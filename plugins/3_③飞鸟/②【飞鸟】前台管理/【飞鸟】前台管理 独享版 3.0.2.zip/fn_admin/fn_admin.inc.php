<?php
/**
 *	[【飞鸟】前台管理(fn_admin.{modulename})] (C)2016-2099 Powered by DisM.Taobao.Com.
 *	Version: 1.0
 *	Date: 2018-5-30 10:27
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once (DISCUZ_ROOT .'./source/plugin/fn_admin/Function.inc.php');
require_once libfile('function/new_admincp','plugin/fn_admin');
require_once libfile('function/admin','plugin/fn_admin');

$navtitle = $metadescription = $metakeywords = $Fn_Admin->Config['PluginVar']['Title'];

if(!$_G['uid']){
	showmessage('to_login', '', array(), array('showmsg' => true,'login' => 1));
	exit();
}

if($Fn_Admin->Config['AdminUserInfo']['disable']){//是否禁用
	showmessage($Fn_Admin->Config['LangVar']['DisableErr'], '', array(), array('showmsg' => true,'login' => 1));
	exit();
}

//导航
if($Fn_Admin->Config['AdminUserInfo']['param']['nav']){
	foreach($Fn_Admin->Config['AdminUserInfo']['param']['nav'] as $Key => $Val) {
		if(!$Key){$Default = $Val;}
		$Menu[$Val] = $Fn_Admin->Config['LangVar']['NavArray'][$Val];
	}
}else{
	showmessage($Fn_Admin->Config['LangVar']['NavErr'], '', array(), array('showmsg' => true,'login' => 1));
	exit();
}

$NavIco = array(
	'global'=>'fa-windows',
	'house'=>'fa-h-square',
	'job'=>'fa-chrome',
	'xiangqin'=>'fa-gratipay',
	'renovation'=>'fa-joomla',
	'fenlei'=>'fa-file-text',
	'shops'=>'fa-sitemap',
	'live'=>'fa-youtube-play',
	'hd'=>'fa-odnoklassniki-square',
	'wxq'=>'fa-wechat',
	'crm'=>'fa-user'
);

$LeftNavIco = array(
	'global_ico'=>array(
		'data_statistics'=>'fa-bar-chart font-size-16',
		'config'=>'fa-cog',
		'user_list'=>'fa-user font-size-16',
		'search_list'=>'fa-bar-chart font-size-14',
		'search_list_log'=>'fa-reorder font-size-16',
		'wx_menu'=>'fa-navicon font-size-16',
		'wx_response'=>'fa-commenting font-size-16',
		'wx_resource'=>'fa-photo font-size-16',
		'wx_scene_qr'=>'fa-qrcode font-size-16',
		'domain'=>'fa-chain',
		'order_list'=>'fa-file-text',
		'sendsms_log_list'=>'fa-envelope',
		'list_do_log'=>'fa-history'
	),
	'xiangqin_ico'=>array(
		'data_statistics'=>'fa-bar-chart font-size-16',
		'config'=>'fa-cog',
		'rewrite'=>'fa-unlink',
		'order_list'=>'fa-file-text',
		'gift_list'=>'fa-gift',
		'meal_list'=>'fa-google-plus-square font-size-16',
		'user_list'=>'fa-user font-size-16',
		'user_follow_log_list'=>'fa-file-text font-size-14',
		'user_pull_log_list'=>'fa-sitemap font-size-16',
		'look_list'=>'fa-reorder',
		'follow_list'=>'fa-heart',
		'user_report_list'=>'fa-exclamation-triangle',
		'user_contact_log_list'=>'fa-eye',
		'user_far_single_list'=>'fa-recycle',
		'con_log_list'=>'fa-dollar',
		'verify_list'=>'fa-vcard font-size-12',
		'wx_menu'=>'fa-navicon font-size-16',
		'wx_response'=>'fa-commenting font-size-16',
		'wx_resource'=>'fa-photo font-size-16',
		'wx_scene_qr'=>'fa-qrcode font-size-16',
		'wx_export_info'=>'fa-file-text font-size-14',
		'activity_list'=>'fa-flag-checkered',
		'mat_list'=>'fa-map-pin',
		'entrance_link'=>'fa-link',
		'language_pack'=>'fa-font'
	),
	'house_ico'=>array(
		'data_statistics'=>'fa-bar-chart font-size-16',
		'config'=>'fa-cog',
		'rewrite'=>'fa-unlink',
		'wx_menu'=>'fa-navicon font-size-16',
		'wx_response'=>'fa-commenting font-size-16',
		'wx_resource'=>'fa-photo font-size-16',
		'wx_scene_qr'=>'fa-qrcode font-size-16',
		'wx_export_info'=>'fa-file-text font-size-14',
		'order_list'=>'fa-file-text',
		'disc_list'=>'fa-building font-size-16',
		'disc_access_record_list'=>'fa-reorder font-size-16',
		'agent_list'=>'fa-flag font-size-16',
		'agent_group_list'=>'fa-google-plus-square font-size-16',
		'agent_user_list'=>'fa-user',
		'wallet_log_list'=>'fa-dollar',
		'info_list'=>'fa-home font-size-18',
		'access_record_list'=>'fa-reorder font-size-16',
		'info_pay_log_list'=>'fa-shopping-cart font-size-16',
		'demand_list'=>'fa-exchange font-size-16',
		'report_list'=>'fa-exclamation-triangle font-size-16',
		'entrust_list'=>'fa-handshake-o font-size-14',
		'article_list'=>'fa-file-text-o',
		'entrance_link'=>'fa-link',
		'language_pack'=>'fa-font'
	),
	'job_ico'=>array(
		'data_statistics'=>'fa-bar-chart font-size-16',
		'config'=>'fa-cog',
		'rewrite'=>'fa-unlink',
		'wx_menu'=>'fa-navicon font-size-16',
		'wx_response'=>'fa-commenting font-size-16',
		'wx_resource'=>'fa-photo font-size-16',
		'wx_menu'=>'fa-wechat font-size-16',
		'wx_scene_qr'=>'fa-qrcode font-size-16',
		'wx_export_info'=>'fa-file-text font-size-14',
		'order_list'=>'fa-file-text',
		'company_group_list'=>'fa-google-plus-square font-size-16',
		'company_list'=>'fa-home font-size-18',
		'company_wallet_log_list'=>'fa-dollar',
		'company_follow_list'=>'fa-star',
		'resume_list'=>'fa-vcard font-size-14',
		'see_resume_list'=>'fa-cloud-download',
		'resume_report_list'=>'fa-exclamation-triangle',
		'info_list'=>'fa-suitcase',
		'apply_info_list'=>'fa-reorder',
		'interview_list'=>'fa-eye',
		'report_list'=>'fa-exclamation-triangle',
		'info_refresh_log_list'=>'fa-refresh',
		'fair_list'=>'fa-flag',
		'hr_tools_list'=>'fa-folder',
		'article_list'=>'fa-file-text-o',
		'entrance_link'=>'fa-link',
		'language_pack'=>'fa-font'
	),
	'renovation_ico'=>array(
		'data_statistics'=>'fa-bar-chart font-size-16',
		'config'=>'fa-cog',
		'order_list'=>'fa-file-text',
		'company_group_list'=>'fa-google-plus-square font-size-16',
		'company_list'=>'fa-home font-size-18',
		'community_list'=>'fa-university font-size-14',
		'case_list'=>'fa-image font-size-16',
		'build_list'=>'fa-sitemap font-size-16',
		'design_list'=>'fa-users font-size-14',
		'form_list'=>'fa-building font-size-16',
		'material_class_list'=>'fa-reorder',
		'material_company_group_list'=>'fa-google-plus-square font-size-16',
		'material_company_list'=>'fa-home font-size-18',
		'material_case_list'=>'fa-image font-size-14',
		'material_goods_list'=>'fa-shopping-cart font-size-16',
		'material_form_list'=>'fa-building font-size-16',
		'artisan_list'=>'fa-user',
		'entrance_link'=>'fa-link',
		'language_pack'=>'fa-font'
	),
	'fenlei_ico'=>array(
		'data_statistics'=>'fa-bar-chart font-size-16',
		'config'=>'fa-cog',
		'rewrite'=>'fa-unlink',
		'region_list'=>'fa-map-marker',
		'class_list'=>'fa-reorder',
		'temp_list'=>'fa-file-code-o',
		'member_list'=>'fa-user',
		'info_list'=>'fa-suitcase font-size-16',
		'info_group_list'=>'fa-google-plus-square font-size-16',
		'info_action_list'=>'fa-users font-size-14',
		'info_refresh_list'=>'fa-refresh',
		'info_report_list'=>'fa-exclamation-triangle',
		'wx_menu'=>'fa-navicon font-size-16',
		'wx_response'=>'fa-commenting font-size-16',
		'wx_resource'=>'fa-photo font-size-16',
		'wx_menu'=>'fa-wechat font-size-16',
		'wx_scene_qr'=>'fa-qrcode font-size-16',
		'wx_export_info'=>'fa-file-text font-size-14',
		'order_list'=>'fa-file-text',
		'entrance_link'=>'fa-link',
		'language_pack'=>'fa-font'
	),
	'shops_ico'=>array(
		'data_statistics'=>'fa-bar-chart font-size-16',
		'config'=>'fa-cog',
		'rewrite'=>'fa-unlink',
		'album_class_list'=>'fa-photo font-size-16',
		'class_list'=>'fa-reorder',
		'shops_list'=>'fa-sitemap font-size-16',
		'shops_group_list'=>'fa-google-plus-square font-size-16',
		'shops_follow_list'=>'fa-star',
		'shops_action_list'=>'fa-users font-size-14',
		'order_list'=>'fa-file-text',
		'entrance_link'=>'fa-link',
		'language_pack'=>'fa-font'
	),
	'live_ico'=>array(
		'data_statistics'=>'fa-bar-chart font-size-16',
		'config'=>'fa-cog',
		'order_list'=>'fa-file-text',
		'number_list'=>'fa-bullseye',
		'gift_list'=>'fa-gift',
		'participant_list'=>'fa-user',
		'live_list'=>'fa-youtube-play',
		'info_list'=>'fa-photo font-size-16',
		'comment_list'=>'fa-commenting',
		'gift_log_list'=>'fa-shopping-bag font-size-16',
		'redpacket_log_list'=>'fa-money font-size-16',
		'invite_log_list'=>'fa-street-view',
		'visit_log_list'=>'fa-users font-size-12',
		'live_pay_log_list'=>'fa-dollar',
		'entrance_link'=>'fa-link',
		'language_pack'=>'fa-font'
	),
	'hd_ico'=>array(
		'data_statistics'=>'fa-bar-chart font-size-16',
		'config'=>'fa-cog',
		'order_list'=>'fa-file-text',
		'vip_list'=>'fa-vcard font-size-16',
		'class_list'=>'fa-reorder',
		'field_list'=>'fa-arrows',
		'list'=>'fa-flag-checkered',
		'sign_up_list'=>'fa-user',
		'post_list'=>'fa-commenting',
		'entrance_link'=>'fa-link',
		'language_pack'=>'fa-font'
	),
	'wxq_ico'=>array(
		'data_statistics'=>'fa-bar-chart font-size-16',
		'config'=>'fa-cog',
		'order_list'=>'fa-file-text',
		'class_list'=>'fa-reorder',
		'info_list'=>'fa-wechat',
		'info_see_log_list'=>'fa-dollar',
		'entrance_link'=>'fa-link',
		'language_pack'=>'fa-font'
	),
	'crm_ico'=>array(
		'data_statistics'=>'fa-bar-chart font-size-14',
		'config'=>'fa-cog',
		'all_customer_list'=>'fa-users font-size-14',
		'customer_common_list'=>'fa-arrows font-size-16',
		'customer_recovery_list'=>'fa-minus-square font-size-16',
		'customer_follow_list'=>'fa-reorder font-size-16',
		'customer_receive_log_list'=>'fa-file-text font-size-16',
		'member_list'=>'fa-user-circle font-size-16'
	)
);

$_GET['mod'] = $_GET['mod'] ? $_GET['mod'] : $Default;

$Ico = $_GET['mod'].'_ico';

$Fn_Admin->Config['ModUrl'] = $Fn_Admin->Config['Url'].'&mod='.$_GET['mod'];

$IframeUrl = strpos($Fn_Admin->GetFullUrl(),'iframe') ?  $Fn_Admin->GetFullUrl() : $Fn_Admin->GetFullUrl().'&iframe=true';

include DISCUZ_ROOT.'./source/plugin/fn_admin/mod/mod_'.$_GET['mod'].'.php';

$Fn_Admin->Config['ItemUrl'] = $Fn_Admin->Config['ModUrl'].'&item='.$_GET['item'];
$Fn_Admin->Config['IframeItemUrl'] = $Fn_Admin->Config['ItemUrl'].'&iframe=true';
$Fn_Admin->Config['IframeModUrl'] = $Fn_Admin->Config['ModUrl'].'&iframe=true';

include template('fn_admin:admin');
?>