<?php

header('Access-Control-Allow-Origin:*');
header('Access-Control-Allow-Headers:*');
if($_SERVER['REQUEST_METHOD'] == 'OPTIONS'){
	echo 'ok';exit();
}
@require_once (DISCUZ_ROOT .'./source/plugin/fn_assembly/app.inc.php');
@require_once (DISCUZ_ROOT .'./source/plugin/fn_admin/Function.inc.php');
$postData = file_get_contents('php://input');
$postData = base64Decode(json_decode($postData,true));
function checkToken($token){
	list($token,$userId) = explode('userId',$token);
	list($bearer,$token) = explode('Bearer ',$token);
	$user = C::t('#fn_admin#fn_admin_staff')->fetch_by_id($userId);
	if(substr(md5($user['username']),0,20).substr(md5($user['password']),0,20).substr(md5($user['code']),0,20) == $token){
		return $user;
	}else if($user['id']){
		baseJosn(array(),'���ݲ�ƥ��','404');
	}
}
if(!in_array($_GET['mod'],array('common')) && !in_array($_GET['item'],array('common'))){
	$user = checkToken($_SERVER['HTTP_AUTHORIZATION']);
	$microTime = microtime(true);
	if(!$user['id']){
		baseJosn(array(),'�û�������','201');
	}else{
		$user['adminName'] = $Fn_Admin->Config['PluginVar']['admin_title'];
	}
}
@include DISCUZ_ROOT.'./source/plugin/fn_admin/api/common/function.inc.php';
@include DISCUZ_ROOT.'./source/plugin/fn_admin/api/'.$_GET['mod'].'/'.$_GET['item'].'.inc.php';