<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}

require_once (DISCUZ_ROOT .'./source/plugin/fn_admin/Function.inc.php');
$Operation = in_array($_GET['Operation'], array('Del','Add','Edit')) ? $_GET['Operation'] : 'List';
$CpMsgUrl = 'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod='.$module['name'];
if($Operation == 'List'){//�б�
	if(!submitcheck('Submit')) {
		/* ��ѯ���� */
		$MpUrl = ADMINSCRIPT.'?'.rawurldecode(cpurl());
		foreach($_GET as $key => $val){
			$MpUrl.= '&'.$key.'='.$val;
		}
		$Where = '';
		$Order = 'G.id';
		$Limit = 30;
		$Page = $_GET['page']?intval($_GET['page']):1;
		/* ��ѯ���� End */
		/* ģ����� */
		$TdStyle = array('width="60"','');
		$FormUrl = ltrim(rawurldecode(cpurl()),'action=');
		showtagheader('div', 'Module', true);
		showformheader($FormUrl,'enctype="multipart/form-data"');
		showtableheader('');
		showsubtitle(array(
			'ID',
			$Fn_Admin->Config['LangVar']['UserGroupNameTitle'],
			$Fn_Admin->Config['LangVar']['OperationTitle']
		), 'header tbm',$TdStyle);
		
		$ModulesList = GetModulesList($Page,$Limit,$Where,$Order);
		$OpCpUrl = ADMINSCRIPT.'?'.rawurldecode(cpurl());
		foreach ($ModulesList as $Module) {
			showtablerow('', array('class="td25"','class="td28"'), array(
				$Module['id'],
				$Module['title'],
				'<a href="'.$OpCpUrl.'&Operation=Edit&gid='.$Module['id'].'">'.$Fn_Admin->Config['LangVar']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&Operation=Del&gid='.$Module['id'].'&formhash='.FORMHASH.'">'.$Fn_Admin->Config['LangVar']['DelTitle'].'</a>',
			));
		}
		showsubmit('','','','<a href="'.$OpCpUrl.'&Operation=Add">'.$Fn_Admin->Config['LangVar']['AddUserGroup'].'</a>',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));
        showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');
		/* ģ����� End */
	}
}else if($Operation == 'Del' && $_GET['formhash'] == formhash() && $_GET['gid']){//ɾ��
	$GId = intval($_GET['gid']);
	DB::delete($Fn_Admin->TableUserGroup,'id ='.$GId);
	cpmsg($Fn_Admin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');

}else if(in_array($Operation,array('Add','Edit'))){//���ӻ�༭
	$GId = intval($_GET['gid']);
	$Item = $GId ? $Fn_Admin->QueryOne($Fn_Admin->TableUserGroup,$GId) : array();
	if($Item){$Item['groups'] = unserialize($Item['groups']);}
	$OpTitle = $Fn_Admin->Config['LangVar']['AddTitle'];
	if(!submitcheck('DetailSubmit')) {
		if($Item) {
			$OpTitle = $Fn_Admin->Config['LangVar']['EditTitle'];
		}

		$FormUrl = ltrim(rawurldecode(cpurl()),'action=');
		showformheader($FormUrl,'enctype');
		showtableheader();
		showtitle($OpTitle);
		showsetting($Fn_Admin->Config['LangVar']['UserGroupNameTitle'], 'title', $Item['title'], 'text');
		
		showsetting($Fn_Admin->Config['LangVar']['GlobalJurisdiction'],array('groups',$Fn_Admin->DyadicArray($Fn_Admin->Config['LangVar']['GlobalJurisdictionArray'])),$Item['groups'],'mcheckbox','','');

		showsetting($Fn_Admin->Config['LangVar']['XiangQinJurisdiction'],array('groups',$Fn_Admin->DyadicArray($Fn_Admin->Config['LangVar']['XiangQinJurisdictionArray'])),$Item['groups'],'mcheckbox','','');

		showsetting($Fn_Admin->Config['LangVar']['HouseJurisdiction'],array('groups',$Fn_Admin->DyadicArray($Fn_Admin->Config['LangVar']['HouseJurisdictionArray'])),$Item['groups'],'mcheckbox','','');

		showsetting($Fn_Admin->Config['LangVar']['JobJurisdiction'],array('groups',$Fn_Admin->DyadicArray($Fn_Admin->Config['LangVar']['JobJurisdictionArray'])),$Item['groups'],'mcheckbox','','');

		showsetting($Fn_Admin->Config['LangVar']['RenovationJurisdiction'],array('groups',$Fn_Admin->DyadicArray($Fn_Admin->Config['LangVar']['RenovationJurisdictionArray'])),$Item['groups'],'mcheckbox','','');

		showsetting($Fn_Admin->Config['LangVar']['FenleiJurisdiction'],array('groups',$Fn_Admin->DyadicArray($Fn_Admin->Config['LangVar']['FenleiJurisdictionArray'])),$Item['groups'],'mcheckbox','','');

		showsetting($Fn_Admin->Config['LangVar']['ShopsJurisdiction'],array('groups',$Fn_Admin->DyadicArray($Fn_Admin->Config['LangVar']['ShopsJurisdictionArray'])),$Item['groups'],'mcheckbox','','');

		showsetting($Fn_Admin->Config['LangVar']['LiveJurisdiction'],array('groups',$Fn_Admin->DyadicArray($Fn_Admin->Config['LangVar']['LiveJurisdictionArray'])),$Item['groups'],'mcheckbox','','');

		showsetting($Fn_Admin->Config['LangVar']['HdJurisdiction'],array('groups',$Fn_Admin->DyadicArray($Fn_Admin->Config['LangVar']['HdJurisdictionArray'])),$Item['groups'],'mcheckbox','','');

		showsetting($Fn_Admin->Config['LangVar']['WxqJurisdiction'],array('groups',$Fn_Admin->DyadicArray($Fn_Admin->Config['LangVar']['WxqJurisdictionArray'])),$Item['groups'],'mcheckbox','','');

		showsetting($Fn_Admin->Config['LangVar']['CrmJurisdiction'],array('groups',$Fn_Admin->DyadicArray($Fn_Admin->Config['LangVar']['CrmJurisdictionArray'])),$Item['groups'],'mcheckbox','','');

		showtablefooter(); /*dism��taobao��com*/
		showsubmit('DetailSubmit');
		showformfooter(); /*Dism_taobao-com*/
	}else{
		$Data['title'] = addslashes(strip_tags($_GET['title']));
		$Data['groups'] = is_array($_GET['groups']) && isset($_GET['groups'])  ? serialize($_GET['groups']) : '';

		if($Item){
			DB::update($Fn_Admin->TableUserGroup,$Data,'id = '.$GId);
		}else{
			$Data['dateline'] =  time();
			DB::insert($Fn_Admin->TableUserGroup,$Data);
		}
		cpmsg($Fn_Admin->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
	}
}

/* �б� */
function GetModulesList($Page,$Limit,$Where=null,$Order){
	global $Fn_Admin;
	$FetchSql = 'SELECT G.* FROM '.DB::table($Fn_Admin->TableUserGroup).' G '.$Where.' order by '.$Order.' asc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}

/* ���� */
function GetModulesCount($Where=null){
	global $Fn_Admin;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_Admin->TableUserGroup).' G '.$Where;
	return DB::result_first($FetchSql);//��������
}
//From: Dism��taobao��com
?>