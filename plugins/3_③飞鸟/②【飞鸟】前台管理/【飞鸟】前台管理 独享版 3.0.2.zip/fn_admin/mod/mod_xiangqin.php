<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!file_exists(DISCUZ_ROOT.'./source/plugin/fn_xiangqin')){
	showmessage($Fn_Admin->Config['LangVar']['NoXiangQin'],'http://dism.taobao.com/?@fn_xiangqin.plugin', array(), array('locationtime'=>true,'refreshtime'=>3, 'showdialog'=>1, 'showmsg' => true));
	exit();
}else{
	@require_once (DISCUZ_ROOT .'./source/plugin/fn_assembly/app.inc.php');
	@require_once (DISCUZ_ROOT.'./source/plugin/fn_xiangqin/config.php');
	//��ർ��
	foreach($Fn_Admin->Config['AdminUserInfo']['param']['xiangqin_left_nav'] as $Key => $Val) {
		if(!$Key){$Default = $Val;}
		$LeftMenu[$Val] = $Fn_Admin->Config['LangVar']['XiangqinLeftNavArray'][$Val];
	}

	$_GET['item'] = $_GET['item'] ? $_GET['item'] : $Default;
}
//From: Dism��taobao��com
?>