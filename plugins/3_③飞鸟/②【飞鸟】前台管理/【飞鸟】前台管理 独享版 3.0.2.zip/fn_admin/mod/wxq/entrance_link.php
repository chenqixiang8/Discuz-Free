<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

showtagheader('div', 'box', true,'box');
showtagheader('div', 'box-body', true,'box-body');
showtagheader('div', 'tab-content', true,'tab-content');
showsetting($Fn_Wxq->Config['LangVar']['PluginLink'], 'PluginLink',$Fn_Wxq->Config['Url'], 'text');
showsetting($Fn_Wxq->Config['LangVar']['PluginLinkArray'][1], 'PluginLink',$Fn_Wxq->Config['Url'].'&app=1', 'text');
showsetting($Fn_Wxq->Config['LangVar']['PluginLinkArray'][2], 'PluginLink',$Fn_Wxq->Config['ListUrl'], 'text');
showsetting($Fn_Wxq->Config['LangVar']['PluginLinkArray'][4], 'PluginLink',$Fn_Wxq->Config['PublishUrl'], 'text');
showsetting($Fn_Wxq->Config['LangVar']['PluginLinkArray'][3], 'PluginLink',$Fn_Wxq->Config['UserInfoListUrl'], 'text');
showsetting($Fn_Wxq->Config['LangVar']['PluginLinkArray'][5], 'PluginLink',$Fn_Wxq->Config['UserInfoSeeLogListUrl'], 'text');
showtagfooter('div');
showtagfooter('div');
showtagfooter('div');

?>