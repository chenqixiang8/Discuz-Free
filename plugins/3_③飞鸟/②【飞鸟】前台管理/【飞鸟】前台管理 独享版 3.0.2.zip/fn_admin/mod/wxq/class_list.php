<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('wxq_all') && !$Fn_Admin->CheckUserGroup('wxq_class_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeItemUrl'];

if(!submitcheck('Submit')){

	showtagheader('div', 'row', true,'row');
	showtagheader('div', 'col-12', true,'col-12');
	showtagheader('div', 'box', true,'box');
	showtagheader('div', 'box-body', true,'box-body');
	showtagheader('div', 'table-responsive', true,'table-responsive');
	showformheader($FormUrl,'enctype="multipart/form-data"');
	showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');

	showsubtitle(array(
		'ID', 
		'display_order',
		$Fn_Wxq->Config['LangVar']['ClassName'],
		$Fn_Wxq->Config['LangVar']['ClassIco'].'('.$Fn_Wxq->Config['LangVar']['ClassIcoTips'].')',
		$Fn_Wxq->Config['LangVar']['DisplayTitle']
	));
	$ModulesList = GetModulesList();

	foreach ($ModulesList as $Module) {
	
		showtablerow('', array('class="tc w50"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
			'<input type="checkbox" class="filled-in" id="checkbox_'.$Module['id'].'" name="delete[]" value="'.$Module['id'].'"><label for="checkbox_'.$Module['id'].'">'.$Module['id'].'</label>',
			'<input type="text" class="input form-control w50" name="displayorder['.$Module['id'].']" value="'.$Module['displayorder'].'" />',
			'<input type="text" class="input form-control w150" name="name['.$Module['id'].']" value="'.$Module['name'].'" />',
			'<a href="'.$Module['ico'].'" target="_blank"><img src="'.$Module['ico'].'" style="height:30px;margin:0 5px 0 0;"></a><input type="hidden" size="30" name="ico['.$Module['id'].']" value="'.$Module['ico'].'" /> <input name="file_ico['.$Module['id'].']" value="" class="txt uploadbtn" type="file" style="width:200px;">',
			'<input class="with-gap" name="display['.$Module['id'].']" type="radio" value="1" '.($Module['display'] ? 'checked="checked"' : '').' id="v_1_new_display_'.$Module['id'].'"/><label class="custom-control-label" for="v_1_new_display_'.$Module['id'].'">'.$Fn_Wxq->Config['LangVar']['DisplayIsTitle'].'</label>&nbsp;&nbsp;<input class="with-gap" name="display['.$Module['id'].']" type="radio" value="0" '.( !$Module['display'] ? 'checked="checked"' : '').' id="v_0_new_display_'.$Module['id'].'"/><label class="custom-control-label" for="v_0_new_display_'.$Module['id'].'">'.$Fn_Wxq->Config['LangVar']['DisplayNoTitle'].'</label>'
		));
	}
	
	showtablerow('', array('class="tc w50"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
		cplang('add_new'),
		sprintf('<input type="text" class="input form-control w50" maxlength="4" name="new_displayorder" value="" />'),
		sprintf('<input type="text" class="input form-control w150" name="new_name" value="" />'),
		sprintf('<input name="new_ico" value="" class="txt uploadbtn" type="file" style="width:266px;">'),
		sprintf('<input class="with-gap" name="new_display" type="radio" value="1" checked="checked" id="v_1_new_display"/><label class="custom-control-label" for="v_1_new_display">'.$Fn_Wxq->Config['LangVar']['DisplayIsTitle'].'</label>&nbsp;&nbsp;<input class="with-gap" name="new_display" type="radio" value="0" id="v_0_new_display"/><label class="custom-control-label" for="v_0_new_display">'.$Fn_Wxq->Config['LangVar']['DisplayNoTitle'].'</label>')
	));
	showsubmit('Submit', '&#20445;&#23384;&#37197;&#32622;', 'del');
    showtablefooter(); /*dism��taobao��com*/
	showformfooter(); /*Dism_taobao-com*/
	showtagfooter('div');
	showtagfooter('div');
	showtagfooter('div');
	showtagfooter('div');
	showtagfooter('div');
}else{
	//ɾ��ѡ��
    if(isset($_POST['delete']) && is_array($_POST['delete'])) {
		foreach($_POST['delete'] as $Id){
			$Id = intval($Id);
			DB::delete($Fn_Wxq->TableClass,'id ='.$Id);
			DB::delete($Fn_Wxq->TableInfo,'classid ='.$Id);
		}
	}
	// ����
    if(isset($_POST['displayorder']) && is_array($_POST['displayorder'])) {
		foreach ($_POST['displayorder'] as $Id => $Displayorder) {
			$UpIns = array();
			$Id = intval($Id);
			$UpIns['name'] =  addslashes(strip_tags($_POST['name'][$Id]));
			$UpIns['displayorder'] =  intval($Displayorder);
			$UpIns['display'] =  intval($_POST['display'][$Id]);
	
			if(!empty($_FILES['file_ico']['size'][$Id])) {
				$Ico = array(
					'name' => $_FILES['file_ico']['name'][$Id],
					'type' => $_FILES['file_ico']['type'][$Id],
					'tmp_name' => $_FILES['file_ico']['tmp_name'][$Id],
					'error' => $_FILES['file_ico']['error'][$Id],
					'size' => $_FILES['file_ico']['size'][$Id]
				);
				$IcoFile = Fn_Upload($Ico,$_POST['ico'][$Id]);
				if($IcoFile['Errorcode']){
					fn_cpmsg($Fn_Wxq->Config['LangVar']['ImgErr'],'','error');
				}else{
					$UpIns['ico'] = $IcoFile['Path'];
				}
			}else{
				$UpIns['ico'] = addslashes(strip_tags($_POST['ico'][$Id]));
			}
			DB::update($Fn_Wxq->TableClass,$UpIns,'id = '.$Id);
		}
    }
	//���ӷ���
    if ($_POST['new_name']) {
		$Ins = array();
		$Ins['name'] = addslashes(strip_tags($_POST['new_name']));
		$Ins['displayorder'] = intval($_POST['new_displayorder']);
		$Ins['display'] = intval($_POST['new_display']);
		if($_FILES['new_ico']['size']){
			$IcoFile = Fn_Upload($_FILES['new_ico']);
			if($IcoFile['Errorcode']){
				fn_cpmsg($Fn_Wxq->Config['LangVar']['ImgErr'],'','error');
			}else{
				$Ins['ico'] = $IcoFile['Path'];
			}
		}
		DB::insert($Fn_Wxq->TableClass,$Ins);
    }
	fn_cpmsg($Fn_Wxq->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
}

/* �б� */
function GetModulesList($Where = null){
	global $Fn_Wxq;
	$FetchSql = 'SELECT * FROM '.DB::table($Fn_Wxq->TableClass).$Where.' order by displayorder asc';
	return DB::fetch_all($FetchSql);//��������
}
//From: Dism_taobao_com
?>