<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('wxq_all') && !$Fn_Admin->CheckUserGroup('wxq_info_see_log_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$SubModel = in_array($_GET['submodel'], array('list','add')) ? $_GET['submodel'] : 'list';
$Fn_Admin->Config['IframeSubModelUrl'] = $Fn_Admin->Config['IframeItemUrl'].'&submodel='.$SubModel;
$NavClass = array($SubModel=>'btn-info Hover');

//����
echo <<<Nav
<div class="SubModelNav">
  <ul>
	<li class="{$NavClass['list']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=list" target="_self">{$Fn_Admin->Config['LangVar']['WxqLeftNavArray']['info_see_log_list']}</a></li>
    <li class="{$NavClass['add']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=add" target="_self">{$Fn_Admin->Config['LangVar']['AddEditTitle']}</a></li>
  </ul>
  <div class="both"></div>
</div>
Nav;

if($SubModel == 'list'){//�б�
	$Do = in_array($_GET['do'], array('Refresh','Del')) ? $_GET['do'] : 'submodel_list';
	//�����ֶ�
	$SearField =array('page','keyword');
	foreach($SearField as $Val) {
		$SearArray[$Val] = $_GET[$Val] || in_array($_GET[$Val],array('0')) ? $_GET[$Val] : '';
	}
	//�����ֶ� End
	$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeSubModelUrl'].'&'.http_build_query($SearArray);


	if($Do == 'submodel_list'){
		if(!submitcheck('Submit')) {
			$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
			$Where = '';
			$Order = in_array($_GET['order'], array('id')) ? 'L.'.addslashes(dhtmlspecialchars($_GET['order'])) : 'L.id';
			
			if($_GET['keyword']){
				$_GET['keyword'] = str_replace(array('%','_'),array('',''),$_GET['keyword']);
				$Where .= ' and (L.username like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\')  or L.uid = '.intval($_GET['keyword']).' or L.iid = '.intval($_GET['keyword']).' )';
			}
			
			$Where = preg_replace('/and/','where',$Where,1);
			$Limit = 20;
			$Page = $_GET['page']?intval($_GET['page']):1;
			/* ��ѯ���� End */
			
			/* ģ����� */	
			showtagheader('div', 'row', true,'row');
			showtagheader('div', 'col-12', true,'col-12');
			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-body', true,'box-body');
			/* ���� */
			$ClassSelected = array($_GET['class']=>' selected');
			$DisplaySelected = array($_GET['display']=>' selected');
			$PaymentStateSelected = array($_GET['payment_state']=>' selected');
			
			$ClassListOption = '<option value="">'.$Fn_Wxq->Config['LangVar']['SelectNull'].'</option>';
			foreach(DB::fetch_all('SELECT * FROM '.DB::table($Fn_Wxq->TableClass).' order by displayorder asc') as $Val) {
				$ClassListOption .= '<option value="'.$Val['id'].'" '.($_GET['classid'] == $Val['id'] ? ' selected' : '' ).'>'.$Val['name'].'</option>';
			}

			echo <<<SEARCH
			<form method="post" autocomplete="off" action="$SearUrl">
				<div class="FormSearchTo" style="margin-bottom:0;">
					<table cellspacing="4" cellpadding="4">
						<tr>
							<th>{$Fn_Wxq->Config['LangVar']['KeywordTitle']}</th><td><input type="text" class="input form-control w200" name="keyword" value="{$_GET['keyword']}">
							&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Admin->Config['LangVar']['SearchSubmit']}" class="btn btn-info" type="submit">
							</td>
						</tr>
					</table>
				</div>
			</form>
SEARCH;
			/* ���� End */
			showtagheader('div', 'table-responsive', true,'table-responsive');
			showformheader($FormUrl,'enctype="multipart/form-data"');
			showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
			showsubtitle(array(
				'ID',
				'UID/'.$Fn_Wxq->Config['LangVar']['UserNameTitle'],
				$Fn_Wxq->Config['LangVar']['Title'],
				$Fn_Wxq->Config['LangVar']['TimeTitle'],
				$Fn_Wxq->Config['LangVar']['UpdateTime'],
				$Fn_Wxq->Config['LangVar']['OperationTitle']
			),'header tbm tc');

			$ModulesList = $Fn_Wxq->InfoListFormat(GetModulesList($Page,$Limit,$Where,$Order));
			
			foreach ($ModulesList as $Module) {
				showtablerow('', array('class="tc w50"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
					'<input type="checkbox" class="filled-in" id="checkbox_'.$Module['id'].'" name="delete[]" value="'.$Module['id'].'"><label for="checkbox_'.$Module['id'].'">'.$Module['id'].'</label>',
					$Module['uid'].'/'.$Module['username'],
					$Module['title'].'&nbsp;&nbsp;<a href="'.$Fn_Wxq->Config['ViewUrl'].$Module['iid'].'" target="_blank">['.cplang('view').']</a>',
					$Module['dateline'] ? date('Y-m-d H:i',$Module['dateline']) : '',
					$Module['updateline'],
					'<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&lid='.$Module['id'].'" class="btn btn-sm btn-info-outline">'.$Fn_Wxq->Config['LangVar']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Del&lid='.$Module['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$Fn_Wxq->Config['LangVar']['DelTitle'].'</a>',
				));
			}

			showsubmit('Submit','&#31435;&#21363;&#25552;&#20132;','del','','',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));

			showtablefooter(); /*dism��taobao��com*/
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			/* ģ�����End */	
		}else{
			if(!$Fn_Admin->CheckUserGroup('wxq_all') && !$Fn_Admin->CheckUserGroup('wxq_del_info_see_log_list')){//Ȩ���ж�
				fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
				exit();
			}

			if(isset($_GET['delete']) && is_array($_GET['delete'])){
				foreach($_GET['delete'] as $Key => $Val) {
					$Val = intval($Val);
					DB::delete($Fn_Wxq->TableSeeLog,'id ='.$Val);
				}

				GetInsertDoLog('del_info_see_log_list_wxq','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete'])));//������¼

				fn_cpmsg($Fn_Wxq->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
			}else{
				fn_cpmsg($Fn_Wxq->Config['LangVar']['DelErr'],'','error');
			}
		}
	}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['lid']){
		if(!$Fn_Admin->CheckUserGroup('wxq_all') && !$Fn_Admin->CheckUserGroup('wxq_del_info_see_log_list')){//Ȩ���ж�
			fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
			exit();
		}
		$lid = intval($_GET['lid']);
		DB::delete($Fn_Wxq->TableSeeLog,'id ='.$lid);
		GetInsertDoLog('del_info_see_log_list_wxq','fn_'.$_GET['mod'],array('id'=>$lid));//������¼
		fn_cpmsg($Fn_Admin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');

	}
}else if($SubModel == 'add'){//���ӻ�༭
	if(!$Fn_Admin->CheckUserGroup('wxq_all') && !$Fn_Admin->CheckUserGroup('wxq_add_info_see_log_list')){//Ȩ���ж�
		fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
		exit();
	}
	$id = intval($_GET['lid']);
	$Item = DB::fetch_first('SELECT * FROM '.DB::table($Fn_Wxq->TableSeeLog).' where id = '.$id);

	if(!submitcheck('DetailSubmit')) {
		$OpTitle = $Fn_Wxq->Config['LangVar']['AddTitle'];
		if($Item){
			$OpTitle = $Fn_Wxq->Config['LangVar']['EditTitle'];
		}

		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-header', true,'with-border box-header');
		showtitle($OpTitle,'class="box-title"');
		showtagfooter('div');
		showformheader($Fn_Admin->Config['IframeSubModelUrl'].'&lid='.$id,'enctype');
		showtagheader('div', 'box-body', true,'box-body');
		

		showsetting('UID', 'new_uid', $Item['uid'], 'text');
		showsetting($Fn_Wxq->Config['LangVar']['WXQID'], 'iid', $Item['iid'], 'text');
		
		if($Item['updateline']){
			showsetting($Fn_Wxq->Config['LangVar']['UpdateTime'], 'updateline',$Item['updateline'] ? date('Y-m-d H:i',$Item['updateline']) : '', 'calendar','','','',1);
		}

		if($Item['dateline']){
			showsetting($Fn_Wxq->Config['LangVar']['TimeTitle'], 'dateline',date('Y-m-d H:i',$Item['dateline']), 'calendar','','','',1);
		}

		showsubmit('DetailSubmit','&#20445;&#23384;&#37197;&#32622;');
		showtagfooter('div');
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');
	}else{
		$Data['uid'] = intval($_GET['new_uid']);
		$Member = DB::fetch_first('SELECT username FROM '.DB::table('common_member').' where uid = '.$Data['uid']);
		$Data['username'] = addslashes(strip_tags($Member['username']));
		$Data['iid'] = intval($_GET['iid']);
		if($Item){
			$Data['dateline'] = strtotime($_GET['dateline']);
			$Data['updateline'] = strtotime($_GET['updateline']);
			GetInsertDoLog('edit_info_see_log_list_wxq','fn_'.$_GET['mod'],array('id'=>$id));//������¼
			DB::update($Fn_Wxq->TableSeeLog,$Data,'id = '.$id);
		}else{
			$Data['dateline'] = $Data['updateline'] = time();
			$Id = DB::insert($Fn_Wxq->TableSeeLog,$Data,true);
			GetInsertDoLog('add_info_see_log_list_wxq','fn_'.$_GET['mod'],array('id'=>$Id));//������¼
		}
		fn_cpmsg($Fn_Wxq->Config['LangVar']['UpdateOk'],$Fn_Admin->Config['IframeItemUrl'].'&submodel=list','succeed');
	}
}


/* �б� */
function GetModulesList($Page,$Limit,$Where=null,$Order){
	global $Fn_Wxq;
	$FetchSql = 'SELECT L.*,I.title FROM '.DB::table($Fn_Wxq->TableSeeLog).' L LEFT JOIN `'.DB::table($Fn_Wxq->TableInfo).'` I on I.id = L.iid '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}

/* ���� */
function GetModulesCount($Where=null){
	global $Fn_Wxq;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_Wxq->TableInfo).' L '.$Where;
	return DB::result_first($FetchSql);//��������
}

?>