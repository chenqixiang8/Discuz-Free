<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('wxq_all') && !$Fn_Admin->CheckUserGroup('wxq_info_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$SubModel = in_array($_GET['submodel'], array('list','add')) ? $_GET['submodel'] : 'list';
$Fn_Admin->Config['IframeSubModelUrl'] = $Fn_Admin->Config['IframeItemUrl'].'&submodel='.$SubModel;
$NavClass = array($SubModel=>'btn-info Hover');

//����
echo <<<Nav
<div class="SubModelNav">
  <ul>
	<li class="{$NavClass['list']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=list" target="_self">{$Fn_Admin->Config['LangVar']['WxqLeftNavArray']['info_list']}</a></li>
    <li class="{$NavClass['add']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=add" target="_self">{$Fn_Admin->Config['LangVar']['AddEditTitle']}</a></li>
  </ul>
  <div class="both"></div>
</div>
Nav;

if($SubModel == 'list'){//�б�
	$Do = in_array($_GET['do'], array('Refresh','Del','Display','PaymentState','Recommend')) ? $_GET['do'] : 'submodel_list';
	//�����ֶ�
	$SearField =array('page','keyword','display','order','payment_state','classid','overdue','recommend');
	foreach($SearField as $Val) {
		$SearArray[$Val] = $_GET[$Val] || in_array($_GET[$Val],array('0')) ? $_GET[$Val] : '';
	}
	//�����ֶ� End
	$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeSubModelUrl'].'&'.http_build_query($SearArray);


	if($Do == 'submodel_list'){
		if(!submitcheck('Submit')) {
			$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
			$Where = '';
			$Order = $_GET['order'] ? 'I.'.addslashes(dhtmlspecialchars($_GET['order'])) : 'I.id';
			
			if($_GET['keyword']){
				$_GET['keyword'] = str_replace(array('%','_'),array('',''),$_GET['keyword']);
				$Where .= ' and (I.title like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or I.username like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\')  or I.uid = '.intval($_GET['keyword']).' or I.id = '.intval($_GET['keyword']).' )';
			}

			if(in_array($_GET['overdue'],array('1')) && $Fn_Wxq->Config['PluginVar']['ExpiryTime']){
				$Where .= ' and I.updateline < '.strtotime("-".intval($Fn_Wxq->Config['PluginVar']['ExpiryTime'])." day",time());
			}

			if(in_array($_GET['recommend'],array('0','1'))){
				$Where .= ' and I.recommend = '.intval($_GET['recommend']);
			}
			
			if(in_array($_GET['display'],array('0','1'))){
				$Where .= ' and I.display = '.intval($_GET['display']);
			}

			if(in_array($_GET['payment_state'],array('0','1'))){
				$Where .= ' and I.payment_state = '.intval($_GET['payment_state']);
			}

			if($_GET['classid']){
				$Where .= ' and I.classid = '.intval($_GET['classid']);
			}

			$Where = preg_replace('/and/','where',$Where,1);
			$Limit = 20;
			$Page = $_GET['page']?intval($_GET['page']):1;
			/* ��ѯ���� End */
		
			/* ģ����� */	
			
			showtagheader('div', 'row', true,'row');
			showtagheader('div', 'col-12', true,'col-12');
			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-body', true,'box-body');
			/* ���� */
			$ClassSelected = array($_GET['class']=>' selected');
			$OverdueSelected = array($_GET['overdue']=>' selected');
			$RecommendSelected = array($_GET['recommend']=>' selected');
			$DisplaySelected = array($_GET['display']=>' selected');
			$PaymentStateSelected = array($_GET['payment_state']=>' selected');
			$OrderSelected = array($_GET['order']=>' selected');
			$ClassListOption = '<option value="">'.$Fn_Wxq->Config['LangVar']['SelectNull'].'</option>';
			foreach(DB::fetch_all('SELECT * FROM '.DB::table($Fn_Wxq->TableClass).' order by displayorder asc') as $Val) {
				$ClassListOption .= '<option value="'.$Val['id'].'" '.($_GET['classid'] == $Val['id'] ? ' selected' : '' ).'>'.$Val['name'].'</option>';
			}

			$OverdueHtml = $Fn_Job->Config['PluginVar']['ExpiryTime'] ? '<th>'.$Fn_Job->Config['LangVar']['IsOverdue'].'</th><td>
							<select name="overdue" class="form-control w120">
								<option value="">'.$Fn_Job->Config['LangVar']['SelectNull'].'</option>
								<option value="1"'.$OverdueSelected['1'].'>'.$Fn_Job->Config['LangVar']['Yes'].'</option>
								<option value="2"'.$OverdueSelected['2'].'>'.$Fn_Job->Config['LangVar']['No'].'</option>
							</select>
							</td>' : '';

			echo <<<SEARCH
			<form method="post" autocomplete="off" action="$SearUrl">
				<div class="FormSearchTo" style="margin-bottom:0;">
					<table cellspacing="4" cellpadding="4">
						<tr>
							<th>{$Fn_Wxq->Config['LangVar']['KeywordTitle']}</th><td><input type="text" class="input form-control w200" name="keyword" value="{$_GET['keyword']}">
							</td>
							<th>{$Fn_Wxq->Config['LangVar']['ClassId']}</th><td>
							<select name="classid" class="form-control w120">
								{$ClassListOption}
							</select>
							</td>
							{$OverdueHtml}
							<th>{$Fn_Wxq->Config['LangVar']['RecommendTitle']}</th><td>
							<select name="recommend" class="form-control w120">
								<option value="">{$Fn_Wxq->Config['LangVar']['SelectNull']}</option>
								<option value="1"{$RecommendSelected['1']}>{$Fn_Wxq->Config['LangVar']['Yes']}</option>
								<option value="0"{$RecommendSelected['0']}>{$Fn_Wxq->Config['LangVar']['No']}</option>
							</select>
							</td>
							<th>{$Fn_Wxq->Config['LangVar']['DisplayTitle']}</th><td>
							<select name="display" class="form-control w120">
								<option value="">{$Fn_Wxq->Config['LangVar']['SelectNull']}</option>
								<option value="1"{$DisplaySelected['1']}>{$Fn_Wxq->Config['LangVar']['Yes']}</option>
								<option value="0"{$DisplaySelected['0']}>{$Fn_Wxq->Config['LangVar']['No']}</option>
							</select>
							</td>
							<th>{$Fn_Wxq->Config['LangVar']['PaymentState']}</th><td>
							
							<select name="payment_state" class="form-control w120">
								<option value="">{$Fn_Wxq->Config['LangVar']['SelectNull']}</option>
								<option value="0"{$PaymentStateSelected['0']}>{$Fn_Wxq->Config['LangVar']['PaymentStateArray'][0]}</option>
								<option value="1"{$PaymentStateSelected['1']}>{$Fn_Wxq->Config['LangVar']['PaymentStateArray'][1]}</option>
							</select>
							</td>
							<th>{$Fn_Admin->Config['LangVar']['Order']}</th><td>
							
							<select name="order" class="form-control w120">
								<option value="dateline"{$OrderSelected['dateline']}>{$Fn_Admin->Config['LangVar']['OrderArray']['dateline']}</option>
								<option value="updateline"{$OrderSelected['updateline']}>{$Fn_Admin->Config['LangVar']['OrderArray']['updateline']}</option>
								<option value="click"{$OrderSelected['click']}>{$Fn_Admin->Config['LangVar']['OrderArray']['click']}</option>
								<option value="topdateline"{$OrderSelected['topdateline']}>{$Fn_Admin->Config['LangVar']['OrderArray']['topdateline']}</option>
							</select>
							&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Admin->Config['LangVar']['SearchSubmit']}" class="btn btn-info" type="submit">
							</td>
						</tr>
					</table>
				</div>
			</form>
SEARCH;
			/* ���� End */

			showtagheader('div', 'table-responsive', true,'table-responsive');
			showformheader($FormUrl,'enctype="multipart/form-data"');
			showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');

			showsubtitle(array(
				'ID',
				'UID/'.$Fn_Wxq->Config['LangVar']['UserNameTitle'],
				$Fn_Wxq->Config['LangVar']['PublishTitle'],
				$Fn_Wxq->Config['LangVar']['ClassId'],
				$Fn_Wxq->Config['LangVar']['Thumbnail'],
				$Fn_Wxq->Config['LangVar']['Qr'],
				$Fn_Wxq->Config['LangVar']['Wx'],
				$Fn_Wxq->Config['LangVar']['Click'],
				$Fn_Wxq->Config['LangVar']['RecommendTitle'],
				$Fn_Wxq->Config['LangVar']['DisplayTitle'],
				$Fn_Wxq->Config['LangVar']['PaymentState'],
				$Fn_Wxq->Config['LangVar']['RefreshTime'],
				$Fn_Wxq->Config['LangVar']['SetTopTime'],
				$Fn_Wxq->Config['LangVar']['TimeTitle'],
				$Fn_Wxq->Config['LangVar']['OperationTitle']
			),'header tbm tc');

			$ModulesList = $Fn_Wxq->InfoListFormat(GetModulesList($Page,$Limit,$Where,$Order));
			
			foreach ($ModulesList as $Module) {
				showtablerow('', array('class="tc w80"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
					'<input type="checkbox" class="filled-in" id="checkbox_'.$Module['id'].'" name="delete[]" value="'.$Module['id'].'"><label for="checkbox_'.$Module['id'].'">'.$Module['id'].'</label>',
					$Module['uid'] ? $Module['uid'].'/'.$Module['username'] : '',
					$Module['title'],
					$Module['class_name'],
					$Module['logo'] ? '<img src="'.$Module['logo'].'" style="height:30px;">' : '',
					$Module['qr'] ? '<img src="'.$Module['qr'].'" style="height:30px;">' : '',
					$Module['wx'],
					$Module['click'],
					$Module['recommend'] ? '<span class="label bg-purple">'.$Fn_Wxq->Config['LangVar']['Yes'].'</span>' : '<span class="label bg-secondary">'.$Fn_Wxq->Config['LangVar']['No'].'</span>',
					!$Module['display'] ? '<span class="label bg-secondary">'.$Fn_Wxq->Config['LangVar']['No'].'</span>' : '<span class="label bg-blue">'.$Fn_Wxq->Config['LangVar']['Yes'].'</span>',
					!$Module['payment_state'] ? '<span class="label bg-secondary">'.$Fn_Wxq->Config['LangVar']['PaymentStateArray']['0'].'</span>' : '<span class="label bg-danger">'.$Fn_Wxq->Config['LangVar']['PaymentStateArray']['1'].'</span>',
					$Module['updateline'],
					$Module['topdateline'] > time() ? date('Y-m-d H:i',$Module['topdateline']) : '',
					date('Y-m-d H:i',$Module['dateline']),
					'<a href="'.$Fn_Wxq->Config['ViewUrl'].$Module['id'].'" target="_blank" class="btn btn-sm btn-dark-outline">'.cplang('view').'</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&iid='.$Module['id'].'" class="btn btn-sm btn-info-outline">'.$Fn_Wxq->Config['LangVar']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Refresh&iid='.$Module['id'].'&formhash='.FORMHASH.'" class="btn btn-sm btn-primary-outline">'.$Fn_Wxq->Config['LangVar']['Refresh'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Recommend&iid='.$Module['id'].'&value='.(!empty($Module['recommend']) ? 0:1).'&formhash='.FORMHASH.'" class="btn btn-sm btn-success-outline">'.(!empty($Module['recommend']) ? $Fn_Wxq->Config['LangVar']['RecommendNoTitle'] : $Fn_Wxq->Config['LangVar']['RecommendTitle']).'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Display&iid='.$Module['id'].'&value='.(!empty($Module['display']) ? 0:1).'&formhash='.FORMHASH.'" class="btn btn-sm btn-warning-outline">'.(!empty($Module['display']) ? $Fn_Wxq->Config['LangVar']['DisplayNoTitle'] : $Fn_Wxq->Config['LangVar']['DisplayIsTitle']).'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=PaymentState&iid='.$Module['id'].'&value='.(!empty($Module['payment_state']) ? 0:1).'&formhash='.FORMHASH.'" class="btn btn-sm btn-purple-outline">'.(!empty($Module['payment_state']) ? $Fn_Wxq->Config['LangVar']['PaymentStateArray'][0] : $Fn_Wxq->Config['LangVar']['PaymentStateArray'][1]).'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Del&iid='.$Module['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$Fn_Wxq->Config['LangVar']['DelTitle'].'</a>',
				));
			}

			showsubmit('Submit','&#31435;&#21363;&#25552;&#20132;','<input name="optype" value="Del" class="with-gap" type="radio" id="v_del"><label class="custom-control-label" for="v_del" style="margin-left:-5px;">'.$Fn_Wxq->Config['LangVar']['DelTitle'].'</label>&nbsp;&nbsp;<input name="optype" value="Refresh" class="with-gap" type="radio" id="v_refresh"><label class="custom-control-label" for="v_refresh">'.$Fn_Wxq->Config['LangVar']['Refresh'].'</label>&nbsp;&nbsp;<input name="optype" value="Display" class="with-gap" type="radio" id="v_display"><label class="custom-control-label" for="v_display">'.$Fn_Wxq->Config['LangVar']['DisplayTitle'].'</label>&nbsp;<select name="new_display" class="form-control w120"><option value="">'.$Fn_Wxq->Config['LangVar']['SelectNull'].'</option><option value="1">'.$Fn_Wxq->Config['LangVar']['Yes'].'</option><option value="0">'.$Fn_Wxq->Config['LangVar']['No'].'</option></select>&nbsp;&nbsp;<input name="optype" value="PaymentState" class="with-gap" type="radio" id="v_paymentstate"><label class="custom-control-label" for="v_paymentstate">'.$Fn_Wxq->Config['LangVar']['PaymentState'].'</label>&nbsp;<select name="new_payment_state" class="form-control w120"><option value="">'.$Fn_Wxq->Config['LangVar']['SelectNull'].'</option><option value="1">'.$Fn_Wxq->Config['LangVar']['PaymentStateArray']['1'].'</option><option value="0">'.$Fn_Wxq->Config['LangVar']['PaymentStateArray']['0'].'</option></select>','','select_all',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));

			showtablefooter(); /*dism��taobao��com*/
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			/* ģ�����End */	
		}else{
			if(isset($_GET['delete']) && is_array($_GET['delete'])){
				if($_GET['optype'] == 'Del'){//ȫɾ
					if(!$Fn_Admin->CheckUserGroup('wxq_all') && !$Fn_Admin->CheckUserGroup('wxq_del_info_list')){//Ȩ���ж�
						fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
						exit();
					}
					foreach($_GET['delete'] as $Key => $Val) {
						$Val = intval($Val);
						DB::delete($Fn_Wxq->TableInfo,'id ='.$Val);
					}
					GetInsertDoLog('del_info_list_wxq','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete'])));//������¼
					fn_cpmsg($Fn_Wxq->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');

				}else if($_GET['optype'] == 'Refresh'){
					foreach($_GET['delete'] as $Key => $Val) {
						$Val = intval($Val);
						$UpData['updateline'] = time();
						DB::update($Fn_Wxq->TableInfo,$UpData,'id = '.$Val);
					}
					GetInsertDoLog('refresh_info_list_wxq','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete'])));//������¼
					fn_cpmsg($Fn_Wxq->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

				}else if($_GET['optype'] == 'Display' && in_array($_GET['new_display'],array('0','1'))){
					foreach($_GET['delete'] as $Key => $Val) {
						$Val = intval($Val);
						$UpData['display'] = intval($_GET['new_display']);
						DB::update($Fn_Wxq->TableInfo,$UpData,'id = '.$Val);
					}
					GetInsertDoLog('display_info_lis_wxq','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete']),'display'=>$_GET['new_display']));//������¼
					fn_cpmsg($Fn_Wxq->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

				}else if($_GET['optype'] == 'PaymentState' && in_array($_GET['new_payment_state'],array('0','1'))){
					foreach($_GET['delete'] as $Key => $Val) {
						$Val = intval($Val);
						$UpData['payment_state'] = intval($_GET['new_payment_state']);
						DB::update($Fn_Wxq->TableInfo,$UpData,'id = '.$Val);
					}
					GetInsertDoLog('payment_state_info_wxq','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete']),'payment_state'=>$_GET['new_payment_state']));//������¼
					fn_cpmsg($Fn_Wxq->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
				}else{
					fn_cpmsg($Fn_Wxq->Config['LangVar']['OpErr'],'','error');
				}	
			}else{
				fn_cpmsg($Fn_Wxq->Config['LangVar']['OpErr'],'','error');
			}	
		}
	}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['iid']){
		if(!$Fn_Admin->CheckUserGroup('wxq_all') && !$Fn_Admin->CheckUserGroup('wxq_del_info_list')){//Ȩ���ж�
			fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
			exit();
		}
		$iid = intval($_GET['iid']);
		DB::delete($Fn_Wxq->TableInfo,'id ='.$iid);
		GetInsertDoLog('del_info_list_wxq','fn_'.$_GET['mod'],array('id'=>$iid));//������¼
		fn_cpmsg($Fn_Admin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');

	}else if($Do == 'Refresh' && $_GET['formhash'] == formhash() && $_GET['iid']){
		$iid = intval($_GET['iid']);
		$UpData['updateline'] = time();
		DB::update($Fn_Wxq->TableInfo,$UpData,'id = '.$iid);
		GetInsertDoLog('refresh_info_list_wxq','fn_'.$_GET['mod'],array('id'=>$iid));//������¼
		fn_cpmsg($Fn_Wxq->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

	}else if($Do == 'Recommend' && $_GET['formhash'] == formhash() && $_GET['iid']){
		$id = intval($_GET['iid']);
		$UpData['recommend'] = intval($_GET['value']);
		DB::update($Fn_Wxq->TableInfo,$UpData,'id = '.$id);
		GetInsertDoLog('recommend_info_wxq','fn_'.$_GET['mod'],array('id'=>$id));//������¼
		fn_cpmsg($Fn_Wxq->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

	}else if($Do == 'Display' && $_GET['formhash'] == formhash() && $_GET['iid']){
		$iid = intval($_GET['iid']);
		$UpData['display'] = intval($_GET['value']);
		DB::update($Fn_Wxq->TableInfo,$UpData,'id = '.$iid);
		GetInsertDoLog('display_info_lis_wxq','fn_'.$_GET['mod'],array('id'=>$iid,'display'=>$_GET['value']));//������¼
		fn_cpmsg($Fn_Wxq->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

	}else if($Do == 'PaymentState' && $_GET['formhash'] == formhash() && $_GET['iid']){
		$iid = intval($_GET['iid']);
		$UpData['payment_state'] = intval($_GET['value']);
		DB::update($Fn_Wxq->TableInfo,$UpData,'id = '.$iid);
		GetInsertDoLog('payment_state_info_wxq','fn_'.$_GET['mod'],array('id'=>$_GET['iid'],'payment_state'=>$_GET['value']));//������¼
		fn_cpmsg($Fn_Wxq->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

	}
}else if($SubModel == 'add'){//���ӻ�༭
	if(!$Fn_Admin->CheckUserGroup('wxq_all') && !$Fn_Admin->CheckUserGroup('wxq_add_info_list')){//Ȩ���ж�
		fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
		exit();
	}
	$iid = intval($_GET['iid']);
	
	$Item = DB::fetch_first('SELECT * FROM '.DB::table($Fn_Wxq->TableInfo).' where id = '.$iid);

	if(!submitcheck('DetailSubmit')) {
		$OpTitle = $Fn_Wxq->Config['LangVar']['AddTitle'];
		if($Item){
			$OpTitle = $Fn_Wxq->Config['LangVar']['EditTitle'];
			$Item['param'] = unserialize($Item['param']);
			$Item['province_text'] = $Fn_Wxq->Area[$Item['province']]['content'].($Item['city'] ? $Fn_Wxq->Area[$Item['city']]['content'] : '').($Item['dist'] ? $Fn_Wxq->Area[$Item['dist']]['content'] : '');
		}

		//ͼƬ�ϴ�
		if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_assembly/class/class_upload.php')){
			@require_once libfile('class/upload','plugin/fn_assembly');
			$UploadConfig = fn_upload::Config();
		}
		
		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-header', true,'with-border box-header');
		showtitle($OpTitle,'class="box-title"');
		showtagfooter('div');
		showformheader($Fn_Admin->Config['IframeSubModelUrl'].'&iid='.$iid,'enctype');
		showtagheader('div', 'box-body', true,'box-body');
		
		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_Wxq->Config['LangVar']['Thumbnail'].':</label><div class="col-sm-9"><div class="AdminSingleUpload"><div class="PhotoControl" id="PhotoControlLogo"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';

		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_Wxq->Config['LangVar']['Qr'].':</label><div class="col-sm-9"><div class="AdminSingleUpload"><div class="PhotoControl" id="PhotoControlQr"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';

		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_Wxq->Config['LangVar']['Album'].':</label><div class="col-sm-9"><div class="AdminSingleUpload"><div class="PhotoControl" id="ImagesPhotoControl"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';
		
		if($Fn_Wxq->Config['PluginVar']['Area']){
			$SmallAreaPositionTreelistHtml = GetTreelistHtml($Fn_Wxq->Area,'SmallAreaPositionList',$Item['province'],$Item['city'],$Item['dist']);
			echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_Wxq->Config['LangVar']['GroupArea'].':</label><div class="col-sm-2"><div style="position:relative;height:40px"><input value="'.$Item['province_text'].'" class="input form-control TreeList" type="text" id="SmallAreaPosition">'.$SmallAreaPositionTreelistHtml.'</div></div><div class="col-sm-7 form-inline"><input type="hidden" name="province" value="'.$Item['province'].'"/><input type="hidden" name="city" value="'.$Item['city'].'"/><input type="hidden" name="dist" value="'.$Item['dist'].'"/></div></div>';
		}
		foreach(DB::fetch_all('SELECT * FROM '.DB::table($Fn_Wxq->TableClass).' order by displayorder asc') as $Key => $Val) {
			if(!$Key){
				$ClassList[] = array('',$Fn_Wxq->Config['LangVar']['SelectNullTo']);
			}
			$ClassList[] = array($Val['id'], $Val['name']);
		}
		if($ClassList){
			showsetting($Fn_Wxq->Config['LangVar']['ClassId'],array('classid',$ClassList),$Item['classid'], 'select');
		}

		showsetting($Fn_Wxq->Config['LangVar']['PublishTitle'], 'title', $Item['title'], 'text');
		showsetting($Fn_Wxq->Config['LangVar']['Wx'], 'wx', $Item['wx'], 'text');
		showsetting($Fn_Wxq->Config['LangVar']['PublishContent'], 'content', str_replace("<br>","\r\n",$Item['content']), 'textarea');
		showsetting($Fn_Wxq->Config['LangVar']['NoWxText'], 'no_wx_text', $Item['param']['no_wx_text'], 'textarea','','',$Fn_Wxq->Config['LangVar']['NoWxTextTips']);
		showsetting($Fn_Wxq->Config['LangVar']['WxText'], 'wx_text', $Item['param']['wx_text'], 'textarea','','',$Fn_Wxq->Config['LangVar']['WxTextTips']);
		showsetting($Fn_Wxq->Config['LangVar']['ApplyBtnTitle'], 'apply_btn',$Item['param']['apply_btn'] ? $Item['param']['apply_btn'] : $Fn_Wxq->Config['LangVar']['ApplyBtn'], 'text');
		showsetting($Fn_Wxq->Config['LangVar']['JumpLink'], 'link', $Item['param']['link'], 'text','','',$Fn_Wxq->Config['LangVar']['JumpLinkTips']);
		showsetting($Fn_Wxq->Config['LangVar']['Money'], 'money', $Item['param']['money'], 'text','','',$Fn_Wxq->Config['LangVar']['MoneyTips']);
		
		showsetting('UID', 'new_uid', $Item['uid']  ? $Item['uid'] : $Fn_Wxq->Config['PluginVar']['AdminAddUid'], 'text');
		showsetting($Fn_Wxq->Config['LangVar']['SetTopTime'], 'topdateline',$Item['topdateline'] ? date('Y-m-d H:i',$Item['topdateline']) : '', 'calendar','','','',1);
		
		if($Item['updateline']){
			showsetting($Fn_Wxq->Config['LangVar']['RefreshTime'], 'updateline',$Item['updateline'] ? date('Y-m-d H:i',$Item['updateline']) : '', 'calendar','','','',1);
		}

		if($Item['dateline']){
			showsetting($Fn_Wxq->Config['LangVar']['TimeTitle'], 'dateline',date('Y-m-d H:i',$Item['dateline']), 'calendar','','','',1);
		}

		showsetting($Fn_Wxq->Config['LangVar']['Click'], 'click', $Item['click'], 'text');

		showsetting($Fn_Wxq->Config['LangVar']['RecommendTitle'], 'recommend', $Item['recommend'], 'radio');

		showsetting($Fn_Wxq->Config['LangVar']['PaymentState'],array('payment_state',DyadicArray($Fn_Wxq->Config['LangVar']['PaymentStateArray'])),$Item ? $Item['payment_state'] : 1,'mradio');

		showsetting($Fn_Wxq->Config['LangVar']['DisplayTitle'], 'display', $Item ? $Item['display'] : 1, 'radio');
		
		showsubmit('DetailSubmit','&#20445;&#23384;&#37197;&#32622;');
		showtagfooter('div');
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');

		$UpLoadHtml  = '';
		if($Item['logo']){
			$LogoJsArray[] = '"'.$Item['logo'].'"';
			$UpLoadHtml .= '
			var InputArray = new Array('.implode(',',$LogoJsArray).');
			$("#PhotoControlLogo").AppUpload({InputName:"new_logo",Multiple:true,InputExist:true,InputArray:InputArray});';

		}else{
			$UpLoadHtml .= '$("#PhotoControlLogo").AppUpload({InputName:"new_logo",Multiple:true});';
		}

		if($Item['qr']){
			$QrJsArray[] = '"'.$Item['qr'].'"';
			$UpLoadHtml .= '
			var InputArray = new Array('.implode(',',$QrJsArray).');
			$("#PhotoControlQr").AppUpload({InputName:"new_qr",Multiple:true,InputExist:true,InputArray:InputArray});';

		}else{
			$UpLoadHtml .= '$("#PhotoControlQr").AppUpload({InputName:"new_qr"});';
		}

		if($Item['param']['album']){
			foreach($Item['param']['album'] as $Key => $Val) {
				$ImagesJsArray[] = '"'.$Val.'"';
			}
			$UpLoadHtml .= '
			var InputArray = new Array('.implode(',',$ImagesJsArray).');
			$("#ImagesPhotoControl").AppUpload({InputName:"new_album",InputExist:true,InputArray:InputArray});';

		}else{
			$UpLoadHtml .= '$("#ImagesPhotoControl").AppUpload({InputName:"new_album"});';
		}

		echo '<script type="text/javascript" src="static/js/calendar.js"></script><script type="text/javascript" src="'.$Fn_Admin->Config['StaticPath'].'/js/jquery.js"></script><script type="text/javascript" src="'.$Fn_Admin->Config['StaticPath'].'/js/common.js"></script><script src="source/plugin/fn_assembly/static/js/mobiscroll.custom-2.16.1.min.js"></script><link rel="stylesheet" href="source/plugin/fn_assembly/static//css/mobiscroll.custom-2.16.1.min.css">'.$UploadConfig['CssJsHtml'];
		
		echo '
			<style>.TreeList{position: absolute;left:0;top:0;z-index:1;}.Tmp{opacity:0;}.Tagging span{font-size:18px;}.Tagging{cursor: pointer;}</style>
			<script>
			$(document).on("click","#SmallAreaPosition",function(){
				GetTreeList($(this),"SmallAreaPositionList","province","city","dist");
				return false;
			});
			'.$UpLoadHtml.'
			</script> 	
		';

	}else{
		
		foreach($_GET['new_logo'] as $Key => $Val) {
			$_GET['new_logo'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}

		foreach($_GET['new_qr'] as $Key => $Val) {
			$_GET['new_qr'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}

		foreach($_GET['new_album'] as $Key => $Val) {
			$_GET['new_album'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}

		$Data['uid'] = intval($_GET['new_uid']);
		$Member = DB::fetch_first('SELECT username FROM '.DB::table('common_member').' where uid = '.$Data['uid']);
		$Data['username'] = addslashes(strip_tags($Member['username']));
		
		$Data['province'] = addslashes(strip_tags($_GET['province']));
		$Data['city'] = addslashes(strip_tags($_GET['city']));
		$Data['dist'] = addslashes(strip_tags($_GET['dist']));
		$Data['classid'] = intval($_GET['classid']);
		$Data['title'] = addslashes(strip_tags($_GET['title']));
		$Data['wx'] = addslashes(strip_tags($_GET['wx']));
		$Data['content'] = addslashes(str_replace("\r\n","<br>",$_GET['content']));
		$Data['click'] = intval($_GET['click']);
		$Data['topdateline'] = $_GET['topdateline'] ? strtotime($_GET['topdateline']) : '';
		$Data['payment_state'] = intval($_GET['payment_state']);
		$Data['recommend'] = intval($_GET['recommend']);
		$Data['display'] = intval($_GET['display']);
		$Data['logo'] = addslashes(strip_tags($_GET['new_logo'][0]));
		$Data['qr'] = addslashes(strip_tags($_GET['new_qr'][0]));
		$Param['no_wx_text'] = addslashes(strip_tags($_GET['no_wx_text']));
		$Param['wx_text'] = addslashes(strip_tags($_GET['wx_text']));
		$Param['apply_btn'] = addslashes(strip_tags($_GET['apply_btn']));
		$Param['link'] = addslashes(strip_tags($_GET['link']));
		$Param['money'] = addslashes(strip_tags($_GET['money']));
		$Param['album'] = is_array($_GET['new_album']) && isset($_GET['new_album'])  ? array_filter($_GET['new_album']) : '';
		$Data['param'] = serialize($Param);

		if($Item){

			$Data['updateline'] = strtotime($_GET['updateline']);

			GetInsertDoLog('edit_info_list_wxq','fn_'.$_GET['mod'],array('id'=>$iid));//������¼
			DB::update($Fn_Wxq->TableInfo,$Data,'id = '.$iid);
		}else{
			$Data['dateline'] = $Data['updateline'] = time();
			$Id = DB::insert($Fn_Wxq->TableInfo,$Data,true);
			GetInsertDoLog('add_info_list_wxq','fn_'.$_GET['mod'],array('id'=>$Id));//������¼
		}
		fn_cpmsg($Fn_Wxq->Config['LangVar']['UpdateOk'],$Fn_Admin->Config['IframeItemUrl'].'&submodel=list','succeed');
		
	}
}


/* �б� */
function GetModulesList($Page,$Limit,$Where=null,$Order){
	global $Fn_Wxq;
	$FetchSql = 'SELECT I.*,C.name as class_name,C.ico FROM '.DB::table($Fn_Wxq->TableInfo).' I LEFT JOIN `'.DB::table($Fn_Wxq->TableClass).'` C on C.id = I.classid '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}

/* ���� */
function GetModulesCount($Where=null){
	global $Fn_Wxq;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_Wxq->TableInfo).' I '.$Where;
	return DB::result_first($FetchSql);//��������
}

?>