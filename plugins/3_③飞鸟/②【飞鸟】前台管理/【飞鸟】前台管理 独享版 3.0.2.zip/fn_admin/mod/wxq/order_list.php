<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('wxq_all') && !$Fn_Admin->CheckUserGroup('wxq_order_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

//����
$_GET['state'] = in_array($_GET['state'],array('0','1')) ? $_GET['state'] : 1;
$NavClass = array($_GET['state']=>'btn-info Hover');

$Do = in_array($_GET['do'], array('AllDel','Del','Refund','Add')) ? $_GET['do'] : 'List';
//�����ֶ�
$SearField =array('page','keyword','start_time','end_time','state','order','refund');
foreach($SearField as $Val) {
	$SearArray[$Val] = $_GET[$Val] || in_array($_GET[$Val],array('0')) ? $_GET[$Val] : '';
}
//�����ֶ� End

$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeItemUrl'].'&'.http_build_query($SearArray);


if($Do == 'List'){
	if(!submitcheck('Submit')) {
		$SearUrl = $Fn_Admin->Config['IframeItemUrl'].'&state='.$_GET['state'];
		/* ��ѯ���� */
		$Where = ' and source = \'fn_wxq\'';
		$Order = 'L.order_id';

		if($_GET['keyword']){
			$_GET['keyword'] = str_replace(array('%','_'),array('',''),$_GET['keyword']);
			$Where .= ' and (L.username like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or L.pubid like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or L.content like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\')  or L.uid = \''.addslashes(strip_tags($_GET['keyword'])).'\' )';
		}
		if($_GET['start_time']){
			$Where .= ' and L.dateline >= '.strtotime($_GET['start_time']);
		}
		if($_GET['end_time']){
			$Where .= ' and L.dateline <= '.strtotime(date('Y-m-d 23:59:59',strtotime($_GET['end_time'])));
		}
		if(in_array($_GET['state'],array('0','1'))){
			$Where .= ' and L.state = '.intval($_GET['state']);
		}

		if(in_array($_GET['refund'],array('0','1'))){
			$Where .= ' and L.refund = '.intval($_GET['refund']);
		}
		
		$Where = preg_replace('/and/','where',$Where,1);
		$Limit = 30;
		$Page = $_GET['page']?intval($_GET['page']):1;
		/* ��ѯ���� End */

		/* ģ����� */
		showtagheader('div', 'row', true,'row');
		showtagheader('div', 'col-12', true,'col-12');
		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-body', true,'box-body');

		echo <<<Nav
		<div class="SubModelNav">
		  <ul>
			<li class="{$NavClass[1]}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&state=1" target="_self">{$Fn_Admin->Config['LangVar']['PayState']['1']}</a></li>
			<li class="{$NavClass[0]}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&state=0" target="_self">{$Fn_Admin->Config['LangVar']['PayState']['0']}</a></li>
		  </ul>
		  <div class="both"></div>
		</div>
Nav;
		/* ���� */
		
		$MidSelected = array($_GET['mid']=>' selected');
		$StateSelected = array($_GET['state']=>' selected');
		$RefundSelected = array($_GET['refund']=>' selected');
		
		if($_GET['state'] == 1){
			$ScreenMoneyCountHtml = $Fn_Admin->Config['LangVar']['ScreenPay'].'<b style="color:red">'.GetModulesScreenMoneyCount($Where).'</b>';
		}
		
		echo <<<SEARCH
		<form method="post" autocomplete="off" action="$SearUrl" id="tb_search">
			<div class="FormSearchTo">
				<table cellspacing="4" cellpadding="4">
					<tr>
						<th>{$Fn_Admin->Config['LangVar']['KeywordTitle']}</th><td><input type="text" class="input form-control w150" name="keyword" value="{$_GET['keyword']}">
						</td>
						<th>{$Fn_Admin->Config['LangVar']['Source']}</th><td><input type="text" class="input form-control w150" name="source" value="{$_GET['source']}">
						</td>
						<th>{$Fn_Admin->Config['LangVar']['StartTime']}</th>
						<td><input type="datetime" class="input w150 form-control" name="start_time" value="{$_GET[start_time]}" id="start_time">
						</td>
						<th>{$Fn_Admin->Config['LangVar']['EndTime']}</th>
						<td><input type="text" class="input w150 form-control" name="end_time" value="{$_GET[end_time]}" id="end_time">
						</td>
						<th>{$Fn_Admin->Config['LangVar']['RefundState']}</th><td>
							<select name="refund" class="form-control w120">
								<option value="">{$Fn_Admin->Config['LangVar']['SelectNull']}</option>
								<option value="1"{$RefundSelected['1']}>{$Fn_Admin->Config['LangVar']['Yes']}</option>
								<option value="0"{$RefundSelected['0']}>{$Fn_Admin->Config['LangVar']['No']}</option>
							</select>
							&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Admin->Config['LangVar']['SearchSubmit']}" class="btn btn-info" type="submit">&nbsp;&nbsp;<a href="{$OpCpUrl}&do=Add" class="btn btn-danger">{$Fn_Admin->Config['LangVar']['AddPubid']}</a>&nbsp;&nbsp;{$ScreenMoneyCountHtml}
						</td>
					</tr>
				</table>
			</div>
		</form>
		<script>
		$('#start_time').fdatepicker({
			format: 'yyyy-mm-dd'
		});
		$('#end_time').fdatepicker({
			format: 'yyyy-mm-dd'
		});
		</script>
SEARCH;
		/* ���� End */

		showtagheader('div', 'table-responsive', true,'table-responsive');
		showformheader($FormUrl,'enctype="multipart/form-data"');
		showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');

		showsubtitle(array(
			$Fn_Admin->Config['LangVar']['PubidTitle'],
			'Uid/'.$Fn_Admin->Config['LangVar']['UserNameTitle'],
			$Fn_Admin->Config['LangVar']['DetailsTitle'],
			$Fn_Admin->Config['LangVar']['MoneyTitle'],
			$Fn_Admin->Config['LangVar']['StateTitle'],
			$Fn_Admin->Config['LangVar']['PaymentType'],
			$Fn_Admin->Config['LangVar']['TimeTitle'].'/'.$Fn_Admin->Config['LangVar']['UpdateTime'],
			$Fn_Admin->Config['LangVar']['RefundDetails'],
			$Fn_Admin->Config['LangVar']['OperationTitle']
		), 'header tbm');
		$ModulesList = GetModulesList($Page,$Limit,$Where,$Order);
		foreach ($ModulesList as $Module) {
			$Module['pay_time'] = $Module['pay_time'] ? date('Y-m-d H:i',$Module['pay_time']) : '';
			showtablerow('',array('class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
				$Module['pubid'],
				$Module['uid'].'/'.$Module['username'],
				stripslashes($Module['content']),
				$Module['money'],
				$Module['state'] ? '<span class="label label-success">'.$Fn_Admin->Config['LangVar']['PayState'][$Module['state']].'</span>' : '<span class="label label-danger">'.$Fn_Admin->Config['LangVar']['PayState'][$Module['state']].'</span>',
				$Module['payment_type'],
				date('Y-m-d H:i',$Module['dateline']).'<br>'.$Module['pay_time'],
				$Module['refund'] ? '<span style="color:red">'.$Fn_Admin->Config['LangVar']['RefundSuccess'].'</span>&nbsp;&nbsp;'.date('Y-m-d H:i',$Module['refund_dateline']).'<br>'.$Fn_Admin->Config['LangVar']['RefundNumber'].'&nbsp;&nbsp;'.$Module['refund_pubid'] : '',
				($Module['pubid'] && $Module['state'] && !$Module['refund'] && in_array($Module['payment_type'],array('app','wx')) ? '<a href="'.$OpCpUrl.'&do=Refund&order_id='.$Module['order_id'].'&formhash='.FORMHASH.'" class="btn btn-sm btn-info-outline">'.$Fn_Admin->Config['LangVar']['Refund'].'</a>&nbsp;&nbsp;' : '').'<a href="'.$OpCpUrl.'&do=Del&order_id='.$Module['order_id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$Fn_Admin->Config['LangVar']['DelTitle'].'</a>'
			));
		}
		showsubmit('','','','&nbsp;&nbsp;&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=AllDel&formhash='.FORMHASH.'" >'.$Fn_Admin->Config['LangVar']['OneKeyDel'].'</a>','',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));
        showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		/* ģ����� End */
	}
}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['order_id']){
	if(!$Fn_Admin->CheckUserGroup($_GET['mod'].'_all') && !$Fn_Admin->CheckUserGroup($_GET['mod'].'_order_del')){//Ȩ���ж�
		fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
		exit();
	}
	DB::delete($Fn_Admin->Pay->TablePayLog,'order_id ='.intval($_GET['order_id']));
	GetInsertDoLog('del_order','fn_'.$_GET['mod'],array('order_id'=>$_GET['order_id']));//������¼
	fn_cpmsg($Fn_Admin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
}else if($Do == 'AllDel' && $_GET['formhash'] == formhash()){
	DB::delete($Fn_Admin->Pay->TablePayLog,'state = 0 and source = \'fn_hd\'');
	fn_cpmsg($Fn_Admin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
}else if($Do == 'Refund' && $_GET['formhash'] == formhash() && $_GET['order_id']){//�˿�
	if(!$Fn_Admin->CheckUserGroup('wxq_all') && !$Fn_Admin->CheckUserGroup('wxq_order_refund')){//Ȩ���ж�
		fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
		exit();
	}
	$Item = DB::fetch_first('SELECT * FROM '.DB::table($Fn_Admin->Pay->TablePayLog).' where order_id = '.intval($_GET['order_id']));
	if($Item['pubid'] && $Item['state'] && !$Item['refund'] && in_array($Item['payment_type'],array('app','wx'))){
		$RefundNo = md5(uniqid());
		$refund = false;
		if($Item['payment_type'] == 'app'){//APP�˿�
			if($Config['PluginVar']['AppType'] == 1){//�����˿�
				$Result = $Fn_Wxq->MagApp->GetMagAccountTransfer($Item['uid'],$Item['money'],$Item['content'],$RefundNo);
			}else if($Config['PluginVar']['AppType'] == 2){//ǧ���˿�
				$Result = $Fn_Wxq->QHApp->GetBalanceAdd($Item['uid'],$Item['money']);
			}
			if($Result['state'] == 200){
				$refund = true;
			}else{
				$Msg = $Result['msg'];
			}
		}else if($Item['payment_type'] == 'wx'){//΢���˿�
			require_once("source/plugin/fn_pay/class/WxPay.Class.php");
			$WxPay = new WxPay;
			$Result = $WxPay->DoRefund($Item['money'],$Item['money'],$RefundNo,$Item['pubid']);
			if($Result['return_code'] == 'SUCCESS'){
				$refund = true;
			}else{
				$Msg = diconv($Result['return_msg'],'UTF-8',CHARSET);
			}
		}
		if($refund){
			DB::update($Fn_Admin->Pay->TablePayLog,array('refund'=>1,'refund_pubid'=>$RefundNo,'refund_dateline'=>time()),'order_id = '.intval($_GET['order_id']));
			GetInsertDoLog('order_refund','fn_'.$_GET['mod'],array('id'=>intval($_GET['order_id'])));//������¼
			fn_cpmsg($Fn_Admin->Config['LangVar']['RefundSuccess'],$CpMsgUrl,'succeed');
		}else{
			fn_cpmsg($Fn_Admin->Config['LangVar']['RefundFail'].$Msg,'','error');
		}
	}else{
		fn_cpmsg($Fn_Admin->Config['LangVar']['OpErr'],'','error');
	}
	exit();
}else if($Do == 'Add'){
	if(!$Fn_Admin->CheckUserGroup($_GET['mod'].'_all') && !$Fn_Admin->CheckUserGroup($_GET['mod'].'_order_add')){//Ȩ���ж�
		fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
		exit();
	}
	if(!submitcheck('DetailSubmit')) {
		$OpTitle = $Fn_Admin->Config['LangVar']['AddTitle'];
		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-header', true,'with-border box-header');
		showtitle($OpTitle,'class="box-title"');
		showtagfooter('div');
		showformheader($Fn_Admin->Config['IframeSubModelUrl'],'enctype');
		showtagheader('div', 'box-body', true,'box-body');
		
		showsetting($Fn_Admin->Config['LangVar']['PubidTitle'], 'pubid', date("YmdHis").rand(10000,9999999), 'text');
		showsetting('uid', 'new_uid', '', 'text');
		showsetting($Fn_Admin->Config['LangVar']['MoneyTitle'], 'money', '', 'text');
		showsetting($Fn_Admin->Config['LangVar']['DetailsTitle'], 'content', '', 'text');
		$PaymentTypeArray = array(
			'alipay'=>'&#25903;&#20184;&#23453;',
			'wx'=>'&#24494;&#20449;',
			'app'=>'&#65;&#80;&#80;&#25903;&#20184;',
			'h5_wx'=>'&#72;&#53;&#24494;&#20449;&#25903;&#20184;',
			'appbyme_wx'=>'&#23567;&#20113;&#65;&#80;&#80;&#24494;&#20449;',
			'palpay'=>'paypal',
			'duigong'=>'&#23545;&#20844;&#25910;&#27454;',
			'caiwu'=>'&#36130;&#21153;&#25910;&#27454;'
		);
		showsetting($Fn_Admin->Config['LangVar']['PaymentType'], array('payment_type',dyadic_array($PaymentTypeArray)),'', 'select');
		showsetting($Fn_Admin->Config['LangVar']['PayTime'], 'pay_time',date('Y-m-d H:i'), 'calendar','','','',1);

		showsubmit('DetailSubmit','&#20445;&#23384;&#37197;&#32622;');
		showtagfooter('div');
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');
	}else{
		$Data['uid'] = intval($_GET['new_uid']);
		$Member = DB::fetch_first('SELECT username FROM '.DB::table('common_member').' where uid = '.$Data['uid']);
		$Data['username'] = addslashes(strip_tags($Member['username']));
		$Data['pubid'] = addslashes(strip_tags($_GET['pubid']));
		$Data['content'] = addslashes(strip_tags($_GET['content']));
		$Data['money'] = addslashes(strip_tags($_GET['money']));
		$Data['source'] = 'fn_'.$_GET['mod'];
		$Data['payment_type'] = addslashes(strip_tags($_GET['payment_type']));
		$Data['pay_time'] = $_GET['pay_time'] ? strtotime($_GET['pay_time']) : '';
		$Data['dateline'] = time();
		$Data['state'] = 1;
		$Id = DB::insert($Fn_Admin->Pay->TablePayLog,$Data,true);
		GetInsertDoLog('add_order','fn_'.$_GET['mod'],array('id'=>$Id));//������¼
		fn_cpmsg($Fn_Admin->Config['LangVar']['UpdateOk'],$Fn_Admin->Config['IframeItemUrl'],'succeed');
	}
}
/* �б� */
function GetModulesList($Page,$Limit,$Where,$Order){
	global $Fn_Admin;
	$FetchSql = 'SELECT M.username as musername,L.* FROM '.DB::table($Fn_Admin->Pay->TablePayLog).' L LEFT JOIN '.DB::table('common_member').' M on M.uid = L.uid '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}

/* ɸѡ���� */
function GetModulesScreenMoneyCount($Where){
	global $Fn_Admin;
	if($Where){
		$Count = DB::result_first('SELECT sum(L.money) FROM '.DB::table($Fn_Admin->Pay->TablePayLog).' L '.$Where.' and L.refund = 0');
		return $Count ? $Count : 0;//��������
	}
}

/* ���� */
function GetModulesCount($Where){
	global $Fn_Admin;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_Admin->Pay->TablePayLog).' L '.$Where;
	return DB::result_first($FetchSql);//��������
}
//From: Dism_taobao_com
?>