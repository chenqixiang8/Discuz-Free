<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if(!$Fn_Admin->CheckUserGroup('wxq_all') && !$Fn_Admin->CheckUserGroup('wxq_config')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

@require_once libfile('function/cache');
@require_once libfile('function/core','plugin/fn_assembly');

$setting_name = 'fn_'.$_GET['mod'].'_setting';
loadcache($setting_name);
$common_setting = $_G['cache'][$setting_name];
$setting = $common_setting = array_filter($common_setting) ? $common_setting : array();
foreach($setting as $key => $value) {
	$setting[$key] = is_array($value) ? $value : stripslashes($value);
}
$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeItemUrl'];

if(!submitcheck('DetailSubmit')) {
	//ͼƬ�ϴ�
	if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_assembly/class/class_upload.php')){
		@require_once libfile('class/upload','plugin/fn_assembly');
		$UploadConfig = fn_upload::Config();
	}

	showtagheader('div', 'box', true,'box');
	showformheader($FormUrl,'enctype');
	if(in_array($Config['PluginVar']['AppType'],array('1','2'))){
		$AppNav = '<li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#app" role="tab" aria-expanded="false"><span class="hidden-sm-up"><i class="ion-email"></i></span> <span class="hidden-xs-down">&#65;&#80;&#80;&#35774;&#32622;</span></a> </li>';
	}
	echo <<<HTML
		<ul class="nav nav-tabs customtab" role="tablist">
          <li class="nav-item"> <a class="nav-link active" data-toggle="tab" href="#basics" role="tab" aria-expanded="true"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#22522;&#30784;&#35774;&#32622;</span></a> </li>
		  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#nav" role="tab" aria-expanded="true"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#23548;&#33322;&#35774;&#32622;</span></a> </li>
		  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#index" role="tab" aria-expanded="true"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#39318;&#39029;&#35774;&#32622;</span></a> </li>
		  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#release" role="tab" aria-expanded="false"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#21457;&#24067;&#35774;&#32622;</span></a> </li>
		  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#share" role="tab" aria-expanded="false"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#20998;&#20139;&#35774;&#32622;</span></a> </li>
		  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#color" role="tab" aria-expanded="false"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#39068;&#33394;&#35774;&#32622;</span></a> </li>
		  {$AppNav}
        </ul>
HTML;

	showtagheader('div', 'box-body', true,'box-body');

	showtagheader('div', 'tab-content', true,'tab-content');

	echo <<<HTML
	<!-- ��������  -->
	<div class="tab-pane active" id="basics" role="tabpanel" aria-expanded="true">
HTML;
	
	showsetting('&#26631;&#39064;', 'setting[Title]', $setting['Title'] ? $setting['Title'] : '&#12304;&#39134;&#40479;&#12305;&#21516;&#22478;&#24494;&#20449;&#32676;', 'text');

	showsetting('&#31649;&#29702;&#21592;&#85;&#105;&#100;&#115;', 'setting[AdminUids]', $setting['AdminUids'], 'text','','','&#26435;&#38480;&#65306;&#21487;&#31649;&#29702;&#25152;&#26377;&#24494;&#20449;&#32676;&#32;&#26684;&#24335;&#65306;&#49;&#44;&#50;&#44;&#51;&#32;&#65281;&#65281;&#65281;&#32;&#27880;&#24847;&#65306;&#35813;&#35774;&#32622;&#21644;&#12304;&#21069;&#21488;&#31649;&#29702;&#12305;&#25554;&#20214;&#26080;&#20851;');

	$setting['OnlineWxPath'] = $setting['OnlineWxPath'] ? $setting['OnlineWxPath'] : '/source/plugin/fn_wxq/static/images/qr.jpg';
	$OnlineWxPathHtml = '<a href="'.$setting['OnlineWxPath'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['OnlineWxPath'].'" height="55"/></a>';
	showsetting('&#23458;&#26381;&#24494;&#20449;&#20108;&#32500;&#30721;', 'new_OnlineWxPath',$setting['OnlineWxPath'], 'filetext', '', 0, $OnlineWxPathHtml);

	showsetting('&#23458;&#26381;&#25991;&#23383;', 'setting[OnlineText]', $setting['OnlineText'] ? $setting['OnlineText'] : '&#32852;&#31995;<br>&#23458;&#26381;', 'text');

	$setting['UserBgPath'] = $setting['UserBgPath'] ? $setting['UserBgPath'] : '/source/plugin/fn_wxq/static/images/user_bg.jpg';
	$UserBgPathHtml = '<a href="'.$setting['UserBgPath'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['UserBgPath'].'" height="55"/></a>&#23610;&#23544;&#65306;&#55;&#50;&#48;&#42;&#50;&#48;&#48;';
	showsetting('&#20250;&#21592;&#39029;&#32972;&#26223;&#22270;&#36335;&#24452;', 'new_UserBgPath',$setting['UserBgPath'], 'filetext', '', 0, $UserBgPathHtml);

	$setting['LogoDefaultPath'] = $setting['LogoDefaultPath'] ? $setting['LogoDefaultPath'] : '/source/plugin/fn_wxq/static/images/logo.png';
	$LogoDefaultPathHtml = '<a href="'.$setting['LogoDefaultPath'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['LogoDefaultPath'].'" height="55"/></a>';
	showsetting('&#40664;&#35748;&#32553;&#30053;&#22270;', 'new_LogoDefaultPath',$setting['LogoDefaultPath'], 'filetext', '', 0, $LogoDefaultPathHtml);

	showsetting('&#21015;&#34920;&#35843;&#29992;&#26465;&#25968;', 'setting[ListNum]', $setting['ListNum'] ? $setting['ListNum'] : '10', 'text');
	
	showsetting('&#21015;&#34920;&#26174;&#31034;&#21457;&#24067;&#25353;&#38062;', 'setting[ListAddSwitch]', $common_setting ? $setting['ListAddSwitch'] : '1', 'radio');
	
	showsetting('&#38750;&#24494;&#20449;&#25552;&#31034;&#35821;', 'setting[NoWxText]', $setting['NoWxText'] ? $setting['NoWxText'] : '&#35831;&#20808;&#28155;&#21152;&#24037;&#20316;&#20154;&#21592;&#24494;&#20449;&#21495;&#65306;{em}{wx}{/em}{br}&#25110;&#20445;&#23384;&#20108;&#32500;&#30721;&#65292;&#22312;&#24494;&#20449;&#35782;&#21035;&#20108;&#32500;&#30721;&#65292;&#28155;&#21152;&#24037;&#20316;&#20154;&#21592;&#65292;&#30003;&#35831;&#20837;&#32676;', 'textarea','','','&#38750;&#24494;&#20449;&#25171;&#24320;&#30340;&#26102;&#20505;&#25552;&#31034;&#35821;<br>&#123;&#119;&#120;&#125;&#20195;&#34920;&#23567;&#32534;&#24494;&#20449;&#21495;&#65292;&#123;&#98;&#114;&#125;&#20026;&#25442;&#34892;&#65292;{em}{/em}&#20026;&#39128;&#32418;');

	showsetting('&#24494;&#20449;&#25552;&#31034;&#35821;', 'setting[WxText]', $setting['WxText'] ? $setting['WxText'] : '&#38271;&#25353;&#20108;&#32500;&#30721;&#35782;&#21035;&#65292;&#28155;&#21152;&#24037;&#20316;&#20154;&#21592;&#65292;&#30003;&#35831;&#20837;&#32676;', 'textarea','','','&#38750;&#24494;&#20449;&#25171;&#24320;&#30340;&#26102;&#20505;&#25552;&#31034;&#35821;<br>&#123;&#119;&#120;&#125;&#20195;&#34920;&#23567;&#32534;&#24494;&#20449;&#21495;&#65292;&#123;&#98;&#114;&#125;&#20026;&#25442;&#34892;&#65292;{em}{/em}&#20026;&#39128;&#32418;');

	showsetting('&#20108;&#32500;&#30721;&#24377;&#31383;&#25552;&#31034;&#35821;', 'setting[PopTips]', $setting['PopTips'], 'textarea');

	$setting['DefaultQrPath'] = $setting['DefaultQrPath'] ? $setting['DefaultQrPath'] : '/source/plugin/fn_wxq/static/images/qr.jpg';
	$DefaultQrPathHtml = '<a href="'.$setting['DefaultQrPath'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['DefaultQrPath'].'" height="55"/></a>';
	showsetting('&#40664;&#35748;&#20108;&#32500;&#30721;', 'new_DefaultQrPath',$setting['DefaultQrPath'], 'filetext', '', 0, $DefaultQrPathHtml);

	showsetting('&#21306;&#22495;&#35774;&#32622;', 'setting[Area]', $setting['Area'], 'textarea','','',lang('plugin/fn_admin', 'MultilevelClassificationTips'));

	showsetting('&#26174;&#31034;&#25512;&#33616;&#24494;&#20449;&#32676;', 'setting[InfoHotSwitch]', $setting ? $setting['InfoHotSwitch'] : '1', 'radio','','','&#35814;&#24773;&#39029;&#26159;&#21542;&#26174;&#31034;&#25512;&#33616;&#24494;&#20449;&#32676;&#21015;&#34920;');

	showsetting('&#26174;&#31034;&#39030;&#37096;&#22266;&#23450;&#23548;&#33322;', 'setting[HeaderSwitch]', $common_setting ? $setting['HeaderSwitch'] : '1', 'radio');

	showsetting('&#35814;&#24773;&#39029;&#26159;&#21542;&#24320;&#21551;', 'setting[ViewSwitch]', $common_setting ? $setting['ViewSwitch'] : '1', 'radio');

	//ˮӡ����
	showsetting('&#24320;&#21551;&#27700;&#21360;',array('setting[watermark]', array(
		array('1','&#26159;', array('watermark_div' => '')),
		array('0','&#21542;', array('watermark_div' => 'none')),
	), TRUE),$setting['watermark'], 'mradio','','','&#24494;&#20449;&#47;&#30005;&#33041;&#29256;&#26377;&#25928;&#65292;&#27880;&#24847;&#65306;&#30001;&#20110;&#65;&#80;&#80;&#26377;&#19978;&#20256;&#32452;&#20214;&#65292;&#25152;&#20197;&#35813;&#35774;&#32622;&#65;&#80;&#80;&#20869;&#26080;&#25928;');
	showtagheader('div', 'watermark_div', $setting['watermark'] == 1 ? true : '','sub');
		$watermark_position_array = array(
			array('1','&#24038;&#19978;'),
			array('2','&#24038;&#20013;'),
			array('3','&#21491;&#19978;'),
			array('4','&#20013;&#24038;'),
			array('5','&#20013;&#38388;'),
			array('6','&#20013;&#21491;'),
			array('7','&#24038;&#19979;'),
			array('8','&#20013;&#19979;'),
			array('9','&#21491;&#19979;'),
		);
		showsetting('&#27700;&#21360;&#20301;&#32622;', array('setting[watermark_status]',$watermark_position_array),$common_setting ? $setting['watermark_status'] : 9,'select');
		showsetting('&#27700;&#21360;&#26465;&#20214;', 'setting[watermark_condition]', $setting['watermark_condition'] ? $setting['watermark_condition'] : '0-0', 'text','','','&#26684;&#24335;&#65306;&#48;&#45;&#48;&#65281;&#65281;&#65281;&#35774;&#32622;&#27700;&#21360;&#28155;&#21152;&#30340;&#26465;&#20214;&#65292;&#23567;&#20110;&#27492;&#23610;&#23544;&#30340;&#22270;&#29255;&#38468;&#20214;&#23558;&#19981;&#28155;&#21152;&#27700;&#21360;');
		
		showsetting('&#74;&#80;&#69;&#71;&#27700;&#21360;&#36136;&#37327;', 'setting[watermark_quality]', $common_setting ? $setting['watermark_quality'] : 90, 'text','','','&#35774;&#32622;&#74;&#80;&#69;&#71;&#31867;&#22411;&#30340;&#22270;&#29255;&#38468;&#20214;&#28155;&#21152;&#27700;&#21360;&#21518;&#30340;&#36136;&#37327;&#21442;&#25968;&#65292;&#33539;&#22260;&#20026;&#32;&#48;&#65374;&#49;&#48;&#48;&#32;&#30340;&#25972;&#25968;&#65292;&#25968;&#20540;&#36234;&#22823;&#32467;&#26524;&#22270;&#29255;&#25928;&#26524;&#36234;&#22909;&#65292;&#20294;&#23610;&#23544;&#20063;&#36234;&#22823;');

		showsetting('&#27700;&#21360;&#31867;&#22411;',array('setting[watermark_type]', array(
			array('png','&#80;&#78;&#71;&#31867;&#22411;&#27700;&#21360;', array('watermark_type_text_div' => 'none','watermark_type_png_div' => '','watermark_type_gif_div' => 'none')),
			array('gif','&#71;&#73;&#70;&#31867;&#22411;&#27700;&#21360;', array('watermark_type_text_div' => 'none','watermark_type_png_div' => 'none','watermark_type_gif_div' => '')),
		), TRUE),$setting['watermark_type'] ? $setting['watermark_type'] : 'png','mradio');

		showtagheader('div', 'watermark_type_png_div', $setting['watermark_type'] == 'png' ? true : '','sub');
			$setting['watermark_png'] = $setting['watermark_png'] ? $setting['watermark_png'] : 'static/image/common/watermark.png';
			$watermark_png_html = '<a href="'.$setting['watermark_png'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['watermark_png'].'" height="55"/></a>&#24314;&#35758;&#23610;&#23544;&#65306;&#49;&#51;&#48;&#32;&#42;&#32;&#52;&#48;';
			showsetting('&#80;&#78;&#71;&#27700;&#21360;', 'new_watermark_png',$setting['watermark_png'], 'filetext', '', 0, $watermark_png_html);
		showtagfooter('div');

		showtagheader('div', 'watermark_type_gif_div', $setting['watermark_type'] == 'gif' ? true : '','sub');
			$setting['watermark_gif'] = $setting['watermark_gif'] ? $setting['watermark_gif'] : 'static/image/common/watermark.gif';
			$watermark_gif_html = '<a href="'.$setting['watermark_gif'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['watermark_gif'].'" height="55"/></a>&#24314;&#35758;&#23610;&#23544;&#65306;&#49;&#51;&#48;&#32;&#42;&#32;&#52;&#48;';
			showsetting('&#71;&#73;&#70;&#27700;&#21360;', 'new_watermark_gif',$setting['watermark_gif'], 'filetext', '', 0, $watermark_gif_html);
			showsetting('&#27700;&#21360;&#34701;&#21512;&#24230;', 'setting[watermark_trans]', $setting['watermark_trans'] ? $setting['watermark_trans'] : 50, 'text','','','&#35774;&#32622;&#71;&#73;&#70;&#31867;&#22411;&#27700;&#21360;&#22270;&#29255;&#19982;&#21407;&#22987;&#22270;&#29255;&#30340;&#34701;&#21512;&#24230;&#65292;&#33539;&#22260;&#20026;&#32;&#49;&#65374;&#49;&#48;&#48;&#32;&#30340;&#25972;&#25968;&#65292;&#25968;&#20540;&#36234;&#22823;&#27700;&#21360;&#22270;&#29255;&#36879;&#26126;&#24230;&#36234;&#20302;&#12290;');
		showtagfooter('div');
		
		showtagheader('div', 'watermark_type_text_div', $setting['watermark_type'] == 'text' ? true : '','sub');
			
		showtagfooter('div');
	showtagfooter('div');
	//ˮӡ���� END

	showsetting('&#31532;&#19977;&#26041;&#32479;&#35745;&#20195;&#30721;', 'setting[Statistics]', $setting['Statistics'], 'textarea');

	echo <<<HTML
	</div>
	<!-- �������� end  -->
HTML;

	echo <<<HTML
	<!-- ��������  -->
	<div class="tab-pane" id="nav" role="tabpanel" aria-expanded="false">
	<script type="text/JavaScript">
	var footernavrowtypedata = [
		[
			[1, '<input type="text" class="form-control w50" name="common_list[footer_nav][displayorder][]" value="">'],
			[1, '<input type="text" class="form-control w200" name="common_list[footer_nav][title][]" value="">'],
			[1, '<input type="text" class="form-control w300" name="common_list[footer_nav][icon][]" value="">'],
			[1, '<input type="text" class="form-control w400" name="common_list[footer_nav][link][]" value="">'],
			[1, '<a href="#" onclick="deleterow(this)" class="btn btn-sm btn-danger-outline">&#21024;&#38500;</a>']
		],
	];
	</script>
HTML;
	//�ײ�����
	echo <<<HTML
	<div class="border box-header margin-top-0"><h5 class="box-title">&#24213;&#37096;&#22266;&#23450;&#23548;&#33322;</h5><p class="margin-bottom-0" style="font-size:12px;">&#23548;&#33322;&#38142;&#25509;&#45;&#91;&#115;&#105;&#116;&#101;&#117;&#114;&#108;&#93;&#20195;&#34920;&#24403;&#21069;&#22495;&#21517;&#65292;&#22914;&#21457;&#24067;&#25353;&#38062;&#31561;&#20110;&#65;&#100;&#100;&#65281;&#65281;&#65281;&#23548;&#33322;&#38142;&#25509;&#31561;&#20110;&#65;&#100;&#100;&#30340;&#26102;&#20505;&#65292;&#22270;&#26631;&#35831;&#25918;&#21457;&#24067;&#25353;&#38062;&#36335;&#24452;&#65281;&#65281;&#65281;<br>&#22270;&#26631;&#21442;&#32771;&#65306;<a href="http://dev.yili6.com/source/plugin/fn_wxq/static/images/fontsize.png" target="_blank">http://dev.yili6.com/source/plugin/fn_wxq/static/images/fontsize.png</a>&#65292;&#27880;&#24847;&#65306;&#22270;&#26631;&#19981;&#29992;&#24102;&#12304;&#38;&#35;&#59;&#12305;&#51;&#20010;&#23383;&#31526;</p></div>
HTML;
	showtableheader('','table table-bordered table-hover display nowrap table-responsive dataTable');
	showsubtitle(array(
		'&#26174;&#31034;&#39034;&#24207;',
		'&#23548;&#33322;&#26631;&#39064;',
		'&#23548;&#33322;&#22270;&#26631;',
		'&#23548;&#33322;&#38142;&#25509;',
		'&#21024;&#38500;'
	),'header tbm tc');
	$FooterNavArray = $common_setting ? $setting['footer_nav'] : array(
		array('displayorder'=>'0','title'=>'&#39318;&#39029;','link'=>'[siteurl]plugin.php?id=fn_wxq','icon'=>'xe721'),
		array('displayorder'=>'1','title'=>'&#21457;&#24067;','link'=>'Add','icon'=>'source/plugin/fn_wxq/static/images/add.png'),
		array('displayorder'=>'2','title'=>'&#25105;&#30340;','link'=>'[siteurl]plugin.php?id=fn_wxq&m=user_info_list','icon'=>'xe605'),
	);
	foreach ($FooterNavArray as $Key => $Nav) {
		showtablerow('', array('class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
			'<input type="text" class="form-control w50" name="common_list[footer_nav][displayorder][]" value="'.$Nav['displayorder'].'">',
			'<input type="text" class="form-control w200" name="common_list[footer_nav][title][]" value="'.$Nav['title'].'">',
			'<input type="text" class="form-control w300" name="common_list[footer_nav][icon][]" value="'.$Nav['icon'].'">',
			'<input type="text" class="form-control w400" name="common_list[footer_nav][link][]" value="'.$Nav['link'].'">',
			'<a href="#" onclick="deleterow(this)" class="btn btn-sm btn-danger-outline">&#21024;&#38500;</a>',
		));
	}
	echo '<tr class="hover"><td class="tc" colspan="10"><a href="#" onclick="addrow(this,footernavrowtypedata, 0)"><i class="fa fa-plus" style="margin-right:5px"></i>&#28155;&#21152;&#23548;&#33322;</a></td></tr>';
	showtablefooter(); /*dism��taobao��com*/
	//�ײ����� End
	
	echo <<<HTML
	</div>
	<!-- �������� end  -->
HTML;

	
	echo <<<HTML
	<!-- ��ҳ����  -->
	<div class="tab-pane" id="index" role="tabpanel" aria-expanded="false">
HTML;

	echo '<div class="form-group row"><label class="col-sm-1 col-form-label">&#27178;&#24133;&#22270;&#29255;:</label><div class="col-sm-9"><div class="UploadBanner"><div class="PhotoControl ClickPhotoControl" id="Banners"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';

	echo '<div class="form-group row"><label class="col-sm-1 col-form-label">&#24191;&#21578;&#22270;</label><div class="col-sm-9"><div class="UploadBanner"><div class="PhotoControl ClickPhotoControl" id="HomeAd"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';

	showsetting('&#26174;&#31034;&#20998;&#31867;&#23548;&#33322;', 'setting[HomeClassSwitch]', $common_setting ? $setting['HomeClassSwitch'] : '1', 'radio','','','&#39318;&#39029;&#26159;&#21542;&#26174;&#31034;&#20998;&#31867;&#22270;&#26631;&#23548;&#33322;');

	showsetting('&#20449;&#24687;&#27969;&#26174;&#31034;&#20998;&#31867;', 'setting[HomeInfoClassSwitch]', $common_setting ? $setting['HomeInfoClassSwitch'] : '1', 'radio','','','&#39318;&#39029;&#20449;&#24687;&#27969;&#26159;&#21542;&#26174;&#31034;&#20998;&#31867;&#65292;&#21542;&#23601;&#26174;&#31034;&#26368;&#26032;&#21457;&#24067;');

	showsetting('&#24320;&#21551;&#25628;&#32034;&#26694;', 'setting[HomeSearchSwitch]', $common_setting ? $setting['HomeSearchSwitch'] : '1', 'radio','','','&#39318;&#39029;&#26159;&#21542;&#24320;&#21551;&#25628;&#32034;&#26694;');
	
	showsetting('&#26174;&#31034;&#28909;&#38376;&#32676;', 'setting[HomeClick]', $setting['HomeClick'], 'radio','','','&#39318;&#39029;&#26159;&#21542;&#26174;&#31034;&#28909;&#38376;&#32676;&#65292;&#25353;&#28857;&#20987;&#29575;&#25490;&#24207;');

	showsetting('&#24320;&#21551;&#21457;&#24067;&#24748;&#28014;&#25353;&#38062;', 'setting[AddFloatSwitch]', $setting['AddFloatSwitch'], 'radio','','','&#39318;&#39029;&#26159;&#21542;&#24320;&#21551;&#21457;&#24067;&#24748;&#28014;&#25353;&#38062;');

	showsetting('&#25512;&#33616;&#32676;&#35843;&#29992;&#26465;&#25968;', 'setting[HomeRecommendNum]', $setting['HomeRecommendNum'] ? $setting['HomeRecommendNum'] : '20', 'text');

	showsetting('&#20844;&#21578;', 'setting[Notice]', $setting['Notice'], 'textarea');

	echo <<<HTML
	</div>
	<!-- ��ҳ���� end  -->
HTML;

	echo <<<HTML
	<!-- ��������  -->
	<div class="tab-pane" id="release" role="tabpanel" aria-expanded="false">
HTML;

	showsetting('&#21457;&#24067;&#26159;&#21542;&#23457;&#26680;', 'setting[InfoAddSwitch]', $setting['InfoAddSwitch'], 'radio');

	showsetting('&#21457;&#24067;&#26174;&#31034;&#32622;&#39030;', 'setting[PublishTopSwitch]', $setting['PublishTopSwitch'], 'radio','','','&#21457;&#24067;&#25104;&#21151;&#21069;&#65292;&#26159;&#21542;&#21487;&#20197;&#36873;&#25321;&#32622;&#39030;');

	showsetting('&#21457;&#24067;&#21306;&#22495;&#26159;&#21542;&#24517;&#22635;', 'setting[AreaFillSwitch]', $setting['AreaFillSwitch'], 'radio');

	showsetting('&#21457;&#24067;&#24320;&#21551;&#35299;&#26512;&#20108;&#32500;&#30721;&#32;', 'setting[AnalysisQr]', $setting['AnalysisQr'], 'radio','','','&#24320;&#21551;&#35813;&#21151;&#33021;&#65292;&#21457;&#24067;&#25552;&#20132;&#30340;&#26102;&#20505;&#65292;&#26377;&#21487;&#33021;&#24433;&#21709;&#24615;&#33021;&#65281;&#35813;&#21151;&#33021;&#30340;&#20316;&#29992;&#26159;&#25226;&#29992;&#25143;&#30340;&#20108;&#32500;&#30721;&#37325;&#26032;&#29983;&#25104;&#19968;&#20010;&#65288;&#19981;&#33021;&#30334;&#20998;&#30334;&#65292;&#21462;&#20915;&#20110;&#29992;&#25143;&#30340;&#20108;&#32500;&#30721;&#35782;&#21035;&#31243;&#24230;&#65289;');

	$setting['AddPath'] = $setting['AddPath'] ? $setting['AddPath'] : '/source/plugin/fn_wxq/static/images/add.png';
	$AddPathHtml = '<a href="'.$setting['AddPath'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['AddPath'].'" height="55"/></a>';
	showsetting('&#21457;&#24067;&#25353;&#38062;&#36335;&#24452;', 'new_AddPath',$setting['AddPath'], 'filetext', '', 0, $AddPathHtml);

	showsetting('&#21457;&#24067;&#36807;&#26399;&#26102;&#38388;', 'setting[ExpiryTime]', $common_setting ? $setting['ExpiryTime'] : 30, 'text','','','&#19981;&#22635;&#21017;&#19981;&#38480;&#21046;&#65292;&#21457;&#24067;&#26102;&#38388;&#36229;&#36807;&#35774;&#32622;&#22825;&#25968;&#21017;&#19981;&#26174;&#31034;&#65292;&#21333;&#20301;&#65306;&#22825;&#65281;&#65281;&#65281;');

	showsetting('&#32676;&#30456;&#20876;&#19978;&#20256;&#24352;&#25968;', 'setting[AlbumNum]', $setting['AlbumNum'], 'text','','','&#48;&#25110;&#31354;&#20195;&#34920;&#19981;&#38480;&#21046;');

	showsetting('&#32676;&#30456;&#20876;&#36229;&#36807;&#24352;&#25968;&#25552;&#31034;&#35821;', 'setting[AlbumNumTips]', $setting['AlbumNumTips'] ? $setting['AlbumNumTips'] : '&#32676;&#30456;&#20876;&#19981;&#33021;&#36229;&#36807;3&#24352;&#21734;', 'text');

	showsetting('&#21457;&#24067;&#37329;&#39069;', 'setting[PublishMoney]', $common_setting ? $setting['PublishMoney'] : 1, 'text','','','&#48;&#25110;&#31354;&#20195;&#34920;&#20813;&#36153;');

	showsetting('&#21457;&#24067;&#25552;&#31034;&#35821;', 'setting[PublishHint]', $setting['PublishHint'] ? $setting['PublishHint'] : '&#35813;&#26465;&#21457;&#24067;&#38656;&#35201;&#25903;&#20184;{Money}&#20803;', 'text');
	
	if(in_array($Config['PluginVar']['AppType'],array('1','2','3'))){
		showsetting('&#65;&#80;&#80;&#21457;&#24067;&#37329;&#39069;', 'setting[AppPublishMoney]', $common_setting ? $setting['AppPublishMoney'] : 1, 'text','','','&#48;&#25110;&#31354;&#20195;&#34920;&#20813;&#36153;');
		showsetting('&#65;&#80;&#80;&#21457;&#24067;&#25552;&#31034;&#35821;', 'setting[AppPublishHint]', $setting['AppPublishHint'] ? $setting['AppPublishHint'] : '&#35813;&#26465;&#21457;&#24067;&#38656;&#35201;&#25903;&#20184;{Money}&#20803;{br}
&#21069;&#24448;APP&#21457;&#24067;&#65292;&#20165;&#38656;{AppMoney}&#20803;&#65292;{Down}', 'textarea');
	}
	
	showsetting('&#32622;&#39030;&#37329;&#39069;', 'setting[TopMoney]', $setting['TopMoney'] ? $setting['TopMoney'] : '30|0.02|&#124;&#32622;&#39030;30&#22825;&#65292;100&#20803;
15|0.01|&#124;&#32622;&#39030;15&#22825;&#65292;70&#20803;','textarea','','','&#19968;&#34892;&#19968;&#20215;&#26684;&#65292;&#26684;&#24335;&#65306;&#22825;&#25968;&#124;&#20215;&#26684;&#124;&#25991;&#23383;<br>&#51;&#48;&#124;&#49;&#48;&#48;&#124;&#32622;&#39030;&#51;&#48;&#22825;&#65292;&#49;&#48;&#48;&#20803;<br>&#49;&#53;&#124;&#55;&#48;&#124;&#32622;&#39030;&#49;&#53;&#22825;&#65292;&#55;&#48;&#20803;');
	
	showsetting('&#21047;&#26032;&#37329;&#39069;', 'setting[RefreshMoney]', $common_setting ? $setting['RefreshMoney'] : 1, 'text');

	showsetting('&#24453;&#23457;&#26680;&#21047;&#26032;&#32622;&#39030;&#25552;&#31034;&#35821;', 'setting[NoDisplayTips]', $setting['NoDisplayTips'] ? $setting['NoDisplayTips'] : '&#35813;&#20449;&#24687;&#27491;&#22312;&#23457;&#26680;&#20013;&#65292;&#26242;&#19981;&#33021;&#21047;&#26032;&#25110;&#32622;&#39030;<br>&#35831;&#32852;&#31995;&#31649;&#29702;&#21592;&#24494;&#20449;&#65306;<span class=FColor>8888888</span>&#24555;&#36895;&#23457;&#26680;', 'textarea');

	showsetting('&#20184;&#36153;&#30003;&#35831;&#21152;&#20837;&#37329;&#39069;', 'setting[ApplyMoney]', $setting['ApplyMoney'], 'text','','','&#31354;&#25110;&#48;&#20195;&#34920;&#20813;&#36153;&#30003;&#35831;&#21152;&#20837;');

	showsetting('&#20184;&#36153;&#30003;&#35831;&#36807;&#26399;&#26102;&#38388;', 'setting[ApplyMoneyExpire]', $setting['ApplyMoneyExpire'], 'text','','','&#20184;&#36153;&#21518;&#22810;&#20037;&#21518;&#37325;&#26032;&#20184;&#36153;&#65292;&#21333;&#20301;&#65306;&#31186;&#65281;&#65281;&#65281;&#31354;&#20195;&#34920;&#19981;&#36807;&#26399;');

	showsetting('&#31105;&#27490;&#21457;&#24067;&#117;&#105;&#100;', 'setting[GlobalProhibitUis]', $setting['GlobalProhibitUis'], 'text','','','&#31105;&#27490;&#29992;&#25143;&#21457;&#24067;&#24494;&#20449;&#32676;&#65281;&#65281;&#65281;&#26684;&#24335;&#65306;&#49;&#44;&#50;&#44;&#51;');

	showsetting('&#31105;&#27490;&#21457;&#24067;&#117;&#105;&#100;&#25552;&#31034;&#35821;', 'setting[GlobalProhibitUisTips]', $setting['GlobalProhibitUisTips'], 'text');

	echo <<<HTML
	</div>
	<!-- �������� end  -->
HTML;

	echo <<<HTML
	<!-- ��������  -->
	<div class="tab-pane" id="share" role="tabpanel" aria-expanded="false">
HTML;
	$setting['InfoCardPath'] = $setting['InfoCardPath'] ? $setting['InfoCardPath'] : 'source/plugin/fn_wxq/static/images/info_card_bg.jpg';
	$InfoCardPathHtml = '<a href="'.$setting['InfoCardPath'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['InfoCardPath'].'" height="55"/></a>&#23610;&#23544;&#55;&#50;&#48;&#32;&#42;&#32;&#57;&#52;&#53;';
	showsetting('&#28023;&#25253;&#32972;&#26223;&#22270;', 'new_InfoCardPath',$setting['InfoCardPath'], 'filetext', '', 0, $InfoCardPathHtml);

	showsetting('&#28023;&#25253;&#20108;&#32500;&#30721;&#25991;&#23383;', 'setting[QrcodeText]', $setting['QrcodeText'] ? $setting['QrcodeText'] : '<p>&#38271;&#25353;&#35782;&#21035;&#20108;&#32500;&#30721;&#65292;&#20102;&#35299;&#26356;&#22810;</p>
<p>&#26469;&#33258;&#12304;&#39134;&#40479;&#24037;&#20316;&#23460;&#12305;</p>', 'textarea');

	showsetting('&#20998;&#20139;&#26631;&#39064;', 'setting[WxTitle]', $setting['WxTitle'] ? $setting['WxTitle'] : '&#12304;&#39134;&#40479;&#12305;&#21516;&#22478;&#24494;&#20449;&#32676;', 'text');

	showsetting('&#20998;&#20139;&#25551;&#36848;', 'setting[WxDes]', $setting['WxDes'] ? $setting['WxDes'] : '&#12304;&#39134;&#40479;&#12305;&#21516;&#22478;&#24494;&#20449;&#32676;', 'textarea');

	$setting['WxImg'] = $setting['WxImg'] ? $setting['WxImg'] : '/source/plugin/fn_wxq/static/images/ico.png';
	$WxImgHtml = '<a href="'.$setting['WxImg'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['WxImg'].'" height="55"/></a>&#23610;&#23544;&#49;&#48;&#48;&#32;&#42;&#32;&#49;&#48;&#48;';
	showsetting('&#20998;&#20139;&#22270;&#29255;', 'new_WxImg',$setting['WxImg'], 'filetext', '', 0, $WxImgHtml);

	echo <<<HTML
	</div>
	<!-- �������� end  -->
HTML;

	echo <<<HTML
	<!-- ��ɫ����  -->
	<div class="tab-pane" id="color" role="tabpanel" aria-expanded="false">
HTML;

	showsetting('&#20027;&#39064;&#39068;&#33394;', 'setting[Color]', $setting['Color'] ? $setting['Color'] : '#2e85f0', 'color');

	showsetting('&#21103;&#20027;&#39064;&#39068;&#33394;', 'setting[FColor]', $setting['FColor'] ? $setting['FColor'] : '#ff4a03', 'color');

	showsetting('&#21103;&#20027;&#39064;&#39068;&#33394;&#50;', 'setting[FFColor]', $setting['FFColor'] ? $setting['FFColor'] : '#f9b63d', 'color');

	showsetting('&#28176;&#21464;&#20027;&#39064;&#39068;&#33394;&#49;&#45;&#48;', 'setting[ChangeColor1_0]', $setting['ChangeColor1_0'] ? $setting['ChangeColor1_0'] : '#2e85f0', 'color');

	showsetting('&#28176;&#21464;&#20027;&#39064;&#39068;&#33394;&#49;&#45;&#49;', 'setting[ChangeColor1_1]', $setting['ChangeColor1_1'] ? $setting['ChangeColor1_1'] : '#85cffe', 'color');

	echo <<<HTML
	</div>
	<!-- ��ɫ���� end  -->
HTML;
	
	if(in_array($Config['PluginVar']['AppType'],array('1','2'))){

	echo <<<HTML
	<!-- APP����  -->
	<div class="tab-pane" id="app" role="tabpanel" aria-expanded="false">
HTML;

	showtagheader('div', 'mag_app_table', $Config['PluginVar']['AppType'] == 1 ? true : '','mag_app_table');
		showsetting('&#39532;&#30002;&#83;&#101;&#99;&#114;&#101;&#116;', 'setting[MagSecret]', $setting['MagSecret'], 'text','','','&#19981;&#22635;&#21017;&#32487;&#25215;&#12304;&#20840;&#23616;&#35774;&#32622;&#12305;&#30340;&#35774;&#32622;');
		showsetting('&#39532;&#30002;&#21161;&#25163;&#83;&#101;&#99;&#114;&#101;&#116;', 'setting[MagAssistantSecret]', $setting['MagAssistantSecret'], 'text','','','&#19981;&#22635;&#21017;&#32487;&#25215;&#12304;&#20840;&#23616;&#35774;&#32622;&#12305;&#30340;&#35774;&#32622;');
		showsetting('&#39532;&#30002;&#21161;&#25163;&#25512;&#36865;', 'setting[MagAssistantPush]', $setting['MagAssistantPush'], 'radio','','','&#19981;&#22635;&#21017;&#32487;&#25215;&#12304;&#20840;&#23616;&#35774;&#32622;&#12305;&#30340;&#35774;&#32622;');
	showtagfooter('div');
	
	showtagheader('div', 'qf_app_table', $Config['PluginVar']['AppType'] == 2 ? true : '','qf_app_table');
		showsetting('&#21315;&#24070;&#25903;&#20184;&#35746;&#21333;&#31867;&#22411;&#73;&#68;', 'setting[qf_type]', $setting['qf_type'], 'text','','','&#19981;&#22635;&#21017;&#32487;&#25215;&#12304;&#20840;&#23616;&#35774;&#32622;&#12305;&#30340;&#35774;&#32622;');
		showsetting('&#21315;&#24070;&#26381;&#21153;&#21495;&#29992;&#25143;&#73;&#68;', 'setting[qf_from_id]', $setting['qf_from_id'], 'text','','','&#19981;&#22635;&#21017;&#32487;&#25215;&#12304;&#20840;&#23616;&#35774;&#32622;&#12305;&#30340;&#35774;&#32622;');
	showtagfooter('div');

	echo <<<HTML
	</div>
	<!-- APP���� end  -->
HTML;
	}

	showsubmit('DetailSubmit', '&#20445;&#23384;&#37197;&#32622;');
	showtagfooter('div');
	showtagfooter('div');
	showformfooter(); /*Dism_taobao-com*/
	showtagfooter('div');
	
	$setting['banners'] = $common_setting ? $setting['banners'] : array(
		array('img'=>'/source/plugin/fn_wxq/static/images/banner.jpg')
	);
	if($setting['banners']){
		foreach($setting['banners'] as $Key => $Val) {
			$banners_js_array[] = '"'.$Val['img'].'|'.$setting['banners'][$Key]['title'].'|'.$setting['banners'][$Key]['link'].'"';
		}
		$UpLoadHtml .= '
		var InputArray = new Array('.implode(',',$banners_js_array).');
		$("#Banners").AppUpload({InputName:"new_banners",InputLink:true,InputExist:true,InputArray:InputArray,Move:true});';
	}else{
		$UpLoadHtml .= '$("#Banners").AppUpload({InputName:"new_banners",InputLink:true,Move:true});';
	}

	if($setting['home_ad']){
		foreach($setting['home_ad'] as $Key => $Val) {
			$home_ad_js_array[] = '"'.$Val['img'].'|'.$setting['home_ad'][$Key]['title'].'|'.$setting['home_ad'][$Key]['link'].'"';
		}
		$UpLoadHtml .= '
		var InputArray = new Array('.implode(',',$home_ad_js_array).');
		$("#HomeAd").AppUpload({InputName:"new_home_ad",InputLink:true,InputExist:true,InputArray:InputArray,Move:true});';
	}else{
		$UpLoadHtml .= '$("#HomeAd").AppUpload({InputName:"new_home_ad",InputLink:true,Move:true});';
	}

	echo $UploadConfig['CssJsHtml'];
	echo '
		<script>
		'.$UpLoadHtml.'
		</script> 	
	';
	
}else{
	
	foreach($_GET['setting'] as $key => $value) {
		$setting[$key] = is_array($value) ? $value : addslashes($value);
	}

	foreach($_GET['upload_admin'] as $key => $value){
		if(strpos($key,'new_') !== false){
			$key_name = str_replace(array('new_'),'',$key);
			$setting[$key_name] = array();
			foreach($_GET[$key] as $k => $v) {
				$setting[$key_name][$k]['img'] = strpos($v,'http') !== false ? $v : $_G['siteurl'].$v;
				$setting[$key_name][$k]['link'] = $_GET[$key.'_link'][$k];
				$setting[$key_name][$k]['title'] = $_GET[$key.'_title'][$k];
			}
		}
	}

	foreach(array('footer_nav') as $common_nav_value){
		foreach($_GET['common_list'][$common_nav_value] as $nav_key => $nav_value){
			foreach($_GET['common_list'][$common_nav_value]['displayorder'] as $key => $value){
				$new_setting[$common_nav_value][$key][$nav_key] = filter_string($_GET['common_list'][$common_nav_value][$nav_key][$key]);
				if($_FILES['common_list']['size'][$common_nav_value]['file_'.$nav_key][$key]){
					$images = array(
						'name' => $_FILES['common_list']['name'][$common_nav_value]['file_'.$nav_key][$key],
						'type' => $_FILES['common_list']['type'][$common_nav_value]['file_'.$nav_key][$key],
						'tmp_name' => $_FILES['common_list']['tmp_name'][$common_nav_value]['file_'.$nav_key][$key],
						'error' => $_FILES['common_list']['error'][$common_nav_value]['file_'.$nav_key][$key],
						'size' => $_FILES['common_list']['size'][$common_nav_value]['file_'.$nav_key][$key]
					);
					$FileCode = Fn_Upload($images);
					$new_setting[$common_nav_value][$key][$nav_key] = $FileCode['Path'];
				}
			}
		}
		$setting[$common_nav_value] = array_sort($new_setting[$common_nav_value],'displayorder');
	}

	foreach($_FILES as $file_key => $file_value){
		if(strpos($file_key,'new_') !== false){
			$key = str_replace(array('TMPnew_','new_'),'',$file_key);
			if($_FILES[$file_key]['size']){
				$FileCode = Fn_Upload($_FILES[$file_key]);
				if($FileCode['Errorcode']){
					cpmsg($Fn_Admin->Config['LangVar']['ImgErr'],'','error');
					exit();
				}else{
					$setting[$key] = $FileCode['Path'];
				}
			}else{
				$file_key = str_replace(array('TMPnew_'),array('new_'),$file_key);
				if(!preg_match('/.*(\.png|\.jpg|\.jpeg|\.gif)$/',$_GET[$file_key]) && $_GET[$file_key]){
					cpmsg($Fn_Admin->Config['LangVar']['ImgErr'],'','error');
					exit();
				}else{
					$setting[$key] = addslashes(strip_tags($_GET[$file_key]));
				}
			}
		}
	}
	savecache($setting_name,$setting);
	fn_cpmsg($Fn_Admin->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
	exit();

}
//From: Dism_taobao_com
?>