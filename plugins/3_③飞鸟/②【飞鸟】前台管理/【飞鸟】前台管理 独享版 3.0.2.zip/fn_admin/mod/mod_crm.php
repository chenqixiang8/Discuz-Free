<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!file_exists(DISCUZ_ROOT.'./source/plugin/fn_crm')){
	showmessage($Fn_Admin->Config['LangVar']['NoCrm'],'http://dism.taobao.com/?@fn_crm.plugin', array(), array('locationtime'=>true,'refreshtime'=>3, 'showdialog'=>1, 'showmsg' => true));
	exit();
}else{
	@require_once (DISCUZ_ROOT .'./source/plugin/fn_assembly/app.inc.php');
	@require_once (DISCUZ_ROOT.'./source/plugin/fn_crm/Function.inc.php');
	
	if($Fn_Crm->Config['setting']['b_c_limit']){
		//����������ʱ��Ŀͻ�
		foreach(DB::fetch_all('SELECT * FROM '.DB::table($Fn_Crm->TableCustomer).' where recovery = 0 and level = 1 and expire_dateline != \'\' and expire_dateline < '.time().' order by id asc') as $Key => $Val) {
			DB::update($Fn_Crm->TableCustomer,array('level'=>2),'id = '.$Val['id']);
		}
		
		$customer_id = array();
		//���δ�����Ŀͻ�
		foreach(DB::fetch_all('SELECT * FROM '.DB::table($Fn_Crm->TableCustomer).' where recovery = 0 and level = 2 and last_follow_dateline != \'\' and last_follow_dateline < '.strtotime('-'.$Fn_Crm->Config['setting']['b_c_limit'].' day').' order by id asc') as $Key => $Val) {
			$customer_id[] = $Val['id'];

		}

		//���δ�����Ŀͻ�
		foreach(DB::fetch_all('SELECT * FROM '.DB::table($Fn_Crm->TableCustomer).' where recovery = 0 and level = 2 and last_follow_dateline = \'\' and receive_dateline < '.strtotime('-'.$Fn_Crm->Config['setting']['b_c_limit'].' day').' order by id asc') as $Key => $Val) {
			$customer_id[] = $Val['id'];
			//DB::update($Fn_Crm->TableCustomer,array('level'=>3,'sale_uid'=>'','drop_dateline'=>time()),'id = '.$Val['id']);
		}
		
		//���δǩԼ�Ŀͻ�
		foreach(DB::fetch_all('SELECT * FROM '.DB::table($Fn_Crm->TableCustomer).' where recovery = 0 and level = 2 and expire_dateline < '.time().' and last_follow_dateline != \'\' and last_follow_dateline < '.strtotime('-'.$Fn_Crm->Config['setting']['b_a_limit'].' day').' order by id asc') as $Key => $Val) {
			$customer_id[] = $Val['id'];
		}

		//���δǩԼ�Ŀͻ�
		foreach(DB::fetch_all('SELECT * FROM '.DB::table($Fn_Crm->TableCustomer).' where recovery = 0 and level = 2 and expire_dateline < '.time().' and last_follow_dateline = \'\' and receive_dateline < '.strtotime('-'.$Fn_Crm->Config['setting']['b_a_limit'].' day').' order by id asc') as $Key => $Val) {
			$customer_id[] = $Val['id'];
		}
		
		if(array_filter($customer_id)){
			DB::update($Fn_Crm->TableCustomer,array('level'=>3,'sale_uid'=>'','last_follow_dateline'=>'','receive_dateline'=>'','drop_dateline'=>time()),'id in('.implode(',',array_unique($customer_id)).')');
		}
	}
	
	//��ർ��
	foreach($Fn_Admin->Config['AdminUserInfo']['param']['crm_left_nav'] as $Key => $Val) {
		if(!$Key){$Default = $Val;}
		$LeftMenu[$Val] = $Fn_Admin->Config['LangVar']['CrmLeftNavArray'][$Val];
	}

	$_GET['item'] = $_GET['item'] ? $_GET['item'] : $Default;
}
//From: Dism��taobao��com
?>