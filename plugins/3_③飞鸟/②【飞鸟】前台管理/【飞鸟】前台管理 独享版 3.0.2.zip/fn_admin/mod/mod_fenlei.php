<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!file_exists(DISCUZ_ROOT.'./source/plugin/fn_fenlei')){
	showmessage('&#20320;&#36824;&#27809;&#26377;&#23433;&#35013;&#39134;&#40479;&#12304;&#21516;&#22478;&#20998;&#31867;&#12305;&#65292;&#27491;&#22312;&#36339;&#36716;&#39134;&#40479;&#12304;&#21516;&#22478;&#20998;&#31867;&#12305;','http://dism.taobao.com/?@fn_fenlei.plugin', array(), array('locationtime'=>true,'refreshtime'=>3, 'showdialog'=>1, 'showmsg' => true));
	exit();
}else{
	@require_once (DISCUZ_ROOT .'./source/plugin/fn_assembly/app.inc.php');
	@require_once (DISCUZ_ROOT.'./source/plugin/fn_fenlei/config.php');

	//��ർ��
	foreach($Fn_Admin->Config['AdminUserInfo']['param']['fenlei_left_nav'] as $Key => $Val) {
		if(!$Key){$Default = $Val;}
		$LeftMenu[$Val] = $Fn_Admin->Config['LangVar']['FenleiLeftNavArray'][$Val];
	}

	$_GET['item'] = $_GET['item'] ? $_GET['item'] : $Default;
}
//From: Dism��taobao��com
?>