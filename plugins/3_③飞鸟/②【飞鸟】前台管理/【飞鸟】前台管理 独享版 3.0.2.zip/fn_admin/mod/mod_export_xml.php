<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
/**
	* exportExcel($data,$title,$filename);
	* ��������Ϊexcel����
	*@param $data    һ����ά����,�ṹ��ͬ�����ݿ�����������
	*@param $title   excel�ĵ�һ�б���,һ������,���Ϊ����û�б���
	*@param $filename ���ص��ļ���
	*@examlpe
	exportExcel($arr,array('id','�˻�','����','�ǳ�'),'�ļ���!');
*/
function exportExcel($Data=array(),$Title=array(),$Filename='report'){
	header("Content-type:application/octet-stream");
	header("Accept-Ranges:bytes");
	header("Content-type:application/vnd.ms-excel"); 
	header("Content-Disposition:attachment;filename=".$Filename.".xls");
	header("Pragma: no-cache");
	header("Expires: 0");
	//����xls��ʼ
	if(!empty($Title)){
		foreach ($Title as $K => $V){
			$Title[$K]=  diconv($V,CHARSET,'GB2312');
		}
		$Title = implode("\t", $Title);
		echo "$Title\n";
	}
	if(!empty($Data)){
		foreach($Data as $Key => $Val){
			foreach($Val as $K => $V){
				$Data[$Key][$K] = diconv($V,CHARSET,'GB2312');
			}
			$Data[$Key] = implode("\t", $Data[$Key]); 
		}
		echo implode("\n",$Data);
	}
}
if($_GET['formhash'] == formhash() && $_GET['type'] == 'order'){
	$SourceArray = $Fn_Admin->Config['LangVar']['order_source_arr'];
	$PaymentTypeArray = $Fn_Admin->Config['LangVar']['order_pay_type_arr'];
	function GetModulesList($Page,$Limit,$Where,$Order){
		global $Fn_Admin;
		$FetchSql = 'SELECT M.username as musername,L.* FROM '.DB::table($Fn_Admin->Pay->TablePayLog).' L LEFT JOIN '.DB::table('common_member').' M on M.uid = L.uid '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
		return DB::fetch_all($FetchSql);//��������
	}
	$Page = 1;
	$Where = ' and L.state = 1';
	$Order = 'L.pay_time';
	$Limit = 10000;
	if($_GET['start_time']){
		$Where .= ' and L.dateline >= '.strtotime($_GET['start_time']);
	}
	if($_GET['end_time']){
		$Where .= ' and L.dateline <= '.strtotime(date('Y-m-d 23:59:59',strtotime($_GET['end_time'])));
	}
	if($_GET['source']){
		$Where .= ' and concat(L.source) like(\'%'.addslashes(dhtmlspecialchars($_GET['source'])).'%\')';
	}

	if($_GET['min_money'] && $_GET['max_money']){
		$Where .= ' and L.money >= '.addslashes(strip_tags($_GET['min_money'])).' and L.money <= '.addslashes(strip_tags($_GET['max_money']));
	}else if($_GET['min_money']){
		$Where .= ' and L.money >= '.addslashes(strip_tags($_GET['min_money']));
	}else if($_GET['max_money']){
		$Where .= ' and L.money <= '.addslashes(strip_tags($_GET['max_money']));
	}
	$Where = preg_replace('/and/','where',$Where,1);
	
	$ModulesList = GetModulesList($Page,$Limit,$Where,$Order);
	if($ModulesList){
		foreach($ModulesList as $key => $val){
			$exportList[$key]['pubid'] = $val['pubid'];
			$exportList[$key]['username'] = $val['uid'] ? $val['uid'].'/'.$val['username'] : '';
			$exportList[$key]['content'] = addslashes(strip_tags($val['content']));
			$exportList[$key]['money'] = $val['money'];
			$exportList[$key]['source'] = $SourceArray[$val['source']];
			$exportList[$key]['payment_type'] = $PaymentTypeArray[$val['payment_type']];
			$exportList[$key]['pay_time'] = date('Y-m-d H:i',$val['pay_time']);
			$exportList[$key]['dateline'] = date('Y-m-d H:i',$val['dateline']);
		}
		exportExcel($exportList,array($Fn_Admin->Config['LangVar']['PubidTitle'],'uid/'.$Fn_Admin->Config['LangVar']['UserNameTitle'],$Fn_Admin->Config['LangVar']['DetailsTitle'],$Fn_Admin->Config['LangVar']['MoneyTitle'],$Fn_Admin->Config['LangVar']['Source'],$Fn_Admin->Config['LangVar']['PaymentType'],$Fn_Admin->Config['LangVar']['PayTime'],$Fn_Admin->Config['LangVar']['TimeTitle']),"order-".date('Y-m-d',time()));
		exit();
	}else{
		fn_cpmsg('&#26242;&#26080;&#25968;&#25454;','','error');
		exit();
	}
}
//From: Dism��taobao��com
?>