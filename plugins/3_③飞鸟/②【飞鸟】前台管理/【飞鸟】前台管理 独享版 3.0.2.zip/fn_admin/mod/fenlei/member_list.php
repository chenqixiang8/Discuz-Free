<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('fenlei_all') && !$Fn_Admin->CheckUserGroup('fenlei_member_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$SubModel = in_array($_GET['submodel'], array('list','add')) ? $_GET['submodel'] : 'list';
$Fn_Admin->Config['IframeSubModelUrl'] = $Fn_Admin->Config['IframeItemUrl'].'&submodel='.$SubModel;
$NavClass = array($SubModel=>'btn-info Hover');

//����
echo <<<Nav
<div class="SubModelNav">
  <ul>
	<li class="{$NavClass['list']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=list" target="_self">{$Fn_Admin->Config['LangVar']['FenleiLeftNavArray'][$_GET['item']]}</a></li>
    <li class="{$NavClass['add']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=add" target="_self">{$Fn_Admin->Config['LangVar']['AddEditTitle']}</a></li>
  </ul>
  <div class="both"></div>
</div>
Nav;

if($SubModel == 'list'){//�б�

	$Do = in_array($_GET['do'], array('del')) ? $_GET['do'] : 'submodel_list';
	//�����ֶ�
	$SearField =array('page','keyword','group_id','vip');
	foreach($SearField as $Val) {
		$SearArray[$Val] = $_GET[$Val] || in_array($_GET[$Val],array('0')) ? $_GET[$Val] : '';
	}
	//�����ֶ� End
	$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeSubModelUrl'].'&'.http_build_query($SearArray);

	if($Do == 'submodel_list'){
		if(!submitcheck('Submit')) {

			$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
			$page = $_GET['page'] ? $_GET['page'] : 0;
			$res = C::t('#fn_fenlei#fn_fenlei_member')->fetch_all_by_list(array('vip'=>$_GET['vip'],'group_id'=>$_GET['group_id'],'keyword'=>$_GET['keyword']),$page - 1,20,$_GET['sort'],$_GET['order'],true);

			/* ģ����� */	
			showtagheader('div', 'row', true,'row');
			showtagheader('div', 'col-12', true,'col-12');
			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-body', true,'box-body');
			/* ���� */
			$vipSelected = array($_GET['vip']=>' selected');
			
			$groupListOption = '<option value="">'.$fn_fenlei->setting['lang']['SelectNull'].'</option>';
			foreach(C::t('#fn_fenlei#fn_fenlei_info_group')->fetch_all_by_list() as $val) {
				$groupListOption .= '<option value="'.$val['id'].'" '.($_GET['group_id'] == $val['id'] ? ' selected' : '' ).'>'.$val['title'].'</option>';
			}

			echo <<<SEARCH
			<form method="post" autocomplete="off" action="$SearUrl">
				<div class="FormSearchTo" style="margin-bottom:0;">
					<table cellspacing="4" cellpadding="4">
				
						<tr>
							<th>&#20851;&#38190;&#35789;</th><td colspan="10"><input type="text" class="input form-control w300" name="keyword" value="{$_GET['keyword']}" placeholder="&#35831;&#36755;&#20837;&#117;&#105;&#100;&#47;&#29992;&#25143;&#21517;&#47;&#25163;&#26426;&#21495;">
							</td>
							<th>&#32423;&#21035;</th><td>
							<select name="group_id" class="form-control w100">
								{$groupListOption}
							</select>
							</td>
							<th>&#26159;&#21542;&#20250;&#21592;</th><td>
							<select name="vip" class="form-control w100">
								<option value="">{$fn_fenlei->setting['lang']['SelectNull']}</option>
								<option value="1"{$vipSelected['1']}>{$fn_fenlei->setting['lang']['Yes']}</option>
								<option value="0"{$vipSelected['0']}>{$fn_fenlei->setting['lang']['No']}</option>
							</select>		
							&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Admin->Config['LangVar']['SearchSubmit']}" class="btn btn-info" type="submit">
							</td>
						</tr>
					</table>
				</div>
			</form>
SEARCH;
			/* ���� End */
			showtagheader('div', 'table-responsive', true,'table-responsive');
			showformheader($FormUrl,'enctype="multipart/form-data"');
			showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
			showsubtitle(array(
				'uid',
				'&#29992;&#25143;&#21517;',
				'&#32852;&#31995;&#22995;&#21517;',
				'&#32852;&#31995;&#30005;&#35805;',
				'&#30005;&#35805;&#35748;&#35777;',
				'openid',
				'unionid',
				'&#24320;&#36807;&#20307;&#39564;&#22871;&#39184;',
				'&#32423;&#21035;',
				'&#21097;&#20313;',
				'&#21040;&#26399;&#26102;&#38388;',
				'&#28155;&#21152;&#26102;&#38388;',
				'&#26356;&#26032;&#26102;&#38388;',
				'&#25805;&#20316;'
			),'header tbm tc');
			
			foreach ($res['list'] as $item) {
				$surplus = '';
				if($item['due_time'] >= time()){
					$surplus .= '&#21457;&#24067;&#25968;&#37327;&#21097;&#20313;:&nbsp;'.($item['pub_count'])."\r\n";
					$surplus .= '&#21047;&#26032;&#27425;&#25968;&#21097;&#20313;:&nbsp;'.($item['refresh_count'])."\r\n";
					$surplus .= '&#32622;&#39030;&#20248;&#24800;&#25240;&#25187;:&nbsp;'.($item['top_discount'] ? $item['top_discount'].'&#25240;' : '&#26080;&#25240;&#25187;')."\r\n";
					$surplus .= '&#21457;&#24067;&#26159;&#21542;&#23457;&#26680;:&nbsp;'.($item['audit_state'] ? $fn_fenlei->setting['lang']['Yes'] : $fn_fenlei->setting['lang']['No'])."\r\n";
					//$surplus .= '&#32622;&#39030;&#22825;&#25968;&#21097;&#20313;:&nbsp;'.($item['top_day'])."\r\n";
				}
				showtablerow('', array('class="tc w100"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
					$item['uid'],
					$item['username'],
					$item['name'],
					$item['phone'],
					!$item['phone_verify'] ? '<span class="label bg-secondary">'.$fn_fenlei->setting['lang']['No'].'</span>' : '<span class="label bg-blue">'.$fn_fenlei->setting['lang']['Yes'].'</span>',
					$item['openid'],
					$item['unionid'],
					!$item['experience'] ? '<span class="label bg-secondary">'.$fn_fenlei->setting['lang']['No'].'</span>' : '<span class="label bg-blue">'.$fn_fenlei->setting['lang']['Yes'].'</span>',
					$item['group_title'],
					$item['due_time'] >= time() ? '<div data-container="body" data-toggle="popover" data-trigger="hover" data-placement="top" data-html="true" data-content="'.str_replace("\r\n","<br>",$surplus).'">&#21457;&#24067;&#25968;&#37327;&#21097;&#20313;:&nbsp;'.($item['pub_count']).'...</div>' : '',
					$item['due_time'] > time() ? date('Y-m-d',$item['due_time']) : '',
					date('Y-m-d',$item['dateline']),
					date('Y-m-d',$item['updateline']),
					'<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&uid='.$item['uid'].'" class="btn btn-sm btn-info-outline">'.$fn_fenlei->setting['lang']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=del&uid='.$item['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline" style="display:none;">'.$fn_fenlei->setting['lang']['DelTitle'].'</a>',
				));
			}

			showsubmit('','','','','',multi($res['count'],20,$page,$MpUrl));
			showtablefooter(); /*dism��taobao��com*/
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			/* ģ�����End */	
		}
	}else if($Do == 'del' && $_GET['formhash'] == formhash() && $_GET['uid']){//ɾ��
		if(!$Fn_Admin->CheckUserGroup('fenlei_all') && !$Fn_Admin->CheckUserGroup('fenlei_del_member_list')){//Ȩ���ж�
			fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
			exit();
		}
		$id = intval($_GET['tid']);
		C::t('#fn_fenlei#fn_fenlei_member')->delete_by_id($id);
		GetInsertDoLog('del_temp_fenlei_list','fn_'.$_GET['mod'],array('id'=>$id));//������¼
		fn_cpmsg($fn_fenlei->setting['lang']['DelOk'],$CpMsgUrl,'succeed');
	}
}else if($SubModel == 'add'){//���ӻ�༭

	if(!$Fn_Admin->CheckUserGroup('fenlei_all') && !$Fn_Admin->CheckUserGroup('fenlei_add_member_list')){//Ȩ���ж�
		fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
		exit();
	}

	$id = intval($_GET['uid']);

	$item = C::t('#fn_fenlei#fn_fenlei_member')->fetch_by_uid($id);
	
	if(!submitcheck('DetailSubmit')) {
		$opTitle = !$item ? $fn_fenlei->setting['lang']['AddTitle'] : $fn_fenlei->setting['lang']['EditTitle'];
	
		showtagheader('div', 'box', true,'box');
		showformheader($Fn_Admin->Config['IframeSubModelUrl'].'&uid='.$id,'enctype');
		showtagheader('div', 'box-body', true,'box-body');
		showtagheader('div', 'tab-content', true,'tab-content');
		
		
		showsetting('uid', 'new_uid', $item['uid'], 'text');

		showsetting('&#32852;&#31995;&#22995;&#21517;', 'name', $item['name'], 'text');
		
		showsetting('&#32852;&#31995;&#30005;&#35805;', 'phone', $item['phone'], 'text');
		
		showsetting("&#30005;&#35805;&#35748;&#35777;", 'phone_verify', $item['phone_verify'], 'radio');
		
		showsetting("&#24320;&#36890;&#22871;&#39184;&#26041;&#24335;", array('vip_type',DyadicArray($fn_fenlei->setting['lang']['AdminVipOpenArray'])),0, 'mradio','','',"&#12304;&#27880;&#24847;&#12305;&#35880;&#24910;&#22788;&#29702;<br>&#37325;&#26032;&#24320;&#36890;&#20250;&#21021;&#22987;&#21270;&#22871;&#39184;&#65292;&#32493;&#36153;&#24320;&#36890;&#27425;&#25968;&#20250;&#21472;&#21152;&#65292;&#20250;&#21592;&#26381;&#21153;&#26102;&#38271;&#20197;&#26032;&#24320;&#22871;&#39184;&#26381;&#21153;&#26102;&#38388;&#20026;&#20934;");

		$groupList = array();
		foreach(C::t('#fn_fenlei#fn_fenlei_info_group')->fetch_all_by_list() as $val) {
			$groupList[] = array($val['id'], $val['title']);
		}
		showsetting("&#36873;&#25321;&#22871;&#39184;", array('group_id', $groupList),$item['due_time'] >= time() ? $item['group_id'] : '', 'mradio');

		showsetting("&#20813;&#36153;&#21457;&#24067;&#25968;&#37327;", 'pub_count', $item['pub_count'], 'text');

		showsetting("&#20813;&#36153;&#21047;&#26032;&#27425;&#25968;", 'refresh_count', $item['refresh_count'], 'text');

		showsetting("&#32622;&#39030;&#20248;&#24800;&#25240;&#25187;", 'top_discount', $item['top_discount'], 'text','','','&#21333;&#20301;&#65306;&#25240;&#65292;&#20363;&#22914;&#65306;&#56;&#46;&#56;&#65281;&#65281;&#65281;&#31354;&#21017;&#20195;&#34920;&#26080;&#25240;&#25187;');

		//showsetting("&#20813;&#36153;&#32622;&#39030;&#22825;&#25968;", 'top_day', $item['top_day'], 'text');

		showsetting("&#21457;&#24067;&#26159;&#21542;&#23457;&#26680;", 'audit_state', $item['audit_state'], 'radio');
		
		showsetting("&#21040;&#26399;&#26102;&#38388;", 'due_time',$item['due_time'] ? date('Y-m-d',$item['due_time']) : '', 'calendar');

		showsetting('&#24320;&#36807;&#20307;&#39564;&#22871;&#39184;', 'experience', $item['experience'], 'radio');
	
		showsubmit('DetailSubmit','&#20445;&#23384;&#37197;&#32622;');
		showtagfooter('div');
		showtagheader('div', 'tab-content', true,'tab-content');
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');


	}else{
		
		if(C::t('#fn_fenlei#fn_fenlei_member')->fetch_by_uid($_GET['new_uid']) && $item['uid'] != $_GET['new_uid']){
			fn_cpmsg("&#35813;&#29992;&#25143;&#24050;&#23384;&#22312;",'','error');
			exit();
		}

		$data['uid'] = intval($_GET['new_uid']);
		$member = DB::fetch_first('SELECT username FROM '.DB::table('common_member').' where uid = '.$data['uid']);
		$data['username'] = addslashes(strip_tags($member['username']));
		$data['name'] = addslashes(strip_tags($_GET['name']));
		$data['phone'] = addslashes(strip_tags($_GET['phone']));
		$data['phone_verify'] = intval($_GET['phone_verify']);
		$data['group_id'] = intval($_GET['group_id']);
		$data['experience'] = intval($_GET['experience']);
		$data['due_time'] = $_GET['due_time'] ? strtotime($_GET['due_time']) : '';
		$groupItem = C::t('#fn_fenlei#fn_fenlei_info_group')->fetch_by_id($data['group_id']);
		
		if($_GET['vip_type'] == 1 && $groupItem){
			$groupData['pub_count'] = $groupItem['pub_count'];
			$groupData['refresh_count'] = $groupItem['refresh_count'];
			$groupData['top_day'] = $groupItem['top_day'];
			$groupData['top_discount'] = addslashes(strip_tags($groupItem['top_discount']));
			$groupData['audit_state'] = intval($groupItem['audit_state']);
			$data['vip_expiry_push'] = 0;
			$data['due_time'] = $data['due_time'] > time() ? strtotime("+".intval($groupItem['group_time'])." day",$data['due_time']) : strtotime("+".intval($groupItem['group_time'])." day",time());
		}else if($_GET['vip_type'] == 2 && $groupItem){
			$groupData['pub_count'] = intval($_GET['pub_count']) + $groupItem['pub_count'];
			$groupData['refresh_count'] = intval($_GET['refresh_count']) + $groupItem['refresh_count'];
			$groupData['top_day'] = intval($_GET['top_day']) + $groupItem['top_day'];
			$groupData['top_discount'] = addslashes(strip_tags($groupItem['top_discount']));
			$groupData['audit_state'] = intval($groupItem['audit_state']);
			$data['vip_expiry_push'] = 0;
			$data['due_time'] = strtotime("+".intval($groupItem['group_time'])." day",time());
		}else{
			$groupData['pub_count'] = intval($_GET['pub_count']);
			$groupData['refresh_count'] = intval($_GET['refresh_count']);
			$groupData['top_day'] = intval($_GET['top_day']);
			$groupData['top_discount'] = addslashes(strip_tags($_GET['top_discount']));
			$groupData['audit_state'] = intval($_GET['audit_state']);
		}
		$memberGroupItem = C::t('#fn_fenlei#fn_fenlei_member_group')->fetch_by_mid($item['id']);
		if($item){
			//GetInsertDoLog('edit_temp_fenlei_list','fn_'.$_GET['mod'],array('uid'=>$id));//������¼
			C::t('#fn_fenlei#fn_fenlei_member')->update($data,$id);
			$id = $item['id'];
		}else{
			$data['dateline'] = $data['updateline'] = time();
			$id = C::t('#fn_fenlei#fn_fenlei_member')->insert($data,true);
			//GetInsertDoLog('add_temp_fenlei_list','fn_'.$_GET['mod'],array('id'=>$id));//������¼
		}
		$memberGroupItem ? C::t('#fn_fenlei#fn_fenlei_member_group')->update($groupData,$item['id']) : C::t('#fn_fenlei#fn_fenlei_member_group')->insert(array_merge($groupData,array('mid'=>$id)));
		fn_cpmsg($fn_fenlei->setting['lang']['UpdateOk'],$Fn_Admin->Config['IframeItemUrl'].'&submodel=list','succeed');
		exit();
	}
}
//From: Dism_taobao_com
?>