<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('fenlei_all') && !$Fn_Admin->CheckUserGroup('fenlei_class_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$SubModel = in_array($_GET['submodel'], array('list','add')) ? $_GET['submodel'] : 'list';
$Fn_Admin->Config['IframeSubModelUrl'] = $Fn_Admin->Config['IframeItemUrl'].'&submodel='.$SubModel;
$NavClass = array($SubModel=>'btn-info Hover');

//����
echo <<<Nav
<div class="SubModelNav">
  <ul>
	<li class="{$NavClass['list']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=list" target="_self">{$Fn_Admin->Config['LangVar']['FenleiLeftNavArray'][$_GET['item']]}</a></li>
    <li class="{$NavClass['add']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=add" target="_self">{$Fn_Admin->Config['LangVar']['AddEditTitle']}</a></li>
  </ul>
  <div class="both"></div>
</div>
Nav;

$allRegion = C::t('#fn_fenlei#fn_region')->fetch_all_by_list();

if($SubModel == 'list'){//�б�

	$Do = in_array($_GET['do'], array('Del')) ? $_GET['do'] : 'submodel_list';

	$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeSubModelUrl'].'&'.http_build_query($SearArray);

	if($Do == 'submodel_list'){
		if(!submitcheck('Submit')) {
			/* ģ����� */	
			showtagheader('div', 'row', true,'row');
			showtagheader('div', 'col-12', true,'col-12');
			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-body', true,'box-body');
			showtagheader('div', 'table-responsive', true,'table-responsive');
			showformheader($FormUrl,'enctype="multipart/form-data"');
			showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
			showsubtitle(array(
				'',
				'ID',
				'&#26174;&#31034;&#39034;&#24207;',
				'&#21306;&#22495;&#21517;&#31216;',
				'&#26159;&#21542;&#26174;&#31034;',
				'&#25805;&#20316;'
			),'header tbm tc');
		
			foreach ($allRegion as $key=>$value) {
				if($value['level'] == 0) {
					echo showClassRow($key, 0, '');
				}
			}
			showtablefooter(); /*dism��taobao��com*/
			showsubmit('Submit','&#31435;&#21363;&#25552;&#20132;');
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			/* ģ�����End */	
		}else{
			
			foreach($_POST['name'] as $key=>$value) {
				$data['displayorder'] = $_POST['neworder'][$key];
				$data['name'] = $_POST['name'][$key];
				//$UpData['bname'] = $_POST['bname'][$key];
				C::t('#fn_fenlei#fn_region')->update($data,$key);
			}
			checkRegion();
			fn_cpmsg($Fn_Admin->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');	
		}
	}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['rid']){//ɾ��
		if(!$Fn_Admin->CheckUserGroup('fenlei_all') && !$Fn_Admin->CheckUserGroup('fenlei_region_list_del')){//Ȩ���ж�
			fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
			exit();
		}
		$id = intval($_GET['rid']);
		C::t('#fn_fenlei#fn_region')->delete_by_id($id);
		GetInsertDoLog('del_region_list_fenlei','fn_'.$_GET['mod'],array('id'=>$id));//������¼

		fn_cpmsg($fn_fenlei->setting['lang']['DelOk'],$CpMsgUrl,'succeed');
	}
}else if($SubModel == 'add'){//���ӻ�༭
	
	$id = intval($_GET['rid']);

	$item = C::t('#fn_fenlei#fn_region')->fetch_by_id($id);

	if(!submitcheck('DetailSubmit')) {
		$opTitle = $item ? $fn_fenlei->setting['lang']['EditTitle'] : $fn_fenlei->setting['lang']['AddTitle'];

		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-header', true,'with-border box-header');
		showtitle($opTitle,'class="box-title"');
		showtagfooter('div');
		showformheader($Fn_Admin->Config['IframeSubModelUrl'].'&classid='.$id,'enctype');
		showtagheader('div', 'box-body', true,'box-body');

		showsetting('&#21306;&#22495;&#21517;&#31216;', 'name', $item['name'], 'text');

		showsetting('&#19978;&#32423;&#20998;&#31867;', '','',$fn_fenlei->getRegionShowSelect($allRegion,'father_id',true,$item['father_id'] ? $item['father_id'] : $_GET['father_id'],true));

		showsetting($fn_fenlei->setting['lang']['DisplayTitle'], 'display', $item ? $item['display'] : 1, 'radio');

		showsetting('display_order', 'displayorder',$item['displayorder'], 'text');

		if($item['dateline']){
			showsetting($fn_fenlei->setting['lang']['TimeTitle'], 'dateline',date('Y-m-d H:i',$item['dateline']), 'calendar','','','',1);
		}

		showsubmit('DetailSubmit','&#20445;&#23384;&#37197;&#32622;');
		showtagfooter('div');
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');


	}else{
		$data['father_id'] = intval($_GET['father_id']);
		$data['name'] = $data['bname'] = addslashes(strip_tags($_GET['name']));
		$data['display'] = intval($_GET['display']);
		$data['displayorder'] = intval($_GET['displayorder']);
		$data['level'] = $data['father_id'] ? $allRegion[$data['father_id']]['level'] + 1 : '';
		
		if($item){
			GetInsertDoLog('edit_region_list_fenlei','fn_'.$_GET['mod'],array('id'=>$id));//������¼
			C::t('#fn_fenlei#fn_region')->update($data,$id);
		}else{
			$data['dateline'] = time();
			$id = C::t('#fn_fenlei#fn_region')->insert($data);;
			GetInsertDoLog('add_region_list_fenlei','fn_'.$_GET['mod'],array('id'=>$id));//������¼
		}
		checkRegion();
		fn_cpmsg($fn_fenlei->setting['lang']['UpdateOk'],$Fn_Admin->Config['IframeItemUrl'].'&submodel=list','succeed');
		exit();
	}
}
function showClassRow($key, $Level = 0, $Last = ''){
	global $allRegion,$Fn_Admin,$fn_fenlei;
	C::t('#fn_fenlei#fn_region')->fetch_all_by_list();
	$item = $allRegion[$key];
	$OpInfoCpUrl = ADMINSCRIPT.'?'.'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod=AdminInfo';
	$OpClassCpUrl = ADMINSCRIPT.'?'.rawurldecode(cpurl());
	if($Level == 2) {
		$Class = $Last ? 'lastchildboard' : 'childboard';
		$Return = '<tr class="hover" id="'.$item['id'].'"><td class="w50">&nbsp;</td><td class="w50">'.$item['id'].'</td><td class="w80"><input type="text" class="form-control w80" name="neworder['.$item['id'].']" value="'.$item['displayorder'].'" /></td><td><div class="'.$Class.'">'.
		'<input type="text" class="form-control w200" name="name['.$item['id'].']" value="'.$item['name'].'" />'.
		'</div>'.
		'</td>'.
		'<td>'.(!empty($item['display']) ? cplang('yes') : cplang('no')).'</td>'.
		'<td><a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&rid='.$item['id'].'" class="btn btn-sm btn-info-outline">'.$Fn_Admin->Config['LangVar']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Display&rid='.$item['id'].'&value='.(!empty($item['display']) ? 0:1).'&formhash='.FORMHASH.'" class="btn btn-sm btn-success-outline">'.(!empty($item['display']) ? $Fn_Admin->Config['LangVar']['DisplayNoTitle'] : $Fn_Admin->Config['LangVar']['DisplayIsTitle']).'</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=list&do=Del&rid='.$item['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$Fn_Admin->Config['LangVar']['DelTitle'].'</a></td></tr>';
	}else if($Level == 1) {
		$Return = '<tr class="hover" id="'.$item['id'].'"><td class="w50">&nbsp;</td><td class="w50">'.$item['id'].'</td><td class="w80"><input type="text" class="form-control w80" name="neworder['.$item['id'].']" value="'.$item['displayorder'].'" /></td><td><div class="board">'.
		'<input type="text" class="form-control w200" name="name['.$item['id'].']" value="'.$item['name'].'" /></div>'.
		'</td>'.
		'<td>'.(!empty($item['display']) ? cplang('yes') : cplang('no')).'</td>'.
		'<td><a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&rid='.$item['id'].'" class="btn btn-sm btn-info-outline">'.$Fn_Admin->Config['LangVar']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Display&rid='.$item['id'].'&value='.(!empty($item['display']) ? 0:1).'&formhash='.FORMHASH.'" class="btn btn-sm btn-success-outline">'.(!empty($item['display']) ? $Fn_Admin->Config['LangVar']['DisplayNoTitle'] : $Fn_Admin->Config['LangVar']['DisplayIsTitle']).'</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=list&do=Del&rid='.$item['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$Fn_Admin->Config['LangVar']['DelTitle'].'</a></td></tr>';
		for($i=0,$L=count($item['children']); $i<$L; $i++) {
			$Return .= ShowClassRow($item['children'][$i], 2, $i==$L-1);
		}
	}else{
		$Childrennum = count(implode(',',$allClass[$Key]['children']));
		$Toggle = $Childrennum > 25 ? ' style="display:none"' : '';
		$Return = '<tbody><tr class="hover" id="'.$item['id'].'"><td class="w50" onclick="toggle_group(\'group_'.$item['id'].'\')"><a id="a_group_'.$item['id'].'" href="javascript:;">'.($Toggle ? '[+]' : '[-]').'</a></td>'.
		'<td class="w50">'.$item['id'].'</td>'
		.'<td class="w80"><input type="text" class="form-control w80" name="neworder['.$item['id'].']" Value="'.$item['displayorder'].'" /></td><td><div class="parentboard">'.
		'<input type="text" class="form-control w200" name="name['.$item['id'].']" Value="'.$item['name'].'" />'.
		'</div>'.
		'</td>'.
		'<td>'.(!empty($item['display']) ? cplang('yes') : cplang('no')).'</td>'.
		'<td><a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&rid='.$item['id'].'" class="btn btn-sm btn-info-outline">'.$Fn_Admin->Config['LangVar']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Display&rid='.$item['id'].'&value='.(!empty($item['display']) ? 0:1).'&formhash='.FORMHASH.'" class="btn btn-sm btn-success-outline">'.(!empty($item['display']) ? $Fn_Admin->Config['LangVar']['DisplayNoTitle'] : $Fn_Admin->Config['LangVar']['DisplayIsTitle']).'</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=list&do=Del&rid='.$item['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$Fn_Admin->Config['LangVar']['DelTitle'].'</a></td></tr></tbody>
		<tbody id="group_'.$item['id'].'"'.$Toggle.'>';
		for($i=0,$L=count($item['children']); $i<$L; $i++) {
			$Return .= ShowClassRow($item['children'][$i], 1, '');
		}
		$Return .= '</tdoby><tr><td>&nbsp;</td><td colspan="10"><div class="lastboard"><a class="addtr" href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&father_id='.$item['id'].'">&#28155;&#21152;&#20998;&#31867;</a></td></div>';
	}
	return $Return;
}

function checkRegion(){
	$check = array();
	foreach(C::t('#fn_fenlei#fn_region')->fetch_all_by_list() as $val){
		$check[$val['id']] = $val;
		$check[$val['id']]['sonid'] = C::t('#fn_fenlei#fn_region')->all_list_id($val['id'],array('display'=>1));
	}
	savecache('fn_region',$check);
}
//From: Dism_taobao_com
?>