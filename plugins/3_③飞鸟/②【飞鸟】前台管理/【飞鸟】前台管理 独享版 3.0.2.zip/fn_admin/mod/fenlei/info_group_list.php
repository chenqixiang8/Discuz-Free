<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('fenlei_all') && !$Fn_Admin->CheckUserGroup('fenlei_info_group_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$SubModel = in_array($_GET['submodel'], array('list','add')) ? $_GET['submodel'] : 'list';
$Fn_Admin->Config['IframeSubModelUrl'] = $Fn_Admin->Config['IframeItemUrl'].'&submodel='.$SubModel;
$NavClass = array($SubModel=>'btn-info Hover');

//����
echo <<<Nav
<div class="SubModelNav">
  <ul>
	<li class="{$NavClass['list']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=list" target="_self">{$Fn_Admin->Config['LangVar']['FenleiLeftNavArray'][$_GET['item']]}</a></li>
    <li class="{$NavClass['add']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=add" target="_self">{$Fn_Admin->Config['LangVar']['AddEditTitle']}</a></li>
  </ul>
  <div class="both"></div>
</div>
Nav;

if($SubModel == 'list'){//�б�
	$Do = in_array($_GET['do'], array('Del')) ? $_GET['do'] : 'submodel_list';
	//�����ֶ�
	$SearField =array('page','keyword');
	foreach($SearField as $Val) {
		$SearArray[$Val] = $_GET[$Val] || in_array($_GET[$Val],array('0')) ? $_GET[$Val] : '';
	}
	//�����ֶ� End
	$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeSubModelUrl'].'&'.http_build_query($SearArray);


	if($Do == 'submodel_list'){
		if(!submitcheck('Submit')) {
			$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
			/* ģ����� */	
			showtagheader('div', 'row', true,'row');
			showtagheader('div', 'col-12', true,'col-12');
			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-body', true,'box-body');
			showtagheader('div', 'table-responsive', true,'table-responsive');
			showformheader($FormUrl,'enctype="multipart/form-data"');
			showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
			showsubtitle(array(
				'ID',
				"&#26631;&#39064;",
				"&#26381;&#21153;&#22825;&#25968;",
				"&#22871;&#39184;&#20215;&#26684;",
				"&#20813;&#36153;&#21457;&#24067;&#25968;&#37327;",
				"&#20813;&#36153;&#21047;&#26032;&#27425;&#25968;",
				"&#32622;&#39030;&#20248;&#24800;&#25240;&#25187;",
				//"&#20813;&#36153;&#32622;&#39030;&#22825;&#25968;",
				"&#21457;&#24067;&#26159;&#21542;&#23457;&#26680;",
				"&#26159;&#21542;&#20026;&#20307;&#39564;&#22871;&#39184;",
				"&#26174;&#31034;&#39034;&#24207;",
				'&#25805;&#20316;'
			),'header tbm tc');
			
			$res = C::t('#fn_fenlei#fn_fenlei_info_group')->fetch_all_by_list();

			foreach ($res as $item) {
				showtablerow('', array('class="tc w50"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
					$item['id'],
					$item['title'],
					$item['group_time'] ? $item['group_time']."&#22825;" : '',
					$item['price'],
					$item['pub_count'],
					$item['refresh_count'],
					$item['top_discount'],
					//$item['top_day'],
					$item['audit_state'] ? cplang('yes') : cplang('no'),
					$item['experience'] ? cplang('yes') : cplang('no'),
					$item['displayorder'],
					'<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&gid='.$item['id'].'" class="btn btn-sm btn-info-outline">&#32534;&#36753;</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Del&gid='.$item['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">&#21024;&#38500;</a>'
				));
			}

			showtablefooter(); /*dism��taobao��com*/
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			/* ģ�����End */	
		}
	}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['gid']){
		$id = intval($_GET['gid']);

		fn_cpmsg($Fn_Admin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
	}
}else if($SubModel == 'add'){//���ӻ�༭

	$id = intval($_GET['gid']);
	$item = C::t('#fn_fenlei#fn_fenlei_info_group')->fetch_by_id($id);
	if(!submitcheck('DetailSubmit')) {
		$opTitle = $fn_fenlei->setting['lang']['AddTitle'];
		if($item)$opTitle = $fn_fenlei->setting['lang']['EditTitle'];
		

		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-header', true,'with-border box-header');
		showtitle($opTitle,'class="box-title"');
		showtagfooter('div');
		showformheader($Fn_Admin->Config['IframeSubModelUrl'].'&gid='.$id,'enctype');
		showtagheader('div', 'box-body', true,'box-body');
	
		showsetting($fn_fenlei->setting['lang']['Title'], 'title', $item['title'], 'text');
	
		showsetting("&#22871;&#39184;&#20215;&#26684;", 'price', $item['price'], 'text');

		showsetting('&#26159;&#21542;&#20026;&#20307;&#39564;&#22871;&#39184;', 'experience', $item['experience'], 'radio','','',"&#27880;&#24847;&#65306;&#25910;&#36153;&#22871;&#39184;&#26080;&#25928;&#65281;&#65281;&#65281;&#36873;&#25321;&#26159;&#65292;&#29992;&#25143;&#21482;&#33021;&#24320;&#36890;&#49;&#27425;&#35813;&#22871;&#39184;&#65292;&#29992;&#20110;&#20813;&#36153;&#24320;&#36890;&#65281;&#65281;&#65281;");

		showsetting("&#26381;&#21153;&#22825;&#25968;", 'group_time', $item['group_time'], 'text','','','&#21333;&#20301;&#65306;&#22825;');

		showsetting("&#20813;&#36153;&#21457;&#24067;&#25968;&#37327;", 'pub_count', $item['pub_count'], 'text');

		showsetting("&#20813;&#36153;&#21047;&#26032;&#27425;&#25968;", 'refresh_count', $item['refresh_count'], 'text');

		showsetting("&#32622;&#39030;&#20248;&#24800;&#25240;&#25187;", 'top_discount', $item['top_discount'], 'text','','','&#21333;&#20301;&#65306;&#25240;&#65292;&#20363;&#22914;&#65306;&#56;&#46;&#56;&#65281;&#65281;&#65281;&#31354;&#21017;&#20195;&#34920;&#26080;&#25240;&#25187;');

		//showsetting("&#20813;&#36153;&#32622;&#39030;&#22825;&#25968;", 'top_day', $item['top_day'], 'text');

		showsetting("&#21457;&#24067;&#26159;&#21542;&#23457;&#26680;", 'audit_state', $item['audit_state'], 'radio');

		showsetting("&#26381;&#21153;&#20869;&#23481;", 'content', $item['content'], 'textarea');
		
		showsetting("&#26174;&#31034;&#39034;&#24207;", 'displayorder', $item['displayorder'], 'text');
		
		showsubmit('DetailSubmit','&#20445;&#23384;&#37197;&#32622;');
		showtagfooter('div');
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');


	}else{
		
		$data['title'] = addslashes(strip_tags($_GET['title']));
		$data['price'] = addslashes(strip_tags($_GET['price']));
		$data['group_time'] = addslashes(strip_tags($_GET['group_time']));
		$data['displayorder'] = intval($_GET['displayorder']);
		$data['experience'] = intval($_GET['experience']);
		$data['pub_count'] = intval($_GET['pub_count']);
		$data['refresh_count'] = intval($_GET['refresh_count']);
		$data['top_day'] = intval($_GET['top_day']);
		$data['top_discount'] = addslashes(strip_tags($_GET['top_discount']));
		$data['audit_state'] = intval($_GET['audit_state']);
		$data['content'] = addslashes(strip_tags($_GET['content']));

		if($item){
			C::t('#fn_fenlei#fn_fenlei_info_group')->update($data,$id);
		}else{
			$id = C::t('#fn_fenlei#fn_fenlei_info_group')->insert($data);
		}
		fn_cpmsg($fn_fenlei->setting['lang']['UpdateOk'],$Fn_Admin->Config['IframeItemUrl'].'&submodel=list','succeed');
	}
}
//From: Dism_taobao_com
?>