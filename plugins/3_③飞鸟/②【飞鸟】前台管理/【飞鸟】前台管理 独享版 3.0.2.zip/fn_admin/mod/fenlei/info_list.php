<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('fenlei_all') && !$Fn_Admin->CheckUserGroup('fenlei_info_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$SubModel = in_array($_GET['submodel'], array('list','add')) ? $_GET['submodel'] : 'list';
$Fn_Admin->Config['IframeSubModelUrl'] = $Fn_Admin->Config['IframeItemUrl'].'&submodel='.$SubModel;
$NavClass = array($SubModel=>'btn-info Hover');

//����
echo <<<Nav
<div class="SubModelNav">
  <ul>
	<li class="{$NavClass['list']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=list" target="_self">{$Fn_Admin->Config['LangVar']['FenleiLeftNavArray']['info_list']}</a></li>
    <li class="{$NavClass['add']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=add" target="_self">{$Fn_Admin->Config['LangVar']['AddEditTitle']}</a></li>
  </ul>
  <div class="both"></div>
</div>
Nav;

$allClass = C::t('#fn_fenlei#fn_fenlei_class')->fetch_all_by_list();
$allRegion = C::t('#fn_fenlei#fn_region')->fetch_all_by_list();

if($SubModel == 'list'){//�б�
	$Do = in_array($_GET['do'], array('refresh','del','display','hide','pay_state')) ? $_GET['do'] : 'submodel_list';
	//�����ֶ�
	$SearField =array('page','keyword','display','audit_state','pay_state','pub_type','classid','shops_id','overdue','order','hide','new_iid');
	foreach($SearField as $Val) {
		$SearArray[$Val] = $_GET[$Val] || in_array($_GET[$Val],array('0')) ? $_GET[$Val] : '';
	}
	//�����ֶ� End
	$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeSubModelUrl'].'&'.http_build_query($SearArray);


	if($Do == 'submodel_list'){
		if(!submitcheck('Submit')) {

			$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
			$page = $_GET['page'] ? $_GET['page'] : 0;
			$res = C::t('#fn_fenlei#fn_fenlei_info')->fetch_all_by_list(array('keyword'=>$_GET['keyword'],'iid'=>$_GET['new_iid'],'overdue'=>$_GET['overdue'],'regionid'=>$_GET['regionid'],'classid'=>$_GET['classid'],'shops_id'=>$_GET['shops_id'],'display'=>$_GET['display'],'hide'=>$_GET['hide'],'pay_state'=>$_GET['pay_state'],'audit_state'=>$_GET['audit_state'],'pub_type'=>$_GET['pub_type']),$_GET['order'],'',$page - 1,20,true,'','');

			/* ��ѯ���� End */
	
			/* ģ����� */	
			showtagheader('div', 'row', true,'row');
			showtagheader('div', 'col-12', true,'col-12');
			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-body', true,'box-body');
			/* ���� */
			$OverdueSelected = array($_GET['overdue']=>' selected');
			$DisplaySelected = array($_GET['display']=>' selected');
			$HideSelected = array($_GET['hide']=>' selected');
			$audit_state_selected = array($_GET['audit_state']=>' selected');
			$pub_type_selected = array($_GET['pub_type']=>' selected');
			$PaymentStateSelected = array($_GET['pay_state']=>' selected');
			$OrderSelected = array($_GET['order']=>' selected');
			$OverdueHtml = '<th>&#26159;&#21542;&#36807;&#26399;</th><td>
							<select name="overdue" class="form-control w120">
								<option value="">'.$fn_fenlei->setting['lang']['SelectNull'].'</option>
								<option value="1"'.$OverdueSelected['1'].'>'.$fn_fenlei->setting['lang']['Yes'].'</option>
								<option value="2"'.$OverdueSelected['2'].'>'.$fn_fenlei->setting['lang']['No'].'</option>
							</select>
							</td>';
			$classShowSelect = $fn_fenlei->getClassShowSelect($allClass,'classid',true,$_GET['classid']);
			$regionShowSelect = $fn_fenlei->getRegionShowSelect($allRegion,'regionid',true,$_GET['regionid']);
			
			$pub_type_list_option = '<option value="">'.$fn_fenlei->setting['lang']['SelectNull'].'</option>';
			foreach($fn_fenlei->setting['lang']['pub_type_arr'] as $key => $val) {
				$pub_type_list_option .= '<option value="'. $key.'" '.($_GET['pub_type'] ==  $key ? ' selected' : '' ).'>'.$val.'</option>';
			}
			
			echo <<<SEARCH
			<form method="post" autocomplete="off" action="$SearUrl">
				<div class="FormSearchTo" style="margin-bottom:0;">
					<table cellspacing="4" cellpadding="4">
						<tr>
							<th>&#20851;&#38190;&#35789;</th><td colspan="10"><input type="text" class="input form-control w300" name="keyword" value="{$_GET['keyword']}" placeholder="&#35831;&#36755;&#20837;&#117;&#105;&#100;&#47;&#29992;&#25143;&#21517;&#47;&#20869;&#23481;&#20851;&#38190;&#35789;">
							&nbsp;&nbsp;&nbsp;&nbsp;&#20449;&#24687;&#73;&#68;&nbsp;&nbsp;<input type="text" class="input form-control w120" name="new_iid" value="{$_GET['new_iid']}" placeholder="&#35831;&#36755;&#20837;&#20449;&#24687;&#73;&#68;">&nbsp;&nbsp;&nbsp;&nbsp;&#21830;&#23478;&#73;&#68;&nbsp;&nbsp;<input type="text" class="input form-control w120" name="shops_id" value="{$_GET['shops_id']}" placeholder="&#35831;&#36755;&#20837;&#21830;&#23478;&#73;&#68;">
							</td>
						</tr>
						<tr>
							<th>&#20998;&#31867;</th>
							<td>{$classShowSelect}</td>
							<th>&#21306;&#22495;</th>
							<td>{$regionShowSelect}</td>
							<th>&#26159;&#21542;&#26174;&#31034;</th><td>
							<select name="display" class="form-control w120">
								<option value="">{$fn_fenlei->setting['lang']['SelectNull']}</option>
								<option value="1"{$DisplaySelected['1']}>{$fn_fenlei->setting['lang']['Yes']}</option>
								<option value="0"{$DisplaySelected['0']}>{$fn_fenlei->setting['lang']['No']}</option>
							</select>
							</td>
							<th>&#23457;&#26680;&#29366;&#24577;</th><td>
							<select name="audit_state" class="form-control w120">
								<option value="">{$fn_fenlei->setting['lang']['SelectNull']}</option>
								<option value="1"{$audit_state_selected['1']}>{$fn_fenlei->setting['lang']['audit_state_arr']['1']}</option>
								<option value="2"{$audit_state_selected['2']}>{$fn_fenlei->setting['lang']['audit_state_arr']['2']}</option>
								<option value="3"{$audit_state_selected['3']}>{$fn_fenlei->setting['lang']['audit_state_arr']['3']}</option>
							</select>
							</td>
						</tr>
						<tr>
							<th>&#26159;&#21542;&#19978;&#26550;</th><td>
							<select name="hide" class="form-control w120">
								<option value="">{$fn_fenlei->setting['lang']['SelectNull']}</option>
								<option value="1"{$HideSelected['1']}>{$fn_fenlei->setting['lang']['No']}</option>
								<option value="0"{$HideSelected['0']}>{$fn_fenlei->setting['lang']['Yes']}</option>
							</select>
							</td>
							<th>&#25903;&#20184;&#29366;&#24577;</th><td>
						
							<select name="pay_state" class="form-control w120">
								<option value="">{$fn_fenlei->setting['lang']['SelectNull']}</option>
								<option value="0"{$PaymentStateSelected['0']}>&#26410;&#25903;&#20184;</option>
								<option value="1"{$PaymentStateSelected['1']}>&#24050;&#25903;&#20184;</option>
							</select>
							</td>
							<th>{$fn_fenlei->setting['lang']['pub_type']}</th><td>
							<select name="pub_type" class="form-control w120">
								{$pub_type_list_option}
							</select>
							<th>&#25490;&#24207;</th><td>
							<select name="order" class="form-control w120">
								<option value="dateline"{$OrderSelected['dateline']}>{$Fn_Admin->Config['LangVar']['OrderArray']['dateline']}</option>
								<option value="updateline"{$OrderSelected['updateline']}>{$Fn_Admin->Config['LangVar']['OrderArray']['updateline']}</option>
								<option value="click"{$OrderSelected['click']}>{$Fn_Admin->Config['LangVar']['OrderArray']['click']}</option>
								<option value="topdateline"{$OrderSelected['topdateline']}>{$Fn_Admin->Config['LangVar']['OrderArray']['topdateline']}</option>
							</select>
							&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Admin->Config['LangVar']['SearchSubmit']}" class="btn btn-info" type="submit">
							</td>
						</tr>
					</table>
				</div>
			</form>
SEARCH;
			/* ���� End */
			showtagheader('div', 'table-responsive', true,'table-responsive');
			showformheader($FormUrl,'enctype="multipart/form-data"');
			showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
			showsubtitle(array(
				'ID',
				'UID/'.$fn_fenlei->setting['lang']['UserNameTitle'],
				'&#20998;&#31867;&#47;&#21306;&#22495;&#47;&#21830;&#23478;',
				$fn_fenlei->setting['lang']['info_content'],
				$fn_fenlei->setting['lang']['info_name'],
				$fn_fenlei->setting['lang']['info_phone'],
				'&#32479;&#35745;',
				'&#21457;&#24067;&#28192;&#36947;&#47;&#31867;&#22411;',
				$fn_fenlei->setting['lang']['DisplayTitle'],
				$fn_fenlei->setting['lang']['hide'],
				'&#26159;&#21542;&#35299;&#20915;',
				$fn_fenlei->setting['lang']['audit_state'],
				$fn_fenlei->setting['lang']['pay_state'],
				//$fn_fenlei->setting['lang']['RefreshTime'],
				//$fn_fenlei->setting['lang']['SetTopTime'],
				'&#26102;&#38388;',
				$fn_fenlei->setting['lang']['OperationTitle']
			),'header tbm tc');

			foreach ($res['list'] as $item) {
				
				$shopsItem = $item['shops_id'] && $fn_fenlei->shops ? $fn_fenlei->shops->getView($item['shops_id']) : '';

				$classItem = $fn_fenlei->_G['cache']['fn_fenlei_class'][$item['classid']];
				$classForms = $fn_fenlei->_G['cache']['fn_form_fenlei_info'][$item['classid']];
				$item['forms'] = $item['forms'] ? dunserialize($item['forms']) : '';
				$formsContent = '';
				$formsReplaceFront = array();
				$formsReplaceAfter = array();
				foreach($classForms as $val){
					$identifier = $item['forms'][$val['identifier']];
					$formsReplaceFront[] = '[--'.$val['identifier'].'--]';
					$formsReplaceAfter[] = $identifier['value'] ? $identifier['content'].$val['unitnew'] : $identifier['content'];
					if($identifier['content']){
						$formsContent .= $val['title'].': '.($identifier['value'] ? $identifier['content'].$val['unitnew'] : $identifier['content'])."<br>";
					}
				}
				$replaceFront = array_merge(array('[--url--]','[--id--]','[--updateline--]','[--dateline--]','[--username--]','[--role--]','[--class_name--]','[--region_name--]','[--title--]','[--name--]','[--phone--]','[--click--]','[--content--]','[--tag--]'),$formsReplaceFront);
				$replaceAfter = array_merge(array($fn_fenlei->getUrl('view',array('iid'=>$item['id'])),$item['id'],$item['updateline'],$item['dateline'],$item['username'],$item['role'],$item['class_name'],$item['region_name'],$item['title'],$item['name'],$item['phone'],$item['click'],strip_tags($item['content']),implode('|',$item['tag_arr'] ? dunserialize($item['tag_arr']) : '')),$formsReplaceAfter);

				$item['content'] = $item['content'] ? $item['content'].'<br>'.$formsContent : $formsContent;

				$countHtml = '';
				foreach ($fn_fenlei->setting['lang']['info_action_arr'] as $key=> $val) {
					$countHtml .= $val.': '.$item[$fn_fenlei->setting['lang']['info_action_field_arr'][$key]].'<br>';
				}
				$countHtml .= $fn_fenlei->setting['lang']['Click'].": ".$item['click'];
				$timeText = '&#36807;&#26399;&#26102;&#38388;&#65306;<span class="text-danger">'.date('Y-m-d',$item['end_dateline']).'</span><br>&#21047;&#26032;&#26102;&#38388;&#65306;'.date('Y-m-d',$item['updateline']).'<br>&#28155;&#21152;&#26102;&#38388;&#65306;'.date('Y-m-d',$item['dateline']).'<br>&#32622;&#39030;&#26102;&#38388;&#65306;'.($item['topdateline'] >= time() ? date('Y-m-d',$item['topdateline']) : ($item['topdateline'] ? '<span class="label bg-danger">'.$fn_fenlei->setting['lang']['Expired'].'</span>' : ''));
				showtablerow('', array('class="tc w100"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
					'<input type="checkbox" class="filled-in" id="checkbox_'.$item['id'].'" name="delete[]" value="'.$item['id'].'"><label for="checkbox_'.$item['id'].'">'.$item['id'].'</label>',
					$item['uid'].'/'.$item['username'],
					$item['class_name'].'<br>'.$item['region_name'].'<br>'.$shopsItem['name'],
					'<div data-container="body" data-toggle="popover" data-trigger="hover" data-placement="top" data-content="'.$item['content'].'" data-html="true">'.cutstr(strip_tags($item['content']),30).'</div>',
					$item['name'],
					$item['phone'],
					'<div data-container="body" data-toggle="popover" data-trigger="hover" data-placement="top" data-content="'.$countHtml.'" data-html="true">'.cutstr(strip_tags($countHtml),11).'</div>',
					$fn_fenlei->setting['lang']['pub_channel_arr'][$item['channel']].'<br>'.$fn_fenlei->setting['lang']['pub_type_arr'][$item['pub_type']],
					!$item['display'] ? '<span class="label bg-secondary">'.$fn_fenlei->setting['lang']['No'].'</span>' : '<span class="label bg-blue">'.$fn_fenlei->setting['lang']['Yes'].'</span>',
					!$item['hide'] ? '<span class="label bg-secondary">'.$fn_fenlei->setting['lang']['No'].'</span>' : '<span class="label bg-blue">'.$fn_fenlei->setting['lang']['Yes'].'</span>',
					!$item['solve'] ? '<span class="label bg-secondary">'.$fn_fenlei->setting['lang']['No'].'</span>' : '<span class="label bg-blue">'.$fn_fenlei->setting['lang']['Yes'].'</span>',
					$item['audit_state'] != 1 ? '<span class="label bg-secondary">'.$fn_fenlei->setting['lang']['audit_state_arr'][$item['audit_state']].'</span>' : '<span class="label bg-blue">'.$fn_fenlei->setting['lang']['audit_state_arr'][$item['audit_state']].'</span>',
					!$item['pay_state'] ? '<span class="label bg-secondary">'.$fn_fenlei->setting['lang']['pay_state_arr']['0'].'</span>' : '<span class="label bg-blue">'.$fn_fenlei->setting['lang']['pay_state_arr']['1'].'</span>',
					$timeText,
					//date('Y-m-d',$item['updateline']),
					//$item['topdateline'] >= time() ? date('Y-m-d',$item['topdateline']) : ($item['topdateline'] ? '<span class="label bg-danger">'.$fn_fenlei->setting['lang']['Expired'].'</span>' : ''),
					//date('Y-m-d',$item['dateline']).'<br>'.$fn_fenlei->setting['lang']['RefreshTime'].,
					'<a href="'.$fn_fenlei->getUrl('view',array('iid'=>$item['id'])).'" target="_blank" class="btn btn-sm btn-dark-outline">'.cplang('view').'</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&iid='.$item['id'].'" class="btn btn-sm btn-info-outline">'.$fn_fenlei->setting['lang']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=refresh&iid='.$item['id'].'&formhash='.FORMHASH.'" class="btn btn-sm btn-primary-outline">'.$fn_fenlei->setting['lang']['Refresh'].'</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeModUrl'].'&item=info_action_list&submodel=list&iid='.$item['id'].'" class="btn btn-sm btn-danger-outline">&#32479;&#35745;&#35760;&#24405;</a><br><div style="height:7px;"></div><span class="btn btn-sm btn-dark-outline copy_btn" data-clipboard-content="'.str_replace($replaceFront,$replaceAfter,$classItem['info_copy_temp']).'">&#22797;&#21046;</span>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=display&iid='.$item['id'].'&value='.(!empty($item['display']) ? 0:1).'&formhash='.FORMHASH.'" class="btn btn-sm btn-warning-outline">'.(!empty($item['display']) ? $fn_fenlei->setting['lang']['DisplayNoTitle'] : $fn_fenlei->setting['lang']['DisplayIsTitle']).'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=hide&iid='.$item['id'].'&value='.(!empty($item['hide']) ? 0:1).'&formhash='.FORMHASH.'" class="btn btn-sm btn-purple-outline">'.(!empty($item['hide']) ? $fn_fenlei->setting['lang']['hide_arr'][0] : $fn_fenlei->setting['lang']['hide_arr'][1]).'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=pay_state&iid='.$item['id'].'&value='.(!empty($item['pay_state']) ? 0:1).'&formhash='.FORMHASH.'" class="btn btn-sm btn-info-outline">'.(!empty($item['pay_state']) ? $fn_fenlei->setting['lang']['pay_state_arr'][0] : $fn_fenlei->setting['lang']['pay_state_arr'][1]).'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=del&iid='.$item['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$fn_fenlei->setting['lang']['DelTitle'].'</a>',
				));
			}
			
			showsubmit('Submit','&#31435;&#21363;&#25552;&#20132;','','','',multi($res['count'],20,$page,$MpUrl));

			showtablefooter(); /*dism��taobao��com*/
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');

			echo '
			<script src="source/plugin/fn_assembly/static/js/clipboard.min.js"></script>    
			<script>
			var clipboard = new ClipboardJS(".copy_btn", {
				text: function(e) {
					return e.getAttribute("data-clipboard-content");
				}
			});
			clipboard.on("success", function(e) {
				alert("\u606d\u559c\u60a8\uff0c\u590d\u5236\u6210\u529f\uff01");
			});

			clipboard.on("error", function(e) {
				alert("\u5f88\u9057\u61be\uff0c\u590d\u5236\u5931\u8d25\uff01");
			});
			</script>';
			/* ģ�����End */	
		}else{
			if(isset($_GET['delete']) && is_array($_GET['delete'])){
				
			}
		}
	}else if($Do == 'del' && $_GET['formhash'] == formhash() && $_GET['iid']){
		if(!$Fn_Admin->CheckUserGroup('fenlei_all') && !$Fn_Admin->CheckUserGroup('fenlei_del_info_list')){//Ȩ���ж�
			fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
			exit();
		}
		$id = intval($_GET['iid']);
		C::t('#fn_fenlei#fn_fenlei_info')->delete_by_id($id);
		GetInsertDoLog('del_info_list_fenlei','fn_'.$_GET['mod'],array('id'=>$id));//������¼
		fn_cpmsg($Fn_Admin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
	}else if(in_array($Do,array('refresh','display','hide','pay_state')) && $_GET['formhash'] == formhash() && $_GET['iid']){
		$id = intval($_GET['iid']);
		if($Do == 'refresh'){
			$item = C::t('#fn_fenlei#fn_fenlei_info')->fetch_by_id($id);
			$data['updateline'] = time();
			$data['end_dateline'] = strtotime("+".intval($allClass[$item['classid']]['info_end_day'])."  day",time());
		}else{
			$data[$Do] = intval($_GET['value']);
		}
		C::t('#fn_fenlei#fn_fenlei_info')->update($data,$id);
		GetInsertDoLog($Do.'_info_list_fenlei','fn_'.$_GET['mod'],array('id'=>$id));//������¼
		fn_cpmsg($fn_fenlei->setting['lang']['UpdateOk'],$CpMsgUrl,'succeed');
		exit();
	}
}else if($SubModel == 'add'){//���ӻ�༭
	if(!$Fn_Admin->CheckUserGroup('fenlei_all') && !$Fn_Admin->CheckUserGroup('fenlei_add_info_list')){//Ȩ���ж�
		fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
		exit();
	}

	$id = intval($_GET['iid']);
	
	$item = C::t('#fn_fenlei#fn_fenlei_info')->fetch_by_id($id);

	if(!submitcheck('DetailSubmit')) {
		$opTitle = $fn_fenlei->setting['lang']['AddTitle'];
		if($item){
			$opTitle = $fn_fenlei->setting['lang']['EditTitle'];
		}
		
		//ͼƬ�ϴ�
		if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_assembly/class/class_upload.php')){
			@require_once libfile('class/upload','plugin/fn_assembly');
			$UploadConfig = fn_upload::Config();
		}

		echo '<script src="'.$Config['StaticPath'].'/ueditor/'.CHARSET.'/ueditor.config.js" type="text/javascript"></script><script src="'.$Config['StaticPath'].'/ueditor/'.CHARSET.'/ueditor.all.js" type="text/javascript"></script>';

		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-header', true,'with-border box-header');
		showtitle($opTitle,'class="box-title"');
		showtagfooter('div');
		showformheader($Fn_Admin->Config['IframeSubModelUrl'].'&iid='.$id,'enctype');
		showtagheader('div', 'box-body', true,'box-body');

		showsetting('uid', 'new_uid', $item['uid'], 'text');

		showsetting('&#21830;&#23478;&#73;&#68;', 'shops_id', $item['shops_id'], 'text');

		showsetting('&#36873;&#25321;&#20998;&#31867;', '','',$fn_fenlei->getClassShowSelect($allClass,'new_classid',true,$item['classid'],true));

		showsetting('&#36873;&#25321;&#21306;&#22495;', '','',$fn_fenlei->getRegionShowSelect($allRegion,'new_regionid',true,$item['regionid'],true));

		showsetting('&#35814;&#32454;&#22320;&#22336;', 'address', $item['address'], 'text','','','<div class="MapClick">&#23450;&#20301;</div><div class="TipMap"><iframe id="MapPage" width="100%" height="100%" frameborder=0 src=""></iframe></div>');
		
		showsetting('&#32463;&#24230;', 'lng', $item['lng'], 'text');

		showsetting('&#32428;&#24230;', 'lat', $item['lat'], 'text');
		
		showsetting($fn_fenlei->setting['lang']['info_name'], 'name', $item['name'], 'text');

		showsetting($fn_fenlei->setting['lang']['info_phone'], 'phone', $item['phone'], 'text');

		$thumb_html = ($item['thumb'] ? '<a href="'.$item['thumb'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$item['thumb'].'" height="55"/></a>' : '');
		showsetting('&#32553;&#30053;&#22270;', 'new_thumb',$item['thumb'], 'filetext', '', 0, $thumb_html);
		
		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$fn_fenlei->setting['lang']['info_album'].'</label><div class="col-sm-9"><div class="AdminSingleUpload"><div class="PhotoControl" id="Album"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';

		//��������
		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$fn_fenlei->setting['lang']['info_content'].':</label><div class="col-sm-9"><textarea id="content" name="content" style="width:80%;height:400px;">'.stripslashes($item['content']).'</textarea></div></div>';
		
		showsetting($fn_fenlei->setting['lang']['SetTopTime'], 'topdateline',$item['topdateline'] ? date('Y-m-d H:i',$item['topdateline']) : '', 'calendar','','','',1);
		
		if($item){
			showsetting('&#36807;&#26399;&#26102;&#38388;', 'end_dateline',$item['end_dateline'] ? date('Y-m-d H:i',$item['end_dateline']) : '', 'calendar','','','',1);
		}

		if($item){
			showsetting($fn_fenlei->setting['lang']['RefreshTime'], 'updateline',$item['updateline'] ? date('Y-m-d H:i',$item['updateline']) : '', 'calendar','','','',1);
		}

		if($item){
			showsetting($fn_fenlei->setting['lang']['TimeTitle'], 'dateline',date('Y-m-d H:i',$item['dateline']), 'calendar','','','',1);
		}

		showsetting($fn_fenlei->setting['lang']['Click'], 'click', $item['click'], 'text');

		showsetting($fn_fenlei->setting['lang']['pay_state'],array('pay_state',DyadicArray($fn_fenlei->setting['lang']['pay_state_arr'])),$item ? $item['pay_state'] : 1,'mradio');

		showsetting($fn_fenlei->setting['lang']['audit_state'],array('audit_state',DyadicArray($fn_fenlei->setting['lang']['audit_state_arr'])),$item ? $item['audit_state'] : 1,'mradio');

		showsetting('&#26159;&#21542;&#35299;&#20915;', 'solve', $item['solve'], 'radio');
		
		showsetting($fn_fenlei->setting['lang']['DisplayTitle'], 'display', $item ? $item['display'] : 1, 'radio');

		showsetting($fn_fenlei->setting['lang']['hide'],array('hide',DyadicArray($fn_fenlei->setting['lang']['hide_arr'])),$item ? $item['hide'] : 1,'mradio');
		
		showsubmit('DetailSubmit','&#20445;&#23384;&#37197;&#32622;');
		showtagfooter('div');
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');

		$upLoadHtml  = '';
		if($item['album']){
			foreach(explode(',',$item['album']) as $val) {
				$albumJsArray[] = '"'.$val.'"';
			}
			$upLoadHtml .= '
			var InputArray = new Array('. implode(',',$albumJsArray).');
			$("#Album").AppUpload({InputName:"upload_album",InputExist:true,InputArray:InputArray});';
		}else{
			$upLoadHtml .= '$("#Album").AppUpload({InputName:"upload_album"});';
		}

		echo '<script src="source/plugin/fn_assembly/static/js/mobiscroll.custom-2.16.1.min.js"></script><link rel="stylesheet" href="source/plugin/fn_assembly/static//css/mobiscroll.custom-2.16.1.min.css"><script charset=utf-8 src="https://map.qq.com/api/js?v=2.exp&key='.$Config['PluginVar']['TxMapKey'].'"></script>'.$UploadConfig['CssJsHtml'];
		echo '
			<script>
			//��ע
			$(document).on("click",".MapClick",function(){
				if(!$("#MapPage").attr("src")){
					$("#MapPage").attr("src","https://apis.map.qq.com/tools/locpicker?search=1&type=1&key='.$Config['PluginVar']['TxMapKey'].'&referer=myapp&'.($item['lat'] && $item['lng'] ? 'coord='.$item['lat'].','.$item['lng'] : '').'");
				}
				$(".TipMap").fadeIn();
				return false;
			});
			window.addEventListener("message", function(Event) {
				var Loc = Event.data;
				if (Loc && Loc.module == "locationPicker") {
					var Geocoder = new qq.maps.Geocoder();
					Geocoder.getAddress(new qq.maps.LatLng(Loc.latlng.lat, Loc.latlng.lng));
					Geocoder.setComplete(function(res) {
						$("input[name=\'lat\']").val(res.detail.location.lat);
						$("input[name=\'lng\']").val(res.detail.location.lng);
						$("input[name=\'address\']").val(res.detail.addressComponents.city + res.detail.addressComponents.district + (res.detail.addressComponents.streetNumber ? res.detail.addressComponents.streetNumber : res.detail.addressComponents.street));
						$(".TipMap").fadeOut();
					});
					Geocoder.setError(function() {
						alert("\u51fa\u9519\u4e86\uff0c\u8bf7\u8f93\u5165\u6b63\u786e\u7684\u5730\u5740\uff01\uff01\uff01");
					});
				}
			}, false);
			//��ע End
			var ue = UE.getEditor("content",{autoHeightEnabled: false,autoFloatEnabled:false,enableAutoSave: false});
			'.$upLoadHtml.'
			</script> 	
		';

	}else{

		foreach($_GET['upload_album'] as $key => $val) {
			$_GET['upload_album'][$key] = strpos($val,'http') !== false ? $val : $_G['siteurl'].$val;
		}
		
		$data['uid'] = intval($_GET['new_uid']);
		$member = DB::fetch_first('SELECT username FROM '.DB::table('common_member').' where uid = '.$data['uid']);
		$data['username'] = addslashes(strip_tags($member['username']));
		$data['name'] = addslashes(strip_tags($_GET['name']));
		$data['phone'] = addslashes(strip_tags($_GET['phone']));
		$data['classid'] = intval($_GET['new_classid']);
		$data['regionid'] = intval($_GET['new_regionid']);
		$data['shops_id'] = intval($_GET['shops_id']);
		$data['role'] = $data['shops_id'] ? 2 : 1;
		$data['address'] = addslashes(strip_tags($_GET['address']));
		$data['lat'] = addslashes(strip_tags($_GET['lat']));
		$data['lng'] = addslashes(strip_tags($_GET['lng']));
		$data['content'] = addslashes($_GET['content']);//�豣��Html
		$data['click'] = intval($_GET['click']);
		$data['topdateline'] = $_GET['topdateline'] ? strtotime($_GET['topdateline']) : '';
		$data['pay_state'] = intval($_GET['pay_state']);
		$data['audit_state'] = intval($_GET['audit_state']);
		$data['solve'] = intval($_GET['solve']);
		$data['display'] = intval($_GET['display']);
		$data['hide'] = intval($_GET['hide']);
		$data['album'] = is_array($_GET['upload_album']) && isset($_GET['upload_album']) ? implode(',',$_GET['upload_album']) : '';
		$data = array_merge($data,$Fn_Admin->uploadFiles($_FILES,false));

		if($item){
			$data['end_dateline'] = $_GET['end_dateline'] ? strtotime($_GET['end_dateline']) : strtotime("+".intval($allClass[$data['classid']]['info_end_day'])."  day",time());
			$data['updateline'] = strtotime($_GET['updateline']);
			C::t('#fn_fenlei#fn_fenlei_info')->update($data,$id);
			GetInsertDoLog('add_info_list_fenlei','fn_'.$_GET['mod'],array('id'=>$id));//������¼
			if($data['classid'] != $item['classid']){
				C::t('#fn_fenlei#fn_fenlei_class')->update_by_info_count($data['classid']);
				C::t('#fn_fenlei#fn_fenlei_class')->update_by_info_count($item['classid'],'-');
			}
		}else{
			$data['pub_type'] = 6;
			$data['channel'] = 1;
			$data['end_dateline'] = strtotime("+".intval($allClass[$data['classid']]['info_end_day'])."  day",time());
			$data['dateline'] = $data['updateline'] = time();

			$id = C::t('#fn_fenlei#fn_fenlei_info')->insert($data);
			C::t('#fn_fenlei#fn_fenlei_class')->update_by_info_count($data['classid']);
			GetInsertDoLog('edit_info_list_fenlei','fn_'.$_GET['mod'],array('id'=>$id));//������¼
		}

		$data['shops_id'] && !$item['shops_id'] && $fn_fenlei->shops ? C::t('#fn_shops#fn_shops')->update_by_count($data['shops_id'],'info_count',1,'+') : '';

		fn_cpmsg($fn_fenlei->setting['lang']['UpdateOk'],$Fn_Admin->Config['IframeItemUrl'].'&submodel=list','succeed');
		exit();
	}
}
//From: Dism_taobao_com
?> 