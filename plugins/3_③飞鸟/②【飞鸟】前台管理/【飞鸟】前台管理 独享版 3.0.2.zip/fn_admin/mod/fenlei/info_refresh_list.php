<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('fenlei_all') && !$Fn_Admin->CheckUserGroup('fenlei_info_refresh_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$Do = in_array($_GET['do'], array('Del')) ? $_GET['do'] : 'List';

//�����ֶ�
$SearField =array('page','keyword','type','iid','order');
foreach($SearField as $Val) {
	$SearArray[$Val] = $_GET[$Val] ? $_GET[$Val] : '';
}
//�����ֶ� End

$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeItemUrl'].'&'.http_build_query($SearArray);

if($Do == 'List'){
	if(!submitcheck('Submit')) {
		$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
		$page = $_GET['page'] ? $_GET['page'] : 0;
		$res = C::t('#fn_fenlei#fn_fenlei_info_refresh_log')->fetch_all_by_list(array('keyword'=>$_GET['keyword'],'type'=>$_GET['type'],'iid'=>$_GET['iid']),'dateline',$page,30,true);
		/* ģ����� */
		showtagheader('div', 'row', true,'row');
		showtagheader('div', 'col-12', true,'col-12');
		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-body', true,'box-body');
		/* ���� */
		$info_refresh_list_option = '<option value="">'.$fn_fenlei->setting['lang']['SelectNull'].'</option>';
		foreach($fn_fenlei->setting['lang']['info_refresh_arr'] as $key => $val) {
			$info_refresh_list_option .= '<option value="'. $key.'" '.($_GET['type'] ==  $key ? ' selected' : '' ).'>'.$val.'</option>';
		}
		echo <<<SEARCH
		<form method="post" autocomplete="off" action="$SearUrl" id="tb_search">
			<div class="FormSearchTo">
				<table cellspacing="4" cellpadding="4">
					<tr>
						<th>&#20851;&#38190;&#35789;</th><td colspan="10"><input type="text" class="input form-control w200" name="keyword" value="{$_GET['keyword']}" placeholder="&#35831;&#36755;&#20837;&#117;&#105;&#100;&#47;&#29992;&#25143;&#21517;">
						</td>
						<th>&#20449;&#24687;&#73;&#68;</th><td><input type="text" class="input form-control w100" name="iid" value="{$_GET['iid']}">
						</td>
						<th>&#21047;&#26032;&#31867;&#22411;</th><td>
						<select name="type" class="form-control w120">
							{$info_refresh_list_option}
						</select>
						&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Admin->Config['LangVar']['SearchSubmit']}" class="btn btn-info" type="submit">
					</tr>
				</table>
			</div>
		</form>
SEARCH;
		/* ���� End */
		showtagheader('div', 'table-responsive', true,'table-responsive');
		showformheader($FormUrl,'enctype="multipart/form-data"');
		showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
		showsubtitle(array(
			'ID',
			'UID/'.$fn_fenlei->setting['lang']['UserNameTitle'],
			'&#20449;&#24687;',
			'&#31867;&#22411;',
			$fn_fenlei->setting['lang']['TimeTitle'],
			$fn_fenlei->setting['lang']['OperationTitle']
		), 'header tbm tc');
	
		foreach ($res['list'] as $item) {
			showtablerow('', array('class="tc w100"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
				'<input type="checkbox" class="filled-in" id="checkbox_'.$item['id'].'" name="delete[]" value="'.$item['id'].'"><label for="checkbox_'.$item['id'].'">'.$item['id'].'</label>',
				$item['uid'] ? $item['uid'].'/'.$item['username'] : '',
				$item['content'] ? '<a href="'.$fn_fenlei->getUrl('view',array('iid'=>$item['iid'])).'" target="_blank">'.cutstr($item['content'],60).'</a>' : '',
				$fn_fenlei->setting['lang']['info_refresh_arr'][$item['type']],
				date('Y-m-d H:i',$item['dateline']),
				'<a href="'.$OpCpUrl.'&do=Del&aid='.$item['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$fn_fenlei->setting['lang']['DelTitle'].'</a>',
			));
		}
		showsubmit('Submit','&#31435;&#21363;&#25552;&#20132;','del','','',multi($res['count'],30,$page,$MpUrl));
		showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		/* ģ����� End */
	}else{
		if(isset($_GET['delete']) && is_array($_GET['delete'])){
			if(!$Fn_Admin->CheckUserGroup('fenlei_all') && !$Fn_Admin->CheckUserGroup('fenlei_del_info_refresh_list')){//Ȩ���ж�
				fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
				exit();
			}
			foreach($_GET['delete'] as $val) {
				$id = intval($val);
				C::t('#fn_fenlei#fn_fenlei_info_refresh_log')->delete_by_id($id);
			}

			GetInsertDoLog('del_info_refresh_list_fenlei','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete'])));//������¼

			fn_cpmsg($fn_fenlei->setting['lang']['DelOk'],$CpMsgUrl,'succeed');
		}else{
			fn_cpmsg($fn_fenlei->setting['lang']['DelErr'],'','error');
		}
	}
}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['aid']){//ɾ��
	if(!$Fn_Admin->CheckUserGroup('fenlei_all') && !$Fn_Admin->CheckUserGroup('fenlei_del_info_refresh_list')){//Ȩ���ж�
		fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
		exit();
	}
	$id = intval($_GET['aid']);
	C::t('#fn_fenlei#fn_fenlei_info_refresh_log')->delete_by_id($id);
	GetInsertDoLog('del_info_refresh_list_fenlei','fn_'.$_GET['mod'],array('id'=>$id));//������¼

	fn_cpmsg($fn_fenlei->setting['lang']['DelOk'],$CpMsgUrl,'succeed');
}
//From: Dism_taobao_com
?>