<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('fenlei_all') && !$Fn_Admin->CheckUserGroup('fenlei_class_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$SubModel = in_array($_GET['submodel'], array('list','add')) ? $_GET['submodel'] : 'list';
$Fn_Admin->Config['IframeSubModelUrl'] = $Fn_Admin->Config['IframeItemUrl'].'&submodel='.$SubModel;
$NavClass = array($SubModel=>'btn-info Hover');

//����
echo <<<Nav
<div class="SubModelNav">
  <ul>
	<li class="{$NavClass['list']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=list" target="_self">{$Fn_Admin->Config['LangVar']['FenleiLeftNavArray'][$_GET['item']]}</a></li>
    <li class="{$NavClass['add']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=add" target="_self">{$Fn_Admin->Config['LangVar']['AddEditTitle']}</a></li>
  </ul>
  <div class="both"></div>
</div>
Nav;

$allClass = C::t('#fn_fenlei#fn_fenlei_class')->fetch_all_by_list();

if($SubModel == 'list'){//�б�

	$Do = in_array($_GET['do'], array('Del','Display','Form','FormDetails')) ? $_GET['do'] : 'submodel_list';

	$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeSubModelUrl'].'&'.http_build_query($SearArray);

	if($Do == 'submodel_list'){
		if(!submitcheck('Submit')) {
			/* ģ����� */	
			showtagheader('div', 'row', true,'row');
			showtagheader('div', 'col-12', true,'col-12');
			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-body', true,'box-body');
			showtagheader('div', 'table-responsive', true,'table-responsive');
			showformheader($FormUrl,'enctype="multipart/form-data"');
			showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
			showsubtitle(array(
				'',
				'ID',
				'&#26174;&#31034;&#39034;&#24207;',
				'&#20998;&#31867;&#21517;&#31216;',
				'&#20998;&#31867;&#22270;&#26631;',
				'&#20449;&#24687;&#25968;',
				'&#39318;&#39029;&#23548;&#33322;',
				'&#26159;&#21542;&#26174;&#31034;',
				'&#25805;&#20316;'
			),'header tbm tc');
		
			foreach ($allClass as $key=>$value) {
				if($value['level'] == 0) {
					echo showClassRow($key, 0, '');
				}
			}
			showtablefooter(); /*dism��taobao��com*/
			showsubmit('Submit','&#31435;&#21363;&#25552;&#20132;');
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			/* ģ�����End */	
		}else{
			
			foreach($_POST['name'] as $key=>$value) {
				$data['displayorder'] = $_POST['neworder'][$key];
				$data['name'] = $_POST['name'][$key];
				//$UpData['bname'] = $_POST['bname'][$key];
				C::t('#fn_fenlei#fn_fenlei_class')->update($data,$key);
			 }
			checkClass();
			fn_cpmsg($Fn_Admin->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');	
		}
	}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['classid']){//ɾ��
		if(!$Fn_Admin->CheckUserGroup('fenlei_all') && !$Fn_Admin->CheckUserGroup('fenlei_class_list_del')){//Ȩ���ж�
			fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
			exit();
		}
		$id = intval($_GET['classid']);
		C::t('#fn_fenlei#fn_fenlei_class')->delete_by_id($id);
		GetInsertDoLog('del_fenlei_list','fn_'.$_GET['mod'],array('id'=>$id));//������¼

		fn_cpmsg($fn_fenlei->setting['lang']['DelOk'],$CpMsgUrl,'succeed');
	}else if($Do == 'Display' && $_GET['formhash'] == formhash() && $_GET['classid']){//ɾ��
		
		$id = intval($_GET['classid']);
		C::t('#fn_fenlei#fn_fenlei_class')->update(array('display'=>intval($_GET['value'])),$id);
		fn_cpmsg($fn_fenlei->setting['lang']['UpdateOk'],$CpMsgUrl,'succeed');
		exit();
	}else if($Do == 'Form' && $_GET['classid']){//�Զ������
		if(!$Fn_Admin->CheckUserGroup('fenlei_all') && !$Fn_Admin->CheckUserGroup('fenlei_class_form_list')){//Ȩ���ж�
			fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
			exit();
		}
		if(!submitcheck('formsubmit')) {
			
			$form_arr_option = '';
			foreach($fn_fenlei->setting['lang']['form_arr'] as $key => $val) {
				$form_arr_option .= '<option value="'. $key.'">'.$val.'</option>';
			}

			echo <<<EOT
<script type="text/JavaScript">
	var formrowtypedata = [
		[
			[1, '', 'tc w50'],
			[1, '<input type="text" class="w80 form-control" size="2" name="newdisplayorder[]" value="0">', 'td28'],
			[1, '<input type="text" class="w200 form-control" size="15" name="newtitle[]">'],
			[1, '<input type="text" class="w200 form-control" size="15" name="newidentifier[]">'],
			[1, '<select name="newtype[]" class="form-control w150">$form_arr_option</select>'],
			[1, '']
		],
	];
</script>
EOT;
			/* ģ����� */	
			showtagheader('div', 'row', true,'row');
			showtagheader('div', 'col-12', true,'col-12');
			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-body', true,'box-body');
			showtagheader('div', 'table-responsive', true,'table-responsive');
			showformheader($Fn_Admin->Config['IframeItemUrl'].'&do=Form&classid='.$_GET['classid'],'enctype="multipart/form-data"');
			showtableheader($allClass[$_GET['classid']]['name'].' - &#33258;&#23450;&#20041;&#34920;&#21333;','table mt-0 table-hover no-wrap dataTable no-footer');
			showsubtitle(array(
				'',
				'&#26174;&#31034;&#39034;&#24207;',
				'&#21517;&#31216;',
				'&#21464;&#37327;&#21517;',
				'&#31867;&#22411;',
				'&#25805;&#20316;'
			),'header tbm tc');
			foreach(C::t('#fn_fenlei#fn_form')->fetch_all_by_classid('fenlei_info',$_GET['classid']) as $option) {
				$option['type'] = $fn_fenlei->setting['lang']['form_arr'][$option['type']];
				showtablerow('', array('class="tc w50"','class="tc w50"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
					'<input type="checkbox" class="filled-in" id="checkbox_'.$option['optionid'].'" name="delete[]" value="'.$option['optionid'].'"><label for="checkbox_'.$option['optionid'].'">'.$option['optionid'].'</label>',
					"<input type=\"text\" class=\"w80 form-control\" size=\"2\" name=\"displayorder[$option[optionid]]\" value=\"$option[displayorder]\">",
					"<input type=\"text\" class=\"w200 form-control\" size=\"15\" name=\"title[$option[optionid]]\" value=\"".dhtmlspecialchars($option['title'])."\">",
					"$option[identifier]<input type=\"hidden\" name=\"identifier[$option[optionid]]\" value=\"$option[identifier]\">",
					$option['type'],
					"<a href='".$Fn_Admin->Config['IframeItemUrl'].'&do=FormDetails&optionid='.$option['optionid'].'&classid='.$_GET['classid']."' class='btn btn-sm btn-info-outline'>&#35814;&#24773;</a>"
				));
			}
			echo '<tr><td></td><td class="tc margin-bottom-30" colspan="10"><a class="addtr" href="#" onclick="addrow(this,formrowtypedata, 0)">&#28155;&#21152;&#34920;&#21333;</a></td></tr>';
			showsubmit('formsubmit','&#31435;&#21363;&#25552;&#20132;','del');
			showtablefooter(); /*dism��taobao��com*/
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			/* ģ�����End */	
		}else{

			$mysql_keywords = array( 'ADD', 'ALL', 'ALTER', 'ANALYZE', 'AND', 'AS', 'ASC', 'ASENSITIVE', 'BEFORE', 'BETWEEN', 'BIGINT', 'BINARY', 'BLOB', 'BOTH', 'BY', 'CALL', 'CASCADE', 'CASE', 'CHANGE', 'CHAR', 'CHARACTER', 'CHECK', 'COLLATE', 'COLUMN', 'CONDITION', 'CONNECTION', 'CONSTRAINT', 'CONTINUE', 'CONVERT', 'CREATE', 'CROSS', 'CURRENT_DATE', 'CURRENT_TIME', 'CURRENT_TIMESTAMP', 'CURRENT_USER', 'CURSOR', 'DATABASE', 'DATABASES', 'DAY_HOUR', 'DAY_MICROSECOND', 'DAY_MINUTE', 'DAY_SECOND', 'DEC', 'DECIMAL', 'DECLARE', 'DEFAULT', 'DELAYED', 'DELETE', 'DESC', 'DESCRIBE', 'DETERMINISTIC', 'DISTINCT', 'DISTINCTROW', 'DIV', 'DOUBLE', 'DROP', 'DUAL', 'EACH', 'ELSE', 'ELSEIF', 'ENCLOSED', 'ESCAPED', 'EXISTS', 'EXIT', 'EXPLAIN', 'FALSE', 'FETCH', 'FLOAT', 'FLOAT4', 'FLOAT8', 'FOR', 'FORCE', 'FOREIGN', 'FROM', 'FULLTEXT', 'GOTO', 'GRANT', 'GROUP', 'HAVING', 'HIGH_PRIORITY', 'HOUR_MICROSECOND', 'HOUR_MINUTE', 'HOUR_SECOND', 'IF', 'IGNORE', 'IN', 'INDEX', 'INFILE', 'INNER', 'INOUT', 'INSENSITIVE', 'INSERT', 'INT', 'INT1', 'INT2', 'INT3', 'INT4', 'INT8', 'INTEGER', 'INTERVAL', 'INTO', 'IS', 'ITERATE', 'JOIN', 'KEY', 'KEYS', 'KILL', 'LABEL', 'LEADING', 'LEAVE', 'LEFT', 'LIKE', 'LIMIT', 'LINEAR', 'LINES', 'LOAD', 'LOCALTIME', 'LOCALTIMESTAMP', 'LOCK', 'LONG', 'LONGBLOB', 'LONGTEXT', 'LOOP', 'LOW_PRIORITY', 'MATCH', 'MEDIUMBLOB', 'MEDIUMINT', 'MEDIUMTEXT', 'MIDDLEINT', 'MINUTE_MICROSECOND', 'MINUTE_SECOND', 'MOD', 'MODIFIES', 'NATURAL', 'NOT', 'NO_WRITE_TO_BINLOG', 'NULL', 'NUMERIC', 'ON', 'OPTIMIZE', 'OPTION', 'OPTIONALLY', 'OR', 'ORDER', 'OUT', 'OUTER', 'OUTFILE', 'PRECISION', 'PRIMARY', 'PROCEDURE', 'PURGE', 'RAID0', 'RANGE', 'READ', 'READS', 'REAL', 'REFERENCES', 'REGEXP', 'RELEASE', 'RENAME', 'REPEAT', 'REPLACE', 'REQUIRE', 'RESTRICT', 'RETURN', 'REVOKE', 'RIGHT', 'RLIKE', 'SCHEMA', 'SCHEMAS', 'SECOND_MICROSECOND', 'SELECT', 'SENSITIVE', 'SEPARATOR', 'SET', 'SHOW', 'SMALLINT', 'SPATIAL', 'SPECIFIC', 'SQL', 'SQLEXCEPTION', 'SQLSTATE', 'SQLWARNING', 'SQL_BIG_RESULT', 'SQL_CALC_FOUND_ROWS', 'SQL_SMALL_RESULT', 'SSL', 'STARTING', 'STRAIGHT_JOIN', 'TABLE', 'TERMINATED', 'THEN', 'TINYBLOB', 'TINYINT', 'TINYTEXT', 'TO', 'TRAILING', 'TRIGGER', 'TRUE', 'UNDO', 'UNION', 'UNIQUE', 'UNLOCK', 'UNSIGNED', 'UPDATE', 'USAGE', 'USE', 'USING', 'UTC_DATE', 'UTC_TIME', 'UTC_TIMESTAMP', 'VALUES', 'VARBINARY', 'VARCHAR', 'VARCHARACTER', 'VARYING', 'WHEN', 'WHERE', 'WHILE', 'WITH', 'WRITE', 'X509', 'XOR', 'YEAR_MONTH', 'ZEROFILL', 'ACTION', 'BIT', 'DATE', 'ENUM', 'NO', 'TEXT', 'TIME');


			if($ids = dimplode($_GET['delete'])) {
				if(!$Fn_Admin->CheckUserGroup('fenlei_all') && !$Fn_Admin->CheckUserGroup('fenlei_class_form_del')){//Ȩ���ж�
					fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
					exit();
				}
				C::t('#fn_fenlei#fn_form')->delete($_GET['delete']);
			}
		
			if(is_array($_GET['title'])) {
				foreach($_GET['title'] as $id => $val) {
					if(in_array(strtoupper($_GET['identifier'][$id]), $mysql_keywords)) {
						continue;
					}
					C::t('#fn_fenlei#fn_form')->update($id, array(
						'displayorder' => $_GET['displayorder'][$id],
						'title' => $_GET['title'][$id],
						'identifier' => $_GET['identifier'][$id],
					));
				}
			}

			if(is_array($_GET['newtitle'])) {
				if(!$Fn_Admin->CheckUserGroup('fenlei_all') && !$Fn_Admin->CheckUserGroup('fenlei_class_form_add')){//Ȩ���ж�
					fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
					exit();
				}
				foreach($_GET['newtitle'] as $key => $value) {
					$newtitle1 = dhtmlspecialchars(trim($value));
					$newidentifier1 = trim($_GET['newidentifier'][$key]);
					if($newtitle1 && $newidentifier1) {
						if(in_array(strtoupper($newidentifier1), $mysql_keywords)) {
							fn_cpmsg('threadtype_infotypes_optionvariable_iskeyword', '', 'error');
						}
						if(C::t('#fn_fenlei#fn_form')->fetch_all_by_identifier($newidentifier1,'fenlei_info',$_GET['classid'], 0, 1) || strlen($newidentifier1) > 40  || !ispluginkey($newidentifier1)) {
							fn_cpmsg('threadtype_infotypes_optionvariable_invalid', '', 'error');
						}
						$data = array(
							'models' => 'fenlei_info',
							'classid' => $_GET['classid'],
							'displayorder' => $_GET['newdisplayorder'][$key],
							'title' => $newtitle1,
							'identifier' => $newidentifier1,
							'type' => $_GET['newtype'][$key],
						);
						C::t('#fn_fenlei#fn_form')->insert($data);
					}
				}
			}


			$tableName = 'fenlei_info'.$_GET['classid'];
			$formList = C::t('#fn_fenlei#fn_form')->fetch_all_by_classid('fenlei_info',$_GET['classid']);
			$insertoptionid = $indexoption = array();
			$create_table_sql = $separator = $create_tableoption_sql = '';
			foreach($formList as $option) {
				$insertoptionid[$option['optionid']]['type'] = $option['type'];
				$insertoptionid[$option['optionid']]['identifier'] = $option['identifier'];
			}

			if(!C::t('#fn_fenlei#fn_form_value')->showcolumns($tableName)) {
				$fields = '';
				foreach($formList as $option) {
					$optionid = $option['optionid'];
					$identifier = $insertoptionid[$optionid]['identifier'];
					if($identifier) {
						if(in_array($insertoptionid[$optionid]['type'], array('radio'))) {
							$create_tableoption_sql .= "$separator$identifier smallint(6) UNSIGNED NOT NULL DEFAULT '0'";
						} elseif(in_array($insertoptionid[$optionid]['type'], array('number', 'range'))) {
							$create_tableoption_sql .= "$separator$identifier int(10) UNSIGNED NOT NULL DEFAULT '0'";
						} elseif($insertoptionid[$optionid]['type'] == 'select') {
							$create_tableoption_sql .= "$separator$identifier varchar(50) NOT NULL";
						} else {
							$create_tableoption_sql .= "$separator$identifier mediumtext NOT NULL";
						}
						$separator = ' ,';
						if(in_array($insertoptionid[$optionid]['type'], array('radio', 'select', 'number'))) {
							$indexoption[] = $identifier;
						}
					}
				}
				$fields .= ($create_tableoption_sql ? $create_tableoption_sql.',' : '')."iid int(11) UNSIGNED NOT NULL DEFAULT '0',classid smallint(6) UNSIGNED NOT NULL DEFAULT '0',dateline int(11) UNSIGNED NOT NULL DEFAULT '0',expiration int(10) UNSIGNED NOT NULL DEFAULT '0',";
				$fields .= "KEY (iid), KEY (classid), KEY(dateline)";
				if($indexoption) {
					foreach($indexoption as $index) {
						$fields .= "$separator KEY $index ($index)";
						$separator = ' ,';
					}
				}
				$dbcharset = $_G['config']['db'][1]['dbcharset'];
				$dbcharset = empty($dbcharset) ? str_replace('-','',CHARSET) : $dbcharset;
				C::t('#fn_fenlei#fn_form_value')->create($tableName, $fields, $dbcharset);
			}else{
				$tables = C::t('#fn_fenlei#fn_form_value')->showcolumns($tableName);
				foreach($formList as $option) {
					$optionid = $option['optionid'];
					$identifier = $insertoptionid[$optionid]['identifier'];
					if(!$tables[$identifier]) {
						$fieldname = $identifier;
						if(in_array($insertoptionid[$optionid]['type'], array('radio'))) {
							$fieldtype = 'smallint(6) UNSIGNED NOT NULL DEFAULT \'0\'';
						} elseif(in_array($insertoptionid[$optionid]['type'], array('number', 'range'))) {
							$fieldtype = 'int(10) UNSIGNED NOT NULL DEFAULT \'0\'';
						} elseif($insertoptionid[$optionid]['type'] == 'select') {
							$fieldtype = 'varchar(50) NOT NULL';
						} else {
							$fieldtype = 'mediumtext NOT NULL';
						}
						C::t('#fn_fenlei#fn_form_value')->alter($tableName, "ADD $fieldname $fieldtype");
						if(in_array($insertoptionid[$optionid]['type'], array('radio', 'select', 'number'))) {
							C::t('#fn_fenlei#fn_form_value')->alter($tableName, "ADD INDEX ($fieldname)");
						}  
					}
				}
			}
			checkForm();
			checkClass();
			fn_cpmsg($fn_fenlei->setting['lang']['UpdateOk'],$Fn_Admin->Config['IframeItemUrl'].'&submodel=list&do=Form&classid='.$_GET['classid'],'succeed');
			exit();
		}
	}else if($Do == 'FormDetails' && $_GET['optionid']){//�޸��Զ����������
		$item = C::t('#fn_fenlei#fn_form')->fetch($_GET['optionid']);
		if(!submitcheck('DetailSubmit')) {
			
			$typeSelect = '<select class="form-control" name="type" onchange="if(this.value.indexOf(\'radio\') >= 0 || this.value.indexOf(\'select\') >= 0 || this.value.indexOf(\'checkbox\') >= 0) document.getElementById(\'extra\').style.display=\'\'; else document.getElementById(\'extra\').style.display=\'none\';">';
			foreach($fn_fenlei->setting['lang']['form_arr'] as $type => $vue) {
				$typeSelect .= '<option value="'.$type.'" '.($item['type'] == $type ? 'selected' : '').'>'.$vue.'</option>';
			}
			$typeSelect .= '</select>';

			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-header', true,'with-border box-header');
			showtitle($allClass[$_GET['classid']]['name'].'&#33258;&#23450;&#20041;&#34920;&#21333; - '.$item['title'],'class="box-title"');
			showtagfooter('div');
			showformheader($Fn_Admin->Config['IframeItemUrl'].'&submodel=list&do=FormDetails&optionid='.$item['optionid'].'&classid='.$_GET['classid'],'enctype');
			showtagheader('div', 'box-body', true,'box-body');
			
			showsetting('&#37197;&#32622;&#21517;&#31216;', 'title', $item['title'], 'text');

			//showsetting('&#21464;&#37327;&#21517;', 'identifier', $item['identifier'], 'text');
			
			showsetting('&#37197;&#32622;&#31867;&#22411;', '', '', $typeSelect);
			
			showtagheader('div', 'extra', $item['type'] == 'radio' || $item['type'] == 'select' || $item['type'] == 'selects' || $item['type'] == 'checkbox','sub');
				$rules = dunserialize($item['rules']);
				showsetting('&#23383;&#27573;&#20869;&#23481;', 'rules[choices]',$rules['choices'], 'textarea','','',$fn_fenlei->setting['lang']['rulesTips']);
			showtagfooter('div');

			showsetting('&#21333;&#20301;', 'unitnew', $item['unitnew'], 'text','','','&#32;&#22914;&#26524;&#31867;&#22411;&#20026;&#19978;&#20256;&#22270;&#29255;&#44;&#35831;&#22635;&#20889;&#26410;&#19978;&#20256;&#30340;&#25552;&#31034;&#35821;&#65292;&#24320;&#21551;&#24517;&#22635;&#26377;&#25928;');

			showsetting('&#34920;&#21333;&#39044;&#32622;&#35789;', 'description', $item['description'], 'text','','','&#34920;&#21333;&#26174;&#31034;&#30340;&#39044;&#32622;&#35789;&#44;&#32;&#22914;&#26524;&#31867;&#22411;&#20026;&#19978;&#20256;&#22270;&#29255;&#44;&#35831;&#22635;&#20889;&#20801;&#35768;&#19978;&#20256;&#30340;&#26368;&#22823;&#22270;&#29255;&#25968;&#37327;');

			showsetting('&#26159;&#21542;&#24517;&#22635;', 'required', $item['required'], 'radio');

			showsetting('&#19981;&#21487;&#20462;&#25913;', 'unchangeable', $item['unchangeable'], 'radio');

			
			showsetting('&#34920;&#21333;&#25628;&#32034;',array('formsearch', array(
				array('1','&#26159;', array('formsearch_div' => '')),
				array('0','&#21542;', array('formsearch_div' => 'none')),
			), TRUE),$item['formsearch'], 'mradio');
			showtagheader('div', 'formsearch_div', $item['formsearch'] == 1 ? true : '','sub');
				showsetting('&#33539;&#22260;&#25628;&#32034;', 'range', $item['range'], 'radio','','','&#25968;&#23383;&#31867;&#22411;&#26377;&#25928;');
			showtagfooter('div');

			showsetting('&#36807;&#26399;&#38544;&#34255;', 'autohide', $item['autohide'], 'radio','','','&#36807;&#26399;&#33258;&#34892;&#38544;&#34255;&#20449;&#24687;&#40;&#20165;&#38480;&#26102;&#38388;&#26085;&#26399;&#31867;&#22411;&#59;&#25171;&#24320;&#21518;&#32;&#27492;&#23383;&#27573;&#30340;&#26102;&#38388;&#22914;&#26524;&#36807;&#26399;&#32;&#20250;&#33258;&#21160;&#26631;&#35760;&#36807;&#26399;&#41;');

			$autoicon_html = ($item['autoicon'] ? '<a href="'.$item['autoicon'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$item['autoicon'].'" height="55"/></a>' : '').'&#31354;&#20195;&#34920;&#19981;&#24320;&#21551;&#65292;&#36807;&#26399;&#33258;&#21160;&#21152;&#19978;&#22270;&#26631;&#40;&#20165;&#38480;&#26102;&#38388;&#26085;&#26399;&#31867;&#22411;&#41;';
			showsetting('&#36807;&#26399;&#22270;&#26631;', 'new_autoicon',$item['autoicon'], 'filetext', '', 0, $autoicon_html);

			//showsetting('&#26631;&#39064;&#26174;&#31034;', 'autotitle', $item['autotitle'], 'radio','','','&#26631;&#39064;&#26159;&#21542;&#26174;&#31034;&#27492;&#23383;&#27573;&#40;&#24320;&#21551;&#21518;&#65292;&#27492;&#23383;&#27573;&#30340;&#20869;&#23481;&#20250;&#33258;&#21160;&#22312;&#26631;&#39064;&#37324;&#26174;&#31034;&#41;');

			showsetting('&#26367;&#25442;&#38754;&#35758;', 'interview', $item['interview'], 'radio','','','&#48;&#47;&#31354;&#30340;&#26102;&#20505;&#65292;&#33258;&#21160;&#26367;&#25442;&#20026;&#38754;&#35758;&#65292;&#20215;&#26684;&#23383;&#27573;&#26102;&#29992;&#21040;');
		
			showsubmit('DetailSubmit','&#20445;&#23384;&#37197;&#32622;');
			showtagfooter('div');
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');
		}else{
			$title = trim($_GET['title']);
			//$_GET['identifier'] = trim($_GET['identifier']);
			if(!$title) {
				fn_cpmsg('threadtype_infotypes_option_invalid', '', 'error');
				exit();
			}

			/*if(in_array(strtoupper($_GET['identifier']), $mysql_keywords)) {
				fn_cpmsg('threadtype_infotypes_optionvariable_iskeyword', '', 'error');
				exit();
			}

			if((C::t('#fn_fenlei#fn_form')->fetch_all_by_identifier($_GET['identifier'],'fenlei_info',$_GET['classid'], 0, 1) || strlen($_GET['identifier']) > 40  || !ispluginkey($_GET['identifier'])) && $_GET['identifier'] != $item['identifier']) {
				fn_cpmsg('threadtype_infotypes_optionvariable_invalid', '', 'error');
				exit();
			}*/
			
			$data['title'] = addslashes(strip_tags($_GET['title']));
			//$data['identifier'] = addslashes(strip_tags($_GET['identifier']));
			$data['description'] = addslashes(strip_tags($_GET['description']));
			$data['type'] = addslashes(strip_tags($_GET['type']));
			$rules = $_GET['rules'];
			foreach(explode("\n", $rules['choices']) as $val) {
				list($index, $choice) = explode('=', $val);
				$choices[trim($index)] = trim($choice);
			}
			$rules['choices_arr'] = $rules['choices'] ? $choices : '';
			$data['rules'] = serialize($rules);
			$data['unitnew'] = addslashes(strip_tags($_GET['unitnew']));
			$data['required'] = intval($_GET['required']);
			$data['unchangeable'] = intval($_GET['unchangeable']);
			$data['formsearch'] = intval($_GET['formsearch']);
			$data['range'] = intval($_GET['range']);
			$data['autohide'] = intval($_GET['autohide']);
			$data['autotitle'] = intval($_GET['autotitle']);
			$data['interview'] = intval($_GET['interview']);
			$data = array_merge($data,$Fn_Admin->uploadFiles($_FILES));
			C::t('#fn_fenlei#fn_form')->update($item['optionid'], $data);
			checkForm();
			checkClass();
			fn_cpmsg($fn_fenlei->setting['lang']['UpdateOk'],$Fn_Admin->Config['IframeItemUrl'].'&submodel=list&do=Form&classid='.$_GET['classid'],'succeed');
			exit();
		}
	}
}else if($SubModel == 'add'){//���ӻ�༭
	
	$id = intval($_GET['classid']);

	$item = C::t('#fn_fenlei#fn_fenlei_class')->fetch_by_classid($id);

	if(!submitcheck('DetailSubmit')) {
		//ͼƬ�ϴ�
		if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_assembly/class/class_upload.php')){
			@require_once libfile('class/upload','plugin/fn_assembly');
			$UploadConfig = fn_upload::Config();
		}

		$opTitle = $item ? $fn_fenlei->setting['lang']['EditTitle'] : $fn_fenlei->setting['lang']['AddTitle'];

		showtagheader('div', 'box', true,'box');
		showformheader($Fn_Admin->Config['IframeSubModelUrl'].'&copy='.$_GET['copy'].'&classid='.$id,'enctype');
		echo <<<HTML
		<ul class="nav nav-tabs customtab" role="tablist">
          <li class="nav-item"> <a class="nav-link active" data-toggle="tab" href="#basics" role="tab" aria-expanded="true"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#22522;&#30784;&#35774;&#32622;</span></a> </li>
		  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#pub" role="tab" aria-expanded="false"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#21457;&#24067;&#35774;&#32622;</span></a> </li>
		  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#price" role="tab" aria-expanded="false"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#20215;&#26684;&#35774;&#32622;</span></a> </li>
		  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#ad" role="tab" aria-expanded="false"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#24191;&#21578;&#35774;&#32622;</span></a> </li>
		  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#share" role="tab" aria-expanded="false"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#20998;&#20139;&#35774;&#32622;</span></a> </li>
        </ul>
HTML;
		showtagheader('div', 'box-body', true,'box-body');
		showtagheader('div', 'tab-content', true,'tab-content');
		
		echo <<<HTML
		<!-- ��������  -->
		<div class="tab-pane active" id="basics" role="tabpanel" aria-expanded="true">
HTML;

		showsetting('&#20998;&#31867;&#21517;&#31216;', 'name', $item['name'], 'text');
		$ico_html = ($item['ico'] ? '<a href="'.$item['ico'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$item['ico'].'" height="55"/></a>' : '').'&#24314;&#35758;&#49;&#53;&#48;&#32;&#42;&#32;&#49;&#53;&#48;&#10;&#10;';
		showsetting('&#20998;&#31867;&#22270;&#26631;', 'new_ico',$item['ico'], 'filetext', '', 0, $ico_html);

		showsetting('&#19978;&#32423;&#20998;&#31867;', '','',$fn_fenlei->getClassShowSelect($allClass,'bclassid',true,$item['bclassid'] ? $item['bclassid'] : $_GET['bclassid'],true));

		showsetting('&#39318;&#39029;&#23548;&#33322;', 'nav', $item['nav'], 'radio','','','&#26159;&#21542;&#35843;&#29992;&#21040;&#39318;&#39029;&#23548;&#33322;');

		showsetting('&#26159;&#21542;&#36339;&#36716;&#38142;&#25509;',array('jump', array(
			array('1','&#26159;', array('jump_div_1' => '','jump_div_0' => 'none')),
			array('0','&#21542;', array('jump_div_1' => 'none','jump_div_0' => '')),
		), TRUE),$item ? $item['jump'] : 0, 'mradio');
		showtagheader('div', 'jump_div_1', $item['jump'],'sub');
			showsetting('&#36339;&#36716;&#38142;&#25509;', 'jump_url', $item['jump_url'], 'text');
		showtagfooter('div');

		showtagheader('div', 'jump_div_0', !$item['jump'] || !$item,'sub');
			$top_icon = $item['top_icon'] ? $item['top_icon'] : '/source/plugin/fn_fenlei/static/images/top.png';
			$top_icon_html = '<a href="'.$top_icon.'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$top_icon.'" height="30"/></a>&#24314;&#35758;&#49;&#48;&#48;&#32;&#42;&#32;&#53;&#56;';
			showsetting('&#32622;&#39030;&#22270;&#26631;', 'new_top_icon',$top_icon, 'filetext', '', 0, $top_icon_html);

			$info_thumb = $item['info_thumb'] ? $item['info_thumb'] : '/source/plugin/fn_fenlei/static/images/info_thumb.jpg';
			$info_thumb_html = '<a href="'.$info_thumb.'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$info_thumb.'" height="30"/></a>&#24314;&#35758;&#65306;&#50;&#53;&#48;&#32;&#42;&#32;&#49;&#57;&#48;';
			showsetting('&#40664;&#35748;&#32553;&#30053;&#22270;', 'new_info_thumb',$info_thumb, 'filetext', '', 0, $info_thumb_html);

			$info_solve_icon = $item['info_solve_icon'] ? $item['info_solve_icon'] : '/source/plugin/fn_fenlei/static/images/solve.png';
			$info_solve_icon_html = '<a href="'.$info_solve_icon.'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$info_solve_icon.'" height="30"/></a>&#24314;&#35758;&#65306;&#50;&#53;&#48;&#32;&#42;&#32;&#49;&#57;&#48;';
			showsetting('&#24050;&#35299;&#20915;&#22270;&#26631;', 'new_info_solve_icon',$info_solve_icon, 'filetext', '', 0, $info_solve_icon_html);

			$tempList = array();
			foreach(C::t('#fn_fenlei#fn_fenlei_temp')->fetch_all_by_list(array('type'=>1)) as $val) {
				$tempList[] = array($val['id'], $val['title']);
			}
			showsetting('&#21015;&#34920;&#27169;&#26495;', array('list_temp_id', $tempList),$item['list_temp_id'], 'select');
			showsetting('&#20869;&#23481;&#27169;&#26495;', array('info_temp_id',DyadicArray($fn_fenlei->setting['lang']['info_temp_arr'])),$item['info_temp_id'], 'select');
			showsetting('&#24320;&#21551;&#35814;&#24773;&#39029;&#29468;&#24744;&#21916;&#27426;', 'info_like', $item ? $item['info_like'] : 1, 'radio');
			showsetting('&#35814;&#24773;&#39029;&#32852;&#31995;&#35201;&#30331;&#24405;&#65311;', 'info_login', $item['info_login'], 'radio','','','&#35814;&#24773;&#39029;&#26597;&#30475;&#32852;&#31995;&#26041;&#24335;&#26159;&#21542;&#35201;&#30331;&#24405;&#65311;');
			showsetting('&#35814;&#24773;&#39029;&#26174;&#31034;&#32852;&#31995;&#27169;&#22359;', 'info_contact', $item ? $item['info_contact'] : 1, 'radio');
			showsetting('&#35814;&#24773;&#39029;&#20813;&#36131;&#22768;&#26126;', 'info_statement', $item['info_statement'], 'textarea','','','&#30041;&#31354;&#20195;&#34920;&#20851;&#38381;');
			showsetting('&#35814;&#24773;&#39029;&#27983;&#35272;&#38543;&#26426;&#25968;', 'info_click_rand', $item['param']['info_click_rand'] ? $item['param']['info_click_rand'] : '1-1', 'text','','','&#26684;&#24335;&#65306;&#26368;&#23567;&#38543;&#26426;&#25968;&#45;&#26368;&#22823;&#38543;&#26426;&#25968;');
			showsetting('&#35814;&#24773;&#39029;&#20960;&#20154;&#21672;&#35810;', 'info_phone_count',$item['param']['info_phone_count'] ? $item['param']['info_phone_count'] : '5', 'text','','','&#35814;&#24773;&#39029;&#24213;&#37096;&#25320;&#25171;&#30005;&#35805;&#65292;&#36229;&#36807;&#35774;&#32622;&#20154;&#25968;&#26174;&#31034;&#65292;&#20960;&#20154;&#21672;&#35810;');

			showsetting('&#35814;&#24773;&#39029;&#19981;&#26174;&#31034;&#25910;&#34255;', 'info_bottom_collection', $item['param']['info_bottom_collection'], 'radio','','','&#35814;&#24773;&#39029;&#24213;&#37096;&#22266;&#23450;&#27169;&#22359;&#26159;&#21542;&#19981;&#26174;&#31034;&#22270;&#26631;&#65311;');

			showsetting('&#35814;&#24773;&#39029;&#19981;&#26174;&#31034;&#21457;&#24067;', 'info_bottom_pub', $item['param']['info_bottom_pub'], 'radio','','','&#35814;&#24773;&#39029;&#24213;&#37096;&#22266;&#23450;&#27169;&#22359;&#19981;&#26174;&#31034;&#21457;&#24067;&#22270;&#26631;&#65311;');

			showsetting('&#35814;&#24773;&#39029;&#26174;&#31034;&#20998;&#20139;',array('info_bottom_share', array(
				array('1','&#26159;', array('info_bottom_share_1' => '')),
				array('0','&#21542;', array('info_bottom_share_1' => 'none')),
			), TRUE),$item['param']['info_bottom_share'], 'mradio','','','&#35814;&#24773;&#39029;&#24213;&#37096;&#22266;&#23450;&#27169;&#22359;&#26159;&#21542;&#26174;&#31034;&#20998;&#20139;&#22270;&#26631;&#65311;');
			showtagheader('div', 'info_bottom_share_1', $item['param']['info_bottom_share'] ? true : '','sub');
				showsetting('&#20998;&#20139;&#22270;&#26631;&#26631;&#39064;', 'info_bottom_share_title',$item['param']['info_bottom_share_title'] ? $item['param']['info_bottom_share_title'] : "&#20998;&#20139;", 'text');
				showsetting('&#26174;&#31034;&#20998;&#20139;&#25552;&#31034;&#35821;',array('info_bottom_share_tips', array(
					array('1','&#26159;', array('info_bottom_share_tips_1' => '')),
					array('0','&#21542;', array('info_bottom_share_tips_1' => 'none')),
				), TRUE),$item['param']['info_bottom_share_tips'], 'mradio','','','&#26159;&#21542;&#26174;&#31034;&#20998;&#20139;&#25552;&#31034;&#35821;&#65311;');
				showtagheader('div', 'info_bottom_share_tips_1', $item['param']['info_bottom_share_tips'] ? true : '','sub');
					showsetting('&#20998;&#20139;&#25552;&#31034;&#35821;', 'info_bottom_share_tips_text',$item['param']['info_bottom_share_tips_text'] ? stripslashes($item['param']['info_bottom_share_tips_text']) : "&#24050;&#26377;&#91;&#45;&#45;&#115;&#104;&#97;&#114;&#101;&#95;&#99;&#111;&#117;&#110;&#116;&#45;&#45;&#93;&#24110;&#24537;&#36716;&#21457;", 'text');
				showtagfooter('div');
			showtagfooter('div');

			showsetting('&#35814;&#24773;&#39029;&#20984;&#20986;&#20998;&#20139;',array('info_bottom_main_share', array(
				array('1','&#26159;', array('info_bottom_main_share_1' => '')),
				array('0','&#21542;', array('info_bottom_main_share_1' => 'none')),
			), TRUE),$item['param']['info_bottom_main_share'], 'mradio','','','&#35814;&#24773;&#39029;&#26159;&#21542;&#20984;&#20986;&#20998;&#20139;&#27169;&#22359;&#65292;&#29992;&#20110;&#22833;&#29289;&#35748;&#39046;&#27169;&#22359;&#26368;&#21512;&#36866;');
			showtagheader('div', 'info_bottom_main_share_1', $item['param']['info_bottom_main_share'] ? true : '','sub');
				showsetting('&#20984;&#20986;&#20998;&#20139;&#25353;&#38062;&#25991;&#23383;', 'info_bottom_main_share_btn',$item['param']['info_bottom_main_share_btn'] ? $item['param']['info_bottom_main_share_btn'] : "&#31435;&#21363;&#20998;&#20139;", 'text');
			showtagfooter('div');

			showsetting('&#35814;&#24773;&#39029;&#25320;&#25171;&#30005;&#35805;&#25353;&#38062;', 'info_bottom_tel_btn',$item['param']['info_bottom_tel_btn'] ? $item['param']['info_bottom_tel_btn'] : "&#25320;&#25171;&#30005;&#35805;", 'text','','','&#35814;&#24773;&#39029;&#24213;&#37096;&#22266;&#23450;&#27169;&#22359;&#25320;&#25171;&#30005;&#35805;&#25353;&#38062;&#25991;&#23383;');

			if(AppYes){
				showsetting('&#35814;&#24773;&#39029;&#26174;&#31034;&#32842;&#22825;',array('info_chat', array(
					array('1','&#26159;', array('info_chat_1' => '')),
					array('0','&#21542;', array('info_chat_1' => 'none')),
				), TRUE),$item ? $item['param']['info_chat'] : 1, 'mradio','','','&#35814;&#24773;&#39029;&#24213;&#37096;&#22266;&#23450;&#27169;&#22359;&#26159;&#21542;&#26174;&#31034;&#32842;&#22825;&#22270;&#26631;&#65311;');
				showtagheader('div', 'info_chat_1', $item['param']['info_chat'] || !$item ? true : '','sub');
					showsetting('&#35814;&#24773;&#39029;&#32842;&#22825;&#25552;&#31034;&#35821;', 'info_chat_tips', $item['param']['info_chat_tips'] ? $item['param']['info_chat_tips'] : '&#19979;&#36733;&#39134;&#40479;&#65;&#80;&#80;&#39532;&#19978;&#21487;&#20197;&#21644;&#25105;&#22312;&#32447;&#32842;&#22825;&#21734;', 'text','','','&#38750;&#65;&#80;&#80;&#20869;&#30340;&#28857;&#20987;&#32842;&#22825;&#30340;&#25552;&#31034;&#35821;');
				showtagfooter('div');
			}

		showtagfooter('div');
		
		showsetting($fn_fenlei->setting['lang']['DisplayTitle'], 'display', $item ? $item['display'] : 1, 'radio');

		showsetting('display_order', 'displayorder',$item['displayorder'], 'text');

		if($item['dateline']){
			showsetting($fn_fenlei->setting['lang']['TimeTitle'], 'dateline',date('Y-m-d H:i',$item['dateline']), 'calendar','','','',1);
		}

		echo <<<HTML
		</div>
		<!-- �������� end  -->
HTML;

		echo <<<HTML
		<!-- ��������  -->
		<div class="tab-pane" id="pub" role="tabpanel" aria-expanded="false">
HTML;
		showsetting('&#20449;&#24687;&#26377;&#25928;&#22825;&#25968;', 'info_end_day',$item['info_end_day'] ? $item['info_end_day'] : 30, 'text');

		showsetting('&#21457;&#24067;&#20449;&#24687;&#26159;&#21542;&#23457;&#26680;', 'pub_audit', $item['param']['pub_audit'], 'radio');

		showsetting('&#32534;&#36753;&#20449;&#24687;&#26159;&#21542;&#23457;&#26680;', 'pub_edit_audit',$item['param']['pub_edit_audit'], 'radio');

		showsetting('&#21457;&#24067;&#26159;&#21542;&#26174;&#31034;&#32622;&#39030;', 'pub_top',$item ? $item['param']['pub_top'] : 1, 'radio');
		

		showsetting('&#21457;&#24067;&#24320;&#21551;&#26631;&#39064;&#22635;&#20889;',array('pub_title', array(
			array('1','&#26159;', array('pub_title_div' => '')),
			array('0','&#21542;', array('pub_title_div' => 'none')),
		), TRUE),$item ? $item['param']['pub_title'] : 0, 'mradio','','','&#21457;&#24067;&#26159;&#21542;&#24320;&#21551;&#26631;&#39064;&#22635;&#20889;');
		showtagheader('div', 'pub_title_div', $item['param']['pub_title'] ? true : '','sub');
			showsetting('&#21457;&#24067;&#26631;&#39064;&#26159;&#21542;&#24517;&#22635;', 'pub_title_fill', $item ? $item['param']['pub_title_fill'] : 1, 'radio');
		showtagfooter('div');

		showsetting('&#21457;&#24067;&#24320;&#21551;&#35814;&#24773;&#22635;&#20889;',array('pub_content', array(
			array('1','&#26159;', array('pub_content_div' => '')),
			array('0','&#21542;', array('pub_content_div' => 'none')),
		), TRUE),$item ? $item['param']['pub_content'] : 1, 'mradio','','','&#21457;&#24067;&#26159;&#21542;&#24320;&#21551;&#26631;&#39064;&#22635;&#20889;');
		showtagheader('div', 'pub_content_div', $item['param']['pub_content'] ? true : '','sub');
			showsetting('&#21457;&#24067;&#35814;&#24773;&#26159;&#21542;&#24517;&#22635;', 'pub_content_fill', $item ? $item['param']['pub_content_fill'] : 1, 'radio');
		showtagfooter('div');

		showsetting('&#24320;&#21551;&#21457;&#24067;&#22270;&#29255;',array('pub_album', array(
			array('1','&#26159;', array('pub_album_div' => '')),
			array('0','&#21542;', array('pub_album_div' => 'none')),
		), TRUE),$item ? $item['param']['pub_album'] : 1, 'mradio');
		showtagheader('div', 'pub_album_div', $item['param']['pub_album'] == 1 || !$item ? true : '','sub');
			showsetting('&#21457;&#24067;&#22270;&#29255;&#26159;&#21542;&#24517;&#22635;', 'pub_album_fill', $item ? $item['param']['pub_album_fill'] : 1, 'radio');
		showtagfooter('div');

		showsetting('&#21457;&#24067;&#24320;&#21551;&#32852;&#31995;&#22995;&#21517;', 'pub_name', $item ? $item['param']['pub_name'] : 1, 'radio','','','&#21457;&#24067;&#30340;&#26159;&#21542;&#24320;&#21551;&#22635;&#20889;&#32852;&#31995;&#22995;&#21517;');

		showsetting('&#21457;&#24067;&#24320;&#21551;&#21306;&#22495;&#36873;&#25321;',array('pub_region', array(
			array('1','&#26159;', array('pub_region_div' => '')),
			array('0','&#21542;', array('pub_region_div' => 'none')),
		), TRUE),$item ? $item['param']['pub_region'] : 1, 'mradio','','','&#21457;&#24067;&#26159;&#21542;&#24320;&#21551;&#21306;&#22495;&#36873;&#25321;');
		showtagheader('div', 'pub_region_div', $item['param']['pub_region'] == 1 || !$item ? true : '','sub');
			showsetting('&#21306;&#22495;&#36873;&#25321;&#26159;&#21542;&#24517;&#22635;', 'pub_region_fill', $item ? $item['param']['pub_region_fill'] : 1, 'radio');
		showtagfooter('div');

		showsetting('&#21457;&#24067;&#24320;&#21551;&#22320;&#22336;&#22635;&#20889;',array('pub_address', array(
			array('1','&#26159;', array('pub_address_div' => '')),
			array('0','&#21542;', array('pub_address_div' => 'none')),
		), TRUE),$item ? $item['param']['pub_address'] : 1, 'mradio','','','&#21457;&#24067;&#26159;&#21542;&#24320;&#21551;&#22320;&#22336;&#22635;&#20889;');
		showtagheader('div', 'pub_address_div', $item['param']['pub_address'] == 1 || !$item ? true : '','sub');
			showsetting('&#22320;&#22336;&#36873;&#25321;&#26159;&#21542;&#24517;&#22635;', 'pub_address_fill', $item ? $item['param']['pub_address_fill'] : 1, 'radio');
			showsetting('&#21457;&#24067;&#26159;&#21542;&#24320;&#21551;&#23450;&#20301;',array('pub_location', array(
				array('1','&#26159;', array('pub_location_div' => '')),
				array('0','&#21542;', array('pub_location_div' => 'none')),
			), TRUE),$item ? $item['param']['pub_location'] : 1, 'mradio');
			showtagheader('div', 'pub_location_div', $item['param']['pub_location'] == 1 || !$item ? true : '','sub');
				showsetting('&#21457;&#24067;&#33258;&#21160;&#21152;&#36733;&#23450;&#20301;', 'pub_location_auto', $item ? $item['param']['pub_location_auto'] : 1, 'radio');
			showtagfooter('div');
		showtagfooter('div');

		showsetting('&#21457;&#24067;&#24320;&#21551;&#35282;&#33394;&#36873;&#25321;',array('pub_role', array(
			array('1','&#26159;', array('pub_role_div' => '')),
			array('0','&#21542;', array('pub_role_div' => 'none')),
		), TRUE),$item ? $item['param']['pub_role'] : 0, 'mradio','','','&#21457;&#24067;&#26159;&#21542;&#24320;&#21551;&#35282;&#33394;&#36873;&#25321;');
		showtagheader('div', 'pub_role_div', $item['param']['pub_role'] ? true : '','sub');
			showsetting('&#21457;&#24067;&#35282;&#33394;&#26631;&#39064;', 'pub_role_title',$item['param']['pub_role_title'] ? $item['param']['pub_role_title'] : '&#20449;&#24687;&#26469;&#28304;', 'text','','','&#20363;&#22914;&#65306;&#36710;&#36742;&#26469;&#28304;');
			showsetting('&#21457;&#24067;&#35282;&#33394;&#26631;&#31614;', 'pub_role_arr',$item['param']['pub_role_arr'] ? $item['param']['pub_role_arr'] : "1=&#20010;&#20154;", 'textarea','','','&#19968;&#34892;&#19968;&#26631;&#31614;&#65281;&#65281;&#65281;&#26684;&#24335;&#65306;&#49;&#61;&#26631;&#31614;&#19968;&#65292;&#50;&#61;&#26631;&#31614;&#20108;&#65281;&#65281;&#65281;&#20363;&#22914;&#65306;<br>&#49;&#61;&#26631;&#31614;&#19968;<br>&#50;&#61;&#26631;&#31614;&#20108;');
			showsetting('&#21457;&#24067;&#35282;&#33394;&#25552;&#31034;&#35821;', 'pub_role_tips',$item['param']['pub_role_tips'] ? $item['param']['pub_role_tips'] : '&#24517;&#39035;&#30495;&#23454;&#36873;&#25321;&#65292;&#20081;&#36873;&#25321;&#23558;&#21487;&#33021;&#34987;&#21024;&#38500;&#21450;&#23553;&#21495;&#65292;&#19981;&#36864;&#27454;', 'text');
			showsetting('&#21457;&#24067;&#35282;&#33394;&#26410;&#36873;&#25552;&#31034;', 'pub_role_err',$item['param']['pub_role_err'] ? $item['param']['pub_role_err'] : '&#35831;&#36873;&#25321;&#20449;&#24687;&#26469;&#28304;', 'text');
		showtagfooter('div');

		showsetting('&#21457;&#24067;&#24320;&#21551;&#26631;&#31614;&#36873;&#25321;',array('pub_tag', array(
			array('1','&#26159;', array('pub_tag_div' => '')),
			array('0','&#21542;', array('pub_tag_div' => 'none')),
		), TRUE),$item ? $item['param']['pub_tag'] : 0, 'mradio','','','&#21457;&#24067;&#26159;&#21542;&#24320;&#21551;&#26631;&#31614;&#36873;&#25321;');
		showtagheader('div', 'pub_tag_div', $item['param']['pub_tag'] ? true : '','sub');
			showsetting('&#21457;&#24067;&#26631;&#31614;&#20869;&#23481;', 'pub_tag_arr',$item['param']['pub_tag_arr'], 'textarea','','','&#19968;&#34892;&#19968;&#26631;&#31614;&#65281;&#65281;&#65281;&#26684;&#24335;&#65306;&#49;&#61;&#26631;&#31614;&#19968;&#65292;&#50;&#61;&#26631;&#31614;&#20108;&#65281;&#65281;&#65281;&#20363;&#22914;&#65306;<br>&#49;&#61;&#26631;&#31614;&#19968;<br>&#50;&#61;&#26631;&#31614;&#20108;');
			showsetting('&#21457;&#24067;&#26631;&#31614;&#26159;&#21542;&#24517;&#22635;', 'pub_tag_fill', $item['param']['pub_tag_fill'], 'radio');
			showsetting('&#21457;&#24067;&#26631;&#31614;&#38480;&#21046;&#20010;&#25968;', 'pub_tag_count', $item['param']['pub_tag_count'], 'text','','','&#48;&#47;&#31354;&#20195;&#34920;&#19981;&#38480;&#21046;');
		showtagfooter('div');
		echo <<<HTML
		</div>
		<!-- �������� end  -->
HTML;
		
		echo <<<HTML
		<!-- �۸�����  -->
		<div class="tab-pane" id="price" role="tabpanel" aria-expanded="false">
HTML;
		showsetting('&#21457;&#24067;&#20215;&#26684;', 'pub_price',$item ? $item['pub_price'] : 2, 'text','','','&#48;&#47;&#31354;&#20195;&#34920;&#20813;&#36153;');

		showsetting('&#21457;&#24067;&#25552;&#31034;&#35821;', 'pub_price_tips',$item['param']['pub_price_tips'] ? $item['param']['pub_price_tips'] : '&#26412;&#20449;&#24687;&#21457;&#24067;<span class=text-red>{price}</span>&#65292;&#26377;&#25928;&#26399;<span class=text-red>30&#22825;</span>', 'textarea','','','{price}&#20195;&#34920;&#21457;&#24067;&#20215;&#26684;&#65292;{br}&#20195;&#34920;&#25442;&#34892;');

		showsetting('&#21047;&#26032;&#20215;&#26684;', 'refresh_price',$item ? $item['refresh_price'] : '0.01', 'text','','','&#31354;&#25110;&#48;&#20195;&#34920;&#19981;&#24320;&#21551;');

		if(AppYes){
			showsetting('&#65;&#80;&#80;&#21457;&#24067;&#20215;&#26684;', 'app_pub_price', $item ? $item['app_pub_price'] : 1, 'text','','','&#48;&#47;&#31354;&#20195;&#34920;&#20813;&#36153;');

			showsetting('&#65;&#80;&#80;&#21457;&#24067;&#25552;&#31034;&#35821;', 'app_pub_price_tips',$item['param']['app_pub_price_tips'] ? $item['param']['app_pub_price_tips'] : '&#35813;&#26465;&#21457;&#24067;&#38656;&#35201;&#25903;&#20184;{price}&#65292;&#26377;&#25928;&#26399;<span class=text-red>30&#22825;</span>{br}
&#21069;&#24448;APP&#21457;&#24067;&#65292;&#20165;&#38656;<span class=text-red>{appprice}</span>&#65292;{down}', 'textarea','','','&#38750;APP&#19979; &#20351;&#29992;&#35813;&#25552;&#31034;&#35821;<br>{price}&#20195;&#34920;&#21457;&#24067;&#20215;&#26684;&#65292;{appprice}&#20195;&#34920;APP&#21457;&#24067;&#20215;&#26684;&#65292;{br}&#20195;&#34920;&#25442;&#34892;&#65292;{down}&#20195;&#34920;&#28857;&#20987;&#19979;&#36733;');
		}

		showsetting('&#24320;&#21551;&#20813;&#36153;&#21457;&#24067;&#35268;&#21017;',array('pub_free', array(
			array('1','&#26159;', array('pub_free_div' => '')),
			array('0','&#21542;', array('pub_free_div' => 'none')),
		), TRUE),$item['param']['pub_free'], 'mradio','','','&#27880;&#24847;&#65306;&#35774;&#32622;&#20102;&#21457;&#24067;&#20215;&#26684;&#21644;&#65;&#80;&#80;&#21457;&#24067;&#20215;&#26684;&#26377;&#25928;');
		showtagheader('div', 'pub_free_div', $item['param']['pub_free'] ? true : '','sub');
			showsetting('&#27599;&#26376;&#20813;&#36153;&#21457;&#24067;&#26465;&#25968;', 'pub_free_month_num',$item ? $item['param']['pub_free_month_num'] : 5, 'text');
			showsetting('&#27599;&#26085;&#38480;&#21046;&#20813;&#36153;&#26465;&#25968;', 'pub_free_day_limit',$item ? $item['param']['pub_free_day_limit'] : 1, 'text');
			showsetting('&#20813;&#36153;&#35268;&#21017;&#25552;&#31034;&#35821;', 'pub_free_tips',$item['param']['pub_free_tips'] ? $item['param']['pub_free_tips'] : '&#26412;&#26376;&#35813;&#20998;&#31867;&#24744;&#36824;&#21487;&#20197;&#20813;&#36153;&#21457;&#24067;<span class=text-red>{surplus_num}</span>&#26465;&#20449;&#24687;&#65292;&#20170;&#26085;&#35813;&#20998;&#31867;&#36824;&#21487;&#20197;&#21457;&#24067;<span class=text-red>{surplus_day_count}</span>&#26465;&#20449;&#24687;', 'textarea','','','&#123;&#115;&#117;&#114;&#112;&#108;&#117;&#115;&#95;&#110;&#117;&#109;&#125;&#20195;&#34920;&#26412;&#26376;&#21097;&#20313;&#22810;&#23569;&#26465;&#65292;&#123;&#115;&#117;&#114;&#112;&#108;&#117;&#115;&#95;&#100;&#97;&#121;&#95;&#99;&#111;&#117;&#110;&#116;&#125;&#20195;&#34920;&#20170;&#26085;&#21097;&#20313;&#22810;&#23569;&#26465;');
		showtagfooter('div');
			
		//�ö�
		echo <<<HTML
		<div class="border box-header margin-top-20"><h5 class="box-title">&#32622;&#39030;&#22871;&#39184;</h5><p class="margin-bottom-0" style="font-size:12px;">&#27880;&#24847;&#65306;&#105;&#100;&#19981;&#33021;&#37325;&#22797;</p></div>

		<script type="text/JavaScript">
		var toprowtypedata = [
			[	
				[1, '<input type="text" class="form-control w50" name="top[displayorder][]" value="">'],
				[1, '<input type="text" class="form-control w50" name="top[id][]" value="">'],
				[1, '<input type="text" class="form-control w50" name="top[day][]" value="">'],
				[1, '<input type="text" class="form-control w50" name="top[price][]" value="">'],
			[1, '<input type="text" class="form-control w200" name="top[title][]" value="">'],
				[1, '<input type="text" class="form-control w200" name="top[content][]" value="">'],
				[1, '<a href="#" onclick="deleterow(this)" class="btn btn-sm btn-danger-outline">&#21024;&#38500;</a>']
			],
		];
		</script>
HTML;
		showtableheader('','table table-bordered table-hover display nowrap table-responsive dataTable');
		showsubtitle(array(
			'&#26174;&#31034;&#39034;&#24207;',
			'ID',
			'&#32622;&#39030;&#22825;&#25968;',
			'&#20215;&#26684;',
			'&#32622;&#39030;&#26631;&#39064;',
			'&#32622;&#39030;&#35828;&#26126;',
			'&#21024;&#38500;'
		),'header tbm tc');
		$topListArr = $item['param']['topList'] ? $item['param']['topList'] : array(
			array('displayorder'=>'0','id'=>'1','day'=>'30','price'=>'150','title'=>'&#32622;&#39030;&#51;&#48;&#22825;','content'=>'&#32622;&#39030;&#51;&#48;&#22825;&#36865;&#26379;&#21451;&#22280;&#20844;&#20247;&#21495;&#32676;&#21457;'),
			array('displayorder'=>'1','id'=>'2','day'=>'15','price'=>'50','title'=>'&#32622;&#39030;&#49;&#53;&#22825;','content'=>'&#32622;&#39030;&#55;&#22825;&#36865;&#26379;&#21451;&#22280;'),
			array('displayorder'=>'2','id'=>'3','day'=>'3','price'=>'30','title'=>'&#32622;&#39030;&#55;&#22825;','content'=>'&#32622;&#39030;&#55;&#22825;')
		);
		foreach ($topListArr as $key => $val) {
			showtablerow('', array('class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
				'<input type="text" class="form-control w50" name="top[displayorder][]" value="'.$val['displayorder'].'">',
				'<input type="text" class="form-control w50" name="top[id][]" value="'.$val['id'].'">',
				'<input type="text" class="form-control w50" name="top[day][]" value="'.$val['day'].'">',
				'<input type="text" class="form-control w50" name="top[price][]" value="'.$val['price'].'">',
				'<input type="text" class="form-control w200" name="top[title][]" value="'.$val['title'].'">',
				'<input type="text" class="form-control w200" name="top[content][]" value="'.$val['content'].'">',
				'<a href="#" onclick="deleterow(this)" class="btn btn-sm btn-danger-outline">&#21024;&#38500;</a>',
			));
		}
		echo '<tr class="hover"><td class="tc margin-bottom-30" colspan="10"><a href="#" onclick="addrow(this,toprowtypedata, 0)"><i class="fa fa-plus" style="margin-right:5px"></i>&#28155;&#21152;</a></td></tr>';
		showtablefooter(); /*dism��taobao��com*/
		echo '<div class="margin-top-20"></div>';
		//�ö� END

		echo <<<HTML
		</div>
		<!-- �۸����� end  -->
HTML;
		echo <<<HTML
		<!-- �������  -->
		<div class="tab-pane" id="ad" role="tabpanel" aria-expanded="false">
HTML;
		
		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">&#35814;&#24773;&#39029;&#20030;&#25253;&#24213;&#37096;&#24191;&#21578;<br>&#24314;&#35758;&#65306;&#54;&#52;&#48;&#32;&#42;&#32;&#57;&#48;</label><div class="col-sm-9"><div class="UploadBanner"><div class="PhotoControl ClickPhotoControl" id="view_report_bottom_ad"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';

		echo <<<HTML
		</div>
		<!-- ������� end  -->
HTML;
		echo <<<HTML
		<!-- ��������  -->
		<div class="tab-pane" id="share" role="tabpanel" aria-expanded="false">
HTML;
		
		showsetting('&#21015;&#34920;&#20998;&#20139;&#26631;&#39064;', 'share_title', $item['share_title'], 'text');

		showsetting('&#21015;&#34920;&#20998;&#20139;&#25551;&#36848;', 'share_desc', $item['share_desc'], 'text');

		$share_icon = $item['share_icon'] ? $item['share_icon'] : '/source/plugin/fn_fenlei/static/images/share_logo.png';
		$share_icon_html = '<a href="'.$share_icon.'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$share_icon.'" height="30"/></a>&#24314;&#35758;&#65306;&#50;&#48;&#48;&#32;&#42;&#32;&#50;&#48;&#48;';
		showsetting('&#21015;&#34920;&#20998;&#20139;&#22270;&#26631;', 'new_share_icon',$share_icon, 'filetext', '', 0, $share_icon_html);

		showsetting('&#35814;&#24773;&#26631;&#39064;', 'info_title', $item['info_title'] ? $item['info_title'] : '[--content--]', 'text','','','&#91;&#45;&#45;&#114;&#111;&#108;&#101;&#45;&#45;&#93;&#20195;&#34920;&#35282;&#33394;&#65292;&#91;&#45;&#45;&#99;&#108;&#97;&#115;&#115;&#95;&#110;&#97;&#109;&#101;&#45;&#45;&#93;&#20195;&#34920;&#20998;&#31867;&#21517;&#31216;&#65292;&#91;&#45;&#45;&#99;&#111;&#110;&#116;&#101;&#110;&#116;&#45;&#45;&#93;&#20195;&#34920;&#20869;&#23481;&#65292;&#91;&#45;&#45;&#114;&#101;&#103;&#105;&#111;&#110;&#95;&#110;&#97;&#109;&#101;&#45;&#45;&#93;&#20195;&#34920;&#21306;&#22495;&#21517;&#31216;&#65292;&#91;&#45;&#45;&#34920;&#21333;&#21464;&#37327;&#21517;&#45;&#45;&#93;');

		showsetting('&#35814;&#24773;&#20998;&#20139;&#26631;&#39064;', 'info_share_title', $item['info_share_title'] ? $item['info_share_title'] : '[--content--]', 'text','','','&#91;&#45;&#45;&#114;&#111;&#108;&#101;&#45;&#45;&#93;&#20195;&#34920;&#35282;&#33394;&#65292;&#91;&#45;&#45;&#99;&#108;&#97;&#115;&#115;&#95;&#110;&#97;&#109;&#101;&#45;&#45;&#93;&#20195;&#34920;&#20998;&#31867;&#21517;&#31216;&#65292;&#91;&#45;&#45;&#99;&#111;&#110;&#116;&#101;&#110;&#116;&#45;&#45;&#93;&#20195;&#34920;&#20869;&#23481;&#65292;&#91;&#45;&#45;&#114;&#101;&#103;&#105;&#111;&#110;&#95;&#110;&#97;&#109;&#101;&#45;&#45;&#93;&#20195;&#34920;&#21306;&#22495;&#21517;&#31216;&#65292;&#91;&#45;&#45;&#34920;&#21333;&#21464;&#37327;&#21517;&#45;&#45;&#93;');

		showsetting('&#35814;&#24773;&#20998;&#20139;&#25551;&#36848;', 'info_share_desc', $item['info_share_desc'] ? $item['info_share_desc'] : '[--content--]', 'text','','','&#91;&#45;&#45;&#114;&#111;&#108;&#101;&#45;&#45;&#93;&#20195;&#34920;&#35282;&#33394;&#65292;&#91;&#45;&#45;&#99;&#108;&#97;&#115;&#115;&#95;&#110;&#97;&#109;&#101;&#45;&#45;&#93;&#20195;&#34920;&#20998;&#31867;&#21517;&#31216;&#65292;&#91;&#45;&#45;&#99;&#111;&#110;&#116;&#101;&#110;&#116;&#45;&#45;&#93;&#20195;&#34920;&#20869;&#23481;&#65292;&#91;&#45;&#45;&#114;&#101;&#103;&#105;&#111;&#110;&#95;&#110;&#97;&#109;&#101;&#45;&#45;&#93;&#20195;&#34920;&#21306;&#22495;&#21517;&#31216;&#65292;&#91;&#45;&#45;&#34920;&#21333;&#21464;&#37327;&#21517;&#45;&#45;&#93;');
		
		showsetting('&#20449;&#24687;&#22797;&#21046;&#27169;&#26495;', 'info_copy_temp', $item['info_copy_temp'] ? $item['info_copy_temp'] : '&#12304;[--class_name--]&#12305;
[--content--]
&#32852;&#31995;&#20154;&#65306;[--name--]
&#28857;&#20987;&#26597;&#35810;&#32852;&#31995;&#26041;&#24335;&#65306;[--url--]
-&#25340;&#36710;&#65292;&#20108;&#25163;&#36710;&#65292;&#23547;&#20154;&#65292;&#22833;&#29289;&#35748;&#39046;&#23601;&#19978;&#39134;&#40479;&#20998;&#31867;&#20449;&#24687;&#32593;-','textarea','','','&#91;&#45;&#45;&#117;&#112;&#100;&#97;&#116;&#101;&#108;&#105;&#110;&#101;&#45;&#45;&#93;&#20195;&#34920;&#21047;&#26032;&#26102;&#38388;&#65292;&#91;&#45;&#45;&#100;&#97;&#116;&#101;&#108;&#105;&#110;&#101;&#45;&#45;&#93;&#20195;&#34920;&#21457;&#24067;&#26102;&#38388;&#65292;&#91;&#45;&#45;&#117;&#115;&#101;&#114;&#110;&#97;&#109;&#101;&#45;&#45;&#93;&#20195;&#34920;&#29992;&#25143;&#21517;&#65292;&#91;&#45;&#45;&#110;&#97;&#109;&#101;&#45;&#45;&#93;&#20195;&#34920;&#32852;&#31995;&#20154;&#65292;&#91;&#45;&#45;&#112;&#104;&#111;&#110;&#101;&#45;&#45;&#93;&#20195;&#34920;&#32852;&#31995;&#30005;&#35805;&#65292;&#91;&#45;&#45;&#114;&#111;&#108;&#101;&#45;&#45;&#93;&#20195;&#34920;&#35282;&#33394;&#65292;&#91;&#45;&#45;&#99;&#108;&#97;&#115;&#115;&#95;&#110;&#97;&#109;&#101;&#45;&#45;&#93;&#20195;&#34920;&#20998;&#31867;&#21517;&#31216;&#65292;&#91;&#45;&#45;&#99;&#111;&#110;&#116;&#101;&#110;&#116;&#45;&#45;&#93;&#20195;&#34920;&#20869;&#23481;&#65292;&#91;&#45;&#45;&#114;&#101;&#103;&#105;&#111;&#110;&#95;&#110;&#97;&#109;&#101;&#45;&#45;&#93;&#20195;&#34920;&#21306;&#22495;&#21517;&#31216;&#65292;&#91;&#45;&#45;&#117;&#114;&#108;&#45;&#45;&#93;&#20195;&#34920;&#38142;&#25509;&#65292;&#91;&#45;&#45;&#34920;&#21333;&#21464;&#37327;&#21517;&#45;&#45;&#93;');


		showsetting('&#20449;&#24687;&#23548;&#20986;&#27169;&#26495;', 'info_wx_temp', $item['info_wx_temp'] ? stripslashes($item['info_wx_temp']) : '<section><section style="margin-bottom: -1em;">
            <section style="width: 100%;text-align: left;" data-width="100%">
                <section style="display: inline-block;box-shadow: #9fbfdb 4px 4px 0px;border-radius:6px ;">
                    <section data-bgless="spin" data-bglessp="180" style="color:#fff;background: #006785;border-radius:6px ;padding: 4px;">
                        <section style="border-radius:6px;border: 1px dashed #fff;">
                            <section class="135brush" data-brushtype="text" style="font-size:17px;font-weight: bold; text-align: center;letter-spacing:1.5px;padding:0em 0.6em;">
                                [--class_name--]
                            </section>
                        </section>
                    </section>
                </section>
            </section>
        </section>
        <section data-bdless="spin" data-bdlessp="220" data-bdopacity="50%" style="width: 100%;border: 1px dashed #9fbfdb;border-radius:6px ;" data-width="100%">
            <section style="padding:4px;">
                <section data-bgless="spin" data-bglessp="280" data-bgopacity="50%" style="background:#cdeaff;color:#2f2f2f;border-radius:6px ;">
                    <section class="135brush" style="padding: 2em 1em 1em; letter-spacing: 1.5px; text-align: justify;">
                        <p style="font-size: 14px;">[--content--]</p>
                        <p style="font-size: 14px;"><strong>&#32852;&#31995;&#20154;</strong>[--name--]</p>
                        <p style="font-size: 14px;"><strong>&#32852;&#31995;&#30005;&#35805;</strong>[--phone--]</p>
                        <p><span style="font-size: 14px;">&#12304;&#25552;&#37266;&#12305;<span style="color: #2f2f2f; font-size: 10px; letter-spacing: 1.5px; text-align: justify; background-color: #cdeaff; text-decoration-line: underline;">&#38271;&#25353;&#20108;&#32500;&#30721;&#35782;&#21035;&#26597;&#30475;</span></span></p>
                        <p>[--qr--]</p>
                    </section>
                </section>
            </section>
        </section>
    </section>', 'textarea','','','&#91;&#45;&#45;&#105;&#110;&#100;&#101;&#120;&#45;&#45;&#93;&#20195;&#34920;&#32534;&#21495;&#65292;&#91;&#45;&#45;&#117;&#112;&#100;&#97;&#116;&#101;&#108;&#105;&#110;&#101;&#45;&#45;&#93;&#20195;&#34920;&#21047;&#26032;&#26102;&#38388;&#65292;&#91;&#45;&#45;&#100;&#97;&#116;&#101;&#108;&#105;&#110;&#101;&#45;&#45;&#93;&#20195;&#34920;&#21457;&#24067;&#26102;&#38388;&#65292;&#91;&#45;&#45;&#117;&#115;&#101;&#114;&#110;&#97;&#109;&#101;&#45;&#45;&#93;&#20195;&#34920;&#29992;&#25143;&#21517;&#65292;&#91;&#45;&#45;&#110;&#97;&#109;&#101;&#45;&#45;&#93;&#20195;&#34920;&#32852;&#31995;&#20154;&#65292;&#91;&#45;&#45;&#112;&#104;&#111;&#110;&#101;&#45;&#45;&#93;&#20195;&#34920;&#32852;&#31995;&#30005;&#35805;&#65292;&#91;&#45;&#45;&#114;&#111;&#108;&#101;&#45;&#45;&#93;&#20195;&#34920;&#35282;&#33394;&#65292;&#91;&#45;&#45;&#99;&#108;&#97;&#115;&#115;&#95;&#110;&#97;&#109;&#101;&#45;&#45;&#93;&#20195;&#34920;&#20998;&#31867;&#21517;&#31216;&#65292;&#91;&#45;&#45;&#99;&#111;&#110;&#116;&#101;&#110;&#116;&#45;&#45;&#93;&#20195;&#34920;&#20869;&#23481;&#65292;&#91;&#45;&#45;&#114;&#101;&#103;&#105;&#111;&#110;&#95;&#110;&#97;&#109;&#101;&#45;&#45;&#93;&#20195;&#34920;&#21306;&#22495;&#21517;&#31216;&#65292;&#91;&#45;&#45;&#116;&#104;&#117;&#109;&#98;&#45;&#45;&#93;&#20195;&#34920;&#32553;&#30053;&#22270;&#65292;&#91;&#45;&#45;&#113;&#114;&#45;&#45;&#93;&#20195;&#34920;&#20108;&#32500;&#30721;&#65292;&#91;&#45;&#45;&#34920;&#21333;&#21464;&#37327;&#21517;&#45;&#45;&#93;');

		echo <<<HTML
		</div>
		<!-- �������� end  -->
HTML;
		showsubmit('DetailSubmit','&#20445;&#23384;&#37197;&#32622;');
		showtagfooter('div');
		showtagheader('div', 'tab-content', true,'tab-content');
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');

		if($item['param']['view_report_bottom_ad']){
			foreach($item['param']['view_report_bottom_ad'] as $key => $val) {
				$view_report_bottom_ad_js_array[] = '"'.$val['img'].'|'.$item['param']['view_report_bottom_ad'][$key]['title'].'|'.$item['param']['view_report_bottom_ad'][$key]['link'].'"';
			}
			$UpLoadHtml .= '
			var InputArray = new Array('.implode(',',$view_report_bottom_ad_js_array).');
			$("#view_report_bottom_ad").AppUpload({InputName:"new_view_report_bottom_ad",InputLink:true,InputExist:true,InputArray:InputArray,Move:true});';
		}else{
			$UpLoadHtml .= '$("#view_report_bottom_ad").AppUpload({InputName:"new_view_report_bottom_ad",InputLink:true,Move:true});';
		}

		echo $UploadConfig['CssJsHtml'];
		echo '<script>'.$UpLoadHtml.'</script>';

	}else{
		$data['bclassid'] = intval($_GET['bclassid']);
		$data['name'] = $data['bname'] = addslashes(strip_tags($_GET['name']));
		$data['nav'] = intval($_GET['nav']);
		$data['share_title'] = addslashes(strip_tags($_GET['share_title']));
		$data['share_desc'] = addslashes(strip_tags($_GET['share_desc']));
		$data['info_end_day'] = intval($_GET['info_end_day']);
		$data['info_like'] = intval($_GET['info_like']);
		$data['info_login'] = intval($_GET['info_login']);
		$data['info_contact'] = intval($_GET['info_contact']);
		$data['info_statement'] = addslashes($_GET['info_statement']);
		$data['pub_price'] = addslashes(strip_tags($_GET['pub_price']));
		$data['info_title'] = addslashes(strip_tags($_GET['info_title']));
		$data['info_share_title'] = addslashes(strip_tags($_GET['info_share_title']));
		$data['info_share_desc'] = addslashes(strip_tags($_GET['info_share_desc']));
		$data['info_wx_temp'] = addslashes($_GET['info_wx_temp']);
		$data['info_copy_temp'] = addslashes(strip_tags($_GET['info_copy_temp']));
		
		$data['app_pub_price'] = addslashes(strip_tags($_GET['app_pub_price']));
		$data['refresh_price'] = addslashes(strip_tags($_GET['refresh_price']));
		$data['list_temp_id'] = intval($_GET['list_temp_id']);
		$data['info_temp_id'] = addslashes(strip_tags($_GET['info_temp_id']));
		$data['jump'] = intval($_GET['jump']);
		$data['jump_url'] = addslashes(strip_tags($_GET['jump_url']));
		$data['display'] = intval($_GET['display']);
		$data['displayorder'] = intval($_GET['displayorder']);
		$data['level'] = $data['bclassid'] ? $allClass[$data['bclassid']]['level'] + 1 : '';
		$data = array_merge($data,$Fn_Admin->uploadFiles($_FILES));
		
		$param['info_phone_count'] = intval($_GET['info_phone_count']);
		$param['info_click_rand'] = addslashes(strip_tags($_GET['info_click_rand']));
		$param['pub_audit'] = intval($_GET['pub_audit']);
		$param['pub_edit_audit'] = intval($_GET['pub_edit_audit']);
		$param['pub_top'] = intval($_GET['pub_top']);
		$param['pub_title'] = intval($_GET['pub_title']);
		$param['pub_title_fill'] = intval($_GET['pub_title_fill']);
		$param['pub_content'] = intval($_GET['pub_content']);
		$param['pub_content_fill'] = intval($_GET['pub_content_fill']);
		$param['pub_album'] = intval($_GET['pub_album']);
		$param['pub_album_fill'] = intval($_GET['pub_album_fill']);
		$param['pub_name'] = intval($_GET['pub_name']);
		$param['pub_region'] = intval($_GET['pub_region']);
		$param['pub_region_fill'] = intval($_GET['pub_region_fill']);
		$param['pub_address'] = intval($_GET['pub_address']);
		$param['pub_address_fill'] = intval($_GET['pub_address_fill']);
		$param['pub_location'] = intval($_GET['pub_location']);
		$param['pub_location_auto'] = intval($_GET['pub_location_auto']);
		$param['pub_role'] = intval($_GET['pub_role']);
		$param['pub_role_title'] = addslashes(strip_tags($_GET['pub_role_title']));
		$param['pub_role_arr'] = addslashes(strip_tags($_GET['pub_role_arr']));
		$param['info_role_arr'] = $param['pub_role_arr'] ? TextareaArray($param['pub_role_arr']) : '';
		$param['pub_role_tips'] = addslashes($_GET['pub_role_tips']);
		$param['pub_role_err'] = addslashes(strip_tags($_GET['pub_role_err']));
		$param['info_bottom_collection'] = intval($_GET['info_bottom_collection']);
		$param['info_bottom_pub'] = intval($_GET['info_bottom_pub']);
		$param['info_bottom_share'] = intval($_GET['info_bottom_share']);
		$param['info_bottom_share_title'] = addslashes(strip_tags($_GET['info_bottom_share_title']));
		$param['info_bottom_share_tips_text'] = addslashes($_GET['info_bottom_share_tips_text']);
		$param['info_bottom_share_tips'] = intval($_GET['info_bottom_share_tips']);
		$param['info_bottom_main_share'] = intval($_GET['info_bottom_main_share']);
		$param['info_bottom_main_share_btn'] = addslashes(strip_tags($_GET['info_bottom_main_share_btn']));
		$param['info_bottom_tel_btn'] = addslashes(strip_tags($_GET['info_bottom_tel_btn']));
		$param['info_chat'] = intval($_GET['info_chat']);
		$param['info_chat_tips'] = addslashes(strip_tags($_GET['info_chat_tips']));
		$param['pub_free'] = intval($_GET['pub_free']);
		$param['pub_free_month_num'] = intval($_GET['pub_free_month_num']);
		$param['pub_free_day_limit'] = intval($_GET['pub_free_day_limit']);
		$param['pub_free_tips'] = addslashes($_GET['pub_free_tips']);
		$param['pub_tag'] = intval($_GET['pub_tag']);
		$param['pub_tag_fill'] = intval($_GET['pub_tag_fill']);
		$param['pub_tag_count'] = intval($_GET['pub_tag_count']);
		$param['pub_tag_arr'] = addslashes(strip_tags($_GET['pub_tag_arr']));
		$param['info_tag_arr'] = $param['pub_tag_arr'] ? TextareaArray($param['pub_tag_arr']) : '';

		$param['pub_price_tips'] = addslashes($_GET['pub_price_tips']);
		$param['pub_price_tips_text'] = str_replace(array('{price}','{br}'),array(($data['pub_price'] ? $data['pub_price'].$fn_fenlei->setting['lang']['yuan'] : $fn_fenlei->setting['lang']['mianfei']),'<br>'),$param['pub_price_tips']);
		$param['app_pub_price_tips'] = addslashes($_GET['app_pub_price_tips']);
		$param['app_pub_price_tips_text'] = str_replace(array('{price}','{br}'),array(($data['app_pub_price'] ? $data['app_pub_price'].$fn_fenlei->setting['lang']['yuan'] : $fn_fenlei->setting['lang']['mianfei']),'<br>'),$param['pub_price_tips']);
		$param['wrong_app_pub_price_tips_text'] = str_replace(array('{price}','{br}','{appprice}','{down}'),array('<span class="FFFFFColor">'.$data['pub_price'].$fn_fenlei->setting['lang']['yuan'].'</span>','<br>',($data['app_pub_price'] ? $data['app_pub_price'].$fn_fenlei->setting['lang']['yuan'] : $fn_fenlei->setting['lang']['mianfei']),'<a href="'.$Config['PluginVar']['AppLink'].'" class=text-red>'.$fn_fenlei->setting['lang']['down'].'</a>'),$param['app_pub_price_tips']);

		foreach($_GET['upload_admin'] as $key => $value){
			if(strpos($key,'new_') !== false){
				$key_name = str_replace(array('new_'),'',$key);
				$param[$key_name] = array();
				foreach($_GET[$key] as $k => $v) {
					$param[$key_name][$k]['img'] = strpos($v,'http') !== false ? $v : $_G['siteurl'].$v;
					$param[$key_name][$k]['link'] = $_GET[$key.'_link'][$k];
					$param[$key_name][$k]['title'] = $_GET[$key.'_title'][$k];
				}
			}
		}

		//�ö�
		foreach($_GET['top'] as $key => $val){
			foreach($_GET['top']['displayorder'] as $k => $v){
				$topList[$k][$key] = addslashes($_GET['top'][$key][$k]);
			}
		}
		foreach(array_sort($topList,'displayorder') as $group){
			$newTopList[$group['id']] = $group; 
		}
		$param['topList'] = $newTopList;
		//�ö� END

		$data['param'] = serialize($param);
		if($item && !$_GET['copy']){
			GetInsertDoLog('edit_fenlei_list','fn_'.$_GET['mod'],array('id'=>$id));//������¼
			C::t('#fn_fenlei#fn_fenlei_class')->update($data,$id);
		}else{
			$data['dateline'] = time();
			$id = C::t('#fn_fenlei#fn_fenlei_class')->insert($data);;
			GetInsertDoLog('add_fenlei_list','fn_'.$_GET['mod'],array('id'=>$id));//������¼
		}
		checkClass();
		fn_cpmsg($fn_fenlei->setting['lang']['UpdateOk'],$Fn_Admin->Config['IframeItemUrl'].'&submodel=list','succeed');
		exit();
	}
}
function showClassRow($key, $Level = 0, $Last = ''){
	global $allClass,$Fn_Admin,$fn_fenlei;
	$item = $allClass[$key];
	$OpInfoCpUrl = ADMINSCRIPT.'?'.'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod=AdminInfo';
	$OpClassCpUrl = ADMINSCRIPT.'?'.rawurldecode(cpurl());
	if($Level == 2) {
		$Class = $Last ? 'lastchildboard' : 'childboard';
		$Return = '<tr class="hover" id="'.$item['classid'].'"><td class="w50">&nbsp;</td><td class="w50">'.$item['classid'].'</td><td class="w80"><input type="text" class="form-control w80" name="neworder['.$item['classid'].']" value="'.$item['displayorder'].'" /></td><td><div class="'.$Class.'">'.
		'<input type="text" class="form-control w200" name="name['.$item['classid'].']" value="'.$item['name'].'" />'.
		'</div>'.
		'</td><td>'.($item['ico'] ? '<img src="'.$item['ico'].'" style="hegiht:30px;width:30px;">' : '').'</td>'.
		'<td>'.$item['info_count'].'</td><td>'.(!empty($item['nav']) ? '<span class="text-danger">'.cplang('yes').'</span>' : cplang('no')).'</td><td>'.(!empty($item['display']) ? cplang('yes') : cplang('no')).'</td>'.
		'<td><a href="'.$fn_fenlei->getUrl('list',array('classid'=>$item['classid'])).'" target="_blank" class="btn btn-sm btn-dark-outline">'.cplang('view').'</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&classid='.$item['classid'].'" class="btn btn-sm btn-info-outline">'.$Fn_Admin->Config['LangVar']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&classid='.$item['classid'].'&copy=1" class="btn btn-sm btn-info-outline">&#22797;&#21046;</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&do=Display&classid='.$item['classid'].'&value='.(!empty($item['display']) ? 0:1).'&formhash='.FORMHASH.'" class="btn btn-sm btn-success-outline">'.(!empty($item['display']) ? $Fn_Admin->Config['LangVar']['DisplayNoTitle'] : $Fn_Admin->Config['LangVar']['DisplayIsTitle']).'</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeModUrl'].'&item=info_list&submodel=list&classid='.$item['classid'].'" class="btn btn-sm btn-primary-outline">&#31649;&#29702;&#20449;&#24687;</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&do=Form&classid='.$item['classid'].'" class="btn btn-sm btn-info-outline">&#33258;&#23450;&#20041;&#34920;&#21333;</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=list&do=Del&classid='.$item['classid'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$Fn_Admin->Config['LangVar']['DelTitle'].'</a></td></tr>';
	}else if($Level == 1) {
		$Return = '<tr class="hover" id="'.$item['classid'].'"><td class="w50">&nbsp;</td><td class="w50">'.$item['classid'].'</td><td class="w80"><input type="text" class="form-control w80" name="neworder['.$item['classid'].']" value="'.$item['displayorder'].'" /></td><td><div class="board">'.
		'<input type="text" class="form-control w200" name="name['.$item['classid'].']" value="'.$item['name'].'" /></div>'.
		'</td><td>'.($item['ico'] ? '<img src="'.$item['ico'].'" style="hegiht:30px;width:30px;">' : '').'</td>'.
		'<td>'.$item['info_count'].'</td><td>'.(!empty($item['nav']) ? '<span class="text-danger">'.cplang('yes').'</span>' : cplang('no')).'</td><td>'.(!empty($item['display']) ? cplang('yes') : cplang('no')).'</td>'.
		'<td><a href="'.$fn_fenlei->getUrl('list',array('classid'=>$item['classid'])).'" target="_blank" class="btn btn-sm btn-dark-outline">'.cplang('view').'</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&classid='.$item['classid'].'" class="btn btn-sm btn-info-outline">'.$Fn_Admin->Config['LangVar']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&classid='.$item['classid'].'&copy=1" class="btn btn-sm btn-info-outline">&#22797;&#21046;</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&do=Display&classid='.$item['classid'].'&value='.(!empty($item['display']) ? 0:1).'&formhash='.FORMHASH.'" class="btn btn-sm btn-success-outline">'.(!empty($item['display']) ? $Fn_Admin->Config['LangVar']['DisplayNoTitle'] : $Fn_Admin->Config['LangVar']['DisplayIsTitle']).'</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeModUrl'].'&item=info_list&submodel=list&classid='.$item['classid'].'" class="btn btn-sm btn-primary-outline">&#31649;&#29702;&#20449;&#24687;</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&do=Form&classid='.$item['classid'].'" class="btn btn-sm btn-info-outline">&#33258;&#23450;&#20041;&#34920;&#21333;</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=list&do=Del&classid='.$item['classid'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$Fn_Admin->Config['LangVar']['DelTitle'].'</a></td></tr>';
		for($i=0,$L=count($item['children']); $i<$L; $i++) {
			$Return .= ShowClassRow($item['children'][$i], 2, $i==$L-1);
		}
	}else{
		$Childrennum = count(implode(',',$allClass[$Key]['children']));
		$Toggle = $Childrennum > 25 ? ' style="display:none"' : '';
		$Return = '<tbody><tr class="hover" id="'.$item['classid'].'"><td class="w50" onclick="toggle_group(\'group_'.$item['classid'].'\')"><a id="a_group_'.$item['classid'].'" href="javascript:;">'.($Toggle ? '[+]' : '[-]').'</a></td>'.
		'<td class="w50">'.$item['classid'].'</td>'
		.'<td class="w80"><input type="text" class="form-control w80" name="neworder['.$item['classid'].']" Value="'.$item['displayorder'].'" /></td><td><div class="parentboard">'.
		'<input type="text" class="form-control w200" name="name['.$item['classid'].']" Value="'.$item['name'].'" />'.
		'</div>'.
		'</td><td>'.($item['ico'] ? '<img src="'.$item['ico'].'" style="hegiht:30px;width:30px;">' : '').'</td>'.
		'<td>'.$item['info_count'].'</td><td>'.(!empty($item['nav']) ? '<span class="text-danger">'.cplang('yes').'</span>' : cplang('no')).'</td><td>'.(!empty($item['display']) ? cplang('yes') : cplang('no')).'</td>'.
		'<td><a href="'.$fn_fenlei->getUrl('list',array('classid'=>$item['classid'])).'" target="_blank" class="btn btn-sm btn-dark-outline">'.cplang('view').'</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&classid='.$item['classid'].'" class="btn btn-sm btn-info-outline">'.$Fn_Admin->Config['LangVar']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&classid='.$item['classid'].'&copy=1" class="btn btn-sm btn-info-outline">&#22797;&#21046;</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&do=Display&classid='.$item['classid'].'&value='.(!empty($item['display']) ? 0:1).'&formhash='.FORMHASH.'" class="btn btn-sm btn-success-outline">'.(!empty($item['display']) ? $Fn_Admin->Config['LangVar']['DisplayNoTitle'] : $Fn_Admin->Config['LangVar']['DisplayIsTitle']).'</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeModUrl'].'&item=info_list&submodel=list&classid='.$item['classid'].'" class="btn btn-sm btn-primary-outline">&#31649;&#29702;&#20449;&#24687;</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&do=Form&classid='.$item['classid'].'" class="btn btn-sm btn-info-outline">&#33258;&#23450;&#20041;&#34920;&#21333;</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=list&do=Del&classid='.$item['classid'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$Fn_Admin->Config['LangVar']['DelTitle'].'</a></td></tr></tbody>
		<tbody id="group_'.$item['classid'].'"'.$Toggle.'>';
		for($i=0,$L=count($item['children']); $i<$L; $i++) {
			$Return .= ShowClassRow($item['children'][$i], 1, '');
		}
		$Return .= '</tdoby><tr><td>&nbsp;</td><td colspan="10"><div class="lastboard"><a class="addtr" href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&bclassid='.$item['classid'].'">&#28155;&#21152;&#20998;&#31867;</a></td></div>';
	}
	return $Return;
}

function checkForm(){
	global $allClass;
	$check = array();
	foreach($allClass as $val){
		$check[$val['classid']] = C::t('#fn_fenlei#fn_form')->fetch_all_by_classid('fenlei_info',$val['classid'],1);
	}
	savecache('fn_form_fenlei_info',$check);
}

function checkClass(){
	global $fn_fenlei;
	$check = array();
	foreach(C::t('#fn_fenlei#fn_fenlei_class')->fetch_all_by_list() as $val){
		$val['formsearch'] = 0;
		foreach($val['forms'] as $k => $v){
			if($v['formsearch'] && $v['type'] != 'text'){
				$val['formsearch'] = 1;
				if($v['range']){
					$val['forms'][$k]['d'] = $v['identifier'].'_d';
					$val['forms'][$k]['u'] = $v['identifier'].'_u';
				}
			}
		}
		$check[$val['classid']] = $val;
		$check[$val['classid']]['sonid'] = C::t('#fn_fenlei#fn_fenlei_class')->all_list_classid($val['classid'],array('display'=>1));
		$check[$val['classid']]['url'] = $val['jump'] && $val['jump_url'] ? $val['jump_url'] : $fn_fenlei->getUrl('list',array('classid'=>$val['classid']));
	}
	savecache('fn_fenlei_class',$check);
}
//From: Dism_taobao_com
?>