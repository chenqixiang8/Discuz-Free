<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('fenlei_all') && !$Fn_Admin->CheckUserGroup('fenlei_info_action_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$Do = in_array($_GET['do'], array('Del')) ? $_GET['do'] : 'List';

//�����ֶ�
$SearField =array('page','keyword','action','source','pages','channel','iid','order');
foreach($SearField as $Val) {
	$SearArray[$Val] = $_GET[$Val] ? $_GET[$Val] : '';
}
//�����ֶ� End

$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeItemUrl'].'&'.http_build_query($SearArray);

if($Do == 'List'){
	if(!submitcheck('Submit')) {
		$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
		$page = $_GET['page'] ? $_GET['page'] : 0;
		$res = C::t('#fn_fenlei#fn_fenlei_info_action')->fetch_all_by_list(array('keyword'=>$_GET['keyword'],'action'=>$_GET['action'],'iid'=>$_GET['iid'],'channel'=>$_GET['channel'],'pages'=>$_GET['pages'],'source'=>$_GET['source']),'dateline',$page - 1,30,true);
		/* ģ����� */
		showtagheader('div', 'row', true,'row');
		showtagheader('div', 'col-12', true,'col-12');
		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-body', true,'box-body');
		/* ���� */
		$info_source_list_option = '<option value="">'.$fn_fenlei->setting['lang']['SelectNull'].'</option>';
		foreach($fn_fenlei->setting['lang']['info_source_arr'] as $key => $val) {
			$info_source_list_option .= '<option value="'. $key.'" '.($_GET['source'] ==  $key ? ' selected' : '' ).'>'.$val.'</option>';
		}
		$info_action_list_option = '<option value="">'.$fn_fenlei->setting['lang']['SelectNull'].'</option>';
		foreach($fn_fenlei->setting['lang']['info_action_arr'] as $key => $val) {
			$info_action_list_option .= '<option value="'. $key.'" '.($_GET['action'] ==  $key ? ' selected' : '' ).'>'.$val.'</option>';
		}
		$info_pages_list_option = '<option value="">'.$fn_fenlei->setting['lang']['SelectNull'].'</option>';
		foreach($fn_fenlei->setting['lang']['info_pages_arr'] as $key => $val) {
			$info_pages_list_option .= '<option value="'. $key.'" '.($_GET['pages'] ==  $key ? ' selected' : '' ).'>'.$val.'</option>';
		}
		echo <<<SEARCH
		<form method="post" autocomplete="off" action="$SearUrl" id="tb_search">
			<div class="FormSearchTo">
				<table cellspacing="4" cellpadding="4">
					<tr>
						<th>&#20851;&#38190;&#35789;</th><td colspan="10"><input type="text" class="input form-control w300" name="keyword" value="{$_GET['keyword']}" placeholder="&#35831;&#36755;&#20837;&#117;&#105;&#100;&#47;&#29992;&#25143;&#21517;&#47;&#105;&#112;">
						</td>
						<th>&#20449;&#24687;&#73;&#68;</th><td><input type="text" class="input form-control w100" name="iid" value="{$_GET['iid']}">
						</td>
						<th>&#28192;&#36947;</th><td><input type="text" class="input form-control w100" name="channel" value="{$_GET['channel']}">
						</td>
						<th>&#26469;&#28304;&#31471;&#21475;</th><td>
						<select name="source" class="form-control w120">
							{$info_source_list_option}
						</select>
						</td>
						<th>&#26469;&#28304;&#39029;&#38754;</th><td>
						<select name="pages" class="form-control w120">
							{$info_pages_list_option}
						</select>
						</td>
						<th>&#21160;&#20316;&#31867;&#22411;</th><td>
						<select name="action" class="form-control w120">
							{$info_action_list_option}
						</select>
						&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Admin->Config['LangVar']['SearchSubmit']}" class="btn btn-info" type="submit">
						</td>
					</tr>
				</table>
			</div>
		</form>
SEARCH;
		/* ���� End */
		showtagheader('div', 'table-responsive', true,'table-responsive');
		showformheader($FormUrl,'enctype="multipart/form-data"');
		showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
		showsubtitle(array(
			'ID',
			'UID/'.$fn_fenlei->setting['lang']['UserNameTitle'],
			'IP',
			'&#20449;&#24687;',
			'&#26469;&#28304;&#31471;&#21475;',
			'&#26469;&#28304;&#39029;&#38754;',
			'&#21160;&#20316;&#31867;&#22411;',
			'&#28192;&#36947;',
			$fn_fenlei->setting['lang']['TimeTitle'],
			$fn_fenlei->setting['lang']['OperationTitle']
		), 'header tbm tc');
	
		foreach ($res['list'] as $item) {
			$item['content'] = $item['content'] ? $item['content'] : ($item['title'] ? $item['title'] : $item['phone']);
			showtablerow('', array('class="tc w100"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
				'<input type="checkbox" class="filled-in" id="checkbox_'.$item['id'].'" name="delete[]" value="'.$item['id'].'"><label for="checkbox_'.$item['id'].'">'.$item['id'].'</label>',
				$item['uid'] ? $item['uid'].'/'.$item['username'] : '',
				$item['ip'],
				$item['content'] ? '<a href="'.$fn_fenlei->getUrl('view',array('iid'=>$item['iid'])).'" target="_blank">'.cutstr($item['content'],60).'</a>' : '',
				$fn_fenlei->setting['lang']['info_source_arr'][$item['source']],
				$fn_fenlei->setting['lang']['info_pages_arr'][$item['pages']],
				$fn_fenlei->setting['lang']['info_action_arr'][$item['action']],
				$item['channel'],
				date('Y-m-d H:i',$item['dateline']),
				'<a href="'.$OpCpUrl.'&do=Del&aid='.$item['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$fn_fenlei->setting['lang']['DelTitle'].'</a>',
			));
		}
		showsubmit('Submit','&#31435;&#21363;&#25552;&#20132;','del','','',multi($res['count'],30,$page,$MpUrl));
		showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		/* ģ����� End */
	}else{
		if(isset($_GET['delete']) && is_array($_GET['delete'])){
			if(!$Fn_Admin->CheckUserGroup('fenlei_all') && !$Fn_Admin->CheckUserGroup('fenlei_del_info_action_list')){//Ȩ���ж�
				fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
				exit();
			}
			foreach($_GET['delete'] as $val) {
				$id = intval($val);
				$item = C::t('#fn_fenlei#fn_fenlei_info_action')->fetch_by_id($id);
				C::t('#fn_fenlei#fn_fenlei_info_action')->delete_by_id($id);
				C::t('#fn_fenlei#fn_fenlei_info')->update_by_count($item['iid'],$fn_fenlei->setting['lang']['info_action_field_arr'][$item['action']],1,'-');
			}

			GetInsertDoLog('del_info_action_list_fenlei','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete'])));//������¼

			fn_cpmsg($fn_fenlei->setting['lang']['DelOk'],$CpMsgUrl,'succeed');
		}else{
			fn_cpmsg($fn_fenlei->setting['lang']['DelErr'],'','error');
		}
	}
}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['aid']){//ɾ��
	if(!$Fn_Admin->CheckUserGroup('fenlei_all') && !$Fn_Admin->CheckUserGroup('fenlei_del_info_action_list')){//Ȩ���ж�
		fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
		exit();
	}
	$id = intval($_GET['aid']);
	$item = C::t('#fn_fenlei#fn_fenlei_info_action')->fetch_by_id($id);
	C::t('#fn_fenlei#fn_fenlei_info_action')->delete_by_id($id);
	C::t('#fn_fenlei#fn_fenlei_info')->update_by_count($item['iid'],$fn_fenlei->setting['lang']['info_action_field_arr'][$item['action']],1,'-');
	GetInsertDoLog('del_info_action_list_fenlei','fn_'.$_GET['mod'],array('id'=>$id));//������¼

	fn_cpmsg($fn_fenlei->setting['lang']['DelOk'],$CpMsgUrl,'succeed');
}
//From: Dism_taobao_com
?>