<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

showtagheader('div', 'box', true,'box');
showtagheader('div', 'box-body', true,'box-body');
showtagheader('div', 'tab-content', true,'tab-content');
showsetting('&#39318;&#39029;&#38142;&#25509;', 'PluginLink',$fn_fenlei->getUrl('index'), 'text');
showsetting('&#39318;&#39029;&#38544;&#34255;&#24213;&#37096;&#23548;&#33322;', 'PluginLink',$fn_fenlei->getUrl('index',array('app'=>1)), 'text');
showsetting('&#20250;&#21592;&#20013;&#24515;', 'PluginLink',$fn_fenlei->getUrl('user'), 'text');
showsetting('&#36141;&#20080;&#22871;&#39184;', 'PluginLink',$fn_fenlei->getUrl('user',array('form'=>'setmeal')), 'text');
showsetting('&#21457;&#24067;&#20449;&#24687;', 'PluginLink',$fn_fenlei->getUrl('user',array('form'=>'pub')), 'text');
showtagfooter('div');
showtagfooter('div');
showtagfooter('div');

?>