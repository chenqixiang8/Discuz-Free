<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if(!$Fn_Admin->CheckUserGroup('fenlei_all') && !$Fn_Admin->CheckUserGroup('fenlei_config')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

@require_once libfile('function/cache');
@require_once libfile('function/core','plugin/fn_assembly');

$setting_name = 'fn_'.$_GET['mod'].'_setting';
loadcache($setting_name);
$common_setting = $_G['cache'][$setting_name];
$setting = $common_setting = array_filter($common_setting) ? $common_setting : array();
foreach($setting as $key => $value) {
	$setting[$key] = is_array($value) ? $value : stripslashes($value);
}
$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeItemUrl'];

if(!submitcheck('DetailSubmit')) {
	//ͼƬ�ϴ�
	if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_assembly/class/class_upload.php')){
		@require_once libfile('class/upload','plugin/fn_assembly');
		$UploadConfig = fn_upload::Config();
	}

	showtagheader('div', 'box', true,'box');
	showformheader($FormUrl,'enctype');
	if(in_array($Config['PluginVar']['AppType'],array('1','2','3'))){
		$AppNav = '<li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#app" role="tab" aria-expanded="false"><span class="hidden-sm-up"><i class="ion-email"></i></span> <span class="hidden-xs-down">&#65;&#80;&#80;&#35774;&#32622;</span></a> </li>';
	}
	echo <<<HTML
		<ul class="nav nav-tabs customtab" role="tablist">
          <li class="nav-item"> <a class="nav-link active" data-toggle="tab" href="#basics" role="tab" aria-expanded="true"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#22522;&#30784;&#35774;&#32622;</span></a> </li>
		  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#index" role="tab" aria-expanded="true"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#39318;&#39029;&#35774;&#32622;</span></a> </li>
		  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#nav" role="tab" aria-expanded="true"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#23548;&#33322;&#35774;&#32622;</span></a> </li>
		  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#wx" role="tab" aria-expanded="false"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#20844;&#20247;&#21495;&#35774;&#32622;</span></a> </li>
		  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#sms" role="tab" aria-expanded="true"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#30701;&#20449;&#27169;&#26495;&#35774;&#32622;</span></a> </li>
		  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#share" role="tab" aria-expanded="false"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#20998;&#20139;&#35774;&#32622;</span></a> </li>
		  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#color" role="tab" aria-expanded="false"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#39068;&#33394;&#35774;&#32622;</span></a> </li>
		  {$AppNav}
        </ul>
HTML;

	showtagheader('div', 'box-body', true,'box-body');

	showtagheader('div', 'tab-content', true,'tab-content');

	echo <<<HTML
	<!-- ��������  -->
	<div class="tab-pane active" id="basics" role="tabpanel" aria-expanded="true">
HTML;

	showsetting('&#26631;&#39064;', 'setting[index_title]', $setting['index_title'] ? $setting['index_title'] : '&#12304;&#39134;&#40479;&#12305;&#21516;&#22478;&#20998;&#31867;', 'text');

	showsetting('&#31649;&#29702;&#21592;&#117;&#105;&#100;', 'setting[admin]', $setting['admin'], 'text','','','&#26435;&#38480;&#65306;&#21487;&#31649;&#29702;&#25152;&#26377;&#20449;&#24687;&#32;&#26684;&#24335;&#65306;&#49;&#44;&#50;&#44;&#51;&#32;&#65281;&#65281;&#65281;&#32;&#27880;&#24847;&#65306;&#35813;&#35774;&#32622;&#21644;&#12304;&#21069;&#21488;&#31649;&#29702;&#12305;&#25554;&#20214;&#26080;&#20851;');

	showsetting('&#23458;&#26381;&#30005;&#35805;', 'setting[OnlineMobile]', $setting['OnlineMobile'], 'text');

	showsetting('&#23458;&#26381;&#24494;&#20449;&#21495;', 'setting[OnlineWx]', $setting['OnlineWx'], 'text');
	
	$OnlineWxPathHtml = ($setting['OnlineWxPath'] ? '<a href="'.$setting['OnlineWxPath'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['OnlineWxPath'].'" height="55"/></a>' : '').'&#19981;&#22635;&#21017;&#19981;&#24320;&#21551;&#65292;&#24494;&#20449;&#20869;&#25165;&#26174;&#31034;';
	showsetting('&#23458;&#26381;&#24494;&#20449;&#20108;&#32500;&#30721;', 'new_OnlineWxPath',$setting['OnlineWxPath'], 'filetext', '', 0, $OnlineWxPathHtml);

	$setting['service_pop_bg'] = $setting['service_pop_bg'] ? $setting['service_pop_bg'] : '/source/plugin/fn_fenlei/static/images/service-bg.png';
	$service_pop_bg_html = '<a href="'.$setting['service_pop_bg'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['service_pop_bg'].'" style="height:45px;"/></a>&#24314;&#35758;&#65306;&#55;&#50;&#48;&#32;&#42;&#32;&#57;&#54;&#54;';
	showsetting('&#23458;&#26381;&#24377;&#31383;&#32972;&#26223;', 'new_service_pop_bg',$setting['service_pop_bg'], 'filetext', '', 0, $service_pop_bg_html);

	$setting['service_pop_zw'] = $setting['service_pop_zw'] ? $setting['service_pop_zw'] : '/source/plugin/fn_fenlei/static/images/service-zw.png';
	$service_pop_zw_html = '<a href="'.$setting['service_pop_zw'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['service_pop_zw'].'" style="height:30px;"/></a>&#24314;&#35758;&#65306;&#49;&#56;&#53;&#32;&#42;&#32;&#49;&#55;&#48;';
	showsetting('&#23458;&#26381;&#24377;&#31383;&#25351;&#32441;', 'new_service_pop_zw',$setting['service_pop_zw'], 'filetext', '', 0, $service_pop_zw_html);

	showsetting('&#23458;&#26381;&#24377;&#31383;&#26631;&#39064;', 'setting[service_pop_title]', $setting['service_pop_title'] ? $setting['service_pop_title'] : '&#26377;&#20107;&#25214;&#23567;&#32534;', 'text');

	showsetting('&#23458;&#26381;&#24377;&#31383;&#24341;&#23548;&#35821;', 'setting[service_pop_tips]', $setting['service_pop_tips'] ? $setting['service_pop_tips'] : '&#38271;&#25353;&#20108;&#32500;&#30721;&#65292;&#35782;&#21035;&#28155;&#21152;&#23567;&#32534;', 'text');

	showsetting('&#21015;&#34920;&#20449;&#24687;&#35843;&#29992;&#26465;&#25968;', 'setting[list_info_limit]', $setting['list_info_limit'] ? $setting['list_info_limit'] : 10, 'text');
	
	showsetting('&#25628;&#32034;&#35201;&#30331;&#24405;&#65311;', 'setting[searchSwitch]', $setting['searchSwitch'], 'radio','','','&#25628;&#32034;&#26159;&#21542;&#35201;&#30331;&#24405;&#65311;');

	showsetting('&#26174;&#31034;&#39030;&#37096;&#22266;&#23450;&#23548;&#33322;', 'setting[headerSwitch]', $common_setting ? $setting['headerSwitch'] : 1, 'radio');

	showsetting('&#35814;&#24773;&#32852;&#31995;&#25552;&#31034;&#35821;', 'setting[viewContactTips]', $setting['viewContactTips'] ? $setting['viewContactTips'] : '&#32852;&#31995;&#25105;&#26102;&#65292;&#35831;&#35828;&#26159;&#22312;&#39134;&#40479;&#21516;&#22478;&#30475;&#21040;&#25105;&#30340;&#65292;&#35874;&#35874;', 'text');

	showsetting('&#35814;&#24773;&#24213;&#37096;&#32852;&#31995;&#25552;&#31034;&#35821;', 'setting[viewContactBottomTips]', $setting['viewContactBottomTips'] ? $setting['viewContactBottomTips'] : '&#32852;&#31995;&#26102;&#35831;&#35828;&#26469;&#33258;&#39134;&#40479;&#21516;&#22478;', 'text');

	showsetting('&#35814;&#24773;&#20030;&#25253;&#26631;&#39064;', 'setting[viewReportTitle]', $setting['viewReportTitle'] ? $setting['viewReportTitle'] : '&#22914;&#36935;&#26080;&#25928;&#12289;&#34394;&#20551;&#12289;&#35784;&#39575;&#20449;&#24687;&#65292;&#35831;&#31435;&#21051;&#20030;&#25253;', 'text');

	showsetting('&#35814;&#24773;&#20030;&#25253;&#25551;&#36848;', 'setting[viewReportDesc]', $setting['viewReportDesc'] ? $setting['viewReportDesc'] : '&#20132;&#26131;&#26102;&#35831;&#20180;&#32454;&#26597;&#39564;&#30456;&#20851;&#35777;&#20214;&#65292;&#19988;&#21247;&#25552;&#21069;&#25903;&#20184;&#20219;&#20309;&#36153;&#29992;', 'text');

	showsetting('&#20030;&#25253;&#21407;&#22240;', 'setting[report_list]', $setting['report_list'] ? $setting['report_list'] : '1=&#35825;&#23548;&#33829;&#38144;
2=&#19981;&#23454;&#20449;&#24687;
3=&#33394;&#24773;
4=&#36829;&#27861;&#29359;&#32618;
5=&#39578;&#25200;
6=&#34394;&#20551;&#30005;&#35805;
7=&#20405;&#26435;(&#20882;&#20805;&#20182;&#20154;&#65292;&#20405;&#29359;&#21517;&#35465;&#31561;)
8=&#20854;&#20182;','textarea','','','&#19968;&#34892;&#19968;&#26631;&#31614;&#65292;&#26684;&#24335;&#65306;<br>1=&#26631;&#31614;&#19968;<br>2=&#26631;&#31614;&#20108;');

	$setting['user_pub_icon'] = $setting['user_pub_icon'] ? $setting['user_pub_icon'] : '/source/plugin/fn_fenlei/static/images/view-content.png';
	$user_pub_icon_html = '<a href="'.$setting['user_pub_icon'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['user_pub_icon'].'" style="height:30px;"/></a>&#24314;&#35758;&#49;&#53;&#56;&#32;&#42;&#32;&#49;&#56;&#55;';
	showsetting('&#25105;&#30340;&#21457;&#24067;&#22270;&#26631;', 'new_user_pub_icon',$setting['user_pub_icon'], 'filetext', '', 0, $user_pub_icon_html);

	$setting['user_collection_icon'] = $setting['user_collection_icon'] ? $setting['user_collection_icon'] : '/source/plugin/fn_fenlei/static/images/view-like.png';
	$user_collection_icon_html = '<a href="'.$setting['user_collection_icon'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['user_collection_icon'].'" style="height:30px;"/></a>&#24314;&#35758;&#49;&#53;&#56;&#32;&#42;&#32;&#49;&#56;&#55;';
	showsetting('&#25105;&#30340;&#25910;&#34255;&#22270;&#26631;', 'new_user_collection_icon',$setting['user_collection_icon'], 'filetext', '', 0, $user_collection_icon_html);

	$setting['user_footprint_icon'] = $setting['user_footprint_icon'] ? $setting['user_footprint_icon'] : '/source/plugin/fn_fenlei/static/images/user-zuji.png';
	$user_footprint_icon_html = '<a href="'.$setting['user_footprint_icon'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['user_footprint_icon'].'" style="height:30px;"/></a>&#24314;&#35758;&#49;&#53;&#56;&#32;&#42;&#32;&#49;&#56;&#55;';
	showsetting('&#25105;&#30340;&#36275;&#36857;&#22270;&#26631;', 'new_user_footprint_icon',$setting['user_footprint_icon'], 'filetext', '', 0, $user_footprint_icon_html);

	$setting['user_online_icon'] = $setting['user_online_icon'] ? $setting['user_online_icon'] : '/source/plugin/fn_fenlei/static/images/user-kefu.png';
	$user_online_icon_html = '<a href="'.$setting['user_online_icon'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['user_online_icon'].'" style="height:30px;"/></a>&#24314;&#35758;&#49;&#53;&#56;&#32;&#42;&#32;&#49;&#56;&#55;';
	showsetting('&#22312;&#32447;&#23458;&#26381;&#22270;&#26631;', 'new_user_online_icon',$setting['user_online_icon'], 'filetext', '', 0, $user_online_icon_html);

	$setting['user_logout_icon'] = $setting['user_logout_icon'] ? $setting['user_logout_icon'] : '/source/plugin/fn_fenlei/static/images/user-logout.png';
	$user_logout_icon_html = '<a href="'.$setting['user_logout_icon'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['user_logout_icon'].'" style="height:30px;"/></a>&#24314;&#35758;&#49;&#53;&#56;&#32;&#42;&#32;&#49;&#56;&#55;';
	showsetting('&#25105;&#30340;&#36864;&#20986;&#22270;&#26631;', 'new_user_logout_icon',$setting['user_logout_icon'], 'filetext', '', 0, $user_logout_icon_html);

	$setting['pub_top_icon'] = $setting['pub_top_icon'] ? $setting['pub_top_icon'] : '/source/plugin/fn_fenlei/static/images/pub-top.png';
	$pub_top_icon_html = '<a href="'.$setting['pub_top_icon'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['pub_top_icon'].'" style="height:30px;"/></a>&#24314;&#35758;&#49;&#53;&#56;&#32;&#42;&#32;&#49;&#56;&#55;';
	showsetting('&#21457;&#24067;&#32622;&#39030;&#22270;&#26631;', 'new_pub_top_icon',$setting['pub_top_icon'], 'filetext', '', 0, $pub_top_icon_html);

	$setting['view_content_icon'] = $setting['view_content_icon'] ? $setting['view_content_icon'] : '/source/plugin/fn_fenlei/static/images/view-content.png';
	$view_content_icon_html = '<a href="'.$setting['view_content_icon'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['view_content_icon'].'" style="height:30px;"/></a>&#24314;&#35758;&#49;&#53;&#56;&#32;&#42;&#32;&#49;&#56;&#55;';
	showsetting('&#35814;&#24773;&#25551;&#36848;&#22270;&#26631;', 'new_view_content_icon',$setting['view_content_icon'], 'filetext', '', 0, $view_content_icon_html);

	$setting['view_contact_icon'] = $setting['view_contact_icon'] ? $setting['view_contact_icon'] : '/source/plugin/fn_fenlei/static/images/view-user.png';
	$view_contact_icon_html = '<a href="'.$setting['view_contact_icon'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['view_contact_icon'].'" style="height:30px;"/></a>&#23610;&#23544;&#65306;&#50;&#48;&#48;&#32;&#42;&#32;&#50;&#48;&#48;';
	showsetting('&#35814;&#24773;&#32852;&#31995;&#20154;&#22270;&#26631;', 'new_view_contact_icon',$setting['view_contact_icon'], 'filetext', '', 0, $view_contact_icon_html);

	$setting['view_phone_icon'] = $setting['view_phone_icon'] ? $setting['view_phone_icon'] : '/source/plugin/fn_fenlei/static/images/view-tel.png';
	$view_phone_icon_html = '<a href="'.$setting['view_phone_icon'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['view_phone_icon'].'" style="height:30px;"/></a>&#23610;&#23544;&#65306;&#50;&#48;&#48;&#32;&#42;&#32;&#50;&#48;&#48;';
	showsetting('&#35814;&#24773;&#30005;&#35805;&#22270;&#26631;', 'new_view_phone_icon',$setting['view_phone_icon'], 'filetext', '', 0, $view_phone_icon_html);

	$setting['view_report_icon'] = $setting['view_report_icon'] ? $setting['view_report_icon'] : '/source/plugin/fn_fenlei/static/images/view-report.png';
	$view_report_icon_html = '<a href="'.$setting['view_report_icon'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['view_report_icon'].'" style="height:30px;"/></a>&#23610;&#23544;&#65306;&#50;&#48;&#48;&#32;&#42;&#32;&#50;&#48;&#48;';
	showsetting('&#35814;&#24773;&#20030;&#25253;&#22270;&#26631;', 'new_view_report_icon',$setting['view_report_icon'], 'filetext', '', 0, $view_report_icon_html);

	$setting['view_like_icon'] = $setting['view_like_icon'] ? $setting['view_like_icon'] : '/source/plugin/fn_fenlei/static/images/view-like.png';
	$view_like_icon_html = '<a href="'.$setting['view_like_icon'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['view_like_icon'].'" style="height:30px;"/></a>&#24314;&#35758;&#49;&#50;&#56;&#32;&#42;&#32;&#54;&#48;';
	showsetting('&#35814;&#24773;&#29468;&#24744;&#21916;&#27426;&#22270;&#26631;', 'new_view_like_icon',$setting['view_like_icon'], 'filetext', '', 0, $view_like_icon_html);

	$setting['view_back_icon'] = $setting['view_back_icon'] ? $setting['view_back_icon'] : '/source/plugin/fn_fenlei/static/images/view-back.png';
	$view_back_icon_html = '<a href="'.$setting['view_back_icon'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['view_back_icon'].'" style="height:30px;"/></a>&#23610;&#23544;&#65306;&#50;&#48;&#48;&#32;&#42;&#32;&#50;&#48;&#48;';
	showsetting('&#35814;&#24773;&#36820;&#22238;&#22270;&#26631;', 'new_view_back_icon',$setting['view_back_icon'], 'filetext', '', 0, $view_back_icon_html);

	$setting['view_home_icon'] = $setting['view_home_icon'] ? $setting['view_home_icon'] : '/source/plugin/fn_fenlei/static/images/view-home.png';
	$view_home_icon_html = '<a href="'.$setting['view_home_icon'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['view_home_icon'].'" style="height:30px;"/></a>&#23610;&#23544;&#65306;&#50;&#48;&#48;&#32;&#42;&#32;&#50;&#48;&#48;';
	showsetting('&#35814;&#24773;&#39318;&#39029;&#22270;&#26631;', 'new_view_home_icon',$setting['view_home_icon'], 'filetext', '', 0, $view_home_icon_html);

	$setting['view_pub_icon'] = $setting['view_pub_icon'] ? $setting['view_pub_icon'] : '/source/plugin/fn_fenlei/static/images/view-add.png';
	$view_pub_icon_html = '<a href="'.$setting['view_pub_icon'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['view_pub_icon'].'" style="height:30px;"/></a>&#23610;&#23544;&#65306;&#50;&#48;&#48;&#32;&#42;&#32;&#50;&#48;&#48;';
	showsetting('&#35814;&#24773;&#21457;&#24067;&#22270;&#26631;', 'new_view_pub_icon',$setting['view_pub_icon'], 'filetext', '', 0, $view_pub_icon_html);

	$setting['view_chat_icon'] = $setting['view_chat_icon'] ? $setting['view_chat_icon'] : '/source/plugin/fn_fenlei/static/images/view-chat.png';
	$view_chat_icon_html = '<a href="'.$setting['view_chat_icon'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['view_chat_icon'].'" style="height:30px;"/></a>&#23610;&#23544;&#65306;&#50;&#48;&#48;&#32;&#42;&#32;&#50;&#48;&#48;';
	showsetting('&#35814;&#24773;&#32842;&#22825;&#22270;&#26631;', 'new_view_chat_icon',$setting['view_chat_icon'], 'filetext', '', 0, $view_chat_icon_html);

	$setting['view_share_icon'] = $setting['view_share_icon'] ? $setting['view_share_icon'] : '/source/plugin/fn_fenlei/static/images/view-share.png';
	$view_share_icon_html = '<a href="'.$setting['view_share_icon'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['view_share_icon'].'" style="height:30px;"/></a>&#23610;&#23544;&#65306;&#50;&#48;&#48;&#32;&#42;&#32;&#50;&#48;&#48;';
	showsetting('&#35814;&#24773;&#20998;&#20139;&#22270;&#26631;', 'new_view_share_icon',$setting['view_share_icon'], 'filetext', '', 0, $view_share_icon_html);

	$setting['view_collection_icon'] = $setting['view_collection_icon'] ? $setting['view_collection_icon'] : '/source/plugin/fn_fenlei/static/images/view-collection.png';
	$view_collection_icon_html = '<a href="'.$setting['view_collection_icon'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['view_collection_icon'].'" style="height:30px;"/></a>&#23610;&#23544;&#65306;&#50;&#48;&#48;&#32;&#42;&#32;&#50;&#48;&#48;';
	showsetting('&#35814;&#24773;&#25910;&#34255;&#22270;&#26631;', 'new_view_collection_icon',$setting['view_collection_icon'], 'filetext', '', 0, $view_collection_icon_html);

	showsetting('&#22871;&#39184;&#35828;&#26126;', 'setting[user_setmeal_tips]', $setting['user_setmeal_tips'] ? $setting['user_setmeal_tips'] : '<p>&#27880;&#24847;</p>
<p>1. &#22871;&#39184;&#20869;&#25152;&#26377;&#20869;&#23481;&#38656;&#35201;&#22312;&#26377;&#25928;&#26399;&#20869;&#20351;&#29992;&#23436;&#27605;&#65292;&#36807;&#26399;&#21518;&#21097;&#20313;&#20869;&#23481;&#23558;&#19981;&#21487;&#20351;&#29992;</p>
<p>2. &#22871;&#39184;&#26410;&#21040;&#26399;&#25110;&#32773;&#22871;&#39184;&#20869;&#23481;&#26410;&#20351;&#29992;&#23436;&#26102;&#65292;&#21487;&#32487;&#32493;&#36141;&#20080;&#22871;&#39184;&#65292;&#36141;&#20080;&#21518;&#22871;&#39184;&#20869;&#23481;&#21472;&#21152;&#65292;&#22871;&#39184;&#26102;&#38388;&#25353;&#26368;&#26032;&#22871;&#39184;&#20026;&#20934;</p>', 'textarea');

	//ˮӡ����
	showsetting('&#24320;&#21551;&#27700;&#21360;',array('setting[watermark]', array(
		array('1','&#26159;', array('watermark_div' => '')),
		array('0','&#21542;', array('watermark_div' => 'none')),
	), TRUE),$setting['watermark'], 'mradio','','','&#24494;&#20449;&#47;&#30005;&#33041;&#29256;&#26377;&#25928;&#65292;&#27880;&#24847;&#65306;&#30001;&#20110;&#65;&#80;&#80;&#26377;&#19978;&#20256;&#32452;&#20214;&#65292;&#25152;&#20197;&#35813;&#35774;&#32622;&#65;&#80;&#80;&#20869;&#26080;&#25928;');
	showtagheader('div', 'watermark_div', $setting['watermark'] == 1 ? true : '','sub');
		$watermark_position_array = array(
			array('1','&#24038;&#19978;'),
			array('2','&#24038;&#20013;'),
			array('3','&#21491;&#19978;'),
			array('4','&#20013;&#24038;'),
			array('5','&#20013;&#38388;'),
			array('6','&#20013;&#21491;'),
			array('7','&#24038;&#19979;'),
			array('8','&#20013;&#19979;'),
			array('9','&#21491;&#19979;'),
		);
		showsetting('&#27700;&#21360;&#20301;&#32622;', array('setting[watermark_status]',$watermark_position_array),$common_setting ? $setting['watermark_status'] : 9,'select');
		showsetting('&#27700;&#21360;&#26465;&#20214;', 'setting[watermark_condition]', $setting['watermark_condition'] ? $setting['watermark_condition'] : '0-0', 'text','','','&#26684;&#24335;&#65306;&#48;&#45;&#48;&#65281;&#65281;&#65281;&#35774;&#32622;&#27700;&#21360;&#28155;&#21152;&#30340;&#26465;&#20214;&#65292;&#23567;&#20110;&#27492;&#23610;&#23544;&#30340;&#22270;&#29255;&#38468;&#20214;&#23558;&#19981;&#28155;&#21152;&#27700;&#21360;');
		
		showsetting('&#74;&#80;&#69;&#71;&#27700;&#21360;&#36136;&#37327;', 'setting[watermark_quality]', $common_setting ? $setting['watermark_quality'] : 90, 'text','','','&#35774;&#32622;&#74;&#80;&#69;&#71;&#31867;&#22411;&#30340;&#22270;&#29255;&#38468;&#20214;&#28155;&#21152;&#27700;&#21360;&#21518;&#30340;&#36136;&#37327;&#21442;&#25968;&#65292;&#33539;&#22260;&#20026;&#32;&#48;&#65374;&#49;&#48;&#48;&#32;&#30340;&#25972;&#25968;&#65292;&#25968;&#20540;&#36234;&#22823;&#32467;&#26524;&#22270;&#29255;&#25928;&#26524;&#36234;&#22909;&#65292;&#20294;&#23610;&#23544;&#20063;&#36234;&#22823;');

		showsetting('&#27700;&#21360;&#31867;&#22411;',array('setting[watermark_type]', array(
			array('png','&#80;&#78;&#71;&#31867;&#22411;&#27700;&#21360;', array('watermark_type_text_div' => 'none','watermark_type_png_div' => '','watermark_type_gif_div' => 'none')),
			array('gif','&#71;&#73;&#70;&#31867;&#22411;&#27700;&#21360;', array('watermark_type_text_div' => 'none','watermark_type_png_div' => 'none','watermark_type_gif_div' => '')),
		), TRUE),$setting['watermark_type'] ? $setting['watermark_type'] : 'png','mradio');

		showtagheader('div', 'watermark_type_png_div', $setting['watermark_type'] == 'png' ? true : '','sub');
			$setting['watermark_png'] = $setting['watermark_png'] ? $setting['watermark_png'] : 'static/image/common/watermark.png';
			$watermark_png_html = '<a href="'.$setting['watermark_png'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['watermark_png'].'" height="55"/></a>&#24314;&#35758;&#23610;&#23544;&#65306;&#49;&#51;&#48;&#32;&#42;&#32;&#52;&#48;';
			showsetting('&#80;&#78;&#71;&#27700;&#21360;', 'new_watermark_png',$setting['watermark_png'], 'filetext', '', 0, $watermark_png_html);
		showtagfooter('div');

		showtagheader('div', 'watermark_type_gif_div', $setting['watermark_type'] == 'gif' ? true : '','sub');
			$setting['watermark_gif'] = $setting['watermark_gif'] ? $setting['watermark_gif'] : 'static/image/common/watermark.gif';
			$watermark_gif_html = '<a href="'.$setting['watermark_gif'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['watermark_gif'].'" height="55"/></a>&#24314;&#35758;&#23610;&#23544;&#65306;&#49;&#51;&#48;&#32;&#42;&#32;&#52;&#48;';
			showsetting('&#71;&#73;&#70;&#27700;&#21360;', 'new_watermark_gif',$setting['watermark_gif'], 'filetext', '', 0, $watermark_gif_html);
			showsetting('&#27700;&#21360;&#34701;&#21512;&#24230;', 'setting[watermark_trans]', $setting['watermark_trans'] ? $setting['watermark_trans'] : 50, 'text','','','&#35774;&#32622;&#71;&#73;&#70;&#31867;&#22411;&#27700;&#21360;&#22270;&#29255;&#19982;&#21407;&#22987;&#22270;&#29255;&#30340;&#34701;&#21512;&#24230;&#65292;&#33539;&#22260;&#20026;&#32;&#49;&#65374;&#49;&#48;&#48;&#32;&#30340;&#25972;&#25968;&#65292;&#25968;&#20540;&#36234;&#22823;&#27700;&#21360;&#22270;&#29255;&#36879;&#26126;&#24230;&#36234;&#20302;&#12290;');
		showtagfooter('div');
		
		showtagheader('div', 'watermark_type_text_div', $setting['watermark_type'] == 'text' ? true : '','sub');
			
		showtagfooter('div');
	showtagfooter('div');
	//ˮӡ���� END

	showsetting('&#30005;&#33041;&#29256;&#20108;&#32500;&#30721;',array('setting[PcQrSwitch]', array(
		array('1','&#26159;', array('PcQrSwitchDiv' => '')),
		array('0','&#21542;', array('PcQrSwitchDiv' => 'none')),
	), TRUE),$setting['PcQrSwitch'], 'mradio');

	showtagheader('div', 'PcQrSwitchDiv', $setting['PcQrSwitch'] == 1 ? true : '','PcQrSwitchDiv');
		showsetting('&#30005;&#33041;&#29256;&#20108;&#32500;&#30721;&#25991;&#23383;', 'setting[PcQrText]', $setting['PcQrText'] ? $setting['PcQrText'] : '&#25195;&#19968;&#25195;&#65292;&#25163;&#26426;&#27983;&#35272;&#20998;&#31867;&#20449;&#24687;&#26356;&#26041;&#20415;', 'text');
	showtagfooter('div');

	showsetting('&#31532;&#19977;&#26041;&#32479;&#35745;&#20195;&#30721;', 'setting[statistics]', $setting['statistics'], 'textarea');

	echo <<<HTML
	</div>
	<!-- �������� end  -->
HTML;

	echo <<<HTML
	<!-- ��������  -->
	<div class="tab-pane" id="nav" role="tabpanel" aria-expanded="false">
	<script type="text/JavaScript">
	var footernavrowtypedata = [
		[
			[1, '<input type="text" class="form-control w50" name="common_list[tabbar][displayorder][]" value="">'],
			[1, '<input name="common_list[tabbar][file_icon][]" value="" class="txt uploadbtn" type="file" style="width:266px;">'],
			[1, '<input name="common_list[tabbar][file_on_icon][]" value="" class="txt uploadbtn" type="file" style="width:266px;">'],
			[1, '<input type="text" class="form-control w200" name="common_list[tabbar][title][]" value="">'],
			[1, '<input type="text" class="form-control w400" name="common_list[tabbar][url][]" value="">'],
			[1, '<input type="text" class="form-control w50" name="common_list[tabbar][top][]" value="">'],
			[1, '<a href="#" onclick="deleterow(this)" class="btn btn-sm btn-danger-outline">&#21024;&#38500;</a>']
		],
	];
	</script>
HTML;

	//�ײ�����
	echo '<div class="alert alert-primary" role="alert" style="display:none;"></div><div class="border box-header margin-top-0"><h5 class="box-title">&#24213;&#37096;&#23548;&#33322; - <span class="font-size-12">&#91;&#115;&#105;&#116;&#101;&#117;&#114;&#108;&#93;&#20195;&#34920;&#24403;&#21069;&#22495;&#21517;</span></h5></div>';
	showtableheader('','table table-bordered table-hover display nowrap table-responsive dataTable');
	showsubtitle(array(
		'&#26174;&#31034;&#39034;&#24207;',
		'&#23548;&#33322;&#22270;&#26631;',
		'&#23548;&#33322;&#36873;&#20013;&#22270;&#26631;',
		'&#23548;&#33322;&#26631;&#39064;',
		'&#23548;&#33322;&#38142;&#25509;',
		'&#26159;&#21542;&#31361;&#20986;&#26174;&#31034;&#40;&#49;&#20195;&#34920;&#26159;&#65292;&#48;&#20195;&#34920;&#21542;&#41;',
		'&#21024;&#38500;'
	),'header tbm tc');
	$tabbarArr = $common_setting ? $setting['tabbar'] : array(
		array('displayorder'=>'0','title'=>'&#39318;&#39029;','url'=>'[siteurl]plugin.php?id=fn_fenlei','icon'=>'/source/plugin/fn_fenlei/static/images/home.png','on_icon'=>'/source/plugin/fn_fenlei/static/images/homed.png','top'=>0),
		array('displayorder'=>'1','title'=>'&#21457;&#24067;','url'=>'[siteurl]plugin.php?id=fn_fenlei&mod=user&form=pub','icon'=>'/source/plugin/fn_fenlei/static/images/add.png','on_icon'=>'/source/plugin/fn_fenlei/static/images/addd.png','top'=>1),
		array('displayorder'=>'2','title'=>'&#25105;&#30340;','url'=>'[siteurl]plugin.php?id=fn_fenlei&mod=user','icon'=>'/source/plugin/fn_fenlei/static/images/user.png','on_icon'=>'/source/plugin/fn_fenlei/static/images/userd.png','top'=>0)
	);
	foreach ($tabbarArr as $key => $nav) {
		showtablerow('', array('class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
			'<input type="text" class="form-control w50" name="common_list[tabbar][displayorder][]" value="'.$nav['displayorder'].'">',
			($nav['icon'] ? '<a href="'.$nav['icon'].'" target="_blank"><img src="'.$nav['icon'].'" style="height:30px;margin:0 5px 0 0;"></a>' : '').'<input type="hidden" size="30" name="common_list[tabbar][icon][]" value="'.$nav['icon'].'" /><input name="common_list[tabbar][file_icon][]" value="" class="txt uploadbtn" type="file" style="width:266px;">',
			($nav['on_icon'] ? '<a href="'.$nav['on_icon'].'" target="_blank"><img src="'.$nav['on_icon'].'" style="height:30px;margin:0 5px 0 0;"></a>' : '').'<input type="hidden" size="30" name="common_list[tabbar][on_icon][]" value="'.$nav['on_icon'].'" /><input name="common_list[tabbar][file_on_icon][]" value="" class="txt uploadbtn" type="file" style="width:266px;">',
			'<input type="text" class="form-control w200" name="common_list[tabbar][title][]" value="'.$nav['title'].'">',
			'<input type="text" class="form-control w400" name="common_list[tabbar][url][]" value="'.$nav['url'].'">',
			'<input type="text" class="form-control w50" name="common_list[tabbar][top][]" value="'.$nav['top'].'">',
			'<a href="#" onclick="deleterow(this)" class="btn btn-sm btn-danger-outline">&#21024;&#38500;</a>',
		));
	}
	echo '<tr class="hover"><td class="tc" colspan="10"><a href="#" onclick="addrow(this,footernavrowtypedata, 0)"><i class="fa fa-plus" style="margin-right:5px"></i>&#28155;&#21152;&#23548;&#33322;</a></td></tr>';
	showtablefooter(); /*dism��taobao��com*/
	//�ײ����� End
echo <<<HTML
	</div>
	<!-- ���� end -->
HTML;

	echo <<<HTML
	<!-- ��ҳ����  -->
	<div class="tab-pane" id="index" role="tabpanel" aria-expanded="false">
HTML;
	
	echo '<div class="form-group row"><label class="col-sm-1 col-form-label">&#27178;&#24133;&#22270;&#29255;<br>&#23610;&#23544;&#24314;&#35758;&#54;&#52;&#48;&#32;&#42;&#32;&#51;&#48;&#48;</label><div class="col-sm-9"><div class="UploadBanner"><div class="PhotoControl ClickPhotoControl" id="Banners"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';
	
	$setting['notice_img'] = $setting['notice_img'] ? $setting['notice_img'] : '/source/plugin/fn_fenlei/static/images/notice_img.png';
	$notice_img_html = '<a href="'.$setting['notice_img'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['notice_img'].'" style="height:30px;"/></a>&#24314;&#35758;&#49;&#50;&#56;&#32;&#42;&#32;&#54;&#48;';
	showsetting('&#20844;&#21578;&#22270;&#26631;', 'new_notice_img',$setting['notice_img'], 'filetext', '', 0, $notice_img_html);

	showsetting('&#20844;&#21578;&#20869;&#23481;', 'setting[NoticeList]', $common_setting ? $setting['NoticeList'] : '&#24685;&#21916;&#39134;&#40479;&#20998;&#31867;&#19978;&#32447;&#21862;|http://dev.yili6.com
&#24685;&#21916;&#39134;&#40479;&#20998;&#31867;&#19978;&#32447;&#21862;|http://dev.yili6.com','textarea','','','&#19968;&#34892;&#19968;&#20844;&#21578;&#65292;&#26684;&#24335;&#65306;&#25991;&#23383;|&#38142;&#25509;&#65281;&#65281;&#65281;&#20363;&#22914;&#65306;<br>
&#24685;&#21916;&#39134;&#40479;&#20998;&#31867;&#19978;&#32447;&#21862;|http://dev.yili6.com<br>
&#24685;&#21916;&#39134;&#40479;&#20998;&#31867;&#19978;&#32447;&#21862;|http://dev.yili6.com');

	showsetting('&#26368;&#26032;&#21457;&#24067;&#23548;&#33322;', 'setting[index_nav_classid]', $setting['index_nav_classid'] ? $setting['index_nav_classid'] : '0=&#26368;&#26032;&#20449;&#24687;
1=&#25214;&#24037;&#20316;
2=&#20108;&#25163;&#36710;
3=&#20986;&#31199;&#25151;
4=&#21830;&#38138;','textarea','','','&#19968;&#34892;&#19968;&#23548;&#33322;&#65292;&#26684;&#24335;&#65306;&#32034;&#24341;&#65288;&#32034;&#24341;&#24517;&#39035;&#20998;&#31867;ID&#65292;0&#20195;&#34920;&#26368;&#26032;&#20449;&#24687;&#65289;=&#26631;&#39064;&#65281;&#65281;&#65281;&#20363;&#22914;&#65306;
0=&#26368;&#26032;&#20449;&#24687;
1=&#25214;&#24037;&#20316;');

	showsetting('&#20449;&#24687;&#21015;&#34920;&#35843;&#29992;&#26465;&#25968;', 'setting[index_info_limit]', $setting['index_info_limit'] ? $setting['index_info_limit'] : 10, 'text');

	showsetting('&#24320;&#21551;&#21491;&#20391;&#22266;&#23450;&#21457;&#24067;',array('setting[index_right_add]', array(
		array('1','&#26159;', array('index_right_add_1' => '')),
		array('0','&#21542;', array('index_right_add_1' => 'none')),
	), TRUE),$setting['index_right_add'], 'mradio');

	showtagheader('div', 'index_right_add_1', $setting['index_right_add'] == 1 ? true : '','index_right_add_1');
		$setting['index_right_add_icon'] = $setting['index_right_add_icon'] ? $setting['index_right_add_icon'] : '/source/plugin/fn_fenlei/static/images/add.png';
		$index_right_add_icon_html = '<a href="'.$setting['index_right_add_icon'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['index_right_add_icon'].'" style="height:30px;"/></a>&#23610;&#23544;&#65306;&#50;&#48;&#48;&#32;&#42;&#32;&#50;&#48;&#48;';
		showsetting('&#21491;&#20391;&#22266;&#23450;&#21457;&#24067;&#22270;&#26631;', 'new_index_right_add_icon',$setting['index_right_add_icon'], 'filetext', '', 0, $index_right_add_icon_html);
	showtagfooter('div');

	showsetting('&#38544;&#34255;&#25968;&#25454;&#32479;&#35745;', 'setting[dataSwitch]', $setting['dataSwitch'], 'radio');

	echo <<<HTML
	</div>
	<!-- ��ҳ���� end  -->
HTML;

	echo <<<HTML
	<!-- ΢������  -->
	<div class="tab-pane" id="wx" role="tabpanel" aria-expanded="false">
HTML;
	
	//showsetting('&#24494;&#20449;&#65;&#112;&#112;&#73;&#100;', 'setting[WxAppid]', $setting['WxAppid'], 'text','','','&#29992;&#20110;&#20844;&#20247;&#21495;&#31649;&#29702;');
	//showsetting('&#24494;&#20449;&#83;&#101;&#99;&#114;&#101;&#116;', 'setting[WxSecret]', $setting['WxSecret'], 'text');

	$setting['WxFollowPath'] = $setting['WxFollowPath'] ? $setting['WxFollowPath'] : '/source/plugin/fn_fenlei/static/images/follow.jpg';
	$WxFollowPathHtml = '<a href="'.$setting['WxFollowPath'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['WxFollowPath'].'" height="55"/></a>';
	showsetting('&#35814;&#24773;&#20851;&#27880;&#20108;&#32500;&#30721;', 'new_WxFollowPath',$setting['WxFollowPath'], 'filetext', '', 0, $WxFollowPathHtml);

	showsetting('&#35814;&#24773;&#20851;&#27880;&#20108;&#32500;&#30721;&#25552;&#31034;&#35821;', 'setting[wx_follow_tips]', $setting['wx_follow_tips'] ? $setting['wx_follow_tips'] : "<p class='font-weight-bold font-size-064rem'>&#39134;&#40479;&#20449;&#24687;&#32593;&#65292;&#20813;&#36153;&#21457;&#24067;&#20449;&#24687;&#65281;&#65288;&#38271;&#25353;&#20851;&#27880;&#65289;</p>
<p class='text-light-muted pt-2' style='line-height:0.9rem'>&#27963;&#21160;&#25512;&#24191;&#65292;&#23478;&#23621;&#24314;&#26448;&#65292;&#29983;&#24847;&#36716;&#35753;&#65292;&#36710;&#36742;&#20132;&#26131;&#65292;&#25171;&#21548;&#27714;&#21161;&#65292;&#20108;&#25163;&#38386;&#32622;&#31561;&#28040;&#24687;&#12290;</p>", 'textarea');
	
	echo <<<HTML
	</div>
	<!-- ΢������ end  -->
HTML;
	
	echo <<<HTML
	<!-- ����ģ������  -->
	<div class="tab-pane" id="sms" role="tabpanel" aria-expanded="false">
HTML;
	
	showsetting('&#24320;&#21551;&#25163;&#26426;&#39564;&#35777;', 'setting[ShortCodeSwitch]', $setting['ShortCodeSwitch'], 'radio','','','&#35831;&#20808;&#21069;&#24448;<a href="plugin.php?id=fn_admin&mod=global&item=config" target="_blank" class="text-info">&#12304;&#30701;&#20449;&#35774;&#32622;&#12305;</a>&#37197;&#32622;&#30701;&#20449;&#25509;&#21475;&#31867;&#22411;&#20197;&#21450;&#36134;&#21495;&#23494;&#30721;&#65281;&#24050;&#37197;&#32622;&#21487;&#24573;&#30053;&#35813;&#25552;&#31034;&#65281;&#65281;&#65281;&#21457;&#24067;&#30340;&#26102;&#20505;&#26159;&#21542;&#24320;&#21551;&#25163;&#26426;&#39564;&#35777;');

	if($Config['PluginVar']['ShortMessageType'] == 1){

		showsetting('&#38463;&#37324;&#20113;&#31614;&#21517;&#21517;&#31216;', 'setting[AliAutograph]', $setting['AliAutograph'], 'text','','','&#33719;&#21462;&#26041;&#24335;&#65306;&#104;&#116;&#116;&#112;&#115;&#58;&#47;&#47;&#100;&#121;&#115;&#109;&#115;&#46;&#99;&#111;&#110;&#115;&#111;&#108;&#101;&#46;&#97;&#108;&#105;&#121;&#117;&#110;&#46;&#99;&#111;&#109;&#47;&#100;&#121;&#115;&#109;&#115;&#46;&#104;&#116;&#109;&#35;&#47;&#100;&#111;&#109;&#101;&#115;&#116;&#105;&#99;&#47;&#116;&#101;&#120;&#116;&#47;&#115;&#105;&#103;&#110;');

		showsetting('&#38463;&#37324;&#20113;&#39564;&#35777;&#30721;&#27169;&#29256;&#67;&#79;&#68;&#69;', 'setting[AliCodeId]', $setting['AliCodeId'], 'text','','','&#33719;&#21462;&#26041;&#24335;&#65306;&#104;&#116;&#116;&#112;&#115;&#58;&#47;&#47;&#100;&#121;&#115;&#109;&#115;&#46;&#99;&#111;&#110;&#115;&#111;&#108;&#101;&#46;&#97;&#108;&#105;&#121;&#117;&#110;&#46;&#99;&#111;&#109;&#47;&#100;&#121;&#115;&#109;&#115;&#46;&#104;&#116;&#109;&#35;&#47;&#100;&#101;&#118;&#101;&#108;&#111;&#112;&#47;&#116;&#101;&#109;&#112;&#108;&#97;&#116;&#101;&#32;&#32;&#26684;&#24335;&#65306;<br>&#24744;&#30340;&#39564;&#35777;&#30721;&#65306;&#36;&#123;&#99;&#111;&#100;&#101;&#125;&#65292;&#24744;&#27491;&#36827;&#34892;&#36523;&#20221;&#39564;&#35777;&#65292;&#25171;&#27515;&#19981;&#21578;&#35785;&#21035;&#20154;&#65281;');

	}else if($Config['PluginVar']['ShortMessageType'] == 2){

		showsetting('&#30701;&#20449;&#36890;&#36890;&#30693;&#27169;&#26495;', 'setting[ChanyooNotice]', $setting['ChanyooNotice'], 'textarea','','','&#33719;&#21462;&#26041;&#24335;&#65306;&#30701;&#20449;&#36890;&#21518;&#21488;&#45;&#12299;&#27169;&#26495;&#21015;&#34920;&#45;&#12299;&#28155;&#21152;&#27169;&#26495;<br>&#27880;&#24847;&#65306;&#30701;&#20449;&#36890;&#21518;&#21488;&#28155;&#21152;&#27169;&#26495;&#30340;&#26102;&#65292;&#123;&#77;&#115;&#103;&#125;&#26356;&#25913;&#20026;&#123;&#21464;&#37327;&#125;<br>&#26684;&#24335;&#65306;&#28040;&#24687;&#36890;&#30693;&#65306;&#123;&#77;&#115;&#103;&#125;&#65292;&#12304;&#30701;&#20449;&#36890;&#30340;&#31614;&#21517;&#12305;');

	}

	echo <<<HTML
	</div>
	<!-- ����ģ������ end  -->
HTML;

	echo <<<HTML
	<!-- ��������  -->
	<div class="tab-pane" id="share" role="tabpanel" aria-expanded="false">
HTML;
	
	showsetting('&#20998;&#20139;&#26631;&#39064;', 'setting[share_title]', $setting['share_title'] ? $setting['share_title'] : '&#12304;&#39134;&#40479;&#12305;&#21516;&#22478;&#20998;&#31867;', 'text');

	showsetting('&#20998;&#20139;&#25551;&#36848;', 'setting[share_desc]', $setting['share_desc'] ? $setting['share_desc'] : '&#12304;&#39134;&#40479;&#12305;&#21516;&#22478;&#20998;&#31867;', 'textarea');

	$setting['share_logo'] = $setting['share_logo'] ? $setting['share_logo'] : '/source/plugin/fn_fenlei/static/images/share_logo.png';
	$share_logo_html = '<a href="'.$setting['share_logo'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['share_logo'].'" height="55"/></a>&#23610;&#23544;&#49;&#48;&#48;&#32;&#42;&#32;&#49;&#48;&#48;';
	showsetting('&#20998;&#20139;&#22270;&#29255;', 'new_share_logo',$setting['share_logo'], 'filetext', '', 0, $share_logo_html);

	echo <<<HTML
	</div>
	<!-- �������� end  -->
HTML;

	echo <<<HTML
	<!-- ��ɫ����  -->
	<div class="tab-pane" id="color" role="tabpanel" aria-expanded="false">
HTML;

	showsetting('&#20027;&#39064;&#39068;&#33394;', 'setting[color]', $setting['color'] ? $setting['color'] : '#104FFF', 'color');

	showsetting('&#20027;&#39064;&#39068;&#33394;2', 'setting[color2]', $setting['color2'] ? $setting['color2'] : '#ff1c53', 'color');

	showsetting('&#28176;&#21464;&#20027;&#39064;&#39068;&#33394;&#49;&#45;&#48;', 'setting[changecolor1_0]', $setting['changecolor1_0'] ? $setting['changecolor1_0'] : '#104FFF', 'color');

	showsetting('&#28176;&#21464;&#20027;&#39064;&#39068;&#33394;&#49;&#45;&#49;', 'setting[changecolor1_1]', $setting['changecolor1_1'] ? $setting['changecolor1_1'] : '#527ef9', 'color');


	echo <<<HTML
	</div>
	<!-- ��ɫ���� end  -->
HTML;
	
	if(in_array($Config['PluginVar']['AppType'],array('1','2','3'))){

	echo <<<HTML
	<!-- APP����  -->
	<div class="tab-pane" id="app" role="tabpanel" aria-expanded="false">
HTML;
	
	showsetting('&#65;&#80;&#80;&#23458;&#26381;&#117;&#105;&#100;', 'setting[AppOnlineUid]', $setting['AppOnlineUid'], 'text');

	showsetting('&#65;&#80;&#80;&#23458;&#26381;&#21517;&#23383;', 'setting[AppOnlineName]', $setting['AppOnlineName'], 'text');

	if(in_array($Config['PluginVar']['AppType'],array('2','3'))){
		$AppOnlineFaceHtml = $setting['AppOnlineFace'] ? '<a href="'.$setting['AppOnlineFace'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['AppOnlineFace'].'" height="55"/></a>' : '';
		showsetting('&#65;&#80;&#80;&#23458;&#26381;&#22836;&#20687;', 'new_AppOnlineFace',$setting['AppOnlineFace'], 'filetext', '', 0, $AppOnlineFaceHtml);
	}

	showtagheader('div', 'mag_app_table', $Config['PluginVar']['AppType'] == 1 ? true : '','mag_app_table');
		showsetting('&#39532;&#30002;&#83;&#101;&#99;&#114;&#101;&#116;', 'setting[MagSecret]', $setting['MagSecret'], 'text','','','&#19981;&#22635;&#21017;&#32487;&#25215;&#12304;&#20840;&#23616;&#35774;&#32622;&#12305;&#30340;&#35774;&#32622;');
		showsetting('&#39532;&#30002;&#21161;&#25163;&#83;&#101;&#99;&#114;&#101;&#116;', 'setting[MagAssistantSecret]', $setting['MagAssistantSecret'], 'text','','','&#19981;&#22635;&#21017;&#32487;&#25215;&#12304;&#20840;&#23616;&#35774;&#32622;&#12305;&#30340;&#35774;&#32622;');
		showsetting('&#39532;&#30002;&#21161;&#25163;&#25512;&#36865;', 'setting[MagAssistantPush]', $setting['MagAssistantPush'], 'radio','','','&#19981;&#22635;&#21017;&#32487;&#25215;&#12304;&#20840;&#23616;&#35774;&#32622;&#12305;&#30340;&#35774;&#32622;');
	showtagfooter('div');
	
	showtagheader('div', 'qf_app_table', $Config['PluginVar']['AppType'] == 2 ? true : '','qf_app_table');
		showsetting('&#21315;&#24070;&#25903;&#20184;&#35746;&#21333;&#31867;&#22411;&#73;&#68;', 'setting[qf_type]', $setting['qf_type'], 'text','','','&#19981;&#22635;&#21017;&#32487;&#25215;&#12304;&#20840;&#23616;&#35774;&#32622;&#12305;&#30340;&#35774;&#32622;');
		showsetting('&#21315;&#24070;&#26381;&#21153;&#21495;&#29992;&#25143;&#73;&#68;', 'setting[qf_from_id]', $setting['qf_from_id'], 'text','','','&#19981;&#22635;&#21017;&#32487;&#25215;&#12304;&#20840;&#23616;&#35774;&#32622;&#12305;&#30340;&#35774;&#32622;');
	showtagfooter('div');

	echo <<<HTML
	</div>
	<!-- APP���� end  -->
HTML;
	}

	showsubmit('DetailSubmit', '&#20445;&#23384;&#37197;&#32622;');
	showtagfooter('div');
	showtagfooter('div');
	showformfooter(); /*Dism_taobao-com*/
	showtagfooter('div');
	
	$setting['banners'] = $common_setting ? $setting['banners'] : array(
		array('img'=>'/source/plugin/fn_fenlei/static/images/banner1.jpg'),
		array('img'=>'/source/plugin/fn_fenlei/static/images/banner2.jpg')	
	);
	if($setting['banners']){
		foreach($setting['banners'] as $Key => $Val) {
			$banners_js_array[] = '"'.$Val['img'].'|'.$setting['banners'][$Key]['title'].'|'.$setting['banners'][$Key]['link'].'"';
		}
		$UpLoadHtml .= '
		var InputArray = new Array('.implode(',',$banners_js_array).');
		$("#Banners").AppUpload({InputName:"new_banners",InputLink:true,InputExist:true,InputArray:InputArray,Move:true});';
	}else{
		$UpLoadHtml .= '$("#Banners").AppUpload({InputName:"new_banners",InputLink:true,Move:true});';
	}

	echo $UploadConfig['CssJsHtml'];
	echo '<script>'.$UpLoadHtml.'</script>';
	
}else{

	foreach($_GET['setting'] as $key => $value) {
		$setting[$key] = is_array($value) ? $value : addslashes($value);
	}

	foreach($_GET['upload_admin'] as $key => $value){
		if(strpos($key,'new_') !== false){
			$key_name = str_replace(array('new_'),'',$key);
			$setting[$key_name] = array();
			foreach($_GET[$key] as $k => $v) {
				$setting[$key_name][$k]['img'] = strpos($v,'http') !== false ? $v : $_G['siteurl'].$v;
				$setting[$key_name][$k]['link'] = $_GET[$key.'_link'][$k];
				$setting[$key_name][$k]['title'] = $_GET[$key.'_title'][$k];
			}
		}
	}

	foreach(array('tabbar') as $common_nav_value){
		foreach($_GET['common_list'][$common_nav_value] as $nav_key => $nav_value){
			foreach($_GET['common_list'][$common_nav_value]['displayorder'] as $key => $value){
				$new_setting[$common_nav_value][$key][$nav_key] = filter_string($_GET['common_list'][$common_nav_value][$nav_key][$key]);
				if($_FILES['common_list']['size'][$common_nav_value]['file_'.$nav_key][$key]){
					$images = array(
						'name' => $_FILES['common_list']['name'][$common_nav_value]['file_'.$nav_key][$key],
						'type' => $_FILES['common_list']['type'][$common_nav_value]['file_'.$nav_key][$key],
						'tmp_name' => $_FILES['common_list']['tmp_name'][$common_nav_value]['file_'.$nav_key][$key],
						'error' => $_FILES['common_list']['error'][$common_nav_value]['file_'.$nav_key][$key],
						'size' => $_FILES['common_list']['size'][$common_nav_value]['file_'.$nav_key][$key]
					);
					$FileCode = Fn_Upload($images);
					$new_setting[$common_nav_value][$key][$nav_key] = $FileCode['Path'];
				}
			}
		}
		$setting[$common_nav_value] = array_sort($new_setting[$common_nav_value],'displayorder');
	}

	foreach($setting['artisan_group'] as $group){
		$new_artisan_group[$group['id']] = $group; 
	}
	$setting['artisan_group'] = $new_artisan_group;

	foreach($_FILES as $file_key => $file_value){
		if(strpos($file_key,'new_') !== false){
			$key = str_replace(array('TMPnew_','new_'),'',$file_key);
			if($_FILES[$file_key]['size']){
				$FileCode = Fn_Upload($_FILES[$file_key]);
				if($FileCode['Errorcode']){
					cpmsg($Fn_Admin->Config['LangVar']['ImgErr'],'','error');
					exit();
				}else{
					$setting[$key] = $FileCode['Path'];
				}
			}else{
				$file_key = str_replace(array('TMPnew_'),array('new_'),$file_key);
				if(!preg_match('/.*(\.png|\.jpg|\.jpeg|\.gif)$/',$_GET[$file_key]) && $_GET[$file_key]){
					cpmsg($Fn_Admin->Config['LangVar']['ImgErr'],'','error');
					exit();
				}else{
					$setting[$key] = addslashes(strip_tags($_GET[$file_key]));
				}
			}
		}
	}
	savecache($setting_name,$setting);
	fn_cpmsg($Fn_Admin->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
	exit();

}
//From: Dism_taobao_com
?>