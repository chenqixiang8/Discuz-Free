<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('fenlei_all') && !$Fn_Admin->CheckUserGroup('fenlei_temp_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$SubModel = in_array($_GET['submodel'], array('list','add')) ? $_GET['submodel'] : 'list';
$Fn_Admin->Config['IframeSubModelUrl'] = $Fn_Admin->Config['IframeItemUrl'].'&submodel='.$SubModel;
$NavClass = array($SubModel=>'btn-info Hover');

//����
echo <<<Nav
<div class="SubModelNav">
  <ul>
	<li class="{$NavClass['list']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=list" target="_self">{$Fn_Admin->Config['LangVar']['FenleiLeftNavArray'][$_GET['item']]}</a></li>
    <li class="{$NavClass['add']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=add" target="_self">{$Fn_Admin->Config['LangVar']['AddEditTitle']}</a></li>
  </ul>
  <div class="both"></div>
</div>
Nav;

if($SubModel == 'list'){//�б�

	$Do = in_array($_GET['do'], array('del')) ? $_GET['do'] : 'submodel_list';

	$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeSubModelUrl'].'&'.http_build_query($SearArray);

	if($Do == 'submodel_list'){
		if(!submitcheck('Submit')) {
			/* ģ����� */	
			showtagheader('div', 'row', true,'row');
			showtagheader('div', 'col-12', true,'col-12');
			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-body', true,'box-body');
		
			showtagheader('div', 'table-responsive', true,'table-responsive');
			showformheader($FormUrl,'enctype="multipart/form-data"');
			showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
			showsubtitle(array(
				'ID',
				'&#27169;&#26495;&#21517;&#31216;',
				'&#27169;&#26495;&#31867;&#22411;',
				'&#28155;&#21152;&#26102;&#38388;',
				'&#25805;&#20316;'
			),'header tbm tc');
			
			$res = C::t('#fn_fenlei#fn_fenlei_temp')->fetch_all_by_list();
			foreach ($res as $item) {
				showtablerow('', array('class="tc w100"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
					$item['id'],
					$item['title'],
					$fn_fenlei->setting['lang']['temp_type_arr'][$item['type']],
					date('Y-m-d',$item['dateline']),
					'<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&tid='.$item['id'].'" class="btn btn-sm btn-info-outline">'.$fn_fenlei->setting['lang']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=del&tid='.$item['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$fn_fenlei->setting['lang']['DelTitle'].'</a>',
				));
			}
			showtablefooter(); /*dism��taobao��com*/
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			/* ģ�����End */	
		}
	}else if($Do == 'del' && $_GET['formhash'] == formhash() && $_GET['tid']){//ɾ��
		if(!$Fn_Admin->CheckUserGroup('fenlei_all') && !$Fn_Admin->CheckUserGroup('fenlei_temp_list_del')){//Ȩ���ж�
			fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
			exit();
		}
		$id = intval($_GET['tid']);
		C::t('#fn_fenlei#fn_fenlei_temp')->delete_by_id($id);
		GetInsertDoLog('del_temp_fenlei_list','fn_'.$_GET['mod'],array('id'=>$id));//������¼
		fn_cpmsg($fn_fenlei->setting['lang']['DelOk'],$CpMsgUrl,'succeed');
	}
}else if($SubModel == 'add'){//���ӻ�༭
	
	$id = intval($_GET['tid']);

	$item = C::t('#fn_fenlei#fn_fenlei_temp')->fetch_by_id($id);
	if($item){
		
	};
	if(!submitcheck('DetailSubmit')) {
		$opTitle = $fn_fenlei->setting['lang']['AddTitle'];
		if($item){
			$opTitle = $fn_fenlei->setting['lang']['EditTitle'];
			
		}
		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-header', true,'with-border box-header');
		showtitle($opTitle,'class="box-title"');
		showtagfooter('div');
		showformheader($Fn_Admin->Config['IframeSubModelUrl'].'&tid='.$id,'enctype');
		showtagheader('div', 'box-body', true,'box-body');
		
		showsetting('&#27169;&#26495;&#21517;&#31216;', 'title', $item['title'], 'text');

		showsetting('&#27169;&#26495;&#31867;&#22411;',array('type', array(
			array('1','&#21015;&#34920;&#27169;&#26495;', array('type_1' => '','type_2' => 'none')),
			//array('2','&#20869;&#23481;&#27169;&#26495;', array('type_1' => 'none','type_2' => '')),
		), TRUE),$item ? $item['type'] : 1, 'mradio');

		showtagheader('div', 'type_1', $item['type'] == 1 || !$item ? true : '','sub');
			showsetting('&#21015;&#34920;&#27169;&#26495;', 'list_temp', stripslashes($item['temp']), 'textarea','','','&#91;&#45;&#45;&#117;&#114;&#108;&#45;&#45;&#93;&#20195;&#34920;&#38142;&#25509;&#65292;&#91;&#45;&#45;&#117;&#112;&#100;&#97;&#116;&#101;&#108;&#105;&#110;&#101;&#45;&#45;&#93;&#20195;&#34920;&#21047;&#26032;&#26102;&#38388;&#65292;&#91;&#45;&#45;&#100;&#97;&#116;&#101;&#108;&#105;&#110;&#101;&#45;&#45;&#93;&#20195;&#34920;&#21457;&#24067;&#26102;&#38388;&#65292;&#91;&#45;&#45;&#117;&#115;&#101;&#114;&#110;&#97;&#109;&#101;&#45;&#45;&#93;&#20195;&#34920;&#29992;&#25143;&#21517;&#65292;&#91;&#45;&#45;&#102;&#97;&#99;&#101;&#45;&#45;&#93;&#20195;&#34920;&#22836;&#20687;&#65292;&#91;&#45;&#45;&#114;&#111;&#108;&#101;&#45;&#45;&#93;&#20195;&#34920;&#35282;&#33394;&#65292;&#91;&#45;&#45;&#99;&#108;&#97;&#115;&#115;&#95;&#110;&#97;&#109;&#101;&#45;&#45;&#93;&#20195;&#34920;&#20998;&#31867;&#21517;&#31216;&#65292;&#91;&#45;&#45;&#99;&#111;&#110;&#116;&#101;&#110;&#116;&#45;&#45;&#93;&#20195;&#34920;&#20869;&#23481;&#65292;&#91;&#45;&#45;&#97;&#108;&#98;&#117;&#109;&#45;&#45;&#93;&#20195;&#34920;&#22270;&#29255;&#65292;&#91;&#45;&#45;&#116;&#111;&#112;&#95;&#105;&#99;&#111;&#110;&#45;&#45;&#93;&#20195;&#34920;&#32622;&#39030;&#22270;&#26631;&#65292;&#91;&#45;&#45;&#114;&#101;&#103;&#105;&#111;&#110;&#95;&#110;&#97;&#109;&#101;&#45;&#45;&#93;&#20195;&#34920;&#21306;&#22495;&#21517;&#31216;&#65292;&#91;&#45;&#45;&#116;&#104;&#117;&#109;&#98;&#45;&#45;&#93;&#20195;&#34920;&#32553;&#30053;&#22270;&#65292;&#91;&#45;&#45;&#99;&#108;&#105;&#99;&#107;&#45;&#45;&#93;&#20195;&#34920;&#28857;&#20987;&#25968;&#65292;&#91;&#45;&#45;&#34920;&#21333;&#21464;&#37327;&#21517;&#45;&#45;&#93;');
			showsetting('&#25130;&#21462;&#20869;&#23481;&#23383;&#31526;', 'cutst_info_content',$item ? $item['cutst_info_content'] : 80, 'text','','','&#21015;&#34920;&#27169;&#26495;&#25130;&#21462;&#20869;&#23481;&#22810;&#23569;&#20010;&#23383;&#31526;&#65292;&#48;&#47;&#31354;&#20195;&#34920;&#19981;&#25130;&#21462;');
			showsetting('&#20869;&#23481;&#22270;&#29255;&#38480;&#21046;&#24352;&#25968;', 'max_album_num',$item ? $item['max_album_num'] : 3, 'text','','','&#21015;&#34920;&#27169;&#26495;&#30340;&#20869;&#23481;&#22270;&#29255;&#38480;&#21046;&#21152;&#36733;&#22810;&#23569;&#24352;&#65292;&#48;&#47;&#31354;&#20195;&#34920;&#19981;&#38480;&#21046;');
		showtagfooter('div');

		showtagheader('div', 'type_2', $item['type'] == 2 ? true : '','sub');
			showsetting('&#20869;&#23481;&#27169;&#26495;', 'view_temp', stripslashes($item['temp']), 'textarea','','','[--url--]&#20195;&#34920;&#38142;&#25509;&#65292;[--updateline--]&#20195;&#34920;&#21047;&#26032;&#26102;&#38388;&#65292;[--dateline--]&#20195;&#34920;&#21457;&#24067;&#26102;&#38388;&#65292;[--username--]&#20195;&#34920;&#29992;&#25143;&#21517;&#65292;[--name--]&#20195;&#34920;&#32852;&#31995;&#20154;&#65292;[--phone--]&#20195;&#34920;&#30005;&#35805;&#65292;[--face--]&#20195;&#34920;&#22836;&#20687;&#65292;[--role--]&#20195;&#34920;&#35282;&#33394;&#65292;[--class_name--]&#20195;&#34920;&#20998;&#31867;&#21517;&#31216;&#65292;[--content--]&#20195;&#34920;&#20869;&#23481;&#65292;[--album--]&#20195;&#34920;&#22270;&#29255;&#65292;[--click--]&#20195;&#34920;&#27983;&#35272;&#37327;&#65292;[--top_icon--]&#20195;&#34920;&#32622;&#39030;&#22270;&#26631;&#65292;[--followqr--]&#20195;&#34920;&#35814;&#24773;&#20108;&#32500;&#30721;&#65292;[--indexurl--]&#20195;&#34920;&#39318;&#39029;&#38142;&#25509;&#65292;[--puburl--]&#20195;&#34920;&#21457;&#24067;&#38142;&#25509;&#65292;[--view_content_icon--]&#20195;&#34920;&#35814;&#24773;&#22270;&#26631;&#65292;[--view_contact_icon--]&#20195;&#34920;&#32852;&#31995;&#20154;&#22270;&#26631;&#65292;[--view_phone_icon--]&#20195;&#34920;&#30005;&#35805;&#22270;&#26631;&#65292;[--view_report_icon--]&#20195;&#34920;&#20030;&#25253;&#22270;&#26631;&#65292;[--view_home_icon--]&#20195;&#34920;&#35814;&#24773;&#39318;&#39029;&#22270;&#26631;&#65292;[--view_pub_icon--]&#20195;&#34920;&#21457;&#24067;&#22270;&#26631;&#65292;[--view_chat_icon--]&#20195;&#34920;&#32842;&#22825;&#22270;&#26631;&#65292;[--view_share_icon--]&#20195;&#34920;&#20998;&#20139;&#22270;&#26631;<br>&#27880;&#24847;&#65306;&#20197;&#19979;&#20107;&#20214;&#35880;&#24910;&#20351;&#29992;<br>onclick="getPhoneInfo()" &#20195;&#34920;&#28857;&#20987;&#32479;&#35745;&#30005;&#35805;<br>onclick="getChatInfo()" &#20195;&#34920;&#21796;&#36215;APP&#32842;&#22825;&#31383;&#21475;<br>onclick="getShareInfo()" &#20195;&#34920;&#29983;&#25104;&#28023;&#25253;');
		showtagfooter('div');

		if($item){
			showsetting($fn_fenlei->setting['lang']['TimeTitle'], 'dateline',date('Y-m-d H:i',$item['dateline']), 'calendar','','','',1);
		}
	
		showsubmit('DetailSubmit','&#20445;&#23384;&#37197;&#32622;');
		showtagfooter('div');
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');


	}else{
		$data['title'] = addslashes(strip_tags($_GET['title']));
		$data['type'] = intval($_GET['type']);
		$data['temp'] = $data['type'] == 1 ? addslashes($_GET['list_temp']) :  addslashes($_GET['view_temp']);
		$data['cutst_info_content'] = intval($_GET['cutst_info_content']);
		$data['max_album_num'] = intval($_GET['max_album_num']);

		if($item){
			$data['dateline'] = strtotime($_GET['dateline']);
			GetInsertDoLog('edit_temp_fenlei_list','fn_'.$_GET['mod'],array('id'=>$id));//������¼
			C::t('#fn_fenlei#fn_fenlei_temp')->update($data,$id);
		}else{
			$data['dateline'] = time();
			$id = C::t('#fn_fenlei#fn_fenlei_temp')->insert($data);;
			GetInsertDoLog('add_temp_fenlei_list','fn_'.$_GET['mod'],array('id'=>$id));//������¼
		}
		fn_cpmsg($fn_fenlei->setting['lang']['UpdateOk'],$Fn_Admin->Config['IframeItemUrl'].'&submodel=list','succeed');
		exit();
	}
}
//From: Dism_taobao_com
?>