<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('fenlei_all') && !$Fn_Admin->CheckUserGroup('fenlei_wx_export_info')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$allClass = C::t('#fn_fenlei#fn_fenlei_class')->fetch_all_by_list();
$allRegion = C::t('#fn_fenlei#fn_region')->fetch_all_by_list();

if(!submitcheck('DetailSubmit')) {
	$OpTitle = $Fn_Admin->Config['LangVar']['FenleiLeftNavArray'][$_GET['item']];

	showtagheader('div', 'box', true,'box');
	showtagheader('div', 'box-header', true,'with-border box-header');
	showtitle($OpTitle,'class="box-title"');
	showtagfooter('div');
	showformheader($Fn_Admin->Config['IframeSubModelUrl'],'enctype');
	showtagheader('div', 'box-body', true,'box-body');
	
	showsetting('&#20449;&#24687;&#31867;&#22411;',array('export_type', array(
		array('info','&#20449;&#24687;&#21015;&#34920;', array('info' => '')),
	), true),'info', 'mradio');

	showsetting('&#20449;&#24687;&#25490;&#24207;',array('export_sort', array(
		array('updateline','&#21047;&#26032;&#26102;&#38388;'),
		array('dateline','&#21457;&#24067;&#26102;&#38388;'),
	), true),'updateline', 'mradio');

	$export_time_array = array(
		array('0','&#19981;&#38480;'),
		array('1','&#49;&#22825;&#20869;'),
		array('3','3&#22825;&#20869;'),
		array('7','7&#22825;&#20869;'),
		array('15','15&#22825;&#20869;'),
		array('30','1&#20010;&#26376;&#20869;'),
		array('60','2&#20010;&#26376;&#20869;'),
		array('90','3&#20010;&#26376;&#20869;'),
	);
	showsetting('&#26102;&#38388;&#31579;&#36873;', array('export_time',$export_time_array),'0','mradio');
	
	showsetting('&#20449;&#24687;&#25968;&#37327;','export_limit','30','text');
	
	//showsetting('&#26159;&#21542;&#21253;&#21547;&#32622;&#39030;', 'export_top','1','radio');

	//showsetting('&#32622;&#39030;&#25490;&#21069;&#38754;&#65311;', 'export_top_sort','1','radio');

	//showsetting('&#20851;&#38190;&#35789;','keyword','','text');

	showtagheader('div', 'info', true,'sub');
		showsetting('&#36873;&#25321;&#20998;&#31867;', '','',$fn_fenlei->getClassShowSelect($allClass,'new_classid',true,$item['classid'],true));
		showsetting('&#36873;&#25321;&#21306;&#22495;', '','',$fn_fenlei->getRegionShowSelect($allRegion,'new_regionid',true,$item['regionid'],true));
		showsetting($fn_fenlei->setting['lang']['pub_type'],array('pub_type',DyadicArray($fn_fenlei->setting['lang']['pub_type_arr'],'&#19981;&#38480;')),0,'mradio');
		showsetting($fn_fenlei->setting['lang']['pay_state'],array('pay_state',DyadicArray($fn_fenlei->setting['lang']['pay_state_arr'])),1,'mradio');
		showsetting($fn_fenlei->setting['lang']['audit_state'],array('audit_state',DyadicArray($fn_fenlei->setting['lang']['audit_state_arr'])),1,'mradio');
		showsetting($fn_fenlei->setting['lang']['DisplayTitle'], 'display',1, 'radio');
		showsetting($fn_fenlei->setting['lang']['hide'],array('hide',DyadicArray($fn_fenlei->setting['lang']['hide_arr'])),1,'mradio');
	showtagfooter('div');

	
	showsubmit('DetailSubmit','&#31435;&#21363;&#23548;&#20986;');
	showtagfooter('div');
	showformfooter(); /*Dism_taobao-com*/
	showtagfooter('div');
}else{
	$html = '<div id="copy_content">';

	if($fn_fenlei->setting['QrParameterSwitch']){
		@require_once libfile('class/wechat','plugin/fn_assembly');
		$WechatClient = new Fn_WeChatClient($fn_fenlei->setting['WxAppid'],$fn_fenlei->setting['WxSecret']);
	}

	if($_GET['export_type'] == 'info'){//��Ϣ�б�
		
		$res = C::t('#fn_fenlei#fn_fenlei_info')->fetch_all_by_list(array('regionid'=>$_GET['new_regionid'],'classid'=>$_GET['new_classid'],'display'=>$_GET['display'],'hide'=>$_GET['hide'],'pay_state'=>1,'audit_state'=>$_GET['audit_state'],'pub_type'=>$_GET['pub_type']),$_GET['export_sort'],0,$_GET['export_limit'],true,'','');
		
		foreach($res['list'] as $index => $item){
			if($fn_fenlei->setting['QrParameterSwitch']){
				$File = $Config['QrcodePath'].'fn_fenlei_view_info_'.$item['id'].'.jpg';
				if(!file_exists($File) || !filesize($File) || (filesize($File) && file_exists($File) && filemtime($File) + 1296000 <= time())) {
					@unlink($File);
					$QrUrl = $WechatClient->getQrcodeImgUrlByTicket($WechatClient->getQrcodeTicket(array('scene_str'=>'fn_fenlei____view_info____'.$item['id'],'expire'=>2592000)));
					DownloadImg($QrUrl,$File);
				}
				$qrcode_url = $_G['siteurl'].str_replace(DISCUZ_ROOT,'',$File);
			}else{
				$qrcode_url = $_G['siteurl'].'plugin.php?id=fn_assembly:qrcode&url='.base64_encode($fn_fenlei->getUrl('view',array('iid'=>$item['id'])));
			}

			$item['forms'] = $item['forms'] ? dunserialize($item['forms']) : '';
			$item['class_forms'] = $fn_fenlei->_G['cache']['fn_form_fenlei_info'][$item['classid']];
			$classItem = $fn_fenlei->_G['cache']['fn_fenlei_class'][$item['classid']];
		
			$formsReplaceFront = array();
			$formsReplaceAfter = array();
			foreach($item['class_forms'] as $k => $v) {
				$identifier = $item['forms'][$v['identifier']];
				$formsReplaceFront[] = '[--'.$v['identifier'].'--]';
				$formsReplaceAfter[] = $identifier['value'] ? $identifier['content'].$v['unitnew'] : $identifier['content'];
			}
			

			$replaceFront = array_merge(array('[--index--]','[--id--]','[--updateline--]','[--dateline--]','[--username--]','[--role--]','[--class_name--]','[--region_name--]','[--title--]','[--name--]','[--phone--]','[--thumb--]','[--click--]','[--content--]','[--tag--]','[--qr--]'),$formsReplaceFront);

			$replaceAfter = array_merge(array($index+1,$item['id'],$item['updateline'],$item['dateline'],$item['username'],$item['role'],$item['class_name'],$item['region_name'],$item['title'],$item['name'],$item['phone'],$item['thumb'] ? '<img src="'.$item['thumb'].'" style="width:200px">' : '',$item['click'],strip_tags($item['content']),implode('|',$item['tag_arr'] ? dunserialize($item['tag_arr']) : ''),'<img src="'.$qrcode_url.'" style="width:100px;height:100px;">'),$formsReplaceAfter);

			$html .= str_replace($replaceFront,$replaceAfter,stripslashes($classItem['info_wx_temp']));
		}
	}
	if($res['list']){
		$html .= '</div>';
		echo $html;
		exit();
	}else{
		fn_cpmsg('&#26080;&#23548;&#20986;&#20449;&#24687;','','error');
		exit();
	}
	
}
//From: Dism_taobao_com
?>