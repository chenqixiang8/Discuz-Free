<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('fenlei_all') && !$Fn_Admin->CheckUserGroup('fenlei_info_report_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$Do = in_array($_GET['do'], array('Del','State')) ? $_GET['do'] : 'List';

//�����ֶ�
$SearField =array('page','keyword','vid','love_vid','state','type','order');
foreach($SearField as $Val) {
	$SearArray[$Val] = $_GET[$Val] ? $_GET[$Val] : '';
}
//�����ֶ� End

$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeItemUrl'].'&'.http_build_query($SearArray);

if($Do == 'List'){
	if(!submitcheck('Submit')) {
		$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
		$page = $_GET['page'] ? $_GET['page'] : 0;
		$res = C::t('#fn_fenlei#fn_fenlei_info_report')->fetch_all_by_list(array('uid'=>$_GET['uid'],'type'=>$_GET['type'],'state'=>$_GET['state']),'dateline',$page - 1,30,true);
		/* ģ����� */
		showtagheader('div', 'row', true,'row');
		showtagheader('div', 'col-12', true,'col-12');
		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-body', true,'box-body');
		/* ���� */
		$stateSelected = array($_GET['state']=>' selected');
		$type_option = '<option value="">'.$fn_fenlei->setting['lang']['SelectNull'].'</option>';
		foreach($fn_fenlei->setting['lang']['report_arr'] as $key => $val) {
			$type_option .= '<option value="'. $key.'" '.($_GET['type'] ==  $key ? ' selected' : '' ).'>'.$val.'</option>';
		}

		echo <<<SEARCH
		<form method="post" autocomplete="off" action="$SearUrl" id="tb_search">
			<div class="FormSearchTo">
				<table cellspacing="4" cellpadding="4">
					<tr>
						<th>&#20030;&#25253;&#29992;&#25143;&#85;&#73;&#68;</th>
						<td colspan="10"><input type="text" class="input form-control w200" name="uid" value="{$_GET['uid']}" placeholder="&#35831;&#36755;&#20837;&#20030;&#25253;&#29992;&#25143;&#85;&#73;&#68;">
						</td>
						<th>&#20030;&#25253;&#20449;&#24687;&#73;&#68;</th>
						<td><input type="text" class="input form-control w200" name="iid" value="{$_GET['iid']}" placeholder="&#35831;&#36755;&#20837;&#20030;&#25253;&#20449;&#24687;&#73;&#68;">
						</td>
						<th>&#20030;&#25253;&#21407;&#22240;</th><td>
						<select name="type" class="form-control w120">
							{$type_option}
						</select>
						</td>
						<th>&#29366;&#24577;</th><td>
						<select name="state" class="form-control w120">
							<option value="">{$fn_fenlei->setting['lang']['SelectNull']}</option>
							<option value="0"{$stateSelected['0']}>{$fn_fenlei->setting['lang']['report_state_arr'][0]}</option>
							<option value="1"{$stateSelected['1']}>{$fn_fenlei->setting['lang']['report_state_arr'][1]}</option>
						</select>
						&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Admin->Config['LangVar']['SearchSubmit']}" class="btn btn-info" type="submit">
						</td>
					</tr>
				</table>
			</div>
		</form>
SEARCH;
		/* ���� End */
		showtagheader('div', 'table-responsive', true,'table-responsive');
		showformheader($FormUrl,'enctype="multipart/form-data"');
		showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
		showsubtitle(array(
			'ID',
			'&#20030;&#25253;&#29992;&#25143;',
			'&#20030;&#25253;&#29992;&#25143;&#22995;&#21517;',
			'&#20030;&#25253;&#29992;&#25143;&#25163;&#26426;',
			'&#34987;&#20030;&#25253;&#20449;&#24687;',
			'&#20030;&#25253;&#21407;&#22240;',
			'&#20030;&#25253;&#20869;&#23481;',
			'&#29366;&#24577;',
			$fn_fenlei->setting['lang']['TimeTitle'],
			'&#22788;&#29702;&#26102;&#38388;',
			$fn_fenlei->setting['lang']['OperationTitle']
		), 'header tbm tc');
	
		foreach($res['list'] as $item) {
			
			showtablerow('', array('class="tc w100"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
				'<input type="checkbox" class="filled-in" id="checkbox_'.$item['id'].'" name="delete[]" value="'.$item['id'].'"><label for="checkbox_'.$item['id'].'">'.$item['id'].'</label>',
				$item['uid'] ? $item['uid'].'/'.$item['username'] : '',
				$item['name'],
				$item['phone'],
				'&#20449;&#24687;&#73;&#68;&#65306;'.$item['iid'].'&nbsp;<a href="'.$fn_fenlei->getUrl('view',array('iid'=>$item['iid'])).'" target="_blank">[&#26597;&#30475;]</a>',
				$fn_fenlei->setting['lang']['report_arr'][$item['type']],
				$item['content'],
				$item['state'] ? '<span class="label bg-blue">'.$fn_fenlei->setting['lang']['report_state_arr'][$item['state']].'</span>' : '<span class="label bg-danger">'.$fn_fenlei->setting['lang']['report_state_arr'][$item['state']].'</span>',
				date('Y-m-d H:i',$item['dateline']),
				$item['handle_dateline'] ? date('Y-m-d H:i',$item['handle_dateline']) : '',
				'<a href="'.$Fn_Admin->Config['IframeModUrl'].'&item=info_list&submodel=list&iid='.$item['iid'].'" class="btn btn-sm btn-dark-outline">&#31649;&#29702;&#20449;&#24687;</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=State&rid='.$item['id'].'&value='.(!empty($item['state']) ? 0:1).'&formhash='.FORMHASH.'" class="btn btn-sm btn-info-outline">&#35774;&#32622;'.(!empty($item['state']) ? $fn_fenlei->setting['lang']['report_state_arr'][0] : $fn_fenlei->setting['lang']['report_state_arr'][1]).'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Del&rid='.$item['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$fn_fenlei->setting['lang']['DelTitle'].'</a>',
			));
		}
		showsubmit('Submit','&#31435;&#21363;&#25552;&#20132;','<input name="optype" value="State" class="with-gap" type="radio" id="v_state"><label class="custom-control-label" for="v_state">&#29366;&#24577;</label>&nbsp;<select name="statenew" class="form-control w120"><option value="">'.$fn_fenlei->setting['lang']['SelectNull'].'</option><option value="1">'.$fn_fenlei->setting['lang']['report_state_arr'][1].'</option><option value="0">'.$fn_fenlei->setting['lang']['report_state_arr'][0].'</option></select>&nbsp;&nbsp;&nbsp;&nbsp;<input name="optype" value="Del" class="with-gap" type="radio" id="v_del"><label class="custom-control-label" for="v_del" style="margin-left:-5px;">'.$fn_fenlei->setting['lang']['DelTitle'].'</label>','','select_all',multi($res['count'],30,$page,$MpUrl));
		showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		/* ģ����� End */
	}else{
		if(isset($_GET['delete']) && is_array($_GET['delete'])){
			if($_GET['optype'] == 'Del'){//ȫɾ
				foreach($_GET['delete'] as $k => $v) {
					$id = intval($v);
					C::t('#fn_fenlei#fn_fenlei_info_report')->delete_by_id($id);
				}
				GetInsertDoLog('del_info_report_fenlei','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete'])));//������¼
				fn_cpmsg($fn_fenlei->setting['lang']['DelOk'],$CpMsgUrl,'succeed');
			}else if($_GET['optype'] == 'State' && in_array($_GET['statenew'],array('0','1'))){
				foreach($_GET['delete'] as $k => $v) {
					$id = intval($v);
					$data['state'] = intval($_GET['statenew']);
					$data['handle_dateline'] = time();
					C::t('#fn_fenlei#fn_fenlei_info_report')->update($data,$id);
				}
				GetInsertDoLog('state_info_report_fenlei','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete']),'state'=>$_GET['statenew']));//������¼
				fn_cpmsg($fn_fenlei->setting['lang']['UpdateOk'],$CpMsgUrl,'succeed');
			}else{
				fn_cpmsg($fn_fenlei->setting['lang']['DelErr'],'','error');
			}
		}else{
			fn_cpmsg($fn_fenlei->setting['lang']['DelErr'],'','error');
		}
	}
}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['rid']){//ɾ��
	$id = intval($_GET['rid']);
	C::t('#fn_fenlei#fn_fenlei_info_report')->delete_by_id($id);
	GetInsertDoLog('del_info_report_fenlei','fn_'.$_GET['mod'],array('id'=>$id));//������¼
	fn_cpmsg($fn_fenlei->setting['lang']['DelOk'],$CpMsgUrl,'succeed');
}else if($Do == 'State' && $_GET['formhash'] == formhash() && $_GET['rid']){
	$id = intval($_GET['rid']);
	$data['state'] = intval($_GET['value']);
	$data['handle_dateline'] = time();
	C::t('#fn_fenlei#fn_fenlei_info_report')->update($data,$id);
	GetInsertDoLog('state_info_report_fenlei','fn_'.$_GET['mod'],array('id'=>$_GET['rid'],'state'=>$_GET['value']));//������¼
	fn_cpmsg($fn_fenlei->setting['lang']['UpdateOk'],$CpMsgUrl,'succeed');
}
//From: Dism_taobao_com
?>