<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('job_all') && !$Fn_Admin->CheckUserGroup('job_wx_export_info')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

if(!submitcheck('DetailSubmit')) {
	$OpTitle = $Fn_Admin->Config['LangVar']['JobLeftNavArray'][$_GET['item']];

	showtagheader('div', 'box', true,'box');
	showtagheader('div', 'box-header', true,'with-border box-header');
	showtitle($OpTitle,'class="box-title"');
	showtagfooter('div');
	showformheader($Fn_Admin->Config['IframeSubModelUrl'],'enctype');
	showtagheader('div', 'box-body', true,'box-body');
	
	showsetting('&#20449;&#24687;&#31867;&#22411;',array('export_type', array(
		array('job','&#32844;&#20301;&#21015;&#34920;', array('job' => '','resume' => 'none','company' => 'none')),
		array('resume','&#31616;&#21382;&#21015;&#34920;', array('job' => 'none','resume' => '','company' => 'none')),
		array('company','&#20844;&#21496;&#21015;&#34920;', array('job' => 'none','resume' => 'none','company' => '')),
	), true),'job', 'mradio');

	showsetting('&#20449;&#24687;&#25490;&#24207;',array('export_sort', array(
		array('updateline','&#21047;&#26032;&#26102;&#38388;'),
		array('dateline','&#21457;&#24067;&#26102;&#38388;'),
	), true),'updateline', 'mradio');

	$export_time_array = array(
		array('0','&#19981;&#38480;'),
		array('1','&#49;&#22825;&#20869;'),
		array('3','3&#22825;&#20869;'),
		array('7','7&#22825;&#20869;'),
		array('15','15&#22825;&#20869;'),
		array('30','1&#20010;&#26376;&#20869;'),
		array('60','2&#20010;&#26376;&#20869;'),
		array('90','3&#20010;&#26376;&#20869;'),
	);
	showsetting('&#26102;&#38388;&#31579;&#36873;', array('export_time',$export_time_array),'0','mradio');
	
	showsetting('&#20449;&#24687;&#25968;&#37327;','export_limit','30','text');
	
	showsetting('&#26159;&#21542;&#21253;&#21547;&#32622;&#39030;', 'export_top','1','radio');

	showsetting('&#32622;&#39030;&#25490;&#21069;&#38754;&#65311;', 'export_top_sort','1','radio');

	//showsetting('&#20851;&#38190;&#35789;','keyword','','text');

	showtagheader('div', 'job', true,'sub');
		
		showsetting('&#25351;&#23450;&#20844;&#21496;ID','company_ids','','text','','','&#35831;&#36755;&#20837;&#20844;&#21496;&#73;&#68;&#65292;&#26684;&#24335;&#65306;&#49;&#44;&#50;&#44;&#51;');
		
		$ClassListHtml = GetTreelistHtml($Fn_Job->ClassList,'ClassList');//С��λ��

		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_Job->Config['LangVar']['JobCategory'].':</label><div class="col-sm-2"><div style="position:relative;height:40px"><input value="" placeholder="&#35831;&#36873;&#25321;&#32844;&#20301;&#31867;&#21035;" class="input form-control TreeList" type="text" id="ClassListClick">'.$ClassListHtml.'</div></div><div class="col-sm-7"><input type="hidden" name="bbclassid" value=""/><input type="hidden" name="bclassid" value=""/><input type="hidden" name="classid" value=""/></div></div>';

		showsetting('&#32844;&#20301;&#31867;&#22411;',array('info_type', array(
			array('0','&#19981;&#38480;', array('info_type_1' => '','info_type_2' => '')),
			array('1','&#20840;&#32844;', array('info_type_1' => '','info_type_2' => 'none')),
			array('2','&#20860;&#32844;', array('info_type_1' => 'none','info_type_2' => '')),
		), true),'1', 'mradio');

		showtagheader('div', 'info_type_1', true,'sub');
			showsetting('&#20840;&#32844;&#27169;&#26495;', 'job_temp_1', $Fn_Job->Config['PluginVar']['WxTemplate'],'textarea','','','&#123;&#116;&#105;&#116;&#108;&#101;&#125;&#20195;&#34920;&#26631;&#39064;&#65292;&#123;&#99;&#108;&#97;&#115;&#115;&#125;&#20195;&#34920;&#20998;&#31867;&#65292;&#123;&#99;&#111;&#109;&#112;&#97;&#110;&#121;&#95;&#110;&#97;&#109;&#101;&#125;&#20195;&#34920;&#20844;&#21496;&#21517;&#23383;&#65292;&#123;&#97;&#100;&#100;&#114;&#101;&#115;&#115;&#125;&#20195;&#34920;&#22320;&#22336;&#65292;&#123;&#109;&#111;&#110;&#116;&#104;&#95;&#119;&#97;&#103;&#101;&#115;&#125;&#20195;&#34920;&#26376;&#34218;&#65292;&#123;&#101;&#100;&#117;&#99;&#97;&#116;&#105;&#111;&#110;&#125;&#20195;&#34920;&#23398;&#21382;&#35201;&#27714;&#65292;&#123;&#101;&#120;&#112;&#101;&#114;&#105;&#101;&#110;&#99;&#101;&#125;&#20195;&#34920;&#24037;&#20316;&#32463;&#39564;&#65292;&#123;&#113;&#114;&#125;&#20195;&#34920;&#20108;&#32500;&#30721;&#38142;&#25509;&#65292;&#123;&#108;&#105;&#110;&#107;&#125;&#20195;&#34920;&#38142;&#25509;&#65292;&#123;&#109;&#111;&#98;&#105;&#108;&#101;&#125;&#20195;&#34920;&#32852;&#31995;&#26041;&#24335;&#65292;&#123;&#99;&#111;&#110;&#116;&#101;&#110;&#116;&#125;&#20195;&#34920;&#25551;&#36848;');
		showtagfooter('div');
		
		showtagheader('div', 'info_type_2', '','sub');
			showsetting('&#20860;&#32844;&#27169;&#26495;', 'job_temp_2', $Fn_Job->Config['PluginVar']['WxTemplate2'],'textarea','','','&#123;&#116;&#105;&#116;&#108;&#101;&#125;&#20195;&#34920;&#26631;&#39064;&#65292;&#123;&#99;&#108;&#97;&#115;&#115;&#125;&#20195;&#34920;&#20998;&#31867;&#65292;&#123;&#99;&#111;&#109;&#112;&#97;&#110;&#121;&#95;&#110;&#97;&#109;&#101;&#125;&#20195;&#34920;&#20844;&#21496;&#21517;&#23383;&#65292;&#123;&#97;&#100;&#100;&#114;&#101;&#115;&#115;&#125;&#20195;&#34920;&#22320;&#22336;&#65292;&#123;&#109;&#111;&#110;&#116;&#104;&#95;&#119;&#97;&#103;&#101;&#115;&#125;&#20195;&#34920;&#26376;&#34218;&#65292;&#123;&#101;&#100;&#117;&#99;&#97;&#116;&#105;&#111;&#110;&#125;&#20195;&#34920;&#23398;&#21382;&#35201;&#27714;&#65292;&#123;&#101;&#120;&#112;&#101;&#114;&#105;&#101;&#110;&#99;&#101;&#125;&#20195;&#34920;&#24037;&#20316;&#32463;&#39564;&#65292;&#123;&#113;&#114;&#125;&#20195;&#34920;&#20108;&#32500;&#30721;&#38142;&#25509;&#65292;&#123;&#108;&#105;&#110;&#107;&#125;&#20195;&#34920;&#38142;&#25509;&#65292;&#123;&#109;&#111;&#98;&#105;&#108;&#101;&#125;&#20195;&#34920;&#32852;&#31995;&#26041;&#24335;&#65292;&#123;&#99;&#111;&#110;&#116;&#101;&#110;&#116;&#125;&#20195;&#34920;&#25551;&#36848;');
		showtagfooter('div');

	showtagfooter('div');

	showtagheader('div', 'resume', '','sub');
		showsetting('&#31616;&#21382;&#27169;&#26495;', 'resume_temp', $Fn_Job->Config['PluginVar']['ResumeWxTemplate'],'textarea','','','&#123;&#110;&#97;&#109;&#101;&#125;&#20195;&#34920;&#22995;&#21517;&#65292;&#123;&#109;&#111;&#98;&#105;&#108;&#101;&#125;&#20195;&#34920;&#30005;&#35805;&#65292;&#123;&#115;&#101;&#120;&#125;&#20195;&#34920;&#24615;&#21035;&#65292;&#123;&#97;&#103;&#101;&#125;&#20195;&#34920;&#24180;&#40836;&#65292;&#123;&#101;&#100;&#117;&#99;&#97;&#116;&#105;&#111;&#110;&#125;&#20195;&#34920;&#23398;&#21382;&#65292;&#123;&#101;&#120;&#112;&#101;&#114;&#105;&#101;&#110;&#99;&#101;&#125;&#20195;&#34920;&#32463;&#39564;&#65292;&#123;&#101;&#120;&#112;&#101;&#99;&#116;&#95;&#106;&#111;&#98;&#125;&#20195;&#34920;&#26399;&#26395;&#32844;&#20301;&#65292;&#123;&#101;&#120;&#112;&#101;&#99;&#116;&#95;&#109;&#111;&#110;&#116;&#104;&#95;&#119;&#97;&#103;&#101;&#115;&#125;&#20195;&#34920;&#26399;&#26395;&#26376;&#34218;&#65292;&#123;&#101;&#120;&#112;&#101;&#99;&#116;&#95;&#97;&#100;&#100;&#114;&#101;&#115;&#115;&#125;&#20195;&#34920;&#26399;&#26395;&#21306;&#22495;&#65292;&#123;&#116;&#97;&#103;&#125;&#20195;&#34920;&#20010;&#20154;&#20142;&#28857;&#65292;&#123;&#113;&#114;&#125;&#20195;&#34920;&#20108;&#32500;&#30721;&#38142;&#25509;&#65292;&#123;&#108;&#105;&#110;&#107;&#125;&#20195;&#34920;&#38142;&#25509;&#65292;&#123;&#99;&#111;&#110;&#116;&#101;&#110;&#116;&#125;&#20195;&#34920;&#25551;&#36848;');
	showtagfooter('div');

	showtagheader('div', 'company', '','sub');

		showsetting('&#26159;&#21542;&#35748;&#35777;',array('company_verify', array(
			array('0','&#19981;&#38480;'),
			array('1','&#26159;'),
		), true),'0', 'mradio');

		showsetting('&#26159;&#21542;&#20250;&#21592;',array('company_vip', array(
			array('0','&#19981;&#38480;', array('company_vip_1' => 'none')),
			array('1','&#26159;', array('company_vip_1' => '')),
		), true),'0', 'mradio');
		
		showtagheader('div', 'company_vip_1', '','sub');
			$CompanyGroupArray[] = array(0,'&#19981;&#38480;');
			foreach($Fn_Job->GetCompanyGroupList() as $key => $val) {
				$CompanyGroupArray[] = array($val['id'],$val['title']);
			}
			showsetting('&#20844;&#21496;&#32423;&#21035;', array('company_group_id',$CompanyGroupArray),'0','mradio');
		showtagfooter('div');
		
		showsetting('&#25351;&#23450;&#20844;&#21496;ID','company_id','','text','','','&#35831;&#36755;&#20837;&#20844;&#21496;&#73;&#68;&#65292;&#26684;&#24335;&#65306;&#49;&#44;&#50;&#44;&#51;');

		$CompanyClassArray[] = array(0,'&#19981;&#38480;');
		foreach($Fn_Job->Config['LangVar']['CompanyClassArray'] as $key => $val) {
			$CompanyClassArray[] = array($key,$val);
		}
		showsetting('&#20844;&#21496;&#20998;&#31867;', array('company_classid',$CompanyClassArray),'0','select');

		showsetting('&#32844;&#20301;&#25968;&#37327;','company_job_limit','5','text');

		showsetting('&#20844;&#21496;&#27169;&#26495;', 'company_temp', $Fn_Job->Config['PluginVar']['CompanyWxTemplate'],'textarea','','','&#123;&#110;&#97;&#109;&#101;&#125;&#20195;&#34920;&#20844;&#21496;&#21517;&#31216;&#65292;&#123;&#109;&#111;&#98;&#105;&#108;&#101;&#125;&#20195;&#34920;&#30005;&#35805;&#65292;&#123;&#115;&#99;&#97;&#108;&#101;&#125;&#20195;&#34920;&#35268;&#27169;&#65292;&#123;&#99;&#108;&#97;&#115;&#115;&#125;&#20195;&#34920;&#20998;&#31867;&#65292;&#123;&#99;&#111;&#110;&#116;&#101;&#110;&#116;&#125;&#20195;&#34920;&#20869;&#23481;&#65292;&#123;&#116;&#97;&#103;&#125;&#20195;&#34920;&#31119;&#21033;&#65292;&#123;&#106;&#111;&#98;&#95;&#108;&#105;&#115;&#116;&#125;&#20195;&#34920;&#22312;&#25307;&#32844;&#20301;&#21015;&#34920;&#65292;&#123;&#113;&#114;&#125;&#20195;&#34920;&#20108;&#32500;&#30721;&#38142;&#25509;&#65292;&#123;&#108;&#105;&#110;&#107;&#125;&#20195;&#34920;&#38142;&#25509;');
	showtagfooter('div');
	
	showsubmit('DetailSubmit','&#31435;&#21363;&#23548;&#20986;');
	showtagfooter('div');
	showformfooter(); /*Dism_taobao-com*/
	showtagfooter('div');

	echo '<script src="source/plugin/fn_assembly/static/js/mobiscroll.custom-2.16.1.min.js"></script><link rel="stylesheet" href="source/plugin/fn_assembly/static//css/mobiscroll.custom-2.16.1.min.css">';
		
	echo '
		<script>
		$(document).on("click","#ClassListClick",function(){
			GetTreeList($(this),"ClassList","bbclassid","bclassid","classid");
			return false;
		});
		</script> 	
	';
}else{
	$html = '<div id="copy_content">';

	if($Fn_Job->Config['PluginVar']['QrParameterSwitch']){
		@require_once libfile('class/wechat','plugin/fn_assembly');
		$WechatClient = new Fn_WeChatClient($Fn_Job->Config['PluginVar']['WxAppid'], $Fn_Job->Config['PluginVar']['WxSecret']);
	}
	if($_GET['export_type'] == 'job'){//ְλ
		$where = ' where I.display = 1 and I.payment_state = 1 and I.hide = 1';

		if($Fn_Job->Config['PluginVar']['ExpiryTime']){
			$where .= ' and ( I.updateline >= '.strtotime("-".intval($Fn_Job->Config['PluginVar']['ExpiryTime'])." day",time()).' or I.topdateline >= '.time().' ) ';
		}

		if($_GET['export_time'] == 1){
			$where .= ' and (I.'.$_GET['export_sort'].' >= '.strtotime(date('Y-m-d')).' and I.'.$_GET['export_sort'].' <='.strtotime(date('Y-m-d 23:59:59')).($_GET['export_top'] ? ' or I.topdateline > '.time() : '').')';
		}else if($_GET['export_time']){
			$where .= ' and (I.'.$_GET['export_sort'].' >= '.strtotime("-".$_GET['export_time']." day",time()).($_GET['export_top'] ? ' or I.topdateline > '.time() : '').')';
		}
		if($_GET['company_ids']){
			$where .= ' and I.company_id in ('.$_GET['company_ids'].')';
		}

		if($_GET['info_type']){
			$where .= ' and I.class = '.intval($_GET['info_type']);
		}

		if($_GET['bbclassid']){
			$where .= ' and I.bbclassid = \''.addslashes(strip_tags($_GET['bbclassid'])).'\'';
			if($_GET['bclassid']){
				$where .= ' and I.bclassid = \''.addslashes(strip_tags($_GET['bclassid'])).'\'';
				if($_GET['classid']){
					$where .= ' and I.classid = \''.addslashes(strip_tags($_GET['classid'])).'\'';
				}
			}
		}

		$ModulesList = $Fn_Job->InfoListFormat(DB::fetch_all('SELECT I.*,C.name,C.content as c_content,C.param as c_param,C.due_time,C.logo,C.type as c_type,C.contacts as c_contacts FROM '.DB::table($Fn_Job->TableInfo).' I LEFT JOIN `'.DB::table($Fn_Job->TableCompany).'` C on C.id = I.company_id '.$where.' order by '.($_GET['export_top_sort'] ? 'I.topdateline > '.time().' desc,' : '').'I.'.$_GET['export_sort'].' desc,I.id desc limit 0 ,'.intval($_GET['export_limit'])));
	
		foreach($ModulesList as $Module){
			if($Fn_Job->Config['PluginVar']['QrParameterSwitch']){
				$File = $Config['QrcodePath'].'fn_job_view_job_'.$Module['id'].'.jpg';
				if(!file_exists($File) || !filesize($File) || (filesize($File) && file_exists($File) && filemtime($File) + 1296000 <= time())) {
					@unlink($File);
					$QrUrl = $WechatClient->getQrcodeImgUrlByTicket($WechatClient->getQrcodeTicket(array('scene_str'=>'fn_job____view_job____'.$Module['id'],'expire'=>2592000)));
					DownloadImg($QrUrl,$File);
				}
				$qrcode_url = $_G['siteurl'].str_replace(DISCUZ_ROOT,'',$File);
			}else{
				$qrcode_url = $_G['siteurl'].'plugin.php?id=fn_assembly:qrcode&url='.base64_encode($Fn_Job->Config['ViewJobUrl'].$Module['id']);
			}
			$html .= str_replace(array('{id}','{title}','{class}','{company_name}','{address}','{month_wages}','{education}','{experience}','{settlement}','{cycle}','{qr}','{link}','{mobile}','{content}','{contacts}','{tag}'),array($Module['id'],$Module['title'],$Module['classid_min_text'],$Module['name'],$Module['province_text'].'['.$Module['community'].']',$Module['month_wages_text'],$Module['education_text'],$Module['experience_text'],$Module['settlement_text'],$Module['cycle_text'],$qrcode_url,$Fn_Job->Config['ViewJobUrl'].$Module['id'],$Module['mobile'],strip_tags($Module['contents']),$Module['c_contacts'],implode('|',$Module['param']['tag_list'])),$_GET['job_temp_'.$Module['class']]);
		}
	}else if($_GET['export_type'] == 'resume'){
		$where = ' where R.display = 1 and state in(1,3)';
		if($_GET['export_time'] == 1){
			$where .= ' and (R.'.$_GET['export_sort'].' >= '.strtotime(date('Y-m-d')).' and R.'.$_GET['export_sort'].' <='.strtotime(date('Y-m-d 23:59:59')).($_GET['export_top'] ? ' or R.topdateline > '.time() : '').')';
		}else if($_GET['export_time']){
			$where .= ' and (R.'.$_GET['export_sort'].' >= '.strtotime("-".$_GET['export_time']." day",time()).($_GET['export_top'] ? ' or R.topdateline > '.time() : '').')';
		}
		$ModulesList = $Fn_Job->ResumeListFormat(DB::fetch_all('SELECT R.* FROM '.DB::table($Fn_Job->TableResume).' R '.$where.' order by '.($_GET['export_top_sort'] ? 'R.topdateline > '.time().' desc,' : '').'R.'.$_GET['export_sort'].' desc,R.id desc limit 0 ,'.intval($_GET['export_limit'])));

		foreach($ModulesList as $Module){
			if($Fn_Job->Config['PluginVar']['QrParameterSwitch']){
				$File = $Config['QrcodePath'].'fn_job_view_resume_'.$Module['uid'].'.jpg';
				if(!file_exists($File) || !filesize($File) || (filesize($File) && file_exists($File) && filemtime($File) + 1296000 <= time())) {
					@unlink($File);
					$QrUrl = $WechatClient->getQrcodeImgUrlByTicket($WechatClient->getQrcodeTicket(array('scene_str'=>'fn_job____view_resume____'.$Module['uid'],'expire'=>2592000)));
					DownloadImg($QrUrl,$File);
				}
				$qrcode_url = $_G['siteurl'].str_replace(DISCUZ_ROOT,'',$File);
			}else{
				$qrcode_url = $_G['siteurl'].'plugin.php?id=fn_assembly:qrcode&url='.base64_encode($Fn_Job->Config['ViewResumeUrl'].$Module['uid']);
			}
			$html .= str_replace(array('{name}','{mobile}','{sex}','{age}','{education}','{experience}','{expect_job}','{expect_month_wages}','{expect_address}','{tag}','{content}','{qr}','{link}'),array($Module['full_name'],$Module['mobile'],$Module['sex_text'],$Module['age'],$Module['education_text'],$Module['experience_text'],$Module['expect_job'],$Module['expect_month_wages_text'],$Module['expect_province_text'],implode('|',$Module['param']['tag_list']),strip_tags($Module['content']),$qrcode_url,$Fn_Job->Config['ViewResumeUrl'].$Module['uid']),$_GET['resume_temp']);
			
		}
	}else if($_GET['export_type'] == 'company'){
		$where = ' where C.display = 1';
		if($_GET['export_time'] == 1){
			$where .= ' and (C.'.$_GET['export_sort'].' >= '.strtotime(date('Y-m-d')).' and C.'.$_GET['export_sort'].' <='.strtotime(date('Y-m-d 23:59:59')).($_GET['export_top'] ? ' or C.topdateline > '.time() : '').')';
		}else if($_GET['export_time']){
			$where .= ' and (C.'.$_GET['export_sort'].' >= '.strtotime("-".$_GET['export_time']." day",time()).($_GET['export_top'] ? ' or C.topdateline > '.time() : '').')';
		}

		if($_GET['company_id']){
			$where .= ' and C.id in ('.$_GET['company_id'].')';
		}

		if($_GET['company_verify']){
			$where .= ' and C.verify = '.intval($_GET['company_verify']);
		}

		if($_GET['company_classid']){
			$where .= ' and C.classid = '.intval($_GET['company_classid']);
		}

		if($_GET['company_classid']){
			$where .= ' and C.classid = '.intval($_GET['company_classid']);
		}

		if($_GET['company_vip']){
			$where .= ' and C.due_time >= '.time();
			if($_GET['company_group_id']){
				$where .= ' and C.group_id = '.intval($_GET['company_group_id']);
			}
		}

		$ModulesList = $Fn_Job->CompanyListFormat(DB::fetch_all('SELECT C.*,AG.title,AG.ico,AGL.day_refresh_count,AGL.day_info_count,AGL.info_count,AGL.resume_count,AGL.resume_day_count,AGL.examine,AGL.refresh_count,AGL.top_discount FROM '.DB::table($Fn_Job->TableCompany).' C LEFT JOIN `'.DB::table($Fn_Job->TableCompanyGroup).'` AG on AG.id = C.group_id LEFT JOIN `'.DB::table($Fn_Job->TableCompanyGroupLog).'` AGL on AGL.company_id = C.id '.$where.' order by '.($_GET['export_top_sort'] ? '(C.due_time > '.time().' and C.vip_stop = 0) desc,' : '').'C.topdateline > '.time().' desc,C.'.$_GET['export_sort'].' desc,C.id desc limit 0 ,'.intval($_GET['export_limit'])),'',$_GET['company_job_limit']);
		
		
		foreach($ModulesList as $Module){
			if($Fn_Job->Config['PluginVar']['QrParameterSwitch']){
				$File = $Config['QrcodePath'].'fn_job_view_company_'.$Module['id'].'.jpg';
				if(!file_exists($File) || !filesize($File) || (filesize($File) && file_exists($File) && filemtime($File) + 1296000 <= time())) {
					@unlink($File);
					$QrUrl = $WechatClient->getQrcodeImgUrlByTicket($WechatClient->getQrcodeTicket(array('scene_str'=>'fn_job____view_company____'.$Module['id'],'expire'=>2592000)));
					DownloadImg($QrUrl,$File);
				}
				$qrcode_url = $_G['siteurl'].str_replace(DISCUZ_ROOT,'',$File);
			}else{
				$qrcode_url = $_G['siteurl'].'plugin.php?id=fn_assembly:qrcode&url='.base64_encode($Fn_Job->Config['ViewCompanyUrl'].$Module['id']);
			}
			
			$info_list = '';
			foreach($Module['info_list'] as $key => $val) {
				$info_list .= ($key ? "<br>" : '').$val['title'].'---'.$val['month_wages_text'];
			}
			$replaceArray = array('{name}','{mobile}','{address}','{scale}','{class}','{content}','{tag}','{job_list}','{qr}','{link}');
			$isreplaceArray = array($Module['name'],$Module['mobile'],$Module['province_text'].'['.$Module['community'].']',$Module['scale_text'],$Module['class_text'],strip_tags($Module['content']),implode('|',$Module['param']['tag_list']),$info_list,$qrcode_url,$Fn_Job->Rewrite('view_company',array('cid'=>$Module['id'])));
			$html .= $Module['info_list'] ? str_replace($replaceArray,$isreplaceArray,$_GET['company_temp']) : '';
			
		}


	}
	if($ModulesList){
		$html .= '</div>';
		echo $html;
		exit();
	}else{
		fn_cpmsg('&#26080;&#23548;&#20986;&#20449;&#24687;','','error');
		exit();
	}
	
}
//From: Dism_taobao_com
?>