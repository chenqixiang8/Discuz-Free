<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('job_all') && !$Fn_Admin->CheckUserGroup('job_company_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$SubModel = in_array($_GET['submodel'], array('list','add')) ? $_GET['submodel'] : 'list';
$Fn_Admin->Config['IframeSubModelUrl'] = $Fn_Admin->Config['IframeItemUrl'].'&submodel='.$SubModel;
$NavClass = array($SubModel=>'btn-info Hover');

//����
echo <<<Nav
<div class="SubModelNav">
  <ul>
	<li class="{$NavClass['list']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=list" target="_self">{$Fn_Admin->Config['LangVar']['JobLeftNavArray']['company_list']}</a></li>
    <li class="{$NavClass['add']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=add" target="_self">{$Fn_Admin->Config['LangVar']['AddEditTitle']}</a></li>
  </ul>
  <div class="both"></div>
</div>
Nav;

if($SubModel == 'list'){//�б�
	$Do = in_array($_GET['do'], array('Refresh','Del','Display','VipStop','Verify','AllRefreshJob')) ? $_GET['do'] : 'submodel_list';
	//�����ֶ�
	$SearField =array('page','keyword','agent_id','display','vip_stop','verify','vip','expired','order','group_id','classid','mobile');
	foreach($SearField as $Val) {
		$SearArray[$Val] = $_GET[$Val] || in_array($_GET[$Val],array('0')) ? $_GET[$Val] : '';
	}
	//�����ֶ� End
	$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeSubModelUrl'].'&'.http_build_query($SearArray);


	if($Do == 'submodel_list'){
		if(!submitcheck('Submit')) {
			$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
			$Where = '';
			$Order = $_GET['order'] ? 'C.'.addslashes(dhtmlspecialchars($_GET['order'])) : 'C.id';
			
			if($_GET['keyword']){
				$_GET['keyword'] = str_replace(array('%','_'),array('',''),$_GET['keyword']);
				$Where .= ' and (C.name like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or C.remarks like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or C.id = '.intval($_GET['keyword']).' )';
			}

			if($_GET['mobile']){
				$Where .= ' and C.mobile like(\'%'.addslashes(strip_tags($_GET['mobile'])).'%\')';
			}

//			if($_GET['company_id']){
//				$Where .= ' and C.id = '.intval($_GET['company_id']);
//			}

			if($_GET['group_id']){
				$Where .= ' and C.group_id = '.intval($_GET['group_id']).' and due_time >= '.time();
			}

			if(in_array($_GET['vip'],array('0','1'))){
				
				$Where .= $_GET['vip'] == 1 ? ' and C.due_time >= '.time() : ' and C.due_time < '.time();
			}

			if(in_array($_GET['expired'],array('1'))){
				
				$Where .=  ' and C.due_time != \'\' and C.due_time < '.time();
			}

			if(in_array($_GET['verify'],array('0','1'))){
				$Where .= ' and C.verify = '.intval($_GET['verify']);
			}
			
			if(in_array($_GET['vip_stop'],array('0','1'))){
				$Where .= ' and C.vip_stop = '.intval($_GET['vip_stop']);
			}

			if($_GET['classid']){
				$Where .= ' and C.classid = '.intval($_GET['classid']);
			}

			if(in_array($_GET['display'],array('0','1'))){
				$Where .= ' and C.display = '.intval($_GET['display']);
			}

			$Where = preg_replace('/and/','where',$Where,1);
			$Limit = 20;
			$Page = $_GET['page']?intval($_GET['page']):1;
			/* ��ѯ���� End */
			

			/* ģ����� */	
			showtagheader('div', 'row', true,'row');
			showtagheader('div', 'col-12', true,'col-12');
			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-body', true,'box-body');
			/* ���� */
			$VipSelected = array($_GET['vip']=>' selected');
			$ExpiredSelected = array($_GET['expired']=>' selected');
			$VerifySelected = array($_GET['verify']=>' selected');
			$VipStopSelected = array($_GET['vip_stop']=>' selected');
			$DisplaySelected = array($_GET['display']=>' selected');
			$OrderSelected = array($_GET['order']=>' selected');
			$GroupListOption = '<option value="">'.$Fn_Job->Config['LangVar']['SelectNull'].'</option>';
			foreach($Fn_Job->GetCompanyGroupList() as $Val) {
				$GroupListOption .= '<option value="'.$Val['id'].'" '.($_GET['group_id'] == $Val['id'] ? ' selected' : '' ).'>'.$Val['title'].'</option>';
			}

			$ClassListOption = '<option value="">'.$Fn_Job->Config['LangVar']['SelectNull'].'</option>';
			foreach($Fn_Job->Config['LangVar']['CompanyClassArray'] as $Key => $Val) {
				$ClassListOption .= '<option value="'.$Key.'" '.($_GET['classid'] == $Key ? ' selected' : '' ).'>'.$Val.'</option>';
			}

			echo <<<SEARCH
			<form method="post" autocomplete="off" action="$SearUrl">
				<div class="FormSearchTo" style="margin-bottom:0;">
					<table cellspacing="4" cellpadding="4">
						<tr>
							<th>{$Fn_Job->Config['LangVar']['KeywordTitle']}</th><td colspan="10"><input type="text" class="input form-control w300" name="keyword" value="{$_GET['keyword']}" placeholder="&#35831;&#36755;&#20837;&#20844;&#21496;&#73;&#68;&#47;&#20844;&#21496;&#21517;">
							&nbsp;&nbsp;&#25163;&#26426;&#21495;&nbsp;&nbsp;<input type="text" class="input form-control w120" name="mobile" value="{$_GET['mobile']}" placeholder="&#35831;&#36755;&#20837;&#25163;&#26426;&#21495;">
							</td>
						</tr>

						<tr>
							<th>{$Fn_Job->Config['LangVar']['Level']}</th><td>
							<select name="group_id" class="form-control w100">
								{$GroupListOption}
							</select>
							</td>
							<th>{$Fn_Job->Config['LangVar']['ISVIP']}</th><td>
							<select name="vip" class="form-control w100">
								<option value="">{$Fn_Job->Config['LangVar']['SelectNull']}</option>
								<option value="1"{$VipSelected['1']}>{$Fn_Job->Config['LangVar']['Yes']}</option>
								<option value="0"{$VipSelected['0']}>{$Fn_Job->Config['LangVar']['No']}</option>
							</select>						
							</td>
							<th>{$Fn_Job->Config['LangVar']['ISExpired']}</th><td>
							<select name="expired" class="form-control w100">
								<option value="">{$Fn_Job->Config['LangVar']['SelectNull']}</option>
								<option value="1"{$ExpiredSelected['1']}>{$Fn_Job->Config['LangVar']['Yes']}</option>
							</select>						
							</td>
							<th>&#26242;&#20572;&#20250;&#21592;</th><td>
							<select name="vip_stop" class="form-control w100">
								<option value="">{$Fn_Job->Config['LangVar']['SelectNull']}</option>
								<option value="1"{$VipStopSelected['1']}>{$Fn_Job->Config['LangVar']['Yes']}</option>
								<option value="0"{$VipStopSelected['0']}>{$Fn_Job->Config['LangVar']['No']}</option>
							</select>						
							</td>
						</tr>

						<tr>
							<th>{$Fn_Job->Config['LangVar']['IsVerify']}</th><td>
							<select name="verify" class="form-control w100">
								<option value="">{$Fn_Job->Config['LangVar']['SelectNull']}</option>
								<option value="1"{$VerifySelected['1']}>{$Fn_Job->Config['LangVar']['Yes']}</option>
								<option value="0"{$VerifySelected['0']}>{$Fn_Job->Config['LangVar']['No']}</option>
							</select>					
							</td>
							<th>{$Fn_Job->Config['LangVar']['ClassTitle']}</th><td>
							<select name="classid" class="form-control w100">
								{$ClassListOption}
							</select>
							</td>
							<th>{$Fn_Job->Config['LangVar']['DisplayTitle']}</th><td>
							<select name="display" class="form-control w100">
								<option value="">{$Fn_Job->Config['LangVar']['SelectNull']}</option>
								<option value="1"{$DisplaySelected['1']}>{$Fn_Job->Config['LangVar']['Yes']}</option>
								<option value="0"{$DisplaySelected['0']}>{$Fn_Job->Config['LangVar']['No']}</option>
							</select>
							</td>
							<th>{$Fn_Admin->Config['LangVar']['Order']}</th><td>
							<select name="order" class="form-control w100">
								<option value="id"{$OrderSelected['id']}>ID</option>
								<option value="dateline"{$OrderSelected['dateline']}>{$Fn_Admin->Config['LangVar']['OrderArray']['dateline']}</option>
								<option value="click"{$OrderSelected['click']}>{$Fn_Admin->Config['LangVar']['OrderArray']['click']}</option>
							</select>
							&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Admin->Config['LangVar']['SearchSubmit']}" class="btn btn-info" type="submit">
							</td>	
						</tr>
					</table>
				</div>
			</form>
SEARCH;
			/* ���� End */
			showtagheader('div', 'table-responsive', true,'table-responsive');
			showformheader($FormUrl,'enctype="multipart/form-data"');
			showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
			showsubtitle(array(
				'ID',
				'UID/'.$Fn_Job->Config['LangVar']['UserNameTitle'],
				'Logo',
				$Fn_Job->Config['LangVar']['LicenseMax'],
				$Fn_Job->Config['LangVar']['CompanyName'],
				$Fn_Job->Config['LangVar']['Telephone'],
				$Fn_Job->Config['LangVar']['Address'],
				$Fn_Job->Config['LangVar']['ClassTitle'],
				$Fn_Job->Config['LangVar']['Level'],
				$Fn_Job->Config['LangVar']['Surplus'],
				'&#31616;&#21382;&#32479;&#35745;',
				$Fn_Job->Config['LangVar']['Remarks'],
				$Fn_Job->Config['LangVar']['IsVerify'],
				$Fn_Job->Config['LangVar']['DisplayTitle'],
				$Fn_Job->Config['LangVar']['DueTime'],
				'&#26242;&#20572;&#26102;&#38388;',
				$Fn_Job->Config['LangVar']['RefreshTime'],
				$Fn_Job->Config['LangVar']['SetTopTime'],
				$Fn_Job->Config['LangVar']['TimeTitle'],
				$Fn_Job->Config['LangVar']['OperationTitle']
			),'header tbm tc');

			$ModulesList = $Fn_Job->CompanyListFormat(GetModulesList($Page,$Limit,$Where,$Order),false,3);
			foreach ($ModulesList as $Module) {
				
				$use_refresh_count = DB::result_first('SELECT COUNT(*) FROM '.DB::table($Fn_Job->TableInfoRefreshLog).' where company_id = '.intval($Module['id']).' and type = 1');
				$use_day_refresh_count = DB::result_first('SELECT COUNT(*) FROM '.DB::table($Fn_Job->TableInfoRefreshLog).' where company_id = '.intval($Module['id']).' and type = 1 and dateline >= '.strtotime(date('Y-m-d',time())).' and dateline <= '.strtotime(date('Y-m-d 23:59:59',time())));
				$use_info_count = DB::result_first('SELECT COUNT(*) FROM '.DB::table($Fn_Job->TableInfo).' where payment_type = 2 and payment_state = 1 and company_id = '.intval($Module['id']));
				$use_resume_count = DB::result_first('SELECT COUNT(*) FROM '.DB::table($Fn_Job->TableResumeSeeLog).' where mode = 2 and company_id = '.intval($Module['id']));
				
				$Surplus = $Fn_Job->Config['LangVar']['CompanyUserCount']['11'].':&nbsp;'.$Module['resume_package_count']."\r\n";
				if($Module['due_time'] >= time()){
					$Surplus .= $Fn_Job->Config['LangVar']['CompanyUserCount']['6'].':&nbsp;'.($Module['group_info_count'] - $use_info_count)."\r\n";
					$Surplus .= $Fn_Job->Config['LangVar']['CompanyUserCount']['10'].':&nbsp;'.($Module['resume_count'] - $use_resume_count)."\r\n";
					$Surplus .= $Module['refresh_type'] == 2 ? $Fn_Job->Config['LangVar']['CompanyUserCount']['9'].':&nbsp;'.($Module['refresh_count'] - $use_refresh_count)."\r\n" : $Fn_Job->Config['LangVar']['CompanyUserCount']['8'].':&nbsp;'.($Module['day_refresh_count'] - $use_day_refresh_count)."\r\n";
				}
				$Surplus .= str_replace(array('{wallet_title}'),array($Fn_Job->Config['PluginVar']['CompanyWalletTitle']),$Fn_Job->Config['LangVar']['CompanyWalletBalance']).':&nbsp;'.$Module['money']."\r\n";
				
				$resumeCountTips = '';
				foreach ($Fn_Job->Config['LangVar']['ResumeDownArray'] as $key => $val) {
					$resumeCountTips .= $val.':&nbsp;'.DB::result_first('SELECT COUNT(*) FROM '.DB::table($Fn_Job->TableResumeSeeLog).' where mode = '.$key.' and company_id = '.intval($Module['id']))."\r\n";
				}
				
				$info_list = '';
				foreach ($Module['info_list'] as $key => $val) {
					$info_list .= ($key ? "\r\n" : '').$val['title'].'---'.$val['month_wages_text'];
				}

				showtablerow('', array('class="tc w80"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
					'<input type="checkbox" class="filled-in" id="checkbox_'.$Module['id'].'" name="delete[]" value="'.$Module['id'].'"><label for="checkbox_'.$Module['id'].'">'.$Module['id'].'</label>',
					$Module['uid'] ? $Module['uid'].'/'.$Module['username'] : '',
					$Module['logo'] ? '<a href="'.$Module['logo'].'" target="_blank"><img src="'.$Module['logo'].'" style="height:30px;"></a>' : '',
					$Module['param']['license'] ? '<a href="'.$Module['param']['license'].'" target="_blank"><img src="'.$Module['param']['license'].'" style="height:30px;"></a>' : '',
					'<div data-container="body" data-toggle="popover" data-trigger="hover" data-placement="top" data-content="'.$Module['name'].'">'.cutstr($Module['name'],15).'</div>',
					$Module['mobile'],
					'<div data-container="body" data-toggle="popover" data-trigger="hover" data-placement="top" data-content="'.$Module['province_text'].$Module['community'].'">'.cutstr($Module['province_text'].$Module['community'],15).'</div>',
					$Module['class_text'],
					$Module['due_time'] >= time() ? $Module['group_title'] : '',
					'<div data-container="body" data-toggle="popover" data-trigger="hover" data-placement="top" data-html="true" data-content="'.str_replace("\r\n","<br>",$Surplus).'">'.cutstr($Surplus,10).'</div>',
					'<div data-container="body" data-toggle="popover" data-trigger="hover" data-placement="top" data-html="true" data-content="'.str_replace("\r\n","<br>",$resumeCountTips).'">'.DB::result_first('SELECT COUNT(*) FROM '.DB::table($Fn_Job->TableResumeSeeLog).' where company_id = '.intval($Module['id'])).'</div>',
					'<div data-container="body" data-toggle="popover" data-trigger="hover" data-placement="top" data-html="true" data-content="'.str_replace("\r\n","<br>",$Module['remarks']).'">'.cutstr($Module['remarks'],10).'</div>',
					!$Module['verify'] ? '<span class="label bg-secondary">'.$Fn_Job->Config['LangVar']['No'].'</span>' : '<span class="label bg-blue">'.$Fn_Job->Config['LangVar']['Yes'].'</span>',
					!$Module['display'] ? '<span class="label bg-secondary">'.$Fn_Job->Config['LangVar']['No'].'</span>' : '<span class="label bg-blue">'.$Fn_Job->Config['LangVar']['Yes'].'</span>',
					$Module['due_time'] >= time() ? date('Y-m-d',$Module['due_time']) : ($Module['due_time'] && !$Module['vip_stop_date'] ? '<span class="label bg-danger">'.$Fn_Job->Config['LangVar']['Expired'].'</span>' : ''),
					$Module['vip_stop_date'] ? date('Y-m-d',$Module['vip_stop_date']) : '',
					$Module['updateline'],
					$Module['topdateline'] && $Module['topdateline'] >= time() ? date('Y-m-d',$Module['topdateline']) : '',
					date('Y-m-d',$Module['dateline']),
					'<a href="'.$Fn_Job->Config['ViewCompanyUrl'].$Module['id'].'" target="_blank">'.cplang('view').'</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&cid='.$Module['id'].'">'.$Fn_Job->Config['LangVar']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Refresh&cid='.$Module['id'].'&formhash='.FORMHASH.'">'.$Fn_Job->Config['LangVar']['Refresh'].'</a>&nbsp;&nbsp;<a href="javacript:void(0);" class="copy_btn" data-clipboard-content="'.str_replace(array('{name}','{address}','{mobile}','{scale}','{class}','{content}','{tag}','{job_list}','{url}'),array($Module['name'],$Module['province_text'].$Module['community'],$Module['mobile'],$Fn_Job->Config['LangVar']['ScaleArray'][$Module['scale']],$Fn_Job->Config['LangVar']['CompanyClassArray'][$Module['classid']],strip_tags($Module['content']),implode('|',$Module['param']['tag_list']),$info_list,$Fn_Job->Rewrite('view_company',array('cid'=>$Module['id']))),$Fn_Job->Config['PluginVar']['CompanyCopyContent']).'">&#22797;&#21046;</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=AllRefreshJob&cid='.$Module['id'].'&formhash='.FORMHASH.'">'.$Fn_Job->Config['LangVar']['AllRefreshJob'].'</a><br><a href="'.$Fn_Admin->Config['ModUrl'].'&item=info_list&submodel=list&iframe=true&company_id='.$Module['id'].'">&#31649;&#29702;&#32844;&#20301;</a>&nbsp;&nbsp;'.($Module['due_time'] >= time() || $Module['vip_stop'] ? '<a href="'.$OpCpUrl.'&do=VipStop&cid='.$Module['id'].'&value='.(!empty($Module['vip_stop']) ? 0:1).'&formhash='.FORMHASH.'">'.(!empty($Module['vip_stop']) ? '&#24674;&#22797;&#22871;&#39184;' : '&#26242;&#20572;&#22871;&#39184;').'</a>&nbsp;&nbsp;' : '').'<a href="'.$OpCpUrl.'&do=Verify&cid='.$Module['id'].'&value='.(!empty($Module['verify']) ? 0:1).'&formhash='.FORMHASH.'">'.(!empty($Module['verify']) ? $Fn_Job->Config['LangVar']['NoVerify'] : $Fn_Job->Config['LangVar']['Verify']).'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Display&cid='.$Module['id'].'&value='.(!empty($Module['display']) ? 0:1).'&formhash='.FORMHASH.'">'.(!empty($Module['display']) ? $Fn_Job->Config['LangVar']['DisplayNoTitle'] : $Fn_Job->Config['LangVar']['DisplayIsTitle']).'</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['ModUrl'].'&item=company_follow_list&submodel=list&iframe=true&company_id='.$Module['id'].'">&#20851;&#27880;&#35760;&#24405;</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Del&cid='.$Module['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;">'.$Fn_Job->Config['LangVar']['DelTitle'].'</a>',
				));
			}
			showsubmit('Submit','&#31435;&#21363;&#25552;&#20132;','del','','',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));
			showtablefooter(); /*dism��taobao��com*/
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			echo '
			<script src="source/plugin/fn_assembly/static/js/clipboard.min.js"></script>    
			<script>
			var clipboard = new ClipboardJS(".copy_btn", {
				text: function(e) {
					return e.getAttribute("data-clipboard-content");
				}
			});
			clipboard.on("success", function(e) {
				alert("\u606d\u559c\u60a8\uff0c\u590d\u5236\u6210\u529f\uff01");
			});

			clipboard.on("error", function(e) {
				alert("\u5f88\u9057\u61be\uff0c\u590d\u5236\u5931\u8d25\uff01");
			});
			</script>';
			/* ģ�����End */	
		}else{
			if(!$Fn_Admin->CheckUserGroup('job_all') && !$Fn_Admin->CheckUserGroup('job_company_del')){//Ȩ���ж�
				fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
				exit();
			}

			if(isset($_GET['delete']) && is_array($_GET['delete'])){
				foreach($_GET['delete'] as $Key => $Val) {
					$Val = intval($Val);
					$Item = DB::fetch_first('SELECT * FROM '.DB::table($Fn_Job->TableCompany).' where id = '.$Val);
					DB::delete($Fn_Job->TableCompany,'id ='.$Val);
					DB::delete($Fn_Job->TableInfo,'company_id ='.intval($Item['id']));
					DB::delete($Fn_Job->TableResumeSeeLog,'company_id ='.intval($Item['id']));
					DB::delete($Fn_Job->TableInterview,'company_id ='.intval($Item['id']));
					DB::delete($Fn_Job->TableInfoApplyLog,'company_id ='.intval($Item['id']));
					DB::delete($Fn_Job->TableCompanyGroupLog,'company_id ='.intval($Item['id']));
					DB::delete($Fn_Job->TableInfoRefreshLog,'company_id ='.intval($Item['id']));
					DB::delete($Fn_Job->TableFairCompany,'company_id ='.intval($Item['id']));
					DB::delete($Fn_Job->TableCompanyWalletLog,'company_id ='.intval($Item['id']));
					DB::delete($Fn_Job->TableResumeSign,'company_id ='.$Item['id']);
					DB::delete($Fn_Job->TableResumeReport,'company_id ='.$Item['id']);
					DB::delete($Fn_Job->TableCompanyFollow,'company_id ='.$Item['id']);
					foreach(DB::fetch_all('SELECT * FROM '.DB::table($Fn_Job->TableInfo).' where company_id = '.intval($Item['id']).' order by dateline desc') as $V) {
						DB::delete($Fn_Job->TableInfo,'id ='.intval($V['id']));
						DB::delete($Fn_Job->TableInfoReport,'iid ='.intval($V['id']));
						DB::delete($Fn_Job->TableInfoCollection,'iid ='.intval($V['id']));
						DB::delete($Fn_Job->TableInfoApplyLog,'iid ='.intval($V['id']));
					}
				}

				GetInsertDoLog('del_company_list_job','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete'])));//������¼

				fn_cpmsg($Fn_Job->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
			}else{
				fn_cpmsg($Fn_Job->Config['LangVar']['DelErr'],'','error');
			}
				
		}
	}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['cid']){
		if(!$Fn_Admin->CheckUserGroup('job_all') && !$Fn_Admin->CheckUserGroup('job_company_del')){//Ȩ���ж�
			fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
			exit();
		}
		$Cid = intval($_GET['cid']);
		$Item = DB::fetch_first('SELECT * FROM '.DB::table($Fn_Job->TableCompany).' where id = '.$Cid);
		DB::delete($Fn_Job->TableCompany,'id ='.$Cid);
		DB::delete($Fn_Job->TableInfo,'company_id ='.intval($Item['id']));
		DB::delete($Fn_Job->TableResumeSeeLog,'company_id ='.intval($Item['id']));
		DB::delete($Fn_Job->TableInterview,'company_id ='.intval($Item['id']));
		DB::delete($Fn_Job->TableInfoApplyLog,'company_id ='.intval($Item['id']));
		DB::delete($Fn_Job->TableCompanyGroupLog,'company_id ='.intval($Item['id']));
		DB::delete($Fn_Job->TableInfoRefreshLog,'company_id ='.intval($Item['id']));
		DB::delete($Fn_Job->TableFairCompany,'company_id ='.intval($Item['id']));
		DB::delete($Fn_Job->TableCompanyWalletLog,'company_id ='.intval($Item['id']));
		DB::delete($Fn_Job->TableResumeSign,'company_id ='.$Item['id']);
		DB::delete($Fn_Job->TableResumeReport,'company_id ='.$Item['id']);
		DB::delete($Fn_Job->TableCompanyFollow,'company_id ='.$Item['id']);
		foreach(DB::fetch_all('SELECT * FROM '.DB::table($Fn_Job->TableInfo).' where company_id = '.intval($Item['id']).' order by dateline desc') as $V) {
			DB::delete($Fn_Job->TableInfo,'id ='.intval($V['id']));
			DB::delete($Fn_Job->TableInfoReport,'iid ='.intval($V['id']));
			DB::delete($Fn_Job->TableInfoCollection,'iid ='.intval($V['id']));
			DB::delete($Fn_Job->TableInfoApplyLog,'iid ='.intval($V['id']));
		}

		GetInsertDoLog('del_company_list_job','fn_'.$_GET['mod'],array('id'=>$AUid));//������¼
		fn_cpmsg($Fn_Admin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
	}else if($Do == 'Refresh' && $_GET['formhash'] == formhash() && $_GET['cid']){
		$id = intval($_GET['cid']);
		$UpData['updateline'] = time();
		DB::update($Fn_Job->TableCompany,$UpData,'id = '.$id);
		GetInsertDoLog('refresh_company_list_job','fn_'.$_GET['mod'],array('id'=>$id));//������¼
		fn_cpmsg($Fn_Job->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

	}else if($Do == 'AllRefreshJob' && $_GET['formhash'] == formhash() && $_GET['cid']){
		$id = intval($_GET['cid']);
		$UpData['updateline'] = time();
		DB::update($Fn_Job->TableInfo,$UpData,'company_id = '.$id);
		GetInsertDoLog('refresh_info_list_job','fn_'.$_GET['mod'],array('id'=>$id));//������¼
		fn_cpmsg($Fn_Job->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

	}else if($Do == 'VipStop' && $_GET['formhash'] == formhash() && $_GET['cid']){
		
		$id = intval($_GET['cid']);
		$Item = DB::fetch_first('SELECT * FROM '.DB::table($Fn_Job->TableCompany).' where id = '.$id);
		$UpData['vip_stop'] = intval($_GET['value']);
		if($UpData['vip_stop']){
			$UpData['vip_stop_date'] = time();
		}else{
			$UpData['due_time'] = time() + ($Item['due_time'] - $Item['vip_stop_date']);
			$UpData['vip_stop_date'] = '';
		}
		DB::update($Fn_Job->TableCompany,$UpData,'id = '.$id);
		GetInsertDoLog('vip_stop_company_lis_job','fn_'.$_GET['mod'],array('id'=>$id,'verify'=>$_GET['value']));//������¼
		fn_cpmsg($Fn_Job->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

	}else if($Do == 'Verify' && $_GET['formhash'] == formhash() && $_GET['cid']){
		$id = intval($_GET['cid']);
		$UpData['verify'] = intval($_GET['value']);
		DB::update($Fn_Job->TableCompany,$UpData,'id = '.$id);
		GetInsertDoLog('verify_company_lis_job','fn_'.$_GET['mod'],array('id'=>$id,'verify'=>$_GET['value']));//������¼
		fn_cpmsg($Fn_Job->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

	}else if($Do == 'Display' && $_GET['formhash'] == formhash() && $_GET['cid']){
		$id = intval($_GET['cid']);
		$UpData['display'] = intval($_GET['value']);
		DB::update($Fn_Job->TableCompany,$UpData,'id = '.$id);
		GetInsertDoLog('display_company_lis_job','fn_'.$_GET['mod'],array('id'=>$id,'display'=>$_GET['value']));//������¼
		fn_cpmsg($Fn_Job->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

	}
}else if($SubModel == 'add'){//���ӻ�༭
	if(!$Fn_Admin->CheckUserGroup('job_all') && !$Fn_Admin->CheckUserGroup('job_company_add')){//Ȩ���ж�
		fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
		exit();
	}
	$id = intval($_GET['cid']);

	$Item = DB::fetch_first('SELECT * FROM '.DB::table($Fn_Job->TableCompany).' where id = '.$id);
	if($Item){
		$Item['param'] = unserialize($Item['param']);
		$CompanyGroupLogItem = DB::fetch_first('SELECT * FROM '.DB::table($Fn_Job->TableCompanyGroupLog).' where company_id = '.$Item['id']);
	};
	if(!submitcheck('DetailSubmit')) {
		$OpTitle = $Fn_Job->Config['LangVar']['AddTitle'];
		if($Item){
			$OpTitle = $Fn_Job->Config['LangVar']['EditTitle'];
			$Item['province_text'] = $Fn_Job->Area[$Item['province']]['content'].($Item['city'] ? $Fn_Job->Area[$Item['city']]['content'] : '').($Item['dist'] ? $Fn_Job->Area[$Item['dist']]['content'] : '');
		}

		echo '<script src="'.$Config['StaticPath'].'/ueditor/'.CHARSET.'/ueditor.config.js" type="text/javascript"></script><script src="'.$Config['StaticPath'].'/ueditor/'.CHARSET.'/ueditor.all.js" type="text/javascript"></script>';
		
		//ͼƬ�ϴ�
		if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_assembly/class/class_upload.php')){
			@require_once libfile('class/upload','plugin/fn_assembly');
			$UploadConfig = fn_upload::Config();
		}

		showtagheader('div', 'box', true,'box');
		showformheader($Fn_Admin->Config['IframeSubModelUrl'].'&cid='.$id,'enctype');
		echo <<<HTML
		<ul class="nav nav-tabs customtab" role="tablist">
          <li class="nav-item"> <a class="nav-link active" data-toggle="tab" href="#basics" role="tab" aria-expanded="true"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#20844;&#21496;&#36164;&#26009;</span></a> </li>
		  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#level" role="tab" aria-expanded="false"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#22871;&#39184;&#35774;&#32622;</span></a> </li>
		  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#other" role="tab" aria-expanded="false"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#20854;&#20182;&#35774;&#32622;</span></a> </li>
        </ul>
HTML;
		showtagheader('div', 'box-body', true,'box-body');
		showtagheader('div', 'tab-content', true,'tab-content');
		
		echo <<<HTML
		<!-- ��˾����  -->
		<div class="tab-pane active" id="basics" role="tabpanel" aria-expanded="true">
HTML;
		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">Logo</label><div class="col-sm-9"><div class="AdminSingleUpload"><div class="PhotoControl" id="LogoPhotoControl"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';

		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_Job->Config['LangVar']['LicenseMax'].'</label><div class="col-sm-9"><div class="AdminSingleUpload"><div class="PhotoControl" id="LicensePhotoControl"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';

		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_Job->Config['LangVar']['HuanJing'].'</label><div class="col-sm-9"><div class="AdminSingleUpload"><div class="PhotoControl" id="ImagesPhotoControl"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';

		showsetting('uid', 'new_uid', $Item['uid'], 'text');

		showsetting($Fn_Job->Config['LangVar']['AdminUid'], 'admin_uid', $Item['admin_uid'], 'text','','',$Fn_Job->Config['LangVar']['AdminUidTips']);
		
		showsetting($Fn_Job->Config['LangVar']['ViewName'], 'name', $Item['name'], 'text');

		showsetting($Fn_Job->Config['LangVar']['Type'], array('type',DyadicArray($Fn_Job->Config['LangVar']['CompanyTypeArray'])),$Item['type'], 'mradio');

		showsetting($Fn_Job->Config['LangVar']['Scale'], array('scale',DyadicArray($Fn_Job->Config['LangVar']['ScaleArray'])),$Item['scale'], 'select');

		showsetting($Fn_Job->Config['LangVar']['ClassTitle'], array('classid',DyadicArray($Fn_Job->Config['LangVar']['CompanyClassArray'],$Fn_Job->Config['LangVar']['SelectNull'])),$Item['classid'], 'select');
		
		$AreaPositionTreelistHtml = GetTreelistHtml($Fn_Job->Area,'SmallAreaPositionList',$Item['province'],$Item['city'],$Item['dist']);
		
		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_Job->Config['LangVar']['Position'].':</label><div class="col-sm-2"><div style="position:relative;height:40px"><input value="'.$Item['province_text'].'" class="input form-control TreeList" type="text" id="SmallAreaPosition">'.$AreaPositionTreelistHtml.'</div></div><div class="col-sm-7 form-inline"><input type="hidden" name="province" value="'.$Item['province'].'"/><input type="hidden" name="city" value="'.$Item['city'].'"/><input type="hidden" name="dist" value="'.$Item['dist'].'"/></div></div>';

		showsetting($Fn_Job->Config['LangVar']['Address'], 'community', $Item['community'], 'text');
		
		showsetting($Fn_Admin->Config['LangVar']['Longitude'], 'lng', $Item['lng'], 'text','','','<div class="MapClick">'.($Item['lng'] && $Item['lat'] ? $Fn_Job->Config['LangVar']['IsTagging'] : $Fn_Job->Config['LangVar']['Tagging']).'</div><div class="TipMap"><iframe id="MapPage" width="100%" height="100%" frameborder=0 src=""></iframe></div>');

		showsetting($Fn_Admin->Config['LangVar']['Latitude'], 'lat', $Item['lat'], 'text');

		showsetting($Fn_Job->Config['LangVar']['Contact'], 'contacts', $Item['contacts'], 'text');

		showsetting($Fn_Job->Config['LangVar']['Telephone'], 'mobile', $Item['mobile'], 'text');

		showsetting($Fn_Job->Config['LangVar']['ShortMessageTel'], 'sms_mobile', $Item['sms_mobile'], 'text');

		showsetting($Fn_Job->Config['LangVar']['MobileVerify'], 'mobile_verify', $Item['mobile_verify'], 'radio');

		showsetting($Fn_Job->Config['LangVar']['HideMobile'], 'hide_mobile', $Item['hide_mobile'], 'radio','','',$Fn_Job->Config['LangVar']['HideMobileTips']);

		showsetting($Fn_Job->Config['LangVar']['Welfare'],array('tag[]',DyadicArray($Fn_Job->Config['LangVar']['WelfareArray'])),explode(',',$Item['tag']),'mselect','','',$Fn_Admin->Config['LangVar']['Ctrl']);

		showsetting($Fn_Job->Config['LangVar']['VideoType'],array('video_type', array(
			array('0',$Fn_Job->Config['LangVar']['VideoTypeArray']['0'], array('video_type' => 'none','video_pic_div'=>'none')),
			array('1',$Fn_Job->Config['LangVar']['VideoTypeArray']['1'], array('video_type' => '','video_pic_div'=>'')),
			array('2',$Fn_Job->Config['LangVar']['VideoTypeArray']['2'], array('video_type' => '','video_pic_div'=>'')),
			array('3',$Fn_Job->Config['LangVar']['VideoTypeArray']['3'], array('video_type' => '','video_pic_div'=>'none')),
		), TRUE),$Item['video_type'], 'mradio');
		showtagheader('div', 'video_type', $Item['video_type'] ? true : '','sub');
			showsetting($Fn_Job->Config['LangVar']['VideoUrl'], 'video_url', stripslashes($Item['video_url']), 'text','','',$Fn_Job->Config['LangVar']['VideoUrlTips']);
			showtagheader('div', 'video_pic_div', in_array($Item['video_type'],array('1','2')) ? true : '','sub');
				echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_Job->Config['LangVar']['VideoPic'].'<br>&#24314;&#35758;&#54;&#52;&#48;&#32;&#42;&#32;&#51;&#54;&#48;</label><div class="col-sm-9"><div class="AdminSingleUpload"><div class="PhotoControl" id="video_pic"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';
			showtagfooter('div');
		showtagfooter('div');
		
		//��������
		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_Job->Config['LangVar']['Describe'].':</label><div class="col-sm-9"><textarea id="content" name="content" style="width:80%;height:350px;">'.stripslashes($Item['content']).'</textarea></div></div>';
		echo <<<HTML
		</div>
		<!-- ��˾���� end  -->
HTML;
		
		echo <<<HTML
		<!-- �ײ�����  -->
		<div class="tab-pane" id="level" role="tabpanel" aria-expanded="false">
HTML;
		
		if($Item['vip_stop']){

			echo '<div class="alert alert-primary margin-top-0" role="alert">&#22871;&#39184;&#24050;&#34987;&#26242;&#20572;&#65292;&#35831;&#20808;&#24674;&#22797;&#22871;&#39184;&#25165;&#33021;&#36827;&#34892;&#22871;&#39184;&#35774;&#32622;</div>';

		}else{
			$GroupList = array();
		
			foreach($Fn_Job->GetCompanyGroupList() as $Val) {
				$GroupList[] = array($Val['id'], $Val['title']);
			}
			
			showsetting($Fn_Job->Config['LangVar']['AdminVipOpen'], array('vip_type',DyadicArray($Fn_Job->Config['LangVar']['AdminVipOpenArray'])),0, 'mradio','','',$Fn_Job->Config['LangVar']['AdminVipOpenTips']);

			showsetting($Fn_Job->Config['LangVar']['xztc'], array('group_id', $GroupList),$Item['due_time'] >= time() ? $Item['group_id'] : '', 'mradio');
			
			showsetting($Fn_Job->Config['LangVar']['CompanyGroupInfoCount'], 'info_count', $CompanyGroupLogItem['info_count'], 'text','','',$Fn_Job->Config['LangVar']['CompanyGroupInfoCountTips']);

			showsetting($Fn_Job->Config['LangVar']['CompanyGroupRefreshType'],array('refresh_type', array(
				array('1',$Fn_Job->Config['LangVar']['CompanyGroupDayRefreshCount'], array('refresh_type_table' => '', 'refresh_type_table_no' => 'none')),
				array('2',$Fn_Job->Config['LangVar']['CompanyGroupRefreshCount'], array('refresh_type_table' => 'none', 'refresh_type_table_no' => '')),
			), TRUE),$CompanyGroupLogItem['refresh_type'], 'mradio');

			$RefreshTypeTableDisplay = $CompanyGroupLogItem['refresh_type'] == 1 || !$CompanyGroupLogItem ? true : false;
			$RefreshTypeTableNoDisplay = $CompanyGroupLogItem['refresh_type'] != 1 && $CompanyGroupLogItem ? true : false;

			showtagheader('tbody', 'refresh_type_table', $RefreshTypeTableDisplay, 'sub');
				showsetting($Fn_Job->Config['LangVar']['CompanyGroupDayRefreshCount'], 'day_refresh_count', $CompanyGroupLogItem['day_refresh_count'], 'text','','',$Fn_Job->Config['LangVar']['CompanyGroupDayRefreshCountTips']);
			showtagfooter('tbody');

			showtagheader('tbody', 'refresh_type_table_no', $RefreshTypeTableNoDisplay, 'sub');
				showsetting($Fn_Job->Config['LangVar']['CompanyGroupRefreshCount'], 'refresh_count', $CompanyGroupLogItem['refresh_count'], 'text','','',$Fn_Job->Config['LangVar']['CompanyGroupRefreshCountTips']);
			showtagfooter('tbody');

			showsetting($Fn_Job->Config['LangVar']['CompanyGroupResumeCount'], 'resume_count', $CompanyGroupLogItem['resume_count'], 'text','','',$Fn_Job->Config['LangVar']['CompanyGroupResumeCountTips']);
			showsetting($Fn_Job->Config['LangVar']['CompanyGroupResumeDayCount'], 'resume_day_count', $CompanyGroupLogItem['resume_day_count'], 'text','','',$Fn_Job->Config['LangVar']['CompanyGroupResumeDayCountTips']);
			showsetting($Fn_Job->Config['LangVar']['CompanyGroupTopDiscount'], 'top_discount', $CompanyGroupLogItem['top_discount'], 'text','','',$Fn_Job->Config['LangVar']['CompanyGroupTopDiscountTips']);
			showsetting($Fn_Job->Config['LangVar']['CompanyGroupHot'], 'hot', $CompanyGroupLogItem ? $CompanyGroupLogItem['hot'] : 0, 'radio');
			showsetting($Fn_Job->Config['LangVar']['CompanyGroupExamine'], 'examine', $CompanyGroupLogItem['examine'], 'radio');
			showsetting($Fn_Job->Config['LangVar']['CompanyGroupApplyInfoResume'], 'apply_resume', $CompanyGroupLogItem['apply_resume'], 'radio');
			showsetting($Fn_Job->Config['LangVar']['CompanyGroupHide'], 'hide', $CompanyGroupLogItem['hide'], 'radio');
			
			if($Fn_Job->Config['PluginVar']['CompanyWalletSwitch']){
				showsetting(str_replace(array('{wallet_title}'),array($Fn_Job->Config['PluginVar']['CompanyWalletTitle']),$Fn_Job->Config['LangVar']['CompanyWalletBalance']), 'money', $Item['money'], 'text','','',$Fn_Job->Config['LangVar']['CompanyWalletBalanceTips']);
			}else{
				echo '<input value="'.$Item['money'].'" type="hidden" name="money">';
			}
		
			showsetting($Fn_Job->Config['LangVar']['DueTime'], 'due_time',$Item['due_time'] ? date('Y-m-d',$Item['due_time']) : '', 'calendar');
		}
		
		echo <<<HTML
		</div>
		<!-- �ײ�Ȩ�� end  -->
HTML;
		
		echo <<<HTML
		<!-- ��������  -->
		<div class="tab-pane" id="other" role="tabpanel" aria-expanded="false">
HTML;
		
		showsetting($Fn_Job->Config['LangVar']['Remarks'], 'remarks', $Item['remarks'], 'textarea');

		showsetting($Fn_Job->Config['LangVar']['CompanyUserCount'][11], 'resume_package_count',$Item['resume_package_count'], 'text');

		showsetting($Fn_Job->Config['LangVar']['SetTopTime'], 'topdateline',$Item['topdateline'] ? date('Y-m-d H:i',$Item['topdateline']) : '', 'calendar','','','',1);
		
		if($Item['updateline']){
			showsetting($Fn_Job->Config['LangVar']['RefreshTime'], 'updateline',$Item['updateline'] ? date('Y-m-d H:i',$Item['updateline']) : '', 'calendar','','','',1);
		}

		if($Item['dateline']){
			showsetting($Fn_Job->Config['LangVar']['TimeTitle'], 'dateline',date('Y-m-d H:i',$Item['dateline']), 'calendar','','','',1);
		}

		showsetting($Fn_Job->Config['LangVar']['IsVerify'], 'verify', $Item['verify'], 'radio');

		showsetting($Fn_Job->Config['LangVar']['Click'], 'click', $Item['click'], 'text');

		showsetting($Fn_Job->Config['LangVar']['VipExpiryPushCompanyTitle'], 'vip_expiry_push', $Item['vip_expiry_push'], 'radio','','',$Fn_Job->Config['LangVar']['VipExpiryPushCompanyTips']);

		showsetting($Fn_Job->Config['LangVar']['DisplayTitle'], 'display', $Item ? $Item['display'] : 1, 'radio');
		echo <<<HTML
		</div>
		<!-- �������� end  -->
HTML;
		
		showsubmit('DetailSubmit','&#20445;&#23384;&#37197;&#32622;');
		showtagfooter('div');
		showtagheader('div', 'tab-content', true,'tab-content');
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');

		$UpLoadHtml  = '';
		if($Item['logo']){
			$LogoJsArray[] = '"'.$Item['logo'].'"';;
			$UpLoadHtml .= '
			var InputArray = new Array('.implode(',',$LogoJsArray).');
			$("#LogoPhotoControl").AppUpload({InputName:"new_logo",Multiple:true,InputExist:true,InputArray:InputArray});';

		}else{
			$UpLoadHtml .= '$("#LogoPhotoControl").AppUpload({InputName:"new_logo",Multiple:true});';
		}

		if($Item['param']['license']){
			$LicenseJsArray[] = '"'.$Item['param']['license'].'"';;
			$UpLoadHtml .= '
			var InputArray = new Array('.implode(',',$LicenseJsArray).');
			$("#LicensePhotoControl").AppUpload({InputName:"new_license",Multiple:true,InputExist:true,InputArray:InputArray});';

		}else{
			$UpLoadHtml .= '$("#LicensePhotoControl").AppUpload({InputName:"new_license",Multiple:true});';
		}

		if($Item['param']['album']){
			foreach($Item['param']['album'] as $Key => $Val) {
				$ImagesJsArray[] = '"'.$Val.'"';
			}
			$UpLoadHtml .= '
			var InputArray = new Array('.implode(',',$ImagesJsArray).');
			$("#ImagesPhotoControl").AppUpload({InputName:"new_album",InputExist:true,InputArray:InputArray});';

		}else{
			$UpLoadHtml .= '$("#ImagesPhotoControl").AppUpload({InputName:"new_album"});';
		}

		if($Item['video_pic']){
			$VideoPicJsArray[] = '"'.$Item['video_pic'].'"';;
			$UpLoadHtml .= '
			var InputArray = new Array('.implode(',',$VideoPicJsArray).');
			$("#video_pic").AppUpload({InputName:"new_video_pic",Multiple:true,InputExist:true,InputArray:InputArray});';

		}else{
			$UpLoadHtml .= '$("#video_pic").AppUpload({InputName:"new_video_pic",Multiple:true});';
		}

		echo '<script src="source/plugin/fn_assembly/static/js/mobiscroll.custom-2.16.1.min.js"></script><link rel="stylesheet" href="source/plugin/fn_assembly/static//css/mobiscroll.custom-2.16.1.min.css"><script charset=utf-8 src="https://map.qq.com/api/js?v=2.exp&key='.$Config['PluginVar']['TxMapKey'].'"></script>'.$UploadConfig['CssJsHtml'];
		
		echo '
			<style>.Tmp{opacity:0;}.Tagging span{font-size:18px;}.Tagging{cursor: pointer;}</style>
			<script>
			$(document).on("click","#SmallAreaPosition",function(){
				GetTreeList($(this),"SmallAreaPositionList","province","city","dist");
				return false;
			});
			//��ע
			$(document).on("click",".MapClick",function(){
				if(!$("#MapPage").attr("src")){
					$("#MapPage").attr("src","https://apis.map.qq.com/tools/locpicker?search=1&type=1&key='.$Config['PluginVar']['TxMapKey'].'&referer=myapp&'.($Item['lat'] && $Item['lng'] ? 'coord='.$Item['lat'].','.$Item['lng'] : '').'");
				}
				$(".TipMap").fadeIn();
				return false;
			});
			window.addEventListener("message", function(Event) {
				var Loc = Event.data;
				if (Loc && Loc.module == "locationPicker") {
					var Geocoder = new qq.maps.Geocoder();
					Geocoder.getAddress(new qq.maps.LatLng(Loc.latlng.lat, Loc.latlng.lng));
					Geocoder.setComplete(function(Result) {
						$("input[name=\'lat\']").val(Result.detail.location.lat);
						$("input[name=\'lng\']").val(Result.detail.location.lng);
						$("input[name=\'community\']").val(Result.detail.addressComponents.street + Result.detail.addressComponents.streetNumber);
						$(".Map").html("'.$Fn_Renovation->Config['LangVar']['IsTagging'].'<span class=iconfont>&#xe621;</span>");
						$(".TipMap").fadeOut();
					});
					Geocoder.setError(function() {
						alert("\u51fa\u9519\u4e86\uff0c\u8bf7\u8f93\u5165\u6b63\u786e\u7684\u5730\u5740\uff01\uff01\uff01");
					});
				}
			}, false);
			//��ע End
			var ue = UE.getEditor("content",{autoHeightEnabled: false,autoFloatEnabled:false,enableAutoSave: false});
			'.$UpLoadHtml.'
			</script> 	
		';

	}else{
	
		$Data['uid'] = intval($_GET['new_uid']);
		$Member = DB::fetch_first('SELECT username FROM '.DB::table('common_member').' where uid = '.$Data['uid']);
		$Data['username'] = addslashes(strip_tags($Member['username']));
		$Data['admin_uid'] = addslashes(strip_tags($_GET['admin_uid']));
		
		foreach($_GET['new_logo'] as $Key => $Val) {
			$_GET['new_logo'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}

		foreach($_GET['new_license'] as $Key => $Val) {
			$_GET['new_license'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}

		foreach($_GET['new_album'] as $Key => $Val) {
			$_GET['new_album'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}

		foreach($_GET['new_video_pic'] as $Key => $Val) {
			$_GET['new_video_pic'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}
		
		$Data['logo'] = addslashes(strip_tags($_GET['new_logo'][0]));
		$Data['name'] = addslashes(strip_tags($_GET['name']));
		$Data['type'] = intval($_GET['type']);
		$Data['scale'] = intval($_GET['scale']);
		$Data['classid'] = intval($_GET['classid']);
		$Data['province'] = addslashes(strip_tags($_GET['province']));
		$Data['city'] = addslashes(strip_tags($_GET['city']));
		$Data['dist'] = addslashes(strip_tags($_GET['dist']));
		$Data['community'] = addslashes(strip_tags($_GET['community']));
		$Data['lat'] = addslashes(strip_tags($_GET['lat']));
		$Data['lng'] = addslashes(strip_tags($_GET['lng']));
		$Data['contacts'] = addslashes(strip_tags($_GET['contacts']));
		$Data['mobile'] = addslashes(strip_tags($_GET['mobile']));
		$Data['sms_mobile'] = addslashes(strip_tags($_GET['sms_mobile']));
		$Data['hide_mobile'] = intval($_GET['hide_mobile']);
		$Data['mobile_verify'] = intval($_GET['mobile_verify']);
		$Data['tag'] = is_array($_GET['tag']) && isset($_GET['tag']) ? implode(',',$_GET['tag']) : '';
		$Data['video_type'] = intval($_GET['video_type']);
		$Data['video_url'] = addslashes($_GET['video_url']);
		$Data['video_pic'] = addslashes(strip_tags($_GET['new_video_pic'][0]));
		$Data['content'] = addslashes($_GET['content']);//�豣��Html
		$Data['remarks'] = addslashes($_GET['remarks']);//�豣��Html
		$Data['money'] = intval($_GET['money']);
		$Data['click'] = intval($_GET['click']);
		
	
		$Data['topdateline'] = $_GET['topdateline'] ? strtotime($_GET['topdateline']) : '';
		$Data['verify'] = intval($_GET['verify']);
		$Data['vip_expiry_push'] = intval($_GET['vip_expiry_push']);
		$Data['display'] = intval($_GET['display']);
		$Data['resume_package_count'] = intval($_GET['resume_package_count']);
		
		$Param['license'] = addslashes(strip_tags($_GET['new_license'][0]));
		$Param['album'] = is_array($_GET['new_album']) && isset($_GET['new_album'])  ? array_filter($_GET['new_album']) : '';
		foreach(array_filter(explode(",",$Data['tag'])) as $Key => $Val) {
			if($Fn_Job->Config['LangVar']['WelfareArray'][$Val]){
				$Param['tag_list'][] = $Fn_Job->Config['LangVar']['WelfareArray'][$Val];
			}
		}
		
		$Data['param'] = serialize($Param);
		
		if(!$Item['vip_stop']){
			$Data['group_id'] = intval($_GET['group_id']);
			$Data['due_time'] = $_GET['due_time'] ? strtotime($_GET['due_time']) : '';
			$GroupItem = DB::fetch_first('SELECT * FROM '.DB::table($Fn_Job->TableCompanyGroup).' where id = '.$Data['group_id']);

			
			$Company['use_refresh_count'] = DB::result_first('SELECT COUNT(*) FROM '.DB::table($Fn_Job->TableInfoRefreshLog).' where company_id = '.intval($Item['id']).' and type = 1');
			$Company['use_day_refresh_count'] = DB::result_first('SELECT COUNT(*) FROM '.DB::table($Fn_Job->TableInfoRefreshLog).' where company_id = '.intval($Item['id']).' and type = 1 and dateline >= '.strtotime(date('Y-m-d',time())).' and dateline <= '.strtotime(date('Y-m-d 23:59:59',time())));
			$Company['use_info_count'] = DB::result_first('SELECT COUNT(*) FROM '.DB::table($Fn_Job->TableInfo).' where payment_type = 2 and payment_state = 1 and company_id = '.intval($Item['id']));
			$Company['use_resume_count'] = DB::result_first('SELECT COUNT(*) FROM '.DB::table($Fn_Job->TableResumeSeeLog).' where mode = 2 and company_id = '.intval($Item['id']));



			if($_GET['vip_type'] == 1 && $GroupItem){

				$GroupLogData['info_count'] = intval($GroupItem['info_count']) + $Company['use_info_count'];
				$GroupLogData['refresh_type'] = intval($GroupItem['refresh_type']);
				$GroupLogData['refresh_count'] = intval($GroupItem['refresh_count']) + $Company['use_refresh_count'];
				$GroupLogData['day_refresh_count'] = intval($GroupItem['day_refresh_count']) + $Company['use_day_refresh_count'];
				$GroupLogData['top_discount'] = addslashes(strip_tags($GroupItem['top_discount']));
				$GroupLogData['resume_count'] = intval($GroupItem['resume_count']) + $Company['use_resume_count'];
				$GroupLogData['resume_day_count'] = intval($GroupItem['resume_day_count']);
				$GroupLogData['hot'] = intval($GroupItem['hot']);
				$GroupLogData['examine'] = intval($GroupItem['examine']);
				$GroupLogData['apply_resume'] = intval($GroupItem['apply_resume']);
				$GroupLogData['hide'] = intval($GroupItem['hide']);
				$Data['vip_expiry_push'] = 0;
				$Data['due_time'] = $Data['due_time'] > time() ? strtotime("+".intval($GroupItem['group_time'])."  month",$Data['due_time']) : strtotime("+".intval($GroupItem['group_time'])."  month",time());

			}else if($_GET['vip_type'] == 2 && $GroupItem){
				
				$GroupLogData['refresh_count'] =  intval($_GET['refresh_count']) + $GroupItem['refresh_count'];
				$GroupLogData['day_refresh_count'] =  intval($_GET['day_refresh_count']) + $GroupItem['day_refresh_count'];
				$GroupLogData['info_count'] = intval($_GET['info_count']) + $GroupItem['info_count'];
				$GroupLogData['resume_count'] =  intval($_GET['resume_count']) + $GroupItem['resume_count'];
				$GroupLogData['resume_day_count'] = $GroupItem['resume_day_count'];
				$GroupLogData['examine'] = $GroupItem['examine'];
				$GroupLogData['top_discount'] = $GroupItem['top_discount'];
				$GroupLogData['hot'] = $GroupItem['hot'];
				$GroupLogData['refresh_type'] = $GroupItem['refresh_type'];
				$GroupLogData['apply_resume'] = $GroupItem['apply_resume'];
				$GroupLogData['hide'] = $GroupItem['hide'];
				$Data['vip_expiry_push'] = 0;
				$Data['due_time'] = strtotime("+".intval($GroupItem['group_time'])."  month",time());

			}else{
				$GroupLogData['info_count'] = intval($_GET['info_count']);
				$GroupLogData['refresh_type'] = intval($_GET['refresh_type']);
				$GroupLogData['refresh_count'] = intval($_GET['refresh_count']);
				$GroupLogData['day_refresh_count'] = intval($_GET['day_refresh_count']);
				$GroupLogData['top_discount'] = addslashes(strip_tags($_GET['top_discount']));
				$GroupLogData['resume_count'] = intval($_GET['resume_count']);
				$GroupLogData['resume_day_count'] = intval($_GET['resume_day_count']);
				$GroupLogData['hot'] = intval($_GET['hot']);
				$GroupLogData['examine'] = intval($_GET['examine']);
				$GroupLogData['apply_resume'] = intval($_GET['apply_resume']);
				$GroupLogData['hide'] = intval($_GET['hide']);
			}
		}
	
		if($Item){
			$Data['updateline'] = strtotime($_GET['updateline']);
			GetInsertDoLog('edit_company_list_job','fn_'.$_GET['mod'],array('id'=>$id));//������¼
			DB::update($Fn_Job->TableCompany,$Data,'id = '.$id);
			DB::update($Fn_Job->TableInfo,array('province'=>$Data['province'],'city'=>$Data['city'],'dist'=>$Data['dist'],'community'=>$Data['community']),'company_id = '.$Item['id']);
		}else{
			$Data['dateline'] = $Data['updateline'] = time();
			$Id = DB::insert($Fn_Job->TableCompany,$Data,true);
			GetInsertDoLog('add_company_list_job','fn_'.$_GET['mod'],array('id'=>$Id));//������¼
		}
		
		if(!$Item['vip_stop']){
			$GroupLogData['company_id'] = $Item['id'] ? $Item['id'] : $Id;
			if($CompanyGroupLogItem){
				DB::update($Fn_Job->TableCompanyGroupLog,$GroupLogData,'company_id = '.$CompanyGroupLogItem['company_id']);
			}else{
				DB::insert($Fn_Job->TableCompanyGroupLog,$GroupLogData);
			}
		}

		fn_cpmsg($Fn_Job->Config['LangVar']['UpdateOk'],$Fn_Admin->Config['IframeItemUrl'].'&submodel=list','succeed');
		
	}
}


/* �б� */
function GetModulesList($Page,$Limit,$Where=null,$Order){
	global $Fn_Job;
	$FetchSql = 'SELECT C.*,AG.title as group_title,AGL.day_refresh_count,AGL.day_info_count,AGL.info_count as group_info_count,AGL.resume_count,AGL.resume_day_count,AGL.examine,AGL.refresh_count,AGL.top_discount,AGL.refresh_type,AGL.hide FROM '.DB::table($Fn_Job->TableCompany).' C LEFT JOIN `'.DB::table($Fn_Job->TableCompanyGroup).'` AG on AG.id = C.group_id LEFT JOIN `'.DB::table($Fn_Job->TableCompanyGroupLog).'` AGL on AGL.company_id = C.id '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}

/* ���� */
function GetModulesCount($Where=null){
	global $Fn_Job;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_Job->TableCompany).' C '.$Where;
	return DB::result_first($FetchSql);//��������
}

?>