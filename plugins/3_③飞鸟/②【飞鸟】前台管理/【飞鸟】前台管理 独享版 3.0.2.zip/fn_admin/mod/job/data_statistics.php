<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

//Ȩ���ж�
if(!$Fn_Admin->CheckUserGroup('job_all') && !$Fn_Admin->CheckUserGroup('job_data_statistics')){
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}


$Timestamp = strtotime(date('Y-m-d'));
$WeekDay = strtotime(date('Y-m-d',$Timestamp - (date('N',$Timestamp)-1) * 86400));//���ܵ�һ��
$EndWeekDay = strtotime(date('Y-m-d 23:59:59',strtotime("+6 day",$WeekDay)));

$FirstDay = strtotime(date('Y-m-01', strtotime(date("Y-m-d"))));//���µ�һ��  
$LastDay = strtotime(date('Y-m-d 23:59:59', strtotime("+1 month -1 day",$FirstDay)));//�������һ�� 

$yesterday = strtotime("-1 day",strtotime(date('Y-m-d')));
$endYesterday = strtotime("-1 day",strtotime(date('Y-m-d 23:59:59')));

$LastLasDday = strtotime(date('Y-m-01', strtotime('-1 month',$FirstDay)));//�ϸ��µ�һ��  
$LastFirstDay = strtotime(date('Y-m-t 23:59:59', strtotime('-1 month',$FirstDay)));//�ϸ������һ��

$DayInfoCount = DB::result_first('SELECT COUNT(*) FROM '.DB::table($Fn_Job->TableInfo).' where display = 1 and payment_state = 1 and dateline >= '.strtotime(date('Y-m-d')).' and dateline <='.strtotime(date('Y-m-d 23:59:59')));

$yesterdayInfoCount = DB::result_first('SELECT COUNT(*) FROM '.DB::table($Fn_Job->TableInfo).' where display = 1 and payment_state = 1 and dateline >= '.$yesterday.' and dateline <='.$endYesterday);

$InfoCount = DB::result_first('SELECT COUNT(*) FROM '.DB::table($Fn_Job->TableInfo).' where display = 1 and payment_state = 1');

$DayResumeCount = DB::result_first('SELECT COUNT(*) FROM '.DB::table($Fn_Job->TableResume).' where display = 1 and dateline >= '.strtotime(date('Y-m-d')).' and dateline <='.strtotime(date('Y-m-d 23:59:59')));

$yesterdayResumeCount = DB::result_first('SELECT COUNT(*) FROM '.DB::table($Fn_Job->TableResume).' where display = 1 and dateline >= '.$yesterday.' and dateline <='.$endYesterday);

$DayCompanyCount = DB::result_first('SELECT COUNT(*) FROM '.DB::table($Fn_Job->TableCompany).' where display = 1 and dateline >= '.strtotime(date('Y-m-d')).' and dateline <='.strtotime(date('Y-m-d 23:59:59')));

$yesterdayCompanyCount = DB::result_first('SELECT COUNT(*) FROM '.DB::table($Fn_Job->TableCompany).' where display = 1 and dateline >= '.$yesterday.' and dateline <='.$endYesterday);

$ResumeCount = DB::result_first('SELECT COUNT(*) FROM '.DB::table($Fn_Job->TableResume).' where display = 1');

$CompanyCount = DB::result_first('SELECT COUNT(*) FROM '.DB::table($Fn_Job->TableCompany).' where display = 1');

$VipCompanyCount = DB::result_first('SELECT COUNT(*) FROM '.DB::table($Fn_Job->TableCompany).' where display = 1 and due_time >= '.time());

$DayResumeSeeCount = DB::result_first('SELECT COUNT(*) FROM '.DB::table($Fn_Job->TableResumeSeeLog).' where updateline >= '.strtotime(date('Y-m-d')).' and updateline <='.strtotime(date('Y-m-d 23:59:59')));

$yesterdayResumeSeeCount = DB::result_first('SELECT COUNT(*) FROM '.DB::table($Fn_Job->TableResumeSeeLog).' where updateline >= '.$yesterday.' and updateline <='.$endYesterday);

$DayInfoApplyCount = DB::result_first('SELECT COUNT(*) FROM '.DB::table($Fn_Job->TableInfoApplyLog).' where dateline >= '.strtotime(date('Y-m-d')).' and dateline <='.strtotime(date('Y-m-d 23:59:59')));

$yesterdayInfoApplyCount = DB::result_first('SELECT COUNT(*) FROM '.DB::table($Fn_Job->TableInfoApplyLog).' where dateline >= '.$yesterday.' and dateline <='.$endYesterday);

$examineInfoCount = DB::result_first('SELECT COUNT(*) FROM '.DB::table($Fn_Job->TableInfo).' where display = 0 and payment_state = 1');

$examineCompanyCount = DB::result_first('SELECT COUNT(*) FROM '.DB::table($Fn_Job->TableCompany).' where display = 0');

$examineResumeCount = DB::result_first('SELECT COUNT(*) FROM '.DB::table($Fn_Job->TableResume).' where display = 0');

//����ͳ��
$MonthCountMoney = GetModulesScreenMoneyCount('where source = \'fn_job\' and L.refund = 0 and L.state = 1 and L.dateline >= '.$FirstDay.' and L.dateline <='.$LastDay);

$LastMonthCountMoney = GetModulesScreenMoneyCount('where source = \'fn_job\' and L.refund = 0 and L.state = 1 and L.dateline >= '.$LastLasDday.' and L.dateline <='.$LastFirstDay);

$TodayCountMoney = GetModulesScreenMoneyCount('where source = \'fn_job\' and L.refund = 0 and L.state = 1 and L.dateline >= '.strtotime(date('Y-m-d')).' and L.dateline <='.strtotime(date('Y-m-d 23:59:59')));

$yesterdayCountMoney = GetModulesScreenMoneyCount('where source = \'fn_job\' and L.refund = 0 and L.state = 1 and L.dateline >= '.$yesterday.' and L.dateline <='.$endYesterday);

$WeekCountMoney = GetModulesScreenMoneyCount('where source = \'fn_job\' and L.refund = 0 and L.state = 1 and L.dateline >= '.$WeekDay.' and L.dateline <='.$EndWeekDay);

$CountMoney = GetModulesScreenMoneyCount('where source = \'fn_job\' and L.refund = 0 and L.state = 1 ');

$todayCountNum = DB::result_first('SELECT COUNT(*) FROM '.DB::table($Fn_Admin->Pay->TablePayLog).' L where source = \'fn_job\' and L.refund = 0 and L.state = 1 and L.dateline >= '.strtotime(date('Y-m-d')).' and L.dateline <='.strtotime(date('Y-m-d 23:59:59')));

$yesterdayCountNum = DB::result_first('SELECT COUNT(*) FROM '.DB::table($Fn_Admin->Pay->TablePayLog).' L where source = \'fn_job\' and L.refund = 0 and L.state = 1 and L.dateline >= '.$yesterday.' and L.dateline <='.$endYesterday);

$todayCountUser = count(DB::fetch_all('SELECT * FROM '.DB::table($Fn_Admin->Pay->TablePayLog).' L where source = \'fn_job\' and L.refund = 0 and L.state = 1 and L.dateline >= '.strtotime(date('Y-m-d')).' and L.dateline <='.strtotime(date('Y-m-d 23:59:59')).' GROUP BY L.uid'));

$yesterdayCountUser = count(DB::fetch_all('SELECT * FROM '.DB::table($Fn_Admin->Pay->TablePayLog).' L where source = \'fn_job\' and L.refund = 0 and L.state = 1 and L.dateline >= '.$yesterday.' and L.dateline <='.$endYesterday.' GROUP BY L.uid'));


for($i = 1;$i < 13; $i++){
	$k = $i;
	$YearMonthLast = strtotime(date('Y').'-'.($i > 9 ? $i : '0'.$i).'-01'); 
	$YearMonthFirst = strtotime(date('Y-m-d 23:59:59', strtotime("+1 month -1 day",$YearMonthLast)));
	$YearMonthCount[$k -1]['m'] = date('Y').'-'.($i > 9 ? $i : '0'.$i);
	$YearMonthCount[$k -1]['item'] = GetModulesScreenMoneyCount('where source = \'fn_job\' and L.refund = 0 and L.state = 1 and L.dateline >= '.$YearMonthLast.' and L.dateline <='.$YearMonthFirst);
	
	$LastYearMonthCount[$k -1]['m'] = (date('Y') - 1).'-'.($i > 9 ? $i : '0'.$i);
	$LastYearMonthCount[$k -1]['item'] = GetModulesScreenMoneyCount('where source = \'fn_job\' and L.refund = 0 and L.state = 1 and L.dateline >= '.strtotime('-1 year',$YearMonthLast).' and L.dateline <='.strtotime('-1 year',$YearMonthFirst));
}
$YearMonthCountJson = json_encode($YearMonthCount);
$LastMonthCountJson = json_encode($LastYearMonthCount);

for($i = 0; $i < 30; $i++) {
	$LastTime = $Timestamp - 86400 * $i;
	$EndTime = $LastTime + 86400;
	$ListInfoCount = DB::result_first('SELECT COUNT(*) FROM '.DB::table($Fn_Job->TableInfo).' where  display = 1 and payment_state = 1 and dateline >= '.$LastTime.' and dateline <='.$EndTime);
	$ListResumeCount = DB::result_first('SELECT COUNT(*) FROM '.DB::table($Fn_Job->TableResume).' where display = 1 and dateline >= '.$LastTime.' and dateline <='.$EndTime);
	$InfoList[] = array('m'=>date('Y-m-d',$LastTime),'item'=>$ListInfoCount);
	$ResumeList[] = array('m'=>date('Y-m-d',$LastTime),'item'=>$ListResumeCount);
}
$InfoJson = json_encode($InfoList);
$ResumeJson = json_encode($ResumeList);

for($i = 0; $i < 6; $i++) {
	$MonthFirstDay =  strtotime("-$i month",$FirstDay);
	$MonthLastDay =  strtotime("-$i month",$LastDay);
	$MonthListInfoCount = DB::result_first('SELECT COUNT(*) FROM '.DB::table($Fn_Job->TableInfo).' where  display = 1 and payment_state = 1 and dateline >= '.$MonthFirstDay.' and dateline <='.$MonthLastDay);
	$MonthListResumeCount = DB::result_first('SELECT COUNT(*) FROM '.DB::table($Fn_Job->TableResume).' where display = 1 and dateline >= '.$MonthFirstDay.' and dateline <='.$MonthLastDay);
	$MonthInfoList[] = array('m'=>date('Y-m-d',$MonthFirstDay),'item'=>$MonthListInfoCount);
	$MonthResumeList[] = array('m'=>date('Y-m-d',$MonthFirstDay),'item'=>$MonthListResumeCount);
}
$MonthInfoJson = json_encode($MonthInfoList);
$MonthResumeJson = json_encode($MonthResumeList);

echo <<<TABLE

<div class="row">
  <div class="col-12">
    <div class="box">
      <div class="box-body">
        <div class="flexbox">
          <h5>&#20170;&#26085;&#25968;&#25454;</h5>
        </div>
        <div class="row">
          <div class="col-sm-6 col-lg-3">
            <div class="box-body">
			  <div>&#20184;&#27454;&#37329;&#39069;&#40;&#20803;&#41;</div>
              <div class="font-size-40 font-weight-200">{$TodayCountMoney}</div>
              <div class="font-size-12">&#26152;&#26085;&#65306;{$yesterdayCountMoney}</div>
            </div>
          </div>
          <div class="col-sm-6 col-lg-3">
            <div class="box-body">
			  <div>&#25903;&#20184;&#35746;&#21333;&#25968;&#40;&#21333;&#41;</div>
              <div class="font-size-40 font-weight-200">{$todayCountNum}</div>
              <div class="font-size-12">&#26152;&#26085;&#65306;{$yesterdayCountNum}</div>
            </div>
          </div>
          <div class="col-sm-6 col-lg-3">
            <div class="box-body">
			  <div>&#20184;&#27454;&#20154;&#25968;&#40;&#20154;&#41;</div>
              <div class="font-size-40 font-weight-200">{$todayCountUser}</div>
              <div class="font-size-12">&#26152;&#26085;&#65306;{$yesterdayCountUser}</div>
            </div>
          </div>
		  <div class="col-sm-6 col-lg-3">
            <div class="box-body">
			  <div>&#20844;&#21496;&#40;&#20010;&#41;</div>
              <div class="font-size-40 font-weight-200">{$DayCompanyCount}</div>
              <div class="font-size-12">&#26152;&#26085;&#65306;{$yesterdayCompanyCount}</div>
            </div>
          </div>
        </div>
		<div class="row">
		  <div class="col-sm-6 col-lg-3">
            <div class="box-body">
			  <div>&#32844;&#20301;&#40;&#20010;&#41;</div>
              <div class="font-size-40 font-weight-200">{$DayInfoCount}</div>
              <div class="font-size-12">&#26152;&#26085;&#65306;{$yesterdayInfoCount}</div>
            </div>
          </div>
          <div class="col-sm-6 col-lg-3">
            <div class="box-body">
			  <div>&#32844;&#20301;&#30003;&#35831;&#40;&#20010;&#41;</div>
              <div class="font-size-40 font-weight-200">{$DayInfoApplyCount}</div>
              <div class="font-size-12">&#26152;&#26085;&#65306;{$yesterdayInfoApplyCount}</div>
            </div>
          </div>
          <div class="col-sm-6 col-lg-3">
            <div class="box-body">
			  <div>&#31616;&#21382;&#40;&#20221;&#41;</div>
              <div class="font-size-40 font-weight-200">{$DayResumeCount}</div>
              <div class="font-size-12">&#26152;&#26085;&#65306;{$yesterdayResumeCount}</div>
            </div>
          </div>
          <div class="col-sm-6 col-lg-3">
            <div class="box-body">
			  <div>&#31616;&#21382;&#19979;&#36733;&#40;&#20221;&#41;</div>
              <div class="font-size-40 font-weight-200">{$DayResumeSeeCount}</div>
              <div class="font-size-12">&#26152;&#26085;&#65306;{$yesterdayResumeSeeCount}</div>
            </div>
          </div>
		  
        </div>
      </div>
    </div>
  </div>
  <!-- /.col -->
</div>


<div class="row">
  <div class="col-12">
    <div class="box">
      <div class="box-body">
        <div class="flexbox">
          <h5>&#20449;&#24687;&#25968;&#25454;</h5>
        </div>
        <div class="row">
          <div class="col-sm-6 col-lg-3">
            <div class="box-body">
              <div class="font-size-40 font-weight-200">{$InfoCount}</div>
              <div>&#32844;&#20301;&#24635;&#25968;</div>
            </div>
          </div>
          <div class="col-sm-6 col-lg-3">
            <div class="box-body">
              <div class="font-size-40 font-weight-200">{$ResumeCount}</div>
              <div>&#31616;&#21382;&#24635;&#25968;</div>
            </div>
          </div>
          <div class="col-sm-6 col-lg-3">
            <div class="box-body">
              <div class="font-size-40 font-weight-200">{$CompanyCount}</div>
              <div>&#20844;&#21496;&#24635;&#25968;</div>
            </div>
          </div>
          <div class="col-sm-6 col-lg-3">
            <div class="box-body">
              <div class="font-size-40 font-weight-200">{$VipCompanyCount}</div>
              <div>&#86;&#73;&#80;&#20844;&#21496;&#24635;&#25968;</div>
            </div>
          </div>
		  <div class="col-sm-6 col-lg-3">
            <div class="box-body">
              <div class="font-size-40 font-weight-200">{$examineInfoCount}</div>
              <div>&#24453;&#23457;&#26680;&#32844;&#20301;</div>
            </div>
          </div>
		  <div class="col-sm-6 col-lg-3">
            <div class="box-body">
              <div class="font-size-40 font-weight-200">{$examineCompanyCount}</div>
              <div>&#24453;&#23457;&#26680;&#20844;&#21496;</div>
            </div>
          </div>
		  <div class="col-sm-6 col-lg-3">
            <div class="box-body">
              <div class="font-size-40 font-weight-200">{$examineResumeCount}</div>
              <div>&#24453;&#23457;&#26680;&#31616;&#21382;</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- /.col -->
</div>

<div class="row">
  <div class="col-md-6 col-lg-20">
    <div class="box">
      <div class="box-body">
        <div class="flexbox">
          <h5>&#20170;&#26085;&#20805;&#20540;&#37329;&#39069;</h5>
        </div>
        <div class="text-center my-2">
          <div class="font-size-50">{$TodayCountMoney}</div>
          <span class="text-muted">&#20803;</span> </div>
      </div>
      <div class="card-body bg-gray-light py-12"> <span class="text-muted mr-1"> Top up today</span></div>
    </div>
  </div>
  <!-- /.col -->
  <div class="col-md-6 col-lg-20">
    <div class="box">
      <div class="box-body">
        <div class="flexbox">
          <h5>&#26412;&#21608;&#20805;&#20540;&#37329;&#39069;</h5>
        </div>
        <div class="text-center my-2">
          <div class="font-size-50">{$WeekCountMoney}</div>
          <span class="text-muted">&#20803;</span> </div>
      </div>
      <div class="box-body bg-gray-light py-12"> <span class="text-muted mr-1">Recharge amount this week</span> </div>
    </div>
  </div>
  <!-- /.col -->
  <div class="col-md-6 col-lg-20">
    <div class="box">
      <div class="box-body">
        <div class="flexbox">
          <h5>&#26412;&#26376;&#20805;&#20540;&#37329;&#39069;</h5>
        </div>
        <div class="text-center my-2">
          <div class="font-size-50">{$MonthCountMoney}</div>
          <span class="text-muted">&#20803;</span> </div>
      </div>
      <div class="box-body bg-gray-light py-12"> <span class="text-muted mr-1">Recharge amount of this month</span> </div>
    </div>
  </div>
  <!-- /.col -->
  <div class="col-md-6 col-lg-20">
    <div class="box">
      <div class="box-body">
        <div class="flexbox">
          <h5>&#19978;&#26376;&#20805;&#20540;&#37329;&#39069;</h5>
        </div>
        <div class="text-center my-2">
          <div class="font-size-50">{$LastMonthCountMoney}</div>
          <span class="text-muted">&#20803;</span> </div>
      </div>
      <div class="box-body bg-gray-light py-12"> <span class="text-muted mr-1">Top up amount of last month</span> </div>
    </div>
  </div>
  <!-- /.col -->
  <div class="col-md-6 col-lg-20">
    <div class="box">
      <div class="box-body">
        <div class="flexbox">
          <h5>&#24635;&#20805;&#20540;&#37329;&#39069;</h5>
        </div>
        <div class="text-center my-2">
          <div class="font-size-50">{$CountMoney}</div>
          <span class="text-muted">&#20803;</span> </div>
      </div>
      <div class="box-body bg-gray-light py-12"> <span class="text-muted mr-1">Total recharge amount</span> </div>
    </div>
  </div>
  <!-- /.col -->
</div>

<div class="row">
  <div class="col-xl-6 col-12">
    <div class="box">
      <div class="box-header with-border">
        <h3 class="box-title">&#27599;&#26085;&#26032;&#22686;&#32844;&#20301;&#32479;&#35745;</h3>
        <div class="box-tools pull-right">
          <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i> </button>
          <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
        </div>
      </div>
      <div class="box-body chart-responsive">
        <div class="chart" id="this-info" style="height: 300px;"></div>
      </div>
      <!-- /.box-body -->
    </div>
    <!-- /.box -->
  </div>
  <div class="col-xl-6 col-12">
    <div class="box">
      <div class="box-header with-border">
        <h3 class="box-title">&#27599;&#26085;&#26032;&#22686;&#31616;&#21382;&#32479;&#35745;</h3>
        <div class="box-tools pull-right">
          <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i> </button>
          <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
        </div>
      </div>
      <div class="box-body chart-responsive">
        <div class="chart" id="this-resume" style="height: 300px;"></div>
      </div>
      <!-- /.box-body -->
    </div>
    <!-- /.box -->
  </div>
</div>

<div class="row">
  <div class="col-xl-6 col-12">
    <div class="box">
      <div class="box-header with-border">
        <h3 class="box-title">&#21322;&#24180;&#20869;&#26032;&#22686;&#32844;&#20301;&#32479;&#35745;</h3>
        <div class="box-tools pull-right">
          <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i> </button>
          <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
        </div>
      </div>
      <div class="box-body chart-responsive">
        <div class="chart" id="this-month-info" style="height: 300px;"></div>
      </div>
      <!-- /.box-body -->
    </div>
    <!-- /.box -->
  </div>
  <div class="col-xl-6 col-12">
    <div class="box">
      <div class="box-header with-border">
        <h3 class="box-title">&#21322;&#24180;&#20869;&#26032;&#22686;&#31616;&#21382;&#32479;&#35745;</h3>
        <div class="box-tools pull-right">
          <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i> </button>
          <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
        </div>
      </div>
      <div class="box-body chart-responsive">
        <div class="chart" id="this-month-resume" style="height: 300px;"></div>
      </div>
      <!-- /.box-body -->
    </div>
    <!-- /.box -->
  </div>
</div>

<div class="row">
  <div class="col-xl-6 col-12">
    <div class="box">
      <div class="box-header with-border">
        <h3 class="box-title">&#20170;&#24180;&#26376;&#20221;&#25910;&#20837;</h3>
        <div class="box-tools pull-right">
          <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i> </button>
          <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
        </div>
      </div>
      <div class="box-body chart-responsive">
        <div class="chart" id="this-year" style="height: 300px;"></div>
      </div>
      <!-- /.box-body -->
    </div>
    <!-- /.box -->
  </div>
  <div class="col-xl-6 col-12">
    <div class="box">
      <div class="box-header with-border">
        <h3 class="box-title">&#21435;&#24180;&#26376;&#20221;&#25910;&#20837;</h3>
        <div class="box-tools pull-right">
          <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i> </button>
          <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
        </div>
      </div>
      <div class="box-body chart-responsive">
        <div class="chart" id="last-year" style="height: 300px;"></div>
      </div>
      <!-- /.box-body -->
    </div>
    <!-- /.box -->
  </div>
</div>
<script>
	var line = new Morris.Line({
		element: 'this-year',
		resize: true,
		data:{$YearMonthCountJson},
		xkey: 'm',
		ykeys: ['item'],
		labels: ['&#37329;&#39069;'],
		lineWidth:2,
		pointFillColors: ['rgba(30,136,229,1)'],
		lineColors: ['rgba(30,136,229,1)'],
		hideHover: 'auto'
    });

	var line = new Morris.Line({
		element: 'last-year',
		resize: true,
		data:{$LastMonthCountJson},
		xkey: 'm',
		ykeys: ['item'],
		labels: ['&#37329;&#39069;'],
		lineWidth:2,
		pointFillColors: ['rgba(30,136,229,1)'],
		lineColors: ['rgba(30,136,229,1)'],
		hideHover: 'auto'
    });

	var line = new Morris.Line({
		element: 'this-info',
		resize: true,
		data:{$InfoJson},
		xkey: 'm',
		ykeys: ['item'],
		labels: ['&#26032;&#22686;'],
		lineWidth:2,
		pointFillColors: ['rgba(30,136,229,1)'],
		lineColors: ['rgba(30,136,229,1)'],
		hideHover: 'auto'
    });
    
    var line = new Morris.Line({
		element: 'this-resume',
		resize: true,
		data:{$ResumeJson},
		xkey: 'm',
		ykeys: ['item'],
		labels: ['&#26032;&#22686;'],
		lineWidth:2,
		pointFillColors: ['rgba(30,136,229,1)'],
		lineColors: ['rgba(30,136,229,1)'],
		hideHover: 'auto'
    });

	var line = new Morris.Line({
		element: 'this-month-info',
		resize: true,
		data:{$MonthInfoJson},
		xkey: 'm',
		ykeys: ['item'],
		labels: ['&#26032;&#22686;'],
		lineWidth:2,
		pointFillColors: ['rgba(30,136,229,1)'],
		lineColors: ['rgba(30,136,229,1)'],
		hideHover: 'auto'
    });
    
    var line = new Morris.Line({
		element: 'this-month-resume',
		resize: true,
		data:{$MonthResumeJson},
		xkey: 'm',
		ykeys: ['item'],
		labels: ['&#26032;&#22686;'],
		lineWidth:2,
		pointFillColors: ['rgba(30,136,229,1)'],
		lineColors: ['rgba(30,136,229,1)'],
		hideHover: 'auto'
    });

</script>

TABLE;

/* ɸѡ���� */
function GetModulesScreenMoneyCount($Where=null){
	global $Fn_Admin;
	$SumCount = DB::result_first('SELECT sum(L.money) FROM '.DB::table($Fn_Admin->Pay->TablePayLog).' L '.$Where);
	return $SumCount ? $SumCount : 0;//��������
}
//From: Dism_taobao_com
?>