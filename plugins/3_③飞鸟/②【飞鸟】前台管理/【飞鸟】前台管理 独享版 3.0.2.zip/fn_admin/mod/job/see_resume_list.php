<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('job_all') && !$Fn_Admin->CheckUserGroup('job_see_resume_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$Do = in_array($_GET['do'], array('Del')) ? $_GET['do'] : 'List';

//�����ֶ�
$SearField =array('page','company_id','order','rid','mode','uid');
foreach($SearField as $Val) {
	$SearArray[$Val] = $_GET[$Val] || in_array($_GET[$Val],array('0')) ? $_GET[$Val] : '';
}
//�����ֶ� End

$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeItemUrl'].'&'.http_build_query($SearArray);

if($Do == 'List'){
	if(!submitcheck('Submit')) {
		$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
		/* ��ѯ���� */
		$Where = '';
		$Order = in_array($_GET['order'], array('id')) ? 'L.'.addslashes(dhtmlspecialchars($_GET['order'])) : 'L.id';

		if($_GET['company_id']){
			$Where .= ' and L.company_id = '.intval($_GET['company_id']);
		}

		if($_GET['uid']){
			$Where .= ' and L.uid = '.intval($_GET['uid']);
		}

		if($_GET['rid']){
			$Where .= ' and L.rid = '.intval($_GET['rid']);
		}

		if($_GET['mode']){
			$Where .= ' and L.mode = '.intval($_GET['mode']);
		}
		
		$Where = preg_replace('/and/','where',$Where,1);
		$Limit = 20;
		$Page = $_GET['page']?intval($_GET['page']):1;
		/* ��ѯ���� End */
		

		/* ģ����� */
		showtagheader('div', 'row', true,'row');
		showtagheader('div', 'col-12', true,'col-12');
		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-body', true,'box-body');
		/* ���� */
		$StateSelected = array($_GET['state']=>' selected');
		$ModeSelected = array($_GET['mode']=>' selected');
		echo <<<SEARCH
		<form method="post" autocomplete="off" action="$SearUrl" id="tb_search">
			<div class="FormSearchTo">
				<table cellspacing="4" cellpadding="4">
					<tr>
						<th>{$Fn_Job->Config['LangVar']['SeeLogCompanyUser']}ID</th><td><input type="text" class="input form-control w100" name="company_id" value="{$_GET['company_id']}">
						</td>
						<th>UID</th><td><input type="text" class="input form-control w100" name="uid" value="{$_GET['uid']}">
						</td>
						<th>{$Fn_Job->Config['LangVar']['SeeLogResumeUser']}UID</th><td><input type="text" class="input form-control w100" name="rid" value="{$_GET['rid']}">
						</td>
						<th>{$Fn_Job->Config['LangVar']['Type']}</th><td>
							<select name="mode" class="form-control w120">
								<option value="">{$Fn_Job->Config['LangVar']['SelectNull']}</option>
								<option value="1"{$ModeSelected['1']}>{$Fn_Job->Config['LangVar']['ResumeDownArray']['1']}</option>
								<option value="2"{$ModeSelected['2']}>{$Fn_Job->Config['LangVar']['ResumeDownArray']['2']}</option>
								<option value="3"{$ModeSelected['3']}>{$Fn_Job->Config['LangVar']['ResumeDownArray']['3']}</option>
								<option value="4"{$ModeSelected['4']}>{$Fn_Job->Config['LangVar']['ResumeDownArray']['4']}</option>
							</select>
						&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Admin->Config['LangVar']['SearchSubmit']}" class="btn btn-info" type="submit">
						</td>
					</tr>
				</table>
			</div>
		</form>
SEARCH;
		/* ���� End */
		showtagheader('div', 'table-responsive', true,'table-responsive');
		showformheader($FormUrl,'enctype="multipart/form-data"');
		showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
		showsubtitle(array(
			'ID',
			$Fn_Job->Config['LangVar']['SeeLogCompanyUser'],
			$Fn_Job->Config['LangVar']['SeeLogResumeUser'],
			cplang('view').$Fn_Job->Config['LangVar']['Type'],
			$Fn_Job->Config['LangVar']['TimeTitle'],
			$Fn_Job->Config['LangVar']['OperationTitle']
		), 'header tbm tc');
		
		$ModulesList = GetModulesList($Page,$Limit,$Where,$Order);
		
		foreach ($ModulesList as $Module) {
			$CompanyItem = $Fn_Job->GetViewCompanythread($Module['company_id'],'id');
			$ResumeItem = $Fn_Job->GetViewResumethread($Module['rid']);
			showtablerow('', array('class="tc w100"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
				'<input type="checkbox" class="filled-in" id="checkbox_'.$Module['id'].'" name="delete[]" value="'.$Module['id'].'"><label for="checkbox_'.$Module['id'].'">'.$Module['id'].'</label>',
				$CompanyItem ? $Fn_Job->Config['LangVar']['SeeLogCompanyUser'].'ID:'.$Module['company_id'].'<br>'.$Fn_Job->Config['LangVar']['CompanyName'].':'.$CompanyItem['name'].'&nbsp;&nbsp;<a href="'.$Fn_Job->Config['ViewCompanyUrl'].$CompanyItem['id'].'" target="_blank">['.cplang('view').']</a><br>'.$Fn_Job->Config['LangVar']['ResumeMobile'].':'.$CompanyItem['mobile'] : 'UID:'.$Module['uid'],
				'UID:'.$ResumeItem['uid'].'<br>'.$Fn_Job->Config['LangVar']['ResumeFullName'].':'.$ResumeItem['full_name'].'&nbsp;&nbsp;<a href="'.$Fn_Job->Config['ViewResumeUrl'].$Module['rid'].'" target="_blank">['.cplang('view').']</a><br>'.$Fn_Job->Config['LangVar']['ResumeMobile'].':'.$ResumeItem['mobile'],
				$Fn_Job->Config['LangVar']['ResumeDownArray'][$Module['mode']],
				date('Y-m-d H:i',$Module['dateline']),
				'<a href="'.$OpCpUrl.'&do=Del&lid='.$Module['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$Fn_Job->Config['LangVar']['DelTitle'].'</a>',
			));
		}
		showsubmit('Submit','&#31435;&#21363;&#25552;&#20132;','del','','',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));
		showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		/* ģ����� End */
	}else{
		if(isset($_GET['delete']) && is_array($_GET['delete'])){
			if(!$Fn_Admin->CheckUserGroup('job_all') && !$Fn_Admin->CheckUserGroup('job_del_see_resume_list')){//Ȩ���ж�
				fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
				exit();
			}
			foreach($_GET['delete'] as $Key => $Val) {
				$Val = intval($Val);
				$Item = DB::fetch_first('SELECT * FROM '.DB::table($Fn_Job->TableResumeSeeLog).' where id = '.$Val);
				DB::delete($Fn_Job->TableResumeSeeLog,'id ='.$Val);
				DB::delete($Fn_Job->TableInterview,'rid ='.intval($Item['rid']).' and company_id = '.intval($Item['company_id']));
				DB::query("UPDATE ".DB::table($Fn_Job->TableResume)." SET down_count = down_count - 1 WHERE uid = ".intval($Item['rid']));
			}

			GetInsertDoLog('del_see_resume_list_job','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete'])));//������¼

			fn_cpmsg($Fn_Job->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
		}else{
			fn_cpmsg($Fn_Job->Config['LangVar']['DelErr'],'','error');
		}
	}
}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['lid']){//ɾ��
	if(!$Fn_Admin->CheckUserGroup('job_all') && !$Fn_Admin->CheckUserGroup('job_del_see_resume_list')){//Ȩ���ж�
		fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
		exit();
	}
	$Lid = intval($_GET['lid']);
	$Item = DB::fetch_first('SELECT * FROM '.DB::table($Fn_Job->TableResumeSeeLog).' where id = '.$Lid);
	DB::delete($Fn_Job->TableResumeSeeLog,'id ='.$Lid);
	DB::delete($Fn_Job->TableInterview,'rid ='.intval($Item['rid']).' and company_id = '.intval($Item['company_id']));
	DB::query("UPDATE ".DB::table($Fn_Job->TableResume)." SET down_count = down_count - 1 WHERE uid = ".intval($Item['rid']));
	
	GetInsertDoLog('del_see_resume_list_job','fn_'.$_GET['mod'],array('id'=>$Lid));//������¼

	fn_cpmsg($Fn_Job->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
}

/* �б� */
function GetModulesList($Page,$Limit,$Where=null,$Order){
	global $Fn_Job;
	$FetchSql = 'SELECT L.* FROM '.DB::table($Fn_Job->TableResumeSeeLog).' L '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}

/* ���� */
function GetModulesCount($Where=null){
	global $Fn_Job;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_Job->TableResumeSeeLog).' L '.$Where;
	return DB::result_first($FetchSql);//��������
}
//From: Dism_taobao_com
?>