<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('job_all') && !$Fn_Admin->CheckUserGroup('job_hr_tools_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$SubModel = in_array($_GET['submodel'], array('list','class_list','add')) ? $_GET['submodel'] : 'list';
$Fn_Admin->Config['IframeSubModelUrl'] = $Fn_Admin->Config['IframeItemUrl'].'&submodel='.$SubModel;
$NavClass = array($SubModel=>'btn-info Hover');

//����
echo <<<Nav
<div class="SubModelNav">
  <ul>
	<li class="{$NavClass['list']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=list" target="_self">{$Fn_Admin->Config['LangVar']['JobLeftNavArray'][$_GET['item']]}</a></li>
    <li class="{$NavClass['class_list']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=class_list" target="_self">{$Fn_Admin->Config['LangVar']['ClassTitle']}</a></li>
	<li class="{$NavClass['add']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=add" target="_self">{$Fn_Admin->Config['LangVar']['AddEditTitle']}</a></li>
  </ul>
  <div class="both"></div>
</div>
Nav;

if($SubModel == 'list'){//�б�
	$Do = in_array($_GET['do'], array('Del','Display')) ? $_GET['do'] : 'submodel_list';
	//�����ֶ�
	$SearField =array('page','keyword','classid','display');
	foreach($SearField as $Val) {
		$SearArray[$Val] = $_GET[$Val] || in_array($_GET[$Val],array('0')) ? $_GET[$Val] : '';
	}
	//�����ֶ� End
	$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeSubModelUrl'].'&'.http_build_query($SearArray);


	if($Do == 'submodel_list'){
		if(!submitcheck('Submit')) {
			$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
			$Where = '';
			$Order = in_array($_GET['order'], array('id')) ? 'I.'.addslashes(dhtmlspecialchars($_GET['order'])) : 'I.id';
			
			if($_GET['keyword']){
				$_GET['keyword'] = str_replace(array('%','_'),array('',''),$_GET['keyword']);
				$Where .= ' and ( I.title like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') )';
			}
			
			if($_GET['classid']){
				$Where .= ' and I.classid = '.intval($_GET['classid']);
			}

			if(in_array($_GET['display'],array('0','1'))){
				$Where .= ' and I.display = '.intval($_GET['display']);
			}

			$Where = preg_replace('/and/','where',$Where,1);
			$Limit = 20;
			$Page = $_GET['page']?intval($_GET['page']):1;
			/* ��ѯ���� End */


			/* ģ����� */	
			showtagheader('div', 'row', true,'row');
			showtagheader('div', 'col-12', true,'col-12');
			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-body', true,'box-body');
			/* ���� */
			$DisplaySelected = array($_GET['display']=>' selected');
			$tHrToolsListOption = '<option value="">'.$Fn_Job->Config['LangVar']['SelectNull'].'</option>';
			foreach(DB::fetch_all('SELECT * FROM '.DB::table($Fn_Job->TableHrTools).' order by displayorder desc') as $Val) {
				$tHrToolsListOption .= '<option value="'.$Val['id'].'" '.($_GET['classid'] == $Val['id'] ? ' selected' : '' ).'>'.$Val['title'].'</option>';
			}

			echo <<<SEARCH
			<form method="post" autocomplete="off" action="$SearUrl">
				<div class="FormSearchTo" style="margin-bottom:0;">
					<table cellspacing="4" cellpadding="4">
						<tr>
							<th>{$Fn_Job->Config['LangVar']['KeywordTitle']}</th><td><input type="text" class="input form-control w200" name="keyword" value="{$_GET['keyword']}">
							</td>
							<th>{$Fn_Admin->Config['LangVar']['ClassTitle']}</th><td>
							<select name="classid" class="form-control w120">
								{$tHrToolsListOption}
							</select>
							
							</td>
							<th>{$Fn_Job->Config['LangVar']['DisplayTitle']}</th><td>
							<select name="display" class="form-control w120">
								<option value="">{$Fn_Job->Config['LangVar']['SelectNull']}</option>
								<option value="1"{$DisplaySelected['1']}>{$Fn_Job->Config['LangVar']['Yes']}</option>
								<option value="0"{$DisplaySelected['0']}>{$Fn_Job->Config['LangVar']['No']}</option>
							</select>
							&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Admin->Config['LangVar']['SearchSubmit']}" class="btn btn-info" type="submit">
							</td>
						</tr>
					</table>
				</div>
			</form>
SEARCH;
			/* ���� End */
			showtagheader('div', 'table-responsive', true,'table-responsive');
			showformheader($FormUrl,'enctype="multipart/form-data"');
			showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
			showsubtitle(array(
				'ID',
				$Fn_Job->Config['LangVar']['Title'],
				$Fn_Admin->Config['LangVar']['ClassTitle'],
				$Fn_Job->Config['LangVar']['DisplayTitle'],
				$Fn_Job->Config['LangVar']['TimeTitle'],
				$Fn_Job->Config['LangVar']['OperationTitle']
			),'header tbm tc');

			$ModulesList = $Fn_Job->CompanyListFormat(GetModulesList($Page,$Limit,$Where,$Order));
			foreach ($ModulesList as $Module) {
				
				showtablerow('', array('class="tc w100"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
					'<input type="checkbox" class="filled-in" id="checkbox_'.$Module['id'].'" name="delete[]" value="'.$Module['id'].'"><label for="checkbox_'.$Module['id'].'">'.$Module['id'].'</label>',
					'<a href="'.$Module['file_url'].'">'.$Module['title'].'</a>',
					$Module['class_title'],
					!$Module['display'] ? '<span class="label bg-secondary">'.$Fn_Renovation->Config['LangVar']['No'].'</span>' : '<span class="label bg-blue">'.$Fn_Job->Config['LangVar']['Yes'].'</span>',
					date('Y-m-d H:i',$Module['dateline']),
					'<a href="'.$Module['file_url'].'">'.$Fn_Admin->Config['LangVar']['Download'].'</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&iid='.$Module['id'].'">'.$Fn_Job->Config['LangVar']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Display&iid='.$Module['id'].'&value='.(!empty($Module['display']) ? 0:1).'&formhash='.FORMHASH.'">'.(!empty($Module['display']) ? $Fn_Job->Config['LangVar']['DisplayNoTitle'] : $Fn_Job->Config['LangVar']['DisplayIsTitle']).'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Del&iid='.$Module['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;">'.$Fn_Job->Config['LangVar']['DelTitle'].'</a>',
				));
			}
			showsubmit('Submit','&#31435;&#21363;&#25552;&#20132;','del','','',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));
			showtablefooter(); /*dism��taobao��com*/
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			/* ģ�����End */	
		}else{
			if(!$Fn_Admin->CheckUserGroup('job_all') && !$Fn_Admin->CheckUserGroup('job_del_hr_tools')){//Ȩ���ж�
				fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
				exit();
			}

			if(isset($_GET['delete']) && is_array($_GET['delete'])){
				foreach($_GET['delete'] as $Key => $Val) {
					$Val = intval($Val);
					$Item = DB::fetch_first('SELECT * FROM '.DB::table($Fn_Job->TableHrToolsInfo).' where id = '.$Val);
					DB::delete($Fn_Job->TableHrToolsInfo,'id ='.$Val);
				}

				GetInsertDoLog('del_hr_tools_list_job','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete'])));//������¼

				fn_cpmsg($Fn_Job->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
			}else{
				fn_cpmsg($Fn_Job->Config['LangVar']['DelErr'],'','error');
			}
				
		}
	}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['iid']){
		if(!$Fn_Admin->CheckUserGroup('job_all') && !$Fn_Admin->CheckUserGroup('job_del_hr_tools')){//Ȩ���ж�
			fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
			exit();
		}
		$iid = intval($_GET['iid']);
		DB::delete($Fn_Job->TableHrToolsInfo,'id ='.$iid);
		GetInsertDoLog('del_hr_tools_list_job','fn_'.$_GET['mod'],array('id'=>$iid));//������¼
		fn_cpmsg($Fn_Admin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');

	}else if($Do == 'Display' && $_GET['formhash'] == formhash() && $_GET['iid']){
		$iid = intval($_GET['iid']);
		$UpData['display'] = intval($_GET['value']);
		DB::update($Fn_Job->TableHrToolsInfo,$UpData,'id = '.$iid);
		GetInsertDoLog('display_hr_tools_list_job','fn_'.$_GET['mod'],array('id'=>$iid,'display'=>$_GET['value']));//������¼
		fn_cpmsg($Fn_Job->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

	}
}else if($SubModel == 'class_list'){//����
	$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeSubModelUrl'].'&'.http_build_query($SearArray);
	if(!submitcheck('Submit')) {
	
		showtagheader('div', 'row', true,'row');
		showtagheader('div', 'col-12', true,'col-12');
		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-body', true,'box-body');
		showtagheader('div', 'table-responsive', true,'table-responsive');
		showformheader($FormUrl,'enctype="multipart/form-data"');
		showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');

		showsubtitle(array(
			'ID', 'display_order',
			$Fn_Job->Config['LangVar']['Title'],
			$Fn_Job->Config['LangVar']['Content'],
			$Fn_Job->Config['LangVar']['ClassIco'].'---'.$Fn_Job->Config['LangVar']['ClassIcoTips'],
			$Fn_Job->Config['LangVar']['DisplayTitle']
		),'header tbm tc');

		$ModulesList = GetModulesClassList();
		foreach ($ModulesList as $Module) {
	
			showtablerow('', array('class="tc w50"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
				'<input type="checkbox" class="filled-in" id="checkbox_'.$Module['id'].'" name="delete[]" value="'.$Module['id'].'"><label for="checkbox_'.$Module['id'].'">'.$Module['id'].'</label>',
				'<input type="text" class="input form-control w50" name="displayorder['.$Module['id'].']" value="'.$Module['displayorder'].'" />',
				'<input type="text" class="input form-control w150" name="title['.$Module['id'].']" value="'.$Module['title'].'" />',
				'<textarea class="textarea form-control" name="content['.$Module['id'].']">'.$Module['content'].'</textarea>',
				'<a href="'.$Module['ico'].'" target="_blank"><img src="'.$Module['ico'].'" style="height:30px;margin:0 5px 0 0;"></a><input type="hidden" size="30" name="ico['.$Module['id'].']" value="'.$Module['ico'].'" /> <input name="file_ico['.$Module['id'].']" value="" class="txt uploadbtn" type="file" style="width:200px;">',
				'<input class="with-gap" name="display['.$Module['id'].']" type="radio" value="1" '.($Module['display'] ? 'checked="checked"' : '').' id="v_1_new_display_'.$Module['id'].'"/><label class="custom-control-label" for="v_1_new_display_'.$Module['id'].'">'.$Fn_Job->Config['LangVar']['DisplayIsTitle'].'</label>&nbsp;&nbsp;<input class="with-gap" name="display['.$Module['id'].']" type="radio" value="0" '.( !$Module['display'] ? 'checked="checked"' : '').' id="v_0_new_display_'.$Module['id'].'"/><label class="custom-control-label" for="v_0_new_display_'.$Module['id'].'">'.$Fn_Job->Config['LangVar']['DisplayNoTitle'].'</label>'
			));

			
		}

		showtablerow('', array('class="tc w50"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
			cplang('add_new'),
			sprintf('<input type="text" class="input form-control w50" maxlength="4" name="new_displayorder" value="" />'),
			sprintf('<input type="text" class="input form-control w150" name="new_title" value="" />'),
			sprintf('<textarea rows="2" cols="10" class="textarea form-control" name="new_content"></textarea>'),
			sprintf('<input name="new_ico" value="" class="txt uploadbtn" type="file" style="width:266px;">'),
			sprintf('<input class="with-gap" name="new_display" type="radio" value="1" checked="checked" id="v_1_new_display"/><label class="custom-control-label" for="v_1_new_display">'.$Fn_Job->Config['LangVar']['DisplayIsTitle'].'</label>&nbsp;&nbsp;<input class="with-gap" name="new_display" type="radio" value="0" id="v_0_new_display"/><label class="custom-control-label" for="v_0_new_display">'.$Fn_Job->Config['LangVar']['DisplayNoTitle'].'</label>')
		));

		showsubmit('Submit', '&#20445;&#23384;&#37197;&#32622;', 'del');
		showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
	}else{
		//ɾ��ѡ��
		if(isset($_POST['delete']) && is_array($_POST['delete'])) {
			foreach($_POST['delete'] as $Id){
				$Id = intval($Id);
				DB::delete($Fn_Job->TableHrTools,'id ='.$Id);
				DB::delete($Fn_Job->TableHrToolsInfo,'classid ='.$Id);
			}
		}

		// ����
		if(isset($_POST['displayorder']) && is_array($_POST['displayorder'])) {
			foreach ($_POST['displayorder'] as $Id => $Displayorder) {
				$UpIns = array();
				$Id = intval($Id);
				$UpIns['title'] =  addslashes(strip_tags($_POST['title'][$Id]));
				$UpIns['content'] =  addslashes(strip_tags($_POST['content'][$Id]));
				$UpIns['displayorder'] =  intval($Displayorder);
				$UpIns['display'] =  intval($_POST['display'][$Id]);
		
				if(!empty($_FILES['file_ico']['size'][$Id])) {
					$Ico = array(
						'name' => $_FILES['file_ico']['name'][$Id],
						'type' => $_FILES['file_ico']['type'][$Id],
						'tmp_name' => $_FILES['file_ico']['tmp_name'][$Id],
						'error' => $_FILES['file_ico']['error'][$Id],
						'size' => $_FILES['file_ico']['size'][$Id]
					);
					$IcoFile = Fn_Upload($Ico,$_POST['ico'][$Id]);
					if($IcoFile['Errorcode']){
						fn_cpmsg($Fn_Job->Config['LangVar']['ImgErr'],'','error');
					}else{
						$UpIns['ico'] = $IcoFile['Path'];
					}
				}else{
					$UpIns['ico'] = addslashes(strip_tags($_POST['ico'][$Id]));
				}
				DB::update($Fn_Job->TableHrTools,$UpIns,'id = '.$Id);
			}
		}

		//���ӷ���
		if ($_POST['new_title']) {
			$Ins = array();
			$Ins['title'] = addslashes(strip_tags($_POST['new_title']));
			$Ins['content'] = addslashes(strip_tags($_POST['new_content']));
			$Ins['displayorder'] = intval($_POST['new_displayorder']);
			$Ins['display'] = intval($_POST['new_display']);
			if($_FILES['new_ico']['size']){
				$IcoFile = Fn_Upload($_FILES['new_ico']);
				if($IcoFile['Errorcode']){
					fn_cpmsg($Fn_Job->Config['LangVar']['ImgErr'],'','error');
				}else{
					$Ins['ico'] = $IcoFile['Path'];
				}
			}
			DB::insert($Fn_Job->TableHrTools,$Ins);
		}

		fn_cpmsg($Fn_Job->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
	}
}else if($SubModel == 'add'){//���ӻ�༭
	if(!$Fn_Admin->CheckUserGroup('job_all') && !$Fn_Admin->CheckUserGroup('job_hr_tools_list')){//Ȩ���ж�
		fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
		exit();
	}
	$iid = intval($_GET['iid']);

	$Item = DB::fetch_first('SELECT * FROM '.DB::table($Fn_Job->TableHrToolsInfo).' where id = '.$iid);

	if(!submitcheck('DetailSubmit')) {
		$OpTitle = $Fn_Job->Config['LangVar']['AddTitle'];
		if($Item){
			$OpTitle = $Fn_Job->Config['LangVar']['EditTitle'];
		}

		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-header', true,'with-border box-header');
		showtitle($OpTitle,'class="box-title"');
		showtagfooter('div');
		showformheader($Fn_Admin->Config['IframeSubModelUrl'].'&iid='.$iid,'enctype');
		showtagheader('div', 'box-body', true,'box-body');

		$HrToolsList = array();
		
		foreach($Fn_Job->GetHrToolsList() as $Val) {
			$HrToolsList[] = array($Val['id'], $Val['title']);
		}

		showsetting($Fn_Admin->Config['LangVar']['ClassTitle'], array('classid', $HrToolsList),$Item['classid'], 'select');

		showsetting($Fn_Job->Config['LangVar']['Title'], 'title', $Item['title'], 'text');
		
		$FileUrlHtml =  $Item['file_url'] ? '<label class="checkbox"><input type="checkbox" class="check" name="del_file_url" value="yes" /><span class="ic"></span>'.cplang('del').'</label><br /><a href="'.$Item['file_url'].'">'.$Item['file_url'].'</a><input type="hidden" value="'.$Item['file_url'].'" name="file_url"><br />'.$Fn_Job->Config['LangVar']['HrToolsFileUrlTips'] : $Fn_Job->Config['LangVar']['HrToolsFileUrlTips'];
		
		showsetting($Fn_Job->Config['LangVar']['HrToolsFileUrl'], 'new_file_url','', 'filetext', '', 0, $FileUrlHtml);

		showsetting($Fn_Job->Config['LangVar']['DisplayTitle'], 'display', $Item ? $Item['display'] : 1, 'radio');

		if($Item['dateline']){
			showsetting($Fn_Job->Config['LangVar']['TimeTitle'], 'dateline',date('Y-m-d H:i',$Item['dateline']), 'calendar','','','',1);
		}

		showsubmit('DetailSubmit','&#20445;&#23384;&#37197;&#32622;');
		showtagfooter('div');
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');

	}else{
		$Data['title'] = addslashes(strip_tags($_GET['title']));
		$Data['classid'] = intval($_GET['classid']);
		$Data['display'] = intval($_GET['display']);

		/* �ĵ� */
		if($_GET['del_file_url'] == 'yes'){
			unlink(DISCUZ_ROOT.$Item['file_url']);
			$Data['file_url'] = '';
		}else{
			$Data['file_url'] = addslashes(strip_tags($_GET['file_url']));
		}
		if($_FILES['new_file_url']['size']){
			$FileUrlFile = Fn_Upload($_FILES['new_file_url'],$Item['file_url'],'',1);
			if($FileUrlFile['Errorcode']){
				fn_cpmsg($Fn_Job->Config['LangVar']['ImgErr'],'','error');
				exit();
			}else{
				if(strpos($FileUrlFile['Path'],'http') !== false){
					$Data['file_url']  = $FileUrlFile['Path'];
				}else{
					$UrlArray = parse_url($FileUrlFile['Path']);
					$FileUrlFile['Path'] = $UrlArray['path'];
					$FileName = substr($FileUrlFile['Path'],0,strripos($FileUrlFile['Path'],'.')).'.'; //��ȡ�ļ���
					rename(DISCUZ_ROOT.$FileUrlFile['Path'],DISCUZ_ROOT.$FileName.GetFileext($_FILES['new_file_url']['name']));
					$Data['file_url']  = $FileName.GetFileext($_FILES['new_file_url']['name']);
				}
			}
		}else if($_GET['new_file_url']){
			$Data['file_url'] = addslashes(strip_tags($_GET['new_file_url']));
		}
		$Data['file_url'] = strpos($Data['file_url'],'http') !== false ? $Data['file_url'] : $_G['siteurl'].$Data['file_url'];
		/* �ĵ� End */

		if($Item){

			GetInsertDoLog('edit_hr_tools_list_job','fn_'.$_GET['mod'],array('id'=>$iid));//������¼
			DB::update($Fn_Job->TableHrToolsInfo,$Data,'id = '.$iid);
		}else{
			$Data['dateline'] = time();
			$Id = DB::insert($Fn_Job->TableHrToolsInfo,$Data,true);
			GetInsertDoLog('add_hr_tools_list_job','fn_'.$_GET['mod'],array('id'=>$Id));//������¼
		}
		fn_cpmsg($Fn_Job->Config['LangVar']['UpdateOk'],$Fn_Admin->Config['IframeItemUrl'].'&submodel=list','succeed');
	}
}


/* �б� */
function GetModulesList($Page,$Limit,$Where=null,$Order){
	global $Fn_Job;
	$FetchSql = 'SELECT I.*,T.title as class_title FROM '.DB::table($Fn_Job->TableHrToolsInfo).' I LEFT JOIN `'.DB::table($Fn_Job->TableHrTools).'` T on T.id = I.classid '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}

/* ���� */
function GetModulesCount($Where=null){
	global $Fn_Job;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_Job->TableHrToolsInfo).' I '.$Where;
	return DB::result_first($FetchSql);//��������
}

/* �б� */
function GetModulesClassList($Where = null){
	global $Fn_Job;
	$FetchSql = 'SELECT * FROM '.DB::table($Fn_Job->TableHrTools).$Where.' order by displayorder asc';
	return DB::fetch_all($FetchSql);//��������
}
//From: Dism_taobao_com
?>