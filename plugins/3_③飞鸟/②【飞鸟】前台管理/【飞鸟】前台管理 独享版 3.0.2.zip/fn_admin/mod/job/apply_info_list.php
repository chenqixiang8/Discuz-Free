<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('job_all') && !$Fn_Admin->CheckUserGroup('job_apply_info_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$Do = in_array($_GET['do'], array('Del')) ? $_GET['do'] : 'List';

//�����ֶ�
$SearField =array('page','keyword','order','iid','fid','type','company_id','uid');
foreach($SearField as $Val) {
	$SearArray[$Val] = $_GET[$Val] || in_array($_GET[$Val],array('0')) ? $_GET[$Val] : '';
}
//�����ֶ� End

$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeItemUrl'].'&'.http_build_query($SearArray);

if($Do == 'List'){
	if(!submitcheck('Submit')) {
		$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
		/* ��ѯ���� */
		$Where = '';
		$Order = in_array($_GET['order'], array('id')) ? 'L.'.addslashes(dhtmlspecialchars($_GET['order'])) : 'L.id';

		if($_GET['keyword']){
			$_GET['keyword'] = str_replace(array('%','_'),array('',''),$_GET['keyword']);
			$Where .= ' and (L.username like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or L.uid = '.intval($_GET['keyword']).')';
		}

		if($_GET['company_id']){
			$Where .= ' and L.company_id = '.intval($_GET['company_id']);
		}

		if($_GET['uid']){
			$Where .= ' and L.uid = '.intval($_GET['uid']);
		}

		if($_GET['iid']){
			$Where .= ' and L.iid = '.intval($_GET['iid']);
		}

		if($_GET['fid']){
			$Where .= ' and L.fid = '.intval($_GET['fid']);
		}

		if($_GET['type']){
			$Where .= ' and L.type = '.intval($_GET['type']);
		}
		
		$Where = preg_replace('/and/','where',$Where,1);
		$Limit = 20;
		$Page = $_GET['page']?intval($_GET['page']):1;
		/* ��ѯ���� End */

		/* ģ����� */		
		showtagheader('div', 'row', true,'row');
		showtagheader('div', 'col-12', true,'col-12');
		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-body', true,'box-body');
		/* ���� */
		$TypeSelected = array($_GET['type']=>' selected');
		echo <<<SEARCH
		<form method="post" autocomplete="off" action="$SearUrl" id="tb_search">
			<div class="FormSearchTo">
				<table cellspacing="4" cellpadding="4">
					<tr>
						<th>{$Fn_Job->Config['LangVar']['JobTitleTo']}ID</th><td><input type="text" class="input form-control w100" name="iid" value="{$_GET['iid']}">
						</td>
						<th>{$Fn_Job->Config['LangVar']['CompanyId']}</th><td><input type="text" class="input form-control w100" name="company_id" value="{$_GET['company_id']}">
						</td>
						<th>&#31616;&#21382;&#85;&#73;&#68;</th><td><input type="text" class="input form-control w100" name="uid" value="{$_GET['uid']}">
						</td>
						<th>{$Fn_Job->Config['LangVar']['FairID']}</th><td><input type="text" class="input form-control w100" name="fid" value="{$_GET['fid']}">
						</td>
						<th>{$Fn_Job->Config['LangVar']['InfoApplyLogType']}</th><td>
							<select name="type" class="form-control w120">
								<option value="">{$Fn_Job->Config['LangVar']['SelectNull']}</option>
								<option value="1"{$TypeSelected['1']}>{$Fn_Job->Config['LangVar']['InfoApplyLogTypeArray']['1']}</option>
								<option value="2"{$TypeSelected['2']}>{$Fn_Job->Config['LangVar']['InfoApplyLogTypeArray']['2']}</option>
							</select>
							&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Admin->Config['LangVar']['SearchSubmit']}" class="btn btn-info" type="submit">
						</td>
					</tr>
				</table>
			</div>
		</form>
SEARCH;
		/* ���� End */
		showtagheader('div', 'table-responsive', true,'table-responsive');
		showformheader($FormUrl,'enctype="multipart/form-data"');
		showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
		showsubtitle(array(
			'ID',
			$Fn_Job->Config['LangVar']['Applicant'],
			$Fn_Job->Config['LangVar']['JobTitleTo'],
			$Fn_Job->Config['LangVar']['SeeLogCompanyUser'],
			$Fn_Job->Config['LangVar']['FairTitle'],
			$Fn_Job->Config['LangVar']['InfoApplyLogType'],
			$Fn_Job->Config['LangVar']['SFYXZJL'],
			$Fn_Job->Config['LangVar']['TimeTitle'],
			$Fn_Job->Config['LangVar']['OperationTitle']
		), 'header tbm tc');
		
		$ModulesList = GetModulesList($Page,$Limit,$Where,$Order);
		
		foreach ($ModulesList as $Module) {
			$Item = $Fn_Job->GetViewthread($Module['iid']);
			$CompanyItem = $Fn_Job->GetViewCompanythread($Module['company_id']);
			$ResumeItem = $Fn_Job->GetViewResumethread($Module['uid']);
			$CheckResumeSeeLog = $CompanyItem['uid'] ? DB::fetch_first('SELECT * FROM '.DB::table($Fn_Job->TableResumeSeeLog).' where (company_id = '.intval($CompanyItem['id']).' or uid = '.intval($CompanyItem['uid']).') and rid = '.intval($ResumeItem['uid'])) : '';
			showtablerow('', array('class="tc w100"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
				'<input type="checkbox" class="filled-in" id="checkbox_'.$Module['id'].'" name="delete[]" value="'.$Module['id'].'"><label for="checkbox_'.$Module['id'].'">'.$Module['id'].'</label>',
				$Fn_Job->Config['LangVar']['ResumeFullName'].':'.$ResumeItem['full_name'].'&nbsp;&nbsp;<a href="'.$Fn_Job->Config['ViewResumeUrl'].$Module['uid'].'" target="_blank">['.cplang('view').']</a><br>'.$Fn_Job->Config['LangVar']['ResumeMobile'].':'.$ResumeItem['mobile'],
				$Item['title'].'&nbsp;&nbsp;<a href="'.$Fn_Job->Config['ViewJobUrl'].$Module['iid'].'" target="_blank">['.cplang('view').']</a>',
				$Fn_Job->Config['LangVar']['CompanyName'].':'.$CompanyItem['name'].'&nbsp;&nbsp;<a href="'.$Fn_Job->Config['ViewCompanyUrl'].$CompanyItem['id'].'" target="_blank">['.cplang('view').']</a><br>'.$Fn_Job->Config['LangVar']['ResumeMobile'].':'.$CompanyItem['mobile'],
				$Module['fair_title'] ? $Module['fair_title'].'&nbsp;&nbsp;<a href="'.$Fn_Job->Config['ViewFairUrl'].$Module['fid'].'" target="_blank">['.cplang('view').']</a>' : '',
				$Fn_Job->Config['LangVar']['InfoApplyLogTypeArray'][$Module['type']],
				empty($CheckResumeSeeLog) ? '<span class="red">'.$Fn_Job->Config['LangVar']['No'].'</span>' : $Fn_Job->Config['LangVar']['Yes'],
				date('Y-m-d H:i',$Module['dateline']),
				'&nbsp;&nbsp;&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Del&lid='.$Module['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$Fn_Job->Config['LangVar']['DelTitle'].'</a>',
			));
		}
		showsubmit('Submit','&#31435;&#21363;&#25552;&#20132;','del','','',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));
		showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		/* ģ����� End */
	}else{
		if(isset($_GET['delete']) && is_array($_GET['delete'])){
			if(!$Fn_Admin->CheckUserGroup('job_all') && !$Fn_Admin->CheckUserGroup('job_del_apply_info_list')){//Ȩ���ж�
				fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
				exit();
			}
			foreach($_GET['delete'] as $Key => $Val) {
				$Val = intval($Val);
				$Item = DB::fetch_first('SELECT iid,uid FROM '.DB::table($Fn_Job->TableInfoApplyLog).' where id = '.$Val);
				DB::delete($Fn_Job->TableInfoApplyLog,'id ='.$Val);
				DB::query("UPDATE ".DB::table($Fn_Job->TableInfo)." SET apply_count = apply_count - 1 WHERE id = ".intval($Item['iid']));
				//DB::query("UPDATE ".DB::table($Fn_Job->TableResume)." SET apply_count = apply_count - 1 WHERE uid = ".intval($Item['uid']));
			}

			GetInsertDoLog('del_apply_info_list_job','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete'])));//������¼

			fn_cpmsg($Fn_Job->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
		}else{
			fn_cpmsg($Fn_Job->Config['LangVar']['DelErr'],'','error');
		}
	}
}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['lid']){//ɾ��
	if(!$Fn_Admin->CheckUserGroup('job_all') && !$Fn_Admin->CheckUserGroup('job_del_apply_info_list')){//Ȩ���ж�
		fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
		exit();
	}
	$Lid = intval($_GET['lid']);
	$Item = DB::fetch_first('SELECT iid,uid FROM '.DB::table($Fn_Job->TableInfoApplyLog).' where id = '.$Lid);
	DB::delete($Fn_Job->TableInfoApplyLog,'id ='.$Lid);
	DB::query("UPDATE ".DB::table($Fn_Job->TableInfo)." SET apply_count = apply_count - 1 WHERE id = ".intval($Item['iid']));
	//DB::query("UPDATE ".DB::table($Fn_Job->TableResume)." SET apply_count = apply_count - 1 WHERE uid = ".intval($Item['uid']));
	GetInsertDoLog('del_apply_info_list_job','fn_'.$_GET['mod'],array('id'=>$Lid));//������¼

	fn_cpmsg($Fn_Job->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
}

/* �б� */
function GetModulesList($Page,$Limit,$Where=null,$Order){
	global $Fn_Job;
	$FetchSql = 'SELECT L.*,F.title as fair_title FROM '.DB::table($Fn_Job->TableInfoApplyLog).' L LEFT JOIN `'.DB::table($Fn_Job->TableFair).'` F on F.id = L.fid '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}

/* ���� */
function GetModulesCount($Where=null){
	global $Fn_Job;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_Job->TableInfoApplyLog).' L '.$Where;
	return DB::result_first($FetchSql);//��������
}
//From: Dism_taobao_com
?>