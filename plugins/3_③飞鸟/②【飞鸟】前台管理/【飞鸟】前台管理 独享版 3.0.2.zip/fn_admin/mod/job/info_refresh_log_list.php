<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('job_all') && !$Fn_Admin->CheckUserGroup('job_info_refresh_log_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$Do = in_array($_GET['do'], array('Del','State')) ? $_GET['do'] : 'List';

//�����ֶ�
$SearField =array('page','keyword','type','uid','company_id','iid','uid','order');
foreach($SearField as $Val) {
	$SearArray[$Val] = $_GET[$Val] ? $_GET[$Val] : '';
}
//�����ֶ� End

$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeItemUrl'].'&'.http_build_query($SearArray);

if($Do == 'List'){
	if(!submitcheck('Submit')) {
		$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
		/* ��ѯ���� */
		$Where = '';
		$Order = in_array($_GET['order'], array('id')) ? 'R.'.addslashes(dhtmlspecialchars($_GET['order'])) : 'R.id';

		if($_GET['keyword']){
			$_GET['keyword'] = str_replace(array('%','_'),array('',''),$_GET['keyword']);
			$Where .= ' and (R.username like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or R.content like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or R.uid = '.intval($_GET['keyword']).' )';
		}

		if(in_array($_GET['type'],array('1','2'))){
			$Where .= ' and R.type = '.intval($_GET['type']);
		}
		
		if($_GET['uid']){
			$Where .= ' and R.uid = '.intval($_GET['uid']);
		}

		if($_GET['company_id']){
			$Where .= ' and R.company_id = '.intval($_GET['company_id']);
		}

		if($_GET['iid']){
			$Where .= ' and R.iid = '.intval($_GET['iid']);
		}
		
		$Where = preg_replace('/and/','where',$Where,1);
		$Limit = 30;
		$Page = $_GET['page']?intval($_GET['page']):1;
		/* ��ѯ���� End */
		

		/* ģ����� */
		showtagheader('div', 'row', true,'row');
		showtagheader('div', 'col-12', true,'col-12');
		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-body', true,'box-body');
		/* ���� */
		$TypeSelected = array($_GET['type']=>' selected');
		echo <<<SEARCH
		<form method="post" autocomplete="off" action="$SearUrl" id="tb_search">
			<div class="FormSearchTo">
				<table cellspacing="4" cellpadding="4">
					<tr>
						<th>{$Fn_Job->Config['LangVar']['CompanyId']}</th><td><input type="text" class="input form-control w100" name="company_id" value="{$_GET['company_id']}">
						</td>
						
						<th>{$Fn_Job->Config['LangVar']['JobTitleTo']}ID</th><td><input type="text" class="input form-control w100" name="iid" value="{$_GET['iid']}">
						</td>
						<th>{$Fn_Job->Config['LangVar']['UserNameID']}</th><td><input type="text" class="input form-control w100" name="uid" value="{$_GET['uid']}">
						</td>
						<th>{$Fn_Job->Config['LangVar']['Type']}</th><td>
						<select name="type" class="form-control w120">
							<option value="">{$Fn_Job->Config['LangVar']['SelectNull']}</option>
							<option value="1"{$TypeSelected['1']}>{$Fn_Job->Config['LangVar']['InfoRefreshTypeArray'][1]}</option>
							<option value="2"{$TypeSelected['2']}>{$Fn_Job->Config['LangVar']['InfoRefreshTypeArray'][2]}</option>
						</select>
						&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Admin->Config['LangVar']['SearchSubmit']}" class="btn btn-info" type="submit">
					</tr>
				</table>
			</div>
		</form>
SEARCH;
		/* ���� End */
		showtagheader('div', 'table-responsive', true,'table-responsive');
		showformheader($FormUrl,'enctype="multipart/form-data"');
		showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
		showsubtitle(array(
			'ID',
			'UID/'.$Fn_Job->Config['LangVar']['UserNameTitle'],
			$Fn_Job->Config['LangVar']['CompanyName'],
			$Fn_Job->Config['LangVar']['JobTitleTo'],
			$Fn_Job->Config['LangVar']['Type'],
			$Fn_Job->Config['LangVar']['TimeTitle'],
			$Fn_Job->Config['LangVar']['OperationTitle']
		), 'header tbm tc');
		
		$ModulesList = GetModulesList($Page,$Limit,$Where,$Order);
		
		foreach ($ModulesList as $Module) {
			showtablerow('', array('class="tc w100"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
				'<input type="checkbox" class="filled-in" id="checkbox_'.$Module['id'].'" name="delete[]" value="'.$Module['id'].'"><label for="checkbox_'.$Module['id'].'">'.$Module['id'].'</label>',
				$Module['uid'] ? $Module['uid'].'/'.$Module['username'] : '',
				$Module['company_name'] ? '<a href="'.$Fn_Job->Config['ViewCompanyUrl'].$Module['company_id'].'" target="_blank">'.$Module['company_name'].'</a>' : '',
				'<a href="'.$Fn_Job->Config['ViewJobUrl'].$Module['iid'].'" target="_blank">'.$Module['title'].'</a>',
				'<span class="label bg-danger">'.$Fn_Job->Config['LangVar']['InfoRefreshTypeArray'][$Module['type']].'</span>',
				date('Y-m-d H:i',$Module['dateline']),
				'<a href="'.$OpCpUrl.'&do=Del&rid='.$Module['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$Fn_Job->Config['LangVar']['DelTitle'].'</a>',
			));
		}
		showsubmit('Submit','&#31435;&#21363;&#25552;&#20132;','del','','',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));
		showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		/* ģ����� End */
	}else{
		if(isset($_GET['delete']) && is_array($_GET['delete'])){
			if(!$Fn_Admin->CheckUserGroup('job_all') && !$Fn_Admin->CheckUserGroup('job_del_info_refresh_log_list')){//Ȩ���ж�
				fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
				exit();
			}
			foreach($_GET['delete'] as $Key => $Val) {
				$Val = intval($Val);
				DB::delete($Fn_Job->TableInfoRefreshLog,'id ='.$Val);
			}

			GetInsertDoLog('del_info_refresh_log_list_job','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete'])));//������¼

			fn_cpmsg($Fn_Job->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
		}else{
			fn_cpmsg($Fn_Job->Config['LangVar']['DelErr'],'','error');
		}
	}
}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['rid']){//ɾ��
	if(!$Fn_Admin->CheckUserGroup('job_all') && !$Fn_Admin->CheckUserGroup('job_del_info_refresh_log_list')){//Ȩ���ж�
		fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
		exit();
	}
	$Rid = intval($_GET['rid']);
	DB::delete($Fn_Job->TableInfoRefreshLog,'id ='.$Rid);
	
	GetInsertDoLog('del_info_refresh_log_list_job','fn_'.$_GET['mod'],array('id'=>$_GET['rid']));//������¼

	fn_cpmsg($Fn_Job->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
}
/* �б� */
function GetModulesList($Page,$Limit,$Where=null,$Order){
	global $Fn_Job;
	$FetchSql = 'SELECT C.name as company_name,I.title,R.* FROM '.DB::table($Fn_Job->TableInfoRefreshLog).' R LEFT JOIN `'.DB::table($Fn_Job->TableInfo).'` I on I.id = R.iid LEFT JOIN `'.DB::table($Fn_Job->TableCompany).'` C on C.id = R.company_id 	 '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}

/* ���� */
function GetModulesCount($Where=null){
	global $Fn_Job;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_Job->TableInfoRefreshLog).' R '.$Where;
	return DB::result_first($FetchSql);//��������
}
//From: Dism_taobao_com
?>