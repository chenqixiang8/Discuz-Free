<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('job_all') && !$Fn_Admin->CheckUserGroup('job_fair_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$SubModel = in_array($_GET['submodel'], array('list','company_list','add')) ? $_GET['submodel'] : 'list';
$Fn_Admin->Config['IframeSubModelUrl'] = $Fn_Admin->Config['IframeItemUrl'].'&submodel='.$SubModel;
$NavClass = array($SubModel=>'btn-info Hover');

//����
echo <<<Nav
<div class="SubModelNav">
  <ul>
	<li class="{$NavClass['list']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=list" target="_self">{$Fn_Admin->Config['LangVar']['JobLeftNavArray'][$_GET['item']]}</a></li>
	<li class="{$NavClass['company_list']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=company_list" target="_self">{$Fn_Admin->Config['LangVar']['JobFairCompany']}</a></li>
	<li class="{$NavClass['add']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=add" target="_self">{$Fn_Admin->Config['LangVar']['AddEditTitle']}</a></li>
  </ul>
  <div class="both"></div>
</div>
Nav;

if($SubModel == 'list'){//�б�
	$Do = in_array($_GET['do'], array('Del','Display')) ? $_GET['do'] : 'submodel_list';
	//�����ֶ�
	$SearField =array('page','keyword','type','display');
	foreach($SearField as $Val) {
		$SearArray[$Val] = $_GET[$Val] || in_array($_GET[$Val],array('0')) ? $_GET[$Val] : '';
	}
	//�����ֶ� End
	$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeSubModelUrl'].'&'.http_build_query($SearArray);


	if($Do == 'submodel_list'){
		if(!submitcheck('Submit')) {
			$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
			$Where = '';
			$Order = in_array($_GET['order'], array('id')) ? 'F.'.addslashes(dhtmlspecialchars($_GET['order'])) : 'F.id';
			
			if($_GET['keyword']){
				$_GET['keyword'] = str_replace(array('%','_'),array('',''),$_GET['keyword']);
				$Where .= ' and ( F.title like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') )';
			}
			
			if(in_array($_GET['display'],array('0','1'))){
				$Where .= ' and F.display = '.intval($_GET['display']);
			}

			if($_GET['type']){
				$Where .= ' and F.type = '.intval($_GET['type']);
			}


			$Where = preg_replace('/and/','where',$Where,1);
			$Limit = 20;
			$Page = $_GET['page']?intval($_GET['page']):1;
			/* ��ѯ���� End */
	
			/* ģ����� */	
			showtagheader('div', 'row', true,'row');
			showtagheader('div', 'col-12', true,'col-12');
			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-body', true,'box-body');
			/* ���� */
			$DisplaySelected = array($_GET['display']=>' selected');
			$TypsSelected = array($_GET['type']=>' selected');
			echo <<<SEARCH
			<form method="post" autocomplete="off" action="$SearUrl">
				<div class="FormSearchTo" style="margin-bottom:0;">
					<table cellspacing="4" cellpadding="4">
						<tr>
							<th>{$Fn_Job->Config['LangVar']['KeywordTitle']}</th><td><input type="text" class="input form-control w200" name="keyword" value="{$_GET['keyword']}">
							</td>
							<th>{$Fn_Job->Config['LangVar']['Type']}</th><td>
							<select name="type" class="form-control w120">
								<option value="">{$Fn_Job->Config['LangVar']['SelectNull']}</option>
								<option value="1"{$TypsSelected['1']}>{$Fn_Job->Config['LangVar']['FairTypeArray']['1']}</option>
							</select>
							</td>
							<th>{$Fn_Job->Config['LangVar']['DisplayTitle']}</th><td>
							<select name="display" class="form-control w120">
								<option value="">{$Fn_Job->Config['LangVar']['SelectNull']}</option>
								<option value="1"{$DisplaySelected['1']}>{$Fn_Job->Config['LangVar']['Yes']}</option>
								<option value="0"{$DisplaySelected['0']}>{$Fn_Job->Config['LangVar']['No']}</option>
							</select>
							&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Admin->Config['LangVar']['SearchSubmit']}" class="btn btn-info" type="submit">
							</td>
						</tr>
					</table>
				</div>
			</form>
SEARCH;
			/* ���� End */

			showtagheader('div', 'table-responsive', true,'table-responsive');
			showformheader($FormUrl,'enctype="multipart/form-data"');
			showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');

			showsubtitle(array(
				'ID',
				$Fn_Job->Config['LangVar']['Title'],
				$Fn_Job->Config['LangVar']['Type'],
				$Fn_Job->Config['LangVar']['CHQY'],
				$Fn_Job->Config['LangVar']['NumberApplicants'],
				$Fn_Job->Config['LangVar']['Click'],
				$Fn_Job->Config['LangVar']['DisplayTitle'],
				$Fn_Job->Config['LangVar']['StartTime'],
				$Fn_Job->Config['LangVar']['EndTime'],
				$Fn_Job->Config['LangVar']['TimeTitle'],
				$Fn_Job->Config['LangVar']['OperationTitle']
			),'header tbm tc');

			$ModulesList = GetModulesList($Page,$Limit,$Where,$Order);
			foreach ($ModulesList as $Module) {
				
				showtablerow('', array('class="tc w50"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
					'<input type="checkbox" class="filled-in" id="checkbox_'.$Module['id'].'" name="delete[]" value="'.$Module['id'].'"><label for="checkbox_'.$Module['id'].'">'.$Module['id'].'</label>',
					$Module['title'],
					$Fn_Job->Config['LangVar']['FairTypeArray'][$Module['type']],
					'<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=company_list&fid='.$Module['id'].'">'.DB::result_first('SELECT COUNT(*) FROM '.DB::table($Fn_Job->TableFairCompany).' where fid = '.intval($Module['id'])).'</a>',
					'<a href="'.$Fn_Admin->Config['ModUrl'].'&iframe=true&item=apply_info_list&fid='.$Module['id'].'">'.DB::result_first('SELECT COUNT(*) FROM '.DB::table($Fn_Job->TableInfoApplyLog).' where fid = '.intval($Module['id'])).'</a>',
					$Module['click'],
					!$Module['display'] ? '<span class="label bg-secondary">'.$Fn_Job->Config['LangVar']['No'].'</span>' : '<span class="label bg-blue">'.$Fn_Job->Config['LangVar']['Yes'].'</span>',
					$Module['start_time'] ? date('Y-m-d H:i',$Module['start_time']) : '',
					$Module['end_time'] ? date('Y-m-d H:i',$Module['end_time']) : '',
					date('Y-m-d H:i',$Module['dateline']),
					'<a href="'.$Fn_Job->Config['ViewFairUrl'].$Module['id'].'" target="_blank">'.cplang('view').'</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&fid='.$Module['id'].'">'.$Fn_Job->Config['LangVar']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Display&fid='.$Module['id'].'&value='.(!empty($Module['display']) ? 0:1).'&formhash='.FORMHASH.'">'.(!empty($Module['display']) ? $Fn_Job->Config['LangVar']['DisplayNoTitle'] : $Fn_Job->Config['LangVar']['DisplayIsTitle']).'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Del&fid='.$Module['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;">'.$Fn_Job->Config['LangVar']['DelTitle'].'</a><br><a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=company_list&do=Add&fid='.$Module['id'].'">'.$Fn_Job->Config['LangVar']['TJCYGS'].'</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=company_list&fid='.$Module['id'].'">'.$Fn_Job->Config['LangVar']['GLCYGS'].'</a>',
				));
			}
			showsubmit('Submit','&#31435;&#21363;&#25552;&#20132;','del','','',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));
			showtablefooter(); /*dism��taobao��com*/
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			/* ģ�����End */	
		}else{
			if(!$Fn_Admin->CheckUserGroup('job_all') && !$Fn_Admin->CheckUserGroup('job_del_fair')){//Ȩ���ж�
				fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
				exit();
			}

			if(isset($_GET['delete']) && is_array($_GET['delete'])){
				foreach($_GET['delete'] as $Key => $Val) {
					$Val = intval($Val);
					$Item = DB::fetch_first('SELECT * FROM '.DB::table($Fn_Job->TableFair).' where id = '.$Val);
					DB::delete($Fn_Job->TableFair,'id ='.$Val);
					DB::delete($Fn_Job->TableFairCompany,'fid ='.$Val);
				}

				GetInsertDoLog('del_fair_job','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete'])));//������¼

				fn_cpmsg($Fn_Job->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
			}else{
				fn_cpmsg($Fn_Job->Config['LangVar']['DelErr'],'','error');
			}
				
		}
	}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['fid']){
		if(!$Fn_Admin->CheckUserGroup('job_all') && !$Fn_Admin->CheckUserGroup('job_del_fair')){//Ȩ���ж�
			fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
			exit();
		}
		$id = intval($_GET['fid']);
		DB::delete($Fn_Job->TableFair,'id ='.$id);
		DB::delete($Fn_Job->TableFairCompany,'fid ='.$id);
		GetInsertDoLog('del_fair_job','fn_'.$_GET['mod'],array('id'=>$id));//������¼
		fn_cpmsg($Fn_Admin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');

	}else if($Do == 'Display' && $_GET['formhash'] == formhash() && $_GET['fid']){
		$id = intval($_GET['fid']);
		$UpData['display'] = intval($_GET['value']);
		DB::update($Fn_Job->TableFair,$UpData,'id = '.$id);
		GetInsertDoLog('display_fair_job','fn_'.$_GET['mod'],array('id'=>$id,'display'=>$_GET['value']));//������¼
		fn_cpmsg($Fn_Job->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

	}
}else if($SubModel == 'company_list'){//�б�
	$Do = in_array($_GET['do'], array('Del','Add','Refresh','Display','Hot')) ? $_GET['do'] : 'submodel_list';
	//�����ֶ�
	$SearField =array('page','fid','company_id','type','order','display','hot');
	foreach($SearField as $Val) {
		$SearArray[$Val] = $_GET[$Val] || in_array($_GET[$Val],array('0')) ? $_GET[$Val] : '';
	}
	//�����ֶ� End
	$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeSubModelUrl'].'&'.http_build_query($SearArray);

	if($Do == 'submodel_list'){
		if(!submitcheck('Submit')) {
			$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
			$Where = '';
			$Order = in_array($_GET['order'], array('id','updateline','dateline')) ? 'C.'.addslashes(dhtmlspecialchars($_GET['order'])) : 'C.id';
			
			if($_GET['fid']){
				$Where .= ' and C.fid = '.intval($_GET['fid']);
			}

			if($_GET['company_id']){
				$Where .= ' and C.company_id = '.intval($_GET['company_id']);
			}

			if(in_array($_GET['hot'],array('0','1'))){
				$Where .= ' and C.hot = '.intval($_GET['hot']);
			}
			if($_GET['type']){
				$Where .= ' and C.type = '.intval($_GET['type']);
			}

			if(in_array($_GET['display'],array('0','1'))){
				$Where .= ' and C.display = '.intval($_GET['display']);
			}

			$Where = preg_replace('/and/','where',$Where,1);
			$Limit = 20;
			$Page = $_GET['page']?intval($_GET['page']):1;
			/* ��ѯ���� End */
			

			/* ģ����� */	
			showtagheader('div', 'row', true,'row');
			showtagheader('div', 'col-12', true,'col-12');
			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-body', true,'box-body');
			/* ���� */

			$TypsSelected = array($_GET['type']=>' selected');
			$HotSelected = array($_GET['hot']=>' selected');
			$DisplaySelected = array($_GET['display']=>' selected');
			$OrderSelected = array($_GET['order']=>' selected');
			echo <<<SEARCH
			<form method="post" autocomplete="off" action="$FormUrl">
				<div class="FormSearchTo" style="margin-bottom:0;">
					<table cellspacing="4" cellpadding="4">
						<tr>
							
							<th>{$Fn_Job->Config['LangVar']['FairID']}</th><td><input type="text" class="input form-control w100" name="fid" value="{$_GET['fid']}">
							</td>
							<th>{$Fn_Job->Config['LangVar']['CompanyId']}</th><td><input type="text" class="input form-control w100" name="company_id" value="{$_GET['company_id']}">
							</td>
							<th>{$Fn_Job->Config['LangVar']['Type']}</th><td>
							<select name="type" class="form-control w120">
								<option value="">{$Fn_Job->Config['LangVar']['SelectNull']}</option>
								<option value="1"{$TypsSelected['1']}>{$Fn_Job->Config['LangVar']['FairCompanyTypeArray']['1']}</option>
								<option value="2"{$TypsSelected['2']}>{$Fn_Job->Config['LangVar']['FairCompanyTypeArray']['2']}</option>
							</select>
							</td>
							<th>{$Fn_Job->Config['LangVar']['RecommendTitle']}</th><td>
							<select name="hot" class="form-control w120">
								<option value="">{$Fn_Job->Config['LangVar']['SelectNull']}</option>
								<option value="1"{$HotSelected['1']}>{$Fn_Job->Config['LangVar']['Yes']}</option>
								<option value="0"{$HotSelected['0']}>{$Fn_Job->Config['LangVar']['No']}</option>
							</select>
							</td>
							<th>{$Fn_Job->Config['LangVar']['DisplayTitle']}</th><td>
							<select name="display" class="form-control w120">
								<option value="">{$Fn_Job->Config['LangVar']['SelectNull']}</option>
								<option value="1"{$DisplaySelected['1']}>{$Fn_Job->Config['LangVar']['Yes']}</option>
								<option value="0"{$DisplaySelected['0']}>{$Fn_Job->Config['LangVar']['No']}</option>
							</select>
							</td>
							<th>{$Fn_Admin->Config['LangVar']['Order']}</th><td>
							
							<select name="order" class="form-control w120">
								<option value="dateline"{$OrderSelected['dateline']}>{$Fn_Admin->Config['LangVar']['OrderArray']['dateline']}</option>
								<option value="updateline"{$OrderSelected['updateline']}>{$Fn_Admin->Config['LangVar']['OrderArray']['updateline']}</option>
							</select>
							&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Admin->Config['LangVar']['SearchSubmit']}" class="btn btn-info" type="submit">
							</td>
						</tr>
					</table>
				</div>
			</form>
SEARCH;
			/* ���� End */
			showtagheader('div', 'table-responsive', true,'table-responsive');
			showformheader($FormUrl,'enctype="multipart/form-data"');
			showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
			showsubtitle(array(
				'ID',
				$Fn_Job->Config['LangVar']['Title'],
				$Fn_Job->Config['LangVar']['CompanyName'],
				$Fn_Job->Config['LangVar']['NumberApplicants'],
				$Fn_Job->Config['LangVar']['Type'],
				$Fn_Job->Config['LangVar']['RecommendTitle'],
				$Fn_Job->Config['LangVar']['DisplayTitle'],
				$Fn_Job->Config['LangVar']['SetTopTime'],
				$Fn_Job->Config['LangVar']['RefreshTime'],
				$Fn_Job->Config['LangVar']['TimeTitle'],
				$Fn_Job->Config['LangVar']['OperationTitle']
			),'header tbm tc');

			$ModulesList = GetCompanyModulesList($Page,$Limit,$Where,$Order);
			foreach ($ModulesList as $Module) {
				
				showtablerow('', array('class="tc w50"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
					'<input type="checkbox" class="filled-in" id="checkbox_'.$Module['id'].'" name="delete[]" value="'.$Module['id'].'"><label for="checkbox_'.$Module['id'].'">'.$Module['id'].'</label>',
					'<a href="'.$Fn_Job->Config['ViewFairUrl'].$Module['fid'].'" target="_blank">'.$Module['title'].'</a>',
					'<a href="'.$Fn_Job->Config['ViewCompanyUrl'].$Module['company_id'].'" target="_blank">'.$Module['name'].'</a>',
					'<a href="'.$Fn_Admin->Config['ModUrl'].'&iframe=true&item=apply_info_list&company_id='.$Module['company_id'].'&fid='.$Module['fid'].'">'.DB::result_first('SELECT COUNT(*) FROM '.DB::table($Fn_Job->TableInfoApplyLog).' where company_id = '.intval($Module['company_id']).' and fid = '.intval($Module['fid'])).'</a>',
					$Fn_Job->Config['LangVar']['FairCompanyTypeArray'][$Module['type']],
					!$Module['hot'] ? '<span class="label bg-secondary">'.$Fn_Job->Config['LangVar']['No'].'</span>' : '<span class="label bg-blue">'.$Fn_Job->Config['LangVar']['Yes'].'</span>',
					!$Module['display'] ? '<span class="label bg-secondary">'.$Fn_Job->Config['LangVar']['No'].'</span>' : '<span class="label bg-blue">'.$Fn_Job->Config['LangVar']['Yes'].'</span>',
					$Module['topdateline'] >= time() ? date('Y-m-d',$Module['topdateline']) : ($Module['topdateline'] ? '<span class="red">'.$Fn_Job->Config['LangVar']['Expired'].'</span>' : ''),
					FormatDate($Module['updateline'],'Y-m-d'),
					date('Y-m-d H:i',$Module['dateline']),
					'<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=company_list&do=Add&cid='.$Module['id'].'" class="btn btn-sm btn-info-outline">'.$Fn_Job->Config['LangVar']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Refresh&cid='.$Module['id'].'&formhash='.FORMHASH.'" class="btn btn-sm btn-primary-outline">'.$Fn_Job->Config['LangVar']['Refresh'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Hot&cid='.$Module['id'].'&value='.(!empty($Module['hot']) ? 0:1).'&formhash='.FORMHASH.'" class="btn btn-sm btn-success-outline">'.(!empty($Module['hot']) ? $Fn_Job->Config['LangVar']['RecommendNoTitle'] : $Fn_Job->Config['LangVar']['RecommendTitle']).'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Display&cid='.$Module['id'].'&value='.(!empty($Module['display']) ? 0:1).'&formhash='.FORMHASH.'" class="btn btn-sm btn-purple-outline">'.(!empty($Module['display']) ? $Fn_Job->Config['LangVar']['DisplayNoTitle'] : $Fn_Job->Config['LangVar']['DisplayIsTitle']).'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Del&cid='.$Module['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$Fn_Job->Config['LangVar']['DelTitle'].'</a>',
				));
			}
			showsubmit('Submit','&#31435;&#21363;&#25552;&#20132;','del','','',multi(GetCompanyModulesCount($Where),$Limit,$Page,$MpUrl));
			showtablefooter(); /*dism��taobao��com*/
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			/* ģ�����End */	
		}else{
			if(!$Fn_Admin->CheckUserGroup('job_all') && !$Fn_Admin->CheckUserGroup('job_del_fair_company')){//Ȩ���ж�
				fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
				exit();
			}

			if(isset($_GET['delete']) && is_array($_GET['delete'])){
				foreach($_GET['delete'] as $Key => $Val) {
					$Val = intval($Val);
					DB::delete($Fn_Job->TableFairCompany,'id ='.$Val);
				}

				GetInsertDoLog('del_fair_company_job','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete'])));//������¼

				fn_cpmsg($Fn_Job->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
			}else{
				fn_cpmsg($Fn_Job->Config['LangVar']['DelErr'],'','error');
			}
				
		}
	}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['cid']){
		if(!$Fn_Admin->CheckUserGroup('job_all') && !$Fn_Admin->CheckUserGroup('job_del_fair_company')){//Ȩ���ж�
			fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
			exit();
		}
		$id = intval($_GET['cid']);
		DB::delete($Fn_Job->TableFairCompany,'id ='.$id);
		GetInsertDoLog('del_fair_company_job','fn_'.$_GET['mod'],array('id'=>$id));//������¼
		fn_cpmsg($Fn_Admin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');

	}else if($Do == 'Hot' && $_GET['formhash'] == formhash() && $_GET['cid']){
		$id = intval($_GET['cid']);
		$UpData['hot'] = intval($_GET['value']);
		DB::update($Fn_Job->TableFairCompany,$UpData,'id = '.$id);
		GetInsertDoLog('hot_fair_company_job','fn_'.$_GET['mod'],array('id'=>$id));//������¼
		fn_cpmsg($Fn_Job->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

	}else if($Do == 'Display' && $_GET['formhash'] == formhash() && $_GET['cid']){
		$id = intval($_GET['cid']);
		$UpData['display'] = intval($_GET['value']);
		DB::update($Fn_Job->TableFairCompany,$UpData,'id = '.$id);
		GetInsertDoLog('display_fair_company_job','fn_'.$_GET['mod'],array('id'=>$id));//������¼
		fn_cpmsg($Fn_Job->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

	}else if($Do == 'Refresh' && $_GET['formhash'] == formhash() && $_GET['cid']){
		$id = intval($_GET['cid']);
		$UpData['updateline'] = time();
		DB::update($Fn_Job->TableFairCompany,$UpData,'id = '.$id);
		GetInsertDoLog('refresh_fair_company_job','fn_'.$_GET['mod'],array('id'=>$id));//������¼
		fn_cpmsg($Fn_Job->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

	}else if($Do == 'Add'){
		if(!$Fn_Admin->CheckUserGroup('job_all') && !$Fn_Admin->CheckUserGroup('job_fair_list')){//Ȩ���ж�
			fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
			exit();
		}
		$id = intval($_GET['cid']);
		$Item = DB::fetch_first('SELECT * FROM '.DB::table($Fn_Job->TableFairCompany).' where id = '.$id);
		if(!submitcheck('DetailSubmit')) {
			$OpTitle = $Fn_Job->Config['LangVar']['AddTitle'];
			if($Item){
				$OpTitle = $Fn_Job->Config['LangVar']['EditTitle'];
			}

			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-header', true,'with-border box-header');
			showtitle($OpTitle,'class="box-title"');
			showtagfooter('div');
			showformheader($Fn_Admin->Config['IframeSubModelUrl'].'&do=Add&cid='.$id.'&fid='.($Item['fid'] ? $Item['fid'] : $_GET['fid']),'enctype');
			showtagheader('div', 'box-body', true,'box-body');

			showsetting($Fn_Job->Config['LangVar']['FairID'], 'fid', $Item['fid'] ? $Item['fid'] : $_GET['fid'], 'text');
			
			if($Item){
				showsetting($Fn_Job->Config['LangVar']['CompanyId'], 'company_id', $Item['company_id'], 'text');
				
				showsetting($Fn_Job->Config['LangVar']['RecommendTitle'], 'hot', $Item['hot'], 'radio');

				showsetting($Fn_Job->Config['LangVar']['SetTopTime'], 'topdateline',$Item['topdateline'] ? date('Y-m-d H:i',$Item['topdateline']) : '', 'calendar','','','',1);
				
			}else{
				showsetting($Fn_Job->Config['LangVar']['CompanyId'], 'company_id','', 'textarea','','',$Fn_Job->Config['LangVar']['CompanyIdTips']);
			}
		
			if($Item['updateline']){
				showsetting($Fn_Job->Config['LangVar']['RefreshTime'], 'updateline',$Item['updateline'] ? date('Y-m-d H:i',$Item['updateline']) : '', 'calendar','','','',1);
			}

			if($Item['dateline']){
				showsetting($Fn_Job->Config['LangVar']['TimeTitle'], 'dateline',date('Y-m-d H:i',$Item['dateline']), 'calendar','','','',1);
			}

			showsubmit('DetailSubmit','&#20445;&#23384;&#37197;&#32622;');
			showtagfooter('div');
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');

			echo '<script type="text/javascript" src="static/js/calendar.js"></script>';

		}else{
			
			$Data['fid'] = intval($_GET['fid']);
			$Data['company_id'] = intval($_GET['company_id']);
			$Data['hot'] = intval($_GET['hot']);
			$Data['topdateline'] = $_GET['topdateline'] ? strtotime($_GET['topdateline']) : '';

			if($Item){
				$Data['updateline'] = strtotime($_GET['updateline']);
				GetInsertDoLog('edit_fair_company_job','fn_'.$_GET['mod'],array('id'=>$id));//������¼
				DB::update($Fn_Job->TableFairCompany,$Data,'id = '.$id);
			}else{
				
				$FairItem = DB::fetch_first('SELECT * FROM '.DB::table($Fn_Job->TableFair).' where id = '.$Data['fid']);
				if($FairItem){
					
					$Ids = array();
					foreach (array_filter(explode("\r\n",$_GET['company_id'])) as $Val) {
						list($CompanyId,$Hot) = explode('|',$Val);
						$CompanyItem = DB::fetch_first('SELECT * FROM '.DB::table($Fn_Job->TableCompany).' where id = '.intval($CompanyId));
						$FairCompanyItem = DB::fetch_first('SELECT * FROM '.DB::table($Fn_Job->TableFairCompany).' where company_id = '.intval($CompanyId).' and  fid = '.intval($FairItem['id']));
						if($CompanyItem && !$FairCompanyItem){
							$InsertData['fid'] = intval($FairItem['id']);
							$InsertData['dateline'] = $InsertData['updateline'] = time();
							$InsertData['company_id'] = $CompanyId;
							$InsertData['hot'] = $Hot;
							$Ids[] = DB::insert($Fn_Job->TableFairCompany,$InsertData,true);
						}
					}
	
					GetInsertDoLog('add_fair_company_job','fn_'.$_GET['mod'],array('ids'=>implode(',',$Ids)));//������¼
				}
				
			}
			fn_cpmsg($Fn_Job->Config['LangVar']['UpdateOk'],$Fn_Admin->Config['IframeItemUrl'].'&submodel=company_list&fid='.$Data['fid'],'succeed');
		}
	}
}else if($SubModel == 'add'){//���ӻ�༭
	if(!$Fn_Admin->CheckUserGroup('job_all') && !$Fn_Admin->CheckUserGroup('job_fair_list')){//Ȩ���ж�
		fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
		exit();
	}
	$id = intval($_GET['fid']);

	$Item = $NewItem = DB::fetch_first('SELECT * FROM '.DB::table($Fn_Job->TableFair).' where id = '.$id);

	if(!submitcheck('DetailSubmit')) {
		$OpTitle = $Fn_Job->Config['LangVar']['AddTitle'];
		if($Item){
			$Item['param'] = unserialize($Item['param']);
			$OpTitle = $Fn_Job->Config['LangVar']['EditTitle'];
		}

		//ͼƬ�ϴ�
		if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_assembly/class/class_upload.php')){
			@require_once libfile('class/upload','plugin/fn_assembly');
			$UploadConfig = fn_upload::Config();
		}

		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-header', true,'with-border box-header');
		showtitle($OpTitle,'class="box-title"');
		showtagfooter('div');
		showformheader($Fn_Admin->Config['IframeSubModelUrl'].'&fid='.$id,'enctype');
		showtagheader('div', 'box-body', true,'box-body');
		
		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_Job->Config['LangVar']['FairBanner'].'</label><div class="col-sm-9"><div class="AdminSingleUpload"><div class="PhotoControl" id="Banner"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';
		
		showsetting($Fn_Job->Config['LangVar']['FairBannerLink'], 'banner_link', $Item['banner_link'], 'text');

		showsetting($Fn_Job->Config['LangVar']['Title'], 'title', $Item['title'], 'text');
		
		showsetting($Fn_Job->Config['LangVar']['StartTime'], 'start_time',$Item['start_time'] ? date('Y-m-d H:i',$Item['start_time']) : '', 'calendar','','','',1);

		showsetting($Fn_Job->Config['LangVar']['EndTime'], 'end_time',$Item['end_time'] ? date('Y-m-d H:i',$Item['end_time']) : '', 'calendar','','','',1);

		showsetting($Fn_Job->Config['LangVar']['Content'], 'content', stripslashes($Item['content']), 'textarea');

		showsetting($Fn_Job->Config['LangVar']['Type'],array('type', array(
			array('1',$Fn_Job->Config['LangVar']['FairTypeArray']['1'], array('type_table_1' => '', 'type_table_2' => 'none')),
			//array('2',$Fn_Job->Config['LangVar']['FairTypeArray']['2'], array('type_table_1' => 'none', 'type_table_2' => '')),
		), TRUE),$Item['type'] ? $Item['type'] : 1, 'mradio');
		
		$TypeTable1 = $Item['type'] == 1 || !$NewItem? true : false;

		showtagheader('div', 'type_table_1', $TypeTable1, 'sub');

			showsetting($Fn_Job->Config['LangVar']['OnlineApplication'],array('sign_up', array(
				array('1','&#26159;', array('OnlineApplication_1' => '','OnlineApplication_0' => 'none')),
				array('0','&#21542;', array('OnlineApplication_1' => 'none','OnlineApplication_0' => '')),
			), TRUE),$Item['param']['sign_up'], 'mradio');

			showtagheader('div', 'OnlineApplication_1', $Item['param']['sign_up'] == 1 ? true : '','ssub');
				showsetting($Fn_Job->Config['LangVar']['FairExamine'], 'sign_up_examine', $Item['param']['sign_up_examine'], 'radio','','',$Fn_Job->Config['LangVar']['FairExamineTips']);
				showsetting($Fn_Job->Config['LangVar']['FairInfo'], 'sign_up_info', $Item['param']['sign_up_info'], 'radio');
				showsetting($Fn_Job->Config['LangVar']['MoneyTitle'], 'money', $Item['money'], 'text','','',$Fn_Job->Config['LangVar']['FairMoneyTips']);
				$GroupList = array();
				foreach($Fn_Job->GetCompanyGroupList() as $Val) {
					$GroupList[] = array($Val['id'], $Val['title']);
				}
				showsetting($Fn_Job->Config['LangVar']['FairGroups'], array('groups[]',$GroupList),$Item['groups'] ? explode(',',$Item['groups']) : '','mselect','','',$Fn_Job->Config['LangVar']['FairGroupsTips']);
			showtagfooter('div');

			showtagheader('div', 'OnlineApplication_0', !$Item['param']['sign_up'] ? true : '','ssub');
				showsetting($Fn_Job->Config['LangVar']['ContactNumber'], 'tel', $Item['tel'], 'text');
				$contact_qr_code_html =  $Item['param']['contact_qr_code'] ? '<a href="'.$Item['param']['contact_qr_code'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$Item['param']['contact_qr_code'].'" height="55"/></a>' : '';
				showsetting($Fn_Job->Config['LangVar']['ContactQrCode'], 'new_contact_qr_code',$Item['param']['contact_qr_code'], 'filetext', '', 0, $contact_qr_code_html);
			showtagfooter('div');
			
			showsetting($Fn_Job->Config['LangVar']['RefreshAmount'], 'refresh_money', $Item['param']['refresh_money'], 'text','','',$Fn_Job->Config['LangVar']['FairRefreshAmountTips']);
			
			$Item['param']['refresh_money_btn_path'] = $Item['param']['refresh_money_btn_path'] ? $Item['param']['refresh_money_btn_path'] : $Fn_Job->Config['StaticPath'].'/images/refresh.png';
			$refresh_money_btn_path_html = '<a href="'.$Item['param']['refresh_money_btn_path'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$Item['param']['refresh_money_btn_path'].'" height="55"/></a>';
			showsetting($Fn_Job->Config['LangVar']['RefreshAmountPath'], 'new_refresh_money_btn_path',$Item['param']['refresh_money_btn_path'], 'filetext', '', 0, $refresh_money_btn_path_html);

			showsetting($Fn_Job->Config['LangVar']['TopAmount'], 'top_money', $Item['param']['top_money'], 'textarea','','',$Fn_Job->Config['LangVar']['FairTopAmountTips']);
			
			$Item['param']['top_money_btn_path'] = $Item['param']['top_money_btn_path'] ? $Item['param']['top_money_btn_path'] :$Fn_Job->Config['StaticPath'].'/images/top.png';
			$top_money_btn_path_html = '<a href="'.$Item['param']['top_money_btn_path'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$Item['param']['top_money_btn_path'].'" height="55"/></a>';
			showsetting($Fn_Job->Config['LangVar']['TopAmountPath'], 'new_top_money_btn_path',$Item['param']['top_money_btn_path'], 'filetext', '', 0, $top_money_btn_path_html);
			

			showsetting('&#26159;&#21542;&#26174;&#31034;&#25237;&#36882;&#20154;&#25968;',array('apply_count', array(
				array('1','&#26159;', array('apply_count_1' => '')),
				array('0','&#21542;', array('apply_count_1' => 'none')),
			), TRUE),$Item['param']['apply_count'], 'mradio');
			
			showtagheader('div', 'apply_count_1', $Item['param']['apply_count'] == 1 ? true : '','ssub');
				showsetting($Fn_Job->Config['LangVar']['FairApplyCountText'], 'apply_count_text', $Item['param']['apply_count_text'] ? $Item['param']['apply_count_text'] : $Fn_Job->Config['LangVar']['ZPRS'], 'text');
				showsetting($Fn_Job->Config['LangVar']['FairFictitious'], 'fictitious', $Item['param']['fictitious'], 'text','','',$Fn_Job->Config['LangVar']['FairFictitiousTips']);
			showtagfooter('div');

			showsetting($Fn_Job->Config['LangVar']['FairProhibitJump'],array('prohibit_jump', array(
				array('1','&#26159;', array('prohibit_jump_1' => '')),
				array('0','&#21542;', array('prohibit_jump_1' => 'none')),
			), TRUE),$Item['param']['prohibit_jump'], 'mradio');
			
			showtagheader('div', 'prohibit_jump_1', $Item['param']['prohibit_jump'] == 1 ? true : '','ssub');
				showsetting($Fn_Job->Config['LangVar']['FairProhibitJumpTips'], 'prohibit_jump_tips', $Item['param']['prohibit_jump_tips'] ? $Item['param']['prohibit_jump_tips'] : $Fn_Job->Config['LangVar']['FairProhibitJumpTipsDefault'], 'text');
			showtagfooter('div');

			showsetting($Fn_Job->Config['LangVar']['HeadNav'],array('head_nav', array(
				array('1','&#26159;', array('head_nav_1' => '')),
				array('0','&#21542;', array('head_nav_1' => 'none')),
			), TRUE),$Item['param']['head_nav'], 'mradio');
			
			showtagheader('div', 'head_nav_1', $Item['param']['head_nav'] == 1 ? true : '','ssub');
				showsetting($Fn_Job->Config['LangVar']['HeadNavBgColor'], 'head_nav_bg_color', $Item['param']['head_nav_bg_color'] ? $Item['param']['head_nav_bg_color'] : $Fn_Job->Config['PluginVar']['Color'], 'color');
				showsetting($Fn_Job->Config['LangVar']['HeadNavColor'], 'head_nav_color', $Item['param']['head_nav_color'] ? $Item['param']['head_nav_color'] : '#ffffff', 'color');
			showtagfooter('div');

			showsetting($Fn_Job->Config['LangVar']['BgColor'], 'bg_color', $Item['param']['bg_color'] ? $Item['param']['bg_color'] : '#E31B04', 'color');

			showsetting($Fn_Job->Config['LangVar']['ThemeColor'], 'theme_color', $Item['param']['theme_color'] ? $Item['param']['theme_color'] : '#E31B04', 'color');

			showsetting($Fn_Job->Config['LangVar']['ThemeColor2'], 'theme_color_2', $Item['param']['theme_color_2'] ? $Item['param']['theme_color_2'] : '#fe8c35', 'color');

			showsetting($Fn_Job->Config['LangVar']['ThemeColor3'], 'theme_color_3', $Item['param']['theme_color_3'] ? $Item['param']['theme_color_3'] : '#ff5159', 'color');
			
			showsetting($Fn_Job->Config['LangVar']['FairCompanyClass'], array('company_class[]',DyadicArray($Fn_Job->Config['LangVar']['CompanyClassArray'])),$Item['param']['company_class'],'mselect','','',$Fn_Job->Config['LangVar']['FairCompanyClassTips']);

			showsetting($Fn_Job->Config['LangVar']['FairCompanyClassHot'], 'company_class_hot', $Item['param']['company_class_hot'], 'radio','','',$Fn_Job->Config['LangVar']['FairCompanyClassHotTips']);
			
			showsetting($Fn_Job->Config['LangVar']['FairCompanyClassBgColor'], 'company_class_bg_color', $Item['param']['company_class_bg_color'] ? $Item['param']['company_class_bg_color'] : '#960804', 'color');

			showsetting($Fn_Job->Config['LangVar']['FairCompanyClassHoverColor'], 'company_class_hover_color', $Item['param']['company_class_hover_color'] ? $Item['param']['company_class_hover_color'] : '#910a04', 'color');

			showsetting($Fn_Job->Config['LangVar']['FairFixedBottomNav'],array('fixed_bottom_nav', array(
				array('1','&#26159;', array('fixed_bottom_nav_1' => '')),
				array('0','&#21542;', array('fixed_bottom_nav_1' => 'none')),
			), TRUE),$NewItem ? $Item['param']['fixed_bottom_nav'] : 1, 'mradio');

			showtagheader('div', 'fixed_bottom_nav_1', $Item['param']['fixed_bottom_nav'] == 1 || !$NewItem ? true : '','ssub');
				showsetting($Fn_Job->Config['LangVar']['FairFixedBottomNavLeftBgColor'], 'fixed_bottom_nav_left_color', $Item['param']['fixed_bottom_nav_left_color'] ? $Item['param']['fixed_bottom_nav_left_color'] : '#ff8a00', 'color');
				showsetting($Fn_Job->Config['LangVar']['FairFixedBottomNavRightBgColor'], 'fixed_bottom_nav_right_color', $Item['param']['fixed_bottom_nav_right_color'] ? $Item['param']['fixed_bottom_nav_right_color'] : '#f56022', 'color');
			showtagfooter('div');

			showsetting($Fn_Job->Config['LangVar']['FairFixedRightIco'],array('fixed_right_ico', array(
				array('1','&#26159;', array('fixed_right_ico_1' => '')),
				array('0','&#21542;', array('fixed_right_ico_1' => 'none')),
			), TRUE),$Item['param']['fixed_right_ico'], 'mradio');
			showtagheader('div', 'fixed_right_ico_1', $Item['param']['fixed_right_ico'] == 1 ? true : '','ssub');
				$Item['param']['fixed_right_ico_path'] = $Item['param']['fixed_right_ico_path'] ? $Item['param']['fixed_right_ico_path'] : $Fn_Job->Config['StaticPath'].'/images/fair_right_ico.png';
				$fixed_right_ico_path_html = '<a href="'.$Item['param']['fixed_right_ico_path'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$Item['param']['fixed_right_ico_path'].'" height="55"/></a>';
				showsetting($Fn_Job->Config['LangVar']['FairFixedRightIcoPath'], 'new_fixed_right_ico_path',$Item['param']['fixed_right_ico_path'], 'filetext', '', 0, $fixed_right_ico_path_html);
			showtagfooter('div');

			showsetting($Fn_Job->Config['LangVar']['FairNav'], 'navs', $Item['param']['navs'], 'textarea','','',$Fn_Job->Config['LangVar']['FairPopNavTips']);

			showsetting($Fn_Job->Config['LangVar']['FairPopNav'], 'pop_nav', $Item['param']['pop_nav'] ? $Item['param']['pop_nav'] : str_replace("<br>","\r\n",$Fn_Job->Config['LangVar']['FairPopNavDefault']), 'textarea','','',$Fn_Job->Config['LangVar']['FairPopNavTips']);
			
			$Item['param']['poster_bg_path'] = $Item['param']['poster_bg_path'] ? $Item['param']['poster_bg_path'] : $Fn_Job->Config['PluginVar']['FairCardPath'];
			$poster_bg_path_html = '<a href="'.$Item['param']['poster_bg_path'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$Item['param']['poster_bg_path'].'" height="55"/></a>';
			showsetting($Fn_Job->Config['LangVar']['FairPosterBgPath'], 'new_poster_bg_path',$Item['param']['poster_bg_path'], 'filetext', '', 0, $poster_bg_path_html);

		showtagfooter('div');

		showsetting($Fn_Job->Config['LangVar']['ShareTitle'], 'share_title', $Item['param']['share_title'], 'text');
		showsetting($Fn_Job->Config['LangVar']['ShareDesc'], 'share_desc', $Item['param']['share_desc'], 'text');

		$share_img_html = ($Item['param']['share_img'] ? '<a href="'.$Item['param']['share_img'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$Item['param']['share_img'].'" height="55"/></a>' : '').$Fn_Job->Config['LangVar']['ShareImgTips'];
		showsetting($Fn_Job->Config['LangVar']['ShareImg'], 'new_share_img',$Item['param']['share_img'], 'filetext', '', 0, $share_img_html);

		showsetting($Fn_Job->Config['LangVar']['Click'], 'click', $Item['click'], 'text');

		showsetting($Fn_Job->Config['LangVar']['ClickRand'], 'click_rand', $Item['param']['click_rand'] ? $Item['param']['click_rand'] : '1-1', 'text','','',$Fn_Job->Config['LangVar']['ClickRandTips']);

		showsetting($Fn_Job->Config['LangVar']['DisplayTitle'], 'display', $Item ? $Item['display'] : 1, 'radio');

		if($Item['dateline']){
			showsetting($Fn_Job->Config['LangVar']['TimeTitle'], 'dateline',date('Y-m-d H:i',$Item['dateline']), 'calendar','','','',1);
		}

		showsubmit('DetailSubmit','&#20445;&#23384;&#37197;&#32622;');
		showtagfooter('div');
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');

		$UpLoadHtml  = '';
		if($Item['banner']){
			$BannerJsArray[] = '"'.$Item['banner'].'"';;
			$UpLoadHtml .= '
			var InputArray = new Array('.implode(',',$BannerJsArray).');
			jQuery("#Banner").AppUpload({InputName:"new_banner",Multiple:true,InputExist:true,InputArray:InputArray});';

		}else{
			$UpLoadHtml .= 'jQuery("#Banner").AppUpload({InputName:"new_banner",Multiple:true});';
		}

		echo $UploadConfig['CssJsHtml'].'<script>'.$UpLoadHtml.'</script> ';

	}else{
		foreach($_GET['new_banner'] as $Key => $Val) {
			$_GET['new_banner'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}

		foreach($_GET['new_share_img'] as $Key => $Val) {
			$_GET['new_share_img'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}
		
		$Data['type'] = intval($_GET['type']);
		$Data['banner_link'] = addslashes(strip_tags($_GET['banner_link']));
		$Data['title'] = addslashes(strip_tags($_GET['title']));
		$Data['banner'] = addslashes(strip_tags($_GET['new_banner'][0]));
		$Data['start_time'] = $_GET['start_time'] ? strtotime($_GET['start_time']) : '';
		$Data['end_time'] = $_GET['end_time'] ? strtotime($_GET['end_time']) : '';
		$Data['content'] = addslashes($_GET['content']);//�豣��Html
		$Data['money'] = addslashes(strip_tags($_GET['money']));
		$Data['groups'] =  is_array($_GET['groups']) && isset($_GET['groups'])  ? implode(',',$_GET['groups']) : '';
		$Data['tel'] = addslashes(strip_tags($_GET['tel']));
		$Data['click'] = intval($_GET['click']);
		$Data['display'] = intval($_GET['display']);
		
		$Param['refresh_money'] = addslashes(strip_tags($_GET['refresh_money']));
		$Param['top_money'] = addslashes(strip_tags($_GET['top_money']));
					
		$Param['apply_count'] = intval($_GET['apply_count']);
		$Param['apply_count_text'] = addslashes(strip_tags($_GET['apply_count_text']));
		$Param['fictitious'] = addslashes(strip_tags($_GET['fictitious']));
		
		$Param['sign_up'] = intval($_GET['sign_up']);
		$Param['sign_up_examine'] = intval($_GET['sign_up_examine']);
		$Param['sign_up_info'] = intval($_GET['sign_up_info']);
		$Param['contact_qr_code'] = addslashes(strip_tags($_GET['contact_qr_code']));
		$Param['head_nav'] = addslashes(strip_tags($_GET['head_nav']));
		$Param['head_nav_bg_color'] = addslashes(strip_tags($_GET['head_nav_bg_color']));
		$Param['head_nav_color'] = addslashes(strip_tags($_GET['head_nav_color']));
		$Param['bg_color'] = addslashes(strip_tags($_GET['bg_color']));
		$Param['theme_color'] = addslashes(strip_tags($_GET['theme_color']));
		$Param['theme_color_2'] = addslashes(strip_tags($_GET['theme_color_2']));
		$Param['theme_color_3'] = addslashes(strip_tags($_GET['theme_color_3']));
		
		$Param['company_class'] =  is_array($_GET['company_class']) && isset($_GET['company_class'])  ? $_GET['company_class'] : '';
		$Param['company_class_hot'] = intval($_GET['company_class_hot']);
		$Param['company_class_bg_color'] = addslashes(strip_tags($_GET['company_class_bg_color']));
		$Param['company_class_hover_color'] = addslashes(strip_tags($_GET['company_class_hover_color']));

		$Param['fixed_bottom_nav'] = intval($_GET['fixed_bottom_nav']);
		$Param['fixed_bottom_nav_left_color'] = addslashes(strip_tags($_GET['fixed_bottom_nav_left_color']));
		$Param['fixed_bottom_nav_right_color'] = addslashes(strip_tags($_GET['fixed_bottom_nav_right_color']));
		$Param['fixed_right_ico'] = intval($_GET['fixed_right_ico']);
		$Param['navs'] = addslashes(strip_tags($_GET['navs']));
		$Param['pop_nav'] = addslashes(strip_tags($_GET['pop_nav']));
		$Param['prohibit_jump'] = addslashes(strip_tags($_GET['prohibit_jump']));
		$Param['prohibit_jump_tips'] = addslashes(strip_tags($_GET['prohibit_jump_tips']));

		$Param['share_title'] = addslashes(strip_tags($_GET['share_title']));
		$Param['share_desc'] = addslashes(strip_tags($_GET['share_desc']));

		$Param['click_rand'] = addslashes(strip_tags($_GET['click_rand']));

		foreach($_FILES as $file_key => $file_value){
			if(strpos($file_key,'new_') !== false){
				$key = str_replace(array('TMPnew_','new_'),'',$file_key);
				if($_FILES[$file_key]['size']){
					$FileCode = Fn_Upload($_FILES[$file_key]);
					if($FileCode['Errorcode']){
						cpmsg($Fn_Admin->Config['LangVar']['ImgErr'],'','error');
						exit();
					}else{
						$Param[$key] = $FileCode['Path'];
					}
				}else{
					$file_key = str_replace(array('TMPnew_'),array('new_'),$file_key);
					if(!preg_match('/.*(\.png|\.jpg|\.jpeg|\.gif)$/',$_GET[$file_key]) && $_GET[$file_key]){
						cpmsg($Fn_Admin->Config['LangVar']['ImgErr'],'','error');
						exit();
					}else{
						$Param[$key] = addslashes(strip_tags($_GET[$file_key]));
					}
				}
			}
		}

		$Data['param'] = serialize($Param);

		if($Item){

			$Data['dateline'] = strtotime($_GET['dateline']);

			GetInsertDoLog('edit_fair_job','fn_'.$_GET['mod'],array('id'=>$id));//������¼
			DB::update($Fn_Job->TableFair,$Data,'id = '.$id);
		}else{
			$Data['dateline'] =  time();
			$Id = DB::insert($Fn_Job->TableFair,$Data,true);
			GetInsertDoLog('add_fair_job','fn_'.$_GET['mod'],array('id'=>$Id));//������¼
		}
		fn_cpmsg($Fn_Job->Config['LangVar']['UpdateOk'],$Fn_Admin->Config['IframeItemUrl'].'&submodel=list','succeed');
	
	}
}


/* �б� */
function GetModulesList($Page,$Limit,$Where=null,$Order){
	global $Fn_Job;
	$FetchSql = 'SELECT F.* FROM '.DB::table($Fn_Job->TableFair).' F '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}

/* ���� */
function GetModulesCount($Where=null){
	global $Fn_Job;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_Job->TableFair).' F '.$Where;
	return DB::result_first($FetchSql);//��������
}

/* �б� */
function GetCompanyModulesList($Page,$Limit,$Where=null,$Order){
	global $Fn_Job;
	$FetchSql = 'SELECT C.*,CC.name,F.title FROM '.DB::table($Fn_Job->TableFairCompany).' C LEFT JOIN `'.DB::table($Fn_Job->TableCompany).'` CC on CC.id = C.company_id LEFT JOIN `'.DB::table($Fn_Job->TableFair).'` F on F.id = C.fid '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}

/* ���� */
function GetCompanyModulesCount($Where=null){
	global $Fn_Job;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_Job->TableFairCompany).' C '.$Where;
	return DB::result_first($FetchSql);//��������
}
//From: Dism_taobao_com
?>