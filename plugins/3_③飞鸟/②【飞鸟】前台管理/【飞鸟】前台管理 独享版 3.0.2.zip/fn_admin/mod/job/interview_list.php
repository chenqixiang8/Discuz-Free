<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('job_all') && !$Fn_Admin->CheckUserGroup('job_interview_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$SubModel = in_array($_GET['submodel'], array('list','add')) ? $_GET['submodel'] : 'list';
$Fn_Admin->Config['IframeSubModelUrl'] = $Fn_Admin->Config['IframeItemUrl'].'&submodel='.$SubModel;
$NavClass = array($SubModel=>'btn-info Hover');

//����
echo <<<Nav
<div class="SubModelNav">
  <ul>
	<li class="{$NavClass['list']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=list" target="_self">{$Fn_Admin->Config['LangVar']['JobLeftNavArray']['interview_list']}</a></li>
    <li class="{$NavClass['add']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=add" target="_self">{$Fn_Admin->Config['LangVar']['AddEditTitle']}</a></li>
  </ul>
  <div class="both"></div>
</div>
Nav;

if($SubModel == 'list'){//�б�
	$Do = in_array($_GET['do'], array('Refresh','Del')) ? $_GET['do'] : 'submodel_list';
	//�����ֶ�
	$SearField =array('page','keyword');
	foreach($SearField as $Val) {
		$SearArray[$Val] = $_GET[$Val] || in_array($_GET[$Val],array('0')) ? $_GET[$Val] : '';
	}
	//�����ֶ� End
	$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeSubModelUrl'].'&'.http_build_query($SearArray);


	if($Do == 'submodel_list'){
		if(!submitcheck('Submit')) {
			$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
			$Where = '';
			$Order = in_array($_GET['order'], array('id')) ? 'I.'.addslashes(dhtmlspecialchars($_GET['order'])) : 'I.id';
			
			if($_GET['keyword']){
				$_GET['keyword'] = str_replace(array('%','_'),array('',''),$_GET['keyword']);
				$Where .= ' and (I.username like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or I.company_id = '.intval($_GET['keyword']).' or I.id = '.intval($_GET['keyword']).' or I.rid = '.intval($_GET['keyword']).' )';
			}

			$Where = preg_replace('/and/','where',$Where,1);
			$Limit = 20;
			$Page = $_GET['page']?intval($_GET['page']):1;
			/* ��ѯ���� End */

			/* ģ����� */	
			showtagheader('div', 'row', true,'row');
			showtagheader('div', 'col-12', true,'col-12');
			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-body', true,'box-body');
			/* ���� */
	
			echo <<<SEARCH
			<form method="post" autocomplete="off" action="$SearUrl">
				<div class="FormSearchTo" style="margin-bottom:0;">
					<table cellspacing="4" cellpadding="4">
						<tr>
							<th>{$Fn_Job->Config['LangVar']['KeywordTitle']}</th><td><input type="text" class="input form-control w200" name="keyword" value="{$_GET['keyword']}">
							&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Admin->Config['LangVar']['SearchSubmit']}" class="btn btn-info" type="submit">
							</td>
						</tr>
					</table>
				</div>
			</form>
SEARCH;
			/* ���� End */
			showtagheader('div', 'table-responsive', true,'table-responsive');
			showformheader($FormUrl,'enctype="multipart/form-data"');
			showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
			showsubtitle(array(
				'ID',
				$Fn_Job->Config['LangVar']['SeeLogCompanyUser'],
				$Fn_Job->Config['LangVar']['TaJianLi'],
				$Fn_Job->Config['LangVar']['IntervieJob'],
				$Fn_Job->Config['LangVar']['InterviewDateline'],
				$Fn_Job->Config['LangVar']['ContactRen'],
				$Fn_Job->Config['LangVar']['ResumeMobile'],
				$Fn_Job->Config['LangVar']['InterviewAddress'],
				$Fn_Job->Config['LangVar']['InterviewContent'],
				$Fn_Job->Config['LangVar']['TimeTitle'],
				$Fn_Job->Config['LangVar']['RefreshTime'],
				$Fn_Job->Config['LangVar']['OperationTitle']
			),'header tbm tc');

			$ModulesList = GetModulesList($Page,$Limit,$Where,$Order);
			foreach ($ModulesList as $Module) {
				$CompanyItem = $Fn_Job->GetViewCompanythread($Module['company_id'],'id');
				$ResumeItem = $Fn_Job->GetViewResumethread($Module['rid']);
				showtablerow('', array('class="tc w80"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
					'<input type="checkbox" class="filled-in" id="checkbox_'.$Module['id'].'" name="delete[]" value="'.$Module['id'].'"><label for="checkbox_'.$Module['id'].'">'.$Module['id'].'</label>',
					'UID:'.$CompanyItem['uid'].'<br>'.$Fn_Job->Config['LangVar']['CompanyName'].':'.$CompanyItem['name'].'&nbsp;&nbsp;<a href="'.$Fn_Job->Config['ViewCompanyUrl'].$CompanyItem['id'].'" target="_blank">['.cplang('view').']</a><br>'.$Fn_Job->Config['LangVar']['ResumeMobile'].':'.$CompanyItem['mobile'],
					'UID:'.$ResumeItem['uid'].'<br>'.$Fn_Job->Config['LangVar']['ResumeFullName'].':'.$ResumeItem['full_name'].'&nbsp;&nbsp;<a href="'.$Fn_Job->Config['ViewResumeUrl'].$Module['rid'].'" target="_blank">['.cplang('view').']</a><br>'.$Fn_Job->Config['LangVar']['ResumeMobile'].':'.$ResumeItem['mobile'],
					$Module['title'],
					$Module['interview_dateline'] ? date('Y-m-d H:i',$Module['interview_dateline']) : '',
					$Module['contacts'],
					$Module['mobile'],
					$Module['address'],
					$Module['content'],
					$Module['dateline'] ? date('Y-m-d H:i',$Module['dateline']) : '',
					$Module['updateline'] ? date('Y-m-d H:i',$Module['updateline']) : '',
					'<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&iid='.$Module['id'].'" class="btn btn-sm btn-info-outline">'.$Fn_Job->Config['LangVar']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Refresh&iid='.$Module['id'].'&formhash='.FORMHASH.'" class="btn btn-sm btn-primary-outline">'.$Fn_Job->Config['LangVar']['Refresh'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Del&iid='.$Module['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$Fn_Job->Config['LangVar']['DelTitle'].'</a>',
				));
			}
			showsubmit('Submit','&#31435;&#21363;&#25552;&#20132;','del','','',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));
			showtablefooter(); /*dism��taobao��com*/
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			/* ģ�����End */	
		}else{
			if(!$Fn_Admin->CheckUserGroup('job_all') && !$Fn_Admin->CheckUserGroup('job_del_interview_list')){//Ȩ���ж�
				fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
				exit();
			}

			if(isset($_GET['delete']) && is_array($_GET['delete'])){
				foreach($_GET['delete'] as $Key => $Val) {
					$Val = intval($Val);
					DB::delete($Fn_Job->TableInterview,'id ='.$Val);
				}

				GetInsertDoLog('del_interview_list_job','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete'])));//������¼

				fn_cpmsg($Fn_Job->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
			}else{
				fn_cpmsg($Fn_Job->Config['LangVar']['DelErr'],'','error');
			}
				
		}
	}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['iid']){
		if(!$Fn_Admin->CheckUserGroup('job_all') && !$Fn_Admin->CheckUserGroup('job_del_interview_list')){//Ȩ���ж�
			fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
			exit();
		}
		$iid = intval($_GET['iid']);
		DB::delete($Fn_Job->TableInterview,'id ='.$iid);
		GetInsertDoLog('del_interview_list_job','fn_'.$_GET['mod'],array('id'=>$AUid));//������¼
		fn_cpmsg($Fn_Admin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
	}else if($Do == 'Refresh' && $_GET['formhash'] == formhash() && $_GET['iid']){
		$iid = intval($_GET['iid']);
		$UpData['updateline'] = time();
		DB::update($Fn_Job->TableInterview,$UpData,'id = '.$iid);
		GetInsertDoLog('refresh_interview_list_job','fn_'.$_GET['mod'],array('id'=>$_GET['iid']));//������¼
		fn_cpmsg($Fn_Job->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

	}
}else if($SubModel == 'add'){//���ӻ�༭
	if(!$Fn_Admin->CheckUserGroup('job_all') && !$Fn_Admin->CheckUserGroup('job_add_interview_list')){//Ȩ���ж�
		fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
		exit();
	}
	$iid = intval($_GET['iid']);

	$Item = DB::fetch_first('SELECT * FROM '.DB::table($Fn_Job->TableInterview).' where id = '.$iid);
	if($Item){
		$Item['param'] = unserialize($Item['param']);
	};
	if(!submitcheck('DetailSubmit')) {
		$OpTitle = $Fn_Job->Config['LangVar']['AddTitle'];
		if($Item){
			$OpTitle = $Fn_Job->Config['LangVar']['EditTitle'];
		}

		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-header', true,'with-border box-header');
		showtitle($OpTitle,'class="box-title"');
		showtagfooter('div');
		showformheader($Fn_Admin->Config['IframeSubModelUrl'].'&iid='.$iid,'enctype');
		showtagheader('div', 'box-body', true,'box-body');

		showsetting($Fn_Job->Config['LangVar']['SeeLogCompanyUser'].'UID', 'company_id', $Item['company_id'], 'text');

		showsetting($Fn_Job->Config['LangVar']['SeeLogResumeUser'].'UID', 'rid', $Item['rid'], 'text');
		
		showsetting($Fn_Job->Config['LangVar']['IntervieJob'], 'title', $Item['title'], 'text');
		
		showsetting($Fn_Job->Config['LangVar']['InterviewDateline'], 'interview_dateline',$Item['interview_dateline'] ? date('Y-m-d H:i',$Item['interview_dateline']) : '', 'calendar','','','',1);
		
		showsetting($Fn_Job->Config['LangVar']['ContactRen'], 'contacts', $Item['contacts'], 'text');

		showsetting($Fn_Job->Config['LangVar']['ResumeMobile'], 'mobile', $Item['mobile'], 'text');

		showsetting($Fn_Job->Config['LangVar']['InterviewAddress'], 'address', $Item['address'], 'text');

		showsetting($Fn_Job->Config['LangVar']['InterviewContent'], 'content', $Item['content'], 'textarea');
		
		if($Item['updateline']){
			showsetting($Fn_Job->Config['LangVar']['RefreshTime'], 'updateline',$Item['updateline'] ? date('Y-m-d H:i',$Item['updateline']) : '', 'calendar','','','',1);
		}

		if($Item['dateline']){
			showsetting($Fn_Job->Config['LangVar']['TimeTitle'], 'dateline',date('Y-m-d H:i',$Item['dateline']), 'calendar','','','',1);
		}
		
		showsubmit('DetailSubmit','&#20445;&#23384;&#37197;&#32622;');
		showtagfooter('div');
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');

	}else{
	
		$Data['company_id'] = intval($_GET['company_id']);
		$Member = DB::fetch_first('SELECT username FROM '.DB::table('common_member').' where uid = '.$Data['company_id']);
		$Data['username'] = addslashes(strip_tags($Member['username']));
		$Data['rid'] = intval($_GET['rid']);
		$Data['title'] = addslashes(strip_tags($_GET['title']));
		$Data['contacts'] = addslashes(strip_tags($_GET['contacts']));
		$Data['mobile'] = addslashes(strip_tags($_GET['mobile']));
		$Data['address'] = addslashes(strip_tags($_GET['address']));
		$Data['content'] = addslashes(strip_tags($_GET['content']));
		$Data['interview_dateline'] = $_GET['interview_dateline'] ? strtotime($_GET['interview_dateline']) : '';

		$Data['param'] = serialize($Param);
		
		if($Member || $Item){

			if($Item){

				$Data['updateline'] = strtotime($_GET['updateline']);

				GetInsertDoLog('edit_interview_list_job','fn_'.$_GET['mod'],array('id'=>$iid));//������¼
				DB::update($Fn_Job->TableInterview,$Data,'id = '.$iid);
			}else{
				$Data['dateline'] = $Data['updateline'] = time();
				$Id = DB::insert($Fn_Job->TableInterview,$Data,true);
				GetInsertDoLog('add_interview_list_job','fn_'.$_GET['mod'],array('id'=>$Id));//������¼
			}
			fn_cpmsg($Fn_Job->Config['LangVar']['UpdateOk'],$Fn_Admin->Config['IframeItemUrl'].'&submodel=list','succeed');
		}else{
			fn_cpmsg($Fn_Job->Config['LangVar']['NoUserErr'],'','error');
			exit();
		}
	}
}


/* �б� */
function GetModulesList($Page,$Limit,$Where=null,$Order){
	global $Fn_Job;
	$FetchSql = 'SELECT I.* FROM '.DB::table($Fn_Job->TableInterview).' I '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}

/* ���� */
function GetModulesCount($Where=null){
	global $Fn_Job;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_Job->TableInterview).' I '.$Where;
	return DB::result_first($FetchSql);//��������
}

?>