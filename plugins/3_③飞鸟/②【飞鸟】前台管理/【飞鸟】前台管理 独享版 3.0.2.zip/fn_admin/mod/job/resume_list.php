<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('job_all') && !$Fn_Admin->CheckUserGroup('job_resume_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$SubModel = in_array($_GET['submodel'], array('list','add')) ? $_GET['submodel'] : 'list';
$Fn_Admin->Config['IframeSubModelUrl'] = $Fn_Admin->Config['IframeItemUrl'].'&submodel='.$SubModel;
$NavClass = array($SubModel=>'btn-info Hover');

//����
echo <<<Nav
<div class="SubModelNav">
  <ul>
	<li class="{$NavClass['list']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=list" target="_self">{$Fn_Admin->Config['LangVar']['JobLeftNavArray']['resume_list']}</a></li>
    <li class="{$NavClass['add']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=add" target="_self">{$Fn_Admin->Config['LangVar']['AddEditTitle']}</a></li>
  </ul>
  <div class="both"></div>
</div>
Nav;

if($SubModel == 'list'){//�б�
	$Do = in_array($_GET['do'], array('Refresh','Del','Display','Verify')) ? $_GET['do'] : 'submodel_list';
	//�����ֶ�
	$SearField =array('page','keyword','display','verify','mobile_verify','state','special','education','order');
	foreach($SearField as $Val) {
		$SearArray[$Val] = $_GET[$Val] ? $_GET[$Val] : '';
	}
	//�����ֶ� End
	$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeSubModelUrl'].'&'.http_build_query($SearArray);


	if($Do == 'submodel_list'){
		if(!submitcheck('Submit')) {
			$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
			$Where = '';
			$Order = $_GET['order'] ? 'R.'.addslashes(dhtmlspecialchars($_GET['order'])) : 'R.dateline';
			
			if($_GET['keyword']){
				$_GET['keyword'] = str_replace(array('%','_'),array('',''),$_GET['keyword']);
				$Where .= ' and (R.full_name like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or R.username like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or R.remarks like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or R.mobile like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or R.uid = '.intval($_GET['keyword']).' or R.id = '.intval($_GET['keyword']).' )';
			}
			
			if(in_array($_GET['verify'],array('0','1'))){
				$Where .= ' and R.verify = '.intval($_GET['verify']);
			}

			if($_GET['special']){
				$Where .= ' and FIND_IN_SET('.intval($_GET['special']).',R.special)';
			}

			if(in_array($_GET['mobile_verify'],array('0','1'))){
				$Where .= ' and R.mobile_verify = '.intval($_GET['mobile_verify']);
			}

			if($_GET['state']){
				$Where .= ' and R.state = '.intval($_GET['state']);
			}

			if($_GET['education']){
				$Where .= ' and R.education = '.intval($_GET['education']);
			}

			if(in_array($_GET['display'],array('0','1'))){
				$Where .= ' and R.display = '.intval($_GET['display']);
			}

			$Where = preg_replace('/and/','where',$Where,1);
			$Limit = 20;
			$Page = $_GET['page']?intval($_GET['page']):1;
			/* ��ѯ���� End */
		
			/* ģ����� */	
			showtagheader('div', 'row', true,'row');
			showtagheader('div', 'col-12', true,'col-12');
			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-body', true,'box-body');
			/* ���� */
			$StateSelected = array($_GET['state']=>' selected');
			$VerifySelected = array($_GET['verify']=>' selected');
			$MobileVerifySelected = array($_GET['mobile_verify']=>' selected');
			$DisplaySelected = array($_GET['display']=>' selected');
			$OrderSelected = array($_GET['order']=>' selected');
			
			$education_option = '<option value="">'.$Fn_Job->Config['LangVar']['SelectNull'].'</option>';
			foreach($Fn_Job->Config['LangVar']['EducationArray'] as $key => $val) {
				$education_option .= '<option value="'. $key.'" '.($_GET['education'] ==  $key ? ' selected' : '' ).'>'.$val.'</option>';
			}

			$special_option = '<option value="">'.$Fn_Job->Config['LangVar']['SelectNull'].'</option>';
			foreach($Fn_Job->Config['LangVar']['ResumeSpecialList'] as $key => $val) {
				$special_option .= '<option value="'. $key.'" '.($_GET['special'] ==  $key ? ' selected' : '' ).'>'.$val.'</option>';
			}

			echo <<<SEARCH
			<form method="post" autocomplete="off" action="$SearUrl">
				<div class="FormSearchTo" style="margin-bottom:0;">
					<table cellspacing="4" cellpadding="4">
						<tr>
							<th>{$Fn_Job->Config['LangVar']['KeywordTitle']}</th><td><input type="text" class="input form-control w200" name="keyword" value="{$_GET['keyword']}" placeholder="{$Fn_Job->Config['LangVar']['AdminResumePlaceholder']}">
							</td>
							<th>{$Fn_Job->Config['LangVar']['ResumeEducation']}</th><td>
							<select name="education" class="form-control w120">
								{$education_option}
							</select>
							</td>
							<th>{$Fn_Job->Config['LangVar']['ResumeState']}</th><td>
							<select name="state" class="form-control w120">
								<option value="">{$Fn_Job->Config['LangVar']['SelectNull']}</option>
								<option value="1"{$StateSelected['1']}>{$Fn_Job->Config['LangVar']['ResumeStateArray']['1']}</option>
								<option value="3"{$StateSelected['3']}>{$Fn_Job->Config['LangVar']['ResumeStateArray']['3']}</option>
								<option value="2"{$StateSelected['2']}>{$Fn_Job->Config['LangVar']['ResumeStateArray']['2']}</option>
							</select>
							</td>
							<th>{$Fn_Job->Config['LangVar']['IsVerify']}</th><td>
							<select name="verify" class="form-control w120">
								<option value="">{$Fn_Job->Config['LangVar']['SelectNull']}</option>
								<option value="1"{$VerifySelected['1']}>{$Fn_Job->Config['LangVar']['Yes']}</option>
								<option value="0"{$VerifySelected['0']}>{$Fn_Job->Config['LangVar']['No']}</option>
							</select>
							</td>
						</tr>
						<tr>
							<th>{$Fn_Job->Config['LangVar']['special']}</th><td>
							<select name="special" class="form-control w200">
								{$special_option}
							</select>
							</td>
							<th>{$Fn_Job->Config['LangVar']['MobileVerify']}</th><td>
							<select name="mobile_verify" class="form-control w120">
								<option value="">{$Fn_Job->Config['LangVar']['SelectNull']}</option>
								<option value="1"{$MobileVerifySelected['1']}>{$Fn_Job->Config['LangVar']['Yes']}</option>
								<option value="0"{$MobileVerifySelected['0']}>{$Fn_Job->Config['LangVar']['No']}</option>
							</select>
							</td>
							<th>{$Fn_Job->Config['LangVar']['DisplayTitle']}</th><td>
							<select name="display" class="form-control w120">
								<option value="">{$Fn_Job->Config['LangVar']['SelectNull']}</option>
								<option value="1"{$DisplaySelected['1']}>{$Fn_Job->Config['LangVar']['Yes']}</option>
								<option value="0"{$DisplaySelected['0']}>{$Fn_Job->Config['LangVar']['No']}</option>
							</select>
							</td>
							<th>{$Fn_Admin->Config['LangVar']['Order']}</th><td>
							<select name="order" class="form-control w120">
								<option value="dateline"{$OrderSelected['dateline']}>{$Fn_Admin->Config['LangVar']['OrderArray']['dateline']}</option>
								<option value="updateline"{$OrderSelected['updateline']}>{$Fn_Admin->Config['LangVar']['OrderArray']['updateline']}</option>
								<option value="click"{$OrderSelected['click']}>{$Fn_Admin->Config['LangVar']['OrderArray']['click']}</option>
								<option value="topdateline"{$OrderSelected['topdateline']}>{$Fn_Admin->Config['LangVar']['OrderArray']['topdateline']}</option>
								<option value="down_count"{$OrderSelected['down_count']}>{$Fn_Job->Config['LangVar']['DownCount']}</option>
								<option value="apply_count"{$OrderSelected['apply_count']}>&#30003;&#35831;&#25968;</option>
							</select>
							&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Admin->Config['LangVar']['SearchSubmit']}" class="btn btn-info" type="submit">
							</td>
						</tr>
					</table>
				</div>
			</form>
SEARCH;
			/* ���� End */
			showtagheader('div', 'table-responsive', true,'table-responsive');
			showformheader($FormUrl,'enctype="multipart/form-data"');
			showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
			showsubtitle(array(
				'ID',
				'UID/'.$Fn_Job->Config['LangVar']['UserNameTitle'],
				$Fn_Job->Config['LangVar']['UploadFace'],
				$Fn_Job->Config['LangVar']['ResumeFullName'],
				$Fn_Job->Config['LangVar']['ResumeMobile'],
				$Fn_Job->Config['LangVar']['WxTitle'],
				$Fn_Job->Config['LangVar']['ExpectJob'],
				$Fn_Job->Config['LangVar']['ExpectMonthWages'],
				$Fn_Job->Config['LangVar']['ExpectRegion'],
				$Fn_Job->Config['LangVar']['DownCount'],
				'&#30003;&#35831;&#25968;',
				$Fn_Job->Config['LangVar']['ResumeState'],
				$Fn_Job->Config['LangVar']['Remarks'],
				$Fn_Job->Config['LangVar']['IsVerify'],
				$Fn_Job->Config['LangVar']['MobileVerify'],
				$Fn_Job->Config['LangVar']['DisplayTitle'],
				'&#21047;&#26032;&#47;&#28155;&#21152;&#26102;&#38388;',
				$Fn_Job->Config['LangVar']['SetTopTime'],
				$Fn_Job->Config['LangVar']['OperationTitle']
			),'header tbm tc');

			$ModulesList = $Fn_Job->ResumeListFormat(GetModulesList($Page,$Limit,$Where,$Order));
			
			foreach ($ModulesList as $Module) {
				showtablerow('', array('class="tc w80"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
					'<input type="checkbox" class="filled-in" id="checkbox_'.$Module['id'].'" name="delete[]" value="'.$Module['id'].'"><label for="checkbox_'.$Module['id'].'">'.$Module['id'].'</label>',
					$Module['uid'].'/'.$Module['username'],
					$Module['face'] ? '<div class="UserLoadFace"><img src="'.$Module['face'].'" height="30"><div class="BigFace" style="background:url('.$Module['face'].') no-repeat center;background-size:cover;"></div></div>' : '',
					$Module['full_name_to'].'-'.$Module['sex_text'].'-'.$Module['age'].$Fn_Job->Config['LangVar']['Sui'],
					$Module['mobile'],
					$Module['wx'],
					'<div data-container="body" data-toggle="popover" data-trigger="hover" data-placement="top" data-content="'.$Module['expect_job'].'">'.cutstr($Module['expect_job'],15).'</div>',
					$Module['expect_month_wages_text'],
					$Module['expect_province_text'],
					$Module['down_count'],
					'<a href="'.$Fn_Admin->Config['IframeModUrl'].'&item=apply_info_list&uid='.$Module['uid'].'">'.$Module['apply_count'].'</a>',
					$Fn_Job->Config['LangVar']['ResumeStateArray'][$Module['state']],
					'<div data-container="body" data-toggle="popover" data-trigger="hover" data-placement="top" data-html="true" data-content="'.str_replace("\r\n","<br>",$Module['remarks']).'">'.cutstr($Module['remarks'],10).'</div>',
					!$Module['verify'] ? '<span class="label bg-secondary">'.$Fn_Job->Config['LangVar']['No'].'</span>' : '<span class="label bg-blue">'.$Fn_Job->Config['LangVar']['Yes'].'</span>',
					!$Module['mobile_verify'] ? '<span class="label bg-secondary">'.$Fn_Job->Config['LangVar']['No'].'</span>' : '<span class="label bg-blue">'.$Fn_Job->Config['LangVar']['Yes'].'</span>',
					!$Module['display'] ? '<span class="label bg-secondary">'.$Fn_Job->Config['LangVar']['No'].'</span>' : '<span class="label bg-blue">'.$Fn_Job->Config['LangVar']['Yes'].'</span>',
					$Module['updateline'].'<br>'.date('Y-m-d',$Module['dateline']),
					$Module['topdateline'] && $Module['topdateline'] > time() ? date('Y-m-d H:i',$Module['topdateline']) : '',
					'<a href="'.$Fn_Job->Config['ViewResumeUrl'].$Module['uid'].'" target="_blank" class="btn btn-sm btn-dark-outline">'.cplang('view').'</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&rid='.$Module['id'].'" class="btn btn-sm btn-success-outline">'.$Fn_Job->Config['LangVar']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Refresh&rid='.$Module['id'].'&formhash='.FORMHASH.'" class="btn btn-sm btn-primary-outline">'.$Fn_Job->Config['LangVar']['Refresh'].'</a>&nbsp;&nbsp;<span class="btn btn-sm btn-info-outline copy_btn" data-clipboard-content="'.str_replace(array('{name}','{mobile}','{sex}','{age}','{education}','{experience}','{expect_job}','{expect_month_wages}','{expect_address}','{tag}','{content}','{url}'),array($Module['full_name'],$Module['mobile'],$Module['sex_text'],$Module['age'],$Module['education_text'],$Module['experience_text'],$Module['expect_job'],$Module['expect_month_wages_text'],$Module['expect_province_text'],implode('|',$Module['param']['tag_list']),strip_tags($Module['content']),$Fn_Job->Rewrite('view_resume',array('rid'=>$Module['uid']))),$Fn_Job->Config['PluginVar']['ResumeCopyContent']).'">&#22797;&#21046;</span>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Display&rid='.$Module['id'].'&value='.(!empty($Module['display']) ? 0:1).'&formhash='.FORMHASH.'" class="btn btn-sm btn-warning-outline">'.(!empty($Module['display']) ? $Fn_Job->Config['LangVar']['DisplayNoTitle'] : $Fn_Job->Config['LangVar']['DisplayIsTitle']).'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Verify&rid='.$Module['id'].'&value='.(!empty($Module['verify']) ? 0:1).'&formhash='.FORMHASH.'" class="btn btn-sm btn-dark-outline">'.(!empty($Module['verify']) ? '&#21462;&#28040;&#35748;&#35777;' : '&#35748;&#35777;').'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Del&rid='.$Module['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$Fn_Job->Config['LangVar']['DelTitle'].'</a>',
				));
			}

			showsubmit('Submit','&#31435;&#21363;&#25552;&#20132;','<input name="optype" value="Del" class="with-gap" type="radio" id="v_del"><label class="custom-control-label" for="v_del" style="margin-left:-5px;">'.$Fn_Job->Config['LangVar']['DelTitle'].'</label>&nbsp;&nbsp;<input name="optype" value="Refresh" class="with-gap" type="radio" id="v_refresh"><label class="custom-control-label" for="v_refresh">'.$Fn_Job->Config['LangVar']['Refresh'].'</label>&nbsp;&nbsp;<input name="optype" value="Display" class="with-gap" type="radio" id="v_display"><label class="custom-control-label" for="v_display">'.$Fn_Job->Config['LangVar']['DisplayTitle'].'</label>&nbsp;<select name="new_display" class="form-control w100"><option value="">'.$Fn_Job->Config['LangVar']['SelectNull'].'</option><option value="1">'.$Fn_Job->Config['LangVar']['Yes'].'</option><option value="0">'.$Fn_Job->Config['LangVar']['No'].'</option></select>','','select_all',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));

			showtablefooter(); /*dism��taobao��com*/
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');

			echo '<style>.UserLoadFace{position:relative;cursor:pointer;}.UserLoadFace .BigFace{position:absolute;right:-350px;top:-250px;width:350px;height:450px;z-index:5;display:none;}</style><script src="'.$Fn_Admin->Config['StaticPath'].'/js/jquery.js"></script>
			<script>
			jQuery.noConflict();
			$(".UserLoadFace").hover(function(){
				$(this).find(".BigFace").show();
			},
			
			function(){
				$(this).find(".BigFace").hide();
			});
			
			</script>';

			echo '
			<script src="source/plugin/fn_assembly/static/js/clipboard.min.js"></script>    
			<script>
			var clipboard = new ClipboardJS(".copy_btn", {
				text: function(e) {
					return e.getAttribute("data-clipboard-content");
				}
			});
			clipboard.on("success", function(e) {
				alert("\u606d\u559c\u60a8\uff0c\u590d\u5236\u6210\u529f\uff01");
			});

			clipboard.on("error", function(e) {
				alert("\u5f88\u9057\u61be\uff0c\u590d\u5236\u5931\u8d25\uff01");
			});
			</script>';

			/* ģ�����End */	
		}else{

			if(isset($_GET['delete']) && is_array($_GET['delete'])){
				if($_GET['optype'] == 'Del'){//ȫɾ
					if(!$Fn_Admin->CheckUserGroup('job_all') && !$Fn_Admin->CheckUserGroup('job_resume_del')){//Ȩ���ж�
						fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
						exit();
					}
					foreach($_GET['delete'] as $Key => $Val) {
						$Val = intval($Val);
						$Item = DB::fetch_first('SELECT * FROM '.DB::table($Fn_Job->TableResume).' where id = '.$Val);
						DB::delete($Fn_Job->TableResume,'id ='.$Val);
						DB::delete($Fn_Job->TableResumeCollection,'rid ='.$Item['uid']);
						DB::delete($Fn_Job->TableResumeSeeLog,'rid ='.$Item['uid']);
						DB::delete($Fn_Job->TableInfoApplyLog,'uid ='.$Item['uid']);
						DB::delete($Fn_Job->TableResumeSign,'rid ='.$Item['uid']);
						DB::delete($Fn_Job->TableResumeReport,'rid ='.$Item['uid']);
						DB::delete($Fn_Job->TableCompanyFollow,'rid ='.$Item['uid']);
					}
					GetInsertDoLog('del_resume_list_job','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete'])));//������¼
					fn_cpmsg($Fn_Job->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');

				}else if($_GET['optype'] == 'Refresh'){
					foreach($_GET['delete'] as $Key => $Val) {
						$Val = intval($Val);
						$UpData['updateline'] = time();
						DB::update($Fn_Job->TableResume,$UpData,'id = '.$Val);
					}
					GetInsertDoLog('refresh_resume_list_job','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete'])));//������¼
					fn_cpmsg($Fn_Job->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

				}else if($_GET['optype'] == 'Display' && in_array($_GET['new_display'],array('0','1'))){
					foreach($_GET['delete'] as $Key => $Val) {
						$Val = intval($Val);
						$UpData['display'] = intval($_GET['new_display']);
						DB::update($Fn_Job->TableResume,$UpData,'id = '.$Val);
					}
					GetInsertDoLog('display_resume_lis_job','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete']),'display'=>$_GET['new_display']));//������¼
					fn_cpmsg($Fn_Job->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
				}else{
					fn_cpmsg($Fn_Job->Config['LangVar']['OpErr'],'','error');
				}
			}else{
				fn_cpmsg($Fn_Job->Config['LangVar']['OpErr'],'','error');
			}
		}
	}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['rid']){
		if(!$Fn_Admin->CheckUserGroup('job_all') && !$Fn_Admin->CheckUserGroup('job_resume_del')){//Ȩ���ж�
			fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
			exit();
		}
		$Rid = intval($_GET['rid']);
		$Item = DB::fetch_first('SELECT * FROM '.DB::table($Fn_Job->TableResume).' where id = '.$Rid);
		DB::delete($Fn_Job->TableResume,'id ='.$Rid);
		DB::delete($Fn_Job->TableResumeCollection,'rid ='.$Item['uid']);
		DB::delete($Fn_Job->TableResumeSeeLog,'rid ='.$Item['uid']);
		DB::delete($Fn_Job->TableInfoApplyLog,'uid ='.$Item['uid']);
		DB::delete($Fn_Job->TableResumeSign,'rid ='.$Item['uid']);
		DB::delete($Fn_Job->TableResumeReport,'rid ='.$Item['uid']);
		DB::delete($Fn_Job->TableCompanyFollow,'rid ='.$Item['uid']);
		
		GetInsertDoLog('del_resume_list_job','fn_'.$_GET['mod'],array('id'=>$Rid));//������¼
		fn_cpmsg($Fn_Admin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');

	}else if($Do == 'Refresh' && $_GET['formhash'] == formhash() && $_GET['rid']){
		$Rid = intval($_GET['rid']);
		$UpData['updateline'] = time();
		DB::update($Fn_Job->TableResume,$UpData,'id = '.$Rid);
		GetInsertDoLog('refresh_resume_list_job','fn_'.$_GET['mod'],array('id'=>$Rid));//������¼
		fn_cpmsg($Fn_Job->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

	}else if($Do == 'Display' && $_GET['formhash'] == formhash() && $_GET['rid']){
		$Rid = intval($_GET['rid']);
		$UpData['display'] = intval($_GET['value']);
		DB::update($Fn_Job->TableResume,$UpData,'id = '.$Rid);
		GetInsertDoLog('display_resume_lis_job','fn_'.$_GET['mod'],array('id'=>$Rid,'display'=>$_GET['value']));//������¼
		fn_cpmsg($Fn_Job->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

	}else if($Do == 'Verify' && $_GET['formhash'] == formhash() && $_GET['rid']){
		$Rid = intval($_GET['rid']);
		$UpData['verify'] = intval($_GET['value']);
		DB::update($Fn_Job->TableResume,$UpData,'id = '.$Rid);
		fn_cpmsg($Fn_Job->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

	}
}else if($SubModel == 'add'){//���ӻ�༭
	if(!$Fn_Admin->CheckUserGroup('job_all') && !$Fn_Admin->CheckUserGroup('job_resume_add')){//Ȩ���ж�
		fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
		exit();
	}
	$Rid = intval($_GET['rid']);
	
	$Item = DB::fetch_first('SELECT * FROM '.DB::table($Fn_Job->TableResume).' where id = '.$Rid);

	if(!submitcheck('DetailSubmit')) {
		$OpTitle = $Fn_Job->Config['LangVar']['AddTitle'];
		if($Item){
			$OpTitle = $Fn_Job->Config['LangVar']['EditTitle'];
			$Item['param'] = unserialize($Item['param']);
			$Item['province_text'] = $Fn_Job->Area[$Item['expect_province']]['content'].($Item['expect_city'] ? $Fn_Job->Area[$Item['expect_city']]['content'] : '').($Item['expect_dist'] ? $Fn_Job->Area[$Item['expect_dist']]['content'] : '');
		}

		echo '<script src="'.$Config['StaticPath'].'/ueditor/'.CHARSET.'/ueditor.config.js" type="text/javascript"></script><script src="'.$Config['StaticPath'].'/ueditor/'.CHARSET.'/ueditor.all.js" type="text/javascript"></script>';
		
		//ͼƬ�ϴ�
		if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_assembly/class/class_upload.php')){
			@require_once libfile('class/upload','plugin/fn_assembly');
			$UploadConfig = fn_upload::Config();
		}
		
		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-header', true,'with-border box-header');
		showtitle($OpTitle,'class="box-title"');
		showtagfooter('div');
		showformheader($Fn_Admin->Config['IframeSubModelUrl'].'&rid='.$Rid,'enctype');
		showtagheader('div', 'box-body', true,'box-body');
		
		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_Job->Config['LangVar']['UploadFace'].'</label><div class="col-sm-9"><div class="AdminSingleUpload"><div class="PhotoControl" id="LogoPhotoControl"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';

		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_Job->Config['LangVar']['Life'].'</label><div class="col-sm-9"><div class="AdminSingleUpload"><div class="PhotoControl" id="Life"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';

		showsetting('uid', 'new_uid', $Item['uid'], 'text');

		showsetting($Fn_Job->Config['LangVar']['ResumeFullName'], 'full_name', $Item['full_name'], 'text');

		showsetting($Fn_Job->Config['LangVar']['ResumeMobile'], 'mobile', $Item['mobile'], 'text');
		
		showsetting($Fn_Job->Config['LangVar']['MobileVerify'], 'mobile_verify', $Item['mobile_verify'], 'radio');

		showsetting($Fn_Job->Config['LangVar']['WxTitle'], 'wx', $Item['wx'], 'text');
		
		showsetting($Fn_Job->Config['LangVar']['ResumeSex'], array('sex',DyadicArray($Fn_Job->Config['LangVar']['SexArray'])),$Item['sex'], 'mradio');

		showsetting($Fn_Job->Config['LangVar']['BirthYear'], array('birth_year',DyadicArray($Fn_Job->Config['LangVar']['BirthYearArray'])),$Item['birth_year'], 'select');

		showsetting($Fn_Job->Config['LangVar']['ResumeEducation'], array('education',DyadicArray($Fn_Job->Config['LangVar']['EducationArray'],$Fn_Job->Config['LangVar']['Unlimited'])),$Item['education'], 'select');

		showsetting($Fn_Job->Config['LangVar']['ResumeExperience'], array('experience',DyadicArray($Fn_Job->Config['LangVar']['ExperienceArray'],$Fn_Job->Config['LangVar']['Unlimited'])),$Item['experience'], 'select');

		
		if(!$Fn_Job->Config['PluginVar']['ResumeExpectJob']){
			showsetting($Fn_Job->Config['LangVar']['ExpectJob'].$Fn_Job->Config['LangVar']['JobCategorySmall'], 'expect_job_classid', $Item['expect_job_classid'], 'text','','',$Fn_Job->Config['LangVar']['ExpectJobClassidTips']);
		}else{
			showsetting($Fn_Job->Config['LangVar']['ExpectJob'], 'expect_job', $Item['expect_job'], 'text');
		}
		
		showsetting($Fn_Job->Config['LangVar']['ExpectMonthWages'], array('expect_month_wages',DyadicArray($Fn_Job->Config['LangVar']['ExpectMonthWagesArray'],$Fn_Job->Config['LangVar']['Unlimited'])),$Item['expect_month_wages'], 'select');

		
		$SmallAreaPositionTreelistHtml = GetTreelistHtml($Fn_Job->Area,'SmallAreaPositionList',$Item['expect_province'],$Item['expect_city'],$Item['expect_dist']);//С��λ��

		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_Job->Config['LangVar']['ExpectRegion'].':</label><div class="col-sm-2"><div style="position:relative;height:40px"><input value="'.$Item['province_text'].'" class="input form-control TreeList" type="text" id="SmallAreaPosition">'.$SmallAreaPositionTreelistHtml.'</div></div><div class="col-sm-7 form-inline"><input type="hidden" name="province" value="'.$Item['expect_province'].'"/><input type="hidden" name="city" value="'.$Item['expect_city'].'"/><input type="hidden" name="dist" value="'.$Item['expect_dist'].'"/></div></div>';
		
		showsetting($Fn_Job->Config['LangVar']['ResumeState'], array('state',DyadicArray($Fn_Job->Config['LangVar']['ResumeStateArray'])),$Item['state'], 'mradio');

		showsetting($Fn_Job->Config['LangVar']['ResumeTag'],array('tag[]',DyadicArray($Fn_Job->Config['LangVar']['ResumeTagArray'])),explode(',',$Item['tag']),'mselect','','',$Fn_Admin->Config['LangVar']['Ctrl']);

		showsetting($Fn_Job->Config['LangVar']['special'],array('special[]',DyadicArray($Fn_Job->Config['LangVar']['ResumeSpecialList'])),explode(',',$Item['special']),'mselect','','',$Fn_Admin->Config['LangVar']['Ctrl']);
		
		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_Job->Config['LangVar']['UploadWorks'].'</label><div class="col-sm-9"><div class="AdminSingleUpload"><div class="PhotoControl" id="UploadWorks"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';

		showsetting($Fn_Job->Config['LangVar']['WorkExperience'], 'work_experience_list',implode("\r\n",$Item['param']['work_experience_list']), 'textarea','','',$Fn_Job->Config['LangVar']['WorkExperienceTpis']);

		showsetting($Fn_Job->Config['LangVar']['EducationalExperience'], 'educational_experience_list',implode("\r\n",$Item['param']['educational_experience_list']), 'textarea','','',$Fn_Job->Config['LangVar']['EducationalExperienceTpis']);

		//��������
		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_Job->Config['LangVar']['Describe'].':</label><div class="col-sm-9"><textarea id="content" name="content" style="width:80%;height:350px;">'.stripslashes($Item['content']).'</textarea></div></div>';

		showsetting($Fn_Job->Config['LangVar']['Remarks'], 'remarks', $Item['remarks'], 'textarea');

		showsetting($Fn_Job->Config['LangVar']['SetTopTime'], 'topdateline',$Item['topdateline'] ? date('Y-m-d H:i',$Item['topdateline']) : '', 'calendar','','','',1);
		
		if($Item['updateline']){
			showsetting($Fn_Job->Config['LangVar']['RefreshTime'], 'updateline',$Item['updateline'] ? date('Y-m-d H:i',$Item['updateline']) : '', 'calendar','','','',1);
		}

		if($Item['dateline']){
			showsetting($Fn_Job->Config['LangVar']['TimeTitle'], 'dateline',date('Y-m-d H:i',$Item['dateline']), 'calendar','','','',1);
		}

		showsetting($Fn_Job->Config['LangVar']['IsVerify'], 'verify', $Item['verify'], 'radio');

		showsetting($Fn_Job->Config['LangVar']['Click'], 'click', $Item['click'], 'text');

		showsetting($Fn_Job->Config['LangVar']['DisplayTitle'], 'display', $Item ? $Item['display'] : 1, 'radio');
		
		showtablefooter(); /*dism��taobao��com*/
		showsubmit('DetailSubmit');
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');

		$UpLoadHtml  = '';
		if($Item['face']){
			$LogoJsArray[] = '"'.$Item['face'].'"';;
			$UpLoadHtml .= '
			var InputArray = new Array('.implode(',',$LogoJsArray).');
			$("#LogoPhotoControl").AppUpload({InputName:"new_face",Multiple:true,InputExist:true,InputArray:InputArray});';

		}else{
			$UpLoadHtml .= '$("#LogoPhotoControl").AppUpload({InputName:"new_face",Multiple:true});';
		}

		if($Item['param']['life']){
			foreach($Item['param']['life'] as $Key => $Val) {
				$lifeJsArray[] = '"'.$Val.'"';
			}
			$UpLoadHtml .= '
			var InputArray = new Array('.implode(',',$lifeJsArray).');
			$("#Life").AppUpload({InputName:"new_life",InputExist:true,InputArray:InputArray});';

		}else{
			$UpLoadHtml .= '$("#Life").AppUpload({InputName:"new_life"});';
		}

		if($Item['param']['works']){
			foreach($Item['param']['works'] as $Key => $Val) {
				$WorksJsArray[] = '"'.$Val.'"';
			}
			$UpLoadHtml .= '
			var InputArray = new Array('.implode(',',$WorksJsArray).');
			$("#UploadWorks").AppUpload({InputName:"new_works",InputExist:true,InputArray:InputArray});';

		}else{
			$UpLoadHtml .= '$("#UploadWorks").AppUpload({InputName:"new_works"});';
		}


		echo '</script><script src="source/plugin/fn_assembly/static/js/mobiscroll.custom-2.16.1.min.js"></script><link rel="stylesheet" href="source/plugin/fn_assembly/static//css/mobiscroll.custom-2.16.1.min.css">'.$UploadConfig['CssJsHtml'];
		
		echo '
			<script>
			$(document).on("click","#SmallAreaPosition",function(){
				GetTreeList($(this),"SmallAreaPositionList","province","city","dist");
				return false;
			});
			var ue = UE.getEditor("content",{autoHeightEnabled: false,autoFloatEnabled:false,enableAutoSave: false});
			'.$UpLoadHtml.'
			</script> 	
		';

	}else{
	
		$Data['uid'] = intval($_GET['new_uid']);
		$Member = DB::fetch_first('SELECT username FROM '.DB::table('common_member').' where uid = '.$Data['uid']);
		$Data['username'] = addslashes(strip_tags($Member['username']));
		
		foreach($_GET['new_face'] as $Key => $Val) {
			$_GET['new_face'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}

		$Data['face'] = addslashes(strip_tags($_GET['new_face'][0]));
		$Data['full_name'] = addslashes(strip_tags($_GET['full_name']));
		$Data['mobile'] = addslashes(strip_tags($_GET['mobile']));
		$Data['mobile_verify'] = intval($_GET['mobile_verify']);
		$Data['wx'] = addslashes(strip_tags($_GET['wx']));
		$Data['sex'] = intval($_GET['sex']);
		$Data['birth_year'] = intval($_GET['birth_year']);
		$Data['age'] = $Data['birth_year'] ? date('Y',time()) - $Data['birth_year'] : '';
		$Data['education'] = intval($_GET['education']);
		$Data['experience'] = intval($_GET['experience']);
		if(!$Fn_Job->Config['PluginVar']['ResumeExpectJob']){
			$Data['expect_job_classid'] = addslashes(strip_tags($_GET['expect_job_classid']));
			$ExpectJobArray = array();
			foreach(array_filter(explode(',',$Data['expect_job_classid'])) as $Key => $Val) {
				$ExpectJobArray[] = $Fn_Job->ClassList[$Val]['content'];
			}
			$Data['expect_job'] = implode(',',$ExpectJobArray);
		}else{
			$Data['expect_job'] = addslashes(strip_tags($_GET['expect_job']));
		}
		$Data['expect_province'] = addslashes(strip_tags($_GET['province']));
		$Data['expect_city'] = addslashes(strip_tags($_GET['city']));
		$Data['expect_dist'] = addslashes(strip_tags($_GET['dist']));
		$Data['expect_month_wages'] = intval($_GET['expect_month_wages']);
		$Data['state'] = intval($_GET['state']);
		$Data['tag'] = is_array($_GET['tag']) && isset($_GET['tag']) ? implode(',',$_GET['tag']) : '';
		$Data['special'] = is_array($_GET['special']) && isset($_GET['special']) ? implode(',',$_GET['special']) : '';
		$Data['content'] = addslashes($_GET['content']);//�豣��Html
		$Data['remarks'] = addslashes($_GET['remarks']);//�豣��Html
		$Data['verify'] = intval($_GET['verify']);
		$Data['click'] = intval($_GET['click']);
		$Data['topdateline'] = $_GET['topdateline'] ? strtotime($_GET['topdateline']) : '';
		$Data['display'] = intval($_GET['display']);
		
		if($Data['tag']){
			foreach(array_filter(explode(",",$Data['tag'])) as $Key => $Val) {
				$Param['tag_list'][] = $Fn_Job->Config['LangVar']['ResumeTagArray'][$Val];
			}
		}

		foreach($_GET['new_life'] as $Key => $Val) {
			$_GET['new_life'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}
		$Param['life'] = is_array($_GET['new_life']) && isset($_GET['new_life'])  ? array_filter($_GET['new_life']) : '';

		foreach($_GET['new_works'] as $Key => $Val) {
			$_GET['new_works'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}
		$Param['works'] = is_array($_GET['new_works']) && isset($_GET['new_works'])  ? array_filter($_GET['new_works']) : '';

		$Param['work_experience_list'] = array_filter(explode("\r\n",$_GET['work_experience_list']));
		$Param['educational_experience_list'] = array_filter(explode("\r\n",$_GET['educational_experience_list']));
		$Data['param'] = serialize($Param);
		
		if(DB::fetch_first('SELECT * FROM '.DB::table($Fn_Job->TableResume).' where uid = '.$Data['uid']) && (!$Item || $Item['uid'] != $Data['uid'])){
			fn_cpmsg($Fn_Job->Config['LangVar']['IsCompanyErr'],'','error');
			exit();	
		}

		if($Member || $Item){

			if($Item){

				$Data['updateline'] = strtotime($_GET['updateline']);
				$Data['dateline'] = strtotime($_GET['dateline']);

				GetInsertDoLog('edit_resume_list_job','fn_'.$_GET['mod'],array('id'=>$Rid));//������¼
				DB::update($Fn_Job->TableResume,$Data,'id = '.$Rid);
			}else{
				$Data['dateline'] = $Data['updateline'] = time();
				$Id = DB::insert($Fn_Job->TableResume,$Data,true);
				GetInsertDoLog('add_resume_list_job','fn_'.$_GET['mod'],array('id'=>$Id));//������¼
			}
			fn_cpmsg($Fn_Job->Config['LangVar']['UpdateOk'],$Fn_Admin->Config['IframeItemUrl'].'&submodel=list','succeed');
		}else{
			fn_cpmsg($Fn_Job->Config['LangVar']['NoUserErr'],'','error');
			exit();
		}
	}
}


/* �б� */
function GetModulesList($Page,$Limit,$Where=null,$Order){
	global $Fn_Job;
	$FetchSql = 'SELECT R.* FROM '.DB::table($Fn_Job->TableResume).' R '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}

/* ���� */
function GetModulesCount($Where=null){
	global $Fn_Job;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_Job->TableResume).' R '.$Where;
	return DB::result_first($FetchSql);//��������
}

?>