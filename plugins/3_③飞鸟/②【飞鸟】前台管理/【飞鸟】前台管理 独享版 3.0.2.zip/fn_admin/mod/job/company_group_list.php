<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('job_all') && !$Fn_Admin->CheckUserGroup('job_company_group_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$SubModel = in_array($_GET['submodel'], array('list','add')) ? $_GET['submodel'] : 'list';
$Fn_Admin->Config['IframeSubModelUrl'] = $Fn_Admin->Config['IframeItemUrl'].'&submodel='.$SubModel;
$NavClass = array($SubModel=>'btn-info Hover');

$Fn_Job->Config['LangVar']['Currency'] = str_replace(array('{wallet_title}'),array($Fn_Job->Config['PluginVar']['CompanyWalletTitle']),$Fn_Job->Config['LangVar']['Currency']);

//����
echo <<<Nav
<div class="SubModelNav">
  <ul>
	<li class="{$NavClass['list']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=list" target="_self">{$Fn_Admin->Config['LangVar']['JobLeftNavArray']['company_group_list']}</a></li>
    <li class="{$NavClass['add']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=add" target="_self">{$Fn_Admin->Config['LangVar']['AddEditTitle']}</a></li>
  </ul>
  <div class="both"></div>
</div>
Nav;

if($SubModel == 'list'){//�б�
	$Do = in_array($_GET['do'], array('Del')) ? $_GET['do'] : 'submodel_list';
	//�����ֶ�
	$SearField =array('page','keyword');
	foreach($SearField as $Val) {
		$SearArray[$Val] = $_GET[$Val] || in_array($_GET[$Val],array('0')) ? $_GET[$Val] : '';
	}
	//�����ֶ� End
	$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeSubModelUrl'].'&'.http_build_query($SearArray);


	if($Do == 'submodel_list'){
		if(!submitcheck('Submit')) {
			$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
			$Where = '';
			$Order = in_array($_GET['order'], array('id','displayorder')) ? 'AG.'.addslashes(dhtmlspecialchars($_GET['order'])) : 'AG.displayorder';
	
			$Where = preg_replace('/and/','where',$Where,1);
			$Limit = 20;
			$Page = $_GET['page']?intval($_GET['page']):1;
			/* ��ѯ���� End */

			/* ģ����� */	
			showtagheader('div', 'row', true,'row');
			showtagheader('div', 'col-12', true,'col-12');
			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-body', true,'box-body');
			showtagheader('div', 'table-responsive', true,'table-responsive');
			showformheader($FormUrl,'enctype="multipart/form-data"');
			showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
			showsubtitle(array(
				'ID',
				$Fn_Job->Config['LangVar']['Title'],
				$Fn_Job->Config['LangVar']['IcoTitle'],
				$Fn_Job->Config['LangVar']['MoneyTitle'],
				$Fn_Job->Config['LangVar']['CompanyGroupTime'],
				$Fn_Job->Config['LangVar']['CompanyGroupInfoCount'],
				$Fn_Job->Config['LangVar']['CompanyGroupRefreshType'],
				$Fn_Job->Config['LangVar']['CompanyGroupResumeCount'],
				$Fn_Job->Config['LangVar']['CompanyGroupResumeDayCount'],
				$Fn_Job->Config['LangVar']['CompanyGroupTopDiscount'],
				$Fn_Job->Config['LangVar']['Currency'],
				$Fn_Job->Config['LangVar']['CompanyGroupHot'],
				$Fn_Job->Config['LangVar']['CompanyGroupExamine'],
				$Fn_Job->Config['LangVar']['CompanyGroupApplyInfoResume'],
				$Fn_Job->Config['LangVar']['CompanyGroupHide'],
				$Fn_Job->Config['LangVar']['DisplayOrder'],
				$Fn_Job->Config['LangVar']['DisplayTitle'],
				$Fn_Job->Config['LangVar']['OperationTitle']
			),'header tbm tc');

			$ModulesList = GetModulesList($Page,$Limit,$Where,$Order);
			foreach ($ModulesList as $Module) {
				showtablerow('', array('class="tc w50"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
					$Module['id'],
					$Module['title'],
					$Module['ico'] ? '<img src="'.$Module['ico'].'" style="height:30px;">' : '',
					$Module['money'],
					$Module['group_time'] ? $Module['group_time'].$Fn_Job->Config['LangVar']['Ge'].$Fn_Job->Config['LangVar']['Month'] : '',
					$Module['info_count'],
					$Module['refresh_type'] == 1 ? $Fn_Job->Config['LangVar']['CompanyGroupDayRefreshCount'].'-'.$Module['day_refresh_count'] : $Fn_Job->Config['LangVar']['CompanyGroupRefreshCount'].' ['.$Module['refresh_count'].']',
					$Module['resume_count'],
					$Module['resume_day_count'] ? $Module['resume_day_count'] : $Fn_Job->Config['LangVar']['NoRestriction'],
					$Module['top_discount'],
					$Module['currency'],
					$Module['hot'] ? '<span class="label bg-blue">'.$Fn_Job->Config['LangVar']['Yes'].'</span>' : '<span class="label bg-secondary">'.$Fn_Job->Config['LangVar']['No'].'</span>',
					$Module['examine'] ? '<span class="label bg-blue">'.$Fn_Job->Config['LangVar']['Yes'].'</span>' : '<span class="label bg-secondary">'.$Fn_Job->Config['LangVar']['No'].'</span>',
					$Module['apply_resume'] ? '<span class="label bg-blue">'.$Fn_Job->Config['LangVar']['Yes'].'</span>' : '<span class="label bg-secondary">'.$Fn_Job->Config['LangVar']['No'].'</span>',
					$Module['hide'] ? '<span class="label bg-blue">'.$Fn_Job->Config['LangVar']['Yes'].'</span>' : '<span class="label bg-secondary">'.$Fn_Job->Config['LangVar']['No'].'</span>',
					$Module['displayorder'],
					!$Module['display'] ? '<span class="label bg-secondary">'.$Fn_Job->Config['LangVar']['No'].'</span>' : '<span class="label bg-blue">'.$Fn_Job->Config['LangVar']['Yes'].'</span>',
					'<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&agid='.$Module['id'].'" class="btn btn-sm btn-info-outline">'.$Fn_Job->Config['LangVar']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Del&agid='.$Module['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$Fn_Job->Config['LangVar']['DelTitle'].'</a>',
				));
			}

			showtablefooter(); /*dism��taobao��com*/
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			/* ģ�����End */	
		}
	}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['agid']){
		$AGid = intval($_GET['agid']);
		DB::delete($Fn_Job->TableCompanyGroup,'id ='.$AGid);

		GetInsertDoLog('del_company_group_job','fn_'.$_GET['mod'],array('id'=>$AGid));//������¼

		fn_cpmsg($Fn_Admin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
	}
}else if($SubModel == 'add'){//���ӻ�༭

	$AGid = intval($_GET['agid']);
	$Item = DB::fetch_first('SELECT * FROM '.DB::table($Fn_Job->TableCompanyGroup).' where id = '.$AGid);
	if($Item)$Item['param'] = unserialize($Item['param']);
	if(!submitcheck('DetailSubmit')) {
		$OpTitle = $Fn_Job->Config['LangVar']['AddTitle'];
		if($Item)$OpTitle = $Fn_Job->Config['LangVar']['EditTitle'];
		
		//ͼƬ�ϴ�
		if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_assembly/class/class_upload.php')){
			@require_once libfile('class/upload','plugin/fn_assembly');
			$UploadConfig = fn_upload::Config();
		}
		
		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-header', true,'with-border box-header');
		showtitle($OpTitle,'class="box-title"');
		showtagfooter('div');
		showformheader($Fn_Admin->Config['IframeSubModelUrl'].'&agid='.$AGid,'enctype');
		showtagheader('div', 'box-body', true,'box-body');
		

		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">Logo</label><div class="col-sm-9"><div class="AdminSingleUpload"><div class="PhotoControl" id="IcoPhotoControl"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';

		showsetting($Fn_Job->Config['LangVar']['Title'], 'title', $Item['title'], 'text');
	
		showsetting($Fn_Job->Config['LangVar']['MoneyTitle'], 'money', $Item['money'], 'text','','',$Fn_Job->Config['LangVar']['CompanyGroupNumberTips']);
		showsetting($Fn_Job->Config['LangVar']['original_price'], 'original_price', $Item['original_price'], 'text');

		showsetting($Fn_Job->Config['LangVar']['CompanyGroupTime'], 'group_time', $Item['group_time'], 'text','','',$Fn_Job->Config['LangVar']['CompanyGroupTimeTips']);

		showsetting($Fn_Job->Config['LangVar']['CompanyGroupInfoCount'], 'info_count', $Item['info_count'], 'text','','',$Fn_Job->Config['LangVar']['CompanyGroupInfoCountTips']);

		showsetting($Fn_Job->Config['LangVar']['CompanyGroupRefreshType'],array('refresh_type', array(
			array('1',$Fn_Job->Config['LangVar']['CompanyGroupDayRefreshCount'], array('refresh_type_table' => '', 'refresh_type_table_no' => 'none')),
			array('2',$Fn_Job->Config['LangVar']['CompanyGroupRefreshCount'], array('refresh_type_table' => 'none', 'refresh_type_table_no' => '')),
		), TRUE),$Item['refresh_type'], 'mradio');

		$RefreshTypeTableDisplay = $Item['refresh_type'] == 1 || !$Item ? true : false;
		$RefreshTypeTableNoDisplay = $Item['refresh_type'] != 1 && $Item ? true : false;

		showtagheader('div', 'refresh_type_table', $RefreshTypeTableDisplay, 'sub');
			showsetting($Fn_Job->Config['LangVar']['CompanyGroupDayRefreshCount'], 'day_refresh_count', $Item['day_refresh_count'], 'text','','',$Fn_Job->Config['LangVar']['CompanyGroupDayRefreshCountTips']);
		showtagfooter('div');

		showtagheader('div', 'refresh_type_table_no', $RefreshTypeTableNoDisplay, 'sub');
			showsetting($Fn_Job->Config['LangVar']['CompanyGroupRefreshCount'], 'refresh_count', $Item['refresh_count'], 'text','','',$Fn_Job->Config['LangVar']['CompanyGroupRefreshCountTips']);
		showtagfooter('div');

		showsetting($Fn_Job->Config['LangVar']['CompanyGroupResumeCount'], 'resume_count', $Item['resume_count'], 'text','','',$Fn_Job->Config['LangVar']['CompanyGroupResumeCountTips']);
		showsetting($Fn_Job->Config['LangVar']['CompanyGroupResumeDayCount'], 'resume_day_count', $Item['resume_day_count'], 'text','','',$Fn_Job->Config['LangVar']['CompanyGroupResumeDayCountTips']);
		showsetting($Fn_Job->Config['LangVar']['CompanyGroupTopDiscount'], 'top_discount', $Item['top_discount'], 'text','','',$Fn_Job->Config['LangVar']['CompanyGroupTopDiscountTips']);
		
		if($Fn_Job->Config['PluginVar']['CompanyWalletSwitch']){
			showsetting($Fn_Job->Config['LangVar']['Currency'], 'currency', $Item['currency'], 'text','','',$Fn_Job->Config['LangVar']['CurrencyTips']);
		}

		showsetting($Fn_Job->Config['LangVar']['CompanyGroupHot'], 'hot', $Item ? $Item['hot'] : 0, 'radio');
		showsetting($Fn_Job->Config['LangVar']['CompanyGroupExamine'], 'examine', $Item['examine'], 'radio');
		showsetting($Fn_Job->Config['LangVar']['CompanyGroupApplyInfoResume'], 'apply_resume', $Item['apply_resume'], 'radio');
		showsetting($Fn_Job->Config['LangVar']['CompanyGroupHide'], 'hide', $Item['hide'], 'radio');
		showsetting($Fn_Job->Config['LangVar']['ServiceContent'], 'content', $Item['content'], 'textarea','','',$Fn_Job->Config['LangVar']['ServiceContentTips']);
		
		showsetting($Fn_Job->Config['LangVar']['DisplayOrder'], 'displayorder', $Item['displayorder'], 'text');
		showsetting($Fn_Job->Config['LangVar']['DisplayTitle'], 'display', $Item ? $Item['display'] : 1, 'radio');
		
		showsubmit('DetailSubmit','&#20445;&#23384;&#37197;&#32622;');
		showtagfooter('div');
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');

		$UpLoadHtml  = '';
		if($Item['ico']){
			$IcoJsArray[] = '"'.$Item['ico'].'"';;
			$UpLoadHtml .= '
			var InputArray = new Array('.implode(',',$IcoJsArray).');
			$("#IcoPhotoControl").AppUpload({InputName:"new_ico",Multiple:true,InputExist:true,InputArray:InputArray});';

		}else{
			$UpLoadHtml .= '$("#IcoPhotoControl").AppUpload({InputName:"new_ico",Multiple:true});';
		}

		echo $UploadConfig['CssJsHtml'].'<script>'.$UpLoadHtml.'</script> ';

	}else{
		foreach($_GET['new_ico'] as $Key => $Val) {
			$_GET['new_ico'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}
		$Data['ico'] = $_GET['new_ico'][0] ? addslashes(strip_tags($_GET['new_ico'][0])) : '';
		$Data['title'] = addslashes(strip_tags($_GET['title']));
		$Data['money'] = addslashes(strip_tags($_GET['money']));
		$Data['original_price'] = addslashes(strip_tags($_GET['original_price']));
		$Data['group_time'] = addslashes(strip_tags($_GET['group_time']));
		$Data['day_info_count'] = intval($_GET['day_info_count']);
		$Data['info_count'] = intval($_GET['info_count']);
		$Data['refresh_type'] = intval($_GET['refresh_type']);
		$Data['refresh_count'] = intval($_GET['refresh_count']);
		$Data['day_refresh_count'] = intval($_GET['day_refresh_count']);
		$Data['top_discount'] = addslashes(strip_tags($_GET['top_discount']));
		$Data['currency'] = intval($_GET['currency']);
		$Data['resume_count'] = intval($_GET['resume_count']);
		$Data['resume_day_count'] = intval($_GET['resume_day_count']);
		$Data['hot'] = intval($_GET['hot']);
		$Data['apply_resume'] = intval($_GET['apply_resume']);
		$Data['hide'] = intval($_GET['hide']);
		$Data['examine'] = intval($_GET['examine']);
		$Data['content'] = addslashes(strip_tags($_GET['content']));

		$Data['displayorder'] = intval($_GET['displayorder']);
		$Data['display'] = intval($_GET['display']);
	
		if($Item){
			GetInsertDoLog('edit_company_group_job','fn_'.$_GET['mod'],array('id'=>$AGid));//������¼
			DB::update($Fn_Job->TableCompanyGroup,$Data,'id = '.$AGid);
		}else{
			$Id = DB::insert($Fn_Job->TableCompanyGroup,$Data,true);
			GetInsertDoLog('add_company_group_job','fn_'.$_GET['mod'],array('id'=>$Id));//������¼
		}
		fn_cpmsg($Fn_Job->Config['LangVar']['UpdateOk'],$Fn_Admin->Config['IframeItemUrl'].'&submodel=list','succeed');
	}
}


/* �б� */
function GetModulesList($Page,$Limit,$Where=null,$Order){
	global $Fn_Job;
	$FetchSql = 'SELECT AG.* FROM '.DB::table($Fn_Job->TableCompanyGroup).' AG '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}

/* ���� */
function GetModulesCount($Where=null){
	global $Fn_Job;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_Job->TableCompanyGroup).' AG '.$Where;
	return DB::result_first($FetchSql);//��������
}

?>