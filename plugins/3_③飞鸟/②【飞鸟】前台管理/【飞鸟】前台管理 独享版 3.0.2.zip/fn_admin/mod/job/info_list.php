<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('job_all') && !$Fn_Admin->CheckUserGroup('job_info_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$SubModel = in_array($_GET['submodel'], array('list','add')) ? $_GET['submodel'] : 'list';
$Fn_Admin->Config['IframeSubModelUrl'] = $Fn_Admin->Config['IframeItemUrl'].'&submodel='.$SubModel;
$NavClass = array($SubModel=>'btn-info Hover');

//����
echo <<<Nav
<div class="SubModelNav">
  <ul>
	<li class="{$NavClass['list']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=list" target="_self">{$Fn_Admin->Config['LangVar']['JobLeftNavArray']['info_list']}</a></li>
    <li class="{$NavClass['add']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=add" target="_self">{$Fn_Admin->Config['LangVar']['AddEditTitle']}</a></li>
  </ul>
  <div class="both"></div>
</div>
Nav;

if($SubModel == 'list'){//�б�
	$Do = in_array($_GET['do'], array('Refresh','Del','Display','PaymentState','recommend_list','ManualPush')) ? $_GET['do'] : 'submodel_list';
	//�����ֶ�
	$SearField =array('page','keyword','display','payment_state','class','overdue','order','hide','company_id');
	foreach($SearField as $Val) {
		$SearArray[$Val] = $_GET[$Val] || in_array($_GET[$Val],array('0')) ? $_GET[$Val] : '';
	}
	//�����ֶ� End
	$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeSubModelUrl'].'&'.http_build_query($SearArray);


	if($Do == 'submodel_list'){
		if(!submitcheck('Submit')) {
			$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
			$Where = '';
			$Order = $_GET['order'] ? 'I.'.addslashes(dhtmlspecialchars($_GET['order'])) : 'I.id';
			
			if($_GET['keyword']){
				$_GET['keyword'] = str_replace(array('%','_'),array('',''),$_GET['keyword']);
				
				//��ѯ��˾
				$CompanyIds = array();
				foreach (DB::fetch_all('SELECT id FROM '.DB::table($Fn_Job->TableCompany).' where name like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') order by id desc') as $Key => $Val) {
					$CompanyIds[] = $Val['id'];
				}

				$Where .= ' and (I.title like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or I.username like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or I.mobile like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or I.remarks like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\')  or I.uid = '.intval($_GET['keyword']).' or I.id = '.intval($_GET['keyword']).' '.($CompanyIds ? ' or I.company_id in ('.implode(',',array_filter($CompanyIds)).')' : '' ).' )';
			}

			if($_GET['company_id']){
				$Where .= ' and I.company_id = '.intval($_GET['company_id']);
			}

			if(in_array($_GET['overdue'],array('1')) && $Fn_Job->Config['PluginVar']['ExpiryTime']){
				$Where .= ' and I.updateline < '.strtotime("-".intval($Fn_Job->Config['PluginVar']['ExpiryTime'])." day",time());
			}
	
			if(in_array($_GET['display'],array('0','1'))){
				$Where .= ' and I.display = '.intval($_GET['display']);
			}

			if(in_array($_GET['hide'],array('0','1'))){
				$Where .= ' and I.hide = '.intval($_GET['hide']);
			}

			if(in_array($_GET['payment_state'],array('0','1'))){
				$Where .= ' and I.payment_state = '.intval($_GET['payment_state']);
			}

			if(in_array($_GET['class'],array('1','2'))){
				$Where .= ' and I.class = '.intval($_GET['class']);
			}

			$Where = preg_replace('/and/','where',$Where,1);
			$Limit = 20;
			$Page = $_GET['page']?intval($_GET['page']):1;
			/* ��ѯ���� End */
	
			/* ģ����� */	
			showtagheader('div', 'row', true,'row');
			showtagheader('div', 'col-12', true,'col-12');
			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-body', true,'box-body');
			/* ���� */
			$ClassSelected = array($_GET['class']=>' selected');
			$OverdueSelected = array($_GET['overdue']=>' selected');
			$DisplaySelected = array($_GET['display']=>' selected');
			$HideSelected = array($_GET['hide']=>' selected');
			$PaymentStateSelected = array($_GET['payment_state']=>' selected');
			$OrderSelected = array($_GET['order']=>' selected');
			$OverdueHtml = $Fn_Job->Config['PluginVar']['ExpiryTime'] ? '<th>'.$Fn_Job->Config['LangVar']['IsOverdue'].'</th><td>
							<select name="overdue" class="form-control w120">
								<option value="">'.$Fn_Job->Config['LangVar']['SelectNull'].'</option>
								<option value="1"'.$OverdueSelected['1'].'>'.$Fn_Job->Config['LangVar']['Yes'].'</option>
								<option value="2"'.$OverdueSelected['2'].'>'.$Fn_Job->Config['LangVar']['No'].'</option>
							</select>
							</td>' : '';
			echo <<<SEARCH
			<form method="post" autocomplete="off" action="$SearUrl">
				<div class="FormSearchTo" style="margin-bottom:0;">
					<table cellspacing="4" cellpadding="4">
						<tr>
							<th>{$Fn_Job->Config['LangVar']['KeywordTitle']}</th><td colspan="1"><input type="text" class="input form-control w200" name="keyword" value="{$_GET['keyword']}" placeholder="{$Fn_Job->Config['LangVar']['AdminInfoPlaceholder']}">
							</td>
							<th>{$Fn_Job->Config['LangVar']['SeeLogCompanyUser']}ID</th><td colspan="10"><input type="text" class="input form-control w120" name="company_id" value="{$_GET['company_id']}" placeholder="&#35831;&#36755;&#20837;&#20844;&#21496;&#73;&#68;">
							</td>
						</tr>
						<tr>
							<th>{$Fn_Job->Config['LangVar']['Type']}</th><td>
							<select name="class" class="form-control w120">
								<option value="">{$Fn_Job->Config['LangVar']['SelectNull']}</option>
								<option value="1"{$ClassSelected['1']}>{$Fn_Job->Config['LangVar']['ClassArray']['1']}</option>
								<option value="2"{$ClassSelected['2']}>{$Fn_Job->Config['LangVar']['ClassArray']['2']}</option>
							</select>
							</td>
							{$OverdueHtml}
							<th>{$Fn_Job->Config['LangVar']['DisplayTitle']}</th><td>
							<select name="display" class="form-control w120">
								<option value="">{$Fn_Job->Config['LangVar']['SelectNull']}</option>
								<option value="1"{$DisplaySelected['1']}>{$Fn_Job->Config['LangVar']['Yes']}</option>
								<option value="0"{$DisplaySelected['0']}>{$Fn_Job->Config['LangVar']['No']}</option>
							</select>
							</td>
						</tr>
						<tr>
							<th>{$Fn_Job->Config['LangVar']['HideTitle']}</th><td>
							<select name="hide" class="form-control w120">
								<option value="">{$Fn_Job->Config['LangVar']['SelectNull']}</option>
								<option value="1"{$HideSelected['1']}>{$Fn_Job->Config['LangVar']['No']}</option>
								<option value="0"{$HideSelected['0']}>{$Fn_Job->Config['LangVar']['Yes']}</option>
							</select>
							</td>
							<th>{$Fn_Job->Config['LangVar']['PaymentState']}</th><td>
						
							<select name="payment_state" class="form-control w120">
								<option value="">{$Fn_Job->Config['LangVar']['SelectNull']}</option>
								<option value="0"{$PaymentStateSelected['0']}>{$Fn_Job->Config['LangVar']['PaymentStateArray'][0]}</option>
								<option value="1"{$PaymentStateSelected['1']}>{$Fn_Job->Config['LangVar']['PaymentStateArray'][1]}</option>
							</select>
							</td>
							<th>{$Fn_Admin->Config['LangVar']['Order']}</th><td>
							<select name="order" class="form-control w120">
								<option value="dateline"{$OrderSelected['dateline']}>{$Fn_Admin->Config['LangVar']['OrderArray']['dateline']}</option>
								<option value="updateline"{$OrderSelected['updateline']}>{$Fn_Admin->Config['LangVar']['OrderArray']['updateline']}</option>
								<option value="click"{$OrderSelected['click']}>{$Fn_Admin->Config['LangVar']['OrderArray']['click']}</option>
								<option value="topdateline"{$OrderSelected['topdateline']}>{$Fn_Admin->Config['LangVar']['OrderArray']['topdateline']}</option>
								<option value="apply_count 	"{$OrderSelected['apply_count 	']}>{$Fn_Job->Config['LangVar']['NumberApplicants']}</option>
							</select>
							&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Admin->Config['LangVar']['SearchSubmit']}" class="btn btn-info" type="submit">
							</td>
						</tr>
					</table>
				</div>
			</form>
SEARCH;
			/* ���� End */
			showtagheader('div', 'table-responsive', true,'table-responsive');
			showformheader($FormUrl,'enctype="multipart/form-data"');
			showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
			showsubtitle(array(
				'ID',
				'UID/'.$Fn_Job->Config['LangVar']['UserNameTitle'],
				$Fn_Job->Config['LangVar']['Title'],
				$Fn_Job->Config['LangVar']['Type'],
				$Fn_Job->Config['LangVar']['CompanyName'],
				$Fn_Job->Config['LangVar']['ContactNumber'],
				$Fn_Job->Config['LangVar']['NumberApplicants'],
				$Fn_Job->Config['LangVar']['RecommendResumeTitle'],
				$Fn_Job->Config['LangVar']['Remarks'],
				$Fn_Job->Config['LangVar']['DisplayTitle'],
				$Fn_Job->Config['LangVar']['HideTitle'],
				$Fn_Job->Config['LangVar']['PaymentState'],
				$Fn_Job->Config['LangVar']['RefreshTime'],
				$Fn_Job->Config['LangVar']['SetTopTime'],
				$Fn_Job->Config['LangVar']['TimeTitle'],
				$Fn_Job->Config['LangVar']['OperationTitle']
			),'header tbm tc');

			$ModulesList = $Fn_Job->InfoListFormat(GetModulesList($Page,$Limit,$Where,$Order));
			
			foreach ($ModulesList as $Module) {
				
				$RecommendCount = $Fn_Job->GetAjaxUserResumeMatchingList(array('iid'=>$Module['id']),true);

				showtablerow('', array('class="tc w100"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
					'<input type="checkbox" class="filled-in" id="checkbox_'.$Module['id'].'" name="delete[]" value="'.$Module['id'].'"><label for="checkbox_'.$Module['id'].'">'.$Module['id'].'</label>',
					$Module['uid'].'/'.$Module['username'],
					'<div data-container="body" data-toggle="popover" data-trigger="hover" data-placement="top" data-content="'.$Module['title'].'">'.cutstr($Module['title'],20).'</div>',
					$Module['class_text'],
					$Module['name'].($Module['due_time'] > time() ? '-'.$Module['group_title'] : ''),
					$Module['mobile'],
					DB::result_first('SELECT COUNT(*) FROM '.DB::table($Fn_Job->TableInfoApplyLog).' where company_id = '.intval($Module['company_id']).' and iid = '.$Module['id']).'&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['ModUrl'].'&item=apply_info_list&iframe=true&iid='.$Module['id'].'">'.cplang('view').'</a>',
					$RecommendCount ? $RecommendCount.'&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeSubModelUrl'].'&do=recommend_list&iid='.$Module['id'].'">'.$Fn_Job->Config['LangVar']['ChoiceRecommendTitle'].'</a>' : 0,
					'<div data-container="body" data-toggle="popover" data-trigger="hover" data-placement="top" data-html="true" data-content="'.str_replace("\r\n","<br>",$Module['remarks']).'">'.cutstr($Module['remarks'],10).'</div>',
					!$Module['display'] ? '<span class="label bg-secondary">'.$Fn_Job->Config['LangVar']['No'].'</span>' : '<span class="label bg-blue">'.$Fn_Job->Config['LangVar']['Yes'].'</span>',
					!$Module['hide'] ? '<span class="label bg-secondary">'.$Fn_Job->Config['LangVar']['Yes'].'</span>' : '<span class="label bg-blue">'.$Fn_Job->Config['LangVar']['No'].'</span>',
					!$Module['payment_state'] ? '<span class="label bg-secondary">'.$Fn_Job->Config['LangVar']['PaymentStateArray']['0'].'</span>' : '<span class="label bg-blue">'.$Fn_Job->Config['LangVar']['PaymentStateArray']['1'].'</span>',
					$Module['updateline'],
					$Module['topdateline'] >= time() ? date('Y-m-d',$Module['topdateline']) : ($Module['topdateline'] ? '<span class="label bg-danger">'.$Fn_Job->Config['LangVar']['Expired'].'</span>' : ''),
					$Module['dateline'],
					'<a href="'.$Fn_Job->Config['ViewJobUrl'].$Module['id'].'" target="_blank" class="btn btn-sm btn-dark-outline">'.cplang('view').'</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&iid='.$Module['id'].'" class="btn btn-sm btn-info-outline">'.$Fn_Job->Config['LangVar']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=ManualPush&iid='.$Module['id'].'&formhash='.FORMHASH.'" class="btn btn-sm btn-success-outline">&#25512;&#36865;&#31616;&#21382;</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Refresh&iid='.$Module['id'].'&formhash='.FORMHASH.'" class="btn btn-sm btn-primary-outline">'.$Fn_Job->Config['LangVar']['Refresh'].'</a>&nbsp;&nbsp;<span class="btn btn-sm btn-info-outline copy_btn" data-clipboard-content="'.str_replace(array('{id}','{title}','{class}','{company_name}','{address}','{month_wages}','{education}','{experience}','{settlement}','{cycle}','{url}','{mobile}','{content}','{contacts}','{tag}'),array($Module['id'],$Module['title'],$Module['classid_min_text'],$Module['name'],$Module['province_text'].'['.$Module['community'].']',$Module['month_wages_text'],$Module['education_text'],$Module['experience_text'],$Module['settlement_text'],$Module['cycle_text'],$Fn_Job->Rewrite('view_job',array('iid'=>$Module['id'])),$Module['mobile'],strip_tags($Module['content']),$Module['c_contacts'],implode('|',$Module['param']['tag_list'])),$Fn_Job->Config['PluginVar']['JobCopyContent']).'">&#22797;&#21046;</span>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Display&iid='.$Module['id'].'&value='.(!empty($Module['display']) ? 0:1).'&formhash='.FORMHASH.'" class="btn btn-sm btn-warning-outline">'.(!empty($Module['display']) ? $Fn_Job->Config['LangVar']['DisplayNoTitle'] : $Fn_Job->Config['LangVar']['DisplayIsTitle']).'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=PaymentState&iid='.$Module['id'].'&value='.(!empty($Module['payment_state']) ? 0:1).'&formhash='.FORMHASH.'" class="btn btn-sm btn-purple-outline">'.(!empty($Module['payment_state']) ? $Fn_Job->Config['LangVar']['PaymentStateArray'][0] : $Fn_Job->Config['LangVar']['PaymentStateArray'][1]).'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Del&iid='.$Module['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$Fn_Job->Config['LangVar']['DelTitle'].'</a>',
				));
			}

			showsubmit('Submit','&#31435;&#21363;&#25552;&#20132;','<input name="optype" value="Del" class="with-gap" type="radio" id="v_del"><label class="custom-control-label" for="v_del" style="margin-left:-5px;">'.$Fn_Job->Config['LangVar']['DelTitle'].'</label>&nbsp;&nbsp;<input name="optype" value="Refresh" class="with-gap" type="radio" id="v_refresh"><label class="custom-control-label" for="v_refresh">'.$Fn_Job->Config['LangVar']['Refresh'].'</label>&nbsp;&nbsp;<input name="optype" value="Display" class="with-gap" type="radio" id="v_display"><label class="custom-control-label" for="v_display">'.$Fn_Job->Config['LangVar']['DisplayTitle'].'</label>&nbsp;<select name="new_display" class="form-control w120"><option value="">'.$Fn_Job->Config['LangVar']['SelectNull'].'</option><option value="1">'.$Fn_Job->Config['LangVar']['Yes'].'</option><option value="0">'.$Fn_Job->Config['LangVar']['No'].'</option></select>&nbsp;&nbsp;<input name="optype" value="PaymentState" class="with-gap" type="radio" id="v_paymentstate"><label class="custom-control-label" for="v_paymentstate">'.$Fn_Job->Config['LangVar']['PaymentState'].'</label>&nbsp;<select name="new_payment_state" class="form-control w120"><option value="">'.$Fn_Job->Config['LangVar']['SelectNull'].'</option><option value="1">'.$Fn_Job->Config['LangVar']['PaymentStateArray']['1'].'</option><option value="0">'.$Fn_Job->Config['LangVar']['PaymentStateArray']['0'].'</option></select>','','select_all',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));

			showtablefooter(); /*dism��taobao��com*/
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');

			echo '
			<script src="source/plugin/fn_assembly/static/js/clipboard.min.js"></script>    
			<script>
			var clipboard = new ClipboardJS(".copy_btn", {
				text: function(e) {
					return e.getAttribute("data-clipboard-content");
				}
			});
			clipboard.on("success", function(e) {
				alert("\u606d\u559c\u60a8\uff0c\u590d\u5236\u6210\u529f\uff01");
			});

			clipboard.on("error", function(e) {
				alert("\u5f88\u9057\u61be\uff0c\u590d\u5236\u5931\u8d25\uff01");
			});
			</script>';
			/* ģ�����End */	
		}else{
			if(isset($_GET['delete']) && is_array($_GET['delete'])){
				if($_GET['optype'] == 'Del'){//ȫɾ
					if(!$Fn_Admin->CheckUserGroup('job_all') && !$Fn_Admin->CheckUserGroup('job_del_info_list')){//Ȩ���ж�
						fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
						exit();
					}
					foreach($_GET['delete'] as $Key => $Val) {
						$Val = intval($Val);
						DB::delete($Fn_Job->TableInfo,'id ='.$Val);
						DB::delete($Fn_Job->TableInfoCollection,'iid ='.$Val);
						DB::delete($Fn_Job->TableInfoReport,'iid ='.$Val);
						//DB::delete($Fn_Job->TableInfoRefreshLog,'iid ='.$Val);
						DB::delete($Fn_Job->TableInfoApplyLog,'iid ='.$Val);
					}
					GetInsertDoLog('del_info_list_job','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete'])));//������¼
					fn_cpmsg($Fn_Job->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');

				}else if($_GET['optype'] == 'Refresh'){
					foreach($_GET['delete'] as $Key => $Val) {
						$Val = intval($Val);
						$UpData['updateline'] = time();
						DB::update($Fn_Job->TableInfo,$UpData,'id = '.$Val);
					}
					GetInsertDoLog('refresh_info_list_job','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete'])));//������¼
					fn_cpmsg($Fn_Job->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

				}else if($_GET['optype'] == 'Display' && in_array($_GET['new_display'],array('0','1'))){
					foreach($_GET['delete'] as $Key => $Val) {
						$Val = intval($Val);
						$UpData['display'] = intval($_GET['new_display']);
						DB::update($Fn_Job->TableInfo,$UpData,'id = '.$Val);
					}
					GetInsertDoLog('display_info_lis_job','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete']),'display'=>$_GET['new_display']));//������¼
					fn_cpmsg($Fn_Job->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

				}else if($_GET['optype'] == 'PaymentState' && in_array($_GET['new_payment_state'],array('0','1'))){
					foreach($_GET['delete'] as $Key => $Val) {
						$Val = intval($Val);
						$UpData['payment_state'] = intval($_GET['new_payment_state']);
						DB::update($Fn_Job->TableInfo,$UpData,'id = '.$Val);
					}
					GetInsertDoLog('payment_state_info_job','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete']),'payment_state'=>$_GET['new_payment_state']));//������¼
					fn_cpmsg($Fn_Job->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
				}else{
					fn_cpmsg($Fn_Job->Config['LangVar']['OpErr'],'','error');
				}	
			}else{
				fn_cpmsg($Fn_Job->Config['LangVar']['OpErr'],'','error');
			}	
		}
	}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['iid']){
		if(!$Fn_Admin->CheckUserGroup('job_all') && !$Fn_Admin->CheckUserGroup('job_del_info_list')){//Ȩ���ж�
			fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
			exit();
		}
		$iid = intval($_GET['iid']);
		DB::delete($Fn_Job->TableInfo,'id ='.$iid);
		DB::delete($Fn_Job->TableInfoReport,'iid ='.$iid);
		DB::delete($Fn_Job->TableInfoCollection,'iid ='.$iid);
		//DB::delete($Fn_Job->TableInfoRefreshLog,'iid ='.$iid);
		DB::delete($Fn_Job->TableInfoApplyLog,'iid ='.$iid);
		
		GetInsertDoLog('del_info_list_job','fn_'.$_GET['mod'],array('id'=>$iid));//������¼
		fn_cpmsg($Fn_Admin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');

	}else if($Do == 'Refresh' && $_GET['formhash'] == formhash() && $_GET['iid']){
		$iid = intval($_GET['iid']);
		$UpData['updateline'] = time();
		DB::update($Fn_Job->TableInfo,$UpData,'id = '.$iid);
		GetInsertDoLog('refresh_info_list_job','fn_'.$_GET['mod'],array('id'=>$iid));//������¼
		fn_cpmsg($Fn_Job->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

	}else if($Do == 'Display' && $_GET['formhash'] == formhash() && $_GET['iid']){
		$iid = intval($_GET['iid']);
		$UpData['display'] = intval($_GET['value']);
		DB::update($Fn_Job->TableInfo,$UpData,'id = '.$iid);
		GetInsertDoLog('display_info_lis_job','fn_'.$_GET['mod'],array('id'=>$iid,'display'=>$_GET['value']));//������¼
		fn_cpmsg($Fn_Job->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

	}else if($Do == 'PaymentState' && $_GET['formhash'] == formhash() && $_GET['iid']){
		$iid = intval($_GET['iid']);
		$UpData['payment_state'] = intval($_GET['value']);
		DB::update($Fn_Job->TableInfo,$UpData,'id = '.$iid);
		GetInsertDoLog('payment_state_info_job','fn_'.$_GET['mod'],array('id'=>$_GET['iid'],'payment_state'=>$_GET['value']));//������¼
		fn_cpmsg($Fn_Job->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

	}else if($Do == 'recommend_list'){
		if(!submitcheck('Submit') && !$_GET['PostSubmit']) {
			$Item = $Fn_Job->GetViewthread($_GET['iid']);
			$Fn_Job->Config['LangVar']['RecommendListTitle'] = str_replace(array('{company_name}','{classid_min_text}'),array($Item['company']['name'],$Item['classid_min_text']),$Fn_Job->Config['LangVar']['RecommendListTitle']);
			
			showtagheader('div', 'row', true,'row');
			showtagheader('div', 'col-12', true,'col-12');
			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-body', true,'box-body');
			echo <<<SEARCH
				<div class="FormSearchTo" style="margin-bottom:0;">
					<table cellspacing="4" cellpadding="4">
						<tr>
							<th>{$Fn_Job->Config['LangVar']['RecommendListTitle']}</th>
						</tr>
					</table>
				</div>
SEARCH;
			showtagheader('div', 'table-responsive', true,'table-responsive');
			showformheader($FormUrl,'enctype="multipart/form-data"');
			showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
			showsubtitle(array(
				'ID',
				'UID/'.$Fn_Job->Config['LangVar']['UserNameTitle'],
				$Fn_Job->Config['LangVar']['UploadFace'],
				$Fn_Job->Config['LangVar']['ResumeFullName'],
				$Fn_Job->Config['LangVar']['ResumeMobile'],
				$Fn_Job->Config['LangVar']['WxTitle'],
				$Fn_Job->Config['LangVar']['ResumeEducation'],
				$Fn_Job->Config['LangVar']['ResumeExperience'],
				$Fn_Job->Config['LangVar']['ExpectJob'],
				$Fn_Job->Config['LangVar']['ExpectMonthWages'],
				$Fn_Job->Config['LangVar']['ExpectRegion'],
				$Fn_Job->Config['LangVar']['RefreshTime'],
				$Fn_Job->Config['LangVar']['SetTopTime'],
				$Fn_Job->Config['LangVar']['TimeTitle'],
				$Fn_Job->Config['LangVar']['OperationTitle']
			),'header tbm tc');
			
			$Page = $_GET['page'] ? intval($_GET['page']) : 1;

			$Limit = 20;
			
			$ModulesList = $Fn_Job->GetAjaxUserResumeMatchingList(array('iid'=>$_GET['iid'],'limit'=>$Limit,'page'=>$Page));
			
			foreach ($ModulesList as $Module) {
				showtablerow('', array('class="tc w100"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
					//'<label class="checkbox"><input type="checkbox" class="check" name="delete[]" value="'.$Module['id'].'" /><span class="ic"></span>'.$Module['id'].'</label>',
					$Module['id'],
					$Module['uid'].'/'.$Module['username'],
					$Module['face'] ? '<a href="'.$Module['face'].'" target="_blank"><img src="'.$Module['face'].'" style="height:30px;"></a>' : '',
					$Module['full_name'].'-'.$Module['sex_text'].'-'.$Module['age'].$Fn_Job->Config['LangVar']['Sui'],
					$Module['mobile'],
					$Module['wx'],
					$Module['education_text'],
					$Module['experience_text'],
					$Module['expect_job'],
					$Module['expect_month_wages_text'],
					$Module['expect_province_text'],
					$Module['updateline'],
					$Module['topdateline'] ? date('Y-m-d H:i',$Module['topdateline']) : '',
					date('Y-m-d H:i',$Module['dateline']),
					'<a href="'.$OpCpUrl.'&do=recommend_list&PostSubmit=1&rid='.$Module['uid'].'&iid='.$_GET['iid'].'&formhash='.FORMHASH.'" class="btn btn-sm btn-danger-outline">'.$Fn_Job->Config['LangVar']['RecommendTitle'].'</a>',
				));
			}

			showsubmit('','','','','',multi($Fn_Job->GetAjaxUserResumeMatchingList(array('iid'=>$_GET['iid']),true),$Limit,$Page,$MpUrl.'&do=recommend_list&iid='.$_GET['iid']));
			showtablefooter(); /*dism��taobao��com*/
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
		}else if($_GET['formhash'] == formhash() && $_GET['iid'] && $_GET['rid']){
			$Data = ArrayUrldecode($Fn_Job->GetAdminApplyLog($_GET['iid'],$_GET['rid']));
			if($Data['State'] == 200){
				fn_cpmsg($Data['Msg'],$Fn_Admin->Config['IframeItemUrl'].'&submodel=list&do=recommend_list&iid='.$_GET['iid'],'succeed');
			}else{
				fn_cpmsg($Data['Msg'],'','error');
			}
			exit();
		}
	}else if($Do == 'ManualPush'){
		if(!submitcheck('DetailSubmit')) {
			$Item = $Fn_Job->GetViewthread($_GET['iid']);
			$Fn_Job->Config['LangVar']['RecommendListTitle'] = str_replace(array('{company_name}','{classid_min_text}'),array($Item['company']['name'],$Item['classid_min_text']),$Fn_Job->Config['LangVar']['RecommendListTitle']);
			
			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-header', true,'with-border box-header');
			showtitle($Fn_Job->Config['LangVar']['RecommendListTitle'],'class="box-title"');
			showtagfooter('div');
			showformheader($Fn_Admin->Config['IframeSubModelUrl'].'&iid='.$_GET['iid'].'&do=ManualPush','enctype');
			showtagheader('div', 'box-body', true,'box-body');

			showsetting($Fn_Job->Config['LangVar']['SeeLogResumeUser'].'UID', 'resume_uids','','textarea','','',$Fn_Job->Config['LangVar']['ResumeManualPushTips']);
			
			showsubmit('DetailSubmit','&#20445;&#23384;&#37197;&#32622;');
			showtagfooter('div');
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');

		}else{
			if($_GET['resume_uids']){
				$I = 0;
				foreach(array_filter(explode("\r\n",$_GET['resume_uids'])) as $UID) {
					$ResumeItem = $Fn_Job->GetViewResumethread($UID);
					$Data = $ResumeItem ? ArrayUrldecode($Fn_Job->GetAdminApplyLog($_GET['iid'],$UID)) : '';
					$Data['State'] == 200 ? $I++ : '';
				}
				fn_cpmsg(str_replace('{num}',$I,$Fn_Job->Config['LangVar']['ManualPushSuccess']),$Fn_Admin->Config['IframeItemUrl'].'&submodel=list','succeed');
			}else{
				fn_cpmsg($Fn_Job->Config['LangVar']['ManualPushUidsErr'],'','error');
			}
			exit();
		}
	}
}else if($SubModel == 'add'){//���ӻ�༭
	if(!$Fn_Admin->CheckUserGroup('job_all') && !$Fn_Admin->CheckUserGroup('job_add_info_list')){//Ȩ���ж�
		fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
		exit();
	}
	$iid = intval($_GET['iid']);
	
	$Item = DB::fetch_first('SELECT * FROM '.DB::table($Fn_Job->TableInfo).' where id = '.$iid);

	if(!submitcheck('DetailSubmit')) {
		$OpTitle = $Fn_Job->Config['LangVar']['AddTitle'];
		if($Item){
			$OpTitle = $Fn_Job->Config['LangVar']['EditTitle'];
			$Item['param'] = unserialize($Item['param']);
			$Item['classid_text'] = $Fn_Job->ClassList[$Item['bbclassid']]['content'].($Item['bclassid'] ? '-'.$Fn_Job->ClassList[$Item['bclassid']]['content'] : '').($Item['classid'] ? '-'.$Fn_Job->ClassList[$Item['classid']]['content'] : '');
			$Item['province_text'] = $Fn_Job->Area[$Item['province']]['content'].($Item['city'] ? $Fn_Job->Area[$Item['city']]['content'] : '').($Item['dist'] ? $Fn_Job->Area[$Item['dist']]['content'] : '');
			
		}

		echo '<script src="'.$Config['StaticPath'].'/ueditor/'.CHARSET.'/ueditor.config.js" type="text/javascript"></script><script src="'.$Config['StaticPath'].'/ueditor/'.CHARSET.'/ueditor.all.js" type="text/javascript"></script>';

		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-header', true,'with-border box-header');
		showtitle($OpTitle,'class="box-title"');
		showtagfooter('div');
		showformheader($Fn_Admin->Config['IframeSubModelUrl'].'&iid='.$iid,'enctype');
		showtagheader('div', 'box-body', true,'box-body');

		showsetting($Fn_Job->Config['LangVar']['CompanyId'], 'company_id', $Item['company_id'], 'text','','',$Fn_Job->Config['LangVar']['CompanyUidTips']);
		showsetting('uid', 'new_uid', $Item['uid']  ? $Item['uid'] : $Fn_Job->Config['PluginVar']['AddJobUid'], 'text');
		showsetting($Fn_Job->Config['LangVar']['Title'], 'title', $Item['title'], 'text');
		showsetting($Fn_Job->Config['LangVar']['ContactNumber'], 'mobile', $Item['mobile'], 'text');
		
		$ClassListHtml = GetTreelistHtml($Fn_Job->ClassList,'ClassList',$Item['bbclassid'],$Item['bclassid'],$Item['classid']);//С��λ��

		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_Job->Config['LangVar']['JobCategory'].':</label><div class="col-sm-2"><div style="position:relative;height:40px"><input value="'.$Item['classid_text'].'" class="input form-control TreeList" type="text" id="ClassListClick">'.$ClassListHtml.'</div></div><div class="col-sm-7"><input type="hidden" name="bbclassid" value="'.$Item['bbclassid'].'"/><input type="hidden" name="bclassid" value="'.$Item['bclassid'].'"/><input type="hidden" name="classid" value="'.$Item['classid'].'"/></div></div>';
		
		showsetting($Fn_Job->Config['LangVar']['Type'],array('class', array(
			array('1',$Fn_Job->Config['LangVar']['ClassArray']['1'], array('class_table' => '', 'class_table_no' => 'none')),
			array('2',$Fn_Job->Config['LangVar']['ClassArray']['2'], array('class_table' => 'none', 'class_table_no' => '')),
		), TRUE),$Item ? $Item['class'] : 1, 'mradio');
		
		
		$ClassTableDisplay = $Item['class'] == 1 || !$Item ? true : false;
		$ClassTableNoDisplay = $Item['class'] != 1 && $Item ? true : false;

		showtagheader('div', 'class_table', $ClassTableDisplay, 'sub');
			showsetting($Fn_Job->Config['LangVar']['MonthWages'], array('month_wages',DyadicArray($Fn_Job->Config['LangVar']['MonthWagesArray'],$Fn_Job->Config['LangVar']['Unlimited'])),$Item['month_wages'], 'select','','',$Fn_Job->Config['LangVar']['MonthWagesTips']);
			showsetting($Fn_Job->Config['LangVar']['Education'], array('education',DyadicArray($Fn_Job->Config['LangVar']['EducationArray'],$Fn_Job->Config['LangVar']['Unlimited'])),$Item['education'], 'select');
			showsetting($Fn_Job->Config['LangVar']['Experience'], array('experience',DyadicArray($Fn_Job->Config['LangVar']['ExperienceArray'],$Fn_Job->Config['LangVar']['Unlimited'])),$Item['experience'], 'select');
			showsetting($Fn_Job->Config['LangVar']['NeedNumber'], 'number', $Item['number'], 'text');
			showsetting($Fn_Job->Config['LangVar']['Welfare'],array('tag[]',DyadicArray($Fn_Job->Config['LangVar']['WelfareArray'])),explode(',',$Item['tag']),'mselect','','',$Fn_Admin->Config['LangVar']['Ctrl']);
		showtagfooter('div');
		
		showtagheader('div', 'class_table_no', $ClassTableNoDisplay, 'sub');
			showsetting($Fn_Job->Config['LangVar']['JobMonthWages'], 'concurrent_month_wages', $Item['month_wages'], 'text','','',$Fn_Job->Config['LangVar']['JobMonthWagesTips']);
			showsetting($Fn_Job->Config['LangVar']['JobMonthWagesType'], array('month_wages_type',DyadicArray($Fn_Job->Config['LangVar']['MonthWagesTypeArray'])),$Item['month_wages_type'], 'select');
			showsetting($Fn_Job->Config['LangVar']['Settlement'], array('settlement',DyadicArray($Fn_Job->Config['LangVar']['SettlementArray'])),$Item['settlement'], 'select');
			showsetting($Fn_Job->Config['LangVar']['Cycle'], array('cycle',DyadicArray($Fn_Job->Config['LangVar']['CycleArray'])),$Item['cycle'], 'mradio');
		showtagfooter('div');
		
		//��������
		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_Job->Config['LangVar']['Describe'].':</label><div class="col-sm-9"><textarea id="content" name="content" style="width:80%;height:400px;">'.stripslashes($Item['content']).'</textarea></div></div>';

		showsetting($Fn_Job->Config['LangVar']['Remarks'], 'remarks', $Item['remarks'], 'textarea');

		showsetting($Fn_Job->Config['LangVar']['SetTopTime'], 'topdateline',$Item['topdateline'] ? date('Y-m-d H:i',$Item['topdateline']) : '', 'calendar','','','',1);
		
		if($Item['updateline']){
			showsetting($Fn_Job->Config['LangVar']['RefreshTime'], 'updateline',$Item['updateline'] ? date('Y-m-d H:i',$Item['updateline']) : '', 'calendar','','','',1);
		}

		if($Item['dateline']){
			showsetting($Fn_Job->Config['LangVar']['TimeTitle'], 'dateline',date('Y-m-d H:i',$Item['dateline']), 'calendar','','','',1);
		}

		showsetting($Fn_Job->Config['LangVar']['Click'], 'click', $Item['click'], 'text');

		showsetting($Fn_Job->Config['LangVar']['PaymentState'],array('payment_state',DyadicArray($Fn_Job->Config['LangVar']['PaymentStateArray'])),$Item ? $Item['payment_state'] : 1,'mradio');
		showsetting('&#25903;&#20184;&#31867;&#22411;',array('payment_type',DyadicArray(array('1'=>'&#20184;&#36153;&#21457;&#24067;','2'=>'&#22871;&#39184;&#21457;&#24067;'))),$Item ? $Item['payment_type'] : 1,'mradio');

		showsetting($Fn_Job->Config['LangVar']['ExpiryPushInfoTitle'], 'expiry_push', $Item['expiry_push'], 'radio','','',$Fn_Job->Config['LangVar']['ExpiryPushInfoTitleTips']);
		
		showsetting($Fn_Job->Config['LangVar']['TopExpiryPushInfoTitle'], 'top_expiry_push', $Item['top_expiry_push'], 'radio','','',$Fn_Job->Config['LangVar']['TopExpiryPushInfoTitleTips']);
		
		showsetting($Fn_Job->Config['LangVar']['DisplayTitle'], 'display', $Item ? $Item['display'] : 1, 'radio');

		showsetting($Fn_Job->Config['LangVar']['HideTitle'], 'hide', !$Item ? 0 : ($Item['hide'] ? 0 : 1), 'radio');
		
		showsubmit('DetailSubmit','&#20445;&#23384;&#37197;&#32622;');
		showtagfooter('div');
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');


		echo '<script src="source/plugin/fn_assembly/static/js/mobiscroll.custom-2.16.1.min.js"></script><link rel="stylesheet" href="source/plugin/fn_assembly/static//css/mobiscroll.custom-2.16.1.min.css">';
		
		echo '
			<script>
			$(document).on("click","#ClassListClick",function(){
				GetTreeList($(this),"ClassList","bbclassid","bclassid","classid");
				return false;
			});
			var ue = UE.getEditor("content",{autoHeightEnabled: false,autoFloatEnabled:false,enableAutoSave: false}); 
			</script> 	
		';

	}else{
		
		$Data['company_id'] = intval($_GET['company_id']);
		$Data['uid'] = intval($_GET['new_uid']);
		$Member = DB::fetch_first('SELECT username FROM '.DB::table('common_member').' where uid = '.$Data['uid']);
		$Company = DB::fetch_first('SELECT C.*,AG.title,AG.ico,AG.day_refresh_count,AG.day_info_count,AG.info_count,AG.resume_count,AG.examine FROM '.DB::table($Fn_Job->TableCompany).' C LEFT JOIN `'.DB::table($Fn_Job->TableCompanyGroup).'` AG on AG.id = C.group_id where C.id = '.intval($Data['company_id']));

		$Data['username'] = addslashes(strip_tags($Member['username']));
		
		$Data['title'] = addslashes(strip_tags($_GET['title']));
		$Data['mobile'] = addslashes(strip_tags($_GET['mobile']));
		$Data['class'] = intval($_GET['class']);
		$Data['bbclassid'] = addslashes(strip_tags($_GET['bbclassid']));
		$Data['bclassid'] = addslashes(strip_tags($_GET['bclassid']));
		$Data['classid'] = addslashes(strip_tags($_GET['classid']));
		$Data['province'] = addslashes(strip_tags($Company['province']));
		$Data['city'] = addslashes(strip_tags($Company['city']));
		$Data['dist'] = addslashes(strip_tags($Company['dist']));
		$Data['community'] = addslashes(strip_tags($Company['community']));
		$Data['lat'] = addslashes(strip_tags($Company['lat']));
		$Data['lng'] = addslashes(strip_tags($Company['lng']));
		$Data['month_wages'] = $Data['class'] == 2 ? intval($_GET['concurrent_month_wages']) : intval($_GET['month_wages']);
		$Data['month_wages_type'] = intval($_GET['month_wages_type']);
		$Data['settlement'] = intval($_GET['settlement']);
		$Data['cycle'] = intval($_GET['cycle']);
		$Data['education'] = intval($_GET['education']);
		$Data['experience'] = intval($_GET['experience']);
		$Data['number'] = intval($_GET['number']);

		$Data['tag'] = is_array($_GET['tag']) && isset($_GET['tag']) ? implode(',',$_GET['tag']) : '';
		$Data['content'] = addslashes($_GET['content']);//�豣��Html
		$Data['remarks'] = addslashes($_GET['remarks']);//�豣��Html
		$Data['click'] = intval($_GET['click']);
		$Data['topdateline'] = $_GET['topdateline'] ? strtotime($_GET['topdateline']) : '';
		$Data['payment_state'] = intval($_GET['payment_state']);
		$Data['payment_type'] = intval($_GET['payment_type']);
		$Data['expiry_push'] = intval($_GET['expiry_push']);
		$Data['top_expiry_push'] = intval($_GET['top_expiry_push']);
		$Data['display'] = intval($_GET['display']);
		$Data['hide'] = $_GET['hide'] ? 0 : 1;
		
		foreach(array_filter(explode(",",$Data['tag'])) as $Key => $Val) {
			if($Fn_Job->Config['LangVar']['WelfareArray'][$Val]){
				$Param['tag_list'][] = $Fn_Job->Config['LangVar']['WelfareArray'][$Val];
			}
		}

		$Data['param'] = serialize($Param);
		if($Item){
			$Data['updateline'] = strtotime($_GET['updateline']);
			GetInsertDoLog('edit_info_list_job','fn_'.$_GET['mod'],array('id'=>$iid));//������¼
			DB::update($Fn_Job->TableInfo,$Data,'id = '.$iid);
		}else{
			$Data['dateline'] = $Data['updateline'] = time();
			$Id = DB::insert($Fn_Job->TableInfo,$Data,true);
			GetInsertDoLog('add_info_list_job','fn_'.$_GET['mod'],array('id'=>$Id));//������¼
		}
		fn_cpmsg($Fn_Job->Config['LangVar']['UpdateOk'],$Fn_Admin->Config['IframeItemUrl'].'&submodel=list','succeed');
	}
}


/* �б� */
function GetModulesList($Page,$Limit,$Where=null,$Order){
	global $Fn_Job;
	$FetchSql = 'SELECT I.*,C.name,C.due_time,G.title as group_title FROM '.DB::table($Fn_Job->TableInfo).' I LEFT JOIN `'.DB::table($Fn_Job->TableCompany).'` C on C.id = I.company_id LEFT JOIN `'.DB::table($Fn_Job->TableCompanyGroup).'` G on G.id = C.group_id '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}

/* ���� */
function GetModulesCount($Where=null){
	global $Fn_Job;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_Job->TableInfo).' I '.$Where;
	return DB::result_first($FetchSql);//��������
}

?>