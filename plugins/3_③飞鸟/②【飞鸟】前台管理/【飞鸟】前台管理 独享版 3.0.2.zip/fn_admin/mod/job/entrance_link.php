<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

showtagheader('div', 'box', true,'box');
showtagheader('div', 'box-body', true,'box-body');
showtagheader('div', 'tab-content', true,'tab-content');
showsetting($Fn_Job->Config['LangVar']['PluginLink'], 'PluginLink',$Fn_Job->Config['Url'], 'text');
showsetting($Fn_Job->Config['LangVar']['PluginLinkArray'][8], 'PluginLink',$Fn_Job->Config['Url'].'&app=1', 'text');
showsetting($Fn_Job->Config['LangVar']['PluginLinkArray'][1], 'PluginLink',$Fn_Job->Config['ListUrl'].'&class=1', 'text','','','&#22914;&#24819;&#35843;&#29992;&#24613;&#32856;&#38142;&#25509;&#65292;&#22312;&#35813;&#38142;&#25509;&#21518;&#38754;&#21152;&#32;&#32;&#38;&#116;&#111;&#112;&#61;&#49;&#32;&#32;&#21363;&#21487;');
showsetting($Fn_Job->Config['LangVar']['PluginLinkArray'][2], 'PluginLink',$Fn_Job->Config['ListUrl'].'&class=2', 'text','','','&#22914;&#24819;&#35843;&#29992;&#24613;&#32856;&#38142;&#25509;&#65292;&#22312;&#35813;&#38142;&#25509;&#21518;&#38754;&#21152;&#32;&#32;&#38;&#116;&#111;&#112;&#61;&#49;&#32;&#32;&#21363;&#21487;');
showsetting($Fn_Job->Config['LangVar']['PluginLinkArray'][3], 'PluginLink',$Fn_Job->Config['ListResumeUrl'], 'text');
showsetting($Fn_Job->Config['LangVar']['PluginLinkArray'][4], 'PluginLink',$Fn_Job->Config['ListCompanyUrl'], 'text');
showsetting($Fn_Job->Config['LangVar']['PluginLinkArray'][5], 'PluginLink',$Fn_Job->Config['PublishUrl'].'&class=1', 'text');
showsetting($Fn_Job->Config['LangVar']['PluginLinkArray'][6], 'PluginLink',$Fn_Job->Config['PublishUrl'].'&class=2', 'text');
showsetting($Fn_Job->Config['LangVar']['PluginLinkArray'][7], 'PluginLink',$Fn_Job->Config['UserResumeUrl'], 'text');
showsetting($Fn_Job->Config['LangVar']['PluginLinkArray'][9], 'PluginLink',$Fn_Job->Config['HrToolsUrl'], 'text');
showsetting('&#32844;&#22330;&#36164;&#35759;', 'PluginLink',$Fn_Job->Config['ListArticleUrl'], 'text');
showtagfooter('div');
showtagfooter('div');
showtagfooter('div');

?>