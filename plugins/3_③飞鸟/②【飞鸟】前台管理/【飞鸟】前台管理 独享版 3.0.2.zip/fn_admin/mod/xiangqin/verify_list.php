<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('xiangqin_all') && !$Fn_Admin->CheckUserGroup('xiangqin_verify_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$Do = in_array($_GET['do'], array('Del','add')) ? $_GET['do'] : 'List';

//�����ֶ�
$SearField =array('page','keyword','vid','type','order','audit_state');
foreach($SearField as $Val) {
	$SearArray[$Val] = $_GET[$Val] ? $_GET[$Val] : '';
}
//�����ֶ� End

$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeItemUrl'].'&'.http_build_query($SearArray);
$verifyArr = array('1'=>'real_verify','2'=>'education_verify','3'=>'vehicle_verify','4'=>'house_verify');
$verifyUrlArr = array('1'=>'cert','2'=>'certedu','3'=>'certcar','4'=>'certhouse');
if($Do == 'List'){
	if(!submitcheck('Submit')) {
		$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
		$page = $_GET['page'] ? $_GET['page'] : 0;
		$res = C::t('#fn_xiangqin#fn_love_verify')->fetch_all_by_list(array('vid'=>$_GET['vid'],'type'=>$_GET['type'],'audit_state'=>$_GET['audit_state']),'dateline',$page - 1,30,true);
		/* ģ����� */
		showtagheader('div', 'row', true,'row');
		showtagheader('div', 'col-12', true,'col-12');
		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-body', true,'box-body');
		/* ���� */
		$audit_state_selected = array($_GET['audit_state']=>' selected');
		$verify_option = '<option value="">'.$fn_xiangqin->setting['lang']['SelectNull'].'</option>';
		foreach($fn_xiangqin->setting['lang']['user_verify_arr'] as $key => $val) {
			$verify_option .= '<option value="'. $key.'" '.($_GET['type'] ==  $key ? ' selected' : '' ).'>'.$val.'</option>';
		}

		echo <<<SEARCH
		<form method="post" autocomplete="off" action="$SearUrl" id="tb_search">
			<div class="FormSearchTo">
				<table cellspacing="4" cellpadding="4">
					<tr>
						<th>&#29992;&#25143;&#73;&#68;</th>
						<td colspan="10">
							<input type="text" class="input form-control w200" name="vid" value="{$_GET['vid']}" placeholder="&#35831;&#36755;&#20837;&#29992;&#25143;&#73;&#68;">
						</td>
						<th>&#23457;&#26680;&#29366;&#24577;</th><td>
						<select name="audit_state" class="form-control w120">
							<option value="">{$fn_xiangqin->setting['lang']['SelectNull']}</option>
							<option value="1"{$audit_state_selected['1']}>{$fn_xiangqin->setting['lang']['audit_state_arr']['1']}</option>
							<option value="2"{$audit_state_selected['2']}>{$fn_xiangqin->setting['lang']['audit_state_arr']['2']}</option>
							<option value="3"{$audit_state_selected['3']}>{$fn_xiangqin->setting['lang']['audit_state_arr']['3']}</option>
						</select>
						</td>
						<th>&#35748;&#35777;&#31867;&#22411;</th>
						<td colspan="10">
							<select name="type" class="form-control w120">
								{$verify_option}
							</select>
							&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Admin->Config['LangVar']['SearchSubmit']}" class="btn btn-info" type="submit">
						</td>
					</tr>
				</table>
			</div>
		</form>
SEARCH;
		/* ���� End */
		showtagheader('div', 'table-responsive', true,'table-responsive');
		showformheader($FormUrl,'enctype="multipart/form-data"');
		showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
		showsubtitle(array(
			'ID',
			'&#29992;&#25143;',
			'&#35748;&#35777;&#31867;&#22411;',
			'&#22270;&#29255;',
			'&#20869;&#23481;',
			$fn_xiangqin->setting['lang']['audit_state'],
			$fn_xiangqin->setting['lang']['refuse'],
			$fn_xiangqin->setting['lang']['TimeTitle'],
			$fn_xiangqin->setting['lang']['UpdateTime'],
			$fn_xiangqin->setting['lang']['OperationTitle']
		), 'header tbm tc');
	
		foreach ($res['list'] as $item) {
			$userInfo = $fn_xiangqin->getView($item['vid']);
			$content = '';
			foreach (dunserialize($item['content']) as $val) {
				$content .= $val['title'].'&#65306;'.$val['content'].'<br>';
			}
			showtablerow('', array('class="tc w100"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
				'<input type="checkbox" class="filled-in" id="checkbox_'.$item['id'].'" name="delete[]" value="'.$item['id'].'"><label for="checkbox_'.$item['id'].'">'.$item['id'].'</label>',
				"&#32534;&#21495;&#65306;".$userInfo['id'].'<br>&#22995;&#21517;&#65306;'.$userInfo['name'].'-'.$userInfo['sex_text'].'-'.$userInfo['age'].'<br>&#25163;&#26426;&#21495;&#65306;'.$userInfo['phone'],
				$fn_xiangqin->setting['lang']['user_verify_arr'][$item['type']],
				'<a href="'.$item['cert_img'].'" target="_blank"><img src="'.$item['cert_img'].'" style="height:45px;"></a>',
				$content,
				$item['audit_state'] != 1 ? '<span class="label bg-secondary">'.$fn_xiangqin->setting['lang']['audit_state_arr'][$item['audit_state']].'</span>' : '<span class="label bg-blue">'.$fn_xiangqin->setting['lang']['audit_state_arr'][$item['audit_state']].'</span>',
				$item['audit_state'] == 3 ? $item['refuse_tips'] : '',
				date('Y-m-d H:i',$item['dateline']),
				date('Y-m-d H:i',$item['updateline']),
				'<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&do=add&aid='.$item['id'].'" class="btn btn-sm btn-info-outline">&#23457;&#26680;</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Del&vid='.$item['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$fn_xiangqin->setting['lang']['DelTitle'].'</a>',
			));
		}
		showsubmit('Submit','&#31435;&#21363;&#25552;&#20132;','del','','',multi($res['count'],30,$page,$MpUrl));
		showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		/* ģ����� End */
	}else{
		if(isset($_GET['delete']) && is_array($_GET['delete'])){
			foreach($_GET['delete'] as $val) {
				$id = intval($val);
				$item = C::t('#fn_xiangqin#fn_love_verify')->fetch_by_id($id);
				C::t('#fn_xiangqin#fn_love_user')->update(array($verifyArr[$item['type']]=>0),$item['vid']);
				C::t('#fn_xiangqin#fn_love_verify')->delete_by_id($id);
			}
			GetInsertDoLog('del_verify_xiangqin','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete'])));//������¼
			fn_cpmsg($fn_xiangqin->setting['lang']['DelOk'],$CpMsgUrl,'succeed');
		}else{
			fn_cpmsg($fn_xiangqin->setting['lang']['DelErr'],'','error');
		}
	}
}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['vid']){//ɾ��
	$id = intval($_GET['vid']);
	$item = C::t('#fn_xiangqin#fn_love_verify')->fetch_by_id($id);
	C::t('#fn_xiangqin#fn_love_user')->update(array($verifyArr[$item['type']]=>0),$item['vid']);
	C::t('#fn_xiangqin#fn_love_verify')->delete_by_id($id);
	GetInsertDoLog('del_verify_xiangqin','fn_'.$_GET['mod'],array('id'=>$id));//������¼
	fn_cpmsg($fn_xiangqin->setting['lang']['DelOk'],$CpMsgUrl,'succeed');
}else if($Do == 'add'){//���ӻ�༭
	$id = intval($_GET['aid']);
	$item = C::t('#fn_xiangqin#fn_love_verify')->fetch_by_id($id);
	if(!submitcheck('DetailSubmit')) {
		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-header', true,'with-border box-header');
		showtitle('&#23457;&#26680;','class="box-title"');
		showtagfooter('div');
		showformheader($Fn_Admin->Config['IframeItemUrl'].'&do=add&aid='.$id,'enctype');
		showtagheader('div', 'box-body', true,'box-body');
		
		showsetting('&#35748;&#35777;&#31867;&#22411;', 'new_type', $fn_xiangqin->setting['lang']['user_verify_arr'][$item['type']], 'text',true);

		showsetting('&#35748;&#35777;&#22270;&#29255;', 'cert_img', $item['cert_img'], 'text',true,'','<a href="'.$item['cert_img'].'" target="_blank"><img src="'.$item['cert_img'].'" style="height:35px;"></a>');
		
		foreach(dunserialize($item['content']) as $val) {
			showsetting($val['title'], $val['name'], $val['content'], 'text',true);
		}

		showsetting($fn_xiangqin->setting['lang']['audit_state'],array('audit_state', array(
			array('1',$fn_xiangqin->setting['lang']['audit_state_arr']['1'], array('audit_state_3' => 'none')),
			array('2',$fn_xiangqin->setting['lang']['audit_state_arr']['2'], array('audit_state_3' => 'none')),
			array('3',$fn_xiangqin->setting['lang']['audit_state_arr']['3'], array('audit_state_3' => '')),
		), TRUE),$item['audit_state'], 'mradio');
		showtagheader('div', 'audit_state_3', $item['audit_state'] == 3 ? true : '');
			showsetting('&#25298;&#32477;&#29702;&#30001;', 'refuse_tips',$item['refuse_tips'], 'text');
		showtagfooter('div');

		showsubmit('DetailSubmit','&#20445;&#23384;&#37197;&#32622;');
		showtagfooter('div');
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');
	}else{
		$pushUrl = $fn_xiangqin->getUrl('user',array('form'=>$verifyUrlArr[$item['type']]));
		$noticeMsg = str_replace(array('[--type--]','[--audit_state--]'),array($fn_xiangqin->setting['lang']['user_verify_arr'][$item['type']],$fn_xiangqin->setting['lang']['audit_state_arr'][$_GET['audit_state']]),$fn_xiangqin->setting['lang']['verifyNoticeMsg']);
		if($_GET['audit_state'] == 1){
			C::t('#fn_xiangqin#fn_love_user')->update(array($verifyArr[$item['type']]=>1),$item['vid']);
			$fn_xiangqin->getAuditNotice($item['vid'],$_GET['audit_state'],$pushUrl,$noticeMsg);
		}else if($_GET['audit_state'] == 3){
			$fn_xiangqin->getAuditNotice($item['vid'],$_GET['audit_state'],$pushUrl,$noticeMsg);
		}
		C::t('#fn_xiangqin#fn_love_verify')->update(array('audit_state'=>$_GET['audit_state'],'refuse_tips'=>$_GET['audit_state'] == 3 ? addslashes(strip_tags($_GET['refuse_tips'])) : ''),$id);
		fn_cpmsg($fn_xiangqin->setting['lang']['UpdateOk'],$CpMsgUrl,'succeed');
		exit();
	}
}
//From: Dism_taobao_com
?>