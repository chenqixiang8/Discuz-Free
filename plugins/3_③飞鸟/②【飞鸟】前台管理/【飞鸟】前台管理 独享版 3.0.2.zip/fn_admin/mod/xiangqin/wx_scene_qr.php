<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('xiangqin_all') && !$Fn_Admin->CheckUserGroup('xiangqin_wx_scene_qr')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$plugin['identifier'] = 'fn_'.$_GET['mod'];
loadcache($plugin['identifier'].'_setting');
$common_setting = (array)$_G['cache'][$plugin['identifier'].'_setting'];
$WxAppid = $common_setting['WxAppid'];
$WxSecret = $common_setting['WxSecret'];

if(!$WxAppid || !$WxSecret) {
	fn_cpmsg(lang('plugin/fn_assembly', 'wsq_menu_at_error'), '', 'error');
	exit();
}

$SubModel = in_array($_GET['submodel'], array('list','add')) ? $_GET['submodel'] : 'list';
$Fn_Admin->Config['IframeSubModelUrl'] = $Fn_Admin->Config['IframeItemUrl'].'&submodel='.$SubModel;
$NavClass = array($SubModel=>'btn-info Hover');

if($SubModel == 'list'){//�б�
	$Do = in_array($_GET['do'], array('Refresh','Del','Display')) ? $_GET['do'] : 'submodel_list';
	//�����ֶ�
	$SearField =array('page','keyword','merge','display','order');
	foreach($SearField as $Val) {
		$SearArray[$Val] = $_GET[$Val] || in_array($_GET[$Val],array('0')) ? $_GET[$Val] : '';
	}
	//�����ֶ� End
	$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeSubModelUrl'].'&'.http_build_query($SearArray);
	
	if($Do == 'submodel_list'){
		if(!submitcheck('Submit')) {
			$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
			$Where = ' and q.plugin  = \'fn_'.$_GET['mod'].'\'';
			$Order = $_GET['order'] ? 'q.'.addslashes(dhtmlspecialchars($_GET['order'])) : 'q.id';
			
			if($_GET['keyword']){
				$_GET['keyword'] = str_replace(array('%','_'),array('',''),$_GET['keyword']);
				$Where .= ' and (q.title like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') )';
			}
			
			$Where = preg_replace('/and/','where',$Where,1);
			$Limit = 20;
			$Page = $_GET['page']?intval($_GET['page']):1;
			/* ��ѯ���� End */
			

			/* ģ����� */	
			showtagheader('div', 'row', true,'row');
			showtagheader('div', 'col-12', true,'col-12');
			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-body', true,'box-body');
			/* ���� */
			
			$MergeSelected = array($_GET['merge']=>' selected');
			$DisplaySelected = array($_GET['display']=>' selected');
			$OrderSelected = array($_GET['order']=>' selected');
		
			echo <<<SEARCH
			<form method="post" autocomplete="off" action="$SearUrl">
				<div class="FormSearchTo" style="margin-bottom:0;">
					<table cellspacing="4" cellpadding="4">
						<tr>
							<th>&#20851;&#38190;&#35789;&#32;</th><td><input type="text" class="input form-control w200" name="keyword" value="{$_GET['keyword']}" placeholder="&#35831;&#36755;&#20837;&#26631;&#39064;">
							</td>
							<th>{$Fn_Admin->Config['LangVar']['Order']}</th><td>
							<select name="order" class="form-control w120">
								<option value="dateline"{$OrderSelected['dateline']}>{$Fn_Admin->Config['LangVar']['OrderArray']['dateline']}</option>
							</select>
							&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Admin->Config['LangVar']['SearchSubmit']}" class="btn btn-info" type="submit">
							&nbsp;&nbsp;<a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=add" target="_self" class="btn btn-danger">{$Fn_Admin->Config['LangVar']['AddEditTitle']}</a>
							</td>
						</tr>
					</table>
				</div>
			</form>
SEARCH;
			/* ���� End */
			showtagheader('div', 'table-responsive', true,'table-responsive');
			showformheader($FormUrl,'enctype="multipart/form-data"');
			showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
			showsubtitle(array(
				'ID',
				'&#26631;&#39064;',
				'&#25688;&#35201;',
				'&#23553;&#38754;',
				'&#20108;&#32500;&#30721;&#31867;&#22411;',
				'&#20108;&#32500;&#30721;',
				'&#28155;&#21152;&#26102;&#38388;',
				'&#25805;&#20316;'
			),'header tbm tc');

			$ModulesList = GetModulesList($Page,$Limit,$Where,$Order);
			foreach ($ModulesList as $Module) {
				
				showtablerow('', array('class="tc w80"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
					'<input type="checkbox" class="filled-in" id="checkbox_'.$Module['id'].'" name="delete[]" value="'.$Module['id'].'"><label for="checkbox_'.$Module['id'].'">'.$Module['id'].'</label>',
					$Module['title'],
					$Module['desc'],
					$Module['pic'] ? '<a href="'.$Module['pic'].'" target="_blank"><img src="'.$Module['pic'].'" style="height:30px;"></a>' : '',
					$Module['qrcode_type'] == 1 ? '&#38480;&#26102;&#26377;&#25928;-'.$Module['qrcode_date'].'&#22825;' : '&#27704;&#20037;&#26377;&#25928;',
					$Module['qrcode'] ? '<a href="'.$Module['qrcode'].'" target="_blank"><img src="'.$Module['qrcode'].'" style="height:30px;"></a>' : '',
					date('Y-m-d H:i',$Module['dateline']),
					'<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&vid='.$Module['id'].'" class="btn btn-sm btn-info-outline">'.$Fn_Admin->Config['LangVar']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Refresh&vid='.$Module['id'].'&formhash='.FORMHASH.'" class="btn btn-sm btn-primary-outline">&#21047;&#26032;&#20108;&#32500;&#30721;</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Del&vid='.$Module['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$Fn_Admin->Config['LangVar']['DelTitle'].'</a>',

				));
			}
			showsubmit('Submit','&#31435;&#21363;&#25552;&#20132;','del','','',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));
			showtablefooter(); /*dism��taobao��com*/
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			/* ģ�����End */	
		}else{
			if(isset($_GET['delete']) && is_array($_GET['delete'])){
				foreach($_GET['delete'] as $Key => $Val) {
					$Val = intval($Val);
					DB::delete('fn_wx_scene_qr','id ='.$Val);
	
				}
				fn_cpmsg($Fn_Admin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
			}else{
				fn_cpmsg($Fn_Admin->Config['LangVar']['DelErr'],'','error');
			}
				
		}
	}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['vid']){
		$id = intval($_GET['vid']);
		DB::delete('fn_wx_scene_qr','id ='.$id);
		fn_cpmsg($Fn_Admin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
	}else if($Do == 'Refresh' && $_GET['formhash'] == formhash() && $_GET['vid']){
		$id = intval($_GET['vid']);
		$Item = DB::fetch_first('SELECT * FROM '.DB::table('fn_wx_scene_qr').' where id = '.$id);
		@require_once libfile('class/wechat','plugin/fn_assembly');
		$WechatClient = new Fn_WeChatClient($WxAppid,$WxSecret);
		$UpData['qrcode'] = $WechatClient->getQrcodeImgUrlByTicket($WechatClient->getQrcodeTicket(array('scene_str'=>'fn_scene_qr____view____'.intval($id),'expire'=>$Item['qrcode_type'] == 1 ? $Item['qrcode_date'] * 60 * 60 * 24 : '')));
		DB::update('fn_wx_scene_qr',$UpData,'id = '.$id);
		fn_cpmsg($Fn_Admin->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
	}
}else if($SubModel == 'add'){//���ӻ�༭
	
	$id = intval($_GET['vid']);

	$Item = DB::fetch_first('SELECT * FROM '.DB::table('fn_wx_scene_qr').' where id = '.$id);
	
	if(!submitcheck('DetailSubmit')) {
		$OpTitle = $Item ? $Fn_Admin->Config['LangVar']['EditTitle'] : $Fn_Admin->Config['LangVar']['AddTitle'];

		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-header', true,'with-border box-header');
		showtitle($OpTitle,'class="box-title"');
		showtagfooter('div');
		showformheader($Fn_Admin->Config['IframeSubModelUrl'].'&vid='.$id,'enctype');
		showtagheader('div', 'box-body', true,'box-body');
		
		showsetting('&#26631;&#39064;', 'title', $Item['title'], 'text');
		$pic_html = ($Item['pic'] ? '<a href="'.$Item['pic'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$Item['pic'].'" height="55"/></a>' : '');
		showsetting('&#23553;&#38754;', 'new_pic',$Item['pic'], 'filetext', '', 0, $pic_html);
		showsetting('&#25688;&#35201;', 'desc', $Item['desc'], 'textarea');
		showsetting('&#21407;&#25991;&#38142;&#25509;', 'url', $Item['url'], 'text');

		showsetting('&#20108;&#32500;&#30721;&#31867;&#22411;',array('qrcode_type', array(
			array('1','&#38480;&#26102;&#26377;&#25928;', array('qrcode_type_1' => '')),
			array('2','&#27704;&#20037;&#26377;&#25928;', array('qrcode_type_1' => 'none')),
		), TRUE),$Item['qrcode_type'] ? $Item['qrcode_type'] : 1, 'mradio','','','&#27880;&#24847;&#65306;&#27704;&#20037;&#26377;&#25928;&#30340;&#20108;&#32500;&#30721;&#26368;&#22810;&#49;&#48;&#19975;&#20010;');

		showtagheader('div', 'qrcode_type_1', $Item['qrcode_type'] == 1 || !$Item ? true : '','sub');
			showsetting('&#20108;&#32500;&#30721;&#26377;&#25928;&#26102;&#38388;', 'qrcode_date', $Item['qrcode_date'] ? $Item['qrcode_date'] : 30, 'text','','','&#21333;&#20301;&#65306;&#22825;&#65281;&#65281;&#65281;&#26368;&#38271;&#21487;&#20197;&#35774;&#32622;&#51;&#48;&#22825;');
		showtagfooter('div');
		
		if($Item['dateline']){
			showsetting('&#28155;&#21152;&#26102;&#38388;', 'dateline',date('Y-m-d H:i',$Item['dateline']), 'calendar','','','',1);
		}

		showsubmit('DetailSubmit','&#20445;&#23384;&#37197;&#32622;');
		showtagfooter('div');
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');
	}else{
		@require_once libfile('function/core','plugin/fn_assembly');

		$Data['plugin'] = 'fn_'.$_GET['mod'];
		$Data['title'] = addslashes(strip_tags($_GET['title']));
		$Data['desc'] = addslashes(strip_tags($_GET['desc']));
		$Data['url'] = addslashes(strip_tags($_GET['url']));
		$Data['qrcode_type'] = intval($_GET['qrcode_type']);
		$Data['qrcode_date'] = intval($_GET['qrcode_date']) > 30 ? 30 : intval($_GET['qrcode_date']);

		foreach($_FILES as $file_key => $file_value){
			if(strpos($file_key,'new_') !== false){
				$key = str_replace(array('TMPnew_','new_'),'',$file_key);
				if($_FILES[$file_key]['size']){
					$FileCode = Fn_Upload($_FILES[$file_key]);
					if($FileCode['Errorcode']){
						fn_cpmsg($Fn_Admin->Config['LangVar']['ImgErr'],'','error');
						exit();
					}else{
						$Data[$key] = $FileCode['Path'];
					}
				}else{
					$file_key = str_replace(array('TMPnew_'),array('new_'),$file_key);
					if(!preg_match('/.*(\.png|\.jpg|\.jpeg|\.gif)$/',$_GET[$file_key]) && $_GET[$file_key]){
						fn_cpmsg($Fn_Admin->Config['LangVar']['ImgErr'],'','error');
						exit();
					}else{
						$Data[$key] = addslashes(strip_tags($_GET[$file_key]));
					}
				}
				if($Data[$key]){
					$Data[$key] = strpos($Data[$key],'http') !== false ? $Data[$key] : $_G['siteurl'].$Data[$key];
				}
			}
		}
		if($Item){
			$Data['dateline'] = strtotime($_GET['dateline']);
		}else{
			$Data['dateline'] = time();
			$id = DB::insert('fn_wx_scene_qr',$Data,true);
		}
		@require_once libfile('class/wechat','plugin/fn_assembly');
		$WechatClient = new Fn_WeChatClient($WxAppid,$WxSecret);
		$Data['qrcode'] = $WechatClient->getQrcodeImgUrlByTicket($WechatClient->getQrcodeTicket(array('scene_str'=>'fn_scene_qr____view____'.intval($id),'expire'=>$Data['qrcode_type'] == 1 ? $Data['qrcode_date'] * 60 * 60 * 24 : '')));
		DB::update('fn_wx_scene_qr',$Data,'id = '.$id);
		fn_cpmsg($Fn_Admin->Config['LangVar']['UpdateOk'],$Fn_Admin->Config['IframeItemUrl'].'&submodel=list','succeed');
	}
}

/* �б� */
function GetModulesList($Page,$Limit,$Where=null,$Order){
	$FetchSql = 'SELECT * FROM '.DB::table('fn_wx_scene_qr').' q '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}

/* ���� */
function GetModulesCount($Where=null){
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table('fn_wx_scene_qr').' q '.$Where;
	return DB::result_first($FetchSql);//��������
}
//From: Dism��taobao��com
?>