<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('xiangqin_all') && !$Fn_Admin->CheckUserGroup('xiangqin_user_pull_log_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$SubModel = in_array($_GET['submodel'], array('list','add')) ? $_GET['submodel'] : 'list';
$Fn_Admin->Config['IframeSubModelUrl'] = $Fn_Admin->Config['IframeItemUrl'].'&submodel='.$SubModel;
$NavClass = array($SubModel=>'btn-info Hover');

//����
echo <<<Nav
<div class="SubModelNav">
  <ul>
	<li class="{$NavClass['list']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=list" target="_self">{$Fn_Admin->Config['LangVar']['XiangqinLeftNavArray'][$_GET['item']]}</a></li>
    <li class="{$NavClass['add']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=add" target="_self">{$Fn_Admin->Config['LangVar']['AddEditTitle']}</a></li>
  </ul>
  <div class="both"></div>
</div>
Nav;

if($SubModel == 'list'){//�б�
	$Do = in_array($_GET['do'], array('Del')) ? $_GET['do'] : 'submodel_list';
	//�����ֶ�
	$SearField =array('page','keyword','vid','love_vid','state','order');
	foreach($SearField as $Val) {
		$SearArray[$Val] = $_GET[$Val] ? $_GET[$Val] : '';
	}
	//�����ֶ� End
	$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeSubModelUrl'].'&'.http_build_query($SearArray);
	if($Do == 'submodel_list'){
		if(!submitcheck('Submit')) {
			$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
			$page = $_GET['page'] ? $_GET['page'] : 0;
			$res = C::t('#fn_xiangqin#fn_love_user_pull_log')->fetch_all_by_list(array('vid'=>$_GET['vid'],'love_vid'=>$_GET['love_vid'],'state'=>$_GET['state']),'dateline',$page - 1,30,true);
			/* ��ѯ���� End */

			/* ģ����� */	
			showtagheader('div', 'row', true,'row');
			showtagheader('div', 'col-12', true,'col-12');
			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-body', true,'box-body');
			/* ���� */
			$state_option = '<option value="">'.$fn_xiangqin->setting['lang']['SelectNull'].'</option>';
			foreach($fn_xiangqin->setting['lang']['pull_state_arr'] as $key => $val) {
				$state_option .= '<option value="'. $key.'" '.($_GET['state'] ==  $key ? ' selected' : '' ).'>'.$val.'</option>';
			}

			echo <<<SEARCH
			<form method="post" autocomplete="off" action="$SearUrl" id="tb_search">
				<div class="FormSearchTo">
					<table cellspacing="4" cellpadding="4">
						<tr>
							<th>&#29301;&#32447;&#29992;&#25143;&#73;&#68;</th>
							<td colspan="10"><input type="text" class="input form-control w200" name="vid" value="{$_GET['vid']}" placeholder="&#35831;&#36755;&#20837;&#29301;&#32447;&#29992;&#25143;&#73;&#68;">
							</td>
							<th>&#34987;&#29301;&#32447;&#29992;&#25143;&#73;&#68;</th>
							<td><input type="text" class="input form-control w200" name="love_vid" value="{$_GET['love_vid']}" placeholder="&#35831;&#36755;&#20837;&#34987;&#29301;&#32447;&#29992;&#25143;&#73;&#68;">
							</td>
							<th>&#29366;&#24577;</th>
							<td colspan="10">
								<select name="state" class="form-control w120">
									{$state_option}
								</select>
								&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Admin->Config['LangVar']['SearchSubmit']}" class="btn btn-info" type="submit">
							</td>
							
						</tr>
					</table>
				</div>
			</form>
SEARCH;
		/* ���� End */
			showtagheader('div', 'table-responsive', true,'table-responsive');
			showformheader($FormUrl,'enctype="multipart/form-data"');
			showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
			showsubtitle(array(
				'ID',
				'&#29301;&#32447;&#29992;&#25143;',
				'&#29301;&#32447;&#29992;&#25143;&#22836;&#20687;',
				'&#34987;&#29301;&#32447;&#29992;&#25143;',
				'&#34987;&#29301;&#32447;&#29992;&#25143;&#22836;&#20687;',
				'&#29301;&#32447;&#29366;&#24577;',
				'&#29301;&#32447;&#22791;&#27880;',
				'&#29301;&#32447;&#26102;&#38388;',
				'&#28155;&#21152;&#26102;&#38388;',
				$fn_xiangqin->setting['lang']['OperationTitle']
			),'header tbm tc');

			foreach ($res['list'] as $item) {
				$userInfo = $fn_xiangqin->getView($item['vid']);
				$coverUserInfo = $fn_xiangqin->getView($item['love_vid']);
				showtablerow('', array('class="tc w50"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
					'<input type="checkbox" class="filled-in" id="checkbox_'.$item['id'].'" name="delete[]" value="'.$item['id'].'"><label for="checkbox_'.$item['id'].'">'.$item['id'].'</label>',
					'<a href="'.$userInfo['url'].'" target="_blank">&#32534;&#21495;&#65306;'.$userInfo['id'].'</a><br>&#22995;&#21517;&#65306;'.$userInfo['name'].'-'.$userInfo['sex_text'].'-'.$userInfo['age'].'<br>&#25163;&#26426;&#21495;&#65306;'.$userInfo['phone'],
					($userInfo['head_portrait'] ? '<a href="'.$userInfo['head_portrait'].'" target="_blank"><img src="'.$userInfo['head_portrait'].'" height="60"></a>' : ''),
					'<a href="'.$coverUserInfo['url'].'" target="_blank">&#32534;&#21495;&#65306;'.$coverUserInfo['id'].'</a><br>&#22995;&#21517;&#65306;'.$coverUserInfo['name'].'-'.$coverUserInfo['sex_text'].'-'.$coverUserInfo['age'].'<br>&#25163;&#26426;&#21495;&#65306;'.$coverUserInfo['phone'],
					($coverUserInfo['head_portrait'] ? '<a href="'.$coverUserInfo['head_portrait'].'" target="_blank"><img src="'.$coverUserInfo['head_portrait'].'" height="60"></a>' : ''),
					'<span class="label bg-blue">'.$fn_xiangqin->setting['lang']['pull_state_arr'][$item['state']]."</span>",
					$item['remarks'],
					date('Y-m-d H:i',$item['pull_dateline']),
					date('Y-m-d H:i',$item['dateline']),
					'<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&aid='.$item['id'].'" class="btn btn-sm btn-info-outline">'.$fn_xiangqin->setting['lang']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Del&aid='.$item['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$fn_xiangqin->setting['lang']['DelTitle'].'</a>',
				));
			}
			showsubmit('Submit','&#31435;&#21363;&#25552;&#20132;','del','','',multi($res['count'],30,$page,$MpUrl));
			showtablefooter(); /*dism��taobao��com*/
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			/* ģ�����End */	
		}else{
			if(isset($_GET['delete']) && is_array($_GET['delete'])){
				if(!$Fn_Admin->CheckUserGroup('xiangqin_all') && !$Fn_Admin->CheckUserGroup('xiangqin_del_user_pull_log')){//Ȩ���ж�
					fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
					exit();
				}
				foreach($_GET['delete'] as $val) {
					$id = intval($val);
					C::t('#fn_xiangqin#fn_love_user_pull_log')->delete_by_id($id);
				}
				GetInsertDoLog('del_pull_xiangqin','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete'])));//������¼
				fn_cpmsg($fn_xiangqin->setting['lang']['DelOk'],$CpMsgUrl,'succeed');
			}else{
				fn_cpmsg($fn_xiangqin->setting['lang']['DelErr'],'','error');
			}
		}
	}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['aid']){
		if(!$Fn_Admin->CheckUserGroup('xiangqin_all') && !$Fn_Admin->CheckUserGroup('xiangqin_del_user_pull_log')){//Ȩ���ж�
			fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
			exit();
		}
		$id = intval($_GET['aid']);
		C::t('#fn_xiangqin#fn_love_user_pull_log')->delete_by_id($id);
		GetInsertDoLog('del_pull_xiangqin','fn_'.$_GET['mod'],array('id'=>$id));//������¼
		fn_cpmsg($fn_xiangqin->setting['lang']['DelOk'],$CpMsgUrl,'succeed');
		exit();
	}
}else if($SubModel == 'add'){//���ӻ�༭

	$id = intval($_GET['aid']);
	
	$item = C::t('#fn_xiangqin#fn_love_user_pull_log')->fetch_by_id($id);

	if(!submitcheck('DetailSubmit')) {
		$opTitle = $fn_xiangqin->setting['lang']['AddTitle'];
		if($item){
			$opTitle = $fn_xiangqin->setting['lang']['EditTitle'];
		}
		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-header', true,'with-border box-header');
		showtitle($opTitle,'class="box-title"');
		showtagfooter('div');
		showformheader($Fn_Admin->Config['IframeSubModelUrl'].'&aid='.$id,'enctype');
		showtagheader('div', 'box-body', true,'box-body');
		showsetting('&#29301;&#32447;&#29992;&#25143;ID', 'vid', $item['vid'], 'text');
		showsetting('&#34987;&#29301;&#32447;&#29992;&#25143;ID', 'love_vid', $item['love_vid'], 'text');
		showsetting('&#29301;&#32447;&#29366;&#24577;',array('state',DyadicArray($fn_xiangqin->setting['lang']['pull_state_arr'])),$item['state'] ? $item['state'] : 1,'mradio');
		showsetting('&#25187;&#38500;&#27425;&#25968;', 'pull_number', $item['pull_number'], 'text','','','&#25187;&#38500;&#22810;&#23569;&#27425;&#29301;&#32447;&#27425;&#25968;&#65292;&#19981;&#22635;&#20889;&#19981;&#25187;&#38500;&#65281;&#65281;&#65281;');
		showsetting('&#29301;&#32447;&#22791;&#27880;', 'remarks', $item['remarks'], 'textarea');
		showsetting('&#29301;&#32447;&#26102;&#38388;', 'pull_dateline',$item['pull_dateline'] ? date('Y-m-d H:i',$item['pull_dateline']) : '', 'calendar','','','',1);
		if($item['dateline']){
			showsetting('&#28155;&#21152;&#26102;&#38388;', 'dateline',date('Y-m-d H:i',$item['dateline']), 'calendar','','','',1);
		}
		showsubmit('DetailSubmit','&#20445;&#23384;&#37197;&#32622;');
		showtagfooter('div');
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');

	}else{
		$data['vid'] = intval($_GET['vid']);
		$data['love_vid'] = intval($_GET['love_vid']);
		$data['remarks'] = addslashes(strip_tags($_GET['remarks']));
		$data['state'] = intval($_GET['state']);
		$data['pull_dateline'] = $_GET['pull_dateline'] ? strtotime($_GET['pull_dateline']) : '';
		$user = C::t('#fn_xiangqin#fn_love_user')->fetch_by_id($data['vid']);
		if($_GET['pull_number'] && $user['pull'] >= $_GET['pull_number']){
			$loveUser = C::t('#fn_xiangqin#fn_love_user')->fetch_by_id($data['love_vid']);
			C::t('#fn_xiangqin#fn_love_user')->update_by_count($data['vid'],'pull',intval($_GET['pull_number']),'-');
			C::t('#fn_xiangqin#fn_love_con_log')->insert(array('uid'=>intval($user['uid']),'vid'=>intval($data['vid']),'love_vid'=>intval($data['love_vid']),'pull'=>intval($_GET['pull_number']),'event_type'=>6,'content'=>str_replace(array('[--name--]','[--love_name--]'),array($user['name'],$loveUser['name']),$fn_xiangqin->setting['lang']['con_log_content']['pull']),'dateline'=>time()));
		}
		if($item){
			$data['dateline'] = strtotime($_GET['dateline']);
			GetInsertDoLog('edit_pull_xiangqin','fn_'.$_GET['mod'],array('id'=>$id));//������¼
			C::t('#fn_xiangqin#fn_love_user_pull_log')->update($data,$id);
		}else{
			$mat = C::t('#fn_xiangqin#fn_love_mat')->fetch_by_uid($_G['uid']);
			$data['mat_id'] = $mat['id'];
			$data['dateline'] = time();
			$id = C::t('#fn_xiangqin#fn_love_user_pull_log')->insert($data);
			GetInsertDoLog('add_pull_xiangqin','fn_'.$_GET['mod'],array('id'=>$id));//������¼
		}
		fn_cpmsg($fn_xiangqin->setting['lang']['UpdateOk'],$Fn_Admin->Config['IframeItemUrl'].'&submodel=list','succeed');
		exit();
	}
}
//From: Dism_taobao_com
?>