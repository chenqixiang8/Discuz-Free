<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

showtagheader('div', 'box', true,'box');
showtagheader('div', 'box-body', true,'box-body');
showtagheader('div', 'tab-content', true,'tab-content');
showsetting('&#39318;&#39029;', 'PluginLink',$fn_xiangqin->getUrl('index'), 'text');
showsetting('&#39318;&#39029;&#38544;&#34255;&#24213;&#37096;&#23548;&#33322;', 'PluginLink',$fn_xiangqin->getUrl('index',array('app'=>1)), 'text');
showsetting('&#32418;&#23064;&#25512;&#33616;&#21015;&#34920;', 'PluginLink',$fn_xiangqin->getUrl('list_hot'), 'text');
showsetting('&#20250;&#21592;&#21015;&#34920;', 'PluginLink',$fn_xiangqin->getUrl('list_vip'), 'text');
showsetting('&#23454;&#21517;&#21015;&#34920;', 'PluginLink',$fn_xiangqin->getUrl('list_cert'), 'text');
showsetting('&#21040;&#24215;&#21015;&#34920;', 'PluginLink',$fn_xiangqin->getUrl('list_offline'), 'text');
showsetting('&#33073;&#21333;&#21015;&#34920;', 'PluginLink',$fn_xiangqin->getUrl('list_far_single'), 'text');
showsetting('&#29301;&#32447;&#21015;&#34920;', 'PluginLink',$fn_xiangqin->getUrl('list_pull'), 'text');
showsetting('&#32418;&#23064;&#21015;&#34920;', 'PluginLink',$fn_xiangqin->getUrl('mat'), 'text');
showsetting('&#27963;&#21160;&#21015;&#34920;', 'PluginLink',$fn_xiangqin->getUrl('activity',array('form'=>'list')), 'text');
showsetting('&#20250;&#21592;&#22871;&#39184;&#36141;&#20080;', 'PluginLink',$fn_xiangqin->getUrl('payment'), 'text');
showsetting('&#20250;&#21592;&#20013;&#24515;', 'PluginLink',$fn_xiangqin->getUrl('user'), 'text');
showsetting('&#28155;&#21152;&#47;&#32534;&#36753;&#36164;&#26009;', 'PluginLink',$fn_xiangqin->getUrl('user',array('form'=>'info')), 'text');
showsetting('&#23454;&#21517;&#35748;&#35777;', 'PluginLink',$fn_xiangqin->getUrl('user',array('form'=>'cert')), 'text');
showsetting('&#23398;&#21382;&#35748;&#35777;', 'PluginLink',$fn_xiangqin->getUrl('user',array('form'=>'certedu')), 'text');
showsetting('&#36710;&#35748;&#35777;', 'PluginLink',$fn_xiangqin->getUrl('user',array('form'=>'certcar')), 'text');
showsetting('&#25151;&#35748;&#35777;', 'PluginLink',$fn_xiangqin->getUrl('user',array('form'=>'certhouse')), 'text');
showtagfooter('div');
showtagfooter('div');
showtagfooter('div');

?>