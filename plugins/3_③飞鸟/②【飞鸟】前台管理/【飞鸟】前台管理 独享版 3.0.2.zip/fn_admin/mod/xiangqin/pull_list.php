<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('xiang_all') && !$Fn_Admin->CheckUserGroup('xiangqin_pull_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$SubModel = in_array($_GET['submodel'], array('list','add')) ? $_GET['submodel'] : 'list';
$Fn_Admin->Config['IframeSubModelUrl'] = $Fn_Admin->Config['IframeItemUrl'].'&submodel='.$SubModel;
$NavClass = array($SubModel=>'btn-info Hover');

//����
echo <<<Nav
<div class="SubModelNav">
  <ul>
	<li class="{$NavClass['list']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=list" target="_self">{$Fn_Admin->Config['LangVar']['XiangqinLeftNavArray'][$_GET['item']]}</a></li>
    <li class="{$NavClass['add']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=add" target="_self">{$Fn_Admin->Config['LangVar']['AddEditTitle']}</a></li>
  </ul>
  <div class="both"></div>
</div>
Nav;

if($SubModel == 'list'){//�б�
	$Do = in_array($_GET['do'], array('Del','Display','PaymentState')) ? $_GET['do'] : 'submodel_list';
	//�����ֶ�
	$SearField =array('page','keyword','state');
	foreach($SearField as $Val) {
		$SearArray[$Val] = $_GET[$Val] || in_array($_GET[$Val],array('0')) ? $_GET[$Val] : '';
	}
	//�����ֶ� End
	$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeSubModelUrl'].'&'.http_build_query($SearArray);


	if($Do == 'submodel_list'){
		if(!submitcheck('Submit')) {
			$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
			$Where = '';
			$Order = in_array($_GET['order'], array('id')) ? 'P.'.addslashes(dhtmlspecialchars($_GET['order'])) : 'P.id';
			
			if(!$Fn_Admin->CheckUserGroup('xiang_all')){
				$Where .= ' and P.mid = '.intval($_G['uid']);
			}

			if($_GET['keyword']){
				$_GET['keyword'] = str_replace(array('%','_'),array('',''),$_GET['keyword']);
				$Where .= ' and (P.pair_username like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or P.username like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\')  or P.uid = '.intval($_GET['keyword']).' or P.pair_uid = '.intval($_GET['keyword']).' )';
			}

			if($_GET['state']){
				$Where .= ' and P.state = '.intval($_GET['state']);
			}

			$Where = preg_replace('/and/','where',$Where,1);
			$Limit = 20;
			$Page = $_GET['page']?intval($_GET['page']):1;
			/* ��ѯ���� End */
			

			/* ģ����� */	
			showtagheader('div', 'row', true,'row');
			showtagheader('div', 'col-12', true,'col-12');
			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-body', true,'box-body');
			/* ���� */
			$StateSelected = array($_GET['state']=>' selected');
	
			echo <<<SEARCH
			<form method="post" autocomplete="off" action="$SearUrl">
				<div class="FormSearchTo" style="margin-bottom:0;">
					<table cellspacing="4" cellpadding="4">
						<tr>
							<th>{$Fn_XiangQin->Config['LangVar']['KeywordTitle']}</th><td><input type="text" class="form-control w200" name="keyword" value="{$_GET['keyword']}">
							</td>
							<th>{$Fn_XiangQin->Config['LangVar']['StateTitle']}</th><td>
							<select name="state" class="form-control w120">
								<option value="">{$Fn_XiangQin->Config['LangVar']['SelectNull']}</option>
								<option value="1"{$StateSelected['1']}>{$Fn_XiangQin->Config['LangVar']['PullStateArray'][1]}</option>
								<option value="2"{$StateSelected['2']}>{$Fn_XiangQin->Config['LangVar']['PullStateArray'][2]}</option>
								<option value="3"{$StateSelected['3']}>{$Fn_XiangQin->Config['LangVar']['PullStateArray'][3]}</option>
								<option value="4"{$StateSelected['4']}>{$Fn_XiangQin->Config['LangVar']['PullStateArray'][4]}</option>
							</select>
							&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Admin->Config['LangVar']['SearchSubmit']}" class="btn btn-info" type="submit">
							</td>
						</tr>
					</table>
				</div>
			</form>
SEARCH;
			/* ���� End */
			showtagheader('div', 'table-responsive', true,'table-responsive');
			showformheader($FormUrl,'enctype="multipart/form-data"');
			showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
			showsubtitle(array(
				'ID',
				'UID/'.$Fn_XiangQin->Config['LangVar']['UserNameTitle'],
				$Fn_XiangQin->Config['LangVar']['NameTitle'],
				$Fn_XiangQin->Config['LangVar']['SexTitle'],
				$Fn_XiangQin->Config['LangVar']['MobileTitle'],
				$Fn_XiangQin->Config['LangVar']['MatchObject'],
				$Fn_XiangQin->Config['LangVar']['PullState'],
				$Fn_XiangQin->Config['LangVar']['RemarksTitle'],
				$Fn_XiangQin->Config['LangVar']['PullDataLine'],
				$Fn_XiangQin->Config['LangVar']['TimeTitle'],
				$Fn_XiangQin->Config['LangVar']['OperationTitle']
			),'header tbm tc');

			$ModulesList = GetModulesList($Page,$Limit,$Where,$Order);
			foreach ($ModulesList as $Module) {
				$UserInfo = $Fn_XiangQin->GetUserInfo($Module['uid']);
				$PairUserInfo = $Fn_XiangQin->GetUserInfo($Module['pair_uid']);
				$PairHtml = 'UID:'.$PairUserInfo['uid'].'<br>'.$Fn_XiangQin->Config['LangVar']['UserNameTitle'].':'.$PairUserInfo['username'].'<br>'.$Fn_XiangQin->Config['LangVar']['NameTitle'].':'.$PairUserInfo['name'];
				showtablerow('', array('class="tc w50"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
					'<input type="checkbox" class="filled-in" id="checkbox_'.$Module['id'].'" name="delete[]" value="'.$Module['id'].'"><label for="checkbox_'.$Module['id'].'">'.$Module['id'].'</label>',
					$Module['uid'].'/'.$Module['username'],
					$UserInfo['name'],
					$Fn_XiangQin->Config['LangVar']['SexArray'][$UserInfo['sex']],
					$UserInfo['mobile'],
					$PairHtml,
					$Fn_XiangQin->Config['LangVar']['PullStateArray'][$Module['state']],
					$Module['remarks'],
					$Module['pull_dateline'] ? date('Y-m-d H:i',$Module['pull_dateline']) : '',
					date('Y-m-d H:i',$Module['dateline']),
					'<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&pid='.$Module['id'].'" class="btn btn-sm btn-info-outline">'.$Fn_XiangQin->Config['LangVar']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Del&pid='.$Module['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$Fn_XiangQin->Config['LangVar']['DelTitle'].'</a>',
				));
			}
			showsubmit('Submit','&#31435;&#21363;&#25552;&#20132;','del','<span style=color:#999>'.$Fn_XiangQin->Config['LangVar']['DelAgenUserListTips'].'</span>','',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));
			showtablefooter(); /*dism��taobao��com*/
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			/* ģ�����End */	
		}else{
			if(!$Fn_Admin->CheckUserGroup('xiang_all') && !$Fn_Admin->CheckUserGroup('xiangqin_pull_list_del')){//Ȩ���ж�
				fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
				exit();
			}

			if(isset($_GET['delete']) && is_array($_GET['delete'])){
				foreach($_GET['delete'] as $Key => $Val) {
					$Val = intval($Val);
					DB::delete($Fn_XiangQin->TablePull,'id ='.$Val);
					
				}
				GetInsertDoLog('del_pull_xiangqin','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete'])));//������¼

				fn_cpmsg($Fn_XiangQin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
			}else{
				fn_cpmsg($Fn_XiangQin->Config['LangVar']['DelErr'],'','error');
			}
				
		}
	}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['pid']){
		if(!$Fn_Admin->CheckUserGroup('xiang_all') && !$Fn_Admin->CheckUserGroup('xiangqin_pull_list_del')){//Ȩ���ж�
			fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
			exit();
		}
		$Pid = intval($_GET['pid']);
		DB::delete($Fn_XiangQin->TablePull,'id ='.$Pid);
		GetInsertDoLog('del_pull_xiangqin','fn_'.$_GET['mod'],array('id'=>$Pid));//������¼
		fn_cpmsg($Fn_Admin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
	}
}else if($SubModel == 'add'){//���ӻ�༭

	$Pid = intval($_GET['pid']);

	$Item = DB::fetch_first('SELECT * FROM '.DB::table($Fn_XiangQin->TablePull).' where id = '.$Pid);

	if(!submitcheck('DetailSubmit')) {
		$OpTitle = $Fn_XiangQin->Config['LangVar']['AddTitle'];
		if($Item){
			$OpTitle = $Fn_XiangQin->Config['LangVar']['EditTitle'];
		}
		
		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-header', true,'with-border box-header');
		showtitle($OpTitle,'class="box-title"');
		showtagfooter('div');
		showformheader($Fn_Admin->Config['IframeSubModelUrl'].'&pid='.$Pid,'enctype');
		showtagheader('div', 'box-body', true,'box-body');

		showsetting('uid', 'uid', $Item['uid'], 'text');
		showsetting($Fn_XiangQin->Config['LangVar']['MatchObject'].'UID', 'pair_uid', $Item['pair_uid'], 'text');
		
		showsetting($Fn_XiangQin->Config['LangVar']['PullState'],array('state',DyadicArray($Fn_XiangQin->Config['LangVar']['PullStateArray'])),$Item['state'] ? $Item['state'] : 1,'mradio');

		showsetting($Fn_XiangQin->Config['LangVar']['RemarksTitle'], 'remarks', $Item['remarks'], 'textarea');

		showsetting($Fn_XiangQin->Config['LangVar']['PullDataLine'], 'pull_dateline',$Item['pull_dateline'] ? date('Y-m-d H:i',$Item['pull_dateline']) : '', 'calendar','','','',1);
				
		if($Item['dateline']){
			showsetting($Fn_XiangQin->Config['LangVar']['TimeTitle'], 'dateline',date('Y-m-d H:i',$Item['dateline']), 'calendar','','','',1);
		}
		
		showsubmit('DetailSubmit','&#20445;&#23384;&#37197;&#32622;');
		showtagfooter('div');
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');

	}else{
	
		$Data['uid'] = intval($_GET['uid']);
		$Data['pair_uid'] = intval($_GET['pair_uid']);

		$Matchmaker = DB::fetch_first('SELECT * FROM '.DB::table($Fn_XiangQin->TableMatchmaker).' where uid = '.intval($_G['uid']));
		$Data['mid'] = $Matchmaker ? intval($_G['uid']) : '';

		$Member = DB::fetch_first('SELECT username FROM '.DB::table('common_member').' where uid = '.$Data['uid']);
		$Data['username'] = addslashes(strip_tags($Member['username']));

		$PairMember = DB::fetch_first('SELECT username FROM '.DB::table('common_member').' where uid = '.$Data['pair_uid']);
		$Data['pair_username'] = addslashes(strip_tags($PairMember['username']));

		$Data['remarks'] = addslashes(strip_tags($_GET['remarks']));
		$Data['state'] = intval($_GET['state']);

		$Data['pull_dateline'] = $_GET['pull_dateline'] ? strtotime($_GET['pull_dateline']) : '';

		if($Item){
			$Data['dateline'] = strtotime($_GET['dateline']);
			GetInsertDoLog('edit_pull_xiangqin','fn_'.$_GET['mod'],array('id'=>$Pid));//������¼
			DB::update($Fn_XiangQin->TablePull,$Data,'id = '.$Pid);
		}else{
			$Data['dateline'] = time();
			$Id = DB::insert($Fn_XiangQin->TablePull,$Data,true);
			GetInsertDoLog('add_pull_xiangqin','fn_'.$_GET['mod'],array('id'=>$Id));//������¼
		}
		fn_cpmsg($Fn_XiangQin->Config['LangVar']['UpdateOk'],$Fn_Admin->Config['IframeItemUrl'].'&submodel=list','succeed');
	}
}


/* �б� */
function GetModulesList($Page,$Limit,$Where=null,$Order){
	global $Fn_XiangQin;
	$FetchSql = 'SELECT P.* FROM '.DB::table($Fn_XiangQin->TablePull).' P '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}

/* ���� */
function GetModulesCount($Where=null){
	global $Fn_XiangQin;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_XiangQin->TablePull).' P '.$Where;
	return DB::result_first($FetchSql);//��������
}

?>