<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('xiang_all') && !$Fn_Admin->CheckUserGroup('xiangqin_vip_user_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$Do = in_array($_GET['do'], array('Del','Display','Condition','Home','Seal','LeadLine','Remarks','ExportText')) ? $_GET['do'] : 'List';

//�����ֶ�
$SearField =array('page','keyword','sex','home','mobile_display','display','examine','seal','order','lead_line_state','source','mid','claim','marriage');
foreach($SearField as $Val) {
	$SearArray[$Val] = $_GET[$Val] || in_array($_GET[$Val],array('0')) ? $_GET[$Val] : '';
}
//�����ֶ� End

$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeItemUrl'].'&'.http_build_query($SearArray);

if($Do == 'List'){
	if(!submitcheck('Submit')) {
		$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
		/* ��ѯ���� */
		$Where = ' and vip_time >= '.time();
		$Order = in_array($_GET['order'], array('id','top_dateline','click','vip_time')) ? 'M.'.addslashes(dhtmlspecialchars($_GET['order'])) : 'M.id';
		
		if(!$Fn_Admin->CheckUserGroup('xiang_all')){
			$Where .= ' and M.mid = '.intval($_G['uid']);

		}else if($Fn_Admin->CheckUserGroup('xiang_all') && $_GET['mid'] ){
			$Where .= ' and M.mid = '.intval($_GET['mid']);
		}

		if(in_array($_GET['claim'],array('0'))){
			$Where .= ' and M.mid = \'\'';
		}else if(in_array($_GET['claim'],array('1'))){
			$Where .= ' and M.mid != \'\'';
		}

		if($_GET['keyword']){
			$_GET['keyword'] = str_replace(array('%','_'),array('',''),$_GET['keyword']);
			$Where .= ' and (M.username like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or M.name like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or M.param like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or M.uid = '.intval($_GET['keyword']).' or M.mobile = \''.addslashes(strip_tags($_GET['keyword'])).'\' )';
		}
		if(in_array($_GET['sex'],array('1','2'))){
			$Where .= ' and M.sex = '.intval($_GET['sex']);
		}
		if(in_array($_GET['display'],array('0','1'))){
			$Where .= ' and M.display = '.intval($_GET['display']);
		}
		if(in_array($_GET['seal'],array('0','1'))){
			$Where .= ' and M.seal = '.intval($_GET['seal']);
		}
		if(in_array($_GET['mobile_display'],array('0','1'))){
			$Where .= ' and M.mobile_display = '.intval($_GET['mobile_display']);
		}
		if(in_array($_GET['home'],array('0','1'))){
			$Where .= ' and M.home = '.intval($_GET['home']);
		}
		if(in_array($_GET['lead_line_state'],array('0','1'))){
			$Where .= ' and M.lead_line_state = '.intval($_GET['lead_line_state']);
		}

		if($_GET['marriage']){
			$Where .= ' and M.marriage = '.intval($_GET['marriage']);
		}

		if(in_array($_GET['source'],array('1','2'))){
			$Where .= ' and M.source = '.intval($_GET['source']);
		}
		
		$Where = preg_replace('/and/','where',$Where,1);
		$Limit = 20;
		$Page = $_GET['page']?intval($_GET['page']):1;
		/* ��ѯ���� End */
		/* ģ����� */	
		showtagheader('div', 'row', true,'row');
		showtagheader('div', 'col-12', true,'col-12');
		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-body', true,'box-body');
		/* ���� */
		$SexSelected = array($_GET['sex']=>' selected');
		$MobileDisplaySelected = array($_GET['mobile_display']=>' selected');
		$DisplaySelected = array($_GET['display']=>' selected');
		$ExamineSelected = array($_GET['examine']=>' selected');
		$SealSelected = array($_GET['seal']=>' selected');
		$HomeSelected = array($_GET['home']=>' selected');
		$LeadLineStateSelected = array($_GET['lead_line_state']=>' selected');
		$MarriageSelected = array($_GET['marriage']=>' selected');

		$SourceSelected = array($_GET['source']=>' selected');
		$MidSelected = array($_GET['mid']=>' selected');
		$ClaimSelected = array($_GET['claim']=>' selected');
		$OrderSelected = array($_GET['order']=>' selected');
		
		if(!$Fn_Admin->CheckUserGroup('xiang_all')){
			$CountWhere .= ' and M.mid = '.intval($_G['uid']);
		}

		$Fn_XiangQin->Config['LangVar']['VipUserListCount'] = str_replace(array('{Count}','{Sex1}','{Sex2}'),array(GetModulesCount(' where M.vip_time >= '.time().$CountWhere),GetModulesCount(' where M.vip_time >= '.time().' and M.sex = 1'.$CountWhere),GetModulesCount(' where M.vip_time >= '.time().' and M.sex = 2'.$CountWhere)),$Fn_XiangQin->Config['LangVar']['VipUserListCount']);

		if($Fn_Admin->CheckUserGroup('xiang_all')){
			foreach($Fn_XiangQin->GetMatchmakerList() as $Val) {
				$OpTionHtml .= '<option value="'.$Val['uid'].'"'.$MidSelected[$Val['uid']].'>'.$Val['name'].'</option>';
			}
			$MatchmakerHtml = '&nbsp;&nbsp;<span>'.$Fn_XiangQin->Config['LangVar']['MatchmakerTitle'].'</span>&nbsp;<select name="mid" class="form-control w120" style="display:inline-block"><option value="">'.$Fn_XiangQin->Config['LangVar']['SelectNull'].'</option>'.$OpTionHtml.'</select>';

			$MatchmakerHtml .= '&nbsp;&nbsp;<span>'.$Fn_XiangQin->Config['LangVar']['MatchmakerClaim'].'</span>&nbsp;<select name="claim" class="form-control w120" style="display:inline-block"><option value="">'.$Fn_XiangQin->Config['LangVar']['SelectNull'].'</option><option value="0"'.$ClaimSelected[0].'>'.$Fn_XiangQin->Config['LangVar']['MatchmakerClaimArray'][0].'</option><option value="1"'.$ClaimSelected[1].'>'.$Fn_XiangQin->Config['LangVar']['MatchmakerClaimArray'][1].'</option></select>';
		}

		echo <<<SEARCH
		<form method="post" autocomplete="off" action="$SearUrl">
			<div class="FormSearch">
				<table cellspacing="4" cellpadding="4">
					<tr>
						<th>{$Fn_XiangQin->Config['LangVar']['KeywordTitle']}</th><td><input type="text" class="form-control w200" name="keyword" value="{$_GET['keyword']}">
						</td>
						<th>{$Fn_XiangQin->Config['LangVar']['SexTitle']}</th><td>
						<select name="sex" class="form-control w120">
							<option value="">{$Fn_XiangQin->Config['LangVar']['SelectNull']}</option>
							<option value="1"{$SexSelected['1']}>{$Fn_XiangQin->Config['LangVar']['SexArray']['1']}</option>
							<option value="2"{$SexSelected['2']}>{$Fn_XiangQin->Config['LangVar']['SexArray']['2']}</option>
						</select>
						</td>
						<th>{$Fn_XiangQin->Config['LangVar']['MobileDisplayTitle']}</th><td>
						<select name="mobile_display" class="form-control w120">
							<option value="">{$Fn_XiangQin->Config['LangVar']['SelectNull']}</option>
							<option value="1"{$MobileDisplaySelected['1']}>{$Fn_XiangQin->Config['LangVar']['Yes']}</option>
							<option value="0"{$MobileDisplaySelected['0']}>{$Fn_XiangQin->Config['LangVar']['No']}</option>
						</select>
						</td>
						<th>{$Fn_XiangQin->Config['LangVar']['DisplayTitle']}</th><td>
						<select name="display" class="form-control w120">
							<option value="">{$Fn_XiangQin->Config['LangVar']['SelectNull']}</option>
							<option value="1"{$DisplaySelected['1']}>{$Fn_XiangQin->Config['LangVar']['Yes']}</option>
							<option value="0"{$DisplaySelected['0']}>{$Fn_XiangQin->Config['LangVar']['No']}</option>
						</select>
						</td>
						<th>{$Fn_XiangQin->Config['LangVar']['SealTitle']}</th><td>
						<select name="seal" class="form-control w120">
							<option value="">{$Fn_XiangQin->Config['LangVar']['SelectNull']}</option>
							<option value="1"{$SealSelected['1']}>{$Fn_XiangQin->Config['LangVar']['Yes']}</option>
							<option value="0"{$SealSelected['0']}>{$Fn_XiangQin->Config['LangVar']['No']}</option>
						</select>
						</td>
						<th>{$Fn_XiangQin->Config['LangVar']['HomeTitle']}</th><td>
						<select name="home" class="form-control w120">
							<option value="">{$Fn_XiangQin->Config['LangVar']['SelectNull']}</option>
							<option value="1"{$HomeSelected['1']}>{$Fn_XiangQin->Config['LangVar']['Yes']}</option>
							<option value="0"{$HomeSelected['0']}>{$Fn_XiangQin->Config['LangVar']['No']}</option>
						</select>
						</td>
						<th>{$Fn_XiangQin->Config['LangVar']['LeadLineState']}</th><td>
						<select name="lead_line_state" class="form-control w120">
							<option value="">{$Fn_XiangQin->Config['LangVar']['SelectNull']}</option>
							<option value="0"{$LeadLineStateSelected['0']}>{$Fn_XiangQin->Config['LangVar']['LeadLineStateArray'][0]}</option>
							<option value="1"{$LeadLineStateSelected['1']}>{$Fn_XiangQin->Config['LangVar']['LeadLineStateArray'][1]}</option>
						</select>
						</td>
						<th>{$Fn_XiangQin->Config['LangVar']['MarriageTitle']}</th><td>
						<select name="marriage" class="form-control w120">
							<option value="">{$Fn_XiangQin->Config['LangVar']['SelectNull']}</option>
							<option value="1"{$MarriageSelected['1']}>{$Fn_XiangQin->Config['LangVar']['MarriageArray'][1]}</option>
							<option value="2"{$MarriageSelected['2']}>{$Fn_XiangQin->Config['LangVar']['MarriageArray'][2]}</option>
							<option value="3"{$MarriageSelected['3']}>{$Fn_XiangQin->Config['LangVar']['MarriageArray'][3]}</option>
						</select>
						</td>
					</tr>
					<tr>
						<td colspan="20">
							{$Fn_XiangQin->Config['LangVar']['Source']}
							<select name="source" class="form-control w120" style="display:inline-block">
							<option value="">{$Fn_XiangQin->Config['LangVar']['SelectNull']}</option>
							<option value="1"{$SourceSelected['1']}>{$Fn_XiangQin->Config['LangVar']['MemberSourceArray'][1]}</option>
							<option value="2"{$SourceSelected['2']}>{$Fn_XiangQin->Config['LangVar']['MemberSourceArray'][2]}</option>
							</select>
							{$MatchmakerHtml}
							&nbsp;&nbsp;
							{$Fn_XiangQin->Config['LangVar']['SortTitle']}
							<select name="order" class="form-control w120" style="display:inline-block">
							<option value="id"{$OrderSelected['id']}>id</option>
							<option value="click"{$OrderSelected['click']}>{$Fn_XiangQin->Config['LangVar']['Click']}</option>
							<option value="top_dateline"{$OrderSelected['top_dateline']}>{$Fn_XiangQin->Config['LangVar']['TopDateline']}</option>
							<option value="vip_time"{$OrderSelected['vip_time']}>VIP{$Fn_XiangQin->Config['LangVar']['UserVipTime']}</option>
							</select>&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Admin->Config['LangVar']['SearchSubmit']}" class="btn btn-info" type="submit">&nbsp;&nbsp;{$Fn_XiangQin->Config['LangVar']['VipUserListCount']}
						</td>
					</tr>
				</table>
			</div>
		</form>
SEARCH;
		/* ���� End */	
		showtagheader('div', 'table-responsive', true,'table-responsive');
		showformheader($FormUrl,'enctype="multipart/form-data"');
		showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
		showsubtitle(array(
			'ID',
			'Uid/'.$Fn_XiangQin->Config['LangVar']['UserNameTitle'],
			$Fn_XiangQin->Config['LangVar']['NameTitle'],
			$Fn_XiangQin->Config['LangVar']['SexTitle'],
			$Fn_XiangQin->Config['LangVar']['ContactTitle'].'/'.$Fn_XiangQin->Config['LangVar']['WxTitle'],
			$Fn_XiangQin->Config['LangVar']['MobileDisplayTitle'],
			$Fn_XiangQin->Config['LangVar']['ExamineState'],
			$Fn_XiangQin->Config['LangVar']['DisplayTitle'],
			$Fn_XiangQin->Config['LangVar']['SealTitle'],
			$Fn_XiangQin->Config['LangVar']['HomeTitle'],
			'VIP'.$Fn_XiangQin->Config['LangVar']['UserVipTime'],
			$Fn_XiangQin->Config['LangVar']['TopDateline'],
			$Fn_XiangQin->Config['LangVar']['ExpireDisplayDate'],
			$Fn_XiangQin->Config['LangVar']['LeadLine'],
			$Fn_XiangQin->Config['LangVar']['LeadLineState'],
			$Fn_XiangQin->Config['LangVar']['SeeLine'],
			$Fn_XiangQin->Config['LangVar']['MatchmakerTitle'],
			$Fn_XiangQin->Config['LangVar']['MatchmakerClaim'],
			$Fn_XiangQin->Config['LangVar']['Source'],
			$Fn_XiangQin->Config['LangVar']['RemarksTitle'],
			$Fn_XiangQin->Config['LangVar']['TimeTitle'].'/'.$Fn_XiangQin->Config['LangVar']['UpdateTime'],
			$Fn_XiangQin->Config['LangVar']['OperationTitle']
		),'header tbm tc');
		
		$ModulesList = GetModulesList($Page,$Limit,$Where,$Order);
		
		foreach ($ModulesList as $Module) {
			$Uids[] = $Module['uid'];
			$Module['param'] = unserialize($Module['param']);
			$LeadLineHtml = $Module['lead_line'] && $Module['vip_time'] > time() ? '&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=LeadLine&uid='.$Module['uid'].'&formhash='.FORMHASH.'">'.$Fn_XiangQin->Config['LangVar']['ReduceLeadLine'].'</a>' : '';
			showtablerow('', array('class="tc w100"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
				'<input type="checkbox" class="filled-in" id="checkbox_'.$Module['uid'].'" name="delete[]" value="'.$Module['uid'].'"><label for="checkbox_'.$Module['uid'].'"></label>',
				$Module['uid'] ? $Module['uid'].'<br>'.cutstr($Module['username'],6) : '',
				$Module['face'] ? '<div class="UserLoadFace"><img src="'.$Module['face'].'" height="30"><div class="BigFace" style="background:url('.$Module['face'].') no-repeat center;background-size:cover;"></div></div>'.cutstr($Module['name'],8) : cutstr($Module['name'],8),
				$Fn_XiangQin->Config['LangVar']['SexArray'][$Module['sex']],
				$Module['mobile'].'<br>'.$Module['param']['wx'],
				!$Module['mobile_display'] ? $Fn_XiangQin->Config['LangVar']['No'] : $Fn_XiangQin->Config['LangVar']['Yes'],
				in_array($Module['examine'],array(2,3)) ? '<span class="red">'.$Fn_XiangQin->Config['LangVar']['ExamineArray'][$Module['examine']].'</span>' : $Fn_XiangQin->Config['LangVar']['ExamineArray'][$Module['examine']],
				!$Module['display'] ? '<span class="red">'.$Fn_XiangQin->Config['LangVar']['No'].'</span>' : $Fn_XiangQin->Config['LangVar']['Yes'],
				$Module['seal'] ? '<span class="red">'.$Fn_XiangQin->Config['LangVar']['Yes'].'</span>' : $Fn_XiangQin->Config['LangVar']['No'],
				$Module['home'] ? '<span class="red">'.$Fn_XiangQin->Config['LangVar']['Yes'].'</span>' : $Fn_XiangQin->Config['LangVar']['No'],
				$Module['vip_time'] && $Module['vip_time'] > time() ? date('Y-m-d',$Module['vip_time']).' '.$Module['param']['vip_title'] : '',
				$Module['top_dateline'] && $Module['top_dateline'] > time() ? date('Y-m-d',$Module['top_dateline']) : '',
				$Module['display_dateline'] && $Module['display_dateline'] > time() ? date('Y-m-d',$Module['display_dateline']) : '',
				$Module['vip_time'] && $Module['vip_time'] > time() ? $Module['lead_line'] : 0,
				$Fn_XiangQin->Config['LangVar']['LeadLineStateArray'][$Module['lead_line_state']],
				$Module['vip_time'] && $Module['vip_time'] > time() ? $Module['see_line'] : 0,
				$Module['m_name'],
				$Module['mid'] ? $Fn_XiangQin->Config['LangVar']['MatchmakerClaimArray'][1] : '<span class="red">'.$Fn_XiangQin->Config['LangVar']['MatchmakerClaimArray'][0].'</span>',
				$Fn_XiangQin->Config['LangVar']['MemberSourceArray'][$Module['source']],
				'<a href="'.$OpCpUrl.'&do=Remarks&uid='.$Module['uid'].'">'.cutstr($Module['param']['remarks'],10).'</a>',
				date('Y-m-d H:i',$Module['dateline']).'<br>'.date('Y-m-d H:i',$Module['updateline']),
				'<a href="'.$Fn_XiangQin->Config['HeUserUrl'].$Module['uid'].'" target="_blank">'.cplang('view').'</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['ModUrl'].'&item=user&do=Edit&uid='.$Module['uid'].'&iframe=true">'.$Fn_XiangQin->Config['LangVar']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Display&uid='.$Module['uid'].'&value='.(!empty($Module['display']) ? 0:1).'&formhash='.FORMHASH.'">'.(!empty($Module['display']) ? $Fn_XiangQin->Config['LangVar']['DisplayNoTitle'] : $Fn_XiangQin->Config['LangVar']['DisplayIsTitle']).'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Seal&uid='.$Module['uid'].'&value='.(!empty($Module['seal']) ? 0:1).'&formhash='.FORMHASH.'">'.(!empty($Module['seal']) ? $Fn_XiangQin->Config['LangVar']['SealNo'] : $Fn_XiangQin->Config['LangVar']['SealYes']).'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Remarks&uid='.$Module['uid'].'">'.$Fn_XiangQin->Config['LangVar']['RemarksTitle'].'</a><br><a href="'.$OpCpUrl.'&do=Home&uid='.$Module['uid'].'&value='.(!empty($Module['home']) ? 0:1).'&formhash='.FORMHASH.'">'.(!empty($Module['home']) ? $Fn_XiangQin->Config['LangVar']['NoHomeTitle'] : $Fn_XiangQin->Config['LangVar']['HomeTitle']).'</a>'.$LeadLineHtml.'&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['ModUrl'].'&item=matching_list&uid='.$Module['uid'].'&iframe=true">'.$Fn_XiangQin->Config['LangVar']['MatchingTitle'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Del&uid='.$Module['uid'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;">'.$Fn_XiangQin->Config['LangVar']['DelTitle'].'</a>',
			));
		}
		/* �ܾ�����Html */
		$RefusalHtml = '<select name="refusal" class="form-control w120"><option value="">'.$Fn_XiangQin->Config['LangVar']['SelectNull'].'</option>';
		foreach ($Fn_XiangQin->ExamineTwoList as $Val) {
			$RefusalHtml .= '<option value="'.$Val.'">'.$Val.'</option>';
		}
		$RefusalHtml .= '</select>';
		/* �ܾ�����Html End*/
		/* ǣ��״̬Html */
		$LeadLineStateHtml = '<select name="lead_line_state_new" class="form-control w120"><option value="">'.$Fn_XiangQin->Config['LangVar']['SelectNull'].'</option>';
		foreach ($Fn_XiangQin->Config['LangVar']['LeadLineStateArray'] as $Key=>$Val) {
			$LeadLineStateHtml .= '<option value="'.$Key.'">'.$Val.'</option>';
		}
		$LeadLineStateHtml .= '</select>';
		/* ǣ��״̬Html End*/

		if($Fn_Admin->CheckUserGroup('xiang_all')){//�ƶ��û���ĳ��������
			$MoveMatchmakerHtml = '&nbsp;&nbsp;<input name="optype" value="MoveMatchmaker" class="with-gap" type="radio" id="v_UserMoveMatchmaker"><label class="custom-control-label" for="v_UserMoveMatchmaker" style="margin-left:-5px;">'.$Fn_XiangQin->Config['LangVar']['UserMoveMatchmaker'].'</label>&nbsp;&nbsp;<select name="new_mid" class="form-control w120"><option value="">'.$Fn_XiangQin->Config['LangVar']['SelectNull'].'</option>';
			foreach ($Fn_XiangQin->GetMatchmakerList() as $Key=>$Val) {
				$MoveMatchmakerHtml .= '<option value="'.$Val['uid'].'">'.$Val['name'].'</option>';
			}
			$MoveMatchmakerHtml .= '</select>';
		}

		showsubmit('Submit','&#31435;&#21363;&#25552;&#20132;','<input name="optype" value="Del" class="with-gap" type="radio" id="v_Del"><label class="custom-control-label" for="v_Del" style="margin-left:-5px;">'.$Fn_XiangQin->Config['LangVar']['DelTitle'].'</label>&nbsp;&nbsp;<input name="optype" value="Display" class="with-gap" type="radio" id="v_Display"><label class="custom-control-label" for="v_Display" style="margin-left:-5px;">'.$Fn_XiangQin->Config['LangVar']['DisplayTitle'].'</label>&nbsp;<select name="displaynew" class="form-control w120"><option value="">'.$Fn_XiangQin->Config['LangVar']['SelectNull'].'</option><option value="1">'.$Fn_XiangQin->Config['LangVar']['Yes'].'</option><option value="0">'.$Fn_XiangQin->Config['LangVar']['No'].'</option></select>&nbsp;&nbsp;<input name="optype" value="LeadLineState" class="with-gap" type="radio" id="v_LeadLineState"><label class="custom-control-label" for="v_LeadLineState" style="margin-left:-5px;">'.$Fn_XiangQin->Config['LangVar']['LeadLineState'].'</label>&nbsp;'.$LeadLineStateHtml.$MoveMatchmakerHtml,'','select_all','');

		showsubmit('','','<a href="'.$Fn_Admin->Config['Url'].'&mod=export_txt&type='.$_GET['mod'].'&uids='.implode(',',$Uids).'&formhash='.FORMHASH.'">'.$Fn_Admin->Config['LangVar']['ExportText'].'</a>','','',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));

		showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		echo '<style>#Module .td25{width:auto;}.UserLoadFace{position:relative;cursor:pointer;}.UserLoadFace .BigFace{position:absolute;right:-300px;top:-200px;width:300px;height:400px;z-index:5;display:none;}</style>
		<script>
		$(".UserLoadFace").hover(function(){
			$(this).find(".BigFace").show();
		},
		
		function(){
			$(this).find(".BigFace").hide();
		});
		</script>';

		/* ģ����� End */
	}else{
		if(isset($_GET['delete']) && is_array($_GET['delete'])){
			if($_GET['optype'] == 'Del'){//ȫɾ
				if(!$Fn_Admin->CheckUserGroup('xiang_all') && !$Fn_Admin->CheckUserGroup('xiangqin_del_user')){//Ȩ���ж�
					fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
					exit();
				}
				foreach($_GET['delete'] as $Key => $Val) {
					$Val = intval($Val);
					DB::delete($Fn_XiangQin->TableMember,'uid ='.$Val);
					DB::delete($Fn_XiangQin->TableCondition,'uid ='.$Val);
					DB::delete($Fn_XiangQin->TableCollect,'uid ='.$Val);
					DB::delete($Fn_XiangQin->TableCollect,'collect_uid ='.$Val);
					DB::delete($Fn_XiangQin->TableAuthentication,'uid ='.$Val);
				}

				GetInsertDoLog('del_user_xiangqin','fn_'.$_GET['mod'],array('uids'=>implode(',',$_GET['delete'])));//������¼

				fn_cpmsg($Fn_XiangQin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
			}else if($_GET['optype'] == 'Display' && in_array($_GET['displaynew'],array('0','1'))){
				foreach($_GET['delete'] as $Key => $Val) {
					$Val = intval($Val);
					DB::update($Fn_XiangQin->TableMember,array('display'=>intval($_GET['displaynew'])),'uid = '.$Val);
				}
				
				GetInsertDoLog('display_user_xiangqin','fn_'.$_GET['mod'],array('uids'=>implode(',',$_GET['delete']),'display'=>$_GET['displaynew']));//������¼

				fn_cpmsg($Fn_XiangQin->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
			}else if($_GET['optype'] == 'LeadLineState' && in_array($_GET['lead_line_state_new'],array('0','1'))){
				foreach($_GET['delete'] as $Key => $Val) {
					$Val = intval($Val);
					DB::update($Fn_XiangQin->TableMember,array('lead_line_state'=>intval($_GET['lead_line_state_new'])),'uid = '.$Val);
				}

				GetInsertDoLog('lead_line_state_xiangqin','fn_'.$_GET['mod'],array('uids'=>implode(',',$_GET['delete']),'lead_line_state'=>$_GET['lead_line_state_new']));//������¼
				
				fn_cpmsg($Fn_XiangQin->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
			}else if($_GET['optype'] == 'MoveMatchmaker' && $_GET['new_mid']){//�ƶ�����
				foreach($_GET['delete'] as $Key => $Val) {
					DB::update($Fn_XiangQin->TableMember,array('mid'=>intval($_GET['new_mid'])),'uid = '.$Val);
					DB::update($Fn_XiangQin->TableReport,array('mid'=>intval($_GET['new_mid'])),'uid = '.$Val);
				}
				
				GetInsertDoLog('user_move_matchmaker_xiangqin','fn_'.$_GET['mod'],array('uids'=>implode(',',$_GET['delete']),'mid'=>$_GET['new_mid']));//������¼

				fn_cpmsg($Fn_XiangQin->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
			}else{
				fn_cpmsg($Fn_XiangQin->Config['LangVar']['OpErr'],'','error');
			}
		}else{
			fn_cpmsg($Fn_XiangQin->Config['LangVar']['OpErr'],'','error');
		}
	}
}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['uid']){//ɾ��
	if(!$Fn_Admin->CheckUserGroup('xiang_all') && !$Fn_Admin->CheckUserGroup('xiangqin_del_user')){//Ȩ���ж�
		fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
		exit();
	}
	$Uid = intval($_GET['uid']);
	DB::delete($Fn_XiangQin->TableMember,'uid ='.$Uid);
	DB::delete($Fn_XiangQin->TableCondition,'uid ='.$Uid);
	DB::delete($Fn_XiangQin->TableCollect,'uid ='.$Uid);
	DB::delete($Fn_XiangQin->TableCollect,'collect_uid ='.$Uid);
	DB::delete($Fn_XiangQin->TableAuthentication,'uid ='.$Uid);
	
	GetInsertDoLog('del_user_xiangqin','fn_'.$_GET['mod'],array('uid'=>$_GET['uid']));//������¼

	fn_cpmsg($Fn_Admin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
}else if($Do == 'Display' && $_GET['formhash'] == formhash() && $_GET['uid']){//�Ƿ���ʾ
	$Uid = intval($_GET['uid']);
	$Value = intval($_GET['value']);
	$Fn_Admin->EditFields($Fn_XiangQin->TableMember,array('uid'=>$Uid),'display',$Value);
	
	GetInsertDoLog('display_user_xiangqin','fn_'.$_GET['mod'],array('uid'=>$_GET['uid'],'display'=>$_GET['value']));//������¼

	fn_cpmsg($Fn_Admin->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
}else if($Do == 'Seal' && $_GET['formhash'] == formhash() && $_GET['uid']){//���
	$Uid = intval($_GET['uid']);
	$Value = intval($_GET['value']);
	$Fn_Admin->EditFields($Fn_XiangQin->TableMember,array('uid'=>$Uid),'seal',$Value);
	$Fn_XiangQin->GetSealPush($Uid,$Value);
	
	GetInsertDoLog('seal_user_xiangqin','fn_'.$_GET['mod'],array('uid'=>$_GET['uid'],'seal'=>$_GET['value']));//������¼

	fn_cpmsg($Fn_Admin->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
}else if($Do == 'Home' && $_GET['formhash'] == formhash() && $_GET['uid']){//�Ƽ���ҳ
	$Uid = intval($_GET['uid']);
	$Value = intval($_GET['value']);
	$Fn_Admin->EditFields($Fn_XiangQin->TableMember,array('uid'=>$Uid),'home',$Value);

	GetInsertDoLog('home_user_xiangqin','fn_'.$_GET['mod'],array('uid'=>$_GET['uid'],'home'=>$_GET['value']));//������¼

	fn_cpmsg($Fn_Admin->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
}else if($Do == 'LeadLine' && $_GET['formhash'] == formhash() && $_GET['uid']){//����ǣ�ߴ���
	$Uid = intval($_GET['uid']);
	DB::query("UPDATE ".DB::table($Fn_XiangQin->TableMember)." SET lead_line = lead_line-1 WHERE uid=".$Uid);
	
	GetInsertDoLog('lead_line_user_xiangqin','fn_'.$_GET['mod'],array('uid'=>$_GET['uid']));//������¼

	fn_cpmsg($Fn_Admin->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
}else if($Do == 'Remarks' && $_GET['uid']){//��ע
	$UserInfo = $Fn_XiangQin->GetUserInfo($_GET['uid']);
	if(!submitcheck('DetailSubmit')) {

		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-header', true,'with-border box-header');
		showtitle($Fn_XiangQin->Config['LangVar']['RemarksTitle'],'class="box-title"');
		showtagfooter('div');
		showformheader($FormUrl.'&do=Remarks&uid='.$_GET['uid'],'enctype');
		showtagheader('div', 'box-body', true,'box-body');

		showsetting($Fn_XiangQin->Config['LangVar']['RemarksTitle'], 'remarks', $UserInfo['param']['remarks'], 'textarea');
		showsubmit('DetailSubmit','&#20445;&#23384;&#37197;&#32622;');

		showtagfooter('div');
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');
	}else{
		$Param['remarks'] =  addslashes(strip_tags($_GET['remarks']));
		$Data['param'] = serialize($Param);
		DB::update($Fn_XiangQin->TableMember,$Data,'uid = '.intval($_GET['uid']));
		fn_cpmsg($Fn_XiangQin->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
	}
}

/* �б� */
function GetModulesList($Page,$Limit,$Where=null,$Order){
	global $Fn_XiangQin;
	$FetchSql = 'SELECT MM.name as m_name,M.* FROM '.DB::table($Fn_XiangQin->TableMember).' M LEFT JOIN `'.DB::table($Fn_XiangQin->TableMatchmaker).'` MM on MM.uid = M.mid  '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}
/* ���� */
function GetModulesCount($Where=null){
	global $Fn_XiangQin;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_XiangQin->TableMember).' M '.$Where;
	return DB::result_first($FetchSql);//��������
}
//From: Dism_taobao_com
?>