<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('xiangqin_all') && !$Fn_Admin->CheckUserGroup('xiangqin_gift_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeItemUrl'];

if(!submitcheck('Submit')){

	showtagheader('div', 'row', true,'row');
	showtagheader('div', 'col-12', true,'col-12');
	showtagheader('div', 'box', true,'box');
	showtagheader('div', 'box-body', true,'box-body');
		
	showtagheader('div', 'table-responsive', true,'table-responsive');
	showformheader($FormUrl,'enctype="multipart/form-data"');
	showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
	showsubtitle(array(
		'ID', 
		'display_order',
		'&#26631;&#39064;',
		'&#37329;&#24065;',
		'&#31036;&#29289;&#22270;&#26631;&#40;&#24314;&#35758;&#50;&#49;&#48;&#42;&#49;&#51;&#50;&#41;'
	));

	$res = C::t('#fn_xiangqin#fn_love_gift')->fetch_all_by_list(array(),'displayorder',$page - 1,20,true,'','');

	foreach($res['list'] as $item) {
	
		showtablerow('', array('class="tc w50"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
			'<input type="checkbox" class="filled-in" id="checkbox_'.$item['id'].'" name="delete[]" value="'.$item['id'].'"><label for="checkbox_'.$item['id'].'">'.$item['id'].'</label>',
			'<input type="text" class="input form-control w50" name="displayorder['.$item['id'].']" value="'.$item['displayorder'].'" />',
			'<input type="text" class="input form-control w150" name="title['.$item['id'].']" value="'.$item['title'].'" />',
			'<input type="text" class="input form-control w150" name="money['.$item['id'].']" value="'.$item['money'].'" />',
			'<a href="'.$item['icon'].'" target="_blank"><img src="'.$item['icon'].'" style="height:30px;margin:0 5px 0 0;"></a><input type="hidden" size="30" name="icon['.$item['id'].']" value="'.$item['icon'].'" /> <input name="file_icon['.$item['id'].']" value="" class="txt uploadbtn" type="file" style="width:200px;">',
			//'<label class="radio"><input class="check" name="display['.$item['id'].']" type="radio" value="1" '.($Module['display'] ? 'checked="checked"' : '').'/><span class="ic"></span>'.$Fn_Live->Config['LangVar']['DisplayIsTitle'].'</label>&nbsp;&nbsp;<label class="radio"><input class="check" name="display['.$Module['id'].']" type="radio" value="0" '.( !$Module['display'] ? 'checked="checked"' : '').'/><span class="ic"></span>'.$Fn_Live->Config['LangVar']['DisplayNoTitle'].'</label>'
		));
	}
	
	showtablerow('', array('class="tc w50"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
		cplang('add_new'),
		sprintf('<input type="text" class="input form-control w50" maxlength="4" name="new_displayorder" value="" />'),
		sprintf('<input type="text" class="input form-control w150" name="new_title" value="" />'),
		sprintf('<input type="text" class="input form-control w150" name="new_money" value="" />'),
		sprintf('<input name="new_icon" value="" class="txt uploadbtn" type="file" style="width:266px;">'),
		//sprintf('<label class="radio"><input class="check" name="new_display" type="radio" value="1" checked="checked"/><span class="ic"></span>'.$Fn_Live->Config['LangVar']['DisplayIsTitle'].'</label>&nbsp;&nbsp;<label class="radio"><input class="check" name="new_display" type="radio" value="0" /><span class="ic"></span>'.$Fn_Live->Config['LangVar']['DisplayNoTitle'].'</label>')
	));
	showsubmit('Submit', '&#31435;&#21363;&#25552;&#20132;', 'del');
    showtablefooter(); /*dism��taobao��com*/
	showformfooter(); /*Dism_taobao-com*/
	showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
}else{
	//ɾ��ѡ��
    if(isset($_POST['delete']) && is_array($_POST['delete'])) {
		foreach($_POST['delete'] as $id){
			$id = intval($id);
			C::t('#fn_xiangqin#fn_love_gift')->delete_by_id($id);
		}
	}
	// ����
    if(isset($_POST['displayorder']) && is_array($_POST['displayorder'])) {
		foreach ($_POST['displayorder'] as $id => $Displayorder) {
			$upIns = array();
			$id = intval($id);
			$upIns['title'] =  addslashes(strip_tags($_POST['title'][$id]));
			$upIns['money'] =  addslashes(strip_tags($_POST['money'][$id]));
			$upIns['displayorder'] =  intval($Displayorder);
			
			if(!empty($_FILES['file_icon']['size'][$id])) {
				$icon = array(
					'name' => $_FILES['file_icon']['name'][$id],
					'type' => $_FILES['file_icon']['type'][$id],
					'tmp_name' => $_FILES['file_icon']['tmp_name'][$id],
					'error' => $_FILES['file_icon']['error'][$id],
					'size' => $_FILES['file_icon']['size'][$id]
				);
				$IcoFile = Fn_Upload($icon,$_POST['icon'][$id]);
				$upIns['icon'] = $IcoFile['Path'];
			}else{
				$upIns['icon'] = addslashes(strip_tags($_POST['icon'][$id]));
			}
			C::t('#fn_xiangqin#fn_love_gift')->update($upIns,$id);
		}
    }
	//���ӷ���
    if ($_POST['new_title']) {
		$insert = array();
		$insert['title'] = addslashes(strip_tags($_POST['new_title']));
		$insert['money'] = addslashes(strip_tags($_POST['new_money']));
		$insert['displayorder'] = intval($_POST['new_displayorder']);
		//$insert['display'] = intval($_POST['new_display']);
		if($_FILES['new_icon']['size']){
			$IcoFile = Fn_Upload($_FILES['new_icon']);
			$insert['icon'] = $IcoFile['Path'];
		}
		C::t('#fn_xiangqin#fn_love_gift')->insert($insert);
    }
	$fn_xiangqin->getCheckGift();
	fn_cpmsg($fn_xiangqin->setting['lang']['UpdateOk'],$CpMsgUrl,'succeed');
}
//From: Dism_taobao_com
?>