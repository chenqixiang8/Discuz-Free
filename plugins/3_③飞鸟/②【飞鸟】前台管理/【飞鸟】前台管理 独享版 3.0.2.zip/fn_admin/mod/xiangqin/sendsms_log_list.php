<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('xiang_all') && !$Fn_Admin->CheckUserGroup('xiangqin_user_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$Do = in_array($_GET['do'], array('AllDel')) ? $_GET['do'] : 'List';

//�����ֶ�
$SearField =array('page','keyword','start_time','end_time','state','order');
foreach($SearField as $Val) {
	$SearArray[$Val] = $_GET[$Val] ? $_GET[$Val] : '';
}
//�����ֶ� End

$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeItemUrl'].'&'.http_build_query($SearArray);


if($Do == 'List'){
	if(!submitcheck('Submit')) {
		$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
		/* ��ѯ���� */
		$Where = '';
		$Order = in_array($_GET['order'], array('id')) ? 'L.'.addslashes(dhtmlspecialchars($_GET['order'])) : 'L.id';
		if($_GET['keyword']){
			$Where .= ' and concat(L.username,L.uid,L.mobile) like(\'%'.addslashes(dhtmlspecialchars(str_replace(array('%','_'),array('',''),$_GET['keyword']))).'%\')';
		}

		if(in_array($_GET['state'],array('200','201'))){
			$Where .= ' and L.state = '.intval($_GET['state']);
		}

		$Where = preg_replace('/and/','where',$Where,1);
		$Limit = 20;
		$Page = $_GET['page']?intval($_GET['page']):1;
		/* ��ѯ���� End */
		/* ���� */
		$StateSelected = array($_GET['state']=>' selected');

		echo <<<SEARCH
		<form method="post" autocomplete="off" action="$SearUrl" id="tb_search">
			<div class="FormSearchTo">
				<table cellspacing="4" cellpadding="4">
					<tr>
						<th>{$Fn_XiangQin->Config['LangVar']['KeywordTitle']}</th><td><input type="text" class="input w150" name="keyword" value="{$_GET['keyword']}">
						</td>
						<th>{$Fn_XiangQin->Config['LangVar']['StateTitle']}</th><td>
						<div class="select">
						<select name="state">
							<option value="">{$Fn_XiangQin->Config['LangVar']['SelectNull']}</option>
							<option value="200"{$StateSelected['200']}>{$Fn_XiangQin->Config['LangVar']['SendSmsState']['200']}</option>
							<option value="201"{$StateSelected['201']}>{$Fn_XiangQin->Config['LangVar']['SendSmsState']['201']}</option>
						</select></div>
						&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_XiangQin->Config['LangVar']['SearchSubmit']}" class="button" type="submit">
						</td>
					</tr>
				</table>
			</div>
		</form>
SEARCH;
		/* ���� End */

		/* ģ����� */		
		showtagheader('div', 'Module', true);
		showformheader($FormUrl,'enctype="multipart/form-data"');
		showtableheader('','listtable');
		showsubtitle(array(
			'ID',
			'Uid/'.$Fn_XiangQin->Config['LangVar']['UserNameTitle'],
			$Fn_XiangQin->Config['LangVar']['MobileTitle'],
			$Fn_XiangQin->Config['LangVar']['ApiType'],
			$Fn_Admin->Config['LangVar']['Content'],
			$Fn_XiangQin->Config['LangVar']['StateTitle'],
			$Fn_XiangQin->Config['LangVar']['TimeTitle'],
		), 'header tbm');
		
		$ModulesList = GetModulesList($Page,$Limit,$Where,$Order);
		
		foreach ($ModulesList as $Module) {
			showtablerow('', array('class="tc w100"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
				'<label class="checkbox"><input type="checkbox" class="check" name="delete[]" value="'.$Module['id'].'" /><span class="ic"></span>'.$Module['id'].'</label>',
				$Module['uid'] ? $Module['uid'].'/'.$Module['username'] : '',
				$Module['mobile'],
				$Fn_XiangQin->Config['LangVar']['ApiTypeArray'][$Module['type']],
				$Module['content'],
				$Module['state'] == 200 ? $Fn_XiangQin->Config['LangVar']['SendSmsState'][$Module['state']] : $Fn_XiangQin->Config['LangVar']['SendSmsState'][$Module['state']].': '.$Module['msg'],
				date('Y-m-d H:i',$Module['dateline'])
			));
		}
		showsubmit('Submit','submit','del','','',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));
        showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');
		/* ģ����� End */
	}else{
		if(isset($_GET['delete']) && is_array($_GET['delete'])){
			foreach($_GET['delete'] as $Key => $Val) {
				$Val = intval($Val);
				DB::delete($Fn_XiangQin->TableSendSmsLog,'id ='.$Val);
			}

			GetInsertDoLog('del_send_sms_log','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete'])));//������¼

			fn_cpmsg($Fn_XiangQin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
		}else{
			fn_cpmsg($Fn_XiangQin->Config['LangVar']['DelErr'],'','error');
		}
	}
}

/* �б� */
function GetModulesList($Page,$Limit,$Where=null,$Order){
	global $Fn_XiangQin;
	$FetchSql = 'SELECT L.* FROM '.DB::table($Fn_XiangQin->TableSendSmsLog).' L '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}

/* ���� */
function GetModulesCount($Where=null){
	global $Fn_XiangQin;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_XiangQin->TableSendSmsLog).' L '.$Where;
	return DB::result_first($FetchSql);//��������
}
//From: Dism_taobao_com
?>