<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('xiangqin_all') && !$Fn_Admin->CheckUserGroup('xiangqin_user_contact_log_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$Do = in_array($_GET['do'], array('Del')) ? $_GET['do'] : 'List';

//�����ֶ�
$SearField =array('page','keyword','vid','love_vid','order');
foreach($SearField as $Val) {
	$SearArray[$Val] = $_GET[$Val] ? $_GET[$Val] : '';
}
//�����ֶ� End

$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeItemUrl'].'&'.http_build_query($SearArray);

if($Do == 'List'){
	if(!submitcheck('Submit')) {
		$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
		$page = $_GET['page'] ? $_GET['page'] : 0;
		$res = C::t('#fn_xiangqin#fn_love_user_contact_log')->fetch_all_by_list(array('vid'=>$_GET['vid'],'love_vid'=>$_GET['love_vid']),'dateline',$page - 1,30,true);
		/* ģ����� */
		showtagheader('div', 'row', true,'row');
		showtagheader('div', 'col-12', true,'col-12');
		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-body', true,'box-body');
		/* ���� */
		
		echo <<<SEARCH
		<form method="post" autocomplete="off" action="$SearUrl" id="tb_search">
			<div class="FormSearchTo">
				<table cellspacing="4" cellpadding="4">
					<tr>
						<th>&#29992;&#25143;&#73;&#68;</th>
						<td colspan="10"><input type="text" class="input form-control w200" name="vid" value="{$_GET['vid']}" placeholder="&#35831;&#36755;&#20837;&#29992;&#25143;&#73;&#68;">
						</td>
						<th>&#34987;&#26597;&#30475;&#29992;&#25143;&#73;&#68;</th>
						<td><input type="text" class="input form-control w200" name="love_vid" value="{$_GET['love_vid']}" placeholder="&#35831;&#36755;&#20837;&#34987;&#26597;&#30475;&#29992;&#25143;&#73;&#68;">
							&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Admin->Config['LangVar']['SearchSubmit']}" class="btn btn-info" type="submit">
						</td>
						
					</tr>
				</table>
			</div>
		</form>
SEARCH;
		/* ���� End */
		showtagheader('div', 'table-responsive', true,'table-responsive');
		showformheader($FormUrl,'enctype="multipart/form-data"');
		showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
		showsubtitle(array(
			'ID',
			'&#26597;&#30475;&#20154;',
			'&#26597;&#30475;&#20154;&#22836;&#20687;',
			'&#34987;&#26597;&#30475;&#20154;',
			'&#34987;&#26597;&#30475;&#20154;&#22836;&#20687;',
			$fn_xiangqin->setting['lang']['TimeTitle'],
			$fn_xiangqin->setting['lang']['OperationTitle']
		), 'header tbm tc');
	
		foreach ($res['list'] as $item) {
			$userInfo = $fn_xiangqin->getView($item['vid']);
			$CoverUserInfo = $fn_xiangqin->getView($item['love_vid']);
			showtablerow('', array('class="tc w100"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
				'<input type="checkbox" class="filled-in" id="checkbox_'.$item['id'].'" name="delete[]" value="'.$item['id'].'"><label for="checkbox_'.$item['id'].'">'.$item['id'].'</label>',
				'<a href="'.$userInfo['url'].'" target="_blank">&#32534;&#21495;&#65306;'.$userInfo['id'].'</a><br>&#22995;&#21517;&#65306;'.$userInfo['name'].'-'.$userInfo['sex_text'].'-'.$userInfo['age'].'<br>&#25163;&#26426;&#21495;&#65306;'.$userInfo['phone'],
				($userInfo['head_portrait'] ? '<a href="'.$userInfo['head_portrait'].'" target="_blank"><img src="'.$userInfo['head_portrait'].'" height="60"></a>' : ''),
				'<a href="'.$CoverUserInfo['url'].'" target="_blank">&#32534;&#21495;&#65306;'.$CoverUserInfo['id'].'</a><br>&#22995;&#21517;&#65306;'.$CoverUserInfo['name'].'-'.$CoverUserInfo['sex_text'].'-'.$CoverUserInfo['age'].'<br>&#25163;&#26426;&#21495;&#65306;'.$CoverUserInfo['phone'],
				($CoverUserInfo['head_portrait'] ? '<a href="'.$CoverUserInfo['head_portrait'].'" target="_blank"><img src="'.$CoverUserInfo['head_portrait'].'" height="60"></a>' : ''),
				date('Y-m-d H:i',$item['dateline']),
				'<a href="'.$OpCpUrl.'&do=Del&aid='.$item['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$fn_xiangqin->setting['lang']['DelTitle'].'</a>',
			));
		}
		showsubmit('Submit','&#31435;&#21363;&#25552;&#20132;','del','','',multi($res['count'],30,$page,$MpUrl));
		showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		/* ģ����� End */
	}else{
		if(isset($_GET['delete']) && is_array($_GET['delete'])){
			if(!$Fn_Admin->CheckUserGroup('xiangqin_all') && !$Fn_Admin->CheckUserGroup('xiangqin_del_user_contact_log')){//Ȩ���ж�
				fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
				exit();
			}
			foreach($_GET['delete'] as $val) {
				$id = intval($val);
				C::t('#fn_xiangqin#fn_love_user_contact_log')->delete_by_id($id);
			}
			GetInsertDoLog('del_user_contact_log_xiangqin','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete'])));//������¼
			fn_cpmsg($fn_xiangqin->setting['lang']['DelOk'],$CpMsgUrl,'succeed');
		}else{
			fn_cpmsg($fn_xiangqin->setting['lang']['DelErr'],'','error');
		}
	}
}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['aid']){//ɾ��
	if(!$Fn_Admin->CheckUserGroup('xiangqin_all') && !$Fn_Admin->CheckUserGroup('xiangqin_del_user_contact_log')){//Ȩ���ж�
		fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
		exit();
	}
	$id = intval($_GET['aid']);
	C::t('#fn_xiangqin#fn_love_user_contact_log')->delete_by_id($id);
	GetInsertDoLog('del_user_contact_log_xiangqin','fn_'.$_GET['mod'],array('id'=>$id));//������¼
	fn_cpmsg($fn_xiangqin->setting['lang']['DelOk'],$CpMsgUrl,'succeed');
}
//From: Dism_taobao_com
?>