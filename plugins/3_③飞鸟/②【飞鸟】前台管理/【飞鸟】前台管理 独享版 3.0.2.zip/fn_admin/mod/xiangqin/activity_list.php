<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('xiangqin_all') && !$Fn_Admin->CheckUserGroup('xiangqin_activity_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$SubModel = in_array($_GET['submodel'], array('list','signup_list','add')) ? $_GET['submodel'] : 'list';
$Fn_Admin->Config['IframeSubModelUrl'] = $Fn_Admin->Config['IframeItemUrl'].'&submodel='.$SubModel;
$NavClass = array($SubModel=>'btn-info Hover');

//����
echo <<<Nav
<div class="SubModelNav">
  <ul>
	<li class="{$NavClass['list']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=list" target="_self">{$Fn_Admin->Config['LangVar']['XiangqinLeftNavArray'][$_GET['item']]}</a></li>
	<li class="{$NavClass['signup_list']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=signup_list" target="_self">&#25253;&#21517;&#31649;&#29702;</a></li>
    <li class="{$NavClass['add']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=add" target="_self">{$Fn_Admin->Config['LangVar']['AddEditTitle']}</a></li>
  </ul>
  <div class="both"></div>
</div>
Nav;

if($SubModel == 'list'){//�б�
	$Do = in_array($_GET['do'], array('Del')) ? $_GET['do'] : 'submodel_list';
	$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeSubModelUrl'].'&'.http_build_query($SearArray);
	if($Do == 'submodel_list'){
		if(!submitcheck('Submit')) {
			$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
			$page = $_GET['page'] ? $_GET['page'] : 0;
			$res = C::t('#fn_xiangqin#fn_love_activity')->fetch_all_by_list(array('id'=>$_GET['aid']),'dateline',$page - 1,30,true);
			/* ��ѯ���� End */

			/* ģ����� */	
			showtagheader('div', 'row', true,'row');
			showtagheader('div', 'col-12', true,'col-12');
			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-body', true,'box-body');
			showtagheader('div', 'table-responsive', true,'table-responsive');
			showformheader($FormUrl,'enctype="multipart/form-data"');
			showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
			showsubtitle(array(
				'ID',
				'&#26631;&#39064;',
				'&#25253;&#21517;&#32467;&#26463;&#26102;&#38388;',
				'&#27963;&#21160;&#32467;&#26463;&#26102;&#38388;',
				$fn_xiangqin->setting['lang']['DisplayTitle'],
				$fn_xiangqin->setting['lang']['TimeTitle'].'/'.$fn_xiangqin->setting['lang']['UpdateTime'],
				$fn_xiangqin->setting['lang']['OperationTitle']
			),'header tbm tc');

			foreach ($res['list'] as $item) {
				showtablerow('', array('class="tc w50"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
					$item['id'],
					$item['title'],
					date('Y-m-d H:i',$item['signup_end_dateline']),
					date('Y-m-d H:i',$item['end_dateline']),
					!$item['display'] ? '<span class="label bg-secondary">'.$fn_xiangqin->setting['lang']['No'].'</span>' : '<span class="label bg-blue">'.$fn_xiangqin->setting['lang']['Yes'].'</span>',
					date('Y-m-d H:i',$item['dateline']).'<br>'.date('Y-m-d H:i',$item['updateline']),
					'<a href="'.$fn_xiangqin->getUrl('activity',array('form'=>'view','aid'=>$item['id'])).'" target="_blank" class="btn btn-sm btn-dark-outline">'.cplang('view').'</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&aid='.$item['id'].'" class="btn btn-sm btn-dark-outline">'.$fn_xiangqin->setting['lang']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=signup_list&aid='.$item['id'].'" class="btn btn-sm btn-dark-outline">&#25253;&#21517;&#31649;&#29702;</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Del&aid='.$item['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$fn_xiangqin->setting['lang']['DelTitle'].'</a>',
				));
			}
			showsubmit('','','','','',multi($res['count'],30,$page,$MpUrl));
			showtablefooter(); /*dism��taobao��com*/
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			/* ģ�����End */	
		}
	}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['aid']){
		if(!$Fn_Admin->CheckUserGroup('xiangqin_all') && !$Fn_Admin->CheckUserGroup('xiangqin_del_activity')){//Ȩ���ж�
			fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
			exit();
		}
		$id = intval($_GET['aid']);
		C::t('#fn_xiangqin#fn_love_activity')->delete_by_id($id);
		fn_cpmsg($fn_xiangqin->setting['lang']['DelOk'],$CpMsgUrl,'succeed');
		exit();
	}
}else if($SubModel == 'signup_list'){
	$Do = in_array($_GET['do'], array('Del')) ? $_GET['do'] : 'submodel_list';
	//�����ֶ�
	$SearField =array('page','keyword','audit_state','uid','order','aid','vid','uid','sex');
	foreach($SearField as $Val) {
		$SearArray[$Val] = $_GET[$Val] || in_array($_GET[$Val],array('0')) ? $_GET[$Val] : '';
	}
	//�����ֶ� End
	$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeSubModelUrl'].'&'.http_build_query($SearArray);
	if($Do == 'submodel_list'){
		if(!submitcheck('Submit')) {
			$SearUrl = $Fn_Admin->Config['IframeSubModelUrl'];
			$page = $_GET['page'] ? $_GET['page'] : 0;
			$res = C::t('#fn_xiangqin#fn_love_activity_signup')->fetch_all_by_list(array('aid'=>$_GET['aid'],'audit_state'=>$_GET['audit_state'],'uid'=>$_GET['uid'],'vid'=>$_GET['vid'],'sex'=>$_GET['sex']),'dateline',$page - 1,30,true);
			/* ��ѯ���� End */

			/* ģ����� */	
			showtagheader('div', 'row', true,'row');
			showtagheader('div', 'col-12', true,'col-12');
			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-body', true,'box-body');
			/* ���� */
			$sex_list_option = '<option value="">'.$fn_xiangqin->setting['lang']['SelectNull'].'</option>';
			foreach($fn_xiangqin->setting['lang']['sex_arr'] as $key => $val) {
				$sex_list_option .= '<option value="'. $key.'" '.($_GET['sex'] ==  $key ? ' selected' : '' ).'>'.$val.'</option>';
			}
			echo <<<SEARCH
			<form method="post" autocomplete="off" action="$SearUrl" id="tb_search">
				<div class="FormSearchTo">
					<table cellspacing="4" cellpadding="4">
						<tr>
							<th>&#27963;&#21160;&#73;&#68;</th>
							<td colspan="10"><input type="text" class="input form-control w150" name="aid" value="{$_GET['aid']}" placeholder="&#35831;&#36755;&#20837;&#27963;&#21160;&#73;&#68;">
							</td>
							<th>&#29992;&#25143;&#73;&#68;</th>
							<td colspan="10"><input type="text" class="input form-control w150" name="vid" value="{$_GET['vid']}" placeholder="&#35831;&#36755;&#20837;&#29992;&#25143;&#73;&#68;">
							</td>
							<th>{$fn_xiangqin->setting['lang']['sex']}</th><td>
							<select name="sex" class="form-control w120">
								{$sex_list_option}
							</select>
							&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Admin->Config['LangVar']['SearchSubmit']}" class="btn btn-info" type="submit">
							</td>
							
						</tr>
					</table>
				</div>
			</form>
SEARCH;
		/* ���� End */
			showtagheader('div', 'table-responsive', true,'table-responsive');
			showformheader($FormUrl,'enctype="multipart/form-data"');
			showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
			showsubtitle(array(
				'ID',
				'&#29992;&#25143;&#32534;&#21495;',
				'&#29992;&#25143;&#22995;&#21517;',
				'&#29992;&#25143;&#30005;&#35805;',
				'&#29992;&#25143;&#24615;&#21035;',
				'&#29992;&#25143;&#22836;&#20687;',
				'&#25253;&#21517;&#26102;&#38388;',
				$fn_xiangqin->setting['lang']['OperationTitle']
			),'header tbm tc');

			foreach ($res['list'] as $item) {
				showtablerow('', array('class="tc w50"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
					$item['id'],
					$item['vid'],
					$item['name'],
					$item['phone'],
					$fn_xiangqin->setting['lang']['sex_arr'][$item['sex']],
					$item['head_portrait'] ? '<img src="'.$item['head_portrait'].'" height="30">' : '',
					date('Y-m-d H:i',$item['dateline']),
					'<a href="'.$OpCpUrl.'&do=Del&sid='.$item['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$fn_xiangqin->setting['lang']['DelTitle'].'</a>',
				));
			}
			showsubmit('','','','','',multi($res['count'],30,$page,$MpUrl));
			showtablefooter(); /*dism��taobao��com*/
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			/* ģ�����End */	
		}
	}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['sid']){
		if(!$Fn_Admin->CheckUserGroup('xiangqin_all') && !$Fn_Admin->CheckUserGroup('xiangqin_del_activity_signup')){//Ȩ���ж�
			fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
			exit();
		}
		$id = intval($_GET['sid']);
		C::t('#fn_xiangqin#fn_love_activity_signup')->delete_by_id($id);
		fn_cpmsg($fn_xiangqin->setting['lang']['DelOk'],$CpMsgUrl,'succeed');
		exit();
	}
}else if($SubModel == 'add'){//���ӻ�༭

	$id = intval($_GET['aid']);
	
	$item = C::t('#fn_xiangqin#fn_love_activity')->fetch_by_id($id);

	if(!submitcheck('DetailSubmit')) {
		$opTitle = $fn_xiangqin->setting['lang']['AddTitle'];
		if($item){
			$opTitle = $fn_xiangqin->setting['lang']['EditTitle'];
		}

		echo '<script src="'.$Config['StaticPath'].'/ueditor/'.CHARSET.'/ueditor.config.js" type="text/javascript"></script><script src="'.$Config['StaticPath'].'/ueditor/'.CHARSET.'/ueditor.all.js" type="text/javascript"></script>';
		
		//ͼƬ�ϴ�
		if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_assembly/class/class_upload.php')){
			@require_once libfile('class/upload','plugin/fn_assembly');
			$UploadConfig = fn_upload::Config();
		}

		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-header', true,'with-border box-header');
		showtitle($opTitle,'class="box-title"');
		showtagfooter('div');
		showformheader($Fn_Admin->Config['IframeSubModelUrl'].'&aid='.$id,'enctype');
		showtagheader('div', 'box-body', true,'box-body');

		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">&#32553;&#30053;&#22270;<br>&#24314;&#35758;&#65306;&#55;&#50;&#48;&#32;&#42;&#32;&#51;&#53;&#48;</label><div class="col-sm-9"><div class="AdminSingleUpload"><div class="PhotoControl" id="thumbnail"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';

		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">&#27178;&#24133;<br>&#24314;&#35758;&#65306;&#55;&#50;&#48;&#32;&#42;&#32;&#51;&#53;&#48;</label><div class="col-sm-9"><div class="AdminSingleUpload"><div class="PhotoControl" id="banner"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';

		showsetting('&#26631;&#39064;', 'title', $item['title'], 'text');

		showsetting('&#20215;&#26684;&#31867;&#22411;',array('price_type', array(
			array('1','&#20250;&#21592;&#20215;&#26684;', array('price_type_1' => '','price_type_2' => 'none')),
			array('2','&#30007;&#22899;&#20215;&#26684;', array('price_type_1' => 'none','price_type_2' => '')),
		), TRUE),$item['price_type'], 'mradio');

		showtagheader('div', 'price_type_1', $item['price_type'] == 1 || !$item ? true : '','sub');
			showsetting('&#20215;&#26684;', 'price', $item['price'], 'text');
			showsetting('&#20250;&#21592;&#20215;&#26684;', 'vip_price', $item['vip_price'], 'text');
		showtagfooter('div');

		showtagheader('div', 'price_type_2', $item['price_type'] == 2 ? true : '','sub');
			showsetting('&#30007;&#20215;&#26684;', 'price_1', $item['price_1'], 'text','','','&#48;&#47;&#31354;&#20195;&#34920;&#20813;&#36153;');
			showsetting('&#22899;&#20215;&#26684;', 'price_2', $item['price_2'], 'text','','','&#48;&#47;&#31354;&#20195;&#34920;&#20813;&#36153;');
		showtagfooter('div');

		showsetting('&#30007;&#25253;&#21517;&#25968;&#38480;&#21046;', 'male_number', $item['male_number'], 'text','','','&#48;&#47;&#31354;&#20195;&#34920;&#19981;&#38480;&#21046;');
		showsetting('&#22899;&#25253;&#21517;&#25968;&#38480;&#21046;', 'female_number', $item['female_number'], 'text','','','&#48;&#47;&#31354;&#20195;&#34920;&#19981;&#38480;&#21046;');
		showsetting('&#27963;&#21160;&#22320;&#22336;', 'address', $item['address'], 'text');
		showsetting('&#23454;&#21517;&#35748;&#35777;&#21487;&#21442;&#21152;', 'real_verify', $item['real_verify'], 'radio');
		showsetting('&#23457;&#26680;&#36890;&#36807;&#21487;&#21442;&#21152;', 'user_audit', $item['user_audit'], 'radio','','','&#36164;&#26009;&#26159;&#21542;&#23457;&#26680;&#36890;&#36807;&#25165;&#21487;&#21442;&#21152;&#27963;&#21160;');
		showsetting('&#20250;&#21592;&#20351;&#29992;&#27963;&#21160;&#27425;&#25968;', 'vip_act', $item['vip_act'], 'radio','','','&#20250;&#21592;&#26159;&#21542;&#21487;&#20197;&#20351;&#29992;&#27963;&#21160;&#27425;&#25968;');
		showsetting('&#25253;&#21517;&#32467;&#26463;&#26102;&#38388;', 'signup_end_dateline',$item['signup_end_dateline'] ? date('Y-m-d H:i',$item['signup_end_dateline']) : '', 'calendar','','','',1);
		showsetting('&#27963;&#21160;&#32467;&#26463;&#26102;&#38388;', 'end_dateline',$item['end_dateline'] ? date('Y-m-d H:i',$item['end_dateline']) : '', 'calendar','','','',1);
		
		//��������
		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">&#27963;&#21160;&#25551;&#36848;:</label><div class="col-sm-9"><textarea id="content" name="content" style="width:80%;height:350px;">'.stripslashes($item['content']).'</textarea></div></div>';

		showsetting('&#20998;&#20139;&#26631;&#39064;', 'share_title', $item['share_title'], 'text');
		showsetting('&#20998;&#20139;&#25551;&#36848;', 'share_desc', $item['share_desc'], 'text');
		$share_logo_html = ($item['share_logo'] ? '<a href="'.$item['share_logo'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$item['share_logo'].'" height="55"/></a>' : '').'&#24314;&#35758;&#65306;&#49;&#48;&#48;&#32;&#42;&#32;&#49;&#48;&#48;';
		showsetting('&#20998;&#20139;&#22270;&#26631;', 'new_share_logo',$item['share_logo'], 'filetext', '', 0, $share_logo_html);

		showsetting($fn_xiangqin->setting['lang']['DisplayTitle'], 'display', $item ? $item['display'] : 1, 'radio');
		if($item){
			showsetting($fn_xiangqin->setting['lang']['RefreshTime'], 'updateline',$item['updateline'] ? date('Y-m-d H:i',$item['updateline']) : '', 'calendar','','','',1);
		}

		if($item){
			showsetting($fn_xiangqin->setting['lang']['TimeTitle'], 'dateline',date('Y-m-d H:i',$item['dateline']), 'calendar','','','',1);
		}
		showsubmit('DetailSubmit','&#20445;&#23384;&#37197;&#32622;');
		showtagfooter('div');
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');

		$UpLoadHtml  = '';
		if($item['thumbnail']){
			$thumbnailJsArray[] = '"'.$item['thumbnail'].'"';;
			$UpLoadHtml .= '
			var InputArray = new Array('.implode(',',$thumbnailJsArray).');
			$("#thumbnail").AppUpload({InputName:"new_thumbnail",Multiple:true,InputExist:true,InputArray:InputArray});';
		}else{
			$UpLoadHtml .= '$("#thumbnail").AppUpload({InputName:"new_thumbnail",Multiple:true});';
		}

		if($item['banner']){
			foreach(array_filter(explode(",",$item['banner'])) as $Key => $Val) {
				$bannerJsArray[] = '"'.$Val.'"';
			}
			$UpLoadHtml .= '
			var InputArray = new Array('.implode(',',$bannerJsArray).');
			$("#banner").AppUpload({InputName:"new_banner",InputExist:true,InputArray:InputArray});';

		}else{
			$UpLoadHtml .= '$("#banner").AppUpload({InputName:"new_banner"});';
		}

		echo $UploadConfig['CssJsHtml'];
		echo '
			<script>
			var ue = UE.getEditor("content",{autoHeightEnabled: false,autoFloatEnabled:false,enableAutoSave: false});
			'.$UpLoadHtml.'
			</script> 	
		';
	}else{
		foreach($_GET['new_thumbnail'] as $Key => $Val) {
			$_GET['new_thumbnail'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}

		foreach($_GET['new_banner'] as $Key => $Val) {
			$_GET['new_banner'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}

		$data['thumbnail'] = addslashes(strip_tags($_GET['new_thumbnail'][0]));
		$data['banner'] = is_array($_GET['new_banner']) && isset($_GET['new_banner']) ? implode(',',$_GET['new_banner']) : '';
		$data['title'] = addslashes(strip_tags($_GET['title']));
		$data['price_type'] = intval($_GET['price_type']);
		$data['price'] = addslashes(strip_tags($_GET['price']));
		$data['price_1'] = addslashes(strip_tags($_GET['price_1']));
		$data['price_2'] = addslashes(strip_tags($_GET['price_2']));
		$data['vip_price'] = addslashes(strip_tags($_GET['vip_price']));
		$data['user_audit'] = intval($_GET['user_audit']);
		$data['real_verify'] = addslashes(strip_tags($_GET['real_verify']));
		$data['address'] = addslashes(strip_tags($_GET['address']));
		$data['share_title'] = addslashes(strip_tags($_GET['share_title']));
		$data['share_desc'] = addslashes(strip_tags($_GET['share_desc']));
		$data['content'] = addslashes($_GET['content']);
		$data['signup_start_dateline'] = $_GET['signup_start_dateline'] ? strtotime($_GET['signup_start_dateline']) : '';
		$data['signup_end_dateline'] = $_GET['signup_end_dateline'] ? strtotime($_GET['signup_end_dateline']) : '';
		$data['start_dateline'] = $_GET['start_dateline'] ? strtotime($_GET['start_dateline']) : '';
		$data['end_dateline'] = $_GET['end_dateline'] ? strtotime($_GET['end_dateline']) : '';
		$data['male_number'] = intval($_GET['male_number']);
		$data['female_number'] = intval($_GET['female_number']);
		$data['vip_act'] = intval($_GET['vip_act']);
		$data['display'] = intval($_GET['display']);
		$data = array_merge($data,$Fn_Admin->uploadFiles($_FILES));
		if($item){
			$data['dateline'] = strtotime($_GET['dateline']);
			$data['updateline'] = strtotime($_GET['updateline']);
			C::t('#fn_xiangqin#fn_love_activity')->update($data,$id);
		}else{
			$data['updateline'] = $data['dateline'] = time();
			$id = C::t('#fn_xiangqin#fn_love_activity')->insert($data);
		}
		fn_cpmsg($fn_xiangqin->setting['lang']['UpdateOk'],$Fn_Admin->Config['IframeItemUrl'].'&submodel=list','succeed');
		exit();
	}
}
//From: Dism_taobao_com
?>