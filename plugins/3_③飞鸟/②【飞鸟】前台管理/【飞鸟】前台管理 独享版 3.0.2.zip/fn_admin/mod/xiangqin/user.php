<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('xiang_all') && !$Fn_Admin->CheckUserGroup('xiangqin_user')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

//�����ֶ�
$SearField =array('uid');
foreach($SearField as $Val) {
	$SearArray[$Val] = $_GET[$Val] || in_array($_GET[$Val],array('0')) ? $_GET[$Val] : '';
}
//�����ֶ� End
$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeItemUrl'].'&'.http_build_query($SearArray);

$Uid = intval($_GET['uid']);
$UserInfo = $Uid ? $Fn_XiangQin->GetUserInfo($Uid) : array();
$Fn_XiangQin->Config['LangVar']['ShapeArray'] = $UserInfo['sex'] == 2 ? $Fn_XiangQin->Config['LangVar']['ShapeSex1Array'] : $Fn_XiangQin->Config['LangVar']['ShapeSex2Array'];//����
if(!submitcheck('DetailSubmit')) {
	$OpTitle = $Fn_XiangQin->Config['LangVar']['AddTitle'];
	if($UserInfo) {
		$OpTitle = $Fn_XiangQin->Config['LangVar']['EditTitle'];
	}

	//ͼƬ�ϴ�
	if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_assembly/class/class_upload.php')){
		@require_once libfile('class/upload','plugin/fn_assembly');
		$UploadConfig = fn_upload::Config();
	}
	
	showtagheader('div', 'box', true,'box');
	showformheader($FormUrl,'enctype');
	echo <<<HTML
		<ul class="nav nav-tabs customtab" role="tablist">
          <li class="nav-item"> <a class="nav-link active" data-toggle="tab" href="#basics" role="tab" aria-expanded="true"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#22522;&#26412;&#36164;&#26009;</span></a> </li>
		  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#single" role="tab" aria-expanded="false"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#25321;&#20598;&#26465;&#20214;</span></a> </li>
		  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#other" role="tab" aria-expanded="false"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#20854;&#20182;&#35774;&#32622;</span></a> </li>
        </ul>
HTML;
	showtagheader('div', 'box-body', true,'box-body');
	showtagheader('div', 'tab-content', true,'tab-content');
	
	echo <<<HTML
	<!-- ��������  -->
	<div class="tab-pane active" id="basics" role="tabpanel" aria-expanded="true">
HTML;
	
	echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_XiangQin->Config['LangVar']['AddFace'].'</label><div class="col-sm-9"><div class="AdminSingleUpload"><div class="PhotoControl" id="FacePhotoControl"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';

	showsetting($Fn_XiangQin->Config['LangVar']['NameTitle'], 'name', $UserInfo['name'], 'text','','','<input type="hidden" value="'.$UserInfo['param']['refusal'].'" name="refusal"><input type="hidden" value="'.$UserInfo['param']['vip_title'].'" name="vip_title">');

	showsetting($Fn_XiangQin->Config['LangVar']['NameTypeTitle'],array('name_type',DyadicArray($Fn_XiangQin->Config['LangVar']['NameTypeArray'])),$UserInfo['name_type'],'select');

	showsetting($Fn_XiangQin->Config['LangVar']['SexTitle'],array('sex',DyadicArray($Fn_XiangQin->Config['LangVar']['SexArray'],$Fn_XiangQin->Config['LangVar']['SelectNullTo'])),$UserInfo['sex'],'select');
	
	showsetting($Fn_XiangQin->Config['LangVar']['BirthTitle'], 'birth', $UserInfo['birth'] ?  date('Y-m-d',$UserInfo['birth']) : '', 'calendar','','','');

	if($Fn_XiangQin->Config['PluginVar']['BirthLocal']){
		$BirthLocalTreelistHtml = GetTreelistHtml($Fn_XiangQin->Config['LangVar']['BirthLocalArray'],'BirthLocalList',$UserInfo['birth_province'],$UserInfo['birth_city'],$UserInfo['birth_dist']);//������

		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_XiangQin->Config['LangVar']['BirthLocalTitle'].':</label><div class="col-sm-2"><div style="position:relative;height:40px"><input value="'.$UserInfo['birth_local'].'" class="form-control TreeList" type="text" id="BirthLocal">'.$BirthLocalTreelistHtml.'</div></div><div class="col-sm-7"><input type="hidden" name="birth_province" value="'.$UserInfo['birth_province'].'"/><input type="hidden" name="birth_city" value="'.$UserInfo['birth_city'].'"/><input type="hidden" name="birth_dist" value="'.$UserInfo['birth_dist'].'"/></div></div>';

	}

	if($Fn_XiangQin->Config['PluginVar']['Reside']){
		$ResideTreelistHtml = GetTreelistHtml($Fn_XiangQin->Config['LangVar']['ResideArray'],'ResideList',$UserInfo['reside_province'],$UserInfo['reside_city'],$UserInfo['reside_dist']);//��ס��
		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_XiangQin->Config['LangVar']['ResideTitle'].':</label><div class="col-sm-2"><div style="position:relative;height:40px"><input value="'.$UserInfo['reside'].'" class="form-control TreeList" type="text" id="Reside">'.$ResideTreelistHtml.'</div></div><div class="col-sm-7"><input type="hidden" name="reside_province" value="'.$UserInfo['reside_province'].'"/><input type="hidden" name="reside_city" value="'.$UserInfo['reside_city'].'"/><input type="hidden" name="reside_dist" value="'.$UserInfo['reside_dist'].'"/></div></div>';
	}

	showsetting($Fn_XiangQin->Config['LangVar']['HeightTitle'],array('height',DyadicArray($Fn_XiangQin->Config['LangVar']['UserInfoHeightArray'],$Fn_XiangQin->Config['LangVar']['SelectNullTo'])),$UserInfo['height'],'select');

	showsetting($Fn_XiangQin->Config['LangVar']['WeightTitle'],array('weight',DyadicArray($Fn_XiangQin->Config['LangVar']['UserInfoWeightArray'],$Fn_XiangQin->Config['LangVar']['SelectNullTo'])),$UserInfo['weight'],'select');

	showsetting($Fn_XiangQin->Config['LangVar']['BloodTitle'],array('blood',DyadicArray($Fn_XiangQin->Config['LangVar']['BloodArray'],$Fn_XiangQin->Config['LangVar']['SelectNullTo'])),$UserInfo['blood'],'select');

	showsetting($Fn_XiangQin->Config['LangVar']['EthnicTitle'],array('ethnic',DyadicArray($Fn_XiangQin->Config['LangVar']['EthnicArray'],$Fn_XiangQin->Config['LangVar']['SelectNullTo'])),$UserInfo['ethnic'],'select');
	
	showsetting($Fn_XiangQin->Config['LangVar']['CompanyTitle'], 'company', $UserInfo['company'], 'text');
	
	showsetting($Fn_XiangQin->Config['LangVar']['OccupationTitle'],array('occupation',DyadicArray($Fn_XiangQin->Config['LangVar']['OccupationArray'],$Fn_XiangQin->Config['LangVar']['SelectNullTo'])),$UserInfo['occupation'],'select');

	showsetting($Fn_XiangQin->Config['LangVar']['EducationTitle'],array('education',DyadicArray($Fn_XiangQin->Config['LangVar']['EducationArray'],$Fn_XiangQin->Config['LangVar']['SelectNullTo'])),$UserInfo['education'],'select');

	showsetting($Fn_XiangQin->Config['LangVar']['MarriageTitle'],array('marriage',DyadicArray($Fn_XiangQin->Config['LangVar']['MarriageArray'],$Fn_XiangQin->Config['LangVar']['SelectNullTo'])),$UserInfo['marriage'],'select');

	showsetting($Fn_XiangQin->Config['LangVar']['ChildTitle'],array('child',DyadicArray($Fn_XiangQin->Config['LangVar']['ChildArray'],$Fn_XiangQin->Config['LangVar']['SelectNullTo'])),$UserInfo['child'],'select');
	
	showsetting($Fn_XiangQin->Config['LangVar']['MobileTitle'], 'mobile', $UserInfo['mobile'], 'text');

	showsetting($Fn_XiangQin->Config['LangVar']['MobileDisplayTitle'], 'mobile_display', $UserInfo ? $UserInfo['mobile_display'] : 1 , 'radio');

	showsetting($Fn_XiangQin->Config['LangVar']['WxTitle'], 'wx', $UserInfo['param']['wx'], 'text');
	
	showsetting($Fn_XiangQin->Config['LangVar']['UserNavWx'], 'wx_display', $UserInfo ? $UserInfo['wx_display'] : 1 , 'radio');

	showsetting($Fn_XiangQin->Config['LangVar']['QQTitle'], 'qq', $UserInfo['param']['qq'], 'text');

	showsetting($Fn_XiangQin->Config['LangVar']['MonthIncomeTitle'],array('month_income',DyadicArray($Fn_XiangQin->Config['LangVar']['MonthIncomeArray'],$Fn_XiangQin->Config['LangVar']['SelectNullTo'])),$UserInfo['month_income'],'select');

	showsetting($Fn_XiangQin->Config['LangVar']['HouseTitle'],array('house',DyadicArray($Fn_XiangQin->Config['LangVar']['HouseArray'],$Fn_XiangQin->Config['LangVar']['SelectNullTo'])),$UserInfo['house'],'select');

	showsetting($Fn_XiangQin->Config['LangVar']['VehicleTitle'],array('vehicle',DyadicArray($Fn_XiangQin->Config['LangVar']['VehicleArray'],$Fn_XiangQin->Config['LangVar']['SelectNullTo'])),$UserInfo['vehicle'],'select');

	showsetting($Fn_XiangQin->Config['LangVar']['HobbyTitle'], array('hobby_array[]',DyadicArray($Fn_XiangQin->Config['LangVar']['HobbyArray'])),$UserInfo['hobby_array'],'mselect');
		
	echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_XiangQin->Config['LangVar']['HeUserAlbum'].'</label><div class="col-sm-9"><div class="AdminSingleUpload"><div class="PhotoControl" id="AlbumPhotoControl"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';

	showsetting($Fn_XiangQin->Config['LangVar']['MonologueTitle'], 'monologue', $UserInfo['param']['monologue'], 'textarea');

	showsetting($Fn_XiangQin->Config['LangVar']['RemarksTitle'], 'remarks', $UserInfo['param']['remarks'], 'textarea');
	echo <<<HTML
	</div>
	<!-- �������� end  -->
HTML;
		
	echo <<<HTML
	<!-- ��ż����  -->
	<div class="tab-pane" id="single" role="tabpanel" aria-expanded="false">
HTML;

	showsetting($Fn_XiangQin->Config['LangVar']['AdminMinAgeTitle'],array('c_min_age',DyadicArray($Fn_XiangQin->Config['LangVar']['AgeArray'],$Fn_XiangQin->Config['LangVar']['SelectNullTo'])),$UserInfo['condition']['c_min_age'],'select');

	showsetting($Fn_XiangQin->Config['LangVar']['AdminMaxAgeTitle'],array('c_max_age',DyadicArray($Fn_XiangQin->Config['LangVar']['AgeArray'],$Fn_XiangQin->Config['LangVar']['SelectNullTo'])),$UserInfo['condition']['c_max_age'],'select');
	
	showsetting($Fn_XiangQin->Config['LangVar']['AdminMinHeightTitle'],array('c_min_height',DyadicArray($Fn_XiangQin->Config['LangVar']['HeightArray'],$Fn_XiangQin->Config['LangVar']['SelectNullTo'])),$UserInfo['condition']['c_min_height'],'select');

	showsetting($Fn_XiangQin->Config['LangVar']['AdminMaxHeightTitle'],array('c_max_height',DyadicArray($Fn_XiangQin->Config['LangVar']['HeightArray'],$Fn_XiangQin->Config['LangVar']['SelectNullTo'])),$UserInfo['condition']['c_max_height'],'select');

	showsetting($Fn_XiangQin->Config['LangVar']['MonthIncomeTitle'],array('c_month_income',DyadicArray($Fn_XiangQin->Config['LangVar']['MonthIncomeArray'],$Fn_XiangQin->Config['LangVar']['SelectNullTo'])),$UserInfo['condition']['c_month_income'],'select');

	showsetting($Fn_XiangQin->Config['LangVar']['EducationTitle'],array('c_education',DyadicArray($Fn_XiangQin->Config['LangVar']['EducationArray'],$Fn_XiangQin->Config['LangVar']['SelectNullTo'])),$UserInfo['condition']['c_education'],'select');

	showsetting($Fn_XiangQin->Config['LangVar']['MarriageTitle'],array('c_marriage',DyadicArray($Fn_XiangQin->Config['LangVar']['MarriageArray'],$Fn_XiangQin->Config['LangVar']['SelectNullTo'])),$UserInfo['condition']['c_marriage'],'select');

	showsetting($Fn_XiangQin->Config['LangVar']['EthnicTitle'],array('c_ethnic',DyadicArray($Fn_XiangQin->Config['LangVar']['EthnicArray'],$Fn_XiangQin->Config['LangVar']['SelectNullTo'])),$UserInfo['condition']['c_ethnic'],'select');

	showsetting($Fn_XiangQin->Config['LangVar']['WhetherHouse'],array('c_house',DyadicArray($Fn_XiangQin->Config['LangVar']['WhetherHouseArray'],$Fn_XiangQin->Config['LangVar']['SelectNullTo'])),$UserInfo['condition']['c_house'],'select');

	showsetting($Fn_XiangQin->Config['LangVar']['WhetherVehicle'],array('c_vehicle',DyadicArray($Fn_XiangQin->Config['LangVar']['WhetherVehicleArray'],$Fn_XiangQin->Config['LangVar']['SelectNullTo'])),$UserInfo['condition']['c_vehicle'],'select');

	showsetting($Fn_XiangQin->Config['LangVar']['ShapeTitle'],array('c_shape',DyadicArray($Fn_XiangQin->Config['LangVar']['ShapeArray'],$Fn_XiangQin->Config['LangVar']['SelectNullTo'])),$UserInfo['condition']['c_shape'],'select');

	showsetting($Fn_XiangQin->Config['LangVar']['WantChildTitle'],array('c_want_child',DyadicArray($Fn_XiangQin->Config['LangVar']['WantChildArray'],$Fn_XiangQin->Config['LangVar']['SelectNullTo'])),$UserInfo['condition']['c_want_child'],'select');

	showsetting($Fn_XiangQin->Config['LangVar']['SmokeTitle'],array('c_smoke',DyadicArray($Fn_XiangQin->Config['LangVar']['SmokeArray'],$Fn_XiangQin->Config['LangVar']['SelectNullTo'])),$UserInfo['condition']['c_smoke'],'select');

	showsetting($Fn_XiangQin->Config['LangVar']['DrinkTitle'],array('c_drink',DyadicArray($Fn_XiangQin->Config['LangVar']['SmokeArray'],$Fn_XiangQin->Config['LangVar']['SelectNullTo'])),$UserInfo['condition']['c_drink'],'select');
	echo <<<HTML
	</div>
	<!-- ��ż���� end  -->
HTML;
		
	echo <<<HTML
	<!-- ��������  -->
	<div class="tab-pane" id="other" role="tabpanel" aria-expanded="false">
HTML;
	//����	
	if($Fn_Admin->CheckUserGroup('xiang_all')){
		foreach($Fn_XiangQin->GetMatchmakerList() as $Val) {
			$MatchmakerList[$Val['uid']] = $Val['name'];
		}
		showsetting($Fn_XiangQin->Config['LangVar']['MatchmakerTitle'],array('mid',DyadicArray($MatchmakerList,$Fn_XiangQin->Config['LangVar']['SelectNullTo'])),$UserInfo['mid'],'select');
	}
	if($UserInfo['uid']){
		showsetting('uid', 'uidnew', $UserInfo['uid'], 'text','readonly');
	}else{
		showsetting('uid', 'uidnew', $UserInfo['uid'], 'text');
	}
	
	showsetting($Fn_XiangQin->Config['LangVar']['Click'], 'click', $UserInfo['click'], 'text');

	showsetting('VIP'.$Fn_XiangQin->Config['LangVar']['UserVipTime'], 'vip_time',$UserInfo['vip_time'] ? date('Y-m-d H:i',$UserInfo['vip_time']) : '', 'calendar','','','',1);

	showsetting($Fn_XiangQin->Config['LangVar']['TopDateline'], 'top_dateline',$UserInfo['top_dateline'] ? date('Y-m-d H:i',$UserInfo['top_dateline']) : '', 'calendar','','','',1);

	showsetting($Fn_XiangQin->Config['LangVar']['ExpireDisplayDate'], 'display_dateline',$UserInfo['display_dateline'] ? date('Y-m-d H:i',$UserInfo['display_dateline']) : '', 'calendar','','','',1);

	showsetting($Fn_XiangQin->Config['LangVar']['LeadLine'], 'lead_line', $UserInfo['lead_line'], 'text');

	showsetting($Fn_XiangQin->Config['LangVar']['SeeLine'], 'see_line', $UserInfo['see_line'], 'text');

	showsetting($Fn_XiangQin->Config['LangVar']['LeadLineState'],array('lead_line_state',DyadicArray($Fn_XiangQin->Config['LangVar']['LeadLineStateArray'])),$UserInfo['lead_line_state'],'select');

	showsetting($Fn_XiangQin->Config['LangVar']['ExamineState'],array('examine',DyadicArray($Fn_XiangQin->Config['LangVar']['ExamineArray'])),$UserInfo['examine'],'select');

	showsetting($Fn_XiangQin->Config['LangVar']['DisplayTitle'], 'display', $UserInfo ? $UserInfo['display'] : 1, 'radio');

	showsetting($Fn_XiangQin->Config['LangVar']['SealTitle'], 'seal',$UserInfo['seal'], 'radio');

	showsetting($Fn_XiangQin->Config['LangVar']['HomeTitle'], 'home',$UserInfo['home'], 'radio');

	if($UserInfo['dateline']){
	showsetting($Fn_XiangQin->Config['LangVar']['TimeTitle'], 'dateline',date('Y-m-d H:i',$UserInfo['dateline']), 'calendar','','','',1);
	}
	echo <<<HTML
	</div>
	<!-- �������� end  -->
HTML;

	showsubmit('DetailSubmit','&#20445;&#23384;&#37197;&#32622;');
	showtagfooter('div');
	showtagfooter('div');
	showformfooter(); /*Dism_taobao-com*/
	showtagfooter('div');
	

	$UpLoadHtml  = '';
	if($UserInfo['face']){
		$FaceJsArray[] = '"'.$UserInfo['face'].'"';;
		$UpLoadHtml .= '
		var InputArray = new Array('.implode(',',$FaceJsArray).');
		$("#FacePhotoControl").AppUpload({InputName:"new_face",Multiple:true,InputExist:true,InputArray:InputArray});';

	}else{
		$UpLoadHtml .= '$("#FacePhotoControl").AppUpload({InputName:"new_face",Multiple:true});';
	}

	if($UserInfo['param']['album']){
		foreach($UserInfo['param']['album'] as $Key => $Val) {
			$ImagesJsArray[] = '"'.$Val.'"';
		}
		$UpLoadHtml .= '
		var InputArray = new Array('.implode(',',$ImagesJsArray).');
		$("#AlbumPhotoControl").AppUpload({InputName:"new_album",InputExist:true,InputArray:InputArray});';

	}else{
		$UpLoadHtml .= '$("#AlbumPhotoControl").AppUpload({InputName:"new_album"});';
	}

	echo '
	<link rel="stylesheet" href="'.$Config['StaticPath'].'/css/mobiscroll.custom-2.16.1.min.css">
	<script src="'.$Config['StaticPath'].'/js/jquery-1.9.1.min.js"></script>
	<script src="'.$Config['StaticPath'].'/js/mobiscroll.custom-2.16.1.min.js"></script>
	'.$UploadConfig['CssJsHtml'].'
	<script>
	'.$UpLoadHtml.'
	$(document).on("click","#BirthLocal",function(){
		GetTreeList($(this),"BirthLocalList","birth_province","birth_city","birth_dist");
		return false;
	});
	$(document).on("click","#Reside",function(){
		GetTreeList($(this),"ResideList","reside_province","reside_city","reside_dist");
		return false;
	});
	function GetTreeList(_This,Id,InputName,InputName2,InputName3){
		var I = $("#"+Id).children("li.Default").attr("Index");
		var J = $("#"+Id).find("ul.Children").children("li.Default").attr("Index");
		var K = $("#"+Id).find("ul.Childrens").children("li.Default").attr("Index");
		$("#"+Id).mobiscroll().treelist({  
			theme: "android-holo-light",
			lang: "zh",  
			display: "bottom",  
			inputClass: "Tmp",  
			headerText: "'.$Fn_XiangQin->Config['LangVar']['SelectNullTo'].'",  
			onSelect: function (ValueText,Inst) {  
				var N = ValueText.split(" ");
				var Obj1 = $(this).children("li").eq(N[0]);
				var Obj2 = Obj1.find("ul.Children").children("li").eq(N[1]);
				var Obj3 = Obj2.find("ul.Childrens").children("li").eq(N[2]);
				var Text1 = typeof(Obj1.attr("DataContnet")) == "undefined" ? "" : Obj1.attr("DataContnet");
				var Value1 = typeof(Obj1.attr("DataValue")) == "undefined" ? "" : Obj1.attr("DataValue");
				var Text2 = typeof(Obj2.attr("DataContnet")) == "undefined" ? "" : Obj2.attr("DataContnet");
				var Value2 = typeof(Obj2.attr("DataValue")) == "undefined" ? "" : Obj2.attr("DataValue");
				var Text3 = typeof(Obj3.attr("DataContnet")) == "undefined" ? "" : Obj3.attr("DataContnet");
				var Value3 = typeof(Obj3.attr("DataValue")) == "undefined" ? "" : Obj3.attr("DataValue");
				Obj1.addClass("Default").siblings().removeClass("Default");
				Obj2.addClass("Default").siblings().removeClass("Default");
				Obj3.addClass("Default").siblings().removeClass("Default");
				_This.val(Text1+Text2+Text3);
				$("input[name=\'"+InputName+"\']").val(Value1);
				$("input[name=\'"+InputName2+"\']").val(Value2);
				$("input[name=\'"+InputName3+"\']").val(Value3);
			},
			defaultValue:[I,J,K]
		});  
		$("input[id^="+Id+"]").focus(); 
	}
	</script>
	';
}else{
	if($Fn_Admin->CheckUserGroup('xiang_all')){
		$Data['mid'] = intval($_GET['mid']);
	}
	$Data['name'] = addslashes(strip_tags($_GET['name']));
	$Data['name_type'] = intval($_GET['name_type']);
	$Data['sex'] = intval($_GET['sex']);
	$Data['birth'] = $_GET['birth'] ? strtotime($_GET['birth']) : '';
	if($Fn_XiangQin->Config['PluginVar']['BirthLocal']){
		$Data['birth_province'] = addslashes(strip_tags($_GET['birth_province']));
		$Data['birth_city'] = addslashes(strip_tags($_GET['birth_city']));
		$Data['birth_dist'] = addslashes(strip_tags($_GET['birth_dist']));
		$Data['birth_community'] = addslashes(strip_tags($_GET['birth_community']));
	}
	if($Fn_XiangQin->Config['PluginVar']['Reside']){
		$Data['reside_province'] = addslashes(strip_tags($_GET['reside_province']));
		$Data['reside_city'] = addslashes(strip_tags($_GET['reside_city']));
		$Data['reside_dist'] = addslashes(strip_tags($_GET['reside_dist']));
		$Data['reside_community'] = addslashes(strip_tags($_GET['reside_community']));
	}
	//����-��Ф
	$Birthext = $Fn_XiangQin->Birthext($Data['birth']);
	$Data['constellation'] = intval($Birthext['constellation']);
	$Data['animal'] = intval($Birthext['animal']);
	$Data['age'] = date('Y') - date('Y',$Data['birth']);
	$Data['height'] = intval($_GET['height']);
	$Data['weight'] = intval($_GET['weight']);
	$Data['blood'] = intval($_GET['blood']);
	$Data['ethnic'] = intval($_GET['ethnic']);
	$Data['company'] = addslashes(strip_tags($_GET['company']));
	$Data['occupation'] = intval($_GET['occupation']);
	$Data['education'] = intval($_GET['education']);
	$Data['marriage'] = intval($_GET['marriage']);
	$Data['child'] = intval($_GET['child']);
	$Data['mobile'] = addslashes(strip_tags($_GET['mobile']));
	$Data['month_income'] = intval($_GET['month_income']);
	$Data['mobile_display'] = intval($_GET['mobile_display']);
	$Data['house'] = intval($_GET['house']);
	$Data['vehicle'] = intval($_GET['vehicle']);
	$Data['hobby'] = is_array($_GET['hobby_array']) && isset($_GET['hobby_array'])  ? implode(',',$_GET['hobby_array']) : '';
	$Data['uid'] = intval($_GET['uidnew']);
	$Data['click'] = intval($_GET['click']);
	$Data['vip_time'] = $_GET['vip_time'] ? strtotime($_GET['vip_time']) : '';
	$Data['top_dateline'] = $_GET['top_dateline'] ? strtotime($_GET['top_dateline']) : '';
	$Data['display_dateline'] = $_GET['display_dateline'] ? strtotime($_GET['display_dateline']) : '';
	$Data['lead_line'] = intval($_GET['lead_line']);
	$Data['lead_line_state'] = intval($_GET['lead_line_state']);
	$Data['see_line'] = intval($_GET['see_line']);
	$Data['home'] = intval($_GET['home']);
	$Data['examine'] = intval($_GET['examine']);
	$Data['display'] = intval($_GET['display']);
	$Data['seal'] = intval($_GET['seal']);
	$Data['wx_display'] = intval($_GET['wx_display']);

	foreach($_GET['new_face'] as $Key => $Val) {
		$_GET['new_face'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
	}
		
	foreach($_GET['new_album'] as $Key => $Val) {
		$_GET['new_album'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
	}
	$Data['face'] = addslashes(strip_tags($_GET['new_face'][0]));

	
	$Param['remarks'] =  addslashes(strip_tags($_GET['remarks']));
	$Param['wx'] =  addslashes(strip_tags($_GET['wx']));
	$Param['qq'] =  addslashes(strip_tags($_GET['qq']));
	$Param['monologue'] = addslashes(strip_tags($_GET['monologue']));
	$Param['refusal'] = addslashes(strip_tags($_GET['refusal']));
	$Param['vip_title'] = addslashes(strip_tags($_GET['vip_title']));
	$Param['album'] = is_array($_GET['new_album']) && isset($_GET['new_album'])  ? array_filter($_GET['new_album']) : '';
	//��ż����
	$ConditionData['uid'] = $Data['uid'];
	$ConditionData['c_min_age'] = intval($_GET['c_min_age']);
	$ConditionData['c_max_age'] = intval($_GET['c_max_age']);
	$ConditionData['c_min_height'] = intval($_GET['c_min_height']);
	$ConditionData['c_max_height'] = intval($_GET['c_max_height']);
	$ConditionData['c_month_income'] = intval($_GET['c_month_income']);
	$ConditionData['c_education'] = intval($_GET['c_education']);
	$ConditionData['c_marriage'] = intval($_GET['c_marriage']);
	$ConditionData['c_ethnic'] = intval($_GET['c_ethnic']);
	$ConditionData['c_house'] = intval($_GET['c_house']);
	$ConditionData['c_vehicle'] = intval($_GET['c_vehicle']);
	$ConditionData['c_shape'] = intval($_GET['c_shape']);
	$ConditionData['c_want_child'] = intval($_GET['c_want_child']);
	$ConditionData['c_smoke'] = intval($_GET['c_smoke']);
	$ConditionData['c_drink'] = intval($_GET['c_drink']);
	//��ż����End

	$Data['param'] = serialize($Param);
	$Member = DB::fetch_first('SELECT username FROM '.DB::table('common_member').' where uid = '.$Data['uid']);
	if($Member || $UserInfo){
		$Data['username'] = addslashes(strip_tags($Member['username']));
		if($UserInfo){
			if($UserInfo['uid'] != $Data['uid']){//����û��Ƿ����
				$CheckUserInfo = $Fn_XiangQin->GetUserInfo($Data['uid']);
				if($CheckUserInfo){
					fn_cpmsg($Fn_XiangQin->Config['LangVar']['CheckUserErr'],'','error');
				}
			}
			$Data['dateline'] = strtotime($_GET['dateline']);
			$Data['updateline'] = $ConditionData['updateline'] = time();
			DB::update($Fn_XiangQin->TableMember,$Data,'uid = '.$Data['uid']);
			if($UserInfo['condition']){
				DB::update($Fn_XiangQin->TableCondition,$ConditionData,'uid = '.$Data['uid']);
			}else{
				DB::insert($Fn_XiangQin->TableCondition,$ConditionData);
			}
			
			if($Fn_Admin->CheckUserGroup('xiang_all')){
				DB::update($Fn_XiangQin->TableReport,array('mid'=>$Data['mid']),'uid = '.$Data['uid']);
			}
			GetInsertDoLog('edit_user_xiangqin','fn_'.$_GET['mod'],array('uid'=>$_GET['uidnew'],'vip_time'=>$_GET['vip_time'],'top_dateline'=>$_GET['top_dateline'],'display_dateline'=>$_GET['display_dateline'],'lead_line'=>$_GET['lead_line']));//������¼
			fn_cpmsg($Fn_XiangQin->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
		}else{
			$CheckUserInfo = $Fn_XiangQin->GetUserInfo($Data['uid']);
			if($CheckUserInfo){//����û��Ƿ����
				fn_cpmsg($Fn_XiangQin->Config['LangVar']['CheckUserErr'],'','error');
			}else{
				$Data['dateline'] = $Data['updateline'] = $ConditionData['dateline'] = $ConditionData['updateline'] = time();
				if($Fn_XiangQin->Config['Matchmaker'] && !$Data['mid']){
					$Data['mid'] = intval($_G['uid']);
				}
				DB::insert($Fn_XiangQin->TableMember,$Data);
				DB::insert($Fn_XiangQin->TableCondition,$ConditionData);
				GetInsertDoLog('add_user_xiangqin','fn_'.$_GET['mod'],array('uid'=>$_GET['uidnew']));//������¼
				fn_cpmsg($Fn_XiangQin->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
			}
		}
	}else{
		fn_cpmsg($Fn_XiangQin->Config['LangVar']['NoUserErr'],'','error');
	}
}
//From: Dism_taobao_com
?>