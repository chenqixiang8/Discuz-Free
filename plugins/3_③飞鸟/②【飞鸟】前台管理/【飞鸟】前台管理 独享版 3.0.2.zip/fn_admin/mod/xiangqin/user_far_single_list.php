<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('xiangqin_all') && !$Fn_Admin->CheckUserGroup('xiangqin_user_far_single_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$SubModel = in_array($_GET['submodel'], array('list','add')) ? $_GET['submodel'] : 'list';
$Fn_Admin->Config['IframeSubModelUrl'] = $Fn_Admin->Config['IframeItemUrl'].'&submodel='.$SubModel;
$NavClass = array($SubModel=>'btn-info Hover');

//����
echo <<<Nav
<div class="SubModelNav">
  <ul>
	<li class="{$NavClass['list']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=list" target="_self">{$Fn_Admin->Config['LangVar']['XiangqinLeftNavArray'][$_GET['item']]}</a></li>
    <li class="{$NavClass['add']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=add" target="_self">{$Fn_Admin->Config['LangVar']['AddEditTitle']}</a></li>
  </ul>
  <div class="both"></div>
</div>
Nav;

if($SubModel == 'list'){//�б�
	$Do = in_array($_GET['do'], array('Del','display')) ? $_GET['do'] : 'submodel_list';
	//�����ֶ�
	$SearField =array('page','keyword','vid','display','order');
	foreach($SearField as $Val) {
		$SearArray[$Val] = $_GET[$Val] ? $_GET[$Val] : '';
	}
	//�����ֶ� End
	$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeSubModelUrl'].'&'.http_build_query($SearArray);
	if($Do == 'submodel_list'){
		if(!submitcheck('Submit')) {
			$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
			$page = $_GET['page'] ? $_GET['page'] : 0;
			$res = C::t('#fn_xiangqin#fn_love_user_far_single')->fetch_all_by_list(array('vid'=>$_GET['vid'],'display'=>$_GET['display']),'dateline',$page - 1,30,true);
			/* ��ѯ���� End */

			/* ģ����� */	
			showtagheader('div', 'row', true,'row');
			showtagheader('div', 'col-12', true,'col-12');
			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-body', true,'box-body');
			/* ���� */

			echo <<<SEARCH
			<form method="post" autocomplete="off" action="$SearUrl" id="tb_search">
				<div class="FormSearchTo">
					<table cellspacing="4" cellpadding="4">
						<tr>
							<th>&#33073;&#21333;&#29992;&#25143;&#73;&#68;</th>
							<td colspan="10"><input type="text" class="input form-control w200" name="vid" value="{$_GET['vid']}" placeholder="&#35831;&#36755;&#20837;&#33073;&#21333;&#29992;&#25143;&#73;&#68;">
							&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Admin->Config['LangVar']['SearchSubmit']}" class="btn btn-info" type="submit">
							</td>
						</tr>
					</table>
				</div>
			</form>
SEARCH;
		/* ���� End */
			showtagheader('div', 'table-responsive', true,'table-responsive');
			showformheader($FormUrl,'enctype="multipart/form-data"');
			showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
			showsubtitle(array(
				'ID',
				'&#33073;&#21333;&#29992;&#25143;',
				'&#22836;&#20687;',
				'&#26631;&#39064;',
				'&#20869;&#23481;',
				$fn_xiangqin->setting['lang']['DisplayTitle'],
				'&#26356;&#26032;&#26102;&#38388;',
				'&#28155;&#21152;&#26102;&#38388;',
				$fn_xiangqin->setting['lang']['OperationTitle']
			),'header tbm tc');

			foreach ($res['list'] as $item) {
				$userInfo = $fn_xiangqin->getView($item['vid']);
				showtablerow('', array('class="tc w50"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
					'<input type="checkbox" class="filled-in" id="checkbox_'.$item['id'].'" name="delete[]" value="'.$item['id'].'"><label for="checkbox_'.$item['id'].'">'.$item['id'].'</label>',
					'<a href="'.$userInfo['url'].'" target="_blank">&#32534;&#21495;&#65306;'.$userInfo['id'].'</a><br>&#22995;&#21517;&#65306;'.$userInfo['name'].'-'.$userInfo['sex_text'].'-'.$userInfo['age'].'<br>&#25163;&#26426;&#21495;&#65306;'.$userInfo['phone'],
					($userInfo['head_portrait'] ? '<a href="'.$userInfo['head_portrait'].'" target="_blank"><img src="'.$userInfo['head_portrait'].'" height="60"></a>' : ''),
					$item['title'],
					cutstr($item['content'],60),
					!$item['display'] ? '<span class="label bg-secondary">'.$fn_xiangqin->setting['lang']['No'].'</span>' : '<span class="label bg-blue">'.$fn_xiangqin->setting['lang']['Yes'].'</span>',
					date('Y-m-d H:i',$item['updateline']),
					date('Y-m-d H:i',$item['dateline']),
					'<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&aid='.$item['id'].'" class="btn btn-sm btn-info-outline">'.$fn_xiangqin->setting['lang']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=display&aid='.$item['id'].'&value='.(!empty($item['display']) ? 0:1).'&formhash='.FORMHASH.'" class="btn btn-sm btn-dark-outline">'.(!empty($item['display']) ? $fn_xiangqin->setting['lang']['DisplayNoTitle'] : $fn_xiangqin->setting['lang']['DisplayIsTitle']).'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Del&aid='.$item['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$fn_xiangqin->setting['lang']['DelTitle'].'</a>',
				));
			}
			showsubmit('Submit','&#31435;&#21363;&#25552;&#20132;','del','','',multi($res['count'],30,$page,$MpUrl));
			showtablefooter(); /*dism��taobao��com*/
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			/* ģ�����End */	
		}else{
			if(isset($_GET['delete']) && is_array($_GET['delete'])){
				if(!$Fn_Admin->CheckUserGroup('xiangqin_all') && !$Fn_Admin->CheckUserGroup('xiangqin_del_user_far_single')){//Ȩ���ж�
					fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
					exit();
				}
				foreach($_GET['delete'] as $val) {
					$id = intval($val);
					C::t('#fn_xiangqin#fn_love_user_far_single')->delete_by_id($id);
				}
				GetInsertDoLog('del_far_single_xiangqin','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete'])));//������¼
				fn_cpmsg($fn_xiangqin->setting['lang']['DelOk'],$CpMsgUrl,'succeed');
			}else{
				fn_cpmsg($fn_xiangqin->setting['lang']['DelErr'],'','error');
			}
		}
	}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['aid']){
		if(!$Fn_Admin->CheckUserGroup('xiangqin_all') && !$Fn_Admin->CheckUserGroup('xiangqin_del_user_far_single')){//Ȩ���ж�
			fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
			exit();
		}
		$id = intval($_GET['aid']);
		C::t('#fn_xiangqin#fn_love_user_far_single')->delete_by_id($id);
		GetInsertDoLog('del_far_single_xiangqin','fn_'.$_GET['mod'],array('id'=>$id));//������¼
		fn_cpmsg($fn_xiangqin->setting['lang']['DelOk'],$CpMsgUrl,'succeed');
		exit();
	}else if(in_array($Do,array('display')) && $_GET['formhash'] == formhash() && $_GET['aid']){
		$id = intval($_GET['aid']);
		$data[$Do] = intval($_GET['value']);
		C::t('#fn_xiangqin#fn_love_user_far_single')->update($data,$id);
		GetInsertDoLog($Do.'_far_single_xiangqin','fn_'.$_GET['mod'],array('id'=>$id));//������¼
		fn_cpmsg($fn_xiangqin->setting['lang']['UpdateOk'],$CpMsgUrl,'succeed');
		exit();
	}
}else if($SubModel == 'add'){//���ӻ�༭

	$id = intval($_GET['aid']);
	
	$item = C::t('#fn_xiangqin#fn_love_user_far_single')->fetch_by_id($id);

	if(!submitcheck('DetailSubmit')) {
		$opTitle = $fn_xiangqin->setting['lang']['AddTitle'];
		if($item){
			$opTitle = $fn_xiangqin->setting['lang']['EditTitle'];
		}

		//ͼƬ�ϴ�
		if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_assembly/class/class_upload.php')){
			@require_once libfile('class/upload','plugin/fn_assembly');
			$UploadConfig = fn_upload::Config();
		}

		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-header', true,'with-border box-header');
		showtitle($opTitle,'class="box-title"');
		showtagfooter('div');
		showformheader($Fn_Admin->Config['IframeSubModelUrl'].'&aid='.$id,'enctype');
		showtagheader('div', 'box-body', true,'box-body');
		showsetting('&#33073;&#21333;&#29992;&#25143;ID', 'vid', $item['vid'], 'text');
		showsetting('&#26631;&#39064;', 'title', $item['title'], 'text');
		showsetting('&#20869;&#23481;', 'content', $item['content'], 'textarea');

		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$fn_xiangqin->setting['lang']['album'].'</label><div class="col-sm-9"><div class="AdminSingleUpload"><div class="PhotoControl" id="album"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';

		showsetting($fn_xiangqin->setting['lang']['DisplayTitle'], 'display', $item ? $item['display'] : 1, 'radio');

		if($item){
			showsetting($fn_xiangqin->setting['lang']['RefreshTime'], 'updateline',$item['updateline'] ? date('Y-m-d H:i',$item['updateline']) : '', 'calendar','','','',1);
		}

		if($item){
			showsetting($fn_xiangqin->setting['lang']['TimeTitle'], 'dateline',date('Y-m-d H:i',$item['dateline']), 'calendar','','','',1);
		}

		showsubmit('DetailSubmit','&#20445;&#23384;&#37197;&#32622;');
		showtagfooter('div');
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');

		$UpLoadHtml  = '';
		if($item['album']){
			foreach(array_filter(explode(",",$item['album'])) as $key => $val) {
				$ImagesJsArray[] = '"'.$val.'"';
			}
			$UpLoadHtml .= '
			var InputArray = new Array('.implode(',',$ImagesJsArray).');
			$("#album").AppUpload({InputName:"new_album",InputExist:true,InputArray:InputArray});';

		}else{
			$UpLoadHtml .= '$("#album").AppUpload({InputName:"new_album"});';
		}

		echo '
		<script src="'.$Config['StaticPath'].'/js/jquery-1.9.1.min.js"></script>'.$UploadConfig['CssJsHtml'].'
		<script>
		'.$UpLoadHtml.'
		</script>
		';

	}else{
		foreach($_GET['new_album'] as $key => $val) {
			$_GET['new_album'][$key] = strpos($val,'http') !== false ? $val : $_G['siteurl'].$val;
		}
		$data['vid'] = intval($_GET['vid']);
		$data['title'] = addslashes(strip_tags($_GET['title']));
		$data['content'] = addslashes(strip_tags($_GET['content']));
		$data['display'] = intval($_GET['display']);
		$data['album'] = is_array($_GET['new_album']) && isset($_GET['new_album'])  ? implode(',',array_filter($_GET['new_album'])) : '';
		if($item){
			$data['dateline'] = strtotime($_GET['dateline']);
			$data['updateline'] = strtotime($_GET['updateline']);
			C::t('#fn_xiangqin#fn_love_user_far_single')->update($data,$id);
		}else{
			$mat = C::t('#fn_xiangqin#fn_love_mat')->fetch_by_uid($_G['uid']);
			$data['mat_id'] = $mat['id'];
			$data['dateline'] = $data['updateline'] = time();
			$id = C::t('#fn_xiangqin#fn_love_user_far_single')->insert($data);
		}
		fn_cpmsg($fn_xiangqin->setting['lang']['UpdateOk'],$Fn_Admin->Config['IframeItemUrl'].'&submodel=list','succeed');
		exit();
	}
}
//From: Dism_taobao_com
?>