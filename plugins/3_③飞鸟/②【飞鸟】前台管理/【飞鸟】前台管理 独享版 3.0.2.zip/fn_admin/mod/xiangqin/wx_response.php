<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: menu_setting.inc.php 35201 2015-02-04 06:32:12Z nemohou $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('xiangqin_all') && !$Fn_Admin->CheckUserGroup('xiangqin_wx_response')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeItemUrl'];

@require_once libfile('class/wechat','plugin/fn_assembly');
@require_once libfile('function/cache');

$plugin['identifier'] = 'fn_'.$_GET['mod'];
loadcache($plugin['identifier'].'_wechat_response');
loadcache($plugin['identifier'].'_setting');
loadcache('plugin');
$response = $_G['cache'][$plugin['identifier'].'_wechat_response'];

$common_setting = (array)$_G['cache'][$plugin['identifier'].'_setting'];
$WxAppid = $common_setting['WxAppid'];
$WxSecret = $common_setting['WxSecret'];

if(!$WxAppid || !$WxSecret) {
	fn_cpmsg(lang('plugin/fn_assembly', 'wsq_menu_at_error'), '', 'error');
	exit();
}

if(!submitcheck('menusubmit') && !submitcheck('pubsubmit')) {

	showtips(lang('plugin/fn_assembly', 'response_tips', array('url' => $url)));

	showtagheader('div', 'row', true,'row');
	showtagheader('div', 'col-12', true,'col-12');
	showtagheader('div', 'box', true,'box');
	showtagheader('div', 'box-body', true,'box-body');
	showtagheader('div', 'table-responsive', true,'table-responsive');

	showformheader($FormUrl);
	showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');

	echo '<tr class="header"><th class="w50"></th><th class="w200">&#20844;&#20247;&#21495;&#20851;&#27880;</th><th>&#22238;&#22797;&#20869;&#23481;</th></tr>';
	showtablerow('', array('', 'class="td23 td28"', 'class="td29"'), array(
		'',
		"&#20851;&#27880;",
		"<textarea class=\"form-control w400\" name=\"response[subscribe]\" id=\"res_subscribe\">".dhtmlspecialchars($response['subscribe'])."</textarea>"
	));

	echo '<tr class="header"><th class="w50"></th><th class="w200">&#26410;&#21305;&#37197;&#20851;&#38190;&#35789;</th><th>&#22238;&#22797;&#20869;&#23481;</th></tr>';
	showtablerow('', array('', 'class="td23 td28"', 'class="td29"'), array(
		'',
		"&#26410;&#21305;&#37197;",
		"<textarea class=\"form-control w400\" name=\"response[unmatched]\" id=\"res_subscribe\">".dhtmlspecialchars($response['unmatched'])."</textarea>"
	));
	
	echo '<tr class="header"><th class="w50"></th><th class="w200">&#20851;&#38190;&#35789;</th><th>&#22238;&#22797;&#20869;&#23481;</th></tr>';
	foreach($response['text'] as $k => $text) {
		showtablerow('', array('', 'class="td23 td28"', 'class="td29"'), array(
			'<input type="checkbox" class="filled-in" id="checkbox_'.$k.'" name="response[text]['.$k.'][delete]" value="yes"><label for="checkbox_'.$k.'"></label>',
			"<div class=\"parentnode\"><input type=\"text\" class=\"form-control\" name=\"response[text][$k][keyword]\" value=\"".dhtmlspecialchars($text['keyword'])."\"></div>",
			"<textarea class=\"form-control w400\" name=\"response[text][$k][response]\"  id=\"res_text_$k\">".dhtmlspecialchars($text['response'])."</textarea>"
		));
	}

	echo '<tr><td></td><td class="td23 td28"></td><td colspan="2"><a href="###" onclick="addrow(this,rowtypedata, 0, 0,)" class="addtr">'.lang('plugin/wechat', 'response_add_message').'</a></td></tr>';
	echo <<<EOT
<script type="text/JavaScript">
var rowtypedata = [
[[1,''], [1, '<input name="newresponse[keyword][]" value="" type="text" class="form-control">'], [1, '<textarea class="form-control w400" name="newresponse[response][]"></textarea>', 'td29']],
];
</script>
EOT;

	showsubmit('menusubmit', 'submit', 'del');
	showtablefooter(); /*dism��taobao��com*/
	showformfooter(); /*Dism_taobao-com*/
	showtagfooter('div');
	showtagfooter('div');
	showtagfooter('div');
	showtagfooter('div');
	showtagfooter('div');
	
} else {
	if(!empty($_GET['newresponse'])) {
		foreach($_GET['newresponse']['keyword'] as $k => $keyword) {
			$item = array(
				'keyword' => $keyword,
				'response' => $_GET['newresponse']['response'][$k],
			);
			$response['text'][] = $item;
		}
	}

	foreach($_GET['response']['text'] as $k => $value) {
		if($value['delete']) {
			unset($response['text'][$k]);
			continue;
		}
		$response['text'][$k] = $value;
	}

	$response['subscribe'] = $_GET['response']['subscribe'];
	$response['access'] = $_GET['response']['access'];
	$response['scan'] = $_GET['response']['scan'];
	$response['unmatched'] = $_GET['response']['unmatched'];

	$query = array(
	    'subscribe' => $response['subscribe'],
	    'text' => array(),
	);

	foreach($response['text'] as $value) {
		$query['text'][$value['keyword']] = $value['response'];
	}

	$response['query'] = $query;
	
	savecache($plugin['identifier'].'_wechat_response',$response);

	fn_cpmsg('setting_update_succeed', $CpMsgUrl, 'succeed');
	exit();

}
//From: Dism��taobao��com
?>