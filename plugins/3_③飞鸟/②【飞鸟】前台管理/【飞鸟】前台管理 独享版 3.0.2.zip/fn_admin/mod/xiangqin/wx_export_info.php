<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('xiangqin_all') && !$Fn_Admin->CheckUserGroup('xiangqin_wx_export_info')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

if(!submitcheck('DetailSubmit')) {
	$OpTitle = $Fn_Admin->Config['LangVar']['JobLeftNavArray'][$_GET['item']];

	showtagheader('div', 'box', true,'box');
	showtagheader('div', 'box-header', true,'with-border box-header');
	showtitle($OpTitle,'class="box-title"');
	showtagfooter('div');
	showformheader($Fn_Admin->Config['IframeSubModelUrl'],'enctype');
	showtagheader('div', 'box-body', true,'box-body');
	
	showsetting('&#20449;&#24687;&#31867;&#22411;',array('export_type', array(
		array('user','&#29992;&#25143;&#21015;&#34920;', array('user' => '')),
	), true),'user', 'mradio');

	showsetting('&#20449;&#24687;&#25490;&#24207;',array('export_sort', array(
		array('updateline','&#21047;&#26032;&#26102;&#38388;'),
		array('dateline','&#21457;&#24067;&#26102;&#38388;'),
	), true),'updateline', 'mradio');

	$export_time_array = array(
		array('0','&#19981;&#38480;'),
		array('1','&#49;&#22825;&#20869;'),
		array('3','3&#22825;&#20869;'),
		array('7','7&#22825;&#20869;'),
		array('15','15&#22825;&#20869;'),
		array('30','1&#20010;&#26376;&#20869;'),
		array('60','2&#20010;&#26376;&#20869;'),
		array('90','3&#20010;&#26376;&#20869;'),
	);
	showsetting('&#26102;&#38388;&#31579;&#36873;', array('export_time',$export_time_array),'0','mradio');
	
	showsetting('&#20449;&#24687;&#25968;&#37327;','export_limit','30','text');
	
	//showsetting('&#26159;&#21542;&#21253;&#21547;&#32622;&#39030;', 'export_top','1','radio');

	//showsetting('&#32622;&#39030;&#25490;&#21069;&#38754;&#65311;', 'export_top_sort','1','radio');

	//showsetting('&#20851;&#38190;&#35789;','keyword','','text');

	showtagheader('div', 'user', true,'sub');
		
		showsetting('&#32534;&#21495;','ids','','text','','','&#26684;&#24335;&#65306;&#49;&#44;&#50;&#44;&#51;');

		showsetting($fn_xiangqin->setting['lang']['sex'],array('sex',DyadicArray($fn_xiangqin->setting['lang']['sex_arr'],$fn_xiangqin->setting['lang']['Unlimited'])),'0','mradio');

		showsetting($fn_xiangqin->setting['lang']['marriage'],array('marriage',DyadicArray($fn_xiangqin->setting['lang']['marriage_arr'],$fn_xiangqin->setting['lang']['Unlimited'])),'0','mradio');

		showsetting($fn_xiangqin->setting['lang']['education'],array('education',DyadicArray($fn_xiangqin->setting['lang']['education_arr'],$fn_xiangqin->setting['lang']['Unlimited'])),'0','mradio');

		showsetting($fn_xiangqin->setting['lang']['family'],array('family',DyadicArray($fn_xiangqin->setting['lang']['family_arr'],$fn_xiangqin->setting['lang']['Unlimited'])),'0','mradio');

		showsetting($fn_xiangqin->setting['lang']['month_income'],array('month_income',DyadicArray($fn_xiangqin->setting['lang']['month_income_arr'],$fn_xiangqin->setting['lang']['Unlimited'])),'0','select');

		showsetting($fn_xiangqin->setting['lang']['nation'],array('nation',DyadicArray($fn_xiangqin->setting['lang']['nation_arr'],$fn_xiangqin->setting['lang']['Unlimited'])),'0','select');

		showsetting($fn_xiangqin->setting['lang']['occupation'],array('occupation',DyadicArray($fn_xiangqin->setting['lang']['occupation_arr'],$fn_xiangqin->setting['lang']['Unlimited'])),'0','select');

		showsetting($fn_xiangqin->setting['lang']['vehicle'],array('vehicle',DyadicArray($fn_xiangqin->setting['lang']['vehicle_arr'],$fn_xiangqin->setting['lang']['Unlimited'])),'0','select');

		showsetting($fn_xiangqin->setting['lang']['house'],array('house',DyadicArray($fn_xiangqin->setting['lang']['house_arr'],$fn_xiangqin->setting['lang']['Unlimited'])),'0','select');

		showsetting($fn_xiangqin->setting['lang']['open_love'],array('open_love',DyadicArray($fn_xiangqin->setting['lang']['open_love_arr'],$fn_xiangqin->setting['lang']['Unlimited'])),'0','mradio');
		
	showtagfooter('div');

	showsubmit('DetailSubmit','&#31435;&#21363;&#23548;&#20986;');
	showtagfooter('div');
	showformfooter(); /*Dism_taobao-com*/
	showtagfooter('div');
}else{
	$html = '<div id="copy_content">';

	if($fn_xiangqin->setting['QrParameterSwitch']){
		@require_once libfile('class/wechat','plugin/fn_assembly');
		$wechatClient = new Fn_WeChatClient($fn_xiangqin->setting['WxAppid'], $fn_xiangqin->setting['WxSecret']);
	}
	if($_GET['export_type'] == 'user'){//��Ա�б�
		$res = C::t('#fn_xiangqin#fn_love_user')->fetch_all_by_list(array('keyword'=>$_GET['keyword'],'display'=>1,'audit_state'=>1,'seal'=>0,'sex'=>$_GET['sex'],'marriage'=>$_GET['marriage'],'education'=>$_GET['education'],'family'=>$_GET['family'],'month_income'=>$_GET['month_income'],'nation'=>$_GET['nation'],'occupation'=>$_GET['occupation'],'vehicle'=>$_GET['vehicle'],'house'=>$_GET['house'],'open_love'=>$_GET['open_love'],'ids'=>$_GET['ids']),$_GET['export_sort'],0,$_GET['export_limit']);
		foreach($res['list'] as $item){
			$item = $fn_xiangqin->getFormUser($item);
			if($fn_xiangqin->setting['QrParameterSwitch']){
				$file = $Config['QrcodePath'].'fn_xiangqin__view_'.$item['id'].'.jpg';
				if(!file_exists($file) || !filesize($file) || (filesize($file) && file_exists($file) && filemtime($file) + 1296000 <= time())) {
					@unlink($file);
					$qrUrl = $wechatClient->getQrcodeImgUrlByTicket($wechatClient->getQrcodeTicket(array('scene_str'=>'fn_xiangqin____view____'.$item['id'],'expire'=>2592000)));
					DownloadImg($qrUrl,$file);
				}
				$qrcode_url = $_G['siteurl'].str_replace(DISCUZ_ROOT,'',$file);
			}else{
				$qrcode_url = $_G['siteurl'].'plugin.php?id=fn_assembly:qrcode&url='.base64_encode($item['url']);
			}
			$html .= str_replace(array('[--qrcode_url--]'),array($qrcode_url),$item['user_wx_temp']);
		}
	}
	if($res['list']){
		$html .= '</div>';
		echo $html;
		exit();
	}else{
		fn_cpmsg('&#26080;&#23548;&#20986;&#20449;&#24687;','','error');
		exit();
	}
	
}
//From: Dism_taobao_com
?>