<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('xiang_all') && !$Fn_Admin->CheckUserGroup('xiangqin_matching_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$Do = in_array($_GET['do'], array('AllDel')) ? $_GET['do'] : 'List';

//�����ֶ�
$SearField =array('page','uid','sex','order');
foreach($SearField as $Val) {
	$SearArray[$Val] = $_GET[$Val] || in_array($_GET[$Val],array('0')) ? $_GET[$Val] : '';
}
//�����ֶ� End

$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeItemUrl'].'&'.http_build_query($SearArray);

if($Do == 'List'){
	if(!submitcheck('Submit')) {
		$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
		/* ��ѯ���� */
		$Where = ' and M.examine = 1 and display = 1';
		$Order = in_array($_GET['order'], array('dateline')) ? 'M.'.addslashes(dhtmlspecialchars($_GET['order'])) : 'M.dateline';

		if($_GET['uid']){
			$UserInfo = $Fn_XiangQin->GetUserInfo($_GET['uid']);
			if(($Fn_Admin->CheckUserGroup('xiang_all') || $UserInfo['mid'] == $_G['uid']) && $UserInfo){
				
				if($UserInfo['condition']['c_min_age'] && $UserInfo['condition']['c_max_age']){
					$Where .= ' and M.age >= '.intval($UserInfo['condition']['c_min_age']).' and M.age <= '.intval($UserInfo['condition']['c_max_age']);
				}

				if($UserInfo['condition']['c_min_height'] && $UserInfo['condition']['c_max_height']){
					$Where .= ' and M.height >= '.intval($UserInfo['condition']['c_min_height']).' and M.height <= '.intval($UserInfo['condition']['c_max_height']);
				}

				if($UserInfo['condition']['c_month_income']){
					$Where .= ' and M.month_income = '.intval($UserInfo['condition']['c_month_income']);
				}

				if($UserInfo['condition']['c_education']){
					$Where .= ' and M.education >= '.intval($UserInfo['condition']['c_education']);
				}

				if($UserInfo['condition']['c_marriage']){
					$Where .= ' and M.marriage = '.intval($UserInfo['condition']['c_marriage']);
				}

				if($UserInfo['condition']['c_ethnic']){
					$Where .= ' and M.ethnic = '.intval($UserInfo['condition']['c_ethnic']);
				}

				if($UserInfo['condition']['c_house'] == 2){
					$Where .= ' and M.house in (2,3)';
				}

				if($UserInfo['condition']['c_vehicle'] == 2){
					$Where .= ' and M.vehicle in (2,3,4)';
				}

				if(!$_GET['sex']){
					$_GET['sex'] = $UserInfo && $UserInfo['sex'] == 1 ? 2 : 1;
				}
			}else{
				unset($UserInfo);
			}

		}

		if(in_array($_GET['sex'],array('1','2'))){
			$Where .= ' and M.sex = '.intval($_GET['sex']);
		}
		
		$Where = preg_replace('/and/','where',$Where,1);
		$Limit = 30;
		$Page = $_GET['page']?intval($_GET['page']):1;
		/* ��ѯ���� End */
		/* ���� */

		$StateSelected = array($_GET['sex']=>' selected');

		echo <<<SEARCH
		<form method="post" autocomplete="off" action="$SearUrl" id="tb_search">
			<div class="FormSearchTo">
				<table cellspacing="4" cellpadding="4">
					<tr>
						<th>{$Fn_XiangQin->Config['LangVar']['MatchingTitle']}UID</th><td><input type="text" class="form-control w150" name="uid" value="{$_GET['uid']}">
						</td>
						<th>{$Fn_XiangQin->Config['LangVar']['SexTitle']}</th><td>
						<select name="sex" class="form-control w120">
							<option value="">{$Fn_XiangQin->Config['LangVar']['SelectNull']}</option>
							<option value="1"{$StateSelected['1']}>{$Fn_XiangQin->Config['LangVar']['SexArray']['1']}</option>
							<option value="2"{$StateSelected['2']}>{$Fn_XiangQin->Config['LangVar']['SexArray']['2']}</option>
						</select>
						&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Admin->Config['LangVar']['SearchSubmit']}" class="btn btn-info" type="submit">
						</td>
					</tr>
				</table>
			</div>
		</form>
SEARCH;
		/* ���� End */

		/* ģ����� */		
		
		if(($Fn_Admin->CheckUserGroup('xiang_all') || $UserInfo['mid'] == $_G['uid']) && $UserInfo){
			$ModulesList = GetModulesList($Page,$Limit,$Where,$Order);
			$Html = '<div class="XiangQinList"><ul>';
			foreach ($ModulesList as $Module) {
				$Module['param'] = unserialize($Module['param']);
				$SexHtml = $Module['sex'] == 1 ? '&#xe628;' : '&#xe616;';
				$TopHtml = time() < $Module['top_dateline'] ? '<img src="'.$Fn_XiangQin->Config['StaticPath'].'/images/d.png">' : '';
				$VipHtml = time() < $Module['vip_time'] ? '<img src="'.$Fn_XiangQin->Config['StaticPath'].'/images/vip.png">' : '';
				$VHtml =  $Module['param']['identity'] ? '<img src="'.$Fn_XiangQin->Config['StaticPath'].'/images/v.png">' : '';
				$HouseHtml = in_array($Module['house'],array(2,3)) ? '<img src="'.$Fn_XiangQin->Config['StaticPath'].'/images/f.png">' : '';
				$VehicleHtml = in_array($Module['vehicle'],array(2,3,4)) ? '<img src="'.$Fn_XiangQin->Config['StaticPath'].'/images/c.png">' : '';
				
				$Html .= '<li><a href="'.$Fn_XiangQin->Config['HeUserUrl'].$Module['uid'].'" target="_blank"><div class="Face"><div class="ImgBg" style="background:url('.$Module['face'].') no-repeat center;background-size:cover;"></div></div><div class="NameSexAgeSalary"> <span class="Name">'.$Module['name'].'</span> <span class="Sex Sex'.$Module['sex'].' ic">'.$SexHtml.'</span><div class="AgeSalary"> <span class="Age ColorRed">'.$Module['age'].$Fn_XiangQin->Config['LangVar']['Sui'].'</span> <span class="ColorRed">'.$Fn_XiangQin->Config['LangVar']['MonthIncomeArray'][$Module['month_income']].'/'.$Fn_XiangQin->Config['LangVar']['Month'].'</span> </div></div><div class="Ico">'.$TopHtml.$VipHtml.$VHtml.$HouseHtml.$VehicleHtml.'<img src="'.$Fn_XiangQin->Config['StaticPath'].'/images/s.png"></div></a><a href="'.$Fn_XiangQin->Config['CardUrl'].'&user_id='.$Module['uid'].'" target="_blank" class="Card">'.$Fn_XiangQin->Config['LangVar']['MatchmakingCard'].'</a></li>';
			}
			$Html .= '</ul><div class="both"></div></div>';
			echo $Html.'<div class="ListPage">'.multi(GetModulesCount($Where),$Limit,$Page,$MpUrl).'</div>';
		}
		/* ģ����� End */
	}
}

/* �б� */
function GetModulesList($Page,$Limit,$Where=null,$Order){
	global $Fn_XiangQin;
	$FetchSql = 'SELECT M.* FROM '.DB::table($Fn_XiangQin->TableMember).' M '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}

/* ���� */
function GetModulesCount($Where=null){
	global $Fn_XiangQin;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_XiangQin->TableMember).' M '.$Where;
	return DB::result_first($FetchSql);//��������
}
//From: Dism_taobao_com
?>