<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('xiangqin_all') && !$Fn_Admin->CheckUserGroup('xiangqin_mat_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$SubModel = in_array($_GET['submodel'], array('list','add')) ? $_GET['submodel'] : 'list';
$Fn_Admin->Config['IframeSubModelUrl'] = $Fn_Admin->Config['IframeItemUrl'].'&submodel='.$SubModel;
$NavClass = array($SubModel=>'btn-info Hover');

//����
echo <<<Nav
<div class="SubModelNav">
  <ul>
	<li class="{$NavClass['list']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=list" target="_self">{$Fn_Admin->Config['LangVar']['XiangqinLeftNavArray'][$_GET['item']]}</a></li>
    <li class="{$NavClass['add']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=add" target="_self">{$Fn_Admin->Config['LangVar']['AddEditTitle']}</a></li>
  </ul>
  <div class="both"></div>
</div>
Nav;

if($SubModel == 'list'){//�б�
	$Do = in_array($_GET['do'], array('Del')) ? $_GET['do'] : 'submodel_list';
	$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeSubModelUrl'].'&'.http_build_query($SearArray);
	if($Do == 'submodel_list'){
		if(!submitcheck('Submit')) {
			$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
			$page = $_GET['page'] ? $_GET['page'] : 0;
			$res = C::t('#fn_xiangqin#fn_love_mat')->fetch_all_by_list();
			/* ��ѯ���� End */

			/* ģ����� */	
			showtagheader('div', 'row', true,'row');
			showtagheader('div', 'col-12', true,'col-12');
			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-body', true,'box-body');
			showtagheader('div', 'table-responsive', true,'table-responsive');
			showformheader($FormUrl,'enctype="multipart/form-data"');
			showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
			showsubtitle(array(
				'ID',
				'&#32465;&#23450;&#85;&#73;&#68;',
				'openid',
				'&#21517;&#31216;',
				'&#24494;&#20449;&#21495;',
				'&#20108;&#32500;&#30721;',
				'&#26381;&#21153;&#20154;&#25968;',
				$fn_xiangqin->setting['lang']['DisplayOrder'],
				$fn_xiangqin->setting['lang']['DisplayTitle'],
				$fn_xiangqin->setting['lang']['OperationTitle']
			),'header tbm tc');

			foreach ($res as $item) {
				$qrcode_url = $_G['siteurl'].'plugin.php?id=fn_assembly:qrcode&url='.base64_encode($_G['siteurl'].'plugin.php?id=fn_xiangqin:mat_openid&mat_id='.$item['id']);
				showtablerow('', array('class="tc w50"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
					$item['id'],
					$item['uid'],
					$item['openid'].'<div data-container="body" data-toggle="popover" data-trigger="hover" data-placement="top" data-html="true" data-content="<img src='.$qrcode_url.'><div class=text-center>&#25195;&#30721;&#32465;&#23450;</div>">[&#32465;&#23450;]</div>',
					$item['name'],
					$item['wx'],
					$item['qrcode'] ? '<img src="'.$item['qrcode'].'" style="height:40px;">' : '',
					'<a href="'.$Fn_Admin->Config['IframeModUrl'].'&item=user_list&mat_id='.$item['id'].'">'.C::t('#fn_xiangqin#fn_love_user')->first_by_count(' where u.mat_id = '.intval($item['id']))."</a>",
					$item['displayorder'],
					!$item['display'] ? '<span class="label bg-secondary">'.$fn_xiangqin->setting['lang']['No'].'</span>' : '<span class="label bg-blue">'.$fn_xiangqin->setting['lang']['Yes'].'</span>',
					'<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&aid='.$item['id'].'" class="btn btn-sm btn-info-outline">'.$fn_xiangqin->setting['lang']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Del&aid='.$item['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$fn_xiangqin->setting['lang']['DelTitle'].'</a>',
				));
			}

			showtablefooter(); /*dism��taobao��com*/
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			/* ģ�����End */	
		}
	}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['aid']){
		$id = intval($_GET['aid']);
		C::t('#fn_xiangqin#fn_love_mat')->delete_by_id($id);
		$fn_xiangqin->getCheckMat();
		fn_cpmsg($fn_xiangqin->setting['lang']['DelOk'],$CpMsgUrl,'succeed');
		exit();
	}
}else if($SubModel == 'add'){//���ӻ�༭

	$id = intval($_GET['aid']);
	
	$item = C::t('#fn_xiangqin#fn_love_mat')->fetch_by_id($id);

	if(!submitcheck('DetailSubmit')) {
		$opTitle = $fn_xiangqin->setting['lang']['AddTitle'];
		if($item){
			$opTitle = $fn_xiangqin->setting['lang']['EditTitle'];
		}
		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-header', true,'with-border box-header');
		showtitle($opTitle,'class="box-title"');
		showtagfooter('div');
		showformheader($Fn_Admin->Config['IframeSubModelUrl'].'&aid='.$id,'enctype');
		showtagheader('div', 'box-body', true,'box-body');
		showsetting('uid', 'new_uid', $item['uid'], 'text');
		showsetting('&#22995;&#21517;', 'name', $item['name'], 'text');
		showsetting('&#24494;&#20449;&#21495;', 'wx', $item['wx'], 'text');
		$qrcode_html = ($item['qrcode'] ? '<a href="'.$item['qrcode'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$item['qrcode'].'" height="55"/></a>' : '').'';
		showsetting('&#20108;&#32500;&#30721;', 'new_qrcode',$item['qrcode'], 'filetext', '', 0, $qrcode_html);
		$head_portrait_html = ($item['head_portrait'] ? '<a href="'.$item['head_portrait'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$item['head_portrait'].'" height="55"/></a>' : '').'';
		showsetting('&#22836;&#20687;', 'new_head_portrait',$item['head_portrait'], 'filetext', '', 0, $head_portrait_html);
		showsetting($fn_xiangqin->setting['lang']['DisplayOrder'], 'displayorder', $item['displayorder'], 'text');
		showsetting($fn_xiangqin->setting['lang']['DisplayTitle'], 'display', $item ? $item['display'] : 1, 'radio');

		showsubmit('DetailSubmit','&#20445;&#23384;&#37197;&#32622;');
		showtagfooter('div');
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');

	}else{
		$data['uid'] = intval($_GET['new_uid']);
		$data['name'] = addslashes(strip_tags($_GET['name']));
		$data['wx'] = addslashes(strip_tags($_GET['wx']));
		$data['display'] = intval($_GET['display']);
		$data['displayorder'] = intval($_GET['displayorder']);
		$data = array_merge($data,$Fn_Admin->uploadFiles($_FILES));
		if($item){
			C::t('#fn_xiangqin#fn_love_mat')->update($data,$id);
		}else{
			$id = C::t('#fn_xiangqin#fn_love_mat')->insert($data);
		}
		$fn_xiangqin->getCheckMat();
		fn_cpmsg($fn_xiangqin->setting['lang']['UpdateOk'],$Fn_Admin->Config['IframeItemUrl'].'&submodel=list','succeed');
		exit();
	}
}
//From: Dism_taobao_com
?>