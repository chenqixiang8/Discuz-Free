<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('xiang_all') && !$Fn_Admin->CheckUserGroup('xiangqin_authentication_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$SubModel = in_array($_GET['submodel'], array('list','add')) ? $_GET['submodel'] : 'list';
$Fn_Admin->Config['IframeSubModelUrl'] = $Fn_Admin->Config['IframeItemUrl'].'&submodel='.$SubModel;
$NavClass = array($SubModel=>'btn-info Hover');

//����
echo <<<Nav
<div class="SubModelNav">
  <ul>
	<li class="{$NavClass['list']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=list" target="_self">{$Fn_Admin->Config['LangVar']['XiangqinLeftNavArray']['authentication_list']}</a></li>
    <li class="{$NavClass['add']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=add" target="_self">{$Fn_Admin->Config['LangVar']['AddEditTitle']}</a></li>
  </ul>
  <div class="both"></div>
</div>
Nav;

if($SubModel == 'list'){//�б�
	$Do = in_array($_GET['do'], array('Del')) ? $_GET['do'] : 'submodel_list';
	//�����ֶ�
	$SearField =array('page','keyword','examine');
	foreach($SearField as $Val) {
		$SearArray[$Val] = $_GET[$Val] || in_array($_GET[$Val],array('0')) ? $_GET[$Val] : '';
	}
	//�����ֶ� End
	$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeSubModelUrl'].'&'.http_build_query($SearArray);


	if($Do == 'submodel_list'){
		if(!submitcheck('Submit')) {
			$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
			$Where = '';
			$Order = in_array($_GET['order'], array('id')) ? 'A.'.addslashes(dhtmlspecialchars($_GET['order'])) : 'A.updateline';
			
			if($_GET['keyword']){
				$_GET['keyword'] = str_replace(array('%','_'),array('',''),$_GET['keyword']);
				$Where .= ' and (A.username like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or A.uid = '.intval($_GET['keyword']).' )';
			}
			
			if(in_array($_GET['examine'],array('0','1','2'))){
				$Where .= ' and A.examine = '.intval($_GET['examine']);
			}

			$Where = preg_replace('/and/','where',$Where,1);
			$Limit = 20;
			$Page = $_GET['page']?intval($_GET['page']):1;
			/* ��ѯ���� End */

			/* ģ����� */	
			showtagheader('div', 'row', true,'row');
			showtagheader('div', 'col-12', true,'col-12');
			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-body', true,'box-body');
			/* ���� */
			$ExamineSelected = array($_GET['examine']=>' selected');
			echo <<<SEARCH
			<form method="post" autocomplete="off" action="$SearUrl">
				<div class="FormSearchTo" style="margin-bottom:0;">
					<table cellspacing="4" cellpadding="4">
						<tr>
							<th>{$Fn_XiangQin->Config['LangVar']['KeywordTitle']}</th><td><input type="text" class="form-control w200" name="keyword" value="{$_GET['keyword']}">
							</td>
							<th>{$Fn_XiangQin->Config['LangVar']['ExamineState']}</th><td>
							<select name="examine" class="form-control w120">
								<option value="">{$Fn_XiangQin->Config['LangVar']['SelectNull']}</option>
								<option value="0"{$ExamineSelected['0']}>{$Fn_XiangQin->Config['LangVar']['AuthenticationExamineArray'][0]}</option>
								<option value="1"{$ExamineSelected['1']}>{$Fn_XiangQin->Config['LangVar']['AuthenticationExamineArray'][1]}</option>
								<option value="2"{$ExamineSelected['2']}>{$Fn_XiangQin->Config['LangVar']['AuthenticationExamineArray'][2]}</option>
							</select>
							&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Admin->Config['LangVar']['SearchSubmit']}" class="btn btn-info" type="submit">
							</td>
						</tr>
					</table>
				</div>
			</form>
SEARCH;
			/* ���� End */
			showtagheader('div', 'table-responsive', true,'table-responsive');
			showformheader($FormUrl,'enctype="multipart/form-data"');
			showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
			showsubtitle(array(
				'ID',
				'UID/'.$Fn_XiangQin->Config['LangVar']['UserNameTitle'],
				$Fn_XiangQin->Config['LangVar']['AuthenticationJust'],
				$Fn_XiangQin->Config['LangVar']['AuthenticationBack'],
				$Fn_XiangQin->Config['LangVar']['AuthenticationHold'],
				$Fn_XiangQin->Config['LangVar']['RealName'],
				$Fn_XiangQin->Config['LangVar']['IDNumber'],
				$Fn_XiangQin->Config['LangVar']['MobileTitle'],
				$Fn_XiangQin->Config['LangVar']['StateTitle'],
				$Fn_XiangQin->Config['LangVar']['TimeTitle'],
				$Fn_XiangQin->Config['LangVar']['UpdateTime'],
				$Fn_XiangQin->Config['LangVar']['OperationTitle']
			),'header tbm tc');

			$ModulesList = GetModulesList($Page,$Limit,$Where,$Order);
			foreach ($ModulesList as $Module) {
				showtablerow('', array('class="tc w100"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
					'<input type="checkbox" class="filled-in" id="checkbox_'.$Module['uid'].'" name="delete[]" value="'.$Module['uid'].'"><label for="checkbox_'.$Module['uid'].'"></label>',
					$Module['uid'].'/'.$Module['username'].'&nbsp;&nbsp;<a href="'.$Fn_XiangQin->Config['HeUserUrl'].$Module['uid'].'" target="_blank">['.cplang('view').']</a>',
					$Module['just'] ? '<div class="UserLoadFace"><img src="'.$Module['just'].'" height="30"><div class="BigFace" style="background:url('.$Module['just'].') no-repeat center;background-size:cover;"></div></div>' : '',
					$Module['back'] ? '<div class="UserLoadFace"><img src="'.$Module['back'].'" height="30"><div class="BigFace" style="background:url('.$Module['back'].') no-repeat center;background-size:cover;"></div></div>' : '',
					$Module['hold'] ? '<div class="UserLoadFace"><img src="'.$Module['hold'].'" height="30"><div class="BigFace" style="background:url('.$Module['hold'].') no-repeat center;background-size:cover;"></div></div>' : '',
					$Module['full_name'],
					$Module['id_number'],
					$Module['mobile'],
					$Fn_XiangQin->Config['LangVar']['AuthenticationExamineArray'][$Module['examine']],
					date('Y-m-d H:i',$Module['dateline']),
					date('Y-m-d H:i',$Module['updateline']),
					'<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&auid='.$Module['uid'].'" class="btn btn-sm btn-info-outline">'.$Fn_XiangQin->Config['LangVar']['EditTitle'].'</a>'.($Module['identity'] != 1 ? '&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Del&auid='.$Module['uid'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$Fn_XiangQin->Config['LangVar']['DelTitle'].'</a>' : ''),
				));
			}

			/* �ܾ�����Html */
			$RefusalHtml = '<select name="refusal" class="form-control w120"><option value="">'.$Fn_XiangQin->Config['LangVar']['SelectNull'].'</option>';
			foreach ($Fn_XiangQin->AuthenticationExamineTwoList as $Val) {
				$RefusalHtml .= '<option value="'.$Val.'">'.$Val.'</option>';
			}
			$RefusalHtml .= '</select>';
			/* �ܾ�����Html End*/

			showsubmit('Submit','&#31435;&#21363;&#25552;&#20132;','<input name="optype" value="Del" class="with-gap" type="radio" id="v_Del"><label class="custom-control-label" for="v_Del" style="margin-left:-5px;">'.$Fn_XiangQin->Config['LangVar']['DelTitle'].'</label>&nbsp;&nbsp;&nbsp;&nbsp;<input name="optype" value="Examine" class="with-gap" type="radio" id="v_Examine"><label class="custom-control-label" for="v_Examine" style="margin-left:-5px;">'.$Fn_XiangQin->Config['LangVar']['ExamineState'].'</label>&nbsp;<select name="examinenew" class="form-control w120"><option value="">'.$Fn_XiangQin->Config['LangVar']['SelectNull'].'</option><option value="0">'.$Fn_XiangQin->Config['LangVar']['AuthenticationExamineArray'][0].'</option><option value="1">'.$Fn_XiangQin->Config['LangVar']['AuthenticationExamineArray'][1].'</option><option value="2">'.$Fn_XiangQin->Config['LangVar']['AuthenticationExamineArray'][2].'</option></select>&nbsp;'.$Fn_XiangQin->Config['LangVar']['RefusalTitle'].'&nbsp;'.$RefusalHtml,'','select_all',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));

			showtablefooter(); /*dism��taobao��com*/
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');

			echo '<style>#Module .td25{width:auto;}.UserLoadFace{position:relative;cursor:pointer;}.UserLoadFace .BigFace{position:absolute;right:-400px;top:-170px;width:500px;height:350px;z-index:5;display:none;}</style><script> var disallowfloat = "'.$_G['setting']['disallowfloat'].';</script><script src="'.$Fn_Admin->Config['StaticPath'].'/js/jquery.js"></script>
			<script>
			jQuery.noConflict();
			$(".UserLoadFace").hover(function(){
				$(this).find(".BigFace").show();
			},
			
			function(){
				$(this).find(".BigFace").hide();
			});
			
			</script>';
			/* ģ�����End */	
		}else{
			

			if(isset($_GET['delete']) && is_array($_GET['delete'])){
				if($_GET['optype'] == 'Del'){//ȫɾ
					
					if(!$Fn_Admin->CheckUserGroup('xiang_all') && !$Fn_Admin->CheckUserGroup('xiangqin_authentication_del')){//Ȩ���ж�
						fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
						exit();
					}

					foreach($_GET['delete'] as $Key => $Val) {
						$Val = intval($Val);
						DB::delete($Fn_XiangQin->TableAuthentication,'uid ='.$Val);
				
					}

					GetInsertDoLog('del_authentication_list_xiangqin','fn_'.$_GET['mod'],array('uids'=>implode(',',$_GET['delete'])));//������¼

					fn_cpmsg($Fn_XiangQin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
				}else if($_GET['optype'] == 'Examine' && $_GET['examinenew']){//���״̬
					foreach($_GET['delete'] as $Key => $Val) {
						$Val = intval($Val);
						if($_GET['examinenew'] == 2){//�ܾ�����
							$UpData['reason'] = addslashes(strip_tags($_GET['refusal']));
						}
						if(in_array($_GET['examinenew'],array('1','2'))){
							$Fn_XiangQin->GetAuthenticationExaminePush($Val,$_GET['examinenew'],$_GET['refusal']);//��Ϣ����
						}
						$UpData['examine'] = intval($_GET['examinenew']);
						
						DB::update($Fn_XiangQin->TableAuthentication,$UpData,'uid = '.$Val);
					}
					
					GetInsertDoLog('examine_authentication_xiangqin','fn_'.$_GET['mod'],array('uids'=>implode(',',$_GET['delete']),'examine'=>$_GET['examinenew']));//������¼

					fn_cpmsg($Fn_XiangQin->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
				}else{
					fn_cpmsg($Fn_XiangQin->Config['LangVar']['OpErr'],'','error');
				}
			}else{
				fn_cpmsg($Fn_XiangQin->Config['LangVar']['OpErr'],'','error');
			}
				
		}
	}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['auid']){
		if(!$Fn_Admin->CheckUserGroup('xiang_all') && !$Fn_Admin->CheckUserGroup('xiangqin_authentication_del')){//Ȩ���ж�
			fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
			exit();
		}
		$AUid = intval($_GET['auid']);
	
		DB::delete($Fn_XiangQin->TableAuthentication,'uid ='.$AUid);

		GetInsertDoLog('del_authentication_list_xiangqin','fn_'.$_GET['mod'],array('uid'=>$AUid));//������¼

		fn_cpmsg($Fn_Admin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
	}
}else if($SubModel == 'add'){//���ӻ�༭

	$AUid = intval($_GET['auid']);

	$Item = DB::fetch_first('SELECT * FROM '.DB::table($Fn_XiangQin->TableAuthentication).' where uid = '.$AUid);

	if(!submitcheck('DetailSubmit')) {
		$OpTitle = $Fn_XiangQin->Config['LangVar']['AddTitle'];
		if($Item){
			$OpTitle = $Fn_XiangQin->Config['LangVar']['EditTitle'];
		}
		
		//ͼƬ�ϴ�
		if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_assembly/class/class_upload.php')){
			@require_once libfile('class/upload','plugin/fn_assembly');
			$UploadConfig = fn_upload::Config();
		}
		
		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-header', true,'with-border box-header');
		showtitle($OpTitle,'class="box-title"');
		showtagfooter('div');
		showformheader($Fn_Admin->Config['IframeSubModelUrl'].'&auid='.$AUid,'enctype');
		showtagheader('div', 'box-body', true,'box-body');
		
		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_XiangQin->Config['LangVar']['AuthenticationJust'].'</label><div class="col-sm-9"><div class="AdminSingleUpload"><div class="PhotoControl" id="JustPhotoControl"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';

		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_XiangQin->Config['LangVar']['AuthenticationBack'].'</label><div class="col-sm-9"><div class="AdminSingleUpload"><div class="PhotoControl" id="BackPhotoControl"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';

		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_XiangQin->Config['LangVar']['AuthenticationHold'].'</label><div class="col-sm-9"><div class="AdminSingleUpload"><div class="PhotoControl" id="HoldPhotoControl"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';

		showsetting($Fn_XiangQin->Config['LangVar']['RealName'], 'full_name', $Item['full_name'], 'text');
		showsetting($Fn_XiangQin->Config['LangVar']['IDNumber'], 'id_number', $Item['id_number'], 'text');
		showsetting($Fn_XiangQin->Config['LangVar']['MobileTitle'], 'mobile', $Item['mobile'], 'text');


		if(!$Item){
			showsetting('uid', 'uid', $Item['uid'], 'text');
		}

		showsetting($Fn_XiangQin->Config['LangVar']['StateTitle'],array('examine',DyadicArray($Fn_XiangQin->Config['LangVar']['AuthenticationExamineArray'])),$Item ? $Item['examine'] : 1,'mradio');

				
		if($Item['dateline']){
			showsetting($Fn_XiangQin->Config['LangVar']['TimeTitle'], 'dateline',date('Y-m-d H:i',$Item['dateline']), 'calendar','','','',1);
		}
		
		showsubmit('DetailSubmit','&#20445;&#23384;&#37197;&#32622;');
		showtagfooter('div');
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');

		$UpLoadHtml  = '';
		if($Item['just']){
			$JustJsArray[] = '"'.$Item['just'].'"';;
			$UpLoadHtml .= '
			var InputArray = new Array('.implode(',',$JustJsArray).');
			$("#JustPhotoControl").AppUpload({InputName:"new_just",Multiple:true,InputExist:true,InputArray:InputArray});';

		}else{
			$UpLoadHtml .= '$("#JustPhotoControl").AppUpload({InputName:"new_just",Multiple:true});';
		}

		if($Item['back']){
			$BackJsArray[] = '"'.$Item['back'].'"';;
			$UpLoadHtml .= '
			var InputArray = new Array('.implode(',',$BackJsArray).');
			$("#BackPhotoControl").AppUpload({InputName:"new_back",Multiple:true,InputExist:true,InputArray:InputArray});';

		}else{
			$UpLoadHtml .= '$("#BackPhotoControl").AppUpload({InputName:"new_back",Multiple:true});';
		}

		if($Item['hold']){
			$HoldJsArray[] = '"'.$Item['hold'].'"';;
			$UpLoadHtml .= '
			var InputArray = new Array('.implode(',',$HoldJsArray).');
			$("#HoldPhotoControl").AppUpload({InputName:"new_hold",Multiple:true,InputExist:true,InputArray:InputArray});';

		}else{
			$UpLoadHtml .= '$("#HoldPhotoControl").AppUpload({InputName:"new_hold",Multiple:true});';
		}

		echo $UploadConfig['CssJsHtml'].'<script>'.$UpLoadHtml.'</script>';

	}else{
		if(!$Item){
			$Data['uid'] = intval($_GET['uid']);
			$Member = DB::fetch_first('SELECT username FROM '.DB::table('common_member').' where uid = '.$Data['uid']);
			$Data['username'] = addslashes(strip_tags($Member['username']));
		}

		foreach($_GET['new_just'] as $Key => $Val) {
			$_GET['new_just'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}

		foreach($_GET['new_back'] as $Key => $Val) {
			$_GET['new_back'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}

		foreach($_GET['new_hold'] as $Key => $Val) {
			$_GET['new_hold'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}

		$Data['just'] = addslashes(strip_tags($_GET['new_just'][0]));
		$Data['back'] = addslashes(strip_tags($_GET['new_back'][0]));
		$Data['hold'] = addslashes(strip_tags($_GET['new_hold'][0]));
		$Data['full_name'] = addslashes(strip_tags($_GET['full_name']));
		$Data['id_number'] = addslashes(strip_tags($_GET['id_number']));
		$Data['mobile'] = addslashes(strip_tags($_GET['mobile']));
		$Data['examine'] = intval($_GET['examine']);

		if($Member || $Item){
			if($Item){
				$Data['updateline'] = time();
				$Data['dateline'] = strtotime($_GET['dateline']);
				GetInsertDoLog('edit_authentication_xiangqin','fn_'.$_GET['mod'],array('id'=>$AUid));//������¼
				DB::update($Fn_XiangQin->TableAuthentication,$Data,'uid = '.$AUid);
			}else{
				$Data['dateline'] = $Data['updateline'] = time();
				$Id = DB::insert($Fn_XiangQin->TableAuthentication,$Data,true);
				GetInsertDoLog('add_authentication_xiangqin','fn_'.$_GET['mod'],array('id'=>$Id));//������¼
			}
			fn_cpmsg($Fn_XiangQin->Config['LangVar']['UpdateOk'],$Fn_Admin->Config['IframeItemUrl'].'&submodel=list','succeed');
		}else{
			fn_cpmsg($Fn_XiangQin->Config['LangVar']['NoUserErr'],'','error');
			exit();
		}
	}
}


/* �б� */
function GetModulesList($Page,$Limit,$Where=null,$Order){
	global $Fn_XiangQin;
	$FetchSql = 'SELECT A.* FROM '.DB::table($Fn_XiangQin->TableAuthentication).' A '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}

/* ���� */
function GetModulesCount($Where=null){
	global $Fn_XiangQin;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_XiangQin->TableAuthentication).' A '.$Where;
	return DB::result_first($FetchSql);//��������
}

?>