<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('xiangqin_all') && !$Fn_Admin->CheckUserGroup('xiangqin_user_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$SubModel = in_array($_GET['submodel'], array('list','add')) ? $_GET['submodel'] : 'list';
$Fn_Admin->Config['IframeSubModelUrl'] = $Fn_Admin->Config['IframeItemUrl'].'&submodel='.$SubModel;
$NavClass = array($SubModel=>'btn-info Hover');

//����
echo <<<Nav
<div class="SubModelNav">
  <ul>
	<li class="{$NavClass['list']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=list" target="_self">{$Fn_Admin->Config['LangVar']['XiangqinLeftNavArray'][$_GET['item']]}</a></li>
    <li class="{$NavClass['add']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=add" target="_self">{$Fn_Admin->Config['LangVar']['AddEditTitle']}</a></li>
  </ul>
  <div class="both"></div>
</div>
Nav;

if($SubModel == 'list'){//�б�
	$Do = in_array($_GET['do'], array('del','display','hot','seal','crm')) ? $_GET['do'] : 'submodel_list';
	//�����ֶ�
	$SearField =array('page','keyword','display','audit_state','group_id','order','seal','hot','channel','sex','marriage','month_income','vid','uid','open_contact','open_love','mat_id','is_vip','expired','age_max','age_min');
	foreach($SearField as $Val) {
		$SearArray[$Val] = $_GET[$Val] || in_array($_GET[$Val],array('0')) ? $_GET[$Val] : '';
	}
	//�����ֶ� End
	$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeSubModelUrl'].'&'.http_build_query($SearArray);


	if($Do == 'submodel_list'){
		if(!submitcheck('Submit')) {

			$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
			$page = $_GET['page'] ? $_GET['page'] : 0;
			$res = C::t('#fn_xiangqin#fn_love_user')->fetch_all_by_list(array('keyword'=>$_GET['keyword'],'audit_state'=>$_GET['audit_state'],'display'=>$_GET['display'],'group_id'=>$_GET['group_id'],'seal'=>$_GET['seal'],'channel'=>$_GET['channel'],'hot'=>$_GET['hot'],'sex'=>$_GET['sex'],'marriage'=>$_GET['marriage'],'month_income'=>$_GET['month_income'],'vid'=>$_GET['vid'],'uid'=>$_GET['uid'],'open_contact'=>$_GET['open_contact'],'open_love'=>$_GET['open_love'],'mat_id'=>$_GET['mat_id'],'is_vip'=>$_GET['is_vip'],'expired'=>$_GET['expired'],'age_max'=>$_GET['age_max'],'age_min'=>$_GET['age_min']),$_GET['order'],$page - 1,20,true,'','');
			
			/* ��ѯ���� End */
	
			/* ģ����� */	
			showtagheader('div', 'row', true,'row');
			showtagheader('div', 'col-12', true,'col-12');
			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-body', true,'box-body');
			/* ���� */
			$DisplaySelected = array($_GET['display']=>' selected');
			$hotSelected = array($_GET['hot']=>' selected');
			$sealSelected = array($_GET['seal']=>' selected');
			$audit_state_selected = array($_GET['audit_state']=>' selected');
			$OrderSelected = array($_GET['order']=>' selected');
			$vipSelected = array($_GET['is_vip']=>' selected');	
			$expiredSelected = array($_GET['expired']=>' selected');

			$sex_list_option = '<option value="">'.$fn_xiangqin->setting['lang']['SelectNull'].'</option>';
			foreach($fn_xiangqin->setting['lang']['sex_arr'] as $key => $val) {
				$sex_list_option .= '<option value="'. $key.'" '.($_GET['sex'] ==  $key ? ' selected' : '' ).'>'.$val.'</option>';
			}

			$marriage_list_option = '<option value="">'.$fn_xiangqin->setting['lang']['SelectNull'].'</option>';
			foreach($fn_xiangqin->setting['lang']['marriage_arr'] as $key => $val) {
				$marriage_list_option .= '<option value="'. $key.'" '.($_GET['marriage'] ==  $key ? ' selected' : '' ).'>'.$val.'</option>';
			}

			$month_income_list_option = '<option value="">'.$fn_xiangqin->setting['lang']['SelectNull'].'</option>';
			foreach($fn_xiangqin->setting['lang']['month_income_arr'] as $key => $val) {
				$month_income_list_option .= '<option value="'. $key.'" '.($_GET['month_income'] ==  $key ? ' selected' : '' ).'>'.$val.'</option>';
			}
			
			$channel_list_option = '<option value="">'.$fn_xiangqin->setting['lang']['SelectNull'].'</option>';
			foreach($fn_xiangqin->setting['lang']['channel_arr'] as $key => $val) {
				$channel_list_option .= '<option value="'. $key.'" '.($_GET['channel'] ==  $key ? ' selected' : '' ).'>'.$val.'</option>';
			}

			$open_contact_list_option = '<option value="">'.$fn_xiangqin->setting['lang']['SelectNull'].'</option>';
			foreach($fn_xiangqin->setting['lang']['open_contact_arr'] as $key => $val) {
				$open_contact_list_option .= '<option value="'. $key.'" '.($_GET['open_contact'] ==  $key ? ' selected' : '' ).'>'.$val.'</option>';
			}

			$open_love_list_option = '<option value="">'.$fn_xiangqin->setting['lang']['SelectNull'].'</option>';
			foreach($fn_xiangqin->setting['lang']['open_love_arr'] as $key => $val) {
				$open_love_list_option .= '<option value="'. $key.'" '.($_GET['open_love'] ==  $key ? ' selected' : '' ).'>'.$val.'</option>';
			}

			$groupListOption = '<option value="">'.$fn_xiangqin->setting['lang']['SelectNull'].'</option>';
			foreach(C::t('#fn_xiangqin#fn_love_meal')->fetch_all_by_list(array('type'=>1)) as $val) {
				$groupListOption .= '<option value="'.$val['id'].'" '.($_GET['group_id'] == $val['id'] ? ' selected' : '' ).'>'.$val['title'].'</option>';
			}

			$matListOption = '<option value="">'.$fn_xiangqin->setting['lang']['SelectNull'].'</option>';
			foreach($fn_xiangqin->matList as $val) {
				$matListOption .= '<option value="'.$val['id'].'" '.($_GET['mat_id'] == $val['id'] ? ' selected' : '' ).'>'.$val['name'].'</option>';
			}

			echo <<<SEARCH
			<form method="post" autocomplete="off" action="$SearUrl">
				<div class="FormSearchTo" style="margin-bottom:0;">
					<table cellspacing="4" cellpadding="4">
						<tr>
							<th>&#20851;&#38190;&#35789;</th><td colspan="10"><input type="text" class="input form-control w150" name="keyword" value="{$_GET['keyword']}" placeholder="&#35831;&#36755;&#20837;&#22995;&#21517;&#47;&#25163;&#26426;&#21495;">&nbsp;&nbsp;&nbsp;&nbsp;&#29992;&#25143;&#73;&#68;&nbsp;&nbsp;<input type="text" class="input form-control w100" name="vid" value="{$_GET['vid']}" placeholder="&#36755;&#20837;&#29992;&#25143;&#73;&#68;">&nbsp;&nbsp;&nbsp;&nbsp;&#29992;&#25143;&#85;&#73;&#68;&nbsp;&nbsp;<input type="text" class="input form-control w100" name="uid" value="{$_GET['uid']}" placeholder="&#36755;&#20837;&#29992;&#25143;&#85;&#73;&#68;">&nbsp;&nbsp;&nbsp;&nbsp;&#24180;&#40836;&nbsp;&nbsp;<input type="text" class="input form-control w80" name="age_min" value="{$_GET['age_min']}" placeholder="&#26368;&#23567;&#24180;&#40836;"> &#8212; <input type="text" class="input form-control w80" name="age_max" value="{$_GET['age_max']}" placeholder="&#26368;&#22823;&#24180;&#40836;">
							</td>
						</tr>
						<tr>

							<th>{$fn_xiangqin->setting['lang']['sex']}</th><td>
							<select name="sex" class="form-control w120">
								{$sex_list_option}
							</select>
							</td>
							<th>{$fn_xiangqin->setting['lang']['marriage']}</th><td>
							<select name="marriage" class="form-control w120">
								{$marriage_list_option}
							</select>
							</td>
							<th>{$fn_xiangqin->setting['lang']['month_income']}</th><td>
							<select name="month_income" class="form-control w120">
								{$month_income_list_option}
							</select>
							</td>
							<th>{$fn_xiangqin->setting['lang']['open_contact']}</th><td>
							<select name="open_contact" class="form-control w120">
								{$open_contact_list_option}
							</select>
							</td>
						</tr>
						<tr>

							<th>&#26159;&#21542;&#26174;&#31034;</th><td>
							<select name="display" class="form-control w120">
								<option value="">{$fn_xiangqin->setting['lang']['SelectNull']}</option>
								<option value="1"{$DisplaySelected['1']}>{$fn_xiangqin->setting['lang']['Yes']}</option>
								<option value="0"{$DisplaySelected['0']}>{$fn_xiangqin->setting['lang']['No']}</option>
							</select>
							</td>
							<th>&#23457;&#26680;&#29366;&#24577;</th><td>
							<select name="audit_state" class="form-control w120">
								<option value="">{$fn_xiangqin->setting['lang']['SelectNull']}</option>
								<option value="1"{$audit_state_selected['1']}>{$fn_xiangqin->setting['lang']['audit_state_arr']['1']}</option>
								<option value="2"{$audit_state_selected['2']}>{$fn_xiangqin->setting['lang']['audit_state_arr']['2']}</option>
								<option value="3"{$audit_state_selected['3']}>{$fn_xiangqin->setting['lang']['audit_state_arr']['3']}</option>
							</select>
							</td>
							<th>{$fn_xiangqin->setting['lang']['channel']}</th><td>
							<select name="channel" class="form-control w120">
								{$channel_list_option}
							</select>
							</td>
							<th>{$fn_xiangqin->setting['lang']['open_love']}</th><td>
							<select name="open_love" class="form-control w120">
								{$open_love_list_option}
							</select>
							</td>
							<th>&#32418;&#23064;</th><td>
							<select name="mat_id" class="form-control w120">
								{$matListOption}
							</select>
							</td>
						</tr>
						<tr>
							<th>&#26159;&#21542;&#25512;&#33616;</th><td>
							<select name="hot" class="form-control w120">
								<option value="">{$fn_xiangqin->setting['lang']['SelectNull']}</option>
								<option value="1"{$hotSelected['1']}>{$fn_xiangqin->setting['lang']['Yes']}</option>
								<option value="0"{$hotSelected['0']}>{$fn_xiangqin->setting['lang']['No']}</option>
							</select>
							</td>
							<th>&#26159;&#21542;&#23553;&#21495;</th><td>
							<select name="seal" class="form-control w120">
								<option value="">{$fn_xiangqin->setting['lang']['SelectNull']}</option>
								<option value="1"{$sealSelected['1']}>{$fn_xiangqin->setting['lang']['Yes']}</option>
								<option value="0"{$sealSelected['0']}>{$fn_xiangqin->setting['lang']['No']}</option>
							</select>
							</td>
							<th>&#26159;&#21542;&#20250;&#21592;</th><td>
							<select name="is_vip" class="form-control w120">
								<option value="">{$fn_xiangqin->setting['lang']['SelectNull']}</option>
								<option value="1"{$vipSelected['1']}>{$fn_xiangqin->setting['lang']['Yes']}</option>
							</select>
							</td>
							<th>&#22871;&#39184;&#32423;&#21035;</th><td>
							<select name="group_id" class="form-control w120">
								{$groupListOption}
							</select>
							</td>
							<th>&#36807;&#26399;&#20250;&#21592;</th><td>
							<select name="expired" class="form-control w120">
								<option value="">{$fn_xiangqin->setting['lang']['SelectNull']}</option>
								<option value="1"{$expiredSelected['1']}>{$fn_xiangqin->setting['lang']['Yes']}</option>
							</select>						
							</td>
							<th>&#25490;&#24207;</th><td>
							<select name="order" class="form-control w120">
								<option value="dateline"{$OrderSelected['dateline']}>{$Fn_Admin->Config['LangVar']['OrderArray']['dateline']}</option>
								<option value="updateline"{$OrderSelected['updateline']}>{$Fn_Admin->Config['LangVar']['OrderArray']['updateline']}</option>
								<option value="click"{$OrderSelected['click']}>{$Fn_Admin->Config['LangVar']['OrderArray']['click']}</option>
							</select>
							</td>
							<th><input name="SearchSubmit" value="{$Fn_Admin->Config['LangVar']['SearchSubmit']}" class="btn btn-info" type="submit"></th>
						</tr>
					</table>
				</div>
			</form>
SEARCH;
			/* ���� End */
			showtagheader('div', 'table-responsive', true,'table-responsive');
			showformheader($FormUrl,'enctype="multipart/form-data"');
			showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
			showsubtitle(array(
				'ID',
				$fn_xiangqin->setting['lang']['name'],
				'&#22522;&#26412;&#36164;&#26009;',
				'&#32852;&#31995;&#47;&#36164;&#26009;&#26435;&#38480;',
				'&#22871;&#39184;/&#21040;&#26399;&#26102;&#38388;/&#21097;&#20313;',
				'&#32418;&#23064;',
				$fn_xiangqin->setting['lang']['channel'],
				'&#29366;&#24577;',
				'&#28155;&#21152;&#47;&#26356;&#26032;&#47;&#32622;&#39030;&#26102;&#38388;',
				$fn_xiangqin->setting['lang']['OperationTitle']
			),'header tbm tc');

			foreach ($res['list'] as $item) {
				$surplus = '&#37329;&#24065;&#25968;&#37327;:&nbsp;'.($item['currency'])."\r\n".'&#38053;&#21273;&#25968;&#37327;:&nbsp;'.($item['imkey'])."\r\n";
				if($item['due_time'] >= time()){
					$surplus .= '&#29301;&#32447;&#27425;&#25968;:&nbsp;'.($item['pull'])."\r\n";
					$surplus .= '&#27963;&#21160;&#27425;&#25968;:&nbsp;'.($item['act'])."\r\n";
				}
				$mat = $fn_xiangqin->matList[$item['mat_id']];
				$item = $fn_xiangqin->getFormUser($item);
				showtablerow('', array('class="tc w100"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
					'<input type="checkbox" class="filled-in" id="checkbox_'.$item['id'].'" name="delete[]" value="'.$item['id'].'"><label for="checkbox_'.$item['id'].'">'.$item['id'].'</label>',
					($item['head_portrait'] ? '<div class="UserLoadFace"><img src="'.$item['head_portrait'].'" height="50"><div class="BigFace" style="background:url('.$item['head_portrait'].') no-repeat center;background-size:cover;"></div></div>' : '').cutstr($item['name'],8),
					($item['uid'] ? '&#29992;&#25143;&#117;&#105;&#100;&#58;'.$item['uid'].' / &#29992;&#25143;&#21517;&#58;'.$item['username']."<br>" : '').$item['sex_text'].' / &#25163;&#26426;&#58;'.$item['phone'].($item['wx']  ? ' / &#24494;&#20449;&#58;'.$item['wx'] : '')."<br>".$item['age'].' / '.$item['height'].' / '.$item['month_income'].' / '.$item['education'].' / '.$item['marriage'],
					$fn_xiangqin->setting['lang']['open_contact_arr'][$item['open_contact']].'<br>'.$fn_xiangqin->setting['lang']['open_love_arr'][$item['open_love']],
					($item['vip'] ? $item['group_title'].' / '.$item['due_time'] : ($item['due_time'] ? '<span class="label bg-danger">&#24050;&#36807;&#26399;</span>' : '')).'<div style="height:7px;"></div><div data-container="body" data-toggle="popover" data-trigger="hover" data-placement="top" data-html="true" data-content="'.str_replace("\r\n","<br>",$surplus).'">&#21097;&#20313;&#65306;&#37329;&#24065;&#25968;&#37327;:&nbsp;'.($item['currency']).'...</div>',
					$mat['name'],
					$fn_xiangqin->setting['lang']['channel_arr'][$item['channel']],
					($item['audit_state'] != 1 ? '<span class="label bg-secondary">'.$fn_xiangqin->setting['lang']['audit_state_arr'][$item['audit_state']].'</span>' : '<span class="label bg-blue">'.$fn_xiangqin->setting['lang']['audit_state_arr'][$item['audit_state']].'</span>').'<div style="height:7px;"></div>'.(!$item['display'] ? '<span class="label bg-secondary">&#19981;&#26174;&#31034;</span>' : '<span class="label bg-blue">&#26174;&#31034;&#20013;</span>').'<div style="height:7px;"></div>'.(!$item['hot'] ? '<span class="label bg-secondary">&#19981;&#25512;&#33616;</span>' : '<span class="label bg-blue">&#25512;&#33616;&#20013;</span>').'<div style="height:7px;"></div>'.(!$item['seal'] ? '<span class="label bg-secondary">&#26410;&#23553;&#21495;</span>' : '<span class="label bg-blue">&#24050;&#23553;&#21495;</span>'),
					date('Y-m-d H:i',$item['dateline']).'<br>'.date('Y-m-d H:i',$item['updateline']).($item['topdateline'] ? '<br>'.date('Y-m-d H:i',$item['topdateline']) : ''),
					'<a href="'.$fn_xiangqin->getUrl('view',array('vid'=>$item['id'])).'" target="_blank" class="btn btn-sm btn-dark-outline">'.cplang('view').'</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&vid='.$item['id'].'" class="btn btn-sm btn-dark-outline">'.$fn_xiangqin->setting['lang']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=display&vid='.$item['id'].'&value='.(!empty($item['display']) ? 0:1).'&formhash='.FORMHASH.'" class="btn btn-sm btn-dark-outline">'.(!empty($item['display']) ? $fn_xiangqin->setting['lang']['DisplayNoTitle'] : $fn_xiangqin->setting['lang']['DisplayIsTitle']).'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=hot&vid='.$item['id'].'&value='.(!empty($item['hot']) ? 0:1).'&formhash='.FORMHASH.'" class="btn btn-sm btn-dark-outline">'.(!empty($item['hot']) ? '&#21462;&#28040;&#25512;&#33616;' : '&#25512;&#33616;').'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=seal&vid='.$item['id'].'&value='.(!empty($item['seal']) ? 0:1).'&formhash='.FORMHASH.'" class="btn btn-sm btn-dark-outline">'.(!empty($item['seal']) ? '&#35299;&#23553;' : '&#23553;&#21495;').'</a>&nbsp;&nbsp;<span class="btn btn-sm btn-dark-outline copy_btn" data-clipboard-content="'.$item['copy_temp'].'">&#22797;&#21046;</span><br><div style="height:7px;"></div><a href="'.$Fn_Admin->Config['IframeModUrl'].'&item=look_list&submodel=list&vid='.$item['id'].'" class="btn btn-sm btn-dark-outline">&#84;&#65;&#30475;&#36807;&#35841;</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeModUrl'].'&item=look_list&submodel=list&love_vid='.$item['id'].'" class="btn btn-sm btn-dark-outline">&#35841;&#30475;&#36807;&#84;&#65;</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeModUrl'].'&item=follow_list&submodel=list&vid='.$item['id'].'" class="btn btn-sm btn-dark-outline">&#84;&#65;&#20851;&#27880;&#35841;</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeModUrl'].'&item=follow_list&submodel=list&love_vid='.$item['id'].'" class="btn btn-sm btn-dark-outline">&#35841;&#20851;&#27880;&#84;&#65;</a><br><div style="height:7px;"></div><a href="'.$OpCpUrl.'&do=crm&vid='.$item['id'].'" class="btn btn-sm btn-dark-outline">&#67;&#82;&#77;&#31649;&#29702;</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeModUrl'].'&item=user_pull_log_list&submodel=list&vid='.$item['id'].'" class="btn btn-sm btn-dark-outline">&#29301;&#32447;&#35760;&#24405;</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeModUrl'].'&item=con_log_list&submodel=list&vid='.$item['id'].'" class="btn btn-sm btn-dark-outline">&#37329;&#24065;&#47;&#38053;&#21273;&#28040;&#36153;&#35760;&#24405;</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=del&vid='.$item['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$fn_xiangqin->setting['lang']['DelTitle'].'</a>',
				));
			}

			if($Fn_Admin->CheckUserGroup('xiangqin_all')){//�ƶ��û���ĳ��������
				$matHtml = '&nbsp;&nbsp;<input name="optype" value="move_mat" class="with-gap" type="radio" id="v_move_mat"><label class="custom-control-label" for="v_move_mat" style="margin-left:-5px;">&#24402;&#31867;&#32418;&#23064;</label>&nbsp;&nbsp;<select name="new_mat_id" class="form-control w120"><option value="">'.$fn_xiangqin->setting['lang']['SelectNull'].'</option>';
				foreach ($fn_xiangqin->matList as $k=>$v) {
					$matHtml .= '<option value="'.$v['id'].'">'.$v['name'].'</option>';
				}
				$matHtml .= '</select>';
			}
			
			showsubmit('Submit','&#31435;&#21363;&#25552;&#20132;','<input name="optype" value="audit_state" class="with-gap" type="radio" id="v_audit_state"><label class="custom-control-label" for="v_audit_state" style="margin-left:-5px;">'.$fn_xiangqin->setting['lang']['audit_state'].'</label>&nbsp;<select name="new_audit_state" class="form-control w120" id="audit_state"><option value="">'.$fn_xiangqin->setting['lang']['SelectNull'].'</option><option value="1">'.$fn_xiangqin->setting['lang']['audit_state_arr']['1'].'</option><option value="3">'.$fn_xiangqin->setting['lang']['audit_state_arr']['3'].'</option></select><span class="refuse_tips" style="display:none">&nbsp;&#25298;&#32477;&#21407;&#22240;&nbsp;<input type="text" class="input form-control w100" name="new_refuse_tips" value="" placeholder=""></span>'.$matHtml,'','select_all',multi($res['count'],20,$page,$MpUrl));

			showtablefooter(); /*dism��taobao��com*/
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			
			echo '<style>#Module .td25{width:auto;}.UserLoadFace{position:relative;cursor:pointer;}.UserLoadFace .BigFace{position:absolute;right:-300px;top:-200px;width:300px;height:400px;z-index:5;display:none;}</style>
			<script>
			$(".UserLoadFace").hover(function(){
				$(this).find(".BigFace").show();
			},
			
			function(){
				$(this).find(".BigFace").hide();
			});

			$("select#audit_state").change(function(){
				if($(this).val() == 3){
					$(".refuse_tips").show();
				}else{
					$(".refuse_tips").hide();
				}
			});
			</script>';


			echo '
			<script src="source/plugin/fn_assembly/static/js/clipboard.min.js"></script>    
			<script>
			var clipboard = new ClipboardJS(".copy_btn", {
				text: function(e) {
					return e.getAttribute("data-clipboard-content");
				}
			});
			clipboard.on("success", function(e) {
				alert("\u606d\u559c\u60a8\uff0c\u590d\u5236\u6210\u529f\uff01");
			});

			clipboard.on("error", function(e) {
				alert("\u5f88\u9057\u61be\uff0c\u590d\u5236\u5931\u8d25\uff01");
			});
			</script>';
			/* ģ�����End */	
		}else{
			if(isset($_GET['delete']) && is_array($_GET['delete'])){
				if($_GET['optype'] == 'audit_state' && $_GET['new_audit_state']){//���״̬
					if(!$_GET['new_refuse_tips'] && $_GET['new_audit_state'] == 3){
						fn_cpmsg('&#35831;&#22635;&#20889;&#25298;&#32477;&#21407;&#22240;','','error');
					}else{
						foreach($_GET['delete'] as $k => $v) {
							$item = C::t('#fn_xiangqin#fn_love_user')->fetch_by_id($v);
							$data['audit_state'] = $_GET['new_audit_state'];
							if($_GET['new_audit_state'] == 3){
								$data['refuse_tips'] == addslashes(strip_tags($_GET['new_refuse_tips']));
							}
							if(($_GET['new_audit_state'] == 1 && $item['audit_state'] != 1) || ($_GET['new_audit_state'] == 3 && $item['audit_state'] != 3)){
								C::t('#fn_xiangqin#fn_love_user')->update($data,$v);
								$fn_xiangqin->getAuditNotice($item['id'],$data['audit_state'],$fn_xiangqin->getUrl('user'),str_replace(array('[--audit_state--]'),array($fn_xiangqin->setting['lang']['audit_state_arr'][$_GET['new_audit_state']]),$fn_xiangqin->setting['lang']['userNoticeMsg']));
							}
						}
						GetInsertDoLog('examine_user_xiangqin','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete']),'audit_state'=>$_GET['new_audit_state']));//������¼
						fn_cpmsg($fn_xiangqin->setting['lang']['UpdateOk'],$CpMsgUrl,'succeed');
					}
				}else if($_GET['optype'] == 'move_mat' && $_GET['new_mat_id']){
					foreach($_GET['delete'] as $k => $v) {
						C::t('#fn_xiangqin#fn_love_user')->update(array('mat_id'=>intval($_GET['new_mat_id'])),$v);
					}
					fn_cpmsg($fn_xiangqin->setting['lang']['UpdateOk'],$CpMsgUrl,'succeed');
				}else{
					fn_cpmsg($fn_xiangqin->setting['lang']['OpErr'],'','error');
				}
			}
		}
	}else if($Do == 'crm'){
		$formhash = FORMHASH;
		$item = C::t('#fn_xiangqin#fn_love_user')->fetch_by_id($_GET['vid']);
		if(!submitcheck('followSubmit') && !submitcheck('remarksSubmit') && !submitcheck('pullSubmit')){
			$res = C::t('#fn_xiangqin#fn_love_user_follow_log')->fetch_all_by_list(array('vid'=>$item['id']),'dateline',$page - 1,1000,true);
			$crmHtml = '';
			foreach ($res['list'] as $log) {
				$crmHtml .= '<tr><td class="pl-20">'.$log['content'].'</td><td>'.date('Y-m-d H:i',$log['follow_dateline']).'</td><td>'.date('Y-m-d H:i',$log['dateline']).'</td></tr>';
			}

			$resPull = C::t('#fn_xiangqin#fn_love_user_pull_log')->fetch_all_by_list(array('vid'=>$item['id']),'dateline',$page - 1,1000,true);
			$pullHtml = '';
			foreach($resPull['list'] as $log) {
				$coverUserInfo = $fn_xiangqin->getView($log['love_vid']);
				$pullHtml .= '<tr><td class="pl-20"><a href="'.$coverUserInfo['url'].'" target="_blank">&#32534;&#21495;&#65306;'.$coverUserInfo['id'].'</a><br>&#22995;&#21517;&#65306;'.$coverUserInfo['name'].'-'.$coverUserInfo['sex_text'].'-'.$coverUserInfo['age'].'<br>&#25163;&#26426;&#21495;&#65306;'.$coverUserInfo['phone'].'</td><td>'.($coverUserInfo['head_portrait'] ? '<a href="'.$coverUserInfo['head_portrait'].'" target="_blank"><img src="'.$coverUserInfo['head_portrait'].'" height="60"></a>' : '').'</td><td><span class="label bg-blue">'.$fn_xiangqin->setting['lang']['pull_state_arr'][$log['state']].'</span></td><td>'.$log['remarks'].'</td><td>'.date('Y-m-d H:i',$log['pull_dateline']).'</td><td>'.date('Y-m-d H:i',$log['dateline']).'</td></tr>';
			}
			echo <<<TABLE
<div class="row">
  <div class="col-xl-6 col-12">
    <div class="box">
      <div class="box-header with-border">
        <h3 class="box-title">&#20889;{$item[name]}&#30340;&#36319;&#36827;</h3>
      </div>
      <div class="box-body">
        <form name="cpform" method="post" autocomplete="off" action="{$OpCpUrl}&do=crm&vid={$item[id]}" id="cpform" enctype="multipart/form-data">
          <input type="hidden" name="formhash" value="{$formhash}">
          <textarea name="content" class="form-control" placeholder="&#35831;&#36755;&#20837;&#36319;&#36827;&#20869;&#23481;" style="height:150px;"></textarea>
          <br>
          <input type="submit" class="btn btn-info" id="submit_DetailSubmit" name="followSubmit" value="&#31435;&#21363;&#20445;&#23384;">
        </form>
      </div>
    </div>
		  <div class="box">
      <div class="box-header with-border">
        <h3 class="box-title">&#20889;{$item[name]}&#30340;&#29301;&#32447;&#35760;&#24405;</h3>
      </div>
      <div class="box-body">
		<form name="cpform" method="post" autocomplete="off" action="{$OpCpUrl}&do=crm&vid={$item[id]}" id="cpform" enctype="multipart/form-data">
		  <input type="hidden" name="formhash" value="{$formhash}">
		  <div class="form-group row"><label class="col-sm-2 col-form-label">&#34987;&#29301;&#32447;&#29992;&#25143;&#73;&#68;&#58;</label><div class="col-sm-4">
		  <input name="love_vid" value="" type="text" class="input form-control"></div></div>
		  <div class="form-group row"><label class="col-sm-2 col-form-label">&#29301;&#32447;&#29366;&#24577;&#58;</label><div class="col-sm-4">
		  <div class="custom-control custom-radio custom-control-inline"><input type="radio" id="_v1_nrygieus" name="state" value="1" class="with-gap" checked=""><label class="custom-control-label" for="_v1_nrygieus">&#31561;&#24453;&#29301;&#32447;</label></div><div class="custom-control custom-radio custom-control-inline"><input type="radio" id="_v2_nrygieus" name="state" value="2" class="with-gap"><label class="custom-control-label" for="_v2_nrygieus">&#29301;&#32447;&#20013;</label></div><div class="custom-control custom-radio custom-control-inline"><input type="radio" id="_v3_nrygieus" name="state" value="3" class="with-gap"><label class="custom-control-label" for="_v3_nrygieus">&#29301;&#32447;&#22833;&#36133;</label></div><div class="custom-control custom-radio custom-control-inline"><input type="radio" id="_v4_nrygieus" name="state" value="4" class="with-gap"><label class="custom-control-label" for="_v4_nrygieus">&#29301;&#32447;&#25104;&#21151;</label></div></div></div>
		  <div class="form-group row"><label class="col-sm-2 col-form-label">&#25187;&#38500;&#27425;&#25968;:</label><div class="col-sm-4">
			<input name="pull_number" value="" type="text" class="input form-control"></div><div class="col-sm-4 form-inline">&#25187;&#38500;&#22810;&#23569;&#27425;&#29301;&#32447;&#27425;&#25968;&#65292;&#19981;&#22635;&#20889;&#19981;&#25187;&#38500;&#65281;&#65281;&#65281;</div></div>
		  <div class="form-group row"><label class="col-sm-2 col-form-label">&#29301;&#32447;&#22791;&#27880;&#58;</label><div class="col-sm-4">
		  <textarea name="remarks" id="remarks" class="form-control" placeholder="&#35831;&#36755;&#20837;&#22791;&#27880;&#65292;&#38271;&#26399;&#26174;&#31034;"></textarea></div></div>
		  <div class="form-group row"><label class="col-sm-2 col-form-label">&#29301;&#32447;&#26102;&#38388;&#58;</label><div class="col-sm-4">
		  <input type="text" class="input form-control" name="pull_dateline" value="" id="_v_zvmsjywe"><script>$('#_v_zvmsjywe').fdatepicker({format: 'yyyy-mm-dd hh:ii',pickTime: true});</script></div></div>
          <br>
          <input type="submit" class="btn btn-info" id="submit_DetailSubmit" name="pullSubmit" value="&#31435;&#21363;&#20445;&#23384;">
		</form>
      </div>
    </div>
    <div class="box">
      <div class="box-header with-border">
        <h3 class="box-title">{$item[name]}&#30340;&#22791;&#27880;</h3>
      </div>
      <div class="box-body">
		<form name="cpform" method="post" autocomplete="off" action="{$OpCpUrl}&do=crm&vid={$item[id]}" id="cpform" enctype="multipart/form-data">
		  <input type="hidden" name="formhash" value="{$formhash}">
          <textarea name="remarks" class="form-control" placeholder="&#35831;&#36755;&#20837;&#22791;&#27880;&#65292;&#38271;&#26399;&#26174;&#31034;" style="height:150px;">{$item[remarks]}</textarea>
          <br>
          <input type="submit" class="btn btn-info" id="submit_DetailSubmit" name="remarksSubmit" value="&#31435;&#21363;&#20445;&#23384;">
		</form>
      </div>
    </div>
  </div>
  <div class="col-xl-6 col-12">
    <div class="box">
      <div class="box-header with-border">
        <h3 class="box-title">&#36319;&#36827;&#35760;&#24405;</h3>
      </div>
      <div class="table-responsive">
        <table id="tickets" class="table mt-0 table-hover no-wrap dataTable no-footer px-10" style="margin-bottom:0">
          <thead>
            <tr role="row">
              <th class="pl-20">&#36319;&#36827;&#20869;&#23481;</th>
              <th>&#36319;&#36827;&#26102;&#38388;</th>
              <th>&#28155;&#21152;&#26102;&#38388;</th>
            </tr>
          </thead>
          <tbody>
			{$crmHtml}
          </tbody>
        </table>
      </div>
    </div>
	<div class="box">
      <div class="box-header with-border">
        <h3 class="box-title">&#29301;&#32447;&#35760;&#24405;</h3>
      </div>
      <div class="table-responsive">
        <table id="tickets" class="table mt-0 table-hover no-wrap dataTable no-footer px-10" style="margin-bottom:0">
          <thead>
            <tr role="row">
              <th class="pl-20">&#34987;&#29301;&#32447;&#29992;&#25143;</th>
              <th>&#34987;&#29301;&#32447;&#29992;&#25143;&#22836;&#20687;</th>
              <th>&#29301;&#32447;&#29366;&#24577;</th>
			  <th>&#29301;&#32447;&#22791;&#27880;</th>
			  <th>&#29301;&#32447;&#26102;&#38388;</th>
			  <th>&#28155;&#21152;&#26102;&#38388;</th>
            </tr>
          </thead>
          <tbody>
			{$pullHtml}
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
TABLE;
		}else if(submitcheck('followSubmit')){//д����
			if($_GET['content']){
				$mat = C::t('#fn_xiangqin#fn_love_mat')->fetch_by_uid($_G['uid']);
				$data['mat_id'] = $mat['id'];
				$data['vid'] = $item['id'];
				$data['content'] = addslashes(strip_tags($_GET['content']));
				$data['follow_dateline'] = time();
				$data['dateline'] = time();
				$id = C::t('#fn_xiangqin#fn_love_user_follow_log')->insert($data);
				fn_cpmsg($fn_xiangqin->setting['lang']['UpdateOk'],$CpMsgUrl.'&do=crm&vid='.$item['id'],'succeed');
				exit();
			}else{
				fn_cpmsg('&#35831;&#22635;&#20889;&#36319;&#36827;&#20869;&#23481;','','error');
				exit();
			}
		}else if(submitcheck('pullSubmit')){//дǣ�߼�¼
			if($_GET['love_vid']){
				$mat = C::t('#fn_xiangqin#fn_love_mat')->fetch_by_uid($_G['uid']);
				$data['mat_id'] = $mat['id'];
				$data['vid'] = intval($item['id']);
				$data['love_vid'] = intval($_GET['love_vid']);
				$data['remarks'] = addslashes(strip_tags($_GET['remarks']));
				$data['state'] = intval($_GET['state']);
				$data['pull_dateline'] = $_GET['pull_dateline'] ? strtotime($_GET['pull_dateline']) : '';
				$data['dateline'] = time();

				$user = C::t('#fn_xiangqin#fn_love_user')->fetch_by_id($data['vid']);
				if($_GET['pull_number'] && $user['pull'] >= $_GET['pull_number']){
					$loveUser = C::t('#fn_xiangqin#fn_love_user')->fetch_by_id($data['love_vid']);
					C::t('#fn_xiangqin#fn_love_user')->update_by_count($data['vid'],'pull',intval($_GET['pull_number']),'-');
					C::t('#fn_xiangqin#fn_love_con_log')->insert(array('uid'=>intval($user['uid']),'vid'=>intval($data['vid']),'love_vid'=>intval($data['love_vid']),'pull'=>intval($_GET['pull_number']),'event_type'=>6,'content'=>str_replace(array('[--name--]','[--love_name--]'),array($user['name'],$loveUser['name']),$fn_xiangqin->setting['lang']['con_log_content']['pull']),'dateline'=>time()));
				}

				$id = C::t('#fn_xiangqin#fn_love_user_pull_log')->insert($data);
				fn_cpmsg($fn_xiangqin->setting['lang']['UpdateOk'],$CpMsgUrl.'&do=crm&vid='.$item['id'],'succeed');
				exit();
			}else{
				fn_cpmsg('&#35831;&#22635;&#20889;&#29301;&#32447;&#23545;&#35937;','','error');
				exit();
			}
		}else if(submitcheck('remarksSubmit')){//д��ע
			if($_GET['remarks']){
				$data['remarks'] = addslashes(strip_tags($_GET['remarks']));
				C::t('#fn_xiangqin#fn_love_user')->update($data,$item['id']);
				fn_cpmsg($fn_xiangqin->setting['lang']['UpdateOk'],$CpMsgUrl.'&do=crm&vid='.$item['id'],'succeed');
				exit();
			}else{
				fn_cpmsg('&#35831;&#36755;&#20837;&#22791;&#27880;','','error');
				exit();
			}
		}
	}else if($Do == 'del' && $_GET['formhash'] == formhash() && $_GET['vid']){//ɾ��
		$id = intval($_GET['vid']);
		C::t('#fn_xiangqin#fn_love_user')->delete_by_id($id);
		GetInsertDoLog('del_user_xiangqin','fn_'.$_GET['mod'],array('id'=>$id));//������¼
		fn_cpmsg($fn_xiangqin->setting['lang']['DelOk'],$CpMsgUrl,'succeed');
	}else if(in_array($Do,array('display','seal','hot')) && $_GET['formhash'] == formhash() && $_GET['vid']){
		$id = intval($_GET['vid']);
		$data[$Do] = intval($_GET['value']);
		C::t('#fn_xiangqin#fn_love_user')->update($data,$id);
		if($Do == 'seal' && $_GET['value']){//���֪ͨ
			$fn_xiangqin->getSealNotice($id,$fn_xiangqin->getUrl('user'),$fn_xiangqin->setting['lang']['sealNoticeMsg']);
		}
		GetInsertDoLog($Do.'_user_list_xiangqin','fn_'.$_GET['mod'],array('id'=>$id));//������¼
		fn_cpmsg($fn_xiangqin->setting['lang']['UpdateOk'],$CpMsgUrl,'succeed');
		exit();
	}
}else if($SubModel == 'add'){//���ӻ�༭
	if(!$Fn_Admin->CheckUserGroup('xiangqin_all') && !$Fn_Admin->CheckUserGroup('xiangqin_add_user')){//Ȩ���ж�
		fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
		exit();
	}

	$id = intval($_GET['vid']);
	
	$item = C::t('#fn_xiangqin#fn_love_user')->fetch_by_id($id);

	if(!submitcheck('DetailSubmit')) {
		$opTitle = $fn_xiangqin->setting['lang']['AddTitle'];
		if($item){
			$opTitle = $fn_xiangqin->setting['lang']['EditTitle'];
		}
		
		//ͼƬ�ϴ�
		if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_assembly/class/class_upload.php')){
			@require_once libfile('class/upload','plugin/fn_assembly');
			$UploadConfig = fn_upload::Config();
		}

		showtagheader('div', 'box', true,'box');
		showformheader($Fn_Admin->Config['IframeSubModelUrl'].'&vid='.$id,'enctype');
		echo <<<HTML
		<ul class="nav nav-tabs customtab" role="tablist">
          <li class="nav-item"> <a class="nav-link active" data-toggle="tab" href="#basics" role="tab" aria-expanded="true"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#22522;&#26412;&#36164;&#26009;</span></a> </li>
		  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#single" role="tab" aria-expanded="false"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#25321;&#20598;&#26465;&#20214;</span></a> </li>
		  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#contact" role="tab" aria-expanded="false"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#32852;&#31995;&#26041;&#24335;&#35774;&#32622;</span></a> </li>
		  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#verify" role="tab" aria-expanded="false"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#35748;&#35777;&#35774;&#32622;</span></a> </li>
		  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#vip" role="tab" aria-expanded="false"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#22871;&#39184;&#35774;&#32622;</span></a> </li>
		  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#other" role="tab" aria-expanded="false"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#20854;&#20182;&#35774;&#32622;</span></a> </li>
        </ul>
HTML;
		showtagheader('div', 'box-body', true,'box-body');

		showtagheader('div', 'tab-content', true,'tab-content');

		echo <<<HTML
		<!-- ��������  -->
		<div class="tab-pane active" id="basics" role="tabpanel" aria-expanded="true">
HTML;
		
		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$fn_xiangqin->setting['lang']['head_portrait'].'</label><div class="col-sm-9"><div class="AdminSingleUpload"><div class="PhotoControl" id="head_portrait"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';

		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$fn_xiangqin->setting['lang']['album'].'</label><div class="col-sm-9"><div class="AdminSingleUpload"><div class="PhotoControl" id="album"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';

		showsetting('uid', 'new_uid', $item['uid'], 'text');
		
		showsetting($fn_xiangqin->setting['lang']['name'], 'name', $item['name'], 'text');

		showsetting($fn_xiangqin->setting['lang']['sex'],array('sex', array(
			array('1','&#30007;', array('sex_1' => '','sex_2' => 'none')),
			array('2','&#22899;', array('sex_1' => 'none','sex_2' => '')),
		), TRUE),$item ? $item['sex'] : 1, 'mradio');

		showsetting($fn_xiangqin->setting['lang']['birth'], 'birth',$item['birth'] ? date('Y-m-d',$item['birth']) : '', 'calendar');

		showsetting($fn_xiangqin->setting['lang']['height'], 'height', $item['height'], 'text','','','&#21333;&#20301;&#65306;&#67;&#77;');

		showsetting($fn_xiangqin->setting['lang']['weight'], 'weight', $item['weight'], 'text','','','&#21333;&#20301;&#65306;&#75;&#71;');

		showsetting($fn_xiangqin->setting['lang']['marriage'],array('marriage',DyadicArray($fn_xiangqin->setting['lang']['marriage_arr'],$fn_xiangqin->setting['lang']['SelectNullTo'])),$item['marriage'],'select');

		showsetting($fn_xiangqin->setting['lang']['education'],array('education',DyadicArray($fn_xiangqin->setting['lang']['education_arr'],$fn_xiangqin->setting['lang']['SelectNullTo'])),$item['education'],'select');

		showsetting($fn_xiangqin->setting['lang']['nation'],array('nation',DyadicArray($fn_xiangqin->setting['lang']['nation_arr'],$fn_xiangqin->setting['lang']['SelectNullTo'])),$item['nation'],'select');

		showsetting($fn_xiangqin->setting['lang']['family'],array('family',DyadicArray($fn_xiangqin->setting['lang']['family_arr'],$fn_xiangqin->setting['lang']['SelectNullTo'])),$item['family'],'select');

		showsetting($fn_xiangqin->setting['lang']['month_income'],array('month_income',DyadicArray($fn_xiangqin->setting['lang']['month_income_arr'],$fn_xiangqin->setting['lang']['SelectNullTo'])),$item['month_income'],'select');
		
		showsetting($fn_xiangqin->setting['lang']['only'], 'only',$item['only'],'radio');

		showsetting($fn_xiangqin->setting['lang']['child'],array('child',DyadicArray($fn_xiangqin->setting['lang']['child_arr'],$fn_xiangqin->setting['lang']['SelectNullTo'])),$item['child'],'select');

		showsetting($fn_xiangqin->setting['lang']['want_child'],array('want_child',DyadicArray($fn_xiangqin->setting['lang']['want_child_arr'],$fn_xiangqin->setting['lang']['SelectNullTo'])),$item['want_child'],'select');

		showsetting($fn_xiangqin->setting['lang']['occupation'],array('occupation',DyadicArray($fn_xiangqin->setting['lang']['occupation_arr'],$fn_xiangqin->setting['lang']['SelectNullTo'])),$item['occupation'],'select');

		showsetting($fn_xiangqin->setting['lang']['vehicle'],array('vehicle',DyadicArray($fn_xiangqin->setting['lang']['vehicle_arr'],$fn_xiangqin->setting['lang']['SelectNullTo'])),$item['vehicle'],'select');

		showsetting($fn_xiangqin->setting['lang']['house'],array('house',DyadicArray($fn_xiangqin->setting['lang']['house_arr'],$fn_xiangqin->setting['lang']['SelectNullTo'])),$item['house'],'select');

		showsetting($fn_xiangqin->setting['lang']['when_marry'],array('when_marry',DyadicArray($fn_xiangqin->setting['lang']['when_marry_arr'],$fn_xiangqin->setting['lang']['SelectNullTo'])),$item['when_marry'],'select');

		showtagheader('div', 'sex_1', !$item || $item['sex'] == 1 ? true : '','sub');
			showsetting($fn_xiangqin->setting['lang']['shape'],array('shape_1',DyadicArray($fn_xiangqin->setting['lang']['shape_arr_1'],$fn_xiangqin->setting['lang']['SelectNullTo'])),$item['shape'],'select');
		showtagfooter('div');

		showtagheader('div', 'sex_2',$item['sex'] == 2 ? true : '','sub');
			showsetting($fn_xiangqin->setting['lang']['shape'],array('shape_2',DyadicArray($fn_xiangqin->setting['lang']['shape_arr_2'],$fn_xiangqin->setting['lang']['SelectNullTo'])),$item['shape'],'select');
		showtagfooter('div');
		
		showsetting($fn_xiangqin->setting['lang']['smoke'],array('smoke',DyadicArray($fn_xiangqin->setting['lang']['smoke_arr'],$fn_xiangqin->setting['lang']['SelectNullTo'])),$item['smoke'],'select');

		showsetting($fn_xiangqin->setting['lang']['drink'],array('drink',DyadicArray($fn_xiangqin->setting['lang']['drink_arr'],$fn_xiangqin->setting['lang']['SelectNullTo'])),$item['drink'],'select');

		showsetting($fn_xiangqin->setting['lang']['religion'],array('religion',DyadicArray($fn_xiangqin->setting['lang']['religion_arr'],$fn_xiangqin->setting['lang']['SelectNullTo'])),$item['religion'],'select');

		showsetting($fn_xiangqin->setting['lang']['hobby'],array('hobby[]',DyadicArray($fn_xiangqin->setting['lang']['hobby_arr'])),array_filter(explode(",",$item['hobby'])),'mselect');

		showsetting($fn_xiangqin->setting['lang']['graduate_school'], 'graduate_school', $item['graduate_school'], 'text');

		showsetting($fn_xiangqin->setting['lang']['major'], 'major', $item['major'], 'text');

		showsetting($fn_xiangqin->setting['lang']['company'], 'company', $item['company'], 'text');

		showsetting($fn_xiangqin->setting['lang']['position'], 'position', $item['position'], 'text');

		showsetting($fn_xiangqin->setting['lang']['company_nature'],array('company_nature',DyadicArray($fn_xiangqin->setting['lang']['company_nature_arr'],$fn_xiangqin->setting['lang']['SelectNullTo'])),$item['company_nature'],'select');

		showsetting($fn_xiangqin->setting['lang']['introduce'], 'introduce', $item['introduce'], 'textarea');

		showsetting($fn_xiangqin->setting['lang']['video_type'],array('video_type', array(
			array('0','&#26080;&#35270;&#39057;', array('video' => 'none')),
			array('1','mp4/m3u8', array('video' => '')),
		), TRUE),$item['video_type'], 'mradio');
		showtagheader('div', 'video', $item['video_type'] ? true : '','sub');
			showsetting($fn_xiangqin->setting['lang']['video_url'], 'video_url', $item['video_url'], 'text');
		showtagfooter('div');
		
		echo <<<HTML
		</div>
		<!-- �������� end  -->
HTML;
		
		echo <<<HTML
		<!-- ��ż����  -->
		<div class="tab-pane" id="single" role="tabpanel" aria-expanded="false">
HTML;
		
		showsetting($fn_xiangqin->setting['lang']['req_age_min'],array('req_age_min',DyadicArray($fn_xiangqin->setting['lang']['age_arr'])),$item['req_age_min'],'select');

		showsetting($fn_xiangqin->setting['lang']['req_age_max'],array('req_age_max',DyadicArray($fn_xiangqin->setting['lang']['age_arr'],$fn_xiangqin->setting['lang']['Unlimited'])),$item['req_age_max'],'select');

		showsetting($fn_xiangqin->setting['lang']['req_height_min'],array('req_height_min',DyadicArray($fn_xiangqin->setting['lang']['height_arr'])),$item['req_height_min'],'select');

		showsetting($fn_xiangqin->setting['lang']['req_height_max'],array('req_height_max',DyadicArray($fn_xiangqin->setting['lang']['height_arr'],$fn_xiangqin->setting['lang']['Unlimited'])),$item['req_height_max'],'select');

		showsetting($fn_xiangqin->setting['lang']['req_month_income'],array('req_month_income',DyadicArray($fn_xiangqin->setting['lang']['month_income_arr'],'&#19981;&#38480;')),$item['req_month_income'],'select');

		showsetting($fn_xiangqin->setting['lang']['req_education'],array('req_education',DyadicArray($fn_xiangqin->setting['lang']['education_arr'],'&#19981;&#38480;')),$item['req_education'],'select');

		showsetting($fn_xiangqin->setting['lang']['req_nation'],array('req_nation',DyadicArray($fn_xiangqin->setting['lang']['nation_arr'],'&#19981;&#38480;')),$item['req_nation'],'select');

		showsetting($fn_xiangqin->setting['lang']['req_marriage'],array('req_marriage',DyadicArray($fn_xiangqin->setting['lang']['marriage_arr'],'&#19981;&#38480;')),$item['req_marriage'],'select');

		showsetting($fn_xiangqin->setting['lang']['req_accept_child'],array('req_accept_child',DyadicArray($fn_xiangqin->setting['lang']['req_accept_child_arr'],$fn_xiangqin->setting['lang']['SelectNullTo'])),$item['req_accept_child'],'select');

		showsetting($fn_xiangqin->setting['lang']['req_want_child'],array('req_want_child',DyadicArray($fn_xiangqin->setting['lang']['req_want_child_arr'],$fn_xiangqin->setting['lang']['SelectNullTo'])),$item['req_want_child'],'select');

		showsetting($fn_xiangqin->setting['lang']['req_smoke'],array('req_smoke',DyadicArray($fn_xiangqin->setting['lang']['req_smoke_arr'],$fn_xiangqin->setting['lang']['SelectNullTo'])),$item['req_smoke'],'select');

		showsetting($fn_xiangqin->setting['lang']['req_drink'],array('req_drink',DyadicArray($fn_xiangqin->setting['lang']['req_drink_arr'],$fn_xiangqin->setting['lang']['SelectNullTo'])),$item['req_drink'],'select');

		showsetting($fn_xiangqin->setting['lang']['req_house'], 'req_house', $item['req_house'] , 'radio');

		showsetting($fn_xiangqin->setting['lang']['req_vehicle'], 'req_vehicle', $item['req_vehicle'] , 'radio');

		echo <<<HTML
		</div>
		<!-- ��ż���� end  -->
HTML;

		echo <<<HTML
		<!-- ��ϵ��ʽ����  -->
		<div class="tab-pane" id="contact" role="tabpanel" aria-expanded="false">
HTML;
		
		showsetting($fn_xiangqin->setting['lang']['phone'], 'phone',$item['phone'], 'text');

		showsetting($fn_xiangqin->setting['lang']['wx'], 'wx',$item['wx'], 'text');
		
		showsetting($fn_xiangqin->setting['lang']['open_contact'],array('open_contact',DyadicArray($fn_xiangqin->setting['lang']['open_contact_arr'])),$item['open_contact'] ? $item['open_contact'] : 1,'mradio','','','&#20844;&#24320;&#32852;&#31995;&#26041;&#24335;&#65306;&#20351;&#29992;&#38053;&#21273;&#21363;&#21487;&#26597;&#30475;&#32852;&#31995;&#20449;&#24687;<br>&#20165;&#23545;&#20250;&#21592;&#20844;&#24320;&#32852;&#31995;&#26041;&#24335;&#65306;&#20250;&#21592;&#29992;&#25143;&#20351;&#29992;&#38053;&#21273;&#21487;&#26597;&#30475;&#32852;&#31995;&#20449;&#24687;<br>&#19981;&#20844;&#24320;&#32852;&#31995;&#26041;&#24335;&#65306;&#21482;&#33021;&#36890;&#36807;&#32418;&#23064;&#29301;&#32447;&#26597;&#30475;&#32852;&#31995;&#20449;&#24687;');

		showsetting($fn_xiangqin->setting['lang']['open_love'],array('open_love',DyadicArray($fn_xiangqin->setting['lang']['open_love_arr'])),$item['open_love'] ? $item['open_love'] : 1,'mradio','','','&#20844;&#24320;&#30456;&#20146;&#65306;&#22312;&#24179;&#21488;&#20013;&#20844;&#24320;&#26174;&#31034;&#22836;&#20687;&#21644;&#35814;&#32454;&#36164;&#26009;&#65288;&#19981;&#21253;&#21547;&#20219;&#20309;&#32852;&#31995;&#26041;&#24335;&#65289;<br>&#20250;&#21592;&#30456;&#20146;&#65306;&#22312;&#24179;&#21488;&#20013;&#20844;&#24320;&#26174;&#31034;&#22836;&#20687;&#65292;&#35814;&#32454;&#36164;&#26009;&#20165;&#20250;&#21592;&#21487;&#26597;&#30475;<br>&#22996;&#25176;&#32418;&#23064;&#65306;&#22312;&#24179;&#21488;&#20013;&#19981;&#26174;&#31034;&#22836;&#20687;&#21644;&#35814;&#32454;&#36164;&#26009;&#65292;&#21482;&#26377;&#32418;&#23064;&#22312;&#21518;&#21488;&#21487;&#35265;&#65292;&#20805;&#20998;&#20445;&#25252;&#24744;&#30340;&#38544;&#31169;&#20449;&#24687;&#65307;&#32418;&#23064;&#20174;&#36164;&#28304;&#24211;&#20013;&#20026;&#24744;&#20154;&#24037;&#31579;&#36873;&#31526;&#21512;&#26465;&#20214;&#30340;&#22025;&#23486;&#25512;&#33616;&#32473;&#24744;&#65307;&#24744;&#20063;&#21487;&#20197;&#20027;&#21160;&#25214;&#32418;&#23064;&#24110;&#24744;&#22312;&#24179;&#21488;&#20013;&#30340;&#22025;&#23486;&#36827;&#34892;&#29301;&#32447;');

		echo <<<HTML
		</div>
		<!-- ��ϵ��ʽ���� end  -->
HTML;

		echo <<<HTML
		<!-- ��֤����  -->
		<div class="tab-pane" id="verify" role="tabpanel" aria-expanded="false">
HTML;
		
		showsetting($fn_xiangqin->setting['lang']['phone_verify'], 'phone_verify', $item['phone_verify'], 'radio');

		showsetting($fn_xiangqin->setting['lang']['real_verify'], 'real_verify', $item['real_verify'], 'radio');

		showsetting($fn_xiangqin->setting['lang']['education_verify'], 'education_verify', $item['education_verify'], 'radio');

		showsetting($fn_xiangqin->setting['lang']['vehicle_verify'], 'vehicle_verify', $item['vehicle_verify'], 'radio');

		showsetting($fn_xiangqin->setting['lang']['house_verify'], 'house_verify', $item['house_verify'], 'radio');

		showsetting($fn_xiangqin->setting['lang']['offline_verify'], 'offline_verify', $item['offline_verify'], 'radio');

		echo <<<HTML
		</div>
		<!-- ��֤���� end  -->
HTML;
		
		echo <<<HTML
		<!-- �ײ�����  -->
		<div class="tab-pane" id="vip" role="tabpanel" aria-expanded="false">
HTML;

		$groupList = array();
		foreach(C::t('#fn_xiangqin#fn_love_meal')->fetch_all_by_list(array('type'=>1)) as $val) {
			$groupList[] = array($val['id'], $val['title']);
		}
		showsetting("&#36873;&#25321;&#22871;&#39184;", array('group_id', $groupList),$item['due_time'] >= time() ? $item['group_id'] : '', 'mradio');

		showsetting("&#21040;&#26399;&#26102;&#38388;", 'due_time',$item['due_time'] ? date('Y-m-d',$item['due_time']) : '', 'calendar');

		showsetting('&#29301;&#32447;&#27425;&#25968;', 'pull', $item['pull'], 'text','','','&#27880;&#24847;&#65306;&#20250;&#21592;&#25165;&#21487;&#20351;&#29992;');

		showsetting('&#27963;&#21160;&#27425;&#25968;', 'act', $item['act'], 'text','','','&#27880;&#24847;&#65306;&#20250;&#21592;&#25165;&#21487;&#20351;&#29992;');

		showsetting('&#37329;&#24065;&#25968;&#37327;', 'currency', $item['currency'], 'text');

		showsetting('&#38053;&#21273;&#25968;&#37327;', 'imkey', $item['imkey'], 'text');

		echo <<<HTML
		</div>
		<!-- �ײ����� end  -->
HTML;
		echo <<<HTML
		<!-- ��������  -->
		<div class="tab-pane" id="other" role="tabpanel" aria-expanded="false">
HTML;
		
		showsetting($fn_xiangqin->setting['lang']['mat_comment'], 'comment', $item['comment'], 'textarea');

		showsetting($fn_xiangqin->setting['lang']['Click'], 'click', $item['click'], 'text');

//		showsetting($fn_xiangqin->setting['lang']['audit_state'],array('audit_state', array(
//			array('1',$fn_xiangqin->setting['lang']['audit_state_arr']['1'], array('audit_state_3' => 'none')),
//			array('2',$fn_xiangqin->setting['lang']['audit_state_arr']['2'], array('audit_state_3' => 'none')),
//			array('3',$fn_xiangqin->setting['lang']['audit_state_arr']['3'], array('audit_state_3' => '')),
//		), TRUE),$item ? $item['audit_state'] : 1, 'mradio');
//		showtagheader('div', 'audit_state_3', $item['audit_state'] == 3 ? true : '');
//			showsetting('&#25298;&#32477;&#29702;&#30001;', 'refuse_tips',$item['refuse_tips'], 'text');
//		showtagfooter('div');

		showsetting($fn_xiangqin->setting['lang']['SetTopTime'], 'topdateline',$item['topdateline'] ? date('Y-m-d H:i',$item['topdateline']) : '', 'calendar','','','',1);

		if($item){
			showsetting($fn_xiangqin->setting['lang']['RefreshTime'], 'updateline',$item['updateline'] ? date('Y-m-d H:i',$item['updateline']) : '', 'calendar','','','',1);
		}

		if($item){
			showsetting($fn_xiangqin->setting['lang']['TimeTitle'], 'dateline',date('Y-m-d H:i',$item['dateline']), 'calendar','','','',1);
		}

		echo <<<HTML
		</div>
		<!-- �������� end  -->
HTML;
		showsubmit('DetailSubmit','&#20445;&#23384;&#37197;&#32622;');
		showtagfooter('div');
		showtagfooter('div');
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');

		$UpLoadHtml  = '';
		if($item['head_portrait']){
			$head_portrait_arr[] = '"'.$item['head_portrait'].'"';;
			$UpLoadHtml .= '
			var InputArray = new Array('.implode(',',$head_portrait_arr).');
			$("#head_portrait").AppUpload({InputName:"new_head_portrait",Multiple:true,InputExist:true,InputArray:InputArray});';

		}else{
			$UpLoadHtml .= '$("#head_portrait").AppUpload({InputName:"new_head_portrait",Multiple:true});';
		}

		if($item['album']){
			foreach(array_filter(explode(",",$item['album'])) as $key => $val) {
				$ImagesJsArray[] = '"'.$val.'"';
			}
			$UpLoadHtml .= '
			var InputArray = new Array('.implode(',',$ImagesJsArray).');
			$("#album").AppUpload({InputName:"new_album",InputExist:true,InputArray:InputArray});';

		}else{
			$UpLoadHtml .= '$("#album").AppUpload({InputName:"new_album"});';
		}

		echo '
		<script src="'.$Config['StaticPath'].'/js/jquery-1.9.1.min.js"></script>'.$UploadConfig['CssJsHtml'].'
		<script>
		'.$UpLoadHtml.'
		</script>
		';

	}else{
		
		foreach($_GET['new_head_portrait'] as $key => $val) {
			$_GET['new_head_portrait'][$key] = strpos($val,'http') !== false ? $val : $_G['siteurl'].$val;
		}
			
		foreach($_GET['new_album'] as $key => $val) {
			$_GET['new_album'][$key] = strpos($val,'http') !== false ? $val : $_G['siteurl'].$val;
		}
		$data['head_portrait'] = addslashes(strip_tags($_GET['new_head_portrait'][0]));
		$data['video_type'] = intval($_GET['video_type']);
		$data['video_url'] = addslashes(strip_tags($_GET['video_url']));
		$data['album'] = is_array($_GET['new_album']) && isset($_GET['new_album'])  ? implode(',',array_filter($_GET['new_album'])) : '';
		$data['uid'] = intval($_GET['new_uid']);
		$member = DB::fetch_first('SELECT username FROM '.DB::table('common_member').' where uid = '.$data['uid']);
		$data['username'] = addslashes(strip_tags($member['username']));
		$data['group_id'] = intval($_GET['group_id']);
		$data['due_time'] = $_GET['due_time'] ? strtotime($_GET['due_time']) : '';
		$data['currency'] = intval($_GET['currency']);
		$data['imkey'] = intval($_GET['imkey']);
		$data['pull'] = intval($_GET['pull']);
		$data['act'] = intval($_GET['act']);
		$data['name'] = addslashes(strip_tags($_GET['name']));
		$data['phone'] = addslashes(strip_tags($_GET['phone']));
		$data['wx'] = addslashes(strip_tags($_GET['wx']));
		$data['graduate_school'] = addslashes(strip_tags($_GET['graduate_school']));
		$data['major'] = addslashes(strip_tags($_GET['major']));
		$data['company'] = addslashes(strip_tags($_GET['company']));
		$data['position'] = addslashes(strip_tags($_GET['position']));
		$data['birth'] = $_GET['birth'] ? strtotime($_GET['birth']) : '';
		$data['comment'] = addslashes(strip_tags($_GET['comment']));
		$data['introduce'] = addslashes(strip_tags($_GET['introduce']));
		//����-��Ф
		$birthext = $fn_xiangqin->birthext($data['birth']);
		$data['constellation'] = intval($birthext['constellation']);
		$data['animal'] = intval($birthext['animal']);
		$data['age'] = date('Y') - date('Y',$data['birth']);
		//$data['mat_id'] = intval($_GET['mat_id']);
		$data['sex'] = intval($_GET['sex']);
		$data['weight'] = intval($_GET['weight']);
		$data['height'] = intval($_GET['height']);
		$data['education'] = intval($_GET['education']);
		$data['marriage'] = intval($_GET['marriage']);
		$data['nation'] = intval($_GET['nation']);
		$data['family'] = intval($_GET['family']);
		$data['month_income'] = intval($_GET['month_income']);
		$data['only'] = intval($_GET['only']);
		$data['child'] = intval($_GET['child']);
		$data['want_child'] = intval($_GET['want_child']);
		$data['occupation'] = intval($_GET['occupation']);
		$data['vehicle'] = intval($_GET['vehicle']);
		$data['house'] = intval($_GET['house']);
		$data['when_marry'] = intval($_GET['when_marry']);
		$data['shape'] = $data['sex'] == 1 ? intval($_GET['shape_1']) : intval($_GET['shape_2']);
		$data['smoke'] = intval($_GET['smoke']);
		$data['drink'] = intval($_GET['drink']);
		$data['religion'] = intval($_GET['religion']);
		$data['hobby'] = is_array($_GET['hobby']) && isset($_GET['hobby']) ? implode(',',$_GET['hobby']) : '';
		$hobby_arr = array();
		foreach($_GET['hobby'] as $k => $v) {
			$hobby_arr[$k] = $fn_xiangqin->setting['lang']['hobby_arr'][$v];
		}
		$data['hobby_arr'] = $hobby_arr ? serialize($hobby_arr) : '';
		$data['company_nature'] = intval($_GET['company_nature']);
		$data['req_age_min'] = intval($_GET['req_age_min']);
		$data['req_age_max'] = intval($_GET['req_age_max']);
		$data['req_height_min'] = intval($_GET['req_height_min']);
		$data['req_height_max'] = intval($_GET['req_height_max']);
		$data['req_month_income'] = $_GET['req_month_income'] ? intval($_GET['req_month_income']) : 99;
		$data['req_education'] = $_GET['req_education'] ? intval($_GET['req_education']) : 99;
		$data['req_nation'] = intval($_GET['req_nation']);
		$data['req_house'] = intval($_GET['req_house']);
		$data['req_vehicle'] = intval($_GET['req_vehicle']);
		$data['req_marriage'] = $_GET['req_marriage'] ? intval($_GET['req_marriage']) : 99;
		$data['req_want_child'] = intval($_GET['req_want_child']);
		$data['req_smoke'] = intval($_GET['req_smoke']);
		$data['req_drink'] = intval($_GET['req_drink']);
		$data['req_accept_child'] = intval($_GET['req_accept_child']);
		$data['open_contact'] = intval($_GET['open_contact']);
		$data['open_love'] = intval($_GET['open_love']);
		$data['phone_verify'] = intval($_GET['phone_verify']);
		$data['real_verify'] = intval($_GET['real_verify']);
		$data['education_verify'] = intval($_GET['education_verify']);
		$data['vehicle_verify'] = intval($_GET['vehicle_verify']);
		$data['house_verify'] = intval($_GET['house_verify']);
		$data['offline_verify'] = intval($_GET['offline_verify']);
		//$data['audit_state'] = intval($_GET['audit_state']);
		//$data['refuse_tips'] = addslashes(strip_tags($_GET['refuse_tips']));
		$data['click'] = intval($_GET['click']);
		$data['topdateline'] = $_GET['topdateline'] ? strtotime($_GET['topdateline']) : '';

		if($item){
			
//			if(($_GET['audit_state'] == 1 && $item['audit_state'] != 1) || ($_GET['audit_state'] == 3 && $item['audit_state'] != 3)){
//				$fn_xiangqin->getAuditNotice($item['id'],$data['audit_state'],$fn_xiangqin->getUrl('user'),str_replace(array('[--audit_state--]'),array($fn_xiangqin->setting['lang']['audit_state_arr'][$_GET['audit_state']]),$fn_xiangqin->setting['lang']['userNoticeMsg']));
//			}
	
			$data['updateline'] = strtotime($_GET['updateline']);
			C::t('#fn_xiangqin#fn_love_user')->update($data,$id);
			GetInsertDoLog('edit_user_xiangqin','fn_'.$_GET['mod'],array('id'=>$id));//������¼
		}else{
			$data['dateline'] = $data['updateline'] = time();
			$data['per_check'] = 1;
			$id = C::t('#fn_xiangqin#fn_love_user')->insert($data);
			GetInsertDoLog('add_user_xiangqin','fn_'.$_GET['mod'],array('id'=>$id));//������¼
		}
		fn_cpmsg($fn_xiangqin->setting['lang']['UpdateOk'],$Fn_Admin->Config['IframeItemUrl'].'&submodel=list','succeed');
		exit();
	}
}
//From: Dism��taobao��com
?> 