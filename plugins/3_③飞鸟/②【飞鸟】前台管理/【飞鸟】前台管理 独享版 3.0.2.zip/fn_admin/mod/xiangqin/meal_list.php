<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('xiangqin_all') && !$Fn_Admin->CheckUserGroup('xiangqin_meal_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$SubModel = in_array($_GET['submodel'], array('list','add')) ? $_GET['submodel'] : 'list';
$Fn_Admin->Config['IframeSubModelUrl'] = $Fn_Admin->Config['IframeItemUrl'].'&submodel='.$SubModel;
$NavClass = array($SubModel=>'btn-info Hover');

//����
echo <<<Nav
<div class="SubModelNav">
  <ul>
	<li class="{$NavClass['list']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=list" target="_self">{$Fn_Admin->Config['LangVar']['XiangqinLeftNavArray'][$_GET['item']]}</a></li>
    <li class="{$NavClass['add']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=add" target="_self">{$Fn_Admin->Config['LangVar']['AddEditTitle']}</a></li>
  </ul>
  <div class="both"></div>
</div>
Nav;

if($SubModel == 'list'){//�б�
	$Do = in_array($_GET['do'], array('Del')) ? $_GET['do'] : 'submodel_list';
	$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeSubModelUrl'].'&'.http_build_query($SearArray);
	if($Do == 'submodel_list'){
		if(!submitcheck('Submit')) {
			$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
			$page = $_GET['page'] ? $_GET['page'] : 0;
			$res = C::t('#fn_xiangqin#fn_love_meal')->fetch_all_by_list();
			/* ��ѯ���� End */

			/* ģ����� */	
			showtagheader('div', 'row', true,'row');
			showtagheader('div', 'col-12', true,'col-12');
			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-body', true,'box-body');
			showtagheader('div', 'table-responsive', true,'table-responsive');
			showformheader($FormUrl,'enctype="multipart/form-data"');
			showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
			showsubtitle(array(
				'ID',
				$fn_xiangqin->setting['lang']['Title'],
				'&#31867;&#22411;',
				'&#22270;&#26631;',
				'&#37329;&#39069;',
				'&#22825;&#25968;',
				'&#37329;&#24065;',
				'&#38053;&#21273;&#25968;&#37327;',
				'&#29301;&#32447;&#27425;&#25968;',
				'&#27963;&#21160;&#27425;&#25968;',
				'&#38480;&#36141;&#27425;&#25968;',
				$fn_xiangqin->setting['lang']['DisplayOrder'],
				$fn_xiangqin->setting['lang']['DisplayTitle'],
				$fn_xiangqin->setting['lang']['OperationTitle']
			),'header tbm tc');

			foreach ($res as $item) {
				showtablerow('', array('class="tc w50"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
					$item['id'],
					$item['title'],
					$fn_xiangqin->setting['lang']['meal_type_arr'][$item['type']],
					$item['icon'] ? '<img src="'.$item['icon'].'" style="height:30px;">' : '',
					$item['money'],
					$item['day'] ? $item['day'].'&#22825;' : '',
					$item['currency'],
					$item['imkey'],
					$item['pull'],
					$item['act'],
					$item['limit'],
					$item['displayorder'],
					!$item['display'] ? '<span class="label bg-secondary">'.$fn_xiangqin->setting['lang']['No'].'</span>' : '<span class="label bg-blue">'.$fn_xiangqin->setting['lang']['Yes'].'</span>',
					'<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&aid='.$item['id'].'" class="btn btn-sm btn-info-outline">'.$fn_xiangqin->setting['lang']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Del&aid='.$item['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$fn_xiangqin->setting['lang']['DelTitle'].'</a>',
				));
			}

			showtablefooter(); /*dism��taobao��com*/
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			/* ģ�����End */	
		}
	}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['aid']){
		$id = intval($_GET['aid']);
		C::t('#fn_xiangqin#fn_love_meal')->delete_by_id($id);
		fn_cpmsg($fn_xiangqin->setting['lang']['DelOk'],$CpMsgUrl,'succeed');
		exit();
	}
}else if($SubModel == 'add'){//���ӻ�༭

	$id = intval($_GET['aid']);
	
	$item = C::t('#fn_xiangqin#fn_love_meal')->fetch_by_id($id);

	if(!submitcheck('DetailSubmit')) {
		$opTitle = $fn_xiangqin->setting['lang']['AddTitle'];
		if($item){
			$opTitle = $fn_xiangqin->setting['lang']['EditTitle'];
		}
		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-header', true,'with-border box-header');
		showtitle($opTitle,'class="box-title"');
		showtagfooter('div');
		showformheader($Fn_Admin->Config['IframeSubModelUrl'].'&aid='.$id,'enctype');
		showtagheader('div', 'box-body', true,'box-body');
		showsetting('&#26631;&#39064;', 'title', $item['title'], 'text');

		$icon_html = ($item['icon'] ? '<a href="'.$item['icon'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$item['icon'].'" height="55"/></a>' : '').'';
		showsetting('&#22270;&#26631;', 'new_icon',$item['icon'], 'filetext', '', 0, $icon_html);
	
		showsetting('&#20215;&#26684;', 'money', $item['money'], 'text');

		showsetting('&#38480;&#36141;&#27425;&#25968;', 'limit', $item['limit'], 'text');
		
		showsetting('&#31867;&#22411;',array('type', array(
			array('1','&#20250;&#21592;', array('type_table_1' => '', 'type_table_2' => '', 'type_table_3' => '')),
			array('2','&#37329;&#24065;', array('type_table_1' => 'none', 'type_table_2' => '', 'type_table_3' => 'none')),
			array('3','&#38053;&#21273;', array('type_table_1' => 'none', 'type_table_2' => 'none', 'type_table_3' => '')),
		), TRUE),$item['type'] ? $item['type'] : 1, 'mradio');


		showtagheader('div', 'type_table_1',!$item || $item['type'] == 1 ? true : '', 'sub');
			showsetting('&#22825;&#25968;', 'day', $item['day'], 'text');
			showsetting('&#29301;&#32447;&#27425;&#25968;', 'pull', $item['pull'], 'text');
			showsetting('&#27963;&#21160;&#27425;&#25968;', 'act', $item['act'], 'text');
		showtagfooter('div');
			
		showtagheader('div', 'type_table_2',$item['type'] == 1 || $item['type'] == 2 || !$item ? true : '', 'sub');
			showsetting('&#37329;&#24065;&#25968;&#37327;', 'currency', $item['currency'], 'text');
		showtagfooter('div');

		showtagheader('div', 'type_table_3',$item['type'] == 1 || $item['type'] == 3 || !$item ? true : '', 'sub');
			showsetting('&#38053;&#21273;&#25968;&#37327;', 'imkey', $item['imkey'], 'text');
		showtagfooter('div');

		showsetting('&#35828;&#26126;', 'content', str_replace("<br>","\r\n",$item['content']), 'textarea');
		showsetting($fn_xiangqin->setting['lang']['DisplayTitle'], 'display', $item ? $item['display'] : 1, 'radio');
		showsetting($fn_xiangqin->setting['lang']['DisplayOrder'], 'displayorder', $item['displayorder'], 'text');
		
		showsubmit('DetailSubmit','&#20445;&#23384;&#37197;&#32622;');
		showtagfooter('div');
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');

	}else{
		$data['title'] = addslashes(strip_tags($_GET['title']));
		$data['money'] = addslashes(strip_tags($_GET['money']));
		$data['currency'] = intval($_GET['currency']);
		$data['imkey'] = intval($_GET['imkey']);
		$data['act'] = intval($_GET['act']);
		$data['pull'] = intval($_GET['pull']);
		$data['day'] = intval($_GET['day']);
		$data['type'] = intval($_GET['type']);
		$data['limit'] = intval($_GET['limit']);
		$data['content'] = addslashes(str_replace("\r\n","<br>",$_GET['content']));
		$data['display'] = intval($_GET['display']);
		$data['displayorder'] = intval($_GET['displayorder']);
		$data = array_merge($data,$Fn_Admin->uploadFiles($_FILES));
		if($item){
			C::t('#fn_xiangqin#fn_love_meal')->update($data,$id);
		}else{
			$id = C::t('#fn_xiangqin#fn_love_meal')->insert($data);
		}
		fn_cpmsg($fn_xiangqin->setting['lang']['UpdateOk'],$Fn_Admin->Config['IframeItemUrl'].'&submodel=list','succeed');
		exit();
	}
}
//From: Dism_taobao_com
?>