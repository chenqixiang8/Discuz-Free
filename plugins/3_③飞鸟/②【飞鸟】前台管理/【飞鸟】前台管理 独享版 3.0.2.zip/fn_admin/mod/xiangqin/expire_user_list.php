<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('xiang_all') && !$Fn_Admin->CheckUserGroup('xiangqin_expire_user_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$Do = in_array($_GET['do'], array('SmsReminding')) ? $_GET['do'] : 'List';

//�����ֶ�
$SearField =array('page','keyword','expire_vip_push','order');
foreach($SearField as $Val) {
	$SearArray[$Val] = $_GET[$Val] || in_array($_GET[$Val],array('0')) ? $_GET[$Val] : '';
}
//�����ֶ� End

$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeItemUrl'].'&'.http_build_query($SearArray);

if($Do == 'List'){
	if(!submitcheck('Submit')) {
		$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
		/* ��ѯ���� */
		$Where = ' and M.vip_time >= '.time().' and M.vip_time <='
		.strtotime("+7 day",time());

		$Order = in_array($_GET['order'], array('id','vip_time')) ? 'M.'.addslashes(dhtmlspecialchars($_GET['order'])) : 'M.id';
		
		if(!$Fn_Admin->CheckUserGroup('xiang_all')){
			$Where .= ' and M.mid = '.intval($_G['uid']);
		}
		
		if($_GET['keyword']){
			$_GET['keyword'] = str_replace(array('%','_'),array('',''),$_GET['keyword']);
			$Where .= ' and (M.username like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or M.name like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or M.uid = '.intval($_GET['keyword']).' or M.mobile = \''.addslashes(strip_tags($_GET['keyword'])).'\' )';
		}

		if(in_array($_GET['expire_vip_push'],array('0','1'))){
			$Where .= ' and M.expire_vip_push = '.intval($_GET['expire_vip_push']);
		}
		
		$Where = preg_replace('/and/','where',$Where,1);
		$Limit = 20;
		$Page = $_GET['page']?intval($_GET['page']):1;
		/* ��ѯ���� End */
		/* ģ����� */		
		showtagheader('div', 'row', true,'row');
		showtagheader('div', 'col-12', true,'col-12');
		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-body', true,'box-body');
		/* ���� */
		$StateSelected = array($_GET['expire_vip_push']=>' selected');
		$OrderSelected = array($_GET['order']=>' selected');
		echo <<<SEARCH
		<form method="post" autocomplete="off" action="$SearUrl" id="tb_search">
			<div class="FormSearchTo">
				<table cellspacing="4" cellpadding="4">
					<tr>
						<th>{$Fn_XiangQin->Config['LangVar']['KeywordTitle']}</th><td><input type="text" class="form-control w150" name="keyword" value="{$_GET['keyword']}">
						</td>
						<th>{$Fn_XiangQin->Config['LangVar']['StateTitle']}</th><td>
						<select name="expire_vip_push" class="form-control w120">
							<option value="">{$Fn_XiangQin->Config['LangVar']['SelectNull']}</option>
							<option value="0"{$StateSelected['0']}>{$Fn_XiangQin->Config['LangVar']['RemindingArray'][0]}</option>
							<option value="1"{$StateSelected['1']}>{$Fn_XiangQin->Config['LangVar']['RemindingArray'][1]}</option>
						</select>
						</td>
						<th>{$Fn_XiangQin->Config['LangVar']['SortTitle']}</th><td>
						<select name="order" class="form-control w120">
							<option value="id"{$OrderSelected['id']}>id</option>
							<option value="vip_time"{$OrderSelected['vip_time']}>VIP{$Fn_XiangQin->Config['LangVar']['UserVipTime']}</option>
						</select>
						&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Admin->Config['LangVar']['SearchSubmit']}" class="btn btn-info" type="submit">
					</tr>
				</table>
			</div>
		</form>
SEARCH;
		/* ���� End */	
		showtagheader('div', 'table-responsive', true,'table-responsive');
		showformheader($FormUrl,'enctype="multipart/form-data"');
		showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
		showsubtitle(array(
			'Uid/'.$Fn_XiangQin->Config['LangVar']['UserNameTitle'],
			$Fn_XiangQin->Config['LangVar']['NameTitle'],
			$Fn_XiangQin->Config['LangVar']['ContactTitle'],
			$Fn_XiangQin->Config['LangVar']['WxTitle'],
			'VIP'.$Fn_XiangQin->Config['LangVar']['UserVipTime'],
			$Fn_XiangQin->Config['LangVar']['StateTitle'],
			$Fn_XiangQin->Config['LangVar']['OperationTitle']
		), 'header tbm tc');
		
		$ModulesList = GetModulesList($Page,$Limit,$Where,$Order);
		
		foreach ($ModulesList as $Module) {
			$Module['param'] = unserialize($Module['param']);
			showtablerow('', array('class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
				$Module['uid'] ? $Module['uid'].'<br>'.$Module['username'] : '',
				$Module['face'] ? '<img src="'.$Module['face'].'" height="30"><br>'.$Module['name'] : $Module['name'],
				$Module['mobile'],
				$Module['param']['wx'],
				date('Y-m-d H:i',$Module['vip_time']),
				$Module['expire_vip_push'] != 1 ? '<span class="label bg-danger">'.$Fn_XiangQin->Config['LangVar']['RemindingArray'][$Module['expire_vip_push']].'</span>' : '<span class="label bg-blue">'.$Fn_XiangQin->Config['LangVar']['RemindingArray'][$Module['expire_vip_push']].'</span>',
				'<a href="'.$OpCpUrl.'&do=SmsReminding&uid='.$Module['uid'].'&formhash='.FORMHASH.'" class="btn btn-sm btn-danger-outline">'.$Fn_XiangQin->Config['LangVar']['RemindingBtn'].'</a>',
			));
		}
		showsubmit('','','','','select_all',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');


		/* ģ����� End */
	}
}else if($Do == 'SmsReminding' && $_GET['formhash'] == formhash() && $_GET['uid']){//��������
	//��������
	$Fn_XiangQin->GetExpireVipPush($_GET['uid']);
	fn_cpmsg($Fn_Admin->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
}

/* �б� */
function GetModulesList($Page,$Limit,$Where=null,$Order){
	global $Fn_XiangQin;
	$FetchSql = 'SELECT M.* FROM '.DB::table($Fn_XiangQin->TableMember).' M '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}
/* ���� */
function GetModulesCount($Where=null){
	global $Fn_XiangQin;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_XiangQin->TableMember).' M '.$Where;
	return DB::result_first($FetchSql);//��������
}
//From: Dism_taobao_com
?>