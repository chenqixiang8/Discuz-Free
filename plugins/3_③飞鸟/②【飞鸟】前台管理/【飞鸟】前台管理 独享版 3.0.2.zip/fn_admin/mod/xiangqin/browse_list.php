<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('xiang_all') && !$Fn_Admin->CheckUserGroup('xiangqin_browse_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$Do = in_array($_GET['do'], array('Del')) ? $_GET['do'] : 'List';

//�����ֶ�
$SearField =array('page','uid','order','view_uid');
foreach($SearField as $Val) {
	$SearArray[$Val] = $_GET[$Val] || in_array($_GET[$Val],array('0')) ? $_GET[$Val] : '';
}
//�����ֶ� End

$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeItemUrl'].'&'.http_build_query($SearArray);

if($Do == 'List'){
	if(!submitcheck('Submit')) {
		$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
		/* ��ѯ���� */
		$Where = '';
		$Order = in_array($_GET['order'], array('id')) ? 'L.'.addslashes(dhtmlspecialchars($_GET['order'])) : 'L.id';

		if($_GET['uid']){
			$Where .= ' and L.uid = '.intval($_GET['uid']);
		}

		if($_GET['view_uid']){
			$Where .= ' and L.view_uid = '.intval($_GET['view_uid']);
		}
		
		$Where = preg_replace('/and/','where',$Where,1);
		$Limit = 20;
		$Page = $_GET['page']?intval($_GET['page']):1;
		/* ��ѯ���� End */

		/* ģ����� */	
		showtagheader('div', 'row', true,'row');
		showtagheader('div', 'col-12', true,'col-12');
		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-body', true,'box-body');
		/* ���� */
		$StateSelected = array($_GET['state']=>' selected');
		echo <<<SEARCH
		<form method="post" autocomplete="off" action="$SearUrl" id="tb_search">
			<div class="FormSearchTo">
				<table cellspacing="4" cellpadding="4">
					<tr>
						<th>{$Fn_XiangQin->Config['LangVar']['BrowseUser']}UID</th><td><input type="text" class="form-control w150" name="uid" value="{$_GET['uid']}">
						</td>
						<th>{$Fn_XiangQin->Config['LangVar']['CoverBrowseUser']}UID</th><td><input type="text" class="form-control w150" name="view_uid" value="{$_GET['view_uid']}">
						&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Admin->Config['LangVar']['SearchSubmit']}" class="btn btn-info" type="submit">
						</td>
					</tr>
				</table>
			</div>
		</form>
SEARCH;
		/* ���� End */
		showtagheader('div', 'table-responsive', true,'table-responsive');
		showformheader($FormUrl,'enctype="multipart/form-data"');
		showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
		showsubtitle(array(
			'ID',
			$Fn_XiangQin->Config['LangVar']['BrowseUser'],
			$Fn_XiangQin->Config['LangVar']['CoverBrowseUser'],
			$Fn_XiangQin->Config['LangVar']['TimeTitle'],
			$Fn_XiangQin->Config['LangVar']['OperationTitle']
		), 'header tbm tc');
		
		$ModulesList = GetModulesList($Page,$Limit,$Where,$Order);
		
		foreach ($ModulesList as $Module) {
			$UserInfo = $Fn_XiangQin->GetUserInfo($Module['uid']);
			$CoverUserInfo = $Fn_XiangQin->GetUserInfo($Module['view_uid']);
			showtablerow('', array('class="tc w100"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
				'<input type="checkbox" class="filled-in" id="checkbox_'.$Module['id'].'" name="delete[]" value="'.$Module['id'].'"><label for="checkbox_'.$Module['id'].'">'.$Module['id'].'</label>',
				'Uid/'.$UserInfo['uid'].'----'.$Fn_XiangQin->Config['LangVar']['UserNameTitle'].'/'.$UserInfo['username'].'<br>'.$Fn_XiangQin->Config['LangVar']['NameTitle'].'/'.$UserInfo['name'].'/'.$Fn_XiangQin->Config['LangVar']['SexArray'][$UserInfo['sex']].'<br>'.$Fn_XiangQin->Config['LangVar']['MobileTitle'].'/'.$UserInfo['mobile'].'<br>'.$Fn_XiangQin->Config['LangVar']['WxTitle'].'/'.$UserInfo['param']['wx'],
				'Uid/'.$CoverUserInfo['uid'].'----'.$Fn_XiangQin->Config['LangVar']['UserNameTitle'].'/'.$CoverUserInfo['username'].'<br>'.$Fn_XiangQin->Config['LangVar']['NameTitle'].'/'.$CoverUserInfo['name'].'/'.$Fn_XiangQin->Config['LangVar']['SexArray'][$CoverUserInfo['sex']].'<br>'.$Fn_XiangQin->Config['LangVar']['MobileTitle'].'/'.$CoverUserInfo['mobile'].'<br>'.$Fn_XiangQin->Config['LangVar']['WxTitle'].'/'.$CoverUserInfo['param']['wx'],
				date('Y-m-d H:i',$Module['dateline']),
				'<a href="'.$OpCpUrl.'&do=Del&lid='.$Module['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$Fn_XiangQin->Config['LangVar']['DelTitle'].'</a>',
			));
		}
		showsubmit('Submit','&#31435;&#21363;&#25552;&#20132;','del','','',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));
        showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		/* ģ����� End */
	}else{
		if(isset($_GET['delete']) && is_array($_GET['delete'])){
			if(!$Fn_Admin->CheckUserGroup('xiang_all') && !$Fn_Admin->CheckUserGroup('xiangqin_collection_list_del')){//Ȩ���ж�
				fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
				exit();
			}
			foreach($_GET['delete'] as $Key => $Val) {
				$Val = intval($Val);
				DB::delete($Fn_XiangQin->TableViewLog,'id ='.$Val);
			}

			GetInsertDoLog('del_browse_xiangqin','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete'])));//������¼

			fn_cpmsg($Fn_XiangQin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
		}else{
			fn_cpmsg($Fn_XiangQin->Config['LangVar']['DelErr'],'','error');
		}
	}
}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['lid']){//ɾ��
	if(!$Fn_Admin->CheckUserGroup('xiang_all') && !$Fn_Admin->CheckUserGroup('xiangqin_collection_list_del')){//Ȩ���ж�
		fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
		exit();
	}
	$Lid = intval($_GET['lid']);
	DB::delete($Fn_XiangQin->TableViewLog,'id ='.$Lid);
	
	GetInsertDoLog('del_browse_xiangqin','fn_'.$_GET['mod'],array('id'=>$_GET['lid']));//������¼

	fn_cpmsg($Fn_XiangQin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
}

/* �б� */
function GetModulesList($Page,$Limit,$Where=null,$Order){
	global $Fn_XiangQin;
	$FetchSql = 'SELECT L.* FROM '.DB::table($Fn_XiangQin->TableViewLog).' L '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}

/* ���� */
function GetModulesCount($Where=null){
	global $Fn_XiangQin;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_XiangQin->TableViewLog).' L '.$Where;
	return DB::result_first($FetchSql);//��������
}
//From: Dism_taobao_com
?>