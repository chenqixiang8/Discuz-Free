<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('xiang_all') && !$Fn_Admin->CheckUserGroup('xiangqin_matchmaker')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$SubModel = in_array($_GET['submodel'], array('list','add')) ? $_GET['submodel'] : 'list';
$Fn_Admin->Config['IframeSubModelUrl'] = $Fn_Admin->Config['IframeItemUrl'].'&submodel='.$SubModel;
$NavClass = array($SubModel=>'btn-info Hover');

//����
echo <<<Nav
<div class="SubModelNav">
  <ul>
	<li class="{$NavClass['list']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=list" target="_self">{$Fn_Admin->Config['LangVar']['XiangqinLeftNavArray']['matchmaker']}</a></li>
    <li class="{$NavClass['add']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=add" target="_self">{$Fn_Admin->Config['LangVar']['AddMatchmaker']}</a></li>
  </ul>
  <div class="both"></div>
</div>
Nav;

if($SubModel == 'list'){//�б�
	$Do = in_array($_GET['do'], array('Del')) ? $_GET['do'] : 'submodel_list';
	//�����ֶ�
	$SearField =array('page','keyword');
	foreach($SearField as $Val) {
		$SearArray[$Val] = $_GET[$Val] || in_array($_GET[$Val],array('0')) ? $_GET[$Val] : '';
	}
	//�����ֶ� End
	$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeSubModelUrl'].'&'.http_build_query($SearArray);


	if($Do == 'submodel_list'){
		if(!submitcheck('Submit')) {
			$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
			$Where = '';
			$Order = in_array($_GET['order'], array('id')) ? 'M.'.addslashes(dhtmlspecialchars($_GET['order'])) : 'M.id';
			if($_GET['keyword']){
				$Where .= ' and concat(M.username,M.uid,M.name) like(\'%'.addslashes(dhtmlspecialchars(str_replace(array('%','_'),array('',''),$_GET['keyword']))).'%\')';
			}
			$Where = preg_replace('/and/','where',$Where,1);
			$Limit = 20;
			$Page = $_GET['page']?intval($_GET['page']):1;
			/* ��ѯ���� End */

			/* ģ����� */	
			showtagheader('div', 'row', true,'row');
			showtagheader('div', 'col-12', true,'col-12');
			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-body', true,'box-body');

			/* ���� */
			echo <<<SEARCH
			<form method="post" autocomplete="off" action="$SearUrl">
				<div class="FormSearchTo" style="margin-bottom:0;">
					<table cellspacing="4" cellpadding="4">
						<tr>
							<th>{$Fn_XiangQin->Config['LangVar']['KeywordTitle']}</th><td><input type="text" class="form-control w200" name="keyword" value="{$_GET['keyword']}">
							&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Admin->Config['LangVar']['SearchSubmit']}" class="btn btn-info" type="submit">
							</td>
						</tr>
			
					</table>
				</div>
			</form>
SEARCH;
			/* ���� End */
			showtagheader('div', 'table-responsive', true,'table-responsive');
			showformheader($FormUrl,'enctype="multipart/form-data"');
			showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
			showsubtitle(array(
				'ID',
				'Uid/'.$Fn_XiangQin->Config['LangVar']['UserNameTitle'],
				$Fn_XiangQin->Config['LangVar']['MatchmakerNameTitle'],
				$Fn_XiangQin->Config['LangVar']['MatchmakerFaceTitle'],
				$Fn_XiangQin->Config['LangVar']['MatchmakerWxTitle'],
				$Fn_XiangQin->Config['LangVar']['MatchmakerWxQrTitle'],
				$Fn_XiangQin->Config['LangVar']['MatchmakerUserCount'],
				$Fn_XiangQin->Config['LangVar']['OperationTitle']
			),'header tbm tc');

			$ModulesList = GetModulesList($Page,$Limit,$Where,$Order);
			foreach ($ModulesList as $Module) {
				$Module['param'] = unserialize($Module['param']);
				$UserCount = DB::result_first('SELECT COUNT(*) FROM '.DB::table($Fn_XiangQin->TableMember).' where mid = '.intval($Module['uid']));
				showtablerow('', array('class="tc w80"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
					'<input type="checkbox" class="filled-in" id="checkbox_'.$Module['uid'].'" name="delete[]" value="'.$Module['uid'].'"><label for="checkbox_'.$Module['uid'].'"></label>',
					$Module['uid'] ? $Module['uid'].'<br>'.$Module['username'] : '',
					$Module['name'],
					$Module['param']['face'] ? '<img src="'.$Module['param']['face'].'" height="30">' : '',
					$Module['param']['wx'],
					$Module['param']['wx_qr'] ? '<img src="'.$Module['param']['wx_qr'].'" height="30">' : '',
					$UserCount,
					'<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&mid='.$Module['id'].'" class="btn btn-sm btn-info-outline">'.$Fn_XiangQin->Config['LangVar']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Del&mid='.$Module['uid'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$Fn_XiangQin->Config['LangVar']['DelTitle'].'</a>',
				));
			}

			/* �����б�Html */
			$MoveMatchmakerHtml = '<select name="new_mid" class="form-control w120"><option value="">'.$Fn_XiangQin->Config['LangVar']['SelectNull'].'</option>';
			foreach ($Fn_XiangQin->GetMatchmakerList() as $Key=>$Val) {
				$MoveMatchmakerHtml .= '<option value="'.$Val['uid'].'">'.$Val['name'].'</option>';
			}
			$MoveMatchmakerHtml .= '</select>';
			/* �����б�Html End*/
			showsubmit('Submit','&#31435;&#21363;&#25552;&#20132;','<input name="optype" value="Move" class="with-gap" type="radio" id="v_Move"><label class="custom-control-label" for="v_Move" style="margin-left:-5px;">'.$Fn_XiangQin->Config['LangVar']['MoveMatchmakerUser'].'</label>&nbsp;&nbsp;'.$MoveMatchmakerHtml,'','select_all','');
			showtablefooter(); /*dism��taobao��com*/
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			/* ģ�����End */	
		}else{
			if(isset($_GET['delete']) && is_array($_GET['delete'])){
				if($_GET['optype'] == 'Move' && $_GET['new_mid']){//�ƶ�����
					foreach($_GET['delete'] as $Key => $Val) {
						$Val = intval($Val);
						$UpData['mid'] = intval($_GET['new_mid']);
						DB::update($Fn_XiangQin->TableMember,$UpData,'mid = '.$Val);
						DB::update($Fn_XiangQin->TableReport,$UpData,'mid = '.$Val);
					}

					GetInsertDoLog('move_matchmaker_user_xiangqin','fn_'.$_GET['mod'],array('uid'=>implode(',',$_GET['delete']),'mid'=>$_GET['new_mid']));//������¼

					fn_cpmsg($Fn_XiangQin->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
				}else{
					fn_cpmsg($Fn_XiangQin->Config['LangVar']['OpErr'],'','error');
				}
			}else{
				fn_cpmsg($Fn_XiangQin->Config['LangVar']['OpErr'],'','error');
			}	
		}
	}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['mid']){
		$Mid = intval($_GET['mid']);
		$UpData['mid'] = '';
		DB::delete($Fn_XiangQin->TableMatchmaker,'uid ='.$Mid);
		DB::update($Fn_XiangQin->TableMember,$UpData,'mid = '.$Mid);
		DB::update($Fn_XiangQin->TableReport,$UpData,'mid = '.$Mid);
		
		GetInsertDoLog('del_matchmaker_xiangqin','fn_'.$_GET['mod'],array('uid'=>$Mid));//������¼

		fn_cpmsg($Fn_Admin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
	}
}else if($SubModel == 'add'){//���ӻ�༭

	$Mid = intval($_GET['mid']);
	$Item = DB::fetch_first('SELECT * FROM '.DB::table($Fn_XiangQin->TableMatchmaker).' where id = '.$Mid);
	if($Item)$Item['param'] = unserialize($Item['param']);
	if(!submitcheck('DetailSubmit')) {
		$OpTitle = $Fn_XiangQin->Config['LangVar']['AddTitle'];
		if($Item)$OpTitle = $Fn_XiangQin->Config['LangVar']['EditTitle'];


		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-header', true,'with-border box-header');
		showtitle($OpTitle,'class="box-title"');
		showtagfooter('div');
		showformheader($Fn_Admin->Config['IframeSubModelUrl'].'&mid='.$Mid,'enctype');
		showtagheader('div', 'box-body', true,'box-body');

		showsetting($Fn_XiangQin->Config['LangVar']['MatchmakerTitle'].'Uid', 'new_uid', $Item['uid'], 'text');
		showsetting($Fn_XiangQin->Config['LangVar']['MatchmakerNameTitle'], 'name', $Item['name'], 'text');
		showsetting($Fn_XiangQin->Config['LangVar']['MatchmakerWxTitle'], 'wx', $Item['param']['wx'], 'text');
		
		if($Item['param']['wx_qr']) {
			$WxQrHtml = '<label><input type="checkbox" class="checkbox" name="del_wx_qr" value="yes" /> '.$lang['delete'].'</label><br /><a href="'.$Item['param']['wx_qr'].'" target="_blank"><img src="'.$Item['param']['wx_qr'].'" width="45"/></a><input type="hidden" value="'.$Item['param']['wx_qr'].'" name="wx_qr"><br />';
		}
		showsetting($Fn_XiangQin->Config['LangVar']['MatchmakerWxQrTitle'], 'new_wx_qr','', 'filetext', '', 0, $WxQrHtml);
		
		if($Item['param']['face']) {
			$FaceHtml = '<label><input type="checkbox" class="checkbox" name="del_face" value="yes" /> '.$lang['delete'].'</label><br /><a href="'.$Item['param']['face'].'" target="_blank"><img src="'.$Item['param']['face'].'" width="45"/></a><input type="hidden" value="'.$Item['param']['face'].'" name="face"><br />';
		}
		showsetting($Fn_XiangQin->Config['LangVar']['MatchmakerFaceTitle'], 'new_face','', 'filetext', '', 0, $FaceHtml);
		
		showsubmit('DetailSubmit','&#20445;&#23384;&#37197;&#32622;');
		showtagfooter('div');
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');
	}else{
		
		$Data['uid'] = intval($_GET['new_uid']);
		$Data['name'] = addslashes(strip_tags($_GET['name']));
		$Param['wx'] = addslashes(strip_tags($_GET['wx']));
	
		/* ��ά�� */
		if($_GET['del_wx_qr'] == 'yes'){
			unlink(DISCUZ_ROOT.$Item['param']['wx_qr']);
			$Param['wx_qr'] = '';
		}else{
			$Param['wx_qr'] = addslashes(strip_tags($_GET['wx_qr']));
		}
		if($_FILES['new_wx_qr']['size']){
			$WxQrFile = $Fn_Admin->Upload($_FILES['new_wx_qr'],DISCUZ_ROOT.$Item['wx_qr']);
			if($WxQrFile['Errorcode']){
				cpmsg($Fn_XiangQin->Config['LangVar']['ImgErr'],'','error');
			}else{
				$Param['wx_qr']  = $WxQrFile['Path'];
			}
		}else if($_GET['new_wx_qr']){
			$Param['wx_qr'] = addslashes(strip_tags($_GET['new_wx_qr']));
		}
		/* ��ά�� End */

		/* ͷ�� */
		if($_GET['del_wx_qr'] == 'yes'){
			unlink(DISCUZ_ROOT.$Item['param']['face']);
			$Param['face'] = '';
		}else{
			$Param['face'] = addslashes(strip_tags($_GET['face']));
		}
		if($_FILES['new_face']['size']){
			$WxQrFile = $Fn_Admin->Upload($_FILES['new_face'],DISCUZ_ROOT.$Item['face']);
			if($WxQrFile['Errorcode']){
				cpmsg($Fn_XiangQin->Config['LangVar']['ImgErr'],'','error');
			}else{
				$Param['face']  = $WxQrFile['Path'];
			}
		}else if($_GET['new_face']){
			$Param['face'] = addslashes(strip_tags($_GET['new_face']));
		}
		/* ͷ�� End */

		$Data['param'] = serialize($Param);
		$Member = DB::fetch_first('SELECT username FROM '.DB::table('common_member').' where uid = '.$Data['uid']);
		
		if($Member){
			//����û��Ƿ����
			$CheckUserInfo = DB::fetch_first('SELECT * FROM '.DB::table($Fn_XiangQin->TableMatchmaker).' where uid = '.$Data['uid']);
			if(($CheckUserInfo && !$Item) || ($Item['uid'] != $Data['uid'] && $CheckUserInfo)){
				fn_cpmsg($Fn_XiangQin->Config['LangVar']['CheckUserErr'],'','error');
				exit();
			}

			$Data['username'] = addslashes(strip_tags($Member['username']));
			if($Item){
				GetInsertDoLog('edit_matchmaker_xiangqin','fn_'.$_GET['mod'],array('uid'=>$Data['uid']));//������¼
				DB::update($Fn_XiangQin->TableMatchmaker,$Data,'id = '.$Mid);
			}else{
				$Data['dateline'] = time();
				DB::insert($Fn_XiangQin->TableMatchmaker,$Data);
				GetInsertDoLog('add_matchmaker_xiangqin','fn_'.$_GET['mod'],array('uid'=>$Data['uid']));//������¼
			}
			fn_cpmsg($Fn_XiangQin->Config['LangVar']['UpdateOk'],$Fn_Admin->Config['IframeItemUrl'].'&submodel=list','succeed');
			exit();
		}else{
			fn_cpmsg($Fn_XiangQin->Config['LangVar']['NoUserErr'],'','error');
			exit();
		}
	}
}


/* �б� */
function GetModulesList($Page,$Limit,$Where=null,$Order){
	global $Fn_XiangQin;
	$FetchSql = 'SELECT M.* FROM '.DB::table($Fn_XiangQin->TableMatchmaker).' M '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}

/* ���� */
function GetModulesCount($Where=null){
	global $Fn_XiangQin;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_XiangQin->TableMatchmaker).' M '.$Where;
	return DB::result_first($FetchSql);//��������
}

?>