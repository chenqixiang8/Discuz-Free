<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

//Ȩ���ж�
if(!$Fn_Admin->CheckUserGroup('xiangqin_all') && !$Fn_Admin->CheckUserGroup('xiangqin_data_statistics')){
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$Timestamp = strtotime(date('Y-m-d'));
$WeekDay = strtotime(date('Y-m-d',$Timestamp - (date('N',$Timestamp)-1) * 86400));//���ܵ�һ��
$EndWeekDay = strtotime(date('Y-m-d 23:59:59',strtotime("+6 day",$WeekDay)));

$FirstDay = strtotime(date('Y-m-01', strtotime(date("Y-m-d"))));//���µ�һ��  
$LastDay = strtotime(date('Y-m-d 23:59:59', strtotime("+1 month -1 day",$FirstDay)));//�������һ�� 

$LastLasDday = strtotime(date('Y-m-01', strtotime('-1 month',$FirstDay)));//�ϸ��µ�һ��  
$LastFirstDay = strtotime(date('Y-m-t 23:59:59', strtotime('-1 month',$FirstDay)));//�ϸ������һ��
$mat = $fn_xiangqin->matList[$_G['uid']];
if(!$Fn_Admin->CheckUserGroup('xiangqin_all')){
	$CountWhere .= ' and M.mat_id = '.intval($mat['id']);
}else if($Fn_Admin->CheckUserGroup('xiangqin_all') && $_GET['mat_id'] && $_GET['mat_id'] != 'count'){
	$CountWhere .= ' and M.mat_id = '.intval($_GET['mat_id']);
}

//����ͳ��
$UserCount = GetModulesCount(preg_replace('/and/','where',$CountWhere,1));
$Sex1UserCount = GetModulesCount(' where M.sex = 1'.$CountWhere);
$Sex2UserCount = GetModulesCount(' where M.sex = 2'.$CountWhere);
$VipUserCount = GetModulesCount(' where M.due_time >= '.time().$CountWhere);
$expiredVipUserCount = GetModulesCount(' where M.due_time != \'\' and M.due_time <= '.time().$CountWhere);
$AuditUserCount = GetModulesCount(' where M.audit_state = 2');

$TodayCountUser = GetModulesCount(' where M.dateline >='.strtotime(date('Y-m-d')).' and M.dateline <='.strtotime(date('Y-m-d 23:59:59')).$CountWhere);
$MonthCountUser = GetModulesCount(' where M.dateline >='.$FirstDay.' and M.dateline <='.$LastDay.$CountWhere);

$verifyCount = C::t('#fn_xiangqin#fn_love_verify')->first_by_count(' where v.audit_state = 2');
$certCount = C::t('#fn_xiangqin#fn_love_verify')->first_by_count(' where v.type = 1 and v.audit_state = 2');
$certeduCount = C::t('#fn_xiangqin#fn_love_verify')->first_by_count(' where v.type = 2 and v.audit_state = 2');
$certcarCount = C::t('#fn_xiangqin#fn_love_verify')->first_by_count(' where v.type = 3 and v.audit_state = 2');
$certhouseCount = C::t('#fn_xiangqin#fn_love_verify')->first_by_count(' where v.type = 4 and v.audit_state = 2');

$reporCount = C::t('#fn_xiangqin#fn_love_user_report')->first_by_count(' where r.state = 0');

if(!$Fn_Admin->CheckUserGroup('xiangqin_all')){
	$PayCountWhere .= ' and L.staff_id = '.intval($mat['id']);
}else if($Fn_Admin->CheckUserGroup('xiangqin_all') && $_GET['mat_id'] && $_GET['mat_id'] != 'count'){
	$PayCountWhere .= ' and L.staff_id = '.intval($_GET['mat_id']);
}
//����ͳ��
$MonthCountMoney = GetModulesScreenMoneyCount('where source = \'fn_xiangqin\' and L.refund = 0 and L.state = 1 and L.dateline >= '.$FirstDay.' and L.dateline <='.$LastDay.$PayCountWhere);

$LastMonthCountMoney = GetModulesScreenMoneyCount('where source = \'fn_xiangqin\' and L.refund = 0 and L.state = 1 and L.dateline >= '.$LastLasDday.' and L.dateline <='.$LastFirstDay.$PayCountWhere);

$TodayCountMoney = GetModulesScreenMoneyCount('where source = \'fn_xiangqin\' and L.refund = 0 and L.state = 1 and L.dateline >= '.strtotime(date('Y-m-d')).' and L.dateline <='.strtotime(date('Y-m-d 23:59:59')).$PayCountWhere);

$WeekCountMoney = GetModulesScreenMoneyCount('where source = \'fn_xiangqin\' and L.refund = 0 and L.state = 1 and L.dateline >= '.$WeekDay.' and L.dateline <='.$EndWeekDay.$PayCountWhere);

$CountMoney = GetModulesScreenMoneyCount('where source = \'fn_xiangqin\' and L.refund = 0 and L.state = 1 '.$PayCountWhere);

for($i = 1;$i < 13; $i++){
	$k = $i;
	$YearMonthLast = strtotime(date('Y').'-'.($i > 9 ? $i : '0'.$i).'-01'); 
	$YearMonthFirst = strtotime(date('Y-m-d 23:59:59', strtotime("+1 month -1 day",$YearMonthLast)));
	$YearMonthCount[$k -1]['m'] = date('Y').'-'.($i > 9 ? $i : '0'.$i);
	$YearMonthCount[$k -1]['item'] = GetModulesScreenMoneyCount('where source = \'fn_xiangqin\' and L.refund = 0 and L.state = 1 and L.dateline >= '.$YearMonthLast.' and L.dateline <='.$YearMonthFirst.$PayCountWhere);
	
	$LastYearMonthCount[$k -1]['m'] = (date('Y') - 1).'-'.($i > 9 ? $i : '0'.$i);
	$LastYearMonthCount[$k -1]['item'] = GetModulesScreenMoneyCount('where source = \'fn_xiangqin\' and L.refund = 0 and L.state = 1 and L.dateline >= '.strtotime('-1 year',$YearMonthLast).' and L.dateline <='.strtotime('-1 year',$YearMonthFirst).$PayCountWhere);
}
$YearMonthCountJson = json_encode($YearMonthCount);
$LastMonthCountJson = json_encode($LastYearMonthCount);


if($Fn_Admin->CheckUserGroup('xiangqin_all')){
$mat_id = $_GET['mat_id'] ? $_GET['mat_id'] : 'count';
$NavClass = array($mat_id=>'btn-info Hover');
foreach ($fn_xiangqin->matList as $Key=>$Val) {
	$SubModelNav .= '<li class="'.$NavClass[$Val['id']].'"><a href="'.$Fn_Admin->Config['IframeItemUrl'].'&mat_id='.$Val['id'].'" target="_self">'.$Val['name'].$Fn_Admin->Config['LangVar']['HeDataStatistics'].'</a></li>';
}
echo <<<Nav
<div class="SubModelNav">
  <ul>
	<li class="{$NavClass['count']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&mat_id=count" target="_self">{$Fn_Admin->Config['LangVar']['CountDataStatistics']}</a></li>
    {$SubModelNav}
  </ul>
  <div class="both"></div>
</div>
Nav;
}

echo <<<TABLE
<div class="row">
  <div class="col-12">
    <div class="box">
      <div class="box-body">
        <div class="flexbox">
          <h5>&#23454;&#26102;&#25968;&#25454;</h5>
        </div>
        <div class="row">
          <div class="col-sm-6 col-lg-2">
            <div class="box-body">
              <div class="font-size-40 font-weight-200">{$TodayCountUser}</div>
              <div>&#20170;&#26085;&#26032;&#22686;</div>
            </div>
          </div>
          <div class="col-sm-6 col-lg-2">
            <div class="box-body">
              <div class="font-size-40 font-weight-200">{$MonthCountUser}</div>
              <div>&#26412;&#26376;&#26032;&#22686;</div>
            </div>
          </div>
          <div class="col-sm-6 col-lg-2">
            <div class="box-body">
			  <a href="{$Fn_Admin->Config[IframeModUrl]}&item=user_list&sex=1&mat_id={$_GET[mat_id]}">
              <div class="font-size-40 font-weight-200">{$Sex1UserCount}</div>
              <div>&#30007;&#29992;&#25143;&#25968;</div>
			  </a>
            </div>
          </div>
          <div class="col-sm-6 col-lg-2">
            <div class="box-body">
			  <a href="{$Fn_Admin->Config[IframeModUrl]}&item=user_list&sex=2&mat_id={$_GET[mat_id]}">
              <div class="font-size-40 font-weight-200">{$Sex2UserCount}</div>
              <div>&#22899;&#29992;&#25143;&#25968;</div>
			  </a>
            </div>
          </div>
		  <div class="col-sm-6 col-lg-2">
            <div class="box-body">
			  <a href="{$Fn_Admin->Config[IframeModUrl]}&item=user_list&mat_id={$_GET[mat_id]}">
              <div class="font-size-40 font-weight-200">{$UserCount}</div>
              <div>&#24635;&#29992;&#25143;&#25968;</div>
			  </a>
            </div>
          </div>
		  <div class="col-sm-6 col-lg-2">
            <div class="box-body">
			  <a href="{$Fn_Admin->Config[IframeModUrl]}&item=user_list&is_vip=1&mat_id={$_GET[mat_id]}">
              <div class="font-size-40 font-weight-200">{$VipUserCount}</div>
              <div>&#20250;&#21592;&#29992;&#25143;&#25968;</div>
			  </a>
            </div>
          </div>
		  <div class="col-sm-6 col-lg-2">
            <div class="box-body">
			  <a href="{$Fn_Admin->Config[IframeModUrl]}&item=user_list&expired=1&mat_id={$_GET[mat_id]}">
              <div class="font-size-40 font-weight-200">{$expiredVipUserCount}</div>
              <div>&#36807;&#26399;&#20250;&#21592;&#29992;&#25143;&#25968;</div>
			  </a>
            </div>
          </div>
		  <div class="col-sm-6 col-lg-2">
            <div class="box-body">
			  <a href="{$Fn_Admin->Config[IframeModUrl]}&item=user_report_list&state=0">
              <div class="font-size-40 font-weight-200">{$reporCount}</div>
              <div>&#20030;&#25253;&#24453;&#22788;&#29702;</div>
			  </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- /.col -->
</div>

<div class="row">
  <div class="col-12">
    <div class="box">
      <div class="box-body">
        <div class="flexbox">
          <h5>&#24453;&#23457;&#26680;</h5>
        </div>
        <div class="row">
		  <div class="col-sm-6 col-lg-2">
            <div class="box-body">
			  <a href="{$Fn_Admin->Config[IframeModUrl]}&item=user_list&audit_state=2&mat_id={$_GET[mat_id]}">
              <div class="font-size-40 font-weight-200">{$AuditUserCount}</div>
              <div>&#24453;&#23457;&#29992;&#25143;</div>
			  </a>
            </div>
          </div>
		  <div class="col-sm-6 col-lg-2">
            <div class="box-body">
			  <a href="{$Fn_Admin->Config[IframeModUrl]}&item=verify_list&audit_state=2">
              <div class="font-size-40 font-weight-200">{$verifyCount}</div>
              <div>&#35748;&#35777;&#24453;&#23457;&#26680;</div>
			  </a>
            </div>
          </div>
          <div class="col-sm-6 col-lg-2">
            <div class="box-body">
			  <a href="{$Fn_Admin->Config[IframeModUrl]}&item=verify_list&type=1&audit_state=2">
              <div class="font-size-40 font-weight-200">{$certCount}</div>
              <div>&#23454;&#21517;&#35748;&#35777;&#24453;&#23457;&#26680;</div>
			  </a>
            </div>
          </div>
          <div class="col-sm-6 col-lg-2">
            <div class="box-body">
			  <a href="{$Fn_Admin->Config[IframeModUrl]}&item=verify_list&type=2&audit_state=2">
              <div class="font-size-40 font-weight-200">{$certeduCount}</div>
              <div>&#23398;&#21382;&#35748;&#35777;&#24453;&#23457;&#26680;</div>
			  </a>
            </div>
          </div>
		  <div class="col-sm-6 col-lg-2">
            <div class="box-body">
			  <a href="{$Fn_Admin->Config[IframeModUrl]}&item=verify_list&type=3&audit_state=2">
              <div class="font-size-40 font-weight-200">{$certcarCount}</div>
              <div>&#36710;&#35748;&#35777;&#24453;&#23457;&#26680;</div>
			  </a>
            </div>
          </div>
		  <div class="col-sm-6 col-lg-2">
            <div class="box-body">
			  <a href="{$Fn_Admin->Config[IframeModUrl]}&item=verify_list&type=4&audit_state=2">
              <div class="font-size-40 font-weight-200">{$certhouseCount}</div>
              <div>&#25151;&#35748;&#35777;&#24453;&#23457;&#26680;</div>
			  </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- /.col -->
</div>

	
<div class="row">
  <div class="col-md-6 col-lg-20">
    <div class="box">
      <div class="box-body">
        <div class="flexbox">
          <h5>&#20170;&#26085;&#20805;&#20540;&#37329;&#39069;</h5>
        </div>
        <div class="text-center my-2">
          <div class="font-size-50">{$TodayCountMoney}</div>
          <span class="text-muted">&#20803;</span> </div>
      </div>
      <div class="card-body bg-gray-light py-12"> <span class="text-muted mr-1"> Top up today</span></div>
    </div>
  </div>
  <!-- /.col -->
  <div class="col-md-6 col-lg-20">
    <div class="box">
      <div class="box-body">
        <div class="flexbox">
          <h5>&#26412;&#21608;&#20805;&#20540;&#37329;&#39069;</h5>
        </div>
        <div class="text-center my-2">
          <div class="font-size-50">{$WeekCountMoney}</div>
          <span class="text-muted">&#20803;</span> </div>
      </div>
      <div class="box-body bg-gray-light py-12"> <span class="text-muted mr-1">Recharge amount this week</span> </div>
    </div>
  </div>
  <!-- /.col -->
  <div class="col-md-6 col-lg-20">
    <div class="box">
      <div class="box-body">
        <div class="flexbox">
          <h5>&#26412;&#26376;&#20805;&#20540;&#37329;&#39069;</h5>
        </div>
        <div class="text-center my-2">
          <div class="font-size-50">{$MonthCountMoney}</div>
          <span class="text-muted">&#20803;</span> </div>
      </div>
      <div class="box-body bg-gray-light py-12"> <span class="text-muted mr-1">Recharge amount of this month</span> </div>
    </div>
  </div>
  <!-- /.col -->
  <div class="col-md-6 col-lg-20">
    <div class="box">
      <div class="box-body">
        <div class="flexbox">
          <h5>&#19978;&#26376;&#20805;&#20540;&#37329;&#39069;</h5>
        </div>
        <div class="text-center my-2">
          <div class="font-size-50">{$LastMonthCountMoney}</div>
          <span class="text-muted">&#20803;</span> </div>
      </div>
      <div class="box-body bg-gray-light py-12"> <span class="text-muted mr-1">Top up amount of last month</span> </div>
    </div>
  </div>
  <!-- /.col -->
  <div class="col-md-6 col-lg-20">
    <div class="box">
      <div class="box-body">
        <div class="flexbox">
          <h5>&#24635;&#20805;&#20540;&#37329;&#39069;</h5>
        </div>
        <div class="text-center my-2">
          <div class="font-size-50">{$CountMoney}</div>
          <span class="text-muted">&#20803;</span> </div>
      </div>
      <div class="box-body bg-gray-light py-12"> <span class="text-muted mr-1">Total recharge amount</span> </div>
    </div>
  </div>
  <!-- /.col -->
</div>
<div class="row">
  <div class="col-xl-6 col-12">
    <div class="box">
      <div class="box-header with-border">
        <h3 class="box-title">&#20170;&#24180;&#26376;&#20221;&#25910;&#20837;</h3>
        <div class="box-tools pull-right">
          <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i> </button>
          <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
        </div>
      </div>
      <div class="box-body chart-responsive">
        <div class="chart" id="this-year" style="height: 300px;"></div>
      </div>
      <!-- /.box-body -->
    </div>
    <!-- /.box -->
  </div>
  <div class="col-xl-6 col-12">
    <div class="box">
      <div class="box-header with-border">
        <h3 class="box-title">&#21435;&#24180;&#26376;&#20221;&#25910;&#20837;</h3>
        <div class="box-tools pull-right">
          <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i> </button>
          <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
        </div>
      </div>
      <div class="box-body chart-responsive">
        <div class="chart" id="last-year" style="height: 300px;"></div>
      </div>
      <!-- /.box-body -->
    </div>
    <!-- /.box -->
  </div>
</div>
<script>
	var line = new Morris.Line({
		element: 'this-year',
		resize: true,
		data:{$YearMonthCountJson},
		xkey: 'm',
		ykeys: ['item'],
		labels: ['&#37329;&#39069;'],
		lineWidth:2,
		pointFillColors: ['rgba(30,136,229,1)'],
		lineColors: ['rgba(30,136,229,1)'],
		hideHover: 'auto'
    });

	var line = new Morris.Line({
		element: 'last-year',
		resize: true,
		data:{$LastMonthCountJson},
		xkey: 'm',
		ykeys: ['item'],
		labels: ['&#37329;&#39069;'],
		lineWidth:2,
		pointFillColors: ['rgba(30,136,229,1)'],
		lineColors: ['rgba(30,136,229,1)'],
		hideHover: 'auto'
    });
</script>

TABLE;

/* ɸѡ���� */
function GetModulesCount($Where=null){
	return DB::result_first('SELECT COUNT(*) FROM '.DB::table('fn_love_user').' M '.$Where);//��������
}

/* ɸѡ���� */
function GetModulesScreenMoneyCount($Where=null){
	global $fn_xiangqin;
	$SumCount = DB::result_first('SELECT sum(L.money) FROM '.DB::table($fn_xiangqin->pay->TablePayLog).' L '.$Where);
	return $SumCount ? $SumCount : 0;//��������
}
//From: Dism_taobao_com
?>
