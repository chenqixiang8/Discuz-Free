<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

showtagheader('div', 'box', true,'box');
showtagheader('div', 'box-body', true,'box-body');
showtagheader('div', 'tab-content', true,'tab-content');
showsetting($Fn_Renovation->Config['LangVar']['PluginLink'], 'PluginLink',$Fn_Renovation->Config['Url'], 'text');
showsetting($Fn_Renovation->Config['LangVar']['PluginLinkArray'][0], 'PluginLink',$Fn_Renovation->Config['Url'].'&app=1', 'text');
showsetting($Fn_Renovation->Config['LangVar']['PluginLinkArray'][1], 'PluginLink',$Fn_Renovation->Config['ListCaseUrl'].'&class=1', 'text');
showsetting($Fn_Renovation->Config['LangVar']['PluginLinkArray'][2], 'PluginLink',$Fn_Renovation->Config['ListCaseUrl'].'&class=2', 'text');
showsetting($Fn_Renovation->Config['LangVar']['PluginLinkArray'][3], 'PluginLink',$Fn_Renovation->Config['ListCompanyUrl'], 'text');
showsetting($Fn_Renovation->Config['LangVar']['PluginLinkArray'][4], 'PluginLink',$Fn_Renovation->Config['ListCommunityUrl'], 'text');
showsetting($Fn_Renovation->Config['LangVar']['PluginLinkArray'][8], 'PluginLink',$Fn_Renovation->Config['UserCompanyUrl'], 'text');
showsetting($Fn_Renovation->Config['LangVar']['PluginLinkArray'][5], 'PluginLink',$Fn_Renovation->Config['UserUrl'], 'text');
showsetting($Fn_Renovation->Config['LangVar']['PluginLinkArray'][9], 'PluginLink',$Fn_Renovation->Config['MaterialUrl'], 'text');
showsetting($Fn_Renovation->Config['LangVar']['PluginLinkArray'][10], 'PluginLink',$Fn_Renovation->Config['ListMaterialCompanyUrl'], 'text');
showsetting($Fn_Renovation->Config['LangVar']['PluginLinkArray'][11], 'PluginLink',$Fn_Renovation->Config['UserMaterialUrl'], 'text');
showsetting($Fn_Renovation->Config['LangVar']['PluginLinkArray'][12], 'PluginLink',$Fn_Renovation->Config['UserMaterialCompanyUrl'], 'text');
showsetting($Fn_Renovation->Config['LangVar']['PluginLinkArray'][6], 'PluginLink',$Fn_Renovation->Config['ListArtisanUrl'], 'text');
showsetting($Fn_Renovation->Config['LangVar']['PluginLinkArray'][7], 'PluginLink',$Fn_Renovation->Config['UserArtisanUrl'], 'text');
showtagfooter('div');
showtagfooter('div');
showtagfooter('div');

?>