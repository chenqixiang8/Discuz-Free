<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('renovation_all') && !$Fn_Admin->CheckUserGroup('renovation_artisan_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$SubModel = in_array($_GET['submodel'], array('list','add')) ? $_GET['submodel'] : 'list';
$Fn_Admin->Config['IframeSubModelUrl'] = $Fn_Admin->Config['IframeItemUrl'].'&submodel='.$SubModel;
$NavClass = array($SubModel=>'btn-info Hover');
$ArtisanGroupList = $Fn_Renovation->Config['PluginVar']['artisan_group'];
//����
echo <<<Nav
<div class="SubModelNav">
  <ul>
	<li class="{$NavClass['list']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=list" target="_self">{$Fn_Admin->Config['LangVar']['RenovationLeftNavArray'][$_GET['item']]}</a></li>
    <li class="{$NavClass['add']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=add" target="_self">{$Fn_Admin->Config['LangVar']['AddEditTitle']}</a></li>
  </ul>
  <div class="both"></div>
</div>
Nav;

if($SubModel == 'list'){//�б�
	$Do = in_array($_GET['do'], array('Refresh','Del','Display','Verify')) ? $_GET['do'] : 'submodel_list';
	//�����ֶ�
	$SearField =array('page','verify','keyword','display','order','expired','group_id','mobile_verify');
	foreach($SearField as $Val) {
		$SearArray[$Val] = $_GET[$Val] || in_array($_GET[$Val],array('0')) ? $_GET[$Val] : '';
	}
	//�����ֶ� End
	$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeSubModelUrl'].'&'.http_build_query($SearArray);


	if($Do == 'submodel_list'){
		if(!submitcheck('Submit')) {
			$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
			$Where = '';
			$Order = $_GET['order'] ? 'A.'.addslashes(dhtmlspecialchars($_GET['order'])) : 'A.id';
			
			if($_GET['keyword']){
				$_GET['keyword'] = str_replace(array('%','_'),array('',''),$_GET['keyword']);
				$Where .= ' and (A.name like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or A.username like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or A.mobile like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or A.id = '.intval($_GET['keyword']).' )';
			}
			
			if($_GET['group_id']){
				$Where .= ' and A.group_id = '.intval($_GET['group_id']).' and A.due_time >= '.time();
			}

			if(in_array($_GET['display'],array('0','1'))){
				$Where .= ' and A.display = '.intval($_GET['display']);
			}

			if(in_array($_GET['expired'],array('1'))){
				
				$Where .=  ' and A.due_time != \'\' and A.due_time < '.time();
			}

			if(in_array($_GET['mobile_verify'],array('0','1'))){
				$Where .= ' and A.mobile_verify = '.intval($_GET['mobile_verify']);
			}

			if(in_array($_GET['verify'],array('0','1'))){
				$Where .= ' and A.verify = '.intval($_GET['verify']);
			}

			$Where = preg_replace('/and/','where',$Where,1);
			$Limit = 20;
			$Page = $_GET['page']?intval($_GET['page']):1;
			/* ��ѯ���� End */

			/* ģ����� */	
			
			showtagheader('div', 'row', true,'row');
			showtagheader('div', 'col-12', true,'col-12');
			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-body', true,'box-body');
			/* ���� */
			$ExpiredSelected = array($_GET['expired']=>' selected');
			$VerifySelected = array($_GET['verify']=>' selected');
			$DisplaySelected = array($_GET['display']=>' selected');
			$MobileVerifySelected = array($_GET['mobile_verify']=>' selected');
			$OrderSelected = array($_GET['order']=>' selected');

			$GroupListOption = '<option value="">'.$Fn_Renovation->Config['LangVar']['SelectNull'].'</option>';
			foreach($ArtisanGroupList as $Val) {
				$GroupListOption .= '<option value="'.$Val['id'].'" '.($_GET['group_id'] == $Val['id'] ? ' selected' : '' ).'>'.$Val['title'].'</option>';
			}

			echo <<<SEARCH
			<form method="post" autocomplete="off" action="$SearUrl">
				<div class="FormSearchTo" style="margin-bottom:0;">
					<table cellspacing="4" cellpadding="4">
						<tr>
							<th>{$Fn_Renovation->Config['LangVar']['KeywordTitle']}</th><td><input type="text" class="input form-control w300" name="keyword" value="{$_GET['keyword']}" placeholder="{$Fn_Renovation->Config['LangVar']['AdminArtisanPlaceholder']}">
							</td>
							<th>{$Fn_Renovation->Config['LangVar']['Level']}</th><td>
							<select name="group_id" class="form-control w120">
								{$GroupListOption}
							</select>
							
							</td>
							<th>{$Fn_Renovation->Config['LangVar']['IsVerify']}</th><td>
							
							<select name="verify" class="form-control w120">
								<option value="">{$Fn_Renovation->Config['LangVar']['SelectNull']}</option>
								<option value="1"{$VerifySelected['1']}>{$Fn_Renovation->Config['LangVar']['Yes']}</option>
								<option value="0"{$VerifySelected['0']}>{$Fn_Renovation->Config['LangVar']['No']}</option>
							</select>						
							</td>
							<th>{$Fn_Renovation->Config['LangVar']['MobileVerify']}</th><td>
							<select name="mobile_verify" class="form-control w120">
								<option value="">{$Fn_Renovation->Config['LangVar']['SelectNull']}</option>
								<option value="1"{$MobileVerifySelected['1']}>{$Fn_Renovation->Config['LangVar']['Yes']}</option>
								<option value="0"{$MobileVerifySelected['0']}>{$Fn_Renovation->Config['LangVar']['No']}</option>
							</select>
							</td>
							<th>{$Fn_Renovation->Config['LangVar']['ISExpired']}</th><td>
							
							<select name="expired" class="form-control w120">
								<option value="">{$Fn_Renovation->Config['LangVar']['SelectNull']}</option>
								<option value="1"{$ExpiredSelected['1']}>{$Fn_Renovation->Config['LangVar']['Yes']}</option>
							</select>						
							</td>
							<th>{$Fn_Renovation->Config['LangVar']['DisplayTitle']}</th><td>
							<select name="display" class="form-control w120">
								<option value="">{$Fn_Renovation->Config['LangVar']['SelectNull']}</option>
								<option value="1"{$DisplaySelected['1']}>{$Fn_Renovation->Config['LangVar']['Yes']}</option>
								<option value="0"{$DisplaySelected['0']}>{$Fn_Renovation->Config['LangVar']['No']}</option>
							</select>
							</td>
							<th>{$Fn_Admin->Config['LangVar']['Order']}</th><td>
							
							<select name="order" class="form-control w120">
								<option value="dateline"{$OrderSelected['dateline']}>{$Fn_Admin->Config['LangVar']['OrderArray']['dateline']}</option>
								<option value="updateline"{$OrderSelected['updateline']}>{$Fn_Admin->Config['LangVar']['OrderArray']['updateline']}</option>
								<option value="click"{$OrderSelected['click']}>{$Fn_Admin->Config['LangVar']['OrderArray']['click']}</option>
							</select>
							&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Admin->Config['LangVar']['SearchSubmit']}" class="btn btn-info" type="submit">
							</td>
						</tr>
					</table>
				</div>
			</form>
SEARCH;
			/* ���� End */
			showtagheader('div', 'table-responsive', true,'table-responsive');
			showformheader($FormUrl,'enctype="multipart/form-data"');
			showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
			showsubtitle(array(
				'ID',
				'UID/'.$Fn_Renovation->Config['LangVar']['UserNameTitle'],
				$Fn_Renovation->Config['LangVar']['HeadPortrait'],
				$Fn_Renovation->Config['LangVar']['FullName'],
				$Fn_Renovation->Config['LangVar']['Telephone'],
				$Fn_Renovation->Config['LangVar']['WorkYears'],
				$Fn_Renovation->Config['LangVar']['Range'],
				$Fn_Renovation->Config['LangVar']['Level'],
				$Fn_Renovation->Config['LangVar']['CompanyExperience'],
				$Fn_Renovation->Config['LangVar']['IsVerify'],
				$Fn_Renovation->Config['LangVar']['MobileVerify'],
				$Fn_Renovation->Config['LangVar']['DisplayTitle'],
				$Fn_Renovation->Config['LangVar']['DueTime'],
				$Fn_Renovation->Config['LangVar']['RefreshTime'],
				$Fn_Renovation->Config['LangVar']['SetTopTime'],
				$Fn_Renovation->Config['LangVar']['TimeTitle'],
				$Fn_Renovation->Config['LangVar']['OperationTitle']
			),'header tbm tc');

			$ModulesList = $Fn_Renovation->ArtisanListFormat(GetModulesList($Page,$Limit,$Where,$Order));
			foreach ($ModulesList as $Module) {
				
				showtablerow('', array('class="tc w50"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
					'<input type="checkbox" class="filled-in" id="checkbox_'.$Module['id'].'" name="delete[]" value="'.$Module['id'].'"><label for="checkbox_'.$Module['id'].'">'.$Module['id'].'</label>',
					$Module['uid'] ? $Module['uid'].'/'.$Module['username'] : '',
					$Module['face'] ? '<img src="'.$Module['face'].'" style="height:30px;">' : '',
					$Module['name'],
					$Module['mobile'],
					$Module['work_years_age'].$Fn_Renovation->Config['LangVar']['Nian'],
					$Module['range'],
					$Module['due_time'] >= time() ? $ArtisanGroupList[$Module['group_id']]['title'] : '',
					!$Module['experience'] ? '<span class="label bg-secondary">'.$Fn_Renovation->Config['LangVar']['No'].'</span>' : '<span class="label bg-blue">'.$Fn_Renovation->Config['LangVar']['Yes'].'</span>',
					!$Module['verify'] ? '<span class="label bg-secondary">'.$Fn_Renovation->Config['LangVar']['No'].'</span>' : '<span class="label bg-blue">'.$Fn_Renovation->Config['LangVar']['Yes'].'</span>',
					!$Module['mobile_verify'] ? '<span class="label bg-secondary">'.$Fn_Renovation->Config['LangVar']['No'].'</span>' : '<span class="label bg-blue">'.$Fn_Renovation->Config['LangVar']['Yes'].'</span>',
					!$Module['display'] ? '<span class="label bg-secondary">'.$Fn_Renovation->Config['LangVar']['No'].'</span>' : '<span class="label bg-blue">'.$Fn_Renovation->Config['LangVar']['Yes'].'</span>',
					$Module['due_time'] >= time() ? date('Y-m-d',$Module['due_time']) : ($Module['due_time'] ? '<span class="label bg-danger">'.$Fn_Renovation->Config['LangVar']['Expired'].'</span>' : ''),
					$Module['updateline'],
					$Module['topdateline'] && $Module['topdateline'] >= time() ? date('Y-m-d H:i',$Module['topdateline']) : '',
					date('Y-m-d H:i',$Module['dateline']),
					'<a href="'.$Fn_Renovation->Config['ViewArtisanUrl'].$Module['id'].'" target="_blank" class="btn btn-sm btn-dark-outline">'.cplang('view').'</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&aid='.$Module['id'].'" class="btn btn-sm btn-info-outline">'.$Fn_Renovation->Config['LangVar']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Refresh&aid='.$Module['id'].'&formhash='.FORMHASH.'" class="btn btn-sm btn-primary-outline">'.$Fn_Renovation->Config['LangVar']['Refresh'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Verify&aid='.$Module['id'].'&value='.(!empty($Module['verify']) ? 0:1).'&formhash='.FORMHASH.'" class="btn btn-sm btn-success-outline">'.(!empty($Module['verify']) ? $Fn_Renovation->Config['LangVar']['NoVerify'] : $Fn_Renovation->Config['LangVar']['Verify']).'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Display&aid='.$Module['id'].'&value='.(!empty($Module['display']) ? 0:1).'&formhash='.FORMHASH.'" class="btn btn-sm btn-purple-outline">'.(!empty($Module['display']) ? $Fn_Renovation->Config['LangVar']['DisplayNoTitle'] : $Fn_Renovation->Config['LangVar']['DisplayIsTitle']).'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Del&aid='.$Module['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$Fn_Renovation->Config['LangVar']['DelTitle'].'</a>',
				));
			}
			showsubmit('Submit','&#31435;&#21363;&#25552;&#20132;','del','','',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));
			showtablefooter(); /*dism��taobao��com*/
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			/* ģ�����End */	
		}else{
			if(!$Fn_Admin->CheckUserGroup('renovation_all') && !$Fn_Admin->CheckUserGroup('renovation_artisan_del')){//Ȩ���ж�
				fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
				exit();
			}

			if(isset($_GET['delete']) && is_array($_GET['delete'])){
				foreach($_GET['delete'] as $Key => $Val) {
					$Val = intval($Val);
					DB::delete($Fn_Renovation->TableArtisan,'id ='.$Val);
				}

				GetInsertDoLog('del_artisan_list_renovation','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete'])));//������¼

				fn_cpmsg($Fn_Renovation->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
			}else{
				fn_cpmsg($Fn_Renovation->Config['LangVar']['DelErr'],'','error');
			}
				
		}
	}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['aid']){
		if(!$Fn_Admin->CheckUserGroup('renovation_all') && !$Fn_Admin->CheckUserGroup('renovation_artisan_del')){//Ȩ���ж�
			fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
			exit();
		}
		$id = intval($_GET['aid']);
		DB::delete($Fn_Renovation->TableArtisan,'id ='.$id);
		fn_cpmsg($Fn_Admin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
	}else if($Do == 'Refresh' && $_GET['formhash'] == formhash() && $_GET['aid']){
		$id = intval($_GET['aid']);
		$UpData['updateline'] = time();
		DB::update($Fn_Renovation->TableArtisan,$UpData,'id = '.$id);
		GetInsertDoLog('refresh_artisan_list_renovation','fn_'.$_GET['mod'],array('id'=>$id ));//������¼
		fn_cpmsg($Fn_Renovation->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

	}else if($Do == 'Verify' && $_GET['formhash'] == formhash() && $_GET['aid']){
		$id = intval($_GET['aid']);
		$UpData['verify'] = intval($_GET['value']);
		DB::update($Fn_Renovation->TableArtisan,$UpData,'id = '.$id);
		GetInsertDoLog('verify_artisan_list_renovation','fn_'.$_GET['mod'],array('id'=>$id,'verify'=>$_GET['value']));//������¼
		fn_cpmsg($Fn_Renovation->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

	}else if($Do == 'Display' && $_GET['formhash'] == formhash() && $_GET['aid']){
		$id = intval($_GET['aid']);
		$UpData['display'] = intval($_GET['value']);
		DB::update($Fn_Renovation->TableArtisan,$UpData,'id = '.$id);
		GetInsertDoLog('display_artisan_list_renovation','fn_'.$_GET['mod'],array('id'=>$id,'display'=>$_GET['value']));//������¼
		fn_cpmsg($Fn_Renovation->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

	}
}else if($SubModel == 'add'){//���ӻ�༭
	if(!$Fn_Admin->CheckUserGroup('renovation_all') && !$Fn_Admin->CheckUserGroup('renovation_artisan_add')){//Ȩ���ж�
		fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
		exit();
	}
	$id = intval($_GET['aid']);

	$Item = DB::fetch_first('SELECT * FROM '.DB::table($Fn_Renovation->TableArtisan).' where id = '.$id);
	if($Item){
		$Item['param'] = unserialize($Item['param']);
	};
	if(!submitcheck('DetailSubmit')) {
		$OpTitle = $Fn_Renovation->Config['LangVar']['AddTitle'];
		if($Item){
			$OpTitle = $Fn_Renovation->Config['LangVar']['EditTitle'];
		}


		//ͼƬ�ϴ�
		if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_assembly/class/class_upload.php')){
			@require_once libfile('class/upload','plugin/fn_assembly');
			$UploadConfig = fn_upload::Config();
		}
		
		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-header', true,'with-border box-header');
		showtitle($OpTitle,'class="box-title"');
		showtagfooter('div');
		showformheader($Fn_Admin->Config['IframeSubModelUrl'].'&aid='.$id,'enctype');
		showtagheader('div', 'box-body', true,'box-body');

		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_Renovation->Config['LangVar']['HeadPortrait'].'</label><div class="col-sm-9"><div class="AdminSingleUpload"><div class="PhotoControl" id="LogoPhotoControl"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';

		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_Renovation->Config['LangVar']['WorkStyle'].'</label><div class="col-sm-9"><div class="AdminSingleUpload"><div class="PhotoControl" id="WorkStyle"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';
		
		showsetting('uid', 'new_uid', $Item['uid'], 'text');
				
		showsetting($Fn_Renovation->Config['LangVar']['FullName'], 'name', $Item['name'], 'text');

		showsetting($Fn_Renovation->Config['LangVar']['Telephone'], 'mobile', $Item['mobile'], 'text');

		showsetting($Fn_Renovation->Config['LangVar']['MobileVerify'], 'mobile_verify', $Item['mobile_verify'], 'radio');

		showsetting($Fn_Renovation->Config['LangVar']['Range'], 'range', $Item['range'], 'text');

		showsetting($Fn_Renovation->Config['LangVar']['SelfIntroduction'], 'content', str_replace("<br>","\r\n",stripslashes($Item['content'])), 'textarea');
		
		showsetting($Fn_Renovation->Config['LangVar']['WorkYears'], array('work_years',DyadicArray($Fn_Renovation->Config['LangVar']['ArtisanWorkYears'])), $Item['work_years'] , 'select');
		
		showsetting($Fn_Renovation->Config['LangVar']['DecorationSkills'], array('decoration[]',DyadicArray($Fn_Renovation->Config['LangVar']['ArtisanRenovation'])), explode(',',$Item['tag']), 'mselect','','',$Fn_Admin->Config['LangVar']['MselectTips']);

		showsetting($Fn_Renovation->Config['LangVar']['InstallationSkills'], array('install[]',DyadicArray($Fn_Renovation->Config['LangVar']['ArtisanInstall'])), explode(',',$Item['tag']), 'mselect','','',$Fn_Admin->Config['LangVar']['MselectTips']);

		showsetting($Fn_Renovation->Config['LangVar']['RepairSkills'], array('repair[]',DyadicArray($Fn_Renovation->Config['LangVar']['ArtisanRepair'])), explode(',',$Item['tag']), 'mselect','','',$Fn_Admin->Config['LangVar']['MselectTips']);

		showsetting($Fn_Renovation->Config['LangVar']['OtherSkills'], array('other[]',DyadicArray($Fn_Renovation->Config['LangVar']['ArtisanOther'])), explode(',',$Item['tag']), 'mselect','','',$Fn_Admin->Config['LangVar']['MselectTips']);

		$GroupList = array();
		
		foreach($ArtisanGroupList as $Val) {
			$GroupList[] = array($Val['id'], $Val['title']);
		}

		showsetting($Fn_Renovation->Config['LangVar']['Level'], array('group_id', $GroupList),$Item['due_time'] >= time() ? $Item['group_id'] : '', 'mradio');

		showsetting($Fn_Renovation->Config['LangVar']['DueTime'], 'due_time',$Item['due_time'] ? date('Y-m-d',$Item['due_time']) : '', 'calendar');

		showsetting($Fn_Renovation->Config['LangVar']['CompanyExperience'], 'experience', $Item['experience'], 'radio');
		
		showsetting($Fn_Renovation->Config['LangVar']['SetTopTime'], 'topdateline',$Item['topdateline'] ? date('Y-m-d H:i',$Item['topdateline']) : '', 'calendar','','','',1);
		
		if($Item['updateline']){
			showsetting($Fn_Renovation->Config['LangVar']['RefreshTime'], 'updateline',$Item['updateline'] ? date('Y-m-d H:i',$Item['updateline']) : '', 'calendar','','','',1);
		}

		if($Item['dateline']){
			showsetting($Fn_Renovation->Config['LangVar']['TimeTitle'], 'dateline',date('Y-m-d H:i',$Item['dateline']), 'calendar','','','',1);
		}
		
		showsetting($Fn_Renovation->Config['LangVar']['IsVerify'], 'verify', $Item['verify'], 'radio');

		showsetting($Fn_Renovation->Config['LangVar']['Click'], 'click', $Item['click'], 'text');

		showsetting($Fn_Renovation->Config['LangVar']['DisplayTitle'], 'display', $Item ? $Item['display'] : 1, 'radio');
		
		showsubmit('DetailSubmit','&#20445;&#23384;&#37197;&#32622;');
		showtagfooter('div');
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');

		$UpLoadHtml  = '';
		if($Item['face']){
			$LogoJsArray[] = '"'.$Item['face'].'"';;
			$UpLoadHtml .= '
			var InputArray = new Array('.implode(',',$LogoJsArray).');
			$("#LogoPhotoControl").AppUpload({InputName:"new_face",Multiple:true,InputExist:true,InputArray:InputArray});';

		}else{
			$UpLoadHtml .= '$("#LogoPhotoControl").AppUpload({InputName:"new_face",Multiple:true});';
		}

		if($Item['param']['work_style']){
			foreach($Item['param']['work_style'] as $Key => $Val) {
				$WorkStyleJsArray[] = '"'.$Val.'"';
			}
			$UpLoadHtml .= '
			var InputArray = new Array('.implode(',',$WorkStyleJsArray).');
			$("#WorkStyle").AppUpload({InputName:"new_work_style",InputExist:true,InputArray:InputArray});';

		}else{
			$UpLoadHtml .= '$("#WorkStyle").AppUpload({InputName:"new_work_style"});';
		}

		echo $UploadConfig['CssJsHtml'].'<script>'.$UpLoadHtml.'</script>';

	}else{

		foreach($_GET['new_face'] as $Key => $Val) {
			$_GET['new_face'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}
		
		foreach($_GET['new_work_style'] as $Key => $Val) {
			$_GET['new_work_style'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}
		$TagArray = array();
		$TagTextArray = array();

		foreach($_GET['decoration'] as $Key => $Val) {
			$TagArray[] = $Val;
			$TagTextArray[] = $Fn_Renovation->Config['LangVar']['ArtisanRenovation'][$Val];
		}
		foreach($_GET['install'] as $Key => $Val) {
			$TagArray[] = $Val;
			$TagTextArray[] = $Fn_Renovation->Config['LangVar']['ArtisanInstall'][$Val];
		}
		foreach($_GET['repair'] as $Key => $Val) {
			$TagArray[] = $Val;
			$TagTextArray[] = $Fn_Renovation->Config['LangVar']['ArtisanRepair'][$Val];
		}
		foreach($_GET['other'] as $Key => $Val) {
			$TagArray[] = $Val;
			$TagTextArray[] = $Fn_Renovation->Config['LangVar']['ArtisanOther'][$Val];
		}

		$Data['uid'] = intval($_GET['new_uid']);
		$Member = DB::fetch_first('SELECT username FROM '.DB::table('common_member').' where uid = '.$Data['uid']);
		$Data['username'] = addslashes(strip_tags($Member['username']));
		$Data['face'] = addslashes(strip_tags($_GET['new_face'][0]));
		$Data['name'] = addslashes(strip_tags($_GET['name']));
		$Data['mobile'] = addslashes(strip_tags($_GET['mobile']));
		$Data['mobile_verify'] = intval($_GET['mobile_verify']);
		$Data['range'] = addslashes(strip_tags($_GET['range']));
		$Data['work_years'] = intval($_GET['work_years']);
		$Data['content'] = addslashes(str_replace("\r\n","<br>",$_GET['content']));
		$Data['tag'] = implode(',',array_filter($TagArray));
		$Data['click'] = intval($_GET['click']);
		$Data['group_id'] = intval($_GET['group_id']);
		$Data['due_time'] = $_GET['due_time'] ? strtotime($_GET['due_time']) : '';
		$Data['topdateline'] = $_GET['topdateline'] ? strtotime($_GET['topdateline']) : '';
		$Data['experience'] = intval($_GET['experience']);
		$Data['verify'] = intval($_GET['verify']);
		$Data['display'] = intval($_GET['display']);
		
		$Param['work_style'] =  is_array($_GET['new_work_style']) && isset($_GET['new_work_style'])  ? $_GET['new_work_style'] : '';
		$Param['tag_list'] =  is_array($TagTextArray) && isset($TagTextArray) ? $TagTextArray : '';
		$Data['param'] = serialize($Param);
				
		if($Item){
			$Data['updateline'] = strtotime($_GET['updateline']);

			GetInsertDoLog('edit_artisan_list_renovation','fn_'.$_GET['mod'],array('id'=>$id));//������¼

			DB::update($Fn_Renovation->TableArtisan,$Data,'id = '.$id);
				
		}else{
			$Data['dateline'] = $Data['updateline'] = time();

			$Id = DB::insert($Fn_Renovation->TableArtisan,$Data,true);

			GetInsertDoLog('add_artisan_list_renovation','fn_'.$_GET['mod'],array('id'=>$Id));//������¼
		}
		fn_cpmsg($Fn_Renovation->Config['LangVar']['UpdateOk'],$Fn_Admin->Config['IframeItemUrl'].'&submodel=list','succeed');
		
	}
}


/* �б� */
function GetModulesList($Page,$Limit,$Where=null,$Order){
	global $Fn_Renovation;
	$FetchSql = 'SELECT A.* FROM '.DB::table($Fn_Renovation->TableArtisan).' A '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}

/* ���� */
function GetModulesCount($Where=null){
	global $Fn_Renovation;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_Renovation->TableArtisan).' A '.$Where;
	return DB::result_first($FetchSql);//��������
}

?>