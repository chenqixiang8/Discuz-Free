<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('renovation_all') && !$Fn_Admin->CheckUserGroup('renovation_material_goods_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$SubModel = in_array($_GET['submodel'], array('list','add')) ? $_GET['submodel'] : 'list';
$Fn_Admin->Config['IframeSubModelUrl'] = $Fn_Admin->Config['IframeItemUrl'].'&submodel='.$SubModel;
$NavClass = array($SubModel=>'btn-info Hover');

//����
echo <<<Nav
<div class="SubModelNav">
  <ul>
	<li class="{$NavClass['list']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=list" target="_self">{$Fn_Admin->Config['LangVar']['RenovationLeftNavArray'][$_GET['item']]}</a></li>
    <li class="{$NavClass['add']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=add" target="_self">{$Fn_Admin->Config['LangVar']['AddEditTitle']}</a></li>
  </ul>
  <div class="both"></div>
</div>
Nav;

if($SubModel == 'list'){//�б�
	$Do = in_array($_GET['do'], array('Refresh','Del','Display','Index')) ? $_GET['do'] : 'submodel_list';
	//�����ֶ�
	$SearField =array('page','keyword','display','type','company_id','order','index');
	foreach($SearField as $Val) {
		$SearArray[$Val] = $_GET[$Val] || in_array($_GET[$Val],array('0')) ? $_GET[$Val] : '';
	}
	//�����ֶ� End
	$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeSubModelUrl'].'&'.http_build_query($SearArray);


	if($Do == 'submodel_list'){
		if(!submitcheck('Submit')) {
			$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
			$Where = '';
			$Order = $_GET['order'] ? 'G.'.addslashes(dhtmlspecialchars($_GET['order'])) : 'G.id';
			
			if($_GET['keyword']){
				$_GET['keyword'] = str_replace(array('%','_'),array('',''),$_GET['keyword']);
				
				//��ѯ��˾
				$CompanyIds = array();
				foreach (DB::fetch_all('SELECT uid FROM '.DB::table($Fn_Renovation->TableCompany).' where name like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') order by id desc') as $Key => $Val) {
					$CompanyIds[] = $Val['uid'];
				}

				$Where .= ' and (G.title like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or G.username like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\')  or G.uid = '.intval($_GET['keyword']).' or G.id = '.intval($_GET['keyword']).' '.($CompanyIds ? ' or G.company_id in ('.implode(',',array_filter($CompanyIds)).')' : '' ).' )';
			}

			if($_GET['company_id']){
				$Where .= ' and G.company_id = '.intval($_GET['company_id']);
			}
			
			if($_GET['index']){
				$Where .= ' and G.index = '.intval($_GET['index']);
			}

			if(in_array($_GET['display'],array('0','1'))){
				$Where .= ' and G.display = '.intval($_GET['display']);
			}

			if($_GET['type']){
				$Where .= ' and G.type = '.intval($_GET['type']);
			}

			$Where = preg_replace('/and/','where',$Where,1);
			$Limit = 20;
			$Page = $_GET['page']?intval($_GET['page']):1;
			/* ��ѯ���� End */

			/* ģ����� */	
			showtagheader('div', 'row', true,'row');
			showtagheader('div', 'col-12', true,'col-12');
			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-body', true,'box-body');
			/* ���� */
			$OverdueSelected = array($_GET['overdue']=>' selected');
			$IndexSelected = array($_GET['display']=>' selected');
			$DisplaySelected = array($_GET['display']=>' selected');
			$OrderSelected = array($_GET['order']=>' selected');
			
			$TypeListOption = '<option value="">'.$Fn_Renovation->Config['LangVar']['SelectNull'].'</option>';
			foreach($Fn_Renovation->Config['LangVar']['GoodsType'] as $Key => $Val) {
				$TypeListOption .= '<option value="'.$Key.'" '.($_GET['type'] == $Key ? ' selected' : '' ).'>'.$Val.'</option>';
			}

			echo <<<SEARCH
			<form method="post" autocomplete="off" action="$SearUrl">
				<div class="FormSearchTo" style="margin-bottom:0;">
					<table cellspacing="4" cellpadding="4">
						<tr>
							<th>{$Fn_Renovation->Config['LangVar']['KeywordTitle']}</th><td><input type="text" class="input form-control w300" name="keyword" value="{$_GET['keyword']}" placeholder="{$Fn_Renovation->Config['LangVar']['AdminCasePlaceholder']}">
							</td>
							<th>{$Fn_Renovation->Config['LangVar']['CompanyID']}</th><td><input type="text" class="input form-control w120" name="company_id" value="{$_GET['company_id']}" placeholder="{$Fn_Renovation->Config['LangVar']['CompanyIDPlaceholder']}">
							</td>
							<th>{$Fn_Renovation->Config['LangVar']['Type']}</th><td>
							<select name="type" class="form-control w120">
								{$TypeListOption}
							</select>
							</td>
							<th>{$Fn_Renovation->Config['LangVar']['TuiIndex']}</th><td>
							<select name="index" class="form-control w120">
								<option value="">{$Fn_Renovation->Config['LangVar']['SelectNull']}</option>
								<option value="1"{$IndexSelected['1']}>{$Fn_Renovation->Config['LangVar']['Yes']}</option>
								<option value="0"{$IndexSelected['0']}>{$Fn_Renovation->Config['LangVar']['No']}</option>
							</select>
							</td>
							<th>{$Fn_Renovation->Config['LangVar']['DisplayTitle']}</th><td>
							<select name="display" class="form-control w120">
								<option value="">{$Fn_Renovation->Config['LangVar']['SelectNull']}</option>
								<option value="1"{$DisplaySelected['1']}>{$Fn_Renovation->Config['LangVar']['Yes']}</option>
								<option value="0"{$DisplaySelected['0']}>{$Fn_Renovation->Config['LangVar']['No']}</option>
							</select>
							</td>
							<th>{$Fn_Admin->Config['LangVar']['Order']}</th><td>
							
							<select name="order" class="form-control w120">
								<option value="dateline"{$OrderSelected['dateline']}>{$Fn_Admin->Config['LangVar']['OrderArray']['dateline']}</option>
								<option value="updateline"{$OrderSelected['updateline']}>{$Fn_Admin->Config['LangVar']['OrderArray']['updateline']}</option>
								<option value="click"{$OrderSelected['click']}>{$Fn_Admin->Config['LangVar']['OrderArray']['click']}</option>
								<option value="topdateline"{$OrderSelected['topdateline']}>{$Fn_Admin->Config['LangVar']['OrderArray']['topdateline']}</option>
							</select>
							&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Admin->Config['LangVar']['SearchSubmit']}" class="btn btn-info" type="submit">
							</td>
						</tr>
					</table>
				</div>
			</form>
SEARCH;
			/* ���� End */
			showtagheader('div', 'table-responsive', true,'table-responsive');
			showformheader($FormUrl,'enctype="multipart/form-data"');
			showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
			showsubtitle(array(
				'ID',
				'UID/'.$Fn_Renovation->Config['LangVar']['UserNameTitle'],
				$Fn_Renovation->Config['LangVar']['Title'],
				$Fn_Renovation->Config['LangVar']['CompanyName'],
				$Fn_Renovation->Config['LangVar']['Type'],
				$Fn_Renovation->Config['LangVar']['TuiIndex'],
				$Fn_Renovation->Config['LangVar']['DisplayTitle'],
				$Fn_Renovation->Config['LangVar']['RefreshTime'],
				$Fn_Renovation->Config['LangVar']['SetTopTime'],
				$Fn_Renovation->Config['LangVar']['TimeTitle'],
				$Fn_Renovation->Config['LangVar']['OperationTitle']
			),'header tbm tc');

			$ModulesList = $Fn_Renovation->GoodsListFormat(GetModulesList($Page,$Limit,$Where,$Order));
			
			foreach ($ModulesList as $Module) {
				
				showtablerow('', array('class="tc w80"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
					'<input type="checkbox" class="filled-in" id="checkbox_'.$Module['id'].'" name="delete[]" value="'.$Module['id'].'"><label for="checkbox_'.$Module['id'].'">'.$Module['id'].'</label>',
					$Module['uid'] ? $Module['uid'].'/'.$Module['username'] : '',
					$Module['title'],
					$Module['company_name'],
					$Module['type_text'],
					!$Module['index'] ? '<span class="label bg-secondary">'.$Fn_Renovation->Config['LangVar']['No'].'</span>' : '<span class="label bg-blue">'.$Fn_Renovation->Config['LangVar']['Yes'].'</span>',
					!$Module['display'] ? '<span class="label bg-secondary">'.$Fn_Renovation->Config['LangVar']['No'].'</span>' : '<span class="label bg-blue">'.$Fn_Renovation->Config['LangVar']['Yes'].'</span>',
					$Module['updateline'],
					$Module['topdateline'] && $Module['topdateline'] > time() ? date('Y-m-d H:i',$Module['topdateline']) : '',
					date('Y-m-d H:i',$Module['dateline']),
					'<a href="'.$Module['url'].'" target="_blank" class="btn btn-sm btn-dark-outline">'.cplang('view').'</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&gid='.$Module['id'].'" class="btn btn-sm btn-info-outline">'.$Fn_Renovation->Config['LangVar']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Refresh&gid='.$Module['id'].'&formhash='.FORMHASH.'" class="btn btn-sm btn-primary-outline">'.$Fn_Renovation->Config['LangVar']['Refresh'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Index&gid='.$Module['id'].'&value='.(!empty($Module['index']) ? 0:1).'&formhash='.FORMHASH.'" class="btn btn-sm btn-success-outline">'.(!empty($Module['index']) ? $Fn_Renovation->Config['LangVar']['NoTuiIndex'] : $Fn_Renovation->Config['LangVar']['TuiIndex']).'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Display&gid='.$Module['id'].'&value='.(!empty($Module['display']) ? 0:1).'&formhash='.FORMHASH.'" class="btn btn-sm btn-purple-outline">'.(!empty($Module['display']) ? $Fn_Renovation->Config['LangVar']['DisplayNoTitle'] : $Fn_Renovation->Config['LangVar']['DisplayIsTitle']).'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Del&gid='.$Module['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$Fn_Renovation->Config['LangVar']['DelTitle'].'</a>',
				));
			}

			showsubmit('Submit','&#31435;&#21363;&#25552;&#20132;','<input name="optype" value="Del" class="with-gap" type="radio" id="v_del"><label class="custom-control-label" for="v_del" style="margin-left:-5px;">'.$Fn_Renovation->Config['LangVar']['DelTitle'].'</label>&nbsp;&nbsp;<input name="optype" value="Refresh" class="with-gap" type="radio" id="v_refresh"><label class="custom-control-label" for="v_refresh">'.$Fn_Renovation->Config['LangVar']['Refresh'].'</label>&nbsp;&nbsp;<input name="optype" value="Display" class="with-gap" type="radio" id="v_display"><label class="custom-control-label" for="v_display">'.$Fn_Renovation->Config['LangVar']['DisplayTitle'].'</label>&nbsp;<select name="new_display" class="form-control w120"><option value="">'.$Fn_Renovation->Config['LangVar']['SelectNull'].'</option><option value="1">'.$Fn_Renovation->Config['LangVar']['Yes'].'</option><option value="0">'.$Fn_Renovation->Config['LangVar']['No'].'</option></select>','','select_all',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));

			showtablefooter(); /*dism��taobao��com*/
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			/* ģ�����End */	
		}else{
			if(isset($_GET['delete']) && is_array($_GET['delete'])){
				if($_GET['optype'] == 'Del'){//ȫɾ
					if(!$Fn_Admin->CheckUserGroup('renovation_all') && !$Fn_Admin->CheckUserGroup('renovation_material_goods_del')){//Ȩ���ж�
						fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
						exit();
					}
					foreach($_GET['delete'] as $Key => $Val) {
						$Val = intval($Val);
						DB::delete($Fn_Renovation->TableMaterialGoods,'id ='.$Val);

					}
					GetInsertDoLog('del_goods_list_renovation','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete'])));//������¼
					fn_cpmsg($Fn_Renovation->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');

				}else if($_GET['optype'] == 'Refresh'){
					foreach($_GET['delete'] as $Key => $Val) {
						$Val = intval($Val);
						$UpData['updateline'] = time();
						DB::update($Fn_Renovation->TableMaterialGoods,$UpData,'id = '.$Val);
					}
					GetInsertDoLog('refresh_goods_list_renovation','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete'])));//������¼
					fn_cpmsg($Fn_Renovation->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

				}else if($_GET['optype'] == 'Display' && in_array($_GET['new_display'],array('0','1'))){
					foreach($_GET['delete'] as $Key => $Val) {
						$Val = intval($Val);
						$UpData['display'] = intval($_GET['new_display']);
						DB::update($Fn_Renovation->TableMaterialGoods,$UpData,'id = '.$Val);
					}
					GetInsertDoLog('display_goods_list_renovation','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete']),'display'=>$_GET['new_display']));//������¼
					fn_cpmsg($Fn_Renovation->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

				}else{
					fn_cpmsg($Fn_Renovation->Config['LangVar']['OpErr'],'','error');
				}	
			}else{
				fn_cpmsg($Fn_Renovation->Config['LangVar']['OpErr'],'','error');
			}	
		}
	}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['gid']){
		if(!$Fn_Admin->CheckUserGroup('renovation_all') && !$Fn_Admin->CheckUserGroup('renovation_material_goods_del')){//Ȩ���ж�
			fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
			exit();
		}
		$id = intval($_GET['gid']);
		DB::delete($Fn_Renovation->TableMaterialGoods,'id ='.$id);
		GetInsertDoLog('del_goods_list_renovation','fn_'.$_GET['mod'],array('id'=>$id));//������¼
		fn_cpmsg($Fn_Admin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');

	}else if($Do == 'Refresh' && $_GET['formhash'] == formhash() && $_GET['gid']){
		$id = intval($_GET['gid']);
		$UpData['updateline'] = time();
		DB::update($Fn_Renovation->TableMaterialGoods,$UpData,'id = '.$id);
		GetInsertDoLog('refresh_goods_list_renovation','fn_'.$_GET['mod'],array('id'=>$id));//������¼
		fn_cpmsg($Fn_Renovation->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

	}else if($Do == 'Index' && $_GET['formhash'] == formhash() && $_GET['gid']){
		$id = intval($_GET['gid']);
		$UpData['index'] = intval($_GET['value']);
		DB::update($Fn_Renovation->TableMaterialGoods,$UpData,'id = '.$id);
		GetInsertDoLog('index_goods_list_renovation','fn_'.$_GET['mod'],array('id'=>$id,'index'=>$_GET['value']));//������¼
		fn_cpmsg($Fn_Renovation->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

	}else if($Do == 'Display' && $_GET['formhash'] == formhash() && $_GET['gid']){
		$id = intval($_GET['gid']);
		$UpData['display'] = intval($_GET['value']);
		DB::update($Fn_Renovation->TableMaterialGoods,$UpData,'id = '.$id);
		GetInsertDoLog('display_goods_list_renovation','fn_'.$_GET['mod'],array('id'=>$id,'display'=>$_GET['value']));//������¼
		fn_cpmsg($Fn_Renovation->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

	}
}else if($SubModel == 'add'){//���ӻ�༭
	if(!$Fn_Admin->CheckUserGroup('renovation_all') && !$Fn_Admin->CheckUserGroup('renovation_add_goods_list')){//Ȩ���ж�
		fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
		exit();
	}
	$id = intval($_GET['gid']);
	
	$Item = DB::fetch_first('SELECT * FROM '.DB::table($Fn_Renovation->TableMaterialGoods).' where id = '.$id);

	if(!submitcheck('DetailSubmit')) {
		$OpTitle = $Fn_Renovation->Config['LangVar']['AddTitle'];
		if($Item){
			$OpTitle = $Fn_Renovation->Config['LangVar']['EditTitle'];
			$Item['param'] = unserialize($Item['param']);
		}

		//ͼƬ�ϴ�
		if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_assembly/class/class_upload.php')){
			@require_once libfile('class/upload','plugin/fn_assembly');
			$UploadConfig = fn_upload::Config();
		}

		echo '<script src="'.$Config['StaticPath'].'/ueditor/'.CHARSET.'/ueditor.config.js" type="text/javascript"></script><script src="'.$Config['StaticPath'].'/ueditor/'.CHARSET.'/ueditor.all.js" type="text/javascript"></script>';
		
		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-header', true,'with-border box-header');
		showtitle($OpTitle,'class="box-title"');
		showtagfooter('div');
		showformheader($Fn_Admin->Config['IframeSubModelUrl'].'&gid='.$id,'enctype');
		showtagheader('div', 'box-body', true,'box-body');
		
		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_Renovation->Config['LangVar']['Products'].'</label><div class="col-sm-9"><div class="AdminSingleUpload"><div class="PhotoControl" id="Banner"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';

		showsetting('uid', 'new_uid', $Item['uid'], 'text');
		showsetting($Fn_Renovation->Config['LangVar']['CompanyID'], 'company_id', $Item['company_id'], 'text');
		showsetting($Fn_Renovation->Config['LangVar']['Title'], 'title', $Item['title'], 'text');
		showsetting($Fn_Renovation->Config['LangVar']['MinTitle'], 'min_title', $Item['min_title'], 'textarea');

		showsetting($Fn_Renovation->Config['LangVar']['GoodsTypeTitle'], array('type',DyadicArray($Fn_Renovation->Config['LangVar']['GoodsType'])), $Item['type'], 'mradio');
		showsetting($Fn_Renovation->Config['LangVar']['OriginalPrice'], 'price', $Item['price'], 'text');
		showsetting($Fn_Renovation->Config['LangVar']['DiscountPrice'], 'original_price', $Item['original_price'], 'text');
		showsetting($Fn_Renovation->Config['LangVar']['GoodsName'], array('price_name',DyadicArray($Fn_Renovation->Config['LangVar']['GoodsPriceTag'])),$Item['price_name'], 'mradio');
		
		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_Renovation->Config['LangVar']['GoodsDetailMap'].'</label><div class="col-sm-9"><div class="AdminSingleUpload"><div class="PhotoControl" id="Products"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';

		//��������
		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_Renovation->Config['LangVar']['Describe'].':</label><div class="col-sm-9"><textarea id="content" name="content" style="width:80%;height:450px;">'.stripslashes($Item['content']).'</textarea></div></div>';

		showsetting($Fn_Renovation->Config['LangVar']['SetTopTime'], 'topdateline',$Item['topdateline'] ? date('Y-m-d H:i',$Item['topdateline']) : '', 'calendar','','','',1);
		
		if($Item['updateline']){
			showsetting($Fn_Renovation->Config['LangVar']['RefreshTime'], 'updateline',$Item['updateline'] ? date('Y-m-d H:i',$Item['updateline']) : '', 'calendar','','','',1);
		}

		if($Item['dateline']){
			showsetting($Fn_Renovation->Config['LangVar']['TimeTitle'], 'dateline',date('Y-m-d H:i',$Item['dateline']), 'calendar','','','',1);
		}

		showsetting($Fn_Renovation->Config['LangVar']['Click'], 'click', $Item['click'], 'text');

		showsetting($Fn_Renovation->Config['LangVar']['DisplayTitle'], 'display', $Item ? $Item['display'] : 1, 'radio');
		
		showsubmit('DetailSubmit','&#20445;&#23384;&#37197;&#32622;');
		showtagfooter('div');
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');
		
		$UpLoadHtml  = '';
		if($Item['banner']){
			foreach(array_filter(explode(",",$Item['banner'])) as $Key => $Val) {
				$BannerJsArray[] = '"'.$Val.'"';
			}
			$UpLoadHtml .= '
			var InputArray = new Array('.implode(',',$BannerJsArray).');
			$("#Banner").AppUpload({InputName:"new_banner",InputExist:true,InputArray:InputArray});';

		}else{
			$UpLoadHtml .= '$("#Banner").AppUpload({InputName:"new_banner"});';
		}

		if($Item['products']){
			foreach(array_filter(explode(",",$Item['products'])) as $Key => $Val) {
				$ProductsJsArray[] = '"'.$Val.'"';
			}
			$UpLoadHtml .= '
			var InputArray = new Array('.implode(',',$ProductsJsArray).');
			$("#Products").AppUpload({InputName:"new_products",InputExist:true,InputArray:InputArray});';

		}else{
			$UpLoadHtml .= '$("#Products").AppUpload({InputName:"new_products"});';
		}

		echo $UploadConfig['CssJsHtml'].'<script>var ue = UE.getEditor("content",{autoHeightEnabled: false,autoFloatEnabled:false,enableAutoSave: false});'.$UpLoadHtml.'</script> ';
		
	}else{
		foreach($_GET['new_banner'] as $Key => $Val) {
			$_GET['new_banner'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}

		foreach($_GET['new_products'] as $Key => $Val) {
			$_GET['new_products'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}

		$Data['uid'] = intval($_GET['new_uid']);
		$Member = DB::fetch_first('SELECT username FROM '.DB::table('common_member').' where uid = '.$Data['uid']);
		$Data['username'] = addslashes(strip_tags($Member['username']));
		$Data['banner'] = is_array($_GET['new_banner']) && isset($_GET['new_banner']) ? implode(',',array_filter($_GET['new_banner'])) : '';
		$Data['products'] = is_array($_GET['new_products']) && isset($_GET['new_products']) ? implode(',',array_filter($_GET['new_products'])) : '';
		$Data['title'] = addslashes(strip_tags($_GET['title']));
		$Data['min_title'] = addslashes(strip_tags($_GET['min_title']));
		$Data['type'] = intval($_GET['type']);
		$Data['company_id'] = intval($_GET['company_id']);
		$Data['price_name'] = intval($_GET['price_name']);
		$Data['price'] = addslashes(strip_tags($_GET['price']));
		$Data['original_price'] = addslashes(strip_tags($_GET['original_price']));
		$Data['content'] = addslashes($_GET['content']);//�豣��Html
		$Data['click'] = intval($_GET['click']);
		$Data['topdateline'] = $_GET['topdateline'] ? strtotime($_GET['topdateline']) : '';
		$Data['display'] = intval($_GET['display']);
		$Param['thumbnail'] = $_GET['new_banner'][0];
		$Data['param'] = serialize($Param);
		
		if($Item){
			$Data['updateline'] = strtotime($_GET['updateline']);
			GetInsertDoLog('edit_goods_list_renovation','fn_'.$_GET['mod'],array('id'=>$id));//������¼
			DB::update($Fn_Renovation->TableMaterialGoods,$Data,'id = '.$id);
		}else{
			$Data['dateline'] = $Data['updateline'] = time();
			$Id = DB::insert($Fn_Renovation->TableMaterialGoods,$Data,true);
			GetInsertDoLog('add_goods_list_renovation','fn_'.$_GET['mod'],array('id'=>$Id));//������¼
		}
		fn_cpmsg($Fn_Renovation->Config['LangVar']['UpdateOk'],$Fn_Admin->Config['IframeItemUrl'].'&submodel=list','succeed');
	}
}


/* �б� */
function GetModulesList($Page,$Limit,$Where=null,$Order){
	global $Fn_Renovation;
	$FetchSql = 'SELECT G.*,C.name as company_name FROM '.DB::table($Fn_Renovation->TableMaterialGoods).' G LEFT JOIN `'.DB::table($Fn_Renovation->TableMaterialCompany).'` C on C.id = G.company_id  '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}

/* ���� */
function GetModulesCount($Where=null){
	global $Fn_Renovation;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_Renovation->TableMaterialGoods).' G '.$Where;
	return DB::result_first($FetchSql);//��������
}

?>