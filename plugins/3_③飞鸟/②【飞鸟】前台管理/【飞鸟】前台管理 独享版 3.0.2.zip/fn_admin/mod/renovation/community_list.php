<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('renovation_all') && !$Fn_Admin->CheckUserGroup('renovation_community_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$SubModel = in_array($_GET['submodel'], array('list','add')) ? $_GET['submodel'] : 'list';
$Fn_Admin->Config['IframeSubModelUrl'] = $Fn_Admin->Config['IframeItemUrl'].'&submodel='.$SubModel;
$NavClass = array($SubModel=>'btn-info Hover');

//����
echo <<<Nav
<div class="SubModelNav">
  <ul>
	<li class="{$NavClass['list']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=list" target="_self">{$Fn_Admin->Config['LangVar']['RenovationLeftNavArray'][$_GET['item']]}</a></li>
    <li class="{$NavClass['add']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=add" target="_self">{$Fn_Admin->Config['LangVar']['AddEditTitle']}</a></li>
  </ul>
  <div class="both"></div>
</div>
Nav;

if($SubModel == 'list'){//�б�
	$Do = in_array($_GET['do'], array('Refresh','Del','Display','Verify','AllRefreshJob')) ? $_GET['do'] : 'submodel_list';
	//�����ֶ�
	$SearField =array('page','keyword','display','order');
	foreach($SearField as $Val) {
		$SearArray[$Val] = $_GET[$Val] || in_array($_GET[$Val],array('0')) ? $_GET[$Val] : '';
	}
	//�����ֶ� End
	$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeSubModelUrl'].'&'.http_build_query($SearArray);


	if($Do == 'submodel_list'){
		if(!submitcheck('Submit')) {
			$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
			$Where = '';
			$Order = $_GET['order'] ? 'C.'.addslashes(dhtmlspecialchars($_GET['order'])) : 'C.updateline';
			
			if($_GET['keyword']){
				$_GET['keyword'] = str_replace(array('%','_'),array('',''),$_GET['keyword']);
				$Where .= ' and (C.name like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or C.id = '.intval($_GET['keyword']).' )';
			}

			if(in_array($_GET['display'],array('0','1'))){
				$Where .= ' and C.display = '.intval($_GET['display']);
			}

			$Where = preg_replace('/and/','where',$Where,1);
			$Limit = 20;
			$Page = $_GET['page']?intval($_GET['page']):1;
			/* ��ѯ���� End */

			/* ģ����� */	
			showtagheader('div', 'row', true,'row');
			showtagheader('div', 'col-12', true,'col-12');
			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-body', true,'box-body');
			/* ���� */
			$DisplaySelected = array($_GET['display']=>' selected');
			$OrderSelected = array($_GET['order']=>' selected');
			echo <<<SEARCH
			<form method="post" autocomplete="off" action="$SearUrl">
				<div class="FormSearchTo" style="margin-bottom:0;">
					<table cellspacing="4" cellpadding="4">
						<tr>
							<th>{$Fn_Renovation->Config['LangVar']['KeywordTitle']}</th><td><input type="text" class="input form-control w200" name="keyword" value="{$_GET['keyword']}" placeholder="{$Fn_Renovation->Config['LangVar']['AdminCommunityPlaceholder']}">
							</td>
							<th>{$Fn_Renovation->Config['LangVar']['DisplayTitle']}</th><td>
							<select name="display" class="form-control w120">
								<option value="">{$Fn_Renovation->Config['LangVar']['SelectNull']}</option>
								<option value="1"{$DisplaySelected['1']}>{$Fn_Renovation->Config['LangVar']['Yes']}</option>
								<option value="0"{$DisplaySelected['0']}>{$Fn_Renovation->Config['LangVar']['No']}</option>
							</select>
							</td>
							<th>{$Fn_Admin->Config['LangVar']['Order']}</th><td>
							<select name="order" class="form-control w120">
								<option value="updateline"{$OrderSelected['updateline']}>{$Fn_Admin->Config['LangVar']['OrderArray']['updateline']}</option>
								<option value="dateline"{$OrderSelected['dateline']}>{$Fn_Admin->Config['LangVar']['OrderArray']['dateline']}</option>
								<option value="click"{$OrderSelected['click']}>{$Fn_Admin->Config['LangVar']['OrderArray']['click']}</option>
							</select>
							&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Admin->Config['LangVar']['SearchSubmit']}" class="btn btn-info" type="submit">
							</td>
						</tr>
					</table>
				</div>
			</form>
SEARCH;
			/* ���� End */
			showtagheader('div', 'table-responsive', true,'table-responsive');
			showformheader($FormUrl,'enctype="multipart/form-data"');
			showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');

			showsubtitle(array(
				'ID',
				$Fn_Renovation->Config['LangVar']['CommunityName'],
				$Fn_Renovation->Config['LangVar']['Thumbnail'],
				$Fn_Renovation->Config['LangVar']['Address'],
				$Fn_Renovation->Config['LangVar']['Click'],
				$Fn_Renovation->Config['LangVar']['DisplayTitle'],
				$Fn_Renovation->Config['LangVar']['RefreshTime'],
				$Fn_Renovation->Config['LangVar']['TimeTitle'],
				$Fn_Renovation->Config['LangVar']['OperationTitle']
			),'header tbm tc');

			$ModulesList = $Fn_Renovation->CommunityListFormat(GetModulesList($Page,$Limit,$Where,$Order));
			foreach ($ModulesList as $Module) {
				
				showtablerow('', array('class="tc w50"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
					'<input type="checkbox" class="filled-in" id="checkbox_'.$Module['id'].'" name="delete[]" value="'.$Module['id'].'"><label for="checkbox_'.$Module['id'].'">'.$Module['id'].'</label>',
					$Module['name'],
					$Module['thumbnail'] ? '<img src="'.$Module['thumbnail'].'" style="height:30px;">' : '',
					$Module['province_text'].$Module['community'],
					$Module['click'],
					!$Module['display'] ? '<span class="label bg-secondary">'.$Fn_Renovation->Config['LangVar']['No'].'</span>' : '<span class="label bg-blue">'.$Fn_Renovation->Config['LangVar']['Yes'].'</span>',
					date('Y-m-d H:i',$Module['updateline']),
					date('Y-m-d H:i',$Module['dateline']),
					'<a href="'.$Module['url'].'" target="_blank">'.cplang('view').'</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&cid='.$Module['id'].'">'.$Fn_Renovation->Config['LangVar']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Display&cid='.$Module['id'].'&value='.(!empty($Module['display']) ? 0:1).'&formhash='.FORMHASH.'">'.(!empty($Module['display']) ? $Fn_Renovation->Config['LangVar']['DisplayNoTitle'] : $Fn_Renovation->Config['LangVar']['DisplayIsTitle']).'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Del&cid='.$Module['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;">'.$Fn_Renovation->Config['LangVar']['DelTitle'].'</a><br><a href="'.$Fn_Admin->Config['ModUrl'].'&item=case_list&iframe=true&community_id='.$Module['id'].'">'.$Fn_Admin->Config['LangVar']['RenovationLeftNavArray']['case_list'].'</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['ModUrl'].'&item=build_list&iframe=true&community_id='.$Module['id'].'">'.$Fn_Admin->Config['LangVar']['RenovationLeftNavArray']['build_list'].'</a>',
				));
			}
			showsubmit('Submit','&#31435;&#21363;&#25552;&#20132;','del','','',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));
			showtablefooter(); /*dism��taobao��com*/
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			/* ģ�����End */	
		}else{
			if(isset($_GET['delete']) && is_array($_GET['delete'])){
				foreach($_GET['delete'] as $Key => $Val) {
					$Val = intval($Val);
					DB::delete($Fn_Renovation->TableCommunity,'id ='.$Val);
				}

				GetInsertDoLog('del_community_list_renovation','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete'])));//������¼

				fn_cpmsg($Fn_Renovation->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
			}else{
				fn_cpmsg($Fn_Renovation->Config['LangVar']['DelErr'],'','error');
			}
				
		}
	}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['cid']){
		$Cid = intval($_GET['cid']);
		DB::delete($Fn_Renovation->TableCommunity,'id ='.$Cid);
		GetInsertDoLog('del_community_list_renovation','fn_'.$_GET['mod'],array('id'=>$AUid));//������¼
		fn_cpmsg($Fn_Admin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
	}else if($Do == 'Display' && $_GET['formhash'] == formhash() && $_GET['cid']){
		$Cid = intval($_GET['cid']);
		$UpData['display'] = intval($_GET['value']);
		DB::update($Fn_Renovation->TableCommunity,$UpData,'id = '.$Cid);
		GetInsertDoLog('display_community_list_renovation','fn_'.$_GET['mod'],array('id'=>$_GET['cid'],'display'=>$_GET['value']));//������¼
		fn_cpmsg($Fn_Renovation->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

	}
}else if($SubModel == 'add'){//���ӻ�༭

	$Cid = intval($_GET['cid']);

	$Item = DB::fetch_first('SELECT * FROM '.DB::table($Fn_Renovation->TableCommunity).' where id = '.$Cid);
	if($Item){
		//$Item['param'] = unserialize($Item['param']);
	};
	if(!submitcheck('DetailSubmit')) {
		$OpTitle = $Fn_Renovation->Config['LangVar']['AddTitle'];
		if($Item){
			$OpTitle = $Fn_Renovation->Config['LangVar']['EditTitle'];
			$Item['province_text'] = $Fn_Renovation->Area[$Item['province']]['content'].($Item['city'] ? $Fn_Renovation->Area[$Item['city']]['content'] : '').($Item['dist'] ? $Fn_Renovation->Area[$Item['dist']]['content'] : '');
		}

		//ͼƬ�ϴ�
		if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_assembly/class/class_upload.php')){
			@require_once libfile('class/upload','plugin/fn_assembly');
			$UploadConfig = fn_upload::Config();
		}

		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-header', true,'with-border box-header');
		showtitle($OpTitle,'class="box-title"');
		showtagfooter('div');
		showformheader($Fn_Admin->Config['IframeSubModelUrl'].'&cid='.$Cid,'enctype');
		showtagheader('div', 'box-body', true,'box-body');

		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_Renovation->Config['LangVar']['Thumbnail'].'</label><div class="col-sm-9"><div class="AdminSingleUpload"><div class="PhotoControl" id="LogoPhotoControl"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';

		showsetting($Fn_Renovation->Config['LangVar']['CommunityName'], 'name', $Item['name'], 'text');

		$SmallAreaPositionTreelistHtml = GetTreelistHtml($Fn_Renovation->Area,'SmallAreaPositionList',$Item['province'],$Item['city'],$Item['dist']);

		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_Renovation->Config['LangVar']['Position'].':</label><div class="col-sm-2"><div style="position:relative;height:40px"><input value="'.$Item['province_text'].'" class="input form-control TreeList" type="text" id="SmallAreaPosition">'.$SmallAreaPositionTreelistHtml.'</div></div><div class="col-sm-7 form-inline"><input type="hidden" name="province" value="'.$Item['province'].'"/><input type="hidden" name="city" value="'.$Item['city'].'"/><input type="hidden" name="dist" value="'.$Item['dist'].'"/></div></div>';
		
		showsetting($Fn_Renovation->Config['LangVar']['Address'], 'community', $Item['community'], 'text');
		
		showsetting($Fn_Admin->Config['LangVar']['Longitude'], 'lng', $Item['lng'], 'text','','','<div class="MapClick">'.($Item['lng'] && $Item['lat'] ? $Fn_Renovation->Config['LangVar']['IsTagging'] : $Fn_Renovation->Config['LangVar']['Tagging']).'</div><div class="TipMap"><iframe id="MapPage" width="100%" height="100%" frameborder=0 src=""></iframe></div>');

		showsetting($Fn_Admin->Config['LangVar']['Latitude'], 'lat', $Item['lat'], 'text');

		if($Item['updateline']){
			showsetting($Fn_Renovation->Config['LangVar']['RefreshTime'], 'updateline',$Item['updateline'] ? date('Y-m-d H:i',$Item['updateline']) : '', 'calendar','','','',1);
		}

		if($Item['dateline']){
			showsetting($Fn_Renovation->Config['LangVar']['TimeTitle'], 'dateline',date('Y-m-d H:i',$Item['dateline']), 'calendar','','','',1);
		}

		showsetting($Fn_Renovation->Config['LangVar']['Click'], 'click', $Item['click'], 'text');

		showsetting($Fn_Renovation->Config['LangVar']['DisplayTitle'], 'display', $Item ? $Item['display'] : 1, 'radio');
		
		showsubmit('DetailSubmit','&#20445;&#23384;&#37197;&#32622;');
		showtagfooter('div');
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');

		$UpLoadHtml  = '';
		if($Item['thumbnail']){
			$ThumbnailJsArray[] = '"'.$Item['thumbnail'].'"';;
			$UpLoadHtml .= '
			var InputArray = new Array('.implode(',',$ThumbnailJsArray).');
			$("#LogoPhotoControl").AppUpload({InputName:"new_thumbnail",Multiple:true,InputExist:true,InputArray:InputArray});';

		}else{
			$UpLoadHtml .= '$("#LogoPhotoControl").AppUpload({InputName:"new_thumbnail",Multiple:true});';
		}


		echo '<script src="source/plugin/fn_assembly/static/js/mobiscroll.custom-2.16.1.min.js"></script><link rel="stylesheet" href="source/plugin/fn_assembly/static//css/mobiscroll.custom-2.16.1.min.css"><script charset=utf-8 src="https://map.qq.com/api/js?v=2.exp&key='.$Config['PluginVar']['TxMapKey'].'"></script>'.$UploadConfig['CssJsHtml'];
		
		echo '
			<style>.Tmp{opacity:0;}.Tagging span{font-size:18px;}.Tagging{cursor: pointer;}</style>
			<script>
			$(document).on("click","#SmallAreaPosition",function(){
				GetTreeList($(this),"SmallAreaPositionList","province","city","dist");
				return false;
			});
			//��ע
			$(document).on("click",".MapClick",function(){
				if(!$("#MapPage").attr("src")){
					$("#MapPage").attr("src","https://apis.map.qq.com/tools/locpicker?search=1&type=1&key='.$Config['PluginVar']['TxMapKey'].'&referer=myapp&'.($Item['lat'] && $Item['lng'] ? 'coord='.$Item['lat'].','.$Item['lng'] : '').'");
				}
				$(".TipMap").fadeIn();
				return false;
			});
			window.addEventListener("message", function(Event) {
				var Loc = Event.data;
				if (Loc && Loc.module == "locationPicker") {
					var Geocoder = new qq.maps.Geocoder();
					Geocoder.getAddress(new qq.maps.LatLng(Loc.latlng.lat, Loc.latlng.lng));
					Geocoder.setComplete(function(Result) {
						$("input[name=\'lat\']").val(Result.detail.location.lat);
						$("input[name=\'lng\']").val(Result.detail.location.lng);
						$("input[name=\'community\']").val(Result.detail.addressComponents.street + Result.detail.addressComponents.streetNumber);
						$(".Map").html("'.$Fn_Renovation->Config['LangVar']['IsTagging'].'<span class=iconfont>&#xe621;</span>");
						$(".TipMap").fadeOut();
					});
					Geocoder.setError(function() {
						alert("\u51fa\u9519\u4e86\uff0c\u8bf7\u8f93\u5165\u6b63\u786e\u7684\u5730\u5740\uff01\uff01\uff01");
					});
				}
			}, false);
			//��ע End
			'.$UpLoadHtml.'
			</script> 	
		';

	}else{
	
		foreach($_GET['new_thumbnail'] as $Key => $Val) {
			$_GET['new_thumbnail'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}

		$Data['thumbnail'] = addslashes(strip_tags($_GET['new_thumbnail'][0]));
		$Data['name'] = addslashes(strip_tags($_GET['name']));
		$Data['province'] = addslashes(strip_tags($_GET['province']));
		$Data['city'] = addslashes(strip_tags($_GET['city']));
		$Data['dist'] = addslashes(strip_tags($_GET['dist']));
		$Data['community'] = addslashes(strip_tags($_GET['community']));
		$Data['lat'] = addslashes(strip_tags($_GET['lat']));
		$Data['lng'] = addslashes(strip_tags($_GET['lng']));
		$Data['click'] = intval($_GET['click']);
		$Data['display'] = intval($_GET['display']);
		
		if($Item){
			$Data['updateline'] = strtotime($_GET['updateline']);
			$Data['dateline'] = strtotime($_GET['dateline']);
			GetInsertDoLog('edit_community_list_renovation','fn_'.$_GET['mod'],array('id'=>$Item['id']));//������¼
			DB::update($Fn_Renovation->TableCommunity,$Data,'id = '.$Item['id']);	
		}else{
			$Data['dateline'] = $Data['updateline'] = time();
			$Id = DB::insert($Fn_Renovation->TableCommunity,$Data,true);
			GetInsertDoLog('add_community_list_renovation','fn_'.$_GET['mod'],array('id'=>$Id));//������¼
		}
		fn_cpmsg($Fn_Renovation->Config['LangVar']['UpdateOk'],$Fn_Admin->Config['IframeItemUrl'].'&submodel=list','succeed');
		
	}
}


/* �б� */
function GetModulesList($Page,$Limit,$Where=null,$Order){
	global $Fn_Renovation;
	$FetchSql = 'SELECT C.* FROM '.DB::table($Fn_Renovation->TableCommunity).' C '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}

/* ���� */
function GetModulesCount($Where=null){
	global $Fn_Renovation;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_Renovation->TableCommunity).' C '.$Where;
	return DB::result_first($FetchSql);//��������
}

?>