<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('renovation_all') && !$Fn_Admin->CheckUserGroup('renovation_form_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$Do = in_array($_GET['do'], array('Del','Push')) ? $_GET['do'] : 'List';

//�����ֶ�
$SearField =array('page','keyword','order','form_type','type','company_id');
foreach($SearField as $Val) {
	$SearArray[$Val] = $_GET[$Val] || in_array($_GET[$Val],array('0')) ? $_GET[$Val] : '';
}
//�����ֶ� End

$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeItemUrl'].'&'.http_build_query($SearArray);

if($Do == 'List'){
	if(!submitcheck('Submit')) {
		$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
		/* ��ѯ���� */
		$Where = '';
		$Order = in_array($_GET['order'], array('dateline','updateline')) ? 'R.'.addslashes(dhtmlspecialchars($_GET['order'])) : 'R.updateline';

		if($_GET['keyword']){
			$_GET['keyword'] = str_replace(array('%','_'),array('',''),$_GET['keyword']);
			$Where .= ' and (R.ip like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or R.username like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or R.name like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or R.url like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or R.mobile like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or R.uid = '.intval($_GET['keyword']).' or R.id = '.intval($_GET['keyword']).' )';
		}

		if($_GET['form_type']){
			$Where .= ' and R.form_type = '.intval($_GET['form_type']);
		}

		if($_GET['type']){
			$Where .= ' and R.type = '.intval($_GET['type']);
		}

		if($_GET['company_id']){
			$Where .= ' and R.company_id = '.intval($_GET['company_id']);
		}

		$Where = preg_replace('/and/','where',$Where,1);
		$Limit = 20;
		$Page = $_GET['page']?intval($_GET['page']):1;
		/* ��ѯ���� End */

		/* ģ����� */
		showtagheader('div', 'row', true,'row');
		showtagheader('div', 'col-12', true,'col-12');
		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-body', true,'box-body');
		/* ���� */
		$StateSelected = array($_GET['state']=>' selected');
		$OrderSelected = array($_GET['order']=>' selected');
		$FormTypeListOption = '<option value="">'.$Fn_Renovation->Config['LangVar']['SelectNull'].'</option>';
		foreach($Fn_Renovation->Config['LangVar']['FormTypeArray'] as $Key => $Val) {
			$FormTypeListOption .= '<option value="'.$Key.'" '.($_GET['form_type'] == $Key ? ' selected' : '' ).'>'.$Val.'</option>';
		}

		$FormSubmitTypeListOption = '<option value="">'.$Fn_Renovation->Config['LangVar']['SelectNull'].'</option>';
		foreach($Fn_Renovation->Config['LangVar']['FormSubmitTypeArray'] as $Key => $Val) {
			$FormSubmitTypeListOption .= '<option value="'.$Key.'" '.($_GET['type'] == $Key ? ' selected' : '' ).'>'.$Val.'</option>';
		}
		echo <<<SEARCH
		<form method="post" autocomplete="off" action="$SearUrl" id="tb_search">
			<div class="FormSearchTo">
				<table cellspacing="4" cellpadding="4">
					<tr>
						<th>{$Fn_Renovation->Config['LangVar']['KeywordTitle']}</th><td><input type="text" class="input form-control w200" name="keyword" value="{$_GET['keyword']}" placeholder="{$Fn_Renovation->Config['LangVar']['AdminFormPlaceholder']}">
						</td>
						<th>{$Fn_Renovation->Config['LangVar']['CompanyID']}</th><td><input type="text" class="input form-control w120" name="company_id" value="{$_GET['company_id']}" placeholder="{$Fn_Renovation->Config['LangVar']['CompanyIDPlaceholder']}">
						</td>
						<th>{$Fn_Renovation->Config['LangVar']['FormType']}</th><td>
							<select name="form_type" class="form-control w120">
								{$FormTypeListOption}
							</select>
						</td>
						<th>{$Fn_Renovation->Config['LangVar']['FormSubmitType']}</th><td>
							<select name="type" class="form-control w120">
								{$FormSubmitTypeListOption}
							</select>
						</td>
						<th>{$Fn_Admin->Config['LangVar']['Order']}</th><td>
							
							<select name="order" class="form-control w120">
								<option value="updateline"{$OrderSelected['updateline']}>{$Fn_Admin->Config['LangVar']['OrderArray']['updateline']}</option>
								<option value="dateline"{$OrderSelected['dateline']}>{$Fn_Admin->Config['LangVar']['OrderArray']['dateline']}</option>
							</select>
							&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Admin->Config['LangVar']['SearchSubmit']}" class="btn btn-info" type="submit">
						</td>
					</tr>
				</table>
			</div>
		</form>
SEARCH;
		/* ���� End */
		showtagheader('div', 'table-responsive', true,'table-responsive');
		showformheader($FormUrl,'enctype="multipart/form-data"');
		showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
		showsubtitle(array(
			'ID',
			'UID/'.$Fn_Renovation->Config['LangVar']['UserNameTitle'],
			$Fn_Renovation->Config['LangVar']['NameTitle'],
			$Fn_Renovation->Config['LangVar']['PhoneNumber'],
			$Fn_Renovation->Config['LangVar']['CompanyName'],
			$Fn_Renovation->Config['LangVar']['FormSubmitType'],
			$Fn_Renovation->Config['LangVar']['FormType'],
			$Fn_Renovation->Config['LangVar']['SourceUrl'],
			$Fn_Renovation->Config['LangVar']['Content'],
			$Fn_Renovation->Config['LangVar']['FormCount'],
			$Fn_Renovation->Config['LangVar']['RefreshTime'],
			$Fn_Renovation->Config['LangVar']['TimeTitle'],
			$Fn_Renovation->Config['LangVar']['OperationTitle']
		), 'header tbm tc');
		
		$ModulesList = GetModulesList($Page,$Limit,$Where,$Order);
		
		foreach ($ModulesList as $Module) {
			$Module['param'] = unserialize($Module['param']);
			$ContentHtml = array();
			foreach($Module['param']['form_list'] as $Val) {
				$ContentHtml[] = $Val['title'].': '.$Val['value'];
			}

			showtablerow('', array('class="tc w100"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
				'<input type="checkbox" class="filled-in" id="checkbox_'.$Module['id'].'" name="delete[]" value="'.$Module['id'].'"><label for="checkbox_'.$Module['id'].'">'.$Module['id'].'</label>',
				$Module['uid'] ? $Module['uid'].'/'.$Module['username'] : '',
				$Module['name'],
				$Module['mobile'],
				$Module['company_name'],
				$Fn_Renovation->Config['LangVar']['FormSubmitTypeArray'][$Module['type']],
				$Fn_Renovation->Config['LangVar']['FormTypeArray'][$Module['form_type']],
				$Module['url'] ? $Module['url'].'&nbsp;&nbsp;<a href="'.$Module['url'].'" target="_blank">'.cplang('view').'</a>' : '',
				implode("<br>",$ContentHtml),
				$Module['count'],
				date('Y-m-d H:i',$Module['updateline']),
				date('Y-m-d H:i',$Module['dateline']),
				'<a href="'.$OpCpUrl.'&do=Push&fid='.$Module['id'].'" class="btn btn-sm btn-info-outline">'.$Fn_Renovation->Config['LangVar']['Push'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Del&fid='.$Module['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$Fn_Renovation->Config['LangVar']['DelTitle'].'</a>',
			));
		}
		showsubmit('Submit','&#31435;&#21363;&#25552;&#20132;','del','','',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));
        showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		/* ģ����� End */
	}else{
		if(isset($_GET['delete']) && is_array($_GET['delete'])){
			foreach($_GET['delete'] as $Key => $Val) {
				$Val = intval($Val);
				DB::delete($Fn_Renovation->TableForm,'id ='.$Val);
			}

			GetInsertDoLog('del_form_list_renovation','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete'])));//������¼

			fn_cpmsg($Fn_Renovation->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
		}else{
			fn_cpmsg($Fn_Renovation->Config['LangVar']['DelErr'],'','error');
		}
	}
}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['fid']){//ɾ��
	$id = intval($_GET['fid']);
	DB::delete($Fn_Renovation->TableForm,'id ='.$id);
	
	GetInsertDoLog('del_form_list_renovation','fn_'.$_GET['mod'],array('id'=>$Lid));//������¼

	fn_cpmsg($Fn_Renovation->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
}else if($Do == 'Push' && $_GET['fid']){//����
	if(!submitcheck('DetailSubmit')) {

		$Item = DB::fetch_first('SELECT * FROM '.DB::table($Fn_Renovation->TableForm).' where id = '.intval($_GET['fid']));
		
		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-header', true,'with-border box-header');
		showtitle($Fn_Renovation->Config['LangVar']['FormPushTitle'],'class="box-title"');
		showtagfooter('div');
		showformheader($FormUrl.'&fid='.$_GET['fid'].'&do=Push','enctype');
		showtagheader('div', 'box-body', true,'box-body');

		showsetting($Fn_Renovation->Config['LangVar']['CompanyID'], 'company_ids','','textarea','','',$Fn_Renovation->Config['LangVar']['FormPushTips']);
			
		showsubmit('DetailSubmit','&#31435;&#21363;&#25512;&#36865;');
		showtagfooter('div');
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');

	}else{
		if($_GET['company_ids']){
			$I = 0;
			$Item = DB::fetch_first('SELECT * FROM '.DB::table($Fn_Renovation->TableForm).' where id = '.intval($_GET['fid']));
			foreach(array_filter(explode("\r\n",$_GET['company_ids'])) as $ID) {
				
				$check = DB::fetch_first('SELECT * FROM '.DB::table($Fn_Renovation->TableForm).' where form_id = '.intval($_GET['fid']).' and company_id = '.intval($ID));
				if(!$check){
					$CompanyItem = $Fn_Renovation->GetViewCompanythread($ID);
					//ģ����Ϣ����
					$FormPush = str_replace(array('{name}','{form_type}','{phone}'),array($Item['name'],$Fn_Renovation->Config['LangVar']['FormTypeArray'][$Item['form_type']],$Item['mobile']),$Fn_Renovation->Config['PluginVar']['FormPush']);
					foreach($CompanyItem['admin'] as $Key => $Val) {
						notification_add($Val,'system','<a href="{url}">{msg}</a>',array(
							'url'=>$Fn_Renovation->Config['Url'],
							'msg'=>$FormPush
						),1);//ϵͳ֪ͨ
						if($Config['PluginVar']['AppType'] == 1){//������������
							$PushData['Uid'] = $Val;
							$PushData['Type'] = 'pictemp';
							$PushData['Content'] = array(
								"tag"=> diconv(addslashes(strip_tags($Fn_Renovation->Config['LangVar']['NewsNotice'])),CHARSET,'UTF-8'),
								"title"=> diconv(addslashes(strip_tags($Fn_Renovation->Config['LangVar']['NewsNotice'])),CHARSET,'UTF-8'),
								"link"=> $Fn_Renovation->Config['Url'],
								"pic_url"=> $_G['siteurl'].$Config['StaticPath'].'/images/notice.png',
								"extra_info"=>array(
									array(
										"key"=>'',
										"val"=>diconv($FormPush,CHARSET,'UTF-8')
									)
								)
							);
							$ReturnAssistantMsg = $Fn_Renovation->MagApp->GetSendAssistantMsg($PushData);
						}
					}

					if($Config['PluginVar']['AppType'] == 2){//ǧ��ģ����Ϣ����
						$PushData['Uid'] = implode(',',$CompanyItem['admin']);
						$PushData['Msg'] = diconv(addslashes(strip_tags($Fn_Renovation->Config['LangVar']['NewsNotice'])),CHARSET,'UTF-8');
						$PushData['Content'] = array(
							'title'=>diconv(addslashes(strip_tags($Fn_Renovation->Config['LangVar']['NewsNotice'])),CHARSET,'UTF-8'),
							'date'=>date('Y-m-d H:i:s'),
							'setting'=>array(),
							'content' => diconv($FormPush,CHARSET,'UTF-8'),
							'url'=>$Fn_Renovation->Config['UrlUrl']
						);
						$Fn_Renovation->QHApp->GetMessagesTemplate($PushData);
					}
					//ģ����Ϣ����End
					
					//��Ϣ����
					@require_once libfile('class/short_message','plugin/fn_assembly');
					if($Config['PluginVar']['ShortMessageType'] == 1){
						$TemplateCode = $Fn_Renovation->Config['PluginVar']['AliNoticeId'];
						$TemplateParam = array('name'=>$Item['name'].'-'.$Item['mobile'],'form_type'=>$Fn_Renovation->Config['LangVar']['FormTypeArray'][$Item['form_type']]);
					}else if($Config['PluginVar']['ShortMessageType'] == 2){
						$TemplateCode = str_replace(array('{name}','{form_type}'),array($Item['name'].'-'.$Item['mobile'],$Fn_Renovation->Config['LangVar']['FormTypeArray'][$Item['form_type']]),$Fn_Renovation->Config['PluginVar']['ChanyooNotice']);
						$TemplateParam = array();
					}
					$SendSms = fn_short_message::send_sms($Config['PluginVar']['MobileAreaCode'].$CompanyItem['mobile'],$Fn_Renovation->Config['PluginVar']['AliAutograph'],$TemplateCode,$TemplateParam,$CompanyItem['uid'],$CompanyItem['username'],'fn_renovation',2);
					//��Ϣ���� End

					$Item['company_id'] = $ID;
					$Item['type'] = 2;
					$Item['form_id'] = $Item['id'];
					$Item['dateline'] = $Item['updateline'] = time();
					$Item['count'] = 1;
					unset($Item['id']);
					DB::insert($Fn_Renovation->TableForm,$Item,true) ? $I++ : '';
				}

				
			}
			fn_cpmsg(str_replace('{num}',$I,$Fn_Renovation->Config['LangVar']['ManualPushSuccess']),$CpMsgUrl,'succeed');
		}else{
			fn_cpmsg($Fn_Renovation->Config['LangVar']['ManualPushUidsErr'],'','error');
		}
		exit();
	}
}

/* �б� */
function GetModulesList($Page,$Limit,$Where=null,$Order){
	global $Fn_Renovation;
	$FetchSql = 'SELECT C.name as company_name,R.* FROM '.DB::table($Fn_Renovation->TableForm).' R LEFT JOIN `'.DB::table($Fn_Renovation->TableCompany).'` C on C.id = R.company_id '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}

/* ���� */
function GetModulesCount($Where=null){
	global $Fn_Renovation;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_Renovation->TableForm).' R '.$Where;
	return DB::result_first($FetchSql);//��������
}
//From: Dism_taobao_com
?>