<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('renovation_all') && !$Fn_Admin->CheckUserGroup('renovation_build_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$SubModel = in_array($_GET['submodel'], array('list','add')) ? $_GET['submodel'] : 'list';
$Fn_Admin->Config['IframeSubModelUrl'] = $Fn_Admin->Config['IframeItemUrl'].'&submodel='.$SubModel;
$NavClass = array($SubModel=>'btn-info Hover');

//����
echo <<<Nav
<div class="SubModelNav">
  <ul>
	<li class="{$NavClass['list']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=list" target="_self">{$Fn_Admin->Config['LangVar']['RenovationLeftNavArray'][$_GET['item']]}</a></li>
    <li class="{$NavClass['add']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=add" target="_self">{$Fn_Admin->Config['LangVar']['AddEditTitle']}</a></li>
  </ul>
  <div class="both"></div>
</div>
Nav;

if($SubModel == 'list'){//�б�
	$Do = in_array($_GET['do'], array('Del','Display','Progress','Info_Display','Info_Add','Info_Del')) ? $_GET['do'] : 'submodel_list';
	//�����ֶ�
	$SearField =array('page','keyword','display','order','company_id','community_id','stage','forms');
	foreach($SearField as $Val) {
		$SearArray[$Val] = $_GET[$Val] || in_array($_GET[$Val],array('0')) ? $_GET[$Val] : '';
	}
	//�����ֶ� End
	$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeSubModelUrl'].'&'.http_build_query($SearArray);


	if($Do == 'submodel_list'){
		if(!submitcheck('Submit')) {
			$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
			$Where = '';
			$Order = $_GET['order'] ? 'B.'.addslashes(dhtmlspecialchars($_GET['order'])) : 'B.id';
			
			if($_GET['keyword']){
				$_GET['keyword'] = str_replace(array('%','_'),array('',''),$_GET['keyword']);
				$Where .= ' and (B.title like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or B.username like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or B.community_name like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or B.uid = '.intval($_GET['keyword']).' or B.id = '.intval($_GET['keyword']).' )';
			}
			
			if($_GET['community_id']){
				$Where .= ' and B.community_id = '.intval($_GET['community_id']);
			}

			if($_GET['company_id']){
				$Where .= ' and B.company_id = '.intval($_GET['company_id']);
			}

			if($_GET['stage']){
				$Where .= ' and B.stage = '.intval($_GET['stage']);
			}

			if($_GET['forms']){
				$Where .= ' and B.forms = '.intval($_GET['forms']);
			}

			if(in_array($_GET['display'],array('0','1'))){
				$Where .= ' and B.display = '.intval($_GET['display']);
			}

			$Where = preg_replace('/and/','where',$Where,1);
			$Limit = 20;
			$Page = $_GET['page']?intval($_GET['page']):1;
			/* ��ѯ���� End */
			
			/* ģ����� */	
			showtagheader('div', 'row', true,'row');
			showtagheader('div', 'col-12', true,'col-12');
			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-body', true,'box-body');
			/* ���� */
			
			$FormsSelected = array($_GET['forms']=>' selected');
			$DisplaySelected = array($_GET['display']=>' selected');
			$OrderSelected = array($_GET['order']=>' selected');
			$StageListOption = '<option value="">'.$Fn_Renovation->Config['LangVar']['SelectNull'].'</option>';
			foreach($Fn_Renovation->Config['LangVar']['StageMinArray'] as $Key => $Val) {
				$StageListOption .= '<option value="'.$Key.'" '.($_GET['stage'] == $Key ? ' selected' : '' ).'>'.$Val.'</option>';
			}

			echo <<<SEARCH
			<form method="post" autocomplete="off" action="$SearUrl">
				<div class="FormSearchTo" style="margin-bottom:0;">
					<table cellspacing="4" cellpadding="4">
						<tr>
							<th>{$Fn_Renovation->Config['LangVar']['KeywordTitle']}</th><td><input type="text" class="input form-control w200" name="keyword" value="{$_GET['keyword']}" placeholder="{$Fn_Renovation->Config['LangVar']['AdminBuildPlaceholder']}">
							</td>
							<th>{$Fn_Renovation->Config['LangVar']['CompanyID']}</th><td><input type="text" class="input form-control w120" name="company_id" value="{$_GET['company_id']}" placeholder="{$Fn_Renovation->Config['LangVar']['CompanyIDPlaceholder']}">
							</td>
							<th>{$Fn_Renovation->Config['LangVar']['CommunityID']}</th><td><input type="text" class="input form-control w120" name="community_id" value="{$_GET['community_id']}" placeholder="{$Fn_Renovation->Config['LangVar']['CompanyIDPlaceholder']}">
							</td>
							<th>{$Fn_Renovation->Config['LangVar']['DecorationForm']}</th><td>
							<select name="forms" class="form-control w120">
								<option value="">{$Fn_Renovation->Config['LangVar']['SelectNull']}</option>
								<option value="1"{$FormsSelected['1']}>{$Fn_Renovation->Config['LangVar']['DecorationFormArray']['1']}</option>
								<option value="2"{$FormsSelected['2']}>{$Fn_Renovation->Config['LangVar']['DecorationFormArray']['2']}</option>
							</select>
							</td>
							<th>{$Fn_Renovation->Config['LangVar']['Stage']}</th><td>
							<select name="stage" class="form-control w120">
								{$StageListOption}
							</select>
							</td>
							<th>{$Fn_Renovation->Config['LangVar']['DisplayTitle']}</th><td>
							<select name="display" class="form-control w120">
								<option value="">{$Fn_Renovation->Config['LangVar']['SelectNull']}</option>
								<option value="1"{$DisplaySelected['1']}>{$Fn_Renovation->Config['LangVar']['Yes']}</option>
								<option value="0"{$DisplaySelected['0']}>{$Fn_Renovation->Config['LangVar']['No']}</option>
							</select>
							</td>
							<th>{$Fn_Admin->Config['LangVar']['Order']}</th><td>
							
							<select name="order" class="form-control w120">
								<option value="dateline"{$OrderSelected['dateline']}>{$Fn_Admin->Config['LangVar']['OrderArray']['dateline']}</option>
								<option value="click"{$OrderSelected['click']}>{$Fn_Admin->Config['LangVar']['OrderArray']['click']}</option>
							</select>
							&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Admin->Config['LangVar']['SearchSubmit']}" class="btn btn-info" type="submit">
							</td>
						</tr>
					</table>
				</div>
			</form>
SEARCH;
			/* ���� End */
			showtagheader('div', 'table-responsive', true,'table-responsive');
			showformheader($FormUrl,'enctype="multipart/form-data"');
			showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
			showsubtitle(array(
				'ID',
				'UID/'.$Fn_Renovation->Config['LangVar']['UserNameTitle'],
				$Fn_Renovation->Config['LangVar']['CompanyName'],
				$Fn_Renovation->Config['LangVar']['CommunityName'],
				$Fn_Renovation->Config['LangVar']['Title'],
				$Fn_Renovation->Config['LangVar']['Apartment'],
				$Fn_Renovation->Config['LangVar']['Style'],
				$Fn_Renovation->Config['LangVar']['MoneyTitle'],
				$Fn_Renovation->Config['LangVar']['Square'],
				$Fn_Renovation->Config['LangVar']['DecorationForm'],
				$Fn_Renovation->Config['LangVar']['Stage'],
				$Fn_Renovation->Config['LangVar']['DisplayTitle'],
				$Fn_Renovation->Config['LangVar']['RefreshTime'],
				$Fn_Renovation->Config['LangVar']['TimeTitle'],
				$Fn_Renovation->Config['LangVar']['OperationTitle']
			),'header tbm tc');

			$ModulesList = $Fn_Renovation->BuildListFormat(GetModulesList($Page,$Limit,$Where,$Order));
			foreach ($ModulesList as $Module) {
				
				showtablerow('', array('class="tc w50"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
					'<input type="checkbox" class="filled-in" id="checkbox_'.$Module['id'].'" name="delete[]" value="'.$Module['id'].'"><label for="checkbox_'.$Module['id'].'">'.$Module['id'].'</label>',
					$Module['uid'] ? $Module['uid'].'/'.$Module['username'] : '',
					$Module['company_name'],
					$Module['community_name'],
					$Module['title'],
					$Module['apartment_text'],
					$Module['style_text'],
					$Module['money'].$Fn_Renovation->Config['LangVar']['Wan'],
					$Module['square'],
					$Module['forms_text'],
					$Module['stage_text'],
					!$Module['display'] ? '<span class="label bg-secondary">'.$Fn_Renovation->Config['LangVar']['No'].'</span>' : '<span class="label bg-blue">'.$Fn_Renovation->Config['LangVar']['Yes'].'</span>',
					$Module['updateline'],
					date('Y-m-d H:i',$Module['dateline']),
					'<a href="'.$OpCpUrl.'&do=Progress&bid='.$Module['id'].'" class="btn btn-sm btn-dark-outline">'.$Fn_Renovation->Config['LangVar']['BuildProgress'].'</a>&nbsp;&nbsp;<a href="'.$Module['url'].'" target="_blank" class="btn btn-sm btn-primary-outline">'.cplang('view').'</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&bid='.$Module['id'].'" class="btn btn-sm btn-info-outline">'.$Fn_Renovation->Config['LangVar']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Display&bid='.$Module['id'].'&value='.(!empty($Module['display']) ? 0:1).'&formhash='.FORMHASH.'" class="btn btn-sm btn-purple-outline">'.(!empty($Module['display']) ? $Fn_Renovation->Config['LangVar']['DisplayNoTitle'] : $Fn_Renovation->Config['LangVar']['DisplayIsTitle']).'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Del&bid='.$Module['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$Fn_Renovation->Config['LangVar']['DelTitle'].'</a>',
				));
			}
			showsubmit('Submit','&#31435;&#21363;&#25552;&#20132;','del','','',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));
			showtablefooter(); /*dism��taobao��com*/
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			/* ģ�����End */	
		}else{
			if(!$Fn_Admin->CheckUserGroup('renovation_all') && !$Fn_Admin->CheckUserGroup('renovation_build_del')){//Ȩ���ж�
				fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
				exit();
			}

			if(isset($_GET['delete']) && is_array($_GET['delete'])){
				foreach($_GET['delete'] as $Key => $Val) {
					$Val = intval($Val);
					DB::delete($Fn_Renovation->TableBuild,'id ='.$Val);
					DB::delete($Fn_Renovation->TableBuildInfo,'build_id ='.$Val);
				}

				GetInsertDoLog('del_build_list_renovation','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete'])));//������¼

				fn_cpmsg($Fn_Renovation->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
			}else{
				fn_cpmsg($Fn_Renovation->Config['LangVar']['DelErr'],'','error');
			}
				
		}
	}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['bid']){
		if(!$Fn_Admin->CheckUserGroup('renovation_all') && !$Fn_Admin->CheckUserGroup('renovation_build_del')){//Ȩ���ж�
			fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
			exit();
		}
		$id = intval($_GET['bid']);
		DB::delete($Fn_Renovation->TableBuild,'id ='.$id);
		DB::delete($Fn_Renovation->TableBuildInfo,'build_id ='.$id);
		GetInsertDoLog('del_build_list_renovation','fn_'.$_GET['mod'],array('id'=>$id));//������¼
		fn_cpmsg($Fn_Admin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
	}else if($Do == 'Display' && $_GET['formhash'] == formhash() && $_GET['bid']){
		$id = intval($_GET['bid']);
		$UpData['display'] = intval($_GET['value']);
		DB::update($Fn_Renovation->TableBuild,$UpData,'id = '.$id);
		GetInsertDoLog('display_build_list_renovation','fn_'.$_GET['mod'],array('id'=>$id,'display'=>$_GET['value']));//������¼
		fn_cpmsg($Fn_Renovation->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

	}else if($Do == 'Progress'){
		//�����ֶ�
		$SearArray = array();
		$SearField =array('do','bid');
		foreach($SearField as $Val) {
			$SearArray[$Val] = $_GET[$Val] || in_array($_GET[$Val],array('0')) ? $_GET[$Val] : '';
		}
		//�����ֶ� End
		$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeSubModelUrl'].'&'.http_build_query($SearArray);
		
		if(!submitcheck('Submit')) {
			$Where = '';
			$Order = $_GET['order'] ? 'I.'.addslashes(dhtmlspecialchars($_GET['order'])) : 'I.id';
			if($_GET['bid']){
				$Where .= ' and I.build_id = '.intval($_GET['bid']);
			}
			$Where = preg_replace('/and/','where',$Where,1);
			$Limit = 100;
			$Page = $_GET['page']?intval($_GET['page']):1;
			/* ��ѯ���� End */
			
			/* ģ����� */
			showtagheader('div', 'row', true,'row');
			showtagheader('div', 'col-12', true,'col-12');
			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-body', true,'box-body');
			$BuildItem = $Fn_Renovation->GetViewBuildthread($_GET['bid']);
			echo <<<SEARCH
				<div class="FormSearchTo" style="margin-bottom:0;">
					<table cellspacing="4" cellpadding="4">
						<tr>
							<th>{$BuildItem['company_name']}&nbsp;&nbsp;{$BuildItem['title']}&nbsp;&nbsp;{$Fn_Renovation->Config['LangVar']['BuildProgress']}</th>
						</tr>
					</table>
				</div>
SEARCH;
			showtagheader('div', 'table-responsive', true,'table-responsive');
			showformheader($FormUrl,'enctype="multipart/form-data"');
			showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
			showsubtitle(array(
				'ID',
				'UID/'.$Fn_Renovation->Config['LangVar']['UserNameTitle'],
				$Fn_Renovation->Config['LangVar']['Content'],
				$Fn_Renovation->Config['LangVar']['Stage'],
				$Fn_Renovation->Config['LangVar']['DisplayTitle'],
				$Fn_Renovation->Config['LangVar']['RefreshTime'],
				$Fn_Renovation->Config['LangVar']['TimeTitle'],
				$Fn_Renovation->Config['LangVar']['OperationTitle']
			),'header tbm tc');

			$ModulesList = $Fn_Renovation->BuildInfoListFormat(GetModulesInfoList($Page,$Limit,$Where,$Order));
			foreach ($ModulesList as $Module) {
				
				showtablerow('', array('class="tc w50"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
					'<input type="checkbox" class="filled-in" id="checkbox_'.$Module['id'].'" name="delete[]" value="'.$Module['id'].'"><label for="checkbox_'.$Module['id'].'">'.$Module['id'].'</label>',
					$Module['uid'] ? $Module['uid'].'/'.$Module['username'] : '',
					'<div title="'.$Module['content'].'">'.cutstr($Module['content'],150).'</div>',
					$Module['stage_text'],
					!$Module['display'] ? '<span class="red">'.$Fn_Renovation->Config['LangVar']['No'].'</span>' : $Fn_Renovation->Config['LangVar']['Yes'],
					date('Y-m-d H:i',$Module['updateline']),
					date('Y-m-d H:i',$Module['dateline']),
					'<a href="'.$OpCpUrl.'&do=Info_Add&bid='.$Module['build_id'].'&iid='.$Module['id'].'" class="btn btn-sm btn-info-outline">'.$Fn_Renovation->Config['LangVar']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Info_Display&bid='.$Module['build_id'].'&iid='.$Module['id'].'&value='.(!empty($Module['display']) ? 0:1).'&formhash='.FORMHASH.'" class="btn btn-sm btn-purple-outline">'.(!empty($Module['display']) ? $Fn_Renovation->Config['LangVar']['DisplayNoTitle'] : $Fn_Renovation->Config['LangVar']['DisplayIsTitle']).'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Info_Del&bid='.$Module['build_id'].'&iid='.$Module['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$Fn_Renovation->Config['LangVar']['DelTitle'].'</a>',
				));
			}
			showsubmit('Submit','&#31435;&#21363;&#25552;&#20132;','del','<a href="'.$OpCpUrl.'&do=Info_Add&bid='.$_GET['bid'].'">'.$Fn_Renovation->Config['LangVar']['AddTitle'].'</a>');
			showtablefooter(); /*dism��taobao��com*/
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');

			/* ģ�����End */

		}else{
			if(isset($_GET['delete']) && is_array($_GET['delete'])){
				foreach($_GET['delete'] as $Key => $Val) {
					$Val = intval($Val);
					DB::delete($Fn_Renovation->TableBuildInfo,'id ='.$Val);
				}

				GetInsertDoLog('del_build_info_list_renovation','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete'])));//������¼

				fn_cpmsg($Fn_Renovation->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
			}else{
				fn_cpmsg($Fn_Renovation->Config['LangVar']['DelErr'],'','error');
			}
		}
	}else if($Do == 'Info_Add'){
		$id = intval($_GET['iid']);
		$Item = DB::fetch_first('SELECT * FROM '.DB::table($Fn_Renovation->TableBuildInfo).' where id = '.$id);
		if($Item){
			$Item['param'] = unserialize($Item['param']);
		};
		if(!submitcheck('DetailSubmit')) {
			$OpTitle = $Fn_Renovation->Config['LangVar']['AddTitle'];
			if($Item){
				$OpTitle = $Fn_Renovation->Config['LangVar']['EditTitle'];
			}
			
			//ͼƬ�ϴ�
			if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_assembly/class/class_upload.php')){
				@require_once libfile('class/upload','plugin/fn_assembly');
				$UploadConfig = fn_upload::Config();
			}
			
			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-header', true,'with-border box-header');
			showtitle($OpTitle,'class="box-title"');
			showtagfooter('div');
			showformheader($Fn_Admin->Config['IframeSubModelUrl'].'&do=Info_Add&bid='.$_GET['bid'].'&iid='.$id,'enctype');
			showtagheader('div', 'box-body', true,'box-body');

			echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_Renovation->Config['LangVar']['ProgressChart'].'</label><div class="col-sm-9"><div class="AdminSingleUpload"><div class="PhotoControl" id="ProgressChartoPhotoControl"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';

			showsetting('uid', 'new_uid', $Item['uid'], 'text');
						
			showsetting($Fn_Renovation->Config['LangVar']['Content'], 'content', $Item['content'], 'textarea');

			showsetting($Fn_Renovation->Config['LangVar']['Stage'], array('stage',DyadicArray($Fn_Renovation->Config['LangVar']['StageMinArray'])), $Item['stage'] ? $Item['stage'] : 1 , 'mradio');
			
			if($Item['updateline']){
				showsetting($Fn_Renovation->Config['LangVar']['RefreshTime'], 'updateline',$Item['updateline'] ? date('Y-m-d H:i',$Item['updateline']) : '', 'calendar','','','',1);
			}

			if($Item['dateline']){
				showsetting($Fn_Renovation->Config['LangVar']['TimeTitle'], 'dateline',date('Y-m-d H:i',$Item['dateline']), 'calendar','','','',1);
			}

			showsetting($Fn_Renovation->Config['LangVar']['DisplayTitle'], 'display', $Item ? $Item['display'] : 1, 'radio');
			
			showsubmit('DetailSubmit','&#20445;&#23384;&#37197;&#32622;');
			showtagfooter('div');
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');
			
			$UpLoadHtml  = '';
			if($Item['param']['imgs']){
				foreach($Item['param']['imgs'] as $Key => $Val) {
					$ImgsJsArray[] = '"'.$Val.'"';
				}
				$UpLoadHtml .= '
				var InputArray = new Array('.implode(',',$ImgsJsArray).');
				$("#ProgressChartoPhotoControl").AppUpload({InputName:"new_imgs",InputExist:true,InputArray:InputArray});';

			}else{
				$UpLoadHtml .= '$("#ProgressChartoPhotoControl").AppUpload({InputName:"new_imgs"});';
			}

			echo $UploadConfig['CssJsHtml'].'<script>'.$UpLoadHtml.'</script> ';

		}else{
			
			foreach($_GET['new_imgs'] as $Key => $Val) {
				$_GET['new_imgs'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
			}

			$Data['uid'] = intval($_GET['new_uid']);
			$Member = DB::fetch_first('SELECT username FROM '.DB::table('common_member').' where uid = '.$Data['uid']);
			$Data['username'] = addslashes(strip_tags($Member['username']));
			$Data['build_id'] = intval($_GET['bid']);
			$Data['content'] = addslashes(strip_tags($_GET['content']));
			$Data['stage'] = intval($_GET['stage']);
			$Data['display'] = intval($_GET['display']);
			
			$Param['imgs'] = is_array($_GET['new_imgs']) && isset($_GET['new_imgs'])  ? array_filter($_GET['new_imgs']) : '';
			$Param['imgs_count'] = count($Param['imgs']);
			$Data['param'] = serialize($Param);
			
			if($Item){
				$Data['updateline'] = strtotime($_GET['updateline']);

				GetInsertDoLog('edit_build_list_renovation','fn_'.$_GET['mod'],array('id'=>$id));//������¼

				DB::update($Fn_Renovation->TableBuildInfo,$Data,'id = '.$id);
					
			}else{
				$Data['dateline'] = $Data['updateline'] = time();

				$Id = DB::insert($Fn_Renovation->TableBuildInfo,$Data,true);

				GetInsertDoLog('add_build_list_renovation','fn_'.$_GET['mod'],array('id'=>$Id));//������¼
			}

			DB::update($Fn_Renovation->TableBuild,array('stage'=>$Data['stage']),'id = '.$Data['build_id']);


			fn_cpmsg($Fn_Renovation->Config['LangVar']['UpdateOk'],$Fn_Admin->Config['IframeItemUrl'].'&submodel=list&do=Progress&bid='.$_GET['bid'],'succeed');
			
		}

	}else if($Do == 'Info_Del' && $_GET['formhash'] == formhash() && $_GET['iid']){
		$id = intval($_GET['iid']);
		DB::delete($Fn_Renovation->TableBuildInfo,'id ='.$id);
		GetInsertDoLog('del_build_info_list_renovation','fn_'.$_GET['mod'],array('id'=>$id));//������¼
		fn_cpmsg($Fn_Admin->Config['LangVar']['DelOk'],$Fn_Admin->Config['IframeItemUrl'].'&submodel=list&do=Progress&bid='.$_GET['bid'],'succeed');
	}else if($Do == 'Info_Display' && $_GET['formhash'] == formhash() && $_GET['iid']){
		$id = intval($_GET['iid']);
		$UpData['display'] = intval($_GET['value']);
		DB::update($Fn_Renovation->TableBuildInfo,$UpData,'id = '.$id);
		GetInsertDoLog('display_build_info_list_renovation','fn_'.$_GET['mod'],array('id'=>$id,'display'=>$_GET['value']));//������¼
		fn_cpmsg($Fn_Admin->Config['LangVar']['DelOk'],$Fn_Admin->Config['IframeItemUrl'].'&submodel=list&do=Progress&bid='.$_GET['bid'],'succeed');
	}
}else if($SubModel == 'add'){//���ӻ�༭
	if(!$Fn_Admin->CheckUserGroup('renovation_all') && !$Fn_Admin->CheckUserGroup('renovation_build_add')){//Ȩ���ж�
		fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
		exit();
	}
	$id = intval($_GET['bid']);

	$Item = DB::fetch_first('SELECT * FROM '.DB::table($Fn_Renovation->TableBuild).' where id = '.$id);
	if($Item){
		//$Item['param'] = unserialize($Item['param']);
	};
	if(!submitcheck('DetailSubmit')) {
		$OpTitle = $Fn_Renovation->Config['LangVar']['AddTitle'];
		if($Item){
			$OpTitle = $Fn_Renovation->Config['LangVar']['EditTitle'];
		}
		
		//ͼƬ�ϴ�
		if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_assembly/class/class_upload.php')){
			@require_once libfile('class/upload','plugin/fn_assembly');
			$UploadConfig = fn_upload::Config();
		}
		
		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-header', true,'with-border box-header');
		showtitle($OpTitle,'class="box-title"');
		showtagfooter('div');
		showformheader($Fn_Admin->Config['IframeSubModelUrl'].'&bid='.$id,'enctype');
		showtagheader('div', 'box-body', true,'box-body');

		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_Renovation->Config['LangVar']['Thumbnail'].'</label><div class="col-sm-9"><div class="AdminSingleUpload"><div class="PhotoControl" id="LogoPhotoControl"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';

		showsetting('uid', 'new_uid', $Item['uid'], 'text');
		
		showsetting($Fn_Renovation->Config['LangVar']['CompanyID'], 'company_id', $Item['company_id'], 'text');

		showsetting($Fn_Renovation->Config['LangVar']['CommunityID'], 'community_id', $Item['community_id'], 'text');
		
		showsetting($Fn_Renovation->Config['LangVar']['Title'], 'title', $Item['title'], 'text');
		
		showsetting($Fn_Renovation->Config['LangVar']['Style'], array('style',DyadicArray($Fn_Renovation->Config['LangVar']['style'])), $Item['style'] , 'select');

		showsetting($Fn_Renovation->Config['LangVar']['Apartment'], array('apartment',DyadicArray($Fn_Renovation->Config['LangVar']['apartment'])), $Item['apartment'] , 'select');

		showsetting($Fn_Renovation->Config['LangVar']['MoneyTitle'], 'money', $Item['money'], 'text','','',$Fn_Renovation->Config['LangVar']['MoneyWanTips']);
		
		showsetting($Fn_Renovation->Config['LangVar']['Square'], 'square', $Item['square'], 'text');
		
		showsetting($Fn_Renovation->Config['LangVar']['DecorationForm'], array('forms',DyadicArray($Fn_Renovation->Config['LangVar']['DecorationFormArray'])), $Item['forms'] , 'mradio');

		showsetting($Fn_Renovation->Config['LangVar']['Stage'], array('stage',DyadicArray($Fn_Renovation->Config['LangVar']['StageMinArray'])), $Item['stage'] , 'mradio');

		
		if($Item['updateline']){
			showsetting($Fn_Renovation->Config['LangVar']['RefreshTime'], 'updateline',$Item['updateline'] ? date('Y-m-d H:i',$Item['updateline']) : '', 'calendar','','','',1);
		}

		if($Item['dateline']){
			showsetting($Fn_Renovation->Config['LangVar']['TimeTitle'], 'dateline',date('Y-m-d H:i',$Item['dateline']), 'calendar','','','',1);
		}

		showsetting($Fn_Renovation->Config['LangVar']['Click'], 'click', $Item['click'], 'text');

		showsetting($Fn_Renovation->Config['LangVar']['DisplayTitle'], 'display', $Item ? $Item['display'] : 1, 'radio');
		
		showsubmit('DetailSubmit','&#20445;&#23384;&#37197;&#32622;');
		showtagfooter('div');
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');
		
		$UpLoadHtml  = '';
		if($Item['thumbnail']){
			$ThumbnailJsArray[] = '"'.$Item['thumbnail'].'"';;
			$UpLoadHtml .= '
			var InputArray = new Array('.implode(',',$ThumbnailJsArray).');
			$("#LogoPhotoControl").AppUpload({InputName:"new_thumbnail",Multiple:true,InputExist:true,InputArray:InputArray});';

		}else{
			$UpLoadHtml .= '$("#LogoPhotoControl").AppUpload({InputName:"new_thumbnail",Multiple:true});';
		}

		echo $UploadConfig['CssJsHtml'].'<script>'.$UpLoadHtml.'</script> ';

	}else{
		
		foreach($_GET['new_thumbnail'] as $Key => $Val) {
			$_GET['new_thumbnail'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}


		$Data['uid'] = intval($_GET['new_uid']);
		$Member = DB::fetch_first('SELECT username FROM '.DB::table('common_member').' where uid = '.$Data['uid']);
		$Data['username'] = addslashes(strip_tags($Member['username']));
		$Data['thumbnail'] = addslashes(strip_tags($_GET['new_thumbnail'][0]));
		$Data['company_id'] = intval($_GET['company_id']);
		$Data['community_id'] = intval($_GET['community_id']);
		$CommunityItem = $Fn_Renovation->GetViewCommunitythread($Data['community_id']);
		$Data['community_name'] = addslashes(strip_tags($CommunityItem['name']));
		$Data['title'] = addslashes(strip_tags($_GET['title']));
		$Data['style'] = intval($_GET['style']);
		$Data['apartment'] = intval($_GET['apartment']);
		$Data['money'] = addslashes(strip_tags($_GET['money']));
		$Data['square'] = intval($_GET['square']);
		$Data['forms'] = intval($_GET['forms']);
		$Data['stage'] = intval($_GET['stage']);

		$Data['click'] = intval($_GET['click']);
		$Data['display'] = intval($_GET['display']);
		
		if($Item){
			$Data['updateline'] = strtotime($_GET['updateline']);

			GetInsertDoLog('edit_build_list_renovation','fn_'.$_GET['mod'],array('id'=>$id));//������¼

			DB::update($Fn_Renovation->TableBuild,$Data,'id = '.$id);
				
		}else{
			$Data['dateline'] = $Data['updateline'] = time();

			$Id = DB::insert($Fn_Renovation->TableBuild,$Data,true);

			GetInsertDoLog('add_build_list_renovation','fn_'.$_GET['mod'],array('id'=>$Id));//������¼
		}
		fn_cpmsg($Fn_Renovation->Config['LangVar']['UpdateOk'],$Fn_Admin->Config['IframeItemUrl'].'&submodel=list','succeed');
		
	}
}


/* �б� */
function GetModulesList($Page,$Limit,$Where=null,$Order){
	global $Fn_Renovation;
	$FetchSql = 'SELECT B.*,C.name as company_name FROM '.DB::table($Fn_Renovation->TableBuild).' B LEFT JOIN `'.DB::table($Fn_Renovation->TableCompany).'` C on C.id = B.company_id '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}

/* �б� */
function GetModulesInfoList($Page,$Limit,$Where=null,$Order){
	global $Fn_Renovation;
	$FetchSql = 'SELECT I.* FROM '.DB::table($Fn_Renovation->TableBuildInfo).' I '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}

/* ���� */
function GetModulesCount($Where=null){
	global $Fn_Renovation;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_Renovation->TableBuild).' B '.$Where;
	return DB::result_first($FetchSql);//��������
}

?>