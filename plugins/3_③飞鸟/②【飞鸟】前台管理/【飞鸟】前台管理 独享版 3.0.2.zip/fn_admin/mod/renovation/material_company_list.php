<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('renovation_all') && !$Fn_Admin->CheckUserGroup('renovation_material_company_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$SubModel = in_array($_GET['submodel'], array('list','add')) ? $_GET['submodel'] : 'list';
$Fn_Admin->Config['IframeSubModelUrl'] = $Fn_Admin->Config['IframeItemUrl'].'&submodel='.$SubModel;
$NavClass = array($SubModel=>'btn-info Hover');

//����
echo <<<Nav
<div class="SubModelNav">
  <ul>
	<li class="{$NavClass['list']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=list" target="_self">{$Fn_Admin->Config['LangVar']['RenovationLeftNavArray'][$_GET['item']]}</a></li>
    <li class="{$NavClass['add']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=add" target="_self">{$Fn_Admin->Config['LangVar']['AddEditTitle']}</a></li>
  </ul>
  <div class="both"></div>
</div>
Nav;

if($SubModel == 'list'){//�б�
	$Do = in_array($_GET['do'], array('Refresh','Del','Display','Verify','AllRefreshJob')) ? $_GET['do'] : 'submodel_list';
	//�����ֶ�
	$SearField =array('page','keyword','agent_id','display','verify','vip','expired','order','group_id','classid');
	foreach($SearField as $Val) {
		$SearArray[$Val] = $_GET[$Val] || in_array($_GET[$Val],array('0')) ? $_GET[$Val] : '';
	}
	//�����ֶ� End
	$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeSubModelUrl'].'&'.http_build_query($SearArray);


	if($Do == 'submodel_list'){
		if(!submitcheck('Submit')) {
			$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
			$Where = '';
			$Order = $_GET['order'] ? 'C.'.addslashes(dhtmlspecialchars($_GET['order'])) : 'C.id';
			
			if($_GET['keyword']){
				$_GET['keyword'] = str_replace(array('%','_'),array('',''),$_GET['keyword']);
				$Where .= ' and (C.name like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or C.username like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or C.mobile like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or C.uid = '.intval($_GET['keyword']).' or C.id = '.intval($_GET['keyword']).' )';
			}
			
			if($_GET['classid']){
				$Where .= ' and C.classid = '.intval($_GET['classid']);
			}

			if($_GET['group_id']){
				$Where .= ' and C.group_id = '.intval($_GET['group_id']).' and C.due_time >= '.time();
			}

			if(in_array($_GET['vip'],array('0','1'))){
				
				$Where .= $_GET['vip'] == 1 ? ' and C.due_time >= '.time() : ' and C.due_time < '.time();
			}

			if(in_array($_GET['expired'],array('1'))){
				
				$Where .=  ' and C.due_time != \'\' and C.due_time < '.time();
			}

			if(in_array($_GET['verify'],array('0','1'))){
				$Where .= ' and C.verify = '.intval($_GET['verify']);
			}

			if(in_array($_GET['display'],array('0','1'))){
				$Where .= ' and C.display = '.intval($_GET['display']);
			}

			$Where = preg_replace('/and/','where',$Where,1);
			$Limit = 20;
			$Page = $_GET['page']?intval($_GET['page']):1;
			/* ��ѯ���� End */
	
			/* ģ����� */	
			showtagheader('div', 'row', true,'row');
			showtagheader('div', 'col-12', true,'col-12');
			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-body', true,'box-body');
			/* ���� */
			$VipSelected = array($_GET['vip']=>' selected');
			$ExpiredSelected = array($_GET['expired']=>' selected');
			$VerifySelected = array($_GET['verify']=>' selected');
			$DisplaySelected = array($_GET['display']=>' selected');
			$OrderSelected = array($_GET['order']=>' selected');
			$GroupListOption = '<option value="">'.$Fn_Renovation->Config['LangVar']['SelectNull'].'</option>';
			foreach($Fn_Renovation->GetMaterialCompanyGroupList() as $Val) {
				$GroupListOption .= '<option value="'.$Val['id'].'" '.($_GET['group_id'] == $Val['id'] ? ' selected' : '' ).'>'.$Val['title'].'</option>';
			}

			$ClassListOption = '<option value="">'.$Fn_Renovation->Config['LangVar']['SelectNull'].'</option>';
			foreach(DB::fetch_all('SELECT * FROM '.DB::table($Fn_Renovation->TableMaterialClass).' order by displayorder asc','','id') as $Val) {
				$ClassListOption .= '<option value="'.$Val['id'].'" '.($_GET['classid'] == $Val['id'] ? ' selected' : '' ).'>'.$Val['name'].'</option>';
			}

			echo <<<SEARCH
			<form method="post" autocomplete="off" action="$SearUrl">
				<div class="FormSearchTo" style="margin-bottom:0;">
					<table cellspacing="4" cellpadding="4">
						<tr>
							<th>{$Fn_Renovation->Config['LangVar']['KeywordTitle']}</th><td><input type="text" class="input form-control w200" name="keyword" value="{$_GET['keyword']}" placeholder="{$Fn_Renovation->Config['LangVar']['AdminCompanyPlaceholder']}">
							</td>
							<th>{$Fn_Admin->Config['LangVar']['ClassTitle']}</th><td>
							<select name="classid" class="form-control w120">
								{$ClassListOption}
							</select>
							
							</td>
							<th>{$Fn_Renovation->Config['LangVar']['Level']}</th><td>
							<select name="group_id" class="form-control w120">
								{$GroupListOption}
							</select>
							
							</td>
							<th>{$Fn_Renovation->Config['LangVar']['ISVIP']}</th><td>
							
							<select name="vip" class="form-control w120">
								<option value="">{$Fn_Renovation->Config['LangVar']['SelectNull']}</option>
								<option value="1"{$VipSelected['1']}>{$Fn_Renovation->Config['LangVar']['Yes']}</option>
								<option value="0"{$VipSelected['0']}>{$Fn_Renovation->Config['LangVar']['No']}</option>
							</select>						
							</td>
							<th>{$Fn_Renovation->Config['LangVar']['ISExpired']}</th><td>
							
							<select name="expired" class="form-control w120">
								<option value="">{$Fn_Renovation->Config['LangVar']['SelectNull']}</option>
								<option value="1"{$ExpiredSelected['1']}>{$Fn_Renovation->Config['LangVar']['Yes']}</option>
							</select>							
							</td>
							<th>{$Fn_Renovation->Config['LangVar']['IsVerify']}</th><td>
							
							<select name="verify" class="form-control w120">
								<option value="">{$Fn_Renovation->Config['LangVar']['SelectNull']}</option>
								<option value="1"{$VerifySelected['1']}>{$Fn_Renovation->Config['LangVar']['Yes']}</option>
								<option value="0"{$VerifySelected['0']}>{$Fn_Renovation->Config['LangVar']['No']}</option>
							</select>						
							</td>
							<th>{$Fn_Renovation->Config['LangVar']['DisplayTitle']}</th><td>
							<select name="display" class="form-control w120">
								<option value="">{$Fn_Renovation->Config['LangVar']['SelectNull']}</option>
								<option value="1"{$DisplaySelected['1']}>{$Fn_Renovation->Config['LangVar']['Yes']}</option>
								<option value="0"{$DisplaySelected['0']}>{$Fn_Renovation->Config['LangVar']['No']}</option>
							</select>
							</td>
							<th>{$Fn_Admin->Config['LangVar']['Order']}</th><td>
							
							<select name="order" class="form-control w120">
								<option value="dateline"{$OrderSelected['dateline']}>{$Fn_Admin->Config['LangVar']['OrderArray']['dateline']}</option>
								<option value="click"{$OrderSelected['click']}>{$Fn_Admin->Config['LangVar']['OrderArray']['click']}</option>
							</select>
							&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Admin->Config['LangVar']['SearchSubmit']}" class="btn btn-info" type="submit">
							</td>
						</tr>
					</table>
				</div>
			</form>
SEARCH;
			/* ���� End */
			showtagheader('div', 'table-responsive', true,'table-responsive');
			showformheader($FormUrl,'enctype="multipart/form-data"');
			showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
			showsubtitle(array(
				'ID',
				'UID/'.$Fn_Renovation->Config['LangVar']['UserNameTitle'],
				'Logo',
				$Fn_Renovation->Config['LangVar']['LicenseMax'],
				$Fn_Renovation->Config['LangVar']['CompanyName'],
				$Fn_Admin->Config['LangVar']['ClassTitle'],
				$Fn_Renovation->Config['LangVar']['Telephone'],
				$Fn_Renovation->Config['LangVar']['Address'],
				$Fn_Renovation->Config['LangVar']['Level'],
				$Fn_Renovation->Config['LangVar']['CompanyExperience'],
				$Fn_Renovation->Config['LangVar']['IsVerify'],
				$Fn_Renovation->Config['LangVar']['DisplayTitle'],
				$Fn_Renovation->Config['LangVar']['DueTime'],
				$Fn_Renovation->Config['LangVar']['RefreshTime'],
				$Fn_Renovation->Config['LangVar']['SetTopTime'],
				$Fn_Renovation->Config['LangVar']['TimeTitle'],
				$Fn_Renovation->Config['LangVar']['OperationTitle']
			),'header tbm tc');

			$ModulesList = $Fn_Renovation->CompanyListFormat(GetModulesList($Page,$Limit,$Where,$Order));
			foreach ($ModulesList as $Module) {
				
				showtablerow('', array('class="tc w50"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
					'<input type="checkbox" class="filled-in" id="checkbox_'.$Module['id'].'" name="delete[]" value="'.$Module['id'].'"><label for="checkbox_'.$Module['id'].'">'.$Module['id'].'</label>',
					$Module['uid'].'/'.$Module['username'],
					$Module['logo'] ? '<img src="'.$Module['logo'].'" style="height:30px;">' : '',
					$Module['param']['license'] ? '<a href="'.$Module['param']['license'].'" target="_blank"><img src="'.$Module['param']['license'].'" style="height:30px;"></a>' : '',
					$Module['name'],
					$Module['class_name'],
					$Module['mobile'],
					$Module['province_text'].$Module['community'],
					$Module['due_time'] >= time() ? $Module['group_title'] : '',
					!$Module['experience'] ? '<span class="label bg-secondary">'.$Fn_Renovation->Config['LangVar']['No'].'</span>' : '<span class="label bg-blue">'.$Fn_Renovation->Config['LangVar']['Yes'].'</span>',
					!$Module['verify'] ? '<span class="label bg-secondary">'.$Fn_Renovation->Config['LangVar']['No'].'</span>' : '<span class="label bg-blue">'.$Fn_Renovation->Config['LangVar']['Yes'].'</span>',
					!$Module['display'] ? '<span class="label bg-secondary">'.$Fn_Renovation->Config['LangVar']['No'].'</span>' : '<span class="label bg-blue">'.$Fn_Renovation->Config['LangVar']['Yes'].'</span>',
					$Module['due_time'] >= time() ? date('Y-m-d',$Module['due_time']) : ($Module['due_time'] ? '<span class="label bg-danger">'.$Fn_Renovation->Config['LangVar']['Expired'].'</span>' : ''),
					$Module['updateline'],
					$Module['topdateline'] && $Module['topdateline'] >= time() ? date('Y-m-d H:i',$Module['topdateline']) : '',
					date('Y-m-d H:i',$Module['dateline']),
					'<a href="'.$Fn_Renovation->Config['ViewMaterialCompanyUrl'].$Module['id'].'" target="_blank">'.cplang('view').'</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&cid='.$Module['id'].'">'.$Fn_Renovation->Config['LangVar']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Refresh&cid='.$Module['id'].'&formhash='.FORMHASH.'">'.$Fn_Renovation->Config['LangVar']['Refresh'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Verify&cid='.$Module['id'].'&value='.(!empty($Module['verify']) ? 0:1).'&formhash='.FORMHASH.'">'.(!empty($Module['verify']) ? $Fn_Renovation->Config['LangVar']['NoVerify'] : $Fn_Renovation->Config['LangVar']['Verify']).'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Display&cid='.$Module['id'].'&value='.(!empty($Module['display']) ? 0:1).'&formhash='.FORMHASH.'">'.(!empty($Module['display']) ? $Fn_Renovation->Config['LangVar']['DisplayNoTitle'] : $Fn_Renovation->Config['LangVar']['DisplayIsTitle']).'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Del&cid='.$Module['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;">'.$Fn_Renovation->Config['LangVar']['DelTitle'].'</a><br><a href="'.$Fn_Admin->Config['ModUrl'].'&item=material_goods_list&iframe=true&company_id='.$Module['id'].'">'.$Fn_Admin->Config['LangVar']['RenovationLeftNavArray']['material_goods_list'].'</a>',
				));
			}
			showsubmit('Submit','&#31435;&#21363;&#25552;&#20132;','del','','',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));
			showtablefooter(); /*dism��taobao��com*/
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			/* ģ�����End */	
		}else{
			if(!$Fn_Admin->CheckUserGroup('renovation_all') && !$Fn_Admin->CheckUserGroup('renovation_material_company_del')){//Ȩ���ж�
				fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
				exit();
			}

			if(isset($_GET['delete']) && is_array($_GET['delete'])){
				foreach($_GET['delete'] as $Key => $Val) {
					$Val = intval($Val);
					DB::delete($Fn_Renovation->TableMaterialCompany,'id ='.$Val);
					DB::delete($Fn_Renovation->TableMaterialCompanyGroupLog,'company_id ='.$Val);
					DB::delete($Fn_Renovation->TableMaterialGoods,'company_id ='.$Val);
					DB::delete($Fn_Renovation->TableMaterialForm,'company_id ='.$Val);
				}

				GetInsertDoLog('del_material_company_list_renovation','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete'])));//������¼

				fn_cpmsg($Fn_Renovation->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
			}else{
				fn_cpmsg($Fn_Renovation->Config['LangVar']['DelErr'],'','error');
			}
				
		}
	}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['cid']){
		if(!$Fn_Admin->CheckUserGroup('renovation_all') && !$Fn_Admin->CheckUserGroup('renovation_material_company_del')){//Ȩ���ж�
			fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
			exit();
		}
		$id = intval($_GET['cid']);
		DB::delete($Fn_Renovation->TableMaterialCompany,'id ='.$id);
		DB::delete($Fn_Renovation->TableMaterialCompanyGroupLog,'company_id ='.$id);
		DB::delete($Fn_Renovation->TableMaterialGoods,'company_id ='.$id);
		DB::delete($Fn_Renovation->TableMaterialForm,'company_id ='.$id);
		GetInsertDoLog('del_material_company_list_renovation','fn_'.$_GET['mod'],array('id'=>$id));//������¼
		fn_cpmsg($Fn_Admin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
	}else if($Do == 'Refresh' && $_GET['formhash'] == formhash() && $_GET['cid']){
		$id = intval($_GET['cid']);
		$UpData['updateline'] = time();
		DB::update($Fn_Renovation->TableMaterialCompany,$UpData,'id = '.$id);
		GetInsertDoLog('refresh_material_company_list_renovation','fn_'.$_GET['mod'],array('id'=>$id));//������¼
		fn_cpmsg($Fn_Renovation->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

	}else if($Do == 'Verify' && $_GET['formhash'] == formhash() && $_GET['cid']){
		$id = intval($_GET['cid']);
		$UpData['verify'] = intval($_GET['value']);
		DB::update($Fn_Renovation->TableMaterialCompany,$UpData,'id = '.$id);
		GetInsertDoLog('verify_material_company_list_renovation','fn_'.$_GET['mod'],array('id'=>$id,'verify'=>$_GET['value']));//������¼
		fn_cpmsg($Fn_Renovation->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

	}else if($Do == 'Display' && $_GET['formhash'] == formhash() && $_GET['cid']){
		$id = intval($_GET['cid']);
		$UpData['display'] = intval($_GET['value']);
		DB::update($Fn_Renovation->TableMaterialCompany,$UpData,'id = '.$id);
		GetInsertDoLog('display_material_company_list_renovation','fn_'.$_GET['mod'],array('id'=>$id,'display'=>$_GET['value']));//������¼
		fn_cpmsg($Fn_Renovation->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

	}
}else if($SubModel == 'add'){//���ӻ�༭
	if(!$Fn_Admin->CheckUserGroup('renovation_all') && !$Fn_Admin->CheckUserGroup('renovation_material_company_add')){//Ȩ���ж�
		fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
		exit();
	}
	$Cid = intval($_GET['cid']);

	$Item = DB::fetch_first('SELECT * FROM '.DB::table($Fn_Renovation->TableMaterialCompany).' where id = '.$Cid);
	if($Item){
		$Item['param'] = unserialize($Item['param']);
		$CompanyGroupLogItem = DB::fetch_first('SELECT * FROM '.DB::table($Fn_Renovation->TableMaterialCompanyGroupLog).' where company_id = '.$Item['id']);
	};
	if(!submitcheck('DetailSubmit')) {
		$OpTitle = $Fn_Renovation->Config['LangVar']['AddTitle'];
		if($Item){
			$OpTitle = $Fn_Renovation->Config['LangVar']['EditTitle'];
			$Item['province_text'] = $Fn_Renovation->Area[$Item['province']]['content'].($Item['city'] ? $Fn_Renovation->Area[$Item['city']]['content'] : '').($Item['dist'] ? $Fn_Renovation->Area[$Item['dist']]['content'] : '');
		}

		echo '<script src="'.$Config['StaticPath'].'/ueditor/'.CHARSET.'/ueditor.config.js" type="text/javascript"></script><script src="'.$Config['StaticPath'].'/ueditor/'.CHARSET.'/ueditor.all.js" type="text/javascript"></script>';
		
		//ͼƬ�ϴ�
		if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_assembly/class/class_upload.php')){
			@require_once libfile('class/upload','plugin/fn_assembly');
			$UploadConfig = fn_upload::Config();
		}
		
		showtagheader('div', 'box', true,'box');
		showformheader($Fn_Admin->Config['IframeSubModelUrl'].'&cid='.$Cid,'enctype');
		echo <<<HTML
		<ul class="nav nav-tabs customtab" role="tablist">
          <li class="nav-item"> <a class="nav-link active" data-toggle="tab" href="#basics" role="tab" aria-expanded="true"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#20844;&#21496;&#36164;&#26009;</span></a> </li>
		  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#level" role="tab" aria-expanded="false"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#22871;&#39184;&#35774;&#32622;</span></a> </li>
		  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#other" role="tab" aria-expanded="false"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#20854;&#20182;&#35774;&#32622;</span></a> </li>
        </ul>
HTML;
		showtagheader('div', 'box-body', true,'box-body');
		showtagheader('div', 'tab-content', true,'tab-content');
		
		echo <<<HTML
		<!-- ��˾����  -->
		<div class="tab-pane active" id="basics" role="tabpanel" aria-expanded="true">
HTML;
		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">Logo</label><div class="col-sm-9"><div class="AdminSingleUpload"><div class="PhotoControl" id="LogoPhotoControl"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';

		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_Renovation->Config['LangVar']['Banner'].'</label><div class="col-sm-9"><div class="AdminSingleUpload"><div class="PhotoControl" id="BannerPhotoControl"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';

		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_Renovation->Config['LangVar']['LicenseMax'].'</label><div class="col-sm-9"><div class="AdminSingleUpload"><div class="PhotoControl" id="LicensePhotoControl"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';
		
	
		showsetting('uid', 'new_uid', $Item['uid'], 'text');

		showsetting($Fn_Renovation->Config['LangVar']['AdminUid'], 'admin_uid', $Item['admin_uid'], 'text','','',$Fn_Renovation->Config['LangVar']['AdminUidTips']);
		
		showsetting($Fn_Renovation->Config['LangVar']['CompanyName'], 'name', $Item['name'], 'text');

		$SmallAreaPositionTreelistHtml = GetTreelistHtml($Fn_Renovation->Area,'SmallAreaPositionList',$Item['province'],$Item['city'],$Item['dist']);
		
		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_Renovation->Config['LangVar']['Position'].':</label><div class="col-sm-2"><div style="position:relative;height:40px"><input value="'.$Item['province_text'].'" class="input form-control TreeList" type="text" id="SmallAreaPosition">'.$SmallAreaPositionTreelistHtml.'</div></div><div class="col-sm-7 form-inline"><input type="hidden" name="province" value="'.$Item['province'].'"/><input type="hidden" name="city" value="'.$Item['city'].'"/><input type="hidden" name="dist" value="'.$Item['dist'].'"/></div></div>';

		showsetting($Fn_Renovation->Config['LangVar']['Address'], 'community', $Item['community'], 'text');
		
		showsetting($Fn_Admin->Config['LangVar']['Longitude'], 'lng', $Item['lng'], 'text','','','<div class="MapClick">'.($Item['lng'] && $Item['lat'] ? $Fn_Renovation->Config['LangVar']['IsTagging'] : $Fn_Renovation->Config['LangVar']['Tagging']).'</div><div class="TipMap"><iframe id="MapPage" width="100%" height="100%" frameborder=0 src=""></iframe></div>');

		showsetting($Fn_Admin->Config['LangVar']['Latitude'], 'lat', $Item['lat'], 'text');

		showsetting($Fn_Renovation->Config['LangVar']['Telephone'], 'landline', $Item['landline'], 'text');

		showsetting($Fn_Renovation->Config['LangVar']['ShortMessageTel'], 'mobile', $Item['mobile'], 'text');

		showsetting($Fn_Renovation->Config['LangVar']['Grade'], 'grade', $Item['grade'], 'text','','',$Fn_Renovation->Config['LangVar']['GradeTips']);

		$ClassList = array();
		
		foreach(DB::fetch_all('SELECT * FROM '.DB::table($Fn_Renovation->TableMaterialClass).' order by displayorder asc','','id') as $Val) {
			$ClassList[] = array($Val['id'], $Val['name']);
		}
		showsetting($Fn_Admin->Config['LangVar']['ClassTitle'], array('classid', $ClassList),$Item['classid'], 'select');

		//��������
		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_Renovation->Config['LangVar']['Describe'].':</label><div class="col-sm-9"><textarea id="content" name="content" style="width:80%;height:450px;">'.stripslashes($Item['content']).'</textarea></div></div>';
		echo <<<HTML
		</div>
		<!-- ��˾���� end  -->
HTML;

		echo <<<HTML
		<!-- �ײ�����  -->
		<div class="tab-pane" id="level" role="tabpanel" aria-expanded="false">
HTML;
		$GroupList = array();
		
		foreach($Fn_Renovation->GetMaterialCompanyGroupList() as $Val) {
			$GroupList[] = array($Val['id'], $Val['title']);
		}

		showsetting($Fn_Renovation->Config['LangVar']['AdminVipOpen'], array('vip_type',DyadicArray($Fn_Renovation->Config['LangVar']['AdminVipOpenArray'])),0, 'mradio','','',$Fn_Renovation->Config['LangVar']['AdminVipOpenTips']);

		showsetting($Fn_Renovation->Config['LangVar']['xztc'], array('group_id', $GroupList),$Item['due_time'] >= time() ? $Item['group_id'] : '', 'mradio');

		showsetting($Fn_Renovation->Config['LangVar']['MaterialCompanyGroupCaseCount'], 'case_count', $CompanyGroupLogItem['case_count'], 'text','','',$Fn_Renovation->Config['LangVar']['MaterialCompanyGroupCaseCountTips']);

		showsetting($Fn_Renovation->Config['LangVar']['MaterialCompanyGroupGoodsCount'], 'goods_count', $CompanyGroupLogItem['goods_count'], 'text','','',$Fn_Renovation->Config['LangVar']['MaterialCompanyGroupGoodsCountTips']);
		
		showsetting($Fn_Renovation->Config['LangVar']['CompanyGroupBanner'], 'banner', $CompanyGroupLogItem['banner'], 'radio');
		showsetting($Fn_Renovation->Config['LangVar']['CompanyGroupHot'], 'hot', $CompanyGroupLogItem['hot'], 'radio');
		showsetting($Fn_Renovation->Config['LangVar']['MaterialCompanyGroupCaseExamine'], 'case_examine', $CompanyGroupLogItem['case_examine'], 'radio');
		showsetting($Fn_Renovation->Config['LangVar']['MaterialCompanyGroupExamine'], 'examine', $CompanyGroupLogItem['examine'], 'radio');
		showsetting($Fn_Renovation->Config['LangVar']['SmsNotification'], 'sms', $CompanyGroupLogItem['sms'], 'radio');
	
		showsetting($Fn_Renovation->Config['LangVar']['DueTime'], 'due_time',$Item['due_time'] ? date('Y-m-d',$Item['due_time']) : '', 'calendar');
		showsetting($Fn_Renovation->Config['LangVar']['CompanyExperience'], 'experience', $Item['experience'], 'radio');
		echo <<<HTML
		</div>
		<!-- �ײ�Ȩ�� end  -->
HTML;
		
		echo <<<HTML
		<!-- ��������  -->
		<div class="tab-pane" id="other" role="tabpanel" aria-expanded="false">
HTML;

		showsetting($Fn_Renovation->Config['LangVar']['SetTopTime'], 'topdateline',$Item['topdateline'] ? date('Y-m-d H:i',$Item['topdateline']) : '', 'calendar','','','',1);
		
		if($Item['updateline']){
			showsetting($Fn_Renovation->Config['LangVar']['RefreshTime'], 'updateline',$Item['updateline'] ? date('Y-m-d H:i',$Item['updateline']) : '', 'calendar','','','',1);
		}

		if($Item['dateline']){
			showsetting($Fn_Renovation->Config['LangVar']['TimeTitle'], 'dateline',date('Y-m-d H:i',$Item['dateline']), 'calendar','','','',1);
		}

		showsetting($Fn_Renovation->Config['LangVar']['IsVerify'], 'verify', $Item['verify'], 'radio');

		showsetting($Fn_Renovation->Config['LangVar']['Click'], 'click', $Item['click'], 'text');

		showsetting($Fn_Renovation->Config['LangVar']['DisplayTitle'], 'display', $Item ? $Item['display'] : 1, 'radio');
		echo <<<HTML
		</div>
		<!-- �������� end  -->
HTML;
		
		showsubmit('DetailSubmit','&#20445;&#23384;&#37197;&#32622;');
		showtagfooter('div');
		showtagheader('div', 'tab-content', true,'tab-content');
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');

		$UpLoadHtml  = '';
		if($Item['logo']){
			$LogoJsArray[] = '"'.$Item['logo'].'"';;
			$UpLoadHtml .= '
			var InputArray = new Array('.implode(',',$LogoJsArray).');
			$("#LogoPhotoControl").AppUpload({InputName:"new_logo",Multiple:true,InputExist:true,InputArray:InputArray});';

		}else{
			$UpLoadHtml .= '$("#LogoPhotoControl").AppUpload({InputName:"new_logo",Multiple:true});';
		}

		if($Item['banner']){
			foreach(array_filter(explode(",",$Item['banner'])) as $Key => $Val) {
				$BannerJsArray[] = '"'.$Val.'"';
			}
			$UpLoadHtml .= '
			var InputArray = new Array('.implode(',',$BannerJsArray).');
			$("#BannerPhotoControl").AppUpload({InputName:"new_banner",InputExist:true,InputArray:InputArray});';

		}else{
			$UpLoadHtml .= '$("#BannerPhotoControl").AppUpload({InputName:"new_banner"});';
		}

		if($Item['param']['license']){
			$LicenseJsArray[] = '"'.$Item['param']['license'].'"';;
			$UpLoadHtml .= '
			var InputArray = new Array('.implode(',',$LicenseJsArray).');
			$("#LicensePhotoControl").AppUpload({InputName:"new_license",Multiple:true,InputExist:true,InputArray:InputArray});';

		}else{
			$UpLoadHtml .= '$("#LicensePhotoControl").AppUpload({InputName:"new_license",Multiple:true});';
		}

		echo '<script src="source/plugin/fn_assembly/static/js/mobiscroll.custom-2.16.1.min.js"></script><link rel="stylesheet" href="source/plugin/fn_assembly/static//css/mobiscroll.custom-2.16.1.min.css"><script charset=utf-8 src="https://map.qq.com/api/js?v=2.exp&key='.$Config['PluginVar']['TxMapKey'].'"></script>'.$UploadConfig['CssJsHtml'];
		
		echo '
			<style>.Tmp{opacity:0;}.Tagging span{font-size:18px;}.Tagging{cursor: pointer;}</style>
			<script>
			$(document).on("click","#SmallAreaPosition",function(){
				GetTreeList($(this),"SmallAreaPositionList","province","city","dist");
				return false;
			});
			//��ע
			$(document).on("click",".MapClick",function(){
				if(!$("#MapPage").attr("src")){
					$("#MapPage").attr("src","https://apis.map.qq.com/tools/locpicker?search=1&type=1&key='.$Config['PluginVar']['TxMapKey'].'&referer=myapp&'.($Item['lat'] && $Item['lng'] ? 'coord='.$Item['lat'].','.$Item['lng'] : '').'");
				}
				$(".TipMap").fadeIn();
				return false;
			});
			window.addEventListener("message", function(Event) {
				var Loc = Event.data;
				if (Loc && Loc.module == "locationPicker") {
					var Geocoder = new qq.maps.Geocoder();
					Geocoder.getAddress(new qq.maps.LatLng(Loc.latlng.lat, Loc.latlng.lng));
					Geocoder.setComplete(function(Result) {
						$("input[name=\'lat\']").val(Result.detail.location.lat);
						$("input[name=\'lng\']").val(Result.detail.location.lng);
						$("input[name=\'community\']").val(Result.detail.addressComponents.street + Result.detail.addressComponents.streetNumber);
						$(".Map").html("'.$Fn_Renovation->Config['LangVar']['IsTagging'].'<span class=iconfont>&#xe621;</span>");
						$(".TipMap").fadeOut();
					});
					Geocoder.setError(function() {
						alert("\u51fa\u9519\u4e86\uff0c\u8bf7\u8f93\u5165\u6b63\u786e\u7684\u5730\u5740\uff01\uff01\uff01");
					});
				}
			}, false);
			//��ע End
			var ue = UE.getEditor("content",{autoHeightEnabled: false,autoFloatEnabled:false,enableAutoSave: false});
			'.$UpLoadHtml.'
			</script> 	
		';

	}else{
	
		$Data['uid'] = intval($_GET['new_uid']);
		$Member = DB::fetch_first('SELECT username FROM '.DB::table('common_member').' where uid = '.$Data['uid']);
		$Data['username'] = addslashes(strip_tags($Member['username']));
		$Data['admin_uid'] = addslashes(strip_tags($_GET['admin_uid']));
		
		foreach($_GET['new_logo'] as $Key => $Val) {
			$_GET['new_logo'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}

		foreach($_GET['new_banner'] as $Key => $Val) {
			$_GET['new_banner'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}

		foreach($_GET['new_license'] as $Key => $Val) {
			$_GET['new_license'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}


		$Data['banner'] = is_array($_GET['new_banner']) && isset($_GET['new_banner']) ? implode(',',array_filter($_GET['new_banner'])) : '';
		$Data['logo'] = addslashes(strip_tags($_GET['new_logo'][0]));
		$Data['name'] = addslashes(strip_tags($_GET['name']));
		$Data['province'] = addslashes(strip_tags($_GET['province']));
		$Data['city'] = addslashes(strip_tags($_GET['city']));
		$Data['dist'] = addslashes(strip_tags($_GET['dist']));
		$Data['community'] = addslashes(strip_tags($_GET['community']));
		$Data['lat'] = addslashes(strip_tags($_GET['lat']));
		$Data['lng'] = addslashes(strip_tags($_GET['lng']));
		$Data['mobile'] = addslashes(strip_tags($_GET['mobile']));
		$Data['landline'] = addslashes(strip_tags($_GET['landline']));
		$Data['grade'] = intval($_GET['grade']) > 5 ? 5 : addslashes(strip_tags($_GET['grade']));
		$Data['tag'] = is_array($_GET['tag']) && isset($_GET['tag']) ? implode(',',$_GET['tag']) : '';
		$Data['content'] = addslashes($_GET['content']);//�豣��Html
		$Data['group_id'] = intval($_GET['group_id']);
		$Data['classid'] = intval($_GET['classid']);
		$Data['click'] = intval($_GET['click']);
		$Data['due_time'] = $_GET['due_time'] ? strtotime($_GET['due_time']) : '';
		$Data['topdateline'] = $_GET['topdateline'] ? strtotime($_GET['topdateline']) : '';
		$Data['experience'] = intval($_GET['experience']);
		$Data['verify'] = intval($_GET['verify']);
		$Data['display'] = intval($_GET['display']);
		
		$Param['license'] = addslashes(strip_tags($_GET['new_license'][0]));
		$Data['param'] = serialize($Param);
		
		$GroupItem = DB::fetch_first('SELECT * FROM '.DB::table($Fn_Renovation->TableMaterialCompanyGroup).' where id = '.$Data['group_id']);
		if($GroupItem)$GroupItem['param'] = unserialize($GroupItem['param']);
		if($_GET['vip_type'] == 1 && $GroupItem){
			$GroupLogData['goods_count'] = $GroupItem['param']['goods_count'];
			$GroupLogData['case_count'] =  $GroupItem['param']['case_count'];
			$GroupLogData['banner'] = $GroupItem['param']['banner'];
			$GroupLogData['case_examine'] = $GroupItem['param']['case_examine'];
			$GroupLogData['examine'] = $GroupItem['param']['examine'];
			$GroupLogData['hot'] = $GroupItem['param']['hot'];
			$GroupLogData['sms'] = $GroupItem['param']['sms'];
			$GroupLogData['wx'] = $GroupItem['param']['wx'];
			$Data['due_time'] = $Data['due_time'] > time() ? strtotime("+".intval($GroupItem['group_time'])."  month",$Data['due_time']) : strtotime("+".intval($GroupItem['group_time'])."  month",time());
		}else if($_GET['vip_type'] == 2 && $GroupItem){
			$GroupLogData['goods_count'] = intval($_GET['goods_count']) + $GroupItem['param']['goods_count'];
			$GroupLogData['case_count'] =  intval($_GET['case_count']) + $GroupItem['param']['case_count'];
			$GroupLogData['banner'] = $GroupItem['param']['banner'];
			$GroupLogData['case_examine'] = $GroupItem['param']['case_examine'];
			$GroupLogData['examine'] = $GroupItem['param']['examine'];
			$GroupLogData['hot'] = $GroupItem['param']['hot'];
			$GroupLogData['sms'] = $GroupItem['param']['sms'];
			$GroupLogData['wx'] = $GroupItem['param']['wx'];
			$Data['due_time'] = strtotime("+".intval($GroupItem['group_time'])."  month",time());
		}else{
			$GroupLogData['company_id'] = $Item['id'];
			$GroupLogData['banner'] = intval($_GET['banner']);
			$GroupLogData['goods_count'] = intval($_GET['goods_count']);
			$GroupLogData['case_count'] = intval($_GET['case_count']);
			$GroupLogData['hot'] = intval($_GET['hot']);
			$GroupLogData['case_examine'] = intval($_GET['case_examine']);
			$GroupLogData['examine'] = intval($_GET['examine']);
			$GroupLogData['sms'] = intval($_GET['sms']);
			$GroupLogData['wx'] = intval($_GET['wx']);
		}
	
		if($Item){

			$Data['updateline'] = strtotime($_GET['updateline']);

			GetInsertDoLog('edit_material_company_list_renovation','fn_'.$_GET['mod'],array('id'=>$Cid));//������¼
			DB::update($Fn_Renovation->TableMaterialCompany,$Data,'id = '.$Cid);
			$GroupLogData['company_id'] = $Cid;

		}else{
			$Data['dateline'] = $Data['updateline'] = time();
			$GroupLogData['company_id'] = $Id = DB::insert($Fn_Renovation->TableMaterialCompany,$Data,true);

			GetInsertDoLog('add_material_company_list_renovation','fn_'.$_GET['mod'],array('id'=>$Id));//������¼
		}

		if($CompanyGroupLogItem){
			DB::update($Fn_Renovation->TableMaterialCompanyGroupLog,$GroupLogData,'company_id = '.$CompanyGroupLogItem['company_id']);
		}else{
				
			DB::insert($Fn_Renovation->TableMaterialCompanyGroupLog,$GroupLogData);
		}

		fn_cpmsg($Fn_Renovation->Config['LangVar']['UpdateOk'],$Fn_Admin->Config['IframeItemUrl'].'&submodel=list','succeed');
		
	}
}


/* �б� */
function GetModulesList($Page,$Limit,$Where=null,$Order){
	global $Fn_Renovation;
	$FetchSql = 'SELECT C.*,AG.title as group_title,MC.name as class_name FROM '.DB::table($Fn_Renovation->TableMaterialCompany).' C LEFT JOIN `'.DB::table($Fn_Renovation->TableMaterialCompanyGroup).'` AG on AG.id = C.group_id LEFT JOIN `'.DB::table($Fn_Renovation->TableMaterialClass).'` MC on MC.id = C.classid '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}

/* ���� */
function GetModulesCount($Where=null){
	global $Fn_Renovation;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_Renovation->TableMaterialCompany).' C '.$Where;
	return DB::result_first($FetchSql);//��������
}

?>