<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('renovation_all') && !$Fn_Admin->CheckUserGroup('renovation_company_group_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$SubModel = in_array($_GET['submodel'], array('list','add')) ? $_GET['submodel'] : 'list';
$Fn_Admin->Config['IframeSubModelUrl'] = $Fn_Admin->Config['IframeItemUrl'].'&submodel='.$SubModel;
$NavClass = array($SubModel=>'btn-info Hover');

//����
echo <<<Nav
<div class="SubModelNav">
  <ul>
	<li class="{$NavClass['list']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=list" target="_self">{$Fn_Admin->Config['LangVar']['RenovationLeftNavArray'][$_GET['item']]}</a></li>
    <li class="{$NavClass['add']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=add" target="_self">{$Fn_Admin->Config['LangVar']['AddEditTitle']}</a></li>
  </ul>
  <div class="both"></div>
</div>
Nav;

if($SubModel == 'list'){//�б�
	$Do = in_array($_GET['do'], array('Del')) ? $_GET['do'] : 'submodel_list';
	//�����ֶ�
	$SearField =array('page','keyword');
	foreach($SearField as $Val) {
		$SearArray[$Val] = $_GET[$Val] || in_array($_GET[$Val],array('0')) ? $_GET[$Val] : '';
	}
	//�����ֶ� End
	$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeSubModelUrl'].'&'.http_build_query($SearArray);


	if($Do == 'submodel_list'){
		if(!submitcheck('Submit')) {
			$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
			$Where = '';
			$Order = in_array($_GET['order'], array('id','displayorder')) ? 'AG.'.addslashes(dhtmlspecialchars($_GET['order'])) : 'AG.displayorder';
	
			$Where = preg_replace('/and/','where',$Where,1);
			$Limit = 20;
			$Page = $_GET['page']?intval($_GET['page']):1;
			/* ��ѯ���� End */

			/* ģ����� */	
			
			showtagheader('div', 'row', true,'row');
			showtagheader('div', 'col-12', true,'col-12');
			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-body', true,'box-body');
			showtagheader('div', 'table-responsive', true,'table-responsive');
			showformheader($FormUrl,'enctype="multipart/form-data"');
			showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
			showsubtitle(array(
				'ID',
				$Fn_Renovation->Config['LangVar']['Title'],
				$Fn_Renovation->Config['LangVar']['IcoTitle'],
				$Fn_Renovation->Config['LangVar']['MoneyTitle'],
				$Fn_Renovation->Config['LangVar']['CompanyGroupExperience'],
				$Fn_Renovation->Config['LangVar']['CompanyGroupTime'],
				$Fn_Renovation->Config['LangVar']['CompanyGroupCaseCount'],
				$Fn_Renovation->Config['LangVar']['CompanyGroupRefreshType'],
				$Fn_Renovation->Config['LangVar']['CompanyGroupBuildCount'],
				$Fn_Renovation->Config['LangVar']['CompanyGroupTeamCount'],
				//$Fn_Renovation->Config['LangVar']['CompanyGroupTopDiscount'],
				$Fn_Renovation->Config['LangVar']['CompanyGroupHot'],
				$Fn_Renovation->Config['LangVar']['CompanyGroupExamine'],
				$Fn_Renovation->Config['LangVar']['CompanyGroupBanner'],
				$Fn_Renovation->Config['LangVar']['SmsNotification'],
				$Fn_Renovation->Config['LangVar']['DisplayOrder'],
				$Fn_Renovation->Config['LangVar']['OperationTitle']
			),'header tbm tc');

			$ModulesList = GetModulesList($Page,$Limit,$Where,$Order);
			foreach ($ModulesList as $Module) {
				$Module['param'] = unserialize($Module['param']);
				showtablerow('', array('class="tc w50"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
					$Module['id'],
					$Module['title'],
					$Module['ico'] ? '<img src="'.$Module['ico'].'" style="height:30px;">' : '',
					$Module['money'],
					$Module['experience'] ? $Fn_Renovation->Config['LangVar']['Yes'] : $Fn_Renovation->Config['LangVar']['No'],
					$Module['group_time'] ? $Module['group_time'].$Fn_Renovation->Config['LangVar']['Ge'].$Fn_Renovation->Config['LangVar']['Month'] : '',
					$Module['param']['case_count'],
					$Module['param']['refresh_type'] == 1 ? $Fn_Renovation->Config['LangVar']['CompanyGroupDayRefreshCount'].'-'.$Module['param']['day_refresh_count'] : $Fn_Renovation->Config['LangVar']['CompanyGroupRefreshCount'].' ['.$Module['param']['refresh_count'].']',
					$Module['param']['build_count'],
					$Module['param']['team_count'],
					//$Module['param']['top_discount'],
					$Module['param']['hot'] ? $Fn_Renovation->Config['LangVar']['Yes'] : $Fn_Renovation->Config['LangVar']['No'],
					$Module['param']['examine'] ? $Fn_Renovation->Config['LangVar']['Yes'] : $Fn_Renovation->Config['LangVar']['No'],
					$Module['param']['banner'] ? $Fn_Renovation->Config['LangVar']['Yes'] : $Fn_Renovation->Config['LangVar']['No'],
					$Module['param']['sms'] ? $Fn_Renovation->Config['LangVar']['Yes'] : $Fn_Renovation->Config['LangVar']['No'],
					$Module['displayorder'],
					'<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&agid='.$Module['id'].'" class="btn btn-sm btn-info-outline">'.$Fn_Renovation->Config['LangVar']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Del&agid='.$Module['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$Fn_Renovation->Config['LangVar']['DelTitle'].'</a>'
				));
			}

			showtablefooter(); /*dism��taobao��com*/
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			/* ģ�����End */	
		}
	}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['agid']){
		$AGid = intval($_GET['agid']);
		DB::delete($Fn_Renovation->TableCompanyGroup,'id ='.$AGid);

		GetInsertDoLog('del_company_group_renovation','fn_'.$_GET['mod'],array('id'=>$AGid));//������¼

		fn_cpmsg($Fn_Admin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
	}
}else if($SubModel == 'add'){//���ӻ�༭

	$AGid = intval($_GET['agid']);
	$Item = DB::fetch_first('SELECT * FROM '.DB::table($Fn_Renovation->TableCompanyGroup).' where id = '.$AGid);
	if($Item)$Item['param'] = unserialize($Item['param']);
	if(!submitcheck('DetailSubmit')) {
		$OpTitle = $Fn_Renovation->Config['LangVar']['AddTitle'];
		if($Item)$OpTitle = $Fn_Renovation->Config['LangVar']['EditTitle'];
		
		//ͼƬ�ϴ�
		if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_assembly/class/class_upload.php')){
			@require_once libfile('class/upload','plugin/fn_assembly');
			$UploadConfig = fn_upload::Config();
		}

		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-header', true,'with-border box-header');
		showtitle($OpTitle,'class="box-title"');
		showtagfooter('div');
		showformheader($Fn_Admin->Config['IframeSubModelUrl'].'&agid='.$AGid,'enctype');
		showtagheader('div', 'box-body', true,'box-body');
		
		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_Renovation->Config['LangVar']['IcoTitle'].'<br>'.$Fn_Renovation->Config['LangVar']['CompanyGroupIcoTips'].'</label><div class="col-sm-9"><div class="AdminSingleUpload"><div class="PhotoControl" id="IcoPhotoControl"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';


		showsetting($Fn_Renovation->Config['LangVar']['Title'], 'title', $Item['title'], 'text');
	
		showsetting($Fn_Renovation->Config['LangVar']['MoneyTitle'], 'money', $Item['money'], 'text','','',$Fn_Renovation->Config['LangVar']['CompanyGroupNumberTips']);

		showsetting($Fn_Renovation->Config['LangVar']['CompanyGroupExperience'], 'experience', $Item['experience'], 'radio','','',$Fn_Renovation->Config['LangVar']['CompanyGroupExperienceTips']);

		showsetting($Fn_Renovation->Config['LangVar']['CompanyGroupTime'], 'group_time', $Item['group_time'], 'text','','',$Fn_Renovation->Config['LangVar']['CompanyGroupTimeTips']);

		showsetting($Fn_Renovation->Config['LangVar']['CompanyGroupCaseCount'], 'case_count', $Item['param']['case_count'], 'text','','',$Fn_Renovation->Config['LangVar']['CompanyGroupCaseCountTips']);

		showsetting($Fn_Renovation->Config['LangVar']['CompanyGroupRefreshType'],array('refresh_type', array(
			array('1',$Fn_Renovation->Config['LangVar']['CompanyGroupDayRefreshCount'], array('refresh_type_table' => '', 'refresh_type_table_no' => 'none')),
			array('2',$Fn_Renovation->Config['LangVar']['CompanyGroupRefreshCount'], array('refresh_type_table' => 'none', 'refresh_type_table_no' => '')),
		), TRUE),$Item['param']['refresh_type'], 'mradio');

		$RefreshTypeTableDisplay = $Item['param']['refresh_type'] == 1 || !$Item ? true : false;
		$RefreshTypeTableNoDisplay = $Item['param']['refresh_type'] != 1 && $Item ? true : false;

		showtagheader('div', 'refresh_type_table', $RefreshTypeTableDisplay, 'sub');
			showsetting($Fn_Renovation->Config['LangVar']['CompanyGroupDayRefreshCount'], 'day_refresh_count', $Item['param']['day_refresh_count'], 'text','','',$Fn_Renovation->Config['LangVar']['CompanyGroupDayRefreshCountTips']);
		showtagfooter('div');

		showtagheader('div', 'refresh_type_table_no', $RefreshTypeTableNoDisplay, 'sub');
			showsetting($Fn_Renovation->Config['LangVar']['CompanyGroupRefreshCount'], 'refresh_count', $Item['param']['refresh_count'], 'text','','',$Fn_Renovation->Config['LangVar']['CompanyGroupRefreshCountTips']);
		showtagfooter('div');

		showsetting($Fn_Renovation->Config['LangVar']['CompanyGroupBuildCount'], 'build_count', $Item['param']['build_count'], 'text','','',$Fn_Renovation->Config['LangVar']['CompanyGroupBuildCountTips']);
		showsetting($Fn_Renovation->Config['LangVar']['CompanyGroupTeamCount'], 'team_count', $Item['param']['team_count'], 'text','','',$Fn_Renovation->Config['LangVar']['CompanyGroupTeamCountTips']);
		//showsetting($Fn_Renovation->Config['LangVar']['CompanyGroupTopDiscount'], 'top_discount', $Item['param']['top_discount'], 'text','','',$Fn_Renovation->Config['LangVar']['CompanyGroupTopDiscountTips']);
		showsetting($Fn_Renovation->Config['LangVar']['CompanyGroupBanner'], 'banner', $Item['param']['banner'], 'radio');
		showsetting($Fn_Renovation->Config['LangVar']['CompanyGroupHot'], 'hot', $Item['param']['hot'], 'radio');
		showsetting($Fn_Renovation->Config['LangVar']['CompanyGroupExamine'], 'examine', $Item['param']['examine'], 'radio');
		showsetting($Fn_Renovation->Config['LangVar']['SmsNotification'], 'sms', $Item['param']['sms'], 'radio');

		showsetting($Fn_Renovation->Config['LangVar']['ServiceContent'], 'content', $Item['param']['content'], 'textarea','','',$Fn_Renovation->Config['LangVar']['ServiceContentTips']);
		
		showsetting($Fn_Renovation->Config['LangVar']['DisplayOrder'], 'displayorder', $Item['displayorder'], 'text');
		
		showsubmit('DetailSubmit','&#20445;&#23384;&#37197;&#32622;');
		showtagfooter('div');
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');

		$UpLoadHtml  = '';
		if($Item['ico']){
			$IcoJsArray[] = '"'.$Item['ico'].'"';;
			$UpLoadHtml .= '
			var InputArray = new Array('.implode(',',$IcoJsArray).');
			jQuery("#IcoPhotoControl").AppUpload({InputName:"new_ico",Multiple:true,InputExist:true,InputArray:InputArray});';

		}else{
			$UpLoadHtml .= 'jQuery("#IcoPhotoControl").AppUpload({InputName:"new_ico",Multiple:true});';
		}

		echo $UploadConfig['CssJsHtml'].'<script>'.$UpLoadHtml.'</script>';

	}else{
		foreach($_GET['new_ico'] as $Key => $Val) {
			$_GET['new_ico'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}
		$Data['ico'] = $_GET['new_ico'][0] ? addslashes(strip_tags($_GET['new_ico'][0])) : '';
		$Data['title'] = addslashes(strip_tags($_GET['title']));
		$Data['money'] = addslashes(strip_tags($_GET['money']));
		$Data['group_time'] = addslashes(strip_tags($_GET['group_time']));
		$Data['displayorder'] = intval($_GET['displayorder']);
		$Data['experience'] = intval($_GET['experience']);
		
		$Param['banner'] = intval($_GET['banner']);
		$Param['build_count'] = intval($_GET['build_count']);
		$Param['case_count'] = intval($_GET['case_count']);
		$Param['team_count'] = intval($_GET['team_count']);
		$Param['refresh_type'] = intval($_GET['refresh_type']);
		$Param['refresh_count'] = intval($_GET['refresh_count']);
		$Param['day_refresh_count'] = intval($_GET['day_refresh_count']);
		$Param['top_discount'] = addslashes(strip_tags($_GET['top_discount']));
		$Param['hot'] = intval($_GET['hot']);
		$Param['examine'] = intval($_GET['examine']);
		$Param['sms'] = intval($_GET['sms']);
		$Param['wx'] = intval($_GET['wx']);
		$Param['content'] = addslashes(strip_tags($_GET['content']));

		$Data['param'] = serialize($Param);
	
		if($Item){
			GetInsertDoLog('edit_company_group_renovation','fn_'.$_GET['mod'],array('id'=>$AGid));//������¼
			DB::update($Fn_Renovation->TableCompanyGroup,$Data,'id = '.$AGid);
		}else{
			$Id = DB::insert($Fn_Renovation->TableCompanyGroup,$Data,true);
			GetInsertDoLog('add_company_group_renovation','fn_'.$_GET['mod'],array('id'=>$Id));//������¼
		}
		fn_cpmsg($Fn_Renovation->Config['LangVar']['UpdateOk'],$Fn_Admin->Config['IframeItemUrl'].'&submodel=list','succeed');
	}
}


/* �б� */
function GetModulesList($Page,$Limit,$Where=null,$Order){
	global $Fn_Renovation;
	$FetchSql = 'SELECT AG.* FROM '.DB::table($Fn_Renovation->TableCompanyGroup).' AG '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}

/* ���� */
function GetModulesCount($Where=null){
	global $Fn_Renovation;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_Renovation->TableCompanyGroup).' AG '.$Where;
	return DB::result_first($FetchSql);//��������
}

?>