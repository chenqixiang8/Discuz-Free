<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('renovation_all') && !$Fn_Admin->CheckUserGroup('renovation_case_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$SubModel = in_array($_GET['submodel'], array('list','add')) ? $_GET['submodel'] : 'list';
$Fn_Admin->Config['IframeSubModelUrl'] = $Fn_Admin->Config['IframeItemUrl'].'&submodel='.$SubModel;
$NavClass = array($SubModel=>'btn-info Hover');

//����
echo <<<Nav
<div class="SubModelNav">
  <ul>
	<li class="{$NavClass['list']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=list" target="_self">{$Fn_Admin->Config['LangVar']['RenovationLeftNavArray'][$_GET['item']]}</a></li>
    <li class="{$NavClass['add']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=add" target="_self">{$Fn_Admin->Config['LangVar']['AddEditTitle']}</a></li>
  </ul>
  <div class="both"></div>
</div>
Nav;

if($SubModel == 'list'){//�б�
	$Do = in_array($_GET['do'], array('Refresh','Del','Display')) ? $_GET['do'] : 'submodel_list';
	//�����ֶ�
	$SearField =array('page','keyword','display','class','company_id','community_id','order');
	foreach($SearField as $Val) {
		$SearArray[$Val] = $_GET[$Val] || in_array($_GET[$Val],array('0')) ? $_GET[$Val] : '';
	}
	//�����ֶ� End
	$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeSubModelUrl'].'&'.http_build_query($SearArray);


	if($Do == 'submodel_list'){
		if(!submitcheck('Submit')) {
			$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
			$Where = '';
			$Order = $_GET['order'] ? 'C.'.addslashes(dhtmlspecialchars($_GET['order'])) : 'C.id';
			
			if($_GET['keyword']){
				$_GET['keyword'] = str_replace(array('%','_'),array('',''),$_GET['keyword']);
				
				//��ѯ��˾
				$CompanyIds = array();
				foreach (DB::fetch_all('SELECT uid FROM '.DB::table($Fn_Renovation->TableCompany).' where name like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') order by id desc') as $Key => $Val) {
					$CompanyIds[] = $Val['uid'];
				}

				$Where .= ' and (C.title like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or C.username like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') '.($CompanyIds ? ' or C.company_id in ('.implode(',',array_filter($CompanyIds)).')' : '' ).' )';
			}

			if($_GET['company_id']){
				$Where .= ' and C.company_id = '.intval($_GET['company_id']);
			}
			
			if($_GET['community_id']){
				$Where .= ' and C.community_id = '.intval($_GET['community_id']);
			}

			if(in_array($_GET['display'],array('0','1'))){
				$Where .= ' and C.display = '.intval($_GET['display']);
			}

			if(in_array($_GET['class'],array('1','2','3'))){
				$Where .= ' and C.class = '.intval($_GET['class']);
			}

			$Where = preg_replace('/and/','where',$Where,1);
			$Limit = 20;
			$Page = $_GET['page']?intval($_GET['page']):1;
			/* ��ѯ���� End */
			

			/* ģ����� */
			showtagheader('div', 'row', true,'row');
			showtagheader('div', 'col-12', true,'col-12');
			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-body', true,'box-body');
			/* ���� */
			$ClassSelected = array($_GET['class']=>' selected');
			$OverdueSelected = array($_GET['overdue']=>' selected');
			$DisplaySelected = array($_GET['display']=>' selected');
			$OrderSelected = array($_GET['order']=>' selected');

			echo <<<SEARCH
			<form method="post" autocomplete="off" action="$SearUrl">
				<div class="FormSearchTo" style="margin-bottom:0;">
					<table cellspacing="4" cellpadding="4">
						<tr>
							<th>{$Fn_Renovation->Config['LangVar']['KeywordTitle']}</th><td><input type="text" class="input form-control w300" name="keyword" value="{$_GET['keyword']}" placeholder="{$Fn_Renovation->Config['LangVar']['AdminCasePlaceholder']}">
							</td>
							<th>{$Fn_Renovation->Config['LangVar']['CompanyID']}</th><td><input type="text" class="input form-control w120" name="company_id" value="{$_GET['company_id']}" placeholder="{$Fn_Renovation->Config['LangVar']['CompanyIDPlaceholder']}">
							</td>
							<th>{$Fn_Renovation->Config['LangVar']['CommunityID']}</th><td><input type="text" class="input form-control w120" name="community_id" value="{$_GET['community_id']}" placeholder="{$Fn_Renovation->Config['LangVar']['CompanyIDPlaceholder']}">
							</td>
							<th>{$Fn_Renovation->Config['LangVar']['Type']}</th><td>
							<select name="class" class="form-control w120">
								<option value="">{$Fn_Renovation->Config['LangVar']['SelectNull']}</option>
								<option value="1"{$ClassSelected['1']}>{$Fn_Renovation->Config['LangVar']['ClassArray']['1']}</option>
								<option value="2"{$ClassSelected['2']}>{$Fn_Renovation->Config['LangVar']['ClassArray']['2']}</option>
							</select>
							</td>
							<th>{$Fn_Renovation->Config['LangVar']['DisplayTitle']}</th><td>
							<select name="display" class="form-control w120">
								<option value="">{$Fn_Renovation->Config['LangVar']['SelectNull']}</option>
								<option value="1"{$DisplaySelected['1']}>{$Fn_Renovation->Config['LangVar']['Yes']}</option>
								<option value="0"{$DisplaySelected['0']}>{$Fn_Renovation->Config['LangVar']['No']}</option>
							</select>
							</td>
							<th>{$Fn_Admin->Config['LangVar']['Order']}</th><td>
							<select name="order" class="form-control w120">
								<option value="dateline"{$OrderSelected['dateline']}>{$Fn_Admin->Config['LangVar']['OrderArray']['dateline']}</option>
								<option value="updateline"{$OrderSelected['updateline']}>{$Fn_Admin->Config['LangVar']['OrderArray']['updateline']}</option>
								<option value="click"{$OrderSelected['click']}>{$Fn_Admin->Config['LangVar']['OrderArray']['click']}</option>
								<option value="topdateline"{$OrderSelected['topdateline']}>{$Fn_Admin->Config['LangVar']['OrderArray']['topdateline']}</option>
							</select>
							&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Admin->Config['LangVar']['SearchSubmit']}" class="btn btn-info" type="submit">
							</td>
						</tr>
					</table>
				</div>
			</form>
SEARCH;
			/* ���� End */
			showtagheader('div', 'table-responsive', true,'table-responsive');
			showformheader($FormUrl,'enctype="multipart/form-data"');
			showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
			showsubtitle(array(
				'ID',
				'UID/'.$Fn_Renovation->Config['LangVar']['UserNameTitle'],
				$Fn_Renovation->Config['LangVar']['Title'],
				$Fn_Renovation->Config['LangVar']['Type'],
				$Fn_Renovation->Config['LangVar']['CommunityName'],
				$Fn_Renovation->Config['LangVar']['CompanyName'],
				$Fn_Renovation->Config['LangVar']['Telephone'],
				$Fn_Renovation->Config['LangVar']['DisplayTitle'],
				$Fn_Renovation->Config['LangVar']['RefreshTime'],
				$Fn_Renovation->Config['LangVar']['SetTopTime'],
				$Fn_Renovation->Config['LangVar']['TimeTitle'],
				$Fn_Renovation->Config['LangVar']['OperationTitle']
			),'header tbm tc');

			$ModulesList = $Fn_Renovation->CaseListFormat(GetModulesList($Page,$Limit,$Where,$Order));
			
			foreach ($ModulesList as $Module) {
				

				showtablerow('', array('class="tc w80"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
					'<input type="checkbox" class="filled-in" id="checkbox_'.$Module['id'].'" name="delete[]" value="'.$Module['id'].'"><label for="checkbox_'.$Module['id'].'">'.$Module['id'].'</label>',
					$Module['uid'] ? $Module['uid'].'/'.$Module['username'] : '',
					$Module['title'],
					$Module['class_text'],
					$Module['community_name'],
					$Module['company_name'],
					$Module['landline'],
					!$Module['display'] ? '<span class="label bg-secondary">'.$Fn_Renovation->Config['LangVar']['No'].'</span>' : '<span class="label bg-blue">'.$Fn_Renovation->Config['LangVar']['Yes'].'</span>',
					$Module['updateline'],
					$Module['topdateline'] && $Module['topdateline'] > time() ? date('Y-m-d H:i',$Module['topdateline']) : '',
					date('Y-m-d H:i',$Module['dateline']),
					'<a href="'.$Module['url'].'" target="_blank" class="btn btn-sm btn-dark-outline">'.cplang('view').'</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&cid='.$Module['id'].'" class="btn btn-sm btn-info-outline">'.$Fn_Renovation->Config['LangVar']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Refresh&cid='.$Module['id'].'&formhash='.FORMHASH.'" class="btn btn-sm btn-primary-outline">'.$Fn_Renovation->Config['LangVar']['Refresh'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Display&cid='.$Module['id'].'&value='.(!empty($Module['display']) ? 0:1).'&formhash='.FORMHASH.'" class="btn btn-sm btn-purple-outline">'.(!empty($Module['display']) ? $Fn_Renovation->Config['LangVar']['DisplayNoTitle'] : $Fn_Renovation->Config['LangVar']['DisplayIsTitle']).'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Del&cid='.$Module['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$Fn_Renovation->Config['LangVar']['DelTitle'].'</a>',
				));
			}

			showsubmit('Submit','&#31435;&#21363;&#25552;&#20132;','<input name="optype" value="Del" class="with-gap" type="radio" id="v_del"><label class="custom-control-label" for="v_del" style="margin-left:-5px;">'.$Fn_Renovation->Config['LangVar']['DelTitle'].'</label>&nbsp;&nbsp;<input name="optype" value="Refresh" class="with-gap" type="radio" id="v_refresh"><label class="custom-control-label" for="v_refresh">'.$Fn_Renovation->Config['LangVar']['Refresh'].'</label>&nbsp;&nbsp;<input name="optype" value="Display" class="with-gap" type="radio" id="v_display"><label class="custom-control-label" for="v_display">'.$Fn_Renovation->Config['LangVar']['DisplayTitle'].'</label>&nbsp;<select name="new_display" class="form-control w120"><option value="">'.$Fn_Renovation->Config['LangVar']['SelectNull'].'</option><option value="1">'.$Fn_Renovation->Config['LangVar']['Yes'].'</option><option value="0">'.$Fn_Renovation->Config['LangVar']['No'].'</option></select>','','select_all',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));
			showtablefooter(); /*dism��taobao��com*/
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');
			/* ģ�����End */	
		}else{
			if(isset($_GET['delete']) && is_array($_GET['delete'])){
				if($_GET['optype'] == 'Del'){//ȫɾ
					if(!$Fn_Admin->CheckUserGroup('renovation_all') && !$Fn_Admin->CheckUserGroup('renovation_case_del')){//Ȩ���ж�
						fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
						exit();
					}
					foreach($_GET['delete'] as $Key => $Val) {
						$Val = intval($Val);
						DB::delete($Fn_Renovation->TableCase,'id ='.$Val);
						DB::delete($Fn_Renovation->TableCaseRefreshLog,'case_id ='.$Val);

					}
					GetInsertDoLog('del_case_list_renovation','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete'])));//������¼
					fn_cpmsg($Fn_Renovation->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');

				}else if($_GET['optype'] == 'Refresh'){
					foreach($_GET['delete'] as $Key => $Val) {
						$Val = intval($Val);
						$UpData['updateline'] = time();
						DB::update($Fn_Renovation->TableCase,$UpData,'id = '.$Val);
					}
					GetInsertDoLog('refresh_case_list_renovation','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete'])));//������¼
					fn_cpmsg($Fn_Renovation->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

				}else if($_GET['optype'] == 'Display' && in_array($_GET['new_display'],array('0','1'))){
					foreach($_GET['delete'] as $Key => $Val) {
						$Val = intval($Val);
						$UpData['display'] = intval($_GET['new_display']);
						DB::update($Fn_Renovation->TableCase,$UpData,'id = '.$Val);
					}
					GetInsertDoLog('display_case_lis_renovation','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete']),'display'=>$_GET['new_display']));//������¼
					fn_cpmsg($Fn_Renovation->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

				}else{
					fn_cpmsg($Fn_Renovation->Config['LangVar']['OpErr'],'','error');
				}	
			}else{
				fn_cpmsg($Fn_Renovation->Config['LangVar']['OpErr'],'','error');
			}	
		}
	}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['cid']){
		if(!$Fn_Admin->CheckUserGroup('renovation_all') && !$Fn_Admin->CheckUserGroup('renovation_case_del')){//Ȩ���ж�
			fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
			exit();
		}
		$id = intval($_GET['cid']);
		DB::delete($Fn_Renovation->TableCase,'id ='.$id);
		DB::delete($Fn_Renovation->TableCaseRefreshLog,'case_id ='.$id);
		GetInsertDoLog('del_case_list_renovation','fn_'.$_GET['mod'],array('id'=>$id));//������¼
		fn_cpmsg($Fn_Admin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');

	}else if($Do == 'Refresh' && $_GET['formhash'] == formhash() && $_GET['cid']){
		$id = intval($_GET['cid']);
		$UpData['updateline'] = time();
		DB::update($Fn_Renovation->TableCase,$UpData,'id = '.$id);
		GetInsertDoLog('refresh_case_list_renovation','fn_'.$_GET['mod'],array('id'=>$id));//������¼
		fn_cpmsg($Fn_Renovation->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

	}else if($Do == 'Display' && $_GET['formhash'] == formhash() && $_GET['cid']){
		$id = intval($_GET['cid']);
		$UpData['display'] = intval($_GET['value']);
		DB::update($Fn_Renovation->TableCase,$UpData,'id = '.$id);
		GetInsertDoLog('display_case_lis_renovation','fn_'.$_GET['mod'],array('id'=>$id,'display'=>$_GET['value']));//������¼
		fn_cpmsg($Fn_Renovation->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

	}
}else if($SubModel == 'add'){//���ӻ�༭
	if(!$Fn_Admin->CheckUserGroup('renovation_all') && !$Fn_Admin->CheckUserGroup('renovation_add_case_list')){//Ȩ���ж�
		fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
		exit();
	}
	$id = intval($_GET['cid']);
	
	$Item = DB::fetch_first('SELECT * FROM '.DB::table($Fn_Renovation->TableCase).' where id = '.$id);

	if(!submitcheck('DetailSubmit')) {
		$OpTitle = $Fn_Renovation->Config['LangVar']['AddTitle'];
		if($Item){
			$OpTitle = $Fn_Renovation->Config['LangVar']['EditTitle'];
			$Item['param'] = unserialize($Item['param']);
		}

		//ͼƬ�ϴ�
		if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_assembly/class/class_upload.php')){
			@require_once libfile('class/upload','plugin/fn_assembly');
			$UploadConfig = fn_upload::Config();
		}


		echo '<script src="'.$Config['StaticPath'].'/ueditor/'.CHARSET.'/ueditor.config.js" type="text/javascript"></script><script src="'.$Config['StaticPath'].'/ueditor/'.CHARSET.'/ueditor.all.js" type="text/javascript"></script>';
		
		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-header', true,'with-border box-header');
		showtitle($OpTitle,'class="box-title"');
		showtagfooter('div');
		showformheader($Fn_Admin->Config['IframeSubModelUrl'].'&cid='.$id,'enctype');
		showtagheader('div', 'box-body', true,'box-body');

		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_Renovation->Config['LangVar']['Thumbnail'].'</label><div class="col-sm-9"><div class="AdminSingleUpload"><div class="PhotoControl" id="LogoPhotoControl"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';

	
		showsetting('uid', 'new_uid', $Item['uid'], 'text');
		showsetting($Fn_Renovation->Config['LangVar']['CompanyID'], 'company_id', $Item['company_id'], 'text');
		showsetting($Fn_Renovation->Config['LangVar']['DesignId'], 'design_id', $Item['design_id'], 'text');
		showsetting($Fn_Renovation->Config['LangVar']['CommunityID'], 'community_id', $Item['community_id'], 'text');
		showsetting($Fn_Renovation->Config['LangVar']['Title'], 'title', $Item['title'], 'text');
		showsetting($Fn_Renovation->Config['LangVar']['Type'],array('class', array(
			array('1',$Fn_Renovation->Config['LangVar']['ClassArray']['1'], array('class_table_1' => '', 'class_table_2' => 'none')),
			array('2',$Fn_Renovation->Config['LangVar']['ClassArray']['2'], array('class_table_1' => 'none', 'class_table_2' => '')),
			//array('3',$Fn_Renovation->Config['LangVar']['ClassArray']['3'], array('class_table_1' => 'none', 'class_table_2' => 'none', 'class_table_3' => '')),
		), TRUE),$Item['class'] ? $Item['class'] : 1, 'mradio');
		
		
		$ClassTable1Display = $Item['class'] == 1 || !$Item ? true : false;
		$ClassTable2Display = $Item['class'] == 2 ? true : false;
		//$ClassTable3Display = $Item['class'] == 3 ? true : false;

		showtagheader('div', 'class_table_1', $ClassTable1Display, 'sub');

			showsetting($Fn_Renovation->Config['LangVar']['Style'], array('style',DyadicArray($Fn_Renovation->Config['LangVar']['style'])), $Item['style'] , 'select');
			showsetting($Fn_Renovation->Config['LangVar']['Apartment'], array('apartment',DyadicArray($Fn_Renovation->Config['LangVar']['apartment'])), $Item['apartment'] , 'select');
			showsetting($Fn_Renovation->Config['LangVar']['MoneyTitle'], array('money',DyadicArray($Fn_Renovation->Config['LangVar']['case_money'])), $Item['money'] , 'select');
			showsetting($Fn_Renovation->Config['LangVar']['CaseType'], array('type',DyadicArray($Fn_Renovation->Config['LangVar']['case_type'])), $Item['type'] ? $Item['type'] : 1, 'mradio');
			showsetting($Fn_Renovation->Config['LangVar']['Square'], 'square', $Item['square'], 'text');
			
			echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_Renovation->Config['LangVar']['CasePictures'].'</label><div class="col-sm-9"><div class="AdminSingleUpload"><div class="PhotoControl" id="ContentImgs"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';
			//��������
			echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_Renovation->Config['LangVar']['Describe'].':</label><div class="col-sm-9"><textarea id="content" name="content" style="width:80%;height:450px;">'.stripslashes($Item['content']).'</textarea></div></div>';
		showtagfooter('div');
		
		showtagheader('div', 'class_table_2', $ClassTable2Display, 'sub');
			showsetting($Fn_Renovation->Config['LangVar']['Style'], array('panorama_style',DyadicArray($Fn_Renovation->Config['LangVar']['style'])), $Item['style'] , 'select');
			showsetting($Fn_Renovation->Config['LangVar']['Apartment'], array('panorama_apartment',DyadicArray($Fn_Renovation->Config['LangVar']['apartment'])), $Item['apartment'] , 'select');
			showsetting($Fn_Renovation->Config['LangVar']['MoneyTitle'], array('panorama_money',DyadicArray($Fn_Renovation->Config['LangVar']['case_money'])), $Item['money'] , 'select');
			showsetting($Fn_Renovation->Config['LangVar']['CaseUrl'], 'url', $Item['url'], 'text');
		showtagfooter('div');
		
		showsetting($Fn_Renovation->Config['LangVar']['SetTopTime'], 'topdateline',$Item['topdateline'] ? date('Y-m-d H:i',$Item['topdateline']) : '', 'calendar','','','',1);
		
		if($Item['updateline']){
			showsetting($Fn_Renovation->Config['LangVar']['RefreshTime'], 'updateline',$Item['updateline'] ? date('Y-m-d H:i',$Item['updateline']) : '', 'calendar','','','',1);
		}

		if($Item['dateline']){
			showsetting($Fn_Renovation->Config['LangVar']['TimeTitle'], 'dateline',date('Y-m-d H:i',$Item['dateline']), 'calendar','','','',1);
		}

		showsetting($Fn_Renovation->Config['LangVar']['Click'], 'click', $Item['click'], 'text');

		showsetting($Fn_Renovation->Config['LangVar']['DisplayTitle'], 'display', $Item ? $Item['display'] : 1, 'radio');
		
		showsubmit('DetailSubmit','&#20445;&#23384;&#37197;&#32622;');
		showtagfooter('div');
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');
		
		$UpLoadHtml  = '';
		if($Item['thumbnail']){
			$ThumbnailJsArray[] = '"'.$Item['thumbnail'].'"';;
			$UpLoadHtml .= '
			var InputArray = new Array('.implode(',',$ThumbnailJsArray).');
			$("#LogoPhotoControl").AppUpload({InputName:"new_thumbnail",Multiple:true,InputExist:true,InputArray:InputArray});';

		}else{
			$UpLoadHtml .= '$("#LogoPhotoControl").AppUpload({InputName:"new_thumbnail",Multiple:true});';
		}

		if($Item['param']['content_imgs']){
			foreach($Item['param']['content_imgs'] as $Key => $Val) {
				$ContentImgsJsArray[] = '"'.$Val.'"';
			}
			$UpLoadHtml .= '
			var InputArray = new Array('.implode(',',$ContentImgsJsArray).');
			$("#ContentImgs").AppUpload({InputName:"new_content_imgs",InputExist:true,InputArray:InputArray});';

		}else{
			$UpLoadHtml .= '$("#ContentImgs").AppUpload({InputName:"new_content_imgs"});';
		}

		echo $UploadConfig['CssJsHtml'].'<script>var ue = UE.getEditor("content",{autoHeightEnabled: false,autoFloatEnabled:false,enableAutoSave: false});'.$UpLoadHtml.'</script> ';

	}else{
		foreach($_GET['new_thumbnail'] as $Key => $Val) {
			$_GET['new_thumbnail'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}

		foreach($_GET['new_content_imgs'] as $Key => $Val) {
			$_GET['new_content_imgs'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}

		$Data['uid'] = intval($_GET['new_uid']);
		$Member = DB::fetch_first('SELECT username FROM '.DB::table('common_member').' where uid = '.$Data['uid']);
		$Data['username'] = addslashes(strip_tags($Member['username']));
		$Data['thumbnail'] = addslashes(strip_tags($_GET['new_thumbnail'][0]));
		$Data['title'] = addslashes(strip_tags($_GET['title']));
		$Data['class'] = intval($_GET['class']);
		$Data['company_id'] = intval($_GET['company_id']);
		$Data['design_id'] = intval($_GET['design_id']);
		$Data['community_id'] = intval($_GET['community_id']);
		
		$Data['style'] = intval($_GET['style']);
		$Data['apartment'] = intval($_GET['apartment']);
		$Data['square'] = intval($_GET['square']);
		$Data['type'] = intval($_GET['type']);
		$Data['local'] = intval($_GET['local']);
		$Data['space'] = intval($_GET['space']);
		$Data['url'] = addslashes(strip_tags($_GET['url']));

		if($Data['class'] == 1){
			$Data['money'] = intval($_GET['money']);
		}else if($Data['class'] == 2){
			$Data['style'] = intval($_GET['panorama_style']);
			$Data['apartment'] = intval($_GET['panorama_apartment']);
			$Data['money'] = intval($_GET['panorama_money']);
			
		}
		
		$Data['content'] = addslashes($_GET['content']);//�豣��Html
		$Data['click'] = intval($_GET['click']);
		$Data['topdateline'] = $_GET['topdateline'] ? strtotime($_GET['topdateline']) : '';
		$Data['display'] = intval($_GET['display']);

		$Param['content_imgs'] = is_array($_GET['new_content_imgs']) && isset($_GET['new_content_imgs']) ? $_GET['new_content_imgs'] : '';

		$Data['param'] = serialize($Param);
		
		if($Item){

			$Data['updateline'] = strtotime($_GET['updateline']);

			GetInsertDoLog('edit_case_list_renovation','fn_'.$_GET['mod'],array('id'=>$id));//������¼
			DB::update($Fn_Renovation->TableCase,$Data,'id = '.$id);
		}else{
			$Data['dateline'] = $Data['updateline'] = time();
			$Id = DB::insert($Fn_Renovation->TableCase,$Data,true);
			GetInsertDoLog('add_case_list_renovation','fn_'.$_GET['mod'],array('id'=>$Id));//������¼
		}
		fn_cpmsg($Fn_Renovation->Config['LangVar']['UpdateOk'],$Fn_Admin->Config['IframeItemUrl'].'&submodel=list','succeed');
		
	}
}


/* �б� */
function GetModulesList($Page,$Limit,$Where=null,$Order){
	global $Fn_Renovation;
	$FetchSql = 'SELECT C.*,CC.name as company_name,CC.landline,CO.name as community_name FROM '.DB::table($Fn_Renovation->TableCase).' C LEFT JOIN `'.DB::table($Fn_Renovation->TableCompany).'` CC on CC.id = C.company_id LEFT JOIN `'.DB::table($Fn_Renovation->TableCommunity).'` CO on CO.id = C.community_id '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}

/* ���� */
function GetModulesCount($Where=null){
	global $Fn_Renovation;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_Renovation->TableCase).' C '.$Where;
	return DB::result_first($FetchSql);//��������
}

?>