<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('renovation_all') && !$Fn_Admin->CheckUserGroup('renovation_design_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$SubModel = in_array($_GET['submodel'], array('list','add')) ? $_GET['submodel'] : 'list';
$Fn_Admin->Config['IframeSubModelUrl'] = $Fn_Admin->Config['IframeItemUrl'].'&submodel='.$SubModel;
$NavClass = array($SubModel=>'btn-info Hover');

//����
echo <<<Nav
<div class="SubModelNav">
  <ul>
	<li class="{$NavClass['list']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=list" target="_self">{$Fn_Admin->Config['LangVar']['RenovationLeftNavArray'][$_GET['item']]}</a></li>
    <li class="{$NavClass['add']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=add" target="_self">{$Fn_Admin->Config['LangVar']['AddEditTitle']}</a></li>
  </ul>
  <div class="both"></div>
</div>
Nav;

if($SubModel == 'list'){//�б�
	$Do = in_array($_GET['do'], array('Del','Display')) ? $_GET['do'] : 'submodel_list';
	//�����ֶ�
	$SearField =array('page','keyword','display','order','company_id');
	foreach($SearField as $Val) {
		$SearArray[$Val] = $_GET[$Val] || in_array($_GET[$Val],array('0')) ? $_GET[$Val] : '';
	}
	//�����ֶ� End
	$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeSubModelUrl'].'&'.http_build_query($SearArray);


	if($Do == 'submodel_list'){
		if(!submitcheck('Submit')) {
			$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
			$Where = '';
			$Order = $_GET['order'] ? 'D.'.addslashes(dhtmlspecialchars($_GET['order'])) : 'D.id';
			
			if($_GET['keyword']){
				$_GET['keyword'] = str_replace(array('%','_'),array('',''),$_GET['keyword']);
				$Where .= ' and (D.name like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or D.username like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or D.id = '.intval($_GET['keyword']).' )';
			}
			
			if($_GET['company_id']){
				$Where .= ' and D.company_id = '.intval($_GET['company_id']);
			}

			if(in_array($_GET['display'],array('0','1'))){
				$Where .= ' and D.display = '.intval($_GET['display']);
			}

			$Where = preg_replace('/and/','where',$Where,1);
			$Limit = 20;
			$Page = $_GET['page']?intval($_GET['page']):1;
			/* ��ѯ���� End */
			

			/* ģ����� */	
			showtagheader('div', 'row', true,'row');
			showtagheader('div', 'col-12', true,'col-12');
			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-body', true,'box-body');
			/* ���� */

			$DisplaySelected = array($_GET['display']=>' selected');
			$OrderSelected = array($_GET['order']=>' selected');

			echo <<<SEARCH
			<form method="post" autocomplete="off" action="$SearUrl">
				<div class="FormSearchTo" style="margin-bottom:0;">
					<table cellspacing="4" cellpadding="4">
						<tr>
							<th>{$Fn_Renovation->Config['LangVar']['KeywordTitle']}</th><td><input type="text" class="input form-control w200" name="keyword" value="{$_GET['keyword']}" placeholder="{$Fn_Renovation->Config['LangVar']['AdminDesignPlaceholder']}">
							</td>
							<th>{$Fn_Renovation->Config['LangVar']['CompanyID']}</th><td><input type="text" class="input form-control w120" name="company_id" value="{$_GET['company_id']}" placeholder="{$Fn_Renovation->Config['LangVar']['CompanyIDPlaceholder']}">
							</td>
							<th>{$Fn_Renovation->Config['LangVar']['DisplayTitle']}</th><td>
							<select name="display" class="form-control w120">
								<option value="">{$Fn_Renovation->Config['LangVar']['SelectNull']}</option>
								<option value="1"{$DisplaySelected['1']}>{$Fn_Renovation->Config['LangVar']['Yes']}</option>
								<option value="0"{$DisplaySelected['0']}>{$Fn_Renovation->Config['LangVar']['No']}</option>
							</select>
							</td>
							<th>{$Fn_Admin->Config['LangVar']['Order']}</th><td>
							
							<select name="order" class="form-control w120">
								<option value="dateline"{$OrderSelected['dateline']}>{$Fn_Admin->Config['LangVar']['OrderArray']['dateline']}</option>
								<option value="click"{$OrderSelected['click']}>{$Fn_Admin->Config['LangVar']['OrderArray']['click']}</option>
							</select>
							&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Admin->Config['LangVar']['SearchSubmit']}" class="btn btn-info" type="submit">
							</td>
						</tr>
					</table>
				</div>
			</form>
SEARCH;
			/* ���� End */
			showtagheader('div', 'table-responsive', true,'table-responsive');
			showformheader($FormUrl,'enctype="multipart/form-data"');
			showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
			showsubtitle(array(
				'ID',
				'UID/'.$Fn_Renovation->Config['LangVar']['UserNameTitle'],
				$Fn_Renovation->Config['LangVar']['CompanyName'],
				$Fn_Renovation->Config['LangVar']['HeadPortrait'],
				$Fn_Renovation->Config['LangVar']['FullName'],
				$Fn_Renovation->Config['LangVar']['DesignTitle'],
				$Fn_Renovation->Config['LangVar']['Experience'],
				$Fn_Renovation->Config['LangVar']['DisplayTitle'],
				$Fn_Renovation->Config['LangVar']['RefreshTime'],
				$Fn_Renovation->Config['LangVar']['TimeTitle'],
				$Fn_Renovation->Config['LangVar']['OperationTitle']
			),'header tbm tc');

			$ModulesList = $Fn_Renovation->DesignListFormat(GetModulesList($Page,$Limit,$Where,$Order));
			foreach ($ModulesList as $Module) {
				
				showtablerow('', array('class="tc w50"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
					'<input type="checkbox" class="filled-in" id="checkbox_'.$Module['id'].'" name="delete[]" value="'.$Module['id'].'"><label for="checkbox_'.$Module['id'].'">'.$Module['id'].'</label>',
					$Module['uid'] ? $Module['uid'].'/'.$Module['username'] : '',
					$Module['company_name'],
					$Module['face'] ? '<img src="'.$Module['face'].'" style="height:30px;">' : '',
					$Module['name'],
					$Module['title'],
					$Fn_Renovation->Config['LangVar']['design_experience'][$Module['experience']],
					!$Module['display'] ? '<span class="label bg-secondary">'.$Fn_Renovation->Config['LangVar']['No'].'</span>' : '<span class="label bg-blue">'.$Fn_Renovation->Config['LangVar']['Yes'].'</span>',
					$Module['updateline'],
					date('Y-m-d H:i',$Module['dateline']),
					'<a href="'.$Fn_Renovation->Config['ViewDesignUrl'].$Module['id'].'" target="_blank" class="btn btn-sm btn-dark-outline">'.cplang('view').'</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&did='.$Module['id'].'" class="btn btn-sm btn-info-outline">'.$Fn_Renovation->Config['LangVar']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Display&did='.$Module['id'].'&value='.(!empty($Module['display']) ? 0:1).'&formhash='.FORMHASH.'" class="btn btn-sm btn-purple-outline">'.(!empty($Module['display']) ? $Fn_Renovation->Config['LangVar']['DisplayNoTitle'] : $Fn_Renovation->Config['LangVar']['DisplayIsTitle']).'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Del&did='.$Module['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$Fn_Renovation->Config['LangVar']['DelTitle'].'</a>',
				));
			}
			showsubmit('Submit','&#31435;&#21363;&#25552;&#20132;','del','','',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));
			showtablefooter(); /*dism��taobao��com*/
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			/* ģ�����End */	
		}else{
			if(!$Fn_Admin->CheckUserGroup('renovation_all') && !$Fn_Admin->CheckUserGroup('renovation_design_del')){//Ȩ���ж�
				fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
				exit();
			}

			if(isset($_GET['delete']) && is_array($_GET['delete'])){
				foreach($_GET['delete'] as $Key => $Val) {
					$Val = intval($Val);
					DB::delete($Fn_Renovation->TableDesign,'id ='.$Val);
				}

				GetInsertDoLog('del_design_list_renovation','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete'])));//������¼

				fn_cpmsg($Fn_Renovation->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
			}else{
				fn_cpmsg($Fn_Renovation->Config['LangVar']['DelErr'],'','error');
			}
				
		}
	}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['did']){
		if(!$Fn_Admin->CheckUserGroup('renovation_all') && !$Fn_Admin->CheckUserGroup('renovation_design_del')){//Ȩ���ж�
			fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
			exit();
		}
		$id = intval($_GET['did']);
		DB::delete($Fn_Renovation->TableDesign,'id ='.$id);
		GetInsertDoLog('del_design_list_renovation','fn_'.$_GET['mod'],array('id'=>$id));//������¼
		fn_cpmsg($Fn_Admin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
	}else if($Do == 'Display' && $_GET['formhash'] == formhash() && $_GET['did']){
		$id = intval($_GET['did']);
		$UpData['display'] = intval($_GET['value']);
		DB::update($Fn_Renovation->TableDesign,$UpData,'id = '.$id);
		GetInsertDoLog('display_design_list_renovation','fn_'.$_GET['mod'],array('id'=>$id,'display'=>$_GET['value']));//������¼
		fn_cpmsg($Fn_Renovation->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

	}
}else if($SubModel == 'add'){//���ӻ�༭
	if(!$Fn_Admin->CheckUserGroup('renovation_all') && !$Fn_Admin->CheckUserGroup('renovation_design_add')){//Ȩ���ж�
		fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
		exit();
	}
	$did = intval($_GET['did']);

	$Item = DB::fetch_first('SELECT * FROM '.DB::table($Fn_Renovation->TableDesign).' where id = '.$did);
	if($Item){
		//$Item['param'] = unserialize($Item['param']);
	};
	if(!submitcheck('DetailSubmit')) {
		$OpTitle = $Fn_Renovation->Config['LangVar']['AddTitle'];
		if($Item){
			$OpTitle = $Fn_Renovation->Config['LangVar']['EditTitle'];
		}

		//ͼƬ�ϴ�
		if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_assembly/class/class_upload.php')){
			@require_once libfile('class/upload','plugin/fn_assembly');
			$UploadConfig = fn_upload::Config();
		}
		
		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-header', true,'with-border box-header');
		showtitle($OpTitle,'class="box-title"');
		showtagfooter('div');
		showformheader($Fn_Admin->Config['IframeSubModelUrl'].'&did='.$did,'enctype');
		showtagheader('div', 'box-body', true,'box-body');
		
		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_Renovation->Config['LangVar']['HeadPortrait'].'</label><div class="col-sm-9"><div class="AdminSingleUpload"><div class="PhotoControl" id="LogoPhotoControl"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';

		showsetting('UID', 'new_uid', $Item['uid'], 'text');
		
		showsetting($Fn_Renovation->Config['LangVar']['CompanyID'], 'company_id', $Item['company_id'], 'text');
		
		showsetting($Fn_Renovation->Config['LangVar']['FullName'], 'name', $Item['name'], 'text');
		
		showsetting($Fn_Renovation->Config['LangVar']['DesignTitle'], 'title', $Item['title'], 'text');

		showsetting($Fn_Renovation->Config['LangVar']['Experience'], array('experience',DyadicArray($Fn_Renovation->Config['LangVar']['design_experience'])), $Item['experience'] , 'select');

		showsetting($Fn_Renovation->Config['LangVar']['Idea'], 'idea', $Item['idea'], 'textarea');

		showsetting($Fn_Renovation->Config['LangVar']['PersonalIntroduction'], 'content', str_replace("<br>","\r\n",$Item['content']), 'textarea');
		
		if($Item['updateline']){
			showsetting($Fn_Renovation->Config['LangVar']['RefreshTime'], 'updateline',$Item['updateline'] ? date('Y-m-d H:i',$Item['updateline']) : '', 'calendar','','','',1);
		}

		if($Item['dateline']){
			showsetting($Fn_Renovation->Config['LangVar']['TimeTitle'], 'dateline',date('Y-m-d H:i',$Item['dateline']), 'calendar','','','',1);
		}

		showsetting($Fn_Renovation->Config['LangVar']['Click'], 'click', $Item['click'], 'text');

		showsetting($Fn_Renovation->Config['LangVar']['DisplayTitle'], 'display', $Item ? $Item['display'] : 1, 'radio');
		
		showsubmit('DetailSubmit','&#20445;&#23384;&#37197;&#32622;');
		showtagfooter('div');
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');

		$UpLoadHtml  = '';
		if($Item['face']){
			$LogoJsArray[] = '"'.$Item['face'].'"';;
			$UpLoadHtml .= '
			var InputArray = new Array('.implode(',',$LogoJsArray).');
			$("#LogoPhotoControl").AppUpload({InputName:"new_face",Multiple:true,InputExist:true,InputArray:InputArray});';

		}else{
			$UpLoadHtml .= '$("#LogoPhotoControl").AppUpload({InputName:"new_face",Multiple:true});';
		}

		echo $UploadConfig['CssJsHtml'].'<script>'.$UpLoadHtml.'</script> ';

	}else{
	
		$Data['uid'] = intval($_GET['new_uid']);
		$Member = DB::fetch_first('SELECT username FROM '.DB::table('common_member').' where uid = '.$Data['uid']);
		$Data['username'] = addslashes(strip_tags($Member['username']));
		
		foreach($_GET['new_face'] as $Key => $Val) {
			$_GET['new_face'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}
		
		$Data['company_id'] = intval($_GET['company_id']);
		$Data['face'] = addslashes(strip_tags($_GET['new_face'][0]));
		$Data['name'] = addslashes(strip_tags($_GET['name']));
		$Data['title'] = addslashes(strip_tags($_GET['title']));
		$Data['experience'] = intval($_GET['experience']);
		$Data['idea'] = addslashes(strip_tags($_GET['idea']));
		$Data['content'] = addslashes(str_replace("\r\n","<br>",$_GET['content']));
		$Data['click'] = intval($_GET['click']);
		$Data['display'] = intval($_GET['display']);
		

				
		if($Item){
			$Data['updateline'] = strtotime($_GET['updateline']);

			GetInsertDoLog('edit_design_list_renovation','fn_'.$_GET['mod'],array('id'=>$did));//������¼

			DB::update($Fn_Renovation->TableDesign,$Data,'id = '.$did);
				
		}else{
			$Data['dateline'] = $Data['updateline'] = time();

			$Id = DB::insert($Fn_Renovation->TableDesign,$Data,true);

			GetInsertDoLog('add_design_list_renovation','fn_'.$_GET['mod'],array('id'=>$Id));//������¼
		}
		fn_cpmsg($Fn_Renovation->Config['LangVar']['UpdateOk'],$Fn_Admin->Config['IframeItemUrl'].'&submodel=list','succeed');
		
	}
}


/* �б� */
function GetModulesList($Page,$Limit,$Where=null,$Order){
	global $Fn_Renovation;
	$FetchSql = 'SELECT D.*,C.name as company_name FROM '.DB::table($Fn_Renovation->TableDesign).' D LEFT JOIN `'.DB::table($Fn_Renovation->TableCompany).'` C on C.id = D.company_id '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}

/* ���� */
function GetModulesCount($Where=null){
	global $Fn_Renovation;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_Renovation->TableDesign).' D '.$Where;
	return DB::result_first($FetchSql);//��������
}

?>