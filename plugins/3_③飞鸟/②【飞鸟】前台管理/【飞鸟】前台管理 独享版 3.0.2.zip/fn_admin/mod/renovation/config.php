<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if(!$Fn_Admin->CheckUserGroup('renovation_all') && !$Fn_Admin->CheckUserGroup('renovation_config')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

@require_once libfile('function/cache');
@require_once libfile('function/core','plugin/fn_assembly');

$setting_name = 'fn_'.$_GET['mod'].'_setting';
loadcache($setting_name);
$common_setting = $_G['cache'][$setting_name];
$setting = $common_setting = array_filter($common_setting) ? $common_setting : array();
foreach($setting as $key => $value) {
	$setting[$key] = is_array($value) ? $value : stripslashes($value);
}
$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeItemUrl'];

if(!submitcheck('DetailSubmit')) {
	//ͼƬ�ϴ�
	if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_assembly/class/class_upload.php')){
		@require_once libfile('class/upload','plugin/fn_assembly');
		$UploadConfig = fn_upload::Config();
	}

	showtagheader('div', 'box', true,'box');
	showformheader($FormUrl,'enctype');
	if(in_array($Config['PluginVar']['AppType'],array('1','2','3'))){
		$AppNav = '<li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#app" role="tab" aria-expanded="false"><span class="hidden-sm-up"><i class="ion-email"></i></span> <span class="hidden-xs-down">&#65;&#80;&#80;&#35774;&#32622;</span></a> </li>';
	}
	echo <<<HTML
		<ul class="nav nav-tabs customtab" role="tablist">
          <li class="nav-item"> <a class="nav-link active" data-toggle="tab" href="#basics" role="tab" aria-expanded="true"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#22522;&#30784;&#35774;&#32622;</span></a> </li>
		  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#nav" role="tab" aria-expanded="true"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#23548;&#33322;&#35774;&#32622;</span></a> </li>
		  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#index" role="tab" aria-expanded="true"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#39318;&#39029;&#35774;&#32622;</span></a> </li>
		  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#pc" role="tab" aria-expanded="true"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#30005;&#33041;&#29256;&#35774;&#32622;</span></a> </li>
		  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#renovation" role="tab" aria-expanded="true"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#35013;&#20462;&#35774;&#32622;</span></a> </li>
		  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#material" role="tab" aria-expanded="true"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#24314;&#26448;&#35774;&#32622;</span></a> </li>
		  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#artisan" role="tab" aria-expanded="true"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#25214;&#24072;&#20613;&#35774;&#32622;</span></a> </li>
		  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#design" role="tab" aria-expanded="true"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#25143;&#22411;&#35774;&#35745;</span></a> </li>
		  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#free_quote" role="tab" aria-expanded="true"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#35013;&#20462;&#39044;&#31639;</span></a> </li>
		  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#inspect" role="tab" aria-expanded="true"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#39564;&#25151;&#26816;&#27979;</span></a> </li>
		  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#sms" role="tab" aria-expanded="true"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#30701;&#20449;&#27169;&#26495;&#35774;&#32622;</span></a> </li>
		  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#share" role="tab" aria-expanded="false"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#20998;&#20139;&#35774;&#32622;</span></a> </li>
		  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#color" role="tab" aria-expanded="false"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#39068;&#33394;&#35774;&#32622;</span></a> </li>
		  {$AppNav}
        </ul>
HTML;

	showtagheader('div', 'box-body', true,'box-body');

	showtagheader('div', 'tab-content', true,'tab-content');

	echo <<<HTML
	<!-- ��������  -->
	<div class="tab-pane active" id="basics" role="tabpanel" aria-expanded="true">
HTML;

	$setting['Logo'] = $setting['Logo'] ? $setting['Logo'] : '/source/plugin/fn_renovation/static/images/logo.png';
	$LogoHtml = '<a href="'.$setting['Logo'].'" target="_blank" style="margin:0 5px 0 0;background:#000;"><img src="'.$setting['Logo'].'" height="15"/></a>';
	showsetting('&#76;&#111;&#103;&#111;', 'new_Logo',$setting['Logo'], 'filetext', '', 0, $LogoHtml);

	showsetting('&#26631;&#39064;', 'setting[Title]', $setting['Title'] ? $setting['Title'] : '&#12304;&#39134;&#40479;&#12305;&#21516;&#22478;&#35013;&#20462;', 'text');

	showsetting('&#31649;&#29702;&#21592;&#85;&#105;&#100;&#115;', 'setting[AdminUids]', $setting['AdminUids'], 'text','','','&#26435;&#38480;&#65306;&#21487;&#31649;&#29702;&#25152;&#26377;&#35013;&#20462;&#20869;&#23481;&#32;&#26684;&#24335;&#65306;&#49;&#44;&#50;&#44;&#51;&#32;&#65281;&#65281;&#65281;&#32;&#27880;&#24847;&#65306;&#35813;&#35774;&#32622;&#21644;&#12304;&#21069;&#21488;&#31649;&#29702;&#12305;&#25554;&#20214;&#26080;&#20851;');

	showsetting('&#21015;&#34920;&#35843;&#29992;&#26465;&#25968;', 'setting[ListNum]', $setting['ListNum'] ? $setting['ListNum'] : '10', 'text');

	showsetting('&#26174;&#31034;&#39030;&#37096;&#22266;&#23450;&#23548;&#33322;', 'setting[HeaderSwitch]', $common_setting ? $setting['HeaderSwitch'] : 1, 'radio');
		
	showsetting('&#21306;&#22495;&#35774;&#32622;', 'setting[Area]', $setting['Area'] ? $setting['Area'] : '1=&#22825;&#27827;&#21306;
1.1=&#20307;&#32946;&#35199;&#36335;
1.2=&#24191;&#24030;&#19996;&#31449;
1.3=&#29141;&#22616;
2=&#36234;&#31168;&#21306;
2.1=&#21271;&#20140;&#36335;
2.2=&#35199;&#38376;&#21475;
2.3=&#23567;&#21271;
2.4=&#28120;&#37329;
3=&#30333;&#20113;&#21306;
3.1=&#40857;&#24402;
3.2=&#32599;&#20914;&#22260;
3.3=&#21516;&#21644;', 'textarea','','',lang('plugin/fn_admin', 'MultilevelClassificationTips'));
	
	showsetting('&#23458;&#26381;&#30005;&#35805;', 'setting[OnlineMobile]', $setting['OnlineMobile'], 'text');

	showsetting('&#23458;&#26381;&#24494;&#20449;&#21495;', 'setting[OnlineWx]', $setting['OnlineWx'], 'text');
	
	$setting['OnlineWxPath'] = $setting['OnlineWxPath'] ? $setting['OnlineWxPath'] : '/source/plugin/fn_renovation/static/images/qr.jpg';
	$OnlineWxPathHtml = '<a href="'.$setting['OnlineWxPath'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['OnlineWxPath'].'" height="55"/></a>';
	showsetting('&#23458;&#26381;&#24494;&#20449;&#20108;&#32500;&#30721;', 'new_OnlineWxPath',$setting['OnlineWxPath'], 'filetext', '', 0, $OnlineWxPathHtml);

	showsetting('&#34920;&#21333;&#25910;&#38598;&#38388;&#38548;&#26102;&#38388;', 'setting[FormTime]', $setting['FormTime'] ? $setting['FormTime'] : 120, 'text');

	showsetting('&#34920;&#21333;&#25910;&#38598;&#38388;&#38548;&#26102;&#38388;&#25552;&#31034;&#35821;', 'setting[FormTimeTips]', $setting['FormTimeTips'] ? $setting['FormTimeTips'] : '&#24744;&#25552;&#20132;&#24471;&#22826;&#24555;&#20102;&#65292;&#20241;&#24687;{time}&#31186;&#22312;&#26469;&#25552;&#20132;&#65281;', 'text','','','&#123;&#116;&#105;&#109;&#101;&#125;&#20195;&#34920;&#21097;&#20313;&#22810;&#23569;&#31186;');
	showsetting('&#34920;&#21333;&#26174;&#31034;&#36873;&#25321;&#20844;&#21496;',array('setting[FormCompany]', array(
		array('1','&#26159;', array('FormCompany_div' => '')),
		array('0','&#21542;', array('FormCompany_div' => 'none')),
	), TRUE),$setting['FormCompany'], 'mradio');

	showtagheader('div', 'FormCompany_div', $setting['FormCompany'] == 1 ? true : '','sub');
		showsetting('&#34920;&#21333;&#36873;&#25321;&#20844;&#21496;&#26368;&#22823;&#25968;', 'setting[FormCompanyMax]', $setting['FormCompanyMax'] ? $setting['FormCompanyMax'] : 3, 'text','','','&#48;&#25110;&#31354;&#20195;&#34920;&#19981;&#38480;&#21046;&#65281;&#65281;&#65281;&#33258;&#23450;&#20041;&#39029;&#38754;&#34920;&#21333;&#36873;&#25321;&#20844;&#21496;&#26368;&#22823;&#21487;&#36873;&#25321;&#22810;&#23569;&#23478;');
	showtagfooter('div');

	showsetting('&#26381;&#21153;&#22810;&#23569;&#25143;&#23478;&#24237;&#34394;&#25311;&#25968;', 'setting[count_family]', $setting['count_family'] ? $setting['count_family'] : 263, 'text');

	showsetting('&#26381;&#21153;&#20960;&#25143;&#23478;&#24237;&#25991;&#26696;', 'setting[count_family_tips]', $setting['count_family_tips'] ? $setting['count_family_tips'] : '&#32047;&#35745;&#24050;&#26381;&#21153;&#20840;&#24066;<em>{count}&#25143;</em>&#23478;&#24237;', 'text','','','&#123;&#99;&#111;&#117;&#110;&#116;&#125;&#31561;&#20110;&#26381;&#21153;&#22810;&#23569;&#25143;&#23478;&#24237;&#34394;&#25311;&#25968;&#32;&#43;&#32;&#25552;&#20132;&#35013;&#20462;&#39044;&#31639;&#34920;&#21333;&#20154;&#25968;');

	showsetting('&#38405;&#35835;&#37327;&#38543;&#26426;&#25968;', 'setting[ClickRand]', $setting['ClickRand'] ? $setting['ClickRand'] : '1-1', 'text','','','&#26684;&#24335;&#65306;&#26368;&#23567;&#38543;&#26426;&#25968;&#45;&#26368;&#22823;&#38543;&#26426;&#25968;');
	
	$setting['AddPath'] = $setting['AddPath'] ? $setting['AddPath'] : '/source/plugin/fn_renovation/static/images/add.png';
	$AddPathHtml = '<a href="'.$setting['AddPath'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['AddPath'].'" height="55"/></a>&#24314;&#35758;&#50;&#53;&#48;&#32;&#42;&#32;&#51;&#52;';
	showsetting('&#21457;&#24067;&#22270;&#26631;', 'new_AddPath',$setting['AddPath'], 'filetext', '', 0, $AddPathHtml);

	$setting['SettledInPath'] = $setting['SettledInPath'] ? $setting['SettledInPath'] : '/source/plugin/fn_renovation/static/images/ruzhu.png';
	$SettledInPathHtml = '<a href="'.$setting['SettledInPath'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['SettledInPath'].'" height="55"/></a>&#24314;&#35758;&#50;&#53;&#48;&#32;&#42;&#32;&#51;&#52;';
	showsetting('&#20837;&#39547;&#22270;&#26631;', 'new_SettledInPath',$setting['SettledInPath'], 'filetext', '', 0, $SettledInPathHtml);

	$setting['UserBgPath'] = $setting['UserBgPath'] ? $setting['UserBgPath'] : '/source/plugin/fn_renovation/static/images/user_bg.jpg';
	$UserBgPathHtml = '<a href="'.$setting['UserBgPath'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['UserBgPath'].'" height="55"/></a>';
	showsetting('&#20250;&#21592;&#39029;&#32972;&#26223;&#22270;&#36335;&#24452;', 'new_UserBgPath',$setting['UserBgPath'], 'filetext', '', 0, $UserBgPathHtml);

	//ˮӡ����
	showsetting('&#24320;&#21551;&#27700;&#21360;',array('setting[watermark]', array(
		array('1','&#26159;', array('watermark_div' => '')),
		array('0','&#21542;', array('watermark_div' => 'none')),
	), TRUE),$setting['watermark'], 'mradio','','','&#24494;&#20449;&#47;&#30005;&#33041;&#29256;&#26377;&#25928;&#65292;&#27880;&#24847;&#65306;&#30001;&#20110;&#65;&#80;&#80;&#26377;&#19978;&#20256;&#32452;&#20214;&#65292;&#25152;&#20197;&#35813;&#35774;&#32622;&#65;&#80;&#80;&#20869;&#26080;&#25928;');
	showtagheader('div', 'watermark_div', $setting['watermark'] == 1 ? true : '','sub');
		$watermark_position_array = array(
			array('1','&#24038;&#19978;'),
			array('2','&#24038;&#20013;'),
			array('3','&#21491;&#19978;'),
			array('4','&#20013;&#24038;'),
			array('5','&#20013;&#38388;'),
			array('6','&#20013;&#21491;'),
			array('7','&#24038;&#19979;'),
			array('8','&#20013;&#19979;'),
			array('9','&#21491;&#19979;'),
		);
		showsetting('&#27700;&#21360;&#20301;&#32622;', array('setting[watermark_status]',$watermark_position_array),$common_setting ? $setting['watermark_status'] : 9,'select');
		showsetting('&#27700;&#21360;&#26465;&#20214;', 'setting[watermark_condition]', $setting['watermark_condition'] ? $setting['watermark_condition'] : '0-0', 'text','','','&#26684;&#24335;&#65306;&#48;&#45;&#48;&#65281;&#65281;&#65281;&#35774;&#32622;&#27700;&#21360;&#28155;&#21152;&#30340;&#26465;&#20214;&#65292;&#23567;&#20110;&#27492;&#23610;&#23544;&#30340;&#22270;&#29255;&#38468;&#20214;&#23558;&#19981;&#28155;&#21152;&#27700;&#21360;');
		
		showsetting('&#74;&#80;&#69;&#71;&#27700;&#21360;&#36136;&#37327;', 'setting[watermark_quality]', $common_setting ? $setting['watermark_quality'] : 90, 'text','','','&#35774;&#32622;&#74;&#80;&#69;&#71;&#31867;&#22411;&#30340;&#22270;&#29255;&#38468;&#20214;&#28155;&#21152;&#27700;&#21360;&#21518;&#30340;&#36136;&#37327;&#21442;&#25968;&#65292;&#33539;&#22260;&#20026;&#32;&#48;&#65374;&#49;&#48;&#48;&#32;&#30340;&#25972;&#25968;&#65292;&#25968;&#20540;&#36234;&#22823;&#32467;&#26524;&#22270;&#29255;&#25928;&#26524;&#36234;&#22909;&#65292;&#20294;&#23610;&#23544;&#20063;&#36234;&#22823;');

		showsetting('&#27700;&#21360;&#31867;&#22411;',array('setting[watermark_type]', array(
			array('png','&#80;&#78;&#71;&#31867;&#22411;&#27700;&#21360;', array('watermark_type_text_div' => 'none','watermark_type_png_div' => '','watermark_type_gif_div' => 'none')),
			array('gif','&#71;&#73;&#70;&#31867;&#22411;&#27700;&#21360;', array('watermark_type_text_div' => 'none','watermark_type_png_div' => 'none','watermark_type_gif_div' => '')),
		), TRUE),$setting['watermark_type'] ? $setting['watermark_type'] : 'png','mradio');

		showtagheader('div', 'watermark_type_png_div', $setting['watermark_type'] == 'png' ? true : '','sub');
			$setting['watermark_png'] = $setting['watermark_png'] ? $setting['watermark_png'] : 'static/image/common/watermark.png';
			$watermark_png_html = '<a href="'.$setting['watermark_png'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['watermark_png'].'" height="55"/></a>&#24314;&#35758;&#23610;&#23544;&#65306;&#49;&#51;&#48;&#32;&#42;&#32;&#52;&#48;';
			showsetting('&#80;&#78;&#71;&#27700;&#21360;', 'new_watermark_png',$setting['watermark_png'], 'filetext', '', 0, $watermark_png_html);
		showtagfooter('div');

		showtagheader('div', 'watermark_type_gif_div', $setting['watermark_type'] == 'gif' ? true : '','sub');
			$setting['watermark_gif'] = $setting['watermark_gif'] ? $setting['watermark_gif'] : 'static/image/common/watermark.gif';
			$watermark_gif_html = '<a href="'.$setting['watermark_gif'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['watermark_gif'].'" height="55"/></a>&#24314;&#35758;&#23610;&#23544;&#65306;&#49;&#51;&#48;&#32;&#42;&#32;&#52;&#48;';
			showsetting('&#71;&#73;&#70;&#27700;&#21360;', 'new_watermark_gif',$setting['watermark_gif'], 'filetext', '', 0, $watermark_gif_html);
			showsetting('&#27700;&#21360;&#34701;&#21512;&#24230;', 'setting[watermark_trans]', $setting['watermark_trans'] ? $setting['watermark_trans'] : 50, 'text','','','&#35774;&#32622;&#71;&#73;&#70;&#31867;&#22411;&#27700;&#21360;&#22270;&#29255;&#19982;&#21407;&#22987;&#22270;&#29255;&#30340;&#34701;&#21512;&#24230;&#65292;&#33539;&#22260;&#20026;&#32;&#49;&#65374;&#49;&#48;&#48;&#32;&#30340;&#25972;&#25968;&#65292;&#25968;&#20540;&#36234;&#22823;&#27700;&#21360;&#22270;&#29255;&#36879;&#26126;&#24230;&#36234;&#20302;&#12290;');
		showtagfooter('div');
		
		showtagheader('div', 'watermark_type_text_div', $setting['watermark_type'] == 'text' ? true : '','sub');
			
		showtagfooter('div');
	showtagfooter('div');
	//ˮӡ���� END

	showsetting('&#31532;&#19977;&#26041;&#32479;&#35745;&#20195;&#30721;', 'setting[Statistics]', $setting['Statistics'], 'textarea');

	echo <<<HTML
	</div>
	<!-- �������� end  -->
HTML;
	
	echo <<<HTML
	<!-- ��������  -->
	<div class="tab-pane" id="nav" role="tabpanel" aria-expanded="false">
	<div class="alert alert-primary" role="alert">&#91;&#115;&#105;&#116;&#101;&#117;&#114;&#108;&#93;&#20195;&#34920;&#24403;&#21069;&#22495;&#21517;</div>
	<script type="text/JavaScript">
	var navrowtypedata = [
		[
			[1, '<input type="text" class="form-control w50" name="common_list[navs][displayorder][]" value="">'],
			[1, '<input type="text" class="form-control w200" name="common_list[navs][title][]" value="">'],
			[1, '<input name="common_list[navs][file_icon][]" value="" class="txt uploadbtn" type="file" style="width:266px;">'],
			[1, '<input type="text" class="form-control w400" name="common_list[navs][link][]" value="">'],
			[1, '<a href="#" onclick="deleterow(this)" class="btn btn-sm btn-danger-outline">&#21024;&#38500;</a>']
		],
	];
	var footernavrowtypedata = [
		[
			[1, '<input type="text" class="form-control w50" name="common_list[footer_nav][displayorder][]" value="">'],
			[1, '<input type="text" class="form-control w80" name="common_list[footer_nav][icon][]" value="">'],
			[1, '<input type="text" class="form-control w200" name="common_list[footer_nav][title][]" value="">'],
			[1, '<input type="text" class="form-control w400" name="common_list[footer_nav][link][]" value="">'],
			[1, '<a href="#" onclick="deleterow(this)" class="btn btn-sm btn-danger-outline">&#21024;&#38500;</a>']
		],
	];
	var addnavrowtypedata = [
		[
			[1, '<input type="text" class="form-control w50" name="common_list[add_nav][displayorder][]" value="">'],
			[1, '<input type="text" class="form-control w200" name="common_list[add_nav][title][]" value="">'],
			[1, '<input name="common_list[add_nav][file_icon][]" value="" class="txt uploadbtn" type="file" style="width:266px;">'],
			[1, '<input type="text" class="form-control w400" name="common_list[add_nav][link][]" value="">'],
			[1, '<a href="#" onclick="deleterow(this)" class="btn btn-sm btn-danger-outline">&#21024;&#38500;</a>']
		],
	];
	</script>
HTML;
	
	echo '<div class="form-group row"><label class="col-sm-1 col-form-label">&#51;&#24352;&#22270;&#23548;&#33322;<br>&#23610;&#23544;&#24314;&#35758;&#54;&#52;&#48;&#32;&#42;&#32;&#51;&#48;&#48;</label><div class="col-sm-9"><div class="UploadBanner"><div class="PhotoControl ClickPhotoControl" id="MinIndexNav"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';
	
	//��ҳ����
	echo '<div class="border box-header margin-top-30"><h5 class="box-title">&#23548;&#33322;</h5></div>';
	showtableheader('','table table-bordered table-hover display nowrap table-responsive dataTable');
	showsubtitle(array(
		'&#26174;&#31034;&#39034;&#24207;',
		'&#23548;&#33322;&#26631;&#39064;',
		'&#23548;&#33322;&#22270;&#26631;',
		'&#23548;&#33322;&#38142;&#25509;',
		'&#21024;&#38500;'
	),'header tbm tc');
	$NavsArray = $common_setting ? $setting['navs'] : array(
		array('displayorder'=>'0','title'=>'&#20813;&#36153;&#35774;&#35745;','link'=>'[siteurl]plugin.php?id=fn_renovation&m=design','icon'=>'/source/plugin/fn_renovation/static/images/nav_1.png'),
		array('displayorder'=>'1','title'=>'&#25928;&#26524;&#22270;','link'=>'[siteurl]plugin.php?id=fn_renovation&m=list_case&class=1','icon'=>'/source/plugin/fn_renovation/static/images/nav_3.png'),
		array('displayorder'=>'2','title'=>'&#20840;&#26223;&#22270;','link'=>'[siteurl]plugin.php?id=fn_renovation&m=list_case&class=2','icon'=>'/source/plugin/fn_renovation/static/images/nav_7.png'),
		array('displayorder'=>'3','title'=>'&#35013;&#20462;&#20844;&#21496;','link'=>'[siteurl]plugin.php?id=fn_renovation&m=list_company','icon'=>'/source/plugin/fn_renovation/static/images/nav_4.png'),
		array('displayorder'=>'4','title'=>'&#25214;&#25105;&#23478;','link'=>'[siteurl]plugin.php?id=fn_renovation&m=list_community','icon'=>'/source/plugin/fn_renovation/static/images/nav_6.png'),
	);
	foreach ($NavsArray as $Key => $Nav) {
		showtablerow('', array('class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
			'<input type="text" class="form-control w50" name="common_list[navs][displayorder][]" value="'.$Nav['displayorder'].'">',
			'<input type="text" class="form-control w200" name="common_list[navs][title][]" value="'.$Nav['title'].'">',
			($Nav['icon'] ? '<a href="'.$Nav['icon'].'" target="_blank"><img src="'.$Nav['icon'].'" style="height:30px;margin:0 5px 0 0;"></a>' : '').'<input type="hidden" size="30" name="common_list[navs][icon][]" value="'.$Nav['icon'].'" /><input name="common_list[navs][file_icon][]" value="" class="txt uploadbtn" type="file" style="width:266px;">',
			'<input type="text" class="form-control w400" name="common_list[navs][link][]" value="'.$Nav['link'].'">',
			'<a href="#" onclick="deleterow(this)" class="btn btn-sm btn-danger-outline">&#21024;&#38500;</a>',
		));
	}
	echo '<tr class="hover"><td class="tc" colspan="10"><a href="#" onclick="addrow(this,navrowtypedata, 0)"><i class="fa fa-plus" style="margin-right:5px"></i>&#28155;&#21152;&#23548;&#33322;</a></td></tr>';
	showtablefooter(); /*dism��taobao��com*/
	//��ҳ���� End
	
	//�ײ�����
	echo '<div class="alert alert-primary margin-top-30" role="alert">&#22270;&#26631;&#21442;&#32771;&#65306;<a href="http://dev.yili6.com/source/plugin/fn_renovation/static/images/fontsize.png" target="_blank" class="text-danger">http://dev.yili6.com/source/plugin/fn_renovation/static/images/fontsize.png</a>&#65292;&#27880;&#24847;&#65306;&#22270;&#26631;&#19981;&#29992;&#24102;&#12304;&#38;&#35;&#59;&#12305;&#51;&#20010;&#23383;&#31526;</div><div class="border box-header margin-top-10"><h5 class="box-title">&#24213;&#37096;&#23548;&#33322;</h5></div>';
	showtableheader('','table table-bordered table-hover display nowrap table-responsive dataTable');
	showsubtitle(array(
		'&#26174;&#31034;&#39034;&#24207;',
		'&#23548;&#33322;&#22270;&#26631;',
		'&#23548;&#33322;&#26631;&#39064;',
		'&#23548;&#33322;&#38142;&#25509;',
		'&#21024;&#38500;'
	),'header tbm tc');
	$FooterNavArray = $common_setting ? $setting['footer_nav'] : array(
		array('displayorder'=>'0','title'=>'&#39318;&#39029;','link'=>'[siteurl]plugin.php?id=fn_renovation','icon'=>'xe600'),
		array('displayorder'=>'1','title'=>'&#25214;&#24314;&#26448;','link'=>'[siteurl]plugin.php?id=fn_renovation&m=material','icon'=>'xe65f'),
		array('displayorder'=>'2','title'=>'&#25928;&#26524;&#22270;','link'=>'[siteurl]plugin.php?id=fn_renovation&m=list_case&class=1','icon'=>'xe968'),
		array('displayorder'=>'3','title'=>'&#25214;&#24072;&#20613;','link'=>'[siteurl]plugin.php?id=fn_renovation&m=list_artisan','icon'=>'xe6f8'),
	);
	foreach ($FooterNavArray as $Key => $Nav) {
		showtablerow('', array('class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
			'<input type="text" class="form-control w50" name="common_list[footer_nav][displayorder][]" value="'.$Nav['displayorder'].'">',
			'<input type="text" class="form-control w80" name="common_list[footer_nav][icon][]" value="'.$Nav['icon'].'">',
			'<input type="text" class="form-control w200" name="common_list[footer_nav][title][]" value="'.$Nav['title'].'">',
			'<input type="text" class="form-control w400" name="common_list[footer_nav][link][]" value="'.$Nav['link'].'">',
			'<a href="#" onclick="deleterow(this)" class="btn btn-sm btn-danger-outline">&#21024;&#38500;</a>',
		));
	}
	echo '<tr class="hover"><td class="tc" colspan="10"><a href="#" onclick="addrow(this,footernavrowtypedata, 0)"><i class="fa fa-plus" style="margin-right:5px"></i>&#28155;&#21152;&#23548;&#33322;</a></td></tr>';
	showtablefooter(); /*dism��taobao��com*/
	//�ײ����� End

	//��������
	echo '<div class="border box-header margin-top-30"><h5 class="box-title">&#21457;&#24067;&#23548;&#33322;</h5></div>';
	showtableheader('','table table-bordered table-hover display nowrap table-responsive dataTable');
	showsubtitle(array(
		'&#26174;&#31034;&#39034;&#24207;',
		'&#23548;&#33322;&#26631;&#39064;',
		'&#23548;&#33322;&#22270;&#26631;',
		'&#23548;&#33322;&#38142;&#25509;',
		'&#21024;&#38500;'
	),'header tbm tc');
	$AddNavArray = $common_setting ? $setting['add_nav'] : array(
		array('displayorder'=>'0','title'=>'&#35013;&#20462;&#26696;&#20363;','link'=>'[siteurl]plugin.php?id=fn_renovation&m=user_case&class=1','icon'=>'/source/plugin/fn_renovation/static/images/nav_3.png'),
		array('displayorder'=>'1','title'=>'&#20840;&#26223;&#26696;&#20363;','link'=>'[siteurl]plugin.php?id=fn_renovation&m=user_case&class=2','icon'=>'/source/plugin/fn_renovation/static/images/nav_7.png'),
		array('displayorder'=>'2','title'=>'&#22312;&#24314;&#24037;&#22320;','link'=>'[siteurl]plugin.php?id=fn_renovation&m=user_build','icon'=>'/source/plugin/fn_renovation/static/images/nav_4.png'),
		array('displayorder'=>'3','title'=>'&#35774;&#35745;&#24072;','link'=>'[siteurl]plugin.php?id=fn_renovation&m=user_design','icon'=>'/source/plugin/fn_renovation/static/images/nav_1.png'),
	);
	foreach ($AddNavArray as $Key => $Nav) {
		showtablerow('', array('class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
			'<input type="text" class="form-control w50" name="common_list[add_nav][displayorder][]" value="'.$Nav['displayorder'].'">',
			'<input type="text" class="form-control w200" name="common_list[add_nav][title][]" value="'.$Nav['title'].'">',
			($Nav['icon'] ? '<a href="'.$Nav['icon'].'" target="_blank"><img src="'.$Nav['icon'].'" style="height:30px;margin:0 5px 0 0;"></a>' : '').'<input type="hidden" size="30" name="common_list[add_nav][icon][]" value="'.$Nav['icon'].'" /><input name="common_list[add_nav][file_icon][]" value="" class="txt uploadbtn" type="file" style="width:266px;">',
			'<input type="text" class="form-control w400" name="common_list[add_nav][link][]" value="'.$Nav['link'].'">',
			'<a href="#" onclick="deleterow(this)" class="btn btn-sm btn-danger-outline">&#21024;&#38500;</a>',
		));
	}
	echo '<tr class="hover"><td class="tc" colspan="10"><a href="#" onclick="addrow(this,addnavrowtypedata, 0)"><i class="fa fa-plus" style="margin-right:5px"></i>&#28155;&#21152;&#23548;&#33322;</a></td></tr>';
	showtablefooter(); /*dism��taobao��com*/
	//�������� End

	//���԰���ҳ����
	echo <<<HTML
		<script type="text/JavaScript">
		var pcnavrowtypedata = [
			[
				[1, '<input type="text" class="form-control w50" name="common_list[pc_nav][displayorder][]" value="">'],
				[1, '<input type="text" class="form-control w100" name="common_list[pc_nav][title][]" value="">'],
				[1, '<input type="text" class="form-control w400" name="common_list[pc_nav][link][]" value="">'],
				[1, '<a href="#" onclick="deleterow(this)" class="btn btn-sm btn-danger-outline">&#21024;&#38500;</a>']
			],
		];
		</script>
HTML;

	echo '<div class="border box-header margin-top-10"><h5 class="box-title">&#30005;&#33041;&#29256;&#23548;&#33322; - <span class="font-size-12">&#91;&#115;&#105;&#116;&#101;&#117;&#114;&#108;&#93;&#20195;&#34920;&#24403;&#21069;&#22495;&#21517;</span></h5></div>';
	showtableheader('','table table-bordered table-hover display nowrap table-responsive dataTable');
	showsubtitle(array(
		'&#26174;&#31034;&#39034;&#24207;',
		'&#23548;&#33322;&#26631;&#39064;',
		'&#23548;&#33322;&#38142;&#25509;',
		'&#21024;&#38500;'
	),'header tbm tc');
	$PcNavArray = $common_setting ? $setting['pc_nav'] : array(
		array('displayorder'=>'0','title'=>'&#39318;&#39029;','link'=>'[siteurl]plugin.php?id=fn_renovation'),
		array('displayorder'=>'1','title'=>'&#35774;&#35745;&#19982;&#25253;&#20215;','link'=>'[siteurl]plugin.php?id=fn_renovation&m=design'),
		array('displayorder'=>'2','title'=>'&#25928;&#26524;&#22270;','link'=>'[siteurl]plugin.php?id=fn_renovation&m=list_case&class=1'),
		array('displayorder'=>'3','title'=>'&#25214;&#25105;&#23478;','link'=>'[siteurl]plugin.php?id=fn_renovation&m=list_community'),
		array('displayorder'=>'4','title'=>'&#25214;&#35013;&#20462;&#20844;&#21496;','link'=>'[siteurl]plugin.php?id=fn_renovation&m=list_company'),
		array('displayorder'=>'5','title'=>'&#36873;&#24314;&#26448;','link'=>'[siteurl]plugin.php?id=fn_renovation&m=list_material_company')
	);
	foreach ($PcNavArray as $Key => $Nav) {
		showtablerow('', array('class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
			'<input type="text" class="form-control w50" name="common_list[pc_nav][displayorder][]" value="'.$Nav['displayorder'].'">',
			'<input type="text" class="form-control w100" name="common_list[pc_nav][title][]" value="'.$Nav['title'].'">',
			'<input type="text" class="form-control w400" name="common_list[pc_nav][link][]" value="'.$Nav['link'].'">',
			'<a href="#" onclick="deleterow(this)" class="btn btn-sm btn-danger-outline">&#21024;&#38500;</a>',
		));
	}
	echo '<tr class="hover"><td class="tc" colspan="10"><a href="#" onclick="addrow(this,pcnavrowtypedata, 0)"><i class="fa fa-plus" style="margin-right:5px"></i>&#28155;&#21152;&#23548;&#33322;</a></td></tr>';
	showtablefooter(); /*dism��taobao��com*/
	//���԰���ҳ���� End

	//���԰���ҳС����
	echo <<<HTML
		<script type="text/JavaScript">
		var pcminnavrowtypedata = [
			[
				[1, '<input type="text" class="form-control w50" name="common_list[pc_min_nav][displayorder][]" value="">'],
				[1, '<input type="text" class="form-control w100" name="common_list[pc_min_nav][title][]" value="">'],
				[1, '<input type="text" class="form-control w200" name="common_list[pc_min_nav][desc][]" value="">'],
				[1, '<input name="common_list[pc_min_nav][file_icon][]" value="" class="txt uploadbtn" type="file" style="width:266px;">'],
				[1, '<input type="text" class="form-control w400" name="common_list[pc_min_nav][link][]" value="">'],
				[1, '<a href="#" onclick="deleterow(this)" class="btn btn-sm btn-danger-outline">&#21024;&#38500;</a>']
			],
		];
		</script>
HTML;

	echo '<div class="border box-header margin-top-10"><h5 class="box-title">&#30005;&#33041;&#29256;&#23567;&#23548;&#33322; - <span class="font-size-12">&#91;&#115;&#105;&#116;&#101;&#117;&#114;&#108;&#93;&#20195;&#34920;&#24403;&#21069;&#22495;&#21517;</span></h5></div>';
	showtableheader('','table table-bordered table-hover display nowrap table-responsive dataTable');
	showsubtitle(array(
		'&#26174;&#31034;&#39034;&#24207;',
		'&#23548;&#33322;&#26631;&#39064;',
		'&#23548;&#33322;&#25551;&#36848;',
		'&#23548;&#33322;&#22270;&#26631;',
		'&#23548;&#33322;&#38142;&#25509;',
		'&#21024;&#38500;'
	),'header tbm tc');
	$PcMinNavArray = $common_setting ? $setting['pc_min_nav'] : array(
		array('displayorder'=>'0','title'=>'&#20813;&#36153;&#35774;&#35745;','desc'=>'&#33719;&#21462;&#19977;&#20221;&#35774;&#35745;&#26041;&#26696;','icon'=>'/source/plugin/fn_renovation/static/images/index-entries-1.jpg','link'=>'[siteurl]plugin.php?id=fn_renovation&m=design'),
		array('displayorder'=>'1','title'=>'&#20813;&#36153;&#25253;&#20215;','desc'=>'&#31639;&#31639;&#35013;&#20462;&#35201;&#33457;&#22810;&#23569;&#38065;','icon'=>'/source/plugin/fn_renovation/static/images/index-entries-2.jpg','link'=>'[siteurl]plugin.php?id=fn_renovation&m=free_quote'),
		array('displayorder'=>'2','title'=>'&#20840;&#23627;&#23450;&#21046;','desc'=>'&#35753;&#23478;&#36731;&#26494;&#25193;&#22823;&#110;&#24179;&#31859;','icon'=>'/source/plugin/fn_renovation/static/images/index-entries-3.jpg','link'=>'[siteurl]plugin.php?id=fn_renovation&m=design'),
		array('displayorder'=>'3','title'=>'&#20840;&#31243;&#36136;&#26816;','desc'=>'&#35831;&#20010;&#36136;&#26816;&#30447;&#24037;&#22320;','icon'=>'/source/plugin/fn_renovation/static/images/index-entries-4.jpg','link'=>'[siteurl]plugin.php?id=fn_renovation&m=inspect')
	);
	foreach ($PcMinNavArray as $Key => $Nav) {
		showtablerow('', array('class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
			'<input type="text" class="form-control w50" name="common_list[pc_min_nav][displayorder][]" value="'.$Nav['displayorder'].'">',
			'<input type="text" class="form-control w100" name="common_list[pc_min_nav][title][]" value="'.$Nav['title'].'">',
			'<input type="text" class="form-control w200" name="common_list[pc_min_nav][desc][]" value="'.$Nav['desc'].'">',
			($Nav['icon'] ? '<a href="'.$Nav['icon'].'" target="_blank"><img src="'.$Nav['icon'].'" style="height:30px;margin:0 5px 0 0;"></a>' : '').'<input type="hidden" size="30" name="common_list[pc_min_nav][icon][]" value="'.$Nav['icon'].'" /><input name="common_list[pc_min_nav][file_icon][]" value="" class="txt uploadbtn" type="file" style="width:266px;">',
			'<input type="text" class="form-control w400" name="common_list[pc_min_nav][link][]" value="'.$Nav['link'].'">',
			'<a href="#" onclick="deleterow(this)" class="btn btn-sm btn-danger-outline">&#21024;&#38500;</a>',
		));
	}
	echo '<tr class="hover"><td class="tc" colspan="10"><a href="#" onclick="addrow(this,pcminnavrowtypedata, 0)"><i class="fa fa-plus" style="margin-right:5px"></i>&#28155;&#21152;&#23548;&#33322;</a></td></tr>';
	showtablefooter(); /*dism��taobao��com*/
	//���԰���ҳС���� End

	echo <<<HTML
	</div>
	<!-- �������� end  -->
HTML;

	echo <<<HTML
	<!-- ��ҳ����  -->
	<div class="tab-pane" id="index" role="tabpanel" aria-expanded="false">
HTML;
	
	echo '<div class="form-group row"><label class="col-sm-1 col-form-label">&#27178;&#24133;&#22270;&#29255;<br>&#23610;&#23544;&#24314;&#35758;&#54;&#52;&#48;&#32;&#42;&#32;&#51;&#48;&#48;</label><div class="col-sm-9"><div class="UploadBanner"><div class="PhotoControl ClickPhotoControl" id="Banners"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';

	showsetting('&#26696;&#20363;&#35843;&#29992;&#26465;&#25968;', 'setting[index_case_num]', $setting['index_case_num'] ? $setting['index_case_num'] : '5', 'text');

	showsetting('&#20840;&#26223;&#26696;&#20363;&#35843;&#29992;&#26465;&#25968;', 'setting[index_case2_num]', $setting['index_case2_num'] ? $setting['index_case2_num'] : '6', 'text');

	showsetting('&#26174;&#31034;&#34920;&#21333;', 'setting[HomeForm]', $common_setting ? $setting['HomeForm'] : 1, 'radio');
	
	showsetting('&#26174;&#31034;&#25214;&#35774;&#35745;', 'setting[HomeCase]', $common_setting ? $setting['HomeCase'] : 1, 'radio');
	
	showsetting('&#26174;&#31034;&#28909;&#38376;&#21830;&#21697;', 'setting[HomeGoods]', $common_setting ? $setting['HomeGoods'] : 1, 'radio');

	showsetting('&#26174;&#31034;&#24314;&#26448;&#20844;&#21496;', 'setting[HomeMaterialCompany]', $common_setting ? $setting['HomeMaterialCompany'] : 1, 'radio');

	showsetting('&#26174;&#31034;&#30475;&#20840;&#26223;', 'setting[HomePanorama]', $common_setting ? $setting['HomePanorama'] : 1, 'radio');

	echo '<div class="form-group row"><label class="col-sm-1 col-form-label">&#23548;&#33322;&#24213;&#37096;&#24191;&#21578;<br>&#24314;&#35758;&#23610;&#23544;&#65306;&#54;&#52;&#48;&#32;&#42;&#32;&#57;&#48;</label><div class="col-sm-9"><div class="UploadBanner"><div class="PhotoControl ClickPhotoControl" id="nav_bottom_ad"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';

	echo <<<HTML
	</div>
	<!-- ��ҳ���� end  -->
HTML;

	echo <<<HTML
	<!-- ���԰�����  -->
	<div class="tab-pane" id="pc" role="tabpanel" aria-expanded="false">
HTML;
	showsetting('&#30005;&#33041;&#29256;&#24320;&#21551;',array('setting[PcQrSwitch]', array(
		array('1','&#26159;', array('PcSwitch_1' => '','PcSwitch_0' => 'none')),
		array('0','&#21542;', array('PcSwitch_1' => 'none','PcSwitch_0' => '')),
	), TRUE),$common_setting ? $setting['PcQrSwitch'] : 1, 'mradio');

	showtagheader('div', 'PcSwitch_1', $setting['PcQrSwitch'] == 1 || !$common_setting ? true : '','ssub');
		
		$setting['PcLogoPath'] = $setting['PcLogoPath'] ? $setting['PcLogoPath'] : '/source/plugin/fn_renovation/static/images/pc_logo.png';
		$PcLogoPathHtml = '<a href="'.$setting['PcLogoPath'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['PcLogoPath'].'" height="35"/></a>&#24314;&#35758;&#32;&#50;&#53;&#48;&#32;&#42;&#32;&#54;&#51;';
		showsetting('&#76;&#111;&#103;&#111;&#36335;&#24452;', 'new_PcLogoPath',$setting['PcLogoPath'], 'filetext', '', 0, $PcLogoPathHtml);

		showsetting('&#39318;&#39029;&#22836;&#37096;&#27426;&#36814;&#35821;', 'setting[pc_head_tips]', $setting['pc_head_tips'] ? $setting['pc_head_tips'] : '&#24744;&#22909;&#65292;&#27426;&#36814;&#26469;&#21040;<span class=Color>&#39134;&#40479;</span>&#35013;&#20462;&#32593;', 'text');

		showsetting('&#24213;&#37096;&#25991;&#23383;', 'setting[PcFooterContent]', $setting['PcFooterContent'] ? $setting['PcFooterContent'] : '<p>&#20405;&#26435;&#20030;&#25253;&#65306;&#26412;&#39029;&#38754;&#25152;&#28041;&#20869;&#23481;&#20026;&#29992;&#25143;&#21457;&#34920;&#24182;&#19978;&#20256;&#65292;&#30456;&#24212;&#30340;&#27861;&#24459;&#36131;&#20219;&#30001;&#29992;&#25143;&#33258;&#34892;&#25215;&#25285;&#65307;</p>
<p>&#24191;&#21578;&#28909;&#32447;&#65306;15918762515 &#20256;&#30495;&#65306;15918762515</p>
<p>&#29256;&#26435;&#25152;&#26377;:&#39134;&#40479;&#35013;&#20462;&#32593;</p>
<p>&#20449;&#24687;&#20135;&#19994;&#37096;&#22791;&#26696;/&#35768;&#21487;&#35777;&#32534;&#21495;&#65306;&#31908;ICP&#22791;06049053&#21495;</p>', 'textarea');
		
		showsetting('&#39318;&#39029;&#83;&#69;&#79;&#26631;&#39064;&#25551;&#36848;', 'setting[PcHomeSeo]', $setting['PcHomeSeo'], 'textarea','','','&#26684;&#24335;&#65306;&#26631;&#39064;&#35;&#20851;&#38190;&#35789;&#35;&#25551;&#36848;');

		showsetting('&#39318;&#39029;&#34920;&#21333;&#25991;&#26696;', 'setting[PcFormContent]', $setting['PcFormContent'] ? $setting['PcFormContent'] : "2|&#20813;&#36153;<br>&#35774;&#35745;|&#20248;&#36136;&#35013;&#20462;&#20844;&#21496;&#20219;&#24744;&#25361;,&#24744;&#23558;&#33719;&#24471;6&#39033;&#20813;&#36153;&#26381;&#21153;|&#30446;&#21069;&#24050;&#20026;<span class='Color font-weight-bold'>96008</span>&#20301;&#19994;&#20027;&#25552;&#20379;&#20102;&#35774;&#35745;&#26041;&#26696;4&#23478;&#20844;&#21496;&#35774;&#35745;&#31295;&#65292;&#30475;&#35841;&#30340;&#35774;&#35745;&#26356;&#35753;&#24744;&#28385;&#24847;
1|&#20813;&#36153;<br>&#25253;&#20215;|&#20813;&#36153;&#33719;&#24471;4&#20221;&#25253;&#20215;&#28165;&#21333;&#65292;&#36731;&#26494;&#35299;&#20915;&#39044;&#31639;&#28902;&#24700;|&#30446;&#21069;&#24050;&#20026;<span class='Color font-weight-bold'>96008</span>&#20301;&#19994;&#20027;&#20813;&#36153;&#25104;&#21151;&#33719;&#21462;&#25253;&#20215;&#25105;&#20204;&#25552;&#20379;&#30340;&#35813;&#39033;&#26381;&#21153;&#20026;&#20813;&#36153;&#26381;&#21153;&#19981;&#25910;&#21462;&#36153;&#29992;
3|&#29305;&#24800;<br>&#29305;&#24800;|&#19987;&#19994;&#26816;&#27979;15&#22823;&#39033;30&#23567;&#39033;&#65292;&#25151;&#23627;&#36136;&#37327;&#20840;&#26816;&#27979;|<span class='Color font-weight-bold'>&#39134;&#40479;&#23478;&#23621;</span>&#32593;&#21451;&#21487;&#20139;&#19987;&#19994;&#39564;&#25151;&#20248;&#24800;&#26412;&#22320;&#23478;&#23621;&#26381;&#21153;&#24179;&#21488;&#65292;&#25968;&#19975;&#19994;&#20027;&#20849;&#21516;&#36873;&#25321;
3|&#19987;&#19994;<br>&#30417;&#29702;|&#19987;&#19994;&#30417;&#29702;&#33410;&#28857;&#39564;&#25910;&#12289;&#20840;&#31243;&#39564;&#25910;&#20219;&#20320;&#36873;|&#20445;&#38556;&#19994;&#20027;&#35013;&#20462;&#36136;&#37327;&#65292;&#26460;&#32477;&#20599;&#24037;&#20943;&#26009;&#65292;&#31532;&#19968;&#23478;&#23621;&#26381;&#21153;&#24179;&#21488;&#65292;&#25968;&#19975;&#19994;&#20027;&#20849;&#21516;&#36873;&#25321;",'textarea','','','&#19968;&#34892;&#19968;&#25991;&#26696;&#65292;&#26684;&#24335;&#65306;&#34920;&#21333;&#31867;&#22411;(1=&#39044;&#31639;,2=&#35774;&#35745;,3=&#39564;&#25151;)|&#23548;&#33322;&#26631;&#39064;|&#26631;&#39064;|&#20869;&#23481;&#65281;&#65281;&#65281;&#20363;&#22914;<br>2|&#20813;&#36153;&#35774;&#35745;|&#26631;&#39064;1|&#20869;&#23481;1<br>1|&#20813;&#36153;&#25253;&#20215;|&#26631;&#39064;2|&#20869;&#23481;2');

		showsetting('&#21451;&#24773;&#38142;&#25509;', 'setting[PcFriendLink]', $setting['PcFriendLink'], 'textarea','','','&#19968;&#34892;&#19968;&#38142;&#25509;&#65292;&#26684;&#24335;&#65306;&#25991;&#23383;&#124;&#38142;&#25509;&#65281;&#65281;&#65281;&#20363;&#22914;<br>&#39134;&#40479;&#49;&#124;&#104;&#116;&#116;&#112;&#58;&#47;&#47;&#100;&#101;&#118;&#46;&#102;&#110;&#109;&#111;&#116;&#111;&#46;&#99;&#111;&#109;<br>&#39134;&#40479;&#50;&#124;&#104;&#116;&#116;&#112;&#58;&#47;&#47;&#100;&#101;&#118;&#46;&#102;&#110;&#109;&#111;&#116;&#111;&#46;&#99;&#111;&#109;');

		showsetting('&#20250;&#21592;&#20013;&#24515;&#22836;&#20687;&#24213;&#37096;&#25551;&#36848;', 'setting[pc_user_head_desc]', $setting['pc_user_head_desc'] ? $setting['pc_user_head_desc'] : '&#23562;&#25964;&#30340;&#29992;&#25143;&#65292;&#27426;&#36814;&#20351;&#29992;&#35013;&#20462;&#24314;&#26448;&#31995;&#32479;&#65292;&#23458;&#26381;&#24494;&#20449;&#65306;&#57;&#53;&#49;&#48;&#54;&#53;&#52;', 'text');

		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">&#27178;&#24133;<br>&#24314;&#35758;&#65306;&#49;&#57;&#50;&#48;&#32;&#42;&#32;460</label><div class="col-sm-9"><div class="UploadBanner"><div class="PhotoControl ClickPhotoControl" id="pc_banners"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';

		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">&#24213;&#37096;&#20108;&#32500;&#30721;</label><div class="col-sm-9"><div class="UploadBanner"><div class="PhotoControl ClickPhotoControl" id="footer_qr_list"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';

		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">&#39318;&#39029;&#35013;&#20462;&#20844;&#21496;&#39030;&#37096;&#24191;&#21578;<br>&#24314;&#35758;&#65306;&#49;&#50;&#48;&#48;&#32;&#42;&#32;&#57;&#48;</label><div class="col-sm-9"><div class="UploadBanner"><div class="PhotoControl ClickPhotoControl" id="pc_home_ad_1"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';

		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">&#39318;&#39029;&#25928;&#26524;&#22270;&#39030;&#37096;&#24191;&#21578;<br>&#24314;&#35758;&#65306;&#49;&#50;&#48;&#48;&#32;&#42;&#32;&#57;&#48;</label><div class="col-sm-9"><div class="UploadBanner"><div class="PhotoControl ClickPhotoControl" id="pc_home_ad_2"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';

		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">&#39318;&#39029;&#24314;&#26448;&#21830;&#23478;&#39030;&#37096;&#24191;&#21578;<br>&#24314;&#35758;&#65306;&#49;&#50;&#48;&#48;&#32;&#42;&#32;&#57;&#48;</label><div class="col-sm-9"><div class="UploadBanner"><div class="PhotoControl ClickPhotoControl" id="pc_home_ad_3"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';

	showtagfooter('div');

	showtagheader('div', 'PcSwitch_0', !$setting['PcSwitch'] && !$common_setting ? true : '','ssub');
		showsetting('&#30005;&#33041;&#29256;&#20108;&#32500;&#30721;&#25991;&#23383;', 'setting[PcQrText]', $setting['PcQrText'] ? $setting['PcQrText'] : '&#25195;&#19968;&#25195;&#65292;&#25163;&#26426;&#27983;&#35272;&#35013;&#20462;&#26356;&#26041;&#20415;', 'text');
	showtagfooter('div');

	echo <<<HTML
	</div>
	<!-- ���԰����� end  -->
HTML;

	echo <<<HTML
	<!-- װ������  -->
	<div class="tab-pane" id="renovation" role="tabpanel" aria-expanded="false">
HTML;

	showsetting('&#20844;&#21496;&#22312;&#32447;&#20837;&#39547;', 'setting[CompanyOnlineSwitch]', $common_setting ? $setting['CompanyOnlineSwitch'] : 1, 'radio','','','&#20844;&#21496;&#26159;&#21542;&#22312;&#32447;&#20837;&#39547;&#65292;&#21542;&#30340;&#35805;&#65292;&#28857;&#20987;&#20837;&#39547;&#25353;&#38062;&#21017;&#24377;&#20986;&#23458;&#26381;&#32852;&#31995;&#26041;&#24335;');

	showsetting('&#20844;&#21496;&#38750;&#20250;&#21592;&#36890;&#30693;', 'setting[CompanyNotice]', $common_setting ? $setting['CompanyNotice'] : 1, 'radio','','','&#20844;&#21496;&#38750;&#20250;&#21592;&#26159;&#21542;&#36890;&#30693;&#29992;&#25143;');

	showsetting('&#20844;&#21496;&#24320;&#21551;&#26631;&#27880;', 'setting[CompanyMapSwitch]', $common_setting ? $setting['CompanyMapSwitch'] : 1, 'radio','','','&#20844;&#21496;&#26159;&#21542;&#24320;&#21551;&#26631;&#27880;&#65292;&#26631;&#27880;&#21518;&#21487;&#23548;&#33322;');

	showsetting('&#20844;&#21496;&#22871;&#39184;&#32493;&#36153;&#21472;&#21152;&#27425;&#25968;', 'setting[GroupSuperpositionSwitch]', $setting['GroupSuperpositionSwitch'], 'radio','','','&#20844;&#21496;&#32493;&#36153;&#22871;&#39184;&#26159;&#21542;&#21472;&#21152;&#65292;&#21457;&#24067;&#21830;&#21697;&#24635;&#25968;&#47;&#26696;&#20363;&#24635;&#25968;');

	showsetting('&#20844;&#21496;&#20837;&#39547;&#26159;&#21542;&#23457;&#26680;', 'setting[CompanyDisplaySwitch]', $common_setting ? $setting['CompanyDisplaySwitch'] : 1, 'radio');

	showsetting('&#20844;&#21496;&#33829;&#19994;&#25191;&#29031;&#26159;&#21542;&#24517;&#22635;', 'setting[CompanyLicenseSwitch]', $setting['CompanyLicenseSwitch'], 'radio');

	showsetting('&#20844;&#21496;&#21047;&#26032;&#25490;&#21517;&#37329;&#39069;', 'setting[company_refresh_money]', $common_setting ? $setting['company_refresh_money'] : '1', 'text','','','&#48;&#25110;&#32773;&#31354;&#20195;&#34920;&#19981;&#24320;&#21551;');
	
	showsetting('&#23567;&#21306;&#24037;&#22320;&#35843;&#29992;&#26465;&#25968;', 'setting[community_build_num]', $setting['community_build_num'] ? $setting['community_build_num'] : '10', 'text');

	showsetting('&#20844;&#21496;&#24037;&#22320;&#35843;&#29992;&#26465;&#25968;', 'setting[company_build_num]', $setting['company_build_num'] ? $setting['company_build_num'] : '10', 'text');

	showsetting('&#23567;&#21306;&#26696;&#20363;&#35843;&#29992;&#26465;&#25968;', 'setting[community_case_num]', $setting['community_case_num'] ? $setting['community_case_num'] : '4', 'text');

	showsetting('&#20844;&#21496;&#26696;&#20363;&#35843;&#29992;&#26465;&#25968;', 'setting[company_case_num]', $setting['company_case_num'] ? $setting['company_case_num'] : '4', 'text');

	showsetting('&#23567;&#21306;&#20840;&#26223;&#26696;&#20363;&#35843;&#29992;&#26465;&#25968;', 'setting[community_case2_num]', $setting['community_case2_num'] ? $setting['community_case2_num'] : '5', 'text');

	showsetting('&#20844;&#21496;&#20840;&#26223;&#26696;&#20363;&#35843;&#29992;&#26465;&#25968;', 'setting[company_case2_num]', $setting['company_case2_num'] ? $setting['company_case2_num'] : '5', 'text');

	showsetting('&#26696;&#20363;&#21047;&#26032;&#37329;&#39069;', 'setting[CaseRefreshMoney]', $common_setting ? $setting['CaseRefreshMoney'] : '1', 'text');

	showsetting('&#24453;&#23457;&#26680;&#21047;&#26032;&#25552;&#31034;&#35821;&#32;', 'setting[NoDisplayTips]', $setting['NoDisplayTips'] ? $setting['NoDisplayTips'] : '&#35813;&#20449;&#24687;&#27491;&#22312;&#23457;&#26680;&#20013;&#65292;&#26242;&#19981;&#33021;&#21047;&#26032;<br>&#35831;&#32852;&#31995;&#31649;&#29702;&#21592;&#24494;&#20449;&#65306;<span class=FColor>8888888</span>&#24555;&#36895;&#23457;&#26680;', 'textarea');

	showsetting('&#35774;&#35745;&#22242;&#38431;&#32463;&#39564;&#26631;&#31614;', 'setting[design_experience]', $setting['design_experience'] ? $setting['design_experience'] : '1=1&#24180;&#32463;&#39564;
2=2&#24180;&#32463;&#39564;
3=3&#24180;&#32463;&#39564;
4=4&#24180;&#32463;&#39564;
5=5&#24180;&#32463;&#39564;
6=6&#24180;&#32463;&#39564;
7=7&#24180;&#32463;&#39564;
8=8&#24180;&#32463;&#39564;
9=9&#24180;&#32463;&#39564;
10=10&#20197;&#19978;&#32463;&#39564;','textarea','','','&#19968;&#34892;&#19968;&#26631;&#31614;&#65281;&#65281;&#65281;&#26684;&#24335;&#65306;&#49;&#61;&#26631;&#31614;&#19968;&#65292;&#50;&#61;&#26631;&#31614;&#20108;&#65281;&#65281;&#65281;&#20363;&#22914;&#65306;<br>&#49;&#61;&#26631;&#31614;&#19968;<br>&#50;&#61;&#26631;&#31614;&#20108;');

	showsetting('&#39118;&#26684;&#26631;&#31614;', 'setting[style]', $setting['style'] ? $setting['style'] : '1=&#22320;&#20013;&#28023;
2=&#20013;&#24335;
3=&#32654;&#24335;
4=&#27431;&#24335;
5=&#28151;&#25645;
6=&#30000;&#22253;
7=&#29616;&#20195;
8=&#26032;&#21476;&#20856;
9=&#19996;&#21335;&#20122;
10=&#26085;&#24335;
11=&#23452;&#23478;
12=&#21271;&#27431;
13=&#31616;&#27431;
14=&#31616;&#32422;
15=&#38889;&#24335;
16=&#27861;&#24335;
17=&#33521;&#24335;
18=&#21488;&#28286;&#39118;
19=&#24037;&#19994;&#39118;
20=&#28207;&#24335;
21=&#26032;&#20013;&#24335;','textarea','','','&#19968;&#34892;&#19968;&#26631;&#31614;&#65281;&#65281;&#65281;&#26684;&#24335;&#65306;&#49;&#61;&#26631;&#31614;&#19968;&#65292;&#50;&#61;&#26631;&#31614;&#20108;&#65281;&#65281;&#65281;&#20363;&#22914;&#65306;<br>&#49;&#61;&#26631;&#31614;&#19968;<br>&#50;&#61;&#26631;&#31614;&#20108;');

	showsetting('&#25143;&#22411;&#26631;&#31614;', 'setting[apartment]', $setting['apartment'] ? $setting['apartment'] : '1=&#23567;&#25143;&#22411;
2=&#20108;&#23460;
3=&#19977;&#23460;
4=&#22235;&#23460;
5=&#20844;&#23507;
6=&#21035;&#22661;
7=&#22797;&#24335;
8=&#33258;&#24314;
9=&#25490;&#23627;
10=&#20844;&#20849;&#31354;&#38388;','textarea','','','&#19968;&#34892;&#19968;&#26631;&#31614;&#65281;&#65281;&#65281;&#26684;&#24335;&#65306;&#49;&#61;&#26631;&#31614;&#19968;&#65292;&#50;&#61;&#26631;&#31614;&#20108;&#65281;&#65281;&#65281;&#20363;&#22914;&#65306;<br>&#49;&#61;&#26631;&#31614;&#19968;<br>&#50;&#61;&#26631;&#31614;&#20108;');

	showsetting('&#23616;&#37096;&#26631;&#31614;', 'setting[local]', $setting['local'] ? $setting['local'] : '1=&#27249;&#26588;
2=&#27067;&#27067;&#31859;
3=&#34915;&#24125;&#38388;
4=&#34915;&#26588;
5=&#32972;&#26223;&#22681;
6=&#38548;&#26029;
7=&#39128;&#31383;
8=&#21338;&#21476;&#26550;
9=&#38401;&#27004;
10=&#38544;&#24418;&#38376;
11=&#21543;&#21488;
12=&#21543;&#21488;
13=&#37202;&#26588;
14=&#38795;&#26588;
15=&#29031;&#29255;&#22681;
16=&#28783;&#20855;
17=&#36807;&#36947;
18=&#21514;&#39030;
19=&#31383;&#24088;
20=&#25670;&#20214;
21=&#27927;&#25163;&#21488;
22=&#27004;&#26799;','textarea','','','&#19968;&#34892;&#19968;&#26631;&#31614;&#65281;&#65281;&#65281;&#26684;&#24335;&#65306;&#49;&#61;&#26631;&#31614;&#19968;&#65292;&#50;&#61;&#26631;&#31614;&#20108;&#65281;&#65281;&#65281;&#20363;&#22914;&#65306;<br>&#49;&#61;&#26631;&#31614;&#19968;<br>&#50;&#61;&#26631;&#31614;&#20108;');

	showsetting('&#26696;&#20363;&#31867;&#22411;&#26631;&#31614;', 'setting[case_type]', $setting['case_type'] ? $setting['case_type'] : '1=&#25928;&#26524;&#22270;
2=&#23454;&#26223;&#22270;','textarea','','','&#19968;&#34892;&#19968;&#26631;&#31614;&#65281;&#65281;&#65281;&#26684;&#24335;&#65306;&#49;&#61;&#26631;&#31614;&#19968;&#65292;&#50;&#61;&#26631;&#31614;&#20108;&#65281;&#65281;&#65281;&#20363;&#22914;&#65306;<br>&#49;&#61;&#26631;&#31614;&#19968;<br>&#50;&#61;&#26631;&#31614;&#20108;');

	showsetting('&#26696;&#20363;&#37329;&#39069;&#26631;&#31614;', 'setting[case_money]', $setting['case_money'] ? $setting['case_money'] : '1=5&#19975;&#20197;&#19979;
2=5&#19975;-8&#19975;
3=8&#19975;-12&#19975;
4=12&#19975;-18&#19975;
5=18&#19975;-30&#19975;
6=30&#19975;-50&#19975;
7=50&#19975;&#20197;&#19978;','textarea','','','&#19968;&#34892;&#19968;&#26631;&#31614;&#65281;&#65281;&#65281;&#26684;&#24335;&#65306;&#49;&#61;&#26631;&#31614;&#19968;&#65292;&#50;&#61;&#26631;&#31614;&#20108;&#65281;&#65281;&#65281;&#20363;&#22914;&#65306;<br>&#49;&#61;&#26631;&#31614;&#19968;<br>&#50;&#61;&#26631;&#31614;&#20108;');

	showsetting('&#31354;&#38388;&#26631;&#31614;', 'setting[space]', $setting['space'] ? $setting['space'] : '1=&#21416;&#25151;
2=&#23458;&#21381;
3=&#21351;&#23460;
4=&#20070;&#25151;
5=&#39184;&#21381;
6=&#21355;&#29983;&#38388;
7=&#38451;&#21488;
8=&#20799;&#31461;&#25151;
9=&#29572;&#20851;
10=&#33457;&#22253;
11=&#22320;&#19979;&#23460;
12=&#22823;&#21381;
13=&#20241;&#38386;&#21306;','textarea','','','&#19968;&#34892;&#19968;&#26631;&#31614;&#65281;&#65281;&#65281;&#26684;&#24335;&#65306;&#49;&#61;&#26631;&#31614;&#19968;&#65292;&#50;&#61;&#26631;&#31614;&#20108;&#65281;&#65281;&#65281;&#20363;&#22914;&#65306;<br>&#49;&#61;&#26631;&#31614;&#19968;<br>&#50;&#61;&#26631;&#31614;&#20108;');
	
	showsetting('&#34920;&#21333;&#25512;&#36865;&#25991;&#26696;', 'setting[FormPush]', $setting['FormPush'] ? $setting['FormPush'] : '&#23562;&#25964;&#30340;&#20250;&#21592;&#65292;&#26377;&#23458;&#25143;&#24819;[{form_type}]&#65292;&#22995;&#21517;&#65306;{name}&#65292;&#32852;&#31995;&#26041;&#24335;&#65306;{phone}&#65292;&#35831;&#30331;&#24405;&#39134;&#40479;&#35013;&#20462;&#32593;&#26597;&#30475;', 'textarea','','','&#65;&#80;&#80;&#47;&#100;&#122;&#36890;&#30693;&#25991;&#26696;<br>&#32;&#123;&#102;&#111;&#114;&#109;&#95;&#116;&#121;&#112;&#101;&#125;&#20195;&#34920;&#34920;&#21333;&#31867;&#22411;&#65292;&#123;&#110;&#97;&#109;&#101;&#125;&#20195;&#34920;&#22995;&#21517;&#65292;&#123;&#112;&#104;&#111;&#110;&#101;&#125;&#20195;&#34920;&#25163;&#26426;&#21495;&#65281;&#65281;&#65281;');

	$setting['CommunityDefaultPath'] = $setting['CommunityDefaultPath'] ? $setting['CommunityDefaultPath'] : '/source/plugin/fn_renovation/static/images/community_thumbnail.jpg';
	$CommunityDefaultPathHtml = '<a href="'.$setting['CommunityDefaultPath'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['CommunityDefaultPath'].'" height="55"/></a>&#24314;&#35758;&#23610;&#23544;&#65306;&#49;&#53;&#48;&#32;&#42;&#32;&#57;&#53;';
	showsetting('&#23567;&#21306;&#40664;&#35748;&#32553;&#30053;&#22270;', 'new_CommunityDefaultPath',$setting['CommunityDefaultPath'], 'filetext', '', 0, $CommunityDefaultPathHtml);
	
	$setting['CompanyVerifyPath'] = $setting['CompanyVerifyPath'] ? $setting['CompanyVerifyPath'] : '/source/plugin/fn_renovation/static/images/verify.png';
	$CompanyVerifyPathHtml = '<a href="'.$setting['CompanyVerifyPath'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['CompanyVerifyPath'].'" height="15"/></a>&#24314;&#35758;&#65306;&#56;&#48;&#32;&#42;&#32;&#50;&#56;';
	showsetting('&#20844;&#21496;&#35748;&#35777;&#22270;&#26631;', 'new_CompanyVerifyPath',$setting['CompanyVerifyPath'], 'filetext', '', 0, $CompanyVerifyPathHtml);
	
	$setting['MerchantEntry'] = $setting['MerchantEntry'] ? $setting['MerchantEntry'] : '/source/plugin/fn_renovation/static/images/sjrz.png';
	$MerchantEntryHtml = '<a href="'.$setting['MerchantEntry'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['MerchantEntry'].'" height="55"/></a>';
	showsetting('&#20844;&#21496;&#20837;&#39547;&#25353;&#38062;&#22270;&#26631;', 'new_MerchantEntry',$setting['MerchantEntry'], 'filetext', '', 0, $MerchantEntryHtml);

	$setting['ManagementCompany'] = $setting['ManagementCompany'] ? $setting['ManagementCompany'] : '/source/plugin/fn_renovation/static/images/glgs.png';
	$ManagementCompanyHtml = '<a href="'.$setting['ManagementCompany'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['ManagementCompany'].'" height="55"/></a>';
	showsetting('&#31649;&#29702;&#20844;&#21496;&#25353;&#38062;&#22270;&#26631;', 'new_ManagementCompany',$setting['ManagementCompany'], 'filetext', '', 0, $ManagementCompanyHtml);

	$setting['CompanyHotPath'] = $setting['CompanyHotPath'] ? $setting['CompanyHotPath'] : '/source/plugin/fn_renovation/static/images/hot.png';
	$CompanyHotPathHtml = '<a href="'.$setting['CompanyHotPath'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['CompanyHotPath'].'" height="55"/></a>';
	showsetting('&#20844;&#21496;&#25512;&#33616;&#22270;&#26631;', 'new_CompanyHotPath',$setting['CompanyHotPath'], 'filetext', '', 0, $CompanyHotPathHtml);

	echo '<div class="form-group row"><label class="col-sm-1 col-form-label">&#20250;&#21592;&#20013;&#24515;&#24191;&#21578;<br>&#24314;&#35758;&#23610;&#23544;&#65306;&#55;&#53;&#48;&#32;&#42;&#32;&#49;&#53;&#48;<br>&#91;&#115;&#105;&#116;&#101;&#117;&#114;&#108;&#93;&#20195;&#34920;&#24403;&#21069;&#22495;&#21517;</label><div class="col-sm-9"><div class="UploadBanner"><div class="PhotoControl ClickPhotoControl" id="UserAd"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';
	
	//�ö�
	echo <<<HTML
	<script type="text/JavaScript">
	var companytoprowtypedata = [
		[	
			[1, '<input type="text" class="form-control w50" name="common_list[company_top][displayorder][]" value="">'],
			[1, '<input type="text" class="form-control w50" name="common_list[company_top][day][]" value="">'],
			[1, '<input type="text" class="form-control w50" name="common_list[company_top][money][]" value="">'],
			[1, '<input type="text" class="form-control w200" name="common_list[company_top][content][]" value="">'],
			[1, '<a href="#" onclick="deleterow(this)" class="btn btn-sm btn-danger-outline">&#21024;&#38500;</a>']
		],
	];
	</script>
	<div class="border box-header margin-top-20"><h5 class="box-title">&#32622;&#39030;&#22871;&#39184;</h5></div>
HTML;
	showtableheader('','table table-bordered table-hover display nowrap table-responsive dataTable');
	showsubtitle(array(
		'&#26174;&#31034;&#39034;&#24207;',
		'&#32622;&#39030;&#22825;&#25968;',
		'&#20215;&#26684;',
		'&#22871;&#39184;&#35828;&#26126;',
		'&#21024;&#38500;'
	),'header tbm tc');
	$CompanyTopArray = $common_setting ? $setting['company_top'] : array(
		array('displayorder'=>'0','day'=>'30','money'=>'200','content'=>'&#32622;&#39030;&#51;&#48;&#22825;&#65292;&#50;&#48;&#48;&#20803;'),
		array('displayorder'=>'1','day'=>'15','money'=>'150','content'=>'&#32622;&#39030;&#49;&#53;&#22825;&#65292;&#49;&#53;&#48;&#20803;')
	);
	foreach ($CompanyTopArray as $Key => $Val) {
		showtablerow('', array('class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
			'<input type="text" class="form-control w50" name="common_list[company_top][displayorder][]" value="'.$Val['displayorder'].'">',
			'<input type="text" class="form-control w50" name="common_list[company_top][day][]" value="'.$Val['day'].'">',
			'<input type="text" class="form-control w50" name="common_list[company_top][money][]" value="'.$Val['money'].'">',
			'<input type="text" class="form-control w200" name="common_list[company_top][content][]" value="'.$Val['content'].'">',
			'<a href="#" onclick="deleterow(this)" class="btn btn-sm btn-danger-outline">&#21024;&#38500;</a>',
		));
	}
	echo '<tr class="hover"><td class="tc" colspan="10"><a href="#" onclick="addrow(this,companytoprowtypedata, 0)"><i class="fa fa-plus" style="margin-right:5px"></i>&#28155;&#21152;</a></td></tr>';
	showtablefooter(); /*dism��taobao��com*/
	//�ö� End

	echo <<<HTML
	</div>
	<!-- װ������ end  -->
HTML;

	echo <<<HTML
	<!-- ��������  -->
	<div class="tab-pane" id="material" role="tabpanel" aria-expanded="false">
HTML;
	
	showsetting('&#26631;&#39064;', 'setting[MaterialTitle]', $setting['MaterialTitle'] ? $setting['MaterialTitle'] : '&#12304;&#39134;&#40479;&#12305;&#24314;&#26448;', 'text');

	echo '<div class="form-group row"><label class="col-sm-1 col-form-label">&#27178;&#24133;&#22270;&#29255;<br>&#24314;&#35758;&#23610;&#23544;&#65306;&#54;&#52;&#48;&#32;&#42;&#32;&#51;&#48;&#48;</label><div class="col-sm-9"><div class="UploadBanner"><div class="PhotoControl ClickPhotoControl" id="MaterialBanners"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';

	echo '<div class="form-group row"><label class="col-sm-1 col-form-label">&#20250;&#21592;&#20013;&#24515;&#24191;&#21578;<br>&#24314;&#35758;&#23610;&#23544;&#65306;&#55;&#53;&#48;&#32;&#42;&#32;&#49;&#53;&#48;<br>&#91;&#115;&#105;&#116;&#101;&#117;&#114;&#108;&#93;&#20195;&#34920;&#24403;&#21069;&#22495;&#21517;</label><div class="col-sm-9"><div class="UploadBanner"><div class="PhotoControl ClickPhotoControl" id="UserMaterialAd"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';
	
	showsetting('&#20844;&#21496;&#22312;&#32447;&#20837;&#39547;', 'setting[MaterialCompanyOnlineSwitch]', $common_setting ? $setting['MaterialCompanyOnlineSwitch'] : 1, 'radio','','','&#20844;&#21496;&#26159;&#21542;&#22312;&#32447;&#20837;&#39547;&#65292;&#21542;&#30340;&#35805;&#65292;&#28857;&#20987;&#20837;&#39547;&#25353;&#38062;&#21017;&#24377;&#20986;&#23458;&#26381;&#32852;&#31995;&#26041;&#24335;');

	showsetting('&#20844;&#21496;&#38750;&#20250;&#21592;&#36890;&#30693;', 'setting[MaterialCompanyNotice]', $common_setting ? $setting['MaterialCompanyNotice'] : 1, 'radio','','','&#20844;&#21496;&#38750;&#20250;&#21592;&#26159;&#21542;&#36890;&#30693;&#29992;&#25143;');

	showsetting('&#20844;&#21496;&#24320;&#21551;&#26631;&#27880;', 'setting[MaterialCompanyMapSwitch]', $common_setting ? $setting['MaterialCompanyMapSwitch'] : 1, 'radio','','','&#20844;&#21496;&#26159;&#21542;&#24320;&#21551;&#26631;&#27880;&#65292;&#26631;&#27880;&#21518;&#21487;&#23548;&#33322;');

	showsetting('&#20844;&#21496;&#22871;&#39184;&#32493;&#36153;&#21472;&#21152;&#27425;&#25968;', 'setting[MaterialGroupSuperpositionSwitch]', $setting['MaterialGroupSuperpositionSwitch'], 'radio','','','&#20844;&#21496;&#32493;&#36153;&#22871;&#39184;&#26159;&#21542;&#21472;&#21152;&#65292;&#21457;&#24067;&#21830;&#21697;&#24635;&#25968;&#47;&#26696;&#20363;&#24635;&#25968;');

	showsetting('&#20844;&#21496;&#20837;&#39547;&#26159;&#21542;&#23457;&#26680;', 'setting[MaterialDisplaySwitch]', $common_setting ? $setting['MaterialDisplaySwitch'] : 1, 'radio');

	showsetting('&#20844;&#21496;&#33829;&#19994;&#25191;&#29031;&#26159;&#21542;&#24517;&#22635;', 'setting[MaterialCompanyLicenseSwitch]', $setting['MaterialCompanyLicenseSwitch'], 'radio');

	showsetting('&#20844;&#21496;&#21047;&#26032;&#25490;&#21517;&#37329;&#39069;', 'setting[material_company_refresh_money]', $common_setting ? $setting['material_company_refresh_money'] : '1', 'text','','','&#48;&#25110;&#32773;&#31354;&#20195;&#34920;&#19981;&#24320;&#21551;');

	showsetting('&#24314;&#26448;&#39318;&#39029;&#26696;&#20363;&#35843;&#29992;&#26465;&#25968;', 'setting[material_index_case_num]', $setting['material_index_case_num'] ? $setting['material_index_case_num'] : 6, 'text');

	showsetting('&#24314;&#26448;&#39318;&#39029;&#21830;&#21697;&#35843;&#29992;&#26465;&#25968;', 'setting[material_index_goods_num]', $setting['material_index_goods_num'] ? $setting['material_index_goods_num'] : 6, 'text');

	showsetting('&#20844;&#21496;&#21830;&#21697;&#35843;&#29992;&#26465;&#25968;', 'setting[company_goods_num]', $setting['company_goods_num'] ? $setting['company_goods_num'] : 4, 'text');

	showsetting('&#20844;&#21496;&#21830;&#21697;&#35843;&#29992;&#26465;&#25968;', 'setting[company_goods_num]', $setting['company_goods_num'] ? $setting['company_goods_num'] : 4, 'text');

	showsetting('&#20844;&#21496;&#26696;&#20363;&#35843;&#29992;&#26465;&#25968;', 'setting[material_company_case_num]', $setting['material_company_case_num'] ? $setting['material_company_case_num'] : 4, 'text');
	
	showsetting('&#34920;&#21333;&#25512;&#36865;&#25991;&#26696;', 'setting[MaterialFormPush]', $setting['MaterialFormPush'] ? $setting['MaterialFormPush'] : '&#23562;&#25964;&#30340;&#20250;&#21592;&#65292;&#26377;&#23458;&#25143;&#24819;[{form_type}]&#65292;&#22995;&#21517;&#65306;{name}&#65292;&#32852;&#31995;&#26041;&#24335;&#65306;{phone}&#65292;&#35831;&#30331;&#24405;&#39134;&#40479;&#35013;&#20462;&#32593;&#26597;&#30475;', 'textarea','','','&#65;&#80;&#80;&#47;&#100;&#122;&#36890;&#30693;&#25991;&#26696;<br>&#32;&#123;&#102;&#111;&#114;&#109;&#95;&#116;&#121;&#112;&#101;&#125;&#20195;&#34920;&#34920;&#21333;&#31867;&#22411;&#65292;&#123;&#110;&#97;&#109;&#101;&#125;&#20195;&#34920;&#22995;&#21517;&#65292;&#123;&#112;&#104;&#111;&#110;&#101;&#125;&#20195;&#34920;&#25163;&#26426;&#21495;&#65281;&#65281;&#65281;');
	
	$setting['MaterialCompanyDefaultPath'] = $setting['MaterialCompanyDefaultPath'] ? $setting['MaterialCompanyDefaultPath'] : '/source/plugin/fn_renovation/static/images/thumbnail.png';
	$MaterialCompanyDefaultPathHtml = '<a href="'.$setting['MaterialCompanyDefaultPath'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['MaterialCompanyDefaultPath'].'" height="55"/></a>';
	showsetting('&#20844;&#21496;&#40664;&#35748;&#32553;&#30053;&#22270;', 'new_MaterialCompanyDefaultPath',$setting['MaterialCompanyDefaultPath'], 'filetext', '', 0, $MaterialCompanyDefaultPathHtml);

	$setting['MaterialCompanyVerifyPath'] = $setting['MaterialCompanyVerifyPath'] ? $setting['MaterialCompanyVerifyPath'] : '/source/plugin/fn_renovation/static/images/verify.png';
	$MaterialCompanyVerifyPathHtml = '<a href="'.$setting['MaterialCompanyVerifyPath'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['MaterialCompanyVerifyPath'].'" height="15"/></a>&#24314;&#35758;&#65306;&#56;&#48;&#32;&#42;&#32;&#50;&#56;';
	showsetting('&#20844;&#21496;&#35748;&#35777;&#22270;&#26631;', 'new_MaterialCompanyVerifyPath',$setting['MaterialCompanyVerifyPath'], 'filetext', '', 0, $MaterialCompanyVerifyPathHtml);

	$setting['MaterialMerchantEntry'] = $setting['MaterialMerchantEntry'] ? $setting['MaterialMerchantEntry'] : '/source/plugin/fn_renovation/static/images/jcsjrz.png';
	$MaterialMerchantEntryHtml = '<a href="'.$setting['MaterialMerchantEntry'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['MaterialMerchantEntry'].'" height="55"/></a>';
	showsetting('&#20844;&#21496;&#20837;&#39547;&#25353;&#38062;&#22270;&#26631;', 'new_MaterialMerchantEntry',$setting['MaterialMerchantEntry'], 'filetext', '', 0, $MaterialMerchantEntryHtml);

	$setting['MaterialManagementCompany'] = $setting['MaterialManagementCompany'] ? $setting['MaterialManagementCompany'] : '/source/plugin/fn_renovation/static/images/jcglgs.png';
	$MaterialManagementCompanyHtml = '<a href="'.$setting['MaterialManagementCompany'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['MaterialManagementCompany'].'" height="55"/></a>';
	showsetting('&#31649;&#29702;&#20844;&#21496;&#25353;&#38062;&#22270;&#26631;', 'new_MaterialManagementCompany',$setting['MaterialManagementCompany'], 'filetext', '', 0, $MaterialManagementCompanyHtml);

	$setting['MaterialCompanyHotPath'] = $setting['MaterialCompanyHotPath'] ? $setting['MaterialCompanyHotPath'] : '/source/plugin/fn_renovation/static/images/hot.png';
	$MaterialCompanyHotPathHtml = '<a href="'.$setting['MaterialCompanyHotPath'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['MaterialCompanyHotPath'].'" height="40"/></a>';
	showsetting('&#20844;&#21496;&#25512;&#33616;&#22270;&#26631;&#22270;&#26631;', 'new_MaterialCompanyHotPath',$setting['MaterialCompanyHotPath'], 'filetext', '', 0, $MaterialCompanyHotPathHtml);

	showsetting('&#21830;&#21697;&#31867;&#22411;&#26631;&#31614;', 'setting[GoodsType]', $setting['GoodsType'] ? $setting['GoodsType'] : '1=&#20419;&#38144;
2=&#25250;&#36141;','textarea','','','&#19968;&#34892;&#19968;&#26631;&#31614;&#65281;&#65281;&#65281;&#26684;&#24335;&#65306;&#49;&#61;&#26631;&#31614;&#19968;&#65292;&#50;&#61;&#26631;&#31614;&#20108;&#65281;&#65281;&#65281;&#20363;&#22914;&#65306;<br>&#49;&#61;&#26631;&#31614;&#19968;<br>&#50;&#61;&#26631;&#31614;&#20108;');

	showsetting('&#21830;&#21697;&#20215;&#26684;&#26631;&#31614;', 'setting[GoodsPriceTag]', $setting['GoodsPriceTag'] ? $setting['GoodsPriceTag'] : '1=&#20803;
2=&#20010;
3=&#22871;
4=&#31859;','textarea','','','&#19968;&#34892;&#19968;&#26631;&#31614;&#65281;&#65281;&#65281;&#26684;&#24335;&#65306;&#49;&#61;&#26631;&#31614;&#19968;&#65292;&#50;&#61;&#26631;&#31614;&#20108;&#65281;&#65281;&#65281;&#20363;&#22914;&#65306;<br>&#49;&#61;&#26631;&#31614;&#19968;<br>&#50;&#61;&#26631;&#31614;&#20108;');
	
	//�ö�
	echo <<<HTML
	<script type="text/JavaScript">
	var materialcompanytoprowtypedata = [
		[	
			[1, '<input type="text" class="form-control w50" name="common_list[material_company_top][displayorder][]" value="">'],
			[1, '<input type="text" class="form-control w50" name="common_list[material_company_top][day][]" value="">'],
			[1, '<input type="text" class="form-control w50" name="common_list[material_company_top][money][]" value="">'],
			[1, '<input type="text" class="form-control w200" name="common_list[material_company_top][content][]" value="">'],
			[1, '<a href="#" onclick="deleterow(this)" class="btn btn-sm btn-danger-outline">&#21024;&#38500;</a>']
		],
	];
	</script>
	<div class="border box-header margin-top-20"><h5 class="box-title">&#32622;&#39030;&#22871;&#39184;</h5></div>
HTML;
	showtableheader('','table table-bordered table-hover display nowrap table-responsive dataTable');
	showsubtitle(array(
		'&#26174;&#31034;&#39034;&#24207;',
		'&#32622;&#39030;&#22825;&#25968;',
		'&#20215;&#26684;',
		'&#22871;&#39184;&#35828;&#26126;',
		'&#21024;&#38500;'
	),'header tbm tc');
	$MaterialCompanyTopArray = $common_setting ? $setting['material_company_top'] : array(
		array('displayorder'=>'0','day'=>'30','money'=>'200','content'=>'&#32622;&#39030;&#51;&#48;&#22825;&#65292;&#50;&#48;&#48;&#20803;'),
		array('displayorder'=>'1','day'=>'15','money'=>'150','content'=>'&#32622;&#39030;&#49;&#53;&#22825;&#65292;&#49;&#53;&#48;&#20803;')
	);
	foreach ($MaterialCompanyTopArray as $Key => $Val) {
		showtablerow('', array('class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
			'<input type="text" class="form-control w50" name="common_list[material_company_top][displayorder][]" value="'.$Val['displayorder'].'">',
			'<input type="text" class="form-control w50" name="common_list[material_company_top][day][]" value="'.$Val['day'].'">',
			'<input type="text" class="form-control w50" name="common_list[material_company_top][money][]" value="'.$Val['money'].'">',
			'<input type="text" class="form-control w200" name="common_list[material_company_top][content][]" value="'.$Val['content'].'">',
			'<a href="#" onclick="deleterow(this)" class="btn btn-sm btn-danger-outline">&#21024;&#38500;</a>',
		));
	}
	echo '<tr class="hover"><td class="tc" colspan="10"><a href="#" onclick="addrow(this,materialcompanytoprowtypedata, 0)"><i class="fa fa-plus" style="margin-right:5px"></i>&#28155;&#21152;</a></td></tr>';
	showtablefooter(); /*dism��taobao��com*/
	//�ö� End

	echo <<<HTML
	</div>
	<!-- �������� end  -->
HTML;


	echo <<<HTML
	<!-- ��ʦ������  -->
	<div class="tab-pane" id="artisan" role="tabpanel" aria-expanded="false">
HTML;
	
	showsetting('&#20837;&#34892;&#26102;&#38388;', 'setting[ArtisanWorkYears]', $setting['ArtisanWorkYears'] ? $setting['ArtisanWorkYears'] : '2020=2020&#24180;
2019=2019&#24180;
2018=2018&#24180;
2017=2017&#24180;
2016=2016&#24180;
2015=2015&#24180;
2014=2014&#24180;
2013=2013&#24180;
2012=2012&#24180;
2011=2011&#24180;
2010=2010&#24180;
2009=2009&#24180;
2008=2008&#24180;
2007=2007&#24180;
2006=2006&#24180;
2005=2005&#24180;
2004=2004&#24180;
2003=2003&#24180;
2002=2002&#24180;
2001=2001&#24180;
2000=2000&#24180;
1999=1999&#24180;
1998=1998&#24180;
1997=1997&#24180;
1996=1996&#24180;
1995=1995&#24180;
1994=1994&#24180;
1993=1993&#24180;
1992=1992&#24180;
1991=1991&#24180;
1990=1990&#24180;
1989=1989&#24180;
1988=1988&#24180;
1987=1987&#24180;
1986=1986&#24180;
1985=1985&#24180;
1984=1984&#24180;
1983=1983&#24180;
1982=1982&#24180;
1981=1981&#24180;
1980=1980&#24180;
1979=1979&#24180;
1978=1978&#24180;
1977=1977&#24180;
1976=1976&#24180;
1975=1975&#24180;
1974=1974&#24180;
1973=1973&#24180;
1972=1972&#24180;
1971=1971&#24180;
1970=1970&#24180;
1969=1969&#24180;
1968=1968&#24180;
1967=1967&#24180;
1966=1966&#24180;
1965=1965&#24180;
1964=1964&#24180;
1963=1963&#24180;
1962=1962&#24180;
1961=1961&#24180;
1960=1960&#24180;','textarea','','','&#19968;&#34892;&#19968;&#26102;&#38388;&#65292;&#26684;&#24335;&#65306;&#49;&#57;&#54;&#48;&#61;&#49;&#57;&#54;&#48;&#24180;&#65281;&#65281;&#65281;&#20363;&#22914;&#65306;<br>&#32;&#49;&#57;&#54;&#48;&#61;&#49;&#57;&#54;&#48;&#24180;<br>&#32;&#49;&#57;&#54;&#49;&#61;&#49;&#57;&#54;&#49;&#24180;');

	showsetting('&#32500;&#20462;&#24072;&#20613;&#26631;&#31614;', 'setting[ArtisanRepair]', $setting['ArtisanRepair'] ? $setting['ArtisanRepair'] : '45=&#28783;&#20855;&#30005;&#36335;
46=&#31649;&#36947;&#30095;&#36890;
47=&#38450;&#27700;&#34917;&#28431;
48=&#22825;&#33457;&#21514;&#39030;
49=&#22320;&#26495;
50=&#31354;&#35843;
51=&#23478;&#20855;
52=&#27249;&#26588;
53=&#26262;&#36890;
54=&#23433;&#38450;
55=&#28909;&#27700;&#22120;
56=&#23478;&#30005;&#21416;&#30005;','textarea','','','&#12304;&#27880;&#24847;&#65306;&#32034;&#24341;&#35831;&#21247;&#21644;&#23433;&#35013;&#24072;&#20613;&#47;&#35013;&#20462;&#24072;&#20613;&#47;&#20854;&#20182;&#31867;&#32;&#37325;&#22797;&#12305;<br>&#19968;&#34892;&#19968;&#26631;&#31614;&#65292;&#26684;&#24335;&#65306;&#49;&#61;&#26408;&#24037;&#65281;&#65281;&#65281;&#20363;&#22914;<br>&#32;&#49;&#61;&#26408;&#24037;');

	showsetting('&#23433;&#35013;&#24072;&#20613;&#26631;&#31614;', 'setting[ArtisanInstall]', $setting['ArtisanInstall'] ? $setting['ArtisanInstall'] : '14=&#38450;&#30423;&#38376;&#31383;
15=&#38450;&#27700;&#34917;&#28431;
16=&#22825;&#33457;&#21514;&#39030;
17=&#28783;&#20855;&#28783;&#39280;
18=&#27249;&#26588;&#34915;&#26588;
19=&#24320;&#27133;&#38075;&#23380;
20=&#21355;&#28020;&#27905;&#20855;
21=&#20116;&#37329;&#25346;&#20214;
22=&#26408;&#38376;&#31227;&#38376;
23=&#22681;&#32440;&#22681;&#24067;
24=&#38145;&#47;&#26234;&#33021;&#38145;
25=&#26238;&#34915;&#26550;
26=&#38109;&#38376;&#31383;
27=&#32433;&#31383;
28=&#31383;&#24088;
29=&#29627;&#29827;
30=&#26262;&#36890;
31=&#22320;&#27631;
32=&#29943;&#30742;
33=&#26408;&#22320;&#26495;
34=&#38451;&#20809;&#25151;
35=&#36974;&#38451;&#26842;
36=&#32972;&#26223;&#22681;
37=&#20928;&#27700;&#22120;
38=&#28909;&#27700;&#22120;
39=&#23478;&#30005;&#21416;&#30005;
40=&#31354;&#35843;
41=&#23478;&#20855;
42=&#26639;&#26438;
43=&#22320;&#26262;
44=&#23433;&#38450;','textarea','','','&#12304;&#27880;&#24847;&#65306;&#32034;&#24341;&#35831;&#21247;&#21644;&#32500;&#20462;&#24072;&#20613;&#47;&#35013;&#20462;&#24072;&#20613;&#47;&#20854;&#20182;&#31867;&#32;&#37325;&#22797;&#12305;<br>&#19968;&#34892;&#19968;&#26631;&#31614;&#65292;&#26684;&#24335;&#65306;&#51;&#61;&#38450;&#30423;&#38376;&#31383;&#65281;&#65281;&#65281;&#20363;&#22914;<br>&#51;&#61;&#38450;&#30423;&#38376;&#31383;');

	showsetting('&#35013;&#20462;&#24072;&#20613;&#26631;&#31614;', 'setting[ArtisanRenovation]', $setting['ArtisanRenovation'] ? $setting['ArtisanRenovation'] : '4=&#26408;&#24037;
5=&#27877;&#24037;
6=&#27700;&#30005;&#24037;
7=&#27833;&#28422;&#24037;
8=&#38450;&#27700;
9=&#38075;&#23380;
10=&#36135;&#36816;
11=&#25159;&#28784;&#24037;
12=&#25286;&#38500;&#24037;
13=&#25644;&#36816;','textarea','','','&#12304;&#27880;&#24847;&#65306;&#32034;&#24341;&#35831;&#21247;&#21644;&#32500;&#20462;&#24072;&#20613;&#47;&#23433;&#35013;&#24072;&#20613;&#47;&#20854;&#20182;&#31867;&#32;&#37325;&#22797;&#12305;<br>&#19968;&#34892;&#19968;&#26631;&#31614;&#65292;&#26684;&#24335;&#65306;&#53;&#61;&#26408;&#24037;&#65281;&#65281;&#65281;&#20363;&#22914;<br>&#32;&#53;&#61;&#26408;&#24037;');

	showsetting('&#20854;&#20182;&#25216;&#33021;&#24072;&#20613;&#26631;&#31614;', 'setting[ArtisanOther]', $setting['ArtisanOther'] ? $setting['ArtisanOther'] : '99=&#24178;&#38646;&#27963;
100=&#20854;&#23427;','textarea','','','&#12304;&#27880;&#24847;&#65306;&#32034;&#24341;&#35831;&#21247;&#21644;&#32500;&#20462;&#24072;&#20613;&#47;&#23433;&#35013;&#24072;&#20613;&#47;&#35013;&#20462;&#24072;&#20613;&#32;&#37325;&#22797;&#12305;<br>&#19968;&#34892;&#19968;&#26631;&#31614;&#65292;&#26684;&#24335;&#65306;&#49;&#48;&#48;&#61;&#20854;&#23427;&#65281;&#65281;&#65281;&#20363;&#22914;<br>&#32;&#49;&#48;&#48;&#61;&#20854;&#23427;');

	showsetting('&#26174;&#31034;&#20250;&#21592;', 'setting[ArtisanListVip]', $setting['ArtisanListVip'], 'radio','','','&#25214;&#24072;&#20613;&#21015;&#34920;&#26159;&#21542;&#21482;&#26174;&#31034;&#20250;&#21592;&#65288;&#21040;&#26399;&#26102;&#38388;&#26410;&#21040;&#26399;&#30340;&#65289;');

	showsetting('&#20813;&#36153;&#22871;&#39184;&#23457;&#26680;', 'setting[ArtisanGroupFree]', $setting['ArtisanGroupFree'], 'radio','','','&#25214;&#24072;&#20613;&#20813;&#36153;&#22871;&#39184;&#26159;&#21542;&#35201;&#23457;&#26680;');

	showsetting('&#25214;&#24072;&#20613;&#30701;&#20449;&#39564;&#35777;', 'setting[ArtisanMobileSwitch]', $setting['ArtisanMobileSwitch'], 'radio','','','&#26159;&#21542;&#24320;&#21551;&#25214;&#24072;&#20613;&#25163;&#26426;&#39564;&#35777;&#65292;&#35831;&#22635;&#20889;&#30701;&#20449;&#39564;&#35777;&#27169;&#26495;&#65281;&#65281;&#65281;&#20351;&#29992;&#12304;&#30701;&#20449;&#36890;&#12305;&#26080;&#38656;&#22635;&#20889;&#30701;&#20449;&#39564;&#35777;&#27169;&#26495;');

	$setting['ArtisanMerchantEntry'] = $setting['ArtisanMerchantEntry'] ? $setting['ArtisanMerchantEntry'] : '/source/plugin/fn_renovation/static/images/sfrz.png';
	$ArtisanMerchantEntryHtml = '<a href="'.$setting['ArtisanMerchantEntry'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['ArtisanMerchantEntry'].'" height="55"/></a>&#23610;&#23544;&#49;&#48;&#48;&#32;&#42;&#32;&#49;&#48;&#48;';
	showsetting('&#20837;&#39547;&#22270;&#26631;&#36335;&#24452;', 'new_ArtisanMerchantEntry',$setting['ArtisanMerchantEntry'], 'filetext', '', 0, $ArtisanMerchantEntryHtml);

	$setting['ArtisanManagement'] = $setting['ArtisanManagement'] ? $setting['ArtisanManagement'] : '/source/plugin/fn_renovation/static/images/sfgl.png';
	$ArtisanManagementHtml = '<a href="'.$setting['ArtisanManagement'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['ArtisanManagement'].'" height="55"/></a>&#23610;&#23544;&#49;&#48;&#48;&#32;&#42;&#32;&#49;&#48;&#48;';
	showsetting('&#31649;&#29702;&#22270;&#26631;&#36335;&#24452;', 'new_ArtisanManagement',$setting['ArtisanManagement'], 'filetext', '', 0, $ArtisanManagementHtml);

	$setting['ArtisanVerifyPath'] = $setting['ArtisanVerifyPath'] ? $setting['ArtisanVerifyPath'] : '/source/plugin/fn_renovation/static/images/verify.png';
	$ArtisanVerifyPathHtml = '<a href="'.$setting['ArtisanVerifyPath'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['ArtisanVerifyPath'].'" height="15"/></a>&#24314;&#35758;&#65306;&#56;&#48;&#32;&#42;&#32;&#50;&#56;';
	showsetting('&#35748;&#35777;&#22270;&#26631;', 'new_ArtisanVerifyPath',$setting['ArtisanVerifyPath'], 'filetext', '', 0, $ArtisanVerifyPathHtml);

	showsetting('&#21047;&#26032;&#37329;&#39069;', 'setting[ArtisanRefreshMoney]',$common_setting ? $setting['ArtisanRefreshMoney'] : 1, 'text');

	echo <<<HTML
	<script type="text/JavaScript">
	var artisangrouprowtypedata = [
		[	
			[1, '<input type="text" class="form-control w50" name="common_list[artisan_group][displayorder][]" value="">'],
			[1, '<input type="text" class="form-control w50" name="common_list[artisan_group][id][]" value="">'],
			[1, '<input type="text" class="form-control w50" name="common_list[artisan_group][day][]" value="">'],
			[1, '<input type="text" class="form-control w50" name="common_list[artisan_group][money][]" value="">'],
			[1, '<input type="text" class="form-control w200" name="common_list[artisan_group][title][]" value="">'],
			[1, '<input type="text" class="form-control w200" name="common_list[artisan_group][content][]" value="">'],
			[1, '<input type="text" class="form-control w50" name="common_list[artisan_group][top_day][]" value="">'],
			[1, '<a href="#" onclick="deleterow(this)" class="btn btn-sm btn-danger-outline">&#21024;&#38500;</a>']
		],
	];

	var artisantoprowtypedata = [
		[	
			[1, '<input type="text" class="form-control w50" name="common_list[artisan_top][displayorder][]" value="">'],
			[1, '<input type="text" class="form-control w50" name="common_list[artisan_top][day][]" value="">'],
			[1, '<input type="text" class="form-control w50" name="common_list[artisan_top][money][]" value="">'],
			[1, '<input type="text" class="form-control w200" name="common_list[artisan_top][content][]" value="">'],
			[1, '<a href="#" onclick="deleterow(this)" class="btn btn-sm btn-danger-outline">&#21024;&#38500;</a>']
		],
	];


	</script>
HTML;

	//�����ײ�
	echo <<<HTML
	<div class="border box-header margin-top-30"><h5 class="box-title">&#26381;&#21153;&#22871;&#39184;</h5><p class="margin-bottom-0" style="font-size:12px;">&#27880;&#24847;&#65306;&#105;&#100;&#19981;&#33021;&#37325;&#22797;</p></div>
HTML;
	showtableheader('','table table-bordered table-hover display nowrap table-responsive dataTable');
	showsubtitle(array(
		'&#26174;&#31034;&#39034;&#24207;',
		'ID',
		'&#26102;&#38388;&#40;&#21333;&#20301;&#58;&#22825;&#41;',
		'&#20215;&#26684;',
		'&#22871;&#39184;&#26631;&#39064;',
		'&#22871;&#39184;&#35828;&#26126;',
		'&#36865;&#32622;&#39030;&#26102;&#38388;&#40;&#21333;&#20301;&#58;&#22825;&#41;',
		'&#21024;&#38500;'
	),'header tbm tc');
	$ArtisanGroupArray = $common_setting ? $setting['artisan_group'] : array(
		array('displayorder'=>'0','id'=>'1','day'=>'30','money'=>'100','title'=>'&#49;&#20010;&#26376;&#118;&#105;&#112;','content'=>'&#49;&#20010;&#26376;&#65292;&#49;&#48;&#48;&#20803;&#65292;&#36865;&#32622;&#39030;&#51;&#22825;','top_day'=>'3'),
		array('displayorder'=>'1','id'=>'2','day'=>'90','money'=>'200','title'=>'&#51;&#20010;&#26376;&#118;&#105;&#112;','content'=>'&#51;&#20010;&#26376;&#65292;&#50;&#48;&#48;&#20803;&#65292;&#36865;&#32622;&#39030;&#49;&#48;&#22825;','top_day'=>'10'),
		array('displayorder'=>'2','id'=>'3','day'=>'365','money'=>'500','title'=>'&#49;&#24180;&#118;&#105;&#112;','content'=>'&#49;&#24180;&#65292;&#53;&#48;&#48;&#20803;&#65292;&#36865;&#32622;&#39030;&#49;&#20010;&#26376;','top_day'=>'30'),
		array('displayorder'=>'3','id'=>'4','day'=>'7','money'=>'0','title'=>'&#55;&#22825;&#20307;&#39564;&#118;&#105;&#112;','content'=>'&#55;&#22825;&#20307;&#39564;&#65292;&#20813;&#36153;&#24320;&#36890;','top_day'=>'0')
		
	);
	foreach ($ArtisanGroupArray as $Key => $Val) {
		showtablerow('', array('class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
			'<input type="text" class="form-control w50" name="common_list[artisan_group][displayorder][]" value="'.$Val['displayorder'].'">',
			'<input type="text" class="form-control w50" name="common_list[artisan_group][id][]" value="'.$Val['id'].'">',
			'<input type="text" class="form-control w50" name="common_list[artisan_group][day][]" value="'.$Val['day'].'">',
			'<input type="text" class="form-control w50" name="common_list[artisan_group][money][]" value="'.$Val['money'].'">',
			'<input type="text" class="form-control w200" name="common_list[artisan_group][title][]" value="'.$Val['title'].'">',
			'<input type="text" class="form-control w200" name="common_list[artisan_group][content][]" value="'.$Val['content'].'">',
			'<input type="text" class="form-control w50" name="common_list[artisan_group][top_day][]" value="'.$Val['top_day'].'">',
			'<a href="#" onclick="deleterow(this)" class="btn btn-sm btn-danger-outline">&#21024;&#38500;</a>',
		));
	}
	echo '<tr class="hover"><td class="tc" colspan="10"><a href="#" onclick="addrow(this,artisangrouprowtypedata, 0)"><i class="fa fa-plus" style="margin-right:5px"></i>&#28155;&#21152;</a></td></tr>';
	showtablefooter(); /*dism��taobao��com*/
	//�����ײ� End

	//ʦ���ö�
	echo <<<HTML
	<div class="border box-header margin-top-30"><h5 class="box-title">&#32622;&#39030;&#22871;&#39184;</h5></div>
HTML;
	showtableheader('','table table-bordered table-hover display nowrap table-responsive dataTable');
	showsubtitle(array(
		'&#26174;&#31034;&#39034;&#24207;',
		'&#32622;&#39030;&#22825;&#25968;',
		'&#20215;&#26684;',
		'&#22871;&#39184;&#35828;&#26126;',
		'&#21024;&#38500;'
	),'header tbm tc');
	$ArtisanTopArray = $common_setting ? $setting['artisan_top'] : array(
		array('displayorder'=>'0','day'=>'30','money'=>'200','content'=>'&#32622;&#39030;&#51;&#48;&#22825;&#65292;&#50;&#48;&#48;&#20803;'),
		array('displayorder'=>'1','day'=>'15','money'=>'150','content'=>'&#32622;&#39030;&#49;&#53;&#22825;&#65292;&#49;&#53;&#48;&#20803;')
	);
	foreach ($ArtisanTopArray as $Key => $Val) {
		showtablerow('', array('class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
			'<input type="text" class="form-control w50" name="common_list[artisan_top][displayorder][]" value="'.$Val['displayorder'].'">',
			'<input type="text" class="form-control w50" name="common_list[artisan_top][day][]" value="'.$Val['day'].'">',
			'<input type="text" class="form-control w50" name="common_list[artisan_top][money][]" value="'.$Val['money'].'">',
			'<input type="text" class="form-control w200" name="common_list[artisan_top][content][]" value="'.$Val['content'].'">',
			'<a href="#" onclick="deleterow(this)" class="btn btn-sm btn-danger-outline">&#21024;&#38500;</a>',
		));
	}
	echo '<tr class="hover"><td class="tc" colspan="10"><a href="#" onclick="addrow(this,artisantoprowtypedata, 0)"><i class="fa fa-plus" style="margin-right:5px"></i>&#28155;&#21152;</a></td></tr>';
	showtablefooter(); /*dism��taobao��com*/
	//ʦ���ö� End

	echo <<<HTML
	</div>
	<!-- ��ʦ������ end  -->
HTML;
	
	
	echo <<<HTML
	<!-- �������  -->
	<div class="tab-pane" id="design" role="tabpanel" aria-expanded="false">
HTML;
	
	showsetting('&#22270;&#29255;&#36335;&#24452;', 'setting[free_quote_imgs]', $setting['free_quote_imgs'] ? $setting['free_quote_imgs'] : '1=/source/plugin/fn_renovation/static/images/free_quote_banner.jpg
3=/source/plugin/fn_renovation/static/images/free_quote_style_title.jpg
4=/source/plugin/fn_renovation/static/images/free_quote_content.jpg', 'textarea','','','&#19968;&#34892;&#19968;&#22270;&#29255;&#36335;&#24452;&#65281;&#65281;&#65281;&#26684;&#24335;&#65306;&#49;&#61;&#27178;&#24133;&#22270;&#29255;&#36335;&#24452;&#65292;&#50;&#61;&#32;&#24494;&#20449;&#20108;&#32500;&#30721;&#36335;&#24452;&#65292;&#51;&#61;&#39118;&#26684;&#26631;&#39064;&#22270;&#29255;&#65292;&#52;&#61;&#20869;&#23481;&#22270;&#29255;&#65281;&#65281;&#65281;&#20363;&#22914;&#65306;<br>1=/source/plugin/fn_renovation/static/images/free_quote_banner.jpg<br>3=/source/plugin/fn_renovation/static/images/free_quote_style_title.jpg');

	showsetting('&#25991;&#23383;', 'setting[free_quote_texts]', $setting['free_quote_texts'] ? stripslashes($setting['free_quote_texts']) : '1=&#32852;&#31995;&#23567;&#32534;&#24494;&#20449;&#65306;pcm9510654 &#33719;&#21462;&#26356;&#22810;&#35013;&#20462;&#31119;&#21033;
2=&#35831;&#38271;&#25353;&#24038;&#20391;&#20108;&#32500;&#30721;
3=&#27979;&#27979;&#25105;&#23478;&#30340;&#35013;&#20462;&#39044;&#31639;', 'textarea','','','&#19968;&#34892;&#19968;&#25991;&#23383;&#65281;&#65281;&#65281;&#26684;&#24335;&#65306;&#49;&#61;&#20108;&#32500;&#30721;&#25552;&#31034;&#35821;&#65292;&#50;&#61;&#32;&#20108;&#32500;&#30721;&#25353;&#38062;&#25991;&#23383;&#65292;&#51;&#61;&#24213;&#37096;&#25353;&#38062;&#25991;&#23383;&#65281;&#65281;&#65281;&#20363;&#22914;&#65306;<br>&#49;&#61;&#32852;&#31995;&#23567;&#32534;&#24494;&#20449;&#65306;&#112;&#99;&#109;&#57;&#53;&#49;&#48;&#54;&#53;&#52;&#32;&#33719;&#21462;&#26356;&#22810;&#35013;&#20462;&#31119;&#21033;<br>&#32;&#50;&#61;&#35831;&#38271;&#25353;&#24038;&#20391;&#20108;&#32500;&#30721;<br><br>&#32;&#51;&#61;&#27979;&#27979;&#25105;&#23478;&#30340;&#35013;&#20462;&#39044;&#31639;');

	showsetting('&#39118;&#26684;&#25991;&#23383;', 'setting[free_quote_style_text]', $setting['free_quote_style_text'] ? $setting['free_quote_style_text'] : '&#29616;&#20195;&#31616;&#32422;|&#20248;&#38597;&#20013;&#24335;|&#28165;&#26032;&#21271;&#27431;|&#32654;&#24335;&#32463;&#20856;|&#32654;&#24335;&#32463;&#20856;|&#31109;&#24847;&#26085;&#24335;', 'text','','','&#26684;&#24335;&#65306;&#29616;&#20195;&#31616;&#32422;&#124;&#20248;&#38597;&#20013;&#24335;&#124;&#28165;&#26032;&#21271;&#27431;&#124;&#32654;&#24335;&#32463;&#20856;&#124;&#32654;&#24335;&#32463;&#20856;&#124;&#31109;&#24847;&#26085;&#24335;&#65281;&#65281;&#65281;&#27880;&#24847;&#65306;&#26368;&#22810;&#35774;&#32622;&#53;&#20010;');

	showsetting('&#39118;&#26684;&#22270;&#29255;', 'setting[free_quote_style_img]', $setting['free_quote_style_img'] ? $setting['free_quote_style_img'] : '/source/plugin/fn_renovation/static/images/free_quote_style1.jpg
/source/plugin/fn_renovation/static/images/free_quote_style2.jpg
/source/plugin/fn_renovation/static/images/free_quote_style3.jpg
/source/plugin/fn_renovation/static/images/free_quote_style4.jpg
/source/plugin/fn_renovation/static/images/free_quote_style5.jpg', 'textarea','','','&#19968;&#34892;&#19968;&#22270;&#29255;&#36335;&#24452;');

	echo <<<HTML
	</div>
	<!-- ������� end  -->
HTML;
	

	echo <<<HTML
	<!-- װ��Ԥ��  -->
	<div class="tab-pane" id="free_quote" role="tabpanel" aria-expanded="false">
HTML;
	
	$setting['design_banner'] = $setting['design_banner'] ? $setting['design_banner'] : '/source/plugin/fn_renovation/static/images/design_banner.jpg';
	$design_bannerHtml = '<a href="'.$setting['design_banner'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['design_banner'].'" height="55"/></a>';
	showsetting('&#27178;&#24133;', 'new_design_banner',$setting['design_banner'], 'filetext', '', 0, $design_bannerHtml);

	$setting['design_form_title'] = $setting['design_form_title'] ? $setting['design_form_title'] : '/source/plugin/fn_renovation/static/images/design_form_title.jpg';
	$design_form_titleHtml = '<a href="'.$setting['design_form_title'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['design_form_title'].'" height="55"/></a>';
	showsetting('&#34920;&#21333;&#22270;&#29255;', 'new_design_form_title',$setting['design_form_title'], 'filetext', '', 0, $design_form_titleHtml);

	showsetting('&#34920;&#21333;&#25353;&#38062;', 'setting[design_form_btn]', $setting['design_form_btn'] ? $setting['design_form_btn'] : '&#20813;&#36153;&#33719;&#21462;&#35774;&#35745;&#26041;&#26696;', 'text');

	showsetting('&#34920;&#21333;&#25552;&#31034;&#35821;', 'setting[design_form_tips]', $setting['design_form_tips'] ? stripslashes($setting['design_form_tips']) : '<p class="Text">&#24050;&#26377;<span class="FColor">{count}</span>&#20154;&#30003;&#35831;&#20813;&#36153;&#35774;&#35745;&#26381;&#21153;</p><p>&#39134;&#40479;&#23478;&#23621;&#23567;&#32534;&#20250;&#22312;24&#23567;&#26102;&#20869;&#21521;&#24744;&#33268;&#30005;</p>', 'textarea','','','&#123;&#99;&#111;&#117;&#110;&#116;&#125;&#31561;&#20110;&#26381;&#21153;&#22810;&#23569;&#25143;&#23478;&#24237;&#34394;&#25311;&#25968;&#32;&#43;&#32;&#25552;&#20132;&#25143;&#22411;&#35774;&#35745;&#34920;&#21333;&#20154;&#25968;');

	showsetting('&#20869;&#23481;&#22270;&#29255;', 'setting[design_content]', $setting['design_content'] ? $setting['design_content'] : '/source/plugin/fn_renovation/static/images/design_1.jpg
/source/plugin/fn_renovation/static/images/design_2.jpg
/source/plugin/fn_renovation/static/images/design_3.jpg
/source/plugin/fn_renovation/static/images/design_4.jpg
/source/plugin/fn_renovation/static/images/design_5.jpg', 'textarea','','','&#19968;&#34892;&#19968;&#36335;&#24452;');

	$setting['design_service_title'] = $setting['design_service_title'] ? $setting['design_service_title'] : '/source/plugin/fn_renovation/static/images/design_6.jpg';
	$design_service_titleHtml = '<a href="'.$setting['design_service_title'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['design_service_title'].'" height="55"/></a>';
	showsetting('&#26381;&#21153;&#27969;&#31243;&#26631;&#39064;', 'new_design_service_title',$setting['design_service_title'], 'filetext', '', 0, $design_service_titleHtml);

	showsetting('&#20869;&#23481;&#22270;&#29255;', 'setting[design_service_content]', $setting['design_service_content'] ? $setting['design_service_content'] : '/source/plugin/fn_renovation/static/images/design_ico_1.png|&#30005;&#35805;&#22238;&#35775;|&#39044;&#32422;&#37327;&#25151;
/source/plugin/fn_renovation/static/images/design_ico_2.png|&#19987;&#19994;&#35774;&#35745;|&#19978;&#38376;&#37327;&#25151;
/source/plugin/fn_renovation/static/images/design_ico_3.png|&#37327;&#36523;&#23450;&#21046;|&#35774;&#35745;&#26041;&#26696;&#37327;&#25151;
/source/plugin/fn_renovation/static/images/design_ico_4.png|&#26041;&#26696;&#27807;&#36890;|&#31934;&#20934;&#25253;&#20215;', 'textarea','','','&#19968;&#34892;&#19968;&#20869;&#23481;&#65281;&#65281;&#65281;&#26684;&#24335;&#65306;&#22270;&#29255;&#36335;&#24452;&#124;&#26631;&#39064;&#124;&#25551;&#36848;&#65281;&#65281;&#65281;&#20363;&#22914;&#65306;<br>&#47;&#115;&#111;&#117;&#114;&#99;&#101;&#47;&#112;&#108;&#117;&#103;&#105;&#110;&#47;&#102;&#110;&#95;&#114;&#101;&#110;&#111;&#118;&#97;&#116;&#105;&#111;&#110;&#47;&#115;&#116;&#97;&#116;&#105;&#99;&#47;&#105;&#109;&#97;&#103;&#101;&#115;&#47;&#100;&#101;&#115;&#105;&#103;&#110;&#95;&#105;&#99;&#111;&#95;&#49;&#46;&#112;&#110;&#103;&#124;&#30005;&#35805;&#22238;&#35775;&#124;&#39044;&#32422;&#37327;&#25151;<br>&#32;&#47;&#115;&#111;&#117;&#114;&#99;&#101;&#47;&#112;&#108;&#117;&#103;&#105;&#110;&#47;&#102;&#110;&#95;&#114;&#101;&#110;&#111;&#118;&#97;&#116;&#105;&#111;&#110;&#47;&#115;&#116;&#97;&#116;&#105;&#99;&#47;&#105;&#109;&#97;&#103;&#101;&#115;&#47;&#100;&#101;&#115;&#105;&#103;&#110;&#95;&#105;&#99;&#111;&#95;&#50;&#46;&#112;&#110;&#103;&#124;&#19987;&#19994;&#35774;&#35745;&#124;&#19978;&#38376;&#37327;&#25151;');

	$setting['design_btn'] = $setting['design_btn'] ? $setting['design_btn'] : '/source/plugin/fn_renovation/static/images/design_btn.png';
	$design_btnHtml = '<a href="'.$setting['design_btn'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['design_btn'].'" height="55"/></a>';
	showsetting('&#21491;&#20391;&#25353;&#38062;&#22270;&#26631;', 'new_design_btn',$setting['design_btn'], 'filetext', '', 0, $design_btnHtml);
	
	showsetting('&#34920;&#21333;&#26631;&#39064;', 'setting[design_form_tit]', $setting['design_form_tit'] ? $setting['design_form_tit'] : '&#24744;&#30340;&#20449;&#24687;&#23558;&#34987;&#20005;&#26684;&#20445;&#23494;&#65292;&#35831;&#20934;&#30830;&#22635;&#20889;', 'text');

	echo <<<HTML
	</div>
	<!-- װ��Ԥ�� end  -->
HTML;
	
	echo <<<HTML
	<!-- �鷿���  -->
	<div class="tab-pane" id="inspect" role="tabpanel" aria-expanded="false">
HTML;

	showsetting('&#39564;&#25151;&#39029;&#38754;&#22270;&#29255;', 'setting[inspect_imgs]', $setting['inspect_imgs'] ? $setting['inspect_imgs'] : '1=/source/plugin/fn_renovation/static/images/inspect_banner.jpg
2=/source/plugin/fn_renovation/static/images/logo.png
3=/source/plugin/fn_renovation/static/images/inspect_form_bg_1.jpg
4=/source/plugin/fn_renovation/static/images/inspect_form_bg_2.jpg
6=/source/plugin/fn_renovation/static/images/inspect_content_1.jpg
7=/source/plugin/fn_renovation/static/images/inspect_content_2.jpg
8=/source/plugin/fn_renovation/static/images/inspect_btn.png','textarea','','','&#19968;&#34892;&#19968;&#22270;&#29255;&#36335;&#24452;&#65281;&#65281;&#65281;&#26684;&#24335;&#65306;&#49;&#61;&#27178;&#24133;&#65292;&#50;&#61;&#108;&#111;&#103;&#111;&#65292;&#51;&#61;&#34920;&#21333;&#32972;&#26223;&#49;&#65292;&#52;&#61;&#34920;&#21333;&#32972;&#26223;&#50;&#65292;&#54;&#61;&#20869;&#23481;&#22270;&#29255;&#49;&#65292;&#55;&#61;&#20869;&#23481;&#22270;&#29255;&#50;&#65292;&#56;&#61;&#21491;&#20391;&#25353;&#38062;&#22270;&#29255;&#65281;&#65281;&#65281;&#20363;&#22914;&#65306;<br>&#49;&#61;&#47;&#115;&#111;&#117;&#114;&#99;&#101;&#47;&#112;&#108;&#117;&#103;&#105;&#110;&#47;&#102;&#110;&#95;&#114;&#101;&#110;&#111;&#118;&#97;&#116;&#105;&#111;&#110;&#47;&#115;&#116;&#97;&#116;&#105;&#99;&#47;&#105;&#109;&#97;&#103;&#101;&#115;&#47;&#105;&#110;&#115;&#112;&#101;&#99;&#116;&#95;&#98;&#97;&#110;&#110;&#101;&#114;&#46;&#106;&#112;&#103;<br>&#50;&#61;&#47;&#115;&#111;&#117;&#114;&#99;&#101;&#47;&#112;&#108;&#117;&#103;&#105;&#110;&#47;&#102;&#110;&#95;&#114;&#101;&#110;&#111;&#118;&#97;&#116;&#105;&#111;&#110;&#47;&#115;&#116;&#97;&#116;&#105;&#99;&#47;&#105;&#109;&#97;&#103;&#101;&#115;&#47;&#108;&#111;&#103;&#111;&#46;&#112;&#110;&#103;');

	showsetting('&#39564;&#25151;&#39029;&#38754;&#25991;&#23383;', 'setting[inspect_texts]', $setting['inspect_texts'] ? stripslashes($setting['inspect_texts']) : '1=&#39564;&#25151;&#23601;&#25214;&#39564;&#25151;&#21733;<p>&#36828;&#36828;&#20302;&#20110;&#24066;&#22330;&#20215;</p>
2=&#31435;&#21363;&#30003;&#35831;&#19987;&#19994;&#39564;&#25151;&#26816;&#27979;<em>&#20005;&#26684;&#25353;&#29031;&#22269;&#23478;&#26631;&#20934;&#26816;&#27979;&#25151;&#23627;</em>
3=&#24744;&#30340;&#20449;&#24687;&#23558;&#34987;&#20005;&#26684;&#20445;&#23494;&#65292;&#35831;&#25918;&#24515;&#22635;&#20889;
4=&#30003;&#35831;&#39564;&#25151;
5=&#32852;&#31995;&#23567;&#32534;&#24494;&#20449;&#65306;pcm9510654    &#33719;&#21462;&#26356;&#22810;&#35013;&#20462;&#31119;&#21033;
6=&#35831;&#38271;&#25353;&#24038;&#20391;&#20108;&#32500;&#30721;','textarea','','','&#12304;&#27880;&#24847;&#65306;&#40664;&#35748;&#30340;&#104;&#116;&#109;&#108;&#19981;&#35201;&#20462;&#25913;&#12305;&#19968;&#34892;&#19968;&#25991;&#23383;&#65281;&#65281;&#65281;&#26684;&#24335;&#65307;&#49;&#61;&#27178;&#24133;&#26631;&#39064;&#65292;&#50;&#61;&#34920;&#21333;&#26631;&#39064;&#65292;&#51;&#61;&#34920;&#21333;&#20445;&#23494;&#25552;&#31034;&#65292;&#52;&#61;&#34920;&#21333;&#25353;&#38062;&#25991;&#23383;&#65292;&#53;&#61;&#20108;&#32500;&#30721;&#25552;&#31034;&#35821;&#65292;&#54;&#61;&#20108;&#32500;&#30721;&#25353;&#38062;&#25991;&#23383;&#65281;&#65281;&#65281;&#20363;&#22914;&#65306;<br>&#49;&#61;&#39564;&#25151;&#23601;&#25214;&#39564;&#25151;&#21733;&#60;&#112;&#62;&#36828;&#36828;&#20302;&#20110;&#24066;&#22330;&#20215;&#60;&#47;&#112;&#62;<br>&#50;&#61;&#31435;&#21363;&#30003;&#35831;&#19987;&#19994;&#39564;&#25151;&#26816;&#27979;&#60;&#101;&#109;&#62;&#20005;&#26684;&#25353;&#29031;&#22269;&#23478;&#26631;&#20934;&#26816;&#27979;&#25151;&#23627;&#60;&#47;&#101;&#109;&#62;');

	showsetting('&#39564;&#25151;&#39029;&#38754;&#20869;&#23481;&#49;', 'setting[inspect_content1]', $setting['inspect_content1'] ? stripslashes($setting['inspect_content1']) : '<div class="Title pa" style="top:-3rem">
        <p><span>&#26381;&#21153;&#27969;&#31243;</span></p>
      </div>
      <div class="Title pa" style="top:22%">
        <p><span>&#20026;&#20160;&#20040;&#35201;&#39564;&#25151;?</span></p>
      </div>
      <div class="Title pa" style="top:60%">
        <p><span>&#26032;&#25151;&#20132;&#20184;&#24120;&#35265;&#38382;&#39064;</span></p>
      </div>
      <p class="pa Text">&#25151;&#23627;&#20132;&#20184; &#26080;&#20174;&#19979;&#25163; &#31181;&#31181;&#38382;&#39064; &#39564;&#25910;&#32321;&#29712;</p>','textarea','','','&#27880;&#24847;&#65306;&#35831;&#21247;&#20462;&#25913;&#104;&#116;&#109;&#108;&#65292;&#22823;&#20332;&#20204;&#21482;&#38656;&#20462;&#25913;&#25991;&#26696;&#21363;&#21487;');
	
	showsetting('&#39564;&#25151;&#39029;&#38754;&#20869;&#23481;&#50;', 'setting[inspect_content2]', $setting['inspect_content2'] ? stripslashes($setting['inspect_content2']) : '<div class="Title pa" style="top:4.8%">
        <p><span>&#19987;&#19994;&#39564;&#25151;&#25214;&#35841;?<em class="FFFColor">&#39564;&#25151;&#21733;!</em></span></p>
      </div>
      <div class="Text pa">
        <p>&#19987;&#19994;&#39564;&#25151;&#26816;&#27979;<br>
          &#25151;&#23627;&#36136;&#37327;&#38382;&#39064;&#19968;&#32593;&#25171;&#23613;</p>
        <p style="margin-top:1rem;">&#21270;&#40857;&#24055;&#23478;&#23621;&#20026;&#20320;&#20445;&#39550;&#25252;&#33322;</p>
      </div>
      <div class="Title pa" style="top:34%">
        <p><span>&#39564;&#25151;&#20869;&#23481;</p>
      </div>','textarea','','','&#27880;&#24847;&#65306;&#35831;&#21247;&#20462;&#25913;&#104;&#116;&#109;&#108;&#65292;&#22823;&#20332;&#20204;&#21482;&#38656;&#20462;&#25913;&#25991;&#26696;&#21363;&#21487;');


	echo <<<HTML
	</div>
	<!-- �鷿��� end  -->
HTML;


	echo <<<HTML
	<!-- ����ģ������  -->
	<div class="tab-pane" id="sms" role="tabpanel" aria-expanded="false">
HTML;
	
	if($Config['PluginVar']['ShortMessageType'] == 1){

		showsetting('&#38463;&#37324;&#20113;&#31614;&#21517;&#21517;&#31216;', 'setting[AliAutograph]', $setting['AliAutograph'], 'text','','','&#33719;&#21462;&#26041;&#24335;&#65306;&#104;&#116;&#116;&#112;&#115;&#58;&#47;&#47;&#100;&#121;&#115;&#109;&#115;&#46;&#99;&#111;&#110;&#115;&#111;&#108;&#101;&#46;&#97;&#108;&#105;&#121;&#117;&#110;&#46;&#99;&#111;&#109;&#47;&#100;&#121;&#115;&#109;&#115;&#46;&#104;&#116;&#109;&#35;&#47;&#100;&#111;&#109;&#101;&#115;&#116;&#105;&#99;&#47;&#116;&#101;&#120;&#116;&#47;&#115;&#105;&#103;&#110;');

		showsetting('&#38463;&#37324;&#20113;&#36890;&#30693;&#27169;&#26495;&#67;&#79;&#68;&#69;', 'setting[AliNoticeId]', $setting['AliNoticeId'], 'text','','','&#33719;&#21462;&#26041;&#24335;&#65306;&#104;&#116;&#116;&#112;&#115;&#58;&#47;&#47;&#100;&#121;&#115;&#109;&#115;&#46;&#99;&#111;&#110;&#115;&#111;&#108;&#101;&#46;&#97;&#108;&#105;&#121;&#117;&#110;&#46;&#99;&#111;&#109;&#47;&#100;&#121;&#115;&#109;&#115;&#46;&#104;&#116;&#109;&#35;&#47;&#100;&#111;&#109;&#101;&#115;&#116;&#105;&#99;&#47;&#116;&#101;&#120;&#116;&#47;&#116;&#101;&#109;&#112;&#108;&#97;&#116;&#101;&#32;&#26684;&#24335;&#65306;<br>&#23562;&#25964;&#30340;&#20250;&#21592;&#65292;&#26377;&#23458;&#25143;&#24819;&#91;&#36;&#123;&#102;&#111;&#114;&#109;&#95;&#116;&#121;&#112;&#101;&#125;&#93;&#65292;&#22995;&#21517;&#65306;&#36;&#123;&#110;&#97;&#109;&#101;&#125;&#65292;&#35831;&#30331;&#24405;&#120;&#120;&#35013;&#20462;&#32593;&#26597;&#30475;');

		showsetting('&#38463;&#37324;&#20113;&#39564;&#35777;&#30721;&#27169;&#29256;&#67;&#79;&#68;&#69;', 'setting[AliCodeId]', $setting['AliCodeId'], 'text','','','&#33719;&#21462;&#26041;&#24335;&#65306;&#104;&#116;&#116;&#112;&#115;&#58;&#47;&#47;&#100;&#121;&#115;&#109;&#115;&#46;&#99;&#111;&#110;&#115;&#111;&#108;&#101;&#46;&#97;&#108;&#105;&#121;&#117;&#110;&#46;&#99;&#111;&#109;&#47;&#100;&#121;&#115;&#109;&#115;&#46;&#104;&#116;&#109;&#35;&#47;&#100;&#101;&#118;&#101;&#108;&#111;&#112;&#47;&#116;&#101;&#109;&#112;&#108;&#97;&#116;&#101;&#32;&#32;&#26684;&#24335;&#65306;<br>&#24744;&#30340;&#39564;&#35777;&#30721;&#65306;&#36;&#123;&#99;&#111;&#100;&#101;&#125;&#65292;&#24744;&#27491;&#36827;&#34892;&#36523;&#20221;&#39564;&#35777;&#65292;&#25171;&#27515;&#19981;&#21578;&#35785;&#21035;&#20154;&#65281;');

	}else if($Config['PluginVar']['ShortMessageType'] == 2){

		showsetting('&#30701;&#20449;&#36890;&#36890;&#30693;&#27169;&#26495;', 'setting[ChanyooNotice]', $setting['ChanyooNotice'], 'textarea','','','&#33719;&#21462;&#26041;&#24335;&#65306;&#30701;&#20449;&#36890;&#21518;&#21488;&#45;&#12299;&#27169;&#26495;&#21015;&#34920;&#45;&#12299;&#28155;&#21152;&#27169;&#26495;<br>&#27880;&#24847;&#65306;&#30701;&#20449;&#36890;&#21518;&#21488;&#28155;&#21152;&#27169;&#26495;&#30340;&#26102;&#65292;&#123;&#102;&#111;&#114;&#109;&#95;&#116;&#121;&#112;&#101;&#125;&#65292;&#123;&#110;&#97;&#109;&#101;&#125;&#26356;&#25913;&#20026;&#123;&#21464;&#37327;&#125;<br>&#26684;&#24335;&#65306;&#23562;&#25964;&#30340;&#20250;&#21592;&#65292;&#26377;&#23458;&#25143;&#24819;&#91;&#123;&#102;&#111;&#114;&#109;&#95;&#116;&#121;&#112;&#101;&#125;&#93;&#65292;&#22995;&#21517;&#65306;&#123;&#110;&#97;&#109;&#101;&#125;&#65292;&#35831;&#30331;&#24405;&#120;&#120;&#35013;&#20462;&#32593;&#26597;&#30475;&#12304;&#30701;&#20449;&#36890;&#30340;&#31614;&#21517;&#12305;');
	}

	echo <<<HTML
	</div>
	<!-- ����ģ������ end  -->
HTML;

	echo <<<HTML
	<!-- ��������  -->
	<div class="tab-pane" id="share" role="tabpanel" aria-expanded="false">
HTML;
	
	showsetting('&#20998;&#20139;&#26631;&#39064;', 'setting[WxTitle]', $setting['WxTitle'] ? $setting['WxTitle'] : '&#12304;&#39134;&#40479;&#12305;&#21516;&#22478;&#35013;&#20462;', 'text');

	showsetting('&#20998;&#20139;&#25551;&#36848;', 'setting[WxDes]', $setting['WxDes'] ? $setting['WxDes'] : '&#12304;&#39134;&#40479;&#12305;&#21516;&#22478;&#35013;&#20462;', 'textarea');

	$setting['WxImg'] = $setting['WxImg'] ? $setting['WxImg'] : '/source/plugin/fn_renovation/static/images/ico.png';
	$WxImgHtml = '<a href="'.$setting['WxImg'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['WxImg'].'" height="55"/></a>&#23610;&#23544;&#49;&#48;&#48;&#32;&#42;&#32;&#49;&#48;&#48;';
	showsetting('&#20998;&#20139;&#22270;&#29255;', 'new_WxImg',$setting['WxImg'], 'filetext', '', 0, $WxImgHtml);

	showsetting('&#35013;&#20462;&#20844;&#21496;&#20998;&#20139;&#26631;&#39064;', 'setting[company_share_title]', $setting['company_share_title'] ? $setting['company_share_title'] : '&#36825;&#23478;&#35013;&#20462;&#20844;&#21496;&#19981;&#38169;&#65292;&#123;&#110;&#97;&#109;&#101;&#125;', 'text','','','&#123;&#110;&#97;&#109;&#101;&#125;&#20195;&#34920;&#20844;&#21496;&#21517;&#31216;&#65292;&#123;&#97;&#100;&#100;&#114;&#101;&#115;&#115;&#125;&#20195;&#34920;&#22320;&#22336;');

	showsetting('&#35013;&#20462;&#20844;&#21496;&#20998;&#20139;&#25551;&#36848;', 'setting[company_share_desc]', $setting['company_share_desc'] ? $setting['company_share_desc'] : '&#22320;&#22336;&#65306;&#123;&#97;&#100;&#100;&#114;&#101;&#115;&#115;&#125;', 'text','','','&#123;&#110;&#97;&#109;&#101;&#125;&#20195;&#34920;&#20844;&#21496;&#21517;&#31216;&#65292;&#123;&#97;&#100;&#100;&#114;&#101;&#115;&#115;&#125;&#20195;&#34920;&#22320;&#22336;');
	
	showsetting('&#24314;&#26448;&#20998;&#20139;&#26631;&#39064;', 'setting[MaterialWxTitle]', $setting['MaterialWxTitle'] ? $setting['MaterialWxTitle'] : '&#12304;&#39134;&#40479;&#12305;&#21516;&#22478;&#24314;&#26448;', 'text');

	showsetting('&#24314;&#26448;&#20998;&#20139;&#25551;&#36848;', 'setting[MaterialWxDes]', $setting['MaterialWxDes'] ? $setting['MaterialWxDes'] : '&#12304;&#39134;&#40479;&#12305;&#21516;&#22478;&#24314;&#26448;', 'textarea');

	$setting['MaterialWxImg'] = $setting['MaterialWxImg'] ? $setting['MaterialWxImg'] : '/source/plugin/fn_renovation/static/images/ico.png';
	$MaterialWxImgHtml = '<a href="'.$setting['MaterialWxImg'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['MaterialWxImg'].'" height="55"/></a>&#23610;&#23544;&#49;&#48;&#48;&#32;&#42;&#32;&#49;&#48;&#48;';
	showsetting('&#24314;&#26448;&#20998;&#20139;&#22270;&#29255;', 'new_MaterialWxImg',$setting['MaterialWxImg'], 'filetext', '', 0, $MaterialWxImgHtml);
	
	showsetting('&#24314;&#26448;&#20844;&#21496;&#20998;&#20139;&#26631;&#39064;', 'setting[material_company_share_title]', $setting['material_company_share_title'] ? $setting['material_company_share_title'] : '&#36825;&#23478;&#24314;&#26448;&#19981;&#38169;&#65292;&#123;&#110;&#97;&#109;&#101;&#125;', 'text','','','&#123;&#110;&#97;&#109;&#101;&#125;&#20195;&#34920;&#20844;&#21496;&#21517;&#31216;&#65292;&#123;&#97;&#100;&#100;&#114;&#101;&#115;&#115;&#125;&#20195;&#34920;&#22320;&#22336;');

	showsetting('&#24314;&#26448;&#20844;&#21496;&#20998;&#20139;&#25551;&#36848;', 'setting[material_company_share_desc]', $setting['material_company_share_desc'] ? $setting['material_company_share_desc'] : '&#22320;&#22336;&#65306;&#123;&#97;&#100;&#100;&#114;&#101;&#115;&#115;&#125;', 'text','','','&#123;&#110;&#97;&#109;&#101;&#125;&#20195;&#34920;&#20844;&#21496;&#21517;&#31216;&#65292;&#123;&#97;&#100;&#100;&#114;&#101;&#115;&#115;&#125;&#20195;&#34920;&#22320;&#22336;');

	echo <<<HTML
	</div>
	<!-- �������� end  -->
HTML;

	echo <<<HTML
	<!-- ��ɫ����  -->
	<div class="tab-pane" id="color" role="tabpanel" aria-expanded="false">
HTML;

	showsetting('&#20027;&#39064;&#39068;&#33394;', 'setting[Color]', $setting['Color'] ? $setting['Color'] : '#34c083', 'color');

	showsetting('&#21103;&#20027;&#39064;&#39068;&#33394;', 'setting[FColor]', $setting['FColor'] ? $setting['FColor'] : '#ff8a00', 'color');

	showsetting('&#21103;&#20027;&#39064;&#39068;&#33394;2', 'setting[FFColor]', $setting['FFColor'] ? $setting['FFColor'] : '#ccf2e2', 'color');

	showsetting('&#21103;&#20027;&#39064;&#39068;&#33394;3', 'setting[FFFColor]', $setting['FFFColor'] ? $setting['FFFColor'] : '#17cca8', 'color');

	showsetting('&#21103;&#20027;&#39064;&#39068;&#33394;4;', 'setting[FFFFColor]', $setting['FFFFColor'] ? $setting['FFFFColor'] : '#fff0ec', 'color');

	showsetting('&#28176;&#21464;&#20027;&#39064;&#39068;&#33394;&#49;&#45;&#48;', 'setting[ChangeColor1_0]', $setting['ChangeColor1_0'] ? $setting['ChangeColor1_0'] : '#3cd5a9', 'color');

	showsetting('&#28176;&#21464;&#20027;&#39064;&#39068;&#33394;&#49;&#45;&#49;', 'setting[ChangeColor1_1]', $setting['ChangeColor1_1'] ? $setting['ChangeColor1_1'] : '#64d6a1', 'color');


	echo <<<HTML
	</div>
	<!-- ��ɫ���� end  -->
HTML;
	
	if(in_array($Config['PluginVar']['AppType'],array('1','2','3'))){

	echo <<<HTML
	<!-- APP����  -->
	<div class="tab-pane" id="app" role="tabpanel" aria-expanded="false">
HTML;

	showsetting('&#65;&#80;&#80;&#23458;&#26381;&#117;&#105;&#100;', 'setting[AppOnlineUid]', $setting['AppOnlineUid'], 'text');

	showsetting('&#65;&#80;&#80;&#23458;&#26381;&#21517;&#23383;', 'setting[AppOnlineName]', $setting['AppOnlineName'], 'text');
	
	if(in_array($Config['PluginVar']['AppType'],array('2','3'))){
		$AppOnlineFaceHtml = $setting['AppOnlineFace'] ? '<a href="'.$setting['AppOnlineFace'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['AppOnlineFace'].'" height="55"/></a>' : '';
		showsetting('&#65;&#80;&#80;&#23458;&#26381;&#22836;&#20687;', 'new_AppOnlineFace',$setting['AppOnlineFace'], 'filetext', '', 0, $AppOnlineFaceHtml);
	}

	showtagheader('div', 'mag_app_table', $Config['PluginVar']['AppType'] == 1 ? true : '','mag_app_table');
		showsetting('&#39532;&#30002;&#83;&#101;&#99;&#114;&#101;&#116;', 'setting[MagSecret]', $setting['MagSecret'], 'text','','','&#19981;&#22635;&#21017;&#32487;&#25215;&#12304;&#20840;&#23616;&#35774;&#32622;&#12305;&#30340;&#35774;&#32622;');
		showsetting('&#39532;&#30002;&#21161;&#25163;&#83;&#101;&#99;&#114;&#101;&#116;', 'setting[MagAssistantSecret]', $setting['MagAssistantSecret'], 'text','','','&#19981;&#22635;&#21017;&#32487;&#25215;&#12304;&#20840;&#23616;&#35774;&#32622;&#12305;&#30340;&#35774;&#32622;');
		showsetting('&#39532;&#30002;&#21161;&#25163;&#25512;&#36865;', 'setting[MagAssistantPush]', $setting['MagAssistantPush'], 'radio','','','&#19981;&#22635;&#21017;&#32487;&#25215;&#12304;&#20840;&#23616;&#35774;&#32622;&#12305;&#30340;&#35774;&#32622;');
	showtagfooter('div');
	
	showtagheader('div', 'qf_app_table', $Config['PluginVar']['AppType'] == 2 ? true : '','qf_app_table');
		showsetting('&#21315;&#24070;&#25903;&#20184;&#35746;&#21333;&#31867;&#22411;&#73;&#68;', 'setting[qf_type]', $setting['qf_type'], 'text','','','&#19981;&#22635;&#21017;&#32487;&#25215;&#12304;&#20840;&#23616;&#35774;&#32622;&#12305;&#30340;&#35774;&#32622;');
		showsetting('&#21315;&#24070;&#26381;&#21153;&#21495;&#29992;&#25143;&#73;&#68;', 'setting[qf_from_id]', $setting['qf_from_id'], 'text','','','&#19981;&#22635;&#21017;&#32487;&#25215;&#12304;&#20840;&#23616;&#35774;&#32622;&#12305;&#30340;&#35774;&#32622;');
	showtagfooter('div');

	echo <<<HTML
	</div>
	<!-- APP���� end  -->
HTML;
	}

	showsubmit('DetailSubmit', '&#20445;&#23384;&#37197;&#32622;');
	showtagfooter('div');
	showtagfooter('div');
	showformfooter(); /*Dism_taobao-com*/
	showtagfooter('div');
	
	$setting['banners'] = $common_setting ? $setting['banners'] : array(
		array('img'=>'/source/plugin/fn_renovation/static/images/banner1.jpg'),
		array('img'=>'/source/plugin/fn_renovation/static/images/banner2.jpg')	
	);
	if($setting['banners']){
		foreach($setting['banners'] as $Key => $Val) {
			$banners_js_array[] = '"'.$Val['img'].'|'.$setting['banners'][$Key]['title'].'|'.$setting['banners'][$Key]['link'].'"';
		}
		$UpLoadHtml .= '
		var InputArray = new Array('.implode(',',$banners_js_array).');
		$("#Banners").AppUpload({InputName:"new_banners",InputLink:true,InputExist:true,InputArray:InputArray,Move:true});';
	}else{
		$UpLoadHtml .= '$("#Banners").AppUpload({InputName:"new_banners",InputLink:true,Move:true});';
	}

	if($setting['nav_bottom_ad']){
		foreach($setting['nav_bottom_ad'] as $Key => $Val) {
			$nav_bottom_ad_js_array[] = '"'.$Val['img'].'|'.$setting['nav_bottom_ad'][$Key]['title'].'|'.$setting['nav_bottom_ad'][$Key]['link'].'"';
		}
		$UpLoadHtml .= '
		var InputArray = new Array('.implode(',',$nav_bottom_ad_js_array).');
		$("#nav_bottom_ad").AppUpload({InputName:"new_nav_bottom_ad",InputLink:true,InputExist:true,InputArray:InputArray,Move:true});';
	}else{
		$UpLoadHtml .= '$("#nav_bottom_ad").AppUpload({InputName:"new_nav_bottom_ad",InputLink:true,Move:true});';
	}

	$setting['min_index_nav'] = $common_setting ? $setting['min_index_nav'] : array(
		array('img'=>'/source/plugin/fn_renovation/static/images/index_ad_1.jpg','link'=>'[siteurl]plugin.php?id=fn_renovation&m=free_quote'),
		array('img'=>'/source/plugin/fn_renovation/static/images/index_ad_2.jpg','link'=>'[siteurl]plugin.php?id=fn_renovation&m=design'),
		array('img'=>'/source/plugin/fn_renovation/static/images/index_ad_3.jpg','link'=>'[siteurl]plugin.php?id=fn_renovation&m=inspect'),
	);
	if($setting['min_index_nav']){
		foreach($setting['min_index_nav'] as $Key => $Val) {
			$min_index_nav_js_array[] = '"'.$Val['img'].'|'.$setting['min_index_nav'][$Key]['title'].'|'.$setting['min_index_nav'][$Key]['link'].'"';
		}
		$UpLoadHtml .= '
		var InputArray = new Array('.implode(',',$min_index_nav_js_array).');
		$("#MinIndexNav").AppUpload({InputName:"new_min_index_nav",InputLink:true,InputExist:true,InputArray:InputArray,Move:true});';
	}else{
		$UpLoadHtml .= '$("#MinIndexNav").AppUpload({InputName:"new_min_index_nav",InputLink:true,Move:true});';
	}

	$setting['material_banners'] = $common_setting ? $setting['material_banners'] : array(
		array('img'=>'/source/plugin/fn_renovation/static/images/banner1.jpg'),
		array('img'=>'/source/plugin/fn_renovation/static/images/banner2.jpg')	
	);

	if($setting['material_banners']){
		foreach($setting['material_banners'] as $Key => $Val) {
			$material_banners_js_array[] = '"'.$Val['img'].'|'.$setting['material_banners'][$Key]['title'].'|'.$setting['material_banners'][$Key]['link'].'"';
		}
		$UpLoadHtml .= '
		var InputArray = new Array('.implode(',',$material_banners_js_array).');
		$("#MaterialBanners").AppUpload({InputName:"new_material_banners",InputLink:true,InputExist:true,InputArray:InputArray,Move:true});';
	}else{
		$UpLoadHtml .= '$("#MaterialBanners").AppUpload({InputName:"new_material_banners",InputLink:true,Move:true});';
	}

	$setting['user_ad'] = $common_setting ? $setting['user_ad'] : array(
		array('img'=>'/source/plugin/fn_renovation/static/images/vip.jpg','link'=>'[siteurl]plugin.php?id=fn_renovation&m=buy_store_level')
	);
	if($setting['user_ad']){
		foreach($setting['user_ad'] as $Key => $Val) {
			$user_ad_js_array[] = '"'.$Val['img'].'|'.$setting['user_ad'][$Key]['title'].'|'.$setting['user_ad'][$Key]['link'].'"';
		}
		$UpLoadHtml .= '
		var InputArray = new Array('.implode(',',$user_ad_js_array).');
		$("#UserAd").AppUpload({InputName:"new_user_ad",InputLink:true,InputExist:true,InputArray:InputArray,Move:true});';
	}else{
		$UpLoadHtml .= '$("#UserAd").AppUpload({InputName:"new_user_ad",InputLink:true,Move:true});';
	}
	
	$setting['material_user_ad'] = $common_setting ? $setting['material_user_ad'] : array(
		array('img'=>'/source/plugin/fn_renovation/static/images/vip.jpg','link'=>'[siteurl]plugin.php?id=fn_renovation&m=buy_store_level_material')
	);
	if($setting['material_user_ad']){
		foreach($setting['material_user_ad'] as $Key => $Val) {
			$material_user_ad_js_array[] = '"'.$Val['img'].'|'.$setting['material_user_ad'][$Key]['title'].'|'.$setting['material_user_ad'][$Key]['link'].'"';
		}
		$UpLoadHtml .= '
		var InputArray = new Array('.implode(',',$material_user_ad_js_array).');
		$("#UserMaterialAd").AppUpload({InputName:"new_material_user_ad",InputLink:true,InputExist:true,InputArray:InputArray,Move:true});';
	}else{
		$UpLoadHtml .= '$("#UserMaterialAd").AppUpload({InputName:"new_material_user_ad",InputLink:true,Move:true});';
	}

	$setting['pc_banners'] = $common_setting ? $setting['pc_banners'] : array(
		array('img'=>'/source/plugin/fn_renovation/static/images/pc_banner.jpg'),
		array('img'=>'/source/plugin/fn_renovation/static/images/pc_banner1.jpg')
	);
	if($setting['pc_banners']){
		foreach($setting['pc_banners'] as $Key => $Val) {
			$pc_banners_js_array[] = '"'.$Val['img'].'|'.$setting['pc_banners'][$Key]['title'].'|'.$setting['pc_banners'][$Key]['link'].'"';
		}
		$UpLoadHtml .= '
		var InputArray = new Array('.implode(',',$pc_banners_js_array).');
		$("#pc_banners").AppUpload({InputName:"new_pc_banners",InputLink:true,InputExist:true,InputArray:InputArray,Move:true});';
	}else{
		$UpLoadHtml .= '$("#pc_banners").AppUpload({InputName:"new_pc_banners",InputLink:true,Move:true});';
	}

	$setting['footer_qr_list'] = $common_setting ? $setting['footer_qr_list'] : array(
		array('img'=>'/source/plugin/fn_renovation/static/images/qr_code1.jpg','title'=>'&#25163;&#26426;&#29256;'),
		array('img'=>'/source/plugin/fn_renovation/static/images/qr_code2.jpg','title'=>'&#24494;&#20449;&#20844;&#20247;&#21495;'),
		array('img'=>'/source/plugin/fn_renovation/static/images/qr_code3.jpg','title'=>'&#23567;&#31243;&#24207;'),
	);
	if($setting['footer_qr_list']){
		foreach($setting['footer_qr_list'] as $Key => $Val) {
			$footer_qr_list_js_array[] = '"'.$Val['img'].'|'.$setting['footer_qr_list'][$Key]['title'].'|'.$setting['footer_qr_list'][$Key]['link'].'"';
		}
		$UpLoadHtml .= '
		var InputArray = new Array('.implode(',',$footer_qr_list_js_array).');
		$("#footer_qr_list").AppUpload({InputName:"new_footer_qr_list",InputTitle:true,InputExist:true,InputArray:InputArray,Move:true});';
	}else{
		$UpLoadHtml .= '$("#footer_qr_list").AppUpload({InputName:"new_footer_qr_list",InputTitle:true,Move:true});';
	}

	if($setting['pc_home_ad_1']){
		foreach($setting['pc_home_ad_1'] as $Key => $Val) {
			$pc_home_ad_1_js_array[] = '"'.$Val['img'].'|'.$setting['pc_home_ad_1'][$Key]['title'].'|'.$setting['pc_home_ad_1'][$Key]['link'].'"';
		}
		$UpLoadHtml .= '
		var InputArray = new Array('.implode(',',$pc_home_ad_1_js_array).');
		$("#pc_home_ad_1").AppUpload({InputName:"new_pc_home_ad_1",InputLink:true,InputExist:true,InputArray:InputArray,Move:true});';
	}else{
		$UpLoadHtml .= '$("#pc_home_ad_1").AppUpload({InputName:"new_pc_home_ad_1",InputLink:true,Move:true});';
	}

	if($setting['pc_home_ad_2']){
		foreach($setting['pc_home_ad_2'] as $Key => $Val) {
			$pc_home_ad_2_js_array[] = '"'.$Val['img'].'|'.$setting['pc_home_ad_2'][$Key]['title'].'|'.$setting['pc_home_ad_2'][$Key]['link'].'"';
		}
		$UpLoadHtml .= '
		var InputArray = new Array('.implode(',',$pc_home_ad_2_js_array).');
		$("#pc_home_ad_2").AppUpload({InputName:"new_pc_home_ad_2",InputLink:true,InputExist:true,InputArray:InputArray,Move:true});';
	}else{
		$UpLoadHtml .= '$("#pc_home_ad_2").AppUpload({InputName:"new_pc_home_ad_2",InputLink:true,Move:true});';
	}

	if($setting['pc_home_ad_3']){
		foreach($setting['pc_home_ad_3'] as $Key => $Val) {
			$pc_home_ad_3_js_array[] = '"'.$Val['img'].'|'.$setting['pc_home_ad_3'][$Key]['title'].'|'.$setting['pc_home_ad_3'][$Key]['link'].'"';
		}
		$UpLoadHtml .= '
		var InputArray = new Array('.implode(',',$pc_home_ad_3_js_array).');
		$("#pc_home_ad_3").AppUpload({InputName:"new_pc_home_ad_3",InputLink:true,InputExist:true,InputArray:InputArray,Move:true});';
	}else{
		$UpLoadHtml .= '$("#pc_home_ad_3").AppUpload({InputName:"new_pc_home_ad_3",InputLink:true,Move:true});';
	}

	echo $UploadConfig['CssJsHtml'];
	echo '<script>'.$UpLoadHtml.'</script>';
	
}else{

	foreach($_GET['setting'] as $key => $value) {
		$setting[$key] = is_array($value) ? $value : addslashes($value);
	}

	foreach($_GET['upload_admin'] as $key => $value){
		if(strpos($key,'new_') !== false){
			$key_name = str_replace(array('new_'),'',$key);
			$setting[$key_name] = array();
			foreach($_GET[$key] as $k => $v) {
				$setting[$key_name][$k]['img'] = strpos($v,'http') !== false ? $v : $_G['siteurl'].$v;
				$setting[$key_name][$k]['link'] = $_GET[$key.'_link'][$k];
				$setting[$key_name][$k]['title'] = $_GET[$key.'_title'][$k];
			}
		}
	}

	foreach(array('artisan_group','artisan_top','navs','footer_nav','add_nav','company_top','material_company_top','pc_nav','pc_min_nav') as $common_nav_value){
		foreach($_GET['common_list'][$common_nav_value] as $nav_key => $nav_value){
			foreach($_GET['common_list'][$common_nav_value]['displayorder'] as $key => $value){
				$new_setting[$common_nav_value][$key][$nav_key] = filter_string($_GET['common_list'][$common_nav_value][$nav_key][$key]);
				if($_FILES['common_list']['size'][$common_nav_value]['file_'.$nav_key][$key]){
					$images = array(
						'name' => $_FILES['common_list']['name'][$common_nav_value]['file_'.$nav_key][$key],
						'type' => $_FILES['common_list']['type'][$common_nav_value]['file_'.$nav_key][$key],
						'tmp_name' => $_FILES['common_list']['tmp_name'][$common_nav_value]['file_'.$nav_key][$key],
						'error' => $_FILES['common_list']['error'][$common_nav_value]['file_'.$nav_key][$key],
						'size' => $_FILES['common_list']['size'][$common_nav_value]['file_'.$nav_key][$key]
					);
					$FileCode = Fn_Upload($images);
					$new_setting[$common_nav_value][$key][$nav_key] = $FileCode['Path'];
				}
			}
		}
		$setting[$common_nav_value] = array_sort($new_setting[$common_nav_value],'displayorder');
	}

	foreach($setting['artisan_group'] as $group){
		$new_artisan_group[$group['id']] = $group; 
	}
	$setting['artisan_group'] = $new_artisan_group;

	foreach($_FILES as $file_key => $file_value){
		if(strpos($file_key,'new_') !== false){
			$key = str_replace(array('TMPnew_','new_'),'',$file_key);
			if($_FILES[$file_key]['size']){
				$FileCode = Fn_Upload($_FILES[$file_key]);
				if($FileCode['Errorcode']){
					cpmsg($Fn_Admin->Config['LangVar']['ImgErr'],'','error');
					exit();
				}else{
					$setting[$key] = $FileCode['Path'];
				}
			}else{
				$file_key = str_replace(array('TMPnew_'),array('new_'),$file_key);
				if(!preg_match('/.*(\.png|\.jpg|\.jpeg|\.gif)$/',$_GET[$file_key]) && $_GET[$file_key]){
					cpmsg($Fn_Admin->Config['LangVar']['ImgErr'],'','error');
					exit();
				}else{
					$setting[$key] = addslashes(strip_tags($_GET[$file_key]));
				}
			}
		}
	}
	savecache($setting_name,$setting);
	fn_cpmsg($Fn_Admin->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
	exit();

}
//From: Dism_taobao_com
?>