<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

showtagheader('div', 'box', true,'box');
showtagheader('div', 'box-body', true,'box-body');
showtagheader('div', 'tab-content', true,'tab-content');
showsetting($Fn_Hd->Config['LangVar']['PluginLink'], 'PluginLink',$_G['siteurl'].'plugin.php?id=fn_hd', 'text');
showtagfooter('div');
showtagfooter('div');
showtagfooter('div');

?>