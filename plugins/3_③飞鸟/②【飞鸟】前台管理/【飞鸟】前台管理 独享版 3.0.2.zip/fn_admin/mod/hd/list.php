<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('hd_all') && !$Fn_Admin->CheckUserGroup('hd_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$SubModel = in_array($_GET['submodel'], array('list','add')) ? $_GET['submodel'] : 'list';
$Fn_Admin->Config['IframeSubModelUrl'] = $Fn_Admin->Config['IframeItemUrl'].'&submodel='.$SubModel;
$NavClass = array($SubModel=>'btn-info Hover');

//����
echo <<<Nav
<div class="SubModelNav">
  <ul>
	<li class="{$NavClass['list']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=list" target="_self">{$Fn_Admin->Config['LangVar']['HdLeftNavArray']['list']}</a></li>
    <li class="{$NavClass['add']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=add" target="_self">{$Fn_Admin->Config['LangVar']['AddEditTitle']}</a></li>
  </ul>
  <div class="both"></div>
</div>
Nav;


if($SubModel == 'list'){//�б�
	$Do = in_array($_GET['do'], array('Del','Export','Fictitious')) ? $_GET['do'] : 'List';

	$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeItemUrl'];
	if($Do == 'List'){
		if(!submitcheck('Submit')) {
			$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
			/* ��ѯ���� */
			$Where = '';
			$Order = 'H.displayorder';
			
			$Where = preg_replace('/and/','where',$Where,1);
			$Limit = 30;
			$Page = $_GET['page']?intval($_GET['page']):1;
			/* ��ѯ���� End */
			
			/* ģ����� */		
			showtagheader('div', 'row', true,'row');
			showtagheader('div', 'col-12', true,'col-12');
			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-body', true,'box-body');
			showtagheader('div', 'table-responsive', true,'table-responsive');
			showformheader($FormUrl,'enctype="multipart/form-data"');
			showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
			showsubtitle(array(
				$Fn_Hd->Config['LangVar']['DisplayOrder'],
				$Fn_Hd->Config['LangVar']['Title'],
				$Fn_Hd->Config['LangVar']['PluginLink'],
				$Fn_Hd->Config['LangVar']['ActivityTitle'].$Fn_Hd->Config['LangVar']['PeopleTitle'],
				$Fn_Hd->Config['LangVar']['EnrolmentCount'],
				$Fn_Hd->Config['LangVar']['EnrolmentExamineCount'],
				$Fn_Hd->Config['LangVar']['PostCountTitle'],
				$Fn_Hd->Config['LangVar']['Click'],
				$Fn_Hd->Config['LangVar']['DisplayTitle'],
				$Fn_Hd->Config['LangVar']['SignUpStartTime'],
				$Fn_Hd->Config['LangVar']['StartTime'],
				$Fn_Hd->Config['LangVar']['TimeTitle'],
				$Fn_Hd->Config['LangVar']['OperationTitle']
			), 'header tbm tc');
			
			$ModulesList = GetModulesList($Page,$Limit,$Where,$Order);
			
			foreach ($ModulesList as $Module) {
				$Module['param'] = unserialize($Module['param']);
				$PostCount = DB::result_first('SELECT COUNT(*) FROM '.DB::table($Fn_Hd->TablePost).' where aid = '.$Module['id']);
				showtablerow('', array('class="tc w80"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
					'<input type="text" class="input form-control w50" name="displayorder['.$Module['id'].']" value='.$Module['displayorder'].'>',
					'<input type="text" class="input form-control w200" name="title['.$Module['id'].']" value='.$Module['title'].'>',
					'<input type="text" class="input form-control w400" value='.$Fn_Hd->Config['ViewUrl'].$Module['id'].' readonly>',
					$Module['param']['people'],
					$Fn_Hd->GetSignUpCount(' and aid = '.$Module['id']),
					$Fn_Hd->GetSignUpCount(' and examine  = 1 and aid = '.$Module['id']),
					$PostCount,
					$Module['click'],
					$Module['display'] ? '<span class="label bg-danger">'.$Fn_Hd->Config['LangVar']['Yes'].'</span>' : '<span class="label bg-secondary">'.$Fn_Hd->Config['LangVar']['No'].'</span>',
					$Module['sign_up_start_time'] ? date('Y-m-d H:i',$Module['sign_up_start_time']) : '',
					$Module['start_time'] ? date('Y-m-d H:i',$Module['start_time']) : '',
					date('Y-m-d',$Module['dateline']),
					'<a href="'.$Fn_Hd->Config['ViewUrl'].$Module['id'].'" target="_blank">'.cplang('view').'</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&aid='.$Module['id'].'">'.$Fn_Hd->Config['LangVar']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['ModUrl'].'&item=post_list&aid='.$Module['id'].'&iframe=true">'.$Fn_Hd->Config['LangVar']['OpCommentTitle'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Del&aid='.$Module['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;">'.$Fn_Hd->Config['LangVar']['DelTitle'].'</a><br><a href="'.$Fn_Admin->Config['ModUrl'].'&item=sign_up_list&iframe=true&aid='.$Module['id'].'">'.$Fn_Hd->Config['LangVar']['SignUpOpTitle'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Fictitious&aid='.$Module['id'].'">'.$Fn_Hd->Config['LangVar']['Fictitious'].'</a>&nbsp;&nbsp;<a href="'.$Fn_Hd->Config['ExportSignUpListUrl'].$Module['id'].'">'.$Fn_Hd->Config['LangVar']['ExportTitle'].'</a>',
				));
			}
			showsubmit('Submit','&#20445;&#23384;&#37197;&#32622;','','','',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));
			showtablefooter(); /*dism��taobao��com*/
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			/* ģ����� End */
		}else{
			if(isset($_GET['displayorder']) && is_array($_GET['displayorder'])){
				foreach($_GET['displayorder'] as $Id => $Val) {
					$Id = intval($Id);
					$Data['displayorder'] = intval($Val);
					$Data['title'] = addslashes(strip_tags($_GET['title'][$Id]));
					DB::update($Fn_Hd->TableHd,$Data,'id = '.$Id);
				}
				fn_cpmsg($Fn_Hd->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
			}
		}
	}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['aid']){//ɾ��
		if(!$Fn_Admin->CheckUserGroup('hd_all') && !$Fn_Admin->CheckUserGroup('hd_list_del')){//Ȩ���ж�
			fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
			exit();
		}
		$AId = intval($_GET['aid']);
		DB::delete($Fn_Hd->TableHd,'id ='.$AId);
		DB::delete($Fn_Hd->TableSignUp,'aid ='.$AId);
		DB::delete($Fn_Hd->TablePost,'aid ='.$AId);

		GetInsertDoLog('del_list_hd','fn_'.$_GET['mod'],array('id'=>$_GET['aid']));//������¼

		fn_cpmsg($Fn_Hd->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
	}else if($Do == 'Fictitious' && $_GET['aid']){//���������û�
		$Item = $Fn_Hd->GetViewthread($_GET['aid']);
		if(!submitcheck('DetailSubmit')){

			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-header', true,'with-border box-header');
			showtitle($Fn_Hd->Config['LangVar']['Fictitious'],'class="box-title"');
			showtagfooter('div');
			showformheader($Fn_Admin->Config['IframeItemUrl'].'&do='.$Do.'&aid='.$_GET['aid'],'enctype');
			showtagheader('div', 'box-body', true,'box-body');

			showsetting($Fn_Hd->Config['LangVar']['FictitiousUid'], 'uids', '', 'textarea','','',$Fn_Hd->Config['LangVar']['FictitiousUidPrompt']);
			showsetting($Fn_Hd->Config['LangVar']['ExamineState'], 'examine',1,'radio');
			
			showsubmit('DetailSubmit','&#20445;&#23384;&#37197;&#32622;');
			showtagfooter('div');
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');
		}else{
			$Uids = array_filter(explode("\n",$_GET['uids']));
			if($Uids){
				$UserNameArray = DB::fetch_all('SELECT uid,username FROM '.DB::table('common_member').' where uid in ('.implode(',',$Uids).')',array(),'uid');//��������
				foreach($Uids as $Val){
					$SignUpItem = DB::fetch_first('SELECT * FROM '.DB::table($Fn_Hd->TableSignUp).' where aid = '.intval($Item['id']).' and uid = '.intval($Val));
					if(!$SignUpItem){
						$SignUpData['aid'] = intval($Item['id']);
						$SignUpData['uid'] = intval($Val);
						$SignUpData['username'] = $UserNameArray[intval($Val)]['username'];
						for($I = 0;$I < 100;$I++){//������
							$SignUpData['code'] = rand(1000,99999999);
							if(!DB::fetch_first('SELECT * FROM '.DB::table($Fn_Hd->TableSignUp).' where aid = '.intval($Item['id']).' and code = '.intval($SignUpData['code']))){
								break;
							};
						}
						$SignUpData['count'] = 1;
						$SignUpData['display'] = 1;
						$SignUpData['examine'] = intval($_GET['examine']);
						$SignUpData['dateline'] = $SignUpData['updateline'] = time();
						DB::insert($Fn_Hd->TableSignUp,$SignUpData);
					}	
				}
				fn_cpmsg($Fn_Hd->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
			}else{
				fn_cpmsg($Fn_Hd->Config['LangVar']['UpdateErr'],'','error');
			}
		}
	}
}else if($SubModel == 'add'){//���ӻ�༭
	if(!$Fn_Admin->CheckUserGroup('hd_all') && !$Fn_Admin->CheckUserGroup('hd_list_add')){//Ȩ���ж�
		fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
		exit();
	}

	$ClassList = $Fn_Hd->GetClassList();
	if($ClassList[$_GET['new_class']]['param']){$NewClass['param'] = unserialize($ClassList[$_GET['new_class']]['param']);}

	$AId = intval($_GET['aid']);
	$Item = $AId ? $Fn_Hd->QueryOne($Fn_Hd->TableHd,$AId) : array();
	if($Item['param']){$Item['param'] = unserialize($Item['param']);}

	if(!submitcheck('DetailSubmit')) {
		$OpTitle = $Fn_Hd->Config['LangVar']['AddTitle'];
		if($Item)$OpTitle = $Fn_Hd->Config['LangVar']['EditTitle'];
		
		//ͼƬ�ϴ�
		if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_assembly/class/class_upload.php')){
			@require_once libfile('class/upload','plugin/fn_assembly');
			$UploadConfig = fn_upload::Config();
		}

		echo '<script src="'.$Config['StaticPath'].'/ueditor/'.CHARSET.'/ueditor.config.js" type="text/javascript"></script><script src="'.$Config['StaticPath'].'/ueditor/'.CHARSET.'/ueditor.all.js" type="text/javascript"></script>';
		
		showtagheader('div', 'box', true,'box');
		showformheader($Fn_Admin->Config['IframeSubModelUrl'].'&aid='.$AId,'enctype');
		echo <<<HTML
		<ul class="nav nav-tabs customtab" role="tablist">
          <li class="nav-item"> <a class="nav-link active" data-toggle="tab" href="#basics" role="tab" aria-expanded="true"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#22522;&#30784;&#35774;&#32622;</span></a> </li>
		  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#sign-up" role="tab" aria-expanded="false"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">{$Fn_Hd->Config['LangVar']['EnrolmentSetting']}</span></a> </li>
		  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#pay" role="tab" aria-expanded="false"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#25903;&#20184;&#35774;&#32622;</span></a> </li>
		  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#comment" role="tab" aria-expanded="false"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#35780;&#35770;&#35774;&#32622;</span></a> </li>
		  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#other" role="tab" aria-expanded="false"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#20854;&#20182;&#35774;&#32622;</span></a> </li>
        </ul>
HTML;
		showtagheader('div', 'box-body', true,'box-body');
		showtagheader('div', 'tab-content', true,'tab-content');
		
		echo <<<HTML
		<!-- ��������  -->
		<div class="tab-pane active" id="basics" role="tabpanel" aria-expanded="true">
HTML;

		showsetting($Fn_Hd->Config['LangVar']['Title'], 'title', $Item['title'], 'text');
	
		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_Hd->Config['LangVar']['CoverTitle'].' '.$Fn_Hd->Config['LangVar']['CoverPrompt'].'</label><div class="col-sm-9"><div class="AdminSingleUpload"><div class="PhotoControl" id="CoverPhotoControl"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';
		
		showsetting($Fn_Hd->Config['LangVar']['TypeTitle'], array('type',DyadicArray($Fn_Hd->Config['LangVar']['TypeArray'])),$Item['type'] ? $Item['type'] : 1,'mradio');
		
		foreach($ClassList as $Val) {
			$SelectClassList[] = array($Val['id'], $Val['name']);
		}
		showsetting($Fn_Hd->Config['LangVar']['ClassTitle'], array('classid', $SelectClassList), $Item['classid'] ? $Item['classid'] : $_GET['new_class'], 'select');


		showsetting($Fn_Hd->Config['LangVar']['SignUpStartTime'], 'sign_up_start_time',$Item['sign_up_start_time'] ? date('Y-m-d H:i',$Item['sign_up_start_time']) : '', 'calendar','','','',1);

		showsetting($Fn_Hd->Config['LangVar']['SignUpEndTime'], 'sign_up_end_time',$Item['sign_up_end_time'] ? date('Y-m-d H:i',$Item['sign_up_end_time']) : '', 'calendar','','','',1);

		showsetting($Fn_Hd->Config['LangVar']['StartTime'], 'start_time',$Item['start_time'] ? date('Y-m-d H:i',$Item['start_time']) : '', 'calendar','','','',1);

		showsetting($Fn_Hd->Config['LangVar']['EndTime'], 'end_time',$Item['end_time'] ? date('Y-m-d H:i',$Item['end_time']) : '', 'calendar','','','',1);

		showsetting($Fn_Hd->Config['LangVar']['PlaceTitle'], 'place', $Item['param']['place'], 'text');
		showsetting($Fn_Hd->Config['LangVar']['PeopleTitle'], 'people', $Item['param']['people'], 'text','','',$Fn_Hd->Config['LangVar']['PeopleTitlePrompt']);
		showsetting($Fn_Hd->Config['LangVar']['MalePeopleTitle'], 'male_people', $Item['param']['male_people'], 'text','','',$Fn_Hd->Config['LangVar']['ToPeopleTitlePrompt']);
		showsetting($Fn_Hd->Config['LangVar']['FemalePeopleTitle'], 'female_people', $Item['param']['female_people'], 'text','','',$Fn_Hd->Config['LangVar']['ToPeopleTitlePrompt']);
		showsetting($Fn_Hd->Config['LangVar']['LimitPeopleTitle'], 'limit_people', $Item['param']['limit_people'] ? $Item['param']['limit_people'] : 1, 'text','','',$Fn_Hd->Config['LangVar']['LimitPeoplePlaceholder']);
		
		showsetting($Fn_Hd->Config['LangVar']['InitiatorTitle'].$Fn_Hd->Config['LangVar']['Title'], 'initiator_title', $Item['param']['initiator_title'] ? $Item['param']['initiator_title'] : $Fn_Hd->Config['LangVar']['InitiatorTitle'], 'text');

		showsetting($Fn_Hd->Config['LangVar']['InitiatorTitle'], 'initiator', $Item['param']['initiator'] ? $Item['param']['initiator'] : $_G['username'], 'text');

		showsetting($Fn_Hd->Config['LangVar']['ConsultingPhoneTitle'], 'tel', $Item['param']['tel'], 'text');
		
		showsetting($Fn_Hd->Config['LangVar']['CustomExplain'], 'custom_explain', $Item['param']['custom_explain'], 'textarea','','',$Fn_Hd->Config['LangVar']['CustomExplainPrompt']);
		
		//��������
		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_Hd->Config['LangVar']['ContentTitle'].':</label><div class="col-sm-9"><textarea id="content" name="content" style="width:80%;height:450px;">'.stripslashes($Item['param']['content']).'</textarea></div></div>';

		showsetting($Fn_Hd->Config['LangVar']['ReviewMaxTitle'], 'review_title', $Item['param']['review_title'] ? $Item['param']['review_title'] : $Fn_Hd->Config['LangVar']['ReviewTitle'], 'text');

		//��ع�
		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_Hd->Config['LangVar']['ReviewTitle'].':</label><div class="col-sm-9"><textarea id="review" name="review" style="width:80%;height:450px;">'.stripslashes($Item['param']['review']).'</textarea></div></div>';
		
		echo <<<HTML
		</div>
		<!-- �������� end  -->
HTML;

		echo <<<HTML
		<!-- ��������  -->
		<div class="tab-pane" id="sign-up" role="tabpanel" aria-expanded="false">
HTML;
		
		//��������
		$SignUpAppDisplay = $Item['param']['sign_up_app'] ? true : false;
		showsetting($Fn_Hd->Config['LangVar']['SignUpApp'],array('sign_up_app', array(
			array('1',$Fn_Hd->Config['LangVar']['Yes'], array('sign_up_app_table' => '', 'sign_up_app_table_no' => 'none')),
			array('0',$Fn_Hd->Config['LangVar']['No'], array('sign_up_app_table'=> 'none', 'sign_up_app_table_no' => ''))
		), TRUE),$Item['param']['sign_up_app'], 'mradio');

		showtagheader('div', 'sign_up_app_table', $SignUpAppDisplay, 'sub');
			showsetting($Fn_Hd->Config['LangVar']['SignUpAppPrompt'], 'sign_up_app_Prompt', $Item['param']['sign_up_app_Prompt'] ? $Item['param']['sign_up_app_Prompt'] : $Fn_Hd->Config['LangVar']['SignUpAppPromptDefault'], 'text');
		showtagfooter('div');

		showsetting($Fn_Hd->Config['LangVar']['SignUpListSwitch'],array('sign_up_list_switch', array(
			array('1',$Fn_Hd->Config['LangVar']['Yes'], array('sign_up_list_switch_table' => 'none', 'sign_up_list_switch_table_no' => '')),
			array('0',$Fn_Hd->Config['LangVar']['No'], array('sign_up_list_switch_table'=> '', 'sign_up_list_switch_table_no' => 'none'))
		), TRUE),$Item ? $Item['param']['sign_up_list_switch'] : 1, 'mradio');
		$SignUpListSwitchDisplay = !$Item || $Item['param']['sign_up_list_switch'] ? false : true;
		showtagheader('div', 'sign_up_list_switch_table', $SignUpListSwitchDisplay, 'sub');
			showsetting($Fn_Hd->Config['LangVar']['ThoroughSignUpListSwitch'], 'thorough_sign_up_list_switch', $Item['param']['thorough_sign_up_list_switch'], 'radio','','',$Fn_Hd->Config['LangVar']['ThoroughSignUpListSwitchPrompt']);
		showtagfooter('div');

		showsetting($Fn_Hd->Config['LangVar']['SignUpSwitch'], 'sign_up_switch',$Item['param']['sign_up_switch'],'radio');

		showsetting($Fn_Hd->Config['LangVar']['SignUpStatementSwitch'],array('sign_up_statement_switch', array(
			array('1',$Fn_Hd->Config['LangVar']['Yes'], array('sign_up_statement_table' => '', 'sign_up_statement_table_no' => 'none')),
			array('0',$Fn_Hd->Config['LangVar']['No'], array('sign_up_statement_table'=> 'none', 'sign_up_statement_table_no' => ''))
		), TRUE),$Item['param']['sign_up_statement_switch'], 'mradio');
		$SignUpStatementSwitchDisplay = $Item['param']['sign_up_statement_switch'] ? true : false;
		
		showtagheader('div', 'sign_up_statement_table', $SignUpStatementSwitchDisplay);

		showsetting($Fn_Hd->Config['LangVar']['Statement'], 'statement', $Item['param']['statement'] ? stripslashes($Item['param']['statement']) : stripslashes($Fn_Hd->Config['PluginVar']['Statement']), 'textarea','','',$Fn_Hd->Config['LangVar']['VerificationUidPrompt']);

		showsetting($Fn_Hd->Config['LangVar']['SignUpStatementPopupSwitch'], 'statement_popup',$Item['param']['statement_popup'],'radio');
		
		showtagfooter('div');
		
		showsetting($Fn_Hd->Config['LangVar']['SignUpDataSwitch'], 'sign_up_data_switch',$Item['param']['sign_up_data_switch'],'radio','','',$Fn_Hd->Config['LangVar']['SignUpDataSwitchPrompt']);
		
		$Form = array();
		foreach($Fn_Hd->GetFieldList() as $Val) {
			$Form[] = array($Val['id'], $Val['title']);
		}
		
		showsetting($Fn_Hd->Config['LangVar']['SignUpForm'], array('sign_up_form[]',$Form),$Item['param']['sign_up_form'] ? $Item['param']['sign_up_form'] : $NewClass['param']['sign_up_form'],'mselect','','',$Fn_Hd->Config['LangVar']['SignUpFormPrompt']);
		
		showsetting($Fn_Hd->Config['LangVar']['VerificationUid'], 'v_uids', $Item['param']['v_uids'] ? $Item['param']['v_uids'] : $_G['uid'], 'text','','',$Fn_Hd->Config['LangVar']['VerificationUidPrompt']);
		echo <<<HTML
		</div>
		<!-- �������� end  -->
HTML;

		echo <<<HTML
		<!-- ֧������  -->
		<div class="tab-pane" id="pay" role="tabpanel" aria-expanded="false">
HTML;

		showsetting($Fn_Hd->Config['LangVar']['PaymentSetUp'],array('payment_type', array(
			array('1',$Fn_Hd->Config['LangVar']['CashPayment'], array('money_table' => '', 'extcredits_table' => 'none')),
			array('2',$Fn_Hd->Config['LangVar']['ExtcreditsPayment'], array('money_table'=> 'none', 'extcredits_table' => ''))
		), TRUE),!$Item ? 1 : $Item['param']['payment_type'], 'mradio');

		$MoneyDisplay = !$Item['param']['payment_type'] || $Item['param']['payment_type'] == 1 ? true : false;
		$ExtcreditsDisplay = $Item['param']['payment_type'] == 2 ? true : false;
		
		showtagheader('div', 'money_table', $MoneyDisplay);
			showsetting($Fn_Hd->Config['LangVar']['PaymentMoney'], 'money', $Item['param']['money'], 'text','','',$Fn_Hd->Config['LangVar']['PaymentMoneyPrompt']);
			showsetting($Fn_Hd->Config['LangVar']['VipPaymentMoney'], 'vip_money', $Item['param']['vip_money'], 'text');
		showtagfooter('div');

		showtagheader('div', 'extcredits_table', $ExtcreditsDisplay);
			$ExtcreditsArray = array();
			foreach($_G['setting']['extcredits'] as $Id => $Val) {
				$ExtcreditsArray[] = array($Id, $Val['title']);
			}
			showsetting($Fn_Hd->Config['LangVar']['ExtcreditsType'], array('extcredits_type',$ExtcreditsArray),$Item['param']['extcredits_type'],'select','','');
			showsetting($Fn_Hd->Config['LangVar']['Extcredits'], 'extcredits', $Item['param']['extcredits'], 'text','','',$Fn_Hd->Config['LangVar']['PaymentMoneyPrompt']);
			showsetting($Fn_Hd->Config['LangVar']['VipExtcredits'], 'vip_extcredits', $Item['param']['vip_extcredits'], 'text');
		showtagfooter('div');
		
		showsetting($Fn_Hd->Config['LangVar']['MoreCostTitle'], 'more_cost', $Item['param']['more_cost'], 'textarea','','',$Fn_Hd->Config['LangVar']['MoreCostPrompt']);

		showsetting($Fn_Hd->Config['LangVar']['XiangQinMoreCostTitle'], 'xiangqin_more_cost', $Item['param']['xiangqin_more_cost'], 'textarea','','',$Fn_Hd->Config['LangVar']['XiangQinMoreCostPrompt']);
		
		echo <<<HTML
		</div>
		<!-- ֧������ end  -->
HTML;

		echo <<<HTML
		<!-- ��������  -->
		<div class="tab-pane" id="comment" role="tabpanel" aria-expanded="false">
HTML;

		showsetting($Fn_Hd->Config['LangVar']['PostSwitch'],array('post_switch', array(
			array('1',$Fn_Hd->Config['LangVar']['Yes'], array('post_table' => '', 'post_table_no' => 'none')),
			array('0',$Fn_Hd->Config['LangVar']['No'], array('post_table'=> 'none', 'post_table_no' => ''))
		), TRUE),$Item['param']['post_switch'], 'mradio');
		
		$PostDisplay = $Item['param']['post_switch'] ? true : false;
		
		showtagheader('div', 'post_table', $PostDisplay);
			
			showsetting($Fn_Hd->Config['LangVar']['PostViolationWordSwitch'], 'post_violation_word_switch', $Item['param']['post_violation_word_switch'], 'radio');

			showsetting($Fn_Hd->Config['LangVar']['PostExamineSwitch'], 'post_examine_switch', $Item['param']['post_examine_switch'], 'radio');

			showsetting($Fn_Hd->Config['LangVar']['PostTime'], 'post_time', $Item['param']['post_time'], 'text','','',$Fn_Hd->Config['LangVar']['PostTimePrompt']);

			$Query = C::t('common_usergroup')->range_orderby_credit();
			$UserGroupList[0] = cplang('plugins_empty');
			foreach($Query as $Id => $UserGroup) {
				$UserGroupList[$UserGroup['groupid']] = $UserGroup['grouptitle'];
			}
			showsetting($Fn_Hd->Config['LangVar']['PostGroupId'], array('post_groupid[]',DyadicArray($UserGroupList)),$Item['param']['post_groupid'],'mselect','','',$Fn_Hd->Config['LangVar']['PostGroupIdPrompt']);

			showsetting($Fn_Hd->Config['LangVar']['PostMinLength'], 'post_min_lenth', $Item['param']['post_min_lenth'], 'text','','',$Fn_Hd->Config['LangVar']['PostMinLengthPrompt']);

			showsetting($Fn_Hd->Config['LangVar']['PostRemind'], 'post_remind', $Item['param']['post_remind'] ? $Item['param']['post_remind'] : $Fn_Hd->Config['LangVar']['PostRemindDefault'], 'text');

			showsetting($Fn_Hd->Config['LangVar']['PostInputPlaceholder'], 'post_input_placeholder', $Item['param']['post_input_placeholder'] ? $Item['param']['post_input_placeholder'] : $Fn_Hd->Config['LangVar']['PostInputPlaceholderDefault'], 'text');
			showsetting($Fn_Hd->Config['LangVar']['PostSubmit'], 'post_submit', $Item['param']['post_submit'] ? $Item['param']['post_submit'] : $Fn_Hd->Config['LangVar']['PostSubmitDefault'], 'text');

		showtagfooter('div');
		echo <<<HTML
		</div>
		<!-- �������� end  -->
HTML;

		echo <<<HTML
		<!-- ��������  -->
		<div class="tab-pane" id="other" role="tabpanel" aria-expanded="false">
HTML;

		showsetting($Fn_Hd->Config['LangVar']['BackSwitch'], 'back_switch', $Item['param']['back_switch'], 'radio','','',$Fn_Hd->Config['LangVar']['BackSwitchPrompt']);
		showsetting($Fn_Hd->Config['LangVar']['PosterNumSwitch'], 'poster_num_switch', $Item ? $Item['param']['poster_num_switch'] : 1, 'radio');
		showsetting($Fn_Hd->Config['LangVar']['WxShareSwitch'], 'wx_shares_switch', $Item['param']['wx_shares_switch'], 'radio');
		showsetting($Fn_Hd->Config['LangVar']['ShareTitle'], 'share_title', $Item['param']['share_title'], 'text');
		showsetting($Fn_Hd->Config['LangVar']['ShareDesc'], 'share_desc', $Item['param']['share_desc'], 'textarea');
		
		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_Hd->Config['LangVar']['ShareLogo'].'['.$Fn_Hd->Config['LangVar']['ShareLogoPrompt'].']</label><div class="col-sm-9"><div class="AdminSingleUpload"><div class="PhotoControl" id="ShareLogoPhotoControl"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';

		showsetting('Uid', 'uid',$Item['uid'] ? $Item['uid'] : $_G['uid'], 'text');
		showsetting($Fn_Hd->Config['LangVar']['Click'], 'click', $Item['click'], 'text');
		showsetting($Fn_Hd->Config['LangVar']['DisplayOrder'], 'displayorder', $Item['displayorder'], 'text');
		showsetting($Fn_Hd->Config['LangVar']['DisplayTitle'], 'display', !$Item ? 1 : $Item['display'], 'radio');
		if($Item['dateline']){
			showsetting($Fn_Hd->Config['LangVar']['TimeTitle'], 'dateline',date('Y-m-d H:i',$Item['dateline']), 'calendar','','','',1);
		}
		echo <<<HTML
		</div>
		<!-- �������� end  -->
HTML;

		showsubmit('DetailSubmit','&#20445;&#23384;&#37197;&#32622;');
		showtagfooter('div');
		showtagfooter('div');
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');

		$UpLoadHtml  = '';
		if($Item['param']['cover']){
			$CoverJsArray[] = '"'.$Item['param']['cover'].'"';;
			$UpLoadHtml .= '
			var InputArray = new Array('.implode(',',$CoverJsArray).');
			$("#CoverPhotoControl").AppUpload({InputName:"new_cover",Multiple:true,InputExist:true,InputArray:InputArray});';

		}else{
			$UpLoadHtml .= '$("#CoverPhotoControl").AppUpload({InputName:"new_cover",Multiple:true});';
		}

		if($Item['param']['share_logo']){
			$ShareLogoJsArray[] = '"'.$Item['param']['share_logo'].'"';;
			$UpLoadHtml .= '
			var InputArray = new Array('.implode(',',$ShareLogoJsArray).');
			$("#ShareLogoPhotoControl").AppUpload({InputName:"new_share_logo",Multiple:true,InputExist:true,InputArray:InputArray});';

		}else{
			$UpLoadHtml .= '$("#ShareLogoPhotoControl").AppUpload({InputName:"new_share_logo",Multiple:true});';
		}

		echo $UploadConfig['CssJsHtml'];
		echo '
			<script type="text/javascript">
			'.$UpLoadHtml.'
			var ue = UE.getEditor("content",{autoHeightEnabled: false,autoFloatEnabled:false,enableAutoSave: false}); 
			var uee = UE.getEditor("review",{autoHeightEnabled: false,autoFloatEnabled:false,enableAutoSave: false}); 
			</script> 	
		';

	}else{
		$Data['title'] = addslashes(strip_tags($_GET['title']));
		$Data['start_time'] = $_GET['start_time'] ? strtotime($_GET['start_time']) : '';
		$Data['end_time'] = $_GET['end_time'] ? strtotime($_GET['end_time']) : '';
		$Data['sign_up_start_time'] = $_GET['sign_up_start_time'] ? strtotime($_GET['sign_up_start_time']) : '';
		$Data['sign_up_end_time'] = $_GET['sign_up_end_time'] ? strtotime($_GET['sign_up_end_time']) : '';
		$Data['display'] = intval($_GET['display']);
		$Data['click'] = intval($_GET['click']);
		$Data['displayorder'] = intval($_GET['displayorder']);
		$Data['uid'] = intval($_GET['uid']);

		//����
		$Data['type'] = intval($_GET['type']);
		$Data['classid'] = intval($_GET['classid']);
		//���� End

		$Param['place'] = addslashes(strip_tags($_GET['place']));
		$Param['people'] = $ClassList[$Data['classid']]['xiangqin'] && $_GET['male_people'] ? intval($_GET['male_people']) + intval($_GET['female_people']) : intval($_GET['people']);
		$Param['male_people'] = intval($_GET['male_people']);
		$Param['female_people'] = intval($_GET['female_people']);
		$Param['limit_people'] = intval($_GET['limit_people']);
		$Param['initiator_title'] = addslashes(strip_tags($_GET['initiator_title']));
		$Param['initiator'] = addslashes(strip_tags($_GET['initiator']));
		$Param['tel'] = addslashes(strip_tags($_GET['tel']));
		$Param['custom_explain'] = addslashes(strip_tags($_GET['custom_explain']));
		$Param['content'] = addslashes($_GET['content']);//�豣��Html
		$Param['review_title'] = addslashes(strip_tags($_GET['review_title']));
		$Param['review'] = addslashes($_GET['review']);//�豣��Html
		$Param['sign_up_app'] = intval($_GET['sign_up_app']);
		$Param['sign_up_app_Prompt'] = addslashes(strip_tags($_GET['sign_up_app_Prompt']));
		$Param['sign_up_list_switch'] = intval($_GET['sign_up_list_switch']);
		$Param['thorough_sign_up_list_switch'] = intval($_GET['thorough_sign_up_list_switch']);

		$Param['sign_up_switch'] = intval($_GET['sign_up_switch']);
		$Param['sign_up_statement_switch'] = intval($_GET['sign_up_statement_switch']);
		$Param['sign_up_data_switch'] = intval($_GET['sign_up_data_switch']);
		$Param['sign_up_form'] =  is_array($_GET['sign_up_form']) && isset($_GET['sign_up_form'])  ? $_GET['sign_up_form'] : '';
		$Param['v_uids'] = addslashes(strip_tags($_GET['v_uids']));
		$Param['statement'] = addslashes($_GET['statement']);//�豣��Html
		$Param['statement_popup'] = intval($_GET['statement_popup']);
		
		$Param['payment_type'] = intval($_GET['payment_type']);
		$Param['money'] = addslashes(strip_tags($_GET['money']));
		$Param['vip_money'] = addslashes(strip_tags($_GET['vip_money']));
		$Param['extcredits_type'] = intval($_GET['extcredits_type']);
		$Param['extcredits_title'] = addslashes(strip_tags($_G['setting']['extcredits'][$_GET['extcredits_type']]['title']));
		$Param['extcredits'] = intval($_GET['extcredits']);
		$Param['vip_extcredits'] = intval($_GET['vip_extcredits']);

		
		$MoreCostArray = array();
		foreach (array_filter(explode("\r\n",$_GET['more_cost'])) as $Key => $Val) {
			$Array = array_filter(explode("|",$Val));
			$MoreCostArray[$Key+1]['title'] = $Array[0];
			$MoreCostArray[$Key+1]['value'] = $Array[1];
		}
		$Param['more_cost'] = $_GET['more_cost'];
		$Param['more_cost_list'] = array_filter($MoreCostArray);
		
		
		foreach (explode("\r\n",$_GET['xiangqin_more_cost']) as $Key => $Val) {
			$XiangQinMoreCostArray[$Key+1] = $Val;
		}
		$Param['xiangqin_more_cost'] = $_GET['xiangqin_more_cost'];
		$Param['xiangqin_more_cost_list'] = $_GET['xiangqin_more_cost'] ? $XiangQinMoreCostArray : '';
		
		//����
		$Param['post_switch'] = intval($_GET['post_switch']);
		$Param['post_time'] = intval($_GET['post_time']);
		$Param['post_violation_word_switch'] = intval($_GET['post_violation_word_switch']);
		$Param['post_examine_switch'] = intval($_GET['post_examine_switch']);
		$Param['post_groupid'] = is_array($_GET['post_groupid']) && isset($_GET['post_groupid']) ? $_GET['post_groupid'] : '';
		$Param['post_min_lenth'] = intval($_GET['post_min_lenth']);
		$Param['post_remind'] = addslashes(strip_tags($_GET['post_remind']));
		$Param['post_input_placeholder'] = addslashes(strip_tags($_GET['post_input_placeholder']));
		$Param['post_submit'] = addslashes(strip_tags($_GET['post_submit']));
		
		$Param['back_switch'] = intval($_GET['back_switch']);
		$Param['poster_num_switch'] = intval($_GET['poster_num_switch']);
		$Param['wx_shares_switch'] = intval($_GET['wx_shares_switch']);
		$Param['share_title'] = addslashes(strip_tags($_GET['share_title']));
		$Param['share_desc'] = addslashes(strip_tags($_GET['share_desc']));
		
		/* ��ϵ��ʽ�ж� */
		/*$IsMob = "/^1[3-9]{1}[0-9]{9}$/";
		$IsTel = "/^([0-9]{3,4}-)?[0-9]{7,8}$/";
		if($Param['tel']){
			if(!preg_match($IsMob,$Param['tel']) && !preg_match($IsTel,$Param['tel'])){
				fn_cpmsg($Fn_Hd->Config['LangVar']['TelErr'],'','error');
			}
		}*/
		/* ��ϵ��ʽ�ж� End */
		foreach($_GET['new_cover'] as $Key => $Val) {
			$_GET['new_cover'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}

		foreach($_GET['new_share_logo'] as $Key => $Val) {
			$_GET['new_share_logo'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}
		$Param['cover'] = addslashes(strip_tags($_GET['new_cover'][0]));
		$Param['share_logo'] = addslashes(strip_tags($_GET['new_share_logo'][0]));

		$Data['param'] = serialize($Param);
		$Member = DB::fetch_first('SELECT username FROM '.DB::table('common_member').' where uid = '.$Data['uid']);
		if($Member){
			$Data['username'] = addslashes(strip_tags($Member['username']));
			if($Item){
				$Data['dateline'] = strtotime($_GET['dateline']);
				$Data['updateline'] = time();
				DB::update($Fn_Hd->TableHd,$Data,'id = '.$AId);
				GetInsertDoLog('edit_hd','fn_'.$_GET['mod'],array('id'=>$AId));//������¼
			}else{
				$Data['dateline'] = $Data['updateline'] = time();
				$AId = DB::insert($Fn_Hd->TableHd,$Data,true);
				GetInsertDoLog('add_hd','fn_'.$_GET['mod'],array('id'=>$AId));//������¼
			}
			fn_cpmsg($Fn_Hd->Config['LangVar']['UpdateOk'],$Fn_Admin->Config['IframeItemUrl'].'&submodel=list','succeed');
		}else{
			fn_cpmsg($Fn_Hd->Config['LangVar']['NoUserErr'],'','error');
		}
		exit();
	}
}

/* �б� */
function GetModulesList($Page,$Limit,$Where=null,$Order){
	global $Fn_Hd;
	$FetchSql = 'SELECT H.* FROM '.DB::table($Fn_Hd->TableHd).' H '.$Where.' order by '.$Order.' asc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}

/* ���� */
function GetModulesCount($Where=null){
	global $Fn_Hd;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_Hd->TableHd).' H '.$Where;
	return DB::result_first($FetchSql);//��������
}
//From: Dism_taobao_com
?>