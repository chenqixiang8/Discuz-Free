<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('hd_all') && !$Fn_Admin->CheckUserGroup('hd_vip_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$SubModel = in_array($_GET['submodel'], array('list','add')) ? $_GET['submodel'] : 'list';
$Fn_Admin->Config['IframeSubModelUrl'] = $Fn_Admin->Config['IframeItemUrl'].'&submodel='.$SubModel;
$NavClass = array($SubModel=>'btn-info Hover');

//����
echo <<<Nav
<div class="SubModelNav">
  <ul>
	<li class="{$NavClass['list']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=list" target="_self">{$Fn_Admin->Config['LangVar']['HdLeftNavArray']['vip_list']}</a></li>
    <li class="{$NavClass['add']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=add" target="_self">{$Fn_Admin->Config['LangVar']['AddEditTitle']}</a></li>
  </ul>
  <div class="both"></div>
</div>
Nav;


if($SubModel == 'list'){//�б�
	$Do = in_array($_GET['do'], array('Del','UserList','UserEdit','UserAdd','UserDel')) ? $_GET['do'] : 'List';

	$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeItemUrl'];
	if($Do == 'List'){
		if(!submitcheck('Submit')) {
			/* ��ѯ���� */
			$Where = '';
			$Order = 'V.id';
			
			$Where = preg_replace('/and/','where',$Where,1);
			$Limit = 50;
			$Page = $_GET['page']?intval($_GET['page']):1;
			/* ��ѯ���� End */
			
			/* ģ����� */		
			showtagheader('div', 'row', true,'row');
			showtagheader('div', 'col-12', true,'col-12');
			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-body', true,'box-body');
			showtagheader('div', 'table-responsive', true,'table-responsive');
			showformheader($FormUrl,'enctype="multipart/form-data"');
			showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
			showsubtitle(array(
				'ID',
				$Fn_Hd->Config['LangVar']['Title'],
				$Fn_Hd->Config['LangVar']['MoneyTitle'],
				$Fn_Hd->Config['LangVar']['VipNumberCount'],
				$Fn_Hd->Config['LangVar']['DisplayTitle'],
				$Fn_Hd->Config['LangVar']['TimeTitle'],
				$Fn_Hd->Config['LangVar']['OperationTitle']
			), 'header tbm tc');
			
			$ModulesList = GetModulesList($Page,$Limit,$Where,$Order);
			
			foreach ($ModulesList as $Module) {
				$VipMemberCount = DB::result_first('SELECT COUNT(*) FROM '.DB::table($Fn_Hd->TableVipMember).' where vip_id = '.intval($Module['id']).' and expire_dateline >= '.time());

				showtablerow('', array('class="tc w80"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
					$Module['id'],
					$Module['title'],
					$Module['money'],
					$VipMemberCount,
					!$Module['display'] ? '<span class="label bg-secondary">'.$Fn_Hd->Config['LangVar']['No'].'</span>' : '<span class="label bg-blue">'.$Fn_Hd->Config['LangVar']['Yes'].'</span>',
					date('Y-m-d',$Module['dateline']),
					'<a href="'.$Fn_Hd->Config['VipUrl'].$Module['id'].'" target="_blank" class="btn btn-sm btn-dark-outline">'.cplang('view').'</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&vid='.$Module['id'].'" class="btn btn-sm btn-info-outline">'.$Fn_Hd->Config['LangVar']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=UserList&vid='.$Module['id'].'" class="btn btn-sm btn-purple-outline">'.$Fn_Hd->Config['LangVar']['VipUserListOp'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Del&vid='.$Module['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$Fn_Hd->Config['LangVar']['DelTitle'].'</a>'
				));
			}
			//showsubmit('','','&nbsp;&nbsp;','','',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));
			showtablefooter(); /*dism��taobao��com*/
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			/* ģ����� End */
		}
	}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['vid']){//ɾ��
		if(!$Fn_Admin->CheckUserGroup('hd_all') && !$Fn_Admin->CheckUserGroup('hd_vip_del')){//Ȩ���ж�
			fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
			exit();
		}
		$VId = intval($_GET['vid']);
		DB::delete($Fn_Hd->TableVip,'id ='.$VId);
		DB::delete($Fn_Hd->TableVipMember,'vip_id ='.$VId);

		GetInsertDoLog('del_vip','fn_'.$_GET['mod'],array('id'=>$_GET['vid']));//������¼

		fn_cpmsg($Fn_Hd->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');

	}else if($Do == 'UserList'){//��Ա����
		if(!$Fn_Admin->CheckUserGroup('hd_all') && !$Fn_Admin->CheckUserGroup('hd_vip_user_list')){//Ȩ���ж�
			fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
			exit();
		}
		$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeSubModelUrl'];
		if(!submitcheck('Submit')) {
			$SearUrl = $Fn_Admin->Config['IframeSubModelUrl'].'&do='.$Do;
			/* ��ѯ���� */
			$VipItem = DB::fetch_first('SELECT * FROM '.DB::table($Fn_Hd->TableVip).' where id = '.intval($_GET['vid']));
			$Where = '';
			$Order = in_array($_GET['order'], array('id','statedateline')) ? 'M.'.addslashes(dhtmlspecialchars($_GET['order'])) : 'M.id';
			if($_GET['vid']){
				$Where .= ' and M.vip_id = '.intval($_GET['vid']);
			}

			if($_GET['keyword']){
				$_GET['keyword'] = str_replace(array('%','_'),array('',''),$_GET['keyword']);
				$Where .= ' and (M.username like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or M.uid = '.intval($_GET['keyword']).')';
			}

			if($_GET['expire']){
				$Where .= ' and M.expire_dateline < '.time();
			}
		
			$Where = preg_replace('/and/','where',$Where,1);
			$Limit = 30;
			$Page = $_GET['page']?intval($_GET['page']):1;
			/* ��ѯ���� End */
			

			/* ģ����� */		
			showtagheader('div', 'row', true,'row');
			showtagheader('div', 'col-12', true,'col-12');
			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-body', true,'box-body');
			/* ���� */
			$ExpireSelected = array($_GET['expire']=>' selected');
			$OrderSelected = array($_GET['order']=>' selected');
			echo <<<SEARCH
			<form method="post" autocomplete="off" action="$SearUrl" id="tb_search">
				<div class="FormSearchTo" style="margin-bottom:0;">
					<table cellspacing="4" cellpadding="4">
						<tr>
							<th>{$Fn_Hd->Config['LangVar']['KeywordTitle']}</th><td><input type="text" class="input form-control w150" name="keyword" value="{$_GET['keyword']}"></td>
							<th>{$Fn_Hd->Config['LangVar']['Yes']}{$Fn_Hd->Config['LangVar']['No']}{$Fn_Hd->Config['LangVar']['ExpireDatelineErr']}</th><td>
							<select name="expire" class="form-control w120">
								<option value="">{$Fn_Hd->Config['LangVar']['SelectNull']}</option>
								<option value="1"{$ExpireSelected['1']}>{$Fn_Hd->Config['LangVar']['Yes']}</option>
							</select>
							</td>
							<th>{$Fn_Hd->Config['LangVar']['SortTitle']}</th><td colspan="3">
							<select name="order"  class="form-control w120">
							<option value="id"{$OrderSelected['id']}>id</option>
							<option value="updateline"{$OrderSelected['updateline']}>{$Fn_Hd->Config['LangVar']['UpdateTime']}</option>
							</select>&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Admin->Config['LangVar']['SearchSubmit']}" class="btn btn-info" type="submit"></td>
						</tr>
					</table>
				</div>
			</form>
SEARCH;
			/* ���� End */
			showtagheader('div', 'table-responsive', true,'table-responsive');
			showformheader($FormUrl,'enctype="multipart/form-data"');
			showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
			showsubtitle(array(
				'ID',
				'UID',
				$Fn_Hd->Config['LangVar']['UserNameTitle'],
				$Fn_Hd->Config['LangVar']['ExpireDateline'],
				$Fn_Hd->Config['LangVar']['TimeTitle'],
				$Fn_Hd->Config['LangVar']['UpdateTime'],
				$Fn_Hd->Config['LangVar']['OperationTitle']
			), 'header tbm tc');
			
			$ModulesList = GetModulesMemBerList($Page,$Limit,$Where,$Order);
			
			foreach ($ModulesList as $Module) {
				showtablerow('', array('class="tc w50"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
					$Module['id'],
					$Module['uid'],
					$Module['username'],
					$Module['expire_dateline'] >= time() ? date('Y-m-d',$Module['expire_dateline']) : '<span style="color:red">'.$Fn_Hd->Config['LangVar']['ExpireDatelineErr'].'</span>',
					date('Y-m-d',$Module['dateline']),
					$Module['updateline'] ? date('Y-m-d',$Module['updateline']) : '',
					'<a href="'.$Fn_Admin->Config['IframeSubModelUrl'].'&do=UserEdit&mid='.$Module['id'].'" class="btn btn-sm btn-info-outline">'.$Fn_Hd->Config['LangVar']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeSubModelUrl'].'&do=UserDel&vid='.$Module['vip_id'].'&mid='.$Module['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$Fn_Hd->Config['LangVar']['DelTitle'].'</a>'
				));
			}
			showsubmit('','','','<a href="'.$Fn_Admin->Config['IframeSubModelUrl'].'&do=UserAdd&vid='.$_GET['vid'].'" class="btn btn-sm btn-info-outline">'.$Fn_Hd->Config['LangVar']['AddVipUserTitle'].'</a>','',multi(GetModulesMemBerCount($Where),$Limit,$Page,$MpUrl));
			showtablefooter(); /*dism��taobao��com*/
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			/* ģ����� End */
		}
	}else if($Do == 'UserDel' && $_GET['formhash'] == formhash() && $_GET['mid']){//ɾ��
		if(!$Fn_Admin->CheckUserGroup('hd_all') && !$Fn_Admin->CheckUserGroup('hd_vip_user_del')){//Ȩ���ж�
			fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
			exit();
		}
		$MId = intval($_GET['mid']);
		DB::delete($Fn_Hd->TableVipMember,'id ='.$MId);
		GetInsertDoLog('del_user_vip','fn_'.$_GET['mod'],array('id'=>$_GET['mid']));//������¼
		fn_cpmsg($Fn_Hd->Config['LangVar']['DelOk'],$Fn_Admin->Config['IframeSubModelUrl'].'&do=UserList&vid='.$_GET['vid'],'succeed');

	}else if(in_array($Do,array('UserAdd','UserEdit'))){//���ӻ�༭
		if(!$Fn_Admin->CheckUserGroup('hd_all') && !$Fn_Admin->CheckUserGroup('hd_vip_user_add')){//Ȩ���ж�
			fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
			exit();
		}
		$MId = intval($_GET['mid']);
		$Item = $MId ? $Fn_Hd->QueryOne($Fn_Hd->TableVipMember,$MId) : array();
		if(!submitcheck('DetailSubmit')) {
			$OpTitle = $Fn_Hd->Config['LangVar']['AddVipUserTitle'];
			if($Item)$OpTitle = $Fn_Hd->Config['LangVar']['EditTitle'];
			
			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-header', true,'with-border box-header');
			showtitle($OpTitle,'class="box-title"');
			showtagfooter('div');
			showformheader($Fn_Admin->Config['IframeSubModelUrl'].'&do='.$Do.'&mid='.$MId.'&vid='.$_GET['vid'],'enctype');
			showtagheader('div', 'box-body', true,'box-body');

			if(!$Item){
				showsetting('UID','uid', $Item['uid'], 'text');
			}
			showsetting($Fn_Hd->Config['LangVar']['ExpireDateline'], 'expire_dateline',$Item['expire_dateline'] ? date('Y-m-d',$Item['expire_dateline']) : '', 'calendar');

			showsubmit('DetailSubmit','&#20445;&#23384;&#37197;&#32622;');
			showtagfooter('div');
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');

		}else{
			if(!$Item){
				$Data['uid'] = intval($_GET['uid']);
				$Data['vip_id'] = intval($_GET['vid']);
			}else{
				$Data['vip_id'] = intval($Item['vip_id']);
			}
			
			$Data['expire_dateline'] = $_GET['expire_dateline'] ? strtotime($_GET['expire_dateline']) : '';

			if($Item){
				$Data['updateline'] = time();
				DB::update($Fn_Hd->TableVipMember,$Data,'id = '.$MId);
				GetInsertDoLog('edit_user_vip','fn_'.$_GET['mod'],array('id'=>$MId,'vip_id'=>$Data['vip_id']));//������¼
			}else{
				$CheCkVipMember = $Fn_Hd->GetVipMember($Data['vip_id'],$Data['uid']);
				if($CheCkVipMember){
					fn_cpmsg($Fn_Hd->Config['LangVar']['CheCkVipMemberErr'],'','error');
					exit();
				}

				$Member = DB::fetch_first('SELECT username FROM '.DB::table('common_member').' where uid = '.$Data['uid']);
				$Data['username'] = addslashes(strip_tags($Member['username']));
				$Data['dateline'] =  time();
				$MId = DB::insert($Fn_Hd->TableVipMember,$Data,true);
				GetInsertDoLog('add_user_vip','fn_'.$_GET['mod'],array('id'=>$MId,'vip_id'=>$Data['vip_id']));//������¼
			}
			fn_cpmsg($Fn_Hd->Config['LangVar']['UpdateOk'],$Fn_Admin->Config['IframeSubModelUrl'].'&do=UserList&vid='.$Data['vip_id'],'succeed');
		}

	}
}else if($SubModel == 'add'){//���ӻ�༭
	if(!$Fn_Admin->CheckUserGroup('hd_all') && !$Fn_Admin->CheckUserGroup('hd_vip_add')){//Ȩ���ж�
		fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
		exit();
	}
	$VId = intval($_GET['vid']);
	$Item = $VId ? $Fn_Hd->QueryOne($Fn_Hd->TableVip,$VId) : array();
	if($Item['param']){$Item['param'] = unserialize($Item['param']);}

	if(!submitcheck('DetailSubmit')) {
		$OpTitle = $Fn_Hd->Config['LangVar']['AddTitle'];
		if($Item)$OpTitle = $Fn_Hd->Config['LangVar']['EditTitle'];
		
		//ͼƬ�ϴ�
		if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_assembly/class/class_upload.php')){
			@require_once libfile('class/upload','plugin/fn_assembly');
			$UploadConfig = fn_upload::Config();
		}
		

		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-header', true,'with-border box-header');
		showtitle($OpTitle,'class="box-title"');
		showtagfooter('div');
		showformheader($Fn_Admin->Config['IframeSubModelUrl'].'&vid='.$VId,'enctype');
		showtagheader('div', 'box-body', true,'box-body');

		showsetting($Fn_Hd->Config['LangVar']['Title'], 'title', $Item['title'], 'text');
		showsetting($Fn_Hd->Config['LangVar']['MoneyTitle'], 'money', $Item['money'], 'text','','',$Fn_Hd->Config['LangVar']['VipMoneyTips']);
		
		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_Hd->Config['LangVar']['CoverTitle'].' '.$Fn_Hd->Config['LangVar']['VipCoverTips'].'</label><div class="col-sm-9"><div class="AdminSingleUpload"><div class="PhotoControl" id="CoverPhotoControl"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';

		showsetting($Fn_Hd->Config['LangVar']['VipCoverRightBottom'], 'cover_right_text_bottom', $Item['param']['cover_right_text_bottom'], 'text');
		showsetting($Fn_Hd->Config['LangVar']['BankVipCount'], 'bank_vip_count', $Item['param']['bank_vip_count'] ? $Item['param']['bank_vip_count'] : $Fn_Hd->Config['LangVar']['BankVipCountDefault'], 'text','','',$Fn_Hd->Config['LangVar']['BankVipCountTips']);
		showsetting($Fn_Hd->Config['LangVar']['BankVipCountFictitious'], 'bank_vip_count_fictitious', $Item['param']['bank_vip_count_fictitious'], 'text');
		showsetting($Fn_Hd->Config['LangVar']['NoVipInfo'], 'no_vip_info', $Item['param']['no_vip_info'] ? $Item['param']['no_vip_info'] : $Fn_Hd->Config['LangVar']['NoVipInfoDefault'], 'text','','',$Fn_Hd->Config['LangVar']['NoVipInfoTpis']);

		showsetting($Fn_Hd->Config['LangVar']['IsVipInfo'], 'is_vip_info', $Item['param']['is_vip_info'] ? $Item['param']['is_vip_info'] : $Fn_Hd->Config['LangVar']['IsVipInfoDefault'], 'text','','',$Fn_Hd->Config['LangVar']['IsVipInfoTpis']);
		
		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_Hd->Config['LangVar']['EquityImg'].':</label><div class="col-sm-9"><div class="AdminSingleUpload"><div class="PhotoControl" id="EquityImgPhotoControl"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';
	

		showsetting($Fn_Hd->Config['LangVar']['ThemeColor'], 'theme_color', $Item['param']['theme_color'] ? $Item['param']['theme_color'] : $Fn_Hd->Config['PluginVar']['Color'], 'color');
		showsetting($Fn_Hd->Config['LangVar']['DisplayTitle'], 'display', !$Item ? 1 : $Item['display'], 'radio');
	
		if($Item['dateline']){
			showsetting($Fn_Hd->Config['LangVar']['TimeTitle'], 'dateline',date('Y-m-d H:i',$Item['dateline']), 'calendar','','','',1);
		}
		
		showsubmit('DetailSubmit','&#20445;&#23384;&#37197;&#32622;');
		showtagfooter('div');
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');

		$UpLoadHtml  = '';
		if($Item['param']['cover']){
			$CoverJsArray[] = '"'.$Item['param']['cover'].'"';;
			$UpLoadHtml .= '
			var InputArray = new Array('.implode(',',$CoverJsArray).');
			jQuery("#CoverPhotoControl").AppUpload({InputName:"new_cover",Multiple:true,InputExist:true,InputArray:InputArray});';

		}else{
			$UpLoadHtml .= 'jQuery("#CoverPhotoControl").AppUpload({InputName:"new_cover",Multiple:true});';
		}

		if($Item['param']['equity_img']){
			$EquityImgJsArray[] = '"'.$Item['param']['equity_img'].'"';;
			$UpLoadHtml .= '
			var InputArray = new Array('.implode(',',$EquityImgJsArray).');
			jQuery("#EquityImgPhotoControl").AppUpload({InputName:"new_equity_img",Multiple:true,InputExist:true,InputArray:InputArray});';

		}else{
			$UpLoadHtml .= 'jQuery("#EquityImgPhotoControl").AppUpload({InputName:"new_equity_img",Multiple:true});';
		}

		echo '<script type="text/javascript" src="static/js/calendar.js"></script><script type="text/javascript" src="'.$Fn_Admin->Config['StaticPath'].'/js/jquery.js"></script><script type="text/javascript" src="'.$Fn_Admin->Config['StaticPath'].'/js/common.js"></script>'.$UploadConfig['CssJsHtml'];
		echo '
			<style>.PublishFormImages .PhotoControl{width:80px;line-height:80px;height:80px;font-size:28px;margin-right:10px;}.PublishFormImages .PhotoControl .Close{width:20px;height:20px;}.TreeList{position: absolute;left:0;top:0;z-index:1;}.Tmp{opacity:0;}.Tagging span{font-size:18px;}.Tagging{cursor: pointer;}</style>
			<script type="text/javascript">
			jQuery.noConflict();
			'.$UpLoadHtml.'
			</script> 	
		';

	}else{
		$Data['title'] = addslashes(strip_tags($_GET['title']));
		$Data['money'] = addslashes(strip_tags($_GET['money']));
		$Data['display'] = intval($_GET['display']);
		
		$Param['cover_right_text_bottom'] = addslashes(strip_tags($_GET['cover_right_text_bottom']));
		$Param['bank_vip_count'] = addslashes(strip_tags($_GET['bank_vip_count']));
		$Param['bank_vip_count_fictitious'] = intval($_GET['bank_vip_count_fictitious']);
		$Param['no_vip_info'] = addslashes(strip_tags($_GET['no_vip_info']));
		$Param['is_vip_info'] = addslashes(strip_tags($_GET['is_vip_info']));
		$Param['theme_color'] = addslashes(strip_tags($_GET['theme_color']));
		
		foreach($_GET['new_cover'] as $Key => $Val) {
			$_GET['new_cover'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}

		foreach($_GET['new_equity_img'] as $Key => $Val) {
			$_GET['new_equity_img'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}

		$Param['cover'] = addslashes(strip_tags($_GET['new_cover'][0]));
		$Param['equity_img'] = addslashes(strip_tags($_GET['new_equity_img'][0]));

		$Data['param'] = serialize($Param);

		if($Item){
			DB::update($Fn_Hd->TableVip,$Data,'id = '.$VId);
			GetInsertDoLog('add_vip','fn_'.$_GET['mod'],array('id'=>$VId));//������¼
		}else{
			$Data['dateline'] =  time();
			$VId = DB::insert($Fn_Hd->TableVip,$Data,true);
			GetInsertDoLog('edit_vip','fn_'.$_GET['mod'],array('id'=>$VId));//������¼

		}
		fn_cpmsg($Fn_Hd->Config['LangVar']['UpdateOk'],$Fn_Admin->Config['IframeItemUrl'],'succeed');
	}
}

/* �б� */
function GetModulesList($Page,$Limit,$Where=null,$Order){
	global $Fn_Hd;
	$FetchSql = 'SELECT V.* FROM '.DB::table($Fn_Hd->TableVip).' V '.$Where.' order by '.$Order.' asc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}
/* ���� */
function GetModulesCount($Where=null){
	global $Fn_Hd;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_Hd->TableVip).' V '.$Where;
	return DB::result_first($FetchSql);//��������
}

/* �б� */
function GetModulesMemBerList($Page,$Limit,$Where=null,$Order){
	global $Fn_Hd;
	$FetchSql = 'SELECT M.* FROM '.DB::table($Fn_Hd->TableVipMember).' M '.$Where.' order by '.$Order.' asc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}
/* ���� */
function GetModulesMemBerCount($Where=null){
	global $Fn_Hd;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_Hd->TableVipMember).' M '.$Where;
	return DB::result_first($FetchSql);//��������
}
//From: Dism_taobao_com
?>