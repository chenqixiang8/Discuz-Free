<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('hd_all') && !$Fn_Admin->CheckUserGroup('hd_sign_up_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$Do = in_array($_GET['do'], array('Del','State','Display','Examine')) ? $_GET['do'] : 'List';

//�����ֶ�
$SearField =array('page','keyword','examine','aid','state','order');
foreach($SearField as $Val) {
	$SearArray[$Val] = $_GET[$Val] || in_array($_GET[$Val],array('0')) ? $_GET[$Val] : '';
}
//�����ֶ� End

$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeItemUrl'].'&'.http_build_query($SearArray);

if($Do == 'List'){

	if(!submitcheck('Submit')) {
		$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
		/* ��ѯ���� */
		$Where = '';
		$Order = in_array($_GET['order'], array('id','statedateline')) ? 'S.'.addslashes(dhtmlspecialchars($_GET['order'])) : 'S.id';
		

		if($_GET['aid']){
			$Where .= ' and S.aid = '.intval($_GET['aid']);
		}
		if($_GET['keyword']){
			$_GET['keyword'] = str_replace(array('%','_'),array('',''),$_GET['keyword']);
			$Where .= ' and (S.username like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or S.code like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or S.param like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or S.uid = '.intval($_GET['keyword']).' )';
		}
		if(in_array($_GET['examine'],array('0','1','2'))){
			$Where .= ' and S.examine = '.intval($_GET['examine']);
		}
		if(in_array($_GET['state'],array('0','1'))){
			$Where .= ' and S.state = '.intval($_GET['state']);
		}

		$Where = preg_replace('/and/','where',$Where,1);
		$Limit = 30;
		$Page = $_GET['page']?intval($_GET['page']):1;
		/* ��ѯ���� End */

		/* ģ����� */		
		showtagheader('div', 'row', true,'row');
		showtagheader('div', 'col-12', true,'col-12');
		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-body', true,'box-body');
		
				/* ���� */
		$ExamineSelected = array($_GET['examine']=>' selected');
		$StateSelected = array($_GET['state']=>' selected');
		$OrderSelected = array($_GET['order']=>' selected');
		echo <<<SEARCH
		<form method="post" autocomplete="off" action="$SearUrl" id="tb_search">
			<div class="FormSearchTo">
				<table cellspacing="4" cellpadding="4">
					<tr>
						<th>{$Fn_Hd->Config['LangVar']['KeywordTitle']}</th><td><input type="text" class="input form-control w150" name="keyword" value="{$_GET['keyword']}"></td>
						<th>{$Fn_Hd->Config['LangVar']['ActivityTitle']}ID</th><td><input type="text" class="input form-control w100" name="aid" value="{$_GET['aid']}"></td>
						<th>{$Fn_Hd->Config['LangVar']['ExamineState']}</th><td>
						
						<select name="examine" class="form-control w120">
							<option value="">{$Fn_Hd->Config['LangVar']['SelectNull']}</option>
							<option value="0"{$ExamineSelected['0']}>{$Fn_Hd->Config['LangVar']['ExamineArray'][0]}</option>
							<option value="1"{$ExamineSelected['1']}>{$Fn_Hd->Config['LangVar']['ExamineArray'][1]}</option>
						</select>
						</td>
						<th>{$Fn_Hd->Config['LangVar']['VerificationState']}</th><td>
						
						<select name="state" class="form-control w120">
							<option value="">{$Fn_Hd->Config['LangVar']['SelectNull']}</option>
							<option value="1"{$StateSelected['1']}>{$Fn_Hd->Config['LangVar']['VerificationStateArray'][1]}</option>
							<option value="0"{$StateSelected['0']}>{$Fn_Hd->Config['LangVar']['VerificationStateArray'][0]}</option>
						</select>
						</td>
						<th>{$Fn_Hd->Config['LangVar']['SortTitle']}</th><td colspan="3">
							<select name="order" class="form-control w120">
							<option value="id"{$OrderSelected['id']}>id</option>
							<option value="statedateline"{$OrderSelected['statedateline']}>{$Fn_Hd->Config['LangVar']['UseTime']}</option>
							</select>
						&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Admin->Config['LangVar']['SearchSubmit']}" class="btn btn-info" type="submit"></td>
					</tr>
				</table>
			</div>
		</form>
SEARCH;
		/* ���� End */

		showtagheader('div', 'table-responsive', true,'table-responsive');
		showformheader($FormUrl,'enctype="multipart/form-data"');
		showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');

		showsubtitle(array(
			'ID',
			$Fn_Hd->Config['LangVar']['ActivityTitle'],
			'Uid/'.$Fn_Hd->Config['LangVar']['UserNameTitle'],
			$Fn_Hd->Config['LangVar']['EnrolmentCount'],
			$Fn_Hd->Config['LangVar']['RegistrationInformation'],
			$Fn_Hd->Config['LangVar']['VoucherCode'],
			$Fn_Hd->Config['LangVar']['ExamineState'],
			$Fn_Hd->Config['LangVar']['VerificationState'],
			$Fn_Hd->Config['LangVar']['WhetherPay'],
			$Fn_Hd->Config['LangVar']['VerificationUid'].'/'.$Fn_Hd->Config['LangVar']['UserNameTitle'],
			$Fn_Hd->Config['LangVar']['UseTime'],
			$Fn_Hd->Config['LangVar']['TimeTitle'],
			$Fn_Hd->Config['LangVar']['OperationTitle']
		), 'header tbm tc');
		
		$ModulesList = GetModulesList($Page,$Limit,$Where,$Order);
		
		foreach ($ModulesList as $Module) {
			$Module['param'] = unserialize($Module['param']);
			$FormList = '<style>.SignUpList img{height:}</style>';
			foreach ($Module['param']['form_list'] as $Key=>$Val) {
				if($Key == 1){
					$I = 0;
					foreach($Val as $V){
						if($I < 4){
							if($V['file']){
								$V['value'] = '<a href="'.$V['value'].'" target="_blank"><img src="'.$V['value'].'" height="20px"></a>';
							}
							$FormList .= $V['title'].':'.$V['value'].'<br>';
						}
						$I++;
					}
				}
			}
			showtablerow('', array('class="tc w50"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
				'<input type="checkbox" class="filled-in" id="checkbox_'.$Module['id'].'" name="delete[]" value="'.$Module['id'].'"><label for="checkbox_'.$Module['id'].'">'.$Module['id'].'</label>',
				'<a href="'.$Fn_Hd->Config['ViewUrl'].$Module['aid'].'" target="_blank">'.$Module['title'].'</a>',
				$Module['uid'].'/'.$Module['username'],
				$Module['count'],
				$FormList,
				$Module['code'],
				$Module['examine'] ? '<span class="label bg-purple">'.$Fn_Hd->Config['LangVar']['ExamineArray'][$Module['examine']].'</span>' : '<span class="label bg-secondary">'.$Fn_Hd->Config['LangVar']['ExamineArray'][$Module['examine']].'</span>',
				$Module['state'] ? '<span class="label bg-blue">'.$Fn_Hd->Config['LangVar']['VerificationStateArray'][$Module['state']].'</span>' : '<span class="label bg-secondary">'.$Fn_Hd->Config['LangVar']['VerificationStateArray'][$Module['state']].'</span>',
				$Module['display'] ? '<span class="label bg-danger">'.$Fn_Hd->Config['LangVar']['Yes'].'</span>' : '<span class="label bg-secondary">'.$Fn_Hd->Config['LangVar']['No'].'</span>',
				$Module['v_uid'] ? $Module['v_uid'].'/'.$Module['v_username'] : '',
				$Module['statedateline'] ? date('Y-m-d H:i',$Module['statedateline']) : '',
				date('Y-m-d H:i',$Module['dateline']),
				
				'<a href="'.$Fn_Hd->Config['SignUpOpUrl'].$Module['id'].'&aid='.$Module['aid'].'" target="_blank" class="btn btn-sm btn-dark-outline">'.cplang('view').'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Examine&sid='.$Module['id'].'&value='.(!empty($Module['examine']) ? 0:1).'&formhash='.FORMHASH.'" class="btn btn-sm btn-info-outline">'.(!empty($Module['examine']) ? $Fn_Hd->Config['LangVar']['SignUpOpExamine0'] : $Fn_Hd->Config['LangVar']['SignUpOpExamine1']).'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=State&sid='.$Module['id'].'&value='.(!empty($Module['state']) ? 0:1).'&formhash='.FORMHASH.'" class="btn btn-sm btn-primary-outline">'.(!empty($Module['state']) ? $Fn_Hd->Config['LangVar']['OpStateArray'][0] : $Fn_Hd->Config['LangVar']['OpStateArray'][1]).'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Display&sid='.$Module['id'].'&value='.(!empty($Module['display']) ? 0:1).'&formhash='.FORMHASH.'" class="btn btn-sm btn-purple-outline">'.(!empty($Module['display']) ? $Fn_Hd->Config['LangVar']['OpPayArray'][0] : $Fn_Hd->Config['LangVar']['OpPayArray'][1]).'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Del&sid='.$Module['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$Fn_Hd->Config['LangVar']['DelTitle'].'</a>'
			));
		}
		showsubmit('Submit','&#31435;&#21363;&#25552;&#20132;','del','','',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));
        showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		/* ģ����� End */
	}else{
		if(isset($_GET['delete']) && is_array($_GET['delete'])){
			if(!$Fn_Admin->CheckUserGroup('hd_all') && !$Fn_Admin->CheckUserGroup('hd_sign_up_del')){//Ȩ���ж�
				fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
				exit();
			}
			foreach($_GET['delete'] as $Key => $Val) {
				$Val = intval($Val);
				DB::delete($Fn_Hd->TableSignUp,'id ='.$Val);
			}

			GetInsertDoLog('del_sign_up_hd','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete'])));//������¼

			fn_cpmsg($Fn_Hd->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
		}else{
			fn_cpmsg($Fn_Hd->Config['LangVar']['DelErr'],'','error');
		}
	}
}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['sid']){//ɾ��
	if(!$Fn_Admin->CheckUserGroup('hd_all') && !$Fn_Admin->CheckUserGroup('hd_sign_up_del')){//Ȩ���ж�
		fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
		exit();
	}
	$SId = intval($_GET['sid']);
	GetInsertDoLog('del_sign_up_hd','fn_'.$_GET['mod'],array('id'=>$_GET['sid']));//������¼
	DB::delete($Fn_Hd->TableSignUp,'id ='.$SId);

	fn_cpmsg($Fn_Hd->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');

}else if($Do == 'State' && $_GET['formhash'] == formhash() && $_GET['sid']){//�����Ƿ�ʹ��
	$Value = intval($_GET['value']);
	$UpData['state'] = intval($Value);
	$UpData['statedateline'] = $Value == 1 ? time() : '';
	$UpData['v_uid'] = $Value == 1 ? intval($_G['uid']) : '';
	$UpData['v_username'] = $Value == 1 ? addslashes(strip_tags($_G['username'])) : '';
	DB::update($Fn_Hd->TableSignUp,$UpData,' id = '.intval($_GET['sid']));

	GetInsertDoLog('state_sign_up_hd','fn_'.$_GET['mod'],array('id'=>$_GET['sid'],'state'=>$_GET['value']));//������¼

	fn_cpmsg($Fn_Hd->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

}else if($Do == 'Display' && $_GET['formhash'] == formhash() && $_GET['sid']){//�Ƿ���ʾ
	$SId = intval($_GET['sid']);
	$Value = intval($_GET['value']);
	EditFields($Fn_Hd->TableSignUp,$SId,'display',$Value);
	
	GetInsertDoLog('display_sign_up_hd','fn_'.$_GET['mod'],array('id'=>$_GET['sid'],'display'=>$_GET['value']));//������¼
	fn_cpmsg($Fn_Hd->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

}else if($Do == 'Examine' && $_GET['formhash'] == formhash() && $_GET['sid']){//���
	$SId = intval($_GET['sid']);
	$Value = intval($_GET['value']);
	EditFields($Fn_Hd->TableSignUp,$SId,'examine',$Value);
	
	GetInsertDoLog('examine_sign_up_hd','fn_'.$_GET['mod'],array('id'=>$_GET['sid'],'examine'=>$_GET['value']));//������¼
	fn_cpmsg($Fn_Hd->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
}

/* �б� */
function GetModulesList($Page,$Limit,$Where,$Order){
	global $Fn_Hd;
	$FetchSql = 'SELECT H.title,S.* FROM '.DB::table($Fn_Hd->TableSignUp).' S LEFT JOIN '.DB::table($Fn_Hd->TableHd).' H on H.id = S.aid '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}

/* ���� */
function GetModulesCount($Where){
	global $Fn_Hd;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_Hd->TableSignUp).' S '.$Where;
	return DB::result_first($FetchSql);//��������
}
//From: Dism_taobao_com
?>