<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('hd_all') && !$Fn_Admin->CheckUserGroup('hd_post_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$Do = in_array($_GET['do'], array('Del','Display','Edit')) ? $_GET['do'] : 'List';

//�����ֶ�
$SearField =array('page','keyword','display','aid','order');
foreach($SearField as $Val) {
	$SearArray[$Val] = $_GET[$Val] || in_array($_GET[$Val],array('0')) ? $_GET[$Val] : '';
}
//�����ֶ� End

$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeItemUrl'].'&'.http_build_query($SearArray);

if($Do == 'List'){

	if(!submitcheck('Submit')) {
		$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
		/* ��ѯ���� */
		$Where = '';
		$Order = in_array($_GET['order'], array('pid')) ? 'P.'.addslashes(dhtmlspecialchars($_GET['order'])) : 'P.pid';

		if($_GET['keyword']){
			$_GET['keyword'] = str_replace(array('%','_'),array('',''),$_GET['keyword']);
			$Where .= ' and (P.username like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or P.content like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or P.uid = '.intval($_GET['keyword']).' )';
		}

		if(in_array($_GET['list_display'],array('0','1'))){
			$Where .= ' and P.display = '.intval($_GET['list_display']);
		}
		if($_GET['aid']){
			$Where .= ' and P.aid = '.intval($_GET['aid']);
		}
		
		$Where = preg_replace('/and/','where',$Where,1);
		$Limit = 30;
		$Page = $_GET['page']?intval($_GET['page']):1;
		/* ��ѯ���� End */

		/* ģ����� */		
		showtagheader('div', 'row', true,'row');
		showtagheader('div', 'col-12', true,'col-12');
		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-body', true,'box-body');
		
		/* ���� */
		$DisplaySelected = array($_GET['list_display']=>' selected');
		echo <<<SEARCH
		<form method="post" autocomplete="off" action="$SearUrl" id="tb_search">
			<div class="FormSearchTo">
				<table cellspacing="4" cellpadding="4">
					<tr>
						<th>{$Fn_Hd->Config['LangVar']['KeywordTitle']}</th><td><input type="text" class="input form-control w150" name="keyword" value="{$_GET['keyword']}"></td>
						<th>{$Fn_Hd->Config['LangVar']['ActivityTitle']}ID</th><td><input type="text" class="input form-control w100" name="aid" value="{$_GET['aid']}"></td>
						<th>{$Fn_Hd->Config['LangVar']['DisplayTitle']}</th><td>
						<select name="list_display" class="form-control w120">
							<option value="">{$Fn_Hd->Config['LangVar']['SelectNull']}</option>
							<option value="1"{$DisplaySelected['1']}>{$Fn_Hd->Config['LangVar']['Yes']}</option>
							<option value="0"{$DisplaySelected['0']}>{$Fn_Hd->Config['LangVar']['No']}</option>
						</select>
						&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Admin->Config['LangVar']['SearchSubmit']}" class="btn btn-info" type="submit">
						</td>
					</tr>
				</table>
			</div>
		</form>
SEARCH;
		/* ���� End */
		
		showtagheader('div', 'table-responsive', true,'table-responsive');
		showformheader($FormUrl,'enctype="multipart/form-data"');
		showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
		showsubtitle(array(
			'ID',
			$Fn_Hd->Config['LangVar']['ActivityTitle'].$Fn_Hd->Config['LangVar']['Title'],
			'Uid/'.$Fn_Hd->Config['LangVar']['UserNameTitle'],
			$Fn_Hd->Config['LangVar']['PostContentTitle'],
			$Fn_Hd->Config['LangVar']['ReplyCountTitle'],
			$Fn_Hd->Config['LangVar']['DisplayTitle'],
			$Fn_Hd->Config['LangVar']['TimeTitle'],
			$Fn_Hd->Config['LangVar']['OperationTitle']
		), 'header tbm tc');
		
		$ModulesList = GetModulesList($Page,$Limit,$Where,$Order);
		
		foreach ($ModulesList as $Module) {
			showtablerow('', array('class="tc w80"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
				'<input type="checkbox" class="filled-in" id="checkbox_'.$Module['id'].'" name="delete[]" value="'.$Module['id'].'"><label for="checkbox_'.$Module['id'].'">'.$Module['id'].'</label>',
				'<a href="'.$Fn_Hd->Config['ViewUrl'].$Module['aid'].'&pid='.$Module['pid'].'" target="_blank">'.$Module['title'].'</a>',
				$Module['uid'].'/'.$Module['username'],
				$Module['content'],
				$Module['reply_count'],
				!$Module['display'] ? '<span class="label bg-secondary">'.$Fn_Hd->Config['LangVar']['No'].'</span>' : '<span class="label bg-blue">'.$Fn_Hd->Config['LangVar']['Yes'].'</span>',
				date('Y-m-d H:i',$Module['dateline']),
				'<a href="'.$OpCpUrl.'&do=Edit&pid='.$Module['pid'].'" class="btn btn-sm btn-info-outline">'.$Fn_Hd->Config['LangVar']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Display&pid='.$Module['pid'].'&value='.(!empty($Module['display']) ? 0:1).'&formhash='.FORMHASH.'" class="btn btn-sm btn-warning-outline">'.(!empty($Module['display']) ? $Fn_Hd->Config['LangVar']['DisplayNoTitle'] : $Fn_Hd->Config['LangVar']['DisplayIsTitle']).'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Del&pid='.$Module['pid'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$Fn_Hd->Config['LangVar']['DelTitle'].'</a>',
			));
		}
		showsubmit('Submit','&#31435;&#21363;&#25552;&#20132;','del','','',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));
        showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		/* ģ����� End */
	}else{
		if(isset($_GET['delete']) && is_array($_GET['delete'])){
			if(!$Fn_Admin->CheckUserGroup('hd_all') && !$Fn_Admin->CheckUserGroup('hd_post_del')){//Ȩ���ж�
				fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
				exit();
			}
			foreach($_GET['delete'] as $Key => $Val) {
				$Val = intval($Val);
				$Item = $Val ? DB::fetch_first('SELECT * FROM '.DB::table($Fn_Hd->TablePost).' where pid = '.$Val) : array();
				if($Item){
					DB::delete($Fn_Hd->TablePost,'pid ='.$Val);
					if($Item['rid']){
						DB::query("UPDATE ".DB::table($Fn_Hd->TablePost)." SET reply_count = reply_count-1 WHERE pid=".intval($Item['rid']));
					}
				}
			}

			GetInsertDoLog('del_post_hd','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete'])));//������¼

			fn_cpmsg($Fn_Hd->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
		}else{
			fn_cpmsg($Fn_Hd->Config['LangVar']['DelErr'],'','error');
		}
	}
}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['pid']){//ɾ��

	if(!$Fn_Admin->CheckUserGroup('hd_all') && !$Fn_Admin->CheckUserGroup('hd_post_del')){//Ȩ���ж�
		fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
		exit();
	}

	$PId = intval($_GET['pid']);
	$Item = $PId ? DB::fetch_first('SELECT * FROM '.DB::table($Fn_Hd->TablePost).' where pid = '.$PId) : array();
	if($Item){
		DB::delete($Fn_Hd->TablePost,'pid ='.$PId);
		if($Item['rid']){
			DB::query("UPDATE ".DB::table($Fn_Hd->TablePost)." SET reply_count = reply_count-1 WHERE pid=".intval($Item['rid']));
		}

		GetInsertDoLog('del_post_hd','fn_'.$_GET['mod'],array('id'=>$_GET['pid']));//������¼

		fn_cpmsg($Fn_Hd->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
	}else{
		fn_cpmsg($Fn_Hd->Config['LangVar']['DelErr'],'','error');
	}
	
}else if($Do == 'Display' && $_GET['formhash'] == formhash() && $_GET['pid']){//�Ƿ���ʾ
	$PId = intval($_GET['pid']);
	$UpData['display'] = intval($_GET['value']);
	DB::update($Fn_Hd->TablePost,$UpData,'pid ='.$PId);
	GetInsertDoLog('display_post_hd','fn_'.$_GET['mod'],array('id'=>$_GET['pid'],'display'=>$_GET['value']));//������¼
	fn_cpmsg($Fn_Hd->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

}else if($Do == 'Edit'){//�༭����

	if(!$Fn_Admin->CheckUserGroup('hd_all') && !$Fn_Admin->CheckUserGroup('hd_post_add')){//Ȩ���ж�
		fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
		exit();
	}

	$PId = intval($_GET['pid']);
	$Item = $PId ? DB::fetch_first('SELECT * FROM '.DB::table($Fn_Hd->TablePost).' where pid = '.$PId) : array();
	if($Item['param']){$Item['param'] = unserialize($Item['param']);}

	if(!submitcheck('DetailSubmit')) {
		$OpTitle = $Fn_Hd->Config['LangVar']['AddTitle'];
		if($Item)$OpTitle = $Fn_Hd->Config['LangVar']['EditTitle'];

		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-header', true,'with-border box-header');
		showtitle($OpTitle,'class="box-title"');
		showtagfooter('div');
		showformheader($Fn_Admin->Config['IframeItemUrl'].'&do=Edit&pid='.$PId,'enctype');
		showtagheader('div', 'box-body', true,'box-body');

		showsetting($Fn_Hd->Config['LangVar']['PostContentTitle'], 'content', $Item['content'], 'textarea');
		showsetting($Fn_Hd->Config['LangVar']['DisplayTitle'], 'display', $Item['display'], 'radio');
		if($Item['dateline']){
			showsetting($Fn_Hd->Config['LangVar']['TimeTitle'], 'dateline',date('Y-m-d H:i',$Item['dateline']), 'calendar','','','',1);
		}

		showsubmit('DetailSubmit','&#20445;&#23384;&#37197;&#32622;');
		showtagfooter('div');
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');
	}else{
		$Data['content'] = addslashes(strip_tags($_GET['content']));
		$Data['display'] = intval($_GET['display']);
		if($Item){
			$Data['dateline'] = strtotime($_GET['dateline']);
			DB::update($Fn_Hd->TablePost,$Data,'pid = '.$PId);
			GetInsertDoLog('edit_post_hd','fn_'.$_GET['mod'],array('id'=>$_GET['pid']));//������¼
		}
		fn_cpmsg($Fn_Hd->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
	}
	
}

/* �б� */
function GetModulesList($Page,$Limit,$Where,$Order){
	global $Fn_Hd;
	$FetchSql = 'SELECT H.title,P.* FROM '.DB::table($Fn_Hd->TablePost).' P LEFT JOIN '.DB::table($Fn_Hd->TableHd).' H on H.id = P.aid '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}
/* ���� */
function GetModulesCount($Where=null){
	global $Fn_Hd;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_Hd->TablePost).' P '.$Where;
	return DB::result_first($FetchSql);//��������
}
//From: Dism_taobao_com
?>