<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('hd_all') && !$Fn_Admin->CheckUserGroup('hd_field_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$SubModel = in_array($_GET['submodel'], array('list','add')) ? $_GET['submodel'] : 'list';
$Fn_Admin->Config['IframeSubModelUrl'] = $Fn_Admin->Config['IframeItemUrl'].'&submodel='.$SubModel;
$NavClass = array($SubModel=>'btn-info Hover');

//����
echo <<<Nav
<div class="SubModelNav">
  <ul>
	<li class="{$NavClass['list']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=list" target="_self">{$Fn_Admin->Config['LangVar']['HdLeftNavArray']['field_list']}</a></li>
    <li class="{$NavClass['add']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=add" target="_self">{$Fn_Admin->Config['LangVar']['AddEditTitle']}</a></li>
  </ul>
  <div class="both"></div>
</div>
Nav;


if($SubModel == 'list'){//�б�
	$Do = in_array($_GET['do'], array('Del','Add','Edit')) ? $_GET['do'] : 'List';

	$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeItemUrl'];
	if($Do == 'List'){
		if(!submitcheck('Submit')) {
			$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
			/* ��ѯ���� */
			$Where = '';
			$Order = 'F.displayorder';
			
			$Where = preg_replace('/and/','where',$Where,1);
			$Limit = 30;
			$Page = $_GET['page']?intval($_GET['page']):1;
			/* ��ѯ���� End */
			
			/* ģ����� */		
			showtagheader('div', 'row', true,'row');
			showtagheader('div', 'col-12', true,'col-12');
			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-body', true,'box-body');
			showtagheader('div', 'table-responsive', true,'table-responsive');
			showformheader($FormUrl,'enctype="multipart/form-data"');
			showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');

			showsubtitle(array(
				'ID',
				$Fn_Hd->Config['LangVar']['DisplayOrder'],
				$Fn_Hd->Config['LangVar']['FieldName'],
				$Fn_Hd->Config['LangVar']['FieldTitle'],
				$Fn_Hd->Config['LangVar']['FieldDesc'],
				$Fn_Hd->Config['LangVar']['FieldType'],
				$Fn_Hd->Config['LangVar']['RequiredTitle'],
				$Fn_Hd->Config['LangVar']['OperationTitle']
			), 'header tbm tc');
			
			$ModulesList = GetModulesList($Page,$Limit,$Where,$Order);
			
			foreach ($ModulesList as $Module) {
				showtablerow('', array('class="tc w50"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
					$Module['id'],
					'<input type="text" class="input form-control w50" name="displayorder['.$Module['id'].']" value='.$Module['displayorder'].'>',
					$Module['name'],
					$Module['title'],
					$Module['description'],
					$Module['formtype'],
					$Module['required'] ? '<span class="label bg-danger">'.$Fn_Hd->Config['LangVar']['Yes'].'</span>' : '<span class="label bg-secondary">'.$Fn_Hd->Config['LangVar']['No'].'</span>',
					'<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&fid='.$Module['id'].'" class="btn btn-sm btn-info-outline">'.$Fn_Hd->Config['LangVar']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Del&fid='.$Module['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$Fn_Hd->Config['LangVar']['DelTitle'].'</a>'
				));
			}
			showsubmit('Submit','&#20445;&#23384;&#37197;&#32622;','','','',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));
			showtablefooter(); /*dism��taobao��com*/
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			/* ģ����� End */
		}else{
			if(isset($_GET['displayorder']) && is_array($_GET['displayorder'])){
				foreach($_GET['displayorder'] as $Id => $Val) {
					$Id = intval($Id);
					$Data['displayorder'] = intval($Val);
					DB::update($Fn_Hd->TableField,$Data,'id = '.$Id);
				}
				fn_cpmsg($Fn_Hd->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
			}else{
				fn_cpmsg($Fn_Hd->Config['LangVar']['UpdateErr'],'','error');
			}
		}
	}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['fid']){//ɾ��
		$FId = intval($_GET['fid']);
		DB::delete($Fn_Hd->TableField,'id ='.$FId);
		
		GetInsertDoLog('del_field_hd','fn_'.$_GET['mod'],array('id'=>$_GET['fid']));//������¼
		fn_cpmsg($Fn_Hd->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');

	}
}else if($SubModel == 'add'){//���ӻ�༭
	$FId = intval($_GET['fid']);
	$Item = $FId ? $Fn_Hd->QueryOne($Fn_Hd->TableField,$FId) : array();
	if(!submitcheck('DetailSubmit')) {
		$OpTitle = $Fn_Hd->Config['LangVar']['AddTitle'];
		if($Item)$OpTitle = $Fn_Hd->Config['LangVar']['EditTitle'];

		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-header', true,'with-border box-header');
		showtitle($OpTitle,'class="box-title"');
		showtagfooter('div');
		showformheader($Fn_Admin->Config['IframeSubModelUrl'].'&fid='.$FId,'enctype');
		showtagheader('div', 'box-body', true,'box-body');

		showsetting($Fn_Hd->Config['LangVar']['FormItemName'], 'name', $Item['name'], 'text','','',$Fn_Hd->Config['LangVar']['FormItemNamePrompt']);
		showsetting($Fn_Hd->Config['LangVar']['FormItemTitle'], 'title', $Item['title'], 'text','','',$Fn_Hd->Config['LangVar']['FormItemTitlePrompt']);
		showsetting($Fn_Hd->Config['LangVar']['FormItemDesc'], 'description', $Item['description'], 'text','','',$Fn_Hd->Config['LangVar']['FormItemDescPrompt']);
		
		showsetting($Fn_Hd->Config['LangVar']['FormItemType'], array('formtype', array(
			array('text',$Fn_Hd->Config['LangVar']['FormArray']['text'], array('valuenumber' => '', 'fieldchoices' => 'none')),
			array('tel',$Fn_Hd->Config['LangVar']['FormArray']['tel'], array('valuenumber' => '', 'fieldchoices' => 'none')),
			array('textarea',$Fn_Hd->Config['LangVar']['FormArray']['textarea'], array('valuenumber' => '', 'fieldchoices' => 'none')),
			array('file',$Fn_Hd->Config['LangVar']['FormArray']['file'], array('valuenumber' => 'none', 'fieldchoices' => 'none')),
			array('select',$Fn_Hd->Config['LangVar']['FormArray']['select'], array('valuenumber' => 'none', 'fieldchoices' => '')),
		)), $Item['formtype'] ? $Item['formtype'] : 'text' , 'mradio', '', '',$Fn_Hd->Config['LangVar']['FormItemTypePrompt']);
		
		if(in_array($Item['formtype'], array('text', 'tel', 'textarea', 'checkbox')) || !$Item['formtype']) {
			$ValuenumberDisplay = true;
		}else{
			$ValuenumberDisplay = false;
		}

		if(in_array($Item['formtype'], array('radio', 'checkbox', 'select'))) {
			$FieldchoicesDisplay = true;
		}else{
			$FieldchoicesDisplay = false;
		}
		
		showtagheader('div', 'valuenumber', $ValuenumberDisplay,'valuenumber');
			showsetting($Fn_Hd->Config['LangVar']['SizeLimit'], 'size', $Item['size'], 'text','','',$Fn_Hd->Config['LangVar']['SizeLimitPrompt']);
			showsetting($Fn_Hd->Config['LangVar']['Match'], 'match', $Item['match'], 'text','','',$Fn_Hd->Config['LangVar']['MatchPrompt']);
		showtagfooter('div');
		
		showtagheader('div', 'fieldchoices', $FieldchoicesDisplay,'fieldchoices');
			showsetting($Fn_Hd->Config['LangVar']['OptionalValue'], 'choices', implode("\r\n",unserialize($Item['choices'])), 'textarea', '', '',$Fn_Hd->Config['LangVar']['OptionalValuePrompt']);
		showtagfooter('div');
		
		showsetting($Fn_Hd->Config['LangVar']['RequiredTitle'], 'required', $Item['required'], 'radio');
		showsetting($Fn_Hd->Config['LangVar']['DisplayOrder'], 'displayorder', $Item['displayorder'], 'text');

		showsubmit('DetailSubmit','&#20445;&#23384;&#37197;&#32622;');
		showtagfooter('div');
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');
	}else{
		$Data['name'] = addslashes(strip_tags($_GET['name']));
		$Data['title'] = addslashes(strip_tags($_GET['title']));
		$Data['description'] = addslashes(strip_tags($_GET['description']));
		$Data['formtype'] = addslashes(strip_tags($_GET['formtype']));
		$Data['size'] = intval($_GET['size']);
		$Data['match'] = addslashes(strip_tags($_GET['match']));
		$Data['choices'] = $_GET['choices'] ? serialize(array_filter(explode("\r\n",$_GET['choices']))) : '';
		$Data['displayorder'] = intval($_GET['displayorder']);
		$Data['required'] = intval($_GET['required']);
		
		$CheCk = DB::fetch_first('SELECT * FROM '.DB::table($Fn_Hd->TableField).' where name = \''.$Data['name'].'\'');
		if($CheCk && !$Item){
			fn_cpmsg($Fn_Hd->Config['LangVar']['FormItemNameErr'],'','error');
			exit();
		}

		if($Item){
			DB::update($Fn_Hd->TableField,$Data,'id = '.$FId);
			GetInsertDoLog('edit_field_hd','fn_'.$_GET['mod'],array('id'=>$FId));//������¼
		}else{
			$Data['dateline'] =  time();
			$FId = DB::insert($Fn_Hd->TableField,$Data,true);
			GetInsertDoLog('add_field_hd','fn_'.$_GET['mod'],array('id'=>$FId));//������¼
		}
		fn_cpmsg($Fn_Hd->Config['LangVar']['UpdateOk'],$Fn_Admin->Config['IframeItemUrl'].'&submodel=list','succeed');
	}
}

/* �б� */
function GetModulesList($Page,$Limit,$Where=null,$Order){
	global $Fn_Hd;
	$FetchSql = 'SELECT F.* FROM '.DB::table($Fn_Hd->TableField).' F '.$Where.' order by '.$Order.' asc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}
/* ���� */
function GetModulesCount($Where=null){
	global $Fn_Hd;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_Hd->TableField).' F '.$Where;
	return DB::result_first($FetchSql);//��������
}
//From: Dism_taobao_com
?>