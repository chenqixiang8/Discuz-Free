<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if(!$Fn_Admin->CheckUserGroup('hd_all') && !$Fn_Admin->CheckUserGroup('hd_config')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

@require_once libfile('function/cache');
@require_once libfile('function/core','plugin/fn_assembly');

$setting_name = 'fn_'.$_GET['mod'].'_setting';
loadcache($setting_name);
$common_setting = $_G['cache'][$setting_name];
$setting = $common_setting = array_filter($common_setting) ? $common_setting : array();
foreach($setting as $key => $value) {
	$setting[$key] = is_array($value) ? $value : stripslashes($value);
}
$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeItemUrl'];

if(!submitcheck('DetailSubmit')) {
	//ͼƬ�ϴ�
	if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_assembly/class/class_upload.php')){
		@require_once libfile('class/upload','plugin/fn_assembly');
		$UploadConfig = fn_upload::Config();
	}

	showtagheader('div', 'box', true,'box');
	showformheader($FormUrl,'enctype');
	if(in_array($Config['PluginVar']['AppType'],array('1','2'))){
		$AppNav = '<li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#app" role="tab" aria-expanded="false"><span class="hidden-sm-up"><i class="ion-email"></i></span> <span class="hidden-xs-down">&#65;&#80;&#80;&#35774;&#32622;</span></a> </li>';
	}
	echo <<<HTML
		<ul class="nav nav-tabs customtab" role="tablist">
          <li class="nav-item"> <a class="nav-link active" data-toggle="tab" href="#basics" role="tab" aria-expanded="true"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#22522;&#30784;&#35774;&#32622;</span></a> </li>
		  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#wx" role="tab" aria-expanded="false"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#20844;&#20247;&#21495;&#35774;&#32622;</span></a> </li>
		  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#share" role="tab" aria-expanded="false"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#20998;&#20139;&#35774;&#32622;</span></a> </li>
		  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#color" role="tab" aria-expanded="false"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#39068;&#33394;&#35774;&#32622;</span></a> </li>
		  {$AppNav}
        </ul>
HTML;

	showtagheader('div', 'box-body', true,'box-body');

	showtagheader('div', 'tab-content', true,'tab-content');

	echo <<<HTML
	<!-- ��������  -->
	<div class="tab-pane active" id="basics" role="tabpanel" aria-expanded="true">
HTML;
	
	showsetting('&#26631;&#39064;', 'setting[Title]', $setting['Title'] ? $setting['Title'] : '&#12304;&#39134;&#40479;&#12305;&#21516;&#22478;&#27963;&#21160;', 'text');

	echo '<div class="form-group row"><label class="col-sm-1 col-form-label">&#27178;&#24133;&#22270;&#29255;<br>&#23610;&#23544;&#24314;&#35758;&#54;&#52;&#48;&#32;&#42;&#32;&#51;&#48;&#48;</label><div class="col-sm-9"><div class="UploadBanner"><div class="PhotoControl ClickPhotoControl" id="Banners"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';

	showsetting('&#21015;&#34920;&#35843;&#29992;&#26465;&#25968;', 'setting[ListNum]', $setting['ListNum'] ? $setting['ListNum'] : 10, 'text');
	
	showsetting('&#21015;&#34920;&#25490;&#24207;', array('setting[ListOrder]',dyadic_array(array('id'=>'&#26368;&#26032;','displayorder'=>'&#26174;&#31034;&#39034;&#24207;'))), $setting['ListOrder'] ? $setting['ListOrder'] : 'id', 'mradio');

	showsetting('&#25253;&#21517;&#21015;&#34920;&#35843;&#29992;&#26465;&#25968;', 'setting[SignUpListNum]', $setting['SignUpListNum'] ? $setting['SignUpListNum'] : 10, 'text');

	showsetting('&#27963;&#21160;&#22768;&#26126;', 'setting[Statement]', $setting['Statement'] ? $setting['Statement'] : '<span class="ColorRed">&#26412;&#27963;&#21160;&#20026;&#38750;&#30408;&#21033;&#30446;&#30340;&#32593;&#21451;&#27963;&#21160;</span>&#65292;&#27963;&#21160;&#20013;&#21487;&#33021;&#23384;&#22312;&#24847;&#22806;&#30340;&#22240;&#32032;&#65292;&#21442;&#21152;&#32773;&#32431;&#23646;&#33258;&#24895;&#34892;&#20026;&#65292;&#19968;&#26086;&#25253;&#21517;&#21442;&#21152;&#65292;&#21017;&#35270;&#20026;&#24895;&#24847;&#33258;&#34892;&#25215;&#25285;&#27963;&#21160;&#20013;&#21487;&#33021;&#20986;&#29616;&#30340;&#24847;&#22806;&#20260;&#23475;&#21450;&#32463;&#27982;&#25439;&#22833;&#65292;&#32452;&#32455;&#32773;&#21450;&#20854;&#20182;&#25104;&#21592;&#27010;&#19981;&#25215;&#25285;&#20219;&#20309;&#27861;&#24459;&#25110;&#32773;&#32463;&#27982;&#19978;&#30340;&#36131;&#20219;&#65292;&#35831;&#24910;&#37325;&#25253;&#21517;&#21442;&#21152;&#65292;&#35874;&#35874;&#12290;', 'textarea');

	showsetting('&#31215;&#20998;&#33719;&#21462;&#26041;&#24335;&#38142;&#25509;', 'setting[ExtcreditsLink]', $setting['ExtcreditsLink'], 'text');

	$setting['UserImgPath'] = $setting['UserImgPath'] ? $setting['UserImgPath'] : '/source/plugin/fn_hd/static/images/user.png';
	$UserImgPathHtml = '<a href="'.$setting['UserImgPath'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['UserImgPath'].'" height="55"/></a>&#25105;&#21442;&#19982;&#30340;&#22270;&#26631;&#36335;&#24452;';
	showsetting('&#25105;&#21442;&#19982;&#30340;&#22270;&#26631;&#36335;&#24452;', 'new_UserImgPath',$setting['UserImgPath'], 'filetext', '', 0, $UserImgPathHtml);

	showsetting('&#36820;&#22238;&#35770;&#22363;&#39318;&#39029;&#38142;&#25509;', 'setting[BackHomeLink]', $setting['BackHomeLink'], 'text');
	
	showsetting('&#30005;&#33041;&#29256;&#20108;&#32500;&#30721;',array('setting[PcQrSwitch]', array(
		array('1','&#26159;', array('PcQrSwitchDiv' => '')),
		array('0','&#21542;;', array('PcQrSwitchDiv' => 'none')),
	), TRUE),$setting['PcQrSwitch'], 'mradio');

	showtagheader('div', 'PcQrSwitchDiv', $setting['PcQrSwitch'] == 1 ? true : '','PcQrSwitchDiv');
		showsetting('&#30005;&#33041;&#29256;&#20108;&#32500;&#30721;&#25991;&#23383;', 'setting[PcQrText]', $setting['PcQrText'] ? $setting['PcQrText'] : '&#25163;&#26426;&#25195;&#19968;&#25195;&#65292;&#21442;&#21152;&#27963;&#21160;&#26356;&#26041;&#20415;', 'text');
	showtagfooter('div');

	showsetting('&#31532;&#19977;&#26041;&#32479;&#35745;&#20195;&#30721;', 'setting[Statistics]', $setting['Statistics'], 'textarea');

	echo <<<HTML
	</div>
	<!-- �������� end  -->
HTML;

	echo <<<HTML
	<!-- ΢������  -->
	<div class="tab-pane" id="wx" role="tabpanel" aria-expanded="false">
	<div class="alert alert-primary" role="alert">&#21442;&#25968;&#20108;&#32500;&#30721;&#20316;&#29992;&#65306;&#29983;&#25104;&#28023;&#25253;&#30340;&#20108;&#32500;&#30721;&#20026;&#20844;&#20247;&#21495;&#30340;&#20108;&#32500;&#30721;&#65292;&#20851;&#27880;&#21518;&#20250;&#33258;&#21160;&#25512;&#36865;&#38142;&#25509;<br>&#28201;&#39336;&#25552;&#37266;&#65306;&#22914;&#26524;&#19981;&#38656;&#35201;&#21442;&#25968;&#20108;&#32500;&#30721;&#65292;&#21487;&#24573;&#30053;&#35813;&#35774;&#32622;</div>
HTML;
	
	showsetting('&#24320;&#21551;&#21442;&#25968;&#20108;&#32500;&#30721;',array('setting[QrParameterSwitch]', array(
		array('1','&#26159;', array('QrParameterDiv' => '')),
		array('0','&#21542;;', array('QrParameterDiv' => 'none')),
	), TRUE),$setting['QrParameterSwitch'], 'mradio');

	showtagheader('div', 'QrParameterDiv', $setting['QrParameterSwitch'] == 1 ? true : '','QrParameterDiv');
		showsetting('&#24494;&#20449;&#65;&#112;&#112;&#73;&#100;', 'setting[WxAppid]', $setting['WxAppid'], 'text');
		showsetting('&#24494;&#20449;&#83;&#101;&#99;&#114;&#101;&#116;', 'setting[WxSecret]', $setting['WxSecret'], 'text');
		showsetting('&#24494;&#20449;&#20196;&#29260;&#40;&#84;&#111;&#107;&#101;&#110;&#41;', 'setting[wechat_token]', $setting['wechat_token'], 'text','','','&#33719;&#21462;&#26041;&#24335;&#65306;&#20844;&#20247;&#21495;&#21518;&#21488;&#45;&#12299;&#22522;&#26412;&#37197;&#32622;&#45;&#12299;&#26381;&#21153;&#22120;&#37197;&#32622;&#45;&#12299;&#20196;&#29260;&#40;&#84;&#111;&#107;&#101;&#110;&#41;');
	showtagfooter('div');

	echo <<<HTML
	</div>
	<!-- ΢������ end  -->
HTML;

	echo <<<HTML
	<!-- ��������  -->
	<div class="tab-pane" id="share" role="tabpanel" aria-expanded="false">
HTML;
	
	showsetting('&#20998;&#20139;&#26631;&#39064;', 'setting[WxTitle]', $setting['WxTitle'] ? $setting['WxTitle'] : '&#12304;&#39134;&#40479;&#12305;&#21516;&#22478;&#27963;&#21160;', 'text');

	showsetting('&#20998;&#20139;&#25551;&#36848;', 'setting[WxDes]', $setting['WxDes'] ? $setting['WxDes'] : '&#12304;&#39134;&#40479;&#12305;&#21516;&#22478;&#27963;&#21160;', 'textarea');

	$setting['WxImg'] = $setting['WxImg'] ? $setting['WxImg'] : '/source/plugin/fn_hd/static/images/ico.png';
	$WxImgHtml = '<a href="'.$setting['WxImg'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['WxImg'].'" height="55"/></a>&#23610;&#23544;&#49;&#48;&#48;&#32;&#42;&#32;&#49;&#48;&#48;';
	showsetting('&#20998;&#20139;&#22270;&#29255;', 'new_WxImg',$setting['WxImg'], 'filetext', '', 0, $WxImgHtml);

	echo <<<HTML
	</div>
	<!-- �������� end  -->
HTML;

	echo <<<HTML
	<!-- ��ɫ����  -->
	<div class="tab-pane" id="color" role="tabpanel" aria-expanded="false">
HTML;

	showsetting('&#20027;&#39064;&#39068;&#33394;', 'setting[Color]', $setting['Color'] ? $setting['Color'] : '#9ed874', 'color');

	showsetting('&#21103;&#20027;&#39064;&#39068;&#33394;', 'setting[FColor]', $setting['FColor'] ? $setting['FColor'] : '#FF715D', 'color');

	echo <<<HTML
	</div>
	<!-- ��ɫ���� end  -->
HTML;
	
	if(in_array($Config['PluginVar']['AppType'],array('1','2'))){

	echo <<<HTML
	<!-- APP����  -->
	<div class="tab-pane" id="app" role="tabpanel" aria-expanded="false">
HTML;

	showtagheader('div', 'mag_app_table', $Config['PluginVar']['AppType'] == 1 ? true : '','mag_app_table');
		showsetting('&#39532;&#30002;&#83;&#101;&#99;&#114;&#101;&#116;', 'setting[MagSecret]', $setting['MagSecret'], 'text','','','&#19981;&#22635;&#21017;&#32487;&#25215;&#12304;&#20840;&#23616;&#35774;&#32622;&#12305;&#30340;&#35774;&#32622;');
	showtagfooter('div');
	
	showtagheader('div', 'qf_app_table', $Config['PluginVar']['AppType'] == 2 ? true : '','qf_app_table');
		showsetting('&#21315;&#24070;&#25903;&#20184;&#35746;&#21333;&#31867;&#22411;&#73;&#68;', 'setting[qf_type]', $setting['qf_type'], 'text','','','&#19981;&#22635;&#21017;&#32487;&#25215;&#12304;&#20840;&#23616;&#35774;&#32622;&#12305;&#30340;&#35774;&#32622;');
	showtagfooter('div');

	echo <<<HTML
	</div>
	<!-- APP���� end  -->
HTML;
	}

	showsubmit('DetailSubmit', '&#20445;&#23384;&#37197;&#32622;');
	showtagfooter('div');
	showtagfooter('div');
	showformfooter(); /*Dism_taobao-com*/
	showtagfooter('div');

	if($setting['banners']){
		foreach($setting['banners'] as $Key => $Val) {
			$banners_js_array[] = '"'.$Val['img'].'|'.$setting['banners'][$Key]['title'].'|'.$setting['banners'][$Key]['link'].'"';
		}
		$UpLoadHtml .= '
		var InputArray = new Array('.implode(',',$banners_js_array).');
		$("#Banners").AppUpload({InputName:"new_banners",InputLink:true,InputExist:true,InputArray:InputArray,Move:true});';
	}else{
		$UpLoadHtml .= '$("#Banners").AppUpload({InputName:"new_banners",InputLink:true,Move:true});';
	}

	echo $UploadConfig['CssJsHtml'];
	echo '<script>'.$UpLoadHtml.'</script>';
	
}else{
	
	foreach($_GET['setting'] as $key => $value) {
		$setting[$key] = is_array($value) ? $value : addslashes($value);
	}

	foreach($_GET['upload_admin'] as $key => $value){
		if(strpos($key,'new_') !== false){
			$key_name = str_replace(array('new_'),'',$key);
			$setting[$key_name] = array();
			foreach($_GET[$key] as $k => $v) {
				$setting[$key_name][$k]['img'] = strpos($v,'http') !== false ? $v : $_G['siteurl'].$v;
				$setting[$key_name][$k]['link'] = $_GET[$key.'_link'][$k];
				$setting[$key_name][$k]['title'] = $_GET[$key.'_title'][$k];
			}
		}
	}

	foreach($_FILES as $file_key => $file_value){
		if(strpos($file_key,'new_') !== false){
			$key = str_replace(array('TMPnew_','new_'),'',$file_key);
			if($_FILES[$file_key]['size']){
				$FileCode = Fn_Upload($_FILES[$file_key]);
				if($FileCode['Errorcode']){
					cpmsg($Fn_Admin->Config['LangVar']['ImgErr'],'','error');
					exit();
				}else{
					$setting[$key] = $FileCode['Path'];
				}
			}else{
				$file_key = str_replace(array('TMPnew_'),array('new_'),$file_key);
				if(!preg_match('/.*(\.png|\.jpg|\.jpeg|\.gif)$/',$_GET[$file_key]) && $_GET[$file_key]){
					cpmsg($Fn_Admin->Config['LangVar']['ImgErr'],'','error');
					exit();
				}else{
					$setting[$key] = addslashes(strip_tags($_GET[$file_key]));
				}
			}
		}
	}

	savecache($setting_name,$setting);
	fn_cpmsg($Fn_Admin->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
	exit();

}
//From: Dism_taobao_com
?>