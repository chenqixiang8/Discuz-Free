<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('live_all') && !$Fn_Admin->CheckUserGroup('live_redpacket_log_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$SubModel = in_array($_GET['submodel'], array('list','add')) ? $_GET['submodel'] : 'list';
$Fn_Admin->Config['IframeSubModelUrl'] = $Fn_Admin->Config['IframeItemUrl'].'&submodel='.$SubModel;
$NavClass = array($SubModel=>'Hover');

if($SubModel == 'list'){//�б�
	$Do = in_array($_GET['do'], array('Del','State')) ? $_GET['do'] : 'submodel_list';
	//�����ֶ�
	$SearField =array('page','keyword','display','order','lid','cid','state');
	foreach($SearField as $Val) {
		$SearArray[$Val] = $_GET[$Val] || in_array($_GET[$Val],array('0')) ? $_GET[$Val] : '';
	}
	//�����ֶ� End
	$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeSubModelUrl'].'&'.http_build_query($SearArray);


	if($Do == 'submodel_list'){
		if(!submitcheck('Submit')) {
			$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
			$Where = '';
			$Order = $_GET['order'] ? 'L.'.addslashes(dhtmlspecialchars($_GET['order'])) : 'L.dateline';
			
			if($_GET['keyword']){
				$_GET['keyword'] = str_replace(array('%','_'),array('',''),$_GET['keyword']);
				$Where .= ' and (L.username like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or L.uid = '.intval($_GET['keyword']).' or L.id = '.intval($_GET['keyword']).' )';
			}

			if($_GET['lid']){
				$Where .= ' and L.lid = '.intval($_GET['lid']);
			}
			
			if($_GET['cid']){
				$Where .= ' and L.cid = '.intval($_GET['cid']);
			}

			if(in_array($_GET['state'],array('0','1'))){
				$Where .= ' and L.state = '.intval($_GET['state']);
			}

			$Where = preg_replace('/and/','where',$Where,1);
			$Limit = 20;
			$Page = $_GET['page']?intval($_GET['page']):1;
			/* ��ѯ���� End */
			

			/* ģ����� */	
			showtagheader('div', 'row', true,'row');
			showtagheader('div', 'col-12', true,'col-12');
			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-body', true,'box-body');
			/* ���� */
			$OrderSelected = array($_GET['order']=>' selected');
			$StateSelected = array($_GET['state']=>' selected');
			echo <<<SEARCH
			<form method="post" autocomplete="off" action="$SearUrl">
				<div class="FormSearchTo" style="margin-bottom:0;">
					<table cellspacing="4" cellpadding="4">
						<tr>
							<th>{$Fn_Live->Config['LangVar']['LiveId']}</th><td><input type="text" class="input form-control w80" name="lid" value="{$_GET['lid']}">
							</td>
							<th>{$Fn_Live->Config['LangVar']['RedpacketId']}</th><td><input type="text" class="input form-control w80" name="cid" value="{$_GET['cid']}">
							</td>
							<th>{$Fn_Live->Config['LangVar']['KeywordTitle']}</th><td><input type="text" class="input form-control w200" name="keyword" value="{$_GET['keyword']}">
							</td>
							<th>{$Fn_Live->Config['LangVar']['StateTitle']}</th><td>
							<select name="state" class="form-control w120">
								<option value="">{$Fn_Live->Config['LangVar']['SelectNull']}</option>
								<option value="0"{$StateSelected['0']}>{$Fn_Live->Config['LangVar']['PedpacketStateArray']['0']}</option>
								<option value="1"{$StateSelected['1']}>{$Fn_Live->Config['LangVar']['PedpacketStateArray']['1']}</option>
							</select>
							&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Admin->Config['LangVar']['SearchSubmit']}" class="btn btn-info" type="submit">
							</td>
						</tr>
					</table>
				</div>
			</form>
SEARCH;
			/* ���� End */
			showtagheader('div', 'table-responsive', true,'table-responsive');
			showformheader($FormUrl,'enctype="multipart/form-data"');
			showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');

			showsubtitle(array(
				'ID',
				'UID/'.$Fn_Live->Config['LangVar']['UserNameTitle'],
				$Fn_Live->Config['LangVar']['Title'],
				$Fn_Live->Config['LangVar']['Money'],
				$Fn_Live->Config['LangVar']['StateTitle'],
				$Fn_Live->Config['LangVar']['TimeTitle'],
				$Fn_Live->Config['LangVar']['OperationTitle']
			),'header tbm tc');

			$ModulesList = GetModulesList($Page,$Limit,$Where,$Order);
			foreach ($ModulesList as $Module) {
				
				showtablerow('', array('class="tc w80"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
					'<input type="checkbox" class="filled-in" id="checkbox_'.$Module['id'].'" name="delete[]" value="'.$Module['id'].'"><label for="checkbox_'.$Module['id'].'">'.$Module['id'].'</label>',
					$Module['uid'] ? $Module['uid'].'/'.$Module['username'] : '',
					'&nbsp;&nbsp;<a href="'.$Fn_Live->Config['ViewUrl'].$Module['id'].'" target="_blank">'.$Module['title'].'</a>',
					$Module['money'],
					!$Module['state'] ? '<span class="label bg-secondary">'.$Fn_Live->Config['LangVar']['PedpacketStateArray']['0'].'</span>' : '<span class="label bg-danger">'.$Fn_Live->Config['LangVar']['PedpacketStateArray']['1'].'</span>',
					date('Y-m-d H:i',$Module['dateline']),
					'<a href="'.$OpCpUrl.'&do=State&pid='.$Module['id'].'&value='.(!empty($Module['state']) ? 0:1).'&formhash='.FORMHASH.'" class="btn btn-sm btn-info-outline">'.(!empty($Module['state']) ? $Fn_Live->Config['LangVar']['PedpacketSetUpStateArray']['0'] : $Fn_Live->Config['LangVar']['PedpacketSetUpStateArray']['1']).'</a>&nbsp;&nbsp<a href="'.$OpCpUrl.'&do=Del&pid='.$Module['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$Fn_Live->Config['LangVar']['DelTitle'].'</a>',
				));
			}

			showsubmit('Submit','&#31435;&#21363;&#25552;&#20132;','<input name="optype" value="Del" class="with-gap" type="radio" id="v_del"><label class="custom-control-label" for="v_del" style="margin-left:-5px;">'.$Fn_Live->Config['LangVar']['DelTitle'].'</label>&nbsp;&nbsp;<input name="optype" value="FBH" class="with-gap" type="radio" id="v_FBH"><label class="custom-control-label" for="v_FBH">'.$Fn_Live->Config['LangVar']['FFWLQHB'].'</label>','','select_all',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));

			showtablefooter(); /*dism��taobao��com*/
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			/* ģ�����End */	
		}else{
			if(isset($_GET['delete']) && is_array($_GET['delete'])){
				if($_GET['optype'] == 'Del'){//ȫɾ
					if(!$Fn_Admin->CheckUserGroup('live_all') && !$Fn_Admin->CheckUserGroup('live_del_redpacket_log')){//Ȩ���ж�
						fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
						exit();
					}
					foreach($_GET['delete'] as $Key => $Val) {
						$Val = intval($Val);
						$Item = DB::fetch_first('SELECT * FROM '.DB::table($Fn_Live->TableRedpacketLog).' where id = '.$Val);
						DB::delete($Fn_Live->TableRedpacketLog,'id ='.$Val);
						DB::delete($Fn_Live->TableComment,'id ='.$Item['father_cid']);
					}
					GetInsertDoLog('del_redpacket_log_live','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete'])));//������¼
					fn_cpmsg($Fn_Live->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');

				}else if($_GET['optype'] == 'FBH'){
					$I = 0;
					foreach($_GET['delete'] as $Key => $Val) {
						$Val = intval($Val);
						$Item = DB::fetch_first('SELECT * FROM '.DB::table($Fn_Live->TableRedpacketLog).' where id = '.$Val.' and state = 0');
						if($Item){
							$HBState = false;
							if($Config['PluginVar']['AppType'] == 2){//ǧ�������
								$ReturnBalance = $Fn_Live->QHApp->GetBalanceAdd($Item['uid'],$Item['money']);
								if($ReturnBalance['state'] == 200){
									$HBState = true;
								}
							}else if($Config['PluginVar']['AppType'] == 1){//���׷����
								$ReturnBalance = $Fn_Live->MagApp->GetMagAccountTransfer($Item['uid'],$Item['money']);
								if($ReturnBalance['state'] == 200){
									$HBState = true;
								}
							}else{//����Ǯ��
								if(FnWallet::WalletLogInsertBy($Item['uid'],$Fn_Live->Config['LangVar']['WalletContent'],$Item['money'],1,'fn_live')){
									$HBState = true;
								}
							}
							if($HBState && DB::update($Fn_Live->TableRedpacketLog,array('state'=>1),'id='.$Val)){
								$I++;
							}
						}
					}
					cpmsg(str_replace('{Num}',$I,$Fn_Live->Config['LangVar']['HandleHBOk']),$CpMsgUrl,'succeed');
				}
			}else{
				fn_cpmsg($Fn_Live->Config['LangVar']['OpErr'],'','error');
			}
				
		}
	}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['pid']){
		if(!$Fn_Admin->CheckUserGroup('live_all') && !$Fn_Admin->CheckUserGroup('live_del_redpacket_log')){//Ȩ���ж�
			fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
			exit();
		}
		$Id = intval($_GET['pid']);
		$Item = DB::fetch_first('SELECT * FROM '.DB::table($Fn_Live->TableRedpacketLog).' where id = '.$Id);
		DB::delete($Fn_Live->TableRedpacketLog,'id ='.$Id);
		DB::delete($Fn_Live->TableComment,'id ='.$Item['father_cid']);
		GetInsertDoLog('del_redpacket_log_live','fn_'.$_GET['mod'],array('id'=>$Id));//������¼
		fn_cpmsg($Fn_Admin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
	}else if($Do == 'State' && $_GET['formhash'] == formhash() && $_GET['pid']){
		if(!$Fn_Admin->CheckUserGroup('live_all') && !$Fn_Admin->CheckUserGroup('live_state_redpacket_log')){//Ȩ���ж�
			fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
			exit();
		}
		$Id = intval($_GET['pid']);
		$UpData['state'] = intval($_GET['value']);
		DB::update($Fn_Live->TableRedpacketLog,$UpData,'id = '.$Id);
		GetInsertDoLog('state_redpacket_log_live','fn_'.$_GET['mod'],array('id'=>$_GET['lid'],'state'=>$_GET['value']));//������¼
		fn_cpmsg($Fn_Live->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

	}
}


/* �б� */
function GetModulesList($Page,$Limit,$Where=null,$Order){
	global $Fn_Live;
	$FetchSql = 'SELECT LL.title,L.* FROM '.DB::table($Fn_Live->TableRedpacketLog).' L LEFT JOIN `'.DB::table($Fn_Live->TableLive).'` LL on LL.id = L.lid '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}

/* ���� */
function GetModulesCount($Where=null){
	global $Fn_Live;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_Live->TableRedpacketLog).' L '.$Where;
	return DB::result_first($FetchSql);//��������
}

?>