<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('live_all') && !$Fn_Admin->CheckUserGroup('live_participant_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$SubModel = in_array($_GET['submodel'], array('list','add')) ? $_GET['submodel'] : 'list';
$Fn_Admin->Config['IframeSubModelUrl'] = $Fn_Admin->Config['IframeItemUrl'].'&submodel='.$SubModel;
$NavClass = array($SubModel=>'btn-info Hover');

//����
echo <<<Nav
<div class="SubModelNav">
  <ul>
	<li class="{$NavClass['list']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=list" target="_self">{$Fn_Admin->Config['LangVar']['LiveLeftNavArray'][$_GET['item']]}</a></li>
    <li class="{$NavClass['add']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=add&lid={$_GET[lid]}" target="_self">{$Fn_Admin->Config['LangVar']['AddEditTitle']}</a></li>
  </ul>
  <div class="both"></div>
</div>
Nav;

if($SubModel == 'list'){//�б�
	$Do = in_array($_GET['do'], array('Refresh','Del','Display')) ? $_GET['do'] : 'submodel_list';
	//�����ֶ�
	$SearField =array('page','keyword','display','order','lid');
	foreach($SearField as $Val) {
		$SearArray[$Val] = $_GET[$Val] || in_array($_GET[$Val],array('0')) ? $_GET[$Val] : '';
	}
	//�����ֶ� End
	$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeSubModelUrl'].'&'.http_build_query($SearArray);


	if($Do == 'submodel_list'){
		if(!submitcheck('Submit')) {
			$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
			$Where = '';
			$Order = $_GET['order'] ? 'P.'.addslashes(dhtmlspecialchars($_GET['order'])) : 'P.id';
			
			if($_GET['keyword']){
				$_GET['keyword'] = str_replace(array('%','_'),array('',''),$_GET['keyword']);
				$Where .= ' and (P.mobile like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or P.name like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or P.username like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or P.uid = '.intval($_GET['keyword']).' or P.id = '.intval($_GET['keyword']).' or P.number = '.intval($_GET['keyword']).' )';
			}

			if($_GET['lid']){
				$Where .= ' and P.lid = '.intval($_GET['lid']);
			}

			if(in_array($_GET['display'],array('0','1'))){
				$Where .= ' and P.display = '.intval($_GET['display']);
			}

			$Where = preg_replace('/and/','where',$Where,1);
			$Limit = 20;
			$Page = $_GET['page']?intval($_GET['page']):1;
			/* ��ѯ���� End */
			

			/* ģ����� */	
			showtagheader('div', 'row', true,'row');
			showtagheader('div', 'col-12', true,'col-12');
			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-body', true,'box-body');
			/* ���� */
			$DisplaySelected = array($_GET['display']=>' selected');
			$OrderSelected = array($_GET['order']=>' selected');
			echo <<<SEARCH
			<form method="post" autocomplete="off" action="$SearUrl">
				<div class="FormSearchTo" style="margin-bottom:0;">
					<table cellspacing="4" cellpadding="4">
						<tr>
							<th>{$Fn_Live->Config['LangVar']['LiveId']}</th><td><input type="text" class="input form-control w80" name="lid" value="{$_GET['lid']}">
							</td>
							<th>{$Fn_Live->Config['LangVar']['KeywordTitle']}</th><td><input type="text" class="input form-control w200" name="keyword" value="{$_GET['keyword']}">
							</td>
							<th>{$Fn_Live->Config['LangVar']['DisplayTitle']}</th><td>
							<select name="display" class="form-control w120">
								<option value="">{$Fn_Live->Config['LangVar']['SelectNull']}</option>
								<option value="1"{$DisplaySelected['1']}>{$Fn_Live->Config['LangVar']['Yes']}</option>
								<option value="0"{$DisplaySelected['0']}>{$Fn_Live->Config['LangVar']['No']}</option>
							</select>
							&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Admin->Config['LangVar']['SearchSubmit']}" class="btn btn-info" type="submit">
							</td>
						</tr>
					</table>
				</div>
			</form>
SEARCH;
			/* ���� End */
			showtagheader('div', 'table-responsive', true,'table-responsive');
			showformheader($FormUrl,'enctype="multipart/form-data"');
			showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');

			showsubtitle(array(
				'ID',
				'UID/'.$Fn_Live->Config['LangVar']['UserNameTitle'],
				$Fn_Live->Config['LangVar']['Title'],
				$Fn_Live->Config['LangVar']['Name'],
				$Fn_Live->Config['LangVar']['NumberId'],
				$Fn_Live->Config['LangVar']['Mobile'],
				$Fn_Live->Config['LangVar']['Thumbnail'],
				$Fn_Live->Config['LangVar']['DisplayTitle'],
				$Fn_Live->Config['LangVar']['TimeTitle'],
				$Fn_Live->Config['LangVar']['OperationTitle']
			),'header tbm tc');

			$ModulesList = GetModulesList($Page,$Limit,$Where,$Order);
			foreach ($ModulesList as $Module) {
				
				showtablerow('', array('class="tc w50"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
					'<input type="checkbox" class="filled-in" id="checkbox_'.$Module['id'].'" name="delete[]" value="'.$Module['id'].'"><label for="checkbox_'.$Module['id'].'">'.$Module['id'].'</label>',
					$Module['uid'] ? $Module['uid'].'/'.$Module['username'] : '',
					'&nbsp;&nbsp;<a href="'.$Fn_Live->Config['ViewUrl'].$Module['lid'].'" target="_blank">'.$Module['title'].'</a>',
					$Module['name'],
					$Module['number'],
					$Module['mobile'],
					$Module['thumbnail'] ? '<img src="'.$Module['thumbnail'].'" style="height:40px;">' : '',
					!$Module['display'] ? '<span class="label bg-secondary">'.$Fn_Live->Config['LangVar']['No'].'</span>' : '<span class="label bg-danger">'.$Fn_Live->Config['LangVar']['Yes'].'</span>',
					date('Y-m-d H:i',$Module['dateline']),
					'<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&pid='.$Module['id'].'" class="btn btn-sm btn-info-outline">'.$Fn_Live->Config['LangVar']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Display&pid='.$Module['id'].'&value='.(!empty($Module['display']) ? 0:1).'&formhash='.FORMHASH.'" class="btn btn-sm btn-purple-outline">'.(!empty($Module['display']) ? $Fn_Live->Config['LangVar']['DisplayNoTitle'] : $Fn_Live->Config['LangVar']['DisplayIsTitle']).'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Del&pid='.$Module['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$Fn_Live->Config['LangVar']['DelTitle'].'</a>',
				));
			}
			showsubmit('Submit','&#31435;&#21363;&#25552;&#20132;','del','','',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));
			showtablefooter(); /*dism��taobao��com*/
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			/* ģ�����End */	
		}else{
			if(!$Fn_Admin->CheckUserGroup('live_all') && !$Fn_Admin->CheckUserGroup('live_participant_list')){//Ȩ���ж�
				fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
				exit();
			}

			if(isset($_GET['delete']) && is_array($_GET['delete'])){
				foreach($_GET['delete'] as $Key => $Val) {
					$Val = intval($Val);
					foreach(DB::fetch_all('SELECT * FROM '.DB::table($Fn_Live->TableGiftLog).' where be_reward_id = '.$Val.' order by dateline desc') as $K => $V) {
						DB::delete($Fn_Live->TableComment,'id ='.$V['father_cid']);
						DB::delete($Fn_Live->TableGiftLog,'id ='.$V['id']);
					}
					DB::delete($Fn_Live->TableParticipant,'id ='.$Val);
				}

				GetInsertDoLog('del_participant_live','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete'])));//������¼

				fn_cpmsg($Fn_Live->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
			}else{
				fn_cpmsg($Fn_Live->Config['LangVar']['DelErr'],'','error');
			}
				
		}
	}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['pid']){
		if(!$Fn_Admin->CheckUserGroup('live_all') && !$Fn_Admin->CheckUserGroup('live_participant_list')){//Ȩ���ж�
			fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
			exit();
		}
		$Id = intval($_GET['pid']);
		foreach(DB::fetch_all('SELECT * FROM '.DB::table($Fn_Live->TableGiftLog).' where be_reward_id = '.$Id.' order by dateline desc') as $Key => $Val) {
			DB::delete($Fn_Live->TableComment,'id ='.$Val['father_cid']);
			DB::delete($Fn_Live->TableGiftLog,'id ='.$Val['id']);
		}
		DB::delete($Fn_Live->TableParticipant,'id ='.$Id);

		GetInsertDoLog('del_participant_live','fn_'.$_GET['mod'],array('id'=>$Id));//������¼
		fn_cpmsg($Fn_Admin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
	}else if($Do == 'Display' && $_GET['formhash'] == formhash() && $_GET['pid']){
		$Id = intval($_GET['pid']);
		$UpData['display'] = intval($_GET['value']);
		DB::update($Fn_Live->TableParticipant,$UpData,'id = '.$Id);
		GetInsertDoLog('display_participant_live','fn_'.$_GET['mod'],array('id'=>$_GET['pid'],'display'=>$_GET['value']));//������¼
		fn_cpmsg($Fn_Live->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

	}
}else if($SubModel == 'add'){//���ӻ�༭
	if(!$Fn_Admin->CheckUserGroup('live_all') && !$Fn_Admin->CheckUserGroup('live_add_comment')){//Ȩ���ж�
		fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
		exit();
	}
	$Id = intval($_GET['pid']);

	$Item = DB::fetch_first('SELECT * FROM '.DB::table($Fn_Live->TableParticipant).' where id = '.$Id);

	if(!submitcheck('DetailSubmit')) {
		$OpTitle = $Fn_Live->Config['LangVar']['AddTitle'];
		if($Item){
			$Item['param'] = unserialize($Item['param']);
			$OpTitle = $Fn_Live->Config['LangVar']['EditTitle'];
		}
		
		//ͼƬ�ϴ�
		if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_assembly/class/class_upload.php')){
			@require_once libfile('class/upload','plugin/fn_assembly');
			$UploadConfig = fn_upload::Config();
		}

		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-header', true,'with-border box-header');
		showtitle($OpTitle,'class="box-title"');
		showtagfooter('div');
		showformheader($Fn_Admin->Config['IframeSubModelUrl'].'&pid='.$Id,'enctype');
		showtagheader('div', 'box-body', true,'box-body');

		showsetting($Fn_Live->Config['LangVar']['LiveId'], 'lid', $Item['lid'] ? $Item['lid'] : $_GET['lid'], 'text');
		showsetting('UID', 'new_uid', $Item['uid'], 'text');
		showsetting($Fn_Live->Config['LangVar']['Name'], 'name', $Item['name'], 'text');
		showsetting($Fn_Live->Config['LangVar']['NumberId'], 'number', $Item['number'], 'text');
		showsetting($Fn_Live->Config['LangVar']['Mobile'], 'mobile', $Item['mobile'], 'text');
		
		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_Live->Config['LangVar']['Thumbnail'].':</label><div class="col-sm-9"><div class="AdminSingleUpload"><div class="PhotoControl" id="ImagesPhotoControl"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';

		//��������
		
		if($Item['updateline']){
			showsetting($Fn_Live->Config['LangVar']['RefreshTime'], 'updateline',$Item['updateline'] ? date('Y-m-d H:i',$Item['updateline']) : '', 'calendar','','','',1);
		}

		if($Item['dateline']){
			showsetting($Fn_Live->Config['LangVar']['TimeTitle'], 'dateline',date('Y-m-d H:i',$Item['dateline']), 'calendar','','','',1);
		}

		showsetting($Fn_Live->Config['LangVar']['DisplayTitle'], 'display', $Item ? $Item['display'] : 1, 'radio');
		
		showsubmit('DetailSubmit','&#20445;&#23384;&#37197;&#32622;');
		showtagfooter('div');
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');
		
		$UpLoadHtml  = '';
		if($Item['thumbnail']){
			$ThumbJsArray[] = '"'.$Item['thumbnail'].'"';;
			$UpLoadHtml .= '
			var InputArray = new Array('.implode(',',$ThumbJsArray).');
			$("#ImagesPhotoControl").AppUpload({InputName:"new_images",InputExist:true,Multiple:true,InputArray:InputArray});';

		}else{
			$UpLoadHtml .= '$("#ImagesPhotoControl").AppUpload({InputName:"new_images",Multiple:true});';
		}
		
		echo $UploadConfig['CssJsHtml'].'<script>'.$UpLoadHtml.'</script>';

	}else{
		
		foreach($_GET['new_images'] as $Key => $Val) {
			$_GET['new_images'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}
		$LiveItem = $Fn_Live->GetViewthread($_GET['lid']);

		$Data['lid'] = intval($_GET['lid']);
		$Data['uid'] = intval($_GET['new_uid']);
		$Member = DB::fetch_first('SELECT username FROM '.DB::table('common_member').' where uid = '.$Data['uid']);
		$Data['username'] = $_GET['username'] ? addslashes(strip_tags($_GET['username'])) : addslashes(strip_tags($Member['username']));
		$Data['name'] = addslashes(strip_tags($_GET['name']));
		$Data['number'] = addslashes(strip_tags($_GET['number']));
		$Data['mobile'] = addslashes(strip_tags($_GET['mobile']));
		$Data['display'] = intval($_GET['display']);
		$Data['thumbnail'] = is_array($_GET['new_images']) && isset($_GET['new_images']) ? $_GET['new_images'][0] : '';

		if($Item){
			$Data['updateline'] = strtotime($_GET['updateline']);
			GetInsertDoLog('edit_participant_live','fn_'.$_GET['mod'],array('id'=>$Id));//������¼
			DB::update($Fn_Live->TableParticipant,$Data,'id = '.$Id);
		}else{
			$Data['dateline'] = $Data['updateline'] = time();
			$Id = DB::insert($Fn_Live->TableParticipant,$Data,true);
			GetInsertDoLog('add_participant_live','fn_'.$_GET['mod'],array('id'=>$Id));//������¼
		}
		fn_cpmsg($Fn_Live->Config['LangVar']['UpdateOk'],$Fn_Admin->Config['IframeItemUrl'].'&submodel=list&lid='.$_GET['lid'],'succeed');
	
	}
}


/* �б� */
function GetModulesList($Page,$Limit,$Where=null,$Order){
	global $Fn_Live;
	$FetchSql = 'SELECT L.title,P.* FROM '.DB::table($Fn_Live->TableParticipant).' P LEFT JOIN `'.DB::table($Fn_Live->TableLive).'` L on L.id = P.lid '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}

/* ���� */
function GetModulesCount($Where=null){
	global $Fn_Live;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_Live->TableParticipant).' P '.$Where;
	return DB::result_first($FetchSql);//��������
}

?>