<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('live_all') && !$Fn_Admin->CheckUserGroup('live_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$SubModel = in_array($_GET['submodel'], array('list','add')) ? $_GET['submodel'] : 'list';
$Fn_Admin->Config['IframeSubModelUrl'] = $Fn_Admin->Config['IframeItemUrl'].'&submodel='.$SubModel;
$NavClass = array($SubModel=>'btn-info Hover');

//����
echo <<<Nav
<div class="SubModelNav">
  <ul>
	<li class="{$NavClass['list']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=list" target="_self">{$Fn_Admin->Config['LangVar']['LiveLeftNavArray'][$_GET['item']]}</a></li>
    <li class="{$NavClass['add']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=add" target="_self">{$Fn_Admin->Config['LangVar']['AddEditTitle']}</a></li>
  </ul>
  <div class="both"></div>
</div>
Nav;

if($SubModel == 'list'){//�б�
	$Do = in_array($_GET['do'], array('Refresh','Del','Display')) ? $_GET['do'] : 'submodel_list';
	//�����ֶ�
	$SearField =array('page','keyword','display','order','number_id');
	foreach($SearField as $Val) {
		$SearArray[$Val] = $_GET[$Val] || in_array($_GET[$Val],array('0')) ? $_GET[$Val] : '';
	}
	//�����ֶ� End
	$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeSubModelUrl'].'&'.http_build_query($SearArray);


	if($Do == 'submodel_list'){
		if(!submitcheck('Submit')) {
			$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
			$Where = '';
			$Order = $_GET['order'] ? 'L.'.addslashes(dhtmlspecialchars($_GET['order'])) : 'L.id';
			
			if($_GET['keyword']){
				$_GET['keyword'] = str_replace(array('%','_'),array('',''),$_GET['keyword']);
				$Where .= ' and (L.title like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or L.content like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\')  or L.id = '.intval($_GET['keyword']).' )';
			}

			if($_GET['number_id']){
				$Where .= ' and L.number_id = '.intval($_GET['number_id']);
			}
		
			if(in_array($_GET['display'],array('0','1'))){
				$Where .= ' and L.display = '.intval($_GET['display']);
			}

			$Where = preg_replace('/and/','where',$Where,1);
			$Limit = 30;
			$Page = $_GET['page']?intval($_GET['page']):1;
			/* ��ѯ���� End */
			
			/* ģ����� */	
			showtagheader('div', 'row', true,'row');
			showtagheader('div', 'col-12', true,'col-12');
			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-body', true,'box-body');
			/* ���� */
			$DisplaySelected = array($_GET['display']=>' selected');
			$OrderSelected = array($_GET['order']=>' selected');

			$NumberListOption = '<option value="">'.$Fn_Live->Config['LangVar']['SelectNull'].'</option>';
			foreach(DB::fetch_all('SELECT * FROM '.DB::table($Fn_Live->TableNumber).' order by dateline desc') as $Val) {
				$NumberListOption .= '<option value="'.$Val['id'].'" '.($_GET['number_id'] == $Val['id'] ? ' selected' : '' ).'>'.$Val['title'].'</option>';
			}

			echo <<<SEARCH
			<form method="post" autocomplete="off" action="$SearUrl">
				<div class="FormSearchTo" style="margin-bottom:0;">
					<table cellspacing="4" cellpadding="4">
						<tr>
							<th>{$Fn_Live->Config['LangVar']['KeywordTitle']}</th><td><input type="text" class="input form-control w200" name="keyword" value="{$_GET['keyword']}">
							</td>
							<th>{$Fn_Live->Config['LangVar']['Number']}</th><td>
							<select name="number_id" class="form-control w120">
								{$NumberListOption}
							</select>
							</td>
							<th>{$Fn_Live->Config['LangVar']['DisplayTitle']}</th><td>
							<select name="display" class="form-control w120">
								<option value="">{$Fn_Live->Config['LangVar']['SelectNull']}</option>
								<option value="1"{$DisplaySelected['1']}>{$Fn_Live->Config['LangVar']['Yes']}</option>
								<option value="0"{$DisplaySelected['0']}>{$Fn_Live->Config['LangVar']['No']}</option>
							</select>
							</td>
							<th>{$Fn_Admin->Config['LangVar']['Order']}</th><td>
							<select name="order" class="form-control w120">
								<option value="dateline"{$OrderSelected['dateline']}>{$Fn_Admin->Config['LangVar']['OrderArray']['dateline']}</option>
								<option value="updateline"{$OrderSelected['updateline']}>{$Fn_Admin->Config['LangVar']['OrderArray']['updateline']}</option>
								<option value="click"{$OrderSelected['click']}>{$Fn_Admin->Config['LangVar']['OrderArray']['click']}</option>
							</select>
							&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Admin->Config['LangVar']['SearchSubmit']}" class="btn btn-info" type="submit">
							</td>
						</tr>
					</table>
				</div>
			</form>
SEARCH;
			/* ���� End */
			showtagheader('div', 'table-responsive', true,'table-responsive');
			showformheader($FormUrl,'enctype="multipart/form-data"');
			showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
			showsubtitle(array(
				'ID',
				$Fn_Live->Config['LangVar']['Title'],
				$Fn_Live->Config['LangVar']['Number'],
				$Fn_Live->Config['LangVar']['StartDateline'],
				//$Fn_Live->Config['LangVar']['EndDateline'],
				//$Fn_Live->Config['LangVar']['StateTitle'],
				$Fn_Live->Config['LangVar']['CommentConut'],
				$Fn_Live->Config['LangVar']['InfoConut'],
				$Fn_Live->Config['LangVar']['DisplayTitle'],
				$Fn_Live->Config['LangVar']['RefreshTime'],
				$Fn_Live->Config['LangVar']['TimeTitle'],
				$Fn_Live->Config['LangVar']['OperationTitle']
			),'header tbm tc');

			$ModulesList = GetModulesList($Page,$Limit,$Where,$Order);
			foreach ($ModulesList as $Module) {
				$CommentConut = DB::result_first('SELECT COUNT(*) FROM '.DB::table($Fn_Live->TableComment).' where lid = '.$Module['id']);
				$InfoConut = DB::result_first('SELECT COUNT(*) FROM '.DB::table($Fn_Live->TableInfo).' where lid = '.$Module['id']);

				showtablerow('', array('class="tc w50"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
					'<input type="checkbox" class="filled-in" id="checkbox_'.$Module['id'].'" name="delete[]" value="'.$Module['id'].'"><label for="checkbox_'.$Module['id'].'">'.$Module['id'].'</label>',
					$Module['title'],
					$Module['number_title'],
					$Module['start_dateline'] ? date('Y-m-d H:i',$Module['start_dateline']) : '',
					//$Module['end_dateline'] ? date('Y-m-d H:i',$Module['end_dateline']) : '',
					//$Fn_Live->Config['LangVar']['LiveStateArray'][$Module['state']],
					$CommentConut,
					$InfoConut,
					!$Module['display'] ? '<span class="label bg-secondary">'.$Fn_Live->Config['LangVar']['No'].'</span>' : '<span class="label bg-danger">'.$Fn_Live->Config['LangVar']['Yes'].'</span>',
					date('Y-m-d H:i',$Module['updateline']),
					date('Y-m-d H:i',$Module['dateline']),
					'<a href="'.$Fn_Live->Config['ViewUrl'].$Module['id'].'" target="_blank">'.cplang('view').'</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&lid='.$Module['id'].'">'.$Fn_Live->Config['LangVar']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&lid='.$Module['id'].'&copy=true">&#22797;&#21046;</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Refresh&lid='.$Module['id'].'&formhash='.FORMHASH.'">'.$Fn_Live->Config['LangVar']['Refresh'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Display&lid='.$Module['id'].'&value='.(!empty($Module['display']) ? 0:1).'&formhash='.FORMHASH.'">'.(!empty($Module['display']) ? $Fn_Live->Config['LangVar']['DisplayNoTitle'] : $Fn_Live->Config['LangVar']['DisplayIsTitle']).'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Del&lid='.$Module['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;">'.$Fn_Live->Config['LangVar']['DelTitle'].'</a><br><a href="'.$Fn_Admin->Config['ModUrl'].'&item=comment_list&submodel=list&iframe=true&lid='.$Module['id'].'">'.$Fn_Live->Config['LangVar']['CommentOp'].'</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['ModUrl'].'&item=info_list&submodel=list&iframe=true&lid='.$Module['id'].'">'.$Fn_Live->Config['LangVar']['InfoOp'].'</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['ModUrl'].'&item=gift_log_list&submodel=list&iframe=true&lid='.$Module['id'].'">'.$Fn_Live->Config['LangVar']['GivingGiftLog'].'</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['ModUrl'].'&item=invite_log_list&submodel=list&iframe=true&lid='.$Module['id'].'">'.$Fn_Live->Config['LangVar']['InviteLog'].'</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['ModUrl'].'&item=visit_log_list&submodel=list&iframe=true&lid='.$Module['id'].'">'.$Fn_Live->Config['LangVar']['VisitLog'].'</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['ModUrl'].'&item=live_pay_log_list&submodel=list&iframe=true&lid='.$Module['id'].'">'.$Fn_Live->Config['LangVar']['PayLog'].'</a>',
				));
			}
			showsubmit('Submit','&#31435;&#21363;&#25552;&#20132;','del','','',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));
			showtablefooter(); /*dism��taobao��com*/
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			/* ģ�����End */	
		}else{
			if(!$Fn_Admin->CheckUserGroup('live_all') && !$Fn_Admin->CheckUserGroup('live_del')){//Ȩ���ж�
				fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
				exit();
			}

			if(isset($_GET['delete']) && is_array($_GET['delete'])){
				foreach($_GET['delete'] as $Key => $Val) {
					$Val = intval($Val);
					DB::delete($Fn_Live->TableLive,'id ='.$Val);
					DB::delete($Fn_Live->TableComment,'lid ='.$Val);
					DB::delete($Fn_Live->TableLivePayLog,'lid ='.$Val);
					DB::delete($Fn_Live->TableRedpacketLog,'lid ='.$Val);
					DB::delete($Fn_Live->TableParticipant,'lid ='.$Val);
				}

				GetInsertDoLog('del_live','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete'])));//������¼

				fn_cpmsg($Fn_Live->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
			}else{
				fn_cpmsg($Fn_Live->Config['LangVar']['DelErr'],'','error');
			}
				
		}
	}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['lid']){
		if(!$Fn_Admin->CheckUserGroup('live_all') && !$Fn_Admin->CheckUserGroup('live_del')){//Ȩ���ж�
			fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
			exit();
		}
		$Id = intval($_GET['lid']);
		DB::delete($Fn_Live->TableLive,'id ='.$Id);
		DB::delete($Fn_Live->TableComment,'lid ='.$Id);
		DB::delete($Fn_Live->TableLivePayLog,'lid ='.$Id);
		DB::delete($Fn_Live->TableRedpacketLog,'lid ='.$Id);
		DB::delete($Fn_Live->TableParticipant,'lid ='.$Id);
		GetInsertDoLog('del_live','fn_'.$_GET['mod'],array('id'=>$Id));//������¼
		fn_cpmsg($Fn_Admin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
	}else if($Do == 'Refresh' && $_GET['formhash'] == formhash() && $_GET['lid']){
		$Id = intval($_GET['lid']);
		$UpData['updateline'] = time();
		DB::update($Fn_Live->TableLive,$UpData,'id = '.$Id);
		GetInsertDoLog('refresh_live','fn_'.$_GET['mod'],array('id'=>$_GET['lid']));//������¼
		fn_cpmsg($Fn_Live->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

	}else if($Do == 'Display' && $_GET['formhash'] == formhash() && $_GET['lid']){
		$Id = intval($_GET['lid']);
		$UpData['display'] = intval($_GET['value']);
		DB::update($Fn_Live->TableLive,$UpData,'id = '.$Id);
		GetInsertDoLog('display_live','fn_'.$_GET['mod'],array('id'=>$_GET['lid'],'display'=>$_GET['value']));//������¼
		fn_cpmsg($Fn_Live->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

	}
}else if($SubModel == 'add'){//���ӻ�༭
	if(!$Fn_Admin->CheckUserGroup('live_all') && !$Fn_Admin->CheckUserGroup('live_add')){//Ȩ���ж�
		fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
		exit();
	}
	$Id = intval($_GET['lid']);

	$Item = DB::fetch_first('SELECT * FROM '.DB::table($Fn_Live->TableLive).' where id = '.$Id);
	if($Item){
		$Item['param'] = unserialize($Item['param']);
	};
	if(!submitcheck('DetailSubmit')) {
		$OpTitle = $Fn_Live->Config['LangVar']['AddTitle'];
		if($Item){
			$OpTitle = $Fn_Live->Config['LangVar']['EditTitle'];
		}

		//ͼƬ�ϴ�
		if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_assembly/class/class_upload.php')){
			@require_once libfile('class/upload','plugin/fn_assembly');
			$UploadConfig = fn_upload::Config();
		}
		
		echo '<script src="'.$Config['StaticPath'].'/ueditor/'.CHARSET.'/ueditor.config.js" type="text/javascript"></script><script src="'.$Config['StaticPath'].'/ueditor/'.CHARSET.'/ueditor.all.js" type="text/javascript"></script>';

		showtagheader('div', 'box', true,'box');
		showformheader($Fn_Admin->Config['IframeSubModelUrl'].'&lid='.$Id.'&copy='.$_GET['copy'],'enctype');
		if(in_array($Config['PluginVar']['AppType'],array('1','2','3'))){
			$AppNav = '<li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#app" role="tab" aria-expanded="false"><span class="hidden-sm-up"><i class="ion-email"></i></span> <span class="hidden-xs-down">&#65;&#80;&#80;&#35774;&#32622;</span></a> </li>';
		}
		echo <<<HTML
		<ul class="nav nav-tabs customtab" role="tablist">
          <li class="nav-item"> <a class="nav-link active" data-toggle="tab" href="#basics" role="tab" aria-expanded="true"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#22522;&#30784;&#35774;&#32622;</span></a> </li>
		  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#gift" role="tab" aria-expanded="false"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#31036;&#29289;&#35774;&#32622;</span></a> </li>
		  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#package" role="tab" aria-expanded="false"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#21457;&#32418;&#21253;&#35774;&#32622;</span></a> </li>
		  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#player" role="tab" aria-expanded="false"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#25773;&#25918;&#22120;&#35774;&#32622;</span></a> </li>
		  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#comment" role="tab" aria-expanded="false"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#35780;&#35770;&#35774;&#32622;</span></a> </li>
		  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#info" role="tab" aria-expanded="false"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#22270;&#25991;&#30452;&#25773;&#35774;&#32622;</span></a> </li>
		  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#ranking" role="tab" aria-expanded="false"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#25490;&#34892;&#27036;&#35774;&#32622;</span></a> </li>
		  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#reward" role="tab" aria-expanded="false"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#25171;&#36175;&#36873;&#25163;&#35774;&#32622;</span></a> </li>
		  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#poster" role="tab" aria-expanded="false"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#28023;&#25253;&#35774;&#32622;</span></a> </li>
		  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#ad" role="tab" aria-expanded="false"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#24191;&#21578;&#35774;&#32622;</span></a> </li>
		  {$AppNav}
		  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#share" role="tab" aria-expanded="false"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#20998;&#20139;&#35774;&#32622;</span></a> </li>
		  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#other" role="tab" aria-expanded="false"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#20854;&#20182;&#35774;&#32622;</span></a> </li>
		  
        </ul>
HTML;
		showtagheader('div', 'box-body', true,'box-body');
		showtagheader('div', 'tab-content', true,'tab-content');
		
		echo <<<HTML
		<!-- ��������  -->
		<div class="tab-pane active" id="basics" role="tabpanel" aria-expanded="true">
HTML;

		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_Live->Config['LangVar']['Thumb'].'<br>'.$Fn_Live->Config['LangVar']['ThumbTips'].'</label><div class="col-sm-9"><div class="AdminSingleUpload"><div class="PhotoControl" id="ThumbPhotoControl"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';

		showsetting($Fn_Live->Config['LangVar']['Title'], 'title', $Item['title'], 'text');

		showsetting($Fn_Live->Config['LangVar']['Describe'], 'content', $Item['content'], 'textarea');

		$NumberList = array();
		foreach(DB::fetch_all('SELECT * FROM '.DB::table($Fn_Live->TableNumber).' order by dateline desc') as $Val) {
			$NumberList[] = array($Val['id'], $Val['title']);
		}
		showsetting($Fn_Live->Config['LangVar']['Number'], array('number_id', $NumberList),$Item['number_id'], 'select');
		showsetting('&#36339;&#36716;&#38142;&#25509;', 'jump_url', $Item['param']['jump_url'], 'text','','','&#35774;&#32622;&#21518;&#65292;&#20840;&#37096;&#35774;&#32622;&#26080;&#25928;&#65292;&#30452;&#25773;&#39029;&#38754;&#20250;&#30452;&#25509;&#36339;&#36716;&#35813;&#38142;&#25509;');
		showsetting($Fn_Live->Config['LangVar']['StartDateline'], 'start_dateline',$Item['start_dateline'] ? date('Y-m-d H:i',$Item['start_dateline']) : '', 'calendar','','',$Fn_Live->Config['LangVar']['StartDatelineTips'],1);
		//showsetting($Fn_Live->Config['LangVar']['EndDateline'], 'end_dateline',$Item['end_dateline'] ? date('Y-m-d H:i',$Item['end_dateline']) : '', 'calendar','','','',1);

		showsetting($Fn_Live->Config['LangVar']['VisitLimit'],array('visit_limit', array(
			array('1',$Fn_Live->Config['LangVar']['VisitLimitArray']['1'], array('visit_limit_table_2' => 'none', 'visit_limit_table_3' => 'none')),
			array('2',$Fn_Live->Config['LangVar']['VisitLimitArray']['2'], array('visit_limit_table_2' => '', 'visit_limit_table_3' => 'none')),
			array('3',$Fn_Live->Config['LangVar']['VisitLimitArray']['3'], array('visit_limit_table_2' => 'none', 'visit_limit_table_3' => '')),
		), TRUE),$Item['param']['visit_limit'] ? $Item['param']['visit_limit'] : 1, 'mradio');
		
		$VisitLimitTableDisplay2 = $Item['param']['visit_limit'] == 2 ? true : false;
		showtagheader('div', 'visit_limit_table_2', $VisitLimitTableDisplay2, 'sub');
			
			showsetting($Fn_Live->Config['LangVar']['Money'], 'money', $Item['param']['money'], 'text');
			showsetting('APP'.$Fn_Live->Config['LangVar']['Money'], 'money_app', $Item['param']['money_app'], 'text','','',$Fn_Live->Config['LangVar']['AppMoneyTips']);
			showsetting($Fn_Live->Config['LangVar']['PayViewTime'], 'money_time', $Item['param']['money_time'] ? $Item['param']['money_time'] / 1000 : '', 'text','','',$Fn_Live->Config['LangVar']['PayViewTimeTips']);
			showsetting($Fn_Live->Config['LangVar']['PayViewTitie'], 'money_title', $Item['param']['money_title'] ? $Item['param']['money_title'] : $Fn_Live->Config['LangVar']['PayViewTitleDefaul'], 'text');
			showsetting($Fn_Live->Config['LangVar']['PayViewBtn'], 'money_btn', $Item['param']['money_btn'] ? $Item['param']['money_btn'] : $Fn_Live->Config['LangVar']['PayViewBtnDefaul'], 'text');
			showsetting($Fn_Live->Config['LangVar']['DwonAppBtn'], 'money_app_btn', $Item['param']['money_app_btn'] ? $Item['param']['money_app_btn'] : $Fn_Live->Config['LangVar']['DwonApp'], 'text');
			showsetting($Fn_Live->Config['LangVar']['PayViewTips'], 'money_tips', $Item['param']['money_tips'] ? $Item['param']['money_tips'] : $Fn_Live->Config['LangVar']['PayViewTipsDefaul'], 'textarea','','',$Fn_Live->Config['LangVar']['PayViewTipsText']);
			showsetting($Fn_Live->Config['LangVar']['AppPayViewTips'], 'money_app_tips', $Item['param']['money_app_tips'] ? $Item['param']['money_app_tips'] : $Fn_Live->Config['LangVar']['AppPayViewTipsDefaul'], 'textarea','','',$Fn_Live->Config['LangVar']['AppPayViewTipsText']);
			showsetting($Fn_Live->Config['LangVar']['NoPayProhibitComment'], 'no_pay_comment', $Item['param']['no_pay_comment'], 'radio');
			showsetting($Fn_Live->Config['LangVar']['NoPayProhibitCommentTips'], 'no_pay_comment_tips', $Item['param']['no_pay_comment_tips'] ? $Item['param']['no_pay_comment_tips'] : $Fn_Live->Config['LangVar']['NoPayProhibitCommentTipsDefaul'], 'text');
			
		showtagfooter('div');

		$VisitLimitTableDisplay3 = $Item['param']['visit_limit'] == 3 ? true : false;
		showtagheader('div', 'visit_limit_table_3', $VisitLimitTableDisplay3, 'sub');
			showsetting($Fn_Live->Config['LangVar']['Password'], 'pass', $Item['param']['pass'], 'text');
			showsetting($Fn_Live->Config['LangVar']['PasswordTime'], 'pass_time', $Item['param']['pass_time'], 'text', '', '',$Fn_Live->Config['LangVar']['PasswordTimeTips']);
		showtagfooter('div');

		showsetting($Fn_Live->Config['LangVar']['StateTitle'], 'state', $Item['state'] ? $Item['state'] : 1, 'text','','',$Fn_Live->Config['LangVar']['StateTitleTipsTo']);
		
		showsetting($Fn_Live->Config['LangVar']['Nav'], 'navs', $Item['param']['navs'], 'textarea','','',$Fn_Live->Config['LangVar']['LiveNavTips']);

		showsetting($Fn_Live->Config['LangVar']['NavFollow'],array('nav_follow', array(
			array('1',$Fn_Live->Config['LangVar']['Yes'], array('nav_follow_table' => '', 'nav_follow_table_no' => 'none')),
			array('0',$Fn_Live->Config['LangVar']['No'], array('nav_follow_table' => 'none', 'nav_follow_table_no' => '')),
		), TRUE),$Item['param']['nav_follow'], 'mradio');
		$NavFollowTableDisplay = $Item['param']['nav_follow'] == 1 ? true : false;
		showtagheader('div', 'nav_follow_table', $NavFollowTableDisplay, 'sub');
			
			echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_Live->Config['LangVar']['FollowQr'].'</label><div class="col-sm-9"><div class="AdminSingleUpload"><div class="PhotoControl" id="FollowQr"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';
			showsetting($Fn_Live->Config['LangVar']['FollowBgColor'], 'follow_bg_color', $Item['param']['follow_bg_color'] ? $Item['param']['follow_bg_color'] : $Fn_Live->Config['PluginVar']['Color'], 'color');
			showsetting($Fn_Live->Config['LangVar']['FollowPopTitle'], 'follow_pop_title', $Item['param']['follow_pop_title'] ? $Item['param']['follow_pop_title'] : $Fn_Live->Config['LangVar']['FollowPopTitleDefaul'], 'text');
			showsetting($Fn_Live->Config['LangVar']['FollowPopWxAppDesc'], 'follow_pop_wx_content', $Item['param']['follow_pop_wx_content'] ? $Item['param']['follow_pop_wx_content'] : $Fn_Live->Config['LangVar']['FollowPopWxAppDescDefaul'], 'text');
			showsetting($Fn_Live->Config['LangVar']['FollowPopDesc'], 'follow_pop_content', $Item['param']['follow_pop_content'] ? $Item['param']['follow_pop_content'] : $Fn_Live->Config['LangVar']['FollowPopDescDefaul'], 'text');
			
		showtagfooter('div');

		//����1
		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_Live->Config['LangVar']['Content'].'2:</label><div class="col-sm-9"><script id="content2" name="content2" type="text/plain" style="width:80%;height:450px;">'.stripslashes($Item['param']['content2']).'</script></div></div>';
		//����2
		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_Live->Config['LangVar']['Content'].'3:</label><div class="col-sm-9"><script id="content3" name="content3" type="text/plain" style="width:80%;height:450px;">'.stripslashes($Item['param']['content3']).'</script></div></div>';

		showsetting('&#26694;&#26550;&#38142;&#25509;&#49;', 'iframe1', $Item['param']['iframe1'], 'text');

		showsetting('&#26694;&#26550;&#38142;&#25509;&#50;', 'iframe2', $Item['param']['iframe2'], 'text');

		echo <<<HTML
		</div>
		<!-- �������� end  -->
HTML;
		echo <<<HTML
		<!-- ��������  -->
		<div class="tab-pane" id="gift" role="tabpanel" aria-expanded="false">
HTML;
		//������
		showsetting($Fn_Live->Config['LangVar']['GiftSwitch'],array('gift', array(
			array('1',$Fn_Live->Config['LangVar']['Yes'], array('gift_table' => '', 'gift_table_no' => 'none')),
			array('0',$Fn_Live->Config['LangVar']['No'], array('gift_table' => 'none', 'gift_table_no' => '')),
		), TRUE),$Item['param']['gift'], 'mradio','','',$Fn_Live->Config['LangVar']['RedpacketSwitchTips']);
		$GiftTableDisplay = $Item['param']['gift'] == 1 ? true : false;
		showtagheader('div', 'gift_table', $GiftTableDisplay, 'sub');
			
			echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_Live->Config['LangVar']['GiftIco'].'</label><div class="col-sm-9"><div class="AdminSingleUpload"><div class="PhotoControl" id="GiftImgPhotoControl"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';

			echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_Live->Config['LangVar']['GiftListBg'].'</label><div class="col-sm-9"><div class="AdminSingleUpload"><div class="PhotoControl" id="GiftListBgPhotoControl"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';

			echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_Live->Config['LangVar']['GiftListMoney'].'</label><div class="col-sm-9"><div class="AdminSingleUpload"><div class="PhotoControl" id="GiftListMoneyPhotoControl"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';

			$GiftForm = array();
			foreach($Fn_Live->GetGiftList() as $Val) {
				$GiftForm[] = array($Val['id'], $Val['title']);
			}
			showsetting($Fn_Live->Config['LangVar']['GiftList'], array('gift_list[]',$GiftForm),$Item['param']['gift_list'] ? $Item['param']['gift_list'] : $NewClass['param']['gift_list'],'mselect','','',$Fn_Live->Config['LangVar']['GiftListTips']);
			
			showsetting($Fn_Live->Config['LangVar']['GiftTitle'], 'gift_title', $Item['param']['gift_title'] ? $Item['param']['gift_title'] : $Fn_Live->Config['LangVar']['GiftTitleDefaul'], 'text');
			showsetting($Fn_Live->Config['LangVar']['GiftListTitle'], 'gift_list_title', $Item['param']['gift_list_title'] ? $Item['param']['gift_list_title'] : $Fn_Live->Config['LangVar']['GiftListTitleDefaul'], 'text');
			showsetting($Fn_Live->Config['LangVar']['GiftComment'], 'gift_comment', $Item['param']['gift_comment'] ? $Item['param']['gift_comment'] : $Fn_Live->Config['LangVar']['GiftCommentDefaul'], 'textarea','','',$Fn_Live->Config['LangVar']['GiftCommentTips']);
			showsetting($Fn_Live->Config['LangVar']['ParticipantGiftComment'], 'participant_gift_comment', $Item['param']['participant_gift_comment'] ? $Item['param']['participant_gift_comment'] : $Fn_Live->Config['LangVar']['ParticipantGiftCommentDefaul'], 'textarea','','',$Fn_Live->Config['LangVar']['ParticipantGiftCommentTips']);
			showsetting($Fn_Live->Config['LangVar']['GiftLogContent'], 'gift_log_content', $Item['param']['gift_log_content'] ? $Item['param']['gift_log_content'] : $Fn_Live->Config['LangVar']['GiftLogContentDefaul'], 'textarea','','',$Fn_Live->Config['LangVar']['GiftLogContentTips']);

		showtagfooter('div');
		echo <<<HTML
		</div>
		<!-- �������� end  -->
HTML;
		echo <<<HTML
		<!-- ���������  -->
		<div class="tab-pane" id="package" role="tabpanel" aria-expanded="false">
HTML;
		//�����
		showsetting($Fn_Live->Config['LangVar']['RedpacketSwitch'],array('pedpacket', array(
			array('1',$Fn_Live->Config['LangVar']['Yes'], array('pedpacket_table' => '', 'pedpacket_table_no' => 'none')),
			array('0',$Fn_Live->Config['LangVar']['No'], array('pedpacket_table' => 'none', 'pedpacket_table_no' => '')),
		), TRUE),$Item['param']['pedpacket'], 'mradio','','',$Fn_Live->Config['LangVar']['RedpacketSwitchTips']);
		$RedpacketTableDisplay = $Item['param']['pedpacket'] == 1 ? true : false;
		showtagheader('div', 'pedpacket_table', $RedpacketTableDisplay, 'sub');

			echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_Live->Config['LangVar']['RedpacketImg'].'</label><div class="col-sm-9"><div class="AdminSingleUpload"><div class="PhotoControl" id="RedpacketImgPhotoControl"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';

			showsetting($Fn_Live->Config['LangVar']['AppRedpacketSwitch'], 'pedpacket_app', $Item['param']['pedpacket_app'], 'radio');
			showsetting($Fn_Live->Config['LangVar']['AppRedpacketTips'], 'pedpacket_app_tips', $Item['param']['pedpacket_app_tips'] ? $Item['param']['pedpacket_app_tips'] : $Fn_Live->Config['LangVar']['AppRedpacketTipsDefaul'], 'text');

		showtagfooter('div');
		echo <<<HTML
		</div>
		<!-- ��������� end  -->
HTML;
		
		echo <<<HTML
		<!-- ����������  -->
		<div class="tab-pane" id="player" role="tabpanel" aria-expanded="false">
HTML;

		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_Live->Config['LangVar']['PlayerCover'].'<br>'.$Fn_Live->Config['LangVar']['PlayerCoverTips'].'</label><div class="col-sm-9"><div class="AdminSingleUpload"><div class="PhotoControl" id="PlayerCover"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';

		//echo '<tr><td colspan="2" class="td27 title" s="1">'.$Fn_Live->Config['LangVar']['VideoResolvingPower'].'</td></tr><tr class="noborder"><td class="vtop rowform" colspan="2"><input size="7" type="text" name="player_weight" value="'.($Item['param']['player_weight'] ? $Item['param']['player_weight'] : 1280).'" class="input w70"> X <input size="7" type="text" name="player_height" value="'.($Item['param']['player_height'] ? $Item['param']['player_height'] : 720).'" class="input w70"></td></tr>';

		showsetting($Fn_Live->Config['LangVar']['PlayerType'],array('player_type', array(
			array('m3u8',$Fn_Live->Config['LangVar']['PlayerTypeArray']['m3u8'], array('m3u8_table' => '', 'iframe_table' => 'none', 'info_table' => 'none', 'huya_table' => 'none', 'yy_table' => 'none', 'qq_table' => 'none', 'douyu_table' => 'none')),
			array('iframe',$Fn_Live->Config['LangVar']['PlayerTypeArray']['iframe'], array('m3u8_table' => 'none', 'iframe_table' => '', 'info_table' => 'none', 'huya_table' => 'none', 'yy_table' => 'none', 'qq_table' => 'none', 'douyu_table' => 'none')),
			array('info',$Fn_Live->Config['LangVar']['PlayerTypeArray']['info'], array('m3u8_table' => 'none', 'iframe_table' => 'none', 'info_table' => '', 'huya_table' => 'none', 'yy_table' => 'none', 'qq_table' => 'none', 'douyu_table' => 'none')),
			array('huya',$Fn_Live->Config['LangVar']['PlayerTypeArray']['huya'], array('m3u8_table' => 'none', 'iframe_table' => 'none','info_table' => 'none', 'huya_table' => '', 'yy_table' => 'none', 'qq_table' => 'none', 'douyu_table' => 'none')),
			array('yy',$Fn_Live->Config['LangVar']['PlayerTypeArray']['yy'], array('m3u8_table' => 'none', 'iframe_table' => 'none','info_table' => 'none', 'huya_table' => 'none', 'yy_table' => '', 'qq_table' => 'none', 'douyu_table' => 'none')),
			array('qq',$Fn_Live->Config['LangVar']['PlayerTypeArray']['qq'], array('m3u8_table' => 'none', 'iframe_table' => 'none','info_table' => 'none', 'huya_table' => 'none', 'yy_table' => 'none', 'qq_table' => '', 'douyu_table' => 'none')),
			//array('douyu',$Fn_Live->Config['LangVar']['PlayerTypeArray']['douyu'], array('m3u8_table' => 'none', 'iframe_table' => 'none','info_table' => 'none', 'huya_table' => 'none', 'yy_table' => 'none', 'qq_table' => 'none', 'douyu_table' => '')),
		), TRUE),$Item['param']['player_type'] ? $Item['param']['player_type'] : 'm3u8', 'mradio');
		
		$TypeTableM3u8 = $Item['param']['player_type'] == 'm3u8' || !$Item ? true : false;

		$TypeTableIframe = $Item['param']['player_type'] == 'iframe' ? true : false;

		$TypeTableInfo = $Item['param']['player_type'] == 'info' ? true : false;

		$TypeTableHuYa = $Item['param']['player_type'] == 'huya' ? true : false;

		$TypeTableYY = $Item['param']['player_type'] == 'yy' ? true : false;

		$TypeTableQQ = $Item['param']['player_type'] == 'qq' ? true : false;

		$TypeTableDouYu = $Item['param']['player_type'] == 'douyu' ? true : false;
		
		showtagheader('div', 'm3u8_table', $TypeTableM3u8, 'sub');
			showsetting($Fn_Live->Config['LangVar']['RTMP'], 'rtmp', $Item['param']['rtmp'], 'text');
			showsetting($Fn_Live->Config['LangVar']['M3U8'], 'm3u8', $Item['param']['m3u8'], 'text');
			showsetting($Fn_Live->Config['LangVar']['APP_M3U8'], 'app_m3u8', $Item['param']['app_m3u8'], 'text');
			showsetting($Fn_Live->Config['LangVar']['APP_M3U8_TIPS'], 'app_m3u8_tips', $Item['param']['app_m3u8_tips'] ? $Item['param']['app_m3u8_tips'] : $Fn_Live->Config['LangVar']['APP_M3U8_TIPS_Defaul'], 'text');
		showtagfooter('div');

		showtagheader('div', 'iframe_table', $TypeTableIframe, 'sub');
			showsetting($Fn_Live->Config['LangVar']['IframeUrl'], 'iframe_url', $Item['param']['iframe_url'], 'text');
			showsetting($Fn_Live->Config['LangVar']['AnalysisUrlSwitch'], 'analysis_url_switch', $Item['param']['analysis_url_switch'], 'radio','','',$Fn_Live->Config['LangVar']['AnalysisUrlSwitchTips']);
		showtagfooter('div');

		showtagheader('div', 'info_table', $TypeTableInfo, 'sub');
			//showsetting($Fn_Live->Config['LangVar']['RoomId'], 'room_id', $Item['param']['room_id'], 'radio');
		showtagfooter('div');

		showtagheader('div', 'huya_table', $TypeTableHuYa, 'sub');
			showsetting($Fn_Live->Config['LangVar']['RoomId'], 'room_id', $Item['param']['room_id'], 'text','','',$Fn_Live->Config['LangVar']['huyaTips']);
		showtagfooter('div');

		showtagheader('div', 'yy_table', $TypeTableYY, 'sub');
			showsetting('sid', 'sid', $Item['param']['sid'], 'text','','',$Fn_Live->Config['LangVar']['SidTips']);
			showsetting('ssid', 'ssid', $Item['param']['ssid'], 'text','','',$Fn_Live->Config['LangVar']['SSidTips']);
			showsetting('tempId', 'temp_id', $Item['param']['temp_id'], 'text','','',$Fn_Live->Config['LangVar']['TempIdTips']);
		showtagfooter('div');

		showtagheader('div', 'qq_table', $TypeTableQQ, 'sub');
			showsetting($Fn_Live->Config['LangVar']['RoomId'], 'qq_room_id', $Item['param']['qq_room_id'], 'text','','',$Fn_Live->Config['LangVar']['qqTips']);
		showtagfooter('div');

		showtagheader('div', 'douyu_table', $TypeTableDouYu, 'sub');
			showsetting($Fn_Live->Config['LangVar']['RoomId'], 'douyu_room_id', $Item['param']['douyu_room_id'], 'text','','',$Fn_Live->Config['LangVar']['douyuTips']);
		showtagfooter('div');
		echo <<<HTML
		</div>
		<!-- ���������� end  -->
HTML;
		echo <<<HTML
		<!-- ��������  -->
		<div class="tab-pane" id="comment" role="tabpanel" aria-expanded="false">
HTML;
		showsetting($Fn_Live->Config['LangVar']['AdministratorsUID'], 'admin_uids', $Item['param']['admin_uids'], 'text','','',$Fn_Live->Config['LangVar']['AdministratorsUIDTips']);
		showsetting($Fn_Live->Config['LangVar']['CommentProhibit'],array('comment_prohibit', array(
			array('1',$Fn_Live->Config['LangVar']['Yes'], array('comment_prohibit_table' => '', 'comment_prohibit_table_no' => 'none')),
			array('0',$Fn_Live->Config['LangVar']['No'], array('comment_prohibit_table' => 'none', 'comment_prohibit_table_no' => '')),
		), TRUE),$Item['param']['comment_prohibit'], 'mradio');
		$CommentProhibitTableDisplay = $Item['param']['comment_prohibit'] == 1 ? true : false;
		showtagheader('div', 'comment_prohibit_table', $CommentProhibitTableDisplay, 'sub');
			showsetting($Fn_Live->Config['LangVar']['CommentProhibitTips'], 'comment_prohibit_tips', $Item['param']['comment_prohibit_tips'] ? $Item['param']['comment_prohibit_tips'] : $Fn_Live->Config['LangVar']['CommentProhibitTipsDefaul'], 'text');
		showtagfooter('div');

		showsetting($Fn_Live->Config['LangVar']['CommentDisplay'], 'comment_display', $Item['param']['comment_display'], 'radio');
		
		showsetting($Fn_Live->Config['LangVar']['CommentAutoTime'], 'comment_auto_time', $Item['param']['comment_auto_time'] ? $Item['param']['comment_auto_time'] / 1000 : '60', 'text','','',$Fn_Live->Config['LangVar']['CommentAutoTimeTips']);

		showsetting($Fn_Live->Config['LangVar']['CommentTime'], 'comment_time', $Item['param']['comment_time'], 'text','','',$Fn_Live->Config['LangVar']['CommentTimeTips']);

		showsetting($Fn_Live->Config['LangVar']['CommentTimeText'], 'comment_time_tips', $Item['param']['comment_time_tips'] ? $Item['param']['comment_time_tips'] : $Fn_Live->Config['LangVar']['CommentTimeTextDefaul'], 'text','','',$Fn_Live->Config['LangVar']['CommentTimeTextTips']);

		showsetting($Fn_Live->Config['LangVar']['CommentInputBtn'], 'comment_input_btn', $Item['param']['comment_input_btn'] ? $Item['param']['comment_input_btn'] : $Fn_Live->Config['LangVar']['CommentInputDefault'], 'text');
		showsetting($Fn_Live->Config['LangVar']['CommentInputTips'], 'comment_input_tips', $Item['param']['comment_input_tips'] ? $Item['param']['comment_input_tips'] : $Fn_Live->Config['LangVar']['CommentInputTipsDefault'], 'text');
		showsetting($Fn_Live->Config['LangVar']['CommentInputNullTips'], 'comment_input_null_tips', $Item['param']['comment_input_null_tips'] ? $Item['param']['comment_input_null_tips'] : $Fn_Live->Config['LangVar']['CommentInputNullTipsDefaul'], 'text');
		showsetting($Fn_Live->Config['LangVar']['CommentLimit'], 'comment_limit', $Item['param']['comment_limit'] ? $Item['param']['comment_limit'] : 30, 'text');

		showsetting($Fn_Live->Config['LangVar']['CommentForbiddenWords'], 'comment_forbidden_words', $Item['param']['comment_forbidden_words'], 'textarea','','',$Fn_Live->Config['LangVar']['CommentForbiddenWordsTips']);
		showsetting($Fn_Live->Config['LangVar']['CommentForbiddenWordsText'], 'comment_forbidden_words_tips', $Item['param']['comment_forbidden_words_tips'] ? $Item['param']['comment_forbidden_words_tips'] : $Fn_Live->Config['LangVar']['CommentForbiddenWordsTextDefaul'], 'text');
		showsetting($Fn_Live->Config['LangVar']['CommentRoll'], 'comment_roll', $Item['param']['comment_roll'], 'text');
		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_Live->Config['LangVar']['CommentBg'].'</label><div class="col-sm-9"><div class="AdminSingleUpload"><div class="PhotoControl" id="CommentBg"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';

		echo <<<HTML
		</div>
		<!-- �������� end  -->
HTML;
		
		echo <<<HTML
		<!-- ͼ��ֱ������  -->
		<div class="tab-pane" id="info" role="tabpanel" aria-expanded="false">
HTML;
		//ͼ��ֱ������
		showsetting($Fn_Live->Config['LangVar']['ImageTextAdministratorsUID'], 'admin_info_uids', $Item['param']['admin_info_uids'], 'text','','',$Fn_Live->Config['LangVar']['ImageTextAdministratorsUIDTips']);
		showsetting($Fn_Live->Config['LangVar']['LiveNameId'], 'live_name_id', $Item['param']['live_name_id'], 'textarea','','',$Fn_Live->Config['LangVar']['LiveNameIdTips']);
		showsetting($Fn_Live->Config['LangVar']['InfoAutoTime'], 'info_auto_time', $Item['param']['info_auto_time'] ? $Item['param']['info_auto_time'] / 1000 : '120', 'text','','',$Fn_Live->Config['LangVar']['InfoAutoTimeTips']);
		showsetting($Fn_Live->Config['LangVar']['InfoLimit'], 'info_limit', $Item['param']['info_limit'] ? $Item['param']['info_limit'] : 15, 'text');

		echo <<<HTML
		</div>
		<!-- ͼ��ֱ������ end  -->
HTML;
		
		echo <<<HTML
		<!-- ���а�����  -->
		<div class="tab-pane" id="ranking" role="tabpanel" aria-expanded="false">
HTML;
		showsetting($Fn_Live->Config['LangVar']['RanKingNav'], 'ranking_nav', $Item['param']['ranking_nav'] ? $Item['param']['ranking_nav'] : str_replace('<br>',"\r\n",$Fn_Live->Config['LangVar']['RanKingNavDefaul']), 'textarea','','',$Fn_Live->Config['LangVar']['RanKingNavTips']);
		showsetting($Fn_Live->Config['LangVar']['RanKingLimit'], 'ranking_limit', $Item['param']['ranking_limit'] ? $Item['param']['ranking_limit'] : 30, 'text','','',$Fn_Live->Config['LangVar']['RanKingLimitTips']);
		echo <<<HTML
		</div>
		<!-- ���а����� end  -->
HTML;
	
		echo <<<HTML
		<!-- ����ѡ������  -->
		<div class="tab-pane" id="reward" role="tabpanel" aria-expanded="false">
HTML;
		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_Live->Config['LangVar']['ParticipantRewardBg'].'</label><div class="col-sm-9"><div class="AdminSingleUpload"><div class="PhotoControl" id="ParticipantRewardBg"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';

		showsetting($Fn_Live->Config['LangVar']['ParticipantRewardTop'], 'participant_reward_top', $Item['param']['participant_reward_top'], 'text','','',$Fn_Live->Config['LangVar']['ParticipantRewardTopTips']);
		
		showsetting($Fn_Live->Config['LangVar']['ParticipantMobile'],array('participant_mobile', array(
			array('1',$Fn_Live->Config['LangVar']['Yes'], array('participant_mobile_table' => '', 'participant_mobile_table_no' => 'none')),
			array('0',$Fn_Live->Config['LangVar']['No'], array('participant_mobile_table' => 'none', 'participant_mobile_table_no' => '')),
		), TRUE),$Item['param']['participant_mobile'], 'mradio');
		$ParticipantMobileTableDisplay = $Item['param']['participant_mobile'] == 1 ? true : false;
		showtagheader('div', 'participant_mobile_table', $ParticipantMobileTableDisplay, 'sub');
			showsetting($Fn_Live->Config['LangVar']['ParticipantMobileBtnText'], 'participant_mobile_btn_text', $Item['param']['participant_mobile_btn_text'] ? $Item['param']['participant_mobile_btn_text'] : $Fn_Live->Config['LangVar']['ParticipantMobileBtnTextDefaul'], 'text');
			showsetting($Fn_Live->Config['LangVar']['ParticipantMobileBgColor'], 'participant_mobile_bg', $Item['param']['participant_mobile_bg'] ? $Item['param']['participant_mobile_bg'] : $Fn_Live->Config['PluginVar']['Color'], 'color');
		showtagfooter('div');

		showsetting($Fn_Live->Config['LangVar']['NumberBg'], 'bumber_bg', $Item['param']['bumber_bg'] ? $Item['param']['bumber_bg'] : $Fn_Live->Config['PluginVar']['Color'], 'color');
		showsetting($Fn_Live->Config['LangVar']['RewardBtnBgColor'], 'reward_btn_bg_color', $Item['param']['reward_btn_bg_color'] ? $Item['param']['reward_btn_bg_color'] : $Fn_Live->Config['PluginVar']['Color'], 'color');
		showsetting($Fn_Live->Config['LangVar']['RewardBtnText'], 'reward_btn_text', $Item['param']['reward_btn_text'] ? $Item['param']['reward_btn_text'] : $Fn_Live->Config['LangVar']['RewardBtnTextDefaul'], 'text');
		showsetting($Fn_Live->Config['LangVar']['ParticipantRewardPercentage'], 'participant_reward_percentage', $Item['param']['participant_reward_percentage'], 'text','','',$Fn_Live->Config['LangVar']['ParticipantRewardPercentageTips']);

		showsetting($Fn_Live->Config['LangVar']['ParticipantRewardAdmin'], 'admin_participant_reward_uids', $Item['param']['admin_participant_reward_uids'], 'text','','',$Fn_Live->Config['LangVar']['ParticipantRewardAdminTips']);
		echo <<<HTML
		</div>
		<!-- ����ѡ������ end  -->
HTML;
		
		echo <<<HTML
		<!-- �������� -->
		<div class="tab-pane" id="poster" role="tabpanel" aria-expanded="false">
HTML;
		showsetting($Fn_Live->Config['LangVar']['PosterSwitch'],array('poster', array(
			array('1',$Fn_Live->Config['LangVar']['Yes'], array('poster_table' => '', 'poster_table_no' => 'none')),
			array('0',$Fn_Live->Config['LangVar']['No'], array('poster_table' => 'none', 'poster_table_no' => '')),
		), TRUE),$Item['param']['poster'], 'mradio','','',$Fn_Live->Config['LangVar']['RedpacketSwitchTips']);
		$PosterTableDisplay = $Item['param']['poster'] == 1 ? true : false;
		showtagheader('div', 'poster_table', $PosterTableDisplay, 'sub');
			echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_Live->Config['LangVar']['PosterIco'].'</label><div class="col-sm-9"><div class="AdminSingleUpload"><div class="PhotoControl" id="PosterIco"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';
			echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_Live->Config['LangVar']['PosterBg'].'</label><div class="col-sm-9"><div class="AdminSingleUpload"><div class="PhotoControl" id="PosterBg"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';
			showsetting($Fn_Live->Config['LangVar']['PosterTitleColor'], 'poster_title_color', $Item['param']['poster_title_color'] ? $Item['param']['poster_title_color'] : '#A62417', 'color');
			showsetting($Fn_Live->Config['LangVar']['PosterInvite'], 'poster_invite', $Item['param']['poster_invite'], 'radio','','',$Fn_Live->Config['LangVar']['PosterInviteTips']);
			showsetting($Fn_Live->Config['LangVar']['ParametricQRCodeSwitch'], 'qr_code_switch', $Item['param']['qr_code_switch'], 'radio','','',$Fn_Live->Config['LangVar']['ParametricQRCodeSwitchTips']);
		showtagfooter('div');
		echo <<<HTML
		</div>
		<!-- ����ѡ������ end  -->
HTML;
		
		echo <<<HTML
		<!-- App���� -->
		<div class="tab-pane" id="app" role="tabpanel" aria-expanded="false">
HTML;

		showsetting($Fn_Live->Config['LangVar']['FixedNavApp'],array('fixed_nav_app', array(
			array('1',$Fn_Live->Config['LangVar']['Yes'], array('fixed_nav_app_table' => '', 'fixed_nav_app_table_no' => 'none')),
			array('0',$Fn_Live->Config['LangVar']['No'], array('fixed_nav_app_table' => 'none', 'fixed_nav_app_table_no' => '')),
		), TRUE),$Item['param']['fixed_nav_app'], 'mradio','','',$Fn_Live->Config['LangVar']['FixedNavAppTips']);
		
		$FixedNavAppTableDisplay = $Item['param']['fixed_nav_app'] == 1 ? true : false;
		showtagheader('div', 'fixed_nav_app_table', $FixedNavAppTableDisplay, 'sub');
			$Item['param']['app_ico'] = $Item['param']['app_ico'] ? $Item['param']['app_ico'] : $Fn_Live->Config['PluginVar']['AppIcoPath'];
			$app_ico_html = '<a href="'.$Item['param']['app_ico'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$Item['param']['app_ico'].'" height="55"/></a>';
			showsetting($Fn_Live->Config['LangVar']['FixedNavAppPath'], 'new_app_ico',$Item['param']['app_ico'], 'filetext', '', 0, $app_ico_html);

		showtagfooter('div');
		
		showsetting($Fn_Live->Config['LangVar']['AppComment'],array('app_comment', array(
			array('1',$Fn_Live->Config['LangVar']['Yes'], array('app_comment_table' => '', 'app_comment_table_no' => 'none')),
			array('0',$Fn_Live->Config['LangVar']['No'], array('app_comment_table' => 'none', 'app_comment_table_no' => '')),
		), TRUE),$Item['param']['app_comment'], 'mradio');
		
		$AppCommentTableDisplay = $Item['param']['app_comment'] == 1 ? true : false;
		showtagheader('div', 'app_comment_table', $AppCommentTableDisplay, 'sub');
			showsetting($Fn_Live->Config['LangVar']['AppCommentText'], 'app_commen_tips', $Item['param']['app_commen_tips'] ? $Item['param']['app_commen_tips'] : $Fn_Live->Config['LangVar']['AppCommentTextDefaul'], 'text');
		showtagfooter('div');

		showsetting($Fn_Live->Config['LangVar']['AppPlayBack'],array('app_play_back', array(
			array('1',$Fn_Live->Config['LangVar']['Yes'], array('app_play_back_table' => '', 'app_play_back_table_no' => 'none')),
			array('0',$Fn_Live->Config['LangVar']['No'], array('app_play_back_table' => 'none', 'app_play_back_table_no' => '')),
		), TRUE),$Item['param']['app_play_back'], 'mradio');
		
		$AppPlayBackTableDisplay = $Item['param']['app_play_back'] == 1 ? true : false;
		showtagheader('div', 'app_play_back_table', $AppPlayBackTableDisplay, 'sub');
			showsetting($Fn_Live->Config['LangVar']['AppPlayBackText'], 'app_play_back_tips', $Item['param']['app_play_back_tips'] ? $Item['param']['app_play_back_tips'] : $Fn_Live->Config['LangVar']['AppPlayBackTextDefaul'], 'text');
		showtagfooter('div');
		echo <<<HTML
		</div>
		<!-- App���� end  -->
HTML;
		
		echo <<<HTML
		<!-- ������� -->
		<div class="tab-pane" id="ad" role="tabpanel" aria-expanded="false">
HTML;
		
		showsetting($Fn_Live->Config['LangVar']['FullScreenSwitch'],array('full_screen', array(
			array('1',$Fn_Live->Config['LangVar']['Yes'], array('full_screen_table' => '', 'full_screen_table_no' => 'none')),
			array('0',$Fn_Live->Config['LangVar']['No'], array('full_screen_table' => 'none', 'full_screen_table_no' => '')),
		), TRUE),$Item['param']['full_screen'], 'mradio');
		$FullScreenTableDisplay = $Item['param']['full_screen'] == 1 ? true : false;
		showtagheader('div', 'full_screen_table', $FullScreenTableDisplay, 'sub');
			
			echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_Live->Config['LangVar']['FullScreenImg'].'</label><div class="col-sm-9"><div class="AdminSingleUpload"><div class="PhotoControl" id="FullScreenControl"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';

			showsetting($Fn_Live->Config['LangVar']['FullScreenLink'], 'full_screen_url', $Item['param']['full_screen_url'], 'text');
			showsetting($Fn_Live->Config['LangVar']['FullScreenTime'], 'full_screen_time', $Item['param']['full_screen_time'] ? $Item['param']['full_screen_time'] : 5, 'text','','',$Fn_Live->Config['LangVar']['FullScreenTimeTips']);
		showtagfooter('div');

		
		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_Live->Config['LangVar']['PlayerBottomAd'].'</label><div class="col-sm-9"><div class="UploadBanner"><div class="PhotoControl ClickPhotoControl" id="PlayerBottomAd"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';

		showsetting($Fn_Live->Config['LangVar']['AdRollSwitch'],array('ad_roll_switch', array(
			array('1',$Fn_Live->Config['LangVar']['Yes'], array('ad_roll_table' => '', 'ad_roll_table_no' => 'none')),
			array('0',$Fn_Live->Config['LangVar']['No'], array('ad_roll_table' => 'none', 'ad_roll_table_no' => '')),
		), TRUE),$Item['param']['ad_roll_switch'], 'mradio','','',$Fn_Live->Config['LangVar']['AdRollSwitchTips']);
		$AdRollTableDisplay = $Item['param']['ad_roll_switch'] == 1 ? true : false;
		showtagheader('div', 'ad_roll_table', $AdRollTableDisplay, 'sub');
			showsetting($Fn_Live->Config['LangVar']['AdRoll'], 'ad_roll', $Item['param']['ad_roll'], 'text');
			showsetting($Fn_Live->Config['LangVar']['AdRollUrl'], 'ad_roll_url', $Item['param']['ad_roll_url'], 'text');
			showsetting($Fn_Live->Config['LangVar']['AdRollColor'], 'ad_roll_color', $Item['param']['ad_roll_color'] ? $Item['param']['ad_roll_color'] : '#ffffff', 'color');
			showsetting($Fn_Live->Config['LangVar']['AdRollBgColor'], 'ad_roll_bg_color', $Item['param']['ad_roll_bg_color'] ? $Item['param']['ad_roll_bg_color'] : '#000000', 'color','','',$Fn_Live->Config['LangVar']['AdRollBgColorTips']);

			echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_Live->Config['LangVar']['AdRollBgCover'].'</label><div class="col-sm-9"><div class="AdminSingleUpload"><div class="PhotoControl" id="AdRollBgCover"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';

		showtagfooter('div');
		echo <<<HTML
		</div>
		<!-- ������� end  -->
HTML;
		
		echo <<<HTML
		<!-- �������� -->
		<div class="tab-pane" id="share" role="tabpanel" aria-expanded="false">
HTML;
		showsetting($Fn_Live->Config['LangVar']['ShareTitle'], 'share_title', $Item['param']['share_title'], 'text');
		showsetting($Fn_Live->Config['LangVar']['ShareDesc'], 'share_desc', $Item['param']['share_desc'], 'text');

		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_Live->Config['LangVar']['ShareImg'].'<br>'.$Fn_Live->Config['LangVar']['ShareImgTips'].'</label><div class="col-sm-9"><div class="AdminSingleUpload"><div class="PhotoControl" id="ShareImgPhotoControl"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';
		
		echo <<<HTML
		</div>
		<!-- �������� end  -->
HTML;
		
		echo <<<HTML
		<!-- �������� -->
		<div class="tab-pane" id="other" role="tabpanel" aria-expanded="false">
HTML;
		if($Item['updateline']){
			showsetting($Fn_Live->Config['LangVar']['RefreshTime'], 'updateline',$Item['updateline'] ? date('Y-m-d H:i',$Item['updateline']) : '', 'calendar','','','',1);
		}

		if($Item['dateline']){
			showsetting($Fn_Live->Config['LangVar']['TimeTitle'], 'dateline',date('Y-m-d H:i',$Item['dateline']), 'calendar','','','',1);
		}
		
		showsetting($Fn_Live->Config['LangVar']['Click'], 'click', $Item['click'], 'text');

		showsetting($Fn_Live->Config['LangVar']['ClickRand'], 'click_rand', $Item['param']['click_rand'] ? $Item['param']['click_rand'] : '1-1', 'text','','',$Fn_Live->Config['LangVar']['ClickRandTips']);
		
		showsetting('&#24320;&#21551;&#35775;&#38382;&#35760;&#24405;', 'visit', $Item['param']['visit'], 'radio','','','&#26159;&#21542;&#24320;&#21551;&#35775;&#38382;&#35760;&#24405;&#65292;&#27880;&#24847;&#65306;&#24320;&#21551;&#20250;&#20154;&#25968;&#22810;&#21487;&#33021;&#20250;&#36896;&#25104;&#26381;&#21153;&#22120;&#21345;');

		showsetting('&#30005;&#33041;&#29256;&#20108;&#32500;&#30721;',array('PcQrSwitch', array(
			array('1','&#26159;', array('PcQrSwitchDiv' => '')),
			array('0','&#21542;;', array('PcQrSwitchDiv' => 'none')),
		), TRUE),$Item['param']['PcQrSwitch'], 'mradio');

		showtagheader('div', 'PcQrSwitchDiv', $Item['param']['PcQrSwitch'] ? true : '','PcQrSwitchDiv');
			showsetting('&#30005;&#33041;&#29256;&#20108;&#32500;&#30721;&#25991;&#23383;', 'PcQrText', $setting['PcQrText'] ? $setting['PcQrText'] : '&#25195;&#19968;&#25195;&#65292;&#25163;&#26426;&#35266;&#30475;&#30452;&#25773;&#26356;&#26041;&#20415;', 'text');
		showtagfooter('div');

		showsetting($Fn_Live->Config['LangVar']['DisplayTitle'], 'display', $Item ? $Item['display'] : 1, 'radio');

		showsetting($Fn_Live->Config['LangVar']['ThemeColor'], 'color', $Item['param']['color'] ? $Item['param']['color'] : $Fn_Live->Config['PluginVar']['Color'], 'color');
		showsetting($Fn_Live->Config['LangVar']['TwoColor'], 'fcolor', $Item['param']['fcolor'] ? $Item['param']['fcolor'] : $Fn_Live->Config['PluginVar']['FColor'], 'color');

		echo <<<HTML
		</div>
		<!-- �������� end  -->
HTML;
		
		showsubmit('DetailSubmit','&#20445;&#23384;&#37197;&#32622;');
		showtagfooter('div');
		showtagfooter('div');
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');

		$UpLoadHtml  = '';
		if($Item['thumb']){
			$ThumbJsArray[] = '"'.$Item['thumb'].'"';;
			$UpLoadHtml .= '
			var InputArray = new Array('.implode(',',$ThumbJsArray).');
			$("#ThumbPhotoControl").AppUpload({InputName:"new_thumb",Multiple:true,InputExist:true,InputArray:InputArray});';

		}else{
			$UpLoadHtml .= '$("#ThumbPhotoControl").AppUpload({InputName:"new_thumb",Multiple:true});';
		}

		$Item['param']['gift_img'] = $Item['param']['gift_img'] ? $Item['param']['gift_img'] : $Fn_Live->Config['StaticPath'].'/images/gift.png';
		if($Item['param']['gift_img']){
			$GiftImgJsArray[] = '"'.$Item['param']['gift_img'].'"';;
			$UpLoadHtml .= '
			var InputArray = new Array('.implode(',',$GiftImgJsArray).');
			$("#GiftImgPhotoControl").AppUpload({InputName:"new_gift_img",Multiple:true,InputExist:true,InputArray:InputArray});';

		}else{
			$UpLoadHtml .= '$("#GiftImgPhotoControl").AppUpload({InputName:"new_gift_img",Multiple:true});';
		}

		$Item['param']['gift_list_bg'] = $Item['param']['gift_list_bg'] ? $Item['param']['gift_list_bg'] : $Fn_Live->Config['StaticPath'].'/images/gift_bg.jpg';
		if($Item['param']['gift_list_bg']){
			$GiftListBgJsArray[] = '"'.$Item['param']['gift_list_bg'].'"';;
			$UpLoadHtml .= '
			var InputArray = new Array('.implode(',',$GiftListBgJsArray).');
			$("#GiftListBgPhotoControl").AppUpload({InputName:"new_gift_list_bg",Multiple:true,InputExist:true,InputArray:InputArray});';

		}else{
			$UpLoadHtml .= '$("#GiftListBgPhotoControl").AppUpload({InputName:"new_gift_list_bg",Multiple:true});';
		}

		$Item['param']['gift_list_money'] = $Item['param']['gift_list_money'] ? $Item['param']['gift_list_money'] : $Fn_Live->Config['StaticPath'].'/images/gift_money.jpg';
		if($Item['param']['gift_list_money']){
			$GiftListMoneyJsArray[] = '"'.$Item['param']['gift_list_money'].'"';;
			$UpLoadHtml .= '
			var InputArray = new Array('.implode(',',$GiftListMoneyJsArray).');
			$("#GiftListMoneyPhotoControl").AppUpload({InputName:"new_gift_list_money",Multiple:true,InputExist:true,InputArray:InputArray});';

		}else{
			$UpLoadHtml .= '$("#GiftListMoneyPhotoControl").AppUpload({InputName:"new_gift_list_money",Multiple:true});';
		}

		if($Item['param']['follow_qr']){
			$FollowQrJsArray[] = '"'.$Item['param']['follow_qr'].'"';;
			$UpLoadHtml .= '
			var InputArray = new Array('.implode(',',$FollowQrJsArray).');
			$("#FollowQr").AppUpload({InputName:"new_follow_qr",Multiple:true,InputExist:true,InputArray:InputArray});';

		}else{
			$UpLoadHtml .= '$("#FollowQr").AppUpload({InputName:"new_follow_qr",Multiple:true});';
		}
		
		$Item['param']['pedpacket_img'] = $Item['param']['pedpacket_img'] ? $Item['param']['pedpacket_img'] : $Fn_Live->Config['StaticPath'].'/images/redpacket.png';
		if($Item['param']['pedpacket_img']){
			$RedpacketImgJsArray[] = '"'.$Item['param']['pedpacket_img'].'"';;
			$UpLoadHtml .= '
			var InputArray = new Array('.implode(',',$RedpacketImgJsArray).');
			$("#RedpacketImgPhotoControl").AppUpload({InputName:"new_pedpacket_img",Multiple:true,InputExist:true,InputArray:InputArray});';

		}else{
			$UpLoadHtml .= '$("#RedpacketImgPhotoControl").AppUpload({InputName:"new_pedpacket_img",Multiple:true});';
		}

		if($Item['param']['player_cover']){
			$PlayerCoverImgJsArray[] = '"'.$Item['param']['player_cover'].'"';;
			$UpLoadHtml .= '
			var InputArray = new Array('.implode(',',$PlayerCoverImgJsArray).');
			$("#PlayerCover").AppUpload({InputName:"new_player_cover",Multiple:true,InputExist:true,InputArray:InputArray});';

		}else{
			$UpLoadHtml .= '$("#PlayerCover").AppUpload({InputName:"new_player_cover",Multiple:true});';
		}

		if($Item['param']['comment_bg']){
			$CommentBgJsArray[] = '"'.$Item['param']['comment_bg'].'"';;
			$UpLoadHtml .= '
			var InputArray = new Array('.implode(',',$CommentBgJsArray).');
			$("#CommentBg").AppUpload({InputName:"new_comment_bg",Multiple:true,InputExist:true,InputArray:InputArray});';

		}else{
			$UpLoadHtml .= '$("#CommentBg").AppUpload({InputName:"new_comment_bg",Multiple:true});';
		}
		
		$Item['param']['poster_ico'] = $Item['param']['poster_ico'] ? $Item['param']['poster_ico'] : $Fn_Live->Config['StaticPath'].'/images/poster_ico.png';
		if($Item['param']['poster_ico']){
			$PosterIcoJsArray[] = '"'.$Item['param']['poster_ico'].'"';;
			$UpLoadHtml .= '
			var InputArray = new Array('.implode(',',$PosterIcoJsArray).');
			$("#PosterIco").AppUpload({InputName:"new_poster_ico",Multiple:true,InputExist:true,InputArray:InputArray});';

		}else{
			$UpLoadHtml .= '$("#PosterIco").AppUpload({InputName:"new_poster_ico",Multiple:true});';
		}
		
		$Item['param']['poster_bg'] = $Item['param']['poster_bg'] ? $Item['param']['poster_bg'] : $Fn_Live->Config['StaticPath'].'/images/poster_bg.jpg';
		if($Item['param']['poster_bg']){
			$PosterBgJsArray[] = '"'.$Item['param']['poster_bg'].'"';;
			$UpLoadHtml .= '
			var InputArray = new Array('.implode(',',$PosterBgJsArray).');
			$("#PosterBg").AppUpload({InputName:"new_poster_bg",Multiple:true,InputExist:true,InputArray:InputArray});';

		}else{
			$UpLoadHtml .= '$("#PosterBg").AppUpload({InputName:"new_poster_bg",Multiple:true});';
		}

		$Item['param']['participant_reward_bg'] = $Item['param']['participant_reward_bg'] ? $Item['param']['participant_reward_bg'] : $Fn_Live->Config['StaticPath'].'/images/participant_reward_bg.jpg';
		if($Item['param']['participant_reward_bg']){
			$ParticipantBgJsArray[] = '"'.$Item['param']['participant_reward_bg'].'"';;
			$UpLoadHtml .= '
			var InputArray = new Array('.implode(',',$ParticipantBgJsArray).');
			$("#ParticipantRewardBg").AppUpload({InputName:"new_participant_reward_bg",Multiple:true,InputExist:true,InputArray:InputArray});';

		}else{
			$UpLoadHtml .= '$("#ParticipantRewardBg").AppUpload({InputName:"new_participant_reward_bg",Multiple:true});';
		}
		if($Item['param']['player_bottom_ad']){
			
			foreach($Item['param']['player_bottom_ad'] as $Key => $Val) {
				$PlayerBottomAdJsArray[] = '"'.$Val['img'].'|'.$Item['param']['player_bottom_ad'][$Key]['title'].'|'.$Item['param']['player_bottom_ad'][$Key]['link'].'"';
			}
			$UpLoadHtml .= '
			var InputArray = new Array('.implode(',',$PlayerBottomAdJsArray).');
			$("#PlayerBottomAd").AppUpload({InputName:"new_player_bottom_ad",InputLink:true,InputExist:true,InputArray:InputArray});';

		}else{
			$UpLoadHtml .= '$("#PlayerBottomAd").AppUpload({InputName:"new_player_bottom_ad",InputLink:true});';
		}


		if($Item['param']['full_screen_cover']){
			$FullScreenCoverImgJsArray[] = '"'.$Item['param']['full_screen_cover'].'"';;
			$UpLoadHtml .= '
			var InputArray = new Array('.implode(',',$FullScreenCoverImgJsArray).');
			$("#FullScreenControl").AppUpload({InputName:"new_full_screen_cover",Multiple:true,InputExist:true,InputArray:InputArray});';

		}else{
			$UpLoadHtml .= '$("#FullScreenControl").AppUpload({InputName:"new_full_screen_cover",Multiple:true});';
		}

		if($Item['param']['ad_roll_bg_cover']){
			$AdRollBgCoverJsArray[] = '"'.$Item['param']['ad_roll_bg_cover'].'"';;
			$UpLoadHtml .= '
			var InputArray = new Array('.implode(',',$AdRollBgCoverJsArray).');
			$("#AdRollBgCover").AppUpload({InputName:"new_ad_roll_bg_cover",Multiple:true,InputExist:true,InputArray:InputArray});';

		}else{
			$UpLoadHtml .= '$("#AdRollBgCover").AppUpload({InputName:"new_ad_roll_bg_cover",Multiple:true});';
		}

		if($Item['param']['share_img']){
			$ShareImgJsArray[] = '"'.$Item['param']['share_img'].'"';;
			$UpLoadHtml .= '
			var InputArray = new Array('.implode(',',$ShareImgJsArray).');
			$("#ShareImgPhotoControl").AppUpload({InputName:"new_share_img",Multiple:true,InputExist:true,InputArray:InputArray});';

		}else{
			$UpLoadHtml .= '$("#ShareImgPhotoControl").AppUpload({InputName:"new_share_img",Multiple:true});';
		}

		echo $UploadConfig['CssJsHtml'];
		
		echo '
			<script>
			var content = UE.getEditor("content2",{autoHeightEnabled: false,autoFloatEnabled:false,enableAutoSave: false}); 
			var contentt = UE.getEditor("content3",{autoHeightEnabled: false,autoFloatEnabled:false,enableAutoSave: false}); 
			'.$UpLoadHtml.'
			</script> 	
		';

	}else{

		foreach($_GET['new_thumb'] as $Key => $Val) {
			$_GET['new_thumb'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}
		
		foreach($_GET['new_gift_img'] as $Key => $Val) {
			$_GET['new_gift_img'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}

		foreach($_GET['new_gift_list_bg'] as $Key => $Val) {
			$_GET['new_gift_list_bg'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}

		foreach($_GET['new_gift_list_money'] as $Key => $Val) {
			$_GET['new_gift_list_money'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}

		foreach($_GET['new_pedpacket_img'] as $Key => $Val) {
			$_GET['new_pedpacket_img'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}

		foreach($_GET['new_follow_qr'] as $Key => $Val) {
			$_GET['new_follow_qr'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}

		foreach($_GET['new_player_cover'] as $Key => $Val) {
			$_GET['new_player_cover'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}

		foreach($_GET['new_comment_bg'] as $Key => $Val) {
			$_GET['new_comment_bg'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}

		foreach($_GET['new_poster_ico'] as $Key => $Val) {
			$_GET['new_poster_ico'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}

		foreach($_GET['new_poster_bg'] as $Key => $Val) {
			$_GET['new_poster_bg'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}

		foreach($_GET['new_participant_reward_bg'] as $Key => $Val) {
			$_GET['new_participant_reward_bg'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}
		
		foreach($_GET['new_player_bottom_ad'] as $Key => $Val) {
			$player_bottom_ad[$Key]['img'] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
			$player_bottom_ad[$Key]['link'] = $_GET['new_player_bottom_ad_link'][$Key];
		}

		foreach($_GET['new_full_screen_cover'] as $Key => $Val) {
			$_GET['new_full_screen_cover'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}
		
		foreach($_GET['new_ad_roll_bg_cover'] as $Key => $Val) {
			$_GET['new_ad_roll_bg_cover'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}


		foreach($_GET['new_share_img'] as $Key => $Val) {
			$_GET['new_share_img'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}
		
		$Data['thumb'] = addslashes(strip_tags($_GET['new_thumb'][0]));
		$Data['title'] = addslashes(strip_tags($_GET['title']));
		$Data['content'] = addslashes($_GET['content']);//�豣��Html
		$Data['number_id'] = intval($_GET['number_id']);
		$Data['start_dateline'] = $_GET['start_dateline'] ? strtotime($_GET['start_dateline']) : '';
		$Data['end_dateline'] = $_GET['end_dateline'] ? strtotime($_GET['end_dateline']) : '';
		$Data['state'] = intval($_GET['state']);
		$Data['click'] = intval($_GET['click']);
		$Data['topdateline'] = $_GET['topdateline'] ? strtotime($_GET['topdateline']) : '';
		$Data['display'] = intval($_GET['display']);
		
		$Param['jump_url'] = addslashes(strip_tags($_GET['jump_url']));

		$Param['gift'] = intval($_GET['gift']);
		$Param['gift_list'] =  is_array($_GET['gift_list']) && isset($_GET['gift_list'])  ? $_GET['gift_list'] : '';
		$Param['gift_img'] = addslashes(strip_tags($_GET['new_gift_img'][0]));
		$Param['gift_list_bg'] = addslashes(strip_tags($_GET['new_gift_list_bg'][0]));
		$Param['gift_list_money'] = addslashes(strip_tags($_GET['new_gift_list_money'][0]));
		$Param['gift_title'] = addslashes(strip_tags($_GET['gift_title']));
		$Param['gift_list_title'] = addslashes(strip_tags($_GET['gift_list_title']));
		$Param['gift_comment'] = addslashes($_GET['gift_comment']);//�豣��Html
		$Param['participant_gift_comment'] = addslashes($_GET['participant_gift_comment']);//�豣��Html
		$Param['gift_log_content'] = addslashes($_GET['gift_log_content']);//�豣��Html
	
		$Param['pedpacket'] = intval($_GET['pedpacket']);
		$Param['pedpacket_img'] = addslashes(strip_tags($_GET['new_pedpacket_img'][0]));
		$Param['pedpacket_app'] = intval($_GET['pedpacket_app']);
		$Param['pedpacket_app_tips'] = addslashes(strip_tags($_GET['pedpacket_app_tips']));
		
		$Param['visit_limit'] = intval($_GET['visit_limit']);
		$Param['no_pay_comment'] = intval($_GET['no_pay_comment']);
		$Param['no_pay_comment_tips'] = addslashes(strip_tags($_GET['no_pay_comment_tips']));
		$Param['money'] = addslashes(strip_tags($_GET['money']));
		$Param['money_app'] = addslashes(strip_tags($_GET['money_app']));
		$Param['money_time'] = $_GET['money_time'] ? intval($_GET['money_time']) * 1000 : '';
		$Param['money_tips'] = addslashes($_GET['money_tips']);//�豣��Html
		$Param['money_app_tips'] = addslashes($_GET['money_app_tips']);//�豣��Html
		$Param['money_title'] = addslashes(strip_tags($_GET['money_title']));
		$Param['money_btn'] = addslashes(strip_tags($_GET['money_btn']));
		$Param['money_app_btn'] = addslashes(strip_tags($_GET['money_app_btn']));
		
		$Param['pass'] = addslashes(strip_tags($_GET['pass']));
		$Param['pass_time'] = intval($_GET['pass_time']);
		
		$Param['password'] = addslashes(strip_tags($_GET['password']));
		$Param['navs'] = addslashes(strip_tags($_GET['navs']));
		$Param['navs_array'] = array_filter(TextareaArray($_GET['navs']));
		$Param['nav_follow'] = intval($_GET['nav_follow']);
		$Param['follow_pop_title'] = addslashes(strip_tags($_GET['follow_pop_title']));
		$Param['follow_pop_wx_content'] = addslashes($_GET['follow_pop_wx_content']);
		$Param['follow_pop_content'] = addslashes($_GET['follow_pop_content']);
		$Param['follow_qr'] = addslashes(strip_tags($_GET['new_follow_qr'][0]));
		$Param['follow_bg_color'] = addslashes(strip_tags($_GET['follow_bg_color']));

		$Param['live_name_id'] = addslashes(strip_tags($_GET['live_name_id']));
		foreach(array_filter(TextareaArray($_GET['live_name_id'])) as $Key => $Val){
			$Array = array_filter(explode('|',$Val));
			$ArrayTo['name'] = $Array['0'];
			$ArrayTo['face'] = $Array['1'];
			$Param['live_name_id_array'][$Key] = $ArrayTo;
		};
		$Param['info_auto_time'] = $_GET['info_auto_time'] ? intval($_GET['info_auto_time']) * 1000 : 10000;
		$Param['info_limit'] = intval($_GET['info_limit']);
		
		$Param['content2'] = addslashes($_GET['content2']);//�豣��Html
		$Param['content3'] = addslashes($_GET['content3']);//�豣��Html
		$Param['iframe1'] = addslashes(strip_tags($_GET['iframe1']));
		$Param['iframe2'] = addslashes(strip_tags($_GET['iframe2']));
		
		$Param['comment_prohibit'] = intval($_GET['comment_prohibit']);
		$Param['comment_prohibit_tips'] = addslashes(strip_tags($_GET['comment_prohibit_tips']));
		$Param['comment_display'] = intval($_GET['comment_display']);
		$Param['comment_auto_time'] = $_GET['comment_auto_time'] ? intval($_GET['comment_auto_time']) * 1000 : 10000;
		
		$Param['comment_time'] = intval($_GET['comment_time']);
		$Param['comment_time_tips'] = addslashes(strip_tags($_GET['comment_time_tips']));
		$Param['comment_input_btn'] = addslashes(strip_tags($_GET['comment_input_btn']));
		$Param['comment_input_tips'] = addslashes(strip_tags($_GET['comment_input_tips']));
		$Param['comment_input_null_tips'] = addslashes(strip_tags($_GET['comment_input_null_tips']));
		$Param['comment_limit'] = intval($_GET['comment_limit']);
		
		$Param['comment_forbidden_words'] = addslashes(strip_tags($_GET['comment_forbidden_words']));
		$Param['comment_forbidden_words_array'] = array_filter(explode("\r\n",$_GET['comment_forbidden_words']));
		$Param['comment_forbidden_words_tips'] = addslashes(strip_tags($_GET['comment_forbidden_words_tips']));
		$Param['comment_roll'] = addslashes(strip_tags($_GET['comment_roll']));
		$Param['comment_bg'] = addslashes(strip_tags($_GET['new_comment_bg'][0]));

		$Param['ranking_nav'] = addslashes(strip_tags($_GET['ranking_nav']));//�豣��Html
		$Param['ranking_nav_array'] = array_filter(TextareaArray($_GET['ranking_nav']));
		$Param['ranking_limit'] = intval($_GET['ranking_limit']);
		
		$Param['participant_reward_percentage'] = intval($_GET['participant_reward_percentage']);
		$Param['participant_reward_bg'] = addslashes(strip_tags($_GET['new_participant_reward_bg'][0]));
		$Param['participant_reward_top'] = intval($_GET['participant_reward_top']);
		$Param['participant_mobile'] = intval($_GET['participant_mobile']);
		$Param['participant_mobile_bg'] = addslashes(strip_tags($_GET['participant_mobile_bg']));
		$Param['participant_mobile_btn_text'] = addslashes(strip_tags($_GET['participant_mobile_btn_text']));
		$Param['bumber_bg'] = addslashes(strip_tags($_GET['bumber_bg']));
		$Param['reward_btn_bg_color'] = addslashes(strip_tags($_GET['reward_btn_bg_color']));
		$Param['reward_btn_text'] = addslashes(strip_tags($_GET['reward_btn_text']));
		
		$Param['poster'] = intval($_GET['poster']);
		$Param['poster_ico'] = addslashes(strip_tags($_GET['new_poster_ico'][0]));
		$Param['poster_bg'] = addslashes(strip_tags($_GET['new_poster_bg'][0]));
		$Param['poster_title_color'] = addslashes(strip_tags($_GET['poster_title_color']));
		$Param['poster_invite'] = intval($_GET['poster_invite']);
		$Param['qr_code_switch'] = intval($_GET['qr_code_switch']);
		//$Param['poster_bg_base'] = base64_encode(dfsockopen(strpos($Param['poster_bg'],'http') !== false ? $Param['poster_bg'] : $_G['siteurl'].$Param['poster_bg']));
		//$Param['poster_bg_base'] = $Param['poster_bg_base'] ? $Param['poster_bg_base'] : base64_encode(file_get_contents($Param['poster_bg']));
		//$Param['poster_bg_base'] = $Param['poster_bg_base'] ? $Param['poster_bg_base'] : base64_encode(CurlGet(str_replace('https','http',$Param['poster_bg'])));
		//$Param['poster_cover_base'] = base64_encode(dfsockopen(strpos($Data['thumb'],'http') !== false ? $Data['thumb'] : $_G['siteurl'].$Data['thumb']));
		//$Param['poster_cover_base'] = $Param['poster_cover_base'] ? $Param['poster_cover_base'] : base64_encode(file_get_contents($Data['thumb']));
		//$Param['poster_cover_base'] = $Param['poster_cover_base'] ? $Param['poster_cover_base'] : base64_encode(CurlGet(str_replace('https','http',$Data['thumb'])));

		$Param['player_cover'] = addslashes(strip_tags($_GET['new_player_cover'][0]));
		$Param['player_weight'] = intval($_GET['player_weight']);
		$Param['player_height'] = intval($_GET['player_height']);
		$Param['player_type'] = addslashes(strip_tags($_GET['player_type']));
		$Param['rtmp'] = addslashes(strip_tags($_GET['rtmp']));
		$Param['m3u8'] = addslashes(strip_tags($_GET['m3u8']));
		$Param['app_m3u8'] = addslashes(strip_tags($_GET['app_m3u8']));
		$Param['app_m3u8_tips'] = addslashes(strip_tags($_GET['app_m3u8_tips']));

		$Param['player_bottom_ad'] =  is_array($player_bottom_ad) && isset($player_bottom_ad)  ? $player_bottom_ad : '';
		$Param['ad_roll_switch'] = intval($_GET['ad_roll_switch']);
		$Param['ad_roll'] = addslashes(strip_tags($_GET['ad_roll']));
		$Param['ad_roll_url'] = addslashes(strip_tags($_GET['ad_roll_url']));
		$Param['ad_roll_color'] = addslashes(strip_tags($_GET['ad_roll_color']));
		$Param['ad_roll_bg_color'] = addslashes(strip_tags($_GET['ad_roll_bg_color']));
		$Param['ad_roll_bg_cover'] = addslashes(strip_tags($_GET['new_ad_roll_bg_cover'][0]));
		
		$Param['iframe_url'] = addslashes(strip_tags($_GET['iframe_url']));
		$Param['analysis_url_switch'] = intval($_GET['analysis_url_switch']);
		$Param['room_id'] = addslashes(strip_tags($_GET['room_id']));
		$Param['sid'] = addslashes(strip_tags($_GET['sid']));
		$Param['ssid'] = addslashes(strip_tags($_GET['ssid']));
		$Param['temp_id'] = addslashes(strip_tags($_GET['temp_id']));
		$Param['qq_room_id'] = addslashes(strip_tags($_GET['qq_room_id']));
		$Param['douyu_room_id'] = addslashes(strip_tags($_GET['douyu_room_id']));
		
		$Param['fixed_nav_app'] = intval($_GET['fixed_nav_app']);
		$Param['app_comment'] = intval($_GET['app_comment']);
		$Param['app_commen_tips'] = addslashes(strip_tags($_GET['app_commen_tips']));
		$Param['app_play_back'] = intval($_GET['app_play_back']);
		$Param['app_play_back_tips'] = addslashes(strip_tags($_GET['app_play_back_tips']));
		
		$Param['full_screen'] = intval($_GET['full_screen']);
		$Param['full_screen_cover'] = addslashes(strip_tags($_GET['new_full_screen_cover'][0]));
		$Param['full_screen_url'] = addslashes(strip_tags($_GET['full_screen_url']));
		$Param['full_screen_time'] = $_GET['full_screen_time'] ? intval($_GET['full_screen_time']) : 5;

		$Param['admin_participant_reward_uids'] = addslashes(strip_tags($_GET['admin_participant_reward_uids']));
		$Param['admin_info_uids'] = addslashes(strip_tags($_GET['admin_info_uids']));
		$Param['admin_uids'] = addslashes(strip_tags($_GET['admin_uids']));

		$Param['share_title'] = addslashes(strip_tags($_GET['share_title']));
		$Param['share_desc'] = addslashes(strip_tags($_GET['share_desc']));
		$Param['share_img'] = addslashes(strip_tags($_GET['new_share_img'][0]));
		$Param['color'] = addslashes(strip_tags($_GET['color']));
		$Param['fcolor'] = addslashes(strip_tags($_GET['fcolor']));	
		
		$Param['visit'] = intval($_GET['visit']);
		$Param['PcQrSwitch'] = intval($_GET['PcQrSwitch']);
		$Param['PcQrText'] = addslashes(strip_tags($_GET['PcQrText']));	

		$Param['click_rand'] = addslashes(strip_tags($_GET['click_rand']));
		
		foreach($_FILES as $file_key => $file_value){
			if(strpos($file_key,'new_') !== false){
				$key = str_replace(array('TMPnew_','new_'),'',$file_key);
				if($_FILES[$file_key]['size']){
					$FileCode = Fn_Upload($_FILES[$file_key]);
					if($FileCode['Errorcode']){
						cpmsg($Fn_Admin->Config['LangVar']['ImgErr'],'','error');
						exit();
					}else{
						$Param[$key] = $FileCode['Path'];
					}
				}else{
					$file_key = str_replace(array('TMPnew_'),array('new_'),$file_key);
					if(!preg_match('/.*(\.png|\.jpg|\.jpeg|\.gif)$/',$_GET[$file_key]) && $_GET[$file_key]){
						cpmsg($Fn_Admin->Config['LangVar']['ImgErr'],'','error');
						exit();
					}else{
						$Param[$key] = addslashes(strip_tags($_GET[$file_key]));
					}
				}
			}
		}
		
		$Data['param'] = serialize($Param);
		
		if($Item && !$_GET['copy']){
			$Data['updateline'] = strtotime($_GET['updateline']);
			GetInsertDoLog('edit_live','fn_'.$_GET['mod'],array('id'=>$Id));//������¼
			DB::update($Fn_Live->TableLive,$Data,'id = '.$Id);
		}else{
			$Data['dateline'] = $Data['updateline'] = time();
			$Id = DB::insert($Fn_Live->TableLive,$Data,true);
			GetInsertDoLog('add_live','fn_'.$_GET['mod'],array('id'=>$Id));//������¼
		}
		
		fn_cpmsg($Fn_Live->Config['LangVar']['UpdateOk'],$Fn_Admin->Config['IframeItemUrl'].'&submodel=list','succeed');
	
	}
}


/* �б� */
function GetModulesList($Page,$Limit,$Where=null,$Order){
	global $Fn_Live;
	$FetchSql = 'SELECT N.title as number_title,L.* FROM '.DB::table($Fn_Live->TableLive).' L LEFT JOIN `'.DB::table($Fn_Live->TableNumber).'` N on N.id = L.number_id '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}

/* ���� */
function GetModulesCount($Where=null){
	global $Fn_Live;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_Live->TableLive).' L '.$Where;
	return DB::result_first($FetchSql);//��������
}

?>