<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('live_all') && !$Fn_Admin->CheckUserGroup('live_gift_log_listt')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$SubModel = in_array($_GET['submodel'], array('list','add')) ? $_GET['submodel'] : 'list';
$Fn_Admin->Config['IframeSubModelUrl'] = $Fn_Admin->Config['IframeItemUrl'].'&submodel='.$SubModel;
$NavClass = array($SubModel=>'Hover');

if($SubModel == 'list'){//�б�
	$Do = in_array($_GET['do'], array('Del','Branch')) ? $_GET['do'] : 'submodel_list';
	//�����ֶ�
	$SearField =array('page','keyword','display','order','lid','gift_id','be_reward_id');
	foreach($SearField as $Val) {
		$SearArray[$Val] = $_GET[$Val] || in_array($_GET[$Val],array('0')) ? $_GET[$Val] : '';
	}
	//�����ֶ� End
	$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeSubModelUrl'].'&'.http_build_query($SearArray);


	if($Do == 'submodel_list'){
		if(!submitcheck('Submit')) {
			$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
			$Where = '';
			$Order = $_GET['order'] ? 'L.'.addslashes(dhtmlspecialchars($_GET['order'])) : 'L.id';
			
			if($_GET['keyword']){
				$_GET['keyword'] = str_replace(array('%','_'),array('',''),$_GET['keyword']);
				$Where .= ' and (L.username like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or L.uid = '.intval($_GET['keyword']).' or L.id = '.intval($_GET['keyword']).' )';
			}

			if($_GET['lid']){
				$Where .= ' and L.lid = '.intval($_GET['lid']);
			}
			
			if($_GET['gift_id']){
				$Where .= ' and L.gift_id = '.intval($_GET['gift_id']);
			}

			if($_GET['be_reward_id']){
				$Where .= ' and L.be_reward_id = '.intval($_GET['be_reward_id']);
			}


			$Where = preg_replace('/and/','where',$Where,1);
			$Limit = 20;
			$Page = $_GET['page']?intval($_GET['page']):1;
			/* ��ѯ���� End */
			
			/* ģ����� */	
			showtagheader('div', 'row', true,'row');
			showtagheader('div', 'col-12', true,'col-12');
			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-body', true,'box-body');
			/* ���� */
			$OrderSelected = array($_GET['order']=>' selected');

			echo <<<SEARCH
			<form method="post" autocomplete="off" action="$SearUrl">
				<div class="FormSearchTo" style="margin-bottom:0;">
					<table cellspacing="4" cellpadding="4">
						<tr>
							<th>{$Fn_Live->Config['LangVar']['LiveId']}</th><td><input type="text" class="input form-control w80" name="lid" value="{$_GET['lid']}">
							</td>
							<th>{$Fn_Live->Config['LangVar']['GiftId']}</th><td><input type="text" class="input form-control w80" name="gift_id" value="{$_GET['gift_id']}">
							</td>
							<th>{$Fn_Live->Config['LangVar']['ParticipantID']}</th><td><input type="text" class="input form-control w80" name="be_reward_id" value="{$_GET['be_reward_id']}">
							</td>
							<th>{$Fn_Live->Config['LangVar']['KeywordTitle']}</th><td><input type="text" class="input form-control w200" name="keyword" value="{$_GET['keyword']}">
							</td>
							<th>{$Fn_Admin->Config['LangVar']['Order']}</th><td>
							<select name="order" class="form-control w120">
								<option value="dateline"{$OrderSelected['dateline']}>{$Fn_Admin->Config['LangVar']['OrderArray']['dateline']}</option>
							</select>
							&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Admin->Config['LangVar']['SearchSubmit']}" class="btn btn-info" type="submit">
							</td>
						</tr>
					</table>
				</div>
			</form>
SEARCH;
			/* ���� End */
			showtagheader('div', 'table-responsive', true,'table-responsive');
			showformheader($FormUrl,'enctype="multipart/form-data"');
			showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');

			showsubtitle(array(
				'ID',
				'UID/'.$Fn_Live->Config['LangVar']['UserNameTitle'],
				$Fn_Live->Config['LangVar']['ParticipantID'],
				$Fn_Live->Config['LangVar']['ParticipantName'],
				$Fn_Live->Config['LangVar']['Title'],
				$Fn_Live->Config['LangVar']['GivingDeGift'],
				$Fn_Live->Config['LangVar']['Money'],
				$Fn_Live->Config['LangVar']['BranchMoney'],
				$Fn_Live->Config['LangVar']['BranchState'],
				$Fn_Live->Config['LangVar']['TimeTitle'],
				$Fn_Live->Config['LangVar']['OperationTitle']
			),'header tbm tc');

			$ModulesList = GetModulesList($Page,$Limit,$Where,$Order);
			foreach ($ModulesList as $Module) {
				
				showtablerow('', array('class="tc w50"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
					'<input type="checkbox" class="filled-in" id="checkbox_'.$Module['id'].'" name="delete[]" value="'.$Module['id'].'"><label for="checkbox_'.$Module['id'].'">'.$Module['id'].'</label>',
					$Module['uid'] ? $Module['uid'].'/'.$Module['username'] : '',
					$Module['be_reward_id'] && $Module['name'] ? $Module['be_reward_id'] : '',
					$Module['name'] ? $Module['name'] : '',
					'&nbsp;&nbsp;<a href="'.$Fn_Live->Config['ViewUrl'].$Module['id'].'" target="_blank">'.$Module['title'].'</a>',
					$Fn_Live->Config['LangVar']['GiftId'].': '.$Module['gift_id'].'<br>'.$Fn_Live->Config['LangVar']['Title'].': '.$Module['gift_title'].( $Module['gift_ico'] ? '<img src="'.$Module['gift_ico'].'" height="20px;">' : '').'<br>',
					$Module['money'],
					$Module['branch_money'] ? $Module['branch_money'] : '',
					$Module['name'] ? (!$Module['branch_state'] ? '<span class="label bg-secondary">'.$Fn_Live->Config['LangVar']['BranchState0'].'</span>' : '<span class="label bg-danger">'.$Fn_Live->Config['LangVar']['BranchState1'].'</span>') : '',
					date('Y-m-d H:i',$Module['dateline']),
					($Module['name'] && !$Module['branch_state'] ? '<a href="'.$OpCpUrl.'&do=Branch&gid='.$Module['id'].'&formhash='.FORMHASH.'" class="btn btn-sm btn-info-outline">'.$Fn_Live->Config['LangVar']['Branch'].'</a>&nbsp;&nbsp;' : '').'<a href="'.$OpCpUrl.'&do=Del&gid='.$Module['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$Fn_Live->Config['LangVar']['DelTitle'].'</a>',
				));
			}

			showsubmit('Submit','&#31435;&#21363;&#25552;&#20132;','del','','',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));

			showtablefooter(); /*dism��taobao��com*/
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			/* ģ�����End */	
		}else{
			if(!$Fn_Admin->CheckUserGroup('live_all') && !$Fn_Admin->CheckUserGroup('live_gift_log_list')){//Ȩ���ж�
				fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
				exit();
			}

			if(isset($_GET['delete']) && is_array($_GET['delete'])){
				foreach($_GET['delete'] as $Key => $Val) {
					$Val = intval($Val);
					$Item = DB::fetch_first('SELECT * FROM '.DB::table($Fn_Live->TableGiftLog).' where id = '.$Val);
					DB::delete($Fn_Live->TableGiftLog,'id ='.$Val);
					DB::delete($Fn_Live->TableComment,'id ='.$Item['father_cid']);
				}

				GetInsertDoLog('del_gift_log_live','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete'])));//������¼

				fn_cpmsg($Fn_Live->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
			}else{
				fn_cpmsg($Fn_Live->Config['LangVar']['DelErr'],'','error');
			}
				
		}
	}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['gid']){
		if(!$Fn_Admin->CheckUserGroup('live_all') && !$Fn_Admin->CheckUserGroup('live_gift_log_list')){//Ȩ���ж�
			fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
			exit();
		}
		$Id = intval($_GET['gid']);
		$Item = DB::fetch_first('SELECT * FROM '.DB::table($Fn_Live->TableGiftLog).' where id = '.$Id);
		DB::delete($Fn_Live->TableGiftLog,'id ='.$Id);
		DB::delete($Fn_Live->TableComment,'id ='.$Item['father_cid']);
		GetInsertDoLog('del_gift_log_live','fn_'.$_GET['mod'],array('id'=>$Id));//������¼
		fn_cpmsg($Fn_Admin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
	}else if($Do == 'Branch' && $_GET['formhash'] == formhash() && $_GET['gid']){
		$Id = intval($_GET['gid']);
		$Item = DB::fetch_first('SELECT * FROM '.DB::table($Fn_Live->TableGiftLog).' where id = '.$Id);
		$ParticipantItem = $Fn_Live->GetViewParticipant($Item['be_reward_id']);
		$HBState = false;
		if($Config['PluginVar']['AppType'] == 2){//ǧ�������
			$ReturnBalance = $Fn_Live->QHApp->GetBalanceAdd($ParticipantItem['uid'],$Item['branch_money']);
			if($ReturnBalance['state'] == 200){
				$HBState = true;
			}
		}else if($Config['PluginVar']['AppType'] == 1){//���׷����
			$ReturnBalance = $Fn_Live->MagApp->GetMagAccountTransfer($ParticipantItem['uid'],$Item['branch_money'],$Fn_Live->Config['LangVar']['GiftSharing']);
			if($ReturnBalance['state'] == 200){
				$HBState = true;
			};
		}else{//����Ǯ��
			if(FnWallet::WalletLogInsertBy($ParticipantItem['uid'],$Fn_Live->Config['LangVar']['GiftSharing'],$Item['branch_money'],1,'fn_live')){
				$HBState = true;
			}
		}
		if($HBState){
			DB::update($Fn_Live->TableGiftLog,array('branch_state'=>1),'id='.$Id);
			fn_cpmsg($Fn_Live->Config['LangVar']['BranchOk'],$CpMsgUrl,'succeed');
		}else{
			fn_cpmsg($Fn_Live->Config['LangVar']['BranchErr'],'','error');
		}
	}
}


/* �б� */
function GetModulesList($Page,$Limit,$Where=null,$Order){
	global $Fn_Live;
	$FetchSql = 'SELECT P.name,G.title as gift_title,G.ico as gift_ico,LL.title,L.* FROM '.DB::table($Fn_Live->TableGiftLog).' L LEFT JOIN `'.DB::table($Fn_Live->TableLive).'` LL on LL.id = L.lid LEFT JOIN `'.DB::table($Fn_Live->TableGift).'` G on G.id = L.gift_id LEFT JOIN `'.DB::table($Fn_Live->TableParticipant).'` P on P.id = L.be_reward_id '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}

/* ���� */
function GetModulesCount($Where=null){
	global $Fn_Live;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_Live->TableGiftLog).' L '.$Where;
	return DB::result_first($FetchSql);//��������
}

?>