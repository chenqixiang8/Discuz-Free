<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if(!$Fn_Admin->CheckUserGroup('live_all') && !$Fn_Admin->CheckUserGroup('live_config')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

@require_once libfile('function/cache');
@require_once libfile('function/core','plugin/fn_assembly');

$setting_name = 'fn_'.$_GET['mod'].'_setting';
loadcache($setting_name);
$common_setting = $_G['cache'][$setting_name];
$setting = $common_setting = array_filter($common_setting) ? $common_setting : array();
foreach($setting as $key => $value) {
	$setting[$key] = is_array($value) ? $value : stripslashes($value);
}
$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeItemUrl'];

if(!submitcheck('DetailSubmit')) {
	//ͼƬ�ϴ�
	if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_assembly/class/class_upload.php')){
		@require_once libfile('class/upload','plugin/fn_assembly');
		$UploadConfig = fn_upload::Config();
	}

	showtagheader('div', 'box', true,'box');
	showformheader($FormUrl,'enctype');
	if(in_array($Config['PluginVar']['AppType'],array('1','2'))){
		$AppNav = '<li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#app" role="tab" aria-expanded="false"><span class="hidden-sm-up"><i class="ion-email"></i></span> <span class="hidden-xs-down">&#65;&#80;&#80;&#35774;&#32622;</span></a> </li>';
	}
	echo <<<HTML
		<ul class="nav nav-tabs customtab" role="tablist">
          <li class="nav-item"> <a class="nav-link active" data-toggle="tab" href="#basics" role="tab" aria-expanded="true"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#22522;&#30784;&#35774;&#32622;</span></a> </li>
		  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#wx" role="tab" aria-expanded="false"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#20844;&#20247;&#21495;&#35774;&#32622;</span></a> </li>
		  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#share" role="tab" aria-expanded="false"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#20998;&#20139;&#35774;&#32622;</span></a> </li>
		  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#color" role="tab" aria-expanded="false"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#39068;&#33394;&#35774;&#32622;</span></a> </li>
		  {$AppNav}
        </ul>
HTML;

	showtagheader('div', 'box-body', true,'box-body');

	showtagheader('div', 'tab-content', true,'tab-content');

	echo <<<HTML
	<!-- ��������  -->
	<div class="tab-pane active" id="basics" role="tabpanel" aria-expanded="true">
HTML;
	
	showsetting('&#26631;&#39064;', 'setting[Title]', $setting['Title'] ? $setting['Title'] : '&#12304;&#39134;&#40479;&#12305;&#30452;&#25773;', 'text');

	showsetting('&#31105;&#27490;&#39046;&#32418;&#21253;&#85;&#73;&#68;', 'setting[ProhibitRedpacketUids]', $setting['ProhibitRedpacketUids'], 'text','','','&#26684;&#24335;&#65306;&#49;&#44;&#50;&#44;&#51;&#32;&#65281;&#65281;&#65281;');

	showsetting('&#31105;&#27490;&#39046;&#32418;&#21253;&#25552;&#31034;&#35821;', 'setting[ProhibitRedpacketTips]', $setting['ProhibitRedpacketTips'] ? $setting['ProhibitRedpacketTips'] : '&#24744;&#30340;&#36134;&#21495;&#19981;&#20801;&#35768;&#39046;&#32418;&#21253;&#65281;&#65281;&#65281;', 'text');

	showsetting('&#35299;&#26512;&#38142;&#25509;&#25773;&#25918;&#22120;', 'setting[AnalysisUrl]', $setting['AnalysisUrl']	, 'text');

	showsetting('&#31532;&#19977;&#26041;&#32479;&#35745;&#20195;&#30721;', 'setting[Statistics]', $setting['Statistics'], 'textarea');

	echo <<<HTML
	</div>
	<!-- �������� end  -->
HTML;

	echo <<<HTML
	<!-- ΢������  -->
	<div class="tab-pane" id="wx" role="tabpanel" aria-expanded="false">
	<div class="alert alert-primary" role="alert">&#21442;&#25968;&#20108;&#32500;&#30721;&#20316;&#29992;&#65306;&#29983;&#25104;&#28023;&#25253;&#30340;&#20108;&#32500;&#30721;&#20026;&#20844;&#20247;&#21495;&#30340;&#20108;&#32500;&#30721;&#65292;&#20851;&#27880;&#21518;&#20250;&#33258;&#21160;&#25512;&#36865;&#38142;&#25509;<br>&#28201;&#39336;&#25552;&#37266;&#65306;&#22914;&#26524;&#19981;&#38656;&#35201;&#21442;&#25968;&#20108;&#32500;&#30721;&#65292;&#21487;&#24573;&#30053;&#35813;&#35774;&#32622;</div>
HTML;
	
	showsetting('&#24494;&#20449;&#65;&#112;&#112;&#73;&#100;', 'setting[WxAppid]', $setting['WxAppid'], 'text');
	showsetting('&#24494;&#20449;&#83;&#101;&#99;&#114;&#101;&#116;', 'setting[WxSecret]', $setting['WxSecret'], 'text');
	showsetting('&#24494;&#20449;&#20196;&#29260;&#40;&#84;&#111;&#107;&#101;&#110;&#41;', 'setting[wechat_token]', $setting['wechat_token'], 'text','','','&#33719;&#21462;&#26041;&#24335;&#65306;&#20844;&#20247;&#21495;&#21518;&#21488;&#45;&#12299;&#22522;&#26412;&#37197;&#32622;&#45;&#12299;&#26381;&#21153;&#22120;&#37197;&#32622;&#45;&#12299;&#20196;&#29260;&#40;&#84;&#111;&#107;&#101;&#110;&#41;');
	
	echo <<<HTML
	</div>
	<!-- ΢������ end  -->
HTML;

	echo <<<HTML
	<!-- ��������  -->
	<div class="tab-pane" id="share" role="tabpanel" aria-expanded="false">
HTML;
	
	showsetting('&#20998;&#20139;&#26631;&#39064;', 'setting[WxTitle]', $setting['WxTitle'] ? $setting['WxTitle'] : '&#12304;&#39134;&#40479;&#12305;&#30452;&#25773;', 'text');

	showsetting('&#20998;&#20139;&#25551;&#36848;', 'setting[WxDes]', $setting['WxDes'] ? $setting['WxDes'] : '&#12304;&#39134;&#40479;&#12305;&#30452;&#25773;', 'textarea');

	$setting['WxImg'] = $setting['WxImg'] ? $setting['WxImg'] : '/source/plugin/fn_live/static/images/ico.png';
	$WxImgHtml = '<a href="'.$setting['WxImg'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['WxImg'].'" height="55"/></a>&#23610;&#23544;&#49;&#48;&#48;&#32;&#42;&#32;&#49;&#48;&#48;';
	showsetting('&#20998;&#20139;&#22270;&#29255;', 'new_WxImg',$setting['WxImg'], 'filetext', '', 0, $WxImgHtml);

	echo <<<HTML
	</div>
	<!-- �������� end  -->
HTML;

	echo <<<HTML
	<!-- ��ɫ����  -->
	<div class="tab-pane" id="color" role="tabpanel" aria-expanded="false">
HTML;

	showsetting('&#20027;&#39064;&#39068;&#33394;', 'setting[Color]', $setting['Color'] ? $setting['Color'] : '#20a0ff', 'color');

	showsetting('&#21103;&#20027;&#39064;&#39068;&#33394;', 'setting[FColor]', $setting['FColor'] ? $setting['FColor'] : '#ff0000', 'color');

	echo <<<HTML
	</div>
	<!-- ��ɫ���� end  -->
HTML;
	
	if(in_array($Config['PluginVar']['AppType'],array('1','2'))){

	echo <<<HTML
	<!-- APP����  -->
	<div class="tab-pane" id="app" role="tabpanel" aria-expanded="false">
HTML;
		
	$setting['AppIcoPath'] = $setting['AppIcoPath'] ? $setting['AppIcoPath'] : '/source/plugin/fn_live/static/images/app.png';
	$AppIcoPathHtml = '<a href="'.$setting['AppIcoPath'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['AppIcoPath'].'" height="55"/></a>&#23610;&#23544;&#49;&#48;&#48;&#32;&#42;&#32;&#49;&#48;&#48;';
	showsetting('&#65;&#80;&#80;&#19979;&#36733;&#22270;&#26631;', 'new_AppIcoPath',$setting['AppIcoPath'], 'filetext', '', 0, $AppIcoPathHtml);

	showtagheader('div', 'mag_app_table', $Config['PluginVar']['AppType'] == 1 ? true : '','mag_app_table');
		showsetting('&#39532;&#30002;&#83;&#101;&#99;&#114;&#101;&#116;', 'setting[MagSecret]', $setting['MagSecret'], 'text','','','&#19981;&#22635;&#21017;&#32487;&#25215;&#12304;&#20840;&#23616;&#35774;&#32622;&#12305;&#30340;&#35774;&#32622;');
		showsetting('&#39532;&#30002;&#21161;&#25163;&#32;&#83;&#101;&#99;&#114;&#101;&#116;', 'setting[MagAssistantSecret]', $setting['MagAssistantSecret'], 'text','','','&#19981;&#22635;&#21017;&#32487;&#25215;&#12304;&#20840;&#23616;&#35774;&#32622;&#12305;&#30340;&#35774;&#32622;');
		showsetting('&#39532;&#30002;&#21161;&#25163;&#25512;&#36865;', 'setting[MagAssistantPush]', $setting['MagAssistantPush'], 'radio','','','&#19981;&#22635;&#21017;&#32487;&#25215;&#12304;&#20840;&#23616;&#35774;&#32622;&#12305;&#30340;&#35774;&#32622;');
	showtagfooter('div');
	
	showtagheader('div', 'qf_app_table', $Config['PluginVar']['AppType'] == 2 ? true : '','qf_app_table');
		showsetting('&#21315;&#24070;&#25903;&#20184;&#35746;&#21333;&#31867;&#22411;&#73;&#68;', 'setting[qf_type]', $setting['qf_type'], 'text','','','&#19981;&#22635;&#21017;&#32487;&#25215;&#12304;&#20840;&#23616;&#35774;&#32622;&#12305;&#30340;&#35774;&#32622;');
		showsetting('&#21315;&#24070;&#25910;&#20837;&#35746;&#21333;&#31867;&#22411;&#73;&#68;', 'setting[qf_sr_type]', $setting['qf_sr_type'], 'text','','','&#19981;&#22635;&#21017;&#32487;&#25215;&#12304;&#20840;&#23616;&#35774;&#32622;&#12305;&#30340;&#35774;&#32622;');
	showtagfooter('div');

	echo <<<HTML
	</div>
	<!-- APP���� end  -->
HTML;
	}

	showsubmit('DetailSubmit', '&#20445;&#23384;&#37197;&#32622;');
	showtagfooter('div');
	showtagfooter('div');
	showformfooter(); /*Dism_taobao-com*/
	showtagfooter('div');

	
}else{
	
	foreach($_GET['setting'] as $key => $value) {
		$setting[$key] = is_array($value) ? $value : addslashes($value);
	}

	foreach($_FILES as $file_key => $file_value){
		if(strpos($file_key,'new_') !== false){
			$key = str_replace(array('TMPnew_','new_'),'',$file_key);
			if($_FILES[$file_key]['size']){
				$FileCode = Fn_Upload($_FILES[$file_key]);
				if($FileCode['Errorcode']){
					cpmsg($Fn_Admin->Config['LangVar']['ImgErr'],'','error');
					exit();
				}else{
					$setting[$key] = $FileCode['Path'];
				}
			}else{
				$file_key = str_replace(array('TMPnew_'),array('new_'),$file_key);
				if(!preg_match('/.*(\.png|\.jpg|\.jpeg|\.gif)$/',$_GET[$file_key]) && $_GET[$file_key]){
					cpmsg($Fn_Admin->Config['LangVar']['ImgErr'],'','error');
					exit();
				}else{
					$setting[$key] = addslashes(strip_tags($_GET[$file_key]));
				}
			}
		}
	}
	savecache($setting_name,$setting);
	fn_cpmsg($Fn_Admin->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
	exit();

}
//From: Dism_taobao_com
?>