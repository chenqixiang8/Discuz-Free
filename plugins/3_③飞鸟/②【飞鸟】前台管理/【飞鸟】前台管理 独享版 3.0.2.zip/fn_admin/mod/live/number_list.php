<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('live_all') && !$Fn_Admin->CheckUserGroup('live_number_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$SubModel = in_array($_GET['submodel'], array('list','add')) ? $_GET['submodel'] : 'list';
$Fn_Admin->Config['IframeSubModelUrl'] = $Fn_Admin->Config['IframeItemUrl'].'&submodel='.$SubModel;
$NavClass = array($SubModel=>'btn-info Hover');

//����
echo <<<Nav
<div class="SubModelNav">
  <ul>
	<li class="{$NavClass['list']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=list" target="_self">{$Fn_Admin->Config['LangVar']['LiveLeftNavArray'][$_GET['item']]}</a></li>
    <li class="{$NavClass['add']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=add" target="_self">{$Fn_Admin->Config['LangVar']['AddEditTitle']}</a></li>
  </ul>
  <div class="both"></div>
</div>
Nav;

if($SubModel == 'list'){//�б�
	$Do = in_array($_GET['do'], array('Refresh','Del','Display')) ? $_GET['do'] : 'submodel_list';
	//�����ֶ�
	$SearField =array('page','keyword','display','order');
	foreach($SearField as $Val) {
		$SearArray[$Val] = $_GET[$Val] || in_array($_GET[$Val],array('0')) ? $_GET[$Val] : '';
	}
	//�����ֶ� End
	$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeSubModelUrl'].'&'.http_build_query($SearArray);


	if($Do == 'submodel_list'){
		if(!submitcheck('Submit')) {
			$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
			$Where = '';
			$Order = $_GET['order'] ? 'N.'.addslashes(dhtmlspecialchars($_GET['order'])) : 'N.id';
			
			if($_GET['keyword']){
				$_GET['keyword'] = str_replace(array('%','_'),array('',''),$_GET['keyword']);
				$Where .= ' and (N.title like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or N.content like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\')  or N.id = '.intval($_GET['keyword']).' )';
			}
		

			if(in_array($_GET['display'],array('0','1'))){
				$Where .= ' and N.display = '.intval($_GET['display']);
			}

			$Where = preg_replace('/and/','where',$Where,1);
			$Limit = 20;
			$Page = $_GET['page']?intval($_GET['page']):1;
			/* ��ѯ���� End */

			/* ģ����� */	
			showtagheader('div', 'row', true,'row');
			showtagheader('div', 'col-12', true,'col-12');
			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-body', true,'box-body');
			/* ���� */
			$DisplaySelected = array($_GET['display']=>' selected');
			$OrderSelected = array($_GET['order']=>' selected');

			echo <<<SEARCH
			<form method="post" autocomplete="off" action="$SearUrl">
				<div class="FormSearchTo" style="margin-bottom:0;">
					<table cellspacing="4" cellpadding="4">
						<tr>
							<th>{$Fn_Live->Config['LangVar']['KeywordTitle']}</th><td><input type="text" class="input form-control w200" name="keyword" value="{$_GET['keyword']}">
							</td>
							<th>{$Fn_Live->Config['LangVar']['DisplayTitle']}</th><td>
							<select name="display" class="form-control w120">
								<option value="">{$Fn_Live->Config['LangVar']['SelectNull']}</option>
								<option value="1"{$DisplaySelected['1']}>{$Fn_Live->Config['LangVar']['Yes']}</option>
								<option value="0"{$DisplaySelected['0']}>{$Fn_Live->Config['LangVar']['No']}</option>
							</select>
							</td>
							<th>{$Fn_Admin->Config['LangVar']['Order']}</th><td>
							
							<select name="order" class="form-control w120">
								<option value="dateline"{$OrderSelected['dateline']}>{$Fn_Admin->Config['LangVar']['OrderArray']['dateline']}</option>
								<option value="updateline"{$OrderSelected['updateline']}>{$Fn_Admin->Config['LangVar']['OrderArray']['updateline']}</option>
								<option value="click"{$OrderSelected['click']}>{$Fn_Admin->Config['LangVar']['OrderArray']['click']}</option>
							</select>
							&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Admin->Config['LangVar']['SearchSubmit']}" class="btn btn-info" type="submit">
							</td>
						</tr>
					</table>
				</div>
			</form>
SEARCH;
			/* ���� End */
			showtagheader('div', 'table-responsive', true,'table-responsive');
			showformheader($FormUrl,'enctype="multipart/form-data"');
			showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
			showsubtitle(array(
				'ID',
				$Fn_Live->Config['LangVar']['Title'],
				'Logo',
				$Fn_Live->Config['LangVar']['DisplayTitle'],
				$Fn_Live->Config['LangVar']['RefreshTime'],
				$Fn_Live->Config['LangVar']['TimeTitle'],
				$Fn_Live->Config['LangVar']['OperationTitle']
			),'header tbm tc');

			$ModulesList = GetModulesList($Page,$Limit,$Where,$Order);
			foreach ($ModulesList as $Module) {
				
				showtablerow('', array('class="tc w80"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
					'<input type="checkbox" class="filled-in" id="checkbox_'.$Module['id'].'" name="delete[]" value="'.$Module['id'].'"><label for="checkbox_'.$Module['id'].'">'.$Module['id'].'</label>',
					$Module['title'],
					$Module['logo'] ? '<img src="'.$Module['logo'].'" style="height:30px;">' : '',
					!$Module['display'] ? '<span class="label bg-secondary">'.$Fn_Live->Config['LangVar']['No'].'</span>' : '<span class="label bg-danger">'.$Fn_Live->Config['LangVar']['Yes'].'</span>',
					date('Y-m-d H:i',$Module['updateline']),
					date('Y-m-d H:i',$Module['dateline']),
					'<a href="'.$Fn_Live->Config['ListViewUrl'].$Module['id'].'" target="_blank" class="btn btn-sm btn-dark-outline">'.cplang('view').'</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&nid='.$Module['id'].'" class="btn btn-sm btn-info-outline">'.$Fn_Live->Config['LangVar']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Refresh&nid='.$Module['id'].'&formhash='.FORMHASH.'" class="btn btn-sm btn-primary-outline">'.$Fn_Live->Config['LangVar']['Refresh'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Display&nid='.$Module['id'].'&value='.(!empty($Module['display']) ? 0:1).'&formhash='.FORMHASH.'" class="btn btn-sm btn-success-outline">'.(!empty($Module['display']) ? $Fn_Live->Config['LangVar']['DisplayNoTitle'] : $Fn_Live->Config['LangVar']['DisplayIsTitle']).'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Del&nid='.$Module['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$Fn_Live->Config['LangVar']['DelTitle'].'</a>',
				));
			}
		showsubmit('Submit','&#31435;&#21363;&#25552;&#20132;','del','','',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));
        showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
			/* ģ�����End */	
		}else{
			if(!$Fn_Admin->CheckUserGroup('live_all') && !$Fn_Admin->CheckUserGroup('live_del_number')){//Ȩ���ж�
				fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
				exit();
			}

			if(isset($_GET['delete']) && is_array($_GET['delete'])){
				foreach($_GET['delete'] as $Key => $Val) {
					$Val = intval($Val);
					DB::delete($Fn_Live->TableNumber,'id ='.$Val);
					foreach(DB::fetch_all('SELECT * FROM '.DB::table($Fn_Live->TableLive).' where number_id = '.$Val.' order by id desc') as $K => $V) {
						DB::delete($Fn_Live->TableLive,'id ='.$V['id']);
						DB::delete($Fn_Live->TableComment,'lid ='.$V['id']);
						DB::delete($Fn_Live->TableLivePayLog,'lid ='.$V['id']);
						DB::delete($Fn_Live->TableRedpacketLog,'lid ='.$V['id']);
						DB::delete($Fn_Live->TableParticipant,'lid ='.$V['id']);
					}
				}

				GetInsertDoLog('del_number_live','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete'])));//������¼

				fn_cpmsg($Fn_Live->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
			}else{
				fn_cpmsg($Fn_Live->Config['LangVar']['DelErr'],'','error');
			}
				
		}
	}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['nid']){
		if(!$Fn_Admin->CheckUserGroup('live_all') && !$Fn_Admin->CheckUserGroup('live_del_number')){//Ȩ���ж�
			fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
			exit();
		}
		$Nid = intval($_GET['nid']);
		
		DB::delete($Fn_Live->TableNumber,'id ='.$Nid);
		foreach(DB::fetch_all('SELECT * FROM '.DB::table($Fn_Live->TableLive).' where number_id = '.$Nid.' order by id desc') as $K => $V) {
			DB::delete($Fn_Live->TableLive,'id ='.$V['id']);
			DB::delete($Fn_Live->TableComment,'lid ='.$V['id']);
			DB::delete($Fn_Live->TableLivePayLog,'lid ='.$V['id']);
			DB::delete($Fn_Live->TableRedpacketLog,'lid ='.$V['id']);
			DB::delete($Fn_Live->TableParticipant,'lid ='.$V['id']);
		}

		GetInsertDoLog('del_number_live','fn_'.$_GET['mod'],array('id'=>$Nid));//������¼
		fn_cpmsg($Fn_Admin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
	}else if($Do == 'Refresh' && $_GET['formhash'] == formhash() && $_GET['nid']){
		$Nid = intval($_GET['nid']);
		$UpData['updateline'] = time();
		DB::update($Fn_Live->TableNumber,$UpData,'id = '.$Nid);
		GetInsertDoLog('refresh_number_live','fn_'.$_GET['mod'],array('id'=>$_GET['nid']));//������¼
		fn_cpmsg($Fn_Live->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

	}else if($Do == 'Display' && $_GET['formhash'] == formhash() && $_GET['nid']){
		$Nid = intval($_GET['nid']);
		$UpData['display'] = intval($_GET['value']);
		DB::update($Fn_Live->TableNumber,$UpData,'id = '.$Nid);
		GetInsertDoLog('display_number_live','fn_'.$_GET['mod'],array('id'=>$_GET['nid'],'display'=>$_GET['value']));//������¼
		fn_cpmsg($Fn_Live->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

	}
}else if($SubModel == 'add'){//���ӻ�༭
	if(!$Fn_Admin->CheckUserGroup('live_all') && !$Fn_Admin->CheckUserGroup('live_add_number')){//Ȩ���ж�
		fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
		exit();
	}
	$Nid = intval($_GET['nid']);

	$Item = DB::fetch_first('SELECT * FROM '.DB::table($Fn_Live->TableNumber).' where id = '.$Nid);
	if($Item){
		$Item['param'] = unserialize($Item['param']);
	};
	if(!submitcheck('DetailSubmit')) {
		$OpTitle = $Fn_Live->Config['LangVar']['AddTitle'];
		if($Item){
			$OpTitle = $Fn_Live->Config['LangVar']['EditTitle'];
		}

		//ͼƬ�ϴ�
		if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_assembly/class/class_upload.php')){
			@require_once libfile('class/upload','plugin/fn_assembly');
			$UploadConfig = fn_upload::Config();
		}
		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-header', true,'with-border box-header');
		showtitle($OpTitle,'class="box-title"');
		showtagfooter('div');
		showformheader($Fn_Admin->Config['IframeSubModelUrl'].'&nid='.$Nid,'enctype');
		showtagheader('div', 'box-body', true,'box-body');

		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">Logo<br>&#23610;&#23544;&#65306;&#49;&#53;&#48;&#32;&#42;&#32;&#49;&#53;&#48;</label><div class="col-sm-9"><div class="AdminSingleUpload"><div class="PhotoControl" id="LogoPhotoControl"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';

		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_Live->Config['LangVar']['Banner'].'<br>&#24314;&#35758;&#23610;&#23544;&#65306;&#54;&#52;&#48;&#32;&#42;&#32;&#51;&#48;&#48;</label><div class="col-sm-9"><div class="UploadBanner"><div class="PhotoControl ClickPhotoControl" id="ImagesPhotoControl"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';
		
		showsetting($Fn_Live->Config['LangVar']['Title'], 'title', $Item['title'], 'text');

		showsetting($Fn_Live->Config['LangVar']['Describe'], 'content', $Item['content'], 'textarea');
		
		showsetting($Fn_Live->Config['LangVar']['StateTitle'], 'state', $Item['param']['state'] ? $Item['param']['state'] : str_replace("<br>","\r\n",$Fn_Live->Config['LangVar']['StateTitleDefaul']), 'textarea','','',$Fn_Live->Config['LangVar']['StateTitleTips']);

		showsetting($Fn_Live->Config['LangVar']['Nav'], 'navs', $Item['param']['navs'], 'text','','',$Fn_Live->Config['LangVar']['NumberNavTips']);
		
		showsetting($Fn_Live->Config['LangVar']['ThemeColor'], 'color', $Item['param']['color'] ? $Item['param']['color'] : $Fn_Live->Config['PluginVar']['Color'], 'color');
		
		if($Item['updateline']){
			showsetting($Fn_Live->Config['LangVar']['RefreshTime'], 'updateline',$Item['updateline'] ? date('Y-m-d H:i',$Item['updateline']) : '', 'calendar','','','',1);
		}

		if($Item['dateline']){
			showsetting($Fn_Live->Config['LangVar']['TimeTitle'], 'dateline',date('Y-m-d H:i',$Item['dateline']), 'calendar','','','',1);
		}

		showsetting($Fn_Live->Config['LangVar']['Click'], 'click', $Item['click'], 'text');

		showsetting($Fn_Live->Config['LangVar']['DisplayTitle'], 'display', $Item ? $Item['display'] : 1, 'radio');
		
		showsubmit('DetailSubmit','&#20445;&#23384;&#37197;&#32622;');
		showtagfooter('div');
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');

		$UpLoadHtml  = '';
		if($Item['logo']){
			$LogoJsArray[] = '"'.$Item['logo'].'"';;
			$UpLoadHtml .= '
			var InputArray = new Array('.implode(',',$LogoJsArray).');
			$("#LogoPhotoControl").AppUpload({InputName:"new_logo",Multiple:true,InputExist:true,InputArray:InputArray});';

		}else{
			$UpLoadHtml .= '$("#LogoPhotoControl").AppUpload({InputName:"new_logo",Multiple:true});';
		}

		if($Item['param']['banner']){
			foreach($Item['param']['banner'] as $Key => $Val) {
				$ImagesJsArray[] = '"'.$Val['img'].'|'.$Item['param']['banner'][$Key]['title'].'|'.$Item['param']['banner'][$Key]['link'].'"';
			}
			$UpLoadHtml .= '
			var InputArray = new Array('.implode(',',$ImagesJsArray).');
			$("#ImagesPhotoControl").AppUpload({InputName:"new_banner",InputLink:true,InputExist:true,InputArray:InputArray,Move:true});';

		}else{
			$UpLoadHtml .= '$("#ImagesPhotoControl").AppUpload({InputName:"new_banner",InputLink:true,Move:true});';
		}

		echo $UploadConfig['CssJsHtml'].'<script>'.$UpLoadHtml.'</script>';
		
	}else{
	

		foreach($_GET['new_logo'] as $Key => $Val) {
			$_GET['new_logo'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}

		foreach($_GET['new_banner'] as $Key => $Val) {
			$banner[$Key]['img'] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
			$banner[$Key]['link'] = $_GET['new_banner_link'][$Key];
		}
		
		$Data['logo'] = addslashes(strip_tags($_GET['new_logo'][0]));
		$Data['title'] = addslashes(strip_tags($_GET['title']));
		$Data['content'] = addslashes($_GET['content']);//�豣��Html
		$Data['click'] = intval($_GET['click']);
		$Data['topdateline'] = $_GET['topdateline'] ? strtotime($_GET['topdateline']) : '';
		$Data['display'] = intval($_GET['display']);
	
		$Param['banner'] = is_array($banner) && isset($banner)  ? $banner : '';
		$Param['state'] = addslashes(strip_tags($_GET['state']));
		$Param['navs'] = addslashes(strip_tags($_GET['navs']));
		$Param['navs_array'] = array_filter(explode(",",$_GET['navs']));
		$Param['color'] = addslashes(strip_tags($_GET['color']));

		$Data['param'] = serialize($Param);
		
		if($Item){

			$Data['updateline'] = strtotime($_GET['updateline']);
			GetInsertDoLog('edit_number_live','fn_'.$_GET['mod'],array('id'=>$Nid));//������¼
			DB::update($Fn_Live->TableNumber,$Data,'id = '.$Nid);
		}else{
			$Data['dateline'] = $Data['updateline'] = time();
			$Id = DB::insert($Fn_Live->TableNumber,$Data,true);
			GetInsertDoLog('add_number_live','fn_'.$_GET['mod'],array('id'=>$Id));//������¼
		}
		fn_cpmsg($Fn_Live->Config['LangVar']['UpdateOk'],$Fn_Admin->Config['IframeItemUrl'].'&submodel=list','succeed');
	
	}
}


/* �б� */
function GetModulesList($Page,$Limit,$Where=null,$Order){
	global $Fn_Live;
	$FetchSql = 'SELECT N.* FROM '.DB::table($Fn_Live->TableNumber).' N '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}

/* ���� */
function GetModulesCount($Where=null){
	global $Fn_Live;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_Live->TableNumber).' N '.$Where;
	return DB::result_first($FetchSql);//��������
}

?>