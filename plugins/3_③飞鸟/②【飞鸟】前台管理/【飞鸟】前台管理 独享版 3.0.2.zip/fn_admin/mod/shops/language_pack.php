<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('shops_all') && !$Fn_Admin->CheckUserGroup('shops_language_pack')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}
$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeItemUrl'];
$Identifier =  'fn_'.$_GET['mod'];
loadcache('pluginlanguage_script');
if(!submitcheck('LangSubmit')){
	showtagheader('div', 'box', true,'box');
	showtagheader('div', 'box-body', true,'box-body');
	showtagheader('div', 'tab-content', true,'tab-content');
    showformheader($FormUrl,'enctype="multipart/form-data"');
	foreach($_G['cache']['pluginlanguage_script'][$Identifier] as $K => $V) {
		if(is_array($V)){
			foreach($V as $TK => $TV) {
				showsetting($K, 'Config['.$K.']['.$TK.']',$TV, 'text', 0, 0 ,'','','','',true);
			}
		}else{
			showsetting($K, 'Config['.$K.']',$V, 'text', 0, 0 ,'','','','',true);
		}
	}
	showsubmit('LangSubmit', '&#20445;&#23384;&#37197;&#32622;');
	showformfooter(); /*Dism_taobao-com*/
	showtagfooter('div');
	showtagfooter('div');
	showtagfooter('div');

}else{
	$CaChe = DB::result_first("select data from ".DB::table('common_syscache')." where cname='pluginlanguage_template'");
    $Data = unserialize($CaChe);
    $Data[$Identifier] = $_GET['Config'];
    C::t('common_syscache')->update('pluginlanguage_template',$Data);
    unset($Data);
    $CaChe = DB::result_first("select data from ".DB::table('common_syscache')." where cname='pluginlanguage_script'");
    $Data = unserialize($CaChe);
    $Data[$Identifier] = $_GET['Config'];
    C::t('common_syscache')->update('pluginlanguage_script', $Data);
    fn_cpmsg(lang('plugin/'.$Identifier,'UpdateOk'),$CpMsgUrl, 'succeed');
}


?>