<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('shops_all') && !$Fn_Admin->CheckUserGroup('shops_follow_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$Do = in_array($_GET['do'], array('Del')) ? $_GET['do'] : 'List';

//�����ֶ�
$SearField =array('page','keyword','uid','sid','order');
foreach($SearField as $Val) {
	$SearArray[$Val] = $_GET[$Val] ? $_GET[$Val] : '';
}
//�����ֶ� End

$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeItemUrl'].'&'.http_build_query($SearArray);

if($Do == 'List'){
	if(!submitcheck('Submit')) {
		$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
		$page = $_GET['page'] ? $_GET['page'] : 0;
		$res = C::t('#fn_shops#fn_shops_follow')->fetch_all_by_list(array('keyword'=>$_GET['keyword'],'uid'=>$_GET['uid'],'sid'=>$_GET['sid']),'dateline',$page,30,true);
		/* ģ����� */
		showtagheader('div', 'row', true,'row');
		showtagheader('div', 'col-12', true,'col-12');
		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-body', true,'box-body');
		/* ���� */
		echo <<<SEARCH
		<form method="post" autocomplete="off" action="$SearUrl" id="tb_search">
			<div class="FormSearchTo">
				<table cellspacing="4" cellpadding="4">
					<tr>
						<th>&#29992;&#25143;&#73;&#68;</th><td colspan="10"><input type="text" class="input form-control w150" name="uid" value="{$_GET['uid']}" placeholder="&#35831;&#36755;&#20837;&#29992;&#25143;&#73;&#68;">
						</td>
						<th>&#21830;&#23478;&#73;&#68;</th><td><input type="text" class="input form-control w150" name="sid" value="{$_GET['sid']}" placeholder="&#35831;&#36755;&#20837;&#21830;&#23478;&#73;&#68;">
						&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Admin->Config['LangVar']['SearchSubmit']}" class="btn btn-info" type="submit">
						</td>
					</tr>
				</table>
			</div>
		</form>
SEARCH;
		/* ���� End */
		showtagheader('div', 'table-responsive', true,'table-responsive');
		showformheader($FormUrl,'enctype="multipart/form-data"');
		showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
		showsubtitle(array(
			'ID',
			'&#20851;&#27880;&#30340;&#29992;&#25143;',
			'&#20851;&#27880;&#30340;&#21830;&#22280;',
			$fn_shops->setting['lang']['TimeTitle'],
			$fn_shops->setting['lang']['OperationTitle']
		), 'header tbm tc');
	
		foreach ($res['list'] as $item) {
			showtablerow('', array('class="tc w100"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
				'<input type="checkbox" class="filled-in" id="checkbox_'.$item['id'].'" name="delete[]" value="'.$item['id'].'"><label for="checkbox_'.$item['id'].'">'.$item['id'].'</label>',
				$item['uid'] ? $item['uid'].'/'.$item['username'] : '',
				$item['name'] ? '<a href="'.$fn_shops->getUrl('view',array('sid'=>$item['sid'])).'" target="_blank">'.cutstr($item['name'],60).'</a>' : '',
				date('Y-m-d H:i',$item['dateline']),
				'<a href="'.$OpCpUrl.'&do=Del&fid='.$item['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$fn_shops->setting['lang']['DelTitle'].'</a>',
			));
		}
		showsubmit('Submit','&#31435;&#21363;&#25552;&#20132;','del','','',multi($res['count'],30,$page,$MpUrl));
		showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		/* ģ����� End */
	}else{
		if(isset($_GET['delete']) && is_array($_GET['delete'])){
			foreach($_GET['delete'] as $val) {
				$id = intval($val);
				$item = C::t('#fn_shops#fn_shops_follow')->fetch_by_id($id);
				C::t('#fn_shops#fn_shops_follow')->delete_by_id($id);
				C::t('#fn_shops#fn_shops')->update_by_count($item['sid'],$fn_shops->setting['lang']['shops_action_field_arr'][4],1,'-');
			}
			GetInsertDoLog('del_follow_shops','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete'])));//������¼
			fn_cpmsg($fn_shops->setting['lang']['DelOk'],$CpMsgUrl,'succeed');
		}else{
			fn_cpmsg($fn_shops->setting['lang']['DelErr'],'','error');
		}
	}
}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['fid']){//ɾ��
	$id = intval($_GET['fid']);
	$item = C::t('#fn_shops#fn_shops_follow')->fetch_by_id($id);
	C::t('#fn_shops#fn_shops_follow')->delete_by_id($id);
	C::t('#fn_shops#fn_shops')->update_by_count($item['sid'],$fn_shops->setting['lang']['shops_action_field_arr'][4],1,'-');
	GetInsertDoLog('del_follow_shops','fn_'.$_GET['mod'],array('id'=>$id));//������¼
	fn_cpmsg($fn_shops->setting['lang']['DelOk'],$CpMsgUrl,'succeed');
}
//From: Dism_taobao_com
?>