<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('shops_all') && !$Fn_Admin->CheckUserGroup('shops_album_class_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$SubModel = in_array($_GET['submodel'], array('list','add')) ? $_GET['submodel'] : 'list';
$Fn_Admin->Config['IframeSubModelUrl'] = $Fn_Admin->Config['IframeItemUrl'].'&submodel='.$SubModel;
$NavClass = array($SubModel=>'btn-info Hover');

//����
echo <<<Nav
<div class="SubModelNav">
  <ul>
	<li class="{$NavClass['list']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=list" target="_self">{$Fn_Admin->Config['LangVar']['ShopsLeftNavArray'][$_GET['item']]}</a></li>
    <li class="{$NavClass['add']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=add" target="_self">{$Fn_Admin->Config['LangVar']['AddEditTitle']}</a></li>
  </ul>
  <div class="both"></div>
</div>
Nav;

$allClass = C::t('#fn_shops#fn_shops_album_class')->fetch_all_by_list();

if($SubModel == 'list'){//�б�

	$Do = in_array($_GET['do'], array('Del','Display','Form','FormDetails')) ? $_GET['do'] : 'submodel_list';

	$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeSubModelUrl'].'&'.http_build_query($SearArray);

	if($Do == 'submodel_list'){
		if(!submitcheck('Submit')) {
			/* ģ����� */	
			showtagheader('div', 'row', true,'row');
			showtagheader('div', 'col-12', true,'col-12');
			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-body', true,'box-body');
			showtagheader('div', 'table-responsive', true,'table-responsive');
			showformheader($FormUrl,'enctype="multipart/form-data"');
			showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
			showsubtitle(array(
				'',
				'ID',
				'&#26174;&#31034;&#39034;&#24207;',
				'&#20998;&#31867;&#21517;&#31216;',
				'&#26159;&#21542;&#26174;&#31034;',
				'&#25805;&#20316;'
			),'header tbm tc');
		
			foreach ($allClass as $key=>$value) {
				if($value['level'] == 0) {
					echo showClassRow($key, 0, '');
				}
			}
			showtablefooter(); /*dism��taobao��com*/
			showsubmit('Submit','&#31435;&#21363;&#25552;&#20132;');
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			/* ģ�����End */	
		}else{
			
			foreach($_POST['name'] as $key=>$value) {
				$data['displayorder'] = $_POST['neworder'][$key];
				$data['name'] = $_POST['name'][$key];
				//$UpData['bname'] = $_POST['bname'][$key];
				C::t('#fn_shops#fn_shops_album_class')->update($data,$key);
			 }
			checkClass();
			fn_cpmsg($Fn_Admin->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');	
		}
	}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['classid']){//ɾ��
		if(!$Fn_Admin->CheckUserGroup('shops_all') && !$Fn_Admin->CheckUserGroup('shops_album_class_list_del')){//Ȩ���ж�
			fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
			exit();
		}
		$id = intval($_GET['classid']);
		C::t('#fn_shops#fn_shops_album_class')->delete_by_id($id);
		GetInsertDoLog('del_shops_album_class_list','fn_'.$_GET['mod'],array('id'=>$id));//������¼

		fn_cpmsg($fn_shops->setting['lang']['DelOk'],$CpMsgUrl,'succeed');
	}else if($Do == 'Display' && $_GET['formhash'] == formhash() && $_GET['classid']){//ɾ��
		
		$id = intval($_GET['classid']);
		C::t('#fn_shops#fn_shops_album_class')->update(array('display'=>intval($_GET['value'])),$id);
		fn_cpmsg($fn_shops->setting['lang']['UpdateOk'],$CpMsgUrl,'succeed');
		exit();
	}
}else if($SubModel == 'add'){//���ӻ�༭
	
	$id = intval($_GET['classid']);

	$item = C::t('#fn_shops#fn_shops_album_class')->fetch_by_classid($id);

	if(!submitcheck('DetailSubmit')) {
		//ͼƬ�ϴ�
		if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_assembly/class/class_upload.php')){
			@require_once libfile('class/upload','plugin/fn_assembly');
			$UploadConfig = fn_upload::Config();
		}

		$opTitle = $item ? $fn_shops->setting['lang']['EditTitle'] : $fn_shops->setting['lang']['AddTitle'];

		showtagheader('div', 'box', true,'box');
		showformheader($Fn_Admin->Config['IframeSubModelUrl'].'&copy='.$_GET['copy'].'&classid='.$id,'enctype');
		echo <<<HTML
		<ul class="nav nav-tabs customtab" role="tablist">
          <li class="nav-item"> <a class="nav-link active" data-toggle="tab" href="#basics" role="tab" aria-expanded="true"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#22522;&#30784;&#35774;&#32622;</span></a> </li>

        </ul>
HTML;
		showtagheader('div', 'box-body', true,'box-body');
		showtagheader('div', 'tab-content', true,'tab-content');
		
		echo <<<HTML
		<!-- ��������  -->
		<div class="tab-pane active" id="basics" role="tabpanel" aria-expanded="true">
HTML;

		showsetting('&#20998;&#31867;&#21517;&#31216;', 'name', $item['name'], 'text');

		showsetting('&#19978;&#32423;&#20998;&#31867;', '','',$fn_fenlei->getClassShowSelect($allClass,'bclassid',true,$item['bclassid'] ? $item['bclassid'] : $_GET['bclassid'],true));

		showsetting($fn_shops->setting['lang']['DisplayTitle'], 'display', $item ? $item['display'] : 1, 'radio');

		showsetting('display_order', 'displayorder',$item['displayorder'], 'text');

		echo <<<HTML
		</div>
		<!-- �������� end  -->
HTML;

		showsubmit('DetailSubmit','&#20445;&#23384;&#37197;&#32622;');
		showtagfooter('div');
		showtagheader('div', 'tab-content', true,'tab-content');
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');

		echo $UploadConfig['CssJsHtml'];
		echo '<script>'.$UpLoadHtml.'</script>';

	}else{
		$data['bclassid'] = intval($_GET['bclassid']);
		$data['name'] = $data['bname'] = addslashes(strip_tags($_GET['name']));
		$data['display'] = intval($_GET['display']);
		$data['displayorder'] = intval($_GET['displayorder']);
		$data['level'] = $data['bclassid'] ? $allClass[$data['bclassid']]['level'] + 1 : '';
		//$data = array_merge($data,$Fn_Admin->uploadFiles($_FILES));
		
		if($item && !$_GET['copy']){
			GetInsertDoLog('edit_shops_album_class_list','fn_'.$_GET['mod'],array('id'=>$id));//������¼
			C::t('#fn_shops#fn_shops_album_class')->update($data,$id);
		}else{
			$id = C::t('#fn_shops#fn_shops_album_class')->insert($data);;
			GetInsertDoLog('add_shops_album_class_list','fn_'.$_GET['mod'],array('id'=>$id));//������¼
		}
		checkClass();
		fn_cpmsg($fn_shops->setting['lang']['UpdateOk'],$Fn_Admin->Config['IframeItemUrl'].'&submodel=list','succeed');
		exit();
	}
}
function showClassRow($key, $Level = 0, $Last = ''){
	global $allClass,$Fn_Admin,$fn_shops;
	$item = $allClass[$key];
	$OpInfoCpUrl = ADMINSCRIPT.'?'.'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod=AdminInfo';
	$OpClassCpUrl = ADMINSCRIPT.'?'.rawurldecode(cpurl());
	if($Level == 2) {
		$Class = $Last ? 'lastchildboard' : 'childboard';
		$Return = '<tr class="hover" id="'.$item['classid'].'"><td class="w50">&nbsp;</td><td class="w50">'.$item['classid'].'</td><td class="w80"><input type="text" class="form-control w80" name="neworder['.$item['classid'].']" value="'.$item['displayorder'].'" /></td><td><div class="'.$Class.'">'.
		'<input type="text" class="form-control w200" name="name['.$item['classid'].']" value="'.$item['name'].'" />'.
		'</div>'.
		'</td>'.
		'<td>'.(!empty($item['display']) ? cplang('yes') : cplang('no')).'</td>'.
		'<td><a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&classid='.$item['classid'].'" class="btn btn-sm btn-info-outline">'.$Fn_Admin->Config['LangVar']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&classid='.$item['classid'].'&copy=1" class="btn btn-sm btn-info-outline">&#22797;&#21046;</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&do=Display&classid='.$item['classid'].'&value='.(!empty($item['display']) ? 0:1).'&formhash='.FORMHASH.'" class="btn btn-sm btn-success-outline">'.(!empty($item['display']) ? $Fn_Admin->Config['LangVar']['DisplayNoTitle'] : $Fn_Admin->Config['LangVar']['DisplayIsTitle']).'</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=list&do=Del&classid='.$item['classid'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$Fn_Admin->Config['LangVar']['DelTitle'].'</a></td></tr>';
	}else if($Level == 1) {
		$Return = '<tr class="hover" id="'.$item['classid'].'"><td class="w50">&nbsp;</td><td class="w50">'.$item['classid'].'</td><td class="w80"><input type="text" class="form-control w80" name="neworder['.$item['classid'].']" value="'.$item['displayorder'].'" /></td><td><div class="board">'.
		'<input type="text" class="form-control w200" name="name['.$item['classid'].']" value="'.$item['name'].'" /></div>'.
		'</td>'.
		'<td>'.(!empty($item['display']) ? cplang('yes') : cplang('no')).'</td>'.
		'<td><a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&classid='.$item['classid'].'" class="btn btn-sm btn-info-outline">'.$Fn_Admin->Config['LangVar']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&classid='.$item['classid'].'&copy=1" class="btn btn-sm btn-info-outline">&#22797;&#21046;</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&do=Display&classid='.$item['classid'].'&value='.(!empty($item['display']) ? 0:1).'&formhash='.FORMHASH.'" class="btn btn-sm btn-success-outline">'.(!empty($item['display']) ? $Fn_Admin->Config['LangVar']['DisplayNoTitle'] : $Fn_Admin->Config['LangVar']['DisplayIsTitle']).'</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=list&do=Del&classid='.$item['classid'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$Fn_Admin->Config['LangVar']['DelTitle'].'</a></td></tr>';
		for($i=0,$L=count($item['children']); $i<$L; $i++) {
			$Return .= ShowClassRow($item['children'][$i], 2, $i==$L-1);
		}
	}else{
		$Childrennum = count(implode(',',$allClass[$Key]['children']));
		$Toggle = $Childrennum > 25 ? ' style="display:none"' : '';
		$Return = '<tbody><tr class="hover" id="'.$item['classid'].'"><td class="w50" onclick="toggle_group(\'group_'.$item['classid'].'\')"><a id="a_group_'.$item['classid'].'" href="javascript:;">'.($Toggle ? '[+]' : '[-]').'</a></td>'.
		'<td class="w50">'.$item['classid'].'</td>'
		.'<td class="w80"><input type="text" class="form-control w80" name="neworder['.$item['classid'].']" Value="'.$item['displayorder'].'" /></td><td><div class="parentboard">'.
		'<input type="text" class="form-control w200" name="name['.$item['classid'].']" Value="'.$item['name'].'" />'.
		'</div>'.
		'</td>'.
		'<td>'.(!empty($item['display']) ? cplang('yes') : cplang('no')).'</td>'.
		'<td><a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&classid='.$item['classid'].'" class="btn btn-sm btn-info-outline">'.$Fn_Admin->Config['LangVar']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&classid='.$item['classid'].'&copy=1" class="btn btn-sm btn-info-outline">&#22797;&#21046;</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&do=Display&classid='.$item['classid'].'&value='.(!empty($item['display']) ? 0:1).'&formhash='.FORMHASH.'" class="btn btn-sm btn-success-outline">'.(!empty($item['display']) ? $Fn_Admin->Config['LangVar']['DisplayNoTitle'] : $Fn_Admin->Config['LangVar']['DisplayIsTitle']).'</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=list&do=Del&classid='.$item['classid'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$Fn_Admin->Config['LangVar']['DelTitle'].'</a></td></tr></tbody>
		<tbody id="group_'.$item['classid'].'"'.$Toggle.'>';
		for($i=0,$L=count($item['children']); $i<$L; $i++) {
			$Return .= ShowClassRow($item['children'][$i], 1, '');
		}
		$Return .= '</tdoby><tr><td>&nbsp;</td><td colspan="10"><div class="lastboard"><a class="addtr" href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&bclassid='.$item['classid'].'">&#28155;&#21152;&#20998;&#31867;</a></td></div>';
	}
	return $Return;
}

function checkClass(){
	global $fn_shops;
	$check = array();
	foreach(C::t('#fn_shops#fn_shops_album_class')->fetch_all_by_list() as $val){
		$check[$val['classid']] = $val;
		$check[$val['classid']]['sonid'] = C::t('#fn_shops#fn_shops_album_class')->all_list_classid($val['classid'],array('display'=>1));
	}
	savecache('fn_shops_album_class',$check);
}
//From: Dism_taobao_com
?>