<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('shops_all') && !$Fn_Admin->CheckUserGroup('shops_group_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$SubModel = in_array($_GET['submodel'], array('list','add')) ? $_GET['submodel'] : 'list';
$Fn_Admin->Config['IframeSubModelUrl'] = $Fn_Admin->Config['IframeItemUrl'].'&submodel='.$SubModel;
$NavClass = array($SubModel=>'btn-info Hover');

//����
echo <<<Nav
<div class="SubModelNav">
  <ul>
	<li class="{$NavClass['list']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=list" target="_self">{$Fn_Admin->Config['LangVar']['ShopsLeftNavArray'][$_GET['item']]}</a></li>
    <li class="{$NavClass['add']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=add" target="_self">{$Fn_Admin->Config['LangVar']['AddEditTitle']}</a></li>
  </ul>
  <div class="both"></div>
</div>
Nav;

if($SubModel == 'list'){//�б�
	$Do = in_array($_GET['do'], array('Del')) ? $_GET['do'] : 'submodel_list';
	//�����ֶ�
	$SearField =array('page','keyword');
	foreach($SearField as $Val) {
		$SearArray[$Val] = $_GET[$Val] || in_array($_GET[$Val],array('0')) ? $_GET[$Val] : '';
	}
	//�����ֶ� End
	$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeSubModelUrl'].'&'.http_build_query($SearArray);


	if($Do == 'submodel_list'){
		if(!submitcheck('Submit')) {
			$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
			/* ģ����� */	
			showtagheader('div', 'row', true,'row');
			showtagheader('div', 'col-12', true,'col-12');
			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-body', true,'box-body');
			showtagheader('div', 'table-responsive', true,'table-responsive');
			showformheader($FormUrl,'enctype="multipart/form-data"');
			showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
			showsubtitle(array(
				'ID',
				'&#26435;&#38480;&#31867;&#22411;',
				"&#26631;&#39064;",
				"&#26381;&#21153;&#22825;&#25968;",
				"&#20215;&#26684;",
				"APP&#20215;&#26684;",
				"&#20844;&#21578;",
				"&#35270;&#39057;",
				"&#20840;&#26223;&#86;&#82;",
				//"&#24494;&#20449;&#20108;&#32500;&#30721;",
				"&#32972;&#26223;&#38899;&#20048;",
				"&#30456;&#20876;",
				"&#32418;&#21253;",
				"&#35814;&#24773;",
				"&#31616;&#20171;",
				"&#26159;&#21542;&#26174;&#31034;",
				"&#26174;&#31034;&#39034;&#24207;",
				'&#25805;&#20316;'
			),'header tbm tc');
			
			$res = C::t('#fn_shops#fn_shops_group')->fetch_all_by_list();

			foreach ($res as $item) {
				showtablerow('', array('class="tc w50"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
					$item['id'],
					$fn_shops->setting['lang']['identity_id_arr'][$item['identity_id']],
					$item['title'],
					$item['day'] ? $item['day']."&#22825;" : '',
					$item['price'],
					$item['app_price'],
					$item['add_notice'] ? cplang('yes') : cplang('no'),
					$item['add_video'] ? cplang('yes') : cplang('no'),
					$item['add_pano'] ? cplang('yes') : cplang('no'),
					//$item['add_wx'] ? cplang('yes') : cplang('no'),
					$item['add_music'] ? cplang('yes') : cplang('no'),
					$item['add_album'] ? cplang('yes') : cplang('no'),
					$item['add_package'] ? cplang('yes') : cplang('no'),
					$item['add_content'] ? cplang('yes') : cplang('no'),
					$item['add_desc'] ? cplang('yes') : cplang('no'),
					!$item['display'] ? '<span class="label bg-secondary">'.cplang('no').'</span>' : '<span class="label bg-blue">'.cplang('yes').'</span>',
					$item['displayorder'],
					'<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&gid='.$item['id'].'" class="btn btn-sm btn-info-outline">&#32534;&#36753;</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Del&gid='.$item['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">&#21024;&#38500;</a>'
				));
			}

			showtablefooter(); /*dism��taobao��com*/
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			/* ģ�����End */	
		}
	}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['gid']){
		$id = intval($_GET['gid']);
		C::t('#fn_shops#fn_shops_group')->delete_by_id($id);
		checkGroup();
		fn_cpmsg($Fn_Admin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
	}
}else if($SubModel == 'add'){//���ӻ�༭

	$id = intval($_GET['gid']);
	$item = C::t('#fn_shops#fn_shops_group')->fetch_by_id($id);
	if(!submitcheck('DetailSubmit')) {
		$opTitle = $fn_shops->setting['lang']['AddTitle'];
		if($item)$opTitle = $fn_shops->setting['lang']['EditTitle'];
		
		//ͼƬ�ϴ�
		if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_assembly/class/class_upload.php')){
			@require_once libfile('class/upload','plugin/fn_assembly');
			$UploadConfig = fn_upload::Config();
		}

		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-header', true,'with-border box-header');
		showtitle($opTitle,'class="box-title"');
		showtagfooter('div');
		showformheader($Fn_Admin->Config['IframeSubModelUrl'].'&gid='.$id,'enctype');
		showtagheader('div', 'box-body', true,'box-body');

		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">&#22270;&#26631;</label><div class="col-sm-9"><div class="AdminSingleUpload"><div class="PhotoControl" id="IcoPhotoControl"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';
	
		showsetting($fn_shops->setting['lang']['Title'], 'title', $item['title'], 'text');
	
		showsetting("&#20215;&#26684;", 'price', $item['price'], 'text');

		showsetting("APP&#20215;&#26684;", 'app_price', $item['app_price'], 'text');

		showsetting("&#26381;&#21153;&#22825;&#25968;", 'day', $item['day'], 'text','','','&#21333;&#20301;&#65306;&#22825;');

		showsetting('&#26435;&#38480;&#31867;&#22411;',array('identity_id', array(
			array('1','&#21830;&#23478;', array('identity_id_div_1' => '','identity_id_div_2' => 'none','identity_id_div_3' => 'none')),
			array('2','&#20013;&#20171;', array('identity_id_div_1' => 'none','identity_id_div_2' => '','identity_id_div_3' => 'none')),
			array('3','&#20108;&#25163;&#36710;&#21830;', array('identity_id_div_1' => 'none','identity_id_div_2' => 'none','identity_id_div_3' => '')),
		), TRUE),$item ? $item['identity_id'] : 1, 'mradio');
		showtagheader('div', 'identity_id_div_1', $item['identity_id'] == 1 || !$item ? true : '','identity_id_div_1');
			showsetting("&#20844;&#21578;", 'add_notice', $item['add_notice'], 'radio');

			showsetting("&#35270;&#39057;", 'add_video', $item['add_video'], 'radio');

			showsetting("&#20840;&#26223;&#86;&#82;", 'add_pano', $item['add_pano'], 'radio');

			//showsetting("&#24494;&#20449;&#20108;&#32500;&#30721;", 'add_wx', $item['add_wx'], 'radio');

			showsetting("&#32972;&#26223;&#38899;&#20048;", 'add_music', $item['add_music'], 'radio');

			showsetting("&#30456;&#20876;", 'add_album', $item['add_album'], 'radio');

			showsetting("&#32418;&#21253;", 'add_package', $item['add_package'], 'radio');

			showsetting("&#35814;&#24773;", 'add_content', $item['add_content'], 'radio');

			showsetting("&#31616;&#20171;", 'add_desc', $item['add_desc'], 'radio');
		showtagfooter('div');

		showtagheader('div', 'identity_id_div_2', $item['identity_id'] == 2 ? true : '','identity_id_div_2');
			
		showtagfooter('div');

		showtagheader('div', 'identity_id_div_3', $item['identity_id'] == 3 ? true : '','identity_id_div_3');
			
		showtagfooter('div');

		showsetting("&#26381;&#21153;&#20869;&#23481;", 'content', $item['content'], 'textarea');

		showsetting("&#26159;&#21542;&#26174;&#31034;", 'display', $item ? $item['display'] : 1, 'radio');
		
		showsetting("&#26174;&#31034;&#39034;&#24207;", 'displayorder', $item['displayorder'], 'text');
		
		showsubmit('DetailSubmit','&#20445;&#23384;&#37197;&#32622;');
		showtagfooter('div');
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');

		$UpLoadHtml  = '';
		if($item['icon']){
			$iconJsArray[] = '"'.$item['icon'].'"';;
			$UpLoadHtml .= '
			var InputArray = new Array('.implode(',',$iconJsArray).');
			jQuery("#IcoPhotoControl").AppUpload({InputName:"new_icon",Multiple:true,InputExist:true,InputArray:InputArray});';

		}else{
			$UpLoadHtml .= 'jQuery("#IcoPhotoControl").AppUpload({InputName:"new_icon",Multiple:true});';
		}

		echo $UploadConfig['CssJsHtml'].'<script>'.$UpLoadHtml.'</script>';


	}else{
		foreach($_GET['new_icon'] as $Key => $Val) {
			$_GET['new_icon'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}
		$data['icon'] = $_GET['new_icon'][0] ? addslashes(strip_tags($_GET['new_icon'][0])) : '';
		$data['title'] = addslashes(strip_tags($_GET['title']));
		$data['price'] = addslashes(strip_tags($_GET['price']));
		$data['app_price'] = addslashes(strip_tags($_GET['app_price']));
		$data['day'] = intval($_GET['day']);
		$data['identity_id'] = intval($_GET['identity_id']);
		$data['displayorder'] = intval($_GET['displayorder']);
		$data['count'] = intval($_GET['count']);
		$data['add_notice'] = intval($_GET['add_notice']);
		$data['add_video'] = intval($_GET['add_video']);
		$data['add_pano'] = intval($_GET['add_pano']);
		//$data['add_wx'] = intval($_GET['add_wx']);
		$data['add_music'] = intval($_GET['add_music']);
		$data['add_album'] = intval($_GET['add_album']);
		$data['add_package'] = intval($_GET['add_package']);
		$data['add_content'] = intval($_GET['add_content']);
		$data['add_desc'] = intval($_GET['add_desc']);
		$data['content'] = addslashes(strip_tags($_GET['content']));

		if($item){
			C::t('#fn_shops#fn_shops_group')->update($data,$id);
		}else{
			$id = C::t('#fn_shops#fn_shops_group')->insert($data);
		}
		checkGroup();
		fn_cpmsg($fn_shops->setting['lang']['UpdateOk'],$Fn_Admin->Config['IframeItemUrl'].'&submodel=list','succeed');
	}
}
function checkGroup(){
	global $fn_shops;
	$check = array();
	foreach(C::t('#fn_shops#fn_shops_group')->fetch_all_by_list() as $val){
		$check[$val['id']] = $val;
		$check[$val['id']]['dayText'] = checkGroupDay($val['day']);
	}
	savecache('fn_shops_group',$check);
}
function checkGroupDay($day){
	$text = '';
	if($day < 30){
		$text = $day.lang('plugin/fn_assembly','day');
	}else if($day == '30'){
		$text = '1'.lang('plugin/fn_assembly','ge').lang('plugin/fn_assembly','month');
	}else if($day == '60'){
		$text = '2'.lang('plugin/fn_assembly','ge').lang('plugin/fn_assembly','month');
	}else if($day == '90'){
		$text = '3'.lang('plugin/fn_assembly','ge').lang('plugin/fn_assembly','month');
	}else if($day == '365'){
		$text = '1'.lang('plugin/fn_assembly','year');
	}else if($day == '730'){
		$text = '2'.lang('plugin/fn_assembly','year');
	}else if($day == '9999'){
		$text = lang('plugin/fn_assembly','yongjiu');
	}else{
		$text = $day.lang('plugin/fn_assembly','day');
	}
	return $text;
}
//From: Dism_taobao_com
?>