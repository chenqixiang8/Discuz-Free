
<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('shops_all') && !$Fn_Admin->CheckUserGroup('shops_class_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$SubModel = in_array($_GET['submodel'], array('list','add')) ? $_GET['submodel'] : 'list';
$Fn_Admin->Config['IframeSubModelUrl'] = $Fn_Admin->Config['IframeItemUrl'].'&submodel='.$SubModel;
$NavClass = array($SubModel=>'btn-info Hover');

//����
echo <<<Nav
<div class="SubModelNav">
  <ul>
	<li class="{$NavClass['list']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=list" target="_self">{$Fn_Admin->Config['LangVar']['FenleiLeftNavArray'][$_GET['item']]}</a></li>
    <li class="{$NavClass['add']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=add" target="_self">{$Fn_Admin->Config['LangVar']['AddEditTitle']}</a></li>
  </ul>
  <div class="both"></div>
</div>
Nav;

$allClass = C::t('#fn_shops#fn_shops_class')->fetch_all_by_list();
$allAlbumClass = C::t('#fn_shops#fn_shops_album_class')->fetch_all_by_list();

if($SubModel == 'list'){//�б�

	$Do = in_array($_GET['do'], array('Del','Display','Form','FormDetails')) ? $_GET['do'] : 'submodel_list';

	$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeSubModelUrl'].'&'.http_build_query($SearArray);

	if($Do == 'submodel_list'){
		if(!submitcheck('Submit')) {
			/* ģ����� */	
			showtagheader('div', 'row', true,'row');
			showtagheader('div', 'col-12', true,'col-12');
			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-body', true,'box-body');
			showtagheader('div', 'table-responsive', true,'table-responsive');
			showformheader($FormUrl,'enctype="multipart/form-data"');
			showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
			showsubtitle(array(
				'',
				'ID',
				'&#26174;&#31034;&#39034;&#24207;',
				'&#20998;&#31867;&#21517;&#31216;',
				'&#20998;&#31867;&#22270;&#26631;',
				'&#21830;&#23478;&#25968;',
				'&#39318;&#39029;&#23548;&#33322;',
				'&#26159;&#21542;&#26174;&#31034;',
				'&#25805;&#20316;'
			),'header tbm tc');
		
			foreach ($allClass as $key=>$value) {
				if($value['level'] == 0) {
					echo showClassRow($key, 0, '');
				}
			}
			showtablefooter(); /*dism��taobao��com*/
			showsubmit('Submit','&#31435;&#21363;&#25552;&#20132;');
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			/* ģ�����End */	
		}else{
			
			foreach($_POST['name'] as $key=>$value) {
				$data['displayorder'] = $_POST['neworder'][$key];
				$data['name'] = $_POST['name'][$key];
				//$UpData['bname'] = $_POST['bname'][$key];
				C::t('#fn_shops#fn_shops_class')->update($data,$key);
			 }
			$fn_shops->checkClass();
			fn_cpmsg($Fn_Admin->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');	
		}
	}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['classid']){//ɾ��
		if(!$Fn_Admin->CheckUserGroup('shops_all') && !$Fn_Admin->CheckUserGroup('shops_class_list_del')){//Ȩ���ж�
			fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
			exit();
		}
		$id = intval($_GET['classid']);
		C::t('#fn_shops#fn_shops_class')->delete_by_id($id);
		GetInsertDoLog('del_shops_class_list','fn_'.$_GET['mod'],array('id'=>$id));//������¼

		fn_cpmsg($fn_shops->setting['lang']['DelOk'],$CpMsgUrl,'succeed');
	}else if($Do == 'Display' && $_GET['formhash'] == formhash() && $_GET['classid']){//ɾ��
		
		$id = intval($_GET['classid']);
		C::t('#fn_shops#fn_shops_class')->update(array('display'=>intval($_GET['value'])),$id);
		fn_cpmsg($fn_shops->setting['lang']['UpdateOk'],$CpMsgUrl,'succeed');
		exit();
	}
}else if($SubModel == 'add'){//���ӻ�༭
	
	$id = intval($_GET['classid']);

	$item = C::t('#fn_shops#fn_shops_class')->fetch_by_classid($id);

	if(!submitcheck('DetailSubmit')) {
		//ͼƬ�ϴ�
		if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_assembly/class/class_upload.php')){
			@require_once libfile('class/upload','plugin/fn_assembly');
			$UploadConfig = fn_upload::Config();
		}

		$opTitle = $item ? $fn_shops->setting['lang']['EditTitle'] : $fn_shops->setting['lang']['AddTitle'];

		showtagheader('div', 'box', true,'box');
		showformheader($Fn_Admin->Config['IframeSubModelUrl'].'&copy='.$_GET['copy'].'&classid='.$id,'enctype');
		echo <<<HTML
		<ul class="nav nav-tabs customtab" role="tablist">
          <li class="nav-item"> <a class="nav-link active" data-toggle="tab" href="#basics" role="tab" aria-expanded="true"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#22522;&#30784;&#35774;&#32622;</span></a> </li>
		  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#share" role="tab" aria-expanded="false"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#20998;&#20139;&#35774;&#32622;</span></a> </li>
        </ul>
HTML;
		showtagheader('div', 'box-body', true,'box-body');
		showtagheader('div', 'tab-content', true,'tab-content');
		
		echo <<<HTML
		<!-- ��������  -->
		<div class="tab-pane active" id="basics" role="tabpanel" aria-expanded="true">
HTML;

		showsetting('&#20998;&#31867;&#21517;&#31216;', 'name', $item['name'], 'text');
		$ico_html = ($item['ico'] ? '<a href="'.$item['ico'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$item['ico'].'" height="55"/></a>' : '').'&#24314;&#35758;&#49;&#53;&#48;&#32;&#42;&#32;&#49;&#53;&#48;&#10;&#10;';
		showsetting('&#20998;&#31867;&#22270;&#26631;', 'new_ico',$item['ico'], 'filetext', '', 0, $ico_html);

		showsetting('&#19978;&#32423;&#20998;&#31867;', '','',$fn_fenlei->getClassShowSelect($allClass,'bclassid',true,$item['bclassid'] ? $item['bclassid'] : $_GET['bclassid'],true));

		showsetting('&#39318;&#39029;&#23548;&#33322;', 'nav', $item['nav'], 'radio','','','&#26159;&#21542;&#35843;&#29992;&#21040;&#39318;&#39029;&#23548;&#33322;');

		showsetting('&#26159;&#21542;&#36339;&#36716;&#38142;&#25509;',array('jump', array(
			array('1','&#26159;', array('jump_div_1' => '','jump_div_0' => 'none')),
			array('0','&#21542;', array('jump_div_1' => 'none','jump_div_0' => '')),
		), TRUE),$item ? $item['jump'] : 0, 'mradio');
		showtagheader('div', 'jump_div_1', $item['jump'],'sub');
			showsetting('&#36339;&#36716;&#38142;&#25509;', 'jump_url', $item['jump_url'], 'text');
		showtagfooter('div');

		showtagheader('div', 'jump_div_0', !$item['jump'] || !$item,'sub');
			$albumList = array();
			foreach($allAlbumClass as $val) {
				if(!$val['level']){
					$albumList[] = array($val['classid'], $val['name']);
				}
			}
			showsetting('&#30456;&#20876;&#20998;&#31867;', array('album_id', $albumList),$item['album_id'], 'select');
			showsetting('&#35814;&#24773;&#39029;&#32852;&#31995;&#35201;&#30331;&#24405;&#65311;', 'shops_login', $item ? $item['shops_login'] : 1, 'radio','','','&#35814;&#24773;&#39029;&#26597;&#30475;&#32852;&#31995;&#26041;&#24335;&#26159;&#21542;&#35201;&#30331;&#24405;&#65311;');
		showtagfooter('div');
		
		showsetting($fn_shops->setting['lang']['DisplayTitle'], 'display', $item ? $item['display'] : 1, 'radio');

		showsetting('display_order', 'displayorder',$item['displayorder'], 'text');

		if($item['dateline']){
			showsetting($fn_shops->setting['lang']['TimeTitle'], 'dateline',date('Y-m-d H:i',$item['dateline']), 'calendar','','','',1);
		}

		echo <<<HTML
		</div>
		<!-- �������� end  -->
HTML;

		echo <<<HTML
		<!-- ��������  -->
		<div class="tab-pane" id="share" role="tabpanel" aria-expanded="false">
HTML;
		
		showsetting('&#21015;&#34920;&#20998;&#20139;&#26631;&#39064;', 'share_title', $item['share_title'], 'text');

		showsetting('&#21015;&#34920;&#20998;&#20139;&#25551;&#36848;', 'share_desc', $item['share_desc'], 'text');

		$share_icon = $item['share_icon'] ? $item['share_icon'] : '/source/plugin/fn_shops/static/images/share_logo.png';
		$share_icon_html = '<a href="'.$share_icon.'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$share_icon.'" height="30"/></a>&#24314;&#35758;&#65306;&#50;&#48;&#48;&#32;&#42;&#32;&#50;&#48;&#48;';
		showsetting('&#21015;&#34920;&#20998;&#20139;&#22270;&#26631;', 'new_share_icon',$share_icon, 'filetext', '', 0, $share_icon_html);

		showsetting('&#35814;&#24773;&#20998;&#20139;&#26631;&#39064;', 'shops_share_title', $item['shops_share_title'] ? $item['shops_share_title'] : '[--name--]', 'text','','','&#91;&#45;&#45;&#110;&#97;&#109;&#101;&#45;&#45;&#93;&#20195;&#34920;&#21517;&#31216;&#65292;&#91;&#45;&#45;&#112;&#104;&#111;&#110;&#101;&#45;&#45;&#93;&#20195;&#34920;&#32852;&#31995;&#30005;&#35805;&#65292;&#91;&#45;&#45;&#99;&#108;&#97;&#115;&#115;&#95;&#110;&#97;&#109;&#101;&#45;&#45;&#93;&#20195;&#34920;&#20998;&#31867;&#21517;&#31216;&#65292;&#91;&#45;&#45;&#99;&#111;&#110;&#116;&#101;&#110;&#116;&#45;&#45;&#93;&#20195;&#34920;&#20869;&#23481;&#65292;&#91;&#45;&#45;&#114;&#101;&#103;&#105;&#111;&#110;&#95;&#110;&#97;&#109;&#101;&#45;&#45;&#93;&#20195;&#34920;&#21306;&#22495;&#21517;&#31216;');

		showsetting('&#35814;&#24773;&#20998;&#20139;&#25551;&#36848;', 'shops_share_desc', $item['shops_share_desc'] ? $item['shops_share_desc'] : '[--name--]', 'text','','','&#91;&#45;&#45;&#110;&#97;&#109;&#101;&#45;&#45;&#93;&#20195;&#34920;&#21517;&#31216;&#65292;&#91;&#45;&#45;&#112;&#104;&#111;&#110;&#101;&#45;&#45;&#93;&#20195;&#34920;&#32852;&#31995;&#30005;&#35805;&#65292;&#91;&#45;&#45;&#99;&#108;&#97;&#115;&#115;&#95;&#110;&#97;&#109;&#101;&#45;&#45;&#93;&#20195;&#34920;&#20998;&#31867;&#21517;&#31216;&#65292;&#91;&#45;&#45;&#99;&#111;&#110;&#116;&#101;&#110;&#116;&#45;&#45;&#93;&#20195;&#34920;&#20869;&#23481;&#65292;&#91;&#45;&#45;&#114;&#101;&#103;&#105;&#111;&#110;&#95;&#110;&#97;&#109;&#101;&#45;&#45;&#93;&#20195;&#34920;&#21306;&#22495;&#21517;&#31216;');
		
		showsetting('&#20449;&#24687;&#22797;&#21046;&#27169;&#26495;', 'shops_copy_temp', $item['shops_copy_temp'] ? $item['shops_copy_temp'] : '&#21830;&#23478;&#21517;&#31216;&#65306;[--name--]
&#21830;&#23478;&#22320;&#22336;&#65306;[--address--]
&#33829;&#19994;&#26102;&#38388;&#65306;[--business_time_start--] - [--business_time_end--]
&#28857;&#20987;&#26597;&#35810;&#32852;&#31995;&#26041;&#24335;&#65306;[--url--]
-&#25340;&#36710;&#65292;&#20108;&#25163;&#36710;&#65292;&#23547;&#20154;&#65292;&#22833;&#29289;&#35748;&#39046;&#23601;&#19978;&#39134;&#40479;&#20998;&#31867;&#20449;&#24687;&#32593;-', 'textarea','','','&#91;&#45;&#45;&#117;&#112;&#100;&#97;&#116;&#101;&#108;&#105;&#110;&#101;&#45;&#45;&#93;&#20195;&#34920;&#21047;&#26032;&#26102;&#38388;&#65292;&#91;&#45;&#45;&#100;&#97;&#116;&#101;&#108;&#105;&#110;&#101;&#45;&#45;&#93;&#20195;&#34920;&#21457;&#24067;&#26102;&#38388;&#65292;&#91;&#45;&#45;&#117;&#115;&#101;&#114;&#110;&#97;&#109;&#101;&#45;&#45;&#93;&#20195;&#34920;&#29992;&#25143;&#21517;&#65292;&#91;&#45;&#45;&#110;&#97;&#109;&#101;&#45;&#45;&#93;&#20195;&#34920;&#21517;&#31216;&#65292;&#91;&#45;&#45;&#112;&#104;&#111;&#110;&#101;&#45;&#45;&#93;&#20195;&#34920;&#32852;&#31995;&#30005;&#35805;&#65292;&#91;&#45;&#45;&#99;&#108;&#97;&#115;&#115;&#95;&#110;&#97;&#109;&#101;&#45;&#45;&#93;&#20195;&#34920;&#20998;&#31867;&#21517;&#31216;&#65292;&#91;&#45;&#45;&#99;&#111;&#110;&#116;&#101;&#110;&#116;&#45;&#45;&#93;&#20195;&#34920;&#20869;&#23481;&#65292;&#91;&#45;&#45;&#114;&#101;&#103;&#105;&#111;&#110;&#95;&#110;&#97;&#109;&#101;&#45;&#45;&#93;&#20195;&#34920;&#21306;&#22495;&#21517;&#31216;&#65292;&#91;&#45;&#45;&#117;&#114;&#108;&#45;&#45;&#93;&#20195;&#34920;&#38142;&#25509;');

		showsetting('&#20449;&#24687;&#23548;&#20986;&#27169;&#26495;', 'shops_wx_temp', $item['shops_wx_temp'] ? stripslashes($item['shops_wx_temp']) : '<section><section style="margin-bottom: -1em;">
            <section style="width: 100%;text-align: left;" data-width="100%">
                <section style="display: inline-block;box-shadow: #9fbfdb 4px 4px 0px;border-radius:6px ;">
                    <section data-bgless="spin" data-bglessp="180" style="color:#fff;background: #006785;border-radius:6px ;padding: 4px;">
                        <section style="border-radius:6px;border: 1px dashed #fff;">
                            <section class="135brush" data-brushtype="text" style="font-size:17px;font-weight: bold; text-align: center;letter-spacing:1.5px;padding:0em 0.6em;">
                                [--name--]
                            </section>
                        </section>
                    </section>
                </section>
            </section>
        </section>
        <section data-bdless="spin" data-bdlessp="220" data-bdopacity="50%" style="width: 100%;border: 1px dashed #9fbfdb;border-radius:6px ;" data-width="100%">
            <section style="padding:4px;">
                <section data-bgless="spin" data-bglessp="280" data-bgopacity="50%" style="background:#cdeaff;color:#2f2f2f;border-radius:6px ;">
                    <section class="135brush" style="padding: 2em 1em 1em; letter-spacing: 1.5px; text-align: justify;">
                        <p style="font-size: 14px;"><strong>&#33829;&#19994;&#26102;&#38388;</strong>[--business_time_start--] - [--business_time_end--]</p>
						<p style="font-size: 14px;"><strong>&#35814;&#32454;&#22320;&#22336;</strong>[--address--]</p>
                        <p style="font-size: 14px;"><strong>&#32852;&#31995;&#30005;&#35805;</strong>[--phone--]</p>
                        <p><span style="font-size: 14px;">&#12304;&#25552;&#37266;&#12305;<span style="color: #2f2f2f; font-size: 10px; letter-spacing: 1.5px; text-align: justify; background-color: #cdeaff; text-decoration-line: underline;">&#38271;&#25353;&#20108;&#32500;&#30721;&#35782;&#21035;&#26597;&#30475;</span></span></p>
                        <p>[--qr--]</p>
                    </section>
                </section>
            </section>
        </section>
    </section>', 'textarea','','','&#91;&#45;&#45;&#117;&#112;&#100;&#97;&#116;&#101;&#108;&#105;&#110;&#101;&#45;&#45;&#93;&#20195;&#34920;&#21047;&#26032;&#26102;&#38388;&#65292;&#91;&#45;&#45;&#100;&#97;&#116;&#101;&#108;&#105;&#110;&#101;&#45;&#45;&#93;&#20195;&#34920;&#21457;&#24067;&#26102;&#38388;&#65292;&#91;&#45;&#45;&#117;&#115;&#101;&#114;&#110;&#97;&#109;&#101;&#45;&#45;&#93;&#20195;&#34920;&#29992;&#25143;&#21517;&#65292;&#91;&#45;&#45;&#110;&#97;&#109;&#101;&#45;&#45;&#93;&#20195;&#34920;&#21517;&#31216;&#65292;&#91;&#45;&#45;&#112;&#104;&#111;&#110;&#101;&#45;&#45;&#93;&#20195;&#34920;&#32852;&#31995;&#30005;&#35805;&#65292;&#91;&#45;&#45;&#99;&#108;&#97;&#115;&#115;&#95;&#110;&#97;&#109;&#101;&#45;&#45;&#93;&#20195;&#34920;&#20998;&#31867;&#21517;&#31216;&#65292;&#91;&#45;&#45;&#99;&#111;&#110;&#116;&#101;&#110;&#116;&#45;&#45;&#93;&#20195;&#34920;&#20869;&#23481;&#65292;&#91;&#45;&#45;&#114;&#101;&#103;&#105;&#111;&#110;&#95;&#110;&#97;&#109;&#101;&#45;&#45;&#93;&#20195;&#34920;&#21306;&#22495;&#21517;&#31216;&#65292;&#91;&#45;&#45;&#117;&#114;&#108;&#45;&#45;&#93;&#20195;&#34920;&#38142;&#25509;');

		echo <<<HTML
		</div>
		<!-- �������� end  -->
HTML;
		showsubmit('DetailSubmit','&#20445;&#23384;&#37197;&#32622;');
		showtagfooter('div');
		showtagheader('div', 'tab-content', true,'tab-content');
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');

		echo $UploadConfig['CssJsHtml'];
		echo '<script>'.$UpLoadHtml.'</script>';

	}else{
		$data['album_id'] = intval($_GET['album_id']);
		$data['bclassid'] = intval($_GET['bclassid']);
		$data['name'] = $data['bname'] = addslashes(strip_tags($_GET['name']));
		$data['nav'] = intval($_GET['nav']);
		$data['shops_login'] = intval($_GET['shops_login']);
		$data['share_title'] = addslashes(strip_tags($_GET['share_title']));
		$data['share_desc'] = addslashes(strip_tags($_GET['share_desc']));
		$data['shops_share_title'] = addslashes(strip_tags($_GET['shops_share_title']));
		$data['shops_share_desc'] = addslashes(strip_tags($_GET['shops_share_desc']));
		$data['shops_wx_temp'] = addslashes($_GET['shops_wx_temp']);
		$data['shops_copy_temp'] = addslashes(strip_tags($_GET['shops_copy_temp']));
		$data['jump'] = intval($_GET['jump']);
		$data['jump_url'] = addslashes(strip_tags($_GET['jump_url']));
		$data['display'] = intval($_GET['display']);
		$data['displayorder'] = intval($_GET['displayorder']);
		$data['level'] = $data['bclassid'] ? $allClass[$data['bclassid']]['level'] + 1 : '';
		$data = array_merge($data,$Fn_Admin->uploadFiles($_FILES));
		
		foreach($_GET['upload_admin'] as $key => $value){
			if(strpos($key,'new_') !== false){
				$key_name = str_replace(array('new_'),'',$key);
				$param[$key_name] = array();
				foreach($_GET[$key] as $k => $v) {
					$param[$key_name][$k]['img'] = strpos($v,'http') !== false ? $v : $_G['siteurl'].$v;
					$param[$key_name][$k]['link'] = $_GET[$key.'_link'][$k];
					$param[$key_name][$k]['title'] = $_GET[$key.'_title'][$k];
				}
			}
		}
		if($item && !$_GET['copy']){
			GetInsertDoLog('edit_shops_class_list','fn_'.$_GET['mod'],array('id'=>$id));//������¼
			C::t('#fn_shops#fn_shops_class')->update($data,$id);
		}else{
			$data['dateline'] = time();
			$id = C::t('#fn_shops#fn_shops_class')->insert($data);;
			GetInsertDoLog('add_shops_class_list','fn_'.$_GET['mod'],array('id'=>$id));//������¼
		}
		$fn_shops->checkClass();
		fn_cpmsg($fn_shops->setting['lang']['UpdateOk'],$Fn_Admin->Config['IframeItemUrl'].'&submodel=list','succeed');
		exit();
	}
}
function showClassRow($key, $Level = 0, $Last = ''){
	global $allClass,$Fn_Admin,$fn_shops;
	$item = $allClass[$key];
	$OpInfoCpUrl = ADMINSCRIPT.'?'.'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod=AdminInfo';
	$OpClassCpUrl = ADMINSCRIPT.'?'.rawurldecode(cpurl());
	if($Level == 2) {
		$Class = $Last ? 'lastchildboard' : 'childboard';
		$Return = '<tr class="hover" id="'.$item['classid'].'"><td class="w50">&nbsp;</td><td class="w50">'.$item['classid'].'</td><td class="w80"><input type="text" class="form-control w80" name="neworder['.$item['classid'].']" value="'.$item['displayorder'].'" /></td><td><div class="'.$Class.'">'.
		'<input type="text" class="form-control w200" name="name['.$item['classid'].']" value="'.$item['name'].'" />'.
		'</div>'.
		'</td><td>'.($item['ico'] ? '<img src="'.$item['ico'].'" style="hegiht:30px;width:30px;">' : '').'</td>'.
		'<td>'.$item['info_count'].'</td><td>'.(!empty($item['nav']) ? '<span class="text-danger">'.cplang('yes').'</span>' : cplang('no')).'</td><td>'.(!empty($item['display']) ? cplang('yes') : cplang('no')).'</td>'.
		'<td><a href="'.$fn_shops->getUrl('list',array('classid'=>$item['classid'])).'" target="_blank" class="btn btn-sm btn-dark-outline">'.cplang('view').'</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&classid='.$item['classid'].'" class="btn btn-sm btn-info-outline">'.$Fn_Admin->Config['LangVar']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&classid='.$item['classid'].'&copy=1" class="btn btn-sm btn-info-outline">&#22797;&#21046;</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&do=Display&classid='.$item['classid'].'&value='.(!empty($item['display']) ? 0:1).'&formhash='.FORMHASH.'" class="btn btn-sm btn-success-outline">'.(!empty($item['display']) ? $Fn_Admin->Config['LangVar']['DisplayNoTitle'] : $Fn_Admin->Config['LangVar']['DisplayIsTitle']).'</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeModUrl'].'&item=shops_list&submodel=list&classid='.$item['classid'].'" class="btn btn-sm btn-primary-outline">&#31649;&#29702;&#21830;&#23478;</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=list&do=Del&classid='.$item['classid'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$Fn_Admin->Config['LangVar']['DelTitle'].'</a></td></tr>';
	}else if($Level == 1) {
		$Return = '<tr class="hover" id="'.$item['classid'].'"><td class="w50">&nbsp;</td><td class="w50">'.$item['classid'].'</td><td class="w80"><input type="text" class="form-control w80" name="neworder['.$item['classid'].']" value="'.$item['displayorder'].'" /></td><td><div class="board">'.
		'<input type="text" class="form-control w200" name="name['.$item['classid'].']" value="'.$item['name'].'" /></div>'.
		'</td><td>'.($item['ico'] ? '<img src="'.$item['ico'].'" style="hegiht:30px;width:30px;">' : '').'</td>'.
		'<td>'.$item['info_count'].'</td><td>'.(!empty($item['nav']) ? '<span class="text-danger">'.cplang('yes').'</span>' : cplang('no')).'</td><td>'.(!empty($item['display']) ? cplang('yes') : cplang('no')).'</td>'.
		'<td><a href="'.$fn_shops->getUrl('list',array('classid'=>$item['classid'])).'" target="_blank" class="btn btn-sm btn-dark-outline">'.cplang('view').'</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&classid='.$item['classid'].'" class="btn btn-sm btn-info-outline">'.$Fn_Admin->Config['LangVar']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&classid='.$item['classid'].'&copy=1" class="btn btn-sm btn-info-outline">&#22797;&#21046;</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&do=Display&classid='.$item['classid'].'&value='.(!empty($item['display']) ? 0:1).'&formhash='.FORMHASH.'" class="btn btn-sm btn-success-outline">'.(!empty($item['display']) ? $Fn_Admin->Config['LangVar']['DisplayNoTitle'] : $Fn_Admin->Config['LangVar']['DisplayIsTitle']).'</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeModUrl'].'&item=shops_list&submodel=list&classid='.$item['classid'].'" class="btn btn-sm btn-primary-outline">&#31649;&#29702;&#21830;&#23478;</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=list&do=Del&classid='.$item['classid'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$Fn_Admin->Config['LangVar']['DelTitle'].'</a></td></tr>';
		for($i=0,$L=count($item['children']); $i<$L; $i++) {
			$Return .= ShowClassRow($item['children'][$i], 2, $i==$L-1);
		}
	}else{
		$Childrennum = count(implode(',',$allClass[$Key]['children']));
		$Toggle = $Childrennum > 25 ? ' style="display:none"' : '';
		$Return = '<tbody><tr class="hover" id="'.$item['classid'].'"><td class="w50" onclick="toggle_group(\'group_'.$item['classid'].'\')"><a id="a_group_'.$item['classid'].'" href="javascript:;">'.($Toggle ? '[+]' : '[-]').'</a></td>'.
		'<td class="w50">'.$item['classid'].'</td>'
		.'<td class="w80"><input type="text" class="form-control w80" name="neworder['.$item['classid'].']" Value="'.$item['displayorder'].'" /></td><td><div class="parentboard">'.
		'<input type="text" class="form-control w200" name="name['.$item['classid'].']" Value="'.$item['name'].'" />'.
		'</div>'.
		'</td><td>'.($item['ico'] ? '<img src="'.$item['ico'].'" style="hegiht:30px;width:30px;">' : '').'</td>'.
		'<td>'.$item['shops_count'].'</td><td>'.(!empty($item['nav']) ? '<span class="text-danger">'.cplang('yes').'</span>' : cplang('no')).'</td><td>'.(!empty($item['display']) ? cplang('yes') : cplang('no')).'</td>'.
		'<td><a href="'.$fn_shops->getUrl('list',array('classid'=>$item['classid'])).'" target="_blank" class="btn btn-sm btn-dark-outline">'.cplang('view').'</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&classid='.$item['classid'].'" class="btn btn-sm btn-info-outline">'.$Fn_Admin->Config['LangVar']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&classid='.$item['classid'].'&copy=1" class="btn btn-sm btn-info-outline">&#22797;&#21046;</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&do=Display&classid='.$item['classid'].'&value='.(!empty($item['display']) ? 0:1).'&formhash='.FORMHASH.'" class="btn btn-sm btn-success-outline">'.(!empty($item['display']) ? $Fn_Admin->Config['LangVar']['DisplayNoTitle'] : $Fn_Admin->Config['LangVar']['DisplayIsTitle']).'</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeModUrl'].'&item=shops_list&submodel=list&classid='.$item['classid'].'" class="btn btn-sm btn-primary-outline">&#31649;&#29702;&#21830;&#23478;</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=list&do=Del&classid='.$item['classid'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$Fn_Admin->Config['LangVar']['DelTitle'].'</a></td></tr></tbody>
		<tbody id="group_'.$item['classid'].'"'.$Toggle.'>';
		for($i=0,$L=count($item['children']); $i<$L; $i++) {
			$Return .= ShowClassRow($item['children'][$i], 1, '');
		}
		$Return .= '</tdoby><tr><td>&nbsp;</td><td colspan="10"><div class="lastboard"><a class="addtr" href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&bclassid='.$item['classid'].'">&#28155;&#21152;&#20998;&#31867;</a></td></div>';
	}
	return $Return;
}
//From: Dism_taobao_com
?>