<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('shops_all') && !$Fn_Admin->CheckUserGroup('shops_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$SubModel = in_array($_GET['submodel'], array('list','add','album')) ? $_GET['submodel'] : 'list';
$Fn_Admin->Config['IframeSubModelUrl'] = $Fn_Admin->Config['IframeItemUrl'].'&submodel='.$SubModel;
$NavClass = array($SubModel=>'btn-info Hover');

//����
echo <<<Nav
<div class="SubModelNav">
  <ul>
	<li class="{$NavClass['list']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=list" target="_self">{$Fn_Admin->Config['LangVar']['ShopsLeftNavArray'][$_GET['item']]}</a></li>
    <li class="{$NavClass['add']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=add" target="_self">{$Fn_Admin->Config['LangVar']['AddEditTitle']}</a></li>
  </ul>
  <div class="both"></div>
</div>
Nav;

$allClass = C::t('#fn_shops#fn_shops_class')->fetch_all_by_list();
$allRegion = C::t('#fn_fenlei#fn_region')->fetch_all_by_list();

if($SubModel == 'list'){//�б�
	$Do = in_array($_GET['do'], array('del','display','refresh')) ? $_GET['do'] : 'submodel_list';
	//�����ֶ�
	$SearField =array('page','name','regionid','new_uid','identity_id','display','audit_state','classid','overdue','order','new_sid');
	foreach($SearField as $Val) {
		$SearArray[$Val] = $_GET[$Val] || in_array($_GET[$Val],array('0')) ? $_GET[$Val] : '';
	}
	//�����ֶ� End
	$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeSubModelUrl'].'&'.http_build_query($SearArray);


	if($Do == 'submodel_list'){
		if(!submitcheck('Submit')) {

			$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
			$page = $_GET['page'] ? $_GET['page'] : 0;
			$res = C::t('#fn_shops#fn_shops')->fetch_all_by_list(array('name'=>$_GET['name'],'uid'=>$_GET['new_uid'],'identity_id'=>$_GET['identity_id'],'sid'=>$_GET['new_sid'],'overdue'=>$_GET['overdue'],'regionid'=>$_GET['regionid'],'classid'=>$_GET['classid'],'display'=>$_GET['display'],'audit_state'=>$_GET['audit_state']),$_GET['order'],'',$page - 1,20,true,'','');

			/* ��ѯ���� End */
	
			/* ģ����� */	
			showtagheader('div', 'row', true,'row');
			showtagheader('div', 'col-12', true,'col-12');
			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-body', true,'box-body');
			/* ���� */
			$OverdueSelected = array($_GET['overdue']=>' selected');
			$DisplaySelected = array($_GET['display']=>' selected');
			$audit_state_selected = array($_GET['audit_state']=>' selected');
			$OrderSelected = array($_GET['order']=>' selected');
			$OverdueHtml = '<th>&#26159;&#21542;&#36807;&#26399;</th><td>
							<select name="overdue" class="form-control w120">
								<option value="">'.$fn_shops->setting['lang']['SelectNull'].'</option>
								<option value="1"'.$OverdueSelected['1'].'>'.$fn_shops->setting['lang']['Yes'].'</option>
								<option value="2"'.$OverdueSelected['2'].'>'.$fn_shops->setting['lang']['No'].'</option>
							</select>
							</td>';
			$classShowSelect = $fn_fenlei->getClassShowSelect($allClass,'classid',true,$_GET['classid']);
			$regionShowSelect = $fn_fenlei->getRegionShowSelect($allRegion,'regionid',true,$_GET['regionid']);

			$identity_id_option = '<option value="">'.$fn_shops->setting['lang']['SelectNull'].'</option>';
			foreach($fn_shops->setting['lang']['identity_id_arr'] as $key => $val) {
				$identity_id_option .= '<option value="'. $key.'" '.($_GET['identity_id'] ==  $key ? ' selected' : '' ).'>'.$val.'</option>';
			}
			
			echo <<<SEARCH
			<form method="post" autocomplete="off" action="$SearUrl">
				<div class="FormSearchTo" style="margin-bottom:0;">
					<table cellspacing="4" cellpadding="4">
						<tr>
							<th>&#21830;&#23478;&#21517;&#31216;</th><td colspan="10"><input type="text" class="input form-control w120" name="name" value="{$_GET['name']}" placeholder="&#35831;&#36755;&#20837;&#21830;&#23478;&#21517;&#31216;">
							&nbsp;&nbsp;&nbsp;&nbsp;&#21830;&#23478;&#73;&#68;&nbsp;&nbsp;<input type="text" class="input form-control w120" name="new_sid" value="{$_GET['new_sid']}" placeholder="&#35831;&#36755;&#20837;&#21830;&#23478;&#73;&#68;">
							&nbsp;&nbsp;&nbsp;&nbsp;&#29992;&#25143;&#73;&#68;&nbsp;&nbsp;<input type="text" class="input form-control w120" name="new_uid" value="{$_GET['new_uid']}" placeholder="&#35831;&#36755;&#20837;&#29992;&#25143;&#73;&#68;">
							</td>
						</tr>
						<tr>
							<th>&#20998;&#31867;</th>
							<td>{$classShowSelect}</td>
							<th>&#21306;&#22495;</th>
							<td>{$regionShowSelect}</td>
							<th>&#21830;&#23478;&#31867;&#22411;</th><td>
							<select name="identity_id" class="form-control w120">
								{$identity_id_option}
							</select></td>
							<th>&#26159;&#21542;&#26174;&#31034;</th><td>
							<select name="display" class="form-control w120">
								<option value="">{$fn_shops->setting['lang']['SelectNull']}</option>
								<option value="1"{$DisplaySelected['1']}>{$fn_shops->setting['lang']['Yes']}</option>
								<option value="0"{$DisplaySelected['0']}>{$fn_shops->setting['lang']['No']}</option>
							</select>
							</td>
							<th>&#23457;&#26680;&#29366;&#24577;</th><td>
							<select name="audit_state" class="form-control w120">
								<option value="">{$fn_shops->setting['lang']['SelectNull']}</option>
								<option value="1"{$audit_state_selected['1']}>{$fn_shops->setting['lang']['audit_state_arr']['1']}</option>
								<option value="2"{$audit_state_selected['2']}>{$fn_shops->setting['lang']['audit_state_arr']['2']}</option>
								<option value="3"{$audit_state_selected['3']}>{$fn_shops->setting['lang']['audit_state_arr']['3']}</option>
							</select>
							</td>
							<th>&#25490;&#24207;</th><td>
							<select name="order" class="form-control w120">
								<option value="dateline"{$OrderSelected['dateline']}>{$Fn_Admin->Config['LangVar']['OrderArray']['dateline']}</option>
								<option value="updateline"{$OrderSelected['updateline']}>{$Fn_Admin->Config['LangVar']['OrderArray']['updateline']}</option>
								<option value="click"{$OrderSelected['click']}>{$Fn_Admin->Config['LangVar']['OrderArray']['click']}</option>
								<option value="topdateline"{$OrderSelected['topdateline']}>{$Fn_Admin->Config['LangVar']['OrderArray']['topdateline']}</option>
							</select>
							&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Admin->Config['LangVar']['SearchSubmit']}" class="btn btn-info" type="submit">
							</td>
						</tr>
					</table>
				</div>
			</form>
SEARCH;
			/* ���� End */
			showtagheader('div', 'table-responsive', true,'table-responsive');
			showformheader($FormUrl,'enctype="multipart/form-data"');
			showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
			showsubtitle(array(
				'ID',
				'UID/'.$fn_shops->setting['lang']['UserNameTitle'],
				'&#20998;&#31867;&#21517;&#31216;',
				'&#21306;&#22495;&#21517;&#31216;',
				$fn_shops->setting['lang']['shops_name'],
				$fn_shops->setting['lang']['contact_number'],
				'&#32479;&#35745;',
				'&#28192;&#36947;',
				'&#26174;&#31034;&#47;&#23457;&#26680;&#29366;&#24577;',
				'&#26102;&#38388;',
				$fn_shops->setting['lang']['OperationTitle']
			),'header tbm tc');

			foreach ($res['list'] as $item) {
				
				$classItem = $fn_shops->_G['cache']['fn_shops_class'][$item['classid']];

				$replaceFront = array('[--url--]','[--id--]','[--updateline--]','[--dateline--]','[--username--]','[--role--]','[--class_name--]','[--region_name--]','[--title--]','[--name--]','[--phone--]','[--click--]','[--content--]','[--tag--]');
				$replaceAfter = array($fn_shops->getUrl('view',array('sid'=>$item['id'])),$item['id'],$item['updateline'],$item['dateline'],$item['username'],$item['role'],$item['class_name'],$item['region_name'],$item['title'],$item['name'],$item['phone'],$item['click'],strip_tags($item['content']),implode('|',$item['tag_arr'] ? dunserialize($item['tag_arr']) : ''));

				$countHtml = '';
				foreach ($fn_shops->setting['lang']['shops_action_arr'] as $key=> $val) {
					$countHtml .= $val.': '.$item[$fn_shops->setting['lang']['shops_action_field_arr'][$key]].'<br>';
				}
				$countHtml .= $fn_shops->setting['lang']['Click'].": ".$item['click'];
				$timeText = '&#21047;&#26032;&#26102;&#38388;&#65306;'.date('Y-m-d',$item['updateline']).'<br>&#28155;&#21152;&#26102;&#38388;&#65306;'.date('Y-m-d',$item['dateline']).'<br>&#32622;&#39030;&#26102;&#38388;&#65306;'.($item['topdateline'] >= time() ? date('Y-m-d',$item['topdateline']) : ($item['topdateline'] ? '<span class="label bg-danger">'.$fn_shops->setting['lang']['Expired'].'</span>' : ''));
				showtablerow('', array('class="tc w100"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
					'<input type="checkbox" class="filled-in" id="checkbox_'.$item['id'].'" name="delete[]" value="'.$item['id'].'"><label for="checkbox_'.$item['id'].'">'.$item['id'].'</label>',
					$item['uid'] ? $item['uid'].'/'.$item['username'] : '',
					$item['class_name'],
					$item['region_name'],
					$item['name'].'<br>'.$item['title'].'<br>&#36807;&#26399;&#26102;&#38388;&#65306;<span class="text-danger">'.($item['due_time'] ? ($item['due_time'] > time() ? date('Y-m-d',$item['due_time']) : '&#24050;&#36807;&#26399;' ) : ''),
					$item['phone'],
					$countHtml,
					$fn_shops->setting['lang']['shops_channel_arr'][$item['channel']].'<br>'.$fn_shops->setting['lang']['shops_source_arr'][$item['source']],
					(!$item['display'] ? '<span class="label bg-secondary">'.$fn_shops->setting['lang']['No'].'</span>' : '<span class="label bg-blue">'.$fn_shops->setting['lang']['Yes'].'</span>').'<div style="height:10px;"></div>'.(
					$item['audit_state'] != 1 ? '<span class="label bg-secondary">'.$fn_shops->setting['lang']['audit_state_arr'][$item['audit_state']].'</span>' : '<span class="label bg-blue">'.$fn_shops->setting['lang']['audit_state_arr'][$item['audit_state']].'</span>'),
					$timeText,
					'<a href="'.$fn_shops->getUrl('view',array('sid'=>$item['id'])).'" target="_blank" class="btn btn-sm btn-dark-outline">'.cplang('view').'</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&sid='.$item['id'].'" class="btn btn-sm btn-info-outline">'.$fn_shops->setting['lang']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=refresh&sid='.$item['id'].'&formhash='.FORMHASH.'" class="btn btn-sm btn-primary-outline">'.$fn_shops->setting['lang']['Refresh'].'</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeModUrl'].'&item=shops_action_list&submodel=list&sid='.$item['id'].'" class="btn btn-sm btn-danger-outline">&#32479;&#35745;&#35760;&#24405;</a><br><div style="height:7px;"></div><span class="btn btn-sm btn-dark-outline copy_btn" data-clipboard-content="'.str_replace($replaceFront,$replaceAfter,$classItem['shops_copy_temp']).'">&#22797;&#21046;</span>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=album&sid='.$item['id'].'" class="btn btn-sm btn-info-outline">&#30456;&#20876;</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=display&sid='.$item['id'].'&value='.(!empty($item['display']) ? 0:1).'&formhash='.FORMHASH.'" class="btn btn-sm btn-warning-outline">'.(!empty($item['display']) ? $fn_shops->setting['lang']['DisplayNoTitle'] : $fn_shops->setting['lang']['DisplayIsTitle']).'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=del&sid='.$item['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$fn_shops->setting['lang']['DelTitle'].'</a>',
				));
			}
			
			showsubmit('Submit','&#31435;&#21363;&#25552;&#20132;','','','',multi($res['count'],20,$page,$MpUrl));

			showtablefooter(); /*dism��taobao��com*/
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');

			echo '
			<script src="source/plugin/fn_assembly/static/js/clipboard.min.js"></script>    
			<script>
			var clipboard = new ClipboardJS(".copy_btn", {
				text: function(e) {
					return e.getAttribute("data-clipboard-content");
				}
			});
			clipboard.on("success", function(e) {
				alert("\u606d\u559c\u60a8\uff0c\u590d\u5236\u6210\u529f\uff01");
			});

			clipboard.on("error", function(e) {
				alert("\u5f88\u9057\u61be\uff0c\u590d\u5236\u5931\u8d25\uff01");
			});
			</script>';
			/* ģ�����End */	
		}else{
			if(isset($_GET['delete']) && is_array($_GET['delete'])){
				
			}
		}
	}else if($Do == 'del' && $_GET['formhash'] == formhash() && $_GET['sid']){
		if(!$Fn_Admin->CheckUserGroup('shops_all') && !$Fn_Admin->CheckUserGroup('shops_del_list')){//Ȩ���ж�
			fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
			exit();
		}
		$id = intval($_GET['sid']);
		C::t('#fn_shops#fn_shops')->delete_by_id($id);
		GetInsertDoLog('del_shops','fn_'.$_GET['mod'],array('id'=>$id));//������¼
		$fn_shops->checkClass();
		fn_cpmsg($Fn_Admin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
	}else if(in_array($Do,array('refresh','display')) && $_GET['formhash'] == formhash() && $_GET['sid']){
		$id = intval($_GET['sid']);
		if($Do == 'refresh'){
			$data['updateline'] = time();
		}else{
			$data[$Do] = intval($_GET['value']);
		}
		C::t('#fn_shops#fn_shops')->update($data,$id);
		GetInsertDoLog($Do.'_shops','fn_'.$_GET['mod'],array('id'=>$id));//������¼
		fn_cpmsg($fn_shops->setting['lang']['UpdateOk'],$CpMsgUrl,'succeed');
		exit();
	}
}else if($SubModel == 'add'){//���ӻ�༭
	if(!$Fn_Admin->CheckUserGroup('shops_all') && !$Fn_Admin->CheckUserGroup('shops_add_list')){//Ȩ���ж�
		fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
		exit();
	}

	$id = intval($_GET['sid']);
	
	$item = C::t('#fn_shops#fn_shops')->fetch_by_id($id);

	if(!submitcheck('DetailSubmit')) {
		$opTitle = $fn_shops->setting['lang']['AddTitle'];
		if($item){
			$opTitle = $fn_shops->setting['lang']['EditTitle'];
		}
		
		//ͼƬ�ϴ�
		if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_assembly/class/class_upload.php')){
			@require_once libfile('class/upload','plugin/fn_assembly');
			$UploadConfig = fn_upload::Config();
		}

		echo '<script src="'.$Config['StaticPath'].'/ueditor/'.CHARSET.'/ueditor.config.js" type="text/javascript"></script><script src="'.$Config['StaticPath'].'/ueditor/'.CHARSET.'/ueditor.all.js" type="text/javascript"></script>';

		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-header', true,'with-border box-header');
		showtitle($opTitle,'class="box-title"');
		showtagfooter('div');
		showformheader($Fn_Admin->Config['IframeSubModelUrl'].'&sid='.$id,'enctype');
		showtagheader('div', 'box-body', true,'box-body');

		showsetting('uid', 'new_uid', $item['uid'], 'text');

		$logo_html = ($item['logo'] ? '<a href="'.$item['logo'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$item['logo'].'" height="55"/></a>' : '');
		showsetting($fn_shops->setting['lang']['shops_logo'], 'new_logo',$item['logo'], 'filetext', '', 0, $logo_html);
		
		showsetting($fn_shops->setting['lang']['shops_name'], 'name', $item['name'], 'text');

		showsetting($fn_shops->setting['lang']['contact_number'], 'phone', $item['phone'], 'text');

		showsetting($fn_shops->setting['lang']['shops_wx_text'], 'wx', $item['wx'], 'text');

		$wx_qr_html = ($item['wx_qr'] ? '<a href="'.$item['wx_qr'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$item['wx_qr'].'" height="55"/></a>' : '');
		showsetting($fn_shops->setting['lang']['shops_wx'], 'new_wx_qr',$item['wx_qr'], 'filetext', '', 0, $wx_qr_html);

		showsetting('&#36873;&#25321;&#20998;&#31867;', '','',$fn_fenlei->getClassShowSelect($allClass,'new_classid',true,$item['classid'],true));

		showsetting('&#36873;&#25321;&#21306;&#22495;', '','',$fn_fenlei->getRegionShowSelect($allRegion,'new_regionid',true,$item['regionid'],true));

		showsetting('&#35814;&#32454;&#22320;&#22336;', 'address', $item['address'], 'text','','','<div class="MapClick">&#23450;&#20301;</div><div class="TipMap"><iframe id="MapPage" width="100%" height="100%" frameborder=0 src=""></iframe></div>');
		
		showsetting('&#32463;&#24230;', 'lng', $item['lng'], 'text');

		showsetting('&#32428;&#24230;', 'lat', $item['lat'], 'text');

		showsetting($fn_shops->setting['lang']['shops_video'], 'video_url', $item['video_url'], 'text');

		showsetting($fn_shops->setting['lang']['shops_pano'], 'pano_url', $item['pano_url'], 'text');

		showsetting($fn_shops->setting['lang']['shops_music'], 'music_url', $item['music_url'], 'text');

		showsetting($fn_shops->setting['lang']['business_start_hours'], 'business_time_start', $item['business_time_start'], 'text');

		showsetting($fn_shops->setting['lang']['business_end_hours'], 'business_time_end', $item['business_time_end'], 'text');

		showsetting($fn_shops->setting['lang']['shops_notice'], 'notice', $item['notice'], 'textarea');

		showsetting($fn_shops->setting['lang']['shops_desc'], 'desc', $item['desc'], 'textarea');

		//��������
		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$fn_shops->setting['lang']['shops_content'].':</label><div class="col-sm-9"><textarea id="content" name="content" style="width:80%;height:400px;">'.stripslashes($item['content']).'</textarea></div></div>';
		
		showsetting('&#21830;&#23478;&#31867;&#22411;',array('identity_id', array(
			array('1','&#21830;&#23478;', array('identity_id_1' => '','identity_id_2' => 'none','identity_id_3' => 'none')),
			array('2','&#20013;&#20171;', array('identity_id_1' => 'none','identity_id_2' => '','identity_id_3' => 'none')),
			array('3','&#20108;&#25163;&#36710;&#21830;', array('identity_id_1' => 'none','identity_id_2' => 'none','identity_id_3' => '')),
		), TRUE),$item['identity_id'] ? $item['identity_id'] : 1, 'mradio');

		$groupList = array();
		foreach($fn_shops->allGroupList as $val) {
			if($val['identity_id'] == 1){ 
				$groupList[1][] = array($val['id'], $val['title']);
			}
			if($val['identity_id'] == 2){ 
				$groupList[2][] = array($val['id'], $val['title']);
			}
			if($val['identity_id'] == 3){ 
				$groupList[3][] = array($val['id'], $val['title']);
			}
		}
		showtagheader('div', 'identity_id_1', $item['identity_id'] == 1 || !$item ? true : '','identity_id_1');
			showsetting('&#26435;&#38480;', array('group_id_1', $groupList[1]),$item['group_id'], 'mradio');
		showtagfooter('div');
		showtagheader('div', 'identity_id_2', $item['identity_id'] == 2 ? true : '','identity_id_2');
			showsetting('&#26435;&#38480;', array('group_id_2', $groupList[2]),$item['group_id'], 'mradio');
		showtagfooter('div');
		showtagheader('div', 'identity_id_3', $item['identity_id'] == 3 ? true : '','identity_id_3');
			showsetting('&#26435;&#38480;', array('group_id_3', $groupList[3]),$item['group_id'], 'mradio');
		showtagfooter('div');
		showsetting('&#21040;&#26399;&#26102;&#38388;', 'due_time',$item['due_time'] ? date('Y-m-d',$item['due_time']) : '', 'calendar');
		
		showsetting($fn_shops->setting['lang']['SetTopTime'], 'topdateline',$item['topdateline'] ? date('Y-m-d H:i',$item['topdateline']) : '', 'calendar','','','',1);
		
		if($item){
			showsetting($fn_shops->setting['lang']['RefreshTime'], 'updateline',$item['updateline'] ? date('Y-m-d H:i',$item['updateline']) : '', 'calendar','','','',1);
		}

		if($item){
			showsetting($fn_shops->setting['lang']['TimeTitle'], 'dateline',date('Y-m-d H:i',$item['dateline']), 'calendar','','','',1);
		}

		showsetting($fn_shops->setting['lang']['Click'], 'click', $item['click'], 'text');

		showsetting($fn_shops->setting['lang']['audit_state'],array('audit_state',DyadicArray($fn_shops->setting['lang']['audit_state_arr'])),$item ? $item['audit_state'] : 1,'mradio');
		
		showsetting($fn_shops->setting['lang']['DisplayTitle'], 'display', $item ? $item['display'] : 1, 'radio');
		
		showsubmit('DetailSubmit','&#20445;&#23384;&#37197;&#32622;');
		showtagfooter('div');
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');

		$upLoadHtml  = '';
//		if($item['album']){
//			foreach(explode(',',$item['album']) as $val) {
//				$albumJsArray[] = '"'.$val.'"';
//			}
//			$upLoadHtml .= '
//			var InputArray = new Array('. implode(',',$albumJsArray).');
//			$("#Album").AppUpload({InputName:"upload_album",InputExist:true,InputArray:InputArray});';
//		}else{
//			$upLoadHtml .= '$("#Album").AppUpload({InputName:"upload_album"});';
//		}

		echo '<script src="source/plugin/fn_assembly/static/js/mobiscroll.custom-2.16.1.min.js"></script><link rel="stylesheet" href="source/plugin/fn_assembly/static/css/mobiscroll.custom-2.16.1.min.css"><script charset=utf-8 src="https://map.qq.com/api/js?v=2.exp&key='.$Config['PluginVar']['TxMapKey'].'"></script>'.$UploadConfig['CssJsHtml'];
		echo '
			<script>
			//��ע
			$(document).on("click",".MapClick",function(){
				if(!$("#MapPage").attr("src")){
					$("#MapPage").attr("src","https://apis.map.qq.com/tools/locpicker?search=1&type=1&key='.$Config['PluginVar']['TxMapKey'].'&referer=myapp&'.($item['lat'] && $item['lng'] ? 'coord='.$item['lat'].','.$item['lng'] : '').'");
				}
				$(".TipMap").fadeIn();
				return false;
			});
			window.addEventListener("message", function(Event) {
				var Loc = Event.data;
				if (Loc && Loc.module == "locationPicker") {
					var Geocoder = new qq.maps.Geocoder();
					Geocoder.getAddress(new qq.maps.LatLng(Loc.latlng.lat, Loc.latlng.lng));
					Geocoder.setComplete(function(res) {
						$("input[name=\'lat\']").val(res.detail.location.lat);
						$("input[name=\'lng\']").val(res.detail.location.lng);
						$("input[name=\'address\']").val(res.detail.addressComponents.city + res.detail.addressComponents.district + (res.detail.addressComponents.streetNumber ? res.detail.addressComponents.streetNumber : res.detail.addressComponents.street));
						$(".TipMap").fadeOut();
					});
					Geocoder.setError(function() {
						alert("\u51fa\u9519\u4e86\uff0c\u8bf7\u8f93\u5165\u6b63\u786e\u7684\u5730\u5740\uff01\uff01\uff01");
					});
				}
			}, false);
			//��ע End
			var ue = UE.getEditor("content",{autoHeightEnabled: false,autoFloatEnabled:false,enableAutoSave: false});
			'.$upLoadHtml.'
			</script> 	
		';

	}else{

		foreach($_GET['upload_album'] as $key => $val) {
			$_GET['upload_album'][$key] = strpos($val,'http') !== false ? $val : $_G['siteurl'].$val;
		}
		
		$data['uid'] = intval($_GET['new_uid']);
		$member = DB::fetch_first('SELECT username FROM '.DB::table('common_member').' where uid = '.$data['uid']);
		$data['username'] = addslashes(strip_tags($member['username']));
		$data['admin'] = $data['uid'];
		$data['name'] = $data['bname'] = addslashes(strip_tags($_GET['name']));
		$data['phone'] = addslashes(strip_tags($_GET['phone']));
		$data['classid'] = intval($_GET['new_classid']);
		$data['regionid'] = intval($_GET['new_regionid']);
		$data['address'] = addslashes(strip_tags($_GET['address']));
		$data['lat'] = addslashes(strip_tags($_GET['lat']));
		$data['lng'] = addslashes(strip_tags($_GET['lng']));
		$data['wx'] = addslashes(strip_tags($_GET['wx']));
		$data['video_url'] = addslashes(strip_tags($_GET['video_url']));
		$data['pano_url'] = addslashes(strip_tags($_GET['pano_url']));
		$data['music_url'] = addslashes(strip_tags($_GET['music_url']));
		$data['business_time_start'] = addslashes(strip_tags($_GET['business_time_start']));
		$data['business_time_end'] = addslashes(strip_tags($_GET['business_time_end']));
		$data['content'] = addslashes($_GET['content']);//�豣��Html
		$data['notice'] = addslashes($_GET['notice']);//�豣��Html
		$data['desc'] = addslashes($_GET['desc']);//�豣��Html
		$data['click'] = intval($_GET['click']);
		$data['topdateline'] = $_GET['topdateline'] ? strtotime($_GET['topdateline']) : '';
		$data['audit_state'] = intval($_GET['audit_state']);
		$data['display'] = intval($_GET['display']);
		$data['group_id'] = intval($_GET['group_id_'.intval($_GET['identity_id'])]);
		$data['identity_id'] = intval($_GET['identity_id']);
		$data['info_nav'] = $data['identity_id'] == 2 && !$item['info_nav'] ? $fn_shops->setting['agent_default_fenlei_classid'] : ($item['info_nav'] ? $item['info_nav'] : '');
		$data['due_time'] = $_GET['due_time'] ? strtotime($_GET['due_time']) : '';
		$data = array_merge($data,$Fn_Admin->uploadFiles($_FILES,false));

		if($item){
			$data['updateline'] = strtotime($_GET['updateline']);
			C::t('#fn_shops#fn_shops')->update($data,$id);
			GetInsertDoLog('add_shops','fn_'.$_GET['mod'],array('id'=>$id));//������¼
			if($data['classid'] != $item['classid']){
				C::t('#fn_shops#fn_shops_class')->update_by_shops_count($data['classid']);
				C::t('#fn_shops#fn_shops_class')->update_by_shops_count($item['classid'],'-');
			}
		}else{
			$data['channel'] = 1;
			$data['source'] = 4;
			$data['dateline'] = $data['updateline'] = $data['edit_dateline'] = time();
			$id = C::t('#fn_shops#fn_shops')->insert($data,true);
			C::t('#fn_shops#fn_shops_class')->update_by_shops_count($data['classid']);

			//������Ϣͳ��
			C::t('#fn_fenlei#fn_fenlei_info')->uid_update(array('shops_id'=>$id,'role'=>2),$data['uid']);
			C::t('#fn_shops#fn_shops')->update(array('info_count'=>C::t('#fn_fenlei#fn_fenlei_info')->first_by_count(" where i.hide = 1 and i.display = 1 and i.audit_state = 1 and i.pay_state = 1 and i.shops_id = ".$id.($data['info_nav'] ? ' and i.classid in('.$data['info_nav'].')' : ''))),$id);
			C::t('#fn_fenlei#fn_fenlei_member')->uid_update(array('shops_id'=>$id),$data['uid']);
			//������Ϣͳ�� END
			GetInsertDoLog('edit_shops','fn_'.$_GET['mod'],array('id'=>$id));//������¼
		}
		fn_cpmsg($fn_shops->setting['lang']['UpdateOk'],$Fn_Admin->Config['IframeItemUrl'].'&submodel=list','succeed');
		exit();
	}
}else if($SubModel == 'album'){//���ӻ�༭

	$id = intval($_GET['sid']);
	
	$item = C::t('#fn_shops#fn_shops')->fetch_by_id($id);

	if(!submitcheck('DetailSubmit')) {
		$opTitle = $fn_shops->setting['lang']['AddTitle'];
		if($item){
			$item['album'] = $item['album'] ? dunserialize($item['album']) : '';
			$opTitle = $fn_shops->setting['lang']['EditTitle'].$item['name'].'&#30340;&#30456;&#20876;';
		}
		
		//ͼƬ�ϴ�
		if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_assembly/class/class_upload.php')){
			@require_once libfile('class/upload','plugin/fn_assembly');
			$UploadConfig = fn_upload::Config();
		}

		echo '<script src="'.$Config['StaticPath'].'/ueditor/'.CHARSET.'/ueditor.config.js" type="text/javascript"></script><script src="'.$Config['StaticPath'].'/ueditor/'.CHARSET.'/ueditor.all.js" type="text/javascript"></script>';

		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-header', true,'with-border box-header');
		showtitle($opTitle,'class="box-title"');
		showtagfooter('div');
		showformheader($Fn_Admin->Config['IframeSubModelUrl'].'&sid='.$id,'enctype');
		showtagheader('div', 'box-body', true,'box-body');
		$upLoadHtml  = '';
		foreach($fn_shops->allAlbumList[$item['album_id']]['children'] as $key => $val) {
			echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$fn_shops->allAlbumList[$val]['name'].'&#30456;&#20876;</label><div class="col-sm-9"><div class="AdminSingleUpload"><div class="PhotoControl" id="album-'.$val.'"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';
			if($item['album'][$val]){
				$imagesJsArray = array();
				foreach($item['album'][$val] as $k => $v) {
					$imagesJsArray[] = '"'.$v.'"';
				}
				$upLoadHtml .= '
				var InputArray = new Array('.implode(',',$imagesJsArray).');
				$("#album-'.$val.'").AppUpload({InputName:"new_album_'.$val.'",InputExist:true,InputArray:InputArray});';
			}else{
				$upLoadHtml .= '$("#album-'.$val.'").AppUpload({InputName:"new_album_'.$val.'"});';
			}
		}
		
		showsubmit('DetailSubmit','&#20445;&#23384;&#37197;&#32622;');
		showtagfooter('div');
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');

		echo $UploadConfig['CssJsHtml'];
		echo '
			<script>
			'.$upLoadHtml.'
			</script> 	
		';

	}else{
		//���
		$album = $albumCount = $albumList = array();
		foreach($fn_shops->allAlbumList[$item['album_id']]['children'] as $key => $val) {
			foreach($_GET['new_album_'.$val] as $k => $v) {
				$album['all'][] = $album[$val][$k] = strpos($v,'http') !== false ? $v : $fn_shops->_G['siteurl'].$v;
			}
		}
		$album['count'] = count($album['all']);
		$albumData['sid'] = $item['id'];
		$albumData['album_id'] = $item['album_id'];
		$albumData['imgs'] = serialize($album);
		$albumItem = C::t('#fn_shops#fn_shops_album')->fetch_by_sid_album($item['id'],$item['album_id']);
		$albumItem ? C::t('#fn_shops#fn_shops_album')->update($albumData,$albumItem['id']) : C::t('#fn_shops#fn_shops_album')->insert($albumData,$albumItem['id']);
		//��� END
		fn_cpmsg($fn_shops->setting['lang']['UpdateOk'],$Fn_Admin->Config['IframeItemUrl'].'&submodel=list','succeed');
		exit();
	}
}
//From: Dism_taobao_com
?> 