<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

showtagheader('div', 'box', true,'box');
showtagheader('div', 'box-body', true,'box-body');
showtagheader('div', 'tab-content', true,'tab-content');
showsetting('&#39318;&#39029;&#38142;&#25509;', 'PluginLink',$fn_shops->getUrl('index'), 'text');
showsetting('&#21830;&#23478;&#20837;&#39547;', 'PluginLink',$fn_shops->getUrl('user',array('form'=>'info')), 'text');
showtagfooter('div');
showtagfooter('div');
showtagfooter('div');

?>