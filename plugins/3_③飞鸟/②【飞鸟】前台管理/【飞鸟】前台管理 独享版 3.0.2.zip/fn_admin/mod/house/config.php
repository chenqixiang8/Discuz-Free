<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if(!$Fn_Admin->CheckUserGroup('house_all') && !$Fn_Admin->CheckUserGroup('house_config')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

@require_once libfile('function/cache');
@require_once libfile('function/core','plugin/fn_assembly');

$setting_name = 'fn_'.$_GET['mod'].'_setting';
loadcache($setting_name);
$common_setting = $_G['cache'][$setting_name];
$setting = $common_setting = array_filter($common_setting) ? $common_setting : array();
foreach($setting as $key => $value) {
	$setting[$key] = is_array($value) ? $value : stripslashes($value);
}

$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeItemUrl'];

if(!submitcheck('DetailSubmit')) {
	//ͼƬ�ϴ�
	if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_assembly/class/class_upload.php')){
		@require_once libfile('class/upload','plugin/fn_assembly');
		$UploadConfig = fn_upload::Config();
	}

	showtagheader('div', 'box', true,'box');
	showformheader($FormUrl,'enctype');
	if(AppYes){
		$AppNav = '<li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#app" role="tab" aria-expanded="false"><span class="hidden-sm-up"><i class="ion-email"></i></span> <span class="hidden-xs-down">&#65;&#80;&#80;&#35774;&#32622;</span></a> </li>';
	}
	echo <<<HTML
		<ul class="nav nav-tabs customtab" role="tablist">
          <li class="nav-item"> <a class="nav-link active" data-toggle="tab" href="#basics" role="tab" aria-expanded="true"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#22522;&#30784;&#35774;&#32622;</span></a> </li>
		  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#nav" role="tab" aria-expanded="true"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#23548;&#33322;&#35774;&#32622;</span></a> </li>
		  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#index" role="tab" aria-expanded="true"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#39318;&#39029;&#35774;&#32622;</span></a> </li>
		  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#money" role="tab" aria-expanded="true"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#37329;&#39069;&#35774;&#32622;</span></a> </li>
		  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#disc" role="tab" aria-expanded="true"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#27004;&#30424;&#35774;&#32622;</span></a> </li>
		  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#pc" role="tab" aria-expanded="true"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#30005;&#33041;&#29256;&#35774;&#32622;</span></a> </li>
		  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#wx" role="tab" aria-expanded="false"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#20844;&#20247;&#21495;&#35774;&#32622;</span></a> </li>
		  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#sms" role="tab" aria-expanded="true"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#30701;&#20449;&#27169;&#26495;&#35774;&#32622;</span></a> </li>
		  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#share" role="tab" aria-expanded="false"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#20998;&#20139;&#35774;&#32622;</span></a> </li>
		  <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#color" role="tab" aria-expanded="false"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#39068;&#33394;&#35774;&#32622;</span></a> </li>
		  {$AppNav}
        </ul>
HTML;

	showtagheader('div', 'box-body', true,'box-body');

	showtagheader('div', 'tab-content', true,'tab-content');

	echo <<<HTML
	<!-- ��������  -->
	<div class="tab-pane active" id="basics" role="tabpanel" aria-expanded="true">
HTML;

	showsetting('&#26631;&#39064;', 'setting[Title]', $setting['Title'] ? $setting['Title'] : '&#12304;&#39134;&#40479;&#12305;&#21516;&#22478;&#25151;&#20135;', 'text');

	showsetting('&#31649;&#29702;&#21592;&#85;&#105;&#100;&#115;', 'setting[AdminUids]', $setting['AdminUids'], 'text','','','&#26435;&#38480;&#65306;&#21487;&#31649;&#29702;&#25152;&#26377;&#25151;&#28304;&#32;&#26684;&#24335;&#65306;&#49;&#44;&#50;&#44;&#51;&#32;&#65281;&#65281;&#65281;&#32;&#27880;&#24847;&#65306;&#35813;&#35774;&#32622;&#21644;&#12304;&#21069;&#21488;&#31649;&#29702;&#12305;&#25554;&#20214;&#26080;&#20851;');

	$ModularListArray = array(
		array('1','&#20108;&#25163;&#25151;'),
		array('2','&#20986;&#31199;&#25151;'),
		array('3','&#21830;&#38138;'),
		array('4','&#21378;&#25151;'),
		array('5','&#20889;&#23383;&#27004;'),
		array('6','&#20179;&#24211;'),
		array('7','&#22303;&#22320;'),
	);
	showsetting('&#27169;&#22359;&#24320;&#21551;', array('setting[ModularList][]',$ModularListArray),$common_setting ? $setting['ModularList'] : array(1,2,3,4,5,6,7),'mselect');

	showsetting('&#21306;&#22495;&#35774;&#32622;', 'setting[Area]', $setting['Area'] ? $setting['Area'] : '1=&#22825;&#27827;&#21306;
1.1=&#20307;&#32946;&#35199;&#36335;
1.2=&#24191;&#24030;&#19996;&#31449;
1.3=&#29141;&#22616;
2=&#36234;&#31168;&#21306;
2.1=&#21271;&#20140;&#36335;
2.2=&#35199;&#38376;&#21475;
2.3=&#23567;&#21271;
2.4=&#28120;&#37329;
3=&#30333;&#20113;&#21306;
3.1=&#40857;&#24402;
3.2=&#32599;&#20914;&#22260;
3.3=&#21516;&#21644;', 'textarea','','',lang('plugin/fn_admin', 'MultilevelClassificationTips'));
	
	showsetting('&#23458;&#26381;&#30005;&#35805;', 'setting[OnlineMobile]', $setting['OnlineMobile'], 'text');
	
	$OnlineWxPathHtml = ($setting['OnlineWxPath'] ? '<a href="'.$setting['OnlineWxPath'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['OnlineWxPath'].'" height="55"/></a>' : '').'&#19981;&#22635;&#21017;&#19981;&#24320;&#21551;&#65292;&#24494;&#20449;&#20869;&#25165;&#26174;&#31034;';
	showsetting('&#23458;&#26381;&#24494;&#20449;&#20108;&#32500;&#30721;', 'new_OnlineWxPath',$setting['OnlineWxPath'], 'filetext', '', 0, $OnlineWxPathHtml);

	$setting['CoverPath'] = $setting['CoverPath'] ? $setting['CoverPath'] : '/source/plugin/fn_house/static/images/cover.jpg';
	$CoverPathHtml = '<a href="'.$setting['CoverPath'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['CoverPath'].'" height="55"/></a>&#24314;&#35758;&#23610;&#23544;&#65306;&#54;&#52;&#48;&#32;&#42;&#32;&#52;&#51;&#48;';
	showsetting('&#40664;&#35748;&#21015;&#34920;&#23553;&#38754;', 'new_CoverPath',$setting['CoverPath'], 'filetext', '', 0, $CoverPathHtml);

	$setting['ViewCoverPath'] = $setting['ViewCoverPath'] ? $setting['ViewCoverPath'] : '/source/plugin/fn_house/static/images/cover.jpg';
	$ViewCoverPathHtml = '<a href="'.$setting['ViewCoverPath'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['ViewCoverPath'].'" height="55"/></a>&#24314;&#35758;&#23610;&#23544;&#65306;&#54;&#52;&#48;&#32;&#42;&#32;&#52;&#51;&#48;';
	showsetting('&#40664;&#35748;&#35814;&#24773;&#20027;&#22270;', 'new_ViewCoverPath',$setting['ViewCoverPath'], 'filetext', '', 0, $ViewCoverPathHtml);

	$setting['ArticleCoverPath'] = $setting['ArticleCoverPath'] ? $setting['ArticleCoverPath'] : '/source/plugin/fn_house/static/images/cover.jpg';
	$ArticleCoverPathHtml = '<a href="'.$setting['ArticleCoverPath'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['ArticleCoverPath'].'" height="55"/></a>';
	showsetting('&#36164;&#35759;&#40664;&#35748;&#32553;&#30053;&#22270;', 'new_ArticleCoverPath',$setting['ArticleCoverPath'], 'filetext', '', 0, $ArticleCoverPathHtml);

	$setting['AddFloatPath'] = $setting['AddFloatPath'] ? $setting['AddFloatPath'] : '/source/plugin/fn_house/static/images/add.png';
	$AddFloatPathHtml = '<a href="'.$setting['AddFloatPath'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['AddFloatPath'].'" height="55"/></a>';
	showsetting('&#21457;&#24067;&#24748;&#28014;&#22270;&#26631;&#21543;', 'new_AddFloatPath',$setting['AddFloatPath'], 'filetext', '', 0, $AddFloatPathHtml);

	$setting['TopPath'] = $setting['TopPath'] ? $setting['TopPath'] : '/source/plugin/fn_house/static/images/top.png';
	$TopPathHtml = '<a href="'.$setting['TopPath'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['TopPath'].'" height="55"/></a>';
	showsetting('&#32622;&#39030;&#22270;&#26631;', 'new_TopPath',$setting['TopPath'], 'filetext', '', 0, $TopPathHtml);

	showsetting('&#26159;&#21542;&#24320;&#21551;&#20013;&#20171;&#20837;&#39547;',array('setting[AgentSwitch]', array(
		array('1','&#26159;', array('AgentSwitch_1' => '')),
		array('0','&#21542;', array('AgentSwitch_1' => 'none')),
	), TRUE),$common_setting ? $setting['AgentSwitch'] : 1, 'mradio');
	showtagheader('div', 'AgentSwitch_1', $setting['AgentSwitch'] || !$common_setting ? true : '','sub');
		showsetting('&#20013;&#20171;&#36873;&#25321;&#38376;&#24215;&#25552;&#31034;&#35821;', 'setting[LocationStoreTips]',$setting['LocationStoreTips'] ? $setting['LocationStoreTips'] : '&#35880;&#24910;&#36873;&#25321;&#65292;&#36873;&#25321;&#21518;&#19981;&#21487;&#26356;&#25913;&#65292;&#36873;&#25321;&#21518;&#21407;&#26377;&#25151;&#28304;&#23637;&#31034;&#21040;&#35813;&#38376;&#24215;&#65281;<br>&#27809;&#26377;&#24744;&#38656;&#35201;&#30340;&#38376;&#24215;&#65311;&#32852;&#31995;&#23458;&#26381;&#24494;&#20449;&#65306;xxxxx&#65292;&#28155;&#21152;&#38376;&#24215;', 'text');
		showsetting('&#20013;&#20171;&#36873;&#25321;&#38376;&#24215;&#25552;&#31034;&#35821;2', 'setting[LocationStoreTips2]',$setting['LocationStoreTips2'] ? $setting['LocationStoreTips2'] : '&#26356;&#25913;&#38376;&#24215;&#35831;&#32852;&#31995;&#23458;&#26381;&#24494;&#20449;&#65306;&#120;&#120;&#120;&#120;&#120;', 'text','','','&#36873;&#25321;&#38376;&#24215;&#21518;&#30340;&#25552;&#31034;&#35821;');
		showsetting('&#20013;&#20171;&#20837;&#39547;&#24378;&#21046;&#36873;&#25321;&#38376;&#24215;', 'setting[ChoiceStoreSwitch]', $common_setting ? $setting['ChoiceStoreSwitch'] : 1, 'radio');
		showsetting('&#20013;&#20171;&#35748;&#35777;&#25165;&#21487;&#21457;&#24067;', 'setting[AgentVerifyAddSwitch]', $setting['AgentVerifyAddSwitch'], 'radio','','','&#20013;&#20171;&#26159;&#21542;&#35748;&#35777;&#21518;&#25165;&#21487;&#21457;&#24067;&#25151;&#28304;');
		showsetting('&#20013;&#20171;&#21015;&#34920;&#26174;&#31034;&#22995;&#21517;', 'setting[AgentListNameSwitch]', $setting['AgentListNameSwitch'], 'radio','','','&#20013;&#20171;&#21015;&#34920;&#26159;&#21542;&#26174;&#31034;&#30495;&#23454;&#22995;&#21517;&#65288;&#24050;&#22635;&#20889;&#30495;&#23454;&#22995;&#21517;&#26377;&#25928;&#65289;');
		
		showsetting('&#20013;&#20171;&#24320;&#21551;&#38065;&#21253;&#27169;&#24335;',array('setting[WalletSwitch]', array(
			array('1','&#26159;', array('WalletSwitch_1' => '')),
			array('0','&#21542;', array('WalletSwitch_1' => 'none')),
		), TRUE),$setting['WalletSwitch'], 'mradio');
		showtagheader('div', 'WalletSwitch_1', $setting['AgentSwitch'] ? true : '','sub');
			showsetting('&#38065;&#21253;&#21517;&#31216;', 'setting[WalletTitle]', $setting['WalletTitle'] ? $setting['WalletTitle'] : '&#37329;&#24065;', 'text');
			showsetting('&#38065;&#21253;&#21333;&#20301;', 'setting[WalletText]', $setting['WalletText'] ? $setting['WalletText'] : '&#20010;', 'text');
		showtagfooter('div');

		showsetting('&#24320;&#21551;&#20013;&#20171;&#35748;&#35777;',array('setting[AgentAuthenticationSwitch]', array(
			array('1','&#26159;', array('AgentAuthenticationSwitch_1' => '')),
			array('0','&#21542;', array('AgentAuthenticationSwitch_1' => 'none')),
		), TRUE),$setting['AgentAuthenticationSwitch'], 'mradio','','','&#24320;&#21551;&#21518;&#65292;&#38656;&#35201;&#36141;&#20080;&#26597;&#35810;&#25509;&#21475;&#65292;&#35748;&#35777;&#25104;&#21151;&#21518;&#65292;&#25163;&#26426;&#21495;/&#22995;&#21517;/&#36523;&#20221;&#35777;&#21495;&#19981;&#21487;&#26356;&#25913;<br>&#36141;&#20080;&#22320;&#22336;&#65306;https://market.aliyun.com/products/57000002/cmapi026061.html');
		showtagheader('div', 'AgentAuthenticationSwitch_1', $setting['AgentAuthenticationSwitch'] ? true : '','sub');
			showsetting('&#35748;&#35777;&#65;&#112;&#112;&#67;&#111;&#100;&#101;', 'setting[AuthenticationCode]', $setting['AuthenticationCode'], 'text','','','&#38656;&#35201;&#20808;&#36141;&#20080;&#25509;&#21475;&#65292;&#25165;&#21487;&#33719;&#21462;&#65292;&#33719;&#21462;&#22320;&#22336;&#65306;https://market.console.aliyun.com/imageconsole/index.htm');
		showtagfooter('div');

		showsetting('&#20013;&#20171;&#26597;&#30475;&#25151;&#28304;&#25442;&#23458;&#26381;&#30005;&#35805;', 'setting[AgentViewTel]',$setting['AgentViewTel'], 'radio','','','&#20013;&#20171;&#26597;&#30475;&#25151;&#28304;&#30005;&#35805;&#26159;&#21542;&#26367;&#25442;&#23458;&#26381;&#30005;&#35805;&#65292;&#35831;&#20808;&#22635;&#20889;&#23458;&#26381;&#30005;&#35805;');

	showtagfooter('div');

	showsetting('&#20449;&#24687;&#27969;&#23548;&#33322;', 'setting[InfoNavList]', $common_setting ? $setting['InfoNavList'] : '0,1,2,3,4,5,6,7', 'text','','','&#48;&#20195;&#34920;&#26368;&#26032;&#21457;&#24067;&#65292;&#49;&#20195;&#34920;&#20108;&#25163;&#25151;&#65292;&#50;&#20195;&#34920;&#20986;&#31199;&#25151;&#65292;&#51;&#20195;&#34920;&#21830;&#38138;&#65292;&#52;&#20195;&#34920;&#21378;&#25151;&#65292;&#53;&#20195;&#34920;&#20889;&#23383;&#27004;&#65292;&#54;&#20195;&#34920;&#20179;&#24211;&#65292;&#55;&#20195;&#34920;&#22303;&#22320;&#65292;&#26684;&#24335;&#65306;&#48;&#44;&#49;&#44;&#50;&#44;&#51;&#44;&#52;&#44;&#53;');

	showsetting('&#21015;&#34920;&#35843;&#29992;&#26465;&#25968;', 'setting[ListNum]', $setting['ListNum'] ? $setting['ListNum'] : '10', 'text');

	showsetting('&#27714;&#31199;&#27714;&#36141;&#21015;&#34920;&#25968;', 'setting[DemandListNum]', $setting['DemandListNum'] ? $setting['DemandListNum'] : '10', 'text');

	showsetting('&#26174;&#31034;&#39030;&#37096;&#22266;&#23450;&#23548;&#33322;', 'setting[HeaderSwitch]', $common_setting ? $setting['HeaderSwitch'] : 1, 'radio');

	showsetting('&#21015;&#34920;&#26174;&#31034;&#20013;&#20171;&#20010;&#20154;', 'setting[ListNatureSwitch]', $common_setting ? $setting['ListNatureSwitch'] : 1, 'radio');

	showsetting('&#25151;&#28304;&#21015;&#34920;&#27983;&#35272;&#35745;&#31639;&#27983;&#35272;&#37327;', 'setting[ListClickSwitch]',$setting['ListClickSwitch'] , 'radio');

	showsetting('&#27714;&#31199;&#27714;&#36141;&#26159;&#21542;&#23457;&#26680;', 'setting[DemandAddSwitch]',$setting['DemandAddSwitch'], 'radio');

	showsetting('&#26159;&#21542;&#24320;&#21551;&#21327;&#35758;',array('setting[Agreement]', array(
		array('1','&#26159;', array('Agreement_1' => '')),
		array('0','&#21542;', array('Agreement_1' => 'none')),
	), TRUE),$setting['Agreement'], 'mradio','','','&#24320;&#21551;&#21518;&#65292;&#21457;&#24067;&#25151;&#20135;&#65292;&#38656;&#35201;&#21246;&#36873;&#21516;&#24847;&#21327;&#35758;');
	showtagheader('div', 'Agreement_1', $setting['Agreement'] ? true : '','sub');
		showsetting('&#21327;&#35758;&#26631;&#39064;', 'setting[AgreementTitle]',$common_setting['AgreementTitle'] ? $setting['AgreementTitle'] : '&#21516;&#24847;&#39134;&#40479;&#25151;&#20135;&#32593;<span class=\'Color AgreementClick\'>&#12298;&#38544;&#31169;&#25919;&#31574;&#12299;<span>','text','','','&#27880;&#24847;&#65306;&#104;&#116;&#109;&#108;&#20195;&#30721;&#21247;&#21024;');
		showsetting('&#21327;&#35758;&#20869;&#23481;', 'setting[AgreementContent]',$common_setting['AgreementContent'] ? $setting['AgreementContent'] : '&#36825;&#26159;&#21327;&#35758;&#20869;&#23481;','textarea');
		showsetting('&#21327;&#35758;&#25552;&#31034;&#35821;', 'setting[AgreementTips]',$common_setting['AgreementTips'] ? $setting['AgreementTips'] : '&#35831;&#20808;&#21516;&#24847;&#38544;&#31169;&#25919;&#31574;','text');
	showtagfooter('div');

	showsetting('&#21457;&#24067;&#25151;&#28304;&#26159;&#21542;&#23457;&#26680;', 'setting[InfoAddSwitch]',$setting['InfoAddSwitch'], 'radio');

	showsetting('&#32534;&#36753;&#25151;&#28304;&#26159;&#21542;&#23457;&#26680;', 'setting[EditDisplaySwitch]',$setting['EditDisplaySwitch'], 'radio');

	showsetting('&#21457;&#24067;&#26159;&#21542;&#26174;&#31034;&#32622;&#39030;', 'setting[PublishTopSwitch]', $common_setting ? $setting['PublishTopSwitch'] : 1, 'radio','','','&#21457;&#24067;&#25104;&#21151;&#21069;&#65292;&#26159;&#21542;&#21487;&#20197;&#36873;&#25321;&#32622;&#39030;');

	showsetting('&#21457;&#24067;&#26159;&#21542;&#24517;&#39035;&#19978;&#20256;&#22270;&#29255;', 'setting[PublishImageSwitch]', $common_setting ? $setting['PublishImageSwitch'] : 1, 'radio');

	showsetting('&#21457;&#24067;&#26174;&#31034;&#26631;&#39064;&#22635;&#20889;', 'setting[PublishTitleSwitch]', $common_setting ? $setting['PublishTitleSwitch'] : 1, 'radio');

	showsetting('&#21457;&#24067;&#26174;&#31034;&#26397;&#21521;&#36873;&#25321;',array('setting[PublishOrientationSwitch]', array(
		array('1','&#26159;', array('PublishOrientationSwitch_1' => '')),
		array('0','&#21542;', array('PublishOrientationSwitch_1' => 'none')),
	), TRUE),$setting['PublishOrientationSwitch'], 'mradio','','','&#20108;&#25163;&#25151;&#47;&#20986;&#31199;&#25151;&#26377;&#25928;');
	
	showtagheader('div', 'PublishOrientationSwitch_1', $setting['PublishOrientationSwitch'] ? true : '','sub');
		showsetting('&#26397;&#21521;&#26159;&#21542;&#24517;&#22635;', 'setting[PublishOrientationRequiredwitch]',$setting['PublishOrientationRequiredwitch'], 'radio');
	showtagfooter('div');
	
	showsetting('&#21457;&#24067;&#26174;&#31034;&#23567;&#21306;&#22635;&#20889;',array('setting[PublishsSmallAreaSwitch]', array(
		array('1','&#26159;', array('PublishsSmallAreaSwitch_1' => '')),
		array('0','&#21542;', array('PublishsSmallAreaSwitch_1' => 'none')),
	), TRUE),$setting['PublishsSmallAreaSwitch'], 'mradio','','','&#20108;&#25163;&#25151;&#47;&#20986;&#31199;&#25151;&#26377;&#25928;');
	
	showtagheader('div', 'PublishsSmallAreaSwitch_1', $setting['PublishsSmallAreaSwitch'] ? true : '','sub');
		showsetting('&#21457;&#24067;&#23567;&#21306;&#38480;&#21046;&#23383;&#25968;', 'setting[SmallAreaLength]',$setting['SmallAreaLength'], 'text','','','&#48;&#25110;&#31354;&#20195;&#34920;&#19981;&#38480;&#21046;');
		showsetting('&#21457;&#24067;&#23567;&#21306;&#26159;&#21542;&#24517;&#22635;', 'setting[PublishsSmallAreaFillSwitch]', $setting['PublishsSmallAreaFillSwitch'], 'radio');
	showtagfooter('div');

	showsetting('&#21457;&#24067;&#26159;&#21542;&#26174;&#31034;&#26631;&#27880;', 'setting[PublishMapSwitch]', $common_setting ? $setting['PublishMapSwitch'] : 1, 'radio','','','&#26631;&#27880;&#29992;&#20110;&#21608;&#36793;&#37197;&#22871;&#26174;&#31034;');

	showsetting('&#21457;&#24067;&#26159;&#21542;&#26174;&#31034;&#22635;&#20889;&#24494;&#20449;', 'setting[PublishWxSwitch]', $setting['PublishWxSwitch'], 'radio');

	showsetting('&#21457;&#24067;&#26159;&#21542;&#24377;&#20986;&#22996;&#25176;&#24377;&#31383;',array('setting[PublishEntrustSwitch]', array(
		array('1','&#26159;', array('PublishEntrustSwitch_1' => '')),
		array('0','&#21542;', array('PublishEntrustSwitch_1' => 'none')),
	), TRUE),$setting['PublishEntrustSwitch'], 'mradio');
	showtagheader('div', 'PublishEntrustSwitch_1', $setting['PublishEntrustSwitch'] ? true : '','sub');
		showsetting('&#22996;&#25176;&#24377;&#31383;&#25991;&#23383;', 'setting[PublishEntrustSText]',$common_setting ? $setting['PublishEntrustSText'] : '&#24744;&#36824;&#21487;&#20197;&#23558;&#25151;&#28304;&#22996;&#25176;&#32473;&#20840;&#31449;&#20013;&#20171;&#21734;&#65281;', 'text');
	showtagfooter('div');

	showsetting('&#21457;&#24067;&#26174;&#31034;&#20010;&#20154;&#20013;&#20171;', 'setting[PublishTypeSwitch]', $setting['PublishTypeSwitch'], 'radio','','','&#21457;&#24067;&#26159;&#21542;&#26174;&#31034;&#20010;&#20154;&#20013;&#20171;&#36873;&#39033;&#65292;&#20851;&#38381;&#12304;&#24320;&#21551;&#20013;&#20171;&#20837;&#39547;&#12305;&#26377;&#25928;&#65281;&#65281;&#65281;');

	showsetting('&#21457;&#24067;&#21830;&#38138;&#47;&#21378;&#25151;&#22635;&#20889;&#22320;&#21517;', 'setting[PublishShopSmallAreaSwitch]', $setting['PublishShopSmallAreaSwitch'], 'radio','','','&#21457;&#24067;&#21830;&#38138;&#47;&#21378;&#25151;&#30340;&#26102;&#20505;&#65292;&#26159;&#21542;&#26174;&#31034;&#22320;&#21517;&#22635;&#20889;');

	showsetting('&#21457;&#24067;&#24320;&#21551;&#25151;&#19996;&#30005;&#35805;&#22635;&#20889;', 'setting[PublishMasterMobile]',$setting['PublishMasterMobile'], 'radio','','','&#21457;&#24067;&#26159;&#21542;&#24320;&#21551;&#25151;&#19996;&#30005;&#35805;&#22635;&#20889;&#65281;&#65281;&#65281;&#27880;&#24847;&#65306;&#20013;&#20171;&#26377;&#25928;');

	showsetting('&#21457;&#24067;&#20986;&#31199;&#26159;&#21542;&#23457;&#26680;', 'setting[InfoAddLeaseSwitch]', $setting['InfoAddLeaseSwitch'], 'radio','','','&#20986;&#31199;&#31867;&#22411;&#26159;&#21542;&#23457;&#26680;&#65292;&#21253;&#25324;&#20986;&#31199;&#47;&#21830;&#38138;&#20986;&#31199;&#31561;');

	showsetting('&#21457;&#24067;&#26631;&#27880;&#33258;&#21160;&#23450;&#20301;', 'setting[PublishMapLocationSwitch]', $setting['PublishMapLocationSwitch'], 'radio','','','&#21457;&#24067;&#26631;&#27880;&#26159;&#21542;&#20801;&#35768;&#33258;&#21160;&#23450;&#20301;&#65292;&#35813;&#24517;&#39035;&#35774;&#32622;&#12304;&#20840;&#23616;&#35774;&#32622;&#30340;&#40664;&#35748;&#32463;&#32428;&#24230;&#12305;&#25165;&#29983;&#25928;');
	
	showsetting('&#21457;&#24067;&#26159;&#21542;&#26631;&#39064;&#33258;&#21160;&#25340;&#25509;', 'setting[PublishAutoTitle]',$common_setting ? $setting['PublishAutoTitle'] : 1, 'radio');

	$InterviewSwitchsArray = array(
		array('1','&#20108;&#25163;&#25151;'),
		array('2','&#20986;&#31199;&#25151;'),
		array('3','&#21830;&#38138;'),
		array('4','&#21378;&#25151;'),
		array('5','&#20889;&#23383;&#27004;'),
		array('6','&#20179;&#24211;'),
		array('7','&#22303;&#22320;'),
	);
	showsetting('&#21457;&#24067;&#20801;&#35768;&#38754;&#35758;', array('setting[InterviewSwitchs][]',$InterviewSwitchsArray),$setting['InterviewSwitchs'],'mselect');

	showsetting('&#25551;&#36848;&#27169;&#26495;', 'setting[DescTemplate]', $setting['DescTemplate'],'textarea','','','&#19981;&#22635;&#20889;&#20195;&#34920;&#19981;&#24320;&#21551;&#65292;1&#20195;&#34920;&#20108;&#25163;&#25151;&#65292;2&#20195;&#34920;&#20986;&#31199;&#25151;&#65292;3&#20195;&#34920;&#21830;&#38138;&#65292;4&#20195;&#34920;&#21378;&#25151;&#65292;5&#20195;&#34920;&#21378;&#25151;&#65292;6&#20195;&#34920;&#20179;&#24211;&#65292;7&#20195;&#34920;&#22303;&#22320;&#65292;&#26684;&#24335;&#65306;1=&#20108;&#25163;&#25151;&#27169;&#26495;1|&#20108;&#25163;&#25151;&#27169;&#26495;2&#65281;&#65281;&#65281;&#20363;&#22914;<br>1=&#20108;&#25163;&#25151;&#27169;&#26495;1|&#20108;&#25163;&#25151;&#27169;&#26495;2<br>2=&#20986;&#31199;&#25151;&#27169;&#26495;1|&#20986;&#31199;&#25151;&#27169;&#26495;');

	showsetting('&#20010;&#20154;&#21457;&#24067;&#26465;&#25968;&#38480;&#21046;', 'setting[PersonalAddNum]',$common_setting ? $setting['PersonalAddNum'] : 3, 'text','','','&#48;&#25110;&#31354;&#20195;&#34920;&#19981;&#38480;&#21046;');

	showsetting('&#20010;&#20154;&#31105;&#27490;&#21457;&#24067;&#85;&#73;&#68;', 'setting[ProhibitUis]', $setting['ProhibitUis'], 'text','','','&#31105;&#27490;&#29992;&#25143;&#21457;&#24067;&#25151;&#28304;&#65292;&#38024;&#23545;&#20010;&#20154;&#65292;&#20837;&#39547;&#32463;&#32426;&#20154;&#24182;&#24320;&#36890;&#22871;&#39184;&#30340;&#29992;&#25143;&#35813;&#36873;&#39033;&#26080;&#25928;&#65281;&#65281;&#65281;&#26684;&#24335;&#65306;&#49;&#44;&#50;&#44;&#51;');

	showsetting('&#20010;&#20154;&#31105;&#27490;&#21457;&#24067;&#85;&#73;&#68;&#25552;&#31034;&#35821;', 'setting[ProhibitUisTips]', $setting['ProhibitUisTips'] ? $setting['ProhibitUisTips'] : '&#24744;&#24050;&#32463;&#34987;&#31105;&#27490;&#21457;&#24067;&#65292;&#22914;&#24819;&#32487;&#32493;&#21457;&#24067;&#65292;&#35831;&#20837;&#39547;&#32463;&#32426;&#20154;&#24182;&#24320;&#36890;&#22871;&#39184;&#65281;&#65281;&#65281;', 'text');

	showsetting('&#20840;&#23616;&#31105;&#27490;&#21457;&#24067;&#85;&#73;&#68;', 'setting[GlobalProhibitUis]', $setting['GlobalProhibitUis'], 'text','','','&#31105;&#27490;&#29992;&#25143;&#21457;&#24067;&#25151;&#28304;&#65292;&#38024;&#23545;&#20840;&#37096;&#20154;&#65292;&#19981;&#31649;&#26159;&#32463;&#32426;&#20154;&#36824;&#26159;&#20010;&#20154;&#37117;&#20250;&#31105;&#27490;&#65281;&#65281;&#65281;&#26684;&#24335;&#65306;&#49;&#44;&#50;&#44;&#51;');

	showsetting('&#20840;&#23616;&#31105;&#27490;&#21457;&#24067;&#85;&#73;&#68;&#25552;&#31034;&#35821;', 'setting[GlobalProhibitUisTips]', $setting['GlobalProhibitUisTips'] ? $setting['GlobalProhibitUisTips'] : '&#24744;&#24050;&#32463;&#34987;&#31105;&#27490;&#21457;&#24067;', 'text');

	showsetting('&#24453;&#23457;&#26680;&#21047;&#26032;&#32622;&#39030;&#25552;&#31034;&#35821;', 'setting[NoDisplayTips]',$common_setting ? $setting['NoDisplayTips'] : '&#35813;&#20449;&#24687;&#27491;&#22312;&#23457;&#26680;&#20013;&#65292;&#26242;&#19981;&#33021;&#21047;&#26032;&#25110;&#32622;&#39030;<br>&#35831;&#32852;&#31995;&#31649;&#29702;&#21592;&#24494;&#20449;&#65306;<span class=FColor>8888888</span>&#24555;&#36895;&#23457;&#26680;','textarea','','','&#24453;&#23457;&#26680;&#20449;&#24687;&#19981;&#33021;&#21047;&#26032;&#32622;&#39030;&#25552;&#31034;&#35821;');

	showsetting('&#36807;&#26399;&#26102;&#38388;', 'setting[ExpiryTime]', $setting['ExpiryTime'], 'text','','','&#19981;&#22635;&#21017;&#19981;&#38480;&#21046;&#65292;&#21457;&#24067;&#26102;&#38388;&#36229;&#36807;&#35774;&#32622;&#22825;&#25968;&#21017;&#19981;&#26174;&#31034;&#65292;&#21333;&#20301;&#65306;&#22825;&#65281;&#65281;&#65281;');

	showsetting('&#21830;&#36151;&#21033;&#29575;', 'setting[BusinessRateArray]', $setting['BusinessRateArray'] ? $setting['BusinessRateArray'] : '4.9=&#26368;&#26032;&#22522;&#20934;&#21033;&#29575;
4.66=&#26368;&#26032;&#22522;&#20934;&#21033;&#29575;9.5&#25240;
4.41=&#26368;&#26032;&#22522;&#20934;&#21033;&#29575;9&#25240;
4.31=&#26368;&#26032;&#22522;&#20934;&#21033;&#29575;8.8&#25240;
4.26=&#26368;&#26032;&#22522;&#20934;&#21033;&#29575;8.7&#25240;
4.21=&#26368;&#26032;&#22522;&#20934;&#21033;&#29575;8.6&#25240;
4.17=&#26368;&#26032;&#22522;&#20934;&#21033;&#29575;8.5&#25240;
4.02=&#26368;&#26032;&#22522;&#20934;&#21033;&#29575;8.2&#25240;
3.92=&#26368;&#26032;&#22522;&#20934;&#21033;&#29575;8&#25240;
3.68=&#26368;&#26032;&#22522;&#20934;&#21033;&#29575;7.5&#25240;
3.43=&#26368;&#26032;&#22522;&#20934;&#21033;&#29575;7&#25240;
5.39=&#26368;&#26032;&#22522;&#20934;&#21033;&#29575;1.1&#20493;
5.88=&#26368;&#26032;&#22522;&#20934;&#21033;&#29575;1.2&#20493;
6.37=&#26368;&#26032;&#22522;&#20934;&#21033;&#29575;1.3&#20493;','textarea','','','&#19968;&#34892;&#19968;&#21033;&#29575;&#65292;&#26684;&#24335;&#65306;4.9=&#26368;&#26032;&#22522;&#20934;&#21033;&#29575;&#65281;&#65281;&#65281;&#20363;&#22914;&#65306;<br>4.9=&#26368;&#26032;&#22522;&#20934;&#21033;&#29575;<br>4.66=&#26368;&#26032;&#22522;&#20934;&#21033;&#29575;9.5&#25240;');

	showsetting('&#20844;&#31215;&#37329;&#21033;&#29575;', 'setting[FundRateArray]', $setting['FundRateArray'] ? $setting['FundRateArray'] : '3.25=&#26368;&#26032;&#22522;&#20934;&#21033;&#29575;
3.58=&#26368;&#26032;&#22522;&#20934;&#21033;&#29575;1.1&#20493;
3.9=&#26368;&#26032;&#22522;&#20934;&#21033;&#29575;1.2&#20493;','textarea','','','&#19968;&#34892;&#19968;&#21033;&#29575;&#65292;&#26684;&#24335;&#65306;4.9=&#26368;&#26032;&#22522;&#20934;&#21033;&#29575;&#65281;&#65281;&#65281;&#20363;&#22914;&#65306;<br>4.9=&#26368;&#26032;&#22522;&#20934;&#21033;&#29575;<br>4.66=&#26368;&#26032;&#22522;&#20934;&#21033;&#29575;9.5&#25240;');

	showsetting('&#36151;&#27454;&#26399;&#38480;', 'setting[LoanTermArray]', $setting['LoanTermArray'] ? $setting['LoanTermArray'] : '1=1&#24180;(12&#26399;)
2=2&#24180;(24&#26399;)
3=3&#24180;(36&#26399;)
4=4&#24180;(48&#26399;)
5=5&#24180;(60&#26399;)
6=6&#24180;(72&#26399;)
7=7&#24180;(84&#26399;)
8=8&#24180;(96&#26399;)
9=9&#24180;(108&#26399;)
10=10&#24180;(120&#26399;)
11=11&#24180;(132&#26399;)
12=12&#24180;(144&#26399;)
13=13&#24180;(156&#26399;)
14=14&#24180;(168&#26399;)
15=15&#24180;(180&#26399;)
16=16&#24180;(192&#26399;)
17=17&#24180;(204&#26399;)
18=18&#24180;(216&#26399;)
19=19&#24180;(228&#26399;)
20=20&#24180;(240&#26399;)
21=21&#24180;(252&#26399;)
22=22&#24180;(264&#26399;)
23=23&#24180;(276&#26399;)
24=24&#24180;(288&#26399;)
25=25&#24180;(300&#26399;)
26=26&#24180;(312&#26399;)
27=27&#24180;(324&#26399;)
28=28&#24180;(336&#26399;)
29=29&#24180;(348&#26399;)
30=30&#24180;(360&#26399;)','textarea','','','&#19968;&#34892;&#19968;&#26399;&#38480;&#65292;&#26684;&#24335;&#65306;1=1&#24180;(12&#26399;)&#65281;&#65281;&#65281;&#20363;&#22914;&#65306;<br>1=1&#24180;(12&#26399;)<br>2=2&#24180;(24&#26399;)');

	showsetting('&#21608;&#36793;&#37197;&#22871;', 'setting[NearbyMatching]', $setting['NearbyMatching'] ? $setting['NearbyMatching'] : '&#36229;&#24066;
&#20844;&#20132;
&#23398;&#26657;
&#21307;&#38498;
&#38134;&#34892;
&#32654;&#39135;
&#36141;&#29289;
&#20581;&#36523;','textarea','','','&#19968;&#34892;&#19968;&#37197;&#22871;&#65292;&#26684;&#24335;&#65306;<br>&#36229;&#24066;<br>&#23398;&#26657;');

	showsetting('&#20986;&#31199;&#21333;&#20301;', 'setting[RentTime]', $setting['RentTime'] ? $setting['RentTime'] : '2=&#26376;
1=&#24180;
3=&#26085;','textarea','','','&#19968;&#34892;&#19968;&#26102;&#38388;&#65292;&#26684;&#24335;&#65306;<br>2=&#26376;<br>1=&#24180;');

	showsetting('&#32463;&#33829;&#31867;&#22411;', 'setting[ManagementTpyeList]', $setting['ManagementTpyeList'] ? $setting['ManagementTpyeList'] : '1=&#37202;&#27004;&#39184;&#39278;
2=&#32654;&#23481;&#32654;&#21457;
3=&#26381;&#39280;&#38795;&#21253;
4=&#19987;&#26588;
5=&#20241;&#38386;&#23089;&#20048;
6=&#30334;&#36135;&#36229;&#24066;
7=&#29983;&#27963;&#26381;&#21153;
8=&#21307;&#33647;&#20445;&#20581;
9=&#20844;&#21496;&#24037;&#21378;
10=&#25945;&#32946;&#22521;&#35757;
11=&#26053;&#39302;&#23486;&#39302;
99=&#20854;&#20182;','textarea','','','&#19968;&#34892;&#19968;&#31867;&#22411;&#65292;&#26684;&#24335;&#65306;<br>1=&#31867;&#22411;&#19968;<br>2=&#31867;&#22411;&#20108;');

	showsetting('&#21830;&#38138;&#31867;&#22411;', 'setting[ShopTypeList]', $setting['ShopTypeList'] ? $setting['ShopTypeList'] : '1=&#21830;&#19994;&#34903;&#21334;&#22330;
2=&#20889;&#23383;&#27004;&#37197;&#22871;
3=&#20303;&#23429;&#24213;&#21830;
4=&#25674;&#20301;&#26588;&#21488;
99=&#20854;&#20182;','textarea','','','&#19968;&#34892;&#19968;&#31867;&#22411;&#65292;&#26684;&#24335;&#65306;<br>1=&#31867;&#22411;&#19968;<br>2=&#31867;&#22411;&#20108;');

	showsetting('&#25276;&#37329;&#26631;&#31614;', 'setting[DepositList]', $setting['DepositList'] ? $setting['DepositList'] : '1=&#20184;&#19977;&#25276;&#19968;
2=&#20184;&#19968;&#25276;&#19968;
3=&#20184;&#19977;&#25276;&#20108;
4=&#24180;&#20184;
5=&#21322;&#24180;&#20184;
6=&#21333;&#26376;&#20184;
99=&#38754;&#35758;','textarea','','','&#19968;&#34892;&#19968;&#26631;&#31614;&#65292;&#26684;&#24335;&#65306;<br>1=&#26631;&#31614;&#19968;<br>2=&#26631;&#31614;&#20108;');

	showsetting('&#24180;&#20195;&#26631;&#31614;', 'setting[YearsList]', $setting['YearsList'] ? $setting['YearsList'] : '1=90&#24180;&#20195;&#20043;&#21069;
2=1990&#24180;
3=1991&#24180;
4=1992&#24180;
5=1993&#24180;
6=1994&#24180;
7=1995&#24180;
8=1996&#24180;
9=1997&#24180;
10=1998&#24180;
11=1999&#24180;
12=2000&#24180;
13=2001&#24180;
14=2002&#24180;
15=2003&#24180;
16=2004&#24180;
17=2005&#24180;
18=2006&#24180;
19=2007&#24180;
20=2008&#24180;
21=2009&#24180;
22=2010&#24180;
23=2011&#24180;
24=2012&#24180;
25=2013&#24180;
26=2014&#24180;
27=2015&#24180;
28=2016&#24180;
29=2017&#24180;
30=2018&#24180;','textarea','','','&#19968;&#34892;&#19968;&#26631;&#31614;&#65292;&#26684;&#24335;&#65306;<br>1=&#26631;&#31614;&#19968;<br>2=&#26631;&#31614;&#20108;');

	showsetting('&#25151;&#23627;&#31867;&#22411;&#26631;&#31614;', 'setting[HouseTypeList]', $setting['HouseTypeList'] ? $setting['HouseTypeList'] : '1=&#26222;&#36890;&#20303;&#23429;
2=&#20844;&#23507;&#24335;&#20303;&#23429;
3=&#22797;&#24335;&#20303;&#23429;
4=&#36291;&#23618;&#24335;&#20303;&#23429;
5=&#23567;&#25143;&#22411;&#20303;&#23429;
6=&#33457;&#22253;&#27915;&#25151;&#24335;&#20303;&#23429;(&#21035;&#22661;)','textarea','','','&#19968;&#34892;&#19968;&#26631;&#31614;&#65292;&#26684;&#24335;&#65306;<br>1=&#26631;&#31614;&#19968;<br>2=&#26631;&#31614;&#20108;');

	showsetting('&#20135;&#26435;&#24180;&#38480;&#26631;&#31614;', 'setting[PropertyRightList]', $setting['PropertyRightList'] ? $setting['PropertyRightList'] : '1=40&#24180;&#20135;&#26435;
2=50&#24180;&#20135;&#26435;
3=70&#24180;&#20135;&#26435;','textarea','','','&#19968;&#34892;&#19968;&#26631;&#31614;&#65292;&#26684;&#24335;&#65306;<br>1=&#26631;&#31614;&#19968;<br>2=&#26631;&#31614;&#20108;');

	showsetting('&#20108;&#25163;&#25151;&#26631;&#31614;', 'setting[HouseTagList]', $setting['HouseTagList'] ? $setting['HouseTagList'] : '1=&#21697;&#36136;&#23567;&#21306;
2=&#32321;&#21326;&#22320;&#27573;
3=&#21335;&#21271;&#36890;&#36879;
4=&#37197;&#22871;&#40784;&#20840;
5=&#20132;&#36890;&#20415;&#21033;
6=&#25294;&#21253;&#20837;&#20303;
7=&#39640;&#23433;&#20840;&#24615;
8=&#37319;&#20809;&#22909;
9=&#20248;&#36136;&#25945;&#32946;
10=&#38543;&#26102;&#30475;&#25151;
11=&#32511;&#21270;&#29575;&#39640;','textarea','','','&#19968;&#34892;&#19968;&#26631;&#31614;&#65292;&#26684;&#24335;&#65306;<br>1=&#26631;&#31614;&#19968;<br>2=&#26631;&#31614;&#20108;');

	showsetting('&#20986;&#31199;&#25151;&#26631;&#31614;', 'setting[RentalHouseTagList]', $setting['RentalHouseTagList'] ? $setting['RentalHouseTagList'] : '1=&#32511;&#21270;&#29575;&#39640;
2=&#20132;&#36890;&#20415;&#25463;
3=&#29289;&#19994;&#31649;&#29702;&#22909;
4=&#25294;&#21253;&#20837;&#20303;
5=&#23398;&#21306;&#25151;
6=&#37197;&#22871;&#40784;&#20840;
7=&#32321;&#21326;&#24066;&#21306;
8=&#37202;&#24215;&#24335;&#20844;&#23507;','textarea','','','&#19968;&#34892;&#19968;&#26631;&#31614;&#65292;&#26684;&#24335;&#65306;<br>1=&#26631;&#31614;&#19968;<br>2=&#26631;&#31614;&#20108;');

	showsetting('&#21830;&#38138;&#26631;&#31614;', 'setting[ShopTagList]', $setting['ShopTagList'] ? $setting['ShopTagList'] : '1=&#20020;&#34903;&#26106;&#38138;
2=&#31199;&#37329;&#23569;
3=&#20154;&#27969;&#37327;&#22823;
4=&#20302;&#20215;&#36716;&#35753;','textarea','','','&#19968;&#34892;&#19968;&#26631;&#31614;&#65292;&#26684;&#24335;&#65306;<br>1=&#26631;&#31614;&#19968;<br>2=&#26631;&#31614;&#20108;');

	showsetting('&#21378;&#25151;&#26631;&#31614;', 'setting[WorkShopTagList]', $setting['WorkShopTagList'] ? $setting['WorkShopTagList'] : '1=&#20020;&#34903;&#21378;&#25151;
2=&#31199;&#37329;&#23569;
3=&#20154;&#27969;&#37327;&#22823;
4=&#20302;&#20215;&#36716;&#35753;','textarea','','','&#19968;&#34892;&#19968;&#26631;&#31614;&#65292;&#26684;&#24335;&#65306;<br>1=&#26631;&#31614;&#19968;<br>2=&#26631;&#31614;&#20108;');

	showsetting('&#20889;&#23383;&#27004;&#26631;&#31614;', 'setting[OfficeTagList]', $setting['OfficeTagList'] ? $setting['OfficeTagList'] : '1=&#21150;&#20844;&#23485;&#24102;
2=&#20813;&#29289;&#19994;&#36153;
3=&#22810;&#36710;&#20301;
4=&#32321;&#21326;&#22320;&#27573;','textarea','','','&#19968;&#34892;&#19968;&#26631;&#31614;&#65292;&#26684;&#24335;&#65306;<br>1=&#26631;&#31614;&#19968;<br>2=&#26631;&#31614;&#20108;');

	showsetting('&#20179;&#24211;&#26631;&#31614;', 'setting[WarehouseTagList]', $setting['WarehouseTagList'] ? $setting['WarehouseTagList'] : '1=&#20301;&#32622;&#22909;
2=&#31354;&#22320;&#22823;
3=&#36817;&#20844;&#36335;
4=&#37197;&#22871;&#20840;','textarea','','','&#19968;&#34892;&#19968;&#26631;&#31614;&#65292;&#26684;&#24335;&#65306;<br>1=&#26631;&#31614;&#19968;<br>2=&#26631;&#31614;&#20108;');

	showsetting('&#22303;&#22320;&#26631;&#31614;', 'setting[LandTagList]', $setting['LandTagList'] ? $setting['LandTagList'] : '1=&#20301;&#32622;&#22909;
2=&#31354;&#22320;&#22823;
3=&#36817;&#20844;&#36335;
4=&#37197;&#22871;&#20840;','textarea','','','&#19968;&#34892;&#19968;&#26631;&#31614;&#65292;&#26684;&#24335;&#65306;<br>1=&#26631;&#31614;&#19968;<br>2=&#26631;&#31614;&#20108;');

	showsetting('&#25151;&#23627;&#37197;&#32622;&#26631;&#31614;', 'setting[ConfigureTagList]', $setting['ConfigureTagList'] ? $setting['ConfigureTagList'] : '1=&#30005;&#35270;&#26426;
2=&#24202;
3=&#27927;&#34915;&#26426;
4=&#31354;&#35843;
5=&#20912;&#31665;
6=&#28909;&#27700;&#22120;
7=&#30005;&#35270;
8=&#23485;&#24102;
9=&#38451;&#21488;
10=&#29420;&#31435;&#21355;&#29983;&#38388;
11=&#27801;&#21457;
12=&#26700;&#26885;','textarea','','','&#19968;&#34892;&#19968;&#26631;&#31614;&#65292;&#26684;&#24335;&#65306;<br>1=&#26631;&#31614;&#19968;<br>2=&#26631;&#31614;&#20108;');

	showsetting('&#35814;&#24773;&#25512;&#33616;&#35843;&#29992;&#26465;&#25968;', 'setting[ViewHotListNum]', $setting['ViewHotListNum'] ? $setting['ViewHotListNum'] : 5,'text');

	showsetting('&#35814;&#24773;&#39029;&#25551;&#36848;&#25552;&#31034;', 'setting[ViewContentTips]', $setting['ViewContentTips'] ? $setting['ViewContentTips'] : '&#32852;&#31995;&#25105;&#26102;&#65292;&#35831;&#35828;&#26126;&#22312;&#91;&#39134;&#40479;&#24037;&#20316;&#23460;&#93;&#30475;&#21040;&#30340;','text');

	echo '<div class="form-group row"><label class="col-sm-1 col-form-label">&#35814;&#24773;&#39029;&#24191;&#21578;<br>&#24314;&#35758;&#23610;&#23544;&#65306;&#54;&#52;&#48;&#32;&#42;&#32;&#49;&#50;&#48;</label><div class="col-sm-9"><div class="UploadBanner"><div class="PhotoControl ClickPhotoControl" id="view_ad_1"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';
	
	showsetting('&#20813;&#36131;&#22768;&#26126;', 'setting[Disclaimer]', $setting['Disclaimer'] ? $setting['Disclaimer'] : '&#22312;&#39134;&#40479;&#25151;&#20135;&#21457;&#24067;&#12289;&#36716;&#36733;&#30340;&#36164;&#26009;&#12289;&#22270;&#29255;&#22343;&#30001;&#32593;&#31449;&#29992;&#25143;&#25552;&#20379;&#65292;&#20854;&#30495;&#23454;&#24615;&#12289;&#20934;&#30830;&#24615;&#21644;&#21512;&#27861;&#24615;&#30001;&#20449;&#24687;&#21457;&#24067;&#20154;&#36127;&#36131;&#12290;&#39134;&#40479;&#25151;&#20135;&#19981;&#25552;&#20379;&#20219;&#20309;&#20445;&#35777;&#65292;&#24182;&#19981;&#25215;&#25285;&#20219;&#20309;&#27861;&#24459;&#36131;&#20219;&#12290;','textarea');

	showsetting('&#32852;&#31995;&#20808;&#24377;&#20813;&#36131;&#22768;&#26126;', 'setting[ContactDisclaimerSwitch]', $setting['ContactDisclaimerSwitch'],'radio','','','&#32852;&#31995;&#30340;&#26102;&#20505;&#65292;&#26159;&#21542;&#20808;&#24377;&#20813;&#36131;&#22768;&#26126;&#65292;&#21516;&#24847;&#25165;&#21487;&#25320;&#25171;&#30005;&#35805;&#47;&#21457;&#20449;&#24687;&#47;&#28155;&#21152;&#24494;&#20449;&#47;&#65;&#112;&#112;&#22312;&#32447;&#32842;&#22825;');


	showsetting('&#35814;&#24773;&#39029;&#21830;&#38138;&#26174;&#31034;&#21608;&#36793;', 'setting[ViewShopsPeripherySwitch]', $setting['ViewShopsPeripherySwitch'], 'radio','','','&#35814;&#24773;&#39029;&#21830;&#38138;&#26159;&#21542;&#26174;&#31034;&#21608;&#36793;&#20449;&#24687;&#65292;&#21457;&#24067;&#26102;&#23450;&#20301;&#21518;&#26377;&#25928;');

	showsetting('&#35814;&#24773;&#39029;&#26159;&#21542;&#26174;&#31034;&#26376;&#36151;', 'setting[ViewLoan]', $common_setting ? $setting['ViewLoan'] : 1,'radio');

	showsetting('&#25151;&#28304;&#26159;&#21542;&#26174;&#31034;&#32534;&#21495;', 'setting[NumberSwitch]',$setting['NumberSwitch'],'radio','','','&#25151;&#28304;&#35814;&#24773;&#39029;&#24038;&#19978;&#35282;&#26159;&#21542;&#26174;&#31034;&#32534;&#21495;');

	showsetting('&#25151;&#28304;&#32852;&#31995;&#30005;&#35805;&#38656;&#30331;&#24405;&#65311;', 'setting[ViewTelContact]', $setting['ViewTelContact'],'radio','','','&#25163;&#26426;&#29256;&#25151;&#28304;&#26597;&#30475;&#32852;&#31995;&#30005;&#35805;&#26159;&#21542;&#38656;&#35201;&#38656;&#30331;&#24405;&#25165;&#21487;&#26597;&#30475;');
	
	showsetting('&#25151;&#28304;&#24403;&#22825;&#19981;&#21487;&#21024;&#38500;',array('setting[ViewDayDel]', array(
		array('1','&#26159;', array('ViewDayDel_1' => '')),
		array('0','&#21542;', array('ViewDayDel_1' => 'none')),
	), TRUE),$setting['ViewDayDel'], 'mradio');
	showtagheader('div', 'ViewDayDel_1', $setting['ViewDayDel'] ? true : '','sub');
		showsetting('&#19981;&#21487;&#21024;&#38500;&#25552;&#31034;&#35821;', 'setting[ViewDayDelTips]', $setting['ViewDayDelTips'] ? $setting['ViewDayDelTips'] : '&#35813;&#25151;&#28304;&#20170;&#26085;&#19981;&#21487;&#21024;&#38500;&#21734;', 'text');
	showtagfooter('div');

	showsetting('&#20030;&#25253;&#20869;&#23481;', 'setting[ReportList]', $setting['ReportList'] ? $setting['ReportList'] : '&#34394;&#20551;&#20449;&#24687;
&#36829;&#27861;&#20449;&#24687;
&#32852;&#31995;&#26041;&#24335;&#26080;&#25928;
&#20998;&#31867;&#38169;&#35823;', 'textarea','','','&#19968;&#34892;&#19968;&#20869;&#23481;&#65292;&#26684;&#24335;&#65306;<br>&#34394;&#20551;&#20449;&#24687;<br>&#36829;&#27861;&#20449;&#24687;');
	
	showsetting('&#20030;&#25253;&#25552;&#31034;&#35821;', 'setting[ReportTips]', $setting['ReportTips'] ? $setting['ReportTips'] : '&#25151;&#28304;&#24050;&#21806;&#25110;&#19981;&#23384;&#22312;/&#20215;&#26684;&#19981;&#30495;&#23454;/&#24694;&#24847;&#20030;&#25253;&#20250;&#34987;&#25289;&#40657;', 'text');

	showsetting('&#20030;&#25253;&#23631;&#34109;&#85;&#73;&#68;', 'setting[ReportProhibitUis]', $setting['ReportProhibitUis'], 'text');

	showsetting('&#20030;&#25253;&#27425;&#25968;', 'setting[ReportNum]', $setting['ReportNum'], 'text','','','&#48;&#47;&#31354;&#20195;&#34920;&#19981;&#38480;&#21046;&#65292;&#27599;&#20010;&#25151;&#28304;&#21487;&#20030;&#25253;&#20960;&#27425;&#65281;&#65281;&#65281;');

	showsetting('&#20030;&#25253;&#27425;&#25968;&#25552;&#31034;&#35821;', 'setting[ReportNumTips]', $setting['ReportNumTips'] ? $setting['ReportNumTips'] : '&#35813;&#25151;&#28304;&#21482;&#33021;&#20030;&#25253;{num}&#27425;', 'text','','','&#123;&#110;&#117;&#109;&#125;&#20195;&#34920;&#20030;&#25253;&#27425;&#25968;');
	
	showsetting('&#38405;&#35835;&#37327;&#38543;&#26426;&#25968;', 'setting[ClickRand]', $setting['ClickRand'] ? $setting['ClickRand'] : '1-1', 'text','','','&#26684;&#24335;&#65306;&#26368;&#23567;&#38543;&#26426;&#25968;&#45;&#26368;&#22823;&#38543;&#26426;&#25968;');

	echo '<div class="form-group row"><label class="col-sm-1 col-form-label">&#35745;&#31639;&#22120;&#24191;&#21578;<br>&#24314;&#35758;&#23610;&#23544;&#65306;&#54;&#52;&#48;&#32;&#42;&#32;&#49;&#50;&#48;</label><div class="col-sm-9"><div class="UploadBanner"><div class="PhotoControl ClickPhotoControl" id="calculation_ad"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';
	//ˮӡ����
	showsetting('&#24320;&#21551;&#27700;&#21360;',array('setting[watermark]', array(
		array('1','&#26159;', array('watermark_div' => '')),
		array('0','&#21542;', array('watermark_div' => 'none')),
	), TRUE),$setting['watermark'], 'mradio','','','&#24494;&#20449;&#47;&#30005;&#33041;&#29256;&#26377;&#25928;&#65292;&#27880;&#24847;&#65306;&#30001;&#20110;&#65;&#80;&#80;&#26377;&#19978;&#20256;&#32452;&#20214;&#65292;&#25152;&#20197;&#35813;&#35774;&#32622;&#65;&#80;&#80;&#20869;&#26080;&#25928;');
	showtagheader('div', 'watermark_div', $setting['watermark'] == 1 ? true : '','sub');
		$watermark_position_array = array(
			array('1','&#24038;&#19978;'),
			array('2','&#24038;&#20013;'),
			array('3','&#21491;&#19978;'),
			array('4','&#20013;&#24038;'),
			array('5','&#20013;&#38388;'),
			array('6','&#20013;&#21491;'),
			array('7','&#24038;&#19979;'),
			array('8','&#20013;&#19979;'),
			array('9','&#21491;&#19979;'),
		);
		showsetting('&#27700;&#21360;&#20301;&#32622;', array('setting[watermark_status]',$watermark_position_array),$common_setting ? $setting['watermark_status'] : 9,'select');
		showsetting('&#27700;&#21360;&#26465;&#20214;', 'setting[watermark_condition]', $setting['watermark_condition'] ? $setting['watermark_condition'] : '0-0', 'text','','','&#26684;&#24335;&#65306;&#48;&#45;&#48;&#65281;&#65281;&#65281;&#35774;&#32622;&#27700;&#21360;&#28155;&#21152;&#30340;&#26465;&#20214;&#65292;&#23567;&#20110;&#27492;&#23610;&#23544;&#30340;&#22270;&#29255;&#38468;&#20214;&#23558;&#19981;&#28155;&#21152;&#27700;&#21360;');
		
		showsetting('&#74;&#80;&#69;&#71;&#27700;&#21360;&#36136;&#37327;', 'setting[watermark_quality]', $common_setting ? $setting['watermark_quality'] : 90, 'text','','','&#35774;&#32622;&#74;&#80;&#69;&#71;&#31867;&#22411;&#30340;&#22270;&#29255;&#38468;&#20214;&#28155;&#21152;&#27700;&#21360;&#21518;&#30340;&#36136;&#37327;&#21442;&#25968;&#65292;&#33539;&#22260;&#20026;&#32;&#48;&#65374;&#49;&#48;&#48;&#32;&#30340;&#25972;&#25968;&#65292;&#25968;&#20540;&#36234;&#22823;&#32467;&#26524;&#22270;&#29255;&#25928;&#26524;&#36234;&#22909;&#65292;&#20294;&#23610;&#23544;&#20063;&#36234;&#22823;');

		showsetting('&#27700;&#21360;&#31867;&#22411;',array('setting[watermark_type]', array(
			array('png','&#80;&#78;&#71;&#31867;&#22411;&#27700;&#21360;', array('watermark_type_text_div' => 'none','watermark_type_png_div' => '','watermark_type_gif_div' => 'none')),
			array('gif','&#71;&#73;&#70;&#31867;&#22411;&#27700;&#21360;', array('watermark_type_text_div' => 'none','watermark_type_png_div' => 'none','watermark_type_gif_div' => '')),
		), TRUE),$setting['watermark_type'] ? $setting['watermark_type'] : 'png','mradio');

		showtagheader('div', 'watermark_type_png_div', $setting['watermark_type'] == 'png' ? true : '','sub');
			$setting['watermark_png'] = $setting['watermark_png'] ? $setting['watermark_png'] : 'static/image/common/watermark.png';
			$watermark_png_html = '<a href="'.$setting['watermark_png'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['watermark_png'].'" height="55"/></a>&#24314;&#35758;&#23610;&#23544;&#65306;&#49;&#51;&#48;&#32;&#42;&#32;&#52;&#48;';
			showsetting('&#80;&#78;&#71;&#27700;&#21360;', 'new_watermark_png',$setting['watermark_png'], 'filetext', '', 0, $watermark_png_html);
		showtagfooter('div');

		showtagheader('div', 'watermark_type_gif_div', $setting['watermark_type'] == 'gif' ? true : '','sub');
			$setting['watermark_gif'] = $setting['watermark_gif'] ? $setting['watermark_gif'] : 'static/image/common/watermark.gif';
			$watermark_gif_html = '<a href="'.$setting['watermark_gif'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['watermark_gif'].'" height="55"/></a>&#24314;&#35758;&#23610;&#23544;&#65306;&#49;&#51;&#48;&#32;&#42;&#32;&#52;&#48;';
			showsetting('&#71;&#73;&#70;&#27700;&#21360;', 'new_watermark_gif',$setting['watermark_gif'], 'filetext', '', 0, $watermark_gif_html);
			showsetting('&#27700;&#21360;&#34701;&#21512;&#24230;', 'setting[watermark_trans]', $setting['watermark_trans'] ? $setting['watermark_trans'] : 50, 'text','','','&#35774;&#32622;&#71;&#73;&#70;&#31867;&#22411;&#27700;&#21360;&#22270;&#29255;&#19982;&#21407;&#22987;&#22270;&#29255;&#30340;&#34701;&#21512;&#24230;&#65292;&#33539;&#22260;&#20026;&#32;&#49;&#65374;&#49;&#48;&#48;&#32;&#30340;&#25972;&#25968;&#65292;&#25968;&#20540;&#36234;&#22823;&#27700;&#21360;&#22270;&#29255;&#36879;&#26126;&#24230;&#36234;&#20302;&#12290;');
		showtagfooter('div');
		
		showtagheader('div', 'watermark_type_text_div', $setting['watermark_type'] == 'text' ? true : '','sub');
			
		showtagfooter('div');
	showtagfooter('div');
	//ˮӡ���� END

	showsetting('&#23567;&#31243;&#24207;&#20851;&#38381;&#20998;&#20139;', 'setting[MinAppShareSwitch]', $setting['MinAppShareSwitch'],'radio');
	showsetting('&#23567;&#31243;&#24207;&#73;&#79;&#83;&#31105;&#27490;&#25903;&#20184;',array('setting[MinAppIosPaySwitch]', array(
		array('1','&#26159;', array('MinAppIosPaySwitchDiv' => '')),
		array('0','&#21542;', array('MinAppIosPaySwitchDiv' => 'none')),
	), TRUE),$setting['MinAppIosPaySwitch'], 'mradio');
	showtagheader('div', 'MinAppIosPaySwitchDiv', $setting['MinAppIosPaySwitch'] == 1 ? true : '','sub');
		showsetting('&#31105;&#27490;&#25903;&#20184;&#25552;&#31034;&#35821;', 'setting[MinAppIosPayTips]', $setting['MinAppIosPayTips'] ? $setting['MinAppIosPayTips'] : '&#30446;&#21069;&#26242;&#19981;&#25903;&#25345;IOS&#23567;&#31243;&#24207;&#25903;&#20184;', 'text');
	showtagfooter('div');

	showsetting('&#31532;&#19977;&#26041;&#32479;&#35745;&#20195;&#30721;', 'setting[Statistics]', $setting['Statistics'], 'textarea');

	echo <<<HTML
	</div>
	<!-- �������� end  -->
HTML;
	
	echo <<<HTML
	<!-- ��������  -->
	<div class="tab-pane" id="nav" role="tabpanel" aria-expanded="false">
	<script type="text/JavaScript">
	var navrowtypedata = [
		[
			[1, '<input type="text" class="form-control w50" name="common_list[navs][displayorder][]" value="">'],
			[1, '<input type="text" class="form-control w200" name="common_list[navs][title][]" value="">'],
			[1, '<input name="common_list[navs][file_icon][]" value="" class="txt uploadbtn" type="file" style="width:266px;">'],
			[1, '<input type="text" class="form-control w400" name="common_list[navs][link][]" value="">'],
			[1, '<a href="#" onclick="deleterow(this)" class="btn btn-sm btn-danger-outline">&#21024;&#38500;</a>']
		],
	];
	var minnavrowtypedata = [
		[
			[1, '<input type="text" class="form-control w50" name="common_list[min_nav][displayorder][]" value="">'],
			[1, '<input type="text" class="form-control w200" name="common_list[min_nav][title][]" value="">'],
			[1, '<input name="common_list[min_nav][file_icon][]" value="" class="txt uploadbtn" type="file" style="width:266px;">'],
			[1, '<input type="text" class="form-control w400" name="common_list[min_nav][link][]" value="">'],
			[1, '<a href="#" onclick="deleterow(this)" class="btn btn-sm btn-danger-outline">&#21024;&#38500;</a>']
		],
	];
	var footernavrowtypedata = [
		[
			[1, '<input type="text" class="form-control w50" name="common_list[footer_nav][displayorder][]" value="">'],
			[1, '<input type="text" class="form-control w300" name="common_list[footer_nav][icon][]" value="">'],
			[1, '<input type="text" class="form-control w200" name="common_list[footer_nav][title][]" value="">'],
			[1, '<input type="text" class="form-control w400" name="common_list[footer_nav][link][]" value="">'],
			[1, '<a href="#" onclick="deleterow(this)" class="btn btn-sm btn-danger-outline">&#21024;&#38500;</a>']
		],
	];
	var addnavrowtypedata = [
		[
			[1, '<input type="text" class="form-control w50" name="common_list[add_nav][displayorder][]" value="">'],
			[1, '<input type="text" class="form-control w200" name="common_list[add_nav][title][]" value="">'],
			[1, '<input name="common_list[add_nav][file_icon][]" value="" class="txt uploadbtn" type="file" style="width:266px;">'],
			[1, '<input type="text" class="form-control w400" name="common_list[add_nav][link][]" value="">'],
			[1, '<a href="#" onclick="deleterow(this)" class="btn btn-sm btn-danger-outline">&#21024;&#38500;</a>']
		],
	];
	</script>
HTML;
	
	//��ҳ����
	echo '<div class="border box-header margin-top-10"><h5 class="box-title">&#23548;&#33322; - <span class="font-size-12">&#91;&#115;&#105;&#116;&#101;&#117;&#114;&#108;&#93;&#20195;&#34920;&#24403;&#21069;&#22495;&#21517;</span></h5></div>';
	showtableheader('','table table-bordered table-hover display nowrap table-responsive dataTable');
	showsubtitle(array(
		'&#26174;&#31034;&#39034;&#24207;',
		'&#23548;&#33322;&#26631;&#39064;',
		'&#23548;&#33322;&#22270;&#26631;',
		'&#23548;&#33322;&#38142;&#25509;',
		'&#21024;&#38500;'
	),'header tbm tc');
	$NavsArray = $common_setting ? $setting['navs'] : array(
		array('displayorder'=>'0','title'=>'&#26032;&#30424;','link'=>'[siteurl]plugin.php?id=fn_house&m=list_disc','icon'=>'/source/plugin/fn_house/static/images/01.png'),
		array('displayorder'=>'1','title'=>'&#20108;&#25163;&#25151;','link'=>'[siteurl]plugin.php?id=fn_house&m=list&class=1','icon'=>'/source/plugin/fn_house/static/images/02.png'),
		array('displayorder'=>'2','title'=>'&#20986;&#31199;&#25151;','link'=>'[siteurl]plugin.php?id=fn_house&m=list&class=2','icon'=>'/source/plugin/fn_house/static/images/03.png'),
		array('displayorder'=>'3','title'=>'&#21830;&#38138;','link'=>'[siteurl]plugin.php?id=fn_house&m=list&class=3','icon'=>'/source/plugin/fn_house/static/images/04.png'),
		array('displayorder'=>'4','title'=>'&#21378;&#25151;','link'=>'[siteurl]plugin.php?id=fn_house&m=list&class=4','icon'=>'/source/plugin/fn_house/static/images/08.png'),
		array('displayorder'=>'5','title'=>'&#20889;&#23383;&#27004;','link'=>'[siteurl]plugin.php?id=fn_house&m=list&class=5','icon'=>'/source/plugin/fn_house/static/images/11.png'),
		array('displayorder'=>'6','title'=>'&#20179;&#24211;','link'=>'[siteurl]plugin.php?id=fn_house&m=list&class=6','icon'=>'/source/plugin/fn_house/static/images/14.png'),
		array('displayorder'=>'7','title'=>'&#22303;&#22320;','link'=>'[siteurl]plugin.php?id=fn_house&m=list&class=7','icon'=>'/source/plugin/fn_house/static/images/15.png'),
		array('displayorder'=>'8','title'=>'&#27714;&#31199;&#27714;&#36141;','link'=>'[siteurl]plugin.php?id=fn_house&m=demand_list&type=','icon'=>'/source/plugin/fn_house/static/images/05.png'),
		array('displayorder'=>'9','title'=>'&#35745;&#31639;&#22120;','link'=>'[siteurl]plugin.php?id=fn_house&m=calculation','icon'=>'/source/plugin/fn_house/static/images/07.png'),
	);
	foreach ($NavsArray as $Key => $Nav) {
		showtablerow('', array('class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
			'<input type="text" class="form-control w50" name="common_list[navs][displayorder][]" value="'.$Nav['displayorder'].'">',
			'<input type="text" class="form-control w200" name="common_list[navs][title][]" value="'.$Nav['title'].'">',
			($Nav['icon'] ? '<a href="'.$Nav['icon'].'" target="_blank"><img src="'.$Nav['icon'].'" style="height:30px;margin:0 5px 0 0;"></a>' : '').'<input type="hidden" size="30" name="common_list[navs][icon][]" value="'.$Nav['icon'].'" /><input name="common_list[navs][file_icon][]" value="" class="txt uploadbtn" type="file" style="width:266px;">',
			'<input type="text" class="form-control w400" name="common_list[navs][link][]" value="'.$Nav['link'].'">',
			'<a href="#" onclick="deleterow(this)" class="btn btn-sm btn-danger-outline">&#21024;&#38500;</a>',
		));
	}
	echo '<tr class="hover"><td class="tc" colspan="10"><a href="#" onclick="addrow(this,navrowtypedata, 0)"><i class="fa fa-plus" style="margin-right:5px"></i>&#28155;&#21152;&#23548;&#33322;</a></td></tr>';
	showtablefooter(); /*dism��taobao��com*/
	//��ҳ���� End

	//��ҳС����
	echo '<div class="border box-header margin-top-10"><h5 class="box-title">&#23567;&#23548;&#33322; - <span class="font-size-12">&#91;&#115;&#105;&#116;&#101;&#117;&#114;&#108;&#93;&#20195;&#34920;&#24403;&#21069;&#22495;&#21517;</span></h5></div>';
	showtableheader('','table table-bordered table-hover display nowrap table-responsive dataTable');
	showsubtitle(array(
		'&#26174;&#31034;&#39034;&#24207;',
		'&#23548;&#33322;&#26631;&#39064;',
		'&#23548;&#33322;&#22270;&#26631;',
		'&#23548;&#33322;&#38142;&#25509;',
		'&#21024;&#38500;'
	),'header tbm tc');
	$MinNavArray = $common_setting ? $setting['min_nav'] : array(
		array('displayorder'=>'0','title'=>'&#20013;&#20171;','link'=>'[siteurl]plugin.php?id=fn_house&m=list_agent','icon'=>'/source/plugin/fn_house/static/images/102.png'),
		array('displayorder'=>'1','title'=>'&#38376;&#24215;','link'=>'[siteurl]plugin.php?id=fn_house&m=list_store','icon'=>'/source/plugin/fn_house/static/images/103.png'),
		array('displayorder'=>'2','title'=>'&#20013;&#20171;&#20837;&#39547;','link'=>'[siteurl]plugin.php?id=fn_house&m=user_agent_info','icon'=>'/source/plugin/fn_house/static/images/104.png'),
		
	);
	foreach ($MinNavArray as $Key => $Nav) {
		showtablerow('', array('class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
			'<input type="text" class="form-control w50" name="common_list[min_nav][displayorder][]" value="'.$Nav['displayorder'].'">',
			'<input type="text" class="form-control w200" name="common_list[min_nav][title][]" value="'.$Nav['title'].'">',
			($Nav['icon'] ? '<a href="'.$Nav['icon'].'" target="_blank"><img src="'.$Nav['icon'].'" style="height:30px;margin:0 5px 0 0;"></a>' : '').'<input type="hidden" size="30" name="common_list[min_nav][icon][]" value="'.$Nav['icon'].'" /><input name="common_list[min_nav][file_icon][]" value="" class="txt uploadbtn" type="file" style="width:266px;">',
			'<input type="text" class="form-control w400" name="common_list[min_nav][link][]" value="'.$Nav['link'].'">',
			'<a href="#" onclick="deleterow(this)" class="btn btn-sm btn-danger-outline">&#21024;&#38500;</a>',
		));
	}
	echo '<tr class="hover"><td class="tc" colspan="10"><a href="#" onclick="addrow(this,minnavrowtypedata, 0)"><i class="fa fa-plus" style="margin-right:5px"></i>&#28155;&#21152;&#23548;&#33322;</a></td></tr>';
	showtablefooter(); /*dism��taobao��com*/
	//��ҳС���� End

	//�ײ�����
	echo '<div class="alert alert-primary margin-top-30" role="alert">&#22270;&#26631;&#21442;&#32771;&#65306;<a href="http://dev.yili6.com/source/plugin/fn_house/static/images/fontsize.png" target="_blank" class="text-danger">http://dev.yili6.com/source/plugin/fn_house/static/images/fontsize.png</a>&#65292;&#27880;&#24847;&#65306;&#22270;&#26631;&#19981;&#29992;&#24102;&#12304;&#38;&#35;&#59;&#12305;&#51;&#20010;&#23383;&#31526;<br>&#22914;&#21457;&#24067;&#25353;&#38062;&#31561;&#20110;&#65;&#100;&#100;&#65281;&#65281;&#65281;&#23548;&#33322;&#38142;&#25509;&#31561;&#20110;&#65;&#100;&#100;&#30340;&#26102;&#20505;&#65292;&#22270;&#26631;&#35831;&#25918;&#21457;&#24067;&#25353;&#38062;&#36335;&#24452;&#65281;&#65281;&#65281;</div><div class="border box-header margin-top-0"><h5 class="box-title">&#24213;&#37096;&#23548;&#33322; - <span class="font-size-12">&#91;&#115;&#105;&#116;&#101;&#117;&#114;&#108;&#93;&#20195;&#34920;&#24403;&#21069;&#22495;&#21517;</span></h5></div>';
	showtableheader('','table table-bordered table-hover display nowrap table-responsive dataTable');
	showsubtitle(array(
		'&#26174;&#31034;&#39034;&#24207;',
		'&#23548;&#33322;&#22270;&#26631;',
		'&#23548;&#33322;&#26631;&#39064;',
		'&#23548;&#33322;&#38142;&#25509;',
		'&#21024;&#38500;'
	),'header tbm tc');
	$FooterNavArray = $common_setting ? $setting['footer_nav'] : array(
		array('displayorder'=>'0','title'=>'&#39318;&#39029;','link'=>'[siteurl]plugin.php?id=fn_house','icon'=>'xe6d5'),
		array('displayorder'=>'1','title'=>'&#20108;&#25163;&#25151;','link'=>'[siteurl]plugin.php?id=fn_house&m=list&class=1','icon'=>'xe62c'),
		array('displayorder'=>'2','title'=>'&#21457;&#24067;&#25151;&#28304;','link'=>'Add','icon'=>'/source/plugin/fn_house/static/images/add.png'),
		array('displayorder'=>'3','title'=>'&#20986;&#31199;&#25151;','link'=>'[siteurl]plugin.php?id=fn_house&m=list&class=2','icon'=>'xe638'),
		array('displayorder'=>'4','title'=>'&#25105;&#30340;','link'=>'[siteurl]plugin.php?id=fn_house&m=user','icon'=>'xe61b'),
	);
	foreach ($FooterNavArray as $Key => $Nav) {
		showtablerow('', array('class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
			'<input type="text" class="form-control w50" name="common_list[footer_nav][displayorder][]" value="'.$Nav['displayorder'].'">',
			'<input type="text" class="form-control w300" name="common_list[footer_nav][icon][]" value="'.$Nav['icon'].'">',
			'<input type="text" class="form-control w200" name="common_list[footer_nav][title][]" value="'.$Nav['title'].'">',
			'<input type="text" class="form-control w400" name="common_list[footer_nav][link][]" value="'.$Nav['link'].'">',
			'<a href="#" onclick="deleterow(this)" class="btn btn-sm btn-danger-outline">&#21024;&#38500;</a>',
		));
	}
	echo '<tr class="hover"><td class="tc" colspan="10"><a href="#" onclick="addrow(this,footernavrowtypedata, 0)"><i class="fa fa-plus" style="margin-right:5px"></i>&#28155;&#21152;&#23548;&#33322;</a></td></tr>';
	showtablefooter(); /*dism��taobao��com*/
	//�ײ����� End

	//��������
	echo '<div class="border box-header margin-top-30"><h5 class="box-title">&#21457;&#24067;&#23548;&#33322; - <span class="font-size-12">&#91;&#115;&#105;&#116;&#101;&#117;&#114;&#108;&#93;&#20195;&#34920;&#24403;&#21069;&#22495;&#21517;</span></h5></div>';
	showtableheader('','table table-bordered table-hover display nowrap table-responsive dataTable');
	showsubtitle(array(
		'&#26174;&#31034;&#39034;&#24207;',
		'&#23548;&#33322;&#26631;&#39064;',
		'&#23548;&#33322;&#22270;&#26631;',
		'&#23548;&#33322;&#38142;&#25509;',
		'&#21024;&#38500;'
	),'header tbm tc');
	$AddNavArray = $common_setting ? $setting['add_nav'] : array(
		array('displayorder'=>'0','title'=>'&#20108;&#25163;&#25151;','link'=>'[siteurl]plugin.php?id=fn_house&m=publish&class=1','icon'=>'/source/plugin/fn_house/static/images/01.png'),
		array('displayorder'=>'1','title'=>'&#20986;&#31199;&#25151;','link'=>'[siteurl]plugin.php?id=fn_house&m=publish&class=2','icon'=>'/source/plugin/fn_house/static/images/02.png'),
		array('displayorder'=>'2','title'=>'&#21830;&#38138;','link'=>'[siteurl]plugin.php?id=fn_house&m=publish&class=3','icon'=>'/source/plugin/fn_house/static/images/03.png'),
		array('displayorder'=>'3','title'=>'&#21378;&#25151;','link'=>'[siteurl]plugin.php?id=fn_house&m=publish&class=4','icon'=>'/source/plugin/fn_house/static/images/08.png'),
		array('displayorder'=>'4','title'=>'&#20889;&#23383;&#27004;','link'=>'[siteurl]plugin.php?id=fn_house&m=publish&class=5','icon'=>'/source/plugin/fn_house/static/images/11.png'),
		array('displayorder'=>'5','title'=>'&#20179;&#24211;','link'=>'[siteurl]plugin.php?id=fn_house&m=publish&class=6','icon'=>'/source/plugin/fn_house/static/images/14.png'),
		array('displayorder'=>'6','title'=>'&#22303;&#22320;','link'=>'[siteurl]plugin.php?id=fn_house&m=publish&class=7','icon'=>'/source/plugin/fn_house/static/images/15.png'),
		array('displayorder'=>'7','title'=>'&#27714;&#31199;&#27714;&#36141;','link'=>'[siteurl]plugin.php?id=fn_house&m=publish&class=99','icon'=>'/source/plugin/fn_house/static/images/05.png')
	);
	foreach ($AddNavArray as $Key => $Nav) {
		showtablerow('', array('class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
			'<input type="text" class="form-control w50" name="common_list[add_nav][displayorder][]" value="'.$Nav['displayorder'].'">',
			'<input type="text" class="form-control w200" name="common_list[add_nav][title][]" value="'.$Nav['title'].'">',
			($Nav['icon'] ? '<a href="'.$Nav['icon'].'" target="_blank"><img src="'.$Nav['icon'].'" style="height:30px;margin:0 5px 0 0;"></a>' : '').'<input type="hidden" size="30" name="common_list[add_nav][icon][]" value="'.$Nav['icon'].'" /><input name="common_list[add_nav][file_icon][]" value="" class="txt uploadbtn" type="file" style="width:266px;">',
			'<input type="text" class="form-control w400" name="common_list[add_nav][link][]" value="'.$Nav['link'].'">',
			'<a href="#" onclick="deleterow(this)" class="btn btn-sm btn-danger-outline">&#21024;&#38500;</a>',
		));
	}
	echo '<tr class="hover"><td class="tc" colspan="10"><a href="#" onclick="addrow(this,addnavrowtypedata, 0)"><i class="fa fa-plus" style="margin-right:5px"></i>&#28155;&#21152;&#23548;&#33322;</a></td></tr>';
	showtablefooter(); /*dism��taobao��com*/
	//�������� End

	echo <<<HTML
		<script type="text/JavaScript">
		var pcnavrowtypedata = [
			[
				[1, '<input type="text" class="form-control w50" name="common_list[pc_nav][displayorder][]" value="">'],
				[1, '<input type="text" class="form-control w100" name="common_list[pc_nav][title][]" value="">'],
				[1, '<input type="text" class="form-control w400" name="common_list[pc_nav][link][]" value="">'],
				[1, '<a href="#" onclick="deleterow(this)" class="btn btn-sm btn-danger-outline">&#21024;&#38500;</a>']
			],
		];
		var pcusernavrowtypedata = [
			[
				[1, '<input type="text" class="form-control w50" name="common_list[pc_user_nav][displayorder][]" value="">'],
				[1, '<input type="text" class="form-control w100" name="common_list[pc_user_nav][title][]" value="">'],
				[1, '<input type="text" class="form-control w400" name="common_list[footer_nav][link][]" value="">'],
				[1, '<a href="#" onclick="deleterow(this)" class="btn btn-sm btn-danger-outline">&#21024;&#38500;</a>']
			],
		];
		</script>
HTML;
	//���԰���ҳ����
	echo '<div class="border box-header margin-top-10"><h5 class="box-title">&#30005;&#33041;&#29256;&#23548;&#33322; - <span class="font-size-12">&#91;&#115;&#105;&#116;&#101;&#117;&#114;&#108;&#93;&#20195;&#34920;&#24403;&#21069;&#22495;&#21517;</span></h5></div>';
	showtableheader('','table table-bordered table-hover display nowrap table-responsive dataTable');
	showsubtitle(array(
		'&#26174;&#31034;&#39034;&#24207;',
		'&#23548;&#33322;&#26631;&#39064;',
		'&#23548;&#33322;&#38142;&#25509;',
		'&#21024;&#38500;'
	),'header tbm tc');
	$PcNavArray = $common_setting ? $setting['pc_nav'] : array(
		array('displayorder'=>'0','title'=>'&#25151;&#20135;&#39318;&#39029;','link'=>'[siteurl]plugin.php?id=fn_house'),
		array('displayorder'=>'1','title'=>'&#26032;&#30424;','link'=>'[siteurl]plugin.php?id=fn_house&m=list_disc'),
		array('displayorder'=>'2','title'=>'&#20108;&#25163;&#25151;','link'=>'[siteurl]plugin.php?id=fn_house&m=list&class=1'),
		array('displayorder'=>'3','title'=>'&#20986;&#31199;&#25151;','link'=>'[siteurl]plugin.php?id=fn_house&m=list&class=2'),
		array('displayorder'=>'4','title'=>'&#21830;&#38138;','link'=>'[siteurl]plugin.php?id=fn_house&m=list&class=3'),
		array('displayorder'=>'5','title'=>'&#21378;&#25151;','link'=>'[siteurl]plugin.php?id=fn_house&m=list&class=4'),
		array('displayorder'=>'6','title'=>'&#20889;&#23383;&#27004;','link'=>'[siteurl]plugin.php?id=fn_house&m=list&class=5'),
		array('displayorder'=>'7','title'=>'&#20179;&#24211;','link'=>'[siteurl]plugin.php?id=fn_house&m=list&class=6'),
		array('displayorder'=>'8','title'=>'&#22303;&#22320;','link'=>'[siteurl]plugin.php?id=fn_house&m=list&class=7'),
	);
	foreach ($PcNavArray as $Key => $Nav) {
		showtablerow('', array('class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
			'<input type="text" class="form-control w50" name="common_list[pc_nav][displayorder][]" value="'.$Nav['displayorder'].'">',
			'<input type="text" class="form-control w100" name="common_list[pc_nav][title][]" value="'.$Nav['title'].'">',
			'<input type="text" class="form-control w400" name="common_list[pc_nav][link][]" value="'.$Nav['link'].'">',
			'<a href="#" onclick="deleterow(this)" class="btn btn-sm btn-danger-outline">&#21024;&#38500;</a>',
		));
	}
	echo '<tr class="hover"><td class="tc" colspan="10"><a href="#" onclick="addrow(this,pcnavrowtypedata, 0)"><i class="fa fa-plus" style="margin-right:5px"></i>&#28155;&#21152;&#23548;&#33322;</a></td></tr>';
	showtablefooter(); /*dism��taobao��com*/
	//���԰���ҳ���� End

	//���԰��Ա���ĵ���
	echo '<div class="border box-header margin-top-10"><h5 class="box-title">&#30005;&#33041;&#29256;&#20250;&#21592;&#20013;&#24515;&#23548;&#33322; - <span class="font-size-12">&#91;&#115;&#105;&#116;&#101;&#117;&#114;&#108;&#93;&#20195;&#34920;&#24403;&#21069;&#22495;&#21517;</span></h5></div>';
	showtableheader('','table table-bordered table-hover display nowrap table-responsive dataTable');
	showsubtitle(array(
		'&#26174;&#31034;&#39034;&#24207;',
		'&#23548;&#33322;&#26631;&#39064;',
		'&#23548;&#33322;&#38142;&#25509;',
		'&#21024;&#38500;'
	),'header tbm tc');
	$PcUserNavArray = $common_setting ? $setting['pc_user_nav'] : array(
		array('displayorder'=>'0','title'=>'&#39318;&#39029;','link'=>'[siteurl]plugin.php?id=fn_house')	
	);
	foreach ($PcUserNavArray as $Key => $Nav) {
		showtablerow('', array('class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
			'<input type="text" class="form-control w50" name="common_list[pc_user_nav][displayorder][]" value="'.$Nav['displayorder'].'">',
			'<input type="text" class="form-control w100" name="common_list[pc_user_nav][title][]" value="'.$Nav['title'].'">',
			'<input type="text" class="form-control w400" name="common_list[pc_user_nav][link][]" value="'.$Nav['link'].'">',
			'<a href="#" onclick="deleterow(this)" class="btn btn-sm btn-danger-outline">&#21024;&#38500;</a>',
		));
	}
	echo '<tr class="hover"><td class="tc" colspan="10"><a href="#" onclick="addrow(this,pcusernavrowtypedata, 0)"><i class="fa fa-plus" style="margin-right:5px"></i>&#28155;&#21152;&#23548;&#33322;</a></td></tr>';
	showtablefooter(); /*dism��taobao��com*/
	//��Ա���ĵ��� End

	echo <<<HTML
	</div>
	<!-- �������� end  -->
HTML;
	
	echo <<<HTML
	<!-- ��ҳ����  -->
	<div class="tab-pane" id="index" role="tabpanel" aria-expanded="false">
HTML;

	showsetting('&#25163;&#26426;&#29256;&#27169;&#26495;',array('setting[IndexTemplet]', array(
		array('index','&#27169;&#26495;&#19968;', array('IndexTemplet_1' => '')),
		array('index_new','&#27169;&#26495;&#20108;', array('IndexTemplet_1' => 'none')),
	), TRUE),$common_setting ? $setting['IndexTemplet'] : 'index', 'mradio');

	echo '<div class="form-group row"><label class="col-sm-1 col-form-label">&#27178;&#24133;&#22270;&#29255;<br>&#23610;&#23544;&#24314;&#35758;&#54;&#52;&#48;&#32;&#42;&#32;&#51;&#48;&#48;</label><div class="col-sm-9"><div class="UploadBanner"><div class="PhotoControl ClickPhotoControl" id="Banners"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';

	showsetting('&#25104;&#20132;&#36895;&#36882;&#26631;&#39064;', 'setting[NoticeTitle]', $common_setting ? $setting['NoticeTitle'] : '&#25104;&#20132;<br><span class=Bg>&#36895;&#36882;</span>','text');

	showsetting('&#25104;&#20132;&#36895;&#36882;', 'setting[NoticeList]', $common_setting ? $setting['NoticeList'] : '<span class=FColor>&#24685;&#21916;</span> <span class=Color>&#39134;&#40479;&#25151;&#20135;&#19978;&#32447;&#21862;</span> 2020-12-12|http://dev.yili6.com
&#25991;&#23383;2&#25991;&#23383;2&#25991;&#23383;2&#25991;&#23383;2&#25991;&#23383;2&#25991;&#23383;2&#25991;&#23383;2','textarea','','','&#19968;&#34892;&#19968;&#25104;&#20132;&#36895;&#36882;&#65292;<span class=FColor>&#20195;&#34920;&#32418;&#33394;</span>&#65292;<span class=Color>&#20195;&#34920;&#32511;&#33394;</span>&#26684;&#24335;&#65306;<br><span class=FColor>&#24685;&#21916;</span><span class=Color>&#39134;&#40479;&#25151;&#20135;&#19978;&#32447;&#21862;</span> 2020-12-12|&#38142;&#25509;<br>&#25991;&#23383;2|&#38142;&#25509;2');

	showsetting('&#27004;&#30424;&#35843;&#29992;&#26465;&#25968;', 'setting[IndexDiscNum]', $setting['IndexDiscNum'] ? $setting['IndexDiscNum'] : 5,'text');
	
	showsetting('&#25151;&#28304;&#35843;&#29992;&#26465;&#25968;', 'setting[IndexListNum]', $setting['IndexListNum'] ? $setting['IndexListNum'] : 5,'text');
		
	showsetting('&#25628;&#32034;&#26694;&#39034;&#24207;', 'setting[HomeSearch]', $common_setting ? $setting['HomeSearch'] : '1,2,3,4,5,6,7,88','text','','','1&#20195;&#34920;&#20108;&#25163;&#25151;&#65292;2&#20195;&#34920;&#20986;&#31199;&#25151;&#65292;3&#20195;&#34920;&#21830;&#38138;&#65292;4&#20195;&#34920;&#21378;&#25151;&#65292;5&#20195;&#34920;&#21378;&#25151;&#65292;6&#20195;&#34920;&#20179;&#24211;&#65292;7&#20195;&#34920;&#22303;&#22320;&#65292;88&#20195;&#34920;&#27004;&#30424;<br>&#26684;&#24335;&#65306;1,2,3,88');

	showsetting('&#27004;&#30424;&#22343;&#20215;', 'setting[HomeAveragePrice]', $common_setting ? $setting['HomeAveragePrice'] : 5000,'text');

	showsetting('&#36164;&#35759;&#26159;&#21542;&#26174;&#31034;',array('setting[HomeArticle]', array(
			array('1','&#26159;', array('HomeArticle_div' => '')),
			array('0','&#21542;', array('HomeArticle_div' => 'none')),
		), TRUE),$common_setting ? $setting['HomeArticle'] : 1, 'mradio','','','&#35813;&#35774;&#32622;&#20165;&#38480;&#20110;&#25163;&#26426;&#29256;&#65292;&#22914;&#30005;&#33041;&#29256;&#65292;&#35831;&#21069;&#24448;&#30005;&#33041;&#29256;&#35774;&#32622;');
	showtagheader('div', 'HomeArticle_div', $setting['HomeArticle'] || !$common_setting ? true : '','sub');
			
	showtagfooter('div');
	
	showsetting('&#24320;&#21551;&#21457;&#24067;&#24748;&#28014;&#25353;&#38062;', 'setting[AddFloatSwitch]', $setting['AddFloatSwitch'],'radio');

	showsetting('&#26159;&#21542;&#26174;&#31034;&#20013;&#20171;', 'setting[HomeAgentSwitch]', $common_setting ? $setting['HomeAgentSwitch'] : 1,'radio');

	showsetting('&#26159;&#21542;&#26174;&#31034;&#32479;&#35745;&#27169;&#22359;', 'setting[HomeCountSwitch]', $common_setting ? $setting['HomeCountSwitch'] : 1,'radio');

	showsetting('&#26159;&#21542;&#26174;&#31034;&#35013;&#20462;&#20844;&#21496;', 'setting[HomeAgentRenovationCompany]', $setting['HomeAgentRenovationCompany'],'radio','','','&#35831;&#20808;&#23433;&#35013;&#21516;&#22478;&#35013;&#20462;&#65292;&#104;&#116;&#116;&#112;&#115;&#58;&#47;&#47;&#97;&#100;&#100;&#111;&#110;&#46;&#100;&#105;&#115;&#109;&#97;&#108;&#108;&#46;&#99;&#111;&#109;&#47;&#63;&#64;&#102;&#110;&#95;&#114;&#101;&#110;&#111;&#118;&#97;&#116;&#105;&#111;&#110;&#46;&#112;&#108;&#117;&#103;&#105;&#110;');
	
	showtagheader('div', 'IndexTemplet_1', $setting['IndexTemplet'] == 'index' || !$common_setting ? true : '','sub');
		showsetting('&#26159;&#21542;&#26174;&#31034;&#32622;&#39030;&#25151;&#28304;', 'setting[HomeInfoTopSwitch]', $common_setting ? $setting['HomeInfoTopSwitch'] : 1,'radio');
		showsetting('&#25151;&#28304;&#35843;&#29992;&#25512;&#33616;', 'setting[IndexHotSwitch]', $setting['IndexHotSwitch'],'radio');
		showsetting('&#27004;&#30424;&#35843;&#29992;&#25512;&#33616;', 'setting[IndexDiscHotSwitch]', $setting['IndexDiscHotSwitch'],'radio');
	showtagfooter('div');

	echo '<div class="form-group row"><label class="col-sm-1 col-form-label">&#25104;&#20132;&#36895;&#36882;&#39030;&#37096;&#24191;&#21578;&#20301;<br>&#24314;&#35758;&#23610;&#23544;&#65306;&#54;&#52;&#48;&#32;&#42;&#32;&#49;&#50;&#48;</label><div class="col-sm-9"><div class="UploadBanner"><div class="PhotoControl ClickPhotoControl" id="notice_top_ad"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';
	
	echo <<<HTML
	</div>
	<!-- ��ҳ���� end  -->
HTML;

	
	echo <<<HTML
	<!-- ��������  -->
	<div class="tab-pane" id="money" role="tabpanel" aria-expanded="false">
HTML;
	
	showsetting('&#21457;&#24067;&#25552;&#31034;&#35821;', 'setting[PublishHint]', $setting['PublishHint'] ? $setting['PublishHint'] : '&#35813;&#26465;&#21457;&#24067;&#38656;&#35201;&#25903;&#20184;{Money}&#20803;','text','','','{Money}&#20195;&#34920;&#37329;&#39069;&#65292;{br}&#20195;&#34920;&#25442;&#34892;');

	showsetting('&#25151;&#28304;&#27599;&#26085;&#27599;&#20010;&#20813;&#36153;&#21047;&#26032;&#27425;&#25968;&#32;', 'setting[RefreshDayNum]', $setting['RefreshDayNum'],'text','','','&#35774;&#32622;&#21047;&#26032;&#37329;&#39069;&#26377;&#25928;&#65292;&#27599;&#26085;&#27599;&#20010;&#25151;&#28304;&#20813;&#36153;&#21047;&#26032;&#27425;&#25968;&#65292;&#48;&#20195;&#34920;&#26080;&#26435;&#38480;&#65281;&#20250;&#21592;&#25110;&#24320;&#36890;&#36807;&#20250;&#21592;&#35813;&#35774;&#32622;&#26080;&#25928;c');

	showsetting('&#20108;&#25163;&#25151;&#21457;&#24067;&#37329;&#39069;', 'setting[HouseMoney]', $common_setting ? $setting['HouseMoney'] : 1,'text','','','&#48;&#25110;&#31354;&#20026;&#20813;&#36153;&#21457;&#24067;');

	showsetting('&#20108;&#25163;&#25151;&#21047;&#26032;&#20215;&#26684;', 'setting[HouseRefreshMoney]', $common_setting ? $setting['HouseRefreshMoney'] : 1,'text');

	showsetting('&#20108;&#25163;&#25151;&#32622;&#39030;&#20215;&#26684;', 'setting[HouseTopMoney]', $common_setting ? $setting['HouseTopMoney'] : '30|100|&#32622;&#39030;30&#22825;&#65292;100&#20803;
15|70|&#32622;&#39030;15&#22825;&#65292;70&#20803;','textarea','','','&#19968;&#34892;&#19968;&#20215;&#26684;&#65292;&#26684;&#24335;&#65306;&#22825;&#25968;|&#20215;&#26684;|&#25991;&#23383;<br>30|100|&#32622;&#39030;30&#22825;&#65292;100&#20803;<br>15|70|&#32622;&#39030;15&#22825;&#65292;70&#20803;');

	showsetting('&#20986;&#31199;&#25151;&#21457;&#24067;&#37329;&#39069;', 'setting[RentalMoney]', $common_setting ? $setting['RentalMoney'] : 1,'text','','','&#48;&#25110;&#31354;&#20026;&#20813;&#36153;&#21457;&#24067;');

	showsetting('&#20986;&#31199;&#25151;&#21047;&#26032;&#20215;&#26684;', 'setting[RentalRefreshMoney]', $common_setting ? $setting['RentalRefreshMoney'] : 1,'text');

	showsetting('&#20986;&#31199;&#25151;&#32622;&#39030;&#20215;&#26684;', 'setting[RentalTopMoney]', $common_setting ? $setting['RentalTopMoney'] : '30|100|&#32622;&#39030;30&#22825;&#65292;100&#20803;
15|70|&#32622;&#39030;15&#22825;&#65292;70&#20803;','textarea','','','&#19968;&#34892;&#19968;&#20215;&#26684;&#65292;&#26684;&#24335;&#65306;&#22825;&#25968;|&#20215;&#26684;|&#25991;&#23383;<br>30|100|&#32622;&#39030;30&#22825;&#65292;100&#20803;<br>15|70|&#32622;&#39030;15&#22825;&#65292;70&#20803;');

	showsetting('&#21830;&#38138;&#21457;&#24067;&#37329;&#39069;', 'setting[ShopMoney]', $common_setting ? $setting['ShopMoney'] : 1,'text','','','&#48;&#25110;&#31354;&#20026;&#20813;&#36153;&#21457;&#24067;');

	showsetting('&#21830;&#38138;&#21047;&#26032;&#20215;&#26684;', 'setting[ShopRefreshMoney]', $common_setting ? $setting['ShopRefreshMoney'] : 1,'text');

	showsetting('&#21830;&#38138;&#32622;&#39030;&#20215;&#26684;', 'setting[ShopTopMoney]', $common_setting ? $setting['ShopTopMoney'] : '30|100|&#32622;&#39030;30&#22825;&#65292;100&#20803;
15|70|&#32622;&#39030;15&#22825;&#65292;70&#20803;','textarea','','','&#19968;&#34892;&#19968;&#20215;&#26684;&#65292;&#26684;&#24335;&#65306;&#22825;&#25968;|&#20215;&#26684;|&#25991;&#23383;<br>30|100|&#32622;&#39030;30&#22825;&#65292;100&#20803;<br>15|70|&#32622;&#39030;15&#22825;&#65292;70&#20803;');

	showsetting('&#21378;&#25151;&#21457;&#24067;&#37329;&#39069;', 'setting[WorkShopMoney]', $common_setting ? $setting['WorkShopMoney'] : 1,'text','','','&#48;&#25110;&#31354;&#20026;&#20813;&#36153;&#21457;&#24067;');

	showsetting('&#21378;&#25151;&#21047;&#26032;&#20215;&#26684;', 'setting[WorkShopRefreshMoney]', $common_setting ? $setting['WorkShopRefreshMoney'] : 1,'text');

	showsetting('&#21378;&#25151;&#32622;&#39030;&#20215;&#26684;', 'setting[WorkShopTopMoney]', $common_setting ? $setting['WorkShopTopMoney'] : '30|100|&#32622;&#39030;30&#22825;&#65292;100&#20803;
15|70|&#32622;&#39030;15&#22825;&#65292;70&#20803;','textarea','','','&#19968;&#34892;&#19968;&#20215;&#26684;&#65292;&#26684;&#24335;&#65306;&#22825;&#25968;|&#20215;&#26684;|&#25991;&#23383;<br>30|100|&#32622;&#39030;30&#22825;&#65292;100&#20803;<br>15|70|&#32622;&#39030;15&#22825;&#65292;70&#20803;');

	showsetting('&#20889;&#23383;&#27004;&#21457;&#24067;&#37329;&#39069;', 'setting[OfficeMoney]', $common_setting ? $setting['OfficeMoney'] : 1,'text','','','&#48;&#25110;&#31354;&#20026;&#20813;&#36153;&#21457;&#24067;');

	showsetting('&#20889;&#23383;&#27004;&#21047;&#26032;&#20215;&#26684;', 'setting[OfficeRefreshMoney]', $common_setting ? $setting['OfficeRefreshMoney'] : 1,'text');

	showsetting('&#20889;&#23383;&#27004;&#32622;&#39030;&#20215;&#26684;', 'setting[OfficeTopMoney]', $common_setting ? $setting['OfficeTopMoney'] : '30|100|&#32622;&#39030;30&#22825;&#65292;100&#20803;
15|70|&#32622;&#39030;15&#22825;&#65292;70&#20803;','textarea','','','&#19968;&#34892;&#19968;&#20215;&#26684;&#65292;&#26684;&#24335;&#65306;&#22825;&#25968;|&#20215;&#26684;|&#25991;&#23383;<br>30|100|&#32622;&#39030;30&#22825;&#65292;100&#20803;<br>15|70|&#32622;&#39030;15&#22825;&#65292;70&#20803;');

	showsetting('&#20179;&#24211;&#21457;&#24067;&#37329;&#39069;', 'setting[WarehouseMoney]', $common_setting ? $setting['WarehouseMoney'] : 1,'text','','','&#48;&#25110;&#31354;&#20026;&#20813;&#36153;&#21457;&#24067;');

	showsetting('&#20179;&#24211;&#21047;&#26032;&#20215;&#26684;', 'setting[WarehouseRefreshMoney]', $common_setting ? $setting['WarehouseRefreshMoney'] : 1,'text');

	showsetting('&#20179;&#24211;&#32622;&#39030;&#20215;&#26684;', 'setting[WarehouseTopMoney]', $common_setting ? $setting['WarehouseTopMoney'] : '30|100|&#32622;&#39030;30&#22825;&#65292;100&#20803;
15|70|&#32622;&#39030;15&#22825;&#65292;70&#20803;','textarea','','','&#19968;&#34892;&#19968;&#20215;&#26684;&#65292;&#26684;&#24335;&#65306;&#22825;&#25968;|&#20215;&#26684;|&#25991;&#23383;<br>30|100|&#32622;&#39030;30&#22825;&#65292;100&#20803;<br>15|70|&#32622;&#39030;15&#22825;&#65292;70&#20803;');

	showsetting('&#22303;&#22320;&#21457;&#24067;&#37329;&#39069;', 'setting[LandMoney]', $common_setting ? $setting['LandMoney'] : 1,'text','','','&#48;&#25110;&#31354;&#20026;&#20813;&#36153;&#21457;&#24067;');

	showsetting('&#22303;&#22320;&#21047;&#26032;&#20215;&#26684;', 'setting[LandRefreshMoney]', $common_setting ? $setting['LandRefreshMoney'] : 1,'text');

	showsetting('&#22303;&#22320;&#32622;&#39030;&#20215;&#26684;', 'setting[LandTopMoney]', $common_setting ? $setting['LandTopMoney'] : '30|100|&#32622;&#39030;30&#22825;&#65292;100&#20803;
15|70|&#32622;&#39030;15&#22825;&#65292;70&#20803;','textarea','','','&#19968;&#34892;&#19968;&#20215;&#26684;&#65292;&#26684;&#24335;&#65306;&#22825;&#25968;|&#20215;&#26684;|&#25991;&#23383;<br>30|100|&#32622;&#39030;30&#22825;&#65292;100&#20803;<br>15|70|&#32622;&#39030;15&#22825;&#65292;70&#20803;');

	showsetting('&#25151;&#28304;&#26597;&#30475;&#32852;&#31995;&#37329;&#39069;', 'setting[SeeInfoMoney]', $setting['SeeInfoMoney'],'textarea','','','&#49;&#20195;&#34920;&#20108;&#25163;&#25151;&#65292;&#50;&#20195;&#34920;&#20986;&#31199;&#25151;&#65292;&#51;&#20195;&#34920;&#21830;&#38138;&#65292;&#52;&#20195;&#34920;&#21378;&#25151;&#65292;&#53;&#20195;&#34920;&#20889;&#23383;&#27004;&#65292;&#54;&#20195;&#34920;&#20179;&#24211;&#65292;&#55;&#20195;&#34920;&#22303;&#22320;&#65292;&#26684;&#24335;&#65306;&#49;&#61;&#37329;&#39069;&#40;&#31354;&#20195;&#34920;&#20813;&#36153;&#41;&#65292;&#20363;&#22914;<br>1=0.01<br>2=0.02');

	showsetting('&#25151;&#28304;&#26597;&#30475;&#32852;&#31995;&#25552;&#31034;&#35821;', 'setting[SeeInfoMoneyTips]', $setting['SeeInfoMoneyTips'] ? $setting['SeeInfoMoneyTips'] : '&#20026;&#38450;&#27490;&#24191;&#21578;&#39578;&#25200;&#123;&#98;&#114;&#125;&#35831;&#20184;&#123;&#109;&#111;&#110;&#101;&#121;&#125;&#20803;&#26597;&#35810;&#32852;&#31995;&#26041;&#24335;','textarea','','','&#123;&#109;&#111;&#110;&#101;&#121;&#125;&#20195;&#34920;&#37329;&#39069;&#65292;&#123;&#98;&#114;&#125;&#20195;&#34920;&#25442;&#34892;');

	showsetting('&#20013;&#20171;&#21047;&#26032;&#20215;&#26684;', 'setting[AgentRefreshMoney]', $common_setting ? $setting['AgentRefreshMoney'] : 1,'text','','','&#19981;&#22635;&#21017;&#19981;&#24320;&#21551;');

	showsetting('&#20013;&#20171;&#32622;&#39030;&#20215;&#26684;', 'setting[AgentTopMoney]', $common_setting ? $setting['AgentTopMoney'] : '30|100|&#32622;&#39030;30&#22825;&#65292;100&#20803;
15|70|&#32622;&#39030;15&#22825;&#65292;70&#20803;','textarea','','','&#19968;&#34892;&#19968;&#20215;&#26684;&#65292;&#26684;&#24335;&#65306;&#22825;&#25968;|&#20215;&#26684;|&#25991;&#23383;<br>30|100|&#32622;&#39030;30&#22825;&#65292;100&#20803;<br>15|70|&#32622;&#39030;15&#22825;&#65292;70&#20803;');

	showsetting('&#26597;&#30475;&#27714;&#31199;&#27714;&#36141;&#25552;&#31034;&#35821;&#32;', 'setting[DemandMoneyTips]', $setting['DemandMoneyTips'] ? $setting['DemandMoneyTips'] : '&#20026;&#38450;&#27490;&#24191;&#21578;&#39578;&#25200;&#65292;&#35831;&#20184;{Money}&#20803;&#26597;&#35810;&#31199;&#23458;&#21495;&#30721;&#65281; ','text','','','&#123;&#77;&#111;&#110;&#101;&#121;&#125;&#20195;&#34920;&#37329;&#39069;&#65292;&#123;&#98;&#114;&#125;&#20195;&#34920;&#25442;&#34892;');

	showsetting('&#26597;&#30475;&#27714;&#31199;&#27714;&#36141;&#37329;&#39069;', 'setting[DemandMoney]', $common_setting ? $setting['DemandMoney'] : 2,'text','','','&#48;&#25110;&#31354;&#20195;&#34920;&#19981;&#24320;&#21551;&#25910;&#36153;&#26597;&#30475;&#27714;&#31199;&#27714;&#36141;&#32852;&#31995;&#26041;&#24335;');

	if(AppYes){
		showsetting('&#65;&#80;&#80;&#21457;&#24067;&#25552;&#31034;&#35821;', 'setting[AppPublishHint]', $setting['AppPublishHint'] ? $setting['AppPublishHint'] : '&#35813;&#26465;&#21457;&#24067;&#38656;&#35201;&#25903;&#20184;{Money}&#20803;{br}
&#21069;&#24448;App&#21457;&#24067;&#65292;&#20165;&#38656;{AppMoney}&#20803;&#65292;{Down}','textarea','','','&#35774;&#32622;&#20102;App&#21457;&#24067;&#37329;&#39069;&#21518;&#29983;&#25928;&#65292;&#20316;&#29992;&#65306;&#38750;App&#19979; &#20351;&#29992;&#35813;&#25552;&#31034;&#35821;<br>{Money}&#20195;&#34920;&#37329;&#39069;&#65292;{AppMoney}&#20195;&#34920;App&#21457;&#24067;&#37329;&#39069;&#65292;{br}&#20195;&#34920;&#25442;&#34892;&#65292;{Down}&#20195;&#34920;&#28857;&#20987;&#19979;&#36733;');

		showsetting('APP&#25151;&#28304;&#26597;&#30475;&#32852;&#31995;&#37329;&#39069;', 'setting[AppSeeInfoMoney]', $setting['AppSeeInfoMoney'],'textarea','','','&#49;&#20195;&#34920;&#20108;&#25163;&#25151;&#65292;&#50;&#20195;&#34920;&#20986;&#31199;&#25151;&#65292;&#51;&#20195;&#34920;&#21830;&#38138;&#65292;&#52;&#20195;&#34920;&#21378;&#25151;&#65292;&#53;&#20195;&#34920;&#20889;&#23383;&#27004;&#65292;&#54;&#20195;&#34920;&#20179;&#24211;&#65292;&#55;&#20195;&#34920;&#22303;&#22320;&#65292;&#26684;&#24335;&#65306;&#49;&#61;&#37329;&#39069;&#40;&#31354;&#20195;&#34920;&#20813;&#36153;&#41;&#65292;&#20363;&#22914;<br>1=0.01<br>2=0.02');

		showsetting('APP&#25151;&#28304;&#26597;&#30475;&#32852;&#31995;&#25552;&#31034;&#35821;', 'setting[AppSeeInfoMoneyTips]', $setting['AppSeeInfoMoneyTips'] ? $setting['AppSeeInfoMoneyTips'] : '&#20026;&#38450;&#27490;&#24191;&#21578;&#39578;&#25200;&#123;&#98;&#114;&#125;&#35831;&#20184;&#123;&#109;&#111;&#110;&#101;&#121;&#125;&#20803;&#26597;&#35810;&#32852;&#31995;&#26041;&#24335;&#123;&#98;&#114;&#125;&#21069;&#24448;&#65;&#80;&#80;&#26597;&#30475;&#65292;&#20165;&#38656;&#123;&#65;&#112;&#112;&#77;&#111;&#110;&#101;&#121;&#125;&#20803;&#65292;&#123;&#68;&#111;&#119;&#110;&#125;','textarea','','','&#35774;&#32622;&#20102;&#12304;&#25151;&#28304;&#26597;&#30475;&#32852;&#31995;&#37329;&#39069;&#12305;&#21518;&#29983;&#25928;&#65292;&#20316;&#29992;&#65306;&#38750;&#65;&#80;&#80;&#19979;&#32;&#20351;&#29992;&#35813;&#25552;&#31034;&#35821;<br>&#123;&#109;&#111;&#110;&#101;&#121;&#125;&#20195;&#34920;&#37329;&#39069;&#65292;&#123;&#65;&#112;&#112;&#77;&#111;&#110;&#101;&#121;&#125;&#20195;&#34920;&#65;&#112;&#112;&#21457;&#24067;&#37329;&#39069;&#65292;&#123;&#98;&#114;&#125;&#20195;&#34920;&#25442;&#34892;&#65292;&#123;&#68;&#111;&#119;&#110;&#125;&#20195;&#34920;&#28857;&#20987;&#19979;&#36733;');

		showsetting('&#20108;&#25163;&#25151;&#65;&#80;&#80;&#21457;&#24067;&#20215;&#26684;', 'setting[HouseAppMoney]', $common_setting ? $setting['HouseAppMoney'] : 0.8,'text','','','&#48;&#47;&#31354;&#20195;&#34920;&#20813;&#36153;');

		showsetting('&#20986;&#31199;&#25151;&#65;&#80;&#80;&#21457;&#24067;&#20215;&#26684;', 'setting[RentalAppMoney]', $common_setting ? $setting['RentalAppMoney'] : 0.8,'text','','','&#48;&#47;&#31354;&#20195;&#34920;&#20813;&#36153;');

		showsetting('&#21830;&#38138;&#65;&#80;&#80;&#21457;&#24067;&#20215;&#26684;', 'setting[ShopAppMoney]', $common_setting ? $setting['ShopAppMoney'] : 0.8,'text','','','&#48;&#47;&#31354;&#20195;&#34920;&#20813;&#36153;');

		showsetting('&#21378;&#25151;&#65;&#80;&#80;&#21457;&#24067;&#20215;&#26684;', 'setting[WorkShopAppMoney]', $common_setting ? $setting['WorkShopAppMoney'] : 0.8,'text','','','&#48;&#47;&#31354;&#20195;&#34920;&#20813;&#36153;');

		showsetting('&#20889;&#23383;&#27004;&#65;&#80;&#80;&#21457;&#24067;&#20215;&#26684;', 'setting[OfficeAppMoney]', $common_setting ? $setting['OfficeAppMoney'] : 0.8,'text','','','&#48;&#47;&#31354;&#20195;&#34920;&#20813;&#36153;');

		showsetting('&#20179;&#24211;&#65;&#80;&#80;&#21457;&#24067;&#20215;&#26684;', 'setting[WarehouseAppMoney]', $common_setting ? $setting['WarehouseAppMoney'] : 0.8,'text','','','&#48;&#47;&#31354;&#20195;&#34920;&#20813;&#36153;');

		showsetting('&#22303;&#22320;&#65;&#80;&#80;&#21457;&#24067;&#20215;&#26684;', 'setting[LandAppMoney]', $common_setting ? $setting['LandAppMoney'] : 0.8,'text','','','&#48;&#47;&#31354;&#20195;&#34920;&#20813;&#36153;');

		showsetting('&#65;&#80;&#80;&#26597;&#30475;&#27714;&#31199;&#27714;&#36141;&#25552;&#31034;&#35821;', 'setting[AppDemandMoneyTips]', $setting['AppDemandMoneyTips'] ? $setting['AppDemandMoneyTips'] : '&#20026;&#38450;&#27490;&#24191;&#21578;&#39578;&#25200;&#65292;&#35831;&#20184;{Money}&#20803;&#26597;&#35810;&#31199;&#23458;&#21495;&#30721;&#65281; {br}
&#21069;&#24448;App&#26597;&#30475;&#65292;&#20165;&#38656;{AppMoney}&#20803;&#21363;&#21487;&#26597;&#30475;&#65292;{Down}','textarea','','','&#35774;&#32622;&#20102;App&#21457;&#24067;&#37329;&#39069;&#21518;&#29983;&#25928;&#65292;&#20316;&#29992;&#65306;&#38750;App&#19979; &#20351;&#29992;&#35813;&#25552;&#31034;&#35821;<br>{Money}&#20195;&#34920;&#37329;&#39069;&#65292;{AppMoney}&#20195;&#34920;App&#21457;&#24067;&#37329;&#39069;&#65292;{br}&#20195;&#34920;&#25442;&#34892;&#65292;{Down}&#20195;&#34920;&#28857;&#20987;&#19979;&#36733;');

		showsetting('APP&#26597;&#30475;&#27714;&#31199;&#27714;&#36141;&#37329;&#39069;', 'setting[DemandAppMoney]', $common_setting ? $setting['DemandAppMoney'] : 1,'text','','','&#19981;&#35774;&#32622;&#32487;&#25215;&#12304;&#26597;&#30475;&#27714;&#31199;&#27714;&#36141;&#37329;&#39069;&#12305;');

	}

	echo <<<HTML
	</div>
	<!-- �������� end  -->
HTML;

	echo <<<HTML
	<!-- ¥������  -->
	<div class="tab-pane" id="disc" role="tabpanel" aria-expanded="false">
HTML;
	
	showsetting('&#35013;&#20462;&#31867;&#22411;&#26631;&#31614;', 'setting[DiscDecorationTag]', $setting['DiscDecorationTag'] ? $setting['DiscDecorationTag'] : '1=&#27611;&#22383;
2=&#26222;&#36890;&#35013;&#20462;
3=&#31934;&#35013;&#20462;
4=&#35946;&#21326;&#35013;&#20462;','textarea','','','&#19968;&#34892;&#19968;&#26631;&#31614;&#65292;&#26684;&#24335;&#65306;<br>1=&#26631;&#31614;&#19968;<br>2=&#26631;&#31614;&#20108;');

	showsetting('&#25151;&#23627;&#31867;&#22411;&#26631;&#31614;', 'setting[DiscHouseTypeList]', $setting['DiscHouseTypeList'] ? $setting['DiscHouseTypeList'] : '1=&#20303;&#23429;
2=&#23398;&#21306;&#25151;
3=&#21035;&#22661;
4=&#23567;&#39640;&#23618;
5=&#38376;&#38754;&#25151;
6=&#21150;&#20844;
7=&#26495;&#24335;&#20303;&#23429;&#27915;&#25151;
8=&#20854;&#20182;','textarea','','','&#19968;&#34892;&#19968;&#26631;&#31614;&#65292;&#26684;&#24335;&#65306;<br>1=&#26631;&#31614;&#19968;<br>2=&#26631;&#31614;&#20108;');

	showsetting('&#29305;&#33394;&#26631;&#31614;', 'setting[DiscTagList]', $setting['DiscTagList'] ? $setting['DiscTagList'] : '1=&#21335;&#21271;&#36890;&#36879;
2=&#36879;&#22823;&#39128;&#31383;
3=&#21452;&#38451;&#21488;
4=&#32511;&#21270;&#29575;&#39640;
5=&#21452;&#21355;&#29983;&#38388;
6=&#23398;&#21306;&#25151;
7=&#27839;&#34903;&#21830;&#38138;
8=&#20844;&#20132;&#27839;&#32447;
9=&#36817;&#21307;&#38498;
10=&#26223;&#35266;&#23621;&#25152;
11=&#38752;&#36817;&#20844;&#22253;','textarea','','','&#19968;&#34892;&#19968;&#26631;&#31614;&#65292;&#26684;&#24335;&#65306;<br>1=&#26631;&#31614;&#19968;<br>2=&#26631;&#31614;&#20108;');

	showsetting('&#25143;&#22411;&#26631;&#31614;', 'setting[DiscHuXingTagList]', $setting['DiscHuXingTagList'] ? $setting['DiscHuXingTagList'] : '1=&#21452;&#38451;&#21488;
2=&#22823;&#39128;&#31383;
3=&#39640;&#36192;&#36865;
4=&#25143;&#22411;&#26041;&#27491;
5=&#21452;&#21355;
6=&#21333;&#21355;
7=&#24067;&#23616;&#21512;&#29702;
8=&#39128;&#31383;&#35774;&#35745;','textarea','','','&#19968;&#34892;&#19968;&#26631;&#31614;&#65292;&#26684;&#24335;&#65306;<br>1=&#26631;&#31614;&#19968;<br>2=&#26631;&#31614;&#20108;');

	showsetting('&#22343;&#20215;&#21015;&#34920;', 'setting[DiscJiaGeList]', $setting['DiscJiaGeList'] ? $setting['DiscJiaGeList'] : '3000-0=3000&#20803;&#20197;&#19979;
3000-4000=3000-4000&#20803;
4000-5000=4000-5000&#20803;
5000-6000=5000-6000&#20803;
6000-7000=6000-7000&#20803;
7000-9000=7000-9000&#20803;
9000-10000=9000-10000&#20803;
0-10000=1&#19975;&#20197;&#19978;','textarea','','','&#19968;&#34892;&#19968;&#20215;&#26684;&#65292;&#26684;&#24335;&#65306;<br>3000-0=&#20215;&#26684;&#19968;<br>3000-4000=&#20215;&#26684;&#20108;');

	showsetting('&#26356;&#22810;&#27004;&#30424;&#20449;&#24687;&#23637;&#24320;', 'setting[DiscMoreInfoSwitch]', $setting['DiscMoreInfoSwitch'],'radio');

	showsetting('&#26174;&#31034;&#22242;&#36141;&#21015;&#34920;', 'setting[DiscGroupBuyingSwitch]', $setting['DiscGroupBuyingSwitch'],'radio');

	echo <<<HTML
	</div>
	<!-- ¥������ end  -->
HTML;
	echo <<<HTML
	<!-- ���԰�����  -->
	<div class="tab-pane" id="pc" role="tabpanel" aria-expanded="false">
HTML;
	
	showsetting('&#30005;&#33041;&#29256;&#24320;&#21551;',array('setting[PcQrSwitch]', array(
		array('1','&#26159;', array('PcSwitch_1' => '','PcSwitch_0' => 'none')),
		array('0','&#21542;', array('PcSwitch_1' => 'none','PcSwitch_0' => '')),
	), TRUE),$common_setting ? $setting['PcQrSwitch'] : 1, 'mradio');

	showtagheader('div', 'PcSwitch_1', $setting['PcQrSwitch'] == 1 || !$common_setting ? true : '','ssub');
		$setting['PcLogoPath'] = $setting['PcLogoPath'] ? $setting['PcLogoPath'] : '/source/plugin/fn_house/static/images/logo.png';
		$PcLogoPathHtml = '<a href="'.$setting['PcLogoPath'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['PcLogoPath'].'" height="35"/></a>&#24314;&#35758;&#32;&#50;&#51;&#56;&#32;&#42;&#32;&#55;&#52;';
		showsetting('&#76;&#111;&#103;&#111;&#36335;&#24452;', 'new_PcLogoPath',$setting['PcLogoPath'], 'filetext', '', 0, $PcLogoPathHtml);

		showsetting('&#24213;&#37096;&#25991;&#23383;', 'setting[PcFooterContent]', $setting['PcFooterContent'] ? $setting['PcFooterContent'] : '<p>Copyright 2019 &#39134;&#40479;&#25151;&#20135;&#39134;&#40479;&#25151;&#20135;&#39134;&#40479;&#25151;&#20135;&#39134;&#40479;&#25151;&#20135;</p>
<p>&#20840;&#22269;&#32479;&#19968;&#26381;&#21153;&#28909;&#32447; 4000000000&#36716;0000 | &#37038;&#31665;&#65306;9510654@qq.com</p>
<p>&#32463;&#33829;&#24615;ICP&#35777;&#65306;&#28248;ICP&#22791;12003586&#21495;-55</p>
<p>&#22686;&#20540;&#30005;&#20449;&#19994;&#21153;&#32463;&#33829;&#35768;&#21487;&#35777;&#65306;&#28248;B2-20130102</p>', 'textarea');

		showsetting('&#27178;&#24133;&#39640;&#24230;', 'setting[PcBannersHeight]', $setting['PcBannersHeight'] ? $setting['PcBannersHeight'] : 440, 'text');
		
		showsetting('&#32593;&#31449;&#23458;&#26381;&#81;&#81;', 'setting[PcQQ]', $setting['PcQQ'] ? $setting['PcQQ'] : 9510654, 'text');

		showsetting('&#23548;&#33322;&#36873;&#20013;&#39068;&#33394;', 'setting[PcNavHoverColor]', $setting['PcNavHoverColor'] ? $setting['PcNavHoverColor'] : '#01af63', 'color');

		showsetting('&#21451;&#24773;&#38142;&#25509;', 'setting[PcFriendLink]', $setting['PcFriendLink'], 'textarea','','','&#19968;&#34892;&#19968;&#38142;&#25509;&#65292;&#26684;&#24335;&#65306;&#25991;&#23383;&#124;&#38142;&#25509;&#65281;&#65281;&#65281;&#20363;&#22914;<br>&#39134;&#40479;&#49;&#124;&#104;&#116;&#116;&#112;&#58;&#47;&#47;&#100;&#101;&#118;&#46;&#102;&#110;&#109;&#111;&#116;&#111;&#46;&#99;&#111;&#109;<br>&#39134;&#40479;&#50;&#124;&#104;&#116;&#116;&#112;&#58;&#47;&#47;&#100;&#101;&#118;&#46;&#102;&#110;&#109;&#111;&#116;&#111;&#46;&#99;&#111;&#109;');

		showsetting('&#39318;&#39029;&#27004;&#30424;&#35843;&#29992;&#26465;&#25968;', 'setting[PcIndexDiscNum]', $setting['PcIndexDiscNum'] ? $setting['PcIndexDiscNum'] : 8, 'text');

		showsetting('&#36164;&#35759;&#26159;&#21542;&#26174;&#31034;',array('setting[PcHomeArticle]', array(
			array('1','&#26159;', array('PcHomeArticle_div' => '')),
			array('0','&#21542;', array('PcHomeArticle_div' => 'none')),
		), TRUE),$common_setting ? $setting['PcHomeArticle'] : 1, 'mradio');
		showtagheader('div', 'PcHomeArticle_div', $setting['PcHomeArticle'] || !$common_setting ? true : '','sub');
			showsetting('&#36164;&#35759;&#24187;&#28783;&#29255;&#35843;&#29992;&#26465;&#25968;', 'setting[PcArticleSlideNum]', $setting['PcArticleSlideNum'] ? $setting['PcArticleSlideNum'] : 5, 'text');
		showtagfooter('div');

		showsetting('&#39318;&#39029;&#83;&#69;&#79;&#26631;&#39064;&#25551;&#36848;', 'setting[PcHomeSeo]', $setting['PcHomeSeo'], 'textarea','','','&#26684;&#24335;&#65306;&#26631;&#39064;&#35;&#20851;&#38190;&#35789;&#35;&#25551;&#36848;');

		showsetting('&#27004;&#30424;&#21015;&#34920;&#83;&#69;&#79;', 'setting[PcListDiscSeo]', $setting['PcListDiscSeo'], 'textarea','','','&#26684;&#24335;&#65306;&#26631;&#39064;&#35;&#20851;&#38190;&#35789;&#35;&#25551;&#36848;');

		showsetting('&#27004;&#30424;&#35814;&#24773;&#83;&#69;&#79;', 'setting[PcViewDiscSeo]', $setting['PcViewDiscSeo'], 'textarea','','','&#26684;&#24335;&#65306;&#26631;&#39064;&#35;&#20851;&#38190;&#35789;&#35;&#25551;&#36848;<br>&#32;&#123;&#116;&#105;&#116;&#108;&#101;&#125;&#20195;&#26631;&#39064;&#65292;&#123;&#99;&#111;&#110;&#116;&#101;&#110;&#116;&#125;&#20195;&#25551;&#36848;');

		showsetting('&#25151;&#28304;&#21015;&#34920;&#83;&#69;&#79;&#26631;&#39064;', 'setting[PcListSeo]', $setting['PcListSeo'], 'textarea','','','1&#20195;&#34920;&#20108;&#25163;&#25151;&#65292;2&#20195;&#34920;&#20986;&#31199;&#25151;&#65292;3&#20195;&#34920;&#21830;&#38138;&#65292;4&#20195;&#34920;&#21378;&#25151;&#65292;5&#20195;&#34920;&#20889;&#23383;&#27004;&#65292;6&#20195;&#34920;&#20179;&#24211;&#65292;7&#20195;&#34920;&#22303;&#22320;&#65292;&#26684;&#24335;&#65306;1=&#26631;&#39064;#&#20851;&#38190;&#35789;#&#25551;&#36848;&#65292;&#20363;&#22914;<br>1=&#39134;&#40479;&#20108;&#25163;&#25151;#&#20108;&#25163;&#25151;&#20851;&#38190;&#35789;#&#20108;&#25163;&#25151;&#25551;&#36848;<br>2=&#39134;&#40479;&#20986;&#31199;&#25151;#&#20986;&#31199;&#25151;&#20851;&#38190;&#35789;#&#20108;&#25163;&#25151;&#25551;&#36848;');

		showsetting('&#25151;&#28304;&#35814;&#24773;&#39029;&#83;&#69;&#79;', 'setting[PcViewSeo]', $setting['PcViewSeo'], 'textarea','','','&#26684;&#24335;&#65306;&#26631;&#39064;&#35;&#20851;&#38190;&#35789;&#35;&#25551;&#36848;<br>&#32;&#123;&#116;&#105;&#116;&#108;&#101;&#125;&#20195;&#26631;&#39064;&#65292;&#123;&#99;&#108;&#97;&#115;&#115;&#125;&#20195;&#20998;&#31867;&#65292;&#123;&#99;&#111;&#110;&#116;&#101;&#110;&#116;&#125;&#20195;&#25551;&#36848;');

		showsetting('&#36164;&#35759;&#35814;&#24773;&#39029;&#83;&#69;&#79;', 'setting[PcArticleSeo]', $setting['PcArticleSeo'], 'textarea','','','&#26684;&#24335;&#65306;&#26631;&#39064;&#35;&#20851;&#38190;&#35789;&#35;&#25551;&#36848;<br>&#32;&#123;&#116;&#105;&#116;&#108;&#101;&#125;&#20195;&#26631;&#39064;&#65292;&#123;&#99;&#108;&#97;&#115;&#115;&#125;&#20195;&#20998;&#31867;&#65292;&#123;&#99;&#111;&#110;&#116;&#101;&#110;&#116;&#125;&#20195;&#25551;&#36848;');
		
		showsetting('&#25151;&#28304;&#21015;&#34920;&#24191;&#21578;&#22270;', 'setting[PcListHouseAd]', $setting['PcListHouseAd'], 'textarea','','','1&#20195;&#34920;&#20108;&#25163;&#25151;&#65292;2&#20195;&#34920;&#20986;&#31199;&#25151;&#65292;3&#20195;&#34920;&#21830;&#38138;&#65292;4&#20195;&#34920;&#21378;&#25151;&#65292;5&#20195;&#34920;&#21378;&#25151;&#65292;6&#20195;&#34920;&#20179;&#24211;&#65292;7&#20195;&#34920;&#22303;&#22320;&#65292;&#26684;&#24335;&#65306;1=&#22270;&#29255;&#36335;&#24452;|&#24191;&#21578;&#38142;&#25509;#&#22270;&#29255;&#36335;&#24452;1|&#24191;&#21578;&#36335;&#24452;1<br>1=source/plugin/fn_house/static/images/ad2.jpg|http://dev.yili6.com<br>2=source/plugin/fn_house/static/images/ad1.gif|http://dev.yili6.com');

		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">&#27178;&#24133;<br>&#24314;&#35758;&#65306;&#49;&#57;&#50;&#48;&#32;&#42;&#32;&#52;&#52;&#48;</label><div class="col-sm-9"><div class="UploadBanner"><div class="PhotoControl ClickPhotoControl" id="pc_banners"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';

		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">&#39030;&#37096;&#20108;&#32500;&#30721;</label><div class="col-sm-9"><div class="UploadBanner"><div class="PhotoControl ClickPhotoControl" id="head_top_qr_list"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';

		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">&#24213;&#37096;&#20108;&#32500;&#30721;</label><div class="col-sm-9"><div class="UploadBanner"><div class="PhotoControl ClickPhotoControl" id="footer_qr_list"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';

		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">&#39318;&#39029;&#24191;&#21578;&#22270;&#29255;&#49;<br>&#24314;&#35758;&#23610;&#23544;&#65306;&#49;&#50;&#48;&#48;&#32;&#42;&#32;&#57;&#48;</label><div class="col-sm-9"><div class="UploadBanner"><div class="PhotoControl ClickPhotoControl" id="pc_home_ad_1"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';

		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">&#39318;&#39029;&#24191;&#21578;&#22270;&#29255;&#50;<br>&#24314;&#35758;&#23610;&#23544;&#65306;&#49;&#50;&#48;&#48;&#32;&#42;&#32;&#57;&#48;</label><div class="col-sm-9"><div class="UploadBanner"><div class="PhotoControl ClickPhotoControl" id="pc_home_ad_2"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';

		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">&#27004;&#30424;&#21015;&#34920;&#24191;&#21578;&#22270;<br>&#24314;&#35758;&#23610;&#23544;&#65306;&#49;&#50;&#48;&#48;&#32;&#42;&#32;&#57;&#48;</label><div class="col-sm-9"><div class="UploadBanner"><div class="PhotoControl ClickPhotoControl" id="pc_list_disc_ad1"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';

		showsetting('&#25151;&#28304;&#32852;&#31995;&#30005;&#35805;&#38656;&#30331;&#24405;&#65311;', 'setting[PcViewTelContact]', $setting['PcViewTelContact'],'radio','','','&#25151;&#28304;&#26597;&#30475;&#32852;&#31995;&#30005;&#35805;&#26159;&#21542;&#38656;&#35201;&#38656;&#30331;&#24405;&#25165;&#21487;&#26597;&#30475;');

	showtagfooter('div');

	showtagheader('div', 'PcSwitch_0', !$setting['PcSwitch'] && !$common_setting ? true : '','ssub');
		showsetting('&#20108;&#32500;&#30721;&#25552;&#31034;&#35821;', 'setting[PcQrText]', $setting['PcQrText'] ? $setting['PcQrText'] : '&#24494;&#20449;&#25195;&#19968;&#25195;&#65292;&#26356;&#26041;&#20415;', 'text');
	showtagfooter('div');

	echo <<<HTML
	</div>
	<!-- ���԰����� end  -->
HTML;
	
	echo <<<HTML
	<!-- ΢������  -->
	<div class="tab-pane" id="wx" role="tabpanel" aria-expanded="false">
HTML;
	
	showsetting('&#24320;&#21551;&#21442;&#25968;&#20108;&#32500;&#30721;',array('setting[QrParameterSwitch]', array(
		array('1','&#26159;', array('QrParameterDiv' => '')),
		array('0','&#21542;', array('QrParameterDiv' => 'none')),
	), TRUE),$setting['QrParameterSwitch'], 'mradio','','','&#22914;&#24819;&#21333;&#29420;&#20844;&#20247;&#21495;&#25165;&#35774;&#32622;&#27492;&#39033;&#65292;&#19981;&#24819;&#21333;&#29420;&#21448;&#24819;&#24320;&#21551;&#65292;&#21487;&#22312;&#22522;&#30784;&#32452;&#20214;&#35774;&#32622;<br>&#35831;&#20808;&#35774;&#32622;&#24494;&#20449;&#65;&#112;&#112;&#105;&#100;&#47;&#24494;&#20449;&#83;&#101;&#99;&#114;&#101;&#116;&#47;&#24494;&#20449;&#20196;&#29260;&#65281;&#19988;&#21435;&#20844;&#20247;&#21495;&#21518;&#21488;&#45;&#62;&#22522;&#26412;&#37197;&#32622;&#45;&#62;&#26381;&#21153;&#22120;&#37197;&#32622;&#45;&#62;&#26381;&#21153;&#22120;&#22320;&#22336;&#40;&#85;&#82;&#76;&#41;&#22635;&#20889;&#65306;&#20320;&#30340;&#22495;&#21517;&#47;&#115;&#111;&#117;&#114;&#99;&#101;&#47;&#112;&#108;&#117;&#103;&#105;&#110;&#47;&#102;&#110;&#95;&#97;&#115;&#115;&#101;&#109;&#98;&#108;&#121;&#47;&#97;&#112;&#105;&#47;&#119;&#101;&#99;&#104;&#97;&#116;&#46;&#112;&#104;&#112;&#63;&#112;&#108;&#117;&#103;&#105;&#110;&#95;&#105;&#100;&#61;&#102;&#110;&#95;&#104;&#111;&#117;&#115;&#101;<br>&#28023;&#25253;&#29983;&#25104;&#30340;&#20108;&#32500;&#30721;&#24102;&#21442;&#25968;&#65292;&#26410;&#20851;&#27880;&#20844;&#20247;&#21495;&#25552;&#31034;&#20851;&#27880;&#65292;&#20851;&#27880;&#21518;&#33258;&#21160;&#25512;&#36865;&#38142;&#25509;');
	showtagheader('div', 'QrParameterDiv', $setting['QrParameterSwitch'] == 1 ? true : '','sub');
		showsetting('&#24494;&#20449;&#65;&#112;&#112;&#73;&#100;', 'setting[WxAppid]', $setting['WxAppid'], 'text');
		showsetting('&#24494;&#20449;&#83;&#101;&#99;&#114;&#101;&#116;', 'setting[WxSecret]', $setting['WxSecret'], 'text');
		showsetting('&#24494;&#20449;&#20196;&#29260;&#40;&#84;&#111;&#107;&#101;&#110;&#41;', 'setting[wechat_token]', $setting['wechat_token'], 'text','','','&#33719;&#21462;&#26041;&#24335;&#65306;&#20844;&#20247;&#21495;&#21518;&#21488;&#45;&#12299;&#22522;&#26412;&#37197;&#32622;&#45;&#12299;&#26381;&#21153;&#22120;&#37197;&#32622;&#45;&#12299;&#20196;&#29260;&#40;&#84;&#111;&#107;&#101;&#110;&#41;');
	showtagfooter('div');

	$WxFollowPathHtml = ($setting['WxFollowPath'] ? '<a href="'.$setting['WxFollowPath'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['WxFollowPath'].'" height="55"/></a>' : '').'&#19981;&#35774;&#32622;&#21017;&#19981;&#24320;&#21551;&#65292;&#24494;&#20449;&#20869;&#25165;&#20250;&#26174;&#31034;';
	showsetting('&#20844;&#20247;&#21495;&#20108;&#32500;&#30721;', 'new_WxFollowPath',$setting['WxFollowPath'], 'filetext', '', 0, $WxFollowPathHtml);

	showsetting('&#20851;&#27880;&#20844;&#20247;&#21495;&#25552;&#31034;&#35821;', 'setting[WxFollowText]', $setting['WxFollowText'] ? $setting['WxFollowText'] : '<p>&#20851;&#27880;&#25105;&#20204;&#33719;&#21462;&#26356;&#22810;&#25151;&#28304;&#25110;&#27004;&#30424;</p>
<p>&#38271;&#25353;&#20108;&#32500;&#30721;&#35782;&#21035;&#20851;&#27880;</p>', 'textarea');

	echo <<<HTML
	</div>
	<!-- ΢������ end  -->
HTML;
	
	echo <<<HTML
	<!-- ����ģ������  -->
	<div class="tab-pane" id="sms" role="tabpanel" aria-expanded="false">
HTML;

	if($Config['PluginVar']['ShortMessageType'] == 1){

		showsetting('&#38463;&#37324;&#20113;&#31614;&#21517;&#21517;&#31216;', 'setting[AliAutograph]', $setting['AliAutograph'], 'text','','','&#33719;&#21462;&#26041;&#24335;&#65306;&#104;&#116;&#116;&#112;&#115;&#58;&#47;&#47;&#100;&#121;&#115;&#109;&#115;&#46;&#99;&#111;&#110;&#115;&#111;&#108;&#101;&#46;&#97;&#108;&#105;&#121;&#117;&#110;&#46;&#99;&#111;&#109;&#47;&#100;&#121;&#115;&#109;&#115;&#46;&#104;&#116;&#109;&#35;&#47;&#100;&#111;&#109;&#101;&#115;&#116;&#105;&#99;&#47;&#116;&#101;&#120;&#116;&#47;&#115;&#105;&#103;&#110;');

		showsetting('&#38463;&#37324;&#20113;&#36890;&#30693;&#27169;&#26495;&#67;&#79;&#68;&#69;', 'setting[AliNoticeId]', $setting['AliNoticeId'], 'text','','','&#33719;&#21462;&#26041;&#24335;&#65306;&#104;&#116;&#116;&#112;&#115;&#58;&#47;&#47;&#100;&#121;&#115;&#109;&#115;&#46;&#99;&#111;&#110;&#115;&#111;&#108;&#101;&#46;&#97;&#108;&#105;&#121;&#117;&#110;&#46;&#99;&#111;&#109;&#47;&#100;&#121;&#115;&#109;&#115;&#46;&#104;&#116;&#109;&#35;&#47;&#100;&#111;&#109;&#101;&#115;&#116;&#105;&#99;&#47;&#116;&#101;&#120;&#116;&#47;&#116;&#101;&#109;&#112;&#108;&#97;&#116;&#101;&#32;&#26684;&#24335;&#65306;<br>&#23562;&#25964;&#30340;&#31649;&#29702;&#21592;&#65292;&#29992;&#25143;&#23545;&#36;&#123;&#116;&#105;&#116;&#108;&#101;&#125;&#30340;&#36;&#123;&#102;&#111;&#114;&#109;&#95;&#116;&#121;&#112;&#101;&#125;&#26377;&#24847;&#21521;&#65292;&#22995;&#21517;&#65306;&#36;&#123;&#110;&#97;&#109;&#101;&#125;&#65292;&#32852;&#31995;&#26041;&#24335;&#65306;&#36;&#123;&#112;&#104;&#111;&#110;&#101;&#125;');

	}else if($Config['PluginVar']['ShortMessageType'] == 2){

		showsetting('&#30701;&#20449;&#36890;&#36890;&#30693;&#27169;&#26495;', 'setting[ChanyooNotice]', $setting['ChanyooNotice'], 'textarea','','','&#33719;&#21462;&#26041;&#24335;&#65306;&#30701;&#20449;&#36890;&#21518;&#21488;-&#12299;&#27169;&#26495;&#21015;&#34920;-&#12299;&#28155;&#21152;&#27169;&#26495;
<br>&#27880;&#24847;&#65306;&#30701;&#20449;&#36890;&#21518;&#21488;&#28155;&#21152;&#27169;&#26495;&#30340;&#26102;&#65292;{title}&#65292;{form_type}&#65292;{name}&#65292;{phone}&#26356;&#25913;&#20026;{&#21464;&#37327;}<br>&#26684;&#24335;&#65306;&#23562;&#25964;&#30340;&#31649;&#29702;&#21592;&#65292;&#29992;&#25143;&#23545;{title}&#30340;{form_type}&#26377;&#24847;&#21521;&#65292;&#22995;&#21517;&#65306;{name}&#65292;&#32852;&#31995;&#26041;&#24335;&#65306;{phone}&#65292;&#12304;&#30701;&#20449;&#36890;&#30340;&#31614;&#21517;&#12305;');
	}

	echo <<<HTML
	</div>
	<!-- ����ģ������ end  -->
HTML;

	echo <<<HTML
	<!-- ��������  -->
	<div class="tab-pane" id="share" role="tabpanel" aria-expanded="false">
HTML;
	showsetting('&#20998;&#20139;&#26631;&#39064;', 'setting[WxTitle]', $setting['WxTitle'] ? $setting['WxTitle'] : '&#12304;&#39134;&#40479;&#12305;&#21516;&#22478;&#25151;&#20135;', 'text');

	showsetting('&#20998;&#20139;&#25551;&#36848;', 'setting[WxDes]', $setting['WxDes'] ? $setting['WxDes'] : '&#12304;&#39134;&#40479;&#12305;&#21516;&#22478;&#25151;&#20135;', 'textarea');

	$setting['WxImg'] = $setting['WxImg'] ? $setting['WxImg'] : '/source/plugin/fn_house/static/images/ico.png';
	$WxImgHtml = '<a href="'.$setting['WxImg'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['WxImg'].'" height="55"/></a>&#23610;&#23544;&#49;&#48;&#48;&#32;&#42;&#32;&#49;&#48;&#48;';
	showsetting('&#20998;&#20139;&#22270;&#29255;', 'new_WxImg',$setting['WxImg'], 'filetext', '', 0, $WxImgHtml);

	showsetting('&#28023;&#25253;&#20108;&#32500;&#30721;&#25991;&#23383;', 'setting[QrcodeText]', $setting['QrcodeText'] ? $setting['QrcodeText'] : '<p>&#38271;&#25353;&#35782;&#21035;&#20108;&#32500;&#30721;&#65292;&#20102;&#35299;&#26356;&#22810;</p>
<p>&#26469;&#33258;[&#39134;&#40479;&#24037;&#20316;&#23460;]</p>', 'textarea');
	
	showsetting('&#35814;&#24773;&#39029;&#20998;&#20139;&#26631;&#39064;', 'setting[ViewShareTitle]', $setting['ViewShareTitle'] ? $setting['ViewShareTitle'] : '{class}{fclass}-{title}-&#39134;&#40479;&#25151;&#20135;', 'text','','','&#123;&#116;&#105;&#116;&#108;&#101;&#125;&#20195;&#34920;&#26631;&#39064;&#65292;&#123;&#99;&#108;&#97;&#115;&#115;&#125;&#20195;&#34920;&#20998;&#31867;&#21517;&#40;&#20108;&#25163;&#25151;&#47;&#20986;&#31199;&#25151;&#47;&#21830;&#38138;&#41;&#65292;&#123;&#102;&#99;&#108;&#97;&#115;&#115;&#125;&#20195;&#34920;&#20998;&#31867;&#21103;&#21517;&#40;&#20986;&#31199;&#47;&#25972;&#31199;&#47;&#36716;&#35753;&#47;&#31561;&#41;');

	showsetting('&#27004;&#30424;&#35814;&#24773;&#20998;&#20139;&#26631;&#39064;', 'setting[ViewDiscShareTitle]', $setting['ViewDiscShareTitle'] ? $setting['ViewDiscShareTitle'] : '{title}-&#39134;&#40479;&#27004;&#30424;', 'text','','','&#123;&#116;&#105;&#116;&#108;&#101;&#125;&#20195;&#34920;&#26631;&#39064;');

	showsetting('&#27714;&#31199;&#27714;&#36141;&#20998;&#20139;&#26631;&#39064;', 'setting[DemandShareTitle]', $setting['DemandShareTitle'] ? $setting['DemandShareTitle'] : '&#27714;&#31199;&#27714;&#36141;', 'text');

	showsetting('&#27714;&#31199;&#27714;&#36141;&#20998;&#20139;&#25551;&#36848;', 'setting[DemandShareDesc]', $setting['DemandShareDesc'] ? $setting['DemandShareDesc'] : '&#27714;&#31199;&#27714;&#36141;', 'text');

	showsetting('&#20108;&#25163;&#25151;&#23548;&#20986;&#27169;&#26495;&#72;&#84;&#77;&#76;&#20195;&#30721;', 'setting[WxTemplate1]', $setting['WxTemplate1'] ? $setting['WxTemplate1'] : '<section class="_135editor" data-tools="135&#32534;&#36753;&#22120;" data-id="93807" >
    <section>
        <section style="margin-bottom: -1em;">
            <section style="width: 100%;text-align: left;" data-width="100%">
                <section style="display: inline-block;box-shadow: #9fbfdb 4px 4px 0px;border-radius:6px ;">
                    <section data-bgless="spin" data-bglessp="180" style="color:#fff;background: #006785;border-radius:6px ;padding: 4px;">
                        <section style="border-radius:6px;border: 1px dashed #fff;">
                            <section class="135brush" data-brushtype="text" style="font-size:17px;font-weight: bold; text-align: center;letter-spacing:1.5px;padding:0em 0.6em;">
                                {title}
                            </section>
                        </section>
                    </section>
                </section>
            </section>
        </section>
        <section data-bdless="spin" data-bdlessp="220" data-bdopacity="50%" style="width: 100%;border: 1px dashed #9fbfdb;border-radius:6px ;" data-width="100%">
            <section style="padding:4px;">
                <section data-bgless="spin" data-bglessp="280" data-bgopacity="50%" style="background:#cdeaff;color:#2f2f2f;border-radius:6px ;">
                    <section class="135brush" style="padding: 2em 1em 1em; letter-spacing: 1.5px; text-align: justify;">
                        <p style="font-size: 14px;">
                            &#12304;&#23567;&#21306;&#12305;{small_area}
                        </p>
    
                        <p style="font-size: 14px;">
                            &#12304;&#22320;&#22336;&#12305;{address}
                        </p>
                        <p style="font-size: 14px;">
                            &#12304;&#20215;&#26684;&#12305;{money}
                        </p>
						<p style="font-size: 14px;">
                            &#12304;&#25143;&#22411;&#12305;{huxing}
                        </p>
						<p style="font-size: 14px;">
                            &#12304;&#38754;&#31215;&#12305;{square}&#24179;&#31859;
                        </p>
						<p style="font-size: 14px;">
                            &#12304;&#26631;&#31614;&#12305;{tag}
                        </p>
						<p style="font-size: 14px;">
                            &#12304;&#25551;&#36848;&#12305;{content}
                        </p>
						<p style="font-size: 14px;">
                            &#12304;&#31216;&#21628;&#12305;{name}
                        </p>
						<p style="font-size: 14px;">
                            &#12304;&#25163;&#26426;&#12305;{mobile}
                        </p>
                        <p>
                            <span style="font-size: 14px;">&#12304;&#25552;&#37266;&#12305;<span style="color: #2f2f2f; font-size: 10px; letter-spacing: 1.5px; text-align: justify; background-color: #cdeaff; text-decoration-line: underline;">&#38271;&#25353;&#20108;&#32500;&#30721;&#35782;&#21035;&#26597;&#30475;&#25151;&#28304;&#25551;&#36848;</span></span>
                        </p>
                        <p>
                            <img src="{qr}" style="width:100px;height:100px;">
                        </p>
                    </section>
                </section>
            </section>
        </section>
    </section>
</section>','textarea','','','&#123;&#116;&#105;&#116;&#108;&#101;&#125;&#26631;&#39064;&#47;&#123;&#115;&#109;&#97;&#108;&#108;&#95;&#97;&#114;&#101;&#97;&#125;&#23567;&#21306;&#47;&#123;&#97;&#100;&#100;&#114;&#101;&#115;&#115;&#125;&#22320;&#22336;&#47;&#123;&#109;&#111;&#110;&#101;&#121;&#125;&#20215;&#26684;&#47;&#123;&#104;&#117;&#120;&#105;&#110;&#103;&#125;&#25143;&#22411;&#47;&#123;&#115;&#113;&#117;&#97;&#114;&#101;&#125;&#38754;&#31215;&#47;&#123;&#104;&#111;&#117;&#115;&#101;&#95;&#116;&#121;&#112;&#101;&#125;&#25151;&#23627;&#31867;&#22411;&#47;&#123;&#100;&#101;&#99;&#111;&#114;&#97;&#116;&#105;&#111;&#110;&#95;&#116;&#121;&#112;&#101;&#125;&#35013;&#20462;&#47;&#123;&#116;&#97;&#103;&#125;&#26631;&#31614;&#47;&#123;&#99;&#111;&#110;&#116;&#101;&#110;&#116;&#125;&#25551;&#36848;&#47;&#123;&#110;&#97;&#109;&#101;&#125;&#31216;&#21628;&#47;&#123;&#109;&#111;&#98;&#105;&#108;&#101;&#125;&#25163;&#26426;&#47;&#123;&#119;&#120;&#125;&#24494;&#20449;&#21495;&#47;&#123;&#113;&#114;&#125;&#20108;&#32500;&#30721;&#38142;&#25509;&#47;&#123;&#108;&#105;&#110;&#107;&#125;&#38142;&#25509;');

	showsetting('&#20986;&#31199;&#25151;&#23548;&#20986;&#27169;&#26495;&#72;&#84;&#77;&#76;&#20195;&#30721;', 'setting[WxTemplate2]', $setting['WxTemplate2'] ? $setting['WxTemplate2'] : '<section class="_135editor" data-tools="135&#32534;&#36753;&#22120;" data-id="93807" >
    <section>
        <section style="margin-bottom: -1em;">
            <section style="width: 100%;text-align: left;" data-width="100%">
                <section style="display: inline-block;box-shadow: #9fbfdb 4px 4px 0px;border-radius:6px ;">
                    <section data-bgless="spin" data-bglessp="180" style="color:#fff;background: #006785;border-radius:6px ;padding: 4px;">
                        <section style="border-radius:6px;border: 1px dashed #fff;">
                            <section class="135brush" data-brushtype="text" style="font-size:17px;font-weight: bold; text-align: center;letter-spacing:1.5px;padding:0em 0.6em;">
                                {title}
                            </section>
                        </section>
                    </section>
                </section>
            </section>
        </section>
        <section data-bdless="spin" data-bdlessp="220" data-bdopacity="50%" style="width: 100%;border: 1px dashed #9fbfdb;border-radius:6px ;" data-width="100%">
            <section style="padding:4px;">
                <section data-bgless="spin" data-bglessp="280" data-bgopacity="50%" style="background:#cdeaff;color:#2f2f2f;border-radius:6px ;">
                    <section class="135brush" style="padding: 2em 1em 1em; letter-spacing: 1.5px; text-align: justify;">
						<p style="font-size: 14px;">
                            &#12304;&#31867;&#22411;&#12305;{vice_class}
                        </p>
    
                        <p style="font-size: 14px;">
                            &#12304;&#23567;&#21306;&#12305;{small_area}
                        </p>
                        <p style="font-size: 14px;">
                            &#12304;&#22320;&#22336;&#12305;{address}
                        </p>
                        <p style="font-size: 14px;">
                            &#12304;&#20215;&#26684;&#12305;{money}
                        </p>
						<p style="font-size: 14px;">
                            &#12304;&#25143;&#22411;&#12305;{huxing}
                        </p>
						<p style="font-size: 14px;">
                            &#12304;&#38754;&#31215;&#12305;{square}&#24179;&#31859;
                        </p>
						<p style="font-size: 14px;">
                            &#12304;&#37197;&#32622;&#12305;{configure}
                        </p>
						<p style="font-size: 14px;">
                            &#12304;&#26631;&#31614;&#12305;{tag}
                        </p>
						<p style="font-size: 14px;">
                            &#12304;&#25551;&#36848;&#12305;{content}
                        </p>
						<p style="font-size: 14px;">
                            &#12304;&#31216;&#21628;&#12305;{name}
                        </p>
						<p style="font-size: 14px;">
                            &#12304;&#25163;&#26426;&#12305;{mobile}
                        </p>
                        <p>
                            <span style="font-size: 14px;">&#12304;&#25552;&#37266;&#12305;<span style="color: #2f2f2f; font-size: 10px; letter-spacing: 1.5px; text-align: justify; background-color: #cdeaff; text-decoration-line: underline;">&#38271;&#25353;&#20108;&#32500;&#30721;&#35782;&#21035;&#26597;&#30475;&#25151;&#28304;&#25551;&#36848;</span></span>
                        </p>
                        <p>
                            <img src="{qr}" style="width:100px;height:100px;">
                        </p>
                    </section>
                </section>
            </section>
        </section>
    </section>
</section>','textarea','','','&#123;&#116;&#105;&#116;&#108;&#101;&#125;&#26631;&#39064;&#47;&#123;&#118;&#105;&#99;&#101;&#95;&#99;&#108;&#97;&#115;&#115;&#125;&#31867;&#22411;&#47;&#123;&#115;&#109;&#97;&#108;&#108;&#95;&#97;&#114;&#101;&#97;&#125;&#23567;&#21306;&#47;&#123;&#97;&#100;&#100;&#114;&#101;&#115;&#115;&#125;&#22320;&#22336;&#47;&#123;&#109;&#111;&#110;&#101;&#121;&#125;&#20215;&#26684;&#47;&#123;&#104;&#117;&#120;&#105;&#110;&#103;&#125;&#25143;&#22411;&#47;&#123;&#115;&#113;&#117;&#97;&#114;&#101;&#125;&#38754;&#31215;&#47;&#123;&#104;&#111;&#117;&#115;&#101;&#95;&#116;&#121;&#112;&#101;&#125;&#25151;&#23627;&#31867;&#22411;&#47;&#123;&#100;&#101;&#99;&#111;&#114;&#97;&#116;&#105;&#111;&#110;&#95;&#116;&#121;&#112;&#101;&#125;&#35013;&#20462;&#47;&#123;&#116;&#97;&#103;&#125;&#26631;&#31614;&#47;&#123;&#99;&#111;&#110;&#116;&#101;&#110;&#116;&#125;&#25551;&#36848;&#47;&#123;&#99;&#111;&#110;&#102;&#105;&#103;&#117;&#114;&#101;&#125;&#37197;&#32622;&#47;&#123;&#110;&#97;&#109;&#101;&#125;&#31216;&#21628;&#47;&#123;&#109;&#111;&#98;&#105;&#108;&#101;&#125;&#25163;&#26426;&#47;&#123;&#119;&#120;&#125;&#24494;&#20449;&#21495;&#47;&#123;&#113;&#114;&#125;&#20108;&#32500;&#30721;&#47;&#123;&#108;&#105;&#110;&#107;&#125;&#38142;&#25509;');

	showsetting('&#21830;&#38138;&#23548;&#20986;&#27169;&#26495;&#72;&#84;&#77;&#76;&#20195;&#30721;', 'setting[WxTemplate3]', $setting['WxTemplate3'] ? $setting['WxTemplate3'] : '<section class="_135editor" data-tools="135&#32534;&#36753;&#22120;" data-id="93807" >
    <section>
        <section style="margin-bottom: -1em;">
            <section style="width: 100%;text-align: left;" data-width="100%">
                <section style="display: inline-block;box-shadow: #9fbfdb 4px 4px 0px;border-radius:6px ;">
                    <section data-bgless="spin" data-bglessp="180" style="color:#fff;background: #006785;border-radius:6px ;padding: 4px;">
                        <section style="border-radius:6px;border: 1px dashed #fff;">
                            <section class="135brush" data-brushtype="text" style="font-size:17px;font-weight: bold; text-align: center;letter-spacing:1.5px;padding:0em 0.6em;">
                                {title}
                            </section>
                        </section>
                    </section>
                </section>
            </section>
        </section>
        <section data-bdless="spin" data-bdlessp="220" data-bdopacity="50%" style="width: 100%;border: 1px dashed #9fbfdb;border-radius:6px ;" data-width="100%">
            <section style="padding:4px;">
                <section data-bgless="spin" data-bglessp="280" data-bgopacity="50%" style="background:#cdeaff;color:#2f2f2f;border-radius:6px ;">
                    <section class="135brush" style="padding: 2em 1em 1em; letter-spacing: 1.5px; text-align: justify;">
						<p style="font-size: 14px;">
                            &#12304;&#31867;&#22411;&#12305;{vice_class}
                        </p>
  
                        <p style="font-size: 14px;">
                            &#12304;&#22320;&#22336;&#12305;{address}
                        </p>
                        <p style="font-size: 14px;">
                            &#12304;&#20215;&#26684;&#12305;{money}
                        </p>
						<p style="font-size: 14px;">
                            &#12304;&#32463;&#33829;&#31867;&#22411;&#12305;{management_type}
                        </p>
						<p style="font-size: 14px;">
                            &#12304;&#21830;&#38138;&#31867;&#22411;&#12305;{shops_type}
                        </p>
						<p style="font-size: 14px;">
                            &#12304;&#38754;&#31215;&#12305;{square}&#24179;&#31859;
                        </p>
						<p style="font-size: 14px;">
                            &#12304;&#26631;&#31614;&#12305;{tag}
                        </p>
						<p style="font-size: 14px;">
                            &#12304;&#25551;&#36848;&#12305;{content}
                        </p>
						<p style="font-size: 14px;">
                            &#12304;&#31216;&#21628;&#12305;{name}
                        </p>
						<p style="font-size: 14px;">
                            &#12304;&#25163;&#26426;&#12305;{mobile}
                        </p>
                        <p>
                            <span style="font-size: 14px;">&#12304;&#25552;&#37266;&#12305;<span style="color: #2f2f2f; font-size: 10px; letter-spacing: 1.5px; text-align: justify; background-color: #cdeaff; text-decoration-line: underline;">&#38271;&#25353;&#20108;&#32500;&#30721;&#35782;&#21035;&#26597;&#30475;&#25151;&#28304;&#25551;&#36848;</span></span>
                        </p>
                        <p>
                            <img src="{qr}" style="width:100px;height:100px;">
                        </p>
                    </section>
                </section>
            </section>
        </section>
    </section>
</section>','textarea','','','&#123;&#116;&#105;&#116;&#108;&#101;&#125;&#26631;&#39064;&#47;&#123;&#118;&#105;&#99;&#101;&#95;&#99;&#108;&#97;&#115;&#115;&#125;&#31867;&#22411;&#47;&#123;&#115;&#109;&#97;&#108;&#108;&#95;&#97;&#114;&#101;&#97;&#125;&#22320;&#21517;&#47;&#123;&#97;&#100;&#100;&#114;&#101;&#115;&#115;&#125;&#22320;&#22336;&#47;&#123;&#109;&#111;&#110;&#101;&#121;&#125;&#20215;&#26684;&#47;&#123;&#115;&#113;&#117;&#97;&#114;&#101;&#125;&#38754;&#31215;&#47;&#123;&#109;&#97;&#110;&#97;&#103;&#101;&#109;&#101;&#110;&#116;&#95;&#116;&#121;&#112;&#101;&#125;&#32463;&#33829;&#31867;&#22411;&#47;&#123;&#115;&#104;&#111;&#112;&#115;&#95;&#116;&#121;&#112;&#101;&#125;&#21830;&#38138;&#31867;&#22411;&#47;&#123;&#116;&#97;&#103;&#125;&#26631;&#31614;&#47;&#123;&#99;&#111;&#110;&#116;&#101;&#110;&#116;&#125;&#25551;&#36848;&#47;&#123;&#110;&#97;&#109;&#101;&#125;&#31216;&#21628;&#47;&#123;&#109;&#111;&#98;&#105;&#108;&#101;&#125;&#25163;&#26426;&#47;&#123;&#119;&#120;&#125;&#24494;&#20449;&#21495;&#47;&#123;&#113;&#114;&#125;&#20108;&#32500;&#30721;&#47;&#123;&#108;&#105;&#110;&#107;&#125;&#38142;&#25509;');

	showsetting('&#21378;&#25151;&#23548;&#20986;&#27169;&#26495;&#72;&#84;&#77;&#76;&#20195;&#30721;', 'setting[WxTemplate4]', $setting['WxTemplate4'] ? $setting['WxTemplate4'] : '<section class="_135editor" data-tools="135&#32534;&#36753;&#22120;" data-id="93807" >
    <section>
        <section style="margin-bottom: -1em;">
            <section style="width: 100%;text-align: left;" data-width="100%">
                <section style="display: inline-block;box-shadow: #9fbfdb 4px 4px 0px;border-radius:6px ;">
                    <section data-bgless="spin" data-bglessp="180" style="color:#fff;background: #006785;border-radius:6px ;padding: 4px;">
                        <section style="border-radius:6px;border: 1px dashed #fff;">
                            <section class="135brush" data-brushtype="text" style="font-size:17px;font-weight: bold; text-align: center;letter-spacing:1.5px;padding:0em 0.6em;">
                                {title}
                            </section>
                        </section>
                    </section>
                </section>
            </section>
        </section>
        <section data-bdless="spin" data-bdlessp="220" data-bdopacity="50%" style="width: 100%;border: 1px dashed #9fbfdb;border-radius:6px ;" data-width="100%">
            <section style="padding:4px;">
                <section data-bgless="spin" data-bglessp="280" data-bgopacity="50%" style="background:#cdeaff;color:#2f2f2f;border-radius:6px ;">
                    <section class="135brush" style="padding: 2em 1em 1em; letter-spacing: 1.5px; text-align: justify;">
						<p style="font-size: 14px;">
                            &#12304;&#31867;&#22411;&#12305;{vice_class}
                        </p>
                        <p style="font-size: 14px;">
                            &#12304;&#22320;&#22336;&#12305;{address}
                        </p>
                        <p style="font-size: 14px;">
                            &#12304;&#20215;&#26684;&#12305;{money}
                        </p>
						<p style="font-size: 14px;">
                            &#12304;&#38754;&#31215;&#12305;{square}&#24179;&#31859;
                        </p>
						<p style="font-size: 14px;">
                            &#12304;&#26631;&#31614;&#12305;{tag}
                        </p>
						<p style="font-size: 14px;">
                            &#12304;&#25551;&#36848;&#12305;{content}
                        </p>
						<p style="font-size: 14px;">
                            &#12304;&#31216;&#21628;&#12305;{name}
                        </p>
						<p style="font-size: 14px;">
                            &#12304;&#25163;&#26426;&#12305;{mobile}
                        </p>
                        <p>
                            <span style="font-size: 14px;">&#12304;&#25552;&#37266;&#12305;<span style="color: #2f2f2f; font-size: 10px; letter-spacing: 1.5px; text-align: justify; background-color: #cdeaff; text-decoration-line: underline;">&#38271;&#25353;&#20108;&#32500;&#30721;&#35782;&#21035;&#26597;&#30475;&#25151;&#28304;&#25551;&#36848;</span></span>
                        </p>
                        <p>
                            <img src="{qr}" style="width:100px;height:100px;">
                        </p>
                    </section>
                </section>
            </section>
        </section>
    </section>
</section>','textarea','','','&#123;&#116;&#105;&#116;&#108;&#101;&#125;&#26631;&#39064;&#47;&#123;&#118;&#105;&#99;&#101;&#95;&#99;&#108;&#97;&#115;&#115;&#125;&#31867;&#22411;&#47;&#123;&#115;&#109;&#97;&#108;&#108;&#95;&#97;&#114;&#101;&#97;&#125;&#22320;&#21517;&#47;&#123;&#97;&#100;&#100;&#114;&#101;&#115;&#115;&#125;&#22320;&#22336;&#47;&#123;&#109;&#111;&#110;&#101;&#121;&#125;&#20215;&#26684;&#47;&#123;&#115;&#113;&#117;&#97;&#114;&#101;&#125;&#38754;&#31215;&#47;&#123;&#116;&#97;&#103;&#125;&#26631;&#31614;&#47;&#123;&#99;&#111;&#110;&#116;&#101;&#110;&#116;&#125;&#25551;&#36848;&#47;&#123;&#110;&#97;&#109;&#101;&#125;&#31216;&#21628;&#47;&#123;&#109;&#111;&#98;&#105;&#108;&#101;&#125;&#25163;&#26426;&#47;&#123;&#119;&#120;&#125;&#24494;&#20449;&#21495;&#47;&#123;&#113;&#114;&#125;&#20108;&#32500;&#30721;&#47;&#123;&#108;&#105;&#110;&#107;&#125;&#38142;&#25509;');

	showsetting('&#20889;&#23383;&#27004;&#23548;&#20986;&#27169;&#26495;&#72;&#84;&#77;&#76;&#20195;&#30721;', 'setting[WxTemplate5]', $setting['WxTemplate5'] ? $setting['WxTemplate5'] : '<section class="_135editor" data-tools="135&#32534;&#36753;&#22120;" data-id="93807" >
    <section>
        <section style="margin-bottom: -1em;">
            <section style="width: 100%;text-align: left;" data-width="100%">
                <section style="display: inline-block;box-shadow: #9fbfdb 4px 4px 0px;border-radius:6px ;">
                    <section data-bgless="spin" data-bglessp="180" style="color:#fff;background: #006785;border-radius:6px ;padding: 4px;">
                        <section style="border-radius:6px;border: 1px dashed #fff;">
                            <section class="135brush" data-brushtype="text" style="font-size:17px;font-weight: bold; text-align: center;letter-spacing:1.5px;padding:0em 0.6em;">
                                {title}
                            </section>
                        </section>
                    </section>
                </section>
            </section>
        </section>
        <section data-bdless="spin" data-bdlessp="220" data-bdopacity="50%" style="width: 100%;border: 1px dashed #9fbfdb;border-radius:6px ;" data-width="100%">
            <section style="padding:4px;">
                <section data-bgless="spin" data-bglessp="280" data-bgopacity="50%" style="background:#cdeaff;color:#2f2f2f;border-radius:6px ;">
                    <section class="135brush" style="padding: 2em 1em 1em; letter-spacing: 1.5px; text-align: justify;">
						<p style="font-size: 14px;">
                            &#12304;&#31867;&#22411;&#12305;{vice_class}
                        </p>
                        <p style="font-size: 14px;">
                            &#12304;&#22320;&#22336;&#12305;{address}
                        </p>
                        <p style="font-size: 14px;">
                            &#12304;&#20215;&#26684;&#12305;{money}
                        </p>
						<p style="font-size: 14px;">
                            &#12304;&#38754;&#31215;&#12305;{square}&#24179;&#31859;
                        </p>
						<p style="font-size: 14px;">
                            &#12304;&#26631;&#31614;&#12305;{tag}
                        </p>
						<p style="font-size: 14px;">
                            &#12304;&#25551;&#36848;&#12305;{content}
                        </p>
						<p style="font-size: 14px;">
                            &#12304;&#31216;&#21628;&#12305;{name}
                        </p>
						<p style="font-size: 14px;">
                            &#12304;&#25163;&#26426;&#12305;{mobile}
                        </p>
                        <p>
                            <span style="font-size: 14px;">&#12304;&#25552;&#37266;&#12305;<span style="color: #2f2f2f; font-size: 10px; letter-spacing: 1.5px; text-align: justify; background-color: #cdeaff; text-decoration-line: underline;">&#38271;&#25353;&#20108;&#32500;&#30721;&#35782;&#21035;&#26597;&#30475;&#25151;&#28304;&#25551;&#36848;</span></span>
                        </p>
                        <p>
                            <img src="{qr}" style="width:100px;height:100px;">
                        </p>
                    </section>
                </section>
            </section>
        </section>
    </section>
</section>','textarea','','','&#123;&#116;&#105;&#116;&#108;&#101;&#125;&#26631;&#39064;&#47;&#123;&#118;&#105;&#99;&#101;&#95;&#99;&#108;&#97;&#115;&#115;&#125;&#31867;&#22411;&#47;&#123;&#115;&#109;&#97;&#108;&#108;&#95;&#97;&#114;&#101;&#97;&#125;&#22320;&#21517;&#47;&#123;&#97;&#100;&#100;&#114;&#101;&#115;&#115;&#125;&#22320;&#22336;&#47;&#123;&#109;&#111;&#110;&#101;&#121;&#125;&#20215;&#26684;&#47;&#123;&#115;&#113;&#117;&#97;&#114;&#101;&#125;&#38754;&#31215;&#47;&#123;&#116;&#97;&#103;&#125;&#26631;&#31614;&#47;&#123;&#99;&#111;&#110;&#116;&#101;&#110;&#116;&#125;&#25551;&#36848;&#47;&#123;&#110;&#97;&#109;&#101;&#125;&#31216;&#21628;&#47;&#123;&#109;&#111;&#98;&#105;&#108;&#101;&#125;&#25163;&#26426;&#47;&#123;&#119;&#120;&#125;&#24494;&#20449;&#21495;&#47;&#123;&#113;&#114;&#125;&#20108;&#32500;&#30721;&#47;&#123;&#108;&#105;&#110;&#107;&#125;&#38142;&#25509;');

	showsetting('&#20179;&#24211;&#23548;&#20986;&#27169;&#26495;&#72;&#84;&#77;&#76;&#20195;&#30721;', 'setting[WxTemplate6]', $setting['WxTemplate6'] ? $setting['WxTemplate6'] : '<section class="_135editor" data-tools="135&#32534;&#36753;&#22120;" data-id="93807" >
    <section>
        <section style="margin-bottom: -1em;">
            <section style="width: 100%;text-align: left;" data-width="100%">
                <section style="display: inline-block;box-shadow: #9fbfdb 4px 4px 0px;border-radius:6px ;">
                    <section data-bgless="spin" data-bglessp="180" style="color:#fff;background: #006785;border-radius:6px ;padding: 4px;">
                        <section style="border-radius:6px;border: 1px dashed #fff;">
                            <section class="135brush" data-brushtype="text" style="font-size:17px;font-weight: bold; text-align: center;letter-spacing:1.5px;padding:0em 0.6em;">
                                {title}
                            </section>
                        </section>
                    </section>
                </section>
            </section>
        </section>
        <section data-bdless="spin" data-bdlessp="220" data-bdopacity="50%" style="width: 100%;border: 1px dashed #9fbfdb;border-radius:6px ;" data-width="100%">
            <section style="padding:4px;">
                <section data-bgless="spin" data-bglessp="280" data-bgopacity="50%" style="background:#cdeaff;color:#2f2f2f;border-radius:6px ;">
                    <section class="135brush" style="padding: 2em 1em 1em; letter-spacing: 1.5px; text-align: justify;">
						<p style="font-size: 14px;">
                            &#12304;&#31867;&#22411;&#12305;{vice_class}
                        </p>
                        <p style="font-size: 14px;">
                            &#12304;&#22320;&#22336;&#12305;{address}
                        </p>
                        <p style="font-size: 14px;">
                            &#12304;&#20215;&#26684;&#12305;{money}
                        </p>
						<p style="font-size: 14px;">
                            &#12304;&#38754;&#31215;&#12305;{square}&#24179;&#31859;
                        </p>
						<p style="font-size: 14px;">
                            &#12304;&#26631;&#31614;&#12305;{tag}
                        </p>
						<p style="font-size: 14px;">
                            &#12304;&#25551;&#36848;&#12305;{content}
                        </p>
						<p style="font-size: 14px;">
                            &#12304;&#31216;&#21628;&#12305;{name}
                        </p>
						<p style="font-size: 14px;">
                            &#12304;&#25163;&#26426;&#12305;{mobile}
                        </p>
                        <p>
                            <span style="font-size: 14px;">&#12304;&#25552;&#37266;&#12305;<span style="color: #2f2f2f; font-size: 10px; letter-spacing: 1.5px; text-align: justify; background-color: #cdeaff; text-decoration-line: underline;">&#38271;&#25353;&#20108;&#32500;&#30721;&#35782;&#21035;&#26597;&#30475;&#25151;&#28304;&#25551;&#36848;</span></span>
                        </p>
                        <p>
                            <img src="{qr}" style="width:100px;height:100px;">
                        </p>
                    </section>
                </section>
            </section>
        </section>
    </section>
</section>','textarea','','','&#123;&#116;&#105;&#116;&#108;&#101;&#125;&#26631;&#39064;&#47;&#123;&#118;&#105;&#99;&#101;&#95;&#99;&#108;&#97;&#115;&#115;&#125;&#31867;&#22411;&#47;&#123;&#115;&#109;&#97;&#108;&#108;&#95;&#97;&#114;&#101;&#97;&#125;&#22320;&#21517;&#47;&#123;&#97;&#100;&#100;&#114;&#101;&#115;&#115;&#125;&#22320;&#22336;&#47;&#123;&#109;&#111;&#110;&#101;&#121;&#125;&#20215;&#26684;&#47;&#123;&#115;&#113;&#117;&#97;&#114;&#101;&#125;&#38754;&#31215;&#47;&#123;&#116;&#97;&#103;&#125;&#26631;&#31614;&#47;&#123;&#99;&#111;&#110;&#116;&#101;&#110;&#116;&#125;&#25551;&#36848;&#47;&#123;&#110;&#97;&#109;&#101;&#125;&#31216;&#21628;&#47;&#123;&#109;&#111;&#98;&#105;&#108;&#101;&#125;&#25163;&#26426;&#47;&#123;&#119;&#120;&#125;&#24494;&#20449;&#21495;&#47;&#123;&#113;&#114;&#125;&#20108;&#32500;&#30721;&#47;&#123;&#108;&#105;&#110;&#107;&#125;&#38142;&#25509;');

	showsetting('&#22303;&#22320;&#23548;&#20986;&#27169;&#26495;&#72;&#84;&#77;&#76;&#20195;&#30721;', 'setting[WxTemplate7]', $setting['WxTemplate7'] ? $setting['WxTemplate7'] : '<section class="_135editor" data-tools="135&#32534;&#36753;&#22120;" data-id="93807" >
    <section>
        <section style="margin-bottom: -1em;">
            <section style="width: 100%;text-align: left;" data-width="100%">
                <section style="display: inline-block;box-shadow: #9fbfdb 4px 4px 0px;border-radius:6px ;">
                    <section data-bgless="spin" data-bglessp="180" style="color:#fff;background: #006785;border-radius:6px ;padding: 4px;">
                        <section style="border-radius:6px;border: 1px dashed #fff;">
                            <section class="135brush" data-brushtype="text" style="font-size:17px;font-weight: bold; text-align: center;letter-spacing:1.5px;padding:0em 0.6em;">
                                {title}
                            </section>
                        </section>
                    </section>
                </section>
            </section>
        </section>
        <section data-bdless="spin" data-bdlessp="220" data-bdopacity="50%" style="width: 100%;border: 1px dashed #9fbfdb;border-radius:6px ;" data-width="100%">
            <section style="padding:4px;">
                <section data-bgless="spin" data-bglessp="280" data-bgopacity="50%" style="background:#cdeaff;color:#2f2f2f;border-radius:6px ;">
                    <section class="135brush" style="padding: 2em 1em 1em; letter-spacing: 1.5px; text-align: justify;">
						<p style="font-size: 14px;">
                            &#12304;&#31867;&#22411;&#12305;{vice_class}
                        </p>
                        <p style="font-size: 14px;">
                            &#12304;&#22320;&#22336;&#12305;{address}
                        </p>
                        <p style="font-size: 14px;">
                            &#12304;&#20215;&#26684;&#12305;{money}
                        </p>
						<p style="font-size: 14px;">
                            &#12304;&#38754;&#31215;&#12305;{square}&#24179;&#31859;
                        </p>
						<p style="font-size: 14px;">
                            &#12304;&#26631;&#31614;&#12305;{tag}
                        </p>
						<p style="font-size: 14px;">
                            &#12304;&#25551;&#36848;&#12305;{content}
                        </p>
						<p style="font-size: 14px;">
                            &#12304;&#31216;&#21628;&#12305;{name}
                        </p>
						<p style="font-size: 14px;">
                            &#12304;&#25163;&#26426;&#12305;{mobile}
                        </p>
                        <p>
                            <span style="font-size: 14px;">&#12304;&#25552;&#37266;&#12305;<span style="color: #2f2f2f; font-size: 10px; letter-spacing: 1.5px; text-align: justify; background-color: #cdeaff; text-decoration-line: underline;">&#38271;&#25353;&#20108;&#32500;&#30721;&#35782;&#21035;&#26597;&#30475;&#25151;&#28304;&#25551;&#36848;</span></span>
                        </p>
                        <p>
                            <img src="{qr}" style="width:100px;height:100px;">
                        </p>
                    </section>
                </section>
            </section>
        </section>
    </section>
</section>','textarea','','','&#123;&#116;&#105;&#116;&#108;&#101;&#125;&#26631;&#39064;&#47;&#123;&#118;&#105;&#99;&#101;&#95;&#99;&#108;&#97;&#115;&#115;&#125;&#31867;&#22411;&#47;&#123;&#115;&#109;&#97;&#108;&#108;&#95;&#97;&#114;&#101;&#97;&#125;&#22320;&#21517;&#47;&#123;&#97;&#100;&#100;&#114;&#101;&#115;&#115;&#125;&#22320;&#22336;&#47;&#123;&#109;&#111;&#110;&#101;&#121;&#125;&#20215;&#26684;&#47;&#123;&#115;&#113;&#117;&#97;&#114;&#101;&#125;&#38754;&#31215;&#47;&#123;&#116;&#97;&#103;&#125;&#26631;&#31614;&#47;&#123;&#99;&#111;&#110;&#116;&#101;&#110;&#116;&#125;&#25551;&#36848;&#47;&#123;&#110;&#97;&#109;&#101;&#125;&#31216;&#21628;&#47;&#123;&#109;&#111;&#98;&#105;&#108;&#101;&#125;&#25163;&#26426;&#47;&#123;&#119;&#120;&#125;&#24494;&#20449;&#21495;&#47;&#123;&#113;&#114;&#125;&#20108;&#32500;&#30721;&#47;&#123;&#108;&#105;&#110;&#107;&#125;&#38142;&#25509;');

	showsetting('&#25151;&#28304;&#23548;&#20986;&#27169;&#26495;&#31579;&#36873;&#26102;&#38388;',array('setting[WxTemplateSort]', array(
		array('updateline','&#26356;&#26032;&#26102;&#38388;'),
		array('dateline','&#21457;&#24067;&#26102;&#38388;'),
	), TRUE),$setting['WxTemplateSort'] ? $setting['WxTemplateSort'] : 'updateline', 'mradio');


	echo <<<HTML
	</div>
	<!-- �������� end  -->
HTML;

	echo <<<HTML
	<!-- ��ɫ����  -->
	<div class="tab-pane" id="color" role="tabpanel" aria-expanded="false">
HTML;

	showsetting('&#20027;&#39064;&#39068;&#33394;', 'setting[Color]', $setting['Color'] ? $setting['Color'] : '#5cc55c', 'color');

	showsetting('&#21103;&#20027;&#39064;&#39068;&#33394;', 'setting[FColor]', $setting['FColor'] ? $setting['FColor'] : '#f74c31', 'color');

	showsetting('&#21103;&#20027;&#39064;&#39068;&#33394;2', 'setting[FFColor]', $setting['FFColor'] ? $setting['FFColor'] : '#3ba1ff', 'color');

	showsetting('&#21103;&#20027;&#39064;&#39068;&#33394;3', 'setting[FFFColor]', $setting['FFFColor'] ? $setting['FFFColor'] : '#ffc502', 'color');

	showsetting('&#21103;&#20027;&#39064;&#39068;&#33394;4;', 'setting[FFFFColor]', $setting['FFFFColor'] ? $setting['FFFFColor'] : '#68a6d5', 'color');

	showsetting('&#21103;&#20027;&#39064;&#39068;&#33394;5;', 'setting[FFFFFColor]', $setting['FFFFFColor'] ? $setting['FFFFFColor'] : '#fb9031', 'color');

	showsetting('&#28176;&#21464;&#20027;&#39064;&#39068;&#33394;&#49;&#45;&#48;', 'setting[ChangeColor1_0]', $setting['ChangeColor1_0'] ? $setting['ChangeColor1_0'] : '#f9b958', 'color');

	showsetting('&#28176;&#21464;&#20027;&#39064;&#39068;&#33394;&#49;&#45;&#49;', 'setting[ChangeColor1_1]', $setting['ChangeColor1_1'] ? $setting['ChangeColor1_1'] : '#fe9102', 'color');

	showsetting('&#28176;&#21464;&#20027;&#39064;&#39068;&#33394;&#50;&#45;&#48;', 'setting[ChangeColor2_0]', $setting['ChangeColor2_0'] ? $setting['ChangeColor2_0'] : '#20ba7a', 'color');

	showsetting('&#28176;&#21464;&#20027;&#39064;&#39068;&#33394;&#50;&#45;&#49;', 'setting[ChangeColor2_1]', $setting['ChangeColor2_1'] ? $setting['ChangeColor2_1'] : '#6ee4b2', 'color');

	showsetting('&#28176;&#21464;&#20027;&#39064;&#39068;&#33394;&#51;&#45;&#48;', 'setting[ChangeColor3_0]', $setting['ChangeColor3_0'] ? $setting['ChangeColor3_0'] : '#4081dd', 'color');

	showsetting('&#28176;&#21464;&#20027;&#39064;&#39068;&#33394;&#51;&#45;&#49;', 'setting[ChangeColor3_1]', $setting['ChangeColor3_1'] ? $setting['ChangeColor3_1'] : '#399dfd', 'color');

	showsetting('&#28176;&#21464;&#20027;&#39064;&#39068;&#33394;&#52;&#45;&#48;', 'setting[ChangeColor4_0]', $setting['ChangeColor4_0'] ? $setting['ChangeColor4_0'] : '#50df4f', 'color');

	showsetting('&#28176;&#21464;&#20027;&#39064;&#39068;&#33394;&#52;&#45;&#49;', 'setting[ChangeColor4_1]', $setting['ChangeColor4_1'] ? $setting['ChangeColor4_1'] : '#50df4f', 'color');

	showsetting('&#28176;&#21464;&#20027;&#39064;&#39068;&#33394;&#53;&#45;&#48;', 'setting[ChangeColor5_0]', $setting['ChangeColor5_0'] ? $setting['ChangeColor5_0'] : '#fa898d', 'color');

	showsetting('&#28176;&#21464;&#20027;&#39064;&#39068;&#33394;&#53;&#45;&#49;', 'setting[ChangeColor5_1]', $setting['ChangeColor5_1'] ? $setting['ChangeColor5_1'] : '#f25568', 'color');

	echo <<<HTML
	</div>
	<!-- ��ɫ���� end  -->
HTML;
	
	if(in_array($Config['PluginVar']['AppType'],array('1','2','3'))){

	echo <<<HTML
	<!-- APP����  -->
	<div class="tab-pane" id="app" role="tabpanel" aria-expanded="false">
HTML;
	
	showsetting('&#65;&#80;&#80;&#25165;&#21487;&#20030;&#25253;',array('setting[AppReportSwitch]', array(
		array('1','&#26159;', array('AppReportSwitch_1' => '')),
		array('0','&#21542;', array('AppReportSwitch_1' => 'none')),
	), TRUE),$setting['AppReportSwitch'], 'mradio','','','&#26159;&#21542;&#65;&#80;&#80;&#25165;&#21487;&#20030;&#25253;&#25151;&#28304;');
	showtagheader('div', 'AppReportSwitch_1', $setting['AppReportSwitch'] ? true : '','sub');
		showsetting('&#65;&#80;&#80;&#20030;&#25253;&#25552;&#31034;&#35821;', 'setting[AppReportTips]', $setting['AppReportTips'] ? $setting['AppReportTips'] : '&#20030;&#25253;&#21482;&#33021;&#22312;&#65;&#80;&#80;&#20030;&#25253;&#21734;<br>&#28857;&#20987;&#30830;&#23450;&#19979;&#36733;&#65;&#80;&#80;', 'text');
	showtagfooter('div');

	showsetting('&#65;&#80;&#80;&#26597;&#30475;&#32852;&#31995;&#26041;&#24335;', 'setting[AppContactSwitch]', $setting['AppContactSwitch'],'radio','','','&#26159;&#21542;&#65;&#80;&#80;&#25165;&#21487;&#26597;&#30475;&#32852;&#31995;&#26041;&#24335;');

	showsetting('&#65;&#80;&#80;&#22312;&#32447;&#32842;&#22825;', 'setting[AppChatSwitch]', $setting['AppChatSwitch'],'radio','','','&#65;&#80;&#80;&#20869;&#21457;&#20449;&#24687;&#47;&#28155;&#21152;&#24494;&#20449;&#26159;&#21542;&#26367;&#25442;&#25104;&#65;&#112;&#112;&#22312;&#32447;&#32842;&#22825;');

	showsetting('&#65;&#80;&#80;&#23458;&#26381;&#117;&#105;&#100;', 'setting[AppOnlineUid]', $setting['AppOnlineUid'], 'text');

	showsetting('&#65;&#80;&#80;&#23458;&#26381;&#21517;&#23383;', 'setting[AppOnlineName]', $setting['AppOnlineName'], 'text');

	showsetting('&#65;&#80;&#80;&#23458;&#26381;&#24494;&#20449;&#21495;', 'setting[AppOnlineWx]', $setting['AppOnlineWx'], 'text','','','&#19981;&#22635;&#21017;&#19981;&#24320;&#21551;');
	
	if(in_array($Config['PluginVar']['AppType'],array('2','3'))){
		$AppOnlineFaceHtml = $setting['AppOnlineFace'] ? '<a href="'.$setting['AppOnlineFace'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$setting['AppOnlineFace'].'" height="55"/></a>' : '';
		showsetting('&#65;&#80;&#80;&#23458;&#26381;&#22836;&#20687;', 'new_AppOnlineFace',$setting['AppOnlineFace'], 'filetext', '', 0, $AppOnlineFaceHtml);
	}

	showtagheader('div', 'mag_app_table', $Config['PluginVar']['AppType'] == 1 ? true : '','mag_app_table');
		showsetting('&#39532;&#30002;&#83;&#101;&#99;&#114;&#101;&#116;', 'setting[MagSecret]', $setting['MagSecret'], 'text','','','&#19981;&#22635;&#21017;&#32487;&#25215;&#12304;&#20840;&#23616;&#35774;&#32622;&#12305;&#30340;&#35774;&#32622;');
		showsetting('&#39532;&#30002;&#21161;&#25163;&#83;&#101;&#99;&#114;&#101;&#116;', 'setting[MagAssistantSecret]', $setting['MagAssistantSecret'], 'text','','','&#19981;&#22635;&#21017;&#32487;&#25215;&#12304;&#20840;&#23616;&#35774;&#32622;&#12305;&#30340;&#35774;&#32622;');
		showsetting('&#39532;&#30002;&#21161;&#25163;&#25512;&#36865;', 'setting[MagAssistantPush]', $setting['MagAssistantPush'], 'radio','','','&#19981;&#22635;&#21017;&#32487;&#25215;&#12304;&#20840;&#23616;&#35774;&#32622;&#12305;&#30340;&#35774;&#32622;');
	showtagfooter('div');
	
	showtagheader('div', 'qf_app_table', $Config['PluginVar']['AppType'] == 2 ? true : '','qf_app_table');
		showsetting('&#21315;&#24070;&#25903;&#20184;&#35746;&#21333;&#31867;&#22411;&#73;&#68;', 'setting[qf_type]', $setting['qf_type'], 'text','','','&#19981;&#22635;&#21017;&#32487;&#25215;&#12304;&#20840;&#23616;&#35774;&#32622;&#12305;&#30340;&#35774;&#32622;');
		showsetting('&#21315;&#24070;&#26381;&#21153;&#21495;&#29992;&#25143;&#73;&#68;', 'setting[qf_from_id]', $setting['qf_from_id'], 'text','','','&#19981;&#22635;&#21017;&#32487;&#25215;&#12304;&#20840;&#23616;&#35774;&#32622;&#12305;&#30340;&#35774;&#32622;');
	showtagfooter('div');

	echo <<<HTML
	</div>
	<!-- APP���� end  -->
HTML;
	}

	showsubmit('DetailSubmit', '&#20445;&#23384;&#37197;&#32622;');
	showtagfooter('div');
	showtagfooter('div');
	showformfooter(); /*Dism_taobao-com*/
	showtagfooter('div');
	
	$setting['banners'] = $common_setting ? $setting['banners'] : array(
		array('img'=>'/source/plugin/fn_house/static/images/banner1.jpg'),
		array('img'=>'/source/plugin/fn_house/static/images/banner2.jpg')
	);
	if($setting['banners']){
		foreach($setting['banners'] as $Key => $Val) {
			$banners_js_array[] = '"'.$Val['img'].'|'.$setting['banners'][$Key]['title'].'|'.$setting['banners'][$Key]['link'].'"';
		}
		$UpLoadHtml .= '
		var InputArray = new Array('.implode(',',$banners_js_array).');
		$("#Banners").AppUpload({InputName:"new_banners",InputLink:true,InputExist:true,InputArray:InputArray,Move:true});';
	}else{
		$UpLoadHtml .= '$("#Banners").AppUpload({InputName:"new_banners",InputLink:true,Move:true});';
	}

	if($setting['view_ad_1']){
		foreach($setting['view_ad_1'] as $Key => $Val) {
			$view_ad_1_js_array[] = '"'.$Val['img'].'|'.$setting['view_ad_1'][$Key]['title'].'|'.$setting['view_ad_1'][$Key]['link'].'"';
		}
		$UpLoadHtml .= '
		var InputArray = new Array('.implode(',',$view_ad_1_js_array).');
		$("#view_ad_1").AppUpload({InputName:"new_view_ad_1",InputLink:true,InputExist:true,InputArray:InputArray,Move:true});';
	}else{
		$UpLoadHtml .= '$("#view_ad_1").AppUpload({InputName:"new_view_ad_1",InputLink:true,Move:true});';
	}
	
	if($setting['calculation_ad']){
		foreach($setting['calculation_ad'] as $Key => $Val) {
			$calculation_ad_js_array[] = '"'.$Val['img'].'|'.$setting['calculation_ad'][$Key]['title'].'|'.$setting['calculation_ad'][$Key]['link'].'"';
		}
		$UpLoadHtml .= '
		var InputArray = new Array('.implode(',',$calculation_ad_js_array).');
		$("#calculation_ad").AppUpload({InputName:"new_calculation_ad",InputLink:true,InputExist:true,InputArray:InputArray,Move:true});';
	}else{
		$UpLoadHtml .= '$("#calculation_ad").AppUpload({InputName:"new_calculation_ad",InputLink:true,Move:true});';
	}
	
	$setting['pc_banners'] = $common_setting ? $setting['pc_banners'] : array(
		array('img'=>'/source/plugin/fn_house/static/images/banner.jpg')
	);
	if($setting['pc_banners']){
		foreach($setting['pc_banners'] as $Key => $Val) {
			$pc_banners_js_array[] = '"'.$Val['img'].'|'.$setting['pc_banners'][$Key]['title'].'|'.$setting['pc_banners'][$Key]['link'].'"';
		}
		$UpLoadHtml .= '
		var InputArray = new Array('.implode(',',$pc_banners_js_array).');
		$("#pc_banners").AppUpload({InputName:"new_pc_banners",InputLink:true,InputExist:true,InputArray:InputArray,Move:true});';
	}else{
		$UpLoadHtml .= '$("#pc_banners").AppUpload({InputName:"new_pc_banners",InputLink:true,Move:true});';
	}
	
	$setting['head_top_qr_list'] = $common_setting ? $setting['head_top_qr_list'] : array(
		array('img'=>'/source/plugin/fn_house/static/images/qr_code1.jpg','title'=>'&#25163;&#26426;&#29256;'),
		array('img'=>'/source/plugin/fn_house/static/images/qr_code2.jpg','title'=>'&#24494;&#20449;&#20844;&#20247;&#21495;'),
		array('img'=>'/source/plugin/fn_house/static/images/qr_code3.jpg','title'=>'&#23567;&#31243;&#24207;'),
	);
	if($setting['head_top_qr_list']){
		foreach($setting['head_top_qr_list'] as $Key => $Val) {
			$head_top_qr_list_js_array[] = '"'.$Val['img'].'|'.$setting['head_top_qr_list'][$Key]['title'].'|'.$setting['head_top_qr_list'][$Key]['link'].'"';
		}
		$UpLoadHtml .= '
		var InputArray = new Array('.implode(',',$head_top_qr_list_js_array).');
		$("#head_top_qr_list").AppUpload({InputName:"new_head_top_qr_list",InputTitle:true,InputExist:true,InputArray:InputArray,Move:true});';
	}else{
		$UpLoadHtml .= '$("#head_top_qr_list").AppUpload({InputName:"new_head_top_qr_list",InputTitle:true,Move:true});';
	}
	$setting['footer_qr_list'] = $common_setting ? $setting['footer_qr_list'] : array(
		array('img'=>'/source/plugin/fn_house/static/images/qr_code1.jpg','title'=>'&#25163;&#26426;&#29256;'),
		array('img'=>'/source/plugin/fn_house/static/images/qr_code2.jpg','title'=>'&#24494;&#20449;&#20844;&#20247;&#21495;'),
		array('img'=>'/source/plugin/fn_house/static/images/qr_code3.jpg','title'=>'&#23567;&#31243;&#24207;'),
	);
	if($setting['footer_qr_list']){
		foreach($setting['footer_qr_list'] as $Key => $Val) {
			$footer_qr_list_js_array[] = '"'.$Val['img'].'|'.$setting['footer_qr_list'][$Key]['title'].'|'.$setting['footer_qr_list'][$Key]['link'].'"';
		}
		$UpLoadHtml .= '
		var InputArray = new Array('.implode(',',$footer_qr_list_js_array).');
		$("#footer_qr_list").AppUpload({InputName:"new_footer_qr_list",InputTitle:true,InputExist:true,InputArray:InputArray,Move:true});';
	}else{
		$UpLoadHtml .= '$("#footer_qr_list").AppUpload({InputName:"new_footer_qr_list",InputTitle:true,Move:true});';
	}

	if($setting['notice_top_ad']){
		foreach($setting['notice_top_ad'] as $Key => $Val) {
			$notice_top_ad_js_array[] = '"'.$Val['img'].'|'.$setting['notice_top_ad'][$Key]['title'].'|'.$setting['notice_top_ad'][$Key]['link'].'"';
		}
		$UpLoadHtml .= '
		var InputArray = new Array('.implode(',',$notice_top_ad_js_array).');
		$("#notice_top_ad").AppUpload({InputName:"new_notice_top_ad",InputLink:true,InputExist:true,InputArray:InputArray,Move:true});';
	}else{
		$UpLoadHtml .= '$("#notice_top_ad").AppUpload({InputName:"new_notice_top_ad",InputLink:true,Move:true});';
	}

	if($setting['pc_home_ad_1']){
		foreach($setting['pc_home_ad_1'] as $Key => $Val) {
			$pc_home_ad_1_js_array[] = '"'.$Val['img'].'|'.$setting['pc_home_ad_1'][$Key]['title'].'|'.$setting['pc_home_ad_1'][$Key]['link'].'"';
		}
		$UpLoadHtml .= '
		var InputArray = new Array('.implode(',',$pc_home_ad_1_js_array).');
		$("#pc_home_ad_1").AppUpload({InputName:"new_pc_home_ad_1",InputLink:true,InputExist:true,InputArray:InputArray,Move:true});';
	}else{
		$UpLoadHtml .= '$("#pc_home_ad_1").AppUpload({InputName:"new_pc_home_ad_1",InputLink:true,Move:true});';
	}

	if($setting['pc_home_ad_2']){
		foreach($setting['pc_home_ad_2'] as $Key => $Val) {
			$pc_home_ad_2_js_array[] = '"'.$Val['img'].'|'.$setting['pc_home_ad_2'][$Key]['title'].'|'.$setting['pc_home_ad_2'][$Key]['link'].'"';
		}
		$UpLoadHtml .= '
		var InputArray = new Array('.implode(',',$pc_home_ad_2_js_array).');
		$("#pc_home_ad_2").AppUpload({InputName:"new_pc_home_ad_2",InputLink:true,InputExist:true,InputArray:InputArray,Move:true});';
	}else{
		$UpLoadHtml .= '$("#pc_home_ad_2").AppUpload({InputName:"new_pc_home_ad_2",InputLink:true,Move:true});';
	}

	if($setting['pc_list_disc_ad1']){
		foreach($setting['pc_list_disc_ad1'] as $Key => $Val) {
			$pc_list_disc_ad1_js_array[] = '"'.$Val['img'].'|'.$setting['pc_list_disc_ad1'][$Key]['title'].'|'.$setting['pc_list_disc_ad1'][$Key]['link'].'"';
		}
		$UpLoadHtml .= '
		var InputArray = new Array('.implode(',',$pc_list_disc_ad1_js_array).');
		$("#pc_list_disc_ad1").AppUpload({InputName:"new_pc_list_disc_ad1",InputLink:true,InputExist:true,InputArray:InputArray,Move:true});';
	}else{
		$UpLoadHtml .= '$("#pc_list_disc_ad1").AppUpload({InputName:"new_pc_list_disc_ad1",InputLink:true,Move:true});';
	}

	echo $UploadConfig['CssJsHtml'];
	echo '<script>'.$UpLoadHtml.'</script>';
	
}else{

	foreach($_GET['setting'] as $key => $value) {
		$setting[$key] = is_array($value) ? $value : addslashes($value);
	}
	
	foreach($_GET['upload_admin'] as $key => $value){
		if(strpos($key,'new_') !== false){
			$key_name = str_replace(array('new_'),'',$key);
			$setting[$key_name] = array();
			foreach($_GET[$key] as $k => $v) {
				$setting[$key_name][$k]['img'] = strpos($v,'http') !== false ? $v : $_G['siteurl'].$v;
				$setting[$key_name][$k]['link'] = $_GET[$key.'_link'][$k];
				$setting[$key_name][$k]['title'] = $_GET[$key.'_title'][$k];
			}
		}
	}

	foreach(array('navs','min_nav','footer_nav','add_nav','pc_user_nav','pc_nav') as $common_nav_value){
		foreach($_GET['common_list'][$common_nav_value] as $nav_key => $nav_value){
			foreach($_GET['common_list'][$common_nav_value]['displayorder'] as $key => $value){
				$new_setting[$common_nav_value][$key][$nav_key] = filter_string($_GET['common_list'][$common_nav_value][$nav_key][$key]);
				if($_FILES['common_list']['size'][$common_nav_value]['file_'.$nav_key][$key]){
					$images = array(
						'name' => $_FILES['common_list']['name'][$common_nav_value]['file_'.$nav_key][$key],
						'type' => $_FILES['common_list']['type'][$common_nav_value]['file_'.$nav_key][$key],
						'tmp_name' => $_FILES['common_list']['tmp_name'][$common_nav_value]['file_'.$nav_key][$key],
						'error' => $_FILES['common_list']['error'][$common_nav_value]['file_'.$nav_key][$key],
						'size' => $_FILES['common_list']['size'][$common_nav_value]['file_'.$nav_key][$key]
					);
					$FileCode = Fn_Upload($images);
					$new_setting[$common_nav_value][$key][$nav_key] = $FileCode['Path'];
				}
			}
		}
		$setting[$common_nav_value] = array_sort($new_setting[$common_nav_value],'displayorder');
	}

	foreach($_FILES as $file_key => $file_value){
		if(strpos($file_key,'new_') !== false){
			$key = str_replace(array('TMPnew_','new_'),'',$file_key);
			if($_FILES[$file_key]['size']){
				$FileCode = Fn_Upload($_FILES[$file_key]);
				if($FileCode['Errorcode']){
					cpmsg($Fn_Admin->Config['LangVar']['ImgErr'],'','error');
					exit();
				}else{
					$setting[$key] = $FileCode['Path'];
				}
			}else{
				$file_key = str_replace(array('TMPnew_'),array('new_'),$file_key);
				if(!preg_match('/.*(\.png|\.jpg|\.jpeg|\.gif)$/',$_GET[$file_key]) && $_GET[$file_key]){
					cpmsg($Fn_Admin->Config['LangVar']['ImgErr'],'','error');
					exit();
				}else{
					$setting[$key] = addslashes(strip_tags($_GET[$file_key]));
				}
			}
		}
	}
	savecache($setting_name,$setting);
	fn_cpmsg($Fn_Admin->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
	exit();

}
//From: Dism_taobao_com
?>