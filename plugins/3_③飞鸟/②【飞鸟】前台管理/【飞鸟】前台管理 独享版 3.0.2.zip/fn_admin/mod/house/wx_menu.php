<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('house_all') && !$Fn_Admin->CheckUserGroup('house_wx_menu')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeItemUrl'];

@require_once libfile('class/wechat','plugin/fn_assembly');
@require_once libfile('function/cache');

$plugin['identifier'] = 'fn_'.$_GET['mod'];
loadcache($plugin['identifier'].'_wechat_menu');
loadcache($plugin['identifier'].'_setting');
loadcache('plugin');
$setting = $_G['cache'][$plugin['identifier'].'_wechat_menu'];
$common_setting = (array)$_G['cache'][$plugin['identifier'].'_setting'];
$WxAppid = $common_setting['WxAppid'];
$WxSecret = $common_setting['WxSecret'];

if(!$WxAppid || !$WxSecret) {
	fn_cpmsg(lang('plugin/fn_assembly', 'wsq_menu_at_error'), '', 'error');
	exit();
}

if(!submitcheck('menusubmit') && !submitcheck('pubsubmit')) {

	$wechat_client = new Fn_WeChatClient($WxAppid,$WxSecret);

	if(in_array('plugin', $_G['setting']['rewritestatus'])) {
		$url = $_G['siteurl'].rewriteoutput('plugin', 1, 'wechat', 'access', '', 'op=access');
	} else {
		$url = $_G['siteurl'].'plugin.php?id=wechat:access';
	}

	showtips(lang('plugin/fn_assembly', 'menu_tips', array('url' => $url)));
	
	showtagheader('div', 'row', true,'row');
	showtagheader('div', 'col-12', true,'col-12');
	showtagheader('div', 'box', true,'box');
	showtagheader('div', 'box-body', true,'box-body');
	showtagheader('div', 'table-responsive', true,'table-responsive');
	showformheader($FormUrl);
	showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
	echo '<tr class="header"><th class="w50"></th><th class="w80">'.lang('plugin/fn_assembly', 'DisplayOrder').'</th><th style="width:350px">'.lang('plugin/fn_assembly', 'wsq_menu_name').'</th><th>'.lang('plugin/fn_assembly', 'wsq_menu_keyurl').'</th><th>'.lang('plugin/fn_assembly', 'wsq_menu_appid').'</th><th>'.lang('plugin/fn_assembly', 'wsq_menu_pagepath').'</th></tr>';

	foreach($setting['button'] as $k => $button) {
		$disabled = !empty($button['sub_button']) ? 'disabled' : '';
		showtablerow('', array('', 'class="td23 td28"', '', 'class="td29"', 'class="td29"', 'class="td29"'), array(
			'<input type="checkbox" class="filled-in" id="checkbox_'.$k.'" name="button['.$k.'][delete]" value="yes" '.$disabled.'><label for="checkbox_'.$k.'"></label>',
			"<input type=\"text\" class=\"form-control txt w80\" size=\"3\" name=\"button[$k][displayorder]\" value=\"$button[displayorder]\">",
			"<div class=\"parentnode\"><input type=\"text\" class=\"form-control txt\" size=\"30\" name=\"button[$k][name]\" value=\"".dhtmlspecialchars($button['name'])."\"></div>",
			"<input type=\"text\" class=\"form-control txt\" size=\"30\" name=\"button[$k][keyurl]\" value=\"".dhtmlspecialchars($button['keyurl'])."\">",
			"<input type=\"text\" class=\"form-control txt\" size=\"30\" name=\"button[$k][appid]\" value=\"".dhtmlspecialchars($button['appid'])."\">",
			"<input type=\"text\" class=\"form-control txt\" size=\"30\" name=\"button[$k][pagepath]\" value=\"".dhtmlspecialchars($button['pagepath'])."\">"
		));
		if(!empty($button['sub_button'])) {
			foreach($button['sub_button'] as $sk => $sub_button) {
				showtablerow('', array('', 'class="td23 td28"', '', 'class="td29"', 'class="td29"', 'class="td29"'), array(
					'<input type="checkbox" class="filled-in" id="checkbox_'.$k.'_'.$sk.'" name="button['.$k.'][sub_button]['.$sk.'][delete]" value="yes"><label for="checkbox_'.$k.'_'.$sk.'"></label>',
					"<input type=\"text\" class=\"form-control txt\" size=\"3\" name=\"button[$k][sub_button][$sk][displayorder]\" value=\"$sub_button[displayorder]\">",
					"<div class=\"node\"><input type=\"text\" class=\"form-control txt\" size=\"30\" name=\"button[$k][sub_button][$sk][name]\" value=\"".dhtmlspecialchars($sub_button['name'])."\"></div>",
					"<input type=\"text\" class=\"form-control txt\" size=\"30\" name=\"button[$k][sub_button][$sk][keyurl]\" value=\"".dhtmlspecialchars($sub_button['keyurl'])."\">",
					"<input type=\"text\" class=\"form-control txt\" size=\"30\" name=\"button[$k][sub_button][$sk][appid]\" value=\"".dhtmlspecialchars($sub_button['appid'])."\">",
					"<input type=\"text\" class=\"form-control txt\" size=\"30\" name=\"button[$k][sub_button][$sk][pagepath]\" value=\"".dhtmlspecialchars($sub_button['pagepath'])."\">",
				));
			}
		}
		echo '<tr><td></td><td></td><td colspan="5"><div class="lastnode" onclick="addrow(this, rowtypedata,1, '.$k.')" style="cursor:pointer;"><span class="addtr">'.lang('plugin/fn_assembly', 'wsq_menu_sub_button').'</span></div></td></tr>';
	}
	echo '<tr><td></td><td class="td23 td28"></td><td colspan="5"><div onclick="addrow(this, rowtypedata, 0,0)" style="cursor:pointer;"><span class="addtr">'.lang('plugin/fn_assembly', 'wsq_menu_button').'</span></div></td></tr>';

	echo <<<EOT
<script type="text/JavaScript">
var rowtypedata = [
[[1,''], [1,'<input name="newbutton[displayorder][]" value="" size="3" type="text" class="form-control">', 'td23 td28'], [1, '<input name="newbutton[name][]" value="" size="30" type="text" class="form-control">'], [1, '<input name="newbutton[keyurl][]" value="" size="30" type="text" class="form-control">', 'td29'], [1, '<input name="newbutton[appid][]" value="" size="30" type="text" class="form-control">', 'td29'], [1, '<input name="newbutton[pagepath][]" value="" size="30" type="text" class="form-control">', 'td29']],
[[1,''], [1,'<input name="newsub_button[{1}][displayorder][]" value="" size="3" type="text" class="form-control">', 'td23 td28'], [1, '<div class=\"node\"><input name="newsub_button[{1}][name][]" value="" size="30" type="text" class="form-control"></div>'], [1, '<input name="newsub_button[{1}][keyurl][]" value="" size="30" type="text" class="form-control">', 'td29'], [1, '<input name="newsub_button[{1}][appid][]" value="" size="30" type="text" class="form-control">', 'td29'], [1, '<input name="newsub_button[{1}][pagepath][]" value="" size="30" type="text" class="form-control">', 'td29']],
];
</script>
EOT;

	showsubmit('menusubmit', lang('plugin/fn_assembly', 'wsq_menu_save'), 'del', '<input type="submit" class="btn  btn-danger" name="pubsubmit" value="'.lang('plugin/fn_assembly', 'wsq_menu_pub').'" />');
	showtablefooter(); /*dism��taobao��com*/
	showformfooter(); /*Dism_taobao-com*/
	showtagfooter('div');
	showtagfooter('div');
	showtagfooter('div');
	showtagfooter('div');
	showtagfooter('div');
} else {

	if(!empty($_GET['newbutton'])) {
		foreach($_GET['newbutton']['name'] as $k => $name) {
			$button = array(
				'displayorder' => $_GET['newbutton']['displayorder'][$k],
				'name' => $name,
				'keyurl' => $_GET['newbutton']['keyurl'][$k],
				'appid' => $_GET['newbutton']['appid'][$k],
				'pagepath' => $_GET['newbutton']['pagepath'][$k]
			);
			$setting['button'][] = $button;
		}
	}

	foreach($_GET['button'] as $k => $value) {
		if($value['sub_button']) {
			foreach($value['sub_button'] as $sk => $v) {
				if($v['delete']) {
					unset($value['sub_button'][$sk]);
				}
			}
		}
		if($value['delete']) {
			unset($setting['button'][$k]);
			continue;
		}
		$setting['button'][$k] = $value;
		if(!empty($_GET['newsub_button'][$k])) {
			foreach($_GET['newsub_button'][$k]['name'] as $sk => $name) {
				$sub_button = array(
					'displayorder' => $_GET['newsub_button'][$k]['displayorder'][$sk],
					'name' => $name,
					'keyurl' => $_GET['newsub_button'][$k]['keyurl'][$sk],
					'appid' => $_GET['newsub_button'][$k]['appid'][$sk],
					'pagepath' => $_GET['newsub_button'][$k]['pagepath'][$sk]
				);
				$setting['button'][$k]['sub_button'][] = $sub_button;
			}
		}
		if(count($setting['button'][$k]['sub_button']) > 7) {
			fn_cpmsg(lang('plugin/fn_assembly', 'wsq_menu_sub_button_max'), '', 'error');
			exit();
		}
		usort($setting['button'][$k]['sub_button'], 'buttoncmp');
	}

	if(count($setting['button']) > 3) {
		fn_cpmsg(lang('plugin/fn_assembly', 'wsq_menu_button_max'), '', 'error');
		exit();
	}

	usort($setting['button'], 'buttoncmp');
	
	savecache($plugin['identifier'].'_wechat_menu',$setting);

	if(submitcheck('pubsubmit')) {
		if(!$setting['button']) {
			fn_cpmsg(lang('plugin/fn_assembly', 'wsq_menu_button_pub_error'), '', 'error');
			exit();
		}
		$pubmenu = array('button' => array());
		foreach($setting['button'] as $button) {
			if(!$button['sub_button']) {
				if(!$button['name']) {
					fn_cpmsg(lang('plugin/fn_assembly', 'wsq_menu_name_empty'), '', 'error');
					exit();
				}
				if(!$button['keyurl']) {
					fn_cpmsg(lang('plugin/fn_assembly', 'wsq_menu_keyurl_empty'), '', 'error');
					exit();
				}
				$parse = parse_url($button['keyurl']);
				$item = array(
					'type' => $parse['host'] ? ($button['appid'] && $button['pagepath'] ? 'miniprogram' : 'view') : 'click',
					'name' => convertname($button['name']),
					$parse['host'] ? 'url' : 'key' => $button['keyurl'],
					'appid' => $button['appid'],
					'pagepath' => $button['pagepath']
				);
				$pubmenu['button'][] = $item;
			} else {
				if(!$button['name']) {
					fn_cpmsg(lang('plugin/fn_assembly', 'wsq_menu_name_empty'), '', 'error');
					exit();
				}
				$sub_buttons = array();
				foreach($button['sub_button'] as $sub_button) {
					if(!$sub_button['name']) {
						fn_cpmsg(lang('plugin/fn_assembly', 'wsq_menu_name_empty'), '', 'error');
						exit();
					}
					if(!$sub_button['keyurl']) {
						fn_cpmsg(lang('plugin/fn_assembly', 'wsq_menu_keyurl_empty'), '', 'error');
						exit();
					}
					$parse = parse_url($sub_button['keyurl']);
					$item = array(
						'type' => $parse['host'] ? ($sub_button['appid'] && $sub_button['pagepath'] ? 'miniprogram' : 'view') : 'click',
						'name' => convertname($sub_button['name']),
						$parse['host'] ? 'url' : 'key' => $sub_button['keyurl'],
						'appid' => $sub_button['appid'],
						'pagepath' => $sub_button['pagepath']
					);
					$sub_buttons[] = $item;
				}
				$item = array(
					'name' => convertname($button['name']),
					'sub_button' => $sub_buttons
				);
				$pubmenu['button'][] = $item;
			}
		}

		$wechat_client = new Fn_WeChatClient($WxAppid,$WxSecret);
	
		if($wechat_client->setMenu($pubmenu)) {
			fn_cpmsg(lang('plugin/fn_assembly', 'wsq_menu_pub_succeed'), $CpMsgUrl, 'succeed');
			exit();
		} else {
			fn_cpmsg(lang('plugin/fn_assembly', 'wsq_menu_pub_error', array('errno' => $wechat_client->error())), '', 'error');
			exit();
		}
	} else {
		fn_cpmsg(lang('plugin/fn_assembly', 'UpdateOk'), $CpMsgUrl, 'succeed');
		exit();
	}

}

function convertname($str) {
	return urlencode(diconv($str, CHARSET, 'UTF-8'));
}

function buttoncmp($a, $b) {
	return $a['displayorder'] > $b['displayorder'] ? 1 : -1;
}
//From: dis'.'m.tao'.'bao.com
?>