<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('house_all') && !$Fn_Admin->CheckUserGroup('house_agent_group_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$Fn_House->Config['LangVar']['Currency'] = str_replace(array('{wallet_title}'),array($Fn_House->Config['PluginVar']['WalletTitle']),$Fn_House->Config['LangVar']['Currency']);

$SubModel = in_array($_GET['submodel'], array('list','add')) ? $_GET['submodel'] : 'list';
$Fn_Admin->Config['IframeSubModelUrl'] = $Fn_Admin->Config['IframeItemUrl'].'&submodel='.$SubModel;
$NavClass = array($SubModel=>'btn-info Hover');

//����
echo <<<Nav
<div class="SubModelNav">
  <ul>
	<li class="{$NavClass['list']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=list" target="_self">{$Fn_Admin->Config['LangVar']['HouseLeftNavArray']['agent_group_list']}</a></li>
    <li class="{$NavClass['add']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=add" target="_self">{$Fn_Admin->Config['LangVar']['AddEditTitle']}</a></li>
  </ul>
  <div class="both"></div>
</div>
Nav;

if($SubModel == 'list'){//�б�
	$Do = in_array($_GET['do'], array('Del')) ? $_GET['do'] : 'submodel_list';
	//�����ֶ�
	$SearField =array('page','keyword');
	foreach($SearField as $Val) {
		$SearArray[$Val] = $_GET[$Val] || in_array($_GET[$Val],array('0')) ? $_GET[$Val] : '';
	}
	//�����ֶ� End
	$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeSubModelUrl'].'&'.http_build_query($SearArray);


	if($Do == 'submodel_list'){
		if(!submitcheck('Submit')) {
			$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
			$Where = '';
			$Order = in_array($_GET['order'], array('id','displayorder')) ? 'AG.'.addslashes(dhtmlspecialchars($_GET['order'])) : 'AG.displayorder';
	
			$Where = preg_replace('/and/','where',$Where,1);
			$Limit = 20;
			$Page = $_GET['page']?intval($_GET['page']):1;
			/* ��ѯ���� End */

			/* ģ����� */	
			showtagheader('div', 'row', true,'row');
			showtagheader('div', 'col-12', true,'col-12');
			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-body', true,'box-body');
			showtagheader('div', 'table-responsive', true,'table-responsive');
			showformheader($FormUrl,'enctype="multipart/form-data"');
			showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
			showsubtitle(array(
				'ID',
				$Fn_House->Config['LangVar']['Title'],
				$Fn_House->Config['LangVar']['IcoTitle'],
				$Fn_House->Config['LangVar']['MoneyTitle'],
				$Fn_House->Config['LangVar']['AgentGroupTime'],
				$Fn_House->Config['LangVar']['AgentGroupDayInfoCount'],
				$Fn_House->Config['LangVar']['AgentGroupInfoCount'],
				$Fn_House->Config['LangVar']['AgentGroupDayRefreshCount'],
				$Fn_House->Config['LangVar']['AgentGroupTopDiscount'],
				$Fn_House->Config['LangVar']['Currency'],
				$Fn_House->Config['LangVar']['AgentGroupExamine'],
				$Fn_House->Config['LangVar']['AgentGroupEntrustData'],
				$Fn_House->Config['LangVar']['AgentGroupAccessRecord'],
				$Fn_House->Config['LangVar']['AgentGroupAccessRecordMobile'],
				$Fn_House->Config['LangVar']['AgentGroupInfoMy'],
				$Fn_House->Config['LangVar']['AgentGroupVr'],
				$Fn_House->Config['LangVar']['DisplayOrder'],
				$Fn_House->Config['LangVar']['DisplayTitle'],
				$Fn_House->Config['LangVar']['OperationTitle']
			),'header tbm tc');

			$ModulesList = GetModulesList($Page,$Limit,$Where,$Order);
			foreach ($ModulesList as $Module) {
				showtablerow('', array('class="tc w50"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
					$Module['id'],
					$Module['title'],
					$Module['ico'] ? '<img src="'.$Module['ico'].'" style="height:30px;">' : '',
					$Module['money'],
					$Module['group_time'] ? $Module['group_time'].$Fn_House->Config['LangVar']['Ge'].$Fn_House->Config['LangVar']['Month'] : '',
					$Module['day_info_count'],
					$Module['info_count'],
					$Module['day_refresh_count'],
					$Module['top_discount'],
					$Module['currency'],
					!$Module['examine'] ? '<span class="label bg-secondary">'.$Fn_House->Config['LangVar']['No'].'</span>' : '<span class="label bg-blue">'.$Fn_House->Config['LangVar']['Yes'].'</span>',
					!$Module['entrust_data'] ? '<span class="label bg-secondary">'.$Fn_House->Config['LangVar']['No'].'</span>' : '<span class="label bg-blue">'.$Fn_House->Config['LangVar']['Yes'].'</span>',
					!$Module['access_record'] ? '<span class="label bg-secondary">'.$Fn_House->Config['LangVar']['No'].'</span>' : '<span class="label bg-blue">'.$Fn_House->Config['LangVar']['Yes'].'</span>',
					!$Module['access_record_mobile'] ? '<span class="label bg-secondary">'.$Fn_House->Config['LangVar']['No'].'</span>' : '<span class="label bg-blue">'.$Fn_House->Config['LangVar']['Yes'].'</span>',
					!$Module['info_my'] ? '<span class="label bg-secondary">'.$Fn_House->Config['LangVar']['No'].'</span>' : '<span class="label bg-blue">'.$Fn_House->Config['LangVar']['Yes'].'</span>',
					!$Module['vr'] ? '<span class="label bg-secondary">'.$Fn_House->Config['LangVar']['No'].'</span>' : '<span class="label bg-blue">'.$Fn_House->Config['LangVar']['Yes'].'</span>',
					$Module['displayorder'],
					!$Module['display'] ? '<span class="label bg-secondary">'.$Fn_House->Config['LangVar']['No'].'</span>' : '<span class="label bg-blue">'.$Fn_House->Config['LangVar']['Yes'].'</span>',
					'<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&agid='.$Module['id'].'" class="btn btn-sm btn-info-outline">'.$Fn_House->Config['LangVar']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Del&agid='.$Module['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$Fn_House->Config['LangVar']['DelTitle'].'</a>',
				));
			}

			showtablefooter(); /*dism��taobao��com*/
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			/* ģ�����End */	
		}
	}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['agid']){
		$AGid = intval($_GET['agid']);
		DB::delete($Fn_House->TableAgentGroup,'id ='.$AGid);

		GetInsertDoLog('del_agent_group_house','fn_'.$_GET['mod'],array('id'=>$AGid));//������¼

		fn_cpmsg($Fn_Admin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
	}
}else if($SubModel == 'add'){//���ӻ�༭

	$AGid = intval($_GET['agid']);
	$Item = DB::fetch_first('SELECT * FROM '.DB::table($Fn_House->TableAgentGroup).' where id = '.$AGid);
	if($Item)$Item['param'] = unserialize($Item['param']);
	if(!submitcheck('DetailSubmit')) {
		$OpTitle = $Fn_House->Config['LangVar']['AddTitle'];
		if($Item)$OpTitle = $Fn_House->Config['LangVar']['EditTitle'];
		
		//ͼƬ�ϴ�
		if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_assembly/class/class_upload.php')){
			@require_once libfile('class/upload','plugin/fn_assembly');
			$UploadConfig = fn_upload::Config();
		}
		
		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-header', true,'with-border box-header');
		showtitle($OpTitle,'class="box-title"');
		showtagfooter('div');
		showformheader($Fn_Admin->Config['IframeSubModelUrl'].'&agid='.$AGid,'enctype');
		showtagheader('div', 'box-body', true,'box-body');

		
		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_House->Config['LangVar']['IcoTitle'].'<br>'.$Fn_House->Config['LangVar']['AgentGroupIcoTips'].':</label><div class="col-sm-9"><div class="AdminSingleUpload"><div class="PhotoControl" id="IcoPhotoControl"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';

		showsetting($Fn_House->Config['LangVar']['Title'], 'title', $Item['title'], 'text');
	
		showsetting($Fn_House->Config['LangVar']['MoneyTitle'], 'money', $Item['money'], 'text','','',$Fn_House->Config['LangVar']['AgentGroupNumberTips']);

		showsetting($Fn_House->Config['LangVar']['AgentGroupTime'], 'group_time', $Item['group_time'], 'text','','',$Fn_House->Config['LangVar']['AgentGroupTimeTips']);

		showsetting($Fn_House->Config['LangVar']['AgentGroupDayInfoCount'], 'day_info_count', $Item['day_info_count'], 'text','','',$Fn_House->Config['LangVar']['AgentGroupDayInfoCountTips']);
		showsetting($Fn_House->Config['LangVar']['AgentGroupInfoCount'], 'info_count', $Item['info_count'], 'text','','',$Fn_House->Config['LangVar']['AgentGroupInfoCountTips']);
		showsetting($Fn_House->Config['LangVar']['AgentGroupDayRefreshCount'], 'day_refresh_count', $Item['day_refresh_count'], 'text','','',$Fn_House->Config['LangVar']['AgentGroupDayRefreshCountTips']);

		showsetting($Fn_House->Config['LangVar']['AgentGroupTopDiscount'], 'top_discount', $Item['top_discount'], 'text','','',$Fn_House->Config['LangVar']['AgentGroupTopDiscountTips']);

		if($Fn_House->Config['PluginVar']['WalletSwitch']){
			showsetting($Fn_House->Config['LangVar']['Currency'], 'currency', $Item['currency'], 'text','','',$Fn_House->Config['LangVar']['CurrencyTips']);
		}

		showsetting($Fn_House->Config['LangVar']['AgentGroupExamine'], 'examine', $Item['examine'], 'radio');
		showsetting($Fn_House->Config['LangVar']['AgentGroupEntrustData'], 'entrust_data', $Item['entrust_data'], 'radio');
		showsetting($Fn_House->Config['LangVar']['AgentGroupAccessRecord'], 'access_record', $Item['access_record'], 'radio');
		showsetting($Fn_House->Config['LangVar']['AgentGroupAccessRecordMobile'], 'access_record_mobile', $Item['access_record_mobile'], 'radio');
		showsetting($Fn_House->Config['LangVar']['AgentGroupInfoMy'], 'info_my', $Item['info_my'], 'radio');
		showsetting($Fn_House->Config['LangVar']['AgentGroupVr'], 'vr', $Item['vr'], 'radio');
		
		showsetting($Fn_House->Config['LangVar']['DisplayOrder'], 'displayorder', $Item['displayorder'], 'text');

		showsetting($Fn_House->Config['LangVar']['DisplayTitle'], 'display', $Item ? $Item['display'] : 1, 'radio');
		
		showsubmit('DetailSubmit','&#20445;&#23384;&#37197;&#32622;');
		showtagfooter('div');
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');

		$UpLoadHtml  = '';
		if($Item['ico']){
			$IcoJsArray[] = '"'.$Item['ico'].'"';;
			$UpLoadHtml .= '
			var InputArray = new Array('.implode(',',$IcoJsArray).');
			$("#IcoPhotoControl").AppUpload({InputName:"new_ico",Multiple:true,InputExist:true,InputArray:InputArray});';

		}else{
			$UpLoadHtml .= '$("#IcoPhotoControl").AppUpload({InputName:"new_ico",Multiple:true});';
		}

		echo $UploadConfig['CssJsHtml'].'<script>'.$UpLoadHtml.'</script>';

	}else{
		foreach($_GET['new_ico'] as $Key => $Val) {
			$_GET['new_ico'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}
		$Data['ico'] = $_GET['new_ico'][0] ? addslashes(strip_tags($_GET['new_ico'][0])) : '';
		$Data['title'] = addslashes(strip_tags($_GET['title']));
		$Data['money'] = addslashes(strip_tags($_GET['money']));
		$Data['group_time'] = addslashes(strip_tags($_GET['group_time']));
		$Data['examine'] = intval($_GET['examine']);
		$Data['day_info_count'] = intval($_GET['day_info_count']);
		$Data['info_count'] = intval($_GET['info_count']);
		$Data['day_refresh_count'] = intval($_GET['day_refresh_count']);
		$Data['top_discount'] = addslashes(strip_tags($_GET['top_discount']));
		$Data['currency'] = intval($_GET['currency']);
		$Data['examine'] = intval($_GET['examine']);
		$Data['entrust_data'] = intval($_GET['entrust_data']);
		$Data['access_record'] = intval($_GET['access_record']);
		$Data['access_record_mobile'] = intval($_GET['access_record_mobile']);
		$Data['info_my'] = intval($_GET['info_my']);
		$Data['vr'] = intval($_GET['vr']);
		$Data['displayorder'] = intval($_GET['displayorder']);
		$Data['display'] = intval($_GET['display']);
	
		if($Item){
			GetInsertDoLog('edit_agent_group_house','fn_'.$_GET['mod'],array('id'=>$AGid));//������¼
			DB::update($Fn_House->TableAgentGroup,$Data,'id = '.$AGid);
		}else{
			$Id = DB::insert($Fn_House->TableAgentGroup,$Data,true);
			GetInsertDoLog('add_agent_group_house','fn_'.$_GET['mod'],array('id'=>$Id));//������¼
		}
		fn_cpmsg($Fn_House->Config['LangVar']['UpdateOk'],$Fn_Admin->Config['IframeItemUrl'].'&submodel=list','succeed');
	}
}


/* �б� */
function GetModulesList($Page,$Limit,$Where=null,$Order){
	global $Fn_House;
	$FetchSql = 'SELECT AG.* FROM '.DB::table($Fn_House->TableAgentGroup).' AG '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}

/* ���� */
function GetModulesCount($Where=null){
	global $Fn_House;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_House->TableAgentGroup).' AG '.$Where;
	return DB::result_first($FetchSql);//��������
}

?>