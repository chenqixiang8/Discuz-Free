<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('house_all') && !$Fn_Admin->CheckUserGroup('house_demand_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$Do = in_array($_GET['do'], array('Del','Display','PaymentState','Deal','Edit')) ? $_GET['do'] : 'List';

//�����ֶ�
$SearField =array('page','keyword','display','deal','payment_state','type','order');
foreach($SearField as $Val) {
	$SearArray[$Val] = $_GET[$Val] || in_array($_GET[$Val],array('0')) ? $_GET[$Val] : '';
}
//�����ֶ� End

$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeItemUrl'].'&'.http_build_query($SearArray);

if($Do == 'List'){

	if(!submitcheck('Submit')) {
		$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
		/* ��ѯ���� */
		$Where = '';
		$Order = in_array($_GET['order'], array('id')) ? 'D.'.addslashes(dhtmlspecialchars($_GET['order'])) : 'D.id';

		if($_GET['keyword']){
			$_GET['keyword'] = str_replace(array('%','_'),array('',''),$_GET['keyword']);
			$Where .= ' and (concat(D.username,D.content,D.name) like(\'%'.addslashes(dhtmlspecialchars(str_replace(array('%','_'),array('',''),$_GET['keyword']))).'%\') or D.uid = '.intval($_GET['keyword']).')';
		}
		
		if(in_array($_GET['type'],array('1','2'))){
			$Where .= ' and D.type = '.intval($_GET['type']);
		}

		if(in_array($_GET['display'],array('0','1'))){
			$Where .= ' and D.display = '.intval($_GET['display']);
		}

		if(in_array($_GET['payment_state'],array('0','1'))){
			$Where .= ' and D.payment_state = '.intval($_GET['payment_state']);
		}

		if(in_array($_GET['deal'],array('0','1'))){
			$Where .= ' and D.deal = '.intval($_GET['deal']);
		}
		
		$Where = preg_replace('/and/','where',$Where,1);
		$Limit = 30;
		$Page = $_GET['page']?intval($_GET['page']):1;
		/* ��ѯ���� End */
		/* ģ����� */
		showtagheader('div', 'row', true,'row');
		showtagheader('div', 'col-12', true,'col-12');
		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-body', true,'box-body');
		/* ���� */
		$TypeSelected = array($_GET['type']=>' selected');
		$DisplaySelected = array($_GET['display']=>' selected');
		$DealSelected = array($_GET['deal']=>' selected');
		$PaymentStateSelected = array($_GET['payment_state']=>' selected');
		echo <<<SEARCH
		<form method="post" autocomplete="off" action="$SearUrl" id="tb_search">
			<div class="FormSearchTo">
				<table cellspacing="4" cellpadding="4">
					<tr>
						<th>{$Fn_House->Config['LangVar']['KeywordTitle']}</th><td><input type="text" class="form-control w150" name="keyword" value="{$_GET['keyword']}">
						</td>
						<th>{$Fn_House->Config['LangVar']['Nature']}</th><td>
						<select name="type" class="form-control w120">
							<option value="">{$Fn_House->Config['LangVar']['SelectNull']}</option>
							<option value="1"{$TypeSelected['1']}>{$Fn_House->Config['LangVar']['DemandTypeArray'][1]}</option>
							<option value="2"{$TypeSelected['2']}>{$Fn_House->Config['LangVar']['DemandTypeArray'][2]}</option>
						</select>
						</td>
						<th>{$Fn_House->Config['LangVar']['DisplayTitle']}</th><td>
						<select name="display" class="form-control w120">
							<option value="">{$Fn_House->Config['LangVar']['SelectNull']}</option>
							<option value="1"{$DisplaySelected['1']}>{$Fn_House->Config['LangVar']['Yes']}</option>
							<option value="0"{$DisplaySelected['0']}>{$Fn_House->Config['LangVar']['No']}</option>
						</select>
						</td>
						<th>{$Fn_House->Config['LangVar']['PaymentState']}</th><td>
						
						<select name="payment_state" class="form-control w120">
							<option value="">{$Fn_House->Config['LangVar']['SelectNull']}</option>
							<option value="0"{$PaymentStateSelected['0']}>{$Fn_House->Config['LangVar']['PaymentStateArray'][0]}</option>
							<option value="1"{$PaymentStateSelected['1']}>{$Fn_House->Config['LangVar']['PaymentStateArray'][1]}</option>
						</select>
						</td>
						<th>{$Fn_House->Config['LangVar']['DealState']}</th><td>
						<select name="deal" class="form-control w120">
							<option value="">{$Fn_House->Config['LangVar']['SelectNull']}</option>
							<option value="1"{$DealSelected['1']}>{$Fn_House->Config['LangVar']['DealStateArray'][1]}</option>
							<option value="0"{$DealSelected['0']}>{$Fn_House->Config['LangVar']['DealStateArray'][0]}</option>
						</select>
						&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Admin->Config['LangVar']['SearchSubmit']}" class="btn btn-info" type="submit">
						</td>
					</tr>
				</table>
			</div>
		</form>
SEARCH;
		/* ���� End */
		showtagheader('div', 'table-responsive', true,'table-responsive');
		showformheader($FormUrl,'enctype="multipart/form-data"');
		showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
		showsubtitle(array(
			'ID',
			'Uid/'.$Fn_House->Config['LangVar']['UserNameTitle'],
			$Fn_House->Config['LangVar']['Name'].'/'.$Fn_House->Config['LangVar']['Mobile'],
			$Fn_House->Config['LangVar']['Nature'],
			$Fn_House->Config['LangVar']['DemandArea'],
			$Fn_House->Config['LangVar']['Title'],
			$Fn_House->Config['LangVar']['Content'],
			$Fn_House->Config['LangVar']['DisplayTitle'],
			$Fn_House->Config['LangVar']['PaymentState'],
			$Fn_House->Config['LangVar']['DealState'],
			$Fn_House->Config['LangVar']['TimeTitle'],
			$Fn_House->Config['LangVar']['OperationTitle']
		), 'header tbm tc');
		
		$ModulesList = GetModulesList($Page,$Limit,$Where,$Order);
		
		foreach ($ModulesList as $Module) {
			showtablerow('', array('class="tc w100"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
				'<input type="checkbox" class="filled-in" id="checkbox_'.$Module['id'].'" name="delete[]" value="'.$Module['id'].'"><label for="checkbox_'.$Module['id'].'">'.$Module['id'].'</label>',
				$Module['uid'] ? $Module['uid'].'<br>'.$Module['username'] : '',
				$Module['name'].'<br>'.$Module['mobile'],
				$Fn_House->Config['LangVar']['DemandTypeArray'][$Module['type']],
				$Fn_House->Area[$Module['province']]['content'].($Module['city'] ? '-'.$Fn_House->Area[$Module['city']]['content'] : '').($Module['dist'] ? '-'.$Fn_House->Area[$Module['dist']]['content'] : ''),
				$Module['title'],
				'<div title="'.$Module['content'].'">'.cutstr($Module['content'],60).'</div>',
				!$Module['display'] ? '<span class="label bg-secondary">'.$Fn_House->Config['LangVar']['No'].'</span>' : '<span class="label bg-blue">'.$Fn_House->Config['LangVar']['Yes'].'</span>',
				!$Module['payment_state'] ? '<span class="label bg-secondary">'.$Fn_House->Config['LangVar']['PaymentStateArray']['0'].'</span>' : '<span class="label bg-blue">'.$Fn_House->Config['LangVar']['PaymentStateArray']['1'].'</span>',
				!$Module['deal'] ? '<span class="label bg-secondary">'.$Fn_House->Config['LangVar']['DealStateArray']['0'].'</span>' : '<span class="label bg-blue">'.$Fn_House->Config['LangVar']['DealStateArray']['1'].'</span>',
				date('Y-m-d H:i',$Module['dateline']),
				'&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Display&did='.$Module['id'].'&value='.(!empty($Module['display']) ? 0:1).'&formhash='.FORMHASH.'">'.(!empty($Module['display']) ? $Fn_House->Config['LangVar']['DisplayNoTitle'] : $Fn_House->Config['LangVar']['DisplayIsTitle']).'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=PaymentState&did='.$Module['id'].'&value='.(!empty($Module['payment_state']) ? 0:1).'&formhash='.FORMHASH.'">'.(!empty($Module['payment_state']) ? $Fn_House->Config['LangVar']['OpPaymentStateArray'][0] : $Fn_House->Config['LangVar']['OpPaymentStateArray'][1]).'</a><br><a href="'.$OpCpUrl.'&do=Deal&did='.$Module['id'].'&value='.(!empty($Module['deal']) ? 0:1).'&formhash='.FORMHASH.'">'.(!empty($Module['deal']) ? $Fn_House->Config['LangVar']['OpDealStateArray'][0] : $Fn_House->Config['LangVar']['OpDealStateArray'][1]).'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Edit&did='.$Module['id'].'">'.$Fn_House->Config['LangVar']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Del&did='.$Module['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;">'.$Fn_House->Config['LangVar']['DelTitle'].'</a>',
			));
		}
		showsubmit('Submit','&#31435;&#21363;&#25552;&#20132;','<input name="optype" value="Del" class="with-gap" type="radio" id="v_del"><label class="custom-control-label" for="v_del" style="margin-left:-5px;">'.$Fn_House->Config['LangVar']['DelTitle'].'</label>&nbsp;&nbsp;<input name="optype" value="Display" class="with-gap" type="radio" id="v_display"><label class="custom-control-label" for="v_display" style="margin-left:-5px;">'.$Fn_House->Config['LangVar']['DisplayTitle'].'</label>&nbsp;<select name="new_display" class="form-control w120"><option value="">'.$Fn_House->Config['LangVar']['SelectNull'].'</option><option value="1">'.$Fn_House->Config['LangVar']['Yes'].'</option><option value="0">'.$Fn_House->Config['LangVar']['No'].'</option></select>&nbsp;&nbsp;<input name="optype" value="PaymentState" class="with-gap" type="radio" id="v_paymentState"><label class="custom-control-label" for="v_paymentState" style="margin-left:-5px;">'.$Fn_House->Config['LangVar']['PaymentState'].'</label>
		&nbsp;<select name="new_payment_state" class="form-control w120"><option value="">'.$Fn_House->Config['LangVar']['SelectNull'].'</option><option value="1">'.$Fn_House->Config['LangVar']['PaymentStateArray']['1'].'</option><option value="0">'.$Fn_House->Config['LangVar']['PaymentStateArray']['0'].'</option></select>&nbsp;&nbsp;<input name="optype" value="Deal" class="with-gap" type="radio" id="v_deal"><label class="custom-control-label" for="v_deal" style="margin-left:-5px;">'.$Fn_House->Config['LangVar']['DealState'].'</label>&nbsp;<select name="new_deal" class="form-control w120"><option value="">'.$Fn_House->Config['LangVar']['SelectNull'].'</option><option value="1">'.$Fn_House->Config['LangVar']['DealStateArray']['1'].'</option><option value="0">'.$Fn_House->Config['LangVar']['DealStateArray']['0'].'</option></select>','','select_all',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));
        showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		/* ģ����� End */
	}else{
		if(isset($_GET['delete']) && is_array($_GET['delete'])){
			if($_GET['optype'] == 'Del'){//ȫɾ
				if(!$Fn_Admin->CheckUserGroup('house_all') && !$Fn_Admin->CheckUserGroup('house_del_demand_list')){//Ȩ���ж�
					fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
					exit();
				}
				foreach($_GET['delete'] as $Key => $Val) {
					$Val = intval($Val);
					DB::delete($Fn_House->TableDemand,'id ='.$Val);
				}
				
				GetInsertDoLog('del_demand_house','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete'])));//������¼

				fn_cpmsg($Fn_House->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
			}else if($_GET['optype'] == 'Display' && in_array($_GET['new_display'],array('0','1'))){
				foreach($_GET['delete'] as $Key => $Val) {
					$Val = intval($Val);
					$UpData['display'] = intval($_GET['new_display']);
					DB::update($Fn_House->TableDemand,$UpData,'id = '.$Val);
				}
				
				GetInsertDoLog('display_demand_house','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete']),'display'=>$_GET['new_display']));//������¼

				fn_cpmsg($Fn_House->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
			}else if($_GET['optype'] == 'PaymentState' && in_array($_GET['new_payment_state'],array('0','1'))){
				foreach($_GET['delete'] as $Key => $Val) {
					$Val = intval($Val);
					$UpData['payment_state'] = intval($_GET['new_payment_state']);
					DB::update($Fn_House->TableDemand,$UpData,'id = '.$Val);
				}
				
				GetInsertDoLog('payment_state_demand_house','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete']),'payment_state'=>$_GET['new_payment_state']));//������¼

				fn_cpmsg($Fn_House->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
			}else if($_GET['optype'] == 'Deal' && in_array($_GET['new_deal'],array('0','1'))){
				foreach($_GET['delete'] as $Key => $Val) {
					$Val = intval($Val);
					$UpData['deal'] = intval($_GET['new_deal']);
					DB::update($Fn_House->TableDemand,$UpData,'id = '.$Val);
				}
				
				GetInsertDoLog('deal_demand_house','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete']),'deal'=>$_GET['new_deal']));//������¼

				fn_cpmsg($Fn_House->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
			}else{
				fn_cpmsg($Fn_House->Config['LangVar']['OpErr'],'','error');
			}
		}else{
			fn_cpmsg($Fn_House->Config['LangVar']['OpErr'],'','error');
		}
	}
}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['did']){//ɾ��
	if(!$Fn_Admin->CheckUserGroup('house_all') && !$Fn_Admin->CheckUserGroup('house_del_demand_list')){//Ȩ���ж�
		fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
		exit();
	}
	$Did = intval($_GET['did']);
	DB::delete($Fn_House->TableDemand,'id ='.$Did);
	
	GetInsertDoLog('del_demand_house','fn_'.$_GET['mod'],array('id'=>$_GET['did']));//������¼

	fn_cpmsg($Fn_House->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
}else if($Do == 'Display' && $_GET['formhash'] == formhash() && $_GET['did']){
	$Did = intval($_GET['did']);
	$UpData['display'] = intval($_GET['value']);
	DB::update($Fn_House->TableDemand,$UpData,'id = '.$Did);
	
	GetInsertDoLog('display_demand_house','fn_'.$_GET['mod'],array('id'=>$_GET['did'],'display'=>$_GET['value']));//������¼

	fn_cpmsg($Fn_House->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
}else if($Do == 'PaymentState' && $_GET['formhash'] == formhash() && $_GET['did']){
	$Did = intval($_GET['did']);
	$UpData['payment_state'] = intval($_GET['value']);
	DB::update($Fn_House->TableDemand,$UpData,'id = '.$Did);
	
	GetInsertDoLog('payment_state_demand_house','fn_'.$_GET['mod'],array('id'=>$_GET['did'],'payment_state'=>$_GET['value']));//������¼

	fn_cpmsg($Fn_House->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
}else if($Do == 'Deal' && $_GET['formhash'] == formhash() && $_GET['did']){
	$Did = intval($_GET['did']);
	$UpData['deal'] = intval($_GET['value']);
	DB::update($Fn_House->TableDemand,$UpData,'id = '.$Did);
	
	GetInsertDoLog('deal_demand_house','fn_'.$_GET['mod'],array('id'=>$_GET['did'],'deal'=>$_GET['value']));//������¼

	fn_cpmsg($Fn_House->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
}else if($Do == 'Edit'){
	if(!$Fn_Admin->CheckUserGroup('house_all') && !$Fn_Admin->CheckUserGroup('house_add_demand_list')){//Ȩ���ж�
		fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
		exit();
	}
	$Did = intval($_GET['did']);
	$Item = DB::fetch_first('SELECT * FROM '.DB::table($Fn_House->TableDemand).' where id = '.$Did);
	if($Item)$Item['param'] = unserialize($Item['param']);
	if(!submitcheck('DetailSubmit')) {
		$OpTitle = $Fn_House->Config['LangVar']['AddTitle'];
		if($Item)$OpTitle = $Fn_House->Config['LangVar']['EditTitle'];
		
		showformheader($Fn_Admin->Config['IframeItemUrl'].'&do=Edit&did='.$Did,'enctype');
		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-header', true,'with-border box-header');
		showtitle($OpTitle.'<input type="hidden" name="cp_msg_url" value="'.$CpMsgUrl.'">','class="box-title"');
		showtagfooter('div');
		showtagheader('div', 'box-body', true,'box-body');


		showsetting($Fn_House->Config['LangVar']['Title'], 'title', $Item['title'], 'text');

		showsetting($Fn_House->Config['LangVar']['NatureTo'],array('type',DyadicArray($Fn_House->Config['LangVar']['DemandTypeArray'])),$Item['type'],'mradio');

		showsetting($Fn_House->Config['LangVar']['DemandContent'],'content',$Item['content'],'textarea');

		showsetting($Fn_House->Config['LangVar']['DemandName'], 'name', $Item['name'], 'text');

		showsetting($Fn_House->Config['LangVar']['DemandMobile'], 'mobile', $Item['mobile'], 'text');

		showsetting($Fn_House->Config['LangVar']['DealState'],array('deal',DyadicArray($Fn_House->Config['LangVar']['DealStateArray'])),$Item['deal'],'mradio');

		showsetting($Fn_House->Config['LangVar']['DisplayTitle'], 'display', $Item['display'], 'radio');
		
		showsubmit('DetailSubmit','&#20445;&#23384;&#37197;&#32622;');
		showtagfooter('div');
		showtagfooter('div');
		showformfooter(); /*Dism_taobao-com*/
	}else{

		$Data['title'] = addslashes(strip_tags($_GET['title']));
		$Data['type'] = intval($_GET['type']);
		$Data['content'] = addslashes(strip_tags($_GET['content']));
		$Data['name'] = addslashes(strip_tags($_GET['name']));
		$Data['mobile'] = addslashes(strip_tags($_GET['mobile']));
		$Data['deal'] = intval($_GET['deal']);
		$Data['display'] = intval($_GET['display']);

		if($Item){
			GetInsertDoLog('edit_demand_house','fn_'.$_GET['mod'],array('id'=>$_GET['did']));//������¼
			DB::update($Fn_House->TableDemand,$Data,'id = '.$Did);
		}

		fn_cpmsg($Fn_House->Config['LangVar']['UpdateOk'],$_GET['cp_msg_url'],'succeed');
	}
}

/* �б� */
function GetModulesList($Page,$Limit,$Where=null,$Order){
	global $Fn_House;
	$FetchSql = 'SELECT D.* FROM '.DB::table($Fn_House->TableDemand).' D '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}

/* ���� */
function GetModulesCount($Where=null){
	global $Fn_House;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_House->TableDemand).' D '.$Where;
	return DB::result_first($FetchSql);//��������
}
//From: Dism_taobao_com
?>