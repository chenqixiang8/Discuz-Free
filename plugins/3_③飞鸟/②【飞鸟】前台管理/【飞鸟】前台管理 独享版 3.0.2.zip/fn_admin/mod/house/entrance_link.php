<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

showtagheader('div', 'box', true,'box');
showtagheader('div', 'box-body', true,'box-body');
showtagheader('div', 'tab-content', true,'tab-content');
showsetting($Fn_House->Config['LangVar']['PluginLink'], 'PluginLink',$Fn_House->Config['Url'], 'text');
showsetting($Fn_House->Config['LangVar']['AdminLinkArray']['25'], 'PluginLink',$Fn_House->Config['Url'].'&app=1', 'text');
showsetting($Fn_House->Config['LangVar']['AdminLinkArray']['1'], 'PluginLink',$Fn_House->Config['ListDiscUrl'], 'text');
showsetting($Fn_House->Config['LangVar']['AdminLinkArray']['2'], 'PluginLink',$Fn_House->Config['ListUrl'].'&class=1', 'text');
showsetting($Fn_House->Config['LangVar']['AdminLinkArray']['3'], 'PluginLink',$Fn_House->Config['ListUrl'].'&class=2', 'text');
showsetting($Fn_House->Config['LangVar']['AdminLinkArray']['4'], 'PluginLink',$Fn_House->Config['ListUrl'].'&class=3', 'text');
showsetting($Fn_House->Config['LangVar']['AdminLinkArray']['15'], 'PluginLink',$Fn_House->Config['ListUrl'].'&class=4', 'text');
showsetting($Fn_House->Config['LangVar']['AdminLinkArray']['17'], 'PluginLink',$Fn_House->Config['ListUrl'].'&class=5', 'text');
showsetting($Fn_House->Config['LangVar']['AdminLinkArray']['19'], 'PluginLink',$Fn_House->Config['ListUrl'].'&class=6', 'text');
showsetting($Fn_House->Config['LangVar']['AdminLinkArray']['21'], 'PluginLink',$Fn_House->Config['ListUrl'].'&class=7', 'text');
showsetting($Fn_House->Config['LangVar']['AdminLinkArray']['5'], 'PluginLink',$Fn_House->Config['DemandListUrl'], 'text');
showsetting($Fn_House->Config['LangVar']['AdminLinkArray']['6'], 'PluginLink',$Fn_House->Config['ListEntrustUrl'], 'text');
showsetting($Fn_House->Config['LangVar']['AdminLinkArray']['7'], 'PluginLink',$Fn_House->Config['EntrustUrl'], 'text');
showsetting($Fn_House->Config['LangVar']['AdminLinkArray']['8'], 'PluginLink',$Fn_House->Config['PublishUrl'].'&class=1', 'text');
showsetting($Fn_House->Config['LangVar']['AdminLinkArray']['9'], 'PluginLink',$Fn_House->Config['PublishUrl'].'&class=2', 'text');
showsetting($Fn_House->Config['LangVar']['AdminLinkArray']['10'], 'PluginLink',$Fn_House->Config['PublishUrl'].'&class=3', 'text');
showsetting($Fn_House->Config['LangVar']['AdminLinkArray']['16'], 'PluginLink',$Fn_House->Config['PublishUrl'].'&class=4', 'text');
showsetting($Fn_House->Config['LangVar']['AdminLinkArray']['18'], 'PluginLink',$Fn_House->Config['PublishUrl'].'&class=5', 'text');
showsetting($Fn_House->Config['LangVar']['AdminLinkArray']['20'], 'PluginLink',$Fn_House->Config['PublishUrl'].'&class=6', 'text');
showsetting($Fn_House->Config['LangVar']['AdminLinkArray']['22'], 'PluginLink',$Fn_House->Config['PublishUrl'].'&class=7', 'text');
showsetting($Fn_House->Config['LangVar']['AdminLinkArray']['11'], 'PluginLink',$Fn_House->Config['PublishUrl'].'&class=99', 'text');
showsetting($Fn_House->Config['LangVar']['AdminLinkArray']['12'], 'PluginLink',$Fn_House->Config['UserUrl'], 'text');
showsetting($Fn_House->Config['LangVar']['AdminLinkArray']['13'], 'PluginLink',$Fn_House->Config['CalculationUrl'], 'text');
showsetting($Fn_House->Config['LangVar']['AdminLinkArray']['14'], 'PluginLink',$Fn_House->Config['UserAgentInfoUrl'], 'text');
showsetting($Fn_House->Config['LangVar']['AdminLinkArray']['24'], 'PluginLink',$Fn_House->Config['ListAgentUrl'], 'text');
showsetting($Fn_House->Config['LangVar']['AdminLinkArray']['23'], 'PluginLink',$Fn_House->Config['ListStoreUrl'], 'text');
showsetting($Fn_House->Config['LangVar']['AdminLinkArray']['26'], 'PluginLink',$Fn_House->Config['ListArticleUrl'], 'text');
showtagfooter('div');
showtagfooter('div');
showtagfooter('div');

?>