<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('house_all') && !$Fn_Admin->CheckUserGroup('house_report_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$Do = in_array($_GET['do'], array('Del','State')) ? $_GET['do'] : 'List';

//�����ֶ�
$SearField =array('page','keyword','iid','state','order');
foreach($SearField as $Val) {
	$SearArray[$Val] = $_GET[$Val] || in_array($_GET[$Val],array('0')) ? $_GET[$Val] : '';
}
//�����ֶ� End

$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeItemUrl'].'&'.http_build_query($SearArray);

if($Do == 'List'){
	if(!submitcheck('Submit')) {
		$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
		/* ��ѯ���� */
		$Where = '';
		$Order = in_array($_GET['order'], array('id')) ? 'R.'.addslashes(dhtmlspecialchars($_GET['order'])) : 'R.id';

		if($_GET['keyword']){
			$_GET['keyword'] = str_replace(array('%','_'),array('',''),$_GET['keyword']);
			$Where .= ' and (R.username like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or R.content like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or R.uid = '.intval($_GET['keyword']).' )';
		}

		if($_GET['iid']){
			$Where .= ' and R.iid = '.intval($_GET['iid']);
		}

		if(in_array($_GET['state'],array('0','1'))){
			$Where .= ' and R.state = '.intval($_GET['state']);
		}
		
		$Where = preg_replace('/and/','where',$Where,1);
		$Limit = 30;
		$Page = $_GET['page']?intval($_GET['page']):1;
		/* ��ѯ���� End */
		/* ģ����� */	
		showtagheader('div', 'row', true,'row');
		showtagheader('div', 'col-12', true,'col-12');
		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-body', true,'box-body');
		/* ���� */
		$StateSelected = array($_GET['state']=>' selected');
		echo <<<SEARCH
		<form method="post" autocomplete="off" action="$SearUrl" id="tb_search">
			<div class="FormSearchTo">
				<table cellspacing="4" cellpadding="4">
					<tr>
						<th>{$Fn_House->Config['LangVar']['KeywordTitle']}</th><td><input type="text" class="form-control w150" name="keyword" value="{$_GET['keyword']}">
						</td>
						<th>&#20449;&#24687;&#73;&#68;</th><td><input type="text" class="form-control w150" name="iid" value="{$_GET['iid']}">
						</td>
						<th>{$Fn_House->Config['LangVar']['StateTitle']}</th><td>
						<select name="state" class="form-control w120">
							<option value="">{$Fn_House->Config['LangVar']['SelectNull']}</option>
							<option value="0"{$StateSelected['0']}>{$Fn_House->Config['LangVar']['ReportStateArray'][0]}</option>
							<option value="1"{$StateSelected['1']}>{$Fn_House->Config['LangVar']['ReportStateArray'][1]}</option>
						</select>
						&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Admin->Config['LangVar']['SearchSubmit']}" class="btn btn-info" type="submit">
					</tr>
				</table>
			</div>
		</form>
SEARCH;
		/* ���� End */
		showtagheader('div', 'table-responsive', true,'table-responsive');
		showformheader($FormUrl,'enctype="multipart/form-data"');
		showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
		showsubtitle(array(
			'ID',
			$Fn_House->Config['LangVar']['ReportPeople'],
			$Fn_House->Config['LangVar']['CoverReportHouse'],
			$Fn_House->Config['LangVar']['Content'],
			$Fn_House->Config['LangVar']['StateTitle'],
			$Fn_House->Config['LangVar']['TimeTitle'],
			$Fn_House->Config['LangVar']['HandleTime'],
			$Fn_House->Config['LangVar']['OperationTitle']
		), 'header tbm tc');
		
		$ModulesList = GetModulesList($Page,$Limit,$Where,$Order);
		
		foreach ($ModulesList as $Module) {
			showtablerow('', array('class="tc w100"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
				'<input type="checkbox" class="filled-in" id="checkbox_'.$Module['id'].'" name="delete[]" value="'.$Module['id'].'"><label for="checkbox_'.$Module['id'].'">'.$Module['id'].'</label>',
				$Module['uid'] ? $Module['uid'].'/'.$Module['username'] : '',
				'<a href="'.$Fn_House->Config['ViewUrl'].$Module['iid'].'" target="_blank">'.$Module['title'].'</a>',
				$Module['content'],
				$Module['state'] ? '<span class="label bg-blue">'.$Fn_House->Config['LangVar']['ReportStateArray'][$Module['state']].'</span>' : '<span class="label bg-danger">'.$Fn_House->Config['LangVar']['ReportStateArray'][$Module['state']].'</span>',
				date('Y-m-d H:i',$Module['dateline']),
				$Module['handle_dateline'] ? date('Y-m-d H:i',$Module['handle_dateline']) : '',
				'&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeModUrl'].'&item=info_list&submodel=list&iid='.$Module['iid'].'" class="btn btn-sm btn-dark-outline">&#31649;&#29702;&#25151;&#28304;</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=State&rid='.$Module['id'].'&value='.(!empty($Module['state']) ? 0:1).'&formhash='.FORMHASH.'" class="btn btn-sm btn-info-outline">'.(!empty($Module['state']) ? $Fn_House->Config['LangVar']['OpReportStateArray'][0] : $Fn_House->Config['LangVar']['OpReportStateArray'][1]).'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Del&rid='.$Module['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$Fn_House->Config['LangVar']['DelTitle'].'</a>',
			));
		}
		showsubmit('Submit','&#31435;&#21363;&#25552;&#20132;','<input name="optype" value="Del" class="with-gap" type="radio" id="v_del"><label class="custom-control-label" for="v_del" style="margin-left:-5px;">'.$Fn_House->Config['LangVar']['DelTitle'].'</label>&nbsp;&nbsp;<input name="optype" value="State" class="with-gap" type="radio" id="v_state"><label class="custom-control-label" for="v_state">'.$Fn_House->Config['LangVar']['StateTitle'].'</label>&nbsp;<select name="statenew" class="form-control w120"><option value="">'.$Fn_House->Config['LangVar']['SelectNull'].'</option><option value="1">'.$Fn_House->Config['LangVar']['OpReportStateArray'][1].'</option><option value="0">'.$Fn_House->Config['LangVar']['OpReportStateArray'][0].'</option></select>','','select_all',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));
		showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		/* ģ����� End */
	}else{
		if(isset($_GET['delete']) && is_array($_GET['delete'])){
			if($_GET['optype'] == 'Del'){//ȫɾ
				if(!$Fn_Admin->CheckUserGroup('house_all') && !$Fn_Admin->CheckUserGroup('house_del_report')){//Ȩ���ж�
					fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
					exit();
				}
				foreach($_GET['delete'] as $Key => $Val) {
					$Val = intval($Val);
					DB::delete($Fn_House->TableInfoReport,'id ='.$Val);
				}
				
				GetInsertDoLog('del_report_house','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete'])));//������¼

				fn_cpmsg($Fn_House->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
			}else if($_GET['optype'] == 'State' && in_array($_GET['statenew'],array('0','1'))){
				foreach($_GET['delete'] as $Key => $Val) {
					$Val = intval($Val);
					$UpData['state'] = intval($_GET['statenew']);
					$UpData['handle_dateline'] = time();
					DB::update($Fn_House->TableInfoReport,$UpData,'id = '.$Val);
				}
				
				GetInsertDoLog('state_report_house','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete']),'state'=>$_GET['statenew']));//������¼

				fn_cpmsg($Fn_House->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
			}else{
				fn_cpmsg($Fn_House->Config['LangVar']['OpErr'],'','error');
			}
		}else{
			fn_cpmsg($Fn_House->Config['LangVar']['OpErr'],'','error');
		}
	}
}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['rid']){//ɾ��
	if(!$Fn_Admin->CheckUserGroup('house_all') && !$Fn_Admin->CheckUserGroup('house_del_report')){//Ȩ���ж�
		fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
		exit();
	}
	$Rid = intval($_GET['rid']);
	DB::delete($Fn_House->TableInfoReport,'id ='.$Rid);
	
	GetInsertDoLog('del_report_house','fn_'.$_GET['mod'],array('id'=>$_GET['rid']));//������¼

	fn_cpmsg($Fn_House->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
}else if($Do == 'State' && $_GET['formhash'] == formhash() && $_GET['rid']){//ɾ��
	$Rid = intval($_GET['rid']);
	$UpData['state'] = intval($_GET['value']);
	$UpData['handle_dateline'] = time();
	DB::update($Fn_House->TableInfoReport,$UpData,'id = '.$Rid);
	
	GetInsertDoLog('state_report_house','fn_'.$_GET['mod'],array('id'=>$_GET['rid'],'state'=>$_GET['value']));//������¼

	fn_cpmsg($Fn_House->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
}

/* �б� */
function GetModulesList($Page,$Limit,$Where=null,$Order){
	global $Fn_House;
	$FetchSql = 'SELECT I.title,R.* FROM '.DB::table($Fn_House->TableInfoReport).' R LEFT JOIN `'.DB::table($Fn_House->TableInfo).'` I on I.id = R.iid '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}

/* ���� */
function GetModulesCount($Where=null){
	global $Fn_House;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_House->TableInfoReport).' R '.$Where;
	return DB::result_first($FetchSql);//��������
}
//From: Dism_taobao_com
?>