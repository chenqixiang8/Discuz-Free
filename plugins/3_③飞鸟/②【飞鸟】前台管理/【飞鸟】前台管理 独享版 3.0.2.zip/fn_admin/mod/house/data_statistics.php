<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

//Ȩ���ж�
if(!$Fn_Admin->CheckUserGroup('house_all') && !$Fn_Admin->CheckUserGroup('house_data_statistics')){
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}


$Timestamp = strtotime(date('Y-m-d'));
$WeekDay = strtotime(date('Y-m-d',$Timestamp - (date('N',$Timestamp)-1) * 86400));//���ܵ�һ��
$EndWeekDay = strtotime(date('Y-m-d 23:59:59',strtotime("+6 day",$WeekDay)));

$FirstDay = strtotime(date('Y-m-01', strtotime(date("Y-m-d"))));//���µ�һ��  
$LastDay = strtotime(date('Y-m-d 23:59:59', strtotime("+1 month -1 day",$FirstDay)));//�������һ�� 

$LastLasDday = strtotime(date('Y-m-01', strtotime('-1 month',$FirstDay)));//�ϸ��µ�һ��  
$LastFirstDay = strtotime(date('Y-m-t 23:59:59', strtotime('-1 month',$FirstDay)));//�ϸ������һ��


$DayInfoCount = DB::result_first('SELECT COUNT(*) FROM '.DB::table($Fn_House->TableInfo).' where display = 1 and payment_state = 1 and dateline >= '.strtotime(date('Y-m-d')).' and dateline <='.strtotime(date('Y-m-d 23:59:59')));

$InfoCount = DB::result_first('SELECT COUNT(*) FROM '.DB::table($Fn_House->TableInfo).' where display = 1 and payment_state = 1');

$AgentUserCount = DB::result_first('SELECT COUNT(*) FROM '.DB::table($Fn_House->TableAgentUser));

$VipAgentUserCount = DB::result_first('SELECT COUNT(*) FROM '.DB::table($Fn_House->TableAgentUser).' where work_state = 1 and due_time >= '.time());

$DiscCount = DB::result_first('SELECT COUNT(*) FROM '.DB::table($Fn_House->TableDisc).' where display = 1');

//����ͳ��
$MonthCountMoney = GetModulesScreenMoneyCount('where source = \'fn_house\' and L.refund = 0 and L.state = 1 and L.dateline >= '.$FirstDay.' and L.dateline <='.$LastDay);

$LastMonthCountMoney = GetModulesScreenMoneyCount('where source = \'fn_house\' and L.refund = 0 and L.state = 1 and L.dateline >= '.$LastLasDday.' and L.dateline <='.$LastFirstDay);

$TodayCountMoney = GetModulesScreenMoneyCount('where source = \'fn_house\' and L.refund = 0 and L.state = 1 and L.dateline >= '.strtotime(date('Y-m-d')).' and L.dateline <='.strtotime(date('Y-m-d 23:59:59')));

$WeekCountMoney = GetModulesScreenMoneyCount('where source = \'fn_house\' and L.refund = 0 and L.state = 1 and L.dateline >= '.$WeekDay.' and L.dateline <='.$EndWeekDay);

$CountMoney = GetModulesScreenMoneyCount('where source = \'fn_house\' and L.refund = 0 and L.state = 1 ');

for($i = 1;$i < 13; $i++){
	$k = $i;
	$YearMonthLast = strtotime(date('Y').'-'.($i > 9 ? $i : '0'.$i).'-01'); 
	$YearMonthFirst = strtotime(date('Y-m-d 23:59:59', strtotime("+1 month -1 day",$YearMonthLast)));
	$YearMonthCount[$k -1]['m'] = date('Y').'-'.($i > 9 ? $i : '0'.$i);
	$YearMonthCount[$k -1]['item'] = GetModulesScreenMoneyCount('where source = \'fn_house\' and L.refund = 0 and L.state = 1 and L.dateline >= '.$YearMonthLast.' and L.dateline <='.$YearMonthFirst);
	
	$LastYearMonthCount[$k -1]['m'] = (date('Y') - 1).'-'.($i > 9 ? $i : '0'.$i);
	$LastYearMonthCount[$k -1]['item'] = GetModulesScreenMoneyCount('where source = \'fn_house\' and L.refund = 0 and L.state = 1 and L.dateline >= '.strtotime('-1 year',$YearMonthLast).' and L.dateline <='.strtotime('-1 year',$YearMonthFirst));
}
$YearMonthCountJson = json_encode($YearMonthCount);
$LastMonthCountJson = json_encode($LastYearMonthCount);

echo <<<TABLE
<div class="row">
  <div class="col-12">
    <div class="box">
      <div class="box-body">
        <div class="flexbox">
          <h5>&#23454;&#26102;&#25968;&#25454;</h5>
        </div>
        <div class="row">
          <div class="col-sm-6 col-lg-20">
            <div class="box-body">
              <div class="font-size-40 font-weight-200">{$DayInfoCount}</div>
              <div>&#20170;&#26085;&#25151;&#28304;&#25968;</div>
            </div>
          </div>
          <div class="col-sm-6 col-lg-20">
            <div class="box-body">
              <div class="font-size-40 font-weight-200">{$InfoCount}</div>
              <div>&#25151;&#28304;&#24635;&#25968;</div>
            </div>
          </div>
          <div class="col-sm-6 col-lg-20">
            <div class="box-body">
              <div class="font-size-40 font-weight-200">{$AgentUserCount}</div>
              <div>&#20013;&#20171;&#24635;&#25968;</div>
            </div>
          </div>
          <div class="col-sm-6 col-lg-20">
            <div class="box-body">
              <div class="font-size-40 font-weight-200">{$VipAgentUserCount}</div>
              <div>&#20013;&#20171;&#86;&#73;&#80;&#24635;&#25968;</div>
            </div>
          </div>
          <div class="col-sm-6 col-lg-20">
            <div class="box-body">
              <div class="font-size-40 font-weight-200">{$DiscCount}</div>
              <div>&#27004;&#30424;&#24635;&#25968;</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- /.col -->
</div>

<div class="row">
  <div class="col-md-6 col-lg-20">
    <div class="box">
      <div class="box-body">
        <div class="flexbox">
          <h5>&#20170;&#26085;&#20805;&#20540;&#37329;&#39069;</h5>
        </div>
        <div class="text-center my-2">
          <div class="font-size-50">{$TodayCountMoney}</div>
          <span class="text-muted">&#20803;</span> </div>
      </div>
      <div class="card-body bg-gray-light py-12"> <span class="text-muted mr-1"> Top up today</span></div>
    </div>
  </div>
  <!-- /.col -->
  <div class="col-md-6 col-lg-20">
    <div class="box">
      <div class="box-body">
        <div class="flexbox">
          <h5>&#26412;&#21608;&#20805;&#20540;&#37329;&#39069;</h5>
        </div>
        <div class="text-center my-2">
          <div class="font-size-50">{$WeekCountMoney}</div>
          <span class="text-muted">&#20803;</span> </div>
      </div>
      <div class="box-body bg-gray-light py-12"> <span class="text-muted mr-1">Recharge amount this week</span> </div>
    </div>
  </div>
  <!-- /.col -->
  <div class="col-md-6 col-lg-20">
    <div class="box">
      <div class="box-body">
        <div class="flexbox">
          <h5>&#26412;&#26376;&#20805;&#20540;&#37329;&#39069;</h5>
        </div>
        <div class="text-center my-2">
          <div class="font-size-50">{$MonthCountMoney}</div>
          <span class="text-muted">&#20803;</span> </div>
      </div>
      <div class="box-body bg-gray-light py-12"> <span class="text-muted mr-1">Recharge amount of this month</span> </div>
    </div>
  </div>
  <!-- /.col -->
  <div class="col-md-6 col-lg-20">
    <div class="box">
      <div class="box-body">
        <div class="flexbox">
          <h5>&#19978;&#26376;&#20805;&#20540;&#37329;&#39069;</h5>
        </div>
        <div class="text-center my-2">
          <div class="font-size-50">{$LastMonthCountMoney}</div>
          <span class="text-muted">&#20803;</span> </div>
      </div>
      <div class="box-body bg-gray-light py-12"> <span class="text-muted mr-1">Top up amount of last month</span> </div>
    </div>
  </div>
  <!-- /.col -->
  <div class="col-md-6 col-lg-20">
    <div class="box">
      <div class="box-body">
        <div class="flexbox">
          <h5>&#24635;&#20805;&#20540;&#37329;&#39069;</h5>
        </div>
        <div class="text-center my-2">
          <div class="font-size-50">{$CountMoney}</div>
          <span class="text-muted">&#20803;</span> </div>
      </div>
      <div class="box-body bg-gray-light py-12"> <span class="text-muted mr-1">Total recharge amount</span> </div>
    </div>
  </div>
  <!-- /.col -->
</div>
<div class="row">
  <div class="col-xl-6 col-12">
    <div class="box">
      <div class="box-header with-border">
        <h3 class="box-title">&#20170;&#24180;&#26376;&#20221;&#25910;&#20837;</h3>
        <div class="box-tools pull-right">
          <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i> </button>
          <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
        </div>
      </div>
      <div class="box-body chart-responsive">
        <div class="chart" id="this-year" style="height: 300px;"></div>
      </div>
      <!-- /.box-body -->
    </div>
    <!-- /.box -->
  </div>
  <div class="col-xl-6 col-12">
    <div class="box">
      <div class="box-header with-border">
        <h3 class="box-title">&#21435;&#24180;&#26376;&#20221;&#25910;&#20837;</h3>
        <div class="box-tools pull-right">
          <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i> </button>
          <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
        </div>
      </div>
      <div class="box-body chart-responsive">
        <div class="chart" id="last-year" style="height: 300px;"></div>
      </div>
      <!-- /.box-body -->
    </div>
    <!-- /.box -->
  </div>
</div>
<script>
	var line = new Morris.Line({
		element: 'this-year',
		resize: true,
		data:{$YearMonthCountJson},
		xkey: 'm',
		ykeys: ['item'],
		labels: ['&#37329;&#39069;'],
		lineWidth:2,
		pointFillColors: ['rgba(30,136,229,1)'],
		lineColors: ['rgba(30,136,229,1)'],
		hideHover: 'auto'
    });

	var line = new Morris.Line({
		element: 'last-year',
		resize: true,
		data:{$LastMonthCountJson},
		xkey: 'm',
		ykeys: ['item'],
		labels: ['&#37329;&#39069;'],
		lineWidth:2,
		pointFillColors: ['rgba(30,136,229,1)'],
		lineColors: ['rgba(30,136,229,1)'],
		hideHover: 'auto'
    });
</script>

TABLE;

/* ɸѡ���� */
function GetModulesScreenMoneyCount($Where=null){
	global $Fn_House;
	$SumCount = DB::result_first('SELECT sum(L.money) FROM '.DB::table($Fn_House->Pay->TablePayLog).' L '.$Where);
	return $SumCount ? $SumCount : 0;//��������
}
//From: Dism_taobao_com
?>