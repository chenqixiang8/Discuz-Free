<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('house_all') && !$Fn_Admin->CheckUserGroup('house_entrust_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$Do = in_array($_GET['do'], array('Del','State')) ? $_GET['do'] : 'List';

//�����ֶ�
$SearField =array('page','keyword','class','state','order');
foreach($SearField as $Val) {
	$SearArray[$Val] = $_GET[$Val] || in_array($_GET[$Val],array('0')) ? $_GET[$Val] : '';
}
//�����ֶ� End

$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeItemUrl'].'&'.http_build_query($SearArray);

if($Do == 'List'){
	if(!submitcheck('Submit')) {
		$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
		/* ��ѯ���� */
		$Where = '';
		$Order = in_array($_GET['order'], array('id')) ? 'E.'.addslashes(dhtmlspecialchars($_GET['order'])) : 'E.id';

		if($_GET['keyword']){
			$_GET['keyword'] = str_replace(array('%','_'),array('',''),$_GET['keyword']);
			$Where .= ' and (E.username like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or E.mobile = \''.addslashes(strip_tags($_GET['keyword'])).'\' or E.uid = '.intval($_GET['keyword']).' )';
		}
		
		if($_GET['class']){
			$Where .= ' and E.class = '.intval($_GET['class']);
		}

		if(in_array($_GET['state'],array('0','1'))){
			$Where .= ' and E.state = '.intval($_GET['state']);
		}
		
		$Where = preg_replace('/and/','where',$Where,1);
		$Limit = 30;
		$Page = $_GET['page']?intval($_GET['page']):1;
		/* ��ѯ���� End */
	
		/* ģ����� */		
		showtagheader('div', 'row', true,'row');
		showtagheader('div', 'col-12', true,'col-12');
		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-body', true,'box-body');
		/* ���� */
		$ClassSelected = array($_GET['class']=>' selected');
		$StateSelected = array($_GET['state']=>' selected');
		echo <<<SEARCH
		<form method="post" autocomplete="off" action="$SearUrl" id="tb_search">
			<div class="FormSearchTo">
				<table cellspacing="4" cellpadding="4">
					<tr>
						<th>{$Fn_House->Config['LangVar']['KeywordTitle']}</th><td><input type="text" class="form-control w150" name="keyword" value="{$_GET['keyword']}">
						</td>
						<th>{$Fn_House->Config['LangVar']['Type']}</th><td>
						<select name="class" class="form-control w120">
							<option value="">{$Fn_House->Config['LangVar']['SelectNull']}</option>
							<option value="1"{$ClassSelected['1']}>{$Fn_House->Config['LangVar']['IndexNav'][1]}</option>
							<option value="2"{$ClassSelected['2']}>{$Fn_House->Config['LangVar']['IndexNav'][2]}</option>
							<option value="3"{$ClassSelected['3']}>{$Fn_House->Config['LangVar']['IndexNav'][3]}</option>
						</select>
						</td>
						<th>{$Fn_House->Config['LangVar']['StateTitle']}</th><td>
						
						<select name="state" class="form-control w120">
							<option value="">{$Fn_House->Config['LangVar']['SelectNull']}</option>
							<option value="0"{$StateSelected['0']}>{$Fn_House->Config['LangVar']['ReportStateArray'][0]}</option>
							<option value="1"{$StateSelected['1']}>{$Fn_House->Config['LangVar']['ReportStateArray'][1]}</option>
						</select>
						&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Admin->Config['LangVar']['SearchSubmit']}" class="btn btn-info" type="submit">
					</tr>
				</table>
			</div>
		</form>
SEARCH;
		/* ���� End */
		showtagheader('div', 'table-responsive', true,'table-responsive');
		showformheader($FormUrl,'enctype="multipart/form-data"');
		showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
		showsubtitle(array(
			'ID',
			'Uid/'.$Fn_House->Config['LangVar']['UserNameTitle'],
			$Fn_House->Config['LangVar']['Contacts'],
			$Fn_House->Config['LangVar']['Mobile'],
			$Fn_House->Config['LangVar']['WxTitle'],
			$Fn_House->Config['LangVar']['Type'],
			$Fn_House->Config['LangVar']['Community'],
			$Fn_House->Config['LangVar']['Square'],
			$Fn_House->Config['LangVar']['Offer'],
			$Fn_House->Config['LangVar']['StateTitle'],
			$Fn_House->Config['LangVar']['TimeTitle'],
			$Fn_House->Config['LangVar']['HandleTime'],
			$Fn_House->Config['LangVar']['OperationTitle']
		), 'header tbm tc');
		
		$ModulesList = GetModulesList($Page,$Limit,$Where,$Order);
		
		foreach ($ModulesList as $Module) {
			$ids[] = $Module['id'];
			$Module['param'] = unserialize($Module['param']);
			showtablerow('', array('class="tc w100"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
				'<input type="checkbox" class="filled-in" id="checkbox_'.$Module['id'].'" name="delete[]" value="'.$Module['id'].'"><label for="checkbox_'.$Module['id'].'">'.$Module['id'].'</label>',
				$Module['uid'] ? $Module['uid'].'/'.$Module['username'] : '',
				$Module['name'],
				$Module['mobile'],
				$Module['wx'],
				$Fn_House->Config['LangVar']['IndexNav'][$Module['class']],
				$Module['address'],
				$Module['square'],
				$Module['price'].( $Module['class'] == 2 ? $Fn_House->Config['LangVar']['Yuan'].'/'.$Fn_House->Config['LangVar']['RentTimeArray'][$Module['param']['price_time']] : $Fn_House->Config['LangVar']['WanYuan']),
				$Module['state'] ? '<span class="label bg-blue">'.$Fn_House->Config['LangVar']['ReportStateArray'][$Module['state']].'</span>' : '<span class="label bg-danger">'.$Fn_House->Config['LangVar']['ReportStateArray'][$Module['state']].'</span>',
				date('Y-m-d H:i',$Module['dateline']),
				$Module['handle_dateline'] ? date('Y-m-d H:i',$Module['handle_dateline']) : '',
				'&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=State&eid='.$Module['id'].'&value='.(!empty($Module['state']) ? 0:1).'&formhash='.FORMHASH.'" class="btn btn-sm btn-info-outline">'.(!empty($Module['state']) ? $Fn_House->Config['LangVar']['OpReportStateArray'][0] : $Fn_House->Config['LangVar']['OpReportStateArray'][1]).'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Del&eid='.$Module['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$Fn_House->Config['LangVar']['DelTitle'].'</a>',
			));
		}
		showsubmit('Submit','&#31435;&#21363;&#25552;&#20132;','<input name="optype" value="Del" class="with-gap" type="radio" id="v_del"><label class="custom-control-label" for="v_del" style="margin-left:-5px;">'.$Fn_House->Config['LangVar']['DelTitle'].'</label>&nbsp;&nbsp;<input name="optype" value="State" class="with-gap" type="radio" id="v_state"><label class="custom-control-label" for="v_state">'.$Fn_House->Config['LangVar']['StateTitle'].'</label>&nbsp;<select name="statenew" class="form-control w120"><option value="">'.$Fn_House->Config['LangVar']['SelectNull'].'</option><option value="1">'.$Fn_House->Config['LangVar']['OpReportStateArray'][1].'</option><option value="0">'.$Fn_House->Config['LangVar']['OpReportStateArray'][0].'</option></select>','','select_all',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));
        showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		/* ģ����� End */
	}else{
		if(isset($_GET['delete']) && is_array($_GET['delete'])){
			if($_GET['optype'] == 'Del'){//ȫɾ
				if(!$Fn_Admin->CheckUserGroup('house_all') && !$Fn_Admin->CheckUserGroup('house_del_entrust')){//Ȩ���ж�
					fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
					exit();
				}
				foreach($_GET['delete'] as $Key => $Val) {
					$Val = intval($Val);
					DB::delete($Fn_House->TableEntrust,'id ='.$Val);
				}
				
				GetInsertDoLog('del_entrust_house','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete'])));//������¼

				fn_cpmsg($Fn_House->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
			}else if($_GET['optype'] == 'State' && in_array($_GET['statenew'],array('0','1'))){
				foreach($_GET['delete'] as $Key => $Val) {
					$Val = intval($Val);
					$UpData['state'] = intval($_GET['statenew']);
					$UpData['handle_dateline'] = time();
					DB::update($Fn_House->TableEntrust,$UpData,'id = '.$Val);
				}
				
				GetInsertDoLog('state_entrust_house','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete']),'state'=>$_GET['statenew']));//������¼

				fn_cpmsg($Fn_House->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
			}else{
				fn_cpmsg($Fn_House->Config['LangVar']['OpErr'],'','error');
			}
		}else{
			fn_cpmsg($Fn_House->Config['LangVar']['OpErr'],'','error');
		}
	}
}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['eid']){//ɾ��
	if(!$Fn_Admin->CheckUserGroup('house_all') && !$Fn_Admin->CheckUserGroup('house_del_entrust')){//Ȩ���ж�
		fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
		exit();
	}
	$Eid = intval($_GET['eid']);
	DB::delete($Fn_House->TableEntrust,'id ='.$Eid);
	
	GetInsertDoLog('del_entrust_house','fn_'.$_GET['mod'],array('id'=>$_GET['eid']));//������¼

	fn_cpmsg($Fn_House->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
}else if($Do == 'State' && $_GET['formhash'] == formhash() && $_GET['eid']){//ɾ��
	$Eid = intval($_GET['eid']);
	$UpData['state'] = intval($_GET['value']);
	$UpData['handle_dateline'] = time();
	DB::update($Fn_House->TableEntrust,$UpData,'id = '.$Eid);
	
	GetInsertDoLog('state_entrust_house','fn_'.$_GET['mod'],array('id'=>$_GET['eid'],'state'=>$_GET['value']));//������¼

	fn_cpmsg($Fn_House->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
}

/* �б� */
function GetModulesList($Page,$Limit,$Where=null,$Order){
	global $Fn_House;
	$FetchSql = 'SELECT E.* FROM '.DB::table($Fn_House->TableEntrust).' E '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}

/* ���� */
function GetModulesCount($Where=null){
	global $Fn_House;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_House->TableEntrust).' E '.$Where;
	return DB::result_first($FetchSql);//��������
}
//From: Dism_taobao_com
?>