<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('house_all') && !$Fn_Admin->CheckUserGroup('house_agent_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$SubModel = in_array($_GET['submodel'], array('list','add')) ? $_GET['submodel'] : 'list';
$Fn_Admin->Config['IframeSubModelUrl'] = $Fn_Admin->Config['IframeItemUrl'].'&submodel='.$SubModel;
$NavClass = array($SubModel=>'btn-info Hover');

//����
echo <<<Nav
<div class="SubModelNav">
  <ul>
	<li class="{$NavClass['list']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=list" target="_self">{$Fn_Admin->Config['LangVar']['HouseLeftNavArray']['agent_list']}</a></li>
    <li class="{$NavClass['add']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=add" target="_self">{$Fn_Admin->Config['LangVar']['AddEditTitle']}</a></li>
  </ul>
  <div class="both"></div>
</div>
Nav;

if($SubModel == 'list'){//�б�
	$Do = in_array($_GET['do'], array('Refresh','Del','Display','PaymentState')) ? $_GET['do'] : 'submodel_list';
	//�����ֶ�
	$SearField =array('page','keyword','display');
	foreach($SearField as $Val) {
		$SearArray[$Val] = $_GET[$Val] || in_array($_GET[$Val],array('0')) ? $_GET[$Val] : '';
	}
	//�����ֶ� End
	$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeSubModelUrl'].'&'.http_build_query($SearArray);


	if($Do == 'submodel_list'){
		if(!submitcheck('Submit')) {
			$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
			$Where = '';
			$Order = in_array($_GET['order'], array('id')) ? 'A.'.addslashes(dhtmlspecialchars($_GET['order'])) : 'A.id';
			
			if($_GET['keyword']){
				$_GET['keyword'] = str_replace(array('%','_'),array('',''),$_GET['keyword']);
				$Where .= ' and (A.title like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or A.username like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or A.id = '.intval($_GET['keyword']).' )';
			}

			if($_GET['group_id']){
				$Where .= ' and A.group_id = '.intval($_GET['group_id']);
			}

			if(in_array($_GET['display'],array('0','1'))){
				$Where .= ' and A.display = '.intval($_GET['display']);
			}

			/*if(in_array($_GET['payment_state'],array('0','1'))){
				$Where .= ' and A.payment_state = '.intval($_GET['payment_state']);
			}*/

			$Where = preg_replace('/and/','where',$Where,1);
			
			$Limit = 20;
			$Page = $_GET['page']?intval($_GET['page']):1;
			/* ��ѯ���� End */
			/* ģ����� */
			showtagheader('div', 'row', true,'row');
			showtagheader('div', 'col-12', true,'col-12');
			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-body', true,'box-body');
			/* ���� */
			$DisplaySelected = array($_GET['display']=>' selected');
			$PaymentStateSelected = array($_GET['payment_state']=>' selected');
			$GroupListOption = '<option value="">'.$Fn_House->Config['LangVar']['SelectNull'].'</option>';
			foreach($Fn_House->GetAgentGroupList() as $Val) {
				$GroupListOption .= '<option value="'.$Val['id'].'" '.($_GET['group_id'] == $Val['id'] ? ' selected' : '' ).'>'.$Val['title'].'</option>';
			}
			echo <<<SEARCH
			<form method="post" autocomplete="off" action="$SearUrl">
				<div class="FormSearchTo" style="margin-bottom:0;">
					<table cellspacing="4" cellpadding="4">
						<tr>
							<th>{$Fn_House->Config['LangVar']['KeywordTitle']}</th><td><input type="text" class="form-control w200" name="keyword" value="{$_GET['keyword']}">
							</td>
							<th>{$Fn_House->Config['LangVar']['DisplayTitle']}</th><td>
							<select name="display" class="form-control w120">
								<option value="">{$Fn_House->Config['LangVar']['SelectNull']}</option>
								<option value="1"{$DisplaySelected['1']}>{$Fn_House->Config['LangVar']['Yes']}</option>
								<option value="0"{$DisplaySelected['0']}>{$Fn_House->Config['LangVar']['No']}</option>
							</select>
							&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Admin->Config['LangVar']['SearchSubmit']}" class="btn btn-info" type="submit">
							</td>
						</tr>
					</table>
				</div>
			</form>
SEARCH;
			/* ���� End */
			showtagheader('div', 'table-responsive', true,'table-responsive');
			showformheader($FormUrl,'enctype="multipart/form-data"');
			showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
			showsubtitle(array(
				'ID',
				//'UID/'.$Fn_House->Config['LangVar']['Shopowner'],
				$Fn_House->Config['LangVar']['Title'],
				$Fn_House->Config['LangVar']['AgentRegion'],
				$Fn_House->Config['LangVar']['AgentAddress'],
				$Fn_House->Config['LangVar']['AgentTel'],
				//$Fn_House->Config['LangVar']['Level'],
				//$Fn_House->Config['LangVar']['AddTeamMembers'].$Fn_House->Config['LangVar']['Community'],
				$Fn_House->Config['LangVar']['DisplayTitle'],
				//$Fn_House->Config['LangVar']['DueTime'],
				$Fn_House->Config['LangVar']['RefreshTime'],
				$Fn_House->Config['LangVar']['SetTopTime'],
				$Fn_House->Config['LangVar']['TimeTitle'],
				
				$Fn_House->Config['LangVar']['OperationTitle']
			),'header tbm tc');

			$ModulesList = $Fn_House->AgentListFormat(GetModulesList($Page,$Limit,$Where,$Order));
			foreach ($ModulesList as $Module) {
				showtablerow('', array('class="tc w50"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
					$Module['id'],
					//$Module['uid'].'/'.$Module['username'],
					$Module['title'],
					$Module['province_text'],
					$Module['community'],
					$Module['tel'],
					//$Module['group_title'],
					//'<input type="text" class="input w200" value='.$Fn_House->Config['StoreJoinUrl'].$Module['id'].' readonly>',
					!$Module['display'] ? '<span class="label bg-secondary">'.$Fn_House->Config['LangVar']['No'].'</span>' : '<span class="label bg-blue">'.$Fn_House->Config['LangVar']['Yes'].'</span>',
					//$Module['due_time'] >= time() ? date('Y-m-d',$Module['due_time']) : '',
					$Module['updateline'] ? date('Y-m-d H:i',$Module['updateline']) : '',
					$Module['topdateline'] ? date('Y-m-d H:i',$Module['topdateline']) : '',
					date('Y-m-d H:i',$Module['dateline']),
					'<a href="'.$Fn_House->Config['StoreUrl'].$Module['id'].'" target="_blank" class="btn btn-sm btn-dark-outline">'.cplang('view').'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Display&aid='.$Module['id'].'&value='.(!empty($Module['display']) ? 0:1).'&formhash='.FORMHASH.'" class="btn btn-sm btn-primary-outline">'.(!empty($Module['display']) ? $Fn_House->Config['LangVar']['DisplayNoTitle'] : $Fn_House->Config['LangVar']['DisplayIsTitle']).'</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&aid='.$Module['id'].'" class="btn btn-sm btn-info-outline">'.$Fn_House->Config['LangVar']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Refresh&aid='.$Module['id'].'&formhash='.FORMHASH.'" class="btn btn-sm btn-warning-outline">'.$Fn_House->Config['LangVar']['Refresh'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Del&aid='.$Module['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$Fn_House->Config['LangVar']['DelTitle'].'</a>',
				));
			}
			showsubmit('','','','','',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));
			showtablefooter(); /*dism��taobao��com*/
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			/* ģ�����End */	
		}
	}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['aid']){
		if(!$Fn_Admin->CheckUserGroup('house_all') && !$Fn_Admin->CheckUserGroup('house_agent_del')){//Ȩ���ж�
			fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
			exit();
		}
		$Aid = intval($_GET['aid']);
		DB::delete($Fn_House->TableAgent,'id ='.$Aid);
		
		//ɾ��������
		/*$AgentUserList = DB::fetch_all('SELECT uid FROM '.DB::table($Fn_House->TableAgentUser).' where agent_id = '.$Aid.' order by id desc',array(),'uid');//��������
		foreach($AgentUserList as $Key => $Val){
			$Uids[] = $Key;
		}
		if($Uids){
			DB::update($Fn_House->TableInfo,array('agent_id'=>''),'agent_id = '.$Aid.' and uid in('.implode(',',$Uids).')');
		}
		DB::delete($Fn_House->TableAgentUser,'agent_id ='.$Aid);*/
		//ɾ�������� End

		GetInsertDoLog('del_agent_house','fn_'.$_GET['mod'],array('id'=>$Aid));//������¼

		fn_cpmsg($Fn_Admin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
	}else if($Do == 'Display' && $_GET['formhash'] == formhash() && $_GET['aid']){
		$Aid = intval($_GET['aid']);
		$UpData['display'] = intval($_GET['value']);
		DB::update($Fn_House->TableAgent,$UpData,'id = '.$Aid);
		GetInsertDoLog('display_agent_house','fn_'.$_GET['mod'],array('id'=>$_GET['aid'],'display'=>$_GET['value']));//������¼
		fn_cpmsg($Fn_House->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

	}else if($Do == 'Refresh' && $_GET['formhash'] == formhash() && $_GET['aid']){
		$Aid = intval($_GET['aid']);
		$UpData['updateline'] = time();
		DB::update($Fn_House->TableAgent,$UpData,'id = '.$Aid);
		GetInsertDoLog('refresh_agent_house','fn_'.$_GET['mod'],array('id'=>$_GET['aid']));//������¼
		fn_cpmsg($Fn_House->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

	}/*else if($Do == 'PaymentState' && $_GET['formhash'] == formhash() && $_GET['aid']){
		$Aid = intval($_GET['aid']);
		$UpData['payment_state'] = intval($_GET['value']);
		DB::update($Fn_House->TableAgent,$UpData,'id = '.$Aid);
		GetInsertDoLog('payment_state_agent_house','fn_'.$_GET['mod'],array('id'=>$_GET['aid'],'payment_state'=>$_GET['value']));//������¼
		fn_cpmsg($Fn_House->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

	}*/
}else if($SubModel == 'add'){//���ӻ�༭
	if(!$Fn_Admin->CheckUserGroup('house_all') && !$Fn_Admin->CheckUserGroup('house_agent_add')){//Ȩ���ж�
		fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
		exit();
	}
	$Aid = intval($_GET['aid']);

	$Item = $Fn_House->GetAgentthread($Aid);

	if(!submitcheck('DetailSubmit')) {
		$OpTitle = $Fn_House->Config['LangVar']['AddTitle'];
		if($Item){
			$OpTitle = $Fn_House->Config['LangVar']['EditTitle'];
			$Item['province_text'] = $Fn_House->Area[$Item['province']]['content'].($Item['city'] ? $Fn_House->Area[$Item['city']]['content'] : '').($Item['dist'] ? $Fn_House->Area[$Item['dist']]['content'] : '');
		}
		
		//ͼƬ�ϴ�
		if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_assembly/class/class_upload.php')){
			@require_once libfile('class/upload','plugin/fn_assembly');
			$UploadConfig = fn_upload::Config();
		}
		
		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-header', true,'with-border box-header');
		showtitle($OpTitle,'class="box-title"');
		showtagfooter('div');
		showformheader($Fn_Admin->Config['IframeSubModelUrl'].'&aid='.$Aid,'enctype');
		showtagheader('div', 'box-body', true,'box-body');

		
		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_House->Config['LangVar']['AgentLogo'].':</label><div class="col-sm-9"><div class="AdminSingleUpload"><div class="PhotoControl" id="LogoPhotoControl"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';

		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_House->Config['LangVar']['StoreBanner'].':</label><div class="col-sm-9"><div class="AdminSingleUpload"><div class="PhotoControl" id="BannerPhotoControl"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';

		//showsetting($Fn_House->Config['LangVar']['Shopowner'].'UID', 'new_uid', $Item['uid'], 'text');

		showsetting($Fn_House->Config['LangVar']['AgentTitle'], 'title', $Item['title'], 'text');

		$SmallAreaPositionTreelistHtml = GetTreelistHtml($Fn_House->Area,'SmallAreaPositionList',$Item['province'],$Item['city'],$Item['dist']);

		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_House->Config['LangVar']['AgentRegion'].':</label><div class="col-sm-2"><div style="position:relative;height:40px"><input value="'.$Item['province_text'].'" class="form-control TreeList" type="text" id="SmallAreaPosition">'.$SmallAreaPositionTreelistHtml.'</div></div><div class="col-sm-7"><input type="hidden" name="province" value="'.$Item['province'].'"/><input type="hidden" name="city" value="'.$Item['city'].'"/><input type="hidden" name="dist" value="'.$Item['dist'].'"/></div></div>';
		
		
		showsetting($Fn_House->Config['LangVar']['AgentAddress'], 'community', $Item['community'], 'text');

		showsetting($Fn_House->Config['LangVar']['AgentTel'], 'tel', $Item['tel'], 'text');
		

		//$GroupList = array();
		//foreach($Fn_House->GetAgentGroupList() as $Val) {
			//$GroupList[] = array($Val['id'], $Val['title']);
		//}

		//showsetting($Fn_House->Config['LangVar']['Level'], array('group_id', $GroupList),$Item['group_id'], 'mradio');
		
		showsetting($Fn_House->Config['LangVar']['Content'], 'content', $Item['content'], 'textarea');

		
		showsetting($Fn_House->Config['LangVar']['Click'], 'click', $Item['click'], 'text');

		/*showsetting($Fn_House->Config['LangVar']['PaymentState'],array('payment_state',DyadicArray($Fn_House->Config['LangVar']['PaymentStateArray'])),$Item ? $Item['payment_state'] : 1,'mradio');*/

		showsetting($Fn_House->Config['LangVar']['DisplayTitle'], 'display', $Item ? $Item['display'] : 1, 'radio');
		
		//showsetting($Fn_House->Config['LangVar']['DueTime'], 'due_time',$Item['due_time'] ? date('Y-m-d',$Item['due_time']) : '', 'calendar');

		//showsetting($Fn_House->Config['LangVar']['BeforeDateline'], 'before_dateline',$Item['before_dateline'] ? date('Y-m-d',$Item['before_dateline']) : '', 'calendar','','',$Fn_House->Config['LangVar']['BeforeDatelineTips']);
		
		showsetting($Fn_House->Config['LangVar']['SetTopTime'], 'topdateline',$Item['topdateline'] ? date('Y-m-d H:i',$Item['topdateline']) : '', 'calendar','','','',1);
		
		if($Item['updateline']){
			showsetting($Fn_House->Config['LangVar']['RefreshTime'], 'updateline',$Item['updateline'] ? date('Y-m-d H:i',$Item['updateline']) : '', 'calendar','','','',1);
		}

		if($Item['dateline']){
			showsetting($Fn_House->Config['LangVar']['TimeTitle'], 'dateline',date('Y-m-d H:i',$Item['dateline']), 'calendar','','','',1);
		}
		
		showsubmit('DetailSubmit','&#20445;&#23384;&#37197;&#32622;');
		showtagfooter('div');
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');

		$UpLoadHtml  = '';
		if($Item['logo']){
			$LogoJsArray[] = '"'.$Item['logo'].'"';;
			$UpLoadHtml .= '
			var InputArray = new Array('.implode(',',$LogoJsArray).');
			$("#LogoPhotoControl").AppUpload({InputName:"new_face",Multiple:true,InputExist:true,InputArray:InputArray});';

		}else{
			$UpLoadHtml .= '$("#LogoPhotoControl").AppUpload({InputName:"new_face",Multiple:true});';
		}

		if($Item['banner']){
			$UpLoadHtml .= '
			var InputArray = '.json_encode($Item['banner']).';
			$("#BannerPhotoControl").AppUpload({InputName:"new_banner",InputExist:true,InputArray:InputArray});';

		}else{
			$UpLoadHtml .= '$("#BannerPhotoControl").AppUpload({InputName:"new_banner"});';
		}

		echo '<script src="source/plugin/fn_assembly/static/js/mobiscroll.custom-2.16.1.min.js"></script><link rel="stylesheet" href="source/plugin/fn_assembly/static//css/mobiscroll.custom-2.16.1.min.css">'.$UploadConfig['CssJsHtml'];
		
		echo '
			<script>
			'.$UpLoadHtml.'
			$(document).on("click","#SmallAreaPosition",function(){
				GetTreeList($(this),"SmallAreaPositionList","province","city","dist");
				return false;
			});
			</script> 	
		';

	}else{
		//$Data['uid'] = intval($_GET['new_uid']);
		$Data['title'] = addslashes(strip_tags($_GET['title']));
		$Data['province'] = addslashes(strip_tags($_GET['province']));
		$Data['city'] = addslashes(strip_tags($_GET['city']));
		$Data['dist'] = addslashes(strip_tags($_GET['dist']));
		$Data['community'] = addslashes(strip_tags($_GET['community']));
		$Data['tel'] = addslashes(strip_tags($_GET['tel']));
		$Data['group_id'] = intval($_GET['group_id']);
		$Data['content'] = addslashes(strip_tags($_GET['content']));
		/*$Data['payment_state'] = intval($_GET['payment_state']);*/
		$Data['click'] = intval($_GET['click']);
		$Data['display'] = intval($_GET['display']);
		$Data['due_time'] = $_GET['due_time'] ? strtotime($_GET['due_time']) : '';
		$Data['before_dateline'] = $_GET['before_dateline'] ? strtotime($_GET['before_dateline']) : '';
		$Data['topdateline'] = $_GET['topdateline'] ? strtotime($_GET['topdateline']) : '';

		foreach($_GET['new_face'] as $Key => $Val) {
			$_GET['new_face'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}

		foreach($_GET['new_banner'] as $Key => $Val) {
			$_GET['new_banner'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}

		$Data['logo'] = addslashes(strip_tags($_GET['new_face'][0]));
		
		$Data['banner'] = is_array($_GET['new_banner']) && isset($_GET['new_banner']) ? implode(',',$_GET['new_banner']) : '';

		if($Item){
			$Data['updateline'] = strtotime($_GET['updateline']);
			$Data['dateline'] = strtotime($_GET['dateline']);
			GetInsertDoLog('edit_agent_house','fn_'.$_GET['mod'],array('id'=>$Aid));//������¼
			DB::update($Fn_House->TableAgent,$Data,'id = '.$Aid);
		}else{
			$Data['dateline'] = $Data['updateline'] = time();
			$Id = DB::insert($Fn_House->TableAgent,$Data,true);

			//�޸ĵ�ǰ�û��ķ�Դ״̬
			DB::update($Fn_House->TableInfo,array('agent_id'=>$Id,'publish_type'=>2),'uid = '.intval($Data['uid']));

			GetInsertDoLog('add_agent_house','fn_'.$_GET['mod'],array('id'=>$Id));//������¼
	
		}
		fn_cpmsg($Fn_House->Config['LangVar']['UpdateOk'],$Fn_Admin->Config['IframeItemUrl'].'&submodel=list','succeed');
	}
}


/* �б� */
function GetModulesList($Page,$Limit,$Where=null,$Order){
	global $Fn_House;
	$FetchSql = 'SELECT A.*,AG.title as group_title  FROM '.DB::table($Fn_House->TableAgent).' A LEFT JOIN `'.DB::table($Fn_House->TableAgentGroup).'` AG on AG.id = A.group_id '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}

/* ���� */
function GetModulesCount($Where=null){
	global $Fn_House;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_House->TableAgent).' A '.$Where;
	return DB::result_first($FetchSql);//��������
}

?>