<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('house_all') && !$Fn_Admin->CheckUserGroup('house_agent_user_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$SubModel = in_array($_GET['submodel'], array('list','add')) ? $_GET['submodel'] : 'list';
$Fn_Admin->Config['IframeSubModelUrl'] = $Fn_Admin->Config['IframeItemUrl'].'&submodel='.$SubModel;
$NavClass = array($SubModel=>'btn-info Hover');

//����
echo <<<Nav
<div class="SubModelNav">
  <ul>
	<li class="{$NavClass['list']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=list" target="_self">{$Fn_Admin->Config['LangVar']['HouseLeftNavArray']['agent_user_list']}</a></li>
    <li class="{$NavClass['add']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=add" target="_self">{$Fn_Admin->Config['LangVar']['AddEditTitle']}</a></li>
  </ul>
  <div class="both"></div>
</div>
Nav;

if($SubModel == 'list'){//�б�
	$Do = in_array($_GET['do'], array('Refresh','Del','Display','PaymentState','MoveInfo')) ? $_GET['do'] : 'submodel_list';
	//�����ֶ�
	$SearField =array('page','keyword','agent_id','work_state','verify','group_id','vip','order','expired');
	foreach($SearField as $Val) {
		$SearArray[$Val] = $_GET[$Val] || in_array($_GET[$Val],array('0')) ? $_GET[$Val] : '';
	}
	//�����ֶ� End
	$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeSubModelUrl'].'&'.http_build_query($SearArray);


	if($Do == 'submodel_list'){
		if(!submitcheck('Submit')) {
			$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
			$Where = '';
			$Order = $_GET['order'] ? 'AU.'.addslashes(dhtmlspecialchars($_GET['order'])) : 'AU.id';
			
			if($_GET['keyword']){
				$_GET['keyword'] = str_replace(array('%','_'),array('',''),$_GET['keyword']);
				$Where .= ' and (AU.name like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or AU.username like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or AU.mobile like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or AU.uid = '.intval($_GET['uid']).' or AU.id = '.intval($_GET['keyword']).' )';
			}
			
			if($_GET['group_id']){
				$Where .= ' and AU.group_id = '.intval($_GET['group_id']);
			}

			if($_GET['agent_id']){
				$Where .= ' and AU.agent_id = '.intval($_GET['agent_id']);
			}

			if(in_array($_GET['vip'],array('0','1'))){
				
				$Where .= $_GET['vip'] == 1 ? ' and AU.due_time >= '.time() : ' and AU.due_time < '.time();
			}

			if(in_array($_GET['expired'],array('1'))){
				
				$Where .=  ' and AU.due_time != \'\' and AU.due_time < '.time();
			}

			if(in_array($_GET['verify'],array('0','1'))){
				$Where .= ' and AU.verify = '.intval($_GET['verify']);
			}

			if($_GET['work_state']){
				$Where .= ' and AU.work_state = '.intval($_GET['work_state']);
			}

			$Where = preg_replace('/and/','where',$Where,1);
			$Limit = 20;
			$Page = $_GET['page']?intval($_GET['page']):1;
			/* ��ѯ���� End */
			/* ģ����� */
			showtagheader('div', 'row', true,'row');
			showtagheader('div', 'col-12', true,'col-12');
			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-body', true,'box-body');
			/* ���� */
			$VipSelected = array($_GET['vip']=>' selected');
			$ExpiredSelected = array($_GET['expired']=>' selected');
			$WorkStateSelected = array($_GET['work_state']=>' selected');
			$VerifySelected = array($_GET['verify']=>' selected');
			$OrderSelected = array($_GET['order']=>' selected');
			$AgentListOption = '<option value="">'.$Fn_House->Config['LangVar']['SelectNull'].'</option>';
			foreach(DB::fetch_all('SELECT * FROM '.DB::table($Fn_House->TableAgent).' order by id desc') as $Val) {
				$AgentListOption .= '<option value="'.$Val['id'].'" '.($_GET['agent_id'] == $Val['id'] ? ' selected' : '' ).'>'.$Val['title'].'</option>';
			}

			$GroupListOption = '<option value="">'.$Fn_House->Config['LangVar']['SelectNull'].'</option>';
			foreach($Fn_House->GetAgentGroupList() as $Val) {
				$GroupListOption .= '<option value="'.$Val['id'].'" '.($_GET['group_id'] == $Val['id'] ? ' selected' : '' ).'>'.$Val['title'].'</option>';
			}

			echo <<<SEARCH
			<form method="post" autocomplete="off" action="$SearUrl">
				<div class="FormSearchTo" style="margin-bottom:0;">
					<table cellspacing="4" cellpadding="4">
						<tr>
							<th>{$Fn_House->Config['LangVar']['KeywordTitle']}</th><td><input type="text" class="form-control w200" name="keyword" value="{$_GET['keyword']}">
							</td>
							<th>{$Fn_House->Config['LangVar']['Level']}</th><td>
							<select name="group_id" class="form-control w120">
								{$GroupListOption}
							</select>
							</td>
							<th>{$Fn_House->Config['LangVar']['Store']}</th><td>
							<select name="agent_id" class="form-control w120">
								{$AgentListOption}
							</select>
							</td>

							<th>{$Fn_House->Config['LangVar']['ISVIP']}</th><td>
							
							<select name="vip" class="form-control w120">
								<option value="">{$Fn_House->Config['LangVar']['SelectNull']}</option>
								<option value="1"{$VipSelected['1']}>{$Fn_House->Config['LangVar']['Yes']}</option>
								<option value="0"{$VipSelected['0']}>{$Fn_House->Config['LangVar']['No']}</option>
							</select>						
							</td>
							<th>{$Fn_House->Config['LangVar']['ISExpired']}</th><td>
							
							<select name="expired" class="form-control w120">
								<option value="">{$Fn_House->Config['LangVar']['SelectNull']}</option>
								<option value="1"{$ExpiredSelected['1']}>{$Fn_House->Config['LangVar']['Yes']}</option>
							</select>						
							</td>

							<th>{$Fn_House->Config['LangVar']['IsVerify']}</th><td>
							
							<select name="verify" class="form-control w120">
								<option value="">{$Fn_House->Config['LangVar']['SelectNull']}</option>
								<option value="1"{$VerifySelected['1']}>{$Fn_House->Config['LangVar']['Yes']}</option>
								<option value="0"{$VerifySelected['0']}>{$Fn_House->Config['LangVar']['No']}</option>
							</select>
							</td>
							<th>{$Fn_Admin->Config['LangVar']['Order']}</th><td>
							
							<select name="order" class="form-control w120">
								<option value="dateline"{$OrderSelected['dateline']}>{$Fn_Admin->Config['LangVar']['OrderArray']['dateline']}</option>
								<option value="updateline"{$OrderSelected['updateline']}>{$Fn_Admin->Config['LangVar']['OrderArray']['updateline']}</option>
								<option value="click"{$OrderSelected['click']}>{$Fn_Admin->Config['LangVar']['OrderArray']['click']}</option>
								<option value="topdateline"{$OrderSelected['topdateline']}>{$Fn_Admin->Config['LangVar']['OrderArray']['topdateline']}</option>
							</select>
							&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Admin->Config['LangVar']['SearchSubmit']}" class="btn btn-info" type="submit">
							</td>
						</tr>
					</table>
				</div>
			</form>
SEARCH;
			/* ���� End */
			showtagheader('div', 'table-responsive', true,'table-responsive');
			showformheader($FormUrl,'enctype="multipart/form-data"');
			showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
			showsubtitle(array(
				'ID',
				$Fn_House->Config['LangVar']['Face'],
				
				'UID/'.$Fn_House->Config['LangVar']['UserNameTitle'],
				$Fn_House->Config['LangVar']['Contacts'],
				$Fn_House->Config['LangVar']['FullName'],
				$Fn_House->Config['LangVar']['IdNumber'],
				$Fn_House->Config['LangVar']['Mobile'],
				$Fn_House->Config['LangVar']['WxTitle'],
				$Fn_House->Config['LangVar']['IsVerify'],
				$Fn_House->Config['LangVar']['Level'],
				$Fn_House->Config['LangVar']['Store'],
				//$Fn_House->Config['LangVar']['Identity'],
				//$Fn_House->Config['LangVar']['StateTitle'],
				$Fn_House->Config['LangVar']['DueTime'],
				str_replace(array('{wallet_title}'),array($Fn_House->Config['PluginVar']['WalletTitle']),$Fn_House->Config['LangVar']['WalletBalance']),
				$Fn_House->Config['LangVar']['RefreshTime'],
				$Fn_House->Config['LangVar']['SetTopTime'],
				$Fn_House->Config['LangVar']['TimeTitle'],
				$Fn_House->Config['LangVar']['OperationTitle']
			),'header tbm tc');

			$ModulesList = $Fn_House->AgentListFormat(GetModulesList($Page,$Limit,$Where,$Order));
			foreach ($ModulesList as $Module) {
				showtablerow('', array('class="tc w80"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
					'<input type="checkbox" class="filled-in" id="checkbox_'.$Module['id'].'" name="delete[]" value="'.$Module['id'].'"><label for="checkbox_'.$Module['id'].'">'.$Module['id'].'</label>',
					$Module['face'] ? '<img src="'.$Module['face'].'" style="height:30px;">' : '',
					$Module['uid'].'/'.$Module['username'],
					$Module['name'],
					$Module['full_name'],
					$Module['id_number'],
					$Module['mobile'],
					$Module['wx'],
					!$Module['verify'] ? '<span class="label bg-secondary">'.$Fn_House->Config['LangVar']['No'].'</span>' : '<span class="label bg-blue">'.$Fn_House->Config['LangVar']['Yes'].'</span>',
					$Module['group_title'],
					$Module['agent_title'],
					//$Fn_House->Config['LangVar']['IdentityArray'][$Module['identity']],
					//$Fn_House->Config['LangVar']['WorkStateArray'][$Module['work_state']],
					$Module['due_time'] >= time() ? date('Y-m-d',$Module['due_time']) : ($Module['due_time'] ? '<span class="label bg-danger">'.$Fn_House->Config['LangVar']['Expired'].'</span>' : ''),
					$Module['money'],
					$Module['updateline'] ? date('Y-m-d H:i',$Module['updateline']) : '',
					$Module['topdateline'] ? date('Y-m-d H:i',$Module['topdateline']) : '',
					date('Y-m-d H:i',$Module['dateline']),
					'<a href="'.$Fn_House->Config['ViewAgentUrl'].$Module['id'].'" target="_blank" class="btn btn-sm btn-dark-outline">'.cplang('view').'</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&auid='.$Module['id'].'" class="btn btn-sm btn-info-outline">'.$Fn_House->Config['LangVar']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Refresh&auid='.$Module['id'].'&formhash='.FORMHASH.'" class="btn btn-sm btn-primary-outline">'.$Fn_House->Config['LangVar']['Refresh'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=MoveInfo&main_uid='.$Module['uid'].'" class="btn btn-sm btn-success-outline">'.$Fn_House->Config['LangVar']['MoveHouse'].'</a>'.($Module['identity'] != 1 ? '&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Del&auid='.$Module['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$Fn_House->Config['LangVar']['DelTitle'].'</a>' : ''),
				));
			}

			$vipHtml = '<input name="optype" value="vip" class="with-gap" type="radio" id="v_vip"><label class="custom-control-label" for="v_vip" style="margin-left:-5px;">&#25209;&#37327;&#35774;&#32622;&#22871;&#39184;</label>
			&nbsp;<select name="new_group_id" class="form-control w120"><option value="">'.$Fn_House->Config['LangVar']['SelectNull'].'</option>';
			foreach($Fn_House->GetAgentGroupList() as $Key => $Value) {
				$vipHtml .= '<option value="'.$Value['id'].'">'.$Value['title'].'</option>';
			}
			$vipHtml .= '</select>';

			showsubmit('Submit','&#31435;&#21363;&#25552;&#20132;',$vipHtml.'&nbsp;&nbsp;&nbsp;&nbsp;<input name="optype" value="Del" class="with-gap" type="radio" id="v_Del"><label class="custom-control-label" for="v_Del" style="margin-left:-5px;">'.$Fn_House->Config['LangVar']['DelTitle'].'</label>','','select_all',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));
			showtablefooter(); /*dism��taobao��com*/
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			/* ģ�����End */	
		}else{
			if(isset($_GET['delete']) && is_array($_GET['delete'])){
				if($_GET['optype'] == 'Del'){//ȫɾ
					if(!$Fn_Admin->CheckUserGroup('house_all') && !$Fn_Admin->CheckUserGroup('house_agent_user_del')){//Ȩ���ж�
						fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
						exit();
					}
					foreach($_GET['delete'] as $Key => $Val) {
						$Val = intval($Val);
						$Item = DB::fetch_first('SELECT * FROM '.DB::table($Fn_House->TableAgentUser).' where id = '.$Val);
							
						if($Item['identity'] != 1){
							DB::update($Fn_House->TableInfo,array('agent_id'=>'','publish_type'=>1),'agent_id = '.$Item['agent_id'].' and uid = '.intval($Item['uid']));
							DB::delete($Fn_House->TableAgentUser,'id ='.$Val);
						}
					}
					GetInsertDoLog('del_agent_user_house','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete'])));//������¼
					fn_cpmsg($Fn_House->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
				}else if($_GET['optype'] == 'vip' && $_GET['new_group_id']){
					foreach($_GET['delete'] as $Key => $Val) {
						$Val = intval($Val);
						$Item = DB::fetch_first('SELECT * FROM '.DB::table($Fn_House->TableAgentUser).' where id = '.$Val);
						$GroupItem = DB::fetch_first('SELECT * FROM '.DB::table($Fn_House->TableAgentGroup).' where id = '.intval($_GET['new_group_id']));
						$due_time = $Item['due_time'] >= time() ? strtotime("+".intval($GroupItem['group_time'])."  month",$Item['due_time']) : strtotime("+".intval($GroupItem['group_time'])."  month",time());
						DB::update($Fn_House->TableAgentUser,array('group_id'=>intval($_GET['new_group_id']),'due_time'=>$due_time),'id = '.intval($Item['id']));
					}
					fn_cpmsg($Fn_House->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
				}else{
					fn_cpmsg($Fn_House->Config['LangVar']['OpErr'],'','error');
				}
			}
		}
	}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['auid']){
		if(!$Fn_Admin->CheckUserGroup('house_all') && !$Fn_Admin->CheckUserGroup('house_agent_user_del')){//Ȩ���ж�
			fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
			exit();
		}
		$AUid = intval($_GET['auid']);
		
		//�޸ĵ�ǰ�û��ķ�Դ״̬
		$Item = DB::fetch_first('SELECT * FROM '.DB::table($Fn_House->TableAgentUser).' where id = '.$AUid);
		if($Item['identity'] != 1){
			DB::update($Fn_House->TableInfo,array('agent_id'=>'','publish_type'=>1),'agent_id = '.$Item['agent_id'].' and uid = '.intval($Item['uid']));

			DB::delete($Fn_House->TableAgentUser,'id ='.$AUid);

			GetInsertDoLog('del_agent_user_house','fn_'.$_GET['mod'],array('id'=>$AUid));//������¼
		}

		fn_cpmsg($Fn_Admin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
	}else if($Do == 'Refresh' && $_GET['formhash'] == formhash() && $_GET['auid']){
		$Auid = intval($_GET['auid']);
		$UpData['updateline'] = time();
		DB::update($Fn_House->TableAgentUser,$UpData,'id = '.$Auid);
		GetInsertDoLog('refresh_agent_user_house','fn_'.$_GET['mod'],array('id'=>$_GET['auid']));//������¼
		fn_cpmsg($Fn_House->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

	}else if($Do == 'MoveInfo' && $_GET['main_uid']){
		
		$OpTitle = $Fn_House->Config['LangVar']['MoveHouse'];

		if(!submitcheck('DetailSubmit')) {

			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-header', true,'with-border box-header');
			showtitle($OpTitle,'class="box-title"');
			showtagfooter('div');
			showformheader($Fn_Admin->Config['IframeSubModelUrl'].'&do=MoveInfo&main_uid='.$_GET['main_uid'],'enctype');
			showtagheader('div', 'box-body', true,'box-body');

			showsetting($Fn_House->Config['LangVar']['MoveHouseUid'], 'move_uid','', 'text');
			showsetting($Fn_House->Config['LangVar']['Contacts'], 'move_name','', 'text','','',$Fn_House->Config['LangVar']['MoveHouseAgentUser']);
			showsetting($Fn_House->Config['LangVar']['Mobile'], 'move_mobile','', 'text','','',$Fn_House->Config['LangVar']['MoveHouseAgentUser']);

			showsubmit('DetailSubmit','&#20445;&#23384;&#37197;&#32622;');
			showtagfooter('div');
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');
		}else{

			if(!$_GET['move_uid']){
				fn_cpmsg($Fn_Admin->Config['LangVar']['NoUidErr'],'','error');
				exit();
			}

			$Member = DB::fetch_first('SELECT username FROM '.DB::table('common_member').' where uid = '.$_GET['move_uid']);
			if(!$Member){
				fn_cpmsg($Fn_Admin->Config['LangVar']['NoUserErr'],'','error');
				exit();
			}

			$Item = DB::fetch_first('SELECT * FROM '.DB::table($Fn_House->TableAgentUser).' where uid = '.intval($_GET['move_uid']));

			if($Item){//ת�Ƶ�������
		
				foreach(DB::fetch_all('SELECT * FROM '.DB::table($Fn_House->TableInfo).' where uid = '.intval($_GET['main_uid']).' order by id desc') as $Val) {
					$Val['param'] = unserialize($Val['param']);
					$Val['param']['mobile'] = $Item['mobile'];
					DB::update($Fn_House->TableInfo,array('agent_id'=>$Item['agent_id'],'publish_type'=>2,'uid'=>$Item['uid'],'username'=>$Member['username'],'name'=>$Item['name'],'param'=>serialize($Val['param'])),' id = '.intval($Val['id']));
				}

			}else{//ת�Ƶ���ͨ�û���
				if(!$_GET['move_name']){
					fn_cpmsg($Fn_House->Config['LangVar']['DemandNamePlaceholder'],'','error');
					exit();
				}

				if(!$_GET['move_mobile']){
					fn_cpmsg($Fn_House->Config['LangVar']['DemandMobilePlaceholder'],'','error');
					exit();
				}

				foreach(DB::fetch_all('SELECT * FROM '.DB::table($Fn_House->TableInfo).' where uid = '.intval($_GET['main_uid']).' order by id desc') as $Val) {
					$Val['param'] = unserialize($Val['param']);
					$Val['param']['mobile'] = addslashes(strip_tags($_GET['move_mobile']));
					DB::update($Fn_House->TableInfo,array('agent_id'=>'','publish_type'=>1,'uid'=>intval($_GET['move_uid']),'username'=>$Member['username'],'name'=>addslashes(strip_tags($_GET['move_name'])),'param'=>serialize($Val['param'])),' id = '.intval($Val['id']));
					
				}

			}

			fn_cpmsg($Fn_House->Config['LangVar']['MoveHouseOK'],$Fn_Admin->Config['IframeSubModelUrl'],'succeed');

		}
	}
}else if($SubModel == 'add'){//���ӻ�༭
	if(!$Fn_Admin->CheckUserGroup('house_all') && !$Fn_Admin->CheckUserGroup('house_agent_user_add')){//Ȩ���ж�
		fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
		exit();
	}
	$AUid = intval($_GET['auid']);

	$Item = DB::fetch_first('SELECT * FROM '.DB::table($Fn_House->TableAgentUser).' where id = '.$AUid);

	if(!submitcheck('DetailSubmit')) {
		$OpTitle = $Fn_House->Config['LangVar']['AddTitle'];
		if($Item){
			$OpTitle = $Fn_House->Config['LangVar']['EditTitle'];
			$Item['province_text'] = $Fn_House->Area[$Item['province']]['content'].($Item['city'] ? $Fn_House->Area[$Item['city']]['content'] : '').($Item['dist'] ? $Fn_House->Area[$Item['dist']]['content'] : '');
		}
		
		//ͼƬ�ϴ�
		if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_assembly/class/class_upload.php')){
			@require_once libfile('class/upload','plugin/fn_assembly');
			$UploadConfig = fn_upload::Config();
		}
		
		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-header', true,'with-border box-header');
		showtitle($OpTitle,'class="box-title"');
		showtagfooter('div');
		showformheader($Fn_Admin->Config['IframeSubModelUrl'].'&auid='.$AUid,'enctype');
		showtagheader('div', 'box-body', true,'box-body');
		
		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_House->Config['LangVar']['AgentLogo'].':</label><div class="col-sm-9"><div class="AdminSingleUpload"><div class="PhotoControl" id="LogoPhotoControl"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';

		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_House->Config['LangVar']['qrcode'].':</label><div class="col-sm-9"><div class="AdminSingleUpload"><div class="PhotoControl" id="qrcode"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';
		
		showsetting('uid', 'uid', $Item['uid'], 'text');
		foreach(DB::fetch_all('SELECT * FROM '.DB::table($Fn_House->TableAgent).' order by id desc') as $Key => $Val) {
			if(!$Key){
				$AgentList[] = array('',$Fn_House->Config['LangVar']['SelectNullTo']);
			}
			$AgentList[] = array($Val['id'], $Val['title']);
		}
		if($AgentList){
			showsetting($Fn_House->Config['LangVar']['Store'],array('agent_id',$AgentList),$Item['agent_id'], 'select');
		}
		
		showsetting($Fn_House->Config['LangVar']['Contacts'], 'name', $Item['name'], 'text');
		showsetting($Fn_House->Config['LangVar']['FullName'], 'full_name', $Item['full_name'], 'text');
		showsetting($Fn_House->Config['LangVar']['IdNumber'], 'id_number', $Item['id_number'], 'text');
		showsetting($Fn_House->Config['LangVar']['Mobile'], 'mobile', $Item['mobile'], 'text');
		showsetting($Fn_House->Config['LangVar']['WxTitle'], 'wx', $Item['wx'], 'text');
		showsetting($Fn_House->Config['LangVar']['IsVerify'], 'verify', $Item['verify'], 'radio');
		//showsetting($Fn_House->Config['LangVar']['WorkState'],array('work_state',DyadicArray($Fn_House->Config['LangVar']['WorkStateArray'])),$Item['work_state'] ? $Item['work_state'] : 1,'mradio');

		$GroupList = array();
		
		foreach($Fn_House->GetAgentGroupList() as $Val) {
			$GroupList[] = array($Val['id'], $Val['title']);
		}

		showsetting($Fn_House->Config['LangVar']['Level'], array('group_id', $GroupList),$Item['due_time'] >= time() ? $Item['group_id'] : '', 'mradio');

		if($Fn_House->Config['PluginVar']['WalletSwitch']){
			showsetting(str_replace(array('{wallet_title}'),array($Fn_House->Config['PluginVar']['WalletTitle']),$Fn_House->Config['LangVar']['WalletBalance']), 'money', $Item['money'], 'text','','',$Fn_House->Config['LangVar']['WalletBalanceTips']);
		}else{
			echo '<input value="'.$Item['money'].'" type="hidden" name="money">';
		}

		showsetting($Fn_House->Config['LangVar']['DueTime'], 'due_time',$Item['due_time'] ? date('Y-m-d',$Item['due_time']) : '', 'calendar');

		showsetting($Fn_House->Config['LangVar']['SetTopTime'], 'topdateline',$Item['topdateline'] ? date('Y-m-d H:i',$Item['topdateline']) : '', 'calendar','','','',1);
		
		if($Item['updateline']){
			showsetting($Fn_House->Config['LangVar']['RefreshTime'], 'updateline',$Item['updateline'] ? date('Y-m-d H:i',$Item['updateline']) : '', 'calendar','','','',1);
		}

		if($Item['dateline']){
			showsetting($Fn_House->Config['LangVar']['TimeTitle'], 'dateline',date('Y-m-d H:i',$Item['dateline']), 'calendar','','','',1);
		}

		showsetting($Fn_House->Config['LangVar']['BeforeDateline'], 'before_dateline',$Item['before_dateline'] ? date('Y-m-d',$Item['before_dateline']) : '', 'calendar','','',$Fn_House->Config['LangVar']['BeforeDatelineTips']);

		showsetting($Fn_House->Config['LangVar']['Click'], 'click', $Item['click'], 'text');
		
		showsubmit('DetailSubmit','&#20445;&#23384;&#37197;&#32622;');
		showtagfooter('div');
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');

		$UpLoadHtml  = '';
		if($Item['face']){
			$LogoJsArray[] = '"'.$Item['face'].'"';;
			$UpLoadHtml .= '
			var InputArray = new Array('.implode(',',$LogoJsArray).');
			$("#LogoPhotoControl").AppUpload({InputName:"new_face",Multiple:true,InputExist:true,InputArray:InputArray});';

		}else{
			$UpLoadHtml .= '$("#LogoPhotoControl").AppUpload({InputName:"new_face",Multiple:true});';
		}

		if($Item['qr']){
			$qr_array[] = '"'.$Item['qr'].'"';;
			$UpLoadHtml .= '
			var InputArray = new Array('.implode(',',$qr_array).');
			$("#qrcode").AppUpload({InputName:"new_qr",Multiple:true,InputExist:true,InputArray:InputArray});';

		}else{
			$UpLoadHtml .= '$("#qrcode").AppUpload({InputName:"new_qr",Multiple:true});';
		}

		echo $UploadConfig['CssJsHtml'].'<script>'.$UpLoadHtml.'</script>';
		
	}else{
	
		$Data['uid'] = intval($_GET['uid']);
		$Member = DB::fetch_first('SELECT username FROM '.DB::table('common_member').' where uid = '.$Data['uid']);
		$Data['username'] = addslashes(strip_tags($Member['username']));
		$Data['agent_id'] = intval($_GET['agent_id']);

		foreach($_GET['new_face'] as $Key => $Val) {
			$_GET['new_face'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}

		foreach($_GET['new_qr'] as $Key => $Val) {
			$_GET['new_qr'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}
		
		$Data['face'] = addslashes(strip_tags($_GET['new_face'][0]));
		$Data['name'] = addslashes(strip_tags($_GET['name']));
		$Data['full_name'] = addslashes(strip_tags($_GET['full_name']));
		$Data['id_number'] = addslashes(strip_tags($_GET['id_number']));
		$Data['mobile'] = addslashes(strip_tags($_GET['mobile']));
		$Data['wx'] = addslashes(strip_tags($_GET['wx']));
		$Data['qr'] = addslashes(strip_tags($_GET['new_qr'][0]));
		$Data['verify'] = intval($_GET['verify']);
		$Data['group_id'] = intval($_GET['group_id']);
		$Data['money'] = intval($_GET['money']);
		$Data['work_state'] = 1;
		$Data['identity'] = 2;
		$Data['click'] = intval($_GET['click']);
		$Data['due_time'] = $_GET['due_time'] ? strtotime($_GET['due_time']) : '';
		$Data['before_dateline'] = $_GET['before_dateline'] ? strtotime($_GET['before_dateline']) : '';
		$Data['topdateline'] = $_GET['topdateline'] ? strtotime($_GET['topdateline']) : '';
		
		if($Member || $Item){

			DB::update($Fn_House->TableInfo,array('agent_id'=>$Data['agent_id'],'publish_type'=>2),'uid = '.intval($Data['uid']));

			if($Item){

				$Data['updateline'] = strtotime($_GET['updateline']);

				GetInsertDoLog('edit_agent_user_house','fn_'.$_GET['mod'],array('id'=>$AUid));//������¼
				DB::update($Fn_House->TableAgentUser,$Data,'id = '.$AUid);
			}else{
				$Data['identity'] = 2;
				$Data['dateline'] = $Data['updateline'] = time();
				$Id = DB::insert($Fn_House->TableAgentUser,$Data,true);
				GetInsertDoLog('add_agent_user_house','fn_'.$_GET['mod'],array('id'=>$Id));//������¼
			}
			fn_cpmsg($Fn_House->Config['LangVar']['UpdateOk'],$Fn_Admin->Config['IframeItemUrl'].'&submodel=list','succeed');
		}else{
			fn_cpmsg($Fn_House->Config['LangVar']['NoUserErr'],'','error');
			exit();
		}
	}
}


/* �б� */
function GetModulesList($Page,$Limit,$Where=null,$Order){
	global $Fn_House;
	$FetchSql = 'SELECT AU.*,A.title as agent_title,AG.title as group_title FROM '.DB::table($Fn_House->TableAgentUser).' AU LEFT JOIN `'.DB::table($Fn_House->TableAgentGroup).'` AG on AG.id = AU.group_id LEFT JOIN `'.DB::table($Fn_House->TableAgent).'` A on A.id = AU.agent_id '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}

/* ���� */
function GetModulesCount($Where=null){
	global $Fn_House;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_House->TableAgentUser).' AU '.$Where;
	return DB::result_first($FetchSql);//��������
}

?>