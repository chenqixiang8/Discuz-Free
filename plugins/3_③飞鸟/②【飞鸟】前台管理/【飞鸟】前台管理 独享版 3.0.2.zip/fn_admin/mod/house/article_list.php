<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('house_all') && !$Fn_Admin->CheckUserGroup('house_article_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$SubModel = in_array($_GET['submodel'], array('list','add','class_list')) ? $_GET['submodel'] : 'list';
$Fn_Admin->Config['IframeSubModelUrl'] = $Fn_Admin->Config['IframeItemUrl'].'&submodel='.$SubModel;
$NavClass = array($SubModel=>'btn-info Hover');

//����
echo <<<Nav
<div class="SubModelNav">
  <ul>
	<li class="{$NavClass['list']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=list" target="_self">{$Fn_Admin->Config['LangVar']['HouseLeftNavArray'][$_GET['item']]}</a></li>
	<li class="{$NavClass['class_list']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=class_list" target="_self">{$Fn_Admin->Config['LangVar']['ClassTitle']}{$Fn_Admin->Config['LangVar']['Administration']}</a></li>
    <li class="{$NavClass['add']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=add" target="_self">{$Fn_Admin->Config['LangVar']['AddEditTitle']}</a></li>
  </ul>
  <div class="both"></div>
</div>
Nav;

if($SubModel == 'list'){//�б�
	$Do = in_array($_GET['do'], array('Refresh','Del','Display','Hot','Slide')) ? $_GET['do'] : 'submodel_list';
	//�����ֶ�
	$SearField =array('page','keyword','display','classid','disc_id','order','slide','hot');
	foreach($SearField as $Val) {
		$SearArray[$Val] = $_GET[$Val] || in_array($_GET[$Val],array('0')) ? $_GET[$Val] : '';
	}
	//�����ֶ� End
	$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeSubModelUrl'].'&'.http_build_query($SearArray);


	if($Do == 'submodel_list'){
		if(!submitcheck('Submit')) {
			$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
			$Where = '';
			$Order = $_GET['order'] ? 'A.'.addslashes(dhtmlspecialchars($_GET['order'])) : 'A.id';
			
			if($_GET['keyword']){
				$_GET['keyword'] = str_replace(array('%','_'),array('',''),$_GET['keyword']);
				$Where .= ' and (A.title like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or A.username like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or A.id = '.intval($_GET['keyword']).' )';
			}

			if($_GET['classid']){
				$Where .= ' and A.classid = '.intval($_GET['classid']);
			}

			if($_GET['disc_id']){
				$Where .= ' and A.disc_id = '.intval($_GET['disc_id']);
			}

			if(in_array($_GET['display'],array('0','1'))){
				$Where .= ' and A.display = '.intval($_GET['display']);
			}
			
			if(in_array($_GET['hot'],array('0','1'))){
				$Where .= ' and A.hot = '.intval($_GET['hot']);
			}

			if(in_array($_GET['slide'],array('0','1'))){
				$Where .= ' and A.slide = '.intval($_GET['slide']);
			}

			$Where = preg_replace('/and/','where',$Where,1);
			
			$Limit = 20;
			$Page = $_GET['page']?intval($_GET['page']):1;
			/* ��ѯ���� End */
			

			/* ģ����� */	
			showtagheader('div', 'row', true,'row');
			showtagheader('div', 'col-12', true,'col-12');
			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-body', true,'box-body');
			/* ���� */
			$DisplaySelected = array($_GET['display']=>' selected');
			$HotSelected = array($_GET['hot']=>' selected');
			$SlideSelected = array($_GET['slide']=>' selected');
			$OrderSelected = array($_GET['order']=>' selected');
			$ClassListOption = '<option value="">'.$Fn_House->Config['LangVar']['SelectNull'].'</option>';
			foreach(DB::fetch_all('SELECT * FROM '.DB::table($Fn_House->TableArticleClass).' order by displayorder asc') as $Val) {
				$ClassListOption .= '<option value="'.$Val['id'].'" '.($_GET['classid'] == $Val['id'] ? ' selected' : '' ).'>'.$Val['title'].'</option>';
			}
			echo <<<SEARCH
			<form method="post" autocomplete="off" action="$SearUrl">
				<div class="FormSearchTo" style="margin-bottom:0;">
					<table cellspacing="4" cellpadding="4">
						<tr>
							<th>{$Fn_House->Config['LangVar']['KeywordTitle']}</th><td><input type="text" class="form-control w200" name="keyword" value="{$_GET['keyword']}">
							</td>
							<th>{$Fn_Admin->Config['LangVar']['ClassTitle']}</th><td>
							<select name="classid" class="form-control w120">
								{$ClassListOption}
							</select>
							</td>
							<th>{$Fn_House->Config['LangVar']['DiscTitle']}ID</th><td><input type="text" class="form-control w100" name="disc_id" value="{$_GET['disc_id']}">
							</td>
							<th>{$Fn_House->Config['LangVar']['Hot']}</th><td>
					
							<select name="hot" class="form-control w120">
								<option value="">{$Fn_House->Config['LangVar']['SelectNull']}</option>
								<option value="1"{$HotSelected['1']}>{$Fn_House->Config['LangVar']['Yes']}</option>
								<option value="0"{$HotSelected['0']}>{$Fn_House->Config['LangVar']['No']}</option>
							</select>
							</td>
							<th>{$Fn_House->Config['LangVar']['Slide']}</th><td>
							<div class="select">
							<select name="slide" class="form-control w120">
								<option value="">{$Fn_House->Config['LangVar']['SelectNull']}</option>
								<option value="1"{$SlideSelected['1']}>{$Fn_House->Config['LangVar']['Yes']}</option>
								<option value="0"{$SlideSelected['0']}>{$Fn_House->Config['LangVar']['No']}</option>
							</select>
							</td>
							<th>{$Fn_House->Config['LangVar']['DisplayTitle']}</th><td>
							<select name="display" class="form-control w120" >
								<option value="">{$Fn_House->Config['LangVar']['SelectNull']}</option>
								<option value="1"{$DisplaySelected['1']}>{$Fn_House->Config['LangVar']['Yes']}</option>
								<option value="0"{$DisplaySelected['0']}>{$Fn_House->Config['LangVar']['No']}</option>
							</select>
							</td>
							<th>{$Fn_Admin->Config['LangVar']['Order']}</th><td>
							
							<select name="order" class="form-control w120">
								<option value="dateline"{$OrderSelected['dateline']}>{$Fn_Admin->Config['LangVar']['OrderArray']['dateline']}</option>
								<option value="updateline"{$OrderSelected['updateline']}>{$Fn_Admin->Config['LangVar']['OrderArray']['updateline']}</option>
								<option value="click"{$OrderSelected['click']}>{$Fn_Admin->Config['LangVar']['OrderArray']['click']}</option>
								<option value="topdateline"{$OrderSelected['topdateline']}>{$Fn_Admin->Config['LangVar']['OrderArray']['topdateline']}</option>
							</select>
							&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Admin->Config['LangVar']['SearchSubmit']}" class="btn btn-info" type="submit">
							</td>
						</tr>
					</table>
				</div>
			</form>
SEARCH;
			/* ���� End */
			showtagheader('div', 'table-responsive', true,'table-responsive');
			showformheader($FormUrl,'enctype="multipart/form-data"');
			showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
			showsubtitle(array(
				'ID',
				'UID/'.$Fn_House->Config['LangVar']['UserNameTitle'],
				$Fn_House->Config['LangVar']['Title'],
				$Fn_Admin->Config['LangVar']['ClassTitle'],
				$Fn_House->Config['LangVar']['DiscTitle'],
				$Fn_House->Config['LangVar']['Click'],
				$Fn_House->Config['LangVar']['Hot'],
				$Fn_House->Config['LangVar']['Slide'],
				$Fn_House->Config['LangVar']['DisplayTitle'],
				$Fn_House->Config['LangVar']['RefreshTime'],
				$Fn_House->Config['LangVar']['SetTopTime'],
				$Fn_House->Config['LangVar']['TimeTitle'],
				
				$Fn_House->Config['LangVar']['OperationTitle']
			),'header tbm tc');

			$ModulesList = $Fn_House->AgentListFormat(GetModulesList($Page,$Limit,$Where,$Order));
			foreach ($ModulesList as $Module) {
				showtablerow('', array('class="tc w50"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
					'<input type="checkbox" class="filled-in" id="checkbox_'.$Module['id'].'" name="delete[]" value="'.$Module['id'].'"><label for="checkbox_'.$Module['id'].'">'.$Module['id'].'</label>',
					$Module['uid'].'/'.$Module['username'],
					$Module['title'],
					$Module['class_title'].'&nbsp;&nbsp;<a href="'.$Fn_House->Config['ListArticleUrl'].'&classid='.$Module['classid'].'" target="_blank">'.cplang('view').'</a>',
					$Module['disc_title'] ? $Module['disc_title'].'&nbsp;&nbsp;<a href="'.$Fn_House->Config['ViewDiscUrl'].$Module['disc_id'].'" target="_blank">'.cplang('view').'</a>' : '',
					$Module['click'],
					!$Module['hot'] ? '<span class="label bg-secondary">'.$Fn_House->Config['LangVar']['No'].'</span>' : '<span class="label bg-blue">'.$Fn_House->Config['LangVar']['Yes'].'</span>',
					!$Module['slide'] ? '<span class="label bg-secondary">'.$Fn_House->Config['LangVar']['No'].'</span>' : '<span class="label bg-blue">'.$Fn_House->Config['LangVar']['Yes'].'</span>',
					!$Module['display'] ? '<span class="label bg-secondary">'.$Fn_House->Config['LangVar']['No'].'</span>' : '<span class="label bg-blue">'.$Fn_House->Config['LangVar']['Yes'].'</span>',
					$Module['updateline'] ? date('Y-m-d H:i',$Module['updateline']) : '',
					$Module['topdateline'] ? date('Y-m-d H:i',$Module['topdateline']) : '',
					date('Y-m-d H:i',$Module['dateline']),
					'<a href="'.($Module['jump'] ? $Module['jump_link'] : $Fn_House->Config['ViewArticleUrl'].$Module['id']).'" target="_blank" class="btn btn-sm btn-dark-outline">'.cplang('view').'</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&aid='.$Module['id'].'" class="btn btn-sm btn-info-outline">'.$Fn_House->Config['LangVar']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Refresh&aid='.$Module['id'].'&formhash='.FORMHASH.'" class="btn btn-sm btn-primary-outline">'.$Fn_House->Config['LangVar']['Refresh'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Hot&aid='.$Module['id'].'&value='.(!empty($Module['hot']) ? 0:1).'&formhash='.FORMHASH.'" class="btn btn-sm btn-success-outline">'.(!empty($Module['hot']) ? $Fn_House->Config['LangVar']['NoHot'] : $Fn_House->Config['LangVar']['Hot']).'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Slide&aid='.$Module['id'].'&value='.(!empty($Module['slide']) ? 0:1).'&formhash='.FORMHASH.'" class="btn btn-sm btn-warning-outline">'.(!empty($Module['slide']) ? $Fn_House->Config['LangVar']['Slide0'] : $Fn_House->Config['LangVar']['Slide1']).'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Display&aid='.$Module['id'].'&value='.(!empty($Module['display']) ? 0:1).'&formhash='.FORMHASH.'" class="btn btn-sm btn-purple-outline">'.(!empty($Module['display']) ? $Fn_House->Config['LangVar']['DisplayNoTitle'] : $Fn_House->Config['LangVar']['DisplayIsTitle']).'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Del&aid='.$Module['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$Fn_House->Config['LangVar']['DelTitle'].'</a>',
				));
			}
			showsubmit('Submit','&#31435;&#21363;&#25552;&#20132;','del','','',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));
			showtablefooter(); /*dism��taobao��com*/
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			/* ģ�����End */	
		}else{
			if(!$Fn_Admin->CheckUserGroup('house_all') && !$Fn_Admin->CheckUserGroup('house_del_article')){//Ȩ���ж�
				fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
				exit();
			}
			if(isset($_GET['delete']) && is_array($_GET['delete'])){
				foreach($_GET['delete'] as $Key => $Val) {
					$Val = intval($Val);
					DB::delete($Fn_House->TableArticle,'id ='.$Val);
				}
				GetInsertDoLog('del_article_house','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete'])));//������¼
				fn_cpmsg($Fn_House->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
			}else{
				fn_cpmsg($Fn_House->Config['LangVar']['DelErr'],'','error');
			}
		}
	}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['aid']){
		if(!$Fn_Admin->CheckUserGroup('house_all') && !$Fn_Admin->CheckUserGroup('house_del_article')){//Ȩ���ж�
			fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
			exit();
		}
		$id = intval($_GET['aid']);
		DB::delete($Fn_House->TableArticle,'id ='.$id);
		
		GetInsertDoLog('del_article_house','fn_'.$_GET['mod'],array('id'=>$id));//������¼

		fn_cpmsg($Fn_Admin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
	}else if($Do == 'Refresh' && $_GET['formhash'] == formhash() && $_GET['aid']){
		$id = intval($_GET['aid']);
		$UpData['updateline'] = time();
		DB::update($Fn_House->TableArticle,$UpData,'id = '.$id);
		GetInsertDoLog('refresh_article_house','fn_'.$_GET['mod'],array('id'=>$id,'display'=>$_GET['value']));//������¼
		fn_cpmsg($Fn_House->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

	}else if($Do == 'Slide' && $_GET['formhash'] == formhash() && $_GET['aid']){
		$id = intval($_GET['aid']);
		$UpData['slide'] = intval($_GET['value']);
		DB::update($Fn_House->TableArticle,$UpData,'id = '.$id);
		GetInsertDoLog('slide_article_house','fn_'.$_GET['mod'],array('id'=>$id,'display'=>$_GET['value']));//������¼
		fn_cpmsg($Fn_House->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

	}else if($Do == 'Display' && $_GET['formhash'] == formhash() && $_GET['aid']){
		$id = intval($_GET['aid']);
		$UpData['display'] = intval($_GET['value']);
		DB::update($Fn_House->TableArticle,$UpData,'id = '.$id);
		GetInsertDoLog('display_article_house','fn_'.$_GET['mod'],array('id'=>$id,'display'=>$_GET['value']));//������¼
		fn_cpmsg($Fn_House->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

	}else if($Do == 'Hot' && $_GET['formhash'] == formhash() && $_GET['aid']){
		$id = intval($_GET['aid']);
		$UpData['hot'] = intval($_GET['value']);
		DB::update($Fn_House->TableArticle,$UpData,'id = '.$id);
		GetInsertDoLog('hot_article_house','fn_'.$_GET['mod'],array('id'=>$id,'display'=>$_GET['value']));//������¼
		fn_cpmsg($Fn_House->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

	}
}if($SubModel == 'class_list'){//�����б�
	$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeSubModelUrl'];
	if(!submitcheck('Submit')){
		showtagheader('div', 'row', true,'row');
		showtagheader('div', 'col-12', true,'col-12');
		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-body', true,'box-body');
		showtagheader('div', 'table-responsive', true,'table-responsive');
		showformheader($FormUrl,'enctype="multipart/form-data"');
		showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
		showsubtitle(array(
			'ID', 
			'display_order',
			$Fn_House->Config['LangVar']['Title'],
			$Fn_Admin->Config['LangVar']['SeoTitleTo'],
			$Fn_Admin->Config['LangVar']['SeoKeyword'],
			$Fn_Admin->Config['LangVar']['SeoDesc'],
			$Fn_Admin->Config['LangVar']['EntryLink'],
			$Fn_House->Config['LangVar']['DisplayTitle']
		));
		$ModulesList = GetModulesClassList();

		foreach ($ModulesList as $Module) {
		
			showtablerow('', array('class="tc w50"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
				'<input type="checkbox" class="filled-in" id="checkbox_'.$Module['id'].'" name="delete[]" value="'.$Module['id'].'"><label for="checkbox_'.$Module['id'].'">'.$Module['id'].'</label>',
				'<input type="text" class="form-control w50" name="displayorder['.$Module['id'].']" value="'.$Module['displayorder'].'" />',
				'<input type="text" class="form-control w150" name="title['.$Module['id'].']" value="'.$Module['title'].'" />',
				'<input type="text" class="form-control w250" name="seo_title['.$Module['id'].']" value="'.$Module['seo_title'].'" />',
				'<input type="text" class="form-control w250" name="seo_keyword['.$Module['id'].']" value="'.$Module['seo_keyword'].'" />',
				'<input type="text" class="form-control w250" name="seo_desc['.$Module['id'].']" value="'.$Module['seo_desc'].'" />',
				'<input type="text" class="form-control w250" name="link['.$Module['id'].']" value="'.$Fn_House->Config['ListArticleUrl'].'&classid='.$Module['id'].'" readonly/>',
				'<input class="with-gap" name="display['.$Module['id'].']" type="radio" value="1" '.($Module['display'] ? 'checked="checked"' : '').' id="v_1_new_display_'.$Module['id'].'"/><label class="custom-control-label" for="v_1_new_display_'.$Module['id'].'">'.$Fn_House->Config['LangVar']['DisplayIsTitle'].'</label>&nbsp;&nbsp;<input class="with-gap" name="display['.$Module['id'].']" type="radio" value="0" '.( !$Module['display'] ? 'checked="checked"' : '').' id="v_0_new_display_'.$Module['id'].'"/><label class="custom-control-label" for="v_0_new_display_'.$Module['id'].'">'.$Fn_House->Config['LangVar']['DisplayNoTitle'].'</label>'
			));
		}
		
		showtablerow('', array('class="tc w50"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
			cplang('add_new'),
			sprintf('<input type="text" class="form-control w50" maxlength="4" name="new_displayorder" value="" />'),
			sprintf('<input type="text" class="form-control w150" name="new_title" value="" />'),
			sprintf('<input type="text" class="form-control w250" name="new_seo_title" value="" />'),
			sprintf('<input type="text" class="form-control w250" name="new_seo_keyword" value="" />'),
			sprintf('<input type="text" class="form-control w250" name="new_seo_desc" value="" />'),
			'',
			sprintf('<input class="with-gap" name="new_display" type="radio" value="1" checked="checked" id="v_1_new_display"/><label class="custom-control-label" for="v_1_new_display">'.$Fn_House->Config['LangVar']['DisplayIsTitle'].'</label>&nbsp;&nbsp;<input class="with-gap" name="new_display" type="radio" value="0" id="v_0_new_display"/><label class="custom-control-label" for="v_0_new_display">'.$Fn_House->Config['LangVar']['DisplayNoTitle'].'</label>')
		));
		showsubmit('Submit', 'submit', 'del');
		showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
	}else{
		//ɾ��ѡ��
		if(isset($_POST['delete']) && is_array($_POST['delete'])) {
			foreach($_POST['delete'] as $Id){
				$Id = intval($Id);
				DB::delete($Fn_House->TableArticleClass,'id ='.$Id);
				DB::delete($Fn_House->TableArticle,'classid ='.$Id);
			}
		}
		// ����
		if(isset($_POST['displayorder']) && is_array($_POST['displayorder'])) {
			foreach ($_POST['displayorder'] as $Id => $Displayorder) {
				$UpIns = array();
				$Id = intval($Id);
				$UpIns['title'] =  addslashes(strip_tags($_POST['title'][$Id]));
				$UpIns['seo_title'] =  addslashes(strip_tags($_POST['seo_title'][$Id]));
				$UpIns['seo_keyword'] =  addslashes(strip_tags($_POST['seo_keyword'][$Id]));
				$UpIns['seo_desc'] =  addslashes(strip_tags($_POST['seo_desc'][$Id]));
				$UpIns['displayorder'] =  intval($Displayorder);
				$UpIns['display'] = intval($_POST['display'][$Id]);
//				if(!empty($_FILES['file_ico']['size'][$Id])) {
//					$Ico = array(
//						'name' => $_FILES['file_ico']['name'][$Id],
//						'type' => $_FILES['file_ico']['type'][$Id],
//						'tmp_name' => $_FILES['file_ico']['tmp_name'][$Id],
//						'error' => $_FILES['file_ico']['error'][$Id],
//						'size' => $_FILES['file_ico']['size'][$Id]
//					);
//					$IcoFile = Fn_Upload($Ico,$_POST['ico'][$Id]);
//					if($IcoFile['Errorcode']){
//						fn_cpmsg($Fn_House->Config['LangVar']['ImgErr'],'','error');
//					}else{
//						$UpIns['ico'] = $IcoFile['Path'];
//					}
//				}else{
//					$UpIns['ico'] = addslashes(strip_tags($_POST['ico'][$Id]));
//				}
				DB::update($Fn_House->TableArticleClass,$UpIns,'id = '.$Id);
			}
		}
		//���ӷ���
		if ($_POST['new_title']) {
			$Ins = array();
			$Ins['title'] = addslashes(strip_tags($_POST['new_title']));
			$Ins['seo_title'] = addslashes(strip_tags($_POST['new_seo_title']));
			$Ins['seo_keyword'] = addslashes(strip_tags($_POST['new_seo_keyword']));
			$Ins['seo_desc'] = addslashes(strip_tags($_POST['new_seo_desc']));
			$Ins['displayorder'] = intval($_POST['new_displayorder']);
			$Ins['display'] = intval($_POST['new_display']);
//			if($_FILES['new_ico']['size']){
//				$IcoFile = Fn_Upload($_FILES['new_ico']);
//				if($IcoFile['Errorcode']){
//					fn_cpmsg($Fn_House->Config['LangVar']['ImgErr'],'','error');
//				}else{
//					$Ins['ico'] = $IcoFile['Path'];
//				}
//			}
			DB::insert($Fn_House->TableArticleClass,$Ins);
		}
		fn_cpmsg($Fn_House->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
	}

}else if($SubModel == 'add'){//���ӻ�༭
	if(!$Fn_Admin->CheckUserGroup('house_all') && !$Fn_Admin->CheckUserGroup('house_add_article')){//Ȩ���ж�
		fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
		exit();
	}
	$id = intval($_GET['aid']);
	
	$Item = DB::fetch_first('SELECT * FROM '.DB::table($Fn_House->TableArticle).' where id = '.$id);

	if(!submitcheck('DetailSubmit')) {
		$OpTitle = $Fn_House->Config['LangVar']['AddTitle'];


		if($Item){
			$OpTitle = $Fn_House->Config['LangVar']['EditTitle'];
		}
		
		//ͼƬ�ϴ�
		if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_assembly/class/class_upload.php')){
			@require_once libfile('class/upload','plugin/fn_assembly');
			$UploadConfig = fn_upload::Config();
		}

		echo '<script src="'.$Config['StaticPath'].'/ueditor/'.CHARSET.'/ueditor.config.js" type="text/javascript"></script><script src="'.$Config['StaticPath'].'/ueditor/'.CHARSET.'/ueditor.all.js" type="text/javascript"></script>';
		

		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-header', true,'with-border box-header');
		showtitle($OpTitle,'class="box-title"');
		showtagfooter('div');
		showformheader($Fn_Admin->Config['IframeSubModelUrl'].'&aid='.$id,'enctype');
		showtagheader('div', 'box-body', true,'box-body');
		
		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_Admin->Config['LangVar']['Thumbnail'].':</label><div class="col-sm-9"><div class="AdminSingleUpload"><div class="PhotoControl" id="Thumbnail"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';

		showsetting('uid', 'new_uid', $Item['uid'] ? $Item['uid'] : $_G['uid'], 'text');

		showsetting($Fn_House->Config['LangVar']['Title'], 'title', $Item['title'], 'text');

		$ClassList = array();
		foreach(DB::fetch_all('SELECT * FROM '.DB::table($Fn_House->TableArticleClass).' order by displayorder asc') as $Val) {
			$ClassList[] = array($Val['id'], $Val['title']);
		}
		showsetting($Fn_Admin->Config['LangVar']['ClassTitle'], array('classid', $ClassList),$Item['classid'], 'select');
		
		showsetting($Fn_House->Config['LangVar']['DiscTitle'].'ID',array('disc_id_type', array(
			array('1',$Fn_Admin->Config['LangVar']['QuickSelection'], array('disc_id_table_1' => '', 'disc_id_table_2' => 'none')),
			array('2',$Fn_Admin->Config['LangVar']['ManuallyFillIn'], array('disc_id_table_1'=> 'none', 'disc_id_table_2' => ''))
		), TRUE),1, 'mradio');

		$DiscIdDisplay1 =  1;
		$DiscIdDisplay0 =  0;
		
		showtagheader('div', 'disc_id_table_1', $DiscIdDisplay1, 'sub');
			$DiscList[] = array('',$Fn_House->Config['LangVar']['SelectNull']);
			foreach(DB::fetch_all('SELECT * FROM '.DB::table($Fn_House->TableDisc).' order by CONVERT(title USING GBK) asc') as $Val) {
				$DiscList[] = array($Val['id'], $Val['title']);
			}
			showsetting($Fn_House->Config['LangVar']['DiscTitle'].'ID', array('disc_id', $DiscList),$Item['disc_id'], 'select');
		showtagfooter('div');

		showtagheader('div', 'disc_id_table_2', $DiscIdDisplay0, 'sub');
			showsetting($Fn_House->Config['LangVar']['DiscTitle'].'ID', 'new_disc_id', $Item['disc_id'], 'text');
		showtagfooter('div');

		showsetting($Fn_House->Config['LangVar']['Hot'], 'hot', $Item['hot'], 'radio','','',$Fn_House->Config['LangVar']['SlideTips']);

		showsetting($Fn_House->Config['LangVar']['Slide'], 'slide', $Item['slide'], 'radio','','',$Fn_House->Config['LangVar']['SlideTips']);

		showsetting($Fn_House->Config['LangVar']['JumpTitle'],array('jump', array(
		array('1',$Fn_House->Config['LangVar']['Yes'], array('jump_table_1' => '', 'jump_table_0' => 'none')),
		array('0',$Fn_House->Config['LangVar']['No'], array('jump_table_1'=> 'none', 'jump_table_0' => ''))
		), TRUE),$Item['jump'], 'mradio');
		
		$JumpDisplay1 = $Item['jump'] ? true : false;
		$JumpDisplay0 = !$Item['jump'] ? true : false;
		showtagheader('div', 'jump_table_1', $JumpDisplay1, 'sub');
			showsetting($Fn_House->Config['LangVar']['OuterChain'], 'jump_link', $Item['jump_link'], 'text');
		showtagfooter('div');
		showtagheader('div', 'jump_table_0', $JumpDisplay0, 'sub');
			//����
			echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_Job->Config['LangVar']['Content'].':</label><div class="col-sm-9"><textarea id="content" name="content" style="width:80%;height:400px;">'.stripslashes($Item['content']).'</textarea></div></div>';
		showtagfooter('div');

		showsetting($Fn_Admin->Config['LangVar']['Abstract'], 'describe', $Item['describe'], 'textarea');

		showsetting($Fn_House->Config['LangVar']['Click'], 'click', $Item['click'], 'text');

		showsetting($Fn_House->Config['LangVar']['DisplayTitle'], 'display', $Item ? $Item['display'] : 1, 'radio');
		
		showsetting($Fn_House->Config['LangVar']['SetTopTime'], 'topdateline',$Item['topdateline'] ? date('Y-m-d H:i',$Item['topdateline']) : '', 'calendar','','','',1);

		if($Item['updateline']){
			showsetting($Fn_House->Config['LangVar']['RefreshTime'], 'updateline',$Item['updateline'] ? date('Y-m-d H:i',$Item['updateline']) : '', 'calendar','','','',1);
		}

		if($Item['dateline']){
			showsetting($Fn_House->Config['LangVar']['TimeTitle'], 'dateline',date('Y-m-d H:i',$Item['dateline']), 'calendar','','','',1);
		}
		
		showsubmit('DetailSubmit','&#20445;&#23384;&#37197;&#32622;');
		showtagfooter('div');
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');

		$UpLoadHtml  = '';
		if($Item['thumbnail']){
			$ThumbnailJsArray[] = '"'.$Item['thumbnail'].'"';;
			$UpLoadHtml .= '
			var InputArray = new Array('.implode(',',$ThumbnailJsArray).');
			jQuery("#Thumbnail").AppUpload({InputName:"new_thumbnail",Multiple:true,InputExist:true,InputArray:InputArray});';

		}else{
			$UpLoadHtml .= 'jQuery("#Thumbnail").AppUpload({InputName:"new_thumbnail",Multiple:true});';
		}
		
		echo '<script src="source/plugin/fn_assembly/static/js/mobiscroll.custom-2.16.1.min.js"></script><link rel="stylesheet" href="source/plugin/fn_assembly/static//css/mobiscroll.custom-2.16.1.min.css">'.$UploadConfig['CssJsHtml'];
		
		echo '<script>var ue = UE.getEditor("content",{autoHeightEnabled: false,autoFloatEnabled:false,enableAutoSave: false});'.$UpLoadHtml.'</script> 	';

	}else{

		foreach($_GET['new_thumbnail'] as $Key => $Val) {
			$_GET['new_thumbnail'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}
		
		$Data['uid'] = intval($_GET['new_uid']);
		$Member = DB::fetch_first('SELECT username FROM '.DB::table('common_member').' where uid = '.$Data['uid']);
		$Data['username'] = addslashes(strip_tags($Member['username']));
		$Data['classid'] = intval($_GET['classid']);
		$Data['disc_id'] = $_GET['disc_id_type'] == 1 ? intval($_GET['disc_id']) : intval($_GET['new_disc_id']);
		$Data['title'] = addslashes(strip_tags($_GET['title']));
		$Data['thumbnail'] = addslashes(strip_tags($_GET['new_thumbnail'][0]));
		$Data['describe'] = addslashes(strip_tags($_GET['describe']));
		$Data['content'] = addslashes($_GET['content']);
		$Data['jump'] = intval($_GET['jump']);
		$Data['jump_link'] = addslashes(strip_tags($_GET['jump_link']));
		$Data['topdateline'] = $_GET['topdateline'] ? strtotime($_GET['topdateline']) : '';
		$Data['hot'] = intval($_GET['hot']);
		$Data['slide'] = intval($_GET['slide']);
		$Data['click'] = intval($_GET['click']);
		$Data['display'] = intval($_GET['display']);

		if($Item){
			$Data['updateline'] = strtotime($_GET['updateline']);
			$Data['dateline'] = strtotime($_GET['dateline']);
			GetInsertDoLog('edit_article_house','fn_'.$_GET['mod'],array('id'=>$id));//������¼
			DB::update($Fn_House->TableArticle,$Data,'id = '.$id);
		}else{
			$Data['dateline'] = $Data['updateline'] = time();
			$id = DB::insert($Fn_House->TableArticle,$Data,true);
			GetInsertDoLog('add_article_house','fn_'.$_GET['mod'],array('id'=>$id));//������¼
	
		}
		fn_cpmsg($Fn_House->Config['LangVar']['UpdateOk'],$Fn_Admin->Config['IframeItemUrl'].'&submodel=list','succeed');
	}
}

/* �б� */
function GetModulesList($Page,$Limit,$Where=null,$Order){
	global $Fn_House;
	$FetchSql = 'SELECT A.*,C.title as class_title,D.title as disc_title  FROM '.DB::table($Fn_House->TableArticle).' A LEFT JOIN `'.DB::table($Fn_House->TableArticleClass).'` C on C.id = A.classid LEFT JOIN `'.DB::table($Fn_House->TableDisc).'` D on D.id = A.disc_id '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}

/* ���� */
function GetModulesCount($Where=null){
	global $Fn_House;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_House->TableArticle).' A '.$Where;
	return DB::result_first($FetchSql);//��������
}

/* �б� */
function GetModulesClassList($Where = null){
	global $Fn_House;
	$FetchSql = 'SELECT * FROM '.DB::table($Fn_House->TableArticleClass).$Where.' order by displayorder asc';
	return DB::fetch_all($FetchSql);//��������
}

?>