<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('house_all') && !$Fn_Admin->CheckUserGroup('house_shop_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$SubModel = in_array($_GET['submodel'], array('list','add')) ? $_GET['submodel'] : 'list';
$Fn_Admin->Config['IframeSubModelUrl'] = $Fn_Admin->Config['IframeItemUrl'].'&submodel='.$SubModel;
$NavClass = array($SubModel=>'Hover');

//����
echo <<<Nav
<div class="SubModelNav">
  <ul>
	<li class="{$NavClass['list']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=list" target="_self">{$Fn_Admin->Config['LangVar']['HouseLeftNavArray']['shop_list']}</a></li>
    <li class="{$NavClass['add']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=add" target="_self">{$Fn_Admin->Config['LangVar']['AddEditTitle']}</a></li>
  </ul>
  <div class="both"></div>
</div>
Nav;

if($SubModel == 'list'){//�б�
	$Do = in_array($_GET['do'], array('Refresh','Del','Display','PaymentState','Deal','Hot')) ? $_GET['do'] : 'submodel_list';
	//�����ֶ�
	$SearField =array('page','keyword','payment_state','display','deal','order','vice_class','hot','publish_type');
	foreach($SearField as $Val) {
		$SearArray[$Val] = $_GET[$Val] ? $_GET[$Val] : '';
	}
	//�����ֶ� End
	$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeSubModelUrl'].'&'.http_build_query($SearArray);


	if($Do == 'submodel_list'){
		if(!submitcheck('Submit')) {
			$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
			$Where = ' and I.class = 3';
			$Order = in_array($_GET['order'], array('id')) ? 'I.'.addslashes(dhtmlspecialchars($_GET['order'])) : 'I.id';

			if($_GET['keyword']){
				$Where .= ' and (I.title like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or I.name like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or I.small_area like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or I.username like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or I.param like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or I.id = '.intval($_GET['keyword']).' )';
			}

			if(in_array($_GET['vice_class'],array('1','2','3'))){
				$Where .= ' and I.vice_class = '.intval($_GET['vice_class']);
			}

			if(in_array($_GET['publish_type'],array('1','2'))){
				$Where .= ' and I.publish_type = '.intval($_GET['publish_type']);
			}

			if(in_array($_GET['display'],array('0','1'))){
				$Where .= ' and I.display = '.intval($_GET['display']);
			}

			if(in_array($_GET['payment_state'],array('0','1'))){
				$Where .= ' and I.payment_state = '.intval($_GET['payment_state']);
			}

			if(in_array($_GET['deal'],array('0','1'))){
				$Where .= ' and I.deal = '.intval($_GET['deal']);
			}

			if(in_array($_GET['hot'],array('0','1'))){
				$Where .= ' and I.hot = '.intval($_GET['hot']);
			}

			$Where = preg_replace('/and/','where',$Where,1);
			$Limit = 20;
			$Page = $_GET['page']?intval($_GET['page']):1;
			/* ��ѯ���� End */

			/* ���� */

			$ViceClassSelected = array($_GET['vice_class']=>' selected');
			$PublishTypeSelected = array($_GET['publish_type']=>' selected');
			$DisplaySelected = array($_GET['display']=>' selected');
			$DealSelected = array($_GET['deal']=>' selected');
			$PaymentStateSelected = array($_GET['payment_state']=>' selected');
			$HotSelected = array($_GET['hot']=>' selected');
			echo <<<SEARCH
			<form method="post" autocomplete="off" action="$SearUrl">
				<div class="FormSearchTo" style="margin-bottom:0;">
					<table cellspacing="4" cellpadding="4">
						<tr>
							<th>{$Fn_House->Config['LangVar']['KeywordTitle']}</th><td><input type="text" class="input w200" name="keyword" value="{$_GET['keyword']}">
							</td>
							<th>{$Fn_House->Config['LangVar']['ShopType']}</th><td>
							<div class="select"><select name="vice_class">
								<option value="">{$Fn_House->Config['LangVar']['SelectNull']}</option>
								<option value="1"{$ViceClassSelected['1']}>{$Fn_House->Config['LangVar']['ShopTypeArray']['1']}</option>
								<option value="2"{$ViceClassSelected['2']}>{$Fn_House->Config['LangVar']['ShopTypeArray']['2']}</option>
								<option value="3"{$ViceClassSelected['3']}>{$Fn_House->Config['LangVar']['ShopTypeArray']['3']}</option>
							</select></div>
							</td>
							<th>{$Fn_House->Config['LangVar']['NatureTo']}</th><td>
							<div class="select"><select name="publish_type">
								<option value="">{$Fn_House->Config['LangVar']['SelectNull']}</option>
								<option value="1"{$PublishTypeSelected['1']}>{$Fn_House->Config['LangVar']['PublishTypeArray']['1']}</option>
								<option value="2"{$PublishTypeSelected['2']}>{$Fn_House->Config['LangVar']['PublishTypeArray']['2']}</option>
							</select></div>
							</td>
							<th>{$Fn_House->Config['LangVar']['DisplayTitle']}</th><td>
							<div class="select"><select name="display">
								<option value="">{$Fn_House->Config['LangVar']['SelectNull']}</option>
								<option value="1"{$DisplaySelected['1']}>{$Fn_House->Config['LangVar']['Yes']}</option>
								<option value="0"{$DisplaySelected['0']}>{$Fn_House->Config['LangVar']['No']}</option>
							</select></div>
							</td>
							<th>{$Fn_House->Config['LangVar']['PaymentState']}</th><td>
							<div class="select">
							<select name="payment_state">
								<option value="">{$Fn_House->Config['LangVar']['SelectNull']}</option>
								<option value="0"{$PaymentStateSelected['0']}>{$Fn_House->Config['LangVar']['PaymentStateArray'][0]}</option>
								<option value="1"{$PaymentStateSelected['1']}>{$Fn_House->Config['LangVar']['PaymentStateArray'][1]}</option>
							</select></div>
							</td>
							<th>{$Fn_House->Config['LangVar']['DealState']}</th><td>
							<div class="select"><select name="deal">
								<option value="">{$Fn_House->Config['LangVar']['SelectNull']}</option>
								<option value="1"{$DealSelected['1']}>{$Fn_House->Config['LangVar']['DealStateArray'][1]}</option>
								<option value="0"{$DealSelected['0']}>{$Fn_House->Config['LangVar']['DealStateArray'][0]}</option>
							</select></div>
							
							</td>

						    <th>{$Fn_House->Config['LangVar']['Hot']}</th><td>
							<div class="select">
							<select name="hot">
								<option value="">{$Fn_House->Config['LangVar']['SelectNull']}</option>
								<option value="1"{$HotSelected['1']}>{$Fn_House->Config['LangVar']['Yes']}</option>
								<option value="0"{$HotSelected['0']}>{$Fn_House->Config['LangVar']['No']}</option>
							</select></div>
							&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_House->Config['LangVar']['SearchSubmit']}" class="button" type="submit">
							</td>
						</tr>
						
			
					</table>
				</div>
			</form>
SEARCH;
			/* ���� End */

			/* ģ����� */	
			
			showtagheader('div', 'Module', true);
			showformheader($FormUrl,'enctype="multipart/form-data"');
			showtableheader($Fn_House->Config['LangVar']['InfoListTitle'],'listtable');
			showsubtitle(array(
				'ID',
				'Uid/'.$Fn_House->Config['LangVar']['UserNameTitle'],
				$Fn_House->Config['LangVar']['Title'],
				$Fn_House->Config['LangVar']['NatureTo'],
				$Fn_House->Config['LangVar']['DisplayTitle'],
				$Fn_House->Config['LangVar']['PaymentState'],
				$Fn_House->Config['LangVar']['DealState'],
				$Fn_House->Config['LangVar']['Hot'],
				$Fn_House->Config['LangVar']['Browse'],
				$Fn_House->Config['LangVar']['TimeTitle'],
				$Fn_House->Config['LangVar']['RefreshTime'],
				$Fn_House->Config['LangVar']['SetTopTime'],
				$Fn_House->Config['LangVar']['OperationTitle']
			),'header tbm tc');

			$ModulesList = $Fn_House->InfoListFormat(GetModulesList($Page,$Limit,$Where,$Order));
			foreach ($ModulesList as $Module) {
				$ids[] = $Module['id'];
				showtablerow('', array('class="tc w50"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
					'<label class="checkbox"><input type="checkbox" class="check" name="delete[]" value="'.$Module['id'].'" /><span class="ic"></span></label>'.$Module['id'],
					$Module['uid'] ? $Module['uid'].'<br>'.$Module['username'] : '',
					$Module['title'].'<br><div class="Type">'.$Module['province_text'].'<span>/</span>'.$Module['shops_type'].'<span>/</span>'.$Module['management_type'].'<span>/</span>'.$Module['square'].$Fn_House->Config['LangVar']['m2'].'<span>/</span>'.$Module['price'].$Module['price_text'].'</div>',
					$Module['publish_type_text'],
					!$Module['display'] ? '<span class="red">'.$Fn_House->Config['LangVar']['No'].'</span>' : $Fn_House->Config['LangVar']['Yes'],
					!$Module['payment_state'] ? '<span class="red">'.$Fn_House->Config['LangVar']['PaymentStateArray']['0'].'</span>' : $Fn_House->Config['LangVar']['PaymentStateArray']['1'],
					!$Module['deal'] ? '<span class="red">'.$Fn_House->Config['LangVar']['DealStateArray']['0'].'</span>' : $Fn_House->Config['LangVar']['DealStateArray']['1'],
					$Module['hot'] ? '<span class="red">'.$Fn_House->Config['LangVar']['Yes'].'</span>' : $Fn_House->Config['LangVar']['No'],
					$Module['click'],
					$Module['dateline'],
					$Module['updateline'] ? date('Y-m-d H:i',$Module['updateline']) : '',
					$Module['topdateline'],
					'<a href="'.$Fn_House->Config['ViewUrl'].$Module['id'].'" target="_blank">'.cplang('view').'</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&iid='.$Module['id'].'&cp_msg_url='.urlencode($CpMsgUrl).'">'.$Fn_House->Config['LangVar']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Refresh&iid='.$Module['id'].'&formhash='.FORMHASH.'">'.$Fn_House->Config['LangVar']['Refresh'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Del&iid='.$Module['id'].'&formhash='.FORMHASH.'">'.$Fn_House->Config['LangVar']['DelTitle'].'</a><br><a href="'.$OpCpUrl.'&do=Display&iid='.$Module['id'].'&value='.(!empty($Module['display']) ? 0:1).'&formhash='.FORMHASH.'">'.(!empty($Module['display']) ? $Fn_House->Config['LangVar']['DisplayNoTitle'] : $Fn_House->Config['LangVar']['DisplayIsTitle']).'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=PaymentState&iid='.$Module['id'].'&value='.(!empty($Module['payment_state']) ? 0:1).'&formhash='.FORMHASH.'">'.(!empty($Module['payment_state']) ? $Fn_House->Config['LangVar']['PaymentStateArray'][0] : $Fn_House->Config['LangVar']['PaymentStateArray'][1]).'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Deal&iid='.$Module['id'].'&value='.(!empty($Module['deal']) ? 0:1).'&formhash='.FORMHASH.'">'.(!empty($Module['deal']) ? $Fn_House->Config['LangVar']['DealStateArray'][0] : $Fn_House->Config['LangVar']['DealStateArray'][1]).'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Hot&iid='.$Module['id'].'&value='.(!empty($Module['hot']) ? 0:1).'&formhash='.FORMHASH.'">'.(!empty($Module['hot']) ? $Fn_House->Config['LangVar']['NoHot'] : $Fn_House->Config['LangVar']['Hot']).'</a>',
				));
			}

			$ClassHtml = '&nbsp;&nbsp;<label class="radio"><input name="optype" value="MoveClass" class="check" type="radio"><span class="ic"></span>'.$Fn_Admin->Config['LangVar']['MoveClass'].'</label>&nbsp;<div class="select"><select name="new_class"><option value="">'.$Fn_House->Config['LangVar']['SelectNull'].'</option>';
			foreach ($Fn_House->Config['LangVar']['IndexNavArray'] as $Key => $Value) {
				$ClassHtml .= '<option value="'.$Key.'">'.$Value.'</option>';
			}
			$ClassHtml .= '</select></div>';

			showsubmit('Submit','submit','&nbsp;&nbsp;<label class="radio"><input name="optype" value="Del" class="check" type="radio"><span class="ic"></span>'.$Fn_House->Config['LangVar']['DelTitle'].'</label>&nbsp;&nbsp;<label class="radio"><input name="optype" value="Refresh" class="check" type="radio"><span class="ic"></span>'.$Fn_House->Config['LangVar']['Refresh'].'</label>&nbsp;&nbsp;<label class="radio"><input name="optype" value="Display" class="check" type="radio"><span class="ic"></span>'.$Fn_House->Config['LangVar']['DisplayTitle'].'</label>&nbsp;<div class="select"><select name="new_display"><option value="">'.$Fn_House->Config['LangVar']['SelectNull'].'</option><option value="1">'.$Fn_House->Config['LangVar']['Yes'].'</option><option value="0">'.$Fn_House->Config['LangVar']['No'].'</option></select></div>&nbsp;&nbsp;<label class="radio"><input name="optype" value="PaymentState" class="check" type="radio"><span class="ic"></span>'.$Fn_House->Config['LangVar']['PaymentState'].'</label>&nbsp;<div class="select"><select name="new_payment_state"><option value="">'.$Fn_House->Config['LangVar']['SelectNull'].'</option><option value="1">'.$Fn_House->Config['LangVar']['PaymentStateArray']['1'].'</option><option value="0">'.$Fn_House->Config['LangVar']['PaymentStateArray']['0'].'</option></select></div>&nbsp;&nbsp;<label class="radio"><input name="optype" value="Deal" class="check" type="radio"><span class="ic"></span>'.$Fn_House->Config['LangVar']['DealState'].'</label>&nbsp;<div class="select"><select name="new_deal"><option value="">'.$Fn_House->Config['LangVar']['SelectNull'].'</option><option value="1">'.$Fn_House->Config['LangVar']['DealStateArray']['1'].'</option><option value="0">'.$Fn_House->Config['LangVar']['DealStateArray']['0'].'</option></select></div>&nbsp;&nbsp;<label class="radio"><input name="optype" value="Hot" class="check" type="radio"><span class="ic"></span>'.$Fn_House->Config['LangVar']['Hot'].'</label>&nbsp;<div class="select"><select name="new_hot"><option value="">'.$Fn_House->Config['LangVar']['SelectNull'].'</option><option value="1">'.$Fn_House->Config['LangVar']['Yes'].'</option><option value="0">'.$Fn_House->Config['LangVar']['No'].'</option></select></div>'.$ClassHtml,'&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['Url'].'&mod=export_txt&type='.$_GET['mod'].'&op=info&ids='.implode(',',$ids).'&formhash='.FORMHASH.'">'.$Fn_Admin->Config['LangVar']['ExportText'].'</a>','select_all',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));
			showtablefooter(); /*dism��taobao��com*/
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');
			/* ģ�����End */
			echo '<style>.Type{color:#999;}.Type span{margin:0 5px;}</style>';
		}else{
			if(isset($_GET['delete']) && is_array($_GET['delete'])){
				if($_GET['optype'] == 'Del'){//ȫɾ
					if(!$Fn_Admin->CheckUserGroup('house_all') && !$Fn_Admin->CheckUserGroup('house_del_shop_list')){//Ȩ���ж�
						fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
						exit();
					}
					foreach($_GET['delete'] as $Key => $Val) {
						$Val = intval($Val);
						DB::delete($Fn_House->TableInfo,'id ='.$Val);
						DB::delete($Fn_House->TableInfoLog,'iid ='.$Val);
						DB::delete($Fn_House->TableInfoCollection,'iid ='.$Val);
						DB::delete($Fn_House->TableInfoReport,'iid ='.$Val);
					}
					GetInsertDoLog('del_shop_house','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete'])));//������¼
					fn_cpmsg($Fn_House->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');

				}else if($_GET['optype'] == 'Refresh'){
					foreach($_GET['delete'] as $Key => $Val) {
						$Val = intval($Val);
						$UpData['updateline'] = time();
						DB::update($Fn_House->TableInfo,$UpData,'id = '.$Val);
					}
					GetInsertDoLog('refresh_house','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete']),'display'=>$_GET['new_display']));//������¼
					fn_cpmsg($Fn_House->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

				}else if($_GET['optype'] == 'Display' && in_array($_GET['new_display'],array('0','1'))){
					foreach($_GET['delete'] as $Key => $Val) {
						$Val = intval($Val);
						$UpData['display'] = intval($_GET['new_display']);
						DB::update($Fn_House->TableInfo,$UpData,'id = '.$Val);
					}
					GetInsertDoLog('display_shop_house','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete']),'display'=>$_GET['new_display']));//������¼
					fn_cpmsg($Fn_House->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

				}else if($_GET['optype'] == 'PaymentState' && in_array($_GET['new_payment_state'],array('0','1'))){
					foreach($_GET['delete'] as $Key => $Val) {
						$Val = intval($Val);
						$UpData['payment_state'] = intval($_GET['new_payment_state']);
						DB::update($Fn_House->TableInfo,$UpData,'id = '.$Val);
					}
					GetInsertDoLog('payment_state_shop_house','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete']),'payment_state'=>$_GET['new_payment_state']));//������¼
					fn_cpmsg($Fn_House->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

				}else if($_GET['optype'] == 'Deal' && in_array($_GET['new_deal'],array('0','1'))){
					foreach($_GET['delete'] as $Key => $Val) {
						$Val = intval($Val);
						$UpData['deal'] = intval($_GET['new_deal']);
						DB::update($Fn_House->TableInfo,$UpData,'id = '.$Val);
					}
					GetInsertDoLog('deal_shop_house','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete']),'deal'=>$_GET['new_deal']));//������¼
					fn_cpmsg($Fn_House->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

				}else if($_GET['optype'] == 'Hot' && in_array($_GET['new_hot'],array('0','1'))){
					foreach($_GET['delete'] as $Key => $Val) {
						$Val = intval($Val);
						$UpData['hot'] = intval($_GET['new_hot']);
						DB::update($Fn_House->TableInfo,$UpData,'id = '.$Val);
					}
					GetInsertDoLog('hot_shop_house','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete']),'hot'=>$_GET['new_hot']));//������¼
					fn_cpmsg($Fn_House->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

				}else if($_GET['optype'] == 'MoveClass' && $_GET['new_class']){
					foreach($_GET['delete'] as $Key => $Val) {
						$Val = intval($Val);
						$UpData['class'] = intval($_GET['new_class']);
						DB::update($Fn_House->TableInfo,$UpData,'id = '.$Val);
					}
					GetInsertDoLog('info_move_class_house','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete']),'class'=>$_GET['new_class']));//������¼
					fn_cpmsg($Fn_House->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

				}
			}else{
				fn_cpmsg($Fn_House->Config['LangVar']['OpErr'],'','error');
			}	
		}
	}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['iid']){
		if(!$Fn_Admin->CheckUserGroup('house_all') && !$Fn_Admin->CheckUserGroup('house_del_shop_list')){//Ȩ���ж�
			fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
			exit();
		}
		$iid = intval($_GET['iid']);
		DB::delete($Fn_House->TableInfo,'id ='.$iid);
		DB::delete($Fn_House->TableInfoLog,'iid ='.$iid);
		DB::delete($Fn_House->TableInfoCollection,'iid ='.$iid);
		DB::delete($Fn_House->TableInfoReport,'iid ='.$iid);
		GetInsertDoLog('del_shop_house','fn_'.$_GET['mod'],array('id'=>$_GET['iid']));//������¼
		fn_cpmsg($Fn_House->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');

	}else if($Do == 'Refresh' && $_GET['formhash'] == formhash() && $_GET['iid']){
		$iid = intval($_GET['iid']);
		$UpData['updateline'] = time();
		DB::update($Fn_House->TableInfo,$UpData,'id = '.$iid);
		GetInsertDoLog('refresh_house','fn_'.$_GET['mod'],array('id'=>$_GET['iid']));//������¼
		fn_cpmsg($Fn_House->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

	}else if($Do == 'Display' && $_GET['formhash'] == formhash() && $_GET['iid']){
		$iid = intval($_GET['iid']);
		$UpData['display'] = intval($_GET['value']);
		DB::update($Fn_House->TableInfo,$UpData,'id = '.$iid);
		GetInsertDoLog('display_shop_house','fn_'.$_GET['mod'],array('id'=>$_GET['iid'],'display'=>$_GET['value']));//������¼
		fn_cpmsg($Fn_House->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

	}else if($Do == 'PaymentState' && $_GET['formhash'] == formhash() && $_GET['iid']){
		$iid = intval($_GET['iid']);
		$UpData['payment_state'] = intval($_GET['value']);
		DB::update($Fn_House->TableInfo,$UpData,'id = '.$iid);
		GetInsertDoLog('payment_state_shop_house','fn_'.$_GET['mod'],array('id'=>$_GET['iid'],'payment_state'=>$_GET['value']));//������¼
		fn_cpmsg($Fn_House->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

	}else if($Do == 'Deal' && $_GET['formhash'] == formhash() && $_GET['iid']){
		$iid = intval($_GET['iid']);
		$UpData['deal'] = intval($_GET['value']);
		DB::update($Fn_House->TableInfo,$UpData,'id = '.$iid);
		GetInsertDoLog('deal_shop_house','fn_'.$_GET['mod'],array('id'=>$_GET['iid'],'deal'=>$_GET['value']));//������¼
		fn_cpmsg($Fn_House->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

	}else if($Do == 'Hot' && $_GET['formhash'] == formhash() && $_GET['iid']){
		$iid = intval($_GET['iid']);
		$UpData['hot'] = intval($_GET['value']);
		DB::update($Fn_House->TableInfo,$UpData,'id = '.$iid);
		GetInsertDoLog('hot_shop_house','fn_'.$_GET['mod'],array('id'=>$_GET['iid'],'hot'=>$_GET['value']));//������¼
		fn_cpmsg($Fn_House->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

	}
}else if($SubModel == 'add'){//���ӻ�༭
	$iid = intval($_GET['iid']);
	$Item = DB::fetch_first('SELECT * FROM '.DB::table($Fn_House->TableInfo).' where id = '.$iid);
	if($Item){
		$Item['param'] = unserialize($Item['param']);
		$Item['province_text'] = $Fn_House->Area[$Item['province']]['content'].($Item['city'] ? $Fn_House->Area[$Item['city']]['content'] : '').($Item['dist'] ? $Fn_House->Area[$Item['dist']]['content'] : '');
	};
	if(!submitcheck('DetailSubmit')) {
		$OpTitle = $Fn_House->Config['LangVar']['AddTitle'];
		if($Item)$OpTitle = $Fn_House->Config['LangVar']['EditTitle'];
		if(CHARSET == 'gbk'){
			echo '<script src="'.$Fn_House->Config['StaticPath'].'/kindeditor/kindeditor-min.js" type="text/javascript"></script><script src="'.$Fn_House->Config['StaticPath'].'/kindeditor/lang/zh_cn_gbk.js" type="text/javascript"></script><script type="text/javascript" src="static/js/calendar.js"></script>';
		}else{
			echo '<script src="'.$Fn_House->Config['StaticPath'].'/kindeditor/kindeditor-min.js" type="text/javascript"></script><script src="'.$Fn_House->Config['StaticPath'].'/kindeditor/lang/zh_cn_utf.js" type="text/javascript"></script><script type="text/javascript" src="static/js/calendar.js"></script>';
		}

		//ͼƬ�ϴ�
		if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_assembly/class/class_upload.php')){
			@require_once libfile('class/upload','plugin/fn_assembly');
			$UploadConfig = fn_upload::Config();
		}

		showtagheader('div', 'infomodule', true);
		showformheader($Fn_Admin->Config['IframeSubModelUrl'].'&iid='.$iid,'enctype');
		showtableheader('','infotable');
		showtitle($OpTitle.'<input type="hidden" name="cp_msg_url" value="'.$_GET['cp_msg_url'].'">');
		
		echo '<tr><td colspan="2" class="td27 title" s="1">'.$Fn_House->Config['LangVar']['FormImagesTitle'].$Fn_House->Config['LangVar']['FormImagesSmallTitle'].'</td></tr><tr class="noborder"><td class="vtop rowform" colspan="2"><div class="PublishFormImages"><div class="PhotoControl" id="PhotoControl"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div><div class="both"></div></div></td></tr>';
		

		showsetting($Fn_House->Config['LangVar']['Title'], 'title', $Item['title'], 'text');

		showsetting($Fn_House->Config['LangVar']['ShopType'],array('vice_class', array(
			array('1',$Fn_House->Config['LangVar']['ShopTypeArray']['1'], array('rental_table' => '', 'rental_table_no' => 'none')),
			array('2',$Fn_House->Config['LangVar']['ShopTypeArray']['2'], array('rental_table' => 'none', 'rental_table_no' => '')),
			array('3',$Fn_House->Config['LangVar']['ShopTypeArray']['3'], array('rental_table' => 'none', 'rental_table_no' => '')),
		), TRUE),$Item['vice_class'], 'mradio');
		
		
		$SmallAreaPositionTreelistHtml = GetTreelistHtml($Fn_House->Area,'SmallAreaPositionList',$Item['province'],$Item['city'],$Item['dist']);//С��λ��
		echo '<tr><td colspan="2" class="td27 title">'.$Fn_House->Config['LangVar']['HouseArea'].':</td></tr><tr class="noborder"><td class="vtop rowform"><div style="position:relative;height:40px"><input value="'.$Item['province_text'].'" class="input TreeList" type="text" id="SmallAreaPosition">'.$SmallAreaPositionTreelistHtml.'</div></td><td class="vtop tips2" s="1"><input type="hidden" name="province" value="'.$Item['province'].'"/><input type="hidden" name="city" value="'.$Item['city'].'"/><input type="hidden" name="dist" value="'.$Item['dist'].'"/>
		
		<div class="Tagging" onclick="return biaozhu();"><span class="ic">&#xe68c;</span>'.$Fn_House->Config['LangVar']['Tagging'].'</div><div id="MapIframe" DataShow=""><div id="AllMap"></div><div class="bottom"><div class="left"><input type="text" class="search_txt" id="search_txt" /><button type="button" class="search_btn" onclick="get_point()">'.$Fn_Admin->Config['LangVar']['Lookup'].'</button></div><div class="right"><a href="javascript:void(0);" onClick="return biaozhu_ok();" class="btn_blue">'.$Fn_Admin->Config['LangVar']['DefiniteAnnotation'].'</a><a href="javascript:void(0);" onClick="return biaozhu_cancel();" class="btn_gray">'.$Fn_Admin->Config['LangVar']['MsgBox_no'].'</a></div></div></div><input type="hidden" name="lat" value="'.$Item['lat'].'"/><input type="hidden" name="lng" value="'.$Item['lng'].'"/>
	
		</td></tr>';

		showsetting($Fn_House->Config['LangVar']['Community'].$Fn_House->Config['LangVar']['community'], 'community', $Item['community'], 'text');

		showsetting($Fn_House->Config['LangVar']['SmallAreaTo'], 'small_area', $Item['small_area'], 'text');

		showsetting($Fn_House->Config['LangVar']['HouseFloorPosition'], 'count_floor', $Item['count_floor'], 'text');

		showsetting($Fn_House->Config['LangVar']['Square'], 'square', $Item['square'], 'text','','',$Fn_House->Config['LangVar']['SquareMetre']);
		
		
		$RentalTableDisplay = $Item['vice_class'] == 1 ? true : false;
		$RentalTableNoDisplay = $Item['vice_class'] != 1 ? true : false;
		
		showtagheader('tbody', 'rental_table', $RentalTableDisplay, 'sub');
			showsetting($Fn_House->Config['LangVar']['Rent'], 'rental_price', $Item['price'], 'text');
			showsetting($Fn_House->Config['LangVar']['RentTimeUnit'],array('price_time',DyadicArray($Fn_House->Config['LangVar']['RentTimeArray'])),$Item['param']['price_time'],'select');
			//showsetting($Fn_House->Config['LangVar']['Deposit'],array('deposit',DyadicArray($Fn_House->Config['LangVar']['DepositArray'])),$Item['deposit'],'select');
		showtagfooter('tbody');

		showtagheader('tbody', 'rental_table_no', $RentalTableNoDisplay, 'sub');
			showsetting($Fn_House->Config['LangVar']['JiaGe'], 'price', $Item['price'], 'text','','',$Fn_House->Config['LangVar']['Wan']);
		showtagfooter('tbody');



		showsetting($Fn_House->Config['LangVar']['ManagementTpye'],array('management_type',DyadicArray($Fn_House->Config['LangVar']['ManagementTpyeArray'],$Fn_House->Config['LangVar']['SelectNullTo'])),$Item['management_type'],'select');

		showsetting($Fn_House->Config['LangVar']['ShopTypeTo'],array('shops_type',DyadicArray($Fn_House->Config['LangVar']['ShopManagementTypeArray'],$Fn_House->Config['LangVar']['SelectNullTo'])),$Item['shops_type'],'select');

		showsetting($Fn_House->Config['LangVar']['CharacteristicTagTitle'],array('tag[]',DyadicArray($Fn_House->Config['LangVar']['ShopTagArray'])),explode(',',$Item['tag']),'mselect','','',$Fn_Admin->Config['LangVar']['Ctrl']);


		//��������
		echo '<tr><td colspan="2" class="td27 title" s="1">'.$Fn_House->Config['LangVar']['HouseContent'].'</td></tr><tr class="noborder"><td class="vtop rowform" colspan="2"><textarea id="content" name="content" style="width:80%;height:300px;visibility:hidden;">'.stripslashes($Item['param']['content']).'</textarea></td></tr>';

		showsetting($Fn_House->Config['LangVar']['Contacts'], 'name', $Item['name'], 'text');
		showsetting($Fn_House->Config['LangVar']['ContactNumber'], 'mobile',$Item['param']['mobile'], 'text');
		showsetting($Fn_House->Config['LangVar']['WxTitle'], 'wx', $Item['param']['wx'], 'text');

		showsetting("Uid", 'uid', $Item['uid'] ? $Item['uid'] : $_G['uid'], 'text');
		
		showsetting($Fn_House->Config['LangVar']['NatureTo'],array('publish_type',DyadicArray($Fn_House->Config['LangVar']['PublishTypeArray'])),$Item ? $Item['publish_type'] : 1,'mradio');

		showsetting($Fn_House->Config['LangVar']['DisplayTitle'], 'display', $Item ? $Item['display'] : 1, 'radio');
		
		showsetting($Fn_House->Config['LangVar']['PaymentState'],array('payment_state',DyadicArray($Fn_House->Config['LangVar']['PaymentStateArray'])),$Item ? $Item['payment_state'] : 1,'mradio');

		showsetting($Fn_House->Config['LangVar']['DealState'],array('deal',DyadicArray($Fn_House->Config['LangVar']['DealStateArray'])),$Item['deal'],'mradio');

		showsetting($Fn_House->Config['LangVar']['SetTopTime'], 'topdateline',$Item['topdateline'] ? date('Y-m-d H:i',$Item['topdateline']) : '', 'calendar','','','',1);
		
		if($Item['updateline']){
			showsetting($Fn_House->Config['LangVar']['RefreshTime'], 'updateline',$Item['updateline'] ? date('Y-m-d H:i',$Item['updateline']) : '', 'calendar','','','',1);
		}
		if($Item['dateline']){
			showsetting($Fn_House->Config['LangVar']['TimeTitle'], 'dateline',date('Y-m-d H:i',$Item['dateline']), 'calendar','','','',1);
		}

		showtablefooter(); /*dism��taobao��com*/
		showsubmit('DetailSubmit');
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');

		if($Item['param']['images']){
			foreach($Item['param']['images'] as $Key => $Val) {
				$JsArray[] = '"'.$Val.'"';
			}
			$UpLoadHtml = '
			var InputArray = new Array('.implode(',',$JsArray).');
			jQuery("#PhotoControl").AppUpload({InputName:"new_images",InputExist:true,InputArray:InputArray})';

		}else{
			$UpLoadHtml = 'jQuery("#PhotoControl").AppUpload({InputName:"new_images"});';
		}

		echo '<script type="text/javascript" src="static/js/calendar.js"></script><script type="text/javascript" src="'.$Fn_Admin->Config['StaticPath'].'/js/jquery.js"></script><script type="text/javascript" src="'.$Fn_Admin->Config['StaticPath'].'/js/common.js"></script><script src="source/plugin/fn_assembly/static/js/mobiscroll.custom-2.16.1.min.js"></script><link rel="stylesheet" href="source/plugin/fn_assembly/static//css/mobiscroll.custom-2.16.1.min.css"><script type="text/javascript" src="https://api.map.baidu.com/api?v=2.0&ak='.$Fn_House->Config['PluginVar']['MapKey'].'&s=1"></script>'.$UploadConfig['CssJsHtml'];

		echo '
			<style>.PublishFormImages .PhotoControl{width:80px;line-height:80px;height:80px;font-size:28px;margin-right:10px;}.PublishFormImages .PhotoControl .Close{width:20px;height:20px;}.TreeList{position: absolute;left:0;top:0;z-index:1;}.Tmp{opacity:0;}.Tagging span{font-size:18px;}.Tagging{cursor: pointer;}</style>
			<script>
			jQuery.noConflict();
			window["CITY"] = "'.$Fn_House->Config['PluginVar']['DefaultCity'].'";
			'.$UpLoadHtml.'
			
			jQuery(document).on("click","#SmallAreaPosition",function(){
				GetTreeList(jQuery(this),"SmallAreaPositionList","province","city","dist");
				return false;
			});
			function GetTreeList(_This,Id,InputName,InputName2,InputName3){
				var I = jQuery("#"+Id).children("li.Default").attr("Index");
				var J = jQuery("#"+Id).find("ul.Children").children("li.Default").attr("Index");
				var K = jQuery("#"+Id).find("ul.Childrens").children("li.Default").attr("Index");
				jQuery("#"+Id).mobiscroll().treelist({  
					theme: "android-holo-light",
					lang: "zh",  
					display: "bottom",  
					inputClass: "Tmp",  
					headerText: "'.$Fn_XiangQin->Config['LangVar']['SelectNullTo'].'",  
					onSelect: function (ValueText,Inst) {  
						var N = ValueText.split(" ");
						var Obj1 = jQuery(this).children("li").eq(N[0]);
						var Obj2 = Obj1.find("ul.Children").children("li").eq(N[1]);
						var Obj3 = Obj2.find("ul.Childrens").children("li").eq(N[2]);
						var Text1 = typeof(Obj1.attr("DataContnet")) == "undefined" ? "" : Obj1.attr("DataContnet");
						var Value1 = typeof(Obj1.attr("DataValue")) == "undefined" ? "" : Obj1.attr("DataValue");
						var Text2 = typeof(Obj2.attr("DataContnet")) == "undefined" ? "" : Obj2.attr("DataContnet");
						var Value2 = typeof(Obj2.attr("DataValue")) == "undefined" ? "" : Obj2.attr("DataValue");
						var Text3 = typeof(Obj3.attr("DataContnet")) == "undefined" ? "" : Obj3.attr("DataContnet");
						var Value3 = typeof(Obj3.attr("DataValue")) == "undefined" ? "" : Obj3.attr("DataValue");
						Obj1.addClass("Default").siblings().removeClass("Default");
						Obj2.addClass("Default").siblings().removeClass("Default");
						Obj3.addClass("Default").siblings().removeClass("Default");
						_This.val(Text1+Text2+Text3);
						jQuery("input[name=\'"+InputName+"\']").val(Value1);
						jQuery("input[name=\'"+InputName2+"\']").val(Value2);
						jQuery("input[name=\'"+InputName3+"\']").val(Value3);
					},
					defaultValue:[I,J,K]
				});  
				jQuery("input[id^="+Id+"]").focus(); 
			}
	
			var options = {  
			filterMode : true,  
			allowImageUpload : true,  
			allowFlashUpload : false,  
			allowMediaUpload : false,  
			allowFileManager : false,  
			items : ["source", "|", "fullscreen", "undo", "redo", "print", "cut", "copy", "paste",
				"plainpaste", "wordpaste", "|", "justifyleft", "justifycenter", "justifyright",
				"justifyfull", "insertorderedlist", "insertunorderedlist", "indent", "outdent", "subscript",
				"superscript", "|", "selectall", "clearhtml","quickformat","|",
				"formatblock", "fontname", "fontsize", "|", "forecolor", "hilitecolor", "bold",
				"italic", "underline", "strikethrough", "lineheight", "removeformat", "|", "image", "table", "hr", "emoticons", "link", "unlink", "|", "about"]
			};  
			var editor = new Array();  
			KindEditor.ready(function(K) {  
			editor[0] = K.create("#content",options);
			});  
			</script> 	
		';
	}else{

		$Data['title'] = addslashes(strip_tags($_GET['title']));
		$Data['province'] = addslashes(strip_tags($_GET['province']));
		$Data['city'] = addslashes(strip_tags($_GET['city']));
		$Data['dist'] = addslashes(strip_tags($_GET['dist']));
		$Data['community'] = addslashes(strip_tags($_GET['community']));
		$Data['small_area'] = addslashes(strip_tags($_GET['small_area']));
		$Data['lat'] = addslashes(strip_tags($_GET['lat']));
		$Data['lng'] = addslashes(strip_tags($_GET['lng']));
		$Data['count_floor'] = intval($_GET['count_floor']);
		$Data['square'] = intval($_GET['square']);
		$Data['price'] = $Item['vice_class'] == 1 ? addslashes(strip_tags($_GET['rental_price'])) : addslashes(strip_tags($_GET['price']));
		$Data['deposit'] = $Item['vice_class'] == 1 ? intval($_GET['deposit']) : '';
		$Data['management_type'] = intval($_GET['management_type']);
		$Data['shops_type'] = intval($_GET['shops_type']);

		$Data['tag'] = is_array($_GET['tag']) && isset($_GET['tag']) ? implode(',',$_GET['tag']) : '';

		$Data['uid'] = intval($_GET['uid']);
		$Data['name'] = addslashes(strip_tags($_GET['name']));
		$Data['publish_type'] = intval($_GET['publish_type']);
		$Data['display'] = intval($_GET['display']);
		$Data['payment_state'] = intval($_GET['payment_state']);
		$Data['deal'] = intval($_GET['deal']);
		
		$Data['class'] = 3;
		$Data['vice_class'] = intval($_GET['vice_class']);
		

		foreach(array_filter(explode(",",$Data['tag'])) as $Key => $Val) {
			$Param['tag_list'][] = $Fn_House->Config['LangVar']['ShopTagArray'][$Val];
		}

		$Param['content'] = addslashes($_GET['content']);//�豣��Html
		$Param['mobile'] = addslashes(strip_tags($_GET['mobile']));
		$Param['wx'] = addslashes(strip_tags($_GET['wx']));
		$Param['price_time'] = intval($_GET['price_time']);
		
		foreach($_GET['new_images'] as $Key => $Val) {
			$_GET['new_images'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}
		$Param['images'] = is_array($_GET['new_images']) && isset($_GET['new_images'])  ? array_filter($_GET['new_images']) : '';
		$Param['cover'] = $_GET['new_images'][0];

		$Member = DB::fetch_first('SELECT username FROM '.DB::table('common_member').' where uid = '.$Data['uid']);
		$Data['username'] = addslashes(strip_tags($Member['username']));
		$Data['param'] = serialize($Param);
		$Data['topdateline'] = $_GET['topdateline'] ? strtotime($_GET['topdateline']) : '';

		if($Item){
			$Data['dateline'] = strtotime($_GET['dateline']);
			$Data['updateline'] = strtotime($_GET['updateline']);
			DB::update($Fn_House->TableInfo,$Data,'id = '.$iid);
			GetInsertDoLog('edit_shop_house','fn_'.$_GET['mod'],array('id'=>$Item['id']));//������¼
		}else{
			$Data['dateline'] = $Data['updateline'] = time();
			$Id = DB::insert($Fn_House->TableInfo,$Data,true);
			GetInsertDoLog('add_shop_house','fn_'.$_GET['mod'],array('id'=>$Id));//������¼
		}

		fn_cpmsg($Fn_House->Config['LangVar']['UpdateOk'],($_GET['cp_msg_url'] ? $_GET['cp_msg_url'] : $Fn_Admin->Config['IframeItemUrl'].'&submodel=list'),'succeed');

	}
}
/* �б� */
function GetModulesList($Page,$Limit,$Where=null,$Order){
	global $Fn_House;
	$FetchSql = 'SELECT I.* FROM '.DB::table($Fn_House->TableInfo).' I '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}

/* ���� */
function GetModulesCount($Where=null){
	global $Fn_House;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_House->TableInfo).' I '.$Where;
	return DB::result_first($FetchSql);//��������
}

?>