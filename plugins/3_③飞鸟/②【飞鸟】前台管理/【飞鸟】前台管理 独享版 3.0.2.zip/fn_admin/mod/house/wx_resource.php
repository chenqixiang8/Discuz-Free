<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('house_all') && !$Fn_Admin->CheckUserGroup('house_wx_resource')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

@require_once libfile('function/cache');
@require_once libfile('function/core','plugin/fn_assembly');

$SubModel = in_array($_GET['submodel'], array('list','add')) ? $_GET['submodel'] : 'list';
$Fn_Admin->Config['IframeSubModelUrl'] = $Fn_Admin->Config['IframeItemUrl'].'&submodel='.$SubModel;
$NavClass = array($SubModel=>'btn-info Hover');

if($SubModel == 'list'){//�б�
	$Do = in_array($_GET['do'], array('Refresh','Del','Display')) ? $_GET['do'] : 'submodel_list';
	//�����ֶ�
	$SearField =array('page','keyword','merge','display','order');
	foreach($SearField as $Val) {
		$SearArray[$Val] = $_GET[$Val] || in_array($_GET[$Val],array('0')) ? $_GET[$Val] : '';
	}
	//�����ֶ� End
	$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeSubModelUrl'].'&'.http_build_query($SearArray);
	
	if($Do == 'submodel_list'){
		if(!submitcheck('Submit')) {
			$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
			$Where = ' and r.plugin  = \'fn_'.$_GET['mod'].'\'';
			$Order = $_GET['order'] ? 'r.'.addslashes(dhtmlspecialchars($_GET['order'])) : 'r.id';
			
			if($_GET['keyword']){
				$_GET['keyword'] = str_replace(array('%','_'),array('',''),$_GET['keyword']);
				$Where .= ' and (r.title like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') )';
			}
			
			if(in_array($_GET['merge'],array('0','1'))){
				$Where .= ' and r.merge = '.intval($_GET['merge']);
			}

			if(in_array($_GET['display'],array('0','1'))){
				$Where .= ' and r.display = '.intval($_GET['display']);
			}

			$Where = preg_replace('/and/','where',$Where,1);
			$Limit = 20;
			$Page = $_GET['page']?intval($_GET['page']):1;
			/* ��ѯ���� End */
			

			/* ģ����� */	
			showtagheader('div', 'row', true,'row');
			showtagheader('div', 'col-12', true,'col-12');
			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-body', true,'box-body');
			/* ���� */
			
			$MergeSelected = array($_GET['merge']=>' selected');
			$DisplaySelected = array($_GET['display']=>' selected');
			$OrderSelected = array($_GET['order']=>' selected');
		
			echo <<<SEARCH
			<form method="post" autocomplete="off" action="$SearUrl">
				<div class="FormSearchTo" style="margin-bottom:0;">
					<table cellspacing="4" cellpadding="4">
						<tr>
							<th>&#20851;&#38190;&#35789;&#32;</th><td><input type="text" class="input form-control w200" name="keyword" value="{$_GET['keyword']}" placeholder="&#35831;&#36755;&#20837;&#26631;&#39064;">
							</td>
							<th>&#26159;&#21542;&#32452;&#21512;&#32032;&#26448;</th><td>
							<select name="merge" class="form-control w100">
								<option value="">{$Fn_Admin->Config['LangVar']['SelectNull']}</option>
								<option value="1"{$MergeSelected['1']}>{$Fn_Admin->Config['LangVar']['Yes']}</option>
								<option value="0"{$MergeSelected['0']}>{$Fn_Admin->Config['LangVar']['No']}</option>
							</select>
							</td>
							<th>{$Fn_Admin->Config['LangVar']['DisplayTitle']}</th><td>
							<select name="display" class="form-control w100">
								<option value="">{$Fn_Admin->Config['LangVar']['SelectNull']}</option>
								<option value="1"{$DisplaySelected['1']}>{$Fn_Admin->Config['LangVar']['Yes']}</option>
								<option value="0"{$DisplaySelected['0']}>{$Fn_Admin->Config['LangVar']['No']}</option>
							</select>
							</td>
							<th>{$Fn_Admin->Config['LangVar']['Order']}</th><td>
							<select name="order" class="form-control w120">
								<option value="dateline"{$OrderSelected['dateline']}>{$Fn_Admin->Config['LangVar']['OrderArray']['dateline']}</option>
								<option value="updateline"{$OrderSelected['updateline']}>{$Fn_Admin->Config['LangVar']['OrderArray']['updateline']}</option>
							</select>
							&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Admin->Config['LangVar']['SearchSubmit']}" class="btn btn-info" type="submit">
							&nbsp;&nbsp;<a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=add" target="_self" class="btn btn-danger">{$Fn_Admin->Config['LangVar']['AddEditTitle']}</a>
							</td>
						</tr>
					</table>
				</div>
			</form>
SEARCH;
			/* ���� End */
			showtagheader('div', 'table-responsive', true,'table-responsive');
			showformheader($FormUrl,'enctype="multipart/form-data"');
			showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
			showsubtitle(array(
				'ID',
				'&#26631;&#39064;',
				'&#23553;&#38754;',
				'&#25688;&#35201;',
				'&#21407;&#25991;&#38142;&#25509;',
				'&#26159;&#21542;&#32452;&#21512;&#32032;&#26448;',
				'&#26159;&#21542;&#26174;&#31034;',
				'&#28155;&#21152;&#26102;&#38388;',
				'&#21047;&#26032;&#26102;&#38388;',
				'&#25805;&#20316;'
			),'header tbm tc');

			$ModulesList = GetModulesList($Page,$Limit,$Where,$Order);
			foreach ($ModulesList as $Module) {
				
				showtablerow('', array('class="tc w80"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
					'<input type="checkbox" class="filled-in" id="checkbox_'.$Module['id'].'" name="delete[]" value="'.$Module['id'].'"><label for="checkbox_'.$Module['id'].'">'.$Module['id'].'</label>',
					$Module['title'],
					$Module['pic'] ? '<a href="'.$Module['pic'].'" target="_blank"><img src="'.$Module['pic'].'" style="height:30px;"></a>' : ($Module['merge'] ? '&#32032;&#26448;&#73;&#68;&#65306;'.$Module['merge_id'] : ''),
					$Module['desc'],
					$Module['url'] ? '<a href="'.$Module['url'].'" target="_blank">&#26597;&#30475;</a>' : '',
					!$Module['merge'] ? '<span class="label bg-secondary">'.$Fn_Admin->Config['LangVar']['No'].'</span>' : '<span class="label bg-blue">'.$Fn_Admin->Config['LangVar']['Yes'].'</span>',
					!$Module['display'] ? '<span class="label bg-secondary">'.$Fn_Admin->Config['LangVar']['No'].'</span>' : '<span class="label bg-blue">'.$Fn_Admin->Config['LangVar']['Yes'].'</span>',
					date('Y-m-d H:i',$Module['dateline']),
					date('Y-m-d H:i',$Module['updateline']),
					'<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&vid='.$Module['id'].'" class="btn btn-sm btn-info-outline">'.$Fn_Admin->Config['LangVar']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Refresh&vid='.$Module['id'].'&formhash='.FORMHASH.'" class="btn btn-sm btn-primary-outline">&#21047;&#26032;</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Display&vid='.$Module['id'].'&value='.(!empty($Module['display']) ? 0:1).'&formhash='.FORMHASH.'" class="btn btn-sm btn-purple-outline">'.(!empty($Module['display']) ? $Fn_Admin->Config['LangVar']['DisplayNoTitle'] : $Fn_Admin->Config['LangVar']['DisplayIsTitle']).'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Del&vid='.$Module['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$Fn_Admin->Config['LangVar']['DelTitle'].'</a>',

				));
			}
			showsubmit('Submit','&#31435;&#21363;&#25552;&#20132;','del','','',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));
			showtablefooter(); /*dism��taobao��com*/
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			/* ģ�����End */	
		}else{
			if(isset($_GET['delete']) && is_array($_GET['delete'])){
				foreach($_GET['delete'] as $Key => $Val) {
					$Val = intval($Val);
					DB::delete('fn_wx_resource','id ='.$Val);
	
				}
				fn_cpmsg($Fn_Admin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
			}else{
				fn_cpmsg($Fn_Admin->Config['LangVar']['DelErr'],'','error');
			}
				
		}
	}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['vid']){

		$id = intval($_GET['vid']);
		DB::delete('fn_wx_resource','id ='.$id);
		fn_cpmsg($Fn_Admin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
	}else if($Do == 'Refresh' && $_GET['formhash'] == formhash() && $_GET['vid']){
		$id = intval($_GET['vid']);
		$UpData['updateline'] = time();
		DB::update('fn_wx_resource',$UpData,'id = '.$id);
		fn_cpmsg($Fn_Admin->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

	}else if($Do == 'Display' && $_GET['formhash'] == formhash() && $_GET['vid']){
		$id = intval($_GET['vid']);
		$UpData['display'] = intval($_GET['value']);
		DB::update('fn_wx_resource',$UpData,'id = '.$id);
		fn_cpmsg($Fn_Admin->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

	}
}else if($SubModel == 'add'){//���ӻ�༭
	
	$id = intval($_GET['vid']);

	$Item = DB::fetch_first('SELECT * FROM '.DB::table('fn_wx_resource').' where id = '.$id);
	
	if(!submitcheck('DetailSubmit')) {
		$OpTitle = $Item ? $Fn_Admin->Config['LangVar']['EditTitle'] : $Fn_Admin->Config['LangVar']['AddTitle'];

		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-header', true,'with-border box-header');
		showtitle($OpTitle,'class="box-title"');
		showtagfooter('div');
		showformheader($Fn_Admin->Config['IframeSubModelUrl'].'&vid='.$id,'enctype');
		showtagheader('div', 'box-body', true,'box-body');
		
		showsetting('&#26159;&#21542;&#32452;&#21512;&#32032;&#26448;',array('merge', array(
			array('1','&#26159;', array('merge_1' => '','merge_0' => 'none')),
			array('0','&#21542;', array('merge_1' => 'none','merge_0' => '')),
		), TRUE),$Item['merge'], 'mradio');
		
		showsetting('&#26631;&#39064;', 'title', $Item['title'], 'text');

		showtagheader('div', 'merge_1', $Item['merge'] ? true : '','sub');
			showsetting('&#32032;&#26448;&#73;&#68;', 'merge_id', $Item['merge_id'], 'text','','','&#35831;&#22635;&#20889;&#32032;&#26448;&#73;&#68;&#65292;&#26684;&#24335;&#65306;&#49;&#44;&#50;&#44;&#51;');
		showtagfooter('div');

		showtagheader('div', 'merge_0', !$Item['merge'] ? true : '','sub');
			$pic_html = ($Item['pic'] ? '<a href="'.$Item['pic'].'" target="_blank" style="margin:0 5px 0 0;"><img src="'.$Item['pic'].'" height="55"/></a>' : '');
			showsetting('&#23553;&#38754;', 'new_pic',$Item['pic'], 'filetext', '', 0, $pic_html);
			showsetting('&#25688;&#35201;', 'desc', $Item['desc'], 'textarea');
			showsetting('&#21407;&#25991;&#38142;&#25509;', 'url', $Item['url'], 'text');
		showtagfooter('div');
		
		showsetting('&#26159;&#21542;&#26174;&#31034;', 'display', $Item ? $Item['display'] : 1, 'radio');

		if($Item['updateline']){
			showsetting('&#26356;&#26032;&#26102;&#38388;', 'updateline',$Item['updateline'] ? date('Y-m-d H:i',$Item['updateline']) : '', 'calendar','','','',1);
		}

		if($Item['dateline']){
			showsetting('&#28155;&#21152;&#26102;&#38388;', 'dateline',date('Y-m-d H:i',$Item['dateline']), 'calendar','','','',1);
		}

		showsubmit('DetailSubmit','&#20445;&#23384;&#37197;&#32622;');
		showtagfooter('div');
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');
	}else{
		
		$Data['plugin'] = 'fn_'.$_GET['mod'];
		$Data['merge'] = intval($_GET['merge']);
		$Data['merge_id'] = addslashes(strip_tags($_GET['merge_id']));
		$Data['display'] = intval($_GET['display']);
		$Data['title'] = addslashes(strip_tags($_GET['title']));
		$Data['desc'] = addslashes(strip_tags($_GET['desc']));
		$Data['content'] = addslashes(strip_tags($_GET['content']));
		$Data['url'] = addslashes(strip_tags($_GET['url']));
		$Data['display'] = intval($_GET['display']);

		foreach($_FILES as $file_key => $file_value){
			if(strpos($file_key,'new_') !== false){
				$key = str_replace(array('TMPnew_','new_'),'',$file_key);
				if($_FILES[$file_key]['size']){
					$FileCode = Fn_Upload($_FILES[$file_key]);
					if($FileCode['Errorcode']){
						fn_cpmsg($Fn_Admin->Config['LangVar']['ImgErr'],'','error');
						exit();
					}else{
						$Data[$key] = $FileCode['Path'];
					}
				}else{
					$file_key = str_replace(array('TMPnew_'),array('new_'),$file_key);
					if(!preg_match('/.*(\.png|\.jpg|\.jpeg|\.gif)$/',$_GET[$file_key]) && $_GET[$file_key]){
						fn_cpmsg($Fn_Admin->Config['LangVar']['ImgErr'],'','error');
						exit();
					}else{
						$Data[$key] = addslashes(strip_tags($_GET[$file_key]));
					}
				}
				if($Data[$key]){
					$Data[$key] = strpos($Data[$key],'http') !== false ? $Data[$key] : $_G['siteurl'].$Data[$key];
				}
			}
		}
;
		
		if($Item){
			$Data['updateline'] = strtotime($_GET['updateline']);
			$Data['dateline'] = strtotime($_GET['dateline']);
			DB::update('fn_wx_resource',$Data,'id = '.$id);
		}else{
			$Data['dateline'] = $Data['updateline'] = time();
			DB::insert('fn_wx_resource',$Data);
		}
		fn_cpmsg($Fn_Admin->Config['LangVar']['UpdateOk'],$Fn_Admin->Config['IframeItemUrl'].'&submodel=list','succeed');
	}
}


/* �б� */
function GetModulesList($Page,$Limit,$Where=null,$Order){
	$FetchSql = 'SELECT * FROM '.DB::table('fn_wx_resource').' r '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}

/* ���� */
function GetModulesCount($Where=null){
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table('fn_wx_resource').' r '.$Where;
	return DB::result_first($FetchSql);//��������
}

?>