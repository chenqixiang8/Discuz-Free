<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('house_all') && !$Fn_Admin->CheckUserGroup('house_disc_access_record_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$Do = in_array($_GET['do'], array('Del','State')) ? $_GET['do'] : 'List';

//�����ֶ�
$SearField =array('page','keyword','iid','updateline');
foreach($SearField as $Val) {
	$SearArray[$Val] = $_GET[$Val] || in_array($_GET[$Val],array('0')) ? $_GET[$Val] : '';
}
//�����ֶ� End

$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeItemUrl'].'&'.http_build_query($SearArray);

if($Do == 'List'){
	if(!submitcheck('Submit')) {
		$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
		/* ��ѯ���� */
		$Where = '';
		$Order = in_array($_GET['order'], array('updateline')) ? 'E.'.addslashes(dhtmlspecialchars($_GET['order'])) : 'L.updateline';

		if(str_replace(array('%','_'),array('',''),$_GET['keyword'])){

			$Where .= ' and (L.username like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or L.uid = '.intval($_GET['keyword']).' )';
		}
		
		if($_GET['iid']){
			$Where .= ' and L.iid = '.intval($_GET['iid']);
		}

		$Where = preg_replace('/and/','where',$Where,1);
		$Limit = 20;
		$Page = $_GET['page']?intval($_GET['page']):1;
		/* ��ѯ���� End */
		
		/* ģ����� */
		/* ���� */
		showtagheader('div', 'row', true,'row');
		showtagheader('div', 'col-12', true,'col-12');
		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-body', true,'box-body');
		echo <<<SEARCH
		<form method="post" autocomplete="off" action="$SearUrl" id="tb_search">
			<div class="FormSearchTo">
				<table cellspacing="4" cellpadding="4">
					<tr>
						<th>&#27004;&#30424;&#73;&#68;</th><td><input type="text" class="form-control w150" name="iid" value="{$_GET['iid']}">
						</td>
						<th>{$Fn_House->Config['LangVar']['KeywordTitle']}</th><td><input type="text" class="form-control w150" name="keyword" value="{$_GET['keyword']}">
						&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Admin->Config['LangVar']['SearchSubmit']}" class="btn btn-info" type="submit">
						</td>
					</tr>
				</table>
			</div>
		</form>
SEARCH;
		/* ���� End */

		showtagheader('div', 'table-responsive', true,'table-responsive');
		showformheader($FormUrl,'enctype="multipart/form-data"');
		showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
		showsubtitle(array(
			'ID',
			$Fn_House->Config['LangVar']['Title'],
			'Uid/'.$Fn_House->Config['LangVar']['UserNameTitle'],
			$Fn_House->Config['LangVar']['Mobile'],
			$Fn_House->Config['LangVar']['TimeTitle'],
			$Fn_House->Config['LangVar']['UpdateTime'],
			$Fn_House->Config['LangVar']['OperationTitle']
		), 'header tbm tc');
		
		$ModulesList = GetModulesList($Page,$Limit,$Where,$Order);
		
		foreach ($ModulesList as $Module) {
			$Mobile = GetMobile($Module['uid']);
			showtablerow('', array('class="tc w80"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
				'<input type="checkbox" class="filled-in" id="checkbox_'.$Module['id'].'" name="delete[]" value="'.$Module['id'].'"><label for="checkbox_'.$Module['id'].'">'.$Module['id'].'</label>',
				'<a href="'.$Fn_House->Config['ViewDiscUrl'].$Module['iid'].'" target="_blank">'.$Module['title'].'</a>',
				$Module['uid'] ? $Module['uid'].'/'.$Module['username'] : '',
				$Mobile,
				date('Y-m-d H:i',$Module['dateline']),
				$Module['updateline'] ? date('Y-m-d H:i',$Module['updateline']) : '',
				'<a href="'.$OpCpUrl.'&do=Del&lid='.$Module['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$Fn_House->Config['LangVar']['DelTitle'].'</a>',
			));
		}
		showsubmit('Submit','&#31435;&#21363;&#25552;&#20132;','del','','',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));
        showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		/* ģ����� End */
	}else{
			if(!$Fn_Admin->CheckUserGroup('house_all') && !$Fn_Admin->CheckUserGroup('house_disc_del_access_record_list')){//Ȩ���ж�
				fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
				exit();
			}

			if(isset($_GET['delete']) && is_array($_GET['delete'])){
				foreach($_GET['delete'] as $Key => $Val) {
					$Val = intval($Val);
					DB::delete($Fn_House->TableDiscLog,'id ='.$Val);
					
				}
				GetInsertDoLog('del_disc_access_record_list_house','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete'])));//������¼

				fn_cpmsg($Fn_House->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
			}else{
				fn_cpmsg($Fn_House->Config['LangVar']['DelErr'],'','error');
			}
				
		}
}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['lid']){//ɾ��
	if(!$Fn_Admin->CheckUserGroup('house_all') && !$Fn_Admin->CheckUserGroup('house_disc_del_access_record_list')){//Ȩ���ж�
		fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
		exit();
	}
	$Lid = intval($_GET['lid']);
	DB::delete($Fn_House->TableDiscLog,'id ='.$Lid);
	
	GetInsertDoLog('del_disc_access_record_list_house','fn_'.$_GET['mod'],array('id'=>$_GET['lid']));//������¼

	fn_cpmsg($Fn_House->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
}

/* �б� */
function GetModulesList($Page,$Limit,$Where=null,$Order){
	global $Fn_House;
	$FetchSql = 'SELECT D.title,L.* FROM '.DB::table($Fn_House->TableDiscLog).' L LEFT JOIN `'.DB::table($Fn_House->TableDisc).'` D on D.id = L.iid '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}

/* ���� */
function GetModulesCount($Where=null){
	global $Fn_House;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_House->TableDiscLog).' L '.$Where;
	return DB::result_first($FetchSql);//��������
}
//From: Dism_taobao_com
?>