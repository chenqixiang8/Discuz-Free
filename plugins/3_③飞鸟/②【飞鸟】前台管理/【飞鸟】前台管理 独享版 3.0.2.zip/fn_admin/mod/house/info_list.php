<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('house_all') && !$Fn_Admin->CheckUserGroup('house_info_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$SubModel = in_array($_GET['submodel'], array('list','add')) ? $_GET['submodel'] : 'list';
$Fn_Admin->Config['IframeSubModelUrl'] = $Fn_Admin->Config['IframeItemUrl'].'&submodel='.$SubModel;

$_GET['list_class'] = $_GET['list_class'] ? $_GET['list_class'] : 1;

//����
$LiHtml = '';
foreach ($Fn_House->Config['PluginVar']['ModularList'] as $Val) {
	$LiHtml .= '<li class="'.($Val == $_GET['list_class'] ? 'btn-info Hover' : '').'"><a href="'.$Fn_Admin->Config[IframeItemUrl].'&submodel=list&list_class='.$Val.'" target="_self">'.$Fn_House->Config['LangVar']['IndexNavArray'][$Val].$Fn_Admin->Config['LangVar']['Administration'].'</a></li>';
}
echo <<<Nav
<div class="SubModelNav">
  <ul>
    {$LiHtml}
  </ul>
  <div class="both"></div>
</div>
Nav;

if($SubModel == 'list'){//�б�
	$Do = in_array($_GET['do'], array('Refresh','Del','Display','PaymentState','Deal','Hot')) ? $_GET['do'] : 'submodel_list';
	//�����ֶ�
	$SearField =array('page','keyword','payment_state','display','deal','order','hot','publish_type','list_class','agent_id','overdue','iid');
	foreach($SearField as $Val) {
		$SearArray[$Val] = $_GET[$Val] || in_array($_GET[$Val],array('0')) ? $_GET[$Val] : '';
	}
	//�����ֶ� End
	$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeSubModelUrl'].'&'.http_build_query($SearArray);


	if($Do == 'submodel_list'){
		if(!submitcheck('Submit')) {
			$SearUrl = $Fn_Admin->Config['IframeItemUrl'].'&list_class='.$_GET['list_class'];
			$Where = ' ';
			$Order = $_GET['order'] ? 'I.'.addslashes(dhtmlspecialchars($_GET['order'])) : 'I.id';

			if($_GET['keyword']){
				$_GET['keyword'] = str_replace(array('%','_'),array('',''),$_GET['keyword']);
				$Where .= ' and (I.title like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or I.name like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or I.small_area like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or I.username like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or I.param like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or I.mobile like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or I.uid = '.intval($_GET['keyword']).' )';
			}

			if($_GET['iid']){
				$Where .= ' and I.id = '.intval($_GET['iid']);
			}
			
			if($_GET['list_class']){
				$Where .= ' and I.class = '.intval($_GET['list_class']);
			}

			if($_GET['agent_id']){
				$Where .= ' and I.agent_id = '.intval($_GET['agent_id']);
			}

			if(in_array($_GET['publish_type'],array('1','2'))){
				$Where .= ' and I.publish_type = '.intval($_GET['publish_type']);
			}

			if(in_array($_GET['overdue'],array('1')) && $Fn_House->Config['PluginVar']['ExpiryTime']){
				$Where .= ' and I.updateline < '.strtotime("-".intval($Fn_House->Config['PluginVar']['ExpiryTime'])." day",time());
			}

			if(in_array($_GET['display'],array('0','1'))){
				$Where .= ' and I.display = '.intval($_GET['display']);
			}

			if(in_array($_GET['payment_state'],array('0','1'))){
				$Where .= ' and I.payment_state = '.intval($_GET['payment_state']);
			}

			if(in_array($_GET['deal'],array('0','1'))){
				$Where .= ' and I.deal = '.intval($_GET['deal']);
			}

			if(in_array($_GET['hot'],array('0','1'))){
				$Where .= ' and I.hot = '.intval($_GET['hot']);
			}

			$Where = preg_replace('/and/','where',$Where,1);
			$Limit = 20;
			$Page = $_GET['page']?intval($_GET['page']):1;
			/* ��ѯ���� End */


			/* ģ����� */
			showtagheader('div', 'row', true,'row');
			showtagheader('div', 'col-12', true,'col-12');
			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-body', true,'box-body');
			/* ���� */
			$PublishTypeSelected = array($_GET['publish_type']=>' selected');
			$OverdueSelected = array($_GET['overdue']=>' selected');
			$DisplaySelected = array($_GET['display']=>' selected');
			$DealSelected = array($_GET['deal']=>' selected');
			$PaymentStateSelected = array($_GET['payment_state']=>' selected');
			$HotSelected = array($_GET['hot']=>' selected');
			$OrderSelected = array($_GET['order']=>' selected');
			$AgentOptionHtml = '';
			foreach(DB::fetch_all('SELECT * FROM '.DB::table($Fn_House->TableAgent).' order by id desc') as $Key => $Val) {
				$AgentOptionHtml .= '<option value="'.$Val['id'].'"'.($Val['id'] == $_GET['agent_id'] ? ' selected' : '').'>'.$Val['title'].'</option>';
			}
			$UrlencodeCpMsgUrl = urlencode($CpMsgUrl);

			$OverdueHtml = $Fn_Job->Config['PluginVar']['ExpiryTime'] ? '<th>'.$Fn_Job->Config['LangVar']['IsOverdue'].'</th><td>
							<select name="overdue" class="form-control w120">
								<option value="">'.$Fn_Job->Config['LangVar']['SelectNull'].'</option>
								<option value="1"'.$OverdueSelected['1'].'>'.$Fn_Job->Config['LangVar']['Yes'].'</option>
								<option value="2"'.$OverdueSelected['2'].'>'.$Fn_Job->Config['LangVar']['No'].'</option>
							</select>
							</td>' : '';

			echo <<<SEARCH
			<form method="post" autocomplete="off" action="$SearUrl">
				<div class="FormSearchTo" style="margin-bottom:0;">
					<table cellspacing="4" cellpadding="4">
						<tr>
							<th>{$Fn_House->Config['LangVar']['KeywordTitle']}</th>
							<td colspan="10"><input type="text" class="form-control w200" name="keyword" value="{$_GET['keyword']}">&nbsp;&nbsp;&nbsp;&nbsp;&#25151;&#28304;&#73;&#68;&nbsp;&nbsp;<input type="text" class="form-control w100" name="iid" value="{$_GET['iid']}"></td>
						</tr>
						<tr>
							<th>{$Fn_House->Config['LangVar']['Store']}</th><td>
							<select name="agent_id" class="form-control w120">
								<option value="">{$Fn_House->Config['LangVar']['SelectNull']}</option>
								{$AgentOptionHtml}
							</select>
							</td>

							<th>{$Fn_House->Config['LangVar']['NatureTo']}</th><td>
							<select name="publish_type" class="form-control w120">
								<option value="">{$Fn_House->Config['LangVar']['SelectNull']}</option>
								<option value="1"{$PublishTypeSelected['1']}>{$Fn_House->Config['LangVar']['PublishTypeArray']['1']}</option>
								<option value="2"{$PublishTypeSelected['2']}>{$Fn_House->Config['LangVar']['PublishTypeArray']['2']}</option>
							</select>
							</td>
							{$OverdueHtml}
							<th>{$Fn_House->Config['LangVar']['DisplayTitle']}</th><td>
							<select name="display" class="form-control w120">
								<option value="">{$Fn_House->Config['LangVar']['SelectNull']}</option>
								<option value="1"{$DisplaySelected['1']}>{$Fn_House->Config['LangVar']['Yes']}</option>
								<option value="0"{$DisplaySelected['0']}>{$Fn_House->Config['LangVar']['No']}</option>
							</select>
							</td>
						</tr>
						<tr>
							<th>{$Fn_House->Config['LangVar']['PaymentState']}</th><td>
							
							<select name="payment_state" class="form-control w120">
								<option value="">{$Fn_House->Config['LangVar']['SelectNull']}</option>
								<option value="0"{$PaymentStateSelected['0']}>{$Fn_House->Config['LangVar']['PaymentStateArray'][0]}</option>
								<option value="1"{$PaymentStateSelected['1']}>{$Fn_House->Config['LangVar']['PaymentStateArray'][1]}</option>
							</select>
							</td>
							
							<th>{$Fn_House->Config['LangVar']['DealState']}</th><td>
							<select name="deal" class="form-control w120">
								<option value="">{$Fn_House->Config['LangVar']['SelectNull']}</option>
								<option value="1"{$DealSelected['1']}>{$Fn_House->Config['LangVar']['DealStateArray'][1]}</option>
								<option value="0"{$DealSelected['0']}>{$Fn_House->Config['LangVar']['DealStateArray'][0]}</option>
							</select>
							
							</td>

						    <th>{$Fn_House->Config['LangVar']['Hot']}</th><td>
							
							<select name="hot" class="form-control w120">
								<option value="">{$Fn_House->Config['LangVar']['SelectNull']}</option>
								<option value="1"{$HotSelected['1']}>{$Fn_House->Config['LangVar']['Yes']}</option>
								<option value="0"{$HotSelected['0']}>{$Fn_House->Config['LangVar']['No']}</option>
							</select>
							</td>
							<th>{$Fn_Admin->Config['LangVar']['Order']}</th><td>
							
							<select name="order" class="form-control w120">
								<option value="dateline"{$OrderSelected['dateline']}>{$Fn_Admin->Config['LangVar']['OrderArray']['dateline']}</option>
								<option value="updateline"{$OrderSelected['updateline']}>{$Fn_Admin->Config['LangVar']['OrderArray']['updateline']}</option>
								<option value="click"{$OrderSelected['click']}>{$Fn_Admin->Config['LangVar']['OrderArray']['click']}</option>
								<option value="topdateline"{$OrderSelected['topdateline']}>{$Fn_Admin->Config['LangVar']['OrderArray']['topdateline']}</option>
							</select>
							&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Admin->Config['LangVar']['SearchSubmit']}" class="btn btn-info" type="submit">
							&nbsp;&nbsp;<a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=add&list_class={$_GET['list_class']}&cp_msg_url={$UrlencodeCpMsgUrl}" target="_self" class="btn  btn-danger">{$Fn_Admin->Config['LangVar']['AddEditTitle']}</a>
							</td>
						</tr>
						
			
					</table>
				</div>
			</form>
SEARCH;
			/* ���� End */
			showtagheader('div', 'table-responsive', true,'table-responsive');
			showformheader($FormUrl,'enctype="multipart/form-data"');
			showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
			showsubtitle(array(
				'ID',
				'Uid/'.$Fn_House->Config['LangVar']['UserNameTitle'],
				$Fn_House->Config['LangVar']['Title'],
				$Fn_House->Config['LangVar']['NatureTo'],
				$Fn_House->Config['LangVar']['Store'],
				$Fn_House->Config['LangVar']['DisplayTitle'],
				$Fn_House->Config['LangVar']['PaymentState'],
				$Fn_House->Config['LangVar']['DealState'],
				$Fn_House->Config['LangVar']['Hot'],
				$Fn_House->Config['LangVar']['Browse'],
				'&#20030;&#25253;&#27425;&#25968;',
				$Fn_House->Config['LangVar']['TimeTitle'],
				$Fn_House->Config['LangVar']['RefreshTime'],
				$Fn_House->Config['LangVar']['SetTopTime'],
				$Fn_House->Config['LangVar']['OperationTitle']
			),'header tbm tc');

			$ModulesList = $Fn_House->InfoListFormat(GetModulesList($Page,$Limit,$Where,$Order));
			foreach ($ModulesList as $Module) {
				$ids[] = $Module['id'];
				$reportCount = DB::result_first('SELECT COUNT(*) FROM '.DB::table($Fn_House->TableInfoReport).' where iid = '.$Module['id']);//��������
				showtablerow('', array('class="tc w100"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
					'<input type="checkbox" class="filled-in" id="checkbox_'.$Module['id'].'" name="delete[]" value="'.$Module['id'].'"><label for="checkbox_'.$Module['id'].'">'.$Module['id'].'</label>',
					$Module['uid'] ? $Module['uid'].'<br>'.$Module['username'] : '',
					$Module['title'].'<br><div class="Type">'.$Module['province_text'].$Module['small_area'].'<span>/</span>'.$Module['square'].$Fn_House->Config['LangVar']['m2'].'<span>/</span>'.$Module['price'].$Module['price_text'].'</div>',
					$Module['publish_type_text'],
					$Module['agent_title'],
					!$Module['display'] ? '<span class="label bg-secondary">'.$Fn_House->Config['LangVar']['No'].'</span>' : '<span class="label bg-blue">'.$Fn_House->Config['LangVar']['Yes'].'</span>',
					!$Module['payment_state'] ? '<span class="label bg-secondary">'.$Fn_House->Config['LangVar']['PaymentStateArray']['0'].'</span>' : '<span class="label bg-blue">'.$Fn_House->Config['LangVar']['PaymentStateArray']['1'].'</span>',
					!$Module['deal'] ? '<span class="label bg-secondary">'.$Fn_House->Config['LangVar']['DealStateArray']['0'].'</span>' : '<span class="label bg-blue">'.$Fn_House->Config['LangVar']['DealStateArray']['1'].'</span>',
					!$Module['hot'] ? '<span class="label bg-secondary">'.$Fn_House->Config['LangVar']['No'].'</span>' : '<span class="label bg-blue">'.$Fn_House->Config['LangVar']['Yes'].'</span>',
					$Module['click'],
					$reportCount,
					$Module['dateline'],
					$Module['updateline'],
					$Module['topdateline'],
					'<a href="'.$Fn_House->Config['ViewUrl'].$Module['id'].'" target="_blank">'.cplang('view').'</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&iid='.$Module['id'].'&list_class='.$_GET['list_class'].'&cp_msg_url='.$UrlencodeCpMsgUrl.'">'.$Fn_House->Config['LangVar']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Refresh&iid='.$Module['id'].'&formhash='.FORMHASH.'">'.$Fn_House->Config['LangVar']['Refresh'].'</a>&nbsp;&nbsp;<a href="'.$Fn_Admin->Config['ModUrl'].'&item=access_record_list&iframe=true&iid='.$Module['id'].'">'.$Fn_House->Config['LangVar']['AccessRecord'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Del&iid='.$Module['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;">'.$Fn_House->Config['LangVar']['DelTitle'].'</a><br><a href="'.$OpCpUrl.'&do=Display&iid='.$Module['id'].'&value='.(!empty($Module['display']) ? 0:1).'&formhash='.FORMHASH.'">'.(!empty($Module['display']) ? $Fn_House->Config['LangVar']['DisplayNoTitle'] : $Fn_House->Config['LangVar']['DisplayIsTitle']).'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=PaymentState&iid='.$Module['id'].'&value='.(!empty($Module['payment_state']) ? 0:1).'&formhash='.FORMHASH.'">'.(!empty($Module['payment_state']) ? $Fn_House->Config['LangVar']['PaymentStateArray'][0] : $Fn_House->Config['LangVar']['PaymentStateArray'][1]).'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Deal&iid='.$Module['id'].'&value='.(!empty($Module['deal']) ? 0:1).'&formhash='.FORMHASH.'">'.(!empty($Module['deal']) ? $Fn_House->Config['LangVar']['DealStateArray'][0] : $Fn_House->Config['LangVar']['DealStateArray'][1]).'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Hot&iid='.$Module['id'].'&value='.(!empty($Module['hot']) ? 0:1).'&formhash='.FORMHASH.'">'.(!empty($Module['hot']) ? $Fn_House->Config['LangVar']['NoHot'] : $Fn_House->Config['LangVar']['Hot']).'</a>',
				));
			}

			$ClassHtml = '&nbsp;&nbsp;<input name="optype" value="MoveClass" class="with-gap" type="radio" id="v_MoveClass"><label class="custom-control-label" for="v_MoveClass" style="margin-left:-5px;">'.$Fn_Admin->Config['LangVar']['MoveClass'].'</label>&nbsp;<select name="new_class" class="form-control w120"><option value="">'.$Fn_House->Config['LangVar']['SelectNull'].'</option>';
			foreach ($Fn_House->Config['LangVar']['IndexNavArray'] as $Key => $Value) {
				$ClassHtml .= '<option value="'.$Key.'">'.$Value.'</option>';
			}
			$ClassHtml .= '</select>';

			$StoreHtml = '&nbsp;&nbsp;<input name="optype" value="MoveStore" class="with-gap" type="radio" id="v_MoveStore"><label class="custom-control-label" for="v_MoveStore" style="margin-left:-5px;">'.$Fn_House->Config['LangVar']['MoveStore'].'</label>
			&nbsp;<select name="new_agent_id" class="form-control w120"><option value="">'.$Fn_House->Config['LangVar']['SelectNull'].'</option>';
			foreach(DB::fetch_all('SELECT * FROM '.DB::table($Fn_House->TableAgent).' order by id desc') as $Key => $Value) {
				$StoreHtml .= '<option value="'.$Value['id'].'">'.$Value['title'].'</option>';
			}
			$StoreHtml .= '</select>';

			$PublishTypeHtml = '&nbsp;&nbsp;<input name="optype" value="PublishType" class="with-gap" type="radio" id="v_publish_type"><label class="custom-control-label" for="v_publish_type" style="margin-left:-5px;">&#24615;&#36136;</label>&nbsp;<select name="new_publish_type" class="form-control w120"><option value="">'.$Fn_House->Config['LangVar']['SelectNull'].'</option>';
			foreach ($Fn_House->Config['LangVar']['PublishTypeArray'] as $Key => $Value) {
				$PublishTypeHtml .= '<option value="'.$Key.'">'.$Value.'</option>';
			}
			$PublishTypeHtml .= '</select>';

			showsubmit('Submit','&#31435;&#21363;&#25552;&#20132;','<input name="optype" value="Refresh" class="with-gap" type="radio" id="v_refresh"><label class="custom-control-label" for="v_refresh" style="margin-left:-5px;">'.$Fn_House->Config['LangVar']['Refresh'].'</label>&nbsp;&nbsp;<input name="optype" value="Display" class="with-gap" type="radio" id="v_Display"><label class="custom-control-label" for="v_Display" style="margin-left:-5px;">'.$Fn_House->Config['LangVar']['DisplayTitle'].'</label>&nbsp;<select name="new_display" class="form-control w120"><option value="">'.$Fn_House->Config['LangVar']['SelectNull'].'</option><option value="1">'.$Fn_House->Config['LangVar']['Yes'].'</option><option value="0">'.$Fn_House->Config['LangVar']['No'].'</option></select>&nbsp;&nbsp;<input name="optype" value="PaymentState" class="with-gap" type="radio" id="v_PaymentState"><label class="custom-control-label" for="v_PaymentState" style="margin-left:-5px;">'.$Fn_House->Config['LangVar']['PaymentState'].'</label>
			&nbsp;<select name="new_payment_state" class="form-control w120"><option value="">'.$Fn_House->Config['LangVar']['SelectNull'].'</option><option value="1">'.$Fn_House->Config['LangVar']['PaymentStateArray']['1'].'</option><option value="0">'.$Fn_House->Config['LangVar']['PaymentStateArray']['0'].'</option></select>&nbsp;&nbsp;<input name="optype" value="Deal" class="with-gap" type="radio" id="v_Deal"><label class="custom-control-label" for="v_Deal" style="margin-left:-5px;">'.$Fn_House->Config['LangVar']['DealState'].'</label>
			&nbsp;<select name="new_deal" class="form-control w120"><option value="">'.$Fn_House->Config['LangVar']['SelectNull'].'</option><option value="1">'.$Fn_House->Config['LangVar']['DealStateArray']['1'].'</option><option value="0">'.$Fn_House->Config['LangVar']['DealStateArray']['0'].'</option></select>&nbsp;&nbsp;<input name="optype" value="Hot" class="with-gap" type="radio" id="v_Hot"><label class="custom-control-label" for="v_Hot" style="margin-left:-5px;">'.$Fn_House->Config['LangVar']['Hot'].'</label>
			&nbsp;<select name="new_hot" class="form-control w120"><option value="">'.$Fn_House->Config['LangVar']['SelectNull'].'</option><option value="1">'.$Fn_House->Config['LangVar']['Yes'].'</option><option value="0">'.$Fn_House->Config['LangVar']['No'].'</option></select>'.$ClassHtml.$StoreHtml.$PublishTypeHtml.'&nbsp;&nbsp;<input name="optype" value="Del" class="with-gap" type="radio" id="v_Del"><label class="custom-control-label" for="v_Del" style="margin-left:-5px;">'.$Fn_House->Config['LangVar']['DelTitle'].'</label>','','select_all',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));
			showtablefooter(); /*dism��taobao��com*/
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			/* ģ�����End */
			echo '<style>.Type{color:#999;}.Type span{margin:0 5px;}</style>';
		}else{
			if(isset($_GET['delete']) && is_array($_GET['delete'])){
				if($_GET['optype'] == 'Del'){//ȫɾ
					if(!$Fn_Admin->CheckUserGroup('house_all') && !$Fn_Admin->CheckUserGroup('house_del_info_list')){//Ȩ���ж�
						fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
						exit();
					}
					foreach($_GET['delete'] as $Key => $Val) {
						$Val = intval($Val);
						DB::delete($Fn_House->TableInfo,'id ='.$Val);
						DB::delete($Fn_House->TableInfoLog,'iid ='.$Val);
						DB::delete($Fn_House->TableInfoCollection,'iid ='.$Val);
						DB::delete($Fn_House->TableInfoReport,'iid ='.$Val);
						DB::delete($Fn_House->TableInfoPayLog,'iid ='.$Val);
					}
					GetInsertDoLog('del_info_house','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete'])));//������¼
					fn_cpmsg($Fn_House->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');

				}else if($_GET['optype'] == 'Refresh'){
					foreach($_GET['delete'] as $Key => $Val) {
						$Val = intval($Val);
						$UpData['updateline'] = time();
						DB::update($Fn_House->TableInfo,$UpData,'id = '.$Val);
					}
					GetInsertDoLog('refresh_house','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete'])));//������¼
					fn_cpmsg($Fn_House->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

				}else if($_GET['optype'] == 'Display' && in_array($_GET['new_display'],array('0','1'))){
					foreach($_GET['delete'] as $Key => $Val) {
						$Val = intval($Val);
						$UpData['display'] = intval($_GET['new_display']);
						DB::update($Fn_House->TableInfo,$UpData,'id = '.$Val);
					}
					GetInsertDoLog('display_info_house','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete']),'display'=>$_GET['new_display']));//������¼
					fn_cpmsg($Fn_House->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

				}else if($_GET['optype'] == 'PaymentState' && in_array($_GET['new_payment_state'],array('0','1'))){
					foreach($_GET['delete'] as $Key => $Val) {
						$Val = intval($Val);
						$UpData['payment_state'] = intval($_GET['new_payment_state']);
						DB::update($Fn_House->TableInfo,$UpData,'id = '.$Val);
					}
					GetInsertDoLog('payment_state_info_house','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete']),'payment_state'=>$_GET['new_payment_state']));//������¼
					fn_cpmsg($Fn_House->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

				}else if($_GET['optype'] == 'Deal' && in_array($_GET['new_deal'],array('0','1'))){
					foreach($_GET['delete'] as $Key => $Val) {
						$Val = intval($Val);
						$UpData['deal'] = intval($_GET['new_deal']);
						DB::update($Fn_House->TableInfo,$UpData,'id = '.$Val);
					}
					GetInsertDoLog('deal_info_house','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete']),'deal'=>$_GET['new_deal']));//������¼
					fn_cpmsg($Fn_House->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

				}else if($_GET['optype'] == 'Hot' && in_array($_GET['new_hot'],array('0','1'))){
					foreach($_GET['delete'] as $Key => $Val) {
						$Val = intval($Val);
						$UpData['hot'] = intval($_GET['new_hot']);
						DB::update($Fn_House->TableInfo,$UpData,'id = '.$Val);
					}
					GetInsertDoLog('hot_info_house','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete']),'hot'=>$_GET['new_hot']));//������¼
					fn_cpmsg($Fn_House->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

				}else if($_GET['optype'] == 'MoveClass' && $_GET['new_class']){
					foreach($_GET['delete'] as $Key => $Val) {
						$Val = intval($Val);
						$UpData['class'] = intval($_GET['new_class']);
						DB::update($Fn_House->TableInfo,$UpData,'id = '.$Val);
					}
					GetInsertDoLog('info_move_class_house','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete']),'class'=>$_GET['new_class']));//������¼
					fn_cpmsg($Fn_House->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

				}else if($_GET['optype'] == 'MoveStore' && $_GET['new_agent_id']){
					foreach($_GET['delete'] as $Key => $Val) {
						$Val = intval($Val);
						$UpData['agent_id'] = intval($_GET['new_agent_id']);
						DB::update($Fn_House->TableInfo,$UpData,'id = '.$Val);
					}
					GetInsertDoLog('info_move_class_house','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete']),'agent_id'=>$_GET['new_agent_id']));//������¼
					fn_cpmsg($Fn_House->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

				}else if($_GET['optype'] == 'PublishType' && $_GET['new_publish_type']){
					foreach($_GET['delete'] as $Key => $Val) {
						$Val = intval($Val);
						$UpData['publish_type'] = intval($_GET['new_publish_type']);
						DB::update($Fn_House->TableInfo,$UpData,'id = '.$Val);
					}
					fn_cpmsg($Fn_House->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

				}else{
					fn_cpmsg($Fn_House->Config['LangVar']['OpErr'],'','error');
				}	
			}else{
				fn_cpmsg($Fn_House->Config['LangVar']['OpErr'],'','error');
			}	
		}
	}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['iid']){
		if(!$Fn_Admin->CheckUserGroup('house_all') && !$Fn_Admin->CheckUserGroup('house_del_info_list')){//Ȩ���ж�
			fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
			exit();
		}
		$iid = intval($_GET['iid']);
		DB::delete($Fn_House->TableInfo,'id ='.$iid);
		DB::delete($Fn_House->TableInfoLog,'iid ='.$iid);
		DB::delete($Fn_House->TableInfoCollection,'iid ='.$iid);
		DB::delete($Fn_House->TableInfoReport,'iid ='.$iid);
		DB::delete($Fn_House->TableInfoPayLog,'iid ='.$iid);
		GetInsertDoLog('del_info_house','fn_'.$_GET['mod'],array('id'=>$_GET['iid']));//������¼
		fn_cpmsg($Fn_House->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');

	}else if($Do == 'Refresh' && $_GET['formhash'] == formhash() && $_GET['iid']){
		$iid = intval($_GET['iid']);
		$UpData['updateline'] = time();
		DB::update($Fn_House->TableInfo,$UpData,'id = '.$iid);
		GetInsertDoLog('refresh_house','fn_'.$_GET['mod'],array('id'=>$_GET['iid']));//������¼
		fn_cpmsg($Fn_House->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

	}else if($Do == 'Display' && $_GET['formhash'] == formhash() && $_GET['iid']){
		$iid = intval($_GET['iid']);
		$UpData['display'] = intval($_GET['value']);
		DB::update($Fn_House->TableInfo,$UpData,'id = '.$iid);
		GetInsertDoLog('display_info_house','fn_'.$_GET['mod'],array('id'=>$_GET['iid'],'display'=>$_GET['value']));//������¼
		fn_cpmsg($Fn_House->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

	}else if($Do == 'PaymentState' && $_GET['formhash'] == formhash() && $_GET['iid']){
		$iid = intval($_GET['iid']);
		$UpData['payment_state'] = intval($_GET['value']);
		DB::update($Fn_House->TableInfo,$UpData,'id = '.$iid);
		GetInsertDoLog('payment_state_info_house','fn_'.$_GET['mod'],array('id'=>$_GET['iid'],'payment_state'=>$_GET['value']));//������¼
		fn_cpmsg($Fn_House->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

	}else if($Do == 'Deal' && $_GET['formhash'] == formhash() && $_GET['iid']){
		$iid = intval($_GET['iid']);
		$UpData['deal'] = intval($_GET['value']);
		DB::update($Fn_House->TableInfo,$UpData,'id = '.$iid);
		GetInsertDoLog('deal_info_house','fn_'.$_GET['mod'],array('id'=>$_GET['iid'],'deal'=>$_GET['value']));//������¼
		fn_cpmsg($Fn_House->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

	}else if($Do == 'Hot' && $_GET['formhash'] == formhash() && $_GET['iid']){
		$iid = intval($_GET['iid']);
		$UpData['hot'] = intval($_GET['value']);
		DB::update($Fn_House->TableInfo,$UpData,'id = '.$iid);
		GetInsertDoLog('hot_info_house','fn_'.$_GET['mod'],array('id'=>$_GET['iid'],'hot'=>$_GET['value']));//������¼
		fn_cpmsg($Fn_House->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

	}
}else if($SubModel == 'add'){//���ӻ�༭
	
	if(!$Fn_Admin->CheckUserGroup('house_all') && !$Fn_Admin->CheckUserGroup('house_add_info_list')){//Ȩ���ж�
		fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
		exit();
	}

	$iid = intval($_GET['iid']);
	$Item = DB::fetch_first('SELECT * FROM '.DB::table($Fn_House->TableInfo).' where id = '.$iid);
	if($Item){
		$Item['param'] = unserialize($Item['param']);
		$Item['province_text'] = $Fn_House->Area[$Item['province']]['content'].($Item['city'] ? $Fn_House->Area[$Item['city']]['content'] : '').($Item['dist'] ? $Fn_House->Area[$Item['dist']]['content'] : '');
	};
	$_GET['list_class'] = $Item['class'] ? $Item['class'] : $_GET['list_class'];
	if($_GET['list_class'] == 1){
		$TagArray = $Fn_House->Config['LangVar']['HouseTagArray'];
	}else if($_GET['list_class'] == 2){
		$TagArray = $Fn_House->Config['LangVar']['RentalHouseTagArray'];
	}else if($_GET['list_class'] == 3){
		$TagArray = $Fn_House->Config['LangVar']['ShopTagArray'];
	}else if($_GET['list_class'] == 4){
		$TagArray = $Fn_House->Config['LangVar']['WorkShopTagArray'];
	}else if($_GET['list_class'] == 5){
		$TagArray = $Fn_House->Config['LangVar']['OfficeTagArray'];
	}else if($_GET['list_class'] == 6){
		$TagArray = $Fn_House->Config['LangVar']['WarehouseTagArray'];
	}else if($_GET['list_class'] == 7){
		$TagArray = $Fn_House->Config['LangVar']['LandTagArray'];
	}

	if(!submitcheck('DetailSubmit')) {
		$OpTitle = $Fn_House->Config['LangVar']['AddTitle'];
		if($Item)$OpTitle = $Fn_House->Config['LangVar']['EditTitle'];
		
		echo '<script src="'.$Config['StaticPath'].'/ueditor/'.CHARSET.'/ueditor.config.js" type="text/javascript"></script><script src="'.$Config['StaticPath'].'/ueditor/'.CHARSET.'/ueditor.all.js" type="text/javascript"></script>';

		//ͼƬ�ϴ�
		if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_assembly/class/class_upload.php')){
			@require_once libfile('class/upload','plugin/fn_assembly');
			$UploadConfig = fn_upload::Config();
		}
		showformheader($Fn_Admin->Config['IframeSubModelUrl'].'&iid='.$iid,'enctype');
		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-header', true,'with-border box-header');
		showtitle($OpTitle.'<input type="hidden" name="cp_msg_url" value="'.$_GET['cp_msg_url'].'"><input type="hidden" name="list_class" value="'.$_GET['list_class'].'">','class="box-title"');
		showtagfooter('div');
		showtagheader('div', 'box-body', true,'box-body');

		
		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_House->Config['LangVar']['FormImagesTitle'].':</label><div class="col-sm-9"><div class="AdminSingleUpload"><div class="PhotoControl" id="PhotoControl"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';

		showsetting($Fn_House->Config['LangVar']['Title'], 'title', $Item['title'], 'text');
		showsetting($Fn_House->Config['LangVar']['SmallAreaTo'], 'small_area', $Item['small_area'], 'text');
		
		$SmallAreaPositionTreelistHtml = GetTreelistHtml($Fn_House->Area,'SmallAreaPositionList',$Item['province'],$Item['city'],$Item['dist']);//С��λ��

		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_House->Config['LangVar']['HouseArea'].':</label><div class="col-sm-2"><div style="position:relative;height:40px"><input value="'.$Item['province_text'].'" class="form-control TreeList" type="text" id="SmallAreaPosition">'.$SmallAreaPositionTreelistHtml.'</div></td><td class="vtop tips2" s="1"><input type="hidden" name="province" value="'.$Item['province'].'"/><input type="hidden" name="city" value="'.$Item['city'].'"/><input type="hidden" name="dist" value="'.$Item['dist'].'"/></div><div class="col-sm-7">
		
		<div class="Tagging" onclick="return biaozhu();"><i class="fa fa-map-marker"></i> '.$Fn_House->Config['LangVar']['Tagging'].'</div><div id="MapIframe" DataShow=""><div id="AllMap"></div><div class="bottom"><div class="left"><input type="text" class="search_txt" id="search_txt" /><button type="button" class="search_btn" onclick="get_point()">'.$Fn_Admin->Config['LangVar']['Lookup'].'</button></div><div class="right"><a href="javascript:void(0);" onClick="return biaozhu_ok();" class="btn_blue">'.$Fn_Admin->Config['LangVar']['DefiniteAnnotation'].'</a><a href="javascript:void(0);" onClick="return biaozhu_cancel();" class="btn_gray">'.$Fn_Admin->Config['LangVar']['MsgBox_no'].'</a></div></div></div><input type="hidden" name="lat" value="'.$Item['lat'].'"/><input type="hidden" name="lng" value="'.$Item['lng'].'"/></div></div>';

		showsetting($Fn_House->Config['LangVar']['Community'].$Fn_House->Config['LangVar']['community'], 'community', $Item['community'], 'text');

		showsetting($Fn_House->Config['LangVar']['VideoUrl'], 'video_url', $Item['video_url'], 'text','','',$Fn_House->Config['LangVar']['VideoUrlTips']);

		showsetting($Fn_House->Config['LangVar']['VRLink'], 'vr_url', $Item['vr_url'], 'text');

		showsetting($Fn_House->Config['LangVar']['Square'], 'square', $Item['square'], 'text','','',$Fn_House->Config['LangVar']['SquareMetre']);
		
		if($_GET['list_class'] == 1){
			showsetting($Fn_House->Config['LangVar']['Price'], 'price', $Item['price'], 'text','','',$Fn_House->Config['LangVar']['Wan']);
			showsetting($Fn_House->Config['LangVar']['HouseFloor'],array('floor',DyadicArray($Fn_House->Config['LangVar']['FloorArray'])),$Item['floor'],'select');

			showsetting($Fn_House->Config['LangVar']['Gong'].$Fn_House->Config['LangVar']['HouseFloor'], 'count_floor', $Item['count_floor'], 'text');
			showsetting($Fn_House->Config['LangVar']['Room'], 'room', $Item['room'], 'text');
			showsetting($Fn_House->Config['LangVar']['Office'], 'office', $Item['office'], 'text');
			showsetting($Fn_House->Config['LangVar']['Guard'], 'guard', $Item['guard'], 'text');
			
			showsetting($Fn_House->Config['LangVar']['Years'],array('years',DyadicArray($Fn_House->Config['LangVar']['YearsArray'],$Fn_House->Config['LangVar']['SelectNullTo'])),$Item['years'],'select');

			showsetting($Fn_House->Config['LangVar']['HouseType'],array('house_type',DyadicArray($Fn_House->Config['LangVar']['HouseTypeArray'],$Fn_House->Config['LangVar']['SelectNullTo'])),$Item['house_type'],'select');

			showsetting($Fn_House->Config['LangVar']['Decoration'],array('decoration_type',DyadicArray($Fn_House->Config['LangVar']['DecorationArray'],$Fn_House->Config['LangVar']['SelectNullTo'])),$Item['decoration_type'],'select');

			showsetting($Fn_House->Config['LangVar']['Orientation'],array('orientation',DyadicArray($Fn_House->Config['LangVar']['OrientationArray'],$Fn_House->Config['LangVar']['SelectNullTo'])),$Item['orientation'],'select');

			showsetting($Fn_House->Config['LangVar']['PropertyRight'],array('property_right',DyadicArray($Fn_House->Config['LangVar']['PropertyRightArray'],$Fn_House->Config['LangVar']['SelectNullTo'])),$Item['property_right'],'select');
		}else if($_GET['list_class'] == 2){
			showsetting($Fn_House->Config['LangVar']['RentalType'],array('vice_class',DyadicArray($Fn_House->Config['LangVar']['RentalTypeArray'])),$Item['vice_class'],'mradio');
			showsetting($Fn_House->Config['LangVar']['Rent'], 'price', $Item['price'], 'text');
			showsetting($Fn_House->Config['LangVar']['RentTimeUnit'],array('price_time',DyadicArray($Fn_House->Config['LangVar']['RentTimeArray'])),$Item['param']['price_time'],'select');
			showsetting($Fn_House->Config['LangVar']['Room'],array('room',DyadicArray($Fn_House->Config['LangVar']['RoomArray'])),$Item['room'],'select');
			showsetting($Fn_House->Config['LangVar']['Office'],array('office',DyadicArray($Fn_House->Config['LangVar']['OfficeArray'])),$Item['office'],'select');
			showsetting($Fn_House->Config['LangVar']['Guard'],array('guard',DyadicArray($Fn_House->Config['LangVar']['GuardArray'])),$Item['guard'],'select');
			showsetting($Fn_House->Config['LangVar']['HouseType'],array('house_type',DyadicArray($Fn_House->Config['LangVar']['HouseTypeArray'],$Fn_House->Config['LangVar']['SelectNullTo'])),$Item['house_type'],'select');
			showsetting($Fn_House->Config['LangVar']['Decoration'],array('decoration_type',DyadicArray($Fn_House->Config['LangVar']['DecorationArray'],$Fn_House->Config['LangVar']['SelectNullTo'])),$Item['decoration_type'],'select');
			showsetting($Fn_House->Config['LangVar']['Orientation'],array('orientation',DyadicArray($Fn_House->Config['LangVar']['OrientationArray'],$Fn_House->Config['LangVar']['SelectNullTo'])),$Item['orientation'],'select');
			showsetting($Fn_House->Config['LangVar']['HousingAllocation'],array('configure[]',DyadicArray($Fn_House->Config['LangVar']['ConfigureTagArray'])),explode(',',$Item['configure']),'mselect','','',$Fn_Admin->Config['LangVar']['Ctrl']);
		}else if(in_array($_GET['list_class'],array(3,4,5,6,7))){
			
			showsetting($Fn_House->Config['LangVar']['NatureTo'],array('vice_class', array(
				array('1',$Fn_House->Config['LangVar']['ShopTypeArray']['1'], array('rental_table' => '', 'rental_table_no' => 'none')),
				array('2',$Fn_House->Config['LangVar']['ShopTypeArray']['2'], array('rental_table' => 'none', 'rental_table_no' => '')),
				array('3',$Fn_House->Config['LangVar']['ShopTypeArray']['3'], array('rental_table' => 'none', 'rental_table_no' => '')),
			), TRUE),$Item['vice_class'], 'mradio');


			$RentalTableDisplay = $Item['vice_class'] == 1 ? true : false;
			$RentalTableNoDisplay = $Item['vice_class'] != 1 ? true : false;
			
			showtagheader('tbody', 'rental_table', $RentalTableDisplay, 'sub');
				showsetting($Fn_House->Config['LangVar']['Rent'], 'rental_price', $Item['price'], 'text');
				showsetting($Fn_House->Config['LangVar']['RentTimeUnit'],array('price_time',DyadicArray($Fn_House->Config['LangVar']['RentTimeArray'])),$Item['param']['price_time'],'select');
				//showsetting($Fn_House->Config['LangVar']['Deposit'],array('deposit',DyadicArray($Fn_House->Config['LangVar']['DepositArray'])),$Item['deposit'],'select');
			showtagfooter('tbody');

			showtagheader('tbody', 'rental_table_no', $RentalTableNoDisplay, 'sub');
				showsetting($Fn_House->Config['LangVar']['JiaGe'], 'price', $Item['price'], 'text','','',$Fn_House->Config['LangVar']['Wan']);
			showtagfooter('tbody');

			if($_GET['list_class'] == 3){
				showsetting($Fn_House->Config['LangVar']['ManagementTpye'],array('management_type',DyadicArray($Fn_House->Config['LangVar']['ManagementTpyeArray'],$Fn_House->Config['LangVar']['SelectNullTo'])),$Item['management_type'],'select');

				showsetting($Fn_House->Config['LangVar']['ShopTypeTo'],array('shops_type',DyadicArray($Fn_House->Config['LangVar']['ShopManagementTypeArray'],$Fn_House->Config['LangVar']['SelectNullTo'])),$Item['shops_type'],'select');
			}

		}

		showsetting($Fn_House->Config['LangVar']['CharacteristicTagTitle'],array('tag[]',DyadicArray($TagArray)),explode(',',$Item['tag']),'mselect','','',$Fn_Admin->Config['LangVar']['Ctrl']);

		//��������
		echo '<div class="form-group row"><label class="col-sm-1 col-form-label">'.$Fn_House->Config['LangVar']['HouseContent'].':</label><div class="col-sm-9"><textarea id="content" name="content" style="width:80%;height:400px;">'.stripslashes($Item['content'] ? $Item['content'] : $Item['param']['content']).'</textarea></div></div>';

		showsetting($Fn_House->Config['LangVar']['Contacts'], 'name', $Item['name'], 'text');
		showsetting($Fn_House->Config['LangVar']['ContactNumber'], 'mobile',$Item['mobile'] ? $Item['mobile'] : $Item['param']['mobile'], 'text');
		showsetting($Fn_House->Config['LangVar']['WxTitle'], 'wx', $Item['param']['wx'], 'text');
		if($Fn_House->Config['PluginVar']['PublishMasterMobile']){
			showsetting($Fn_House->Config['LangVar']['mastermobile'], 'mastermobile', $Item['param']['mastermobile'], 'text');
		}
		
		showsetting("uid", 'uid', $Item['uid'] ? $Item['uid'] : $_G['uid'], 'text');

		showsetting($Fn_House->Config['LangVar']['NatureTo'],array('publish_type',DyadicArray($Fn_House->Config['LangVar']['PublishTypeArray'])),$Item ? $Item['publish_type'] : 1,'mradio');

		showsetting($Fn_House->Config['LangVar']['DisplayTitle'], 'display', $Item ? $Item['display'] : 1, 'radio');
		
		showsetting($Fn_House->Config['LangVar']['PaymentState'],array('payment_state',DyadicArray($Fn_House->Config['LangVar']['PaymentStateArray'])),$Item ? $Item['payment_state'] : 1,'mradio');

		showsetting($Fn_House->Config['LangVar']['DealState'],array('deal',DyadicArray($Fn_House->Config['LangVar']['DealStateArray'])),$Item['deal'],'mradio');
		
		showsetting($Fn_House->Config['LangVar']['SetTopTime'], 'topdateline',$Item['topdateline'] ? date('Y-m-d H:i',$Item['topdateline']) : '', 'calendar','','','',1);

		showsetting($Fn_House->Config['LangVar']['Click'], 'click', $Item['click'], 'text');

		if($Item['updateline']){
			showsetting($Fn_House->Config['LangVar']['RefreshTime'], 'updateline',$Item['updateline'] ? date('Y-m-d H:i',$Item['updateline']) : '', 'calendar','','','',1);
		}

		if($Item['dateline']){
			showsetting($Fn_House->Config['LangVar']['TimeTitle'], 'dateline',date('Y-m-d H:i',$Item['dateline']), 'calendar','','','',1);
		}
		
		showsubmit('DetailSubmit','&#20445;&#23384;&#37197;&#32622;');
		showtagfooter('div');
		showtagfooter('div');
		showformfooter(); /*Dism_taobao-com*/

		if($Item['param']['images']){
			foreach($Item['param']['images'] as $Key => $Val) {
				$JsArray[] = '"'.$Val.'"';
			}
			$UpLoadHtml = '
			var InputArray = new Array('.implode(',',$JsArray).');
			$("#PhotoControl").AppUpload({InputName:"new_images",InputExist:true,InputArray:InputArray})';

		}else{
			$UpLoadHtml = '$("#PhotoControl").AppUpload({InputName:"new_images"});';
		}

		echo '<script src="source/plugin/fn_assembly/static/js/mobiscroll.custom-2.16.1.min.js"></script><link rel="stylesheet" href="source/plugin/fn_assembly/static//css/mobiscroll.custom-2.16.1.min.css"><script type="text/javascript" src="https://api.map.baidu.com/api?v=2.0&ak='.$Config['PluginVar']['BaiDuMapKey'].'&s=1"></script>'.$UploadConfig['CssJsHtml'];

		echo '
			<script>
			window["CITY"] = "'.$Config['PluginVar']['DefaultCity'].'";
			'.$UpLoadHtml.'
			$(document).on("click","#SmallAreaPosition",function(){
				GetTreeList($(this),"SmallAreaPositionList","province","city","dist");
				return false;
			});
			var ue = UE.getEditor("content",{autoHeightEnabled: false,autoFloatEnabled:false,enableAutoSave: false}); 
			</script> 	
		';
	}else{
	
		$Data['class'] = $_GET['list_class'];
		$Data['vice_class'] = $_GET['vice_class'];
		$Data['title'] = addslashes(strip_tags($_GET['title']));
		$Data['small_area'] = addslashes(strip_tags($_GET['small_area']));
		$Data['province'] = addslashes(strip_tags($_GET['province']));
		$Data['city'] = addslashes(strip_tags($_GET['city']));
		$Data['dist'] = addslashes(strip_tags($_GET['dist']));
		$Data['community'] = addslashes(strip_tags($_GET['community']));
		$Data['lat'] = addslashes(strip_tags($_GET['lat']));
		$Data['lng'] = addslashes(strip_tags($_GET['lng']));
		$Data['floor'] = intval($_GET['floor']);
		$Data['count_floor'] = intval($_GET['count_floor']);
		$Data['room'] = intval($_GET['room']);
		$Data['office'] = intval($_GET['office']);
		$Data['guard'] = intval($_GET['guard']);
		$Data['deposit'] = intval($_GET['deposit']);
		$Data['square'] = intval($_GET['square']);
		
		if(in_array($Data['class'],array(3,4,5,6,7))){
			$Data['price'] = $Data['vice_class'] == 1 ? addslashes(strip_tags($_GET['rental_price'])) : addslashes(strip_tags($_GET['price']));
		}else{
			$Data['price'] = addslashes(strip_tags($_GET['price']));
		}
		
		$Data['video_url'] = addslashes(strip_tags($_GET['video_url']));
		$Data['vr_url'] = addslashes(strip_tags($_GET['vr_url']));
		$Data['years'] = intval($_GET['years']);
		$Data['house_type'] = intval($_GET['house_type']);
		$Data['decoration_type'] = intval($_GET['decoration_type']);
		$Data['orientation'] = intval($_GET['orientation']);
		$Data['property_right'] = intval($_GET['property_right']);
		$Data['management_type'] = intval($_GET['management_type']);
		$Data['shops_type'] = intval($_GET['shops_type']);
		$Data['tag'] = is_array($_GET['tag']) && isset($_GET['tag']) ? implode(',',$_GET['tag']) : '';
		$Data['configure'] = is_array($_GET['configure']) && isset($_GET['configure']) ? implode(',',$_GET['configure']) : '';
		
		$Data['uid'] = intval($_GET['uid']);
		$Data['name'] = addslashes(strip_tags($_GET['name']));
		$Data['publish_type'] = intval($_GET['publish_type']);
		$Data['display'] = intval($_GET['display']);
		$Data['payment_state'] = intval($_GET['payment_state']);
		$Data['deal'] = intval($_GET['deal']);
		$Data['click'] = intval($_GET['click']);
		$Data['mobile'] = addslashes(strip_tags($_GET['mobile']));
		$Data['content'] = addslashes($_GET['content']);//�豣��Html
		
		foreach(array_filter(explode(",",$Data['tag'])) as $Key => $Val) {
			$Param['tag_list'][] = $TagArray[$Val];
		}
		
		$Param['wx'] = addslashes(strip_tags($_GET['wx']));
		$Param['mastermobile'] = addslashes(strip_tags($_GET['mastermobile']));
		$Param['price_time'] = intval($_GET['price_time']);
		
		
		foreach($_GET['new_images'] as $Key => $Val) {
			$_GET['new_images'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}
		$Param['images'] = is_array($_GET['new_images']) && isset($_GET['new_images'])  ? array_filter($_GET['new_images']) : '';
		$Param['cover'] = $_GET['new_images'][0];

		$Member = DB::fetch_first('SELECT username FROM '.DB::table('common_member').' where uid = '.$Data['uid']);
		$Data['username'] = addslashes(strip_tags($Member['username']));
		$Data['param'] = serialize($Param);
		$Data['topdateline'] = $_GET['topdateline'] ? strtotime($_GET['topdateline']) : '';

		if($Item){
			$Data['dateline'] = strtotime($_GET['dateline']);
			$Data['updateline'] = strtotime($_GET['updateline']);
			
			DB::update($Fn_House->TableInfo,$Data,'id = '.$iid);
			GetInsertDoLog('edit_info_house','fn_'.$_GET['mod'],array('id'=>$Item['id']));//������¼
		}else{
			$Data['dateline'] = $Data['updateline'] = time();
			$Id = DB::insert($Fn_House->TableInfo,$Data,true);
			GetInsertDoLog('add_info_house','fn_'.$_GET['mod'],array('id'=>$Id));//������¼
		}
	
		fn_cpmsg($Fn_House->Config['LangVar']['UpdateOk'],($_GET['cp_msg_url'] ? $_GET['cp_msg_url'] : $Fn_Admin->Config['IframeItemUrl'].'&submodel=list'),'succeed');

	}
}
/* �б� */
function GetModulesList($Page,$Limit,$Where=null,$Order){
	global $Fn_House;
	$FetchSql = 'SELECT I.*,A.title as agent_title FROM '.DB::table($Fn_House->TableInfo).' I LEFT JOIN `'.DB::table($Fn_House->TableAgent).'` A on A.id = I.agent_id '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}

/* ���� */
function GetModulesCount($Where=null){
	global $Fn_House;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_House->TableInfo).' I '.$Where;
	return DB::result_first($FetchSql);//��������
}

?>