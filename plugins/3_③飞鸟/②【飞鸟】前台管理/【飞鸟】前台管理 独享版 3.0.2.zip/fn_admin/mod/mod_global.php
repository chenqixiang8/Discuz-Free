<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
//��ർ��
foreach($Fn_Admin->Config['AdminUserInfo']['param']['global_left_nav'] as $Key => $Val) {
	if(!$Key){$Default = $Val;}
	$LeftMenu[$Val] = $Fn_Admin->Config['LangVar']['GlobalLeftNavArray'][$Val];
}

$_GET['item'] = $_GET['item'] ? $_GET['item'] : $Default;

?>