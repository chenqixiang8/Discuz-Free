<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

//Ȩ���ж�
if(!$Fn_Admin->CheckUserGroup('crm_all') && !$Fn_Admin->CheckUserGroup('crm_data_statistics')){
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$Timestamp = strtotime(date('Y-m-d'));
$WeekDay = strtotime(date('Y-m-d',$Timestamp - (date('N',$Timestamp)-1) * 86400));//���ܵ�һ��
$EndWeekDay = strtotime(date('Y-m-d 23:59:59',strtotime("+6 day",$WeekDay)));

$FirstDay = strtotime(date('Y-m-01', strtotime(date("Y-m-d"))));//���µ�һ��  
$LastDay = strtotime(date('Y-m-d 23:59:59', strtotime("+1 month -1 day",$FirstDay)));//�������һ�� 

$LastLasDday = strtotime(date('Y-m-01', strtotime('-1 month',$FirstDay)));//�ϸ��µ�һ��  
$LastFirstDay = strtotime(date('Y-m-t 23:59:59', strtotime('-1 month',$FirstDay)));//�ϸ������һ��


$count_title = $Fn_Admin->CheckUserGroup('crm_data_statistics_my') ? '&#25105;&#30340;&#23454;&#26102;&#25968;&#25454;' : '&#23454;&#26102;&#25968;&#25454;';
$where = $Fn_Admin->CheckUserGroup('crm_data_statistics_my') ? ' where sale_uid = '.intval($_G['uid']).' and ' : ' where ';
$CustomerCount = DB::result_first('SELECT COUNT(*) FROM '.DB::table($Fn_Crm->TableCustomer).$where.' recovery = 0');
$CustomerCountB = DB::result_first('SELECT COUNT(*) FROM '.DB::table($Fn_Crm->TableCustomer).$where.' level = 2');
$CustomerCountA = DB::result_first('SELECT COUNT(*) FROM '.DB::table($Fn_Crm->TableCustomer).$where.' level = 1');
$DayCustomerFollowCount = DB::result_first('SELECT COUNT(*) FROM '.DB::table($Fn_Crm->TableCustomerFollow).$where.' dateline >= '.strtotime(date('Y-m-d')).' and dateline <='.strtotime(date('Y-m-d 23:59:59')));
$YesterdayCustomerFollowCount = DB::result_first('SELECT COUNT(*) FROM '.DB::table($Fn_Crm->TableCustomerFollow).$where.' dateline >= '.strtotime("-1 day",strtotime(date('Y-m-d'))).' and dateline <='.strtotime("-1 day",strtotime(date('Y-m-d 23:59:59'))));
$WeekCustomerFollowCount = DB::result_first('SELECT COUNT(*) FROM '.DB::table($Fn_Crm->TableCustomerFollow).$where.' dateline >= '.$WeekDay.' and dateline <='.$EndWeekDay);

$member = $Fn_Admin->CheckUserGroup('crm_data_statistics_my') ? DB::fetch_first('SELECT * FROM '.DB::table($Fn_Crm->TableMember).' where uid = '.intval($_G['uid'])) : '';
$project_html = '';
$project_group = array_filter(explode(',',$member['project_group']));
foreach($Fn_Crm->Config['setting']['project'] as $key => $val) {
	if(($member && $project_group && in_array($key,$project_group)) || ($member && !$project_group) || (!$member)){
		$project_html .= '<div class="col-sm-6 col-lg-2">
			<div class="box-body">
					<div class="font-size-40 font-weight-200">'.DB::result_first('SELECT COUNT(*) FROM '.DB::table($Fn_Crm->TableCustomer).$where.' project = \''.$key.'\'').'</div>
				<div>'.$val.'&#23458;&#25143;</div>
			</div>
		</div>';
	}
}

echo <<<TABLE
<div class="row">
  <div class="col-12">
    <div class="box">
      <div class="box-body">
        <div class="flexbox">
          <h5>{$count_title}</h5>
        </div>
        <div class="row">
          <div class="col-sm-6 col-lg-2">
            <div class="box-body">
              <div class="font-size-40 font-weight-200">{$CustomerCount}</div>
              <div>&#67;&#82;&#77;&#24635;&#23458;&#25143;</div>
            </div>
          </div>
          <div class="col-sm-6 col-lg-2">
            <div class="box-body">
              <div class="font-size-40 font-weight-200">{$CustomerCountB}</div>
              <div>&#66;&#32423;&#40;&#36319;&#36827;&#23458;&#25143;&#41;</div>
            </div>
          </div>
          <div class="col-sm-6 col-lg-2">
            <div class="box-body">
              <div class="font-size-40 font-weight-200">{$CustomerCountA}</div>
              <div>&#65;&#32423;&#40;&#31614;&#32422;&#23458;&#25143;&#41;</div>
            </div>
          </div>
		  <div class="col-sm-6 col-lg-2">
            <div class="box-body">
              <div class="font-size-40 font-weight-200">{$DayCustomerFollowCount}</div>
              <div>&#20170;&#26085;&#36319;&#36827;</div>
            </div>
          </div>
		  <div class="col-sm-6 col-lg-2">
            <div class="box-body">
              <div class="font-size-40 font-weight-200">{$YesterdayCustomerFollowCount}</div>
              <div>&#26152;&#26085;&#36319;&#36827;</div>
            </div>
          </div>
		  <div class="col-sm-6 col-lg-2">
            <div class="box-body">
              <div class="font-size-40 font-weight-200">{$WeekCustomerFollowCount}</div>
              <div>&#26412;&#21608;&#36319;&#36827;</div>
            </div>
          </div>
          {$project_html}
        </div>
      </div>
    </div>
  </div>
  <!-- /.col -->
</div>
TABLE;

//ȫ���˵�ͳ��
if(!$Fn_Admin->CheckUserGroup('crm_data_statistics_my')){
	foreach (DB::fetch_all('SELECT * FROM '.DB::table($Fn_Crm->TableMember)) as $val) {
		$CustomerCount = DB::result_first('SELECT COUNT(*) FROM '.DB::table($Fn_Crm->TableCustomer).' where sale_uid = '.intval($val['uid']).' and recovery = 0');
		$CustomerCountB = DB::result_first('SELECT COUNT(*) FROM '.DB::table($Fn_Crm->TableCustomer).' where sale_uid = '.intval($val['uid']).' and level = 2');
		$CustomerCountA = DB::result_first('SELECT COUNT(*) FROM '.DB::table($Fn_Crm->TableCustomer).' where sale_uid = '.intval($val['uid']).' and level = 1');
		$DayCustomerFollowCount = DB::result_first('SELECT COUNT(*) FROM '.DB::table($Fn_Crm->TableCustomerFollow).' where sale_uid = '.intval($val['uid']).' and dateline >= '.strtotime(date('Y-m-d')).' and dateline <='.strtotime(date('Y-m-d 23:59:59')));
		$YesterdayCustomerFollowCount = DB::result_first('SELECT COUNT(*) FROM '.DB::table($Fn_Crm->TableCustomerFollow).' where sale_uid = '.intval($val['uid']).' and dateline >= '.strtotime("-1 day",strtotime(date('Y-m-d'))).' and dateline <='.strtotime("-1 day",strtotime(date('Y-m-d 23:59:59'))));
		$WeekCustomerFollowCount = DB::result_first('SELECT COUNT(*) FROM '.DB::table($Fn_Crm->TableCustomerFollow).' where sale_uid = '.intval($val['uid']).' and dateline >= '.$WeekDay.' and dateline <='.$EndWeekDay);

		$project_html = '';
		$project_group = array_filter(explode(',',$val['project_group']));
		foreach($Fn_Crm->Config['setting']['project'] as $k => $v) {
			if(($project_group && in_array($k,$project_group)) || (!$project_group)){
				$project_html .= '<div class="col-sm-6 col-lg-2">
					<div class="box-body">
							<div class="font-size-40 font-weight-200">'.DB::result_first('SELECT COUNT(*) FROM '.DB::table($Fn_Crm->TableCustomer).' where sale_uid = '.intval($val['uid']).' and project = \''.$k.'\'').'</div>
						<div>'.$v.'&#23458;&#25143;</div>
					</div>
				</div>';
			}
		}
		echo <<<TABLE
		<div class="row">
		  <div class="col-12">
			<div class="box">
			  <div class="box-body">
				<div class="flexbox">
				  <h5>{$val['name']}&#30340;&#23454;&#26102;&#25968;&#25454;</h5>
				</div>
				<div class="row">
				  <div class="col-sm-6 col-lg-2">
					<div class="box-body">
					  <div class="font-size-40 font-weight-200">{$CustomerCount}</div>
					  <div>&#67;&#82;&#77;&#24635;&#23458;&#25143;</div>
					</div>
				  </div>
				  <div class="col-sm-6 col-lg-2">
					<div class="box-body">
					  <div class="font-size-40 font-weight-200">{$CustomerCountB}</div>
					  <div>&#66;&#32423;&#40;&#36319;&#36827;&#23458;&#25143;&#41;</div>
					</div>
				  </div>
				  <div class="col-sm-6 col-lg-2">
					<div class="box-body">
					  <div class="font-size-40 font-weight-200">{$CustomerCountA}</div>
					  <div>&#65;&#32423;&#40;&#31614;&#32422;&#23458;&#25143;&#41;</div>
					</div>
				  </div>
				  <div class="col-sm-6 col-lg-2">
					<div class="box-body">
					  <div class="font-size-40 font-weight-200">{$DayCustomerFollowCount}</div>
					  <div>&#20170;&#26085;&#36319;&#36827;</div>
					</div>
				  </div>
				  <div class="col-sm-6 col-lg-2">
					<div class="box-body">
					  <div class="font-size-40 font-weight-200">{$YesterdayCustomerFollowCount}</div>
					  <div>&#26152;&#26085;&#36319;&#36827;</div>
					</div>
				  </div>
				  <div class="col-sm-6 col-lg-2">
					<div class="box-body">
					  <div class="font-size-40 font-weight-200">{$WeekCustomerFollowCount}</div>
					  <div>&#26412;&#21608;&#36319;&#36827;</div>
					</div>
				  </div>
				  {$project_html}
				</div>
			  </div>
			</div>
		  </div>
		  <!-- /.col -->
		</div>
TABLE;
	}
}

//������¼
$customer_follow_url = $Fn_Admin->Config[ModUrl].'&item=customer_follow_list&submodel=list&iframe=true';
$customer_follow_html = '';
@require_once libfile('function/forum');
foreach (DB::fetch_all('SELECT f.*,m.name as sale_name,c.name as customer_name FROM '.DB::table($Fn_Crm->TableCustomerFollow).' f LEFT JOIN `'.DB::table($Fn_Crm->TableMember).'` m on m.uid = f.sale_uid LEFT JOIN `'.DB::table($Fn_Crm->TableCustomer).'` c on c.id = f.customer_id '.($Fn_Admin->CheckUserGroup('crm_data_statistics_my') ? ' where f.sale_uid = '.intval($_G['uid']) : '').' order by f.id desc limit 0,15') as $val) {
	$customer_follow_html .= '<div class="media-list media-list-hover media-list-divided">
          <div class="media" style="padding-top:12px;padding-bottom:12px;"> <a href="'.$customer_follow_url.'&customer_id='.$val['customer_id'].'"><img class="avatar" src="'.discuz_uc_avatar($val['sale_uid'],'middle',true).'" alt="..."></a>
            <div class="media-body">
              <p> <strong style="font-weight:500;"><a href="'.$customer_follow_url.'&customer_id='.$val['customer_id'].'" class="hover-info">'.$val['content'].'</a></strong>
                <time class="float-right">'.date('Y-m-d H:i',$val['dateline']).'</time>
              </p>
			  <small class="text-fader font-size-12">'.$val['customer_name'].'</small>
            </div>
          </div>
        </div>';
}
if($customer_follow_html){
echo <<<TABLE
<div class="row">
  <div class="col-12">
    <div class="box">
      <div class="box-header with-border">
        <h5 class="box-title">&#36319;&#36827;&#35760;&#24405;</h5>
		<div class="pull-right"><a href="{$customer_follow_url}">&#26356;&#22810;<i class="fa fa-angle-right" style="margin:0 0 0 3px;"></i></a></div>
      </div>
      <div class="box-body p-0">
	  {$customer_follow_html}
      </div>
    </div>
  </div>
</div>
TABLE;
}

/* ɸѡ���� */
function GetModulesScreenMoneyCount($Where=null){
	global $Fn_House;
	$SumCount = DB::result_first('SELECT sum(L.money) FROM '.DB::table($Fn_House->Pay->TablePayLog).' L '.$Where);
	return $SumCount ? $SumCount : 0;//��������
}
//From: Dism_taobao_com
?>