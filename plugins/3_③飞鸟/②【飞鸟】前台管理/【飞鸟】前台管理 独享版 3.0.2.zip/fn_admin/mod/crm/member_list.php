<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('crm_all') && !$Fn_Admin->CheckUserGroup('crm_member_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$SubModel = in_array($_GET['submodel'], array('list','add')) ? $_GET['submodel'] : 'list';
$Fn_Admin->Config['IframeSubModelUrl'] = $Fn_Admin->Config['IframeItemUrl'].'&submodel='.$SubModel;
$NavClass = array($SubModel=>'btn-info Hover');

//����
echo <<<Nav
<div class="SubModelNav">
  <ul>
	<li class="{$NavClass['list']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=list" target="_self">{$Fn_Admin->Config['LangVar']['CrmLeftNavArray'][$_GET['item']]}</a></li>
    <li class="{$NavClass['add']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=add" target="_self">{$Fn_Admin->Config['LangVar']['AddEditTitle']}</a></li>
  </ul>
  <div class="both"></div>
</div>
Nav;

if($SubModel == 'list'){//�б�
	$Do = in_array($_GET['do'], array('Del')) ? $_GET['do'] : 'submodel_list';
	//�����ֶ�
	$SearField =array('page','keyword','order');
	foreach($SearField as $Val) {
		$SearArray[$Val] = $_GET[$Val] || in_array($_GET[$Val],array('0')) ? $_GET[$Val] : '';
	}
	//�����ֶ� End
	$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeSubModelUrl'].'&'.http_build_query($SearArray);


	if($Do == 'submodel_list'){
		if(!submitcheck('Submit')) {
			$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
			$Where = '';
			$Order = $_GET['order'] ? 'm.'.addslashes(dhtmlspecialchars($_GET['order'])) : 'm.id';
			
			if($_GET['keyword']){
				$_GET['keyword'] = str_replace(array('%','_'),array('',''),$_GET['keyword']);
				$Where .= ' and (m.name like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or m.mobile like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\'))';
			}

			$Where = preg_replace('/and/','where',$Where,1);
			$Limit = 20;
			$Page = $_GET['page']?intval($_GET['page']):1;
			/* ��ѯ���� End */
		
			/* ģ����� */	
			
			showtagheader('div', 'row', true,'row');
			showtagheader('div', 'col-12', true,'col-12');
			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-body', true,'box-body');
			/* ���� */
		
			echo <<<SEARCH
			<form method="post" autocomplete="off" action="$SearUrl">
				<div class="FormSearchTo" style="margin-bottom:0;">
					<table cellspacing="4" cellpadding="4">
						<tr>
							<th>&#20851;&#38190;&#35789;</th><td><input type="text" class="input form-control w200" name="keyword" value="{$_GET['keyword']}" placeholder="&#35831;&#36755;&#20837;&#32844;&#21592;&#22995;&#21517;&#47;&#32852;&#31995;&#30005;&#35805;">
							&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Admin->Config['LangVar']['SearchSubmit']}" class="btn btn-info" type="submit">
							</td>
						</tr>
					</table>
				</div>
			</form>
SEARCH;
			/* ���� End */

			showtagheader('div', 'table-responsive', true,'table-responsive');
			showformheader($FormUrl,'enctype="multipart/form-data"');
			showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');

			showsubtitle(array(
				'ID',
				'&#32844;&#21592;&#22995;&#21517;',
				'&#32852;&#31995;&#30005;&#35805;',
				'&#25152;&#23646;&#37096;&#38376;',
				'&#25152;&#23646;&#32844;&#20301;',
				'&#39033;&#30446;&#26435;&#38480;',
				'&#66;&#32423;&#23458;&#25143;&#25968;&#37327;&#19978;&#38480;',
				'&#25805;&#20316;'
			),'header tbm tc');

			$ModulesList = GetModulesList($Page,$Limit,$Where,$Order);
			
			foreach ($ModulesList as $Module) {
				$project_group = array();
				foreach(explode(',',$Module['project_group']) as $val) {
					$project_group[] = $Fn_Crm->Config['setting']['project'][$val];
				}
				showtablerow('', array('class="tc w80"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
					'<input type="checkbox" class="filled-in" id="checkbox_'.$Module['id'].'" name="delete[]" value="'.$Module['id'].'"><label for="checkbox_'.$Module['id'].'">'.$Module['id'].'</label>',
					$Module['name'],
					$Module['mobile'],
					$Fn_Crm->Config['setting']['department'][$Module['department']],
					$Fn_Crm->Config['setting']['position'][$Module['position']],
					array_filter($project_group) ? implode(',',$project_group) : '&#19981;&#38480;&#21046;',
					$Module['customer_limit'],
					'<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&vid='.$Module['id'].'" class="btn btn-sm btn-info-outline">&#32534;&#36753;</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Del&vid='.$Module['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$Fn_Admin->Config['LangVar']['DelTitle'].'</a>',
				));
			}

			showsubmit('Submit','&#31435;&#21363;&#25552;&#20132;','del','','',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));

			showtablefooter(); /*dism��taobao��com*/
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			/* ģ�����End */	
		}else{
			if(!$Fn_Admin->CheckUserGroup('crm_all') && !$Fn_Admin->CheckUserGroup('crm_member_del')){//Ȩ���ж�
				fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
				exit();
			}

			if(isset($_GET['delete']) && is_array($_GET['delete'])){
				foreach($_GET['delete'] as $Key => $Val) {
					$Val = intval($Val);
					$member = DB::fetch_first('SELECT * FROM '.DB::table($Fn_Crm->TableMember).' where id = '.$Val);
					DB::delete($Fn_Crm->TableMember,'id ='.$Val);
					//DB::delete($Fn_Crm->TableCustomerFollow,'sale_uid ='.$member['uid']);
				}

				GetInsertDoLog('del_member_crm','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete'])));//������¼

				fn_cpmsg($Fn_Admin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
			}else{
				fn_cpmsg($Fn_Admin->Config['LangVar']['DelErr'],'','error');
			}
		}
	}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['vid']){
		if(!$Fn_Admin->CheckUserGroup('crm_all') && !$Fn_Admin->CheckUserGroup('crm_member_del')){//Ȩ���ж�
			fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
			exit();
		}
		$id = intval($_GET['vid']);
		$member = DB::fetch_first('SELECT * FROM '.DB::table($Fn_Crm->TableMember).' where id = '.$id);
		DB::delete($Fn_Crm->TableMember,'id ='.$id);
		//DB::delete($Fn_Crm->TableCustomerFollow,'sale_uid ='.$member['uid']);
		GetInsertDoLog('del_member_crm','fn_'.$_GET['mod'],array('id'=>$id));//������¼
		fn_cpmsg($Fn_Admin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');

	}
}else if($SubModel == 'add'){//���ӻ�༭
	if(!$Fn_Admin->CheckUserGroup('crm_all') && !$Fn_Admin->CheckUserGroup('crm_member_add')){//Ȩ���ж�
		fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
		exit();
	}
	$id = intval($_GET['vid']);
	
	$Item = DB::fetch_first('SELECT * FROM '.DB::table($Fn_Crm->TableMember).' where id = '.$id);

	if(!submitcheck('DetailSubmit')) {
		$OpTitle = $Fn_Admin->Config['LangVar']['AddTitle'];
		if($Item){
			$OpTitle = $Fn_Admin->Config['LangVar']['EditTitle'];
		}

		//ͼƬ�ϴ�
		if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_assembly/class/class_upload.php')){
			@require_once libfile('class/upload','plugin/fn_assembly');
			$UploadConfig = fn_upload::Config();
		}
		
		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-header', true,'with-border box-header');
		showtitle($OpTitle,'class="box-title"');
		showtagfooter('div');
		showformheader($Fn_Admin->Config['IframeSubModelUrl'].'&vid='.$id,'enctype');
		showtagheader('div', 'box-body', true,'box-body');
		
		showsetting('uid', 'new_uid', $Item['uid'], 'text',($Item ? true : ''));
		showsetting('&#32844;&#21592;&#22995;&#21517;', 'name', $Item['name'], 'text');
		showsetting('&#32852;&#31995;&#30005;&#35805;', 'mobile', $Item['mobile'], 'text');
		showsetting('&#25152;&#23646;&#37096;&#38376;',array('department',DyadicArray($Fn_Crm->Config['setting']['department'])),$Item['department'],'select');
		showsetting('&#25152;&#23646;&#32844;&#20301;',array('position',DyadicArray($Fn_Crm->Config['setting']['position'])),$Item['position'],'select');
		showsetting('&#66;&#32423;&#23458;&#25143;&#25968;&#37327;&#19978;&#38480;', 'customer_limit', $Item['customer_limit'], 'text','','','&#38144;&#21806;&#20154;&#21592;&#22312;&#19981;&#21516;&#26102;&#26399;&#25152;&#33021;&#22815;&#36319;&#36827;&#30340;&#23458;&#25143;&#25968;&#37327;&#26159;&#19981;&#21516;&#30340;&#65292;&#21487;&#29992;&#20110;&#35774;&#32622;&#26032;&#32769;&#38144;&#21806;&#30340;&#23458;&#25143;&#25968;&#65292;&#20063;&#21487;&#29992;&#20110;&#38144;&#21806;&#30340;&#22870;&#21169;&#21644;&#22788;&#32602;');
		
		$project_group = array();
		foreach($Fn_Crm->Config['setting']['project'] as $key => $val) {
			$project_group[] = array($key, $val);
		}
		showsetting('&#39033;&#30446;&#26435;&#38480;', array('project_group[]',$project_group),$Item['project_group'] ? explode(',',$Item['project_group']) : '','mselect','','','&#19981;&#36873;&#25321;&#20195;&#34920;&#20840;&#37096;&#39033;&#30446;&#21487;&#20197;&#31649;&#29702;&#65281;&#36873;&#25321;&#21518;&#65292;&#20844;&#20849;&#27744;/&#20840;&#37096;&#23458;&#25143;&#21482;&#26174;&#31034;&#26435;&#38480;&#20013;&#30340;&#23458;&#25143;<br>&#25353;&#20303;ctrl&#22810;&#36873;');

		if($Item['dateline']){
			showsetting('&#21019;&#24314;&#26102;&#38388;', 'dateline',date('Y-m-d H:i',$Item['dateline']), 'calendar','','','',1);
		}

		showsubmit('DetailSubmit','&#20445;&#23384;&#37197;&#32622;');
		showtagfooter('div');
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');


	}else{
		
		if(!$Item){
			$Data['uid'] = intval($_GET['new_uid']);
			if(!DB::fetch_first('SELECT username FROM '.DB::table('common_member').' where uid = '.$Data['uid'])){
				fn_cpmsg('&#29992;&#25143;&#19981;&#23384;&#22312;','','error');
				exit();
			}
		}
		$Data['name'] = addslashes(strip_tags($_GET['name']));
		$Data['mobile'] = addslashes(strip_tags($_GET['mobile']));
		$Data['project_group'] = implode(',',$_GET['project_group']);
		$Data['position'] = intval($_GET['position']);
		$Data['department'] = intval($_GET['department']);
		$Data['customer_limit'] = intval($_GET['customer_limit']);
		
		if($Item){

			$Data['dateline'] = strtotime($_GET['dateline']);

			GetInsertDoLog('edit_member_crm','fn_'.$_GET['mod'],array('id'=>$id));//������¼
			DB::update($Fn_Crm->TableMember,$Data,'id = '.$id);
		}else{
			$Data['dateline'] = time();
			$id = DB::insert($Fn_Crm->TableMember,$Data,true);
			GetInsertDoLog('add_member_crm','fn_'.$_GET['mod'],array('id'=>$id));//������¼
		}
		fn_cpmsg($Fn_Admin->Config['LangVar']['UpdateOk'],$Fn_Admin->Config['IframeItemUrl'].'&submodel=list','succeed');
		
	}
}


/* �б� */
function GetModulesList($Page,$Limit,$Where=null,$Order){
	global $Fn_Crm;
	$FetchSql = 'SELECT m.* FROM '.DB::table($Fn_Crm->TableMember).' m '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}

/* ���� */
function GetModulesCount($Where=null){
	global $Fn_Crm;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_Crm->TableMember).' m '.$Where;
	return DB::result_first($FetchSql);//��������
}

?>