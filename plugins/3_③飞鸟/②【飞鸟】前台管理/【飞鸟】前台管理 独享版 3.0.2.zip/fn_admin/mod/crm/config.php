<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if(!$Fn_Admin->CheckUserGroup('crm_all') && !$Fn_Admin->CheckUserGroup('crm_config')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

@require_once libfile('function/cache');
@require_once libfile('function/core','plugin/fn_assembly');

$setting_name = 'fn_'.$_GET['mod'].'_setting';
loadcache($setting_name);
$common_setting = $_G['cache'][$setting_name];
$setting = $common_setting = array_filter($common_setting) ? $common_setting : array();
foreach($setting as $key => $value) {
	$setting[$key] = is_array($value) ? $value : stripslashes($value);
}
$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeItemUrl'];

if(!submitcheck('DetailSubmit')) {
	//ͼƬ�ϴ�
	if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_assembly/class/class_upload.php')){
		@require_once libfile('class/upload','plugin/fn_assembly');
		$UploadConfig = fn_upload::Config();
	}

	showtagheader('div', 'box', true,'box');
	showformheader($FormUrl,'enctype');
	echo <<<HTML
		<ul class="nav nav-tabs customtab" role="tablist">
          <li class="nav-item"> <a class="nav-link active" data-toggle="tab" href="#basics" role="tab" aria-expanded="true"><span class="hidden-sm-up"><i class="ion-home"></i></span> <span class="hidden-xs-down">&#22522;&#30784;&#35774;&#32622;</span></a> </li>
        </ul>
HTML;

	showtagheader('div', 'box-body', true,'box-body');

	showtagheader('div', 'tab-content', true,'tab-content');

	echo <<<HTML
	<!-- ��������  -->
	<div class="tab-pane active" id="basics" role="tabpanel" aria-expanded="true">
HTML;
		
	showsetting('&#23458;&#25143;&#29366;&#24577;&#26631;&#31614;', 'setting[level]', $setting['level'] ? $setting['level'] : '1=A&#32423;(&#31614;&#32422;&#23458;&#25143;)
2=B&#32423;(&#36319;&#36827;&#23458;&#25143;)
3=C&#32423;(&#20844;&#28023;&#23458;&#25143;)', 'textarea','','','&#24314;&#35758;&#20351;&#29992;&#40664;&#35748;<br>&#19968;&#34892;&#19968;&#26631;&#31614;&#65292;&#26684;&#24335;&#65306;<br>1=&#26631;&#31614;&#19968;<br>2=&#26631;&#31614;&#20108;');

	showsetting('&#25152;&#23646;&#39033;&#30446;&#26631;&#31614;', 'setting[project]', $setting['project'] ? $setting['project'] : 'fn_job=&#25307;&#32856;
fn_renovation=&#35013;&#20462;
fn_renovation_material=&#24314;&#26448;
fn_xiangqin=&#30456;&#20146;', 'textarea','','','&#24314;&#35758;&#20351;&#29992;&#40664;&#35748;<br>&#19968;&#34892;&#19968;&#26631;&#31614;&#65292;&#26684;&#24335;&#65306;<br>1=&#26631;&#31614;&#19968;<br>2=&#26631;&#31614;&#20108;');

	showsetting('&#25152;&#23646;&#37096;&#38376;&#26631;&#31614;', 'setting[department]', $setting['department'] ? $setting['department'] : '1=&#38144;&#21806;&#37096;
2=&#32534;&#36753;&#37096;', 'textarea','','','&#24314;&#35758;&#20351;&#29992;&#40664;&#35748;<br>&#19968;&#34892;&#19968;&#26631;&#31614;&#65292;&#26684;&#24335;&#65306;<br>1=&#26631;&#31614;&#19968;');

	showsetting('&#25152;&#23646;&#32844;&#20301;&#26631;&#31614;', 'setting[position]', $setting['position'] ? $setting['position'] : '1=&#38144;&#21806;
2=&#37096;&#38376;&#20027;&#31649;', 'textarea','','','&#24314;&#35758;&#20351;&#29992;&#40664;&#35748;<br>&#19968;&#34892;&#19968;&#26631;&#31614;&#65292;&#26684;&#24335;&#65306;<br>1=&#26631;&#31614;&#19968;');

	showsetting('&#21069;&#36127;&#36131;&#20154;&#35268;&#21017;', 'setting[front_sale_limit]', $setting['front_sale_limit'] ? $setting['front_sale_limit'] : '10', 'text','','','&#21069;&#36127;&#36131;&#20154;&#22810;&#23569;&#22825;&#20869;&#19981;&#21487;&#39046;&#21462;&#35813;&#23458;&#25143;');
	
	showsetting('&#66;&#32423;&#26410;&#36319;&#36827;', 'setting[b_c_limit]', $setting['b_c_limit'] ? $setting['b_c_limit'] : '15', 'text','','','&#66;&#32423;&#40;&#36319;&#36827;&#23458;&#25143;&#41;&#22810;&#23569;&#22825;&#26410;&#36319;&#36827;&#65292;&#33258;&#21160;&#25481;&#33853;&#23458;&#25143;&#20844;&#28023;&#27744;');

	showsetting('&#66;&#32423;&#26410;&#31614;&#32422;', 'setting[b_a_limit]', $setting['b_a_limit'] ? $setting['b_a_limit'] : '30', 'text','','','&#66;&#32423;&#40;&#36319;&#36827;&#23458;&#25143;&#41;&#22810;&#23569;&#22825;&#26410;&#31614;&#32422;&#65292;&#33258;&#21160;&#25481;&#33853;&#23458;&#25143;&#20844;&#28023;&#27744;');

	echo <<<HTML
	</div>
	<!-- �������� end  -->
HTML;

	showsubmit('DetailSubmit', '&#20445;&#23384;&#37197;&#32622;');
	showtagfooter('div');
	showtagfooter('div');
	showformfooter(); /*Dism_taobao-com*/
	showtagfooter('div');
	
}else{
	
	foreach($_GET['setting'] as $key => $value) {
		$setting[$key] = is_array($value) ? $value : addslashes($value);
	}

	foreach($_GET['upload_admin'] as $key => $value){
		if(strpos($key,'new_') !== false){
			$key_name = str_replace(array('new_'),'',$key);
			$setting[$key_name] = array();
			foreach($_GET[$key] as $k => $v) {
				$setting[$key_name][$k]['img'] = strpos($v,'http') !== false ? $v : $_G['siteurl'].$v;
				$setting[$key_name][$k]['link'] = $_GET[$key.'_link'][$k];
				$setting[$key_name][$k]['title'] = $_GET[$key.'_title'][$k];
			}
		}
	}

	foreach(array('footer_nav') as $common_nav_value){
		foreach($_GET['common_list'][$common_nav_value] as $nav_key => $nav_value){
			foreach($_GET['common_list'][$common_nav_value]['displayorder'] as $key => $value){
				$new_setting[$common_nav_value][$key][$nav_key] = filter_string($_GET['common_list'][$common_nav_value][$nav_key][$key]);
				if($_FILES['common_list']['size'][$common_nav_value]['file_'.$nav_key][$key]){
					$images = array(
						'name' => $_FILES['common_list']['name'][$common_nav_value]['file_'.$nav_key][$key],
						'type' => $_FILES['common_list']['type'][$common_nav_value]['file_'.$nav_key][$key],
						'tmp_name' => $_FILES['common_list']['tmp_name'][$common_nav_value]['file_'.$nav_key][$key],
						'error' => $_FILES['common_list']['error'][$common_nav_value]['file_'.$nav_key][$key],
						'size' => $_FILES['common_list']['size'][$common_nav_value]['file_'.$nav_key][$key]
					);
					$FileCode = Fn_Upload($images);
					$new_setting[$common_nav_value][$key][$nav_key] = $FileCode['Path'];
				}
			}
		}
		$setting[$common_nav_value] = array_sort($new_setting[$common_nav_value],'displayorder');
	}

	foreach($_FILES as $file_key => $file_value){
		if(strpos($file_key,'new_') !== false){
			$key = str_replace(array('TMPnew_','new_'),'',$file_key);
			if($_FILES[$file_key]['size']){
				$FileCode = Fn_Upload($_FILES[$file_key]);
				if($FileCode['Errorcode']){
					cpmsg($Fn_Admin->Config['LangVar']['ImgErr'],'','error');
					exit();
				}else{
					$setting[$key] = $FileCode['Path'];
				}
			}else{
				$file_key = str_replace(array('TMPnew_'),array('new_'),$file_key);
				if(!preg_match('/.*(\.png|\.jpg|\.jpeg|\.gif)$/',$_GET[$file_key]) && $_GET[$file_key]){
					cpmsg($Fn_Admin->Config['LangVar']['ImgErr'],'','error');
					exit();
				}else{
					$setting[$key] = addslashes(strip_tags($_GET[$file_key]));
				}
			}
		}
	}
	savecache($setting_name,$setting);
	fn_cpmsg($Fn_Admin->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
	exit();

}
//From: Dism_taobao_com
?>