<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('crm_all') && !$Fn_Admin->CheckUserGroup('crm_customer_recovery_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$SubModel = in_array($_GET['submodel'], array('list','add')) ? $_GET['submodel'] : 'list';
$Fn_Admin->Config['IframeSubModelUrl'] = $Fn_Admin->Config['IframeItemUrl'].'&submodel='.$SubModel;
$NavClass = array($SubModel=>'btn-info Hover');

if($SubModel == 'list'){//�б�
	$Do = in_array($_GET['do'], array('Receive')) ? $_GET['do'] : 'submodel_list';
	//�����ֶ�
	$SearField =array('page','keyword','order','project','project_id');
	foreach($SearField as $Val) {
		$SearArray[$Val] = $_GET[$Val] || in_array($_GET[$Val],array('0')) ? $_GET[$Val] : '';
	}
	//�����ֶ� End
	$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeSubModelUrl'].'&'.http_build_query($SearArray);

	$member = DB::fetch_first('SELECT * FROM '.DB::table($Fn_Crm->TableMember).' where uid = '.intval($_G['uid']));

	if($Do == 'submodel_list'){
		if(!submitcheck('Submit')) {
			$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
			if($member['project_group']){
				$project_group = array();
				foreach(explode(',',$member['project_group']) as $val) {
					$project_group[] = "'".$val."'";
				}
			}
			$Where = ' and c.recovery = 0 and c.level = 3'.($project_group ? ' and c.project in('.implode(',',$project_group).')' : '');

			$Order = $_GET['order'] ? 'c.'.addslashes(dhtmlspecialchars($_GET['order'])) : 'c.id';
			
			if($_GET['keyword']){
				$_GET['keyword'] = str_replace(array('%','_'),array('',''),$_GET['keyword']);
				$Where .= ' and (c.name like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or c.decision_mobile like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') )';
			}

			if($_GET['project']){
				$Where .= ' and c.project = \''.addslashes(strip_tags($_GET['project'])).'\'';
			}

			if($_GET['project_id']){
				$Where .= ' and c.project_id = '.intval($_GET['project_id']);
			}

			$Where = preg_replace('/and/','where',$Where,1);
			$Limit = 20;
			$Page = $_GET['page']?intval($_GET['page']):1;
			/* ��ѯ���� End */
		
			/* ģ����� */	
			
			showtagheader('div', 'row', true,'row');
			showtagheader('div', 'col-12', true,'col-12');
			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-body', true,'box-body');
			/* ���� */
			
			$project_option = '<option value="">'.$Fn_Admin->Config['LangVar']['SelectNull'].'</option>';
			foreach($Fn_Crm->Config['setting']['project'] as $key => $val) {
				if(in_array($key,explode(',',$member['project_group'])) && $member['project_group']){
					$project_option .= '<option value="'.$key.'" '.($_GET['project'] == $key ? ' selected' : '' ).'>'.$val.'</option>';
				}else if(!$member['project_group']){
					$project_option .= '<option value="'.$key.'" '.($_GET['project'] == $key ? ' selected' : '' ).'>'.$val.'</option>';
				}
			}

			echo <<<SEARCH
			<form method="post" autocomplete="off" action="$SearUrl">
				<div class="FormSearchTo" style="margin-bottom:0;">
					<table cellspacing="4" cellpadding="4">
						<tr>
							<th>&#23458;&#25143;</th><td><input type="text" class="input form-control w200" name="keyword" value="{$_GET['keyword']}" placeholder="&#35831;&#36755;&#20837;&#23458;&#25143;&#21517;&#31216;&#47;&#30005;&#35805;">
							</td>

							<th>&#25152;&#23646;&#39033;&#30446;</th><td>
							<select name="project" class="form-control w120">
								{$project_option}
							</select>
							</td>
							<th>&#39033;&#30446;&#20844;&#21496;&#73;&#68;</th><td><input type="text" class="input form-control w150" name="project_id" value="{$_GET['project_id']}" placeholder="&#35831;&#36755;&#20837;&#39033;&#30446;&#20844;&#21496;&#73;&#68;">
							&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Admin->Config['LangVar']['SearchSubmit']}" class="btn btn-info" type="submit">
							</td>
						</tr>
					</table>
				</div>
			</form>
SEARCH;
			/* ���� End */

			showtagheader('div', 'table-responsive', true,'table-responsive');
			showformheader($FormUrl,'enctype="multipart/form-data"');
			showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');

			showsubtitle(array(
				'ID',
				'&#23458;&#25143;&#21517;&#31216;',
				'&#23458;&#25143;&#32852;&#31995;&#30005;&#35805;',
				'&#25152;&#23646;&#39033;&#30446;',
				'&#26368;&#21518;&#36319;&#36827;&#26102;&#38388;&#32;',
				'&#25481;&#33853;&#26102;&#38388;',
				'&#21019;&#24314;&#26102;&#38388;',
				'&#25805;&#20316;'
			),'header tbm tc');

			$ModulesList = GetModulesList($Page,$Limit,$Where,$Order);
			
			foreach ($ModulesList as $Module) {
				showtablerow('', array('class="tc w80"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
					'<input type="checkbox" class="filled-in" id="checkbox_'.$Module['id'].'" name="delete[]" value="'.$Module['id'].'"><label for="checkbox_'.$Module['id'].'">'.$Module['id'].'</label>',
					$Module['name'],
					$Module['decision_mobile'],
					$Fn_Crm->Config['setting']['project'][$Module['project']],
					$Module['last_follow_dateline'] ? date('Y-m-d H:i',$Module['last_follow_dateline']) : '&#26242;&#26080;&#36319;&#36827;&#35760;&#24405;',
					$Module['drop_dateline'] ? date('Y-m-d H:i',$Module['drop_dateline']) : '',
					date('Y-m-d H:i',$Module['dateline']),
					'<a href="'.$OpCpUrl.'&do=Receive&vid='.$Module['id'].'&formhash='.FORMHASH.'" class="btn btn-sm btn-danger-outline">&#39046;&#21462;</a>',
				));
			}

			showsubmit('Submit','&#31435;&#21363;&#25552;&#20132;','<input name="optype" value="Receive" class="with-gap" type="radio" id="v_recovery"><label class="custom-control-label" for="v_recovery" style="margin-left:-5px;">&#39046;&#21462;</label>','','select_all',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));

			showtablefooter(); /*dism��taobao��com*/
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			/* ģ�����End */	
		}else{
			if(isset($_GET['delete']) && is_array($_GET['delete'])){
				if($_GET['optype'] == 'Receive'){//��ȡ
					$member = DB::fetch_first('SELECT * FROM '.DB::table($Fn_Crm->TableMember).' where uid = '.intval($_G['uid']));
					if(DB::result_first('SELECT COUNT(*) FROM '.DB::table($Fn_Crm->TableCustomer).' where level = 2 and sale_uid = '.intval($_G['uid'])) >= $member['customer_limit']){
						fn_cpmsg('&#32844;&#21592;&#25345;&#26377;B&#32423;&#23458;&#25143;&#24050;&#36798;&#19978;&#38480;<br>&#35831;&#32852;&#31995;&#20027;&#31649;&#35843;&#25972;B&#32423;&#23458;&#25143;&#19978;&#38480;','','error');
						exit();
					}
	
					foreach($_GET['delete'] as $Key => $Val) {
						$Val = intval($Val);
						if(!DB::fetch_first('SELECT * FROM '.DB::table($Fn_Crm->TableCustomer).' where front_sale_uid = '.intval($_G['uid']).' and id = '.$Val.' and drop_dateline >'.strtotime('-'.$Fn_Crm->Config['setting']['front_sale_limit'].' day'))){
							DB::update($Fn_Crm->TableCustomer,array('sale_uid'=>intval($_G['uid']),'front_sale_uid'=>intval($_G['uid']),'level'=>2,'drop_dateline'=>'','receive_dateline'=>time()),'id = '.$Val);
						}
						DB::insert($Fn_Crm->TableReceiveLog,array('sale_uid'=>intval($_G['uid']),'customer_id'=>$Val,'dateline'=>time()));
					}
					GetInsertDoLog('crm_customer_recovery_0','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete'])));//������¼
					fn_cpmsg('&#39046;&#21462;&#25104;&#21151;',$CpMsgUrl,'succeed');

				}else{
					fn_cpmsg($Fn_Admin->Config['LangVar']['OpErr'],'','error');
				}	
			}else{
				fn_cpmsg($Fn_Admin->Config['LangVar']['OpErr'],'','error');
			}	
		}
	}else if($Do == 'Receive' && $_GET['formhash'] == formhash() && $_GET['vid']){
		$member = DB::fetch_first('SELECT * FROM '.DB::table($Fn_Crm->TableMember).' where uid = '.intval($_G['uid']));
		if(DB::result_first('SELECT COUNT(*) FROM '.DB::table($Fn_Crm->TableCustomer).' where level = 2 and sale_uid = '.intval($_G['uid'])) >= $member['customer_limit']){
			fn_cpmsg('&#32844;&#21592;&#25345;&#26377;B&#32423;&#23458;&#25143;&#24050;&#36798;&#19978;&#38480;<br>&#35831;&#32852;&#31995;&#20027;&#31649;&#35843;&#25972;B&#32423;&#23458;&#25143;&#19978;&#38480;','','error');
			exit();
		}
		$id = intval($_GET['vid']);
		
		if(DB::fetch_first('SELECT * FROM '.DB::table($Fn_Crm->TableCustomer).' where front_sale_uid = '.intval($_G['uid']).' and id = '.$id.' and drop_dateline >'.strtotime('-'.$Fn_Crm->Config['setting']['front_sale_limit'].' day'))){
			fn_cpmsg('&#35813;&#23458;&#25143;&#24744;&#26242;&#26102;&#19981;&#33021;&#39046;&#21462;','','error');
			exit();
		}

		DB::insert($Fn_Crm->TableReceiveLog,array('sale_uid'=>intval($_G['uid']),'customer_id'=>$id,'dateline'=>time()));

		DB::update($Fn_Crm->TableCustomer,array('sale_uid'=>intval($_G['uid']),'front_sale_uid'=>intval($_G['uid']),'level'=>2,'drop_dateline'=>'','receive_dateline'=>time()),'id = '.$id);
		GetInsertDoLog('crm_customer_receive','fn_'.$_GET['mod'],array('id'=>$id));//������¼
		fn_cpmsg('&#39046;&#21462;&#25104;&#21151;',$CpMsgUrl,'succeed');
	}
}

/* �б� */
function GetModulesList($Page,$Limit,$Where=null,$Order){
	global $Fn_Crm;
	$FetchSql = 'SELECT c.* FROM '.DB::table($Fn_Crm->TableCustomer).' c '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}

/* ���� */
function GetModulesCount($Where=null){
	global $Fn_Crm;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_Crm->TableCustomer).' c '.$Where;
	return DB::result_first($FetchSql);//��������
}

?>