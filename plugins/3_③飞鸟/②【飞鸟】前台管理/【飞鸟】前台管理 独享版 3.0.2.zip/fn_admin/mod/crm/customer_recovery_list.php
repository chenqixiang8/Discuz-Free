<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('crm_all') && !$Fn_Admin->CheckUserGroup('crm_customer_recovery_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$SubModel = in_array($_GET['submodel'], array('list','add')) ? $_GET['submodel'] : 'list';
$Fn_Admin->Config['IframeSubModelUrl'] = $Fn_Admin->Config['IframeItemUrl'].'&submodel='.$SubModel;
$NavClass = array($SubModel=>'btn-info Hover');

if($SubModel == 'list'){//�б�
	$Do = in_array($_GET['do'], array('Del','Recovery')) ? $_GET['do'] : 'submodel_list';
	//�����ֶ�
	$SearField =array('page','keyword','order');
	foreach($SearField as $Val) {
		$SearArray[$Val] = $_GET[$Val] || in_array($_GET[$Val],array('0')) ? $_GET[$Val] : '';
	}
	//�����ֶ� End
	$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeSubModelUrl'].'&'.http_build_query($SearArray);


	if($Do == 'submodel_list'){
		if(!submitcheck('Submit')) {
			$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
			$Where = ' and c.recovery = 1';
			$Order = $_GET['order'] ? 'c.'.addslashes(dhtmlspecialchars($_GET['order'])) : 'c.id';
			
			if($_GET['keyword']){
				$_GET['keyword'] = str_replace(array('%','_'),array('',''),$_GET['keyword']);
				$Where .= ' and (c.name like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') )';
			}

			$Where = preg_replace('/and/','where',$Where,1);
			$Limit = 20;
			$Page = $_GET['page']?intval($_GET['page']):1;
			/* ��ѯ���� End */
		
			/* ģ����� */	
			
			showtagheader('div', 'row', true,'row');
			showtagheader('div', 'col-12', true,'col-12');
			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-body', true,'box-body');
			/* ���� */
			

			echo <<<SEARCH
			<form method="post" autocomplete="off" action="$SearUrl">
				<div class="FormSearchTo" style="margin-bottom:0;">
					<table cellspacing="4" cellpadding="4">
						<tr>
							<th>&#23458;&#25143;</th><td><input type="text" class="input form-control w200" name="keyword" value="{$_GET['keyword']}" placeholder="&#35831;&#36755;&#20837;&#23458;&#25143;&#21517;&#31216;">
							&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Admin->Config['LangVar']['SearchSubmit']}" class="btn btn-info" type="submit">
							</td>
						</tr>
					</table>
				</div>
			</form>
SEARCH;
			/* ���� End */

			showtagheader('div', 'table-responsive', true,'table-responsive');
			showformheader($FormUrl,'enctype="multipart/form-data"');
			showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');

			showsubtitle(array(
				'ID',
				'&#23458;&#25143;&#21517;&#31216;',
				'&#23458;&#25143;&#32852;&#31995;&#30005;&#35805;',
				'&#25918;&#36827;&#22238;&#25910;&#31449;&#26102;&#38388;',
				'&#25805;&#20316;'
			),'header tbm tc');

			$ModulesList = GetModulesList($Page,$Limit,$Where,$Order);
			
			foreach ($ModulesList as $Module) {
				showtablerow('', array('class="tc w80"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
					'<input type="checkbox" class="filled-in" id="checkbox_'.$Module['id'].'" name="delete[]" value="'.$Module['id'].'"><label for="checkbox_'.$Module['id'].'">'.$Module['id'].'</label>',
					$Module['name'],
					$Module['decision_mobile'],
					date('Y-m-d H:i',$Module['void_dateline']),
					'<a href="'.$OpCpUrl.'&do=Recovery&vid='.$Module['id'].'&formhash='.FORMHASH.'" class="btn btn-sm btn-info-outline">&#24674;&#22797;</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Del&vid='.$Module['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$Fn_Admin->Config['LangVar']['DelTitle'].'</a>',
				));
			}

			showsubmit('Submit','&#31435;&#21363;&#25552;&#20132;','<input name="optype" value="Recovery" class="with-gap" type="radio" id="v_recovery"><label class="custom-control-label" for="v_recovery" style="margin-left:-5px;">&#24674;&#22797;</label>&nbsp;&nbsp;&nbsp;&nbsp;<input name="optype" value="Del" class="with-gap" type="radio" id="v_del"><label class="custom-control-label" for="v_del" style="margin-left:-5px;">'.$Fn_Admin->Config['LangVar']['DelTitle'].'</label>','','select_all',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));

			showtablefooter(); /*dism��taobao��com*/
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			/* ģ�����End */	
		}else{
			if(isset($_GET['delete']) && is_array($_GET['delete'])){
				if($_GET['optype'] == 'Del'){//ȫɾ
					if(!$Fn_Admin->CheckUserGroup('crm_all') && !$Fn_Admin->CheckUserGroup('crm_customer_del')){//Ȩ���ж�
						fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
						exit();
					}
					foreach($_GET['delete'] as $Key => $Val) {
						$Val = intval($Val);
						DB::delete($Fn_Crm->TableCustomer,'id ='.$Val);
						DB::delete($Fn_Crm->TableCustomerFollow,'customer_id ='.$Val);
					}
					GetInsertDoLog('del_customer_crm','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete'])));//������¼
					fn_cpmsg($Fn_Admin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');

				}else if($_GET['optype'] == 'Recovery'){//ȫɾ
					foreach($_GET['delete'] as $Key => $Val) {
						$Val = intval($Val);
						DB::update($Fn_Crm->TableCustomer,array('recovery'=>0,'void_dateline'=>''),'id = '.$Val);
					}
					GetInsertDoLog('crm_customer_recovery_0','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete'])));//������¼
					fn_cpmsg($Fn_Admin->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

				}else{
					fn_cpmsg($Fn_Admin->Config['LangVar']['OpErr'],'','error');
				}	
			}else{
				fn_cpmsg($Fn_Admin->Config['LangVar']['OpErr'],'','error');
			}	
		}
	}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['vid']){
		if(!$Fn_Admin->CheckUserGroup('crm_all') && !$Fn_Admin->CheckUserGroup('crm_customer_del')){//Ȩ���ж�
			fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
			exit();
		}
		$id = intval($_GET['vid']);
		DB::delete($Fn_Crm->TableCustomer,'id ='.$id);
		DB::delete($Fn_Crm->TableCustomerFollow,'customer_id ='.$id);
		GetInsertDoLog('del_customer_crm','fn_'.$_GET['mod'],array('id'=>$id));//������¼
		fn_cpmsg($Fn_Admin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');

	}else if($Do == 'Recovery' && $_GET['formhash'] == formhash() && $_GET['vid']){
		$id = intval($_GET['vid']);
		DB::update($Fn_Crm->TableCustomer,array('recovery'=>0,'void_dateline'=>''),'id = '.$id);
		GetInsertDoLog('crm_customer_recovery_0','fn_'.$_GET['mod'],array('id'=>$id));//������¼
		fn_cpmsg($Fn_Admin->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
	}
}

/* �б� */
function GetModulesList($Page,$Limit,$Where=null,$Order){
	global $Fn_Crm;
	$FetchSql = 'SELECT c.* FROM '.DB::table($Fn_Crm->TableCustomer).' c '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}

/* ���� */
function GetModulesCount($Where=null){
	global $Fn_Crm;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_Crm->TableCustomer).' c '.$Where;
	return DB::result_first($FetchSql);//��������
}

?>