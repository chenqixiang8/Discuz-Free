<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('crm_all') && !$Fn_Admin->CheckUserGroup('crm_customer_follow_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$SubModel = in_array($_GET['submodel'], array('list','add')) ? $_GET['submodel'] : 'list';
$Fn_Admin->Config['IframeSubModelUrl'] = $Fn_Admin->Config['IframeItemUrl'].'&submodel='.$SubModel;
$NavClass = array($SubModel=>'btn-info Hover');

if($SubModel == 'list'){//�б�
	$Do = in_array($_GET['do'], array('Del','Recovery')) ? $_GET['do'] : 'submodel_list';
	//�����ֶ�
	$SearField =array('page','keyword','order','customer_id','sale_uid');
	foreach($SearField as $Val) {
		$SearArray[$Val] = $_GET[$Val] || in_array($_GET[$Val],array('0')) ? $_GET[$Val] : '';
	}
	//�����ֶ� End
	$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeSubModelUrl'].'&'.http_build_query($SearArray);

	
	if($Do == 'submodel_list'){
		if(!submitcheck('Submit')) {
			$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
			
			if($Fn_Admin->CheckUserGroup('crm_customer_follow_my')){
				$customer_id = array();
				foreach(DB::fetch_all('SELECT id FROM '.DB::table($Fn_Crm->TableCustomer).' where sale_uid = '.intval($_G['uid']).' order by id asc') as $val) {
					$customer_id[] = $val['id'];
				}
			}
			
			$Where = $Fn_Admin->CheckUserGroup('crm_customer_follow_my') ? ' and (f.sale_uid = '.intval($_G['uid']).( !empty($customer_id) ? ' or f.customer_id in('.implode(',',$customer_id).')' : '').')' : '';
			$Order = $_GET['order'] ? 'f.'.addslashes(dhtmlspecialchars($_GET['order'])) : 'f.id';
			
			if($_GET['keyword']){
				$_GET['keyword'] = str_replace(array('%','_'),array('',''),$_GET['keyword']);
				$Where .= ' and (f.name like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') )';
			}

			if($_GET['customer_id']){
				$Where .= ' and f.customer_id = '.intval($_GET['customer_id']);
			}

			if($_GET['sale_uid']){
				$Where .= ' and f.sale_uid = '.intval($_GET['sale_uid']);
			}

			$Where = preg_replace('/and/','where',$Where,1);
			$Limit = 20;
			$Page = $_GET['page']?intval($_GET['page']):1;
			/* ��ѯ���� End */
		
			/* ģ����� */	
			
			showtagheader('div', 'row', true,'row');
			showtagheader('div', 'col-12', true,'col-12');
			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-body', true,'box-body');
			/* ���� */
			
			if(!$Fn_Admin->CheckUserGroup('crm_customer_follow_my')){
				$member_option = '<th>&#36319;&#36827;&#20154;</th><td><select name="sale_uid" class="form-control w150"><option value="">'.$Fn_Admin->Config['LangVar']['SelectNull'].'</option>';
				foreach(DB::fetch_all('SELECT * FROM '.DB::table($Fn_Crm->TableMember).' order by id asc') as $Val) {
					$member_option .= '<option value="'.$Val['uid'].'" '.($_GET['sale_uid'] == $Val['uid'] ? ' selected' : '' ).'>'.$Val['name'].'</option>';
				}
				$member_option .= '</select></td>';
			}

			echo <<<SEARCH
			<form method="post" autocomplete="off" action="$SearUrl">
				<div class="FormSearchTo" style="margin-bottom:0;">
					<table cellspacing="4" cellpadding="4">
						<tr>
							<!--<th>&#23458;&#25143;</th><td><input type="text" class="input form-control w200" name="keyword" value="{$_GET['keyword']}" placeholder="&#35831;&#36755;&#20837;&#23458;&#25143;&#21517;&#31216;">
							</td>-->

							<th>&#23458;&#25143;&#73;&#68;</th><td><input type="text" class="input form-control w150" name="customer_id" value="{$_GET['customer_id']}" placeholder="&#35831;&#36755;&#20837;&#23458;&#25143;&#73;&#68;">
							</td>
							$member_option
							<td>&nbsp;<input name="SearchSubmit" value="{$Fn_Admin->Config['LangVar']['SearchSubmit']}" class="btn btn-info" type="submit"></td>
						</tr>
					</table>
				</div>
			</form>
SEARCH;
			/* ���� End */

			showtagheader('div', 'table-responsive', true,'table-responsive');
			showformheader($FormUrl,'enctype="multipart/form-data"');
			showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');

			showsubtitle(array(
				'ID',
				'&#23458;&#25143;&#21517;&#31216;',
				'&#36319;&#36827;&#20154;',
				'&#36319;&#36827;&#20869;&#23481;',
				'&#36319;&#36827;&#22270;&#29255;',
				'&#36319;&#36827;&#26102;&#38388;',
				'&#21019;&#24314;&#26102;&#38388;',
				'&#25805;&#20316;'
			),'header tbm tc');

			$ModulesList = GetModulesList($Page,$Limit,$Where,$Order);
			
			foreach ($ModulesList as $Module) {
				$pic_html = '';
				foreach(explode(',',$Module['pic']) as $pic) {
					$pic_html .= '<a class="image-popup-vertical-fit" href="'.$pic.'" style="float:left;display:inline;margin-right:5px;" target="_blank"><div style="background:url('.$pic.') no-repeat center;background-size:cover;width:30px;height:30px;"></div></a>';
				}
				showtablerow('', array('class="tc w80"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
					'<input type="checkbox" class="filled-in" id="checkbox_'.$Module['id'].'" name="delete[]" value="'.$Module['id'].'"><label for="checkbox_'.$Module['id'].'">'.$Module['id'].'</label>',
					$Module['customer_name'],
					$Module['sale_name'],
					'<div data-container="body" data-toggle="popover" data-trigger="hover" data-placement="left" data-html="true" data-content="'.$Module['content'].'">'.cutstr($Module['content'],100).'</div>',
					$pic_html,
					$Module['follow_dateline'] ? date('Y-m-d H:i',$Module['follow_dateline']) : '',
					$Module['dateline'] ? date('Y-m-d H:i',$Module['dateline']) : '',
					'<a href="'.$OpCpUrl.'&do=Del&vid='.$Module['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">'.$Fn_Admin->Config['LangVar']['DelTitle'].'</a>',
				));
			}

			showsubmit('Submit','&#31435;&#21363;&#25552;&#20132;','del','','',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));

			showtablefooter(); /*dism��taobao��com*/
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			/* ģ�����End */	
		}else{
			if(!$Fn_Admin->CheckUserGroup('crm_all') && !$Fn_Admin->CheckUserGroup('crm_customer_follow_del')){//Ȩ���ж�
				fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
				exit();
			}

			if(isset($_GET['delete']) && is_array($_GET['delete'])){
				foreach($_GET['delete'] as $Key => $Val) {
					$Val = intval($Val);
					DB::delete($Fn_Crm->TableCustomerFollow,'id ='.$Val);
				}

				GetInsertDoLog('del_customer_follow_crm','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete'])));//������¼

				fn_cpmsg($Fn_Admin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
			}else{
				fn_cpmsg($Fn_Admin->Config['LangVar']['DelErr'],'','error');
			}
		}
	}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['vid']){
		if(!$Fn_Admin->CheckUserGroup('crm_all') && !$Fn_Admin->CheckUserGroup('crm_customer_follow_del')){//Ȩ���ж�
			fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
			exit();
		}
		$id = intval($_GET['vid']);
		DB::delete($Fn_Crm->TableCustomerFollow,'id ='.$id);
		GetInsertDoLog('del_customer_follow_crm','fn_'.$_GET['mod'],array('id'=>$id));//������¼
		fn_cpmsg($Fn_Admin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');

	}
}

/* �б� */
function GetModulesList($Page,$Limit,$Where=null,$Order){
	global $Fn_Crm;
	$FetchSql = 'SELECT f.*,m.name as sale_name,c.name as customer_name FROM '.DB::table($Fn_Crm->TableCustomerFollow).' f LEFT JOIN `'.DB::table($Fn_Crm->TableMember).'` m on m.uid = f.sale_uid LEFT JOIN `'.DB::table($Fn_Crm->TableCustomer).'` c on c.id = f.customer_id '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}

/* ���� */
function GetModulesCount($Where=null){
	global $Fn_Crm;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_Crm->TableCustomerFollow).' f '.$Where;
	return DB::result_first($FetchSql);//��������
}

?>