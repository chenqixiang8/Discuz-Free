<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('crm_all') && !$Fn_Admin->CheckUserGroup('crm_all_customer_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$SubModel = in_array($_GET['submodel'], array('list','add')) ? $_GET['submodel'] : 'list';
$Fn_Admin->Config['IframeSubModelUrl'] = $Fn_Admin->Config['IframeItemUrl'].'&submodel='.$SubModel;
$NavClass = array($SubModel=>'btn-info Hover');

//����
echo <<<Nav
<div class="SubModelNav">
  <ul>
	<li class="{$NavClass['list']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=list" target="_self">{$Fn_Admin->Config['LangVar']['CrmLeftNavArray'][$_GET['item']]}</a></li>
    <li class="{$NavClass['add']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=add" target="_self">{$Fn_Admin->Config['LangVar']['AddEditTitle']}</a></li>
  </ul>
  <div class="both"></div>
</div>
Nav;

if($SubModel == 'list'){//�б�
	$Do = in_array($_GET['do'], array('Del','Follow','Import','AllImport')) ? $_GET['do'] : 'submodel_list';
	//�����ֶ�
	$SearField =array('page','keyword','level','order','sale_uid','project','project_id');
	foreach($SearField as $Val) {
		$SearArray[$Val] = $_GET[$Val] || in_array($_GET[$Val],array('0')) ? $_GET[$Val] : '';
	}
	//�����ֶ� End
	$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeSubModelUrl'].'&'.http_build_query($SearArray);
	
	$member = DB::fetch_first('SELECT * FROM '.DB::table($Fn_Crm->TableMember).' where uid = '.intval($_G['uid']));

	if($Do == 'submodel_list'){
		if(!submitcheck('Submit')) {
			$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
			
			if($member['project_group']){
				$project_group = array();
				foreach(explode(',',$member['project_group']) as $val) {
					$project_group[] = "'".$val."'";
				}
			}
		
			$Where = ' and c.recovery = 0'.($Fn_Admin->CheckUserGroup('crm_customer_my') ? ' and c.sale_uid = '.intval($_G['uid']) : '').($project_group ? ' and c.project in('.implode(',',$project_group).')' : '');
			$Order = $_GET['order'] ? 'c.'.addslashes(dhtmlspecialchars($_GET['order'])) : 'c.id';
			
			if($_GET['keyword']){
				$_GET['keyword'] = str_replace(array('%','_'),array('',''),$_GET['keyword']);
				$Where .= ' and (c.name like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or c.decision_mobile like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') )';
			}

			if($_GET['level']){
				$Where .= ' and c.level = '.intval($_GET['level']);
			}

			if($_GET['sale_uid']){
				$Where .= ' and c.sale_uid = '.intval($_GET['sale_uid']);
			}

			if($_GET['project']){
				$Where .= ' and c.project = \''.addslashes(strip_tags($_GET['project'])).'\'';
			}

			if($_GET['project_id']){
				$Where .= ' and c.project_id = '.intval($_GET['project_id']);
			}

			$Where = preg_replace('/and/','where',$Where,1);
			$Limit = 20;
			$Page = $_GET['page']?intval($_GET['page']):1;
			/* ��ѯ���� End */
		
			/* ģ����� */	
			
			showtagheader('div', 'row', true,'row');
			showtagheader('div', 'col-12', true,'col-12');
			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-body', true,'box-body');
			/* ���� */
			$level_option = '<option value="">'.$Fn_Admin->Config['LangVar']['SelectNull'].'</option>';
			foreach($Fn_Crm->Config['setting']['level'] as $key => $val) {
				$level_option .= '<option value="'.$key.'" '.($_GET['level'] == $key ? ' selected' : '' ).'>'.$val.'</option>';
			}

			if(!$Fn_Admin->CheckUserGroup('crm_customer_my')){
				$member_html = '<th>&#23458;&#25143;&#36127;&#36131;&#20154;</th><td><select name="sale_uid" class="form-control w120">';
				$member_option = $new_member_option = '<option value="">'.$Fn_Admin->Config['LangVar']['SelectNull'].'</option>';
				$member_option = $member_html.$member_option;
				foreach(DB::fetch_all('SELECT * FROM '.DB::table($Fn_Crm->TableMember).' order by id asc') as $Val) {
					$member_option .= '<option value="'.$Val['uid'].'" '.($_GET['sale_uid'] == $Val['uid'] ? ' selected' : '' ).'>'.$Val['name'].'</option>';
					$new_member_option .= '<option value="'.$Val['uid'].'">'.$Val['name'].'</option>';
				}
				$member_option .= '</select></td>';
			}

			$project_option = '<option value="">'.$Fn_Admin->Config['LangVar']['SelectNull'].'</option>';
			foreach($Fn_Crm->Config['setting']['project'] as $key => $val) {
				if(in_array($key,explode(',',$member['project_group'])) && $member['project_group']){
					$project_option .= '<option value="'.$key.'" '.($_GET['project'] == $key ? ' selected' : '' ).'>'.$val.'</option>';
				}else if(!$member['project_group']){
					$project_option .= '<option value="'.$key.'" '.($_GET['project'] == $key ? ' selected' : '' ).'>'.$val.'</option>';
				}
				
			}

			$OrderSelected = array($_GET['order']=>' selected');

			echo <<<SEARCH
			<form method="post" autocomplete="off" action="$SearUrl">
				<div class="FormSearchTo" style="margin-bottom:0;">
					<table cellspacing="4" cellpadding="4">
						<tr>
							<th>&#23458;&#25143;</th><td><input type="text" class="input form-control w200" name="keyword" value="{$_GET['keyword']}" placeholder="&#35831;&#36755;&#20837;&#23458;&#25143;&#21517;&#31216;&#47;&#30005;&#35805;">
							</td>
							<th>&#23458;&#25143;&#29366;&#24577;</th><td>
							<select name="level" class="form-control w120">
								{$level_option}
							</select>
							</td>
							{$member_option}
							<th>&#25152;&#23646;&#39033;&#30446;</th><td>
							<select name="project" class="form-control w120">
								{$project_option}
							</select>
							</td>
							<th>&#39033;&#30446;&#20844;&#21496;&#73;&#68;</th><td><input type="text" class="input form-control w150" name="project_id" value="{$_GET['project_id']}" placeholder="&#35831;&#36755;&#20837;&#39033;&#30446;&#20844;&#21496;&#73;&#68;">
							</td>
							<th>{$Fn_Admin->Config['LangVar']['Order']}</th><td>
							<select name="order" class="form-control w120">
								<option value="dateline"{$OrderSelected['dateline']}>{$Fn_Admin->Config['LangVar']['OrderArray']['dateline']}</option>
								<option value="last_follow_dateline"{$OrderSelected['last_follow_dateline']}>&#36319;&#36827;&#26102;&#38388;</option>
								<option value="expire_dateline"{$OrderSelected['expire_dateline']}>&#21512;&#20316;&#21040;&#26399;&#26102;&#38388;</option>
							</select>
							&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Admin->Config['LangVar']['SearchSubmit']}" class="btn btn-info" type="submit">
							</td>
						</tr>
					</table>
				</div>
			</form>
SEARCH;
			/* ���� End */

			showtagheader('div', 'table-responsive', true,'table-responsive');
			showformheader($FormUrl,'enctype="multipart/form-data"');
			showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');

			showsubtitle(array(
				'ID',
				'&#23458;&#25143;&#36127;&#36131;&#20154;',
				'&#26368;&#21518;&#36319;&#36827;&#26102;&#38388;',
				'&#26368;&#21518;&#36319;&#36827;&#35760;&#24405;',
				'&#23458;&#25143;&#21517;&#31216;',
				'&#36127;&#36131;&#20154;&#22995;&#21517;',
				'&#23458;&#25143;&#32852;&#31995;&#30005;&#35805;',
				'&#23458;&#25143;&#29366;&#24577;',
				'&#23458;&#25143;&#22791;&#27880;',
				'&#25152;&#23646;&#39033;&#30446;',
				'&#21512;&#20316;&#21040;&#26399;&#26102;&#38388;',
				'&#21019;&#24314;&#26102;&#38388;',
				'&#25805;&#20316;'
			),'header tbm tc');

			$ModulesList = GetModulesList($Page,$Limit,$Where,$Order);
			
			foreach ($ModulesList as $Module) {
				$CustomerFollow = !$Module['last_follow_dateline'] ? DB::fetch_first('SELECT dateline FROM '.DB::table($Fn_Crm->TableCustomerFollow).' where customer_id = '.intval($Module['id']).' order by id desc') : '';
				$CustomerFollowHtml = '<div class="media-list media-list-hover media-list-divided">';
				$CustomerFollowContent = '';
				foreach(DB::fetch_all('SELECT f.*,m.name as sale_name FROM '.DB::table($Fn_Crm->TableCustomerFollow).' f LEFT JOIN `'.DB::table($Fn_Crm->TableMember).'` m on m.uid = f.sale_uid where f.customer_id = '.intval($Module['id']).' order by f.id desc limit 0,5') as $k => $v) {
					if(!$k){
						$CustomerFollowContent = $v['content'];
					}
					$CustomerFollowHtml .= '<div class="media media-single" style="padding:10px 0;"><span class="title">'.$v['content'].'</span><time>'.date('Y-m-d H:i',$v['dateline']).'</time><span>&#36319;&#36827;&#20154;&#65306;'.$v['sale_name'].'</span></div>';
				}
				$CustomerFollowHtml .= '</div>';
				showtablerow('', array('class="tc w80"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
					'<input type="checkbox" class="filled-in" id="checkbox_'.$Module['id'].'" name="delete[]" value="'.$Module['id'].'"><label for="checkbox_'.$Module['id'].'">'.$Module['id'].'</label>',
					$Module['sale_name'] ? $Module['sale_name'] : '&#26242;&#26080;&#36127;&#36131;&#20154;',
					$Module['last_follow_dateline'] ? date('Y-m-d H:i',$Module['last_follow_dateline']) : ($CustomerFollow['dateline'] ? date('Y-m-d H:i',$Module['dateline']) : '&#26242;&#26080;&#36319;&#36827;&#35760;&#24405;'),
					$CustomerFollowContent ? '<div data-container="body" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-html="true" data-content=\''.$CustomerFollowHtml.'\' data-original-title="" title="">'.cutstr($CustomerFollowContent,60).'</div>' : '&#26242;&#26080;&#36319;&#36827;&#35760;&#24405;',
					$Module['name'],
					$Module['decision_name'],
					$Module['decision_mobile'],
					$Fn_Crm->Config['setting']['level'][$Module['level']],
					'<div data-container="body" data-toggle="popover" data-trigger="hover" data-placement="top" data-html="true" data-content="'.$Module['remarks'].'">'.cutstr($Module['remarks'],30).'</div>',
					$Fn_Crm->Config['setting']['project'][$Module['project']].($Module['project_id'] ? '--&#20851;&#32852;&#73;&#68;&#65306;'.$Module['project_id'] : ''),
					$Module['expire_dateline'] > time() ? date('Y-m-d H:i',$Module['expire_dateline']) : '&#26242;&#26080;&#21512;&#20316;',
					date('Y-m-d H:i',$Module['dateline']),
					'<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&vid='.$Module['id'].'" class="btn btn-sm btn-info-outline">&#32534;&#36753;</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Follow&vid='.$Module['id'].'&formhash='.FORMHASH.'" class="btn btn-sm btn-danger-outline">&#20889;&#36319;&#36827;</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Del&vid='.$Module['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\'\u60a8\u786e\u5b9a\u8981\u653e\u8fdb\u56de\u6536\u7ad9\u5417\uff1f\')==false)return false;" class="btn btn-sm btn-danger-outline" style="display:none;">&#25918;&#36827;&#22238;&#25910;&#31449;</a><a href="'.$Fn_Admin->Config['ModUrl'].'&item=customer_follow_list&submodel=list&iframe=true&customer_id='.$Module['id'].'" class="btn btn-sm btn-purple-outline">&#36319;&#36827;&#35760;&#24405;</a>',
				));
			}

			showsubmit('Submit','&#31435;&#21363;&#25552;&#20132;','<input name="optype" value="Common" class="with-gap" type="radio" id="v_Common"><label class="custom-control-label" for="v_Common" style="margin-left:-5px;">&#36864;&#22238;&#20844;&#28023;</label>&nbsp;&nbsp;&nbsp;&nbsp;<input name="optype" value="Del" class="with-gap" type="radio" id="v_del"><label class="custom-control-label" for="v_del" style="margin-left:-5px;">&#25918;&#36827;&#22238;&#25910;&#31449;</label>'.(!$Fn_Admin->CheckUserGroup('crm_customer_my') ? '&nbsp;&nbsp;&nbsp;&nbsp;<input name="optype" value="Sale" class="with-gap" type="radio" id="v_Sale"><label class="custom-control-label" for="v_Sale" style="margin-left:-5px;">&#20998;&#37197;&#36127;&#36131;&#20154;</label>&nbsp;<select name="new_sale_uid" class="form-control w120">'.$new_member_option.'</select>' : ''),'<a href="'.$OpCpUrl.'&do=AllImport">&#25209;&#37327;&#23548;&#20837;&#23458;&#25143;</a>&nbsp;&nbsp;&nbsp;&nbsp'.(file_exists(DISCUZ_ROOT.'./source/plugin/fn_job') ? '<a href="'.$OpCpUrl.'&do=Import&action=fn_job&formhash='.FORMHASH.'">&#19968;&#38190;&#23548;&#20837;&#25307;&#32856;</a>&nbsp;&nbsp;&nbsp;&nbsp;' : '').(file_exists(DISCUZ_ROOT.'./source/plugin/fn_renovation') ? '<a href="'.$OpCpUrl.'&do=Import&action=fn_renovation&formhash='.FORMHASH.'">&#19968;&#38190;&#23548;&#20837;&#35013;&#20462;</a>&nbsp;&nbsp;&nbsp;&nbsp;' : '').(file_exists(DISCUZ_ROOT.'./source/plugin/fn_renovation') ? '<a href="'.$OpCpUrl.'&do=Import&action=fn_renovation_material&formhash='.FORMHASH.'">&#19968;&#38190;&#23548;&#20837;&#24314;&#26448;</a>&nbsp;&nbsp;&nbsp;&nbsp;' : '').(file_exists(DISCUZ_ROOT.'./source/plugin/fn_xiangqin') ? '<a href="'.$OpCpUrl.'&do=Import&action=fn_xiangqin&formhash='.FORMHASH.'">&#19968;&#38190;&#23548;&#20837;&#30456;&#20146;</a>&nbsp;&nbsp;&nbsp;&nbsp;' : ''),'select_all',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));

			showtablefooter(); /*dism��taobao��com*/
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');

			echo '<style>.popover{max-width:500px;width:500px;}</style>';
			/* ģ�����End */	
		}else{
			if(isset($_GET['delete']) && is_array($_GET['delete'])){
				if($_GET['optype'] == 'Del'){//ȫɾ
					if(!$Fn_Admin->CheckUserGroup('crm_all') && !$Fn_Admin->CheckUserGroup('crm_customer_recovery')){//Ȩ���ж�
						fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
						exit();
					}
					foreach($_GET['delete'] as $Key => $Val) {
						$Val = intval($Val);
						DB::update($Fn_Crm->TableCustomer,array('sale_uid'=>'','last_follow_dateline'=>'','level'=>3,'recovery'=>1,'void_dateline'=>time()),'id = '.$Val);
					}
					GetInsertDoLog('recovery_customer_crm','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete'])));//������¼
					fn_cpmsg('&#25918;&#36827;&#22238;&#25910;&#31449;&#25104;&#21151;',$CpMsgUrl,'succeed');

				}else if($_GET['optype'] == 'Common'){//�˻ع���
					if(!$Fn_Admin->CheckUserGroup('crm_all') && !$Fn_Admin->CheckUserGroup('crm_customer_common')){//Ȩ���ж�
						fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
						exit();
					}
					foreach($_GET['delete'] as $Key => $Val) {
						$Val = intval($Val);
						DB::update($Fn_Crm->TableCustomer,array('sale_uid'=>'','last_follow_dateline'=>'','level'=>3,'drop_dateline'=>time()),'id = '.$Val);
					}
					GetInsertDoLog('common_customer_crm','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete'])));//������¼
					fn_cpmsg('&#36864;&#22238;&#20844;&#28023;&#25104;&#21151;',$CpMsgUrl,'succeed');
				}else if($_GET['optype'] == 'Sale' && $_GET['new_sale_uid']){//���为����
					if(!$Fn_Admin->CheckUserGroup('crm_all') && !$Fn_Admin->CheckUserGroup('crm_customer_sale')){//Ȩ���ж�
						fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
						exit();
					}
					foreach($_GET['delete'] as $Key => $Val) {
						$Val = intval($Val);
						$customer = DB::fetch_first('SELECT * FROM '.DB::table($Fn_Crm->TableCustomer).' where id = '.$Val);
						DB::update($Fn_Crm->TableCustomer,array('sale_uid'=>intval($_GET['new_sale_uid']),'level'=>$customer['level'] == 1 ? $customer['level'] : 2,'receive_dateline'=>time()),'id = '.$Val);
					}
					GetInsertDoLog('sale_customer_crm','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete'])));//������¼
					fn_cpmsg('&#20998;&#37197;&#25104;&#21151;',$CpMsgUrl,'succeed');
				}else{
					fn_cpmsg($Fn_Admin->Config['LangVar']['OpErr'],'','error');
				}	
			}else{
				fn_cpmsg($Fn_Admin->Config['LangVar']['OpErr'],'','error');
			}	
		}
	}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['vid']){
		if(!$Fn_Admin->CheckUserGroup('crm_all') && !$Fn_Admin->CheckUserGroup('crm_customer_recovery')){//Ȩ���ж�
			fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
			exit();
		}
		$id = intval($_GET['vid']);
		DB::update($Fn_Crm->TableCustomer,array('recovery'=>1,'void_dateline'=>time()),'id = '.$id);
		GetInsertDoLog('recovery_customer_crm','fn_'.$_GET['mod'],array('id'=>$id));//������¼
		fn_cpmsg('&#25918;&#36827;&#22238;&#25910;&#31449;&#25104;&#21151;',$CpMsgUrl,'succeed');

	}else if($Do == 'Import' && $_GET['formhash'] == formhash() && $_GET['action']){
		$i = 0;
		$sql = "insert INTO ".DB::table($Fn_Crm->TableCustomer)." (name,address, project, project_id, decision_mobile,expire_dateline, dateline) VALUES";
		if($_GET['action'] == 'fn_job'){
			@require_once (DISCUZ_ROOT .'./source/plugin/fn_job/Function.inc.php');
			foreach(DB::fetch_all('SELECT * FROM '.DB::table('fn_job_company').' order by id asc') as $Val) {
				if(!DB::fetch_first('SELECT * FROM '.DB::table($Fn_Crm->TableCustomer).' where project = \''.addslashes(strip_tags($_GET['action'])).'\' and  project_id = '.$Val['id'])){
					$address = $Fn_Job->Area[$Val['province']]['content'].$Fn_Job->Area[$Val['city']]['content'].$Fn_Job->Area[$Val['dist']]['content'].$Val['community'];
					$sql .= "('".$Val['name']."','".$address."','".addslashes(strip_tags($_GET['action']))."','".$Val['id']."','".$Val['mobile']."','".($Val['due_time'] > time() ? $Val['due_time'] : '')."','".$Val['dateline']."'),";
					$i++;
				}
			}
		}else if($_GET['action'] == 'fn_renovation'){
			@require_once (DISCUZ_ROOT .'./source/plugin/fn_renovation/Function.inc.php');
			foreach(DB::fetch_all('SELECT * FROM '.DB::table('fn_renovation_company').' order by id asc') as $Val) {
				if(!DB::fetch_first('SELECT * FROM '.DB::table($Fn_Crm->TableCustomer).' where project = \''.addslashes(strip_tags($_GET['action'])).'\' and  project_id = '.$Val['id'])){
					$address = $Fn_Renovation->Area[$Val['province']]['content'].$Fn_Renovation->Area[$Val['city']]['content'].$Fn_Renovation->Area[$Val['dist']]['content'].$Val['community'];
					$sql .= "('".$Val['name']."','".$address."','".addslashes(strip_tags($_GET['action']))."','".$Val['id']."','".$Val['mobile']."','".($Val['due_time'] > time() ? $Val['due_time'] : '')."','".$Val['dateline']."'),";
					$i++;
				}
			}
		}else if($_GET['action'] == 'fn_renovation_material'){
			@require_once (DISCUZ_ROOT .'./source/plugin/fn_renovation/Function.inc.php');
			foreach(DB::fetch_all('SELECT * FROM '.DB::table('fn_renovation_material_company').' order by id asc') as $Val) {
				if(!DB::fetch_first('SELECT * FROM '.DB::table($Fn_Crm->TableCustomer).' where project = \''.addslashes(strip_tags($_GET['action'])).'\' and  project_id = '.$Val['id'])){
					$address = $Fn_Renovation->Area[$Val['province']]['content'].$Fn_Renovation->Area[$Val['city']]['content'].$Fn_Renovation->Area[$Val['dist']]['content'].$Val['community'];
					$sql .= "('".$Val['name']."','".$address."','".addslashes(strip_tags($_GET['action']))."','".$Val['id']."','".$Val['mobile']."','".($Val['due_time'] > time() ? $Val['due_time'] : '')."','".$Val['dateline']."'),";
					$i++;
				}
			}
		}else if($_GET['action'] == 'fn_xiangqin'){
			@require_once (DISCUZ_ROOT .'./source/plugin/fn_assembly/app.inc.php');
			@require_once (DISCUZ_ROOT.'./source/plugin/fn_xiangqin/config.php');
			$res = C::t('#fn_xiangqin#fn_love_user')->fetch_all_by_list(array(),'updateline',0,3000);
			foreach($res['list'] as $item) {
				if(!DB::fetch_first('SELECT * FROM '.DB::table($Fn_Crm->TableCustomer).' where project = \''.addslashes(strip_tags($_GET['action'])).'\' and  project_id = '.$item['id'])){
					$item = $fn_xiangqin->getFormUser($item);
					$name = $item['name'].'-'.$item['age'].'-'.$item['sex_text'];
					$sql .= "('".$name."','".$address."','".addslashes(strip_tags($_GET['action']))."','".$item['id']."','".$item['phone']."','".($item['vip_time'] > time() ? $vip_time['vip_time'] : '')."','".$item['dateline']."'),";
					$i++;
				}
			}
		}
		$sql = substr($sql,0,strlen($sql)-1);

		if($i){
			DB::query($sql);
			fn_cpmsg(str_replace(array('{count}'),array($i),'&#24685;&#21916;&#24744;&#65292;&#25104;&#21151;&#23548;&#20837;{count}&#20010;&#23458;&#25143;'),$CpMsgUrl,'succeed');
		}else{
			fn_cpmsg('&#27809;&#26377;&#21487;&#23548;&#20837;&#30340;&#23458;&#25143;','','error');
		}
		exit();
	}else if($Do == 'AllImport'){//��������

		if(!submitcheck('DetailSubmit')) {
			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-header', true,'with-border box-header');
			showtitle('&#25209;&#37327;&#23548;&#20837;&#23458;&#25143;','class="box-title"');
			showtagfooter('div');
			showformheader($Fn_Admin->Config['IframeSubModelUrl'].'&do=AllImport','enctype');
			showtagheader('div', 'box-body', true,'box-body');
			
			showsetting('&#36873;&#25321;&#23548;&#20837;&#25991;&#20214;', 'new_file','', 'filetext', '', 0, '&#27880;&#24847;&#65306;&#25991;&#20214;&#22823;&#21487;&#33021;&#20250;&#21345;&#65292;&#35831;&#26681;&#25454;&#33258;&#36523;&#26381;&#21153;&#22120;&#20248;&#21270;&#23548;&#20837;&#30340;&#25991;&#20214;<br>&#21482;&#25903;&#25345;&#120;&#108;&#115;&#120;&#47;&#120;&#108;&#115;&#25991;&#20214;<br>&#25991;&#20214;&#26684;&#24335;&#65306;&#65;&#20026;&#23458;&#25143;&#21517;&#31216;&#65292;&#66;&#20026;&#23458;&#25143;&#30005;&#35805;&#65292;&#67;&#20026;&#23458;&#25143;&#22320;&#22336;');
			showsetting('&#23458;&#25143;&#25152;&#23646;&#39033;&#30446;',array('project',DyadicArray($Fn_Crm->Config['setting']['project'],$Fn_Admin->Config['LangVar']['SelectNull'])),$Item ? $Item['project'] : 1,'select');
			showsetting('&#26816;&#27979;&#23458;&#25143;&#21517;&#31216;', 'ckche_name',0,'radio','','','&#26159;&#21542;&#26816;&#27979;&#23458;&#25143;&#21517;&#31216;&#37325;&#22797;&#65292;&#36873;&#25321;&#26159;&#65292;&#37325;&#22797;&#30340;&#21517;&#31216;&#21017;&#19981;&#20837;&#23458;&#25143;&#20844;&#20849;&#27744;');
			showsetting('&#26816;&#27979;&#23458;&#25143;&#30005;&#35805;', 'ckche_mobile',0,'radio','','','&#26159;&#21542;&#26816;&#27979;&#23458;&#25143;&#30005;&#35805;&#37325;&#22797;&#65292;&#36873;&#25321;&#26159;&#65292;&#37325;&#22797;&#30340;&#30005;&#35805;&#21017;&#19981;&#20837;&#23458;&#25143;&#20844;&#20849;&#27744;');
			
			showsubmit('DetailSubmit','&#20445;&#23384;&#37197;&#32622;');
			showtagfooter('div');
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');
		}else{

			$extend = GetFileext($_FILES['new_file']['name']);
			if(in_array($extend,array('xlsx','xls'))){
				spl_autoload_unregister(array('core', 'autoload')); 
				require_once DISCUZ_ROOT.'source/plugin/fn_assembly/lib/excel/PHPExcel.php';
				require_once DISCUZ_ROOT.'source/plugin/fn_assembly/lib/excel/PHPExcel/IOFactory.php';
				require_once DISCUZ_ROOT.'source/plugin/fn_assembly/lib/excel/PHPExcel/Reader/Excel5.php';
				require_once DISCUZ_ROOT.'source/plugin/fn_assembly/lib/excel/PHPExcel/Reader/Excel2007.php';
				spl_autoload_register(array('core', 'autoload'));
				//�ϴ��ļ�
				require_once (DISCUZ_ROOT.'./source/class/discuz/discuz_upload.php');
				$upload = new discuz_upload();
				$upload->init($_FILES['new_file'], 'forum');
				$upload->save(1);
				$target = array_shift(explode('.attach',$upload->attach['target'])).'.'.$extend;
				rename($upload->attach['target'],$target);
				//�ϴ��ļ�End
				if(strpos($extend,'xlsx') !== false){
					$objReader = PHPExcel_IOFactory::createReader('excel2007'); //use excel2007 for 2007 format 
				}else{
					$objReader = PHPExcel_IOFactory::createReader('Excel5');//use excel2007 for 2007 format 
				}
				$objPHPExcel = $objReader->load($target); 
				$sheet = $objPHPExcel->getSheet(0); 
				$objWorksheet = $objPHPExcel->getActiveSheet();
				$highestRow = $objWorksheet->getHighestRow();
				$highestColumn = $objWorksheet->getHighestColumn();
				$highestColumnIndex = PHPExcel_Cell::columnIndexFromString($highestColumn);//������
				$headtitle = array();
				$i = 0;
				$sql = "insert INTO ".DB::table($Fn_Crm->TableCustomer)." (name,address,project,decision_mobile,dateline) VALUES";
				for($row = 1;$row <= $highestRow;$row++){//�ӵڶ��п�ʼ��ȡ���ݣ�һ���һ����Ϊ����
					$strs = array();
					for($col = 0;$col < $highestColumnIndex;$col++){
						$strs[$col] =$objWorksheet->getCellByColumnAndRow($col, $row)->getValue(); 
					}
					$name = diconv(addslashes(strip_tags($strs['0'])), 'utf-8', CHARSET);
					$mobile = diconv(addslashes(strip_tags($strs['1'])), 'utf-8', CHARSET);
					$address = diconv(addslashes(strip_tags($strs['2'])), 'utf-8', CHARSET);
					if(($_GET['ckche_mobile'] && !DB::fetch_first('SELECT * FROM '.DB::table($Fn_Crm->TableCustomer).' where decision_mobile = \''.$mobile.'\'')) || (!$_GET['ckche_mobile'] && !$_GET['ckche_name']) || ($_GET['ckche_name'] && !DB::fetch_first('SELECT * FROM '.DB::table($Fn_Crm->TableCustomer).' where name = \''.$name.'\''))){
						$sql .= "('".$name."','".$address."','".($_GET['project'] ? addslashes(strip_tags($_GET['project'])) : '')."','".$mobile."','".time()."'),";
						$i++;
					}
				}
				$sql = substr($sql,0,strlen($sql)-1);
				@unlink($target);
				if($i){
					DB::query($sql);
					fn_cpmsg(str_replace(array('{count}'),array($i),'&#24685;&#21916;&#24744;&#65292;&#25104;&#21151;&#23548;&#20837;{count}&#20010;&#23458;&#25143;'),$CpMsgUrl,'succeed');
				}else{
					fn_cpmsg('&#27809;&#26377;&#21487;&#23548;&#20837;&#30340;&#23458;&#25143;','','error');
				}
			}else{
				fn_cpmsg('&#25991;&#20214;&#26684;&#24335;&#19981;&#26159;&#120;&#108;&#115;&#120;&#47;&#120;&#108;&#115;','','error');
			}
			exit();
		}
		
	}else if($Do == 'Follow'){
		$id = intval($_GET['vid']);
		$customer = DB::fetch_first('SELECT * FROM '.DB::table($Fn_Crm->TableCustomer).' where id = '.$id);
		if(!submitcheck('DetailSubmit')) {
			$OpTitle = '&#28155;&#21152;&#36319;&#36827;';
		
			//ͼƬ�ϴ�
			if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_assembly/class/class_upload.php')){
				@require_once libfile('class/upload','plugin/fn_assembly');
				$UploadConfig = fn_upload::Config();
			}
			
			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-header', true,'with-border box-header');
			showtitle($OpTitle,'class="box-title"');
			showtagfooter('div');
			showformheader($Fn_Admin->Config['IframeSubModelUrl'].'&vid='.$id.'&do=Follow','enctype');
			showtagheader('div', 'box-body', true,'box-body');
			
			echo '<div class="form-group row"><label class="col-sm-1 col-form-label">&#36319;&#36827;&#22270;&#29255;:</label><div class="col-sm-9"><div class="AdminSingleUpload"><div class="PhotoControl" id="pic"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div></div><div class="both"></div></div></div>';
			showsetting('&#23458;&#25143;&#21517;&#31216;', 'customer_name', $customer['name'], 'text',true);
			showsetting('&#36319;&#36827;&#20869;&#23481;', 'content', '', 'textarea');
			showsetting('&#36319;&#36827;&#26102;&#38388;', 'follow_dateline',date('Y-m-d H:i',time()), 'calendar','','','',1);
	
			showsubmit('DetailSubmit','&#20445;&#23384;&#37197;&#32622;');
			showtagfooter('div');
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');

			$UpLoadHtml = '$("#pic").AppUpload({InputName:"new_pic"});';
			echo $UploadConfig['CssJsHtml'].'<script>'.$UpLoadHtml.'</script>';
		
		}else{
			foreach($_GET['new_pic'] as $Key => $Val) {
				$_GET['new_pic'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
			}
			
			$Data['sale_uid'] = intval($_G['uid']);
			$Data['customer_id'] = intval($_GET['vid']);
			$Data['pic'] = is_array($_GET['new_pic']) && isset($_GET['new_pic'])  ? implode(',',array_filter($_GET['new_pic'])) : '';
			$Data['content'] = addslashes(strip_tags($_GET['content']));
			$Data['follow_dateline'] = $_GET['follow_dateline'] ? strtotime($_GET['follow_dateline']) : time();
			$Data['dateline'] = time();
			
			DB::update($Fn_Crm->TableCustomer,array('last_follow_dateline'=>time()),'id = '.$id);
			$fid = DB::insert($Fn_Crm->TableCustomerFollow,$Data,true);
			GetInsertDoLog('add_customer_follow_crm','fn_'.$_GET['mod'],array('id'=>$fid));//������¼
			fn_cpmsg('&#28155;&#21152;&#36319;&#36827;&#35760;&#24405;&#25104;&#21151;',$CpMsgUrl,'succeed');
		}
	
	}
}else if($SubModel == 'add'){//���ӻ�༭

	$id = intval($_GET['vid']);
	
	$Item = DB::fetch_first('SELECT * FROM '.DB::table($Fn_Crm->TableCustomer).' where id = '.$id);

	if(!submitcheck('DetailSubmit')) {
		$OpTitle = $Fn_Admin->Config['LangVar']['AddTitle'];
		if($Item){
			$OpTitle = $Fn_Admin->Config['LangVar']['EditTitle'];
		}

		//ͼƬ�ϴ�
		if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_assembly/class/class_upload.php')){
			@require_once libfile('class/upload','plugin/fn_assembly');
			$UploadConfig = fn_upload::Config();
		}
		
		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-header', true,'with-border box-header');
		showtitle($OpTitle,'class="box-title"');
		showtagfooter('div');
		showformheader($Fn_Admin->Config['IframeSubModelUrl'].'&vid='.$id,'enctype');
		showtagheader('div', 'box-body', true,'box-body');

		if(!$Item){
			$member[] = array('',$Fn_Admin->Config['LangVar']['SelectNull']);
			foreach(DB::fetch_all('SELECT * FROM '.DB::table($Fn_Crm->TableMember).' order by id asc') as $Val) {
				$member[] = array($Val['uid'], $Val['name']);
			}
			showsetting('&#23458;&#25143;&#36127;&#36131;&#20154;', array('sale_uid',$member),$_G['uid'],'select');
		}

		showsetting('&#23458;&#25143;&#21517;&#31216;', 'name', $Item['name'], 'text');
		showsetting('&#23458;&#25143;&#22320;&#22336;', 'address', $Item['address'], 'text');
		showsetting('&#23458;&#25143;&#22791;&#27880;', 'remarks', $Item['remarks'], 'textarea');
		showsetting('&#36127;&#36131;&#20154;&#22995;&#21517;', 'decision_name', $Item['decision_name'], 'text');
		showsetting('&#36127;&#36131;&#20154;&#30005;&#35805;', 'decision_mobile', $Item['decision_mobile'], 'text');
		
		showsetting('&#25152;&#23646;&#39033;&#30446;',array('project',DyadicArray($Fn_Crm->Config['setting']['project'],$Fn_Admin->Config['LangVar']['SelectNull'])),$Item ? $Item['project'] : 1,'select');
		
		showsetting('&#39033;&#30446;&#20844;&#21496;&#20851;&#32852;&#73;&#68;', 'project_id', $Item['project_id'], 'text','','','&#36873;&#25321;&#20102;&#39033;&#30446;&#19988;&#35813;&#39033;&#30446;&#26377;&#35813;&#20844;&#21496;&#25165;&#22635;&#20889;&#35813;&#39033;');

		showsetting('&#21512;&#20316;&#21040;&#26399;&#26102;&#38388;', 'expire_dateline',$Item['expire_dateline'] ? date('Y-m-d H:i',$Item['expire_dateline']) : '', 'calendar','','','&#21512;&#20316;&#26102;&#38388;&#21040;&#26399;&#21518;&#65292;&#33258;&#21160;&#25481;&#33853;&#20026;&#66;&#32423;&#40;&#36319;&#36827;&#23458;&#25143;&#41;',1);

		if($Item['dateline']){
			showsetting('&#21019;&#24314;&#26102;&#38388;', 'dateline',date('Y-m-d H:i',$Item['dateline']), 'calendar','','','',1);
		}

		showsubmit('DetailSubmit','&#20445;&#23384;&#37197;&#32622;');
		showtagfooter('div');
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');


	}else{
		if(!$Item){
			$Data['sale_uid'] = intval($_GET['sale_uid']);
		}
		$Data['name'] = addslashes(strip_tags($_GET['name']));
		$Data['address'] = addslashes(strip_tags($_GET['address']));
		$Data['remarks'] = addslashes(strip_tags($_GET['remarks']));
		$Data['decision_name'] = addslashes(strip_tags($_GET['decision_name']));
		$Data['decision_mobile'] = addslashes(strip_tags($_GET['decision_mobile']));
		$Data['project'] = addslashes(strip_tags($_GET['project']));
		$Data['project_id'] = intval($_GET['project_id']);
		$Data['expire_dateline'] = $_GET['expire_dateline'] ? strtotime($_GET['expire_dateline']) : '';
		if($Data['expire_dateline'] > time()){
			$Data['level'] = 1;
		}else if($Item['sale_uid'] && $Data['expire_dateline'] < time()){
			$Data['level'] = 2;
		}else if(!$Item){
			$Data['level'] =  $Data['sale_uid'] ? 2 : 3;
			$Data['receive_dateline'] =  time();
		}
		if($Item){

			$Data['dateline'] = strtotime($_GET['dateline']);

			GetInsertDoLog('edit_customer_crm','fn_'.$_GET['mod'],array('id'=>$id));//������¼
			DB::update($Fn_Crm->TableCustomer,$Data,'id = '.$id);
		}else{
			$Data['dateline'] = time();
			$id = DB::insert($Fn_Crm->TableCustomer,$Data,true);
			GetInsertDoLog('add_customer_crm','fn_'.$_GET['mod'],array('id'=>$id));//������¼
		}
		fn_cpmsg($Fn_Admin->Config['LangVar']['UpdateOk'],$Fn_Admin->Config['IframeItemUrl'].'&submodel=list','succeed');
		
	}
}


/* �б� */
function GetModulesList($Page,$Limit,$Where=null,$Order){
	global $Fn_Crm;
	$FetchSql = 'SELECT c.*,m.name as sale_name FROM '.DB::table($Fn_Crm->TableCustomer).' c LEFT JOIN `'.DB::table($Fn_Crm->TableMember).'` m on m.uid = c.sale_uid '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}

/* ���� */
function GetModulesCount($Where=null){
	global $Fn_Crm;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_Crm->TableCustomer).' c '.$Where;
	return DB::result_first($FetchSql);//��������
}

?>