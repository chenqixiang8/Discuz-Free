<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if($_GET['type'] == 'xiangqin' && $_GET['formhash'] == formhash() && $_GET['uids']){

	if(!$Fn_Admin->CheckUserGroup('xiang_all') && !$Fn_Admin->CheckUserGroup('xiangqin_user_export')){//Ȩ���ж�
		fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
		exit();
	}

	Header( "Content-type:application/octet-stream");
	Header( "Accept-Ranges:bytes");
	header( "Content-Disposition:attachment;filename=userlist.txt");
	header( "Expires:0");
	header( "Cache-Control:must-revalidate,post-check=0,pre-check=0");
	header( "Pragma:public");
	@require_once (DISCUZ_ROOT .'./source/plugin/fn_assembly/app.inc.php');
	@require_once DISCUZ_ROOT.'./source/plugin/fn_xiangqin/Function.inc.php';
	$Fn_XiangQin = new Fn_XiangQin;
	$Where = ' where M.uid in('.$_GET['uids'].')';
	$ModulesList = DB::fetch_all('SELECT M.*,M.param as mparam,C.* FROM '.DB::table($Fn_XiangQin->TableMember).' M LEFT JOIN '.DB::table($Fn_XiangQin->TableCondition).' C on C.uid = M.uid '.$Where);
	foreach($ModulesList as $Module){
		$Module['mparam'] = unserialize($Module['mparam']);
		echo $Fn_XiangQin->Config['LangVar']['CardTitle'].":".$Fn_XiangQin->Config['PluginVar']['MatchmakingCardNum'].$Module['uid']."\r\n";
		echo $Fn_XiangQin->Config['LangVar']['NameTitle'].":".$Module['name']."\r\n";
		echo $Fn_XiangQin->Config['LangVar']['SexTitle'].":".$Fn_XiangQin->Config['LangVar']['SexArray'][$Module['sex']]."\r\n";
		echo $Fn_XiangQin->Config['LangVar']['BirthTitle'].":".$Module['birth'] ?  date('Y-m-d',$Module['birth']) : ''."\r\n";
		echo $Fn_XiangQin->Config['LangVar']['HeightTitle'].":".$Fn_XiangQin->Config['LangVar']['UserInfoHeightArray'][$Module['height']]."\r\n";
		echo $Fn_XiangQin->Config['LangVar']['WeightTitle'].":".$Fn_XiangQin->Config['LangVar']['UserInfoWeightArray'][$Module['weight']]."\r\n";
		echo $Fn_XiangQin->Config['LangVar']['BloodTitle'].":".$Fn_XiangQin->Config['LangVar']['BloodArray'][$Module['blood']]."\r\n";
		echo $Fn_XiangQin->Config['LangVar']['EthnicTitle'].":".$Fn_XiangQin->Config['LangVar']['EthnicArray'][$Module['ethnic']]."\r\n";
		echo $Fn_XiangQin->Config['LangVar']['CompanyTitle'].":".$Module['company']."\r\n";
		echo $Fn_XiangQin->Config['LangVar']['OccupationTitle'].":".$Fn_XiangQin->Config['LangVar']['OccupationArray'][$Module['occupation']]."\r\n";
		echo $Fn_XiangQin->Config['LangVar']['EducationTitle'].":".$Fn_XiangQin->Config['LangVar']['EducationArray'][$Module['education']]."\r\n";
		echo $Fn_XiangQin->Config['LangVar']['MarriageTitle'].":".$Fn_XiangQin->Config['LangVar']['MarriageArray'][$Module['marriage']]."\r\n";
		echo $Fn_XiangQin->Config['LangVar']['ChildTitle'].":".$Fn_XiangQin->Config['LangVar']['ChildArray'][$Module['child']]."\r\n";
		echo $Fn_XiangQin->Config['LangVar']['MonthIncomeTitle'].":".$Fn_XiangQin->Config['LangVar']['MonthIncomeArray'][$Module['month_income']]."\r\n";
		echo $Fn_XiangQin->Config['LangVar']['HouseTitle'].":".$Fn_XiangQin->Config['LangVar']['HouseArray'][$Module['house']]."\r\n";
		echo $Fn_XiangQin->Config['LangVar']['VehicleTitle'].":".$Fn_XiangQin->Config['LangVar']['VehicleArray'][$Module['vehicle']]."\r\n";
		echo $Fn_XiangQin->Config['LangVar']['MobileTitle'].":".$Module['mobile']."\r\n";
		echo $Fn_XiangQin->Config['LangVar']['WxTitle'].":".$Module['mparam']['wx']."\r\n";
		echo $Fn_XiangQin->Config['LangVar']['MonologueTitle'].":".$Module['mparam']['monologue']."\r\n";
		echo $Fn_XiangQin->Config['LangVar']['RemarksTitle'].":".$Module['mparam']['remarks']."\r\n";
		
		echo "----".$Fn_XiangQin->Config['LangVar']['ConditionTitle']."----\r\n";//��ż����
		echo $Fn_XiangQin->Config['LangVar']['AgeTitle'].":".$Fn_XiangQin->Config['LangVar']['AgeArray'][$Module['c_min_age']]."-".$Fn_XiangQin->Config['LangVar']['AgeArray'][$Module['c_max_age']]."\r\n";
		$Fn_XiangQin->Config['LangVar']['HeightTitle'].":".$Fn_XiangQin->Config['LangVar']['HeightArray'][$Module['c_min_height']]."-".$Fn_XiangQin->Config['LangVar']['HeightArray'][$Module['c_max_height']]."\r\n";
		echo $Fn_XiangQin->Config['LangVar']['MonthIncomeTitle'].":".$Fn_XiangQin->Config['LangVar']['MonthIncomeArray'][$Module['c_month_income']]."\r\n";echo $Fn_XiangQin->Config['LangVar']['EducationTitle'].":".$Fn_XiangQin->Config['LangVar']['EducationArray'][$Module['c_education']]."\r\n";
		echo $Fn_XiangQin->Config['LangVar']['MarriageTitle'].":".$Fn_XiangQin->Config['LangVar']['MarriageArray'][$Module['c_marriage']]."\r\n";
		echo $Fn_XiangQin->Config['LangVar']['WhetherHouse'].":".$Fn_XiangQin->Config['LangVar']['WhetherHouseArray'][$Module['c_house']]."\r\n";
		echo $Fn_XiangQin->Config['LangVar']['WhetherVehicle'].":".$Fn_XiangQin->Config['LangVar']['WhetherVehicleArray'][$Module['c_vehicle']]."\r\n";
		echo $Fn_XiangQin->Config['LangVar']['ShapeTitle'].":".$Fn_XiangQin->Config['LangVar']['ShapeArray'][$Module['c_shape']]."\r\n";
		echo $Fn_XiangQin->Config['LangVar']['WantChildTitle'].":".$Fn_XiangQin->Config['LangVar']['WantChildArray'][$Module['c_want_child']]."\r\n";
		echo $Fn_XiangQin->Config['LangVar']['SmokeTitle'].":".$Fn_XiangQin->Config['LangVar']['SmokeArray'][$Module['c_smoke']]."\r\n";
		echo $Fn_XiangQin->Config['LangVar']['DrinkTitle'].":".$Fn_XiangQin->Config['LangVar']['SmokeArray'][$Module['c_drink']]."\r\n";
		echo "\r\n\r\n";
	}
	exit();
}else if($_GET['type'] == 'house' && $_GET['formhash'] == formhash() && $_GET['op'] == 'info'){//����������Դ
	if(!$Fn_Admin->CheckUserGroup('house_all') && !$Fn_Admin->CheckUserGroup('house_export')){//Ȩ���ж�
		fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
		exit();
	}
	@require_once (DISCUZ_ROOT .'./source/plugin/fn_assembly/app.inc.php');
	@require_once DISCUZ_ROOT.'./source/plugin/fn_house/Function.inc.php';
	$Where = ' where I.display = 1 and I.payment_state = 1 and class = '.intval($_GET['list_class']);
	$Filed = $Fn_House->Config['PluginVar']['WxTemplateSort'];
	if($_GET['time'] == '1'){
		$Where .= ' and (I.'.$Filed.' >= '.strtotime(date('Y-m-d')).' and I.'.$Filed.' <='.strtotime(date('Y-m-d 23:59:59')).' or I.topdateline > '.time().')';
	}elseif($_GET['time']){
		$Where .= ' and (I.'.$Filed.' >= '.strtotime("-".$_GET['time']." day",time()).' or I.topdateline > '.time().')';
	}
	$ModulesList = $Fn_House->InfoListFormat(DB::fetch_all('SELECT I.* FROM '.DB::table($Fn_House->TableInfo).' I '.$Where.' order by I.topdateline > '.time().' desc,I.updateline desc,I.dateline desc'));
	if($Fn_House->Config['PluginVar']['QrParameterSwitch']){
		@require_once libfile('class/wechat','plugin/fn_assembly');
		$WechatClient = new Fn_WeChatClient($Fn_House->Config['PluginVar']['WxAppid'], $Fn_House->Config['PluginVar']['WxSecret']);
	}
	foreach($ModulesList as $Module){
		$ConfigureList = array();
		foreach(array_filter(explode(",",$Module['configure'])) as $Val){
			$ConfigureList[] = $Fn_House->Config['LangVar']['ConfigureTagArray'][$Val];
		}

		if($Fn_House->Config['PluginVar']['QrParameterSwitch']){
			$File = $Config['QrcodePath'].'fn_house_view_'.$Module['id'].'.jpg';
			if(!file_exists($File) || !filesize($File) || (filesize($File) && file_exists($File) && filemtime($File) + 1296000 <= time())) {
				@unlink($File);
				$QrUrl = $WechatClient->getQrcodeImgUrlByTicket($WechatClient->getQrcodeTicket(array('scene_str'=>'fn_house____view____'.$Module['id'],'expire'=>2592000)));
				DownloadImg($QrUrl,$File);
			}
			$qrcode_url = $_G['siteurl'].str_replace(DISCUZ_ROOT,'',$File);
		}else{
			$qrcode_url = $_G['siteurl'].'plugin.php?id=fn_assembly:qrcode&url='.base64_encode($Fn_House->Config['ViewUrl'].$Module['id']);
		}

		echo str_replace(array('{title}','{vice_class}','{small_area}','{address}','{money}','{huxing}','{square}','{house_type}','{decoration_type}','{management_type}','{shops_type}','{tag}','{content}','{configure}','{name}','{mobile}','{wx}','{qr}','{link}'),array($Module['title'],$Module['vice_class_text'],$Module['small_area'],$Module['province_text'].'['.$Module['community'].']',$Module['price'].$Module['price_text'],$Module['huxing'],$Module['square'],$Module['house_type'],$Module['decoration_type'],$Module['management_type'],$Module['shops_type'],implode('|',$Module['param']['tag_list']),strip_tags($Module['content'] ? $Module['content'] : $Module['param']['content']),implode('|',$ConfigureList),$Module['name'],($Module['mobile'] ? $Module['mobile'] : $Module['param']['mobile']),$Module['param']['wx'],$qrcode_url,$Fn_House->Config['ViewUrl'].$Module['id']),$Fn_House->Config['PluginVar']['WxTemplate'.$_GET['list_class']]);
		
	}
	exit();

}else if($_GET['type'] == 'house' && $_GET['formhash'] == formhash() && $_GET['ids'] && $_GET['op'] == 'entrust'){//��������ί��
	if(!$Fn_Admin->CheckUserGroup('house_all') && !$Fn_Admin->CheckUserGroup('house_entrust_export')){//Ȩ���ж�
		fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
		exit();
	}

	Header( "Content-type:application/octet-stream");
	Header( "Accept-Ranges:bytes");
	header( "Content-Disposition:attachment;filename=entrust_list.txt");
	header( "Expires:0");
	header( "Cache-Control:must-revalidate,post-check=0,pre-check=0");
	header( "Pragma:public");
	@require_once (DISCUZ_ROOT .'./source/plugin/fn_assembly/app.inc.php');
	@require_once DISCUZ_ROOT.'./source/plugin/fn_house/Function.inc.php';
	$Where = ' where E.id in('.$_GET['ids'].')';
	$ModulesList = DB::fetch_all('SELECT E.* FROM '.DB::table($Fn_House->TableEntrust).' E '.$Where);
	foreach($ModulesList as $Module){
		$Module['param'] = unserialize($Module['param']);
		echo $Fn_House->Config['LangVar']['Type'].":".$Fn_House->Config['LangVar']['IndexNav'][$Module['class']]."\r\n";
		echo $Fn_House->Config['LangVar']['Community'].":".$Module['address']."\r\n";
		echo $Fn_House->Config['LangVar']['Square'].":".$Module['square']."\r\n";
		echo $Fn_House->Config['LangVar']['Offer'].":".$Module['price'].( $Module['class'] == 2 ? $Fn_House->Config['LangVar']['Yuan'].'/'.$Fn_House->Config['LangVar']['RentTimeArray'][$Module['param']['price_time']] : $Fn_House->Config['LangVar']['WanYuan'])."\r\n";
		echo $Fn_House->Config['LangVar']['Contacts'].":".$Module['name']."\r\n";
		echo $Fn_House->Config['LangVar']['Mobile'].":".$Module['mobile']."\r\n";
		echo $Fn_House->Config['LangVar']['WxTitle'].":".$Module['wx']."\r\n";
		echo "\r\n\r\n";
	}

	exit();
}else if($_GET['type'] == 'house' && $_GET['formhash'] == formhash() && $_GET['ids'] && $_GET['op'] == 'disc_customer'){
	if(!$Fn_Admin->CheckUserGroup('house_all') && !$Fn_Admin->CheckUserGroup('house_disc_customer_export')){//Ȩ���ж�
		fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
		exit();
	}
	Header( "Content-type:application/octet-stream");
	Header( "Accept-Ranges:bytes");
	header( "Content-Disposition:attachment;filename=customer_list.txt");
	header( "Expires:0");
	header( "Cache-Control:must-revalidate,post-check=0,pre-check=0");
	header( "Pragma:public");
	@require_once (DISCUZ_ROOT .'./source/plugin/fn_assembly/app.inc.php');
	@require_once DISCUZ_ROOT.'./source/plugin/fn_house/Function.inc.php';
	$Where = ' where M.id in('.$_GET['ids'].')';
	$ModulesList = DB::fetch_all('SELECT D.title,M.* FROM '.DB::table($Fn_House->TableDiscMobile).' M LEFT JOIN `'.DB::table($Fn_House->TableDisc).'` D on D.id = M.iid '.$Where);
	foreach($ModulesList as $Module){

		echo $Fn_House->Config['LangVar']['DiscTitle'].":".$Module['title']."\r\n";
		echo $Fn_House->Config['LangVar']['Type'].":".$Fn_House->Config['LangVar']['DiscMobileTypeArray'][$Module['type']]."\r\n";
		echo $Fn_House->Config['LangVar']['Contacts'].":".$Module['name']."\r\n";
		echo $Fn_House->Config['LangVar']['Mobile'].":".$Module['mobile']."\r\n";
		echo "\r\n\r\n";
	}

	exit();

}
//From: Dism��taobao��com
?>