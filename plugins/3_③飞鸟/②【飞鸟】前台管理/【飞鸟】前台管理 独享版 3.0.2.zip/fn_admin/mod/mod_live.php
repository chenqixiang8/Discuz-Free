<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!file_exists(DISCUZ_ROOT.'./source/plugin/fn_live')){
	showmessage($Fn_Admin->Config['LangVar']['NoLive'],'http://dism.taobao.com/?@fn_live.plugin', array(), array('locationtime'=>true,'refreshtime'=>3, 'showdialog'=>1, 'showmsg' => true));
	exit();
}else{
	@require_once (DISCUZ_ROOT .'./source/plugin/fn_assembly/app.inc.php');
	@require_once (DISCUZ_ROOT.'./source/plugin/fn_live/Function.inc.php');

	//��ർ��
	foreach($Fn_Admin->Config['AdminUserInfo']['param']['live_left_nav'] as $Key => $Val) {
		if(!$Key){$Default = $Val;}
		$LeftMenu[$Val] = $Fn_Admin->Config['LangVar']['LiveLeftNavArray'][$Val];
	}

	$_GET['item'] = $_GET['item'] ? $_GET['item'] : $Default;
}
//From: Dism��taobao��com
?>