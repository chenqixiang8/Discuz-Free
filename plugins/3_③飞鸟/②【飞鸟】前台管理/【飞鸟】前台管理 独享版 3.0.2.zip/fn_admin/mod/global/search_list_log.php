<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!file_exists(DISCUZ_ROOT.'./source/plugin/fn_fenlei')){
	showmessage('&#20320;&#36824;&#27809;&#26377;&#23433;&#35013;&#39134;&#40479;&#12304;&#21516;&#22478;&#20998;&#31867;&#12305;&#65292;&#27491;&#22312;&#36339;&#36716;&#39134;&#40479;&#12304;&#21516;&#22478;&#20998;&#31867;&#12305;','http://dism.taobao.com/?@fn_fenlei.plugin', array(), array('locationtime'=>true,'refreshtime'=>3, 'showdialog'=>1, 'showmsg' => true));
	exit();
}

if(!$Fn_Admin->CheckUserGroup('global_all') && !$Fn_Admin->CheckUserGroup('global_search_list_log')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

@require_once (DISCUZ_ROOT .'./source/plugin/fn_assembly/app.inc.php');
if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_login/config.php')){
	@require_once (DISCUZ_ROOT.'./source/plugin/fn_login/config.php');
}

$Do = in_array($_GET['do'], array('Del')) ? $_GET['do'] : 'List';

//�����ֶ�
$SearField =array('page','keyword','channel','search_id','source','uid','ip','order');
foreach($SearField as $Val) {
	$SearArray[$Val] = $_GET[$Val] ? $_GET[$Val] : '';
}
//�����ֶ� End

$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeItemUrl'].'&'.http_build_query($SearArray);

if($Do == 'List'){
	if(!submitcheck('Submit')) {
		$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
		$page = $_GET['page'] ? $_GET['page'] : 0;
		$res = C::t('#fn_fenlei#fn_search_log')->fetch_all_by_list(array('keyword'=>$_GET['keyword'],'channel'=>$_GET['channel'],'search_id'=>$_GET['search_id'],'source'=>$_GET['source'],'uid'=>$_GET['uid'],'ip'=>$_GET['ip']),$page - 1,30,'dateline','',true);
		/* ģ����� */
		showtagheader('div', 'row', true,'row');
		showtagheader('div', 'col-12', true,'col-12');
		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-body', true,'box-body');
		/* ���� */
		$OrderSelected = array($_GET['order']=>' selected');
		$search_channel_option = '<option value="">'.$Fn_Admin->Config['LangVar']['SelectNull'].'</option>';
		foreach($Fn_Admin->Config['LangVar']['search_channel_arr'] as $key => $val) {
			$search_channel_option .= '<option value="'. $key.'" '.($_GET['channel'] ==  $key ? ' selected' : '' ).'>'.$val.'</option>';
		}
		$search_source_option = '<option value="">'.$Fn_Admin->Config['LangVar']['SelectNull'].'</option>';
		foreach($Fn_Admin->Config['LangVar']['search_source_arr'] as $key => $val) {
			$search_source_option .= '<option value="'. $key.'" '.($_GET['source'] ==  $key ? ' selected' : '' ).'>'.$val.'</option>';
		}
		echo <<<SEARCH
		<form method="post" autocomplete="off" action="$SearUrl" id="tb_search">
			<div class="FormSearchTo">
				<table cellspacing="4" cellpadding="4">
					<tr>
						<th>&#20851;&#38190;&#35789;</th><td colspan="10"><input type="text" class="input form-control w100" name="keyword" value="{$_GET['keyword']}" placeholder="&#35831;&#36755;&#20837;&#25628;&#32034;&#35789;">
						</td>
						<th>&#29992;&#25143;&#73;&#68;</th><td colspan="10"><input type="text" class="input form-control w100" name="uid" value="{$_GET['uid']}" placeholder="&#35831;&#36755;&#20837;&#29992;&#25143;&#73;&#68;">
						</td>
						<th>&#73;&#80;</th><td colspan="10"><input type="text" class="input form-control w100" name="ip" value="{$_GET['ip']}" placeholder="&#35831;&#36755;&#20837;&#73;&#80;">
						</td>
						<th>&#28192;&#36947;</th><td>
						<select name="channel" class="form-control w120">
							{$search_channel_option}
						</select>
						</td>
						<th>&#26469;&#28304;</th><td>
						<select name="source" class="form-control w120">
							{$search_source_option}
						</select>
						</td>
						<th>&#25490;&#24207;</th><td>
						<select name="order" class="form-control w120">
							<option value="dateline"{$OrderSelected['dateline']}>{$Fn_Admin->Config['LangVar']['OrderArray']['dateline']}</option>
						</select>
						</td>
						<th><input name="SearchSubmit" value="{$Fn_Admin->Config['LangVar']['SearchSubmit']}" class="btn btn-info" type="submit"></th>
					</tr>
				</table>
			</div>
		</form>
SEARCH;
		/* ���� End */
		showtagheader('div', 'table-responsive', true,'table-responsive');
		showformheader($FormUrl,'enctype="multipart/form-data"');
		showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
		showsubtitle(array(
			'ID',
			'&#85;&#73;&#68;&#47;&#29992;&#25143;&#21517;',
			'&#25163;&#26426;&#21495;',
			'&#25628;&#32034;&#35789;',
			'&#28192;&#36947;',
			'&#26469;&#28304;',
			'&#73;&#80;',
			$Fn_Admin->Config['LangVar']['TimeTitle'],
			$Fn_Admin->Config['LangVar']['OperationTitle']
		), 'header tbm tc');
	
		foreach ($res['list'] as $item) {
			if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_login/config.php')){
				$member = C::t('#fn_login#fn_user')->fetch_by_uid($item['uid']);
			}
			if(!$member){
				if($Config['PluginVar']['AppType'] == 2){
					$member = DB::fetch_first('SELECT phone FROM '.DB::table('phonebind').' where uid = '.$item['uid']);
				}else if($Config['PluginVar']['AppType'] == 1 && file_exists(DISCUZ_ROOT.'./source/plugin/fn_login/config.php')){
					$member = DB::fetch_first("SELECT * FROM " .DB::table($fn_login->magConfig['user_mobile_relations'])." WHERE ".$fn_login->magConfig['user_mobile_relations_userid']."=%s", array($item['uid']));
				}else{
					$member = DB::fetch_first('SELECT mobile as phone FROM '.DB::table('common_member_profile').' where uid = '.$item['uid']);
				}
			}
			showtablerow('', array('class="tc w100"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
				'<input type="checkbox" class="filled-in" id="checkbox_'.$item['id'].'" name="delete[]" value="'.$item['id'].'"><label for="checkbox_'.$item['id'].'">'.$item['id'].'</label>',
				$item['uid'] ? $item['uid'].'/'.$item['username'] : '',
				$member['phone'],
				$item['keyword'],
				$Fn_Admin->Config['LangVar']['search_channel_arr'][$item['channel']],
				$Fn_Admin->Config['LangVar']['search_source_arr'][$item['source']],
				$item['ip'],
				date('Y-m-d H:i',$item['dateline']),
				'<a href="'.$OpCpUrl.'&do=Del&lid='.$item['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">&#21024;&#38500;</a>',
			));
		}
		showsubmit('Submit','&#31435;&#21363;&#25552;&#20132;','del','','',multi($res['count'],30,$page,$MpUrl));
		showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		/* ģ����� End */
	}else{
		if(isset($_GET['delete']) && is_array($_GET['delete'])){
			if(!$Fn_Admin->CheckUserGroup('global_all') && !$Fn_Admin->CheckUserGroup('global_search_list_log')){//Ȩ���ж�
				fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
				exit();
			}
			foreach($_GET['delete'] as $val) {
				$id = intval($val);
				$item = C::t('#fn_fenlei#fn_search_log')->fetch_by_id($id);
				C::t('#fn_fenlei#fn_search_log')->delete_by_id($id);
				C::t('#fn_fenlei#fn_search')->update_by_count($item['search_id'],'count',1,'-');
			}
			GetInsertDoLog('del_search_list_log','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete'])));//������¼

			fn_cpmsg($Fn_Admin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
		}else{
			fn_cpmsg($Fn_Admin->Config['LangVar']['DelErr'],'','error');
		}
	}
}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['lid']){//ɾ��
	if(!$Fn_Admin->CheckUserGroup('global_all') && !$Fn_Admin->CheckUserGroup('global_search_list_log')){//Ȩ���ж�
		fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
		exit();
	}
	$id = intval($_GET['lid']);
	$item = C::t('#fn_fenlei#fn_search_log')->fetch_by_id($id);
	C::t('#fn_fenlei#fn_search_log')->delete_by_id($id);
	C::t('#fn_fenlei#fn_search')->update_by_count($item['search_id'],'count',1,'-');
	GetInsertDoLog('del_search_list_log','fn_'.$_GET['mod'],array('id'=>$id));//������¼
	fn_cpmsg($Fn_Admin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
}
//From: Dism_taobao_com
?>