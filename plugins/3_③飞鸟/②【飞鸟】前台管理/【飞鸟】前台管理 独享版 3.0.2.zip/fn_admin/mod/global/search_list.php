<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!file_exists(DISCUZ_ROOT.'./source/plugin/fn_fenlei')){
	showmessage('&#20320;&#36824;&#27809;&#26377;&#23433;&#35013;&#39134;&#40479;&#12304;&#21516;&#22478;&#20998;&#31867;&#12305;&#65292;&#27491;&#22312;&#36339;&#36716;&#39134;&#40479;&#12304;&#21516;&#22478;&#20998;&#31867;&#12305;','http://dism.taobao.com/?@fn_fenlei.plugin', array(), array('locationtime'=>true,'refreshtime'=>3, 'showdialog'=>1, 'showmsg' => true));
	exit();
}

if(!$Fn_Admin->CheckUserGroup('global_all') && !$Fn_Admin->CheckUserGroup('global_search_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$Do = in_array($_GET['do'], array('Del')) ? $_GET['do'] : 'List';

//�����ֶ�
$SearField =array('page','keyword','order');
foreach($SearField as $Val) {
	$SearArray[$Val] = $_GET[$Val] ? $_GET[$Val] : '';
}
//�����ֶ� End

$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeItemUrl'].'&'.http_build_query($SearArray);

if($Do == 'List'){
	if(!submitcheck('Submit')) {
		$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
		$page = $_GET['page'] ? $_GET['page'] : 0;
		$res = C::t('#fn_fenlei#fn_search')->fetch_all_by_list(array('keyword'=>$_GET['keyword']),$page - 1,30,'updateline','',true);
		/* ģ����� */
		showtagheader('div', 'row', true,'row');
		showtagheader('div', 'col-12', true,'col-12');
		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-body', true,'box-body');
		/* ���� */
		$OrderSelected = array($_GET['order']=>' selected');
		echo <<<SEARCH
		<form method="post" autocomplete="off" action="$SearUrl" id="tb_search">
			<div class="FormSearchTo">
				<table cellspacing="4" cellpadding="4">
					<tr>
						<th>&#20851;&#38190;&#35789;</th><td colspan="10"><input type="text" class="input form-control w200" name="keyword" value="{$_GET['keyword']}" placeholder="&#35831;&#36755;&#20837;&#25628;&#32034;&#35789;">
						</td>
						<th>&#25490;&#24207;</th><td>
						<select name="order" class="form-control w120">
							<option value="updateline"{$OrderSelected['updateline']}>{$Fn_Admin->Config['LangVar']['OrderArray']['updateline']}</option>
							<option value="dateline"{$OrderSelected['dateline']}>{$Fn_Admin->Config['LangVar']['OrderArray']['dateline']}</option>
							<option value="count"{$OrderSelected['count']}>&#25628;&#32034;&#27425;&#25968;</option>
						</select>
						</td>
						<th><input name="SearchSubmit" value="{$Fn_Admin->Config['LangVar']['SearchSubmit']}" class="btn btn-info" type="submit"></th>
					</tr>
				</table>
			</div>
		</form>
SEARCH;
		/* ���� End */
		showtagheader('div', 'table-responsive', true,'table-responsive');
		showformheader($FormUrl,'enctype="multipart/form-data"');
		showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
		showsubtitle(array(
			'ID',
			'&#25628;&#32034;&#35789;',
			'&#25628;&#32034;&#27425;&#25968;',
			'&#26356;&#26032;&#26102;&#38388;',
			$Fn_Admin->Config['LangVar']['TimeTitle'],
			$Fn_Admin->Config['LangVar']['OperationTitle']
		), 'header tbm tc');
	
		foreach ($res['list'] as $item) {
			$item['content'] = $item['content'] ? $item['content'] : ($item['title'] ? $item['title'] : $item['phone']);
			showtablerow('', array('class="tc w100"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
				'<input type="checkbox" class="filled-in" id="checkbox_'.$item['id'].'" name="delete[]" value="'.$item['id'].'"><label for="checkbox_'.$item['id'].'">'.$item['id'].'</label>',
				$item['keyword'],
				$item['count'],
				date('Y-m-d H:i',$item['updateline']),
				date('Y-m-d H:i',$item['dateline']),
				'<a href="'.$Fn_Admin->Config['IframeModUrl'].'&item=search_list_log&submodel=list&search_id='.$item['id'].'" class="btn btn-sm btn-info-outline">&#25628;&#32034;&#35760;&#24405;</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=Del&sid='.$item['id'].'&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;" class="btn btn-sm btn-danger-outline">&#21024;&#38500;</a>',
			));
		}
		showsubmit('Submit','&#31435;&#21363;&#25552;&#20132;','del','','',multi($res['count'],30,$page,$MpUrl));
		showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		/* ģ����� End */
	}else{
		if(isset($_GET['delete']) && is_array($_GET['delete'])){
			if(!$Fn_Admin->CheckUserGroup('global_all') && !$Fn_Admin->CheckUserGroup('global_search_list')){//Ȩ���ж�
				fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
				exit();
			}
			foreach($_GET['delete'] as $val) {
				$id = intval($val);
				C::t('#fn_fenlei#fn_search')->delete_by_id($id);
			}

			GetInsertDoLog('del_search_list','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete'])));//������¼

			fn_cpmsg($Fn_Admin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
		}else{
			fn_cpmsg($Fn_Admin->Config['LangVar']['DelErr'],'','error');
		}
	}
}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['sid']){//ɾ��
	if(!$Fn_Admin->CheckUserGroup('global_all') && !$Fn_Admin->CheckUserGroup('global_search_list')){//Ȩ���ж�
		fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
		exit();
	}
	$id = intval($_GET['sid']);
	C::t('#fn_fenlei#fn_search')->delete_by_id($id);
	GetInsertDoLog('del_search_list','fn_'.$_GET['mod'],array('id'=>$id));//������¼
	fn_cpmsg($Fn_Admin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
}
//From: Dism_taobao_com
?>