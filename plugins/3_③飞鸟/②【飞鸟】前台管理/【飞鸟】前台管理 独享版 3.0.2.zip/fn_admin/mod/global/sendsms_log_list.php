<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('global_all') && !$Fn_Admin->CheckUserGroup('global_sendsms_log_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$Do = in_array($_GET['do'], array('AllDel')) ? $_GET['do'] : 'List';

//�����ֶ�
$SearField =array('page','keyword','start_time','end_time','state','order','source');
foreach($SearField as $Val) {
	$SearArray[$Val] = $_GET[$Val] || in_array($_GET[$Val],array('0')) ? $_GET[$Val] : '';
}
//�����ֶ� End

$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeItemUrl'].'&'.http_build_query($SearArray);

if($Do == 'List'){
	if(!submitcheck('Submit')) {
		$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
		/* ��ѯ���� */
		$Where = '';
		$Order = in_array($_GET['order'], array('id')) ? 'L.'.addslashes(dhtmlspecialchars($_GET['order'])) : 'L.id';
		if($_GET['keyword']){
			$_GET['keyword'] = str_replace(array('%','_'),array('',''),$_GET['keyword']);
			
			$Where .= ' and (L.username like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') or L.mobile like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\')  or L.uid = '.intval($_GET['keyword']).' or L.content like(\'%'.addslashes(strip_tags($_GET['keyword'])).'%\') )';

		}
		
		if($_GET['source']){
			$_GET['source'] = str_replace(array('%'),array(''),$_GET['source']);
			$Where .= ' and L.source like(\'%'.addslashes(strip_tags($_GET['source'])).'%\')';
		}
		

		if(in_array($_GET['state'],array('200','201'))){
			$Where .= ' and L.state = '.intval($_GET['state']);
		}

		$Where = preg_replace('/and/','where',$Where,1);
		$Limit = 20;
		$Page = $_GET['page']?intval($_GET['page']):1;
		/* ��ѯ���� End */
		/* ���� */
		$StateSelected = array($_GET['state']=>' selected');

		/* ���� End */

		/* ģ����� */		
		showtagheader('div', 'row', true,'row');
		showtagheader('div', 'col-12', true,'col-12');
		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-body', true,'box-body');
		echo <<<SEARCH
		<form method="post" autocomplete="off" action="$SearUrl" id="tb_search">
			<div class="FormSearchTo">
				<table cellspacing="4" cellpadding="4">
					<tr>
						<th>{$Fn_Admin->Config['LangVar']['KeywordTitle']}</th><td><input type="text" class="input form-control w200" name="keyword" value="{$_GET['keyword']}">
						</td>
						<th>{$Fn_Admin->Config['LangVar']['Source']}</th><td><input type="text" class="input form-control w150" name="source" value="{$_GET['source']}">
						</td>
						<th>{$Fn_Admin->Config['LangVar']['StateTitle']}</th><td>
						<select name="state" class="form-control w120">
							<option value="">{$Fn_Admin->Config['LangVar']['SelectNull']}</option>
							<option value="200"{$StateSelected['200']}>{$Fn_Admin->Config['LangVar']['SendSmsState']['200']}</option>
							<option value="201"{$StateSelected['201']}>{$Fn_Admin->Config['LangVar']['SendSmsState']['201']}</option>
						</select>
						&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Admin->Config['LangVar']['SearchSubmit']}" class="btn btn-info" type="submit">
						</td>
					</tr>
				</table>
			</div>
		</form>
SEARCH;
		showtagheader('div', 'table-responsive', true,'table-responsive');
		showformheader($FormUrl,'enctype="multipart/form-data"');
		showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
		showsubtitle(array(
			'ID',
			'Uid/'.$Fn_Admin->Config['LangVar']['UserNameTitle'],
			$Fn_Admin->Config['LangVar']['MobileTitle'],
			$Fn_Admin->Config['LangVar']['Source'],
			$Fn_Admin->Config['LangVar']['ApiType'],
			$Fn_Admin->Config['LangVar']['Content'],
			$Fn_Admin->Config['LangVar']['StateTitle'],
			$Fn_Admin->Config['LangVar']['TimeTitle'],
		), 'header tbm');
		
		$ModulesList = GetModulesList($Page,$Limit,$Where,$Order);
		
		foreach ($ModulesList as $Module) {
			showtablerow('', array('class="tc w100"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
				'<input type="checkbox" class="filled-in" id="checkbox_'.$Module['id'].'" name="delete[]" value="'.$Module['id'].'"><label for="checkbox_'.$Module['id'].'">'.$Module['id'].'</label>',
				$Module['uid'] ? $Module['uid'].'/'.$Module['username'] : '',
				$Module['mobile'],
				$Module['source'],
				$Fn_Admin->Config['LangVar']['ApiTypeArray'][$Module['type']],
				$Module['content'],
				$Module['state'] == 200 ? $Fn_Admin->Config['LangVar']['SendSmsState'][$Module['state']] : $Fn_Admin->Config['LangVar']['SendSmsState'][$Module['state']].': '.$Module['msg'],
				date('Y-m-d H:i',$Module['dateline'])
			));
		}
		showsubmit('Submit','submit','del','&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=AllDel&day=365&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;">'.$Fn_Admin->Config['LangVar']['AllDelTimeArray']['365'].'</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=AllDel&day=180&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;">'.$Fn_Admin->Config['LangVar']['AllDelTimeArray']['180'].'</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=AllDel&day=90&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;">'.$Fn_Admin->Config['LangVar']['AllDelTimeArray']['90'].'</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=AllDel&day=30&formhash='.FORMHASH.'"  onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;">'.$Fn_Admin->Config['LangVar']['AllDelTimeArray']['30'].'</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=AllDel&day=1&formhash='.FORMHASH.'"  onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;">&#21024;&#38500;&#49;&#22825;&#21069;</a>','',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));
        showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		/* ģ����� End */
	}else{
		if(isset($_GET['delete']) && is_array($_GET['delete'])){
			foreach($_GET['delete'] as $Key => $Val) {
				$Val = intval($Val);
				DB::delete('fn_send_sms_log','id ='.$Val);
			}

			GetInsertDoLog('del_send_sms_log','fn_'.$_GET['mod'],array('ids'=>implode(',',$_GET['delete'])));//������¼

			fn_cpmsg($Fn_Admin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
		}else{
			fn_cpmsg($Fn_Admin->Config['LangVar']['DelErr'],'','error');
		}
	}
}else if($Do == 'AllDel' && $_GET['formhash'] == formhash() && $_GET['day']){
	if(!$Fn_Admin->CheckUserGroup('global_all') && !$Fn_Admin->CheckUserGroup('global_del_sendsms_log_log')){//Ȩ���ж�
		fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
		exit();
	}

	DB::delete('fn_send_sms_log','dateline <= '.strtotime("-".intval($_GET['day'])." day",time()));
	
	GetInsertDoLog('del_send_sms_log','fn_'.$_GET['mod'],array('day'=>$_GET['day']));//������¼

	fn_cpmsg($Fn_Admin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
}

/* �б� */
function GetModulesList($Page,$Limit,$Where=null,$Order){
	global $Fn_Admin;
	$FetchSql = 'SELECT L.* FROM '.DB::table('fn_send_sms_log').' L '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}

/* ���� */
function GetModulesCount($Where=null){
	global $Fn_Admin;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table('fn_send_sms_log').' L '.$Where;
	return DB::result_first($FetchSql);//��������
}
//From: Dism_taobao_com
?>