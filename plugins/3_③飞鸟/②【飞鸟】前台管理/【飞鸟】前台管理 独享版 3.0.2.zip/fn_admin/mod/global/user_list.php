<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('global_all') && !$Fn_Admin->CheckUserGroup('global_user_list')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

@require_once (DISCUZ_ROOT .'./source/plugin/fn_assembly/app.inc.php');
@require_once (DISCUZ_ROOT.'./source/plugin/fn_login/config.php');

$SubModel = in_array($_GET['submodel'], array('list','add')) ? $_GET['submodel'] : 'list';
$Fn_Admin->Config['IframeSubModelUrl'] = $Fn_Admin->Config['IframeItemUrl'].'&submodel='.$SubModel;
$NavClass = array($SubModel=>'btn-info Hover');

//����
echo <<<Nav
<div class="SubModelNav">
  <ul>
	<li class="{$NavClass['list']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=list" target="_self">{$Fn_Admin->Config['LangVar']['XiangqinLeftNavArray'][$_GET['item']]}</a></li>
    <li class="{$NavClass['add']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=add" target="_self">{$Fn_Admin->Config['LangVar']['AddEditTitle']}</a></li>
  </ul>
  <div class="both"></div>
</div>
Nav;

if($SubModel == 'list'){//�б�
	$Do = in_array($_GET['do'], array('Del')) ? $_GET['do'] : 'submodel_list';
	//�����ֶ�
	$SearField =array('page','keyword','new_uid','phone','openid','order','unionid');
	foreach($SearField as $Val) {
		$SearArray[$Val] = $_GET[$Val] || in_array($_GET[$Val],array('0')) ? $_GET[$Val] : '';
	}
	//�����ֶ� End
	$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeSubModelUrl'].'&'.http_build_query($SearArray);
	if($Do == 'submodel_list'){
		if(!submitcheck('Submit')) {
			$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
			$page = $_GET['page'] ? $_GET['page'] : 0;
			$res = C::t('#fn_login#fn_user')->fetch_all_by_list(array('uid'=>$_GET['new_uid'],'phone'=>$_GET['phone'],'openid'=>$_GET['openid'],'unionid'=>$_GET['unionid']),$page - 1,20,$_GET['order'],'',true);
			/* ��ѯ���� End */

			/* ģ����� */	
			showtagheader('div', 'row', true,'row');
			showtagheader('div', 'col-12', true,'col-12');
			showtagheader('div', 'box', true,'box');
			showtagheader('div', 'box-body', true,'box-body');
			/* ���� */
			$OrderSelected = array($_GET['order']=>' selected');
			echo <<<SEARCH
			<form method="post" autocomplete="off" action="$SearUrl">
				<div class="FormSearchTo" style="margin-bottom:0;">
					<table cellspacing="4" cellpadding="4">
						<tr>
							<th>&#29992;&#25143;&#73;&#68;</th><td>
								<input type="text" class="input form-control w150" name="new_uid" value="{$_GET['new_uid']}" placeholder="&#35831;&#36755;&#20837;&#29992;&#25143;&#73;&#68;">
							</td>
							<th>&#29992;&#25143;&#25163;&#26426;</th><td>
								<input type="text" class="input form-control w150" name="phone" value="{$_GET['phone']}" placeholder="&#35831;&#36755;&#20837;&#29992;&#25143;&#25163;&#26426;">
							</td>
							<th>openid</th><td>
								<input type="text" class="input form-control w150" name="openid" value="{$_GET['openid']}" placeholder="&#35831;&#36755;&#20837;&#111;&#112;&#101;&#110;&#105;&#100;">
							</td>
							<th>unionid</th><td>
								<input type="text" class="input form-control w150" name="unionid" value="{$_GET['unionid']}" placeholder="&#35831;&#36755;&#20837;&#117;&#110;&#105;&#111;&#110;&#105;&#100;">
							</td>
							<th>&#25490;&#24207;</th><td>
							<select name="order" class="form-control w120">
								<option value="dateline"{$OrderSelected['dateline']}>{$Fn_Admin->Config['LangVar']['OrderArray']['dateline']}</option>
								<option value="last_login_dateline"{$OrderSelected['last_login_dateline']}>&#26368;&#21518;&#30331;&#24405;&#26102;&#38388;</option>
								<option value="uid"{$OrderSelected['uid']}>&#29992;&#25143;&#73;&#68;</option>
							</select>
							</td>
							<th><input name="SearchSubmit" value="{$Fn_Admin->Config['LangVar']['SearchSubmit']}" class="btn btn-info" type="submit"></th>
						</tr>
					
					</table>
				</div>
			</form>
SEARCH;
			/* ���� End */
			showtagheader('div', 'table-responsive', true,'table-responsive');
			showformheader($FormUrl,'enctype="multipart/form-data"');
			showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
			showsubtitle(array(
				'&#29992;&#25143;&#73;&#68;',
				'&#29992;&#25143;&#25163;&#26426;',
				'&#29992;&#25143;&#22320;&#21306;',
				'openid',
				'unionid',
				'&#30331;&#24405;&#27425;&#25968;',
				'&#26368;&#21518;&#30331;&#24405;&#26102;&#38388;',
				'&#28155;&#21152;&#26102;&#38388;',
				'&#25805;&#20316;',
			),'header tbm tc');

			foreach ($res['list'] as $item) {
				$region = C::t('#fn_fenlei#fn_region')->fetch_by_id($item['regionid']);
				showtablerow('', array('class="tc w100"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
					$item['uid'],
					$item['phone'],
					$region['name'],
					$item['openid'],
					$item['unionid'],
					$item['counts'],
					date('Y-m-d H:i',$item['last_login_dateline']),
					date('Y-m-d H:i',$item['dateline']),
					'<a href="'.$Fn_Admin->Config['IframeItemUrl'].'&submodel=add&aid='.$item['uid'].'" class="btn btn-sm btn-info-outline">'.$Fn_Admin->Config['LangVar']['EditTitle'].'</a>',
				));
			}
			showsubmit('','','','','',multi($res['count'],20,$page,$MpUrl));
			showtablefooter(); /*dism��taobao��com*/
			showformfooter(); /*Dism_taobao-com*/
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			showtagfooter('div');
			/* ģ�����End */	
		}
	}
}else if($SubModel == 'add'){//���ӻ�༭

	$id = intval($_GET['aid']);
	
	$item = C::t('#fn_login#fn_user')->fetch_by_uid($id);

	if(!submitcheck('DetailSubmit')) {
		$opTitle = $Fn_Admin->Config['LangVar']['AddTitle'];
		if($item){
			$opTitle = $Fn_Admin->Config['LangVar']['EditTitle'];
		}
		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-header', true,'with-border box-header');
		showtitle($opTitle,'class="box-title"');
		showtagfooter('div');
		showformheader($Fn_Admin->Config['IframeSubModelUrl'].'&aid='.$id,'enctype');
		showtagheader('div', 'box-body', true,'box-body');
		
		if($item){
			//showsetting('uid', 'new_uid', $item['uid'], 'text');
		}

		showsetting('&#29992;&#25143;&#22320;&#21306;', 'regionid', $item['regionid'], 'text');
		//showsetting('&#29992;&#25143;&#25163;&#26426;', 'phone', $item['phone'], 'text');

		showsubmit('DetailSubmit','&#20445;&#23384;&#37197;&#32622;');
		showtagfooter('div');
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');

	}else{
		if($item){
			//$data['uid'] = intval($_GET['new_uid']);
		}else{
			$data['phone'] = addslashes(strip_tags($_GET['phone']));
		}
		$data['regionid'] = intval($_GET['regionid']);
		
		if($item && $_GET['phone'] != $item['phone'] && C::t('#fn_login#fn_user')->fetch_by_phone($_GET['phone'])){
			fn_cpmsg($fn_login->setting['lang']['phone_existence_tips'],'','error');
			exit();
		}

		if($item && $_GET['new_uid'] != $item['uid'] && C::t('#fn_login#fn_user')->fetch_by_uid($_GET['new_uid'])){
			fn_cpmsg($fn_login->setting['lang']['userid_existence_tips'],'','error');
			exit();
		}
			
		if(!$item){
			$checkUser = C::t('#fn_login#fn_user')->fetch_by_phone($_GET['phone']);
			if($checkUser){
				fn_cpmsg($fn_login->setting['lang']['phone_existence_tips'],'','error');
				exit();
			}
		}	

		if($item){
			C::t('#fn_login#fn_user')->update($data,$id);
		}else{
			if($fn_login->setting['AppType'] == 2){
				$appUser =  DB::fetch_first('SELECT * FROM %t WHERE phone = %s LIMIT 1', array('phonebind',$_GET['phone']));
			}else if($fn_login->setting['AppType'] == 1){
				$appUser = DB::fetch_first("SELECT *,".$fn_login->magConfig['user_mobile_relations_userid']." as uid FROM " .DB::table($fn_login->magConfig['user_mobile_relations'])." WHERE ".$fn_login->magConfig['user_mobile_relations_phone']."=%s", array($_GET['phone']));
			}

			if($appUser['uid']){
				$data['uid'] = $appUser['uid'];
				if($fn_login->setting['AppType'] == 2){
					$wxUser = DB::fetch_first("SELECT wx.* FROM " .DB::table('thirdbind')." wx WHERE wx.uid=%s", array($data['uid']));
				}else if($fn_login->setting['AppType'] == 1){
					$wxUser = DB::fetch_first("SELECT wx.*,wx.".$fn_login->magConfig['user_weixin_relations_userid']." as uid FROM " .DB::table($fn_login->magConfig['user_weixin_relations'])." wx WHERE wx.".$fn_login->magConfig['user_weixin_relations_unionid']."=%s", array($data['uid']));
				}
				$data['openid'] = $appUser['openid'];
				$data['unionid'] = $appUser['unionid'];
			}else{
				//ע��
				loaducenter();
				$passWord = md5(random(10));
				$email = 'wx_'.strtolower(random(10)).'@null.null';
				$uid = uc_user_register($data['phone'],$passWord,$email,'', '',$fn_login->_G['clientip']);
				if($uid <= 0){
					if($uid == -1){
					   $error = $fn_login->setting['lang']['profile_username_illegal'];
					}else if($uid == -2){
						$error = $fn_login->setting['lang']['profile_username_protect'];
					}else if($uid == -3){
						$error = $fn_login->setting['lang']['profile_username_duplicate'];
					}else if($uid == -4){
						$error = $fn_login->setting['lang']['profile_email_illegal'];
					}else if($uid == -5){
						$error = $fn_login->setting['lang']['profile_email_domain_illegal'];
					}else if($uid == -6){
						$error = $fn_login->setting['lang']['profile_email_duplicate'];
					}else{
						$error = $fn_login->setting['lang']['undefined_action'];
					}

					fn_cpmsg($error,'','error');
					exit();
				}else{
					$data['uid'] = $uid;
					//ͬ��APP
					if($fn_login->setting['AppType'] == 2){
						DB::insert('phonebind',array('uid'=> $uid,'phone'=>$data['phone'],'dateline'=>time()));
					}else if($fn_login->setting['AppType'] == 1){
						DB::insert($fn_login->magConfig['user_mobile_relations'],array($fn_login->magConfig['user_mobile_relations_userid']=> $uid,'phone'=>$data['phone'],'create_time'=>time()));
					}
					//ͬ��APP END
				}
				$groupId = $fn_login->setting['register_groupid'] ? $fn_login->setting['register_groupid'] : $fn_login->_G['setting']['newusergroupid'];
				$initArr = array('credits' => explode(',', $fn_login->_G['setting']['initcredits']), 'profile' => array('gender' => $sex,'mobile' => $mobile));
				C::t('common_member')->insert($uid,$data['phone'],$passWord,$email,$fn_login->_G['clientip'],$groupId, $initArr);
				if($fn_login->_G['setting']['regctrl'] || $fn_login->_G['setting']['regfloodctrl']){
					C::t('common_regip')->delete_by_dateline($fn_login->_G['timestamp'] - ($fn_login->_G['setting']['regctrl'] > 72 ? $fn_login->_G['setting']['regctrl'] : 72) * 3600);
					if($fn_login->_G['setting']['regctrl']){
						C::t('common_regip')->insert(array('ip' => $fn_login->_G['clientip'], 'count' => -1, 'dateline' => $fn_login->_G['timestamp']));
					}
				}
				if($fn_login->_G['setting']['regverify'] == 2){
					C::t('common_member_validate')->insert(array('uid' => $uid, 'submitdate' => $fn_login->_G['timestamp'], 'moddate' => 0, 'admin' => '', 'submittimes' => 1, 'status' => 0, 'message' => '', 'remark' => ''), false, true);
					manage_addnotify('verifyuser');
				}
				include_once libfile('function/stat');
				updatestat('register');
				//ע�� END
			}

			$data['last_login_dateline'] = $data['dateline'] = time();
			$id = C::t('#fn_login#fn_user')->insert($data);
		}
		fn_cpmsg($fn_login->setting['lang']['UpdateOk'],$Fn_Admin->Config['IframeItemUrl'].'&submodel=list','succeed');
		exit();
	}
}
//From: Dism_taobao_com
?>