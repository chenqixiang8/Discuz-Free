<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$Fn_Admin->CheckUserGroup('global_all') && !$Fn_Admin->CheckUserGroup('global_list_do_log')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

$Do = in_array($_GET['do'], array('Del','AllDel')) ? $_GET['do'] : 'List';

//�����ֶ�
$SearField =array('page','keyword','order','act');
foreach($SearField as $Val) {
	$SearArray[$Val] = $_GET[$Val] || in_array($_GET[$Val],array('0')) ? $_GET[$Val] : '';
}
//�����ֶ� End

$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeItemUrl'].'&'.http_build_query($SearArray);

if($Do == 'List'){
	if(!submitcheck('Submit')) {
		$SearUrl = $Fn_Admin->Config['IframeItemUrl'];
		/* ��ѯ���� */
		$Where = '';
		$Order = in_array($_GET['order'], array('id')) ? 'L.'.addslashes(dhtmlspecialchars($_GET['order'])) : 'L.id';
		if($_GET['keyword']){
			$Where .= ' and (concat(L.username,L.source,L.doing) like(\'%'.addslashes(dhtmlspecialchars(str_replace(array('%','_'),array('',''),$_GET['keyword']))).'%\') or L.uid = '.intval($_GET['keyword']).') or L.ip = \''.addslashes(dhtmlspecialchars($_GET['keyword'])).'\'';
		}

		if($_GET['act']){
			$Where .= ' and L.action = \''.addslashes(dhtmlspecialchars($_GET['act'])).'\'';
		}

		$Where = preg_replace('/and/','where',$Where,1);
		$Limit = 20;
		$Page = $_GET['page']?intval($_GET['page']):1;
		/* ��ѯ���� End */
		/* ���� */
		$StateSelected = array($_GET['state']=>' selected');
		/* ���� End */

		/* ģ����� */		
		showtagheader('div', 'row', true,'row');
		showtagheader('div', 'col-12', true,'col-12');
		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-body', true,'box-body');
		$action_option = '<option value="">'.$Fn_Admin->Config['LangVar']['SelectNull'].'</option>';
		foreach($Fn_Admin->Config['LangVar']['ActionArray'] as $key => $val) {
			$action_option .= '<option value="'. $key.'" '.($_GET['act'] ==  $key ? ' selected' : '' ).'>'.$val.'</option>';
		}

		echo <<<SEARCH
		<form method="post" autocomplete="off" action="$SearUrl" id="tb_search">
			<div class="FormSearchTo">
				<table cellspacing="4" cellpadding="4">
					<tr>
						<th>{$Fn_Admin->Config['LangVar']['KeywordTitle']}</th><td><input type="text" class="input form-control w200" name="keyword" value="{$_GET['keyword']}">
						</td>
						<th>&#25805;&#20316;&#21160;&#20316;</th><td>
						<select name="act" class="form-control w200">
							{$action_option}
						</select>
						&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Admin->Config['LangVar']['SearchSubmit']}" class="btn btn-info" type="submit">
						</td>
					</tr>
				</table>
			</div>
		</form>
SEARCH;
	
		showtagheader('div', 'table-responsive', true,'table-responsive');
		showformheader($FormUrl,'enctype="multipart/form-data"');
		showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
		showsubtitle(array(
			'ID',
			'Uid/'.$Fn_Admin->Config['LangVar']['UserName'],
			$Fn_Admin->Config['LangVar']['Action'],
			$Fn_Admin->Config['LangVar']['Doing'],
			$Fn_Admin->Config['LangVar']['Source'],
			'IP',
			$Fn_Admin->Config['LangVar']['DoDateLine'],
			$Fn_Admin->Config['LangVar']['OperationTitle'],
		), 'header tbm');
		
		$ModulesList = GetModulesList($Page,$Limit,$Where,$Order);
		
		foreach ($ModulesList as $Module) {
			showtablerow('', array('class="tc w100"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"','class="tc"'), array(
				'<input type="checkbox" class="filled-in" id="checkbox_'.$Module['id'].'" name="delete[]" value="'.$Module['id'].'"><label for="checkbox_'.$Module['id'].'">'.$Module['id'].'</label>',
				$Module['uid'] ? $Module['uid'].'/'.$Module['username'] : '',
				$Fn_Admin->Config['LangVar']['ActionArray'][$Module['action']],
				$Module['doing'],
				$Module['source'],
				$Module['ip'],
				date('Y-m-d H:i',$Module['dateline']),
				'<a href="'.$OpCpUrl.'&do=Del&lid='.$Module['id'].'&formhash='.FORMHASH.'" class="btn btn-sm btn-danger-outline"  onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;">'.$Fn_Admin->Config['LangVar']['DelTitle'].'</a>'
			));
		}
		showsubmit('Submit','submit','del','&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=AllDel&day=365&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;">'.$Fn_Admin->Config['LangVar']['AllDelTimeArray']['365'].'</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=AllDel&day=180&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;">'.$Fn_Admin->Config['LangVar']['AllDelTimeArray']['180'].'</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=AllDel&day=90&formhash='.FORMHASH.'" onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;">'.$Fn_Admin->Config['LangVar']['AllDelTimeArray']['90'].'</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="'.$OpCpUrl.'&do=AllDel&day=30&formhash='.FORMHASH.'"  onclick="if(confirm(\''.$Fn_Admin->Config['LangVar']['MsgBox_msg_del'].'\')==false)return false;">'.$Fn_Admin->Config['LangVar']['AllDelTimeArray']['30'].'</a>','',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));
        showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		/* ģ����� End */
	}else{
		if(isset($_GET['delete']) && is_array($_GET['delete'])){
			if(!$Fn_Admin->CheckUserGroup('global_all') && !$Fn_Admin->CheckUserGroup('global_del_do_log')){//Ȩ���ж�
				fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
				exit();
			}
			foreach($_GET['delete'] as $Key => $Val) {
				$Val = intval($Val);
				DB::delete($Fn_Admin->TableDoLog,'id ='.$Val);
			}
			fn_cpmsg($Fn_Admin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
		}else{
			fn_cpmsg($Fn_Admin->Config['LangVar']['DelErr'],'','error');
		}
		exit();
	}
}else if($Do == 'Del' && $_GET['formhash'] == formhash() && $_GET['lid']){//ɾ��
	if(!$Fn_Admin->CheckUserGroup('global_all') && !$Fn_Admin->CheckUserGroup('global_del_do_log')){//Ȩ���ж�
		fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
		exit();
	}
	DB::delete($Fn_Admin->TableDoLog,'id ='.intval($_GET['lid']));
	fn_cpmsg($Fn_Admin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
}else if($Do == 'AllDel' && $_GET['formhash'] == formhash() && $_GET['day']){
	if(!$Fn_Admin->CheckUserGroup('global_all') && !$Fn_Admin->CheckUserGroup('global_del_do_log')){//Ȩ���ж�
		fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
		exit();
	}

	DB::delete($Fn_Admin->TableDoLog,'dateline <= '.strtotime("-".intval($_GET['day'])." day",time()));
	
	fn_cpmsg($Fn_Admin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
}

/* �б� */
function GetModulesList($Page,$Limit,$Where=null,$Order){
	global $Fn_Admin;
	$FetchSql = 'SELECT L.* FROM '.DB::table($Fn_Admin->TableDoLog).' L '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}

/* ���� */
function GetModulesCount($Where=null){
	global $Fn_Admin;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_Admin->TableDoLog).' L '.$Where;
	return DB::result_first($FetchSql);//��������
}
//From: Dism_taobao_com
?>