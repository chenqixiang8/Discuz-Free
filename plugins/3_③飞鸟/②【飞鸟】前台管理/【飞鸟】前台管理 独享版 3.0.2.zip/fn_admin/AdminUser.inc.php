<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}

require_once (DISCUZ_ROOT .'./source/plugin/fn_admin/Function.inc.php');
$Operation = in_array($_GET['Operation'], array('Del','Add','Edit')) ? $_GET['Operation'] : 'List';
$CpMsgUrl = 'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod='.$module['name'];
if($Operation == 'List'){//�б�
	if(!submitcheck('Submit')) {
		/* ��ѯ���� */
		$MpUrl = ADMINSCRIPT.'?'.rawurldecode(cpurl());
		foreach($_GET as $key => $val){
			$MpUrl.= '&'.$key.'='.$val;
		}
		$Where = '';
		$Order = 'U.id';
		$Limit = 30;
		$Page = $_GET['page']?intval($_GET['page']):1;
		/* ��ѯ���� End */
		/* ģ����� */
		$TdStyle = array('width="60"','');
		$FormUrl = ltrim(rawurldecode(cpurl()),'action=');
		showtagheader('div', 'Module', true);
		showformheader($FormUrl,'enctype="multipart/form-data"');
		showtableheader('');
		showsubtitle(array(
			'ID',
			'UID/'.$Fn_Admin->Config['LangVar']['UserName'],
			$Fn_Admin->Config['LangVar']['UserGroupTitle'],
			$Fn_Admin->Config['LangVar']['DisableTitle'],
			$Fn_Admin->Config['LangVar']['OperationTitle']
		), 'header tbm',$TdStyle);
		
		$ModulesList = GetModulesList($Page,$Limit,$Where,$Order);
		$OpCpUrl = ADMINSCRIPT.'?'.rawurldecode(cpurl());
		foreach ($ModulesList as $Module) {
			showtablerow('', array('class="td25"','class="td28"'), array(
				$Module['id'],
				$Module['uid'].'/'.$Module['username'],
				$Module['title'],
				$Module['disable'] ? '<span style="color:red">'.$Fn_Admin->Config['LangVar']['Yes'].'</span>' : $Fn_Admin->Config['LangVar']['No'],
				'<a href="'.$OpCpUrl.'&Operation=Edit&uid='.$Module['id'].'">'.$Fn_Admin->Config['LangVar']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&Operation=Del&uid='.$Module['id'].'&formhash='.FORMHASH.'">'.$Fn_Admin->Config['LangVar']['DelTitle'].'</a>',
			));
		}
		showsubmit('','','','<a href="'.$OpCpUrl.'&Operation=Add">'.$Fn_Admin->Config['LangVar']['AddUser'].'</a>',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));
        showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');
		/* ģ����� End */
	}
}else if($Operation == 'Del' && $_GET['formhash'] == formhash() && $_GET['uid']){//ɾ��
	$UId = intval($_GET['uid']);
	DB::delete($Fn_Admin->TableUser,'id ='.$UId);
	cpmsg($Fn_Admin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');

}else if(in_array($Operation,array('Add','Edit'))){//���ӻ�༭
	$UId = intval($_GET['uid']);
	$Item = $UId ? $Fn_Admin->QueryOne($Fn_Admin->TableUser,$UId) : array();
	if($Item){$Item['param'] = unserialize($Item['param']);}
	$OpTitle = $Fn_Admin->Config['LangVar']['AddTitle'];
	if(!submitcheck('DetailSubmit')) {
		if($Item) {
			$OpTitle = $Fn_Admin->Config['LangVar']['EditTitle'];
		}

		$FormUrl = ltrim(rawurldecode(cpurl()),'action=');
		showformheader($FormUrl,'enctype');
		showtableheader();
		showtitle($OpTitle);
		showsetting('uid', 'new_uid', $Item['uid'], 'text');
		
		$UserGroup = array();
		foreach(DB::fetch_all('SELECT * FROM '.DB::table($Fn_Admin->TableUserGroup).' order by id asc','','id') as $Val) {
			$UserGroup[] = array($Val['id'], $Val['title']);
		}

		showsetting($Fn_Admin->Config['LangVar']['UserGroupTitle'], array('groupid', $UserGroup), $Item['groupid'], 'select');

		showsetting($Fn_Admin->Config['LangVar']['TopNav'],array('nav',$Fn_Admin->DyadicArray($Fn_Admin->Config['LangVar']['NavArray'])),$Item['param']['nav'],'mcheckbox','','');

		showsetting($Fn_Admin->Config['LangVar']['GlobalLeftNav'],array('global_left_nav',$Fn_Admin->DyadicArray($Fn_Admin->Config['LangVar']['GlobalLeftNavArray'])),$Item['param']['global_left_nav'],'mcheckbox','','');

		showsetting($Fn_Admin->Config['LangVar']['XiangqinLeftNav'],array('xiangqin_left_nav',$Fn_Admin->DyadicArray($Fn_Admin->Config['LangVar']['XiangqinLeftNavArray'])),$Item['param']['xiangqin_left_nav'],'mcheckbox','','');

		showsetting($Fn_Admin->Config['LangVar']['HouseLeftNav'],array('house_left_nav',$Fn_Admin->DyadicArray($Fn_Admin->Config['LangVar']['HouseLeftNavArray'])),$Item['param']['house_left_nav'],'mcheckbox','','');

		showsetting($Fn_Admin->Config['LangVar']['JobLeftNav'],array('job_left_nav',$Fn_Admin->DyadicArray($Fn_Admin->Config['LangVar']['JobLeftNavArray'])),$Item['param']['job_left_nav'],'mcheckbox','','');

		showsetting($Fn_Admin->Config['LangVar']['RenovationLeftNav'],array('renovation_left_nav',$Fn_Admin->DyadicArray($Fn_Admin->Config['LangVar']['RenovationLeftNavArray'])),$Item['param']['renovation_left_nav'],'mcheckbox','','');

		showsetting($Fn_Admin->Config['LangVar']['FenleiLeftNav'],array('fenlei_left_nav',$Fn_Admin->DyadicArray($Fn_Admin->Config['LangVar']['FenleiLeftNavArray'])),$Item['param']['fenlei_left_nav'],'mcheckbox','','');

		showsetting($Fn_Admin->Config['LangVar']['ShopsLeftNav'],array('shops_left_nav',$Fn_Admin->DyadicArray($Fn_Admin->Config['LangVar']['ShopsLeftNavArray'])),$Item['param']['shops_left_nav'],'mcheckbox','','');

		showsetting($Fn_Admin->Config['LangVar']['LiveLeftNav'],array('live_left_nav',$Fn_Admin->DyadicArray($Fn_Admin->Config['LangVar']['LiveLeftNavArray'])),$Item['param']['live_left_nav'],'mcheckbox','','');

		showsetting($Fn_Admin->Config['LangVar']['HdLeftNav'],array('hd_left_nav',$Fn_Admin->DyadicArray($Fn_Admin->Config['LangVar']['HdLeftNavArray'])),$Item['param']['hd_left_nav'],'mcheckbox','','');

		showsetting($Fn_Admin->Config['LangVar']['WxqLeftNav'],array('wxq_left_nav',$Fn_Admin->DyadicArray($Fn_Admin->Config['LangVar']['WxqLeftNavArray'])),$Item['param']['wxq_left_nav'],'mcheckbox','','');

		showsetting($Fn_Admin->Config['LangVar']['CrmLeftNav'],array('crm_left_nav',$Fn_Admin->DyadicArray($Fn_Admin->Config['LangVar']['CrmLeftNavArray'])),$Item['param']['crm_left_nav'],'mcheckbox','','');
		
		showsetting($Fn_Admin->Config['LangVar']['DisableTitle'], 'disable', $Item['disable'], 'radio');

		showtablefooter(); /*dism��taobao��com*/
		showsubmit('DetailSubmit');
		showformfooter(); /*Dism_taobao-com*/
	}else{
		$Data['uid'] = intval($_GET['new_uid']);
		$Data['groupid'] = intval($_GET['groupid']);
		$Data['disable'] = intval($_GET['disable']);
		$Param['nav'] = is_array($_GET['nav']) && isset($_GET['nav']) ? $_GET['nav'] : '';
		$Param['global_left_nav'] = is_array($_GET['global_left_nav']) && isset($_GET['global_left_nav']) ? $_GET['global_left_nav'] : '';
		$Param['xiangqin_left_nav'] = is_array($_GET['xiangqin_left_nav']) && isset($_GET['xiangqin_left_nav']) ? $_GET['xiangqin_left_nav'] : '';
		$Param['house_left_nav'] = is_array($_GET['house_left_nav']) && isset($_GET['house_left_nav']) ? $_GET['house_left_nav'] : '';
		$Param['job_left_nav'] = is_array($_GET['job_left_nav']) && isset($_GET['job_left_nav']) ? $_GET['job_left_nav'] : '';
		$Param['renovation_left_nav'] = is_array($_GET['renovation_left_nav']) && isset($_GET['renovation_left_nav']) ? $_GET['renovation_left_nav'] : '';
		$Param['fenlei_left_nav'] = is_array($_GET['fenlei_left_nav']) && isset($_GET['fenlei_left_nav']) ? $_GET['fenlei_left_nav'] : '';
		$Param['shops_left_nav'] = is_array($_GET['shops_left_nav']) && isset($_GET['shops_left_nav']) ? $_GET['shops_left_nav'] : '';
		$Param['live_left_nav'] = is_array($_GET['live_left_nav']) && isset($_GET['live_left_nav']) ? $_GET['live_left_nav'] : '';
		$Param['hd_left_nav'] = is_array($_GET['hd_left_nav']) && isset($_GET['hd_left_nav']) ? $_GET['hd_left_nav'] : '';
		$Param['wxq_left_nav'] = is_array($_GET['wxq_left_nav']) && isset($_GET['wxq_left_nav']) ? $_GET['wxq_left_nav'] : '';
		$Param['crm_left_nav'] = is_array($_GET['crm_left_nav']) && isset($_GET['crm_left_nav']) ? $_GET['crm_left_nav'] : '';
		
		$Data['param'] = serialize($Param);
		$Member = DB::fetch_first('SELECT username FROM '.DB::table('common_member').' where uid = '.$Data['uid']);
		if($Member){
			$Data['username'] = addslashes(strip_tags($Member['username']));
			if($Item){
				DB::update($Fn_Admin->TableUser,$Data,'id = '.$UId);
			}else{
				$Data['dateline'] =  time();
				DB::insert($Fn_Admin->TableUser,$Data);
			}
			cpmsg($Fn_Admin->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
		}else{
			cpmsg($Fn_Admin->Config['LangVar']['NoUserErr'],'','error');
		}
	}
}

/* �б� */
function GetModulesList($Page,$Limit,$Where=null,$Order){
	global $Fn_Admin;
	$FetchSql = 'SELECT G.title,U.* FROM '.DB::table($Fn_Admin->TableUser).' U LEFT JOIN '.DB::table($Fn_Admin->TableUserGroup).' G on G.id = U.groupid '.$Where.' order by '.$Order.' asc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}
/* ���� */
function GetModulesCount($Where=null){
	global $Fn_Admin;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_Admin->TableUser).' U '.$Where;
	return DB::result_first($FetchSql);//��������
}
//From: Dism��taobao��com
?>