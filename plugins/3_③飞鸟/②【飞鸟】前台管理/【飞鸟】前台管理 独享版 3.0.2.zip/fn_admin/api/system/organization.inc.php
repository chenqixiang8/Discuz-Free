<?php

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
header("Content-type: text/html; charset=utf-8");
function checkOrganization(){
	$res = C::t('#fn_admin#fn_admin_organization')->fetch_all_by_list(array(),'o.sortNumber',0,300,true);
	foreach($res['list'] as $val){
		$check[$val['id']] = $val;
		$check[$val['id']]['sonid'] = C::t('#fn_admin#fn_admin_organization')->all_list_id($val['id']);
	}
	savecache('fn_admin_organization',$check);
}
loadcache('fn_admin_organization');
$organizationList = $_G['cache']['fn_admin_organization'];

if($_GET['op'] == 'type'){
	baseJosn(vueFormArray($Fn_Admin->Config['LangVar']['organization_type_arr']));
}else if($_GET['op'] == 'list'){//列表
	$res = C::t('#fn_admin#fn_admin_organization')->fetch_all_by_list(array(),'o.sortNumber',0,300,true);
	$list = array();
	foreach($res['list'] as $key => $val){
		$val['dateline'] =  FormatDate($val['dateline'],'Y-m-d H:i');
		$val['sortNumber'] = (int)$val['sortNumber'];
		$val['parentId'] = $val['parentId'] ? $val['parentId'] : null;
		$list[] = $val;
	}
	baseJosn($list,'',0, $res['count']);
}else if($_GET['op'] == 'save'){
	$item = C::t('#fn_admin#fn_admin_organization')->fetch_by_id($postData['id']);
	$data['parentId'] = intval($postData['parentId']);
	$data['name'] = addslashes(strip_tags($postData['name']));
	$data['fullName'] = addslashes(strip_tags($postData['fullName']));
	$data['type'] = intval($postData['type']);
	$data['sortNumber'] = intval($postData['sortNumber']);
	$data['comments'] = addslashes(strip_tags($postData['comments']));
	if($item['id']){
		C::t('#fn_admin#fn_admin_organization')->update($data,$item['id']);
		saveOperRecordSave('部门管理','更新部门');
	}else{
		$data['dateline'] = time();
		C::t('#fn_admin#fn_admin_organization')->insert($data);
		saveOperRecordSave('部门管理','添加部门');
	}
	checkOrganization();
	baseJosn(array(),'更新成功');

}else if($_GET['op'] == 'del'){
	if($_GET['oid']){
		C::t('#fn_admin#fn_admin_organization')->delete_by_id($_GET['oid']);
	}
	checkOrganization();
	saveOperRecordSave('部门管理','删除部门');
	baseJosn(array(),'删除成功');
}
//From: Dism·taobao·com
?>