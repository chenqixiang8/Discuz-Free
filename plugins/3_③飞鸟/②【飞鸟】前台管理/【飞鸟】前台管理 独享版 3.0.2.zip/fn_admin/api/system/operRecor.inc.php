<?php

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
header("Content-type: text/html; charset=utf-8");
if($_GET['op'] == 'list'){//列表
	$res = C::t('#fn_admin#fn_admin_oper_record')->fetch_all_by_list(array('userId'=>$_GET['userId'],'project'=>$_GET['project'],'model'=>$_GET['model'],'createTimeStart'=>$_GET['createTimeStart'],'createTimeEnd'=>$_GET['createTimeEnd']),'r.id',$_GET['page'] - 1,$_GET['limit'],true);
	foreach($res['list'] as $key => $val){
		$res['list'][$key]['dateline'] =  FormatDate($val['dateline'],'Y-m-d H:i');
	}
	baseJosn($res['list'],'',0, $res['count']);
}else if($_GET['op'] == 'save'){
	$item = C::t('#fn_admin#fn_admin_oper_record')->fetch_by_id($postData['id']);
	$data['name'] = addslashes(strip_tags($postData['name']));
	$data['code'] = addslashes(strip_tags($postData['code']));
	$data['comments'] = addslashes(strip_tags($postData['comments']));
	if($item['id']){
		C::t('#fn_admin#fn_admin_oper_record')->update($data,$item['id']);
		baseJosn(array(),'更新成功');
	}else{
		$data['dateline'] = time();
		C::t('#fn_admin#fn_admin_oper_record')->insert($data);
		baseJosn(array(),'更新成功');
	}
}else if($_GET['op'] == 'del'){
	if($_GET['rid']){
		C::t('#fn_admin#fn_admin_oper_record')->delete_by_id($_GET['rid']);
	}else if($_GET['day']){
		C::t('#fn_admin#fn_admin_oper_record')->delete_by_day($_GET['day']);
	}
	baseJosn(array(),'删除成功');
}
//From: Dism·taobao·com
?>