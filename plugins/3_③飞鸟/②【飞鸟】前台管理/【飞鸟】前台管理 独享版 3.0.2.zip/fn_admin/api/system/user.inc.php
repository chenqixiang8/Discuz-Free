<?php

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
header("Content-type: text/html; charset=utf-8");
if($_GET['op'] == 'menu'){
	$menuIds = array();
	foreach(C::t('#fn_admin#fn_admin_role_menu')->fetch_all_by_list(array('roleId'=>$user['roleId']),0,500) as $key => $val){
		$menuIds[] = $val['menuId'];
	}
	if($menuIds){
		$menu = $menus = $authorities = array();
		$res = C::t('#fn_admin#fn_admin_menu')->fetch_all_by_list(array('ids'=>$menuIds),'m.sortNumber',0,500);
		foreach($res['list'] as $key => $val){
			$val['hide'] = (int)$val['hide'];
			if(!$val['type']){
				$menu[$val['id']] = $val;
			}else if($val['type'] == 1){
				$authorities[] = $val['authority'];
			}
		}
	    foreach($menu as $val){
			if(isset($menu[$val['parentId']])){
				$menu[$val['parentId']]['children'][] = &$menu[$val['id']];
			}else{
				$menus[] = &$menu[$val['id']];
			}
		}
	}
	$user['authorities'] = $authorities;
	baseJosn($menus,'','','',$user);
}else if($_GET['op'] == 'userList'){
	$res = C::t('#fn_admin#fn_admin_staff')->fetch_all_by_list(array(),'a.id',$_GET['page'] - 1,$_GET['limit'],true);
	$data = array();
	foreach($res['list'] as $key => $val){
		$data[$key]['value'] = $val['id'];
		$data[$key]['title'] = $val['name'];
	}
	baseJosn($data,'',0, $res['count']);
}else if($_GET['op'] == 'list'){//列表
	$res = C::t('#fn_admin#fn_admin_staff')->fetch_all_by_list(array('name'=>$_GET['name'],'username'=>$_GET['username'],'sex'=>$_GET['sex'],'roleId'=>$_GET['roleId'],'organizationId'=>$_GET['organizationId']),'a.id',$_GET['page'] - 1,$_GET['limit'],true);
	foreach($res['list'] as $key => $val){
		$res['list'][$key]['dateline'] =  FormatDate($val['dateline'],'Y-m-d H:i');
		$res['list'][$key]['birthDay'] =  $val['birthDay'] ? date('Y-m-d',$val['birthDay']) : '';
		$res['list'][$key]['entryTime'] =  $val['entryTime'] ? date('Y-m-d',$val['entryTime']) : '';
		$res['list'][$key]['departureTime'] =  $val['departureTime'] ? date('Y-m-d',$val['departureTime']) : '';
		$res['list'][$key]['sexName'] =  $Fn_Admin->Config['LangVar']['sex_arr'][$val['sex']];
		$res['list'][$key]['sex'] = (int)$val['sex'];
		$res['list'][$key]['state'] = (int)$val['state'];
	}
	baseJosn($res['list'],'',0, $res['count']);
}else if($_GET['op'] == 'save'){
	$item = C::t('#fn_admin#fn_admin_staff')->fetch_by_id($postData['id']);
	//$data['bbsUid'] = intval($postData['bbsUid']);
	//$member = DB::fetch_first('SELECT username FROM '.DB::table('common_member').' where uid = '.$data['bbsUid']);
	//$data['username'] = addslashes(strip_tags($member['username']));
	$data['username'] = addslashes(strip_tags($postData['username']));
	$data['name'] = addslashes(strip_tags($postData['name']));
	$data['phone'] = addslashes(strip_tags($postData['phone']));
	$data['wx'] = addslashes(strip_tags($postData['wx']));
	$data['avatar'] = addslashes(strip_tags($postData['avatar']));
	$data['introduction'] = addslashes(strip_tags($postData['introduction']));
	$data['position'] = addslashes(strip_tags($postData['position']));
	$data['idCard'] = addslashes(strip_tags($postData['idCard']));
	$data['birthDay'] = $postData['birthDay'] ? strtotime($postData['birthDay']) : '';
	$data['entryTime'] = $postData['entryTime'] ? strtotime($postData['entryTime']) : '';
	$data['departureTime'] = $postData['departureTime'] ? strtotime($postData['departureTime']) : '';
	$data['sex'] = intval($postData['sex']);
	$data['roleId'] = intval($postData['roleId']);
	$data['organizationId'] = intval($postData['organizationId']);
	if($item['id']){
		C::t('#fn_admin#fn_admin_staff')->update($data,$item['id']);
		saveOperRecordSave('员工管理','更新员工');
	}else{
		$data['code'] = substr(uniqid(rand()), -6);
		$data['password'] = md5(md5(addslashes(strip_tags($postData['password'] ? $postData['password'] : '123456'))).$data['code']);
		$data['dateline'] = time();
		C::t('#fn_admin#fn_admin_staff')->insert($data);
		saveOperRecordSave('员工管理','更新员工');
	}
	baseJosn(array(),'更新成功');
}else if($_GET['op'] == 'del'){
	if($_GET['userId']){
		C::t('#fn_admin#fn_admin_staff')->delete_by_id($_GET['userId']);
	}
	saveOperRecordSave('员工管理','删除员工');
	baseJosn(array(),'删除成功');
}else if($_GET['op'] == 'state' && $_GET['userId']){
	C::t('#fn_admin#fn_admin_staff')->update(array('state'=>intval($_GET['state'])),$_GET['userId']);
	saveOperRecordSave('员工管理','修改员工状态');
	baseJosn(array(),'更新成功');
}else if($_GET['op'] == 'password'){
	if($user['password'] != md5(md5($postData['oldPsw']).$user['code'])){
		baseJosn(array(),'旧密码不正确','201');
	}else if($user['password'] == md5(md5($postData['newPsw']).$user['code'])){
		baseJosn(array(),'新密码和旧密码一致','202');
	}
	$data['code'] = substr(uniqid(rand()), -6);
	$data['password'] = md5(md5(addslashes(strip_tags($postData['newPsw']))).$data['code']);
	C::t('#fn_admin#fn_admin_staff')->update($data,$user['id']);
	saveOperRecordSave('员工管理','修改员工密码');
	baseJosn(array(),'修改成功，请重新登录');
}
//From: Dism·taobao·com
?>