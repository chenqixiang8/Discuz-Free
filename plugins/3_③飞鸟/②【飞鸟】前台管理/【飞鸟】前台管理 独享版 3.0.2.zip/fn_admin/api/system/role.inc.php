<?php

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
header("Content-type: text/html; charset=utf-8");
if($_GET['op'] == 'list'){//列表
	$res = C::t('#fn_admin#fn_admin_role')->fetch_all_by_list(array('name'=>$_GET['name'],'code'=>$_GET['code'],'comments'=>$_GET['comments']),'r.id',$_GET['page'] - 1,$_GET['limit'],true);
	foreach($res['list'] as $key => $val){
		$res['list'][$key]['dateline'] =  FormatDate($val['dateline'],'Y-m-d H:i');
	}
	baseJosn($res['list'],'',0, $res['count']);
}else if($_GET['op'] == 'save'){
	$item = C::t('#fn_admin#fn_admin_role')->fetch_by_id($postData['id']);
	$data['name'] = addslashes(strip_tags($postData['name']));
	$data['code'] = addslashes(strip_tags($postData['code']));
	$data['comments'] = addslashes(strip_tags($postData['comments']));
	if($item['id']){
		C::t('#fn_admin#fn_admin_role')->update($data,$item['id']);
		saveOperRecordSave('角色管理','更新角色');
		baseJosn(array(),'更新成功');
	}else{
		$data['dateline'] = time();
		C::t('#fn_admin#fn_admin_role')->insert($data);
		saveOperRecordSave('角色管理','添加角色');
		baseJosn(array(),'更新成功');
	}
}else if($_GET['op'] == 'del'){
	if($_GET['rid']){
		C::t('#fn_admin#fn_admin_role')->delete_by_id($_GET['rid']);
	}
	saveOperRecordSave('角色管理','删除角色');
	baseJosn(array(),'删除成功');
}else if($_GET['op'] == 'menu' && $_GET['roleId']){//列表
	$res = C::t('#fn_admin#fn_admin_menu')->fetch_all_by_list(array(),'m.sortNumber',0,500,true);
	$data = array();
	foreach($res['list'] as $key => $val){
		$data[$key] = $val;
		$data[$key]['checked'] = C::t('#fn_admin#fn_admin_role_menu')->fetch_by_roleId_menuId($_GET['roleId'],$val['id']) ? true : null;
	}
	baseJosn($data);
}else if($_GET['op'] == 'menu_save' && $_GET['roleId']){//列表
	
	C::t('#fn_admin#fn_admin_role_menu')->delete_by_id(intval($_GET['roleId']));
	foreach($postData as $key => $val){
		C::t('#fn_admin#fn_admin_role_menu')->insert(array('roleId'=>intval($_GET['roleId']),'menuId'=>intval($val)));
	}
	saveOperRecordSave('角色管理','分配权限');
	baseJosn(array(),'更新成功');
}
//From: Dism·taobao·com
?>