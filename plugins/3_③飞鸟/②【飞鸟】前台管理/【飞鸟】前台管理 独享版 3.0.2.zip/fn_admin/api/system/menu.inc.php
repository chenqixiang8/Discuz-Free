<?php

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
header("Content-type: text/html; charset=utf-8");
if($_GET['op'] == 'list'){//列表
	$res = C::t('#fn_admin#fn_admin_menu')->fetch_all_by_list(array('title'=>$_GET['title'],'path'=>$_GET['path'],'authority'=>$_GET['authority']),'m.sortNumber',0,500,true);
	foreach($res['list'] as $key => $val){
		$res['list'][$key]['dateline'] =  FormatDate($val['dateline'],'Y-m-d H:i');
		$res['list'][$key]['type'] = (int)$val['type'];
		$res['list'][$key]['sortNumber'] = (int)$val['sortNumber'];
		$res['list'][$key]['openType'] = (int)$val['openType'];
		$res['list'][$key]['hide'] = (int)$val['hide'];
		$res['list'][$key]['parentId'] = $val['parentId'] ? $val['parentId'] : null;
	}
	baseJosn($res['list'],'',0, $res['count']);
}else if($_GET['op'] == 'save'){
	$item = C::t('#fn_admin#fn_admin_menu')->fetch_by_id($postData['id']);
	$data['title'] = addslashes(strip_tags($postData['title']));
	$data['path'] = addslashes(strip_tags($postData['path']));
	$data['component'] = addslashes(strip_tags($postData['component']));
	$data['authority'] = addslashes(strip_tags($postData['authority']));
	$data['target'] = addslashes(strip_tags($postData['target']));
	$data['icon'] = addslashes(strip_tags($postData['icon']));
	$data['color'] = addslashes(strip_tags($postData['color']));
	$data['type'] = intval($postData['type']);
	$data['openType'] = intval($postData['openType']);
	$data['parentId'] = intval($postData['parentId']);
	$data['sortNumber'] = intval($postData['sortNumber']);
	$data['hide'] = intval($postData['hide']);
	if($item['id']){
		C::t('#fn_admin#fn_admin_menu')->update($data,$item['id']);
		saveOperRecordSave('菜单管理','更新菜单');
	}else{
		$data['dateline'] = time();
		C::t('#fn_admin#fn_admin_menu')->insert($data);
		saveOperRecordSave('菜单管理','添加菜单');
	}
	baseJosn(array(),'更新成功');
}else if($_GET['op'] == 'del'){
	if($_GET['mid']){
		C::t('#fn_admin#fn_admin_menu')->delete_by_id($_GET['mid']);
	}
	saveOperRecordSave('菜单管理','删除菜单');
	baseJosn(array(),'删除成功');
}
//From: Dism·taobao·com
?>