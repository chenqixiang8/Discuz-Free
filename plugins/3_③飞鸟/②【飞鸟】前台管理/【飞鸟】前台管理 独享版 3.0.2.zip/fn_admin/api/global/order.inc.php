<?php

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
header("Content-type: text/html; charset=utf-8");
if($_GET['op'] == 'init'){
	$data['sourceList'] = vueFormArray($Fn_Admin->Config['LangVar']['order_source_arr']);
	$data['paymentList'] = vueFormArray($Fn_Admin->Config['LangVar']['order_pay_type_arr']);
	$data['payActionList'] = vueFormArray(lang('plugin/'.$_GET['plugin'], 'pay_action_arr'));
	baseJosn($data);
}else if($_GET['op'] == 'list'){//列表
	$res = C::t('#fn_admin#fn_pay_log')->fetch_all_by_list(array('uid'=>$_GET['uid'],'source'=>$_GET['source'],'pay_action'=>$_GET['pay_action'],'state'=>$_GET['state'],'refund'=>$_GET['refund'],'pubid'=>$_GET['pubid'],'payment_type'=>$_GET['payment_type'],'staff_id'=>$_GET['staff_id'],'createTimeStart'=>$_GET['createTimeStart'],'createTimeEnd'=>$_GET['createTimeEnd'],'min_money'=>$_GET['min_money'],'max_money'=>$_GET['max_money']),'o.dateline',$_GET['page'] - 1,$_GET['limit'],true);
	foreach($res['list'] as $key => $val){
		$res['list'][$key]['dateline'] = date('Y-m-d H:i',$val['dateline']);
		$res['list'][$key]['pay_time'] = $val['pay_time'] ? date('Y-m-d H:i',$val['pay_time']) : '';
		$res['list'][$key]['content'] = stripslashes($val['content']);
		$res['list'][$key]['payment_type_text'] = $Fn_Admin->Config['LangVar']['order_pay_type_arr'][$val['payment_type']];
		$res['list'][$key]['source_text'] = $Fn_Admin->Config['LangVar']['order_source_arr'][$val['source']];
		$res['list'][$key]['isRefund'] = $val['pubid'] && $val['state'] && !$val['refund'] && in_array($val['payment_type'],array('app','wx')) ? true : null;
	}
	baseJosn($res['list'],'',0, $res['count']);
}else if($_GET['op'] == 'save'){
	$data['uid'] = intval($postData['uid']);
	$Member = DB::fetch_first('SELECT username FROM '.DB::table('common_member').' where uid = '.$data['uid']);
	$data['username'] = addslashes(strip_tags($Member['username']));
	$data['staff_id'] = intval($postData['staff_id']);
	$data['pubid'] = date("YmdHis").rand(10000,9999999);
	$data['content'] = addslashes(strip_tags($postData['content']));
	$data['money'] = addslashes(strip_tags($postData['money']));
	$data['source'] = addslashes(strip_tags($postData['source']));
	$data['payment_type'] = addslashes(strip_tags($postData['payment_type']));
	$data['pay_time'] = $postData['pay_time'] ? strtotime($postData['pay_time']) : '';
	$data['dateline'] = time();
	$data['state'] = 1;
	C::t('#fn_admin#fn_pay_log')->insert($data);
	saveOperRecordSave('订单管理','添加订单');
	baseJosn(array(),'添加成功');
}else if($_GET['op'] == 'del'){
	if($_GET['oid']){
		C::t('#fn_admin#fn_pay_log')->delete_by_id($_GET['oid']);
	}else if(in_array($_GET['state'], array('0'))){
		$array = array(
			'state'=>$_GET['state']
		);
		$array = $_GET['source'] != 'fn_global' && $_GET['source'] ? array_merge($array,array('source'=>$_GET['source'])) : $array;
		C::t('#fn_admin#fn_pay_log')->delete_by_state($array);
	}
	saveOperRecordSave('订单管理','删除订单');
	baseJosn(array(),'删除成功');
}else if($_GET['op'] == 'refund'){
	if($_GET['oid']){
		$item = C::t('#fn_admin#fn_pay_log')->fetch_by_id($_GET['oid']);
		if($item['pubid'] && $item['state'] && !$item['refund'] && in_array($item['payment_type'],array('app','wx'))){
			$refundNo = md5(uniqid());
			$refund = false;
			if($item['payment_type'] == 'app'){//APP退款
				if($_G['cache']['plugin']['fn_assembly']['AppType'] == 1){//马甲退款
					@require_once libfile('class/magapp','plugin/fn_assembly');
					$MagApp = new MagApp();
					$result = $MagApp->GetMagAccountTransfer($item['uid'],$item['money'],$item['content'],$refundNo);
				}else if($_G['cache']['plugin']['fn_assembly']['AppType'] == 2){//千帆退款
					@require_once libfile('class/qfapp','plugin/fn_assembly');
					$QHApp = new QHApp();
					$result = $QHApp->GetBalanceAdd($item['uid'],$item['money']);
				}
				if($result['state'] == 200){
					$refund = true;
				}else{
					$msg = $result['msg'];
				}
			}else if($item['payment_type'] == 'wx'){//微信退款
				require_once("source/plugin/fn_pay/class/WxPay.Class.php");
				$WxPay = new WxPay;
				$result = $WxPay->DoRefund($item['money'],$item['money'],$refundNo,$item['pubid']);
				if($Result['return_code'] == 'SUCCESS'){
					$refund = true;
				}else{
					$msg = diconv($result['return_msg'],'UTF-8',CHARSET);
				}
			}
			if($refund){
				C::t('#fn_admin#fn_pay_log')->update(array('refund'=>1,'refund_pubid'=>$refundNo,'refund_dateline'=>time()),$_GET['oid']);
				saveOperRecordSave('订单管理','订单退款');
				baseJosn(array(),'退款成功');
			}else{
				baseJosn(array(),'退款失败，失败原因：'.$msg,201);
			}
		}else{
			baseJosn(array(),'退款功能仅支持APP支付和微信支付才可退款',202);
		}
	}else{
		baseJosn(array(),'订单未支付，不支持退款',203);
	}
}
//From: Dism·taobao·com
?>