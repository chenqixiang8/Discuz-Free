<?php

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
header("Content-type: text/html; charset=utf-8");
if($_GET['op'] == 'init'){
	$data['sourceList'] = vueFormArray($Fn_Admin->Config['LangVar']['order_source_arr']);
	baseJosn($data);
}else if($_GET['op'] == 'list'){//列表
	$res = C::t('#fn_admin#fn_send_sms_log')->fetch_all_by_list(array('keyword'=>$_GET['keyword'],'source'=>$_GET['source'],'state'=>$_GET['state']),'l.id',$_GET['page'] - 1,$_GET['limit'],true);
	foreach($res['list'] as $key => $val){
		$res['list'][$key]['dateline'] =  FormatDate($val['dateline'],'Y-m-d H:i');
		$res['list'][$key]['type_text'] =  $Fn_Admin->Config['LangVar']['ApiTypeArray'][$val['type']];
		$res['list'][$key]['state_text'] =  $Fn_Admin->Config['LangVar']['SendSmsState'][$val['state']];
		$res['list'][$key]['source_text'] = $Fn_Admin->Config['LangVar']['order_source_arr'][$val['source']];
	}
	baseJosn($res['list'],'',0, $res['count']);
}else if($_GET['op'] == 'del'){
	
	if($_GET['day']){
		C::t('#fn_admin#fn_send_sms_log')->delete_by_day($_GET['day']);
	}else if($_GET['ids']){
		foreach(array_filter(explode(",",$_GET['ids'])) as $k => $v) {
			C::t('#fn_admin#fn_send_sms_log')->delete_by_id($v);
		}
	}
	saveOperRecordSave('短信管理','删除短信');
	baseJosn();
}
//From: Dism·taobao·com
?>