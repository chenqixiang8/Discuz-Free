<?php

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
header("Content-type: text/html; charset=utf-8");
if($_GET['op'] == 'list'){//列表
	$res = C::t('#fn_admin#fn_wx_resource')->fetch_all_by_list(array('plugin'=>$_GET['plugin'],'title'=>$_GET['title'],'merge'=>$_GET['merge'],'display'=>$_GET['display']),'r.id',$_GET['page'] - 1,$_GET['limit'],true);
	foreach($res['list'] as $key => $val){
		$res['list'][$key]['dateline'] =  FormatDate($val['dateline'],'Y-m-d H:i');
		$res['list'][$key]['updateline'] =  FormatDate($val['updateline'],'Y-m-d H:i');
	}
	baseJosn($res['list'],'',0, $res['count']);
}else if($_GET['op'] == 'save'){
	$item = C::t('#fn_admin#fn_wx_resource')->fetch_by_id($postData['id']);

	$data['plugin'] = $_GET['plugin'];
	$data['merge'] = intval($postData['merge']);
	$data['merge_id'] = addslashes(strip_tags($postData['merge_id']));
	$data['display'] = intval($postData['display']);
	$data['title'] = addslashes(strip_tags($postData['title']));
	$data['pic'] = addslashes(strip_tags($postData['pic']));
	$data['desc'] = addslashes(strip_tags($postData['desc']));
	$data['content'] = addslashes(strip_tags($postData['content']));
	$data['url'] = addslashes(strip_tags($postData['url']));
	$data['display'] = intval($postData['display']);

	if($item['id']){
		C::t('#fn_admin#fn_wx_resource')->update($data,$item['id']);
		saveOperRecordSave('公众号素材管理','更新素材');
	}else{
		$data['dateline'] = $data['updateline'] = time();
		C::t('#fn_admin#fn_wx_resource')->insert($data);
		saveOperRecordSave('公众号素材管理','添加素材');
		
	}
	baseJosn(array(),'更新成功');
}else if($_GET['op'] == 'del'){
	if($_GET['rid']){
		C::t('#fn_admin#fn_wx_resource')->delete_by_id($_GET['rid']);
	}else if($_GET['ids']){
		foreach(array_filter(explode(",",$_GET['ids'])) as $k => $v) {
			C::t('#fn_admin#fn_wx_resource')->delete_by_id($v);
		}
	}
	saveOperRecordSave('公众号素材管理','删除素材');
	baseJosn(array(),'删除成功');
}else if($_GET['op'] == 'refresh' && $_GET['rid']){
	C::t('#fn_admin#fn_wx_resource')->update(array('updateline'=>time()),$_GET['rid']);
	saveOperRecordSave('公众号素材管理','刷新素材');
	baseJosn(array(),'刷新成功');
}else if($_GET['op'] == 'display' && $_GET['rid']){
	C::t('#fn_admin#fn_wx_resource')->update(array('display'=>$_GET['value']),$_GET['rid']);
	saveOperRecordSave('公众号素材管理','显示/不显示素材');
	baseJosn(array(),'更新成功');
}
//From: Dism·taobao·com
?>