<?php

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
header("Content-type: text/html; charset=utf-8");
if($_GET['op'] == 'list'){//列表
	$res = C::t('#fn_fenlei#fn_search')->fetch_all_by_list(array('keyword'=>$_GET['keyword']),$_GET['page'] - 1,$_GET['limit'],$_GET['sort'] ? $_GET['sort'] : 'updateline',$_GET['order'] ? $_GET['order'] : 'desc',true);
	foreach($res['list'] as $key => $val){
		$res['list'][$key]['dateline'] =  FormatDate($val['dateline'],'Y-m-d H:i');
		$res['list'][$key]['updateline'] =  FormatDate($val['updateline'],'Y-m-d H:i');
	}
	baseJosn($res['list'],'',0, $res['count']);
}else if($_GET['op'] == 'del'){
	if($_GET['sid']){
		C::t('#fn_fenlei#fn_search')->delete_by_id($_GET['sid']);
	}else if($_GET['ids']){
		foreach(array_filter(explode(",",$_GET['ids'])) as $k => $v) {
			C::t('#fn_fenlei#fn_search')->delete_by_id($v);
		}
	}
	saveOperRecordSave('搜索统计','删除搜索统计');
	baseJosn(array(),'删除成功');
}
//From: Dism·taobao·com
?>