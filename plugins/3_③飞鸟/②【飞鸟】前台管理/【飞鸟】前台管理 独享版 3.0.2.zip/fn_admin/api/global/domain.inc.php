<?php

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
header("Content-type: text/html; charset=utf-8");
@require_once libfile('function/cache');
$cache_name = 'fn_global_domain';
loadcache($cache_name);
$setting = $_G['cache'][$cache_name];

if($_GET['op'] == 'check'){
	if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_admin/mod/global/domain_setting.php')){
		$data['check'] = true;
	}else{
		$data['check'] = false;
		$data['tips'] = str_replace(array('{url}'),array('https://dism.taobao.com/?@fn_admin.plugin.87730'),lang('plugin/fn_admin','NoPayDomainTips'));
	}
	baseJosn($data);
}else if($_GET['op'] == 'list'){
	$data = array();
	foreach($setting as $key => $val){
		$val['id'] = $key;
		$data[] = $val;
	}
	baseJosn($data);
}else if($_GET['op'] == 'save'){//列表
	$data['domain'] = addslashes(strip_tags($postData['domain']));
	$data['plugin'] = addslashes(strip_tags($postData['plugin']));
	$data['siteurl'] = addslashes(strip_tags($postData['siteurl']));
	if($postData['id']){
		$setting[$postData['id']] = $data;
		saveOperRecordSave('域名绑定管理','更新域名绑定');
	}else{
		end($setting);
		$id = key($setting) + 1;
		$setting[$id] = $data;
		saveOperRecordSave('域名绑定管理','添加域名绑定');
	}
	fsavecache($setting);
	baseJosn(array(),'更新成功');
}else if($_GET['op'] == 'del'){
	if($_GET['oid']){
		$newSetting = array();
		foreach($setting as $k => $v) {
			if($k != $_GET['oid']){
				$newSetting[$k] = $v;
			}
		}
		fsavecache($newSetting);
		saveOperRecordSave('域名绑定管理','删除域名绑定');
		baseJosn(array(),'删除成功');
	}else{
		baseJosn(array(),'删除失败');
	}
}

function fsavecache($setting){
	global $cache_name;
	savecache($cache_name,$setting);
	writetocache($cache_name, getcachevars(array($cache_name => $setting)));
	$files = array(DISCUZ_ROOT.'/index.php',DISCUZ_ROOT.'/forum.php');
	foreach($files as $f) {
		$code = readFileCode($f);
		if(!empty($code) && strpos(strtolower($code),'domain_check.php') === false){
			$find = array(
				'/<\?php/si',
			);
			$replace = array(
				"<?php\r\n@include 'source/plugin/fn_admin/mod/global/domain_check.php';",
			);
			$code = preg_replace($find, $replace, $code);
			if(!empty($code)) {
				writeFileCode($f, $code);
			}
		}
	}
}
function readFileCode($f) {
	if (file_exists($f) === false) {
		return '';
	}

	$fp = fopen($f, 'r');
	$code = '';
	while (!feof($fp)) {
		$code .= fgets($fp, 4096);
	}
	fclose($fp);
	
	return $code;
}

function writeFileCode($f, $code) {
	$fp = fopen($f, 'w');
	fwrite($fp, $code);
	fclose($fp);
}
//From: Dism·taobao·com
?>