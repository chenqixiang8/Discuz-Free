<?php

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
header("Content-type: text/html; charset=utf-8");
if($_GET['op'] == 'list'){//列表
	$res = C::t('#fn_fenlei#fn_region')->fetch_all_by_list();
	$list = array();
	foreach($res as $key => $val){
		$list[] = $val;
	}
	baseJosn($list);
}else if($_GET['op'] == 'save'){
	$allRegion = C::t('#fn_fenlei#fn_region')->fetch_all_by_list();
	$item = C::t('#fn_fenlei#fn_region')->fetch_by_id($postData['id']);
	
	$data['father_id'] = intval($postData['father_id']);
	$data['name'] = $data['bname'] = addslashes(strip_tags($postData['name']));
	$data['display'] = intval($postData['display']);
	$data['displayorder'] = intval($postData['displayorder']);
	$data['level'] = $data['father_id'] ? $allRegion[$data['father_id']]['level'] + 1 : '';

	if($item['id']){
		C::t('#fn_fenlei#fn_region')->update($data,$item['id']);
		saveOperRecordSave('区域管理','更新区域');
	}else{
		$data['dateline'] = time();
		C::t('#fn_fenlei#fn_region')->insert($data);
		saveOperRecordSave('区域管理','添加区域');
	}
	checkRegion();
	baseJosn(array(),'更新成功');
}else if($_GET['op'] == 'del'){
	if($_GET['rid']){
		C::t('#fn_fenlei#fn_region')->delete_by_id($_GET['rid']);
	}
	saveOperRecordSave('区域管理','删除区域');
	baseJosn(array(),'删除成功');
}
function checkRegion(){
	$check = array();
	foreach(C::t('#fn_fenlei#fn_region')->fetch_all_by_list() as $val){
		$check[$val['id']] = $val;
		$check[$val['id']]['sonid'] = C::t('#fn_fenlei#fn_region')->all_list_id($val['id'],array('display'=>1));
	}
	savecache('fn_region',$check);
}
//From: Dism·taobao·com
?>