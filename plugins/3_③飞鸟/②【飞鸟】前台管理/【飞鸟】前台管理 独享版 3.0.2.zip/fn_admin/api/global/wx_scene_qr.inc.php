<?php

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
header("Content-type: text/html; charset=utf-8");
$plugin['identifier'] = $_GET['plugin'];
loadcache($plugin['identifier'].'_setting');
$common_setting = (array)$_G['cache'][$plugin['identifier'].'_setting'];
$wxAppid = $common_setting['WxAppid'];
$wxSecret = $common_setting['WxSecret'];

if($_GET['op'] == 'list'){//列表
	$res = C::t('#fn_admin#fn_wx_scene_qr')->fetch_all_by_list(array('plugin'=>$_GET['plugin'],'title'=>$_GET['title']),'q.id',$_GET['page'] - 1,$_GET['limit'],true);
	foreach($res['list'] as $key => $val){
		$res['list'][$key]['dateline'] =  FormatDate($val['dateline'],'Y-m-d H:i');
	}
	baseJosn($res['list'],'',0, $res['count']);
}else if($_GET['op'] == 'save'){
	if(!$wxAppid && !$wxSecret){
		baseJosn(array(),lang('plugin/fn_assembly', 'wsq_menu_at_error'),201);
	}
	$item = C::t('#fn_admin#fn_wx_scene_qr')->fetch_by_id($postData['id']);
	$data['plugin'] = $_GET['plugin'];
	$data['qrcode_type'] = intval($postData['qrcode_type']);
	$data['title'] = addslashes(strip_tags($postData['title']));
	$data['pic'] = addslashes(strip_tags($postData['pic']));
	$data['desc'] = addslashes(strip_tags($postData['desc']));
	$data['url'] = addslashes(strip_tags($postData['url']));
	$data['qrcode_date'] = intval($postData['qrcode_date']) > 30 ? 30 : intval($postData['qrcode_date']);

	@require_once libfile('class/wechat','plugin/fn_assembly');
	$wechatClient = new Fn_WeChatClient($wxAppid,$wxSecret);
	$data['qrcode'] = $wechatClient->getQrcodeImgUrlByTicket($wechatClient->getQrcodeTicket(array('scene_str'=>'fn_scene_qr____view____'.intval($id),'expire'=>$data['qrcode_type'] == 1 ? $data['qrcode_date'] * 60 * 60 * 24 : '')));

	if($item['id']){
		C::t('#fn_admin#fn_wx_scene_qr')->update($data,$item['id']);
		saveOperRecordSave('公众号场景二维码','更新场景二维码');
	}else{
		$data['dateline'] = time();
		C::t('#fn_admin#fn_wx_scene_qr')->insert($data);
		saveOperRecordSave('公众号场景二维码','添加场景二维码');
	}
	baseJosn(array(),'更新成功');
}else if($_GET['op'] == 'del'){
	if($_GET['qid']){
		C::t('#fn_admin#fn_wx_scene_qr')->delete_by_id($_GET['qid']);
	}else if($_GET['ids']){
		foreach(array_filter(explode(",",$_GET['ids'])) as $k => $v) {
			C::t('#fn_admin#fn_wx_scene_qr')->delete_by_id($v);
		}
	}
	saveOperRecordSave('公众号场景二维码','删除素材');
	baseJosn(array(),'删除成功');
}else if($_GET['op'] == 'refresh' && $_GET['qid']){
	$item = C::t('#fn_admin#fn_wx_scene_qr')->fetch_by_id($_GET['qid']);

	@require_once libfile('class/wechat','plugin/fn_assembly');
	$wechatClient = new Fn_WeChatClient($wxAppid,$wxSecret);
	$data['qrcode'] = $wechatClient->getQrcodeImgUrlByTicket($wechatClient->getQrcodeTicket(array('scene_str'=>'fn_scene_qr____view____'.intval($_GET['qid']),'expire'=>$item['qrcode_type'] == 1 ? $item['qrcode_date'] * 60 * 60 * 24 : '')));

	C::t('#fn_admin#fn_wx_scene_qr')->update($data,$item['id']);
	baseJosn(array(),'刷新成功');
}
//From: Dism·taobao·com
?>