<?php

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
header("Content-type: text/html; charset=utf-8");
@require_once libfile('function/cache');
$plugin['identifier'] = $_GET['plugin'];
loadcache($plugin['identifier'].'_wechat_response');
loadcache($plugin['identifier'].'_setting');
$response = $_G['cache'][$plugin['identifier'].'_wechat_response'];
$common_setting = (array)$_G['cache'][$plugin['identifier'].'_setting'];
$wxAppid = $common_setting['WxAppid'];
$wxSecret = $common_setting['WxSecret'];

if($_GET['op'] == 'init'){//列表
	$list = array();
	foreach($response['text'] as $key => $val){
		$val['__index'] = $key + 1;
		$list[] = $val;
	}
	baseJosn(array('subscribe'=>$response['subscribe'],'unmatched'=>$response['unmatched'],'list'=>$list));
}else if($_GET['op'] == 'save'){
	$key = $postData['__index'] - 1;
	$data['keyword'] = $postData['keyword'];
	$data['response'] = $postData['response'];
	if($response['text'][$key]){
		$response['text'][$key] = $data;
		saveOperRecordSave('公众号回复管理','更新关键词回复');
	}else{
		$response['text'][] = $data;
		saveOperRecordSave('公众号回复管理','添加关键词回复');
	}
	$query = array(
	    'subscribe' => $response['subscribe'],
	    'text' => array(),
	);
	foreach($response['text'] as $value) {
		$query['text'][$value['keyword']] = $value['response'];
	}
	$response['query'] = $query;
	savecache($plugin['identifier'].'_wechat_response',$response);
	baseJosn(array(),'更新成功');
}else if($_GET['op'] == 'del' && $_GET['rid']){
	unset($response['text'][$_GET['rid'] - 1]);
	$query = array(
	    'subscribe' => $response['subscribe'],
	    'text' => array(),
	);
	foreach($response['text'] as $value) {
		$query['text'][$value['keyword']] = $value['response'];
	}
	$response['query'] = $query;
	savecache($plugin['identifier'].'_wechat_response',$response);
	saveOperRecordSave('公众号回复管理','删除关键词回复');
	baseJosn(array(),'删除成功');
}else if($_GET['op'] == 'response'){
	$response['subscribe'] = $postData['subscribe'];
	$response['unmatched'] = $postData['unmatched'];
	savecache($plugin['identifier'].'_wechat_response',$response);
	saveOperRecordSave('公众号回复管理','更新关注/未匹配回复内容');
	baseJosn(array(),'更新成功');
}
//From: Dism·taobao·com
?>