<?php

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
header("Content-type: text/html; charset=utf-8");
if($_GET['op'] == 'init'){
	$data['channelList'] = vueFormArray($Fn_Admin->Config['LangVar']['search_channel_arr']);
	$data['sourceList'] = vueFormArray($Fn_Admin->Config['LangVar']['search_source_arr']);
	baseJosn($data);
}else if($_GET['op'] == 'list'){//列表
	$res = C::t('#fn_fenlei#fn_search_log')->fetch_all_by_list(array('keyword'=>$_GET['keyword'],'channel'=>$_GET['channel'],'search_id'=>$_GET['search_id'],'source'=>$_GET['source'],'uid'=>$_GET['uid'],'ip'=>$_GET['ip']),$_GET['page'] - 1,$_GET['limit'],$_GET['sort'] ? $_GET['sort'] : 'dateline',$_GET['order'] ? $_GET['order'] : 'desc',true);
	foreach($res['list'] as $key => $val){
		if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_login/config.php')){
			$member = C::t('#fn_login#fn_user')->fetch_by_uid($val['uid']);
		}
		if(!$member){
			if($Config['PluginVar']['AppType'] == 2){
				$member = DB::fetch_first('SELECT phone FROM '.DB::table('phonebind').' where uid = '.$val['uid']);
			}else if($Config['PluginVar']['AppType'] == 1 && file_exists(DISCUZ_ROOT.'./source/plugin/fn_login/config.php')){
				$member = DB::fetch_first("SELECT * FROM " .DB::table($fn_login->magConfig['user_mobile_relations'])." WHERE ".$fn_login->magConfig['user_mobile_relations_userid']."=%s", array($val['uid']));
			}else{
				$member = DB::fetch_first('SELECT mobile as phone FROM '.DB::table('common_member_profile').' where uid = '.$val['uid']);
			}
		}
		$res['list'][$key]['dateline'] =  FormatDate($val['dateline'],'Y-m-d H:i');
		$res['list'][$key]['phone'] = $member['phone'];
		$res['list'][$key]['channel_text'] = $Fn_Admin->Config['LangVar']['search_channel_arr'][$val['channel']];
		$res['list'][$key]['source_text'] = $Fn_Admin->Config['LangVar']['search_source_arr'][$val['source']];
	}
	baseJosn($res['list'],'',0, $res['count']);
}else if($_GET['op'] == 'del'){
	if($_GET['sid']){
		C::t('#fn_fenlei#fn_search_log')->delete_by_id($_GET['sid']);
	}else if($_GET['ids']){
		foreach(array_filter(explode(",",$_GET['ids'])) as $k => $v) {
			C::t('#fn_fenlei#fn_search_log')->delete_by_id($v);
		}
	}
	saveOperRecordSave('搜索记录','删除搜索记录');
	baseJosn(array(),'删除成功');
}
//From: Dism·taobao·com
?>