<?php

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
header("Content-type: text/html; charset=utf-8");

if($_GET['op'] == 'list'){//列表
	$res = C::t('#fn_admin#fn_html_temp')->fetch_all_by_list(array('plugin'=>$_GET['plugin'],'classId'=>$_GET['classId']),$_GET['page'] - 1,$_GET['limit'],$_GET['sort'],$_GET['order'],true);
	$list = array();
	foreach($res['list'] as $key => $val){
		$val['temp'] = stripslashes($val['temp']);
		$list[] = $val;
	}
	baseJosn($list,'',0, $res['count']);
}else if($_GET['op'] == 'save'){
	$item = C::t('#fn_admin#fn_html_temp')->fetch_by_id($postData['id']);

	$data['plugin'] = addslashes(strip_tags($_GET['plugin'] ? $_GET['plugin'] : $postData['plugin']));
	$data['classId'] = addslashes(strip_tags($_GET['classId'] ? $_GET['classId'] : $postData['classId']));
	$data['title'] = addslashes(strip_tags($postData['title']));
	$data['temp'] = addslashes($postData['temp']);
	$data['displayorder'] = intval($postData['displayorder']);
	if($item['id']){
		C::t('#fn_admin#fn_html_temp')->update($data,$item['id']);
		saveOperRecordSave('微信导出模板管理','更新模板');
	}else{
		C::t('#fn_admin#fn_html_temp')->insert($data);
		saveOperRecordSave('微信导出模板管理','添加模板');
	}
	baseJosn(array(),'更新成功');
}else if($_GET['op'] == 'del'){
	if($_GET['tid']){
		C::t('#fn_admin#fn_html_temp')->delete_by_id($_GET['tid']);
	}else if($_GET['ids']){
		foreach(array_filter(explode(",",$_GET['ids'])) as $k => $v) {
			C::t('#fn_admin#fn_html_temp')->delete_by_id($v);
		}
	}
	saveOperRecordSave('微信导出模板管理','删除模板');
	baseJosn(array(),'删除成功');
}
//From: Dism·taobao·com
?>