<?php

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
header("Content-type: text/html; charset=utf-8");
if($_GET['op'] == 'init'){
	$data = array();
	$data['action'] = vueFormArray($Fn_Admin->Config['LangVar']['ActionArray']);
	baseJosn($data);
}else if($_GET['op'] == 'list'){//列表
	$res = C::t('#fn_admin#fn_admin_do_log')->fetch_all_by_list(array('uid'=>$_GET['uid'],'source'=>$_GET['source'],'action'=>$_GET['action']),'l.id',$_GET['page'] - 1,$_GET['limit'],true);
	foreach($res['list'] as $key => $val){
		$res['list'][$key]['dateline'] =  FormatDate($val['dateline'],'Y-m-d H:i');
		$res['list'][$key]['action_text'] =  $Fn_Admin->Config['LangVar']['ActionArray'][$val['action']];
	}
	baseJosn($res['list'],'',0, $res['count']);
}else if($_GET['op'] == 'del'){
	if($_GET['day']){
		C::t('#fn_admin#fn_admin_do_log')->delete_by_day($_GET['day']);
	}else if($_GET['ids']){
		foreach(array_filter(explode(",",$_GET['ids'])) as $k => $v) {
			C::t('#fn_admin#fn_admin_do_log')->delete_by_id($v);
		}
	}else if($_GET['oid']){
		C::t('#fn_admin#fn_admin_do_log')->delete_by_id($_GET['oid']);
	}
	baseJosn();
}
//From: Dism·taobao·com
?>