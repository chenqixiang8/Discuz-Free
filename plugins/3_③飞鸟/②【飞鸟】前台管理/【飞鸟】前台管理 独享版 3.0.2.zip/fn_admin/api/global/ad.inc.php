<?php

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
header("Content-type: text/html; charset=utf-8");
if($_GET['op'] == 'list'){//列表
	$res = $adList = array();
	if($_GET['plugin'] == 'fn_xiangqin'){
		$adList = array(
			'banner'=>'手机版首页横幅广告位',
			'navBottom'=>'手机版首页导航底部广告位',
			'hobbyBottom'=>'手机版详情页兴趣爱好底部广告位'
		);
	}
	foreach($adList as $key => $val){
		$arr = array();
		$arr['classId'] = $arr['id'] = $key;
		$arr['title'] = diconv($val,mb_detect_encoding($val, array('ASCII','UTF-8','GB2312','GBK','BIG5')),CHARSET);
		$arr['plugin'] = $_GET['plugin'];
		$res[] = $arr;
	}
	baseJosn($res);
}else if($_GET['op'] == 'adList'){//列表
	$res = C::t('#fn_admin#fn_ad')->fetch_all_by_list(array('plugin'=>$_GET['plugin'],'classId'=>$_GET['classId'],'display'=>$_GET['display']),$_GET['page'] - 1,$_GET['limit'],$_GET['sort'],$_GET['order'],true);
	foreach($res['list'] as $key => $val){
		$res['list'][$key]['dateline'] =  FormatDate($val['dateline'],'Y-m-d H:i');
	}
	check($_GET['plugin']);
	baseJosn($res['list'],'',0, $res['count']);
}else if($_GET['op'] == 'save'){
	$item = C::t('#fn_admin#fn_ad')->fetch_by_id($postData['id']);

	$data['plugin'] = addslashes(strip_tags($_GET['plugin']));
	$data['classId'] = addslashes(strip_tags($_GET['classId']));
	$data['title'] = addslashes(strip_tags($postData['title']));
	$data['pic'] = addslashes(strip_tags($postData['pic']));
	$data['url'] = addslashes(strip_tags($postData['url']));
	$data['displayorder'] = intval($postData['displayorder']);
	if($item['id']){
		C::t('#fn_admin#fn_ad')->update($data,$item['id']);
		saveOperRecordSave('广告管理','更新广告');
	}else{
		$data['dateline'] = time();
		C::t('#fn_admin#fn_ad')->insert($data);
		saveOperRecordSave('广告管理','更新广告');
	}
	baseJosn(array(),'更新成功');
}else if($_GET['op'] == 'del'){
	if($_GET['aid']){
		C::t('#fn_admin#fn_ad')->delete_by_id($_GET['aid']);
	}else if($_GET['ids']){
		foreach(array_filter(explode(",",$_GET['ids'])) as $k => $v) {
			C::t('#fn_admin#fn_ad')->delete_by_id($v);
		}
	}
	saveOperRecordSave('广告管理','删除公告');
	baseJosn(array(),'删除成功');
}else if($_GET['op'] == 'display' && $_GET['aid']){
	C::t('#fn_admin#fn_ad')->update(array('display'=>$_GET['value']),$_GET['aid']);
	saveOperRecordSave('广告管理','显示/不显示广告');
	baseJosn(array(),'更新成功');
}
function check($plugin){
	$check = array();
	$res = C::t('#fn_admin#fn_ad')->fetch_all_by_list(array('plugin'=>$plugin,'display'=>1),0,100,$_GET['sort'],$_GET['order'],true);
	foreach($res['list'] as $val){
		$check[$val['classId']][] = $val;
	}
	savecache('fn_ad_'.$plugin,$check);
}
//From: Dism·taobao·com
?>