<?php

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
header("Content-type: text/html; charset=utf-8");
$plugin['identifier'] = $_GET['plugin'];
loadcache($plugin['identifier'].'_setting');
$common_setting = (array)$_G['cache'][$plugin['identifier'].'_setting'];
$wxAppid = $common_setting['WxAppid'];
$wxSecret = $common_setting['WxSecret'];

if($_GET['op'] == 'list'){//列表
	$res = C::t('#fn_admin#fn_wx_menu')->fetch_all_by_list(array('plugin'=>$_GET['plugin'],'title'=>$_GET['title']));
	$list = array();
	foreach($res as $key => $val){
		$list[] = $val;
	}
	baseJosn($list);
}else if($_GET['op'] == 'save'){

	if(!$wxAppid && !$wxSecret){
		baseJosn(array(),'您需要填写微信AppId后才能使用此功能',201);
	}

	$menuList = C::t('#fn_admin#fn_wx_menu')->fetch_all_by_list(array('plugin'=>$_GET['plugin']));
	$item = C::t('#fn_admin#fn_wx_menu')->fetch_by_id($postData['id']);
	$data['father_id'] = intval($postData['father_id']);
	$data['plugin'] = addslashes(strip_tags($_GET['plugin']));
	$data['title'] = addslashes(strip_tags($postData['title']));
	$data['url'] = addslashes(strip_tags($postData['url']));
	$data['appid'] = addslashes(strip_tags($postData['appid']));
	$data['pagepath'] = addslashes(strip_tags($postData['pagepath']));
	$data['type'] = intval($postData['type']);
	$data['displayorder'] = intval($postData['displayorder']);
	if($menuList[$postData['father_id']]['father_id']){
		baseJosn(array(),'公众号支持二级菜单，不支持三级菜单',202);
	}else if(count($menuList[$postData['father_id']]['children']) > 4 && !$item){
		baseJosn(array(),'二级菜单最多只能有 5 个',203);
	}

	$i = 0;
	foreach($menuList as $key => $val){
		if(!$val['father_id']){
			$i++;
		}
	}
	if($i > 2 && !$item){
		baseJosn(array(),'一级菜单最多只能有 3 个',204);
	}

	if($item['id']){
		C::t('#fn_admin#fn_wx_menu')->update($data,$item['id']);
		saveOperRecordSave('公众号菜单管理','更新公众号菜单');
	}else{
		C::t('#fn_admin#fn_wx_menu')->insert($data);
		saveOperRecordSave('公众号菜单管理','添加公众号菜单');
	}
	baseJosn(array(),'更新成功');
}else if($_GET['op'] == 'release'){
	if(!$wxAppid && !$wxSecret){
		baseJosn(array(),'您需要填写微信AppId后才能使用此功能',201);
	}
	$menuList = C::t('#fn_admin#fn_wx_menu')->fetch_all_by_list(array('plugin'=>$_GET['plugin']));
	if(!$menuList) {
		baseJosn(array(),'菜单数据错误，无法发布',201);
	}
	$menus = array();
	foreach($menuList as $val){
		if(isset($menuList[$val['father_id']])){
			$menuList[$val['father_id']]['childrenArr'][] = &$menuList[$val['id']];
		}else{
			$menus[] = &$menuList[$val['id']];
		}
	}
	foreach($menus as $val) {
		if(!$val['childrenArr']){
			if(!$val['title']) {
				baseJosn(array(),'菜单中存在“菜单标题”为空的项目，无法发布',201);
			}
			if(!$val['url'] && $val['type'] == 1) {
				baseJosn(array(),'菜单中存在“网页链接”为空的项目，无法发布',202);
			}else if(!$val['appid'] && !$val['pagepath'] && $val['type'] == 2){
				baseJosn(array(),'菜单中存在“小程序APPID/路径”为空的项目，无法发布',203);
			}
			$item = array(
				'type' => in_array($val['type'],array('1','2')) ? ($val['type'] == 2 ? 'miniprogram' : 'view') : 'click',
				'name' => convertname($val['title']),
				$val['type'] == 1 ? 'url' : 'key' => $val['url'],
				'appid' => $val['appid'],
				'pagepath' => $val['pagepath']
			);
			$pubMenu['button'][] = $item;
		}else{
			if(!$val['title']) {
				baseJosn(array(),'菜单中存在“菜单标题”为空的项目，无法发布',201);
			}
			$subMenu = array();
			foreach($val['childrenArr'] as $sub_button) {
				if(!$sub_button['title']) {
					baseJosn(array(),'菜单中存在“菜单标题”为空的项目，无法发布',201);
				}
				if(!$sub_button['url'] && $sub_button['type'] == 1) {
					baseJosn(array(),'菜单中存在“网页链接”为空的项目，无法发布',202);
				}else if(!$sub_button['appid'] && !$sub_button['pagepath'] && $sub_button['type'] == 2){
					baseJosn(array(),'菜单中存在“小程序APPID/路径”为空的项目，无法发布',203);
				}
				$item = array(
					'type' => in_array($sub_button['type'],array('1','2')) ? ($sub_button['type'] == 2 ? 'miniprogram' : 'view') : 'click',
					'name' => convertname($sub_button['title']),
					$sub_button['type'] == 1 ? 'url' : 'key' => $sub_button['url'],
					'appid' => $sub_button['appid'],
					'pagepath' => $sub_button['pagepath']
				);
				$subMenu[] = $item;
			}
			$item = array(
				'name' => convertname($val['title']),
				'sub_button' => $subMenu
			);
			$pubMenu['button'][] = $item;
		}
	}
	@require_once libfile('class/wechat','plugin/fn_assembly');
	$wechatClient = new Fn_WeChatClient($wxAppid,$wxSecret);
	if($wechatClient->setMenu($pubMenu)) {
		baseJosn(array(),'菜单已成功更新到您的微信公众号中');
	} else {
		baseJosn(array(),str_replace(array('{errno}'),array($wechatClient->error()),'菜单发布失败（{errno}）'),201);
	}
}else if($_GET['op'] == 'del'){
	if($_GET['mid']){
		C::t('#fn_admin#fn_wx_menu')->delete_by_id($_GET['mid']);
	}
	saveOperRecordSave('公众号菜单管理','删除公众号菜单');
	baseJosn(array(),'删除成功');
}
function convertname($str) {
	return urlencode(diconv($str, CHARSET, 'UTF-8'));
}
//From: Dism·taobao·com
?>