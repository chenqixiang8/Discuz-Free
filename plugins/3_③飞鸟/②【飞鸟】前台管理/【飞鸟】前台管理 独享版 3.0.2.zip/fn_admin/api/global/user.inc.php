<?php

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
header("Content-type: text/html; charset=utf-8");
if($_GET['op'] == 'list'){//列表
	$res = C::t('#fn_login#fn_user')->fetch_all_by_list(array('uid'=>$_GET['uid'],'phone'=>$_GET['phone'],'openid'=>$_GET['openid'],'unionid'=>$_GET['unionid']),$_GET['page'] - 1,$_GET['limit'],$_GET['sort'] ? $_GET['sort'] : 'dateline',$_GET['order'] ? $_GET['order'] : 'desc',true);
	foreach($res['list'] as $key => $val){
		$region = C::t('#fn_fenlei#fn_region')->fetch_by_id($val['regionid']);
		$res['list'][$key]['dateline'] =  FormatDate($val['dateline'],'Y-m-d H:i');
		$res['list'][$key]['last_login_dateline'] =  FormatDate($val['last_login_dateline'],'Y-m-d H:i');
		$res['list'][$key]['name'] = $region['name'];
	}
	baseJosn($res['list'],'',0, $res['count']);
}
//From: Dism·taobao·com
?>