<?php

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
header("Content-type: text/html; charset=utf-8");
@require_once ('common.php');
if($_GET['op'] == 'init'){
	$data['auditStateList'] = vueFormArray($fn_xiangqin->setting['lang']['audit_state_arr']);
	$data['typeList'] = vueFormArray($fn_xiangqin->setting['lang']['user_verify_arr']);
	baseJosn($data);
}else if($_GET['op'] == 'list'){//列表
	$res = C::t('#fn_xiangqin#fn_love_verify')->fetch_all_by_list(array('vid'=>$_GET['vid'],'type'=>$_GET['type'],'audit_state'=>$_GET['audit_state']),'dateline',$_GET['page'] - 1,$_GET['limit'],true);
	foreach($res['list'] as $key => $val){
		$content = '';
		foreach (dunserialize($val['content']) as $v) {
			$content .= $v['title'].': '.$v['content'].'<br>';
		}
		$res['list'][$key]['userInfo'] = $fn_xiangqin->getView($val['vid']);
		$res['list'][$key]['dateline'] =  FormatDate($val['dateline'],'Y-m-d H:i');
		$res['list'][$key]['updateline'] =  FormatDate($val['updateline'],'Y-m-d H:i');
		$res['list'][$key]['audit_state_text'] = $fn_xiangqin->setting['lang']['audit_state_arr'][$val['audit_state']];
		$res['list'][$key]['type_text'] = $fn_xiangqin->setting['lang']['user_verify_arr'][$val['type']];
		$res['list'][$key]['content'] = $content;
	}
	baseJosn($res['list'],'',0, $res['count']);
}else if($_GET['op'] == 'del'){
	if($_GET['vid']){
		C::t('#fn_xiangqin#fn_love_verify')->delete_by_id($_GET['vid']);
	}else if($_GET['ids']){
		foreach(array_filter(explode(",",$_GET['ids'])) as $k => $v) {
			C::t('#fn_xiangqin#fn_love_verify')->delete_by_id($v);
		}
	}
	saveOperRecordSave('认证记录管理','删除认证记录');
	baseJosn(array(),'删除成功');
}else if($_GET['op'] == 'auditState'){
	$verifyArr = array('1'=>'real_verify','2'=>'education_verify','3'=>'vehicle_verify','4'=>'house_verify');
	$verifyUrlArr = array('1'=>'cert','2'=>'certedu','3'=>'certcar','4'=>'certhouse');
	$item = C::t('#fn_xiangqin#fn_love_verify')->fetch_by_id($postData['id']);
	$pushUrl = $fn_xiangqin->getUrl('user',array('form'=>$verifyUrlArr[$item['type']]));
	$noticeMsg = str_replace(array('[--type--]','[--audit_state--]'),array($fn_xiangqin->setting['lang']['user_verify_arr'][$item['type']],$fn_xiangqin->setting['lang']['audit_state_arr'][$postData['audit_state']]),$fn_xiangqin->setting['lang']['verifyNoticeMsg']);
	if($postData['audit_state'] == 1){
		C::t('#fn_xiangqin#fn_love_user')->update(array($verifyArr[$item['type']]=>1),$item['vid']);
		$fn_xiangqin->getAuditNotice($item['vid'],$postData['audit_state'],$pushUrl,$noticeMsg);
	}else if($postData['audit_state'] == 3){
		$fn_xiangqin->getAuditNotice($item['vid'],$postData['audit_state'],$pushUrl,$noticeMsg);
	}
	C::t('#fn_xiangqin#fn_love_verify')->update(array('audit_state'=>$postData['audit_state'],'refuse_tips'=>$postData['audit_state'] == 3 ? addslashes(strip_tags($postData['refuse_tips'])) : ''),$postData['id']);
	saveOperRecordSave('认证记录管理','审核认证记录');
	baseJosn(array(),'审核成功');
}
//From: Dism·taobao·com
?>