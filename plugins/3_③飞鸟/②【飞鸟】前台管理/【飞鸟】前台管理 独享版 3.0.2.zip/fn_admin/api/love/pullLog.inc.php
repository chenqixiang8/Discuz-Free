<?php

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
header("Content-type: text/html; charset=utf-8");
@require_once ('common.php');

if($_GET['op'] == 'init'){
	$data['stateList'] = vueFormArray($fn_xiangqin->setting['lang']['pull_state_arr']);
	baseJosn($data);
}else if($_GET['op'] == 'list'){//列表
	$res = C::t('#fn_xiangqin#fn_love_user_pull_log')->fetch_all_by_list(array('vid'=>$_GET['vid'],'love_vid'=>$_GET['love_vid'],'state'=>$_GET['state']),'dateline',$_GET['page'] - 1,$_GET['limit'],true);
	foreach($res['list'] as $key => $val){
		$res['list'][$key]['userInfo'] = $fn_xiangqin->getView($val['vid']);
		$res['list'][$key]['heUserInfo'] = $fn_xiangqin->getView($val['love_vid']);
		$res['list'][$key]['pull_dateline'] = date('Y-m-d H:i',$val['pull_dateline']);
		$res['list'][$key]['dateline'] = date('Y-m-d H:i',$val['dateline']);
		$res['list'][$key]['state_text'] = $fn_xiangqin->setting['lang']['pull_state_arr'][$val['state']];
	}
	baseJosn($res['list'],'',0,$res['count']);
}else if($_GET['op'] == 'save'){
	$item = C::t('#fn_xiangqin#fn_love_user_pull_log')->fetch_by_id($postData['id']);
	$data['vid'] = intval($postData['vid']);
	$data['love_vid'] = intval($postData['love_vid']);
	$data['remarks'] = addslashes(strip_tags($postData['remarks']));
	$data['state'] = intval($postData['state']);
	$data['pull_dateline'] = $postData['pull_dateline'] ? strtotime($postData['pull_dateline']) : '';
	$userItem = C::t('#fn_xiangqin#fn_love_user')->fetch_by_id($data['vid']);
	if($postData['pull_number'] && $userItem['pull'] >= $postData['pull_number']){
		$loveUser = C::t('#fn_xiangqin#fn_love_user')->fetch_by_id($data['love_vid']);
		C::t('#fn_xiangqin#fn_love_user')->update_by_count($data['vid'],'pull',intval($postData['pull_number']),'-');
		C::t('#fn_xiangqin#fn_love_con_log')->insert(array('uid'=>intval($userItem['uid']),'vid'=>intval($data['vid']),'love_vid'=>intval($data['love_vid']),'pull'=>intval($postData['pull_number']),'event_type'=>6,'content'=>str_replace(array('[--name--]','[--love_name--]'),array($userItem['name'],$loveUser['name']),$fn_xiangqin->setting['lang']['con_log_content']['pull']),'dateline'=>time()));
	}
	if($item['id']){
		C::t('#fn_xiangqin#fn_love_user_pull_log')->update($data,$item['id']);
		saveOperRecordSave('牵线记录管理','更新牵线记录');
	}else{
		$data['dateline'] = time();
		C::t('#fn_xiangqin#fn_love_user_pull_log')->insert($data);
		saveOperRecordSave('牵线记录管理','添加牵线记录');
	}
	baseJosn(array(),'更新成功');
}else if($_GET['op'] == 'del'){
	if($_GET['vid']){
		C::t('#fn_xiangqin#fn_love_user_pull_log')->delete_by_id($_GET['vid']);
	}else if($_GET['ids']){
		foreach(array_filter(explode(",",$_GET['ids'])) as $k => $v) {
			C::t('#fn_xiangqin#fn_love_user_pull_log')->delete_by_id($v);
		}
	}
	saveOperRecordSave('牵线记录管理','删除牵线记录');
	baseJosn(array(),'删除成功');
}
//From: Dism·taobao·com
?>