<?php

@require_once (DISCUZ_ROOT.'./source/plugin/fn_xiangqin/config.php');