<?php

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
header("Content-type: text/html; charset=utf-8");
@require_once ('common.php');

if($_GET['op'] == 'list'){//列表
	$res = C::t('#fn_xiangqin#fn_love_user_far_single')->fetch_all_by_list(array('vid'=>$_GET['vid']),'dateline',$_GET['page'] - 1,$_GET['limit'],true);
	foreach($res['list'] as $key => $val){
		$res['list'][$key]['userInfo'] = $fn_xiangqin->getView($val['vid']);
		$res['list'][$key]['dateline'] =  FormatDate($val['dateline'],'Y-m-d H:i');
		$res['list'][$key]['updateline'] =  FormatDate($val['updateline'],'Y-m-d H:i');
		$res['list'][$key]['album'] = array_filter(explode(",",$val['album']));
	}
	baseJosn($res['list'],'',0, $res['count']);
}else if($_GET['op'] == 'save'){
	$item = C::t('#fn_xiangqin#fn_love_user_far_single')->fetch_by_id($postData['id']);
	$data['album'] = is_array($postData['album']) && isset($postData['album']) ? implode(',',$postData['album']) : '';
	$data['vid'] = intval($postData['vid']);
	$data['title'] = addslashes(strip_tags($postData['title']));
	$data['content'] = addslashes(strip_tags($postData['content']));
	if($item['id']){
		C::t('#fn_xiangqin#fn_love_user_far_single')->update($data,$item['id']);
		saveOperRecordSave('脱单记录管理','更新脱单记录');
	}else{
		$data['display'] = 1;
		$data['updateline'] = $data['dateline'] = time();
		C::t('#fn_xiangqin#fn_love_user_far_single')->insert($data);
		saveOperRecordSave('脱单记录管理','添加脱单记录');
	}
	baseJosn(array(),'更新成功');
}else if($_GET['op'] == 'del'){
	if($_GET['vid']){
		C::t('#fn_xiangqin#fn_love_user_far_single')->delete_by_id($_GET['vid']);
	}else if($_GET['ids']){
		foreach(array_filter(explode(",",$_GET['ids'])) as $k => $v) {
			C::t('#fn_xiangqin#fn_love_user_far_single')->delete_by_id($v);
		}
	}
	saveOperRecordSave('脱单记录管理','删除脱单记录');
	baseJosn(array(),'删除成功');
}else if($_GET['op'] == 'display' && $_GET['vid']){
	C::t('#fn_xiangqin#fn_love_user_far_single')->update(array('display'=>intval($_GET['value'])),$_GET['vid']);
	saveOperRecordSave('脱单记录管理','修改显示状态');
	baseJosn(array(),'更新成功');
}else if($_GET['op'] == 'refresh' && $_GET['vid']){
	C::t('#fn_xiangqin#fn_love_user_far_single')->update(array('updateline'=>time()),$_GET['vid']);
	saveOperRecordSave('脱单记录管理','刷新更新时间');
	baseJosn(array(),'刷新成功');
}
//From: Dism·taobao·com
?>