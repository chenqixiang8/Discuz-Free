<?php

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
header("Content-type: text/html; charset=utf-8");
@require_once ('common.php');
@require_once libfile('function/cache');
$rewriteName = 'fn_xiangqin_rewrite';
loadcache($rewriteName);
$rewriteSetting = $_G['cache'][$rewriteName];
$rewrite = array(
	'index' => array('rule'=>'love','title'=>'首页','sign'=>''),
	'list_hot' => array('rule'=>'love/hot','title'=>'红娘推荐列表','sign'=>''),
	'list_vip' => array('rule'=>'love/vip','title'=>'会员推荐列表','sign'=>''),
	'list_cert' => array('rule'=>'love/cert','title'=>'实名制列表','sign'=>''),
	'list_offline' => array('rule'=>'love/offline','title'=>'到店列表','sign'=>''),
	'list_far_single' => array('rule'=>'love/farsingle','title'=>'脱单列表','sign'=>''),
	'list_pull' => array('rule'=>'love/pull','title'=>'牵线列表','sign'=>''),
	'activity_list' => array('rule'=>'love/activity_list','title'=>'活动列表','sign'=>''),
	'poster' => array('rule'=>'love/poster/{vid}.htm','title'=>'海报','sign'=>'{aid}'),
	'mat' => array('rule'=>'love/mat','title'=>'红娘','sign'=>''),
	'payment' => array('rule'=>'love/payment','title'=>'会员/钥匙/金币购买','sign'=>''),
	'view' => array('rule'=>'love/view/{vid}.htm','title'=>'详情页','sign'=>'{vid}'),
	'activity_view' => array('rule'=>'love/activity/{aid}.htm','title'=>'活动详情页','sign'=>'{aid}'),
	'user' => array('rule'=>'love/user','title'=>'会员中心','sign'=>''),
	'user_admin' => array('rule'=>'love/user/admin','title'=>'管理用户','sign'=>''),
	'user_info' => array('rule'=>'love/user/info','title'=>'添加/编辑资料','sign'=>''),
	'user_cert' => array('rule'=>'love/user/cert','title'=>'实名认证','sign'=>''),
	'user_certedu' => array('rule'=>'love/user/certedu','title'=>'学历认证','sign'=>''),
	'user_certcar' => array('rule'=>'love/user/certcar','title'=>'车认证','sign'=>''),
	'user_certhouse' => array('rule'=>'love/user/certhouse','title'=>'房认证','sign'=>''),
	'user_gift' => array('rule'=>'love/user/gift','title'=>'我的礼物','sign'=>''),
	'user_service' => array('rule'=>'love/user/service','title'=>'服务条款','sign'=>'')
);
if($_GET['op'] == 'check'){
	$data['check'] = file_exists(DISCUZ_ROOT.'./source/plugin/fn_xiangqin/rewrite.php') ? true : false;
	$data['checkTips'] = !$data['check'] ? str_replace(array('{url}'),array('https://dism.taobao.com/plugins/fn_xiangqin.90430.html'),lang('plugin/fn_assembly','NoPayRewriteTips')) : '';
	baseJosn($data);
}else if($_GET['op'] == 'list'){//列表
	$list = array();
	foreach($rewrite as $key => $val){
		$rule = $rewriteSetting[$key]['rule'] ? $rewriteSetting[$key]['rule'] : $val['rule'];
		$val['id'] = $key;
		$val['rule'] = $rule;
		$val['available'] = $rewriteSetting[$key]['available'] ? $rewriteSetting[$key]['available'] : 0;
		$list[] = $val;
	}
	baseJosn($list);
}else if($_GET['op'] == 'save'){
	$rewriteList = array();
	$i = 0;
	foreach($rewrite as $key => $val){
		$rewriteList[$key]['rule'] = $postData['rule'][$i];
		$rewriteList[$key]['available'] = $postData['available'][$i] ? 1 : 0;
		$i++;
	}
	savecache($rewriteName,$rewriteList);
	saveOperRecordSave('伪静态设置','保存伪静态');
	baseJosn(array(),'更新成功');
}else if($_GET['op'] == 'rule'){
	$rule = array();
	$rewrite = $rewriteSetting;
	$rewritedata = array(
		'rulesearch' => array(
			'index' => $rewrite['index']['rule'],
			'list_hot' => $rewrite['list_hot']['rule'],
			'list_vip' => $rewrite['list_vip']['rule'],
			'list_cert' => $rewrite['list_cert']['rule'],
			'list_offline' => $rewrite['list_offline']['rule'],
			'list_far_single' => $rewrite['list_far_single']['rule'],
			'list_pull' => $rewrite['list_pull']['rule'],
			'activity_list' => $rewrite['activity_list']['rule'],
			'poster' => $rewrite['poster']['rule'],
			'mat' => $rewrite['mat']['rule'],
			'payment' => $rewrite['payment']['rule'],
			'view' => $rewrite['view']['rule'],
			'activity_view' => $rewrite['activity_view']['rule'],
			'user' => $rewrite['user']['rule'],
			'user_admin' => $rewrite['user_admin']['rule'],
			'user_info' => $rewrite['user_info']['rule'],
			'user_cert' => $rewrite['user_cert']['rule'],
			'user_certedu' => $rewrite['user_certedu']['rule'],
			'user_certcar' => $rewrite['user_certcar']['rule'],
			'user_certhouse' => $rewrite['user_certhouse']['rule'],
			'user_gift' => $rewrite['user_gift']['rule'],
			'user_service' => $rewrite['user_service']['rule']
		),
		'rulereplace' => array(
			'index' => 'plugin.php?id=fn_xiangqin',
			'list_hot' => 'plugin.php?id=fn_xiangqin&mod=list_hot',
			'list_vip' => 'plugin.php?id=fn_xiangqin&mod=list_vip',
			'list_cert' => 'plugin.php?id=fn_xiangqin&mod=list_cert',
			'list_offline' => 'plugin.php?id=fn_xiangqin&mod=list_offline',
			'list_far_single' => 'plugin.php?id=fn_xiangqin&mod=list_far_single',
			'list_pull' => 'plugin.php?id=fn_xiangqin&mod=list_pull',
			'activity_list' => 'plugin.php?id=fn_xiangqin&mod=activity&form=list',
			'poster' => 'plugin.php?id=fn_xiangqin&mod=poster&vid={vid}',
			'mat' => 'plugin.php?id=fn_xiangqin&mod=mat',
			'payment' => 'plugin.php?id=fn_xiangqin&mod=payment',
			'view' => 'plugin.php?id=fn_xiangqin&mod=view&vid={vid}',
			'activity_view' => 'plugin.php?id=fn_xiangqin&mod=activity&form=view&aid={aid}',
			'user' => 'plugin.php?id=fn_xiangqin&mod=user',
			'user_admin' => 'plugin.php?id=fn_xiangqin&mod=user&form=admin',
			'user_info' => 'plugin.php?id=fn_xiangqin&mod=user&form=info',
			'user_cert' => 'plugin.php?id=fn_xiangqin&mod=user&form=cert',
			'user_certedu' => 'plugin.php?id=fn_xiangqin&mod=user&form=certedu',
			'user_certcar' => 'plugin.php?id=fn_xiangqin&mod=user&form=certcar',
			'user_certhouse' => 'plugin.php?id=fn_xiangqin&mod=user&form=certhouse',
			'user_gift' => 'plugin.php?id=fn_xiangqin&mod=user&form=gift',
			'user_service' => 'plugin.php?id=fn_xiangqin&mod=user&form=service'
		),
		'rulevars' => array(
			'index' => array(),
			'list_hot' => array(),
			'list_vip' => array(),
			'list_cert' => array(),
			'list_offline' => array(),
			'list_pull' => array(),
			'list_far_single' => array(),
			'activity_list' => array(),
			'poster' => array('{vid}' => '([0-9]+)'),
			'mat' => array(),
			'payment' => array(),
			'view' => array('{vid}' => '([0-9]+)'),
			'activity_view' => array('{aid}' => '([0-9]+)'),
			'user' => array(),
			'user_admin' => array(),
			'user_info' => array(),
			'user_cert' => array(),
			'user_certedu' => array(),
			'user_certcar' => array(),
			'user_certhouse' => array(),
			'user_gift' => array(),
			'user_service' => array()
		)
	);
	$rule['{apache1}'] = $rule['{apache2}'] = $rule['{iis}'] = $rule['{iis7}'] = $rule['{zeus}'] = $rule['{nginx}'] = '';
	foreach($rewritedata['rulesearch'] as $k => $v) {
		
		if(!$rewrite[$k]['available']) {
			continue;
		}
		
		$v = !$_G['setting']['rewriterule'][$k] ? $v : $_G['setting']['rewriterule'][$k];
		
		$pvmaxv = count($rewritedata['rulevars'][$k]) + 2;
		$vkeys = array_keys($rewritedata['rulevars'][$k]);
		
		$rewritedata['rulereplace'][$k] = pvsort($vkeys, $v, $rewritedata['rulereplace'][$k]);
		
		$v = str_replace($vkeys, $rewritedata['rulevars'][$k], addcslashes($v, '?*+^$.[]()|'));
		$rule['{apache1}'] .= 'RewriteCond %{QUERY_STRING} ^(.*)$'."\n".'RewriteRule ^(.*/)*'.$v.'$ $1/'.pvadd($rewritedata['rulereplace'][$k])."&%1\n";
		if($k != 'forum_archiver') {
			$rule['{apache2}'] .= 'RewriteCond %{QUERY_STRING} ^(.*)$'."\n".'RewriteRule ^'.$v.'$ '.$rewritedata['rulereplace'][$k]."&%1\n";
		} else {
			$rule['{apache2}'] .= 'RewriteCond %{QUERY_STRING} ^(.*)$'."\n".'RewriteRule ^archiver/'.$v.'$ archiver/'.$rewritedata['rulereplace'][$k]."&%1\n";
		}
		$rule['{iis}'] .= 'RewriteRule ^(.*)/'.$v.'(\?(.*))*$ $1/'.addcslashes(pvadd($rewritedata['rulereplace'][$k]).'&$'.($pvmaxv + 1), '.?')."\n";
		$rule['{iis7}'] .= '&lt;rule name="'.$k.'"&gt;'."\n\t".'&lt;match url="^(.*/)*'.str_replace('\.', '.', $v).'\?*(.*)$" /&gt;'."\n\t".'&lt;action type="Rewrite" url="{R:1}/'.str_replace(array('&', 'page\%3D'), array('&amp;amp;', 'page%3D'), addcslashes(pvadd($rewritedata['rulereplace'][$k], 1).'&{R:'.$pvmaxv.'}', '?')).'" /&gt;'."\n".'&lt;/rule&gt;'."\n";
		$rule['{zeus}'] .= 'match URL into $ with ^(.*)/'.$v.'\?*(.*)$'."\n".'if matched then'."\n\t".'set URL = $1/'.pvadd($rewritedata['rulereplace'][$k]).'&$'.$pvmaxv."\nendif\n";
		$rule['{nginx}'] .= 'rewrite ^([^\.]*)/'.$v.'$ $1/'.stripslashes(pvadd($rewritedata['rulereplace'][$k]))." last;\n";
	}
	if(!$rule['{nginx}']){
		baseJosn('','伪静态未开启',201);
	}else{
		baseJosn(str_replace(array_keys($rule), $rule, cplang('rewrite_message')));
	}
}

function pvsort($key, $v, $s) {
	$r = '/';
	$p = '';
	foreach($key as $k) {
		$r .= $p.preg_quote($k);
		$p = '|';
	}
	$r .= '/';
	preg_match_all($r, $v, $a);
	$a = $a[0];
	$a = array_flip($a);
	foreach($a as $key => $value) {
		$s = str_replace($key, '$'.($value + 1), $s);
	}
	return $s;
}

function pvadd($s, $t = 0) {
	$s = str_replace(array('$5', '$4', '$3', '$2', '$1'), array('~6', '~5', '~4', '~3', '~2'), $s);
	if(!$t) {
		return str_replace(array('~6', '~5', '~4', '~3', '~2'), array('$6', '$5', '$4', '$3', '$2'), $s);
	} else {
		return str_replace(array('~6', '~5', '~4', '~3', '~2'), array('{R:6}', '{R:5}', '{R:4}', '{R:3}', '{R:2}'), $s);
	}

}