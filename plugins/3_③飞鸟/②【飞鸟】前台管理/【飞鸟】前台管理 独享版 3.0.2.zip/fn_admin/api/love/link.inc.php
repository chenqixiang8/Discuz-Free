<?php

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
header("Content-type: text/html; charset=utf-8");
@require_once ('common.php');
$data = array(
	array('value'=>$fn_xiangqin->getUrl('index'),'title'=>'首页'),
	array('value'=>$_G['siteurl'].'plugin.php?id=fn_xiangqin&mod=index&app=1','title'=>'首页隐藏底部导航'),
	array('value'=>$fn_xiangqin->getUrl('list_hot'),'title'=>'红娘推荐列表'),
	array('value'=>$fn_xiangqin->getUrl('list_vip'),'title'=>'会员列表'),
	array('value'=>$fn_xiangqin->getUrl('list_cert'),'title'=>'实名列表'),
	array('value'=>$fn_xiangqin->getUrl('list_offline'),'title'=>'到店列表'),
	array('value'=>$fn_xiangqin->getUrl('list_far_single'),'title'=>'脱单列表'),
	array('value'=>$fn_xiangqin->getUrl('list_pull'),'title'=>'牵线列表'),
	array('value'=>$fn_xiangqin->getUrl('mat'),'title'=>'红娘列表'),
	array('value'=>$fn_xiangqin->getUrl('activity',array('form'=>'list')),'title'=>'活动列表'),
	array('value'=>$fn_xiangqin->getUrl('payment'),'title'=>'会员套餐购买'),
	array('value'=>$fn_xiangqin->getUrl('user'),'title'=>'会员中心'),
	array('value'=>$fn_xiangqin->getUrl('user',array('form'=>'info')),'title'=>'添加/编辑资料'),
	array('value'=>$fn_xiangqin->getUrl('user',array('form'=>'cert')),'title'=>'实名认证'),
	array('value'=>$fn_xiangqin->getUrl('user',array('form'=>'certedu')),'title'=>'学历认证'),
	array('value'=>$fn_xiangqin->getUrl('user',array('form'=>'certcar')),'title'=>'车认证'),
	array('value'=>$fn_xiangqin->getUrl('user',array('form'=>'certhouse')),'title'=>'房认证')
);
foreach($data as $key => $val){
	$data[$key]['title'] = diconv($val['title'],mb_detect_encoding($val['title'], array('ASCII','UTF-8','GB2312','GBK','BIG5')),CHARSET);
}
baseJosn($data);