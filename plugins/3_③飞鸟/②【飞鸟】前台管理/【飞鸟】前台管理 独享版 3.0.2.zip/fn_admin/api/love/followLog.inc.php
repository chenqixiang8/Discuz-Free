<?php

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
header("Content-type: text/html; charset=utf-8");
@require_once ('common.php');
if($_GET['op'] == 'init'){
	$data['eventYypeList'] = vueFormArray($fn_xiangqin->setting['lang']['event_type_arr']);
	baseJosn($data);
}else if($_GET['op'] == 'list'){//列表
	$res = C::t('#fn_xiangqin#fn_love_user_follow_log')->fetch_all_by_list(array('vid'=>$_GET['vid']),'dateline',$_GET['page'] - 1,$_GET['limit'],true);
	foreach($res['list'] as $key => $val){
		$mat = $fn_xiangqin->matList[$val['mat_id']];
		$res['list'][$key]['userInfo'] = $fn_xiangqin->getView($val['vid']);
		$res['list'][$key]['follow_dateline'] =  FormatDate($val['follow_dateline'],'Y-m-d H:i');
		$res['list'][$key]['dateline'] =  FormatDate($val['dateline'],'Y-m-d H:i');
		$res['list'][$key]['staffName'] = $mat['name'];
	}
	baseJosn($res['list'],'',0, $res['count']);
}else if($_GET['op'] == 'del'){
	if($_GET['lid']){
		C::t('#fn_xiangqin#fn_love_user_follow_log')->delete_by_id($_GET['lid']);
	}else if($_GET['ids']){
		foreach(array_filter(explode(",",$_GET['ids'])) as $k => $v) {
			C::t('#fn_xiangqin#fn_love_user_follow_log')->delete_by_id($v);
		}
	}
	saveOperRecordSave('访问记录','删除访问记录');
	baseJosn(array(),'删除成功');
}
//From: Dism·taobao·com
?>