<?php

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
header("Content-type: text/html; charset=utf-8");
@require_once ('common.php');
if($_GET['op'] == 'list'){//列表
	$res = C::t('#fn_xiangqin#fn_love_mat')->fetch_all_by_list();
	foreach($res as $key => $val){
		$staff = C::t('#fn_admin#fn_admin_staff')->fetch_by_id($val['staff_id']);
		$qrcode_url = $_G['siteurl'].'plugin.php?id=fn_assembly:qrcode&url='.base64_encode($_G['siteurl'].'plugin.php?id=fn_xiangqin:mat_openid&mat_id='.$val['id']);
		$res[$key]['qrcodeUrl'] = $qrcode_url;
		$res[$key]['count'] = C::t('#fn_xiangqin#fn_love_user')->first_by_count(' where u.mat_id = '.intval($val['id']));
		$res[$key]['staffName'] = $staff['name'];
	}
	baseJosn($res);
}else if($_GET['op'] == 'save'){
	$item = C::t('#fn_xiangqin#fn_love_mat')->fetch_by_id($postData['id']);
	$data['staff_id'] = intval($postData['staff_id']);
	$data['uid'] = intval($postData['uid']);
	$data['name'] = addslashes(strip_tags($postData['name']));
	$data['head_portrait'] = addslashes(strip_tags($postData['head_portrait']));
	$data['qrcode'] = addslashes(strip_tags($postData['qrcode']));
	$data['wx'] = addslashes(strip_tags($postData['wx']));
	$data['displayorder'] = intval($postData['displayorder']);
	
	$checkStaff = C::t('#fn_xiangqin#fn_love_mat')->fetch_by_staff_id($postData['staff_id']);
	if($checkStaff['id'] && $item['staff_id'] != $postData['staff_id']){
		baseJosn(array(),'员工已存在，请勿重复绑定','201');
	}

	if($item['id']){
		C::t('#fn_xiangqin#fn_love_mat')->update($data,$item['id']);
		saveOperRecordSave('红娘管理','更新红娘');
	}else{
		$data['display'] = 1;
		C::t('#fn_xiangqin#fn_love_mat')->insert($data);
		saveOperRecordSave('红娘管理','添加红娘');
	}
	$fn_xiangqin->getCheckMat();
	baseJosn(array(),'更新成功');
}else if($_GET['op'] == 'del'){
	if($_GET['mid']){
		C::t('#fn_xiangqin#fn_love_mat')->delete_by_id($_GET['mid']);
	}
	$fn_xiangqin->getCheckMat();
	saveOperRecordSave('红娘管理','删除红娘');
	baseJosn(array(),'删除成功');
}else if($_GET['op'] == 'display' && $_GET['mid']){
	C::t('#fn_xiangqin#fn_love_mat')->update(array('display'=>intval($_GET['value'])),$_GET['mid']);
	$fn_xiangqin->getCheckMat();
	saveOperRecordSave('红娘管理','修改红娘显示状态');
	baseJosn(array(),'更新成功');
}
//From: Dism·taobao·com
?>