<?php

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
header("Content-type: text/html; charset=utf-8");
@require_once ('common.php');
if($_GET['op'] == 'list'){//列表
	$res = C::t('#fn_xiangqin#fn_love_activity')->fetch_all_by_list(array('id'=>$_GET['aid']),'dateline',$_GET['page'] - 1,$_GET['limit'],true);
	foreach($res['list'] as $key => $val){
		$res['list'][$key]['url'] = $fn_xiangqin->getUrl('activity',array('form'=>'view','aid'=>$val['id']));
		$res['list'][$key]['signup_end_dateline'] = date('Y-m-d H:i',$val['signup_end_dateline']);
		$res['list'][$key]['end_dateline'] = date('Y-m-d H:i',$val['end_dateline']);
		$res['list'][$key]['updateline'] = date('Y-m-d H:i',$val['updateline']);
		$res['list'][$key]['dateline'] = date('Y-m-d H:i',$val['dateline']);
		$res['list'][$key]['banner'] = array_filter(explode(",",$val['banner']));
		
	}
	baseJosn($res['list'],'',0,$res['count']);
}else if($_GET['op'] == 'signup_list'){
	$res = C::t('#fn_xiangqin#fn_love_activity_signup')->fetch_all_by_list(array('aid'=>$_GET['aid'],'audit_state'=>$_GET['audit_state'],'vid'=>$_GET['vid'],'sex'=>$_GET['sex']),'dateline',$_GET['page'] - 1,$_GET['limit'],true);
	foreach($res['list'] as $key => $val){
		$res['list'][$key]['sex_text'] = $fn_xiangqin->setting['lang']['sex_arr'][$val['sex']];
		$res['list'][$key]['dateline'] = date('Y-m-d H:i',$val['dateline']);
	}
	baseJosn($res['list'],'',0,$res['count']);
}else if($_GET['op'] == 'save'){
	$item = C::t('#fn_xiangqin#fn_love_activity')->fetch_by_id($postData['id']);
	$data['banner'] = is_array($postData['banner']) && isset($postData['banner']) ? implode(',',$postData['banner']) : '';
	$data['thumbnail'] = addslashes(strip_tags($postData['thumbnail']));
	$data['title'] = addslashes(strip_tags($postData['title']));
	$data['price_type'] = intval($postData['price_type']);
	$data['price'] = addslashes(strip_tags($postData['price']));
	$data['price_1'] = addslashes(strip_tags($postData['price_1']));
	$data['price_2'] = addslashes(strip_tags($postData['price_2']));
	$data['vip_price'] = addslashes(strip_tags($postData['vip_price']));
	$data['user_audit'] = intval($postData['user_audit']);
	$data['real_verify'] = addslashes(strip_tags($postData['real_verify']));
	$data['address'] = addslashes(strip_tags($postData['address']));
	$data['share_logo'] = addslashes(strip_tags($postData['share_logo']));
	$data['share_title'] = addslashes(strip_tags($postData['share_title']));
	$data['share_desc'] = addslashes(strip_tags($postData['share_desc']));
	$data['signup_start_dateline'] = $postData['signup_start_dateline'] ? strtotime($postData['signup_start_dateline']) : '';
	$data['signup_end_dateline'] = $postData['signup_end_dateline'] ? strtotime($postData['signup_end_dateline']) : '';
	$data['start_dateline'] = $postData['start_dateline'] ? strtotime($postData['start_dateline']) : '';
	$data['end_dateline'] = $postData['end_dateline'] ? strtotime($postData['end_dateline']) : '';
	$data['male_number'] = intval($postData['male_number']);
	$data['female_number'] = intval($postData['female_number']);
	$data['vip_act'] = intval($postData['vip_act']);

	if($item['id']){
		C::t('#fn_xiangqin#fn_love_activity')->update($data,$item['id']);
		saveOperRecordSave('活动管理','更新活动');
	}else{
		$data['display'] = 1;
		$data['updateline'] = $data['dateline'] = time();
		C::t('#fn_xiangqin#fn_love_activity')->insert($data);
		saveOperRecordSave('活动管理','添加活动');
	}
	baseJosn(array(),'更新成功');
}else if($_GET['op'] == 'saveContent'){
	$item = C::t('#fn_xiangqin#fn_love_activity')->fetch_by_id($postData['id']);
	$data['content'] = addslashes($postData['content']);
	if($item['id']){
		C::t('#fn_xiangqin#fn_love_activity')->update($data,$item['id']);
		saveOperRecordSave('活动管理','更新描述');
	}
	baseJosn(array(),'更新成功');
}else if($_GET['op'] == 'del'){
	if($_GET['aid']){
		C::t('#fn_xiangqin#fn_love_activity')->delete_by_id($_GET['aid']);
	}
	saveOperRecordSave('活动管理','删除活动');
	baseJosn(array(),'删除成功');
}else if($_GET['op'] == 'display' && $_GET['aid']){
	C::t('#fn_xiangqin#fn_love_activity')->update(array('display'=>intval($_GET['value'])),$_GET['aid']);
	saveOperRecordSave('活动管理','修改显示状态');
	baseJosn(array(),'更新成功');
}else if($_GET['op'] == 'refresh' && $_GET['aid']){
	C::t('#fn_xiangqin#fn_love_activity')->update(array('updateline'=>time()),$_GET['aid']);
	saveOperRecordSave('活动管理','刷新更新时间');
	baseJosn(array(),'刷新成功');
}else if($_GET['op'] == 'del_signup'){
	if($_GET['sid']){
		C::t('#fn_xiangqin#fn_love_activity_signup')->delete_by_id($_GET['sid']);
	}
	saveOperRecordSave('活动管理','删除活动报名');
	baseJosn(array(),'删除成功');
}
//From: Dism·taobao·com
?>