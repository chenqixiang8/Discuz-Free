<?php

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
header("Content-type: text/html; charset=utf-8");
@require_once ('common.php');
if($_GET['op'] == 'list'){//列表
	$res = C::t('#fn_xiangqin#fn_love_gift')->fetch_all_by_list(array(),'displayorder',$_GET['page'] -1, $_GET['limit'],true);
	$list = array();
	foreach($res['list'] as $key => $val){
		$val['money'] = (int)$val['money'];
		$list[] = $val;
	}
	baseJosn($list,'',0, $res['count']);
}else if($_GET['op'] == 'save'){
	$item = C::t('#fn_xiangqin#fn_love_gift')->fetch_by_id($postData['id']);
	$data['title'] = addslashes(strip_tags($postData['title']));
	$data['icon'] = addslashes(strip_tags($postData['icon']));
	$data['money'] = intval($postData['money']);
	$data['displayorder'] = intval($postData['displayorder']);
	
	if($item['id']){
		C::t('#fn_xiangqin#fn_love_gift')->update($data,$item['id']);
		saveOperRecordSave('礼物管理','更新礼物');
	}else{
		C::t('#fn_xiangqin#fn_love_gift')->insert($data);
		saveOperRecordSave('礼物管理','添加礼物');
	}
	baseJosn(array(),'更新成功');
}else if($_GET['op'] == 'del'){
	if($_GET['gid']){
		C::t('#fn_xiangqin#fn_love_gift')->delete_by_id($_GET['gid']);
	}
	saveOperRecordSave('礼物管理','删除礼物');
	baseJosn(array(),'删除成功');
}
//From: Dism·taobao·com
?>