<?php

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
header("Content-type: text/html; charset=utf-8");
@require_once ('common.php');
if($_GET['op'] == 'list'){//列表
	$res = C::t('#fn_xiangqin#fn_love_meal')->fetch_all_by_list();
	foreach($res as $key => $val){
		$res[$key]['type_text'] = $fn_xiangqin->setting['lang']['meal_type_arr'][$val['type']];
	}
	baseJosn($res);
}else if($_GET['op'] == 'save'){
	$item = C::t('#fn_xiangqin#fn_love_meal')->fetch_by_id($postData['id']);
	$data['title'] = addslashes(strip_tags($postData['title']));
	$data['money'] = addslashes(strip_tags($postData['money']));
	$data['currency'] = intval($postData['currency']);
	$data['imkey'] = intval($postData['imkey']);
	$data['act'] = intval($postData['act']);
	$data['pull'] = intval($postData['pull']);
	$data['day'] = intval($postData['day']);
	$data['type'] = intval($postData['type']);
	$data['limit'] = intval($postData['limit']);
	$data['content'] = addslashes($postData['content']);
	$data['displayorder'] = intval($postData['displayorder']);
	
	if($item['id']){
		C::t('#fn_xiangqin#fn_love_meal')->update($data,$item['id']);
		saveOperRecordSave('套餐管理','更新套餐');
	}else{
		$data['display'] = 1;
		C::t('#fn_xiangqin#fn_love_meal')->insert($data);
		saveOperRecordSave('套餐管理','添加套餐');
	}
	baseJosn(array(),'更新成功');
}else if($_GET['op'] == 'del'){
	if($_GET['mid']){
		C::t('#fn_xiangqin#fn_love_meal')->delete_by_id($_GET['mid']);
	}
	saveOperRecordSave('套餐管理','删除套餐');
	baseJosn(array(),'删除成功');
}else if($_GET['op'] == 'display' && $_GET['mid']){
	C::t('#fn_xiangqin#fn_love_meal')->update(array('display'=>intval($_GET['value'])),$_GET['mid']);
	saveOperRecordSave('套餐管理','修改显示状态');
	baseJosn(array(),'更新成功');
}
//From: Dism·taobao·com
?>