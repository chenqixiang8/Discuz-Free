<?php

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
header("Content-type: text/html; charset=utf-8");
@require_once ('common.php');
if($_GET['op'] == 'init'){
	$mealList = array();
	foreach(C::t('#fn_xiangqin#fn_love_meal')->fetch_all_by_list(array('type'=>1)) as $val) {
		$mealList[] = array('value'=>$val['id'],'title'=>$val['title']);
	}

	$matList = array();
	foreach($fn_xiangqin->matList as $val) {
		$matList[] = array('value'=>$val['id'],'title'=>$val['name']);
	}
	
	$data['auditStateList'] = vueFormArray($fn_xiangqin->setting['lang']['audit_state_arr']);
	$data['sexList'] = vueFormArray($fn_xiangqin->setting['lang']['sex_arr']);
	$data['marriageList'] = vueFormArray($fn_xiangqin->setting['lang']['marriage_arr']);
	$data['monthIncomeList'] = vueFormArray($fn_xiangqin->setting['lang']['month_income_arr']);
	$data['channelList'] = vueFormArray($fn_xiangqin->setting['lang']['channel_arr']);
	$data['openContactList'] = vueFormArray($fn_xiangqin->setting['lang']['open_contact_arr']);
	$data['openLoveList'] = vueFormArray($fn_xiangqin->setting['lang']['open_love_arr']);
	$data['familyList'] = vueFormArray($fn_xiangqin->setting['lang']['family_arr']);
	$data['educationList'] = vueFormArray($fn_xiangqin->setting['lang']['education_arr']);
	$data['houseList'] = vueFormArray($fn_xiangqin->setting['lang']['house_arr']);
	$data['vehicleList'] = vueFormArray($fn_xiangqin->setting['lang']['vehicle_arr']);
	$data['occupationList'] = vueFormArray($fn_xiangqin->setting['lang']['occupation_arr']);
	$data['nationList'] = vueFormArray($fn_xiangqin->setting['lang']['nation_arr']);
	$data['childList'] = vueFormArray($fn_xiangqin->setting['lang']['child_arr']);
	$data['wantChildList'] = vueFormArray($fn_xiangqin->setting['lang']['want_child_arr']);
	$data['whenMarryList'] = vueFormArray($fn_xiangqin->setting['lang']['when_marry_arr']);
	$data['smokeList'] = vueFormArray($fn_xiangqin->setting['lang']['smoke_arr']);
	$data['drinkList'] = vueFormArray($fn_xiangqin->setting['lang']['drink_arr']);
	$data['religionList'] = vueFormArray($fn_xiangqin->setting['lang']['religion_arr']);
	$data['hobbyList'] = vueFormArray($fn_xiangqin->setting['lang']['hobby_arr']);
	$data['companyNatureList'] = vueFormArray($fn_xiangqin->setting['lang']['company_nature_arr']);
	$data['shape1List'] = vueFormArray($fn_xiangqin->setting['lang']['shape_arr_1']);
	$data['shape2List'] = vueFormArray($fn_xiangqin->setting['lang']['shape_arr_2']);
	$data['ageList'] = vueFormArray($fn_xiangqin->setting['lang']['age_arr']);
	$data['heightList'] = vueFormArray($fn_xiangqin->setting['lang']['height_arr']);
	$data['reqAcceptChildList'] = vueFormArray($fn_xiangqin->setting['lang']['req_accept_child_arr']);
	$data['reqWantChildList'] = vueFormArray($fn_xiangqin->setting['lang']['req_want_child_arr']);
	$data['reqSmokeList'] = vueFormArray($fn_xiangqin->setting['lang']['req_smoke_arr']);
	$data['reqDrinkList'] = vueFormArray($fn_xiangqin->setting['lang']['req_drink_arr']);
	$data['mealList'] = $mealList;
	$data['matList'] = $matList;
	baseJosn($data);
}else if($_GET['op'] == 'list'){//列表
	$res = C::t('#fn_xiangqin#fn_love_user')->fetch_all_by_list(array('keyword'=>$_GET['keyword'],'audit_state'=>$_GET['audit_state'],'display'=>$_GET['display'],'group_id'=>$_GET['group_id'],'seal'=>$_GET['seal'],'channel'=>$_GET['channel'],'hot'=>$_GET['hot'],'sex'=>$_GET['sex'],'marriage'=>$_GET['marriage'],'month_income'=>$_GET['month_income'],'vid'=>$_GET['vid'],'uid'=>$_GET['uid'],'open_contact'=>$_GET['open_contact'],'open_love'=>$_GET['open_love'],'mat_id'=>$_GET['mat_id'],'is_vip'=>$_GET['is_vip'],'expired'=>$_GET['expired'],'age_max'=>$_GET['age_max'],'age_min'=>$_GET['age_min']),$_GET['sort'],$_GET['page'] - 1,$_GET['limit'],true);
	foreach($res['list'] as $key => $val){
		$mat = $fn_xiangqin->matList[$val['mat_id']];
		$res['list'][$key] = $fn_xiangqin->getFormUser($val);
		$res['list'][$key]['updateline'] = date('Y-m-d H:i',$val['updateline']);
		$res['list'][$key]['dateline'] = date('Y-m-d H:i',$val['dateline']);
		$res['list'][$key]['topdateline'] = $val['topdateline'] ? date('Y-m-d H:i',$val['topdateline']) : '';
		$res['list'][$key]['open_contact_text'] = $fn_xiangqin->setting['lang']['open_contact_arr'][$val['open_contact']];
		$res['list'][$key]['open_love_text'] = $fn_xiangqin->setting['lang']['open_love_arr'][$val['open_love']];
		$res['list'][$key]['staffName'] = $mat['name'];
		$res['list'][$key]['channel_text'] = $fn_xiangqin->setting['lang']['channel_arr'][$val['channel']];
		$res['list'][$key]['audit_state_text'] = $fn_xiangqin->setting['lang']['audit_state_arr'][$val['audit_state']];
		$res['list'][$key]['hobby_arr_text'] = implode(',',$res['list'][$key]['hobby_arr']);
	}
	baseJosn($res['list'],'',0,$res['count']);
}else if($_GET['op'] == 'export'){//导出列表

	if($fn_xiangqin->setting['QrParameterSwitch']){
		@require_once libfile('class/wechat','plugin/fn_assembly');
		$wechatClient = new Fn_WeChatClient($fn_xiangqin->setting['WxAppid'], $fn_xiangqin->setting['WxSecret']);
	}

	$res = C::t('#fn_xiangqin#fn_love_user')->fetch_all_by_list(array('keyword'=>$postData['keyword'],'display'=>1,'audit_state'=>1,'seal'=>0,'sex'=>$postData['sex'],'marriage'=>$postData['marriage'],'education'=>$postData['education'],'family'=>$postData['family'],'month_income'=>$postData['month_income'],'nation'=>$postData['nation'],'occupation'=>$postData['occupation'],'vehicle'=>$postData['vehicle'],'house'=>$postData['house'],'open_love'=>$postData['open_love'],'age_max'=>$postData['age_max'],'age_min'=>$postData['age_min'],'ids'=>$postData['ids']),$postData['sort'],$postData['page'] - 1,$postData['limit'],true);


	foreach($res['list'] as $key => $val){
		$val = $fn_xiangqin->getFormUser($val);
		if($fn_xiangqin->setting['QrParameterSwitch']){
			$file = $Config['QrcodePath'].'fn_xiangqin__view_'.$val['id'].'.jpg';
			if(!file_exists($file) || !filesize($file) || (filesize($file) && file_exists($file) && filemtime($file) + 1296000 <= time())) {
				@unlink($file);
				$qrUrl = $wechatClient->getQrcodeImgUrlByTicket($wechatClient->getQrcodeTicket(array('scene_str'=>'fn_xiangqin____view____'.$val['id'],'expire'=>2592000)));
				DownloadImg($qrUrl,$file);
			}
			$qrcode_url = $_G['siteurl'].str_replace(DISCUZ_ROOT,'',$file);
		}else{
			$qrcode_url = $_G['siteurl'].'plugin.php?id=fn_assembly:qrcode&url='.base64_encode($val['url']);
		}
		$val['user_wx_temp'] = str_replace($val['replaceFront'],$val['replaceAfter'],$postData['temp'.$val['sex']]);
		$val['user_wx_temp'] = str_replace(array('[--qrcode_url--]'),array($qrcode_url),$val['user_wx_temp']);
		$res['list'][$key] = $val;
	}
	baseJosn($res['list'],'',0,$res['count']);
}else if($_GET['op'] == 'data'){
	$item = C::t('#fn_xiangqin#fn_love_user')->fetch_by_id($_GET['vid']);
	if($item){
		$item['album'] = array_filter(explode(",",$item['album']));
		$item['hobby'] = array_filter(explode(",",$item['hobby']));
		$item['birth'] = date('Y-m-d',$item['birth']);
	}
	baseJosn($item);
}else if($_GET['op'] == 'save'){
	$item = C::t('#fn_xiangqin#fn_love_user')->fetch_by_id($postData['id']);
	$data['head_portrait'] = addslashes(strip_tags($postData['head_portrait']));
	$data['video_type'] = intval($postData['video_type']);
	$data['video_url'] = addslashes(strip_tags($_GET['video_url']));
	$data['album'] = is_array($postData['album']) && isset($postData['album'])  ? implode(',',array_filter($postData['album'])) : '';
	$data['uid'] = intval($postData['uid']);
	$member = DB::fetch_first('SELECT username FROM '.DB::table('common_member').' where uid = '.$data['uid']);
	$data['username'] = addslashes(strip_tags($member['username']));
	$data['name'] = addslashes(strip_tags($postData['name']));
	$data['phone'] = addslashes(strip_tags($postData['phone']));
	$data['wx'] = addslashes(strip_tags($postData['wx']));
	$data['graduate_school'] = addslashes(strip_tags($postData['graduate_school']));
	$data['major'] = addslashes(strip_tags($postData['major']));
	$data['company'] = addslashes(strip_tags($postData['company']));
	$data['position'] = addslashes(strip_tags($postData['position']));
	$data['birth'] = $postData['birth'] ? strtotime($postData['birth']) : '';
	$data['introduce'] = addslashes(strip_tags($postData['introduce']));
	//星座-生肖
	$birthext = $fn_xiangqin->birthext($data['birth']);
	$data['constellation'] = intval($birthext['constellation']);
	$data['animal'] = intval($birthext['animal']);
	$data['age'] = date('Y') - date('Y',$data['birth']);
	$data['sex'] = intval($postData['sex']);
	$data['weight'] = intval($postData['weight']);
	$data['height'] = intval($postData['height']);
	$data['education'] = intval($postData['education']);
	$data['marriage'] = intval($postData['marriage']);
	$data['nation'] = intval($postData['nation']);
	$data['family'] = intval($postData['family']);
	$data['month_income'] = intval($postData['month_income']);
	$data['only'] = intval($postData['only']);
	$data['child'] = intval($postData['child']);
	$data['want_child'] = intval($postData['want_child']);
	$data['occupation'] = intval($postData['occupation']);
	$data['vehicle'] = intval($postData['vehicle']);
	$data['house'] = intval($postData['house']);
	$data['when_marry'] = intval($postData['when_marry']);
	$data['shape'] = intval($postData['shape']);
	$data['smoke'] = intval($postData['smoke']);
	$data['drink'] = intval($postData['drink']);
	$data['religion'] = intval($postData['religion']);
	$data['hobby'] = is_array($postData['hobby']) && isset($postData['hobby']) ? implode(',',$postData['hobby']) : '';
	$hobby_arr = array();
	foreach($postData['hobby'] as $k => $v) {
		$hobby_arr[$k] = $fn_xiangqin->setting['lang']['hobby_arr'][$v];
	}
	$data['hobby_arr'] = $hobby_arr ? serialize($hobby_arr) : '';
	$data['company_nature'] = intval($postData['company_nature']);
	$data['req_age_min'] = intval($postData['req_age_min']);
	$data['req_age_max'] = intval($postData['req_age_max']);
	$data['req_height_min'] = intval($postData['req_height_min']);
	$data['req_height_max'] = intval($postData['req_height_max']);
	$data['req_month_income'] = $postData['req_month_income'] ? intval($postData['req_month_income']) : 99;
	$data['req_education'] = $postData['req_education'] ? intval($postData['req_education']) : 99;
	$data['req_nation'] = intval($postData['req_nation']);
	$data['req_house'] = intval($postData['req_house']);
	$data['req_vehicle'] = intval($postData['req_vehicle']);
	$data['req_marriage'] = $postData['req_marriage'] ? intval($postData['req_marriage']) : 99;
	$data['req_want_child'] = intval($postData['req_want_child']);
	$data['req_smoke'] = intval($postData['req_smoke']);
	$data['req_drink'] = intval($postData['req_drink']);
	$data['req_accept_child'] = intval($postData['req_accept_child']);
	$data['open_contact'] = intval($postData['open_contact']);
	$data['open_love'] = intval($postData['open_love']);
	$data['phone_verify'] = intval($postData['phone_verify']);
	$data['real_verify'] = intval($postData['real_verify']);
	$data['education_verify'] = intval($postData['education_verify']);
	$data['vehicle_verify'] = intval($postData['vehicle_verify']);
	$data['house_verify'] = intval($postData['house_verify']);
	$data['offline_verify'] = intval($postData['offline_verify']);
	if($item['id']){
		$id = $item['id'];
		C::t('#fn_xiangqin#fn_love_user')->update($data,$item['id']);
		saveOperRecordSave('用户管理','更新用户');
	}else{
		$mat = C::t('#fn_xiangqin#fn_love_mat')->fetch_by_staff_id($user['id']);
		$data['mat_id'] = $mat['id'];
		$data['per_check'] = 1;
		$data['updateline'] = $data['dateline'] = time();
		$id = C::t('#fn_xiangqin#fn_love_user')->insert($data,true);
		saveOperRecordSave('用户管理','添加用户');
	}
	baseJosn(array('id'=>$id),'更新成功');
}else if($_GET['op'] == 'del'){
	if($_GET['vid']){
		C::t('#fn_xiangqin#fn_love_user')->delete_by_id($_GET['vid']);
	}
	saveOperRecordSave('用户管理','删除用户');
	baseJosn(array(),'删除成功');
}else if($_GET['op'] == 'field' && $_GET['vid']){
	C::t('#fn_xiangqin#fn_love_user')->update(array($_GET['field']=>intval($_GET['value'])),$_GET['vid']);
	saveOperRecordSave('用户管理','修改状态');
	baseJosn(array(),'更新成功');
}else if($_GET['op'] == 'refresh' && $_GET['vid']){
	C::t('#fn_xiangqin#fn_love_user')->update(array('updateline'=>time()),$_GET['vid']);
	saveOperRecordSave('用户管理','刷新用户');
	baseJosn(array(),'更新成功');
}else if($_GET['op'] == 'remarks' && $postData['id']){
	C::t('#fn_xiangqin#fn_love_user')->update(array('remarks'=>addslashes(strip_tags($postData['remarks']))),$postData['id']);
	saveOperRecordSave('用户管理','修改备注');
	baseJosn(array(),'更新成功');
}else if($_GET['op'] == 'comment' && $postData['id']){
	C::t('#fn_xiangqin#fn_love_user')->update(array('comment'=>addslashes(strip_tags($postData['comment']))),$postData['id']);
	saveOperRecordSave('用户管理','修改评语');
	baseJosn(array(),'更新成功');
}else if($_GET['op'] == 'topdateline' && $postData['id']){
	C::t('#fn_xiangqin#fn_love_user')->update(array('topdateline'=>$postData['topdateline'] ? strtotime($postData['topdateline']) : ''),$postData['id']);
	saveOperRecordSave('用户管理','修改置顶时间');
	baseJosn(array(),'更新成功');
}else if($_GET['op'] == 'follow' && $postData['id']){
	$mat = C::t('#fn_xiangqin#fn_love_mat')->fetch_by_staff_id($user['id']);
	$data['mat_id'] = $mat['id'];
	$data['vid'] = $postData['id'];
	$data['content'] = addslashes(strip_tags($postData['followContent']));
	$data['follow_dateline'] = time();
	$data['dateline'] = time();
	C::t('#fn_xiangqin#fn_love_user_follow_log')->insert($data);
	saveOperRecordSave('用户管理','写跟进');
	baseJosn(array(),'添加成功');
}else if($_GET['op'] == 'vip' && $postData['id']){
	$data['group_id'] = intval($postData['group_id']);
	$data['due_time'] = $postData['due_time'] ? strtotime($postData['due_time']) : '';
	$data['currency'] = intval($postData['currency']);
	$data['imkey'] = intval($postData['imkey']);
	$data['pull'] = intval($postData['pull']);
	$data['act'] = intval($postData['act']);
	C::t('#fn_xiangqin#fn_love_user')->update($data,$postData['id']);
	saveOperRecordSave('用户管理','修改会员');
	baseJosn(array(),'更新成功');
}else if($_GET['op'] == 'audit' && $postData['id']){
	$item = C::t('#fn_xiangqin#fn_love_user')->fetch_by_id($postData['id']);
	$data['audit_state'] = intval($postData['audit_state']);
	if($data['audit_state'] == 3){
		$data['refuse_tips'] = addslashes(strip_tags($postData['refuse_tips']));
	}
	if(($data['audit_state'] == 1 && $item['audit_state'] != 1) || ($data['audit_state'] == 3 && $item['audit_state'] != 3)){
		C::t('#fn_xiangqin#fn_love_user')->update($data,$postData['id']);
		$fn_xiangqin->getAuditNotice($item['id'],$data['audit_state'],$fn_xiangqin->getUrl('user'),str_replace(array('[--audit_state--]'),array($fn_xiangqin->setting['lang']['audit_state_arr'][$data['audit_state']]),$fn_xiangqin->setting['lang']['userNoticeMsg']));
	}
	saveOperRecordSave('用户管理','审核操作');
	baseJosn(array(),'更新成功');
}
//From: Dism·taobao·com
?>