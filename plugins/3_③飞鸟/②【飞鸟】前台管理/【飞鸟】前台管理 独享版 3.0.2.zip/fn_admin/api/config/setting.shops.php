<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
header("Content-type: text/html; charset=utf-8");
$defaultsetting = array(
	'index_title'=>'【飞鸟】同城商圈',
	'modularList'=>array('1','2','3'),
	'searchSwitch'=>'1',
	'headerSwitch'=>'1',
	'watermark'=>'0',
	'PcQrSwitch'=>'0',
	'index_right_add'=>'1',
	'index_right_add_icon'=>'/source/plugin/fn_shops/static/images/ruzhu.png',
	'tel_icon'=>'/source/plugin/fn_shops/static/images/tel.png',
	'info_vip_icon'=>'/source/plugin/fn_shops/static/images/info_vip_icon.png',
	'view_desc_icon'=>'/source/plugin/fn_shops/static/images/view_desc_icon.png',
	'view_album_icon'=>'/source/plugin/fn_shops/static/images/view_album_icon.png',
	'view_business_hours_icon'=>'/source/plugin/fn_shops/static/images/view_business_hours_icon.png',
	'view_address_icon'=>'/source/plugin/fn_shops/static/images/view_address_icon.png',
	'view_wx_icon'=>'/source/plugin/fn_shops/static/images/view_wx_icon.png',
	'view_pano_icon'=>'/source/plugin/fn_shops/static/images/view_pano_icon.png',
	'view_video_icon'=>'/source/plugin/fn_shops/static/images/view_video_icon.png',
	'view_notice_icon'=>'/source/plugin/fn_shops/static/images/view_notice_icon.png',
	'view_back_icon'=>'/source/plugin/fn_shops/static/images/view-back.png',
	'view_home_icon'=>'/source/plugin/fn_shops/static/images/view-home.png',
	'view_pub_icon'=>'/source/plugin/fn_shops/static/images/view-add.png',
	'view_share_icon'=>'/source/plugin/fn_shops/static/images/view-share.png',
	'view_chat'=>'0',
	'view_chat_icon'=>'/source/plugin/fn_shops/static/images/view-chat.png',
	'chat_tips'=>'下载飞鸟APP马上可以和我在线聊天哦',
	'agent_default_classid'=>'5',
	'agent_default_fenlei_classid'=>'9,13,8',
	'agent_bg'=>'/source/plugin/fn_shops/static/images/agent_bg.png',
	'car_default_classid'=>'6',
	'share_title'=>'【飞鸟】同城商圈',
	'share_desc'=>'【飞鸟】同城商圈',
	'share_logo'=>'/source/plugin/fn_shops/static/images/share_logo.png',
	'color'=>'#104FFF',
	'color2'=>'#ff1c53',
	'changecolor1_0'=>'#104FFF',
	'changecolor1_1'=>'#527ef9'
);