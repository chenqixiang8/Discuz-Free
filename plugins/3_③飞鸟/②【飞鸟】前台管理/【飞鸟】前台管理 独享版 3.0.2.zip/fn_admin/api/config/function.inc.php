<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
header("Content-type: text/html; charset=utf-8");
function saveOperRecordSave($model,$description,$state=0){
	global $user,$_G,$microTime,$postData;
	@require_once libfile('class/json','plugin/fn_assembly');
	$data['userId'] = $user['id'];
	$data['project'] = diconv(project(),mb_detect_encoding(project(), array('ASCII','UTF-8','GB2312','GBK','BIG5')),CHARSET);
	$data['model'] = diconv($model,mb_detect_encoding($model, array('ASCII','UTF-8','GB2312','GBK','BIG5')),CHARSET);
	$data['description'] = diconv($description,mb_detect_encoding($description, array('ASCII','UTF-8','GB2312','GBK','BIG5')),CHARSET);
	$data['url'] = $_SERVER["REQUEST_URI"];
	$data['requestMethod'] = $_SERVER['REQUEST_METHOD'];
	$data['param'] = $data['requestMethod'] == 'POST' ? urldecode(json_encode(ArrayUrlencode($postData))) : $_SERVER['QUERY_STRING'];
	$data['ip'] = $_G['clientip'];
	$data['state'] = $state;
	$data['spendTime'] = round(microtime(true) - $microTime,3);
	$data['dateline'] = time();
	C::t('#fn_admin#fn_admin_oper_record')->insert($data);
}
function project(){
	switch($_GET['mod']){
		case 'global':
			$project = '全局管理';
			break;  
		case 'system':
			$project = '系统管理';
			break;
		case 'love':
			$project = '相亲系统';
			break;
		case 'fenlei':
			$project = '分类系统';
			break;
		default:
			$project = '全局管理';

	}
	return $project;
}

function cplang($name, $replace = array(), $output = false) {
	global $_G;
	$ret = '';

	if(!isset($_G['lang']['admincp'])) {
		lang('admincp');
	}
	if(!isset($_G['lang']['admincp_menu'])) {
		lang('admincp_menu');
	}
	if(!isset($_G['lang']['admincp_msg'])) {
		lang('admincp_msg');
	}

	if(isset($_G['lang']['admincp'][$name])) {
		$ret = $_G['lang']['admincp'][$name];
	} elseif(isset($_G['lang']['admincp_menu'][$name])) {
		$ret = $_G['lang']['admincp_menu'][$name];
	} elseif(isset($_G['lang']['admincp_msg'][$name])) {
		$ret = $_G['lang']['admincp_msg'][$name];
	}
	$ret = $ret ? $ret : ($replace === false ? '' : $name);
	if($replace && is_array($replace)) {
		$s = $r = array();
		foreach($replace as $k => $v) {
			$s[] = '{'.$k.'}';
			$r[] = $v;
		}
		$ret = str_replace($s, $r, $ret);
	}
	$output && print($ret);
	return $ret;
}