<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
header("Content-type: text/html; charset=utf-8");
$defaultsetting = array(
	'index_title'=>'【飞鸟】同城分类',
	'service_pop'=>'1',
	'service_pop_bg'=>'/source/plugin/fn_fenlei/static/images/service-bg.png',
	'service_pop_zw'=>'/source/plugin/fn_fenlei/static/images/service-zw.png',
	'service_pop_title'=>'有事找小编',
	'service_pop_tips'=>'长按二维码，识别添加小编',
	'list_info_limit'=>'10',
	'searchSwitch'=>'1',
	'headerSwitch'=>'1',
	'viewContactTips'=>'联系我时，请说是在飞鸟同城看到我的，谢谢',
	'viewContactBottomTips'=>'联系时请说来自飞鸟同城',
	'viewReportTitle'=>'如遇无效、虚假、诈骗信息，请立刻举报',
	'viewReportDesc'=>'交易时请仔细查验相关证件，且勿提前支付任何费用',
	'report_list'=>'1=诱导营销
2=不实信息
3=色情
4=违法犯罪
5=骚扰
6=虚假电话
7=侵权(冒充他人，侵犯名誉等)
8=其他',
	'user_setmeal_tips'=>'<p>注意</p>
<p>1. 套餐内所有内容需要在有效期内使用完毕，过期后剩余内容将不可使用</p>
<p>2. 套餐未到期或者套餐内容未使用完时，可继续购买套餐，购买后套餐内容叠加，套餐时间按最新套餐为准</p>',
	'watermark'=>'0',
	'PcQrSwitch'=>'0',
	'notice_img'=>'/source/plugin/fn_fenlei/static/images/notice_img.png',
	'index_nav_classid'=>'0=最新信息
1=找工作
7=二手车
13=出租房
8=商铺',
	'index_info_limit'=>'10',
	'index_right_add'=>'0',
	'index_right_add_icon'=>'/source/plugin/fn_fenlei/static/images/add.png',
	'dataSwitch'=>'0',
	'user_pub_icon'=>'/source/plugin/fn_fenlei/static/images/view-content.png',
	'user_collection_icon'=>'/source/plugin/fn_fenlei/static/images/view-like.png',
	'user_footprint_icon'=>'/source/plugin/fn_fenlei/static/images/user-zuji.png',
	'user_online_icon'=>'/source/plugin/fn_fenlei/static/images/user-kefu.png',
	'user_logout_icon'=>'/source/plugin/fn_fenlei/static/images/user-logout.png',
	'pub_top_icon'=>'/source/plugin/fn_fenlei/static/images/user-top.png',
	'view_content_icon'=>'/source/plugin/fn_fenlei/static/images/view-content.png',
	'view_contact_icon'=>'/source/plugin/fn_fenlei/static/images/view-user.png',
	'view_phone_icon'=>'/source/plugin/fn_fenlei/static/images/view-tel.png',
	'view_report_icon'=>'/source/plugin/fn_fenlei/static/images/view-report.png',
	'view_like_icon'=>'/source/plugin/fn_fenlei/static/images/view-like.png',
	'view_back_icon'=>'/source/plugin/fn_fenlei/static/images/view-back.png',
	'view_home_icon'=>'/source/plugin/fn_fenlei/static/images/view-home.png',
	'view_pub_icon'=>'/source/plugin/fn_fenlei/static/images/view-add.png',
	'view_chat_icon'=>'/source/plugin/fn_fenlei/static/images/view-chat.png',
	'view_share_icon'=>'/source/plugin/fn_fenlei/static/images/view-share.png',
	'view_collection_icon'=>'/source/plugin/fn_fenlei/static/images/view-collection.png',
	'WxFollowPath'=>'/source/plugin/fn_fenlei/static/images/follow.jpg',
	'wx_follow_tips'=>'<p class="font-weight-bold font-size-064rem">飞鸟信息网，免费发布信息！（长按关注）</p>
<p class="text-light-muted pt-2" style="line-height:0.9rem">活动推广，家居建材，生意转让，车辆交易，打听求助，二手闲置等消息。</p>',
	'share_title'=>'【飞鸟】同城分类',
	'share_desc'=>'【飞鸟】同城分类',
	'share_logo'=>'/source/plugin/fn_fenlei/static/images/share_logo.png',
	'color'=>'#104FFF',
	'color2'=>'#ff1c53',
	'changecolor1_0'=>'#104FFF',
	'changecolor1_1'=>'#527ef9'
);