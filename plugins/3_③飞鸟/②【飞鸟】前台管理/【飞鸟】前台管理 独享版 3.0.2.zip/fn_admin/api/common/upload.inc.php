<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once libfile('function/upload');
$upload = new discuz_upload();
$_FILES["file"]['name'] = addslashes(diconv(urldecode($_FILES["file"]['name']), 'UTF-8'));
$upload->init($_FILES['file'], 'forum');
if(!$upload->attach['isimage']) {
	baseJosn(array(),'',1);
}else{
	$upload->save();
	$errorcode = 0;
}
if($upload->error()) {
	$errorcode = 4;
	baseJosn(array(),'',2);
}else{
	
	if(in_array(strtolower($upload->attach['ext']),array('php'))){
		@unlink($upload->attach['target']);
		baseJosn(array(),'',2);
	}

	$aid = 1;
	$upload->attach['attachment'] = $_G['setting']['attachurl'].'forum/'.$upload->attach['attachment'];
	//ˮӡ����
	loadcache($_GET['source'].'_setting');
	$setting = $_G['cache'][$_GET['source'].'_setting'];
	if($setting['watermark'] && $upload->attach['isimage']){
		list($width,$height) = explode('-', $setting['watermark_condition']);
		@require_once libfile('class/image','plugin/fn_assembly');
		$image = new fn_image();
		$image->image(array(
			'imagelib'		=> $_G['setting']['imagelib'],
			'imageimpath'		=> $_G['setting']['imageimpath'],
			'thumbquality'		=> $_G['setting']['thumbquality'],
			'watermarkstatus'	=> $setting['watermark_status'],
			'watermarkminwidth'	=> $width,
			'watermarkminheight'	=> $height,
			'watermarktype'		=> $setting['watermark_type'],
			'watermarktext'		=> $_G['setting']['watermarktext'],
			'watermarktrans'	=> $setting['watermark_trans'],
			'watermarkquality'	=> $setting['watermark_quality'],
			'watermarkpngfile'	=> $setting['watermark_png'],
			'watermarkgiffile'	=> $setting['watermark_gif'],
		));
		$image->Watermark($upload->attach['target'], '');
	}
	//ˮӡ���� END
	if($Config['PluginVar']['Attachment'] == 1){
		@include_once DISCUZ_ROOT.'source/plugin/fn_assembly/lib/OSS/common.php';
		if($imageUrl = AliOssUpload(uniqid('fn'.time()).'.'.$upload->attach['ext'],$upload->attach['target'],$_GET['source'])) {
			@unlink($upload->attach['target']);
			$upload->attach['attachment'] = $imageUrl;
		}
	}else if($Config['PluginVar']['Attachment'] == 2){
		@include_once DISCUZ_ROOT.'source/plugin/fn_assembly/lib/qiniu/common.php';
		if($imageUrl = QiNiuOssUpload(uniqid('fn'.time()).'.'.$upload->attach['ext'],$upload->attach['target'],$_GET['source'])) {
			@unlink($upload->attach['target']);
			$upload->attach['attachment'] = $imageUrl;
		}
	}else{
		dmkdir(DISCUZ_ROOT.$Config['StaticPicPath'].'/'.$_GET['source'].'/');
		$attachmentName = uniqid('fn_'.time()).'.'.$upload->attach['ext'];
		$copyUrl = DISCUZ_ROOT.$Config['StaticPicPath'].'/'.$_GET['source'].'/'.$attachmentName;
		if(copy($upload->attach['target'],$copyUrl)){
			@unlink($upload->attach['target']);
			$upload->attach['attachment'] = $_G['siteurl'].$Config['StaticPicPath'].'/'.$_GET['source'].'/'.$attachmentName;
		}
	}
	baseJosn(array('url'=>$upload->attach['attachment']));
}
