<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
header("Content-type: text/html; charset=utf-8");
if($_GET['op'] == 'login'){
	$username = strip_tags($postData['username']);
	$password = strip_tags($postData['password']);
	$user = C::t('#fn_admin#fn_admin_staff')->fetch_by_username($username);
	if(!$user['id']){
		baseJosn(array(),'账号不存在','201');
	}else if(!$user['state']){
		baseJosn(array(),'账号被禁用','201');
	}else if($user['password'] != md5(md5($password).$user['code'])){
		baseJosn(array(),'密码不正确','201');
	}else{
        $access_token = substr(md5($user['username']),0,20).substr(md5($user['password']),0,20).substr(md5($user['code']),0,20).'userId'.$user['id'];
		baseJosn(array('access_token'=>$access_token),'登录成功');
	}
}