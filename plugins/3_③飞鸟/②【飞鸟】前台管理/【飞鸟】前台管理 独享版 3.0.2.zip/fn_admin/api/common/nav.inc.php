<?php

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
header("Content-type: text/html; charset=utf-8");
if($_GET['op'] == 'list'){//列表
	$res = $adList = array();
	if($_GET['plugin'] == 'fn_xiangqin'){
		$adList = array(
			'nav'=>'手机版首页导航',
			'navBottom'=>'手机版底部固定导航',
			'navMiddle'=>'手机版首页中间4图导航'
		);
	}else if($_GET['plugin'] == 'fn_fenlei'){
		$adList = array(
			'navBottom'=>'手机版底部固定导航',
		);
	}else if($_GET['plugin'] == 'fn_shops'){
		$adList = array(
			'navBottom'=>'手机版底部固定导航',
		);
	}
	foreach($adList as $key => $val){
		$arr = array();
		$arr['classId'] = $arr['id'] = $key;
		$arr['title'] = diconv($val,mb_detect_encoding($val, array('ASCII','UTF-8','GB2312','GBK','BIG5')),CHARSET);
		$arr['plugin'] = $_GET['plugin'];
		$res[] = $arr;
	}
	baseJosn($res);
}else if($_GET['op'] == 'navList'){//列表
	$res = C::t('#fn_admin#fn_nav')->fetch_all_by_list(array('plugin'=>$_GET['plugin'],'classId'=>$_GET['classId']),$_GET['page'] - 1,$_GET['limit'],$_GET['sort'],$_GET['order'],true);
	check($_GET['plugin']);
	baseJosn($res['list'],'',0, $res['count']);
}else if($_GET['op'] == 'save'){
	$item = C::t('#fn_admin#fn_nav')->fetch_by_id($postData['id']);

	$data['plugin'] = addslashes(strip_tags($_GET['plugin']));
	$data['classId'] = addslashes(strip_tags($_GET['classId']));
	$data['title'] = addslashes(strip_tags($postData['title']));
	$data['icon'] = addslashes(strip_tags($postData['icon']));
	$data['onIcon'] = addslashes(strip_tags($postData['onIcon']));
	$data['url'] = addslashes(strip_tags($postData['url']));
	$data['top'] = intval($postData['top']);
	$data['displayorder'] = intval($postData['displayorder']);
	if($item['id']){
		C::t('#fn_admin#fn_nav')->update($data,$item['id']);
		saveOperRecordSave('导航管理','更新导航');
	}else{
		C::t('#fn_admin#fn_nav')->insert($data);
		saveOperRecordSave('导航管理','添加导航');
	}
	baseJosn(array(),'更新成功');
}else if($_GET['op'] == 'del'){
	if($_GET['nid']){
		C::t('#fn_admin#fn_nav')->delete_by_id($_GET['nid']);
	}else if($_GET['ids']){
		foreach(array_filter(explode(",",$_GET['ids'])) as $k => $v) {
			C::t('#fn_admin#fn_nav')->delete_by_id($v);
		}
	}
	saveOperRecordSave('导航管理','删除导航');
	baseJosn(array(),'删除成功');
}else if($_GET['op'] == 'display' && $_GET['nid']){
	C::t('#fn_admin#fn_nav')->update(array('display'=>$_GET['value']),$_GET['nid']);
	saveOperRecordSave('导航管理','显示/不显示导航');
	baseJosn(array(),'更新成功');
}else if($_GET['op'] == 'top' && $_GET['nid']){
	C::t('#fn_admin#fn_nav')->update(array('top'=>$_GET['value']),$_GET['nid']);
	saveOperRecordSave('导航管理','突出图标设置');
	baseJosn(array(),'更新成功');
}
function check($plugin){
	$check = array();
	$res = C::t('#fn_admin#fn_nav')->fetch_all_by_list(array('plugin'=>$plugin,'display'=>1),0,100,$_GET['sort'],$_GET['order'],true);
	foreach($res['list'] as $val){
		$check[$val['classId']][] = $val;
	}
	savecache('fn_nav_'.$plugin,$check);
}
//From: Dism·taobao·com
?>