<?php

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
header("Content-type: text/html; charset=utf-8");
if($_GET['op'] == 'list'){//列表
	$res = C::t('#fn_admin#fn_notice')->fetch_all_by_list(array('plugin'=>$_GET['plugin'],'title'=>$_GET['title'],'display'=>$_GET['display']),$_GET['page'] - 1,$_GET['limit'],$_GET['sort'],$_GET['order'],true);
	foreach($res['list'] as $key => $val){
		$res['list'][$key]['dateline'] =  FormatDate($val['dateline'],'Y-m-d H:i');
	}
	check($_GET['plugin']);
	baseJosn($res['list'],'',0, $res['count']);
}else if($_GET['op'] == 'save'){
	$item = C::t('#fn_admin#fn_notice')->fetch_by_id($postData['id']);

	$data['plugin'] = $_GET['plugin'];
	$data['title'] = addslashes(strip_tags($postData['title']));
	$data['thumb'] = addslashes(strip_tags($postData['thumb']));
	$data['url'] = addslashes(strip_tags($postData['url']));
	$data['displayorder'] = intval($postData['displayorder']);

	if($item['id']){
		C::t('#fn_admin#fn_notice')->update($data,$item['id']);
		saveOperRecordSave('公告管理','更新公告');
	}else{

		$data['dateline'] = time();
		C::t('#fn_admin#fn_notice')->insert($data);
		saveOperRecordSave('公告管理','更新公告');
		
	}
	baseJosn(array(),'更新成功');
}else if($_GET['op'] == 'del'){
	if($_GET['nid']){
		C::t('#fn_admin#fn_notice')->delete_by_id($_GET['nid']);
	}else if($_GET['ids']){
		foreach(array_filter(explode(",",$_GET['ids'])) as $k => $v) {
			C::t('#fn_admin#fn_notice')->delete_by_id($v);
		}
	}
	saveOperRecordSave('公告管理','删除公告');
	baseJosn(array(),'删除成功');
}else if($_GET['op'] == 'display' && $_GET['nid']){
	C::t('#fn_admin#fn_notice')->update(array('display'=>$_GET['value']),$_GET['nid']);
	saveOperRecordSave('公告管理','显示/不显示公告');
	baseJosn(array(),'更新成功');
}
function check($plugin){
	$check = array();
	$res = C::t('#fn_admin#fn_notice')->fetch_all_by_list(array('plugin'=>$plugin,'display'=>1),0,100,$_GET['sort'],$_GET['order'],true);
	foreach($res['list'] as $val){
		$check[] = $val;
	}
	savecache('fn_notice_'.$plugin,$check);
}
//From: Dism·taobao·com
?>