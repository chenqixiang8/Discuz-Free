<?php

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
header("Content-type: text/html; charset=utf-8");
if($_GET['op'] == 'likeUsername'){//�б�
	$list = C::t('common_member')->fetch_all_by_like_username($postData['username']);
	sort($list);
	baseJosn($list);
}