<?php

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
header("Content-type: text/html; charset=utf-8");
@require_once ('common.php');
if($_GET['op'] == 'init'){
	$data['sourceList'] = vueFormArray($fn_shops->setting['lang']['shops_source_arr']);
	$data['pagesList'] = vueFormArray($fn_shops->setting['lang']['shops_pages_arr']);
	$data['actionList'] = vueFormArray($fn_shops->setting['lang']['shops_action_arr']);
	baseJosn($data);
}else if($_GET['op'] == 'list'){//列表
	$res = C::t('#fn_shops#fn_shops_action')->fetch_all_by_list(array('keyword'=>$_GET['keyword'],'action'=>$_GET['action'],'sid'=>$_GET['sid'],'channel'=>$_GET['channel'],'pages'=>$_GET['pages'],'source'=>$_GET['source']),'dateline',$_GET['page'] - 1,$_GET['limit'],true);
	foreach($res['list'] as $key => $val){
		$res['list'][$key]['dateline'] =  FormatDate($val['dateline'],'Y-m-d H:i');
		$res['list'][$key]['source_text'] = $fn_shops->setting['lang']['shops_source_arr'][$val['source']];
		$res['list'][$key]['pages_text']	= $fn_shops->setting['lang']['shops_pages_arr'][$val['pages']];
		$res['list'][$key]['action_text']	= $fn_shops->setting['lang']['shops_action_arr'][$val['action']];
		$res['list'][$key]['item'] = $fn_shops->getView($val['sid']);
	}
	baseJosn($res['list'],'',0, $res['count']);
}else if($_GET['op'] == 'del'){
	if($_GET['lid']){
		C::t('#fn_shops#fn_shops_action')->delete_by_id($_GET['lid']);
	}else if($_GET['ids']){
		foreach(array_filter(explode(",",$_GET['ids'])) as $k => $v) {
			C::t('#fn_shops#fn_shops_action')->delete_by_id($v);
		}
	}
	saveOperRecordSave('统计记录','删除统计记录');
	baseJosn(array(),'删除成功');
}