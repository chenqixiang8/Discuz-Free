<?php

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
header("Content-type: text/html; charset=utf-8");
@require_once ('common.php');
if($_GET['op'] == 'list'){//列表
	$res = C::t('#fn_shops#fn_shops_album_class')->fetch_all_by_list();
	$list = array();
	foreach($res as $key => $val){
		$list[] = $val;
	}
	$fn_shops->checkAlbumClass();
	baseJosn($list);
}else if($_GET['op'] == 'save'){
	$allAlbum = C::t('#fn_shops#fn_shops_album_class')->fetch_all_by_list();
	$item = C::t('#fn_shops#fn_shops_album_class')->fetch_by_classid($postData['classid']);
	
	$data['bclassid'] = intval($postData['bclassid']);
	$data['name'] = $data['bname'] = addslashes(strip_tags($postData['name']));
	$data['displayorder'] = intval($postData['displayorder']);
	$data['level'] = $data['bclassid'] ? $allAlbum[$data['bclassid']]['level'] + 1 : '';

	if($item['classid']){
		C::t('#fn_shops#fn_shops_album_class')->update($data,$item['classid']);
		saveOperRecordSave('相册管理','更新相册');
	}else{
		$data['display'] = 1;
		C::t('#fn_shops#fn_shops_album_class')->insert($data);
		saveOperRecordSave('相册管理','添加相册');
	}
	baseJosn(array(),'更新成功');
}else if($_GET['op'] == 'del'){
	if($_GET['aid']){
		C::t('#fn_shops#fn_shops_album_class')->delete_by_id($_GET['aid']);
	}
	saveOperRecordSave('相册管理','删除相册');
	baseJosn(array(),'删除成功');
}else if($_GET['op'] == 'field' && $_GET['classid']){
	C::t('#fn_shops#fn_shops_album_class')->update(array($_GET['field']=>intval($_GET['value'])),$_GET['classid']);
	saveOperRecordSave('相册管理','修改状态');
	baseJosn(array(),'更新成功');
}
//From: Dism·taobao·com
?>