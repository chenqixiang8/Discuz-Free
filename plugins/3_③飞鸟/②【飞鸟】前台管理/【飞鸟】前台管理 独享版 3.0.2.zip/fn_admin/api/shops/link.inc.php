<?php

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
header("Content-type: text/html; charset=utf-8");
@require_once ('common.php');
$data = array(
	array('value'=>$fn_shops->getUrl('index'),'title'=>'首页链接'),
	array('value'=>$fn_shops->getUrl('user',array('form'=>'info')),'title'=>'商家入驻')
);
foreach($data as $key => $val){
	$data[$key]['title'] = diconv($val['title'],mb_detect_encoding($val['title'], array('ASCII','UTF-8','GB2312','GBK','BIG5')),CHARSET);
}
baseJosn($data);