<?php

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
header("Content-type: text/html; charset=utf-8");
@require_once ('common.php');
if($_GET['op'] == 'list'){//列表
	$res = C::t('#fn_shops#fn_shops_group')->fetch_all_by_list();
	foreach($res as $key => $val){
		$res[$key]['identity_text'] = $fn_shops->setting['lang']['identity_id_arr'][$val['identity_id']];
	}
	$fn_shops->checkGroup();
	baseJosn($res);
}else if($_GET['op'] == 'save'){
	$item = C::t('#fn_shops#fn_shops_group')->fetch_by_id($postData['id']);
	$data['icon'] = addslashes(strip_tags($postData['icon']));
	$data['title'] = addslashes(strip_tags($postData['title']));
	$data['price'] = addslashes(strip_tags($postData['price']));
	$data['app_price'] = addslashes(strip_tags($postData['app_price']));
	$data['day'] = intval($postData['day']);
	$data['identity_id'] = intval($postData['identity_id']);
	$data['displayorder'] = intval($postData['displayorder']);
	$data['count'] = intval($postData['count']);
	$data['add_notice'] = intval($postData['add_notice']);
	$data['add_video'] = intval($postData['add_video']);
	$data['add_pano'] = intval($postData['add_pano']);
	//$data['add_wx'] = intval($postData['add_wx']);
	$data['add_music'] = intval($postData['add_music']);
	$data['add_album'] = intval($postData['add_album']);
	$data['add_package'] = intval($postData['add_package']);
	$data['add_content'] = intval($postData['add_content']);
	$data['add_desc'] = intval($postData['add_desc']);
	$data['content'] = addslashes(strip_tags($postData['content']));
	
	if($item['id']){
		C::t('#fn_shops#fn_shops_group')->update($data,$item['id']);
		saveOperRecordSave('权限管理','更新权限');
	}else{
		$data['display'] = 1;
		C::t('#fn_shops#fn_shops_group')->insert($data);
		saveOperRecordSave('权限管理','添加权限');
	}
	baseJosn(array(),'更新成功');
}else if($_GET['op'] == 'del'){
	if($_GET['gid']){
		C::t('#fn_shops#fn_shops_group')->delete_by_id($_GET['gid']);
	}
	saveOperRecordSave('权限管理','删除权限');
	baseJosn(array(),'删除成功');
}else if($_GET['op'] == 'display' && $_GET['gid']){
	C::t('#fn_shops#fn_shops_group')->update(array('display'=>intval($_GET['value'])),$_GET['gid']);
	saveOperRecordSave('权限管理','修改显示状态');
	baseJosn(array(),'更新成功');
}
//From: Dism·taobao·com
?>