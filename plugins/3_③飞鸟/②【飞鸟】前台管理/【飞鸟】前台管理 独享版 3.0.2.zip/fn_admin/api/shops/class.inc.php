<?php

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
header("Content-type: text/html; charset=utf-8");
@require_once ('common.php');
if($_GET['op'] == 'init'){
	$data['albumList'] = C::t('#fn_shops#fn_shops_album_class')->fetch_all_by_list();
	sort($data['albumList']);
	baseJosn($data);
}else if($_GET['op'] == 'list'){//列表
	$res = C::t('#fn_shops#fn_shops_class')->fetch_all_by_list();
	$list = array();
	foreach($res as $key => $val){
		$list[] = $val;
	}
	$fn_shops->checkClass();
	baseJosn($list);
}else if($_GET['op'] == 'save'){
	$allClass = C::t('#fn_shops#fn_shops_class')->fetch_all_by_list();
	$item = C::t('#fn_shops#fn_shops_class')->fetch_by_classid($postData['classid']);
	
	$data['album_id'] = intval($postData['album_id']);
	$data['bclassid'] = intval($postData['bclassid']);
	$data['name'] = $data['bname'] = addslashes(strip_tags($postData['name']));
	$data['nav'] = intval($postData['nav']);
	$data['shops_login'] = intval($postData['shops_login']);
	$data['ico'] = addslashes(strip_tags($postData['ico']));
	$data['share_icon'] = addslashes(strip_tags($postData['share_icon']));
	$data['share_title'] = addslashes(strip_tags($postData['share_title']));
	$data['share_desc'] = addslashes(strip_tags($postData['share_desc']));
	$data['shops_share_title'] = addslashes(strip_tags($postData['shops_share_title']));
	$data['shops_share_desc'] = addslashes(strip_tags($postData['shops_share_desc']));
	$data['shops_wx_temp'] = addslashes($postData['shops_wx_temp']);
	$data['shops_copy_temp'] = addslashes(strip_tags($postData['shops_copy_temp']));
	$data['jump'] = intval($postData['jump']);
	$data['jump_url'] = addslashes(strip_tags($postData['jump_url']));
	$data['license'] = intval($postData['license']);
	$data['license_fill'] = intval($postData['license_fill']);
	$data['displayorder'] = intval($postData['displayorder']);
	$data['level'] = $data['bclassid'] ? $allClass[$data['bclassid']]['level'] + 1 : '';

	if($item['classid']){
		C::t('#fn_shops#fn_shops_class')->update($data,$item['classid']);
		saveOperRecordSave('商家分类管理','更新商家分类');
	}else{
		$data['display'] = 1;
		C::t('#fn_shops#fn_shops_class')->insert($data);
		saveOperRecordSave('商家分类管理','添加商家分类');
	}
	baseJosn(array(),'更新成功');
}else if($_GET['op'] == 'del'){
	if($_GET['classid']){
		C::t('#fn_shops#fn_shops_class')->delete_by_id($_GET['classid']);
	}
	saveOperRecordSave('商家分类管理','删除商家分类');
	baseJosn(array(),'删除成功');
}else if($_GET['op'] == 'field' && $_GET['classid']){
	C::t('#fn_shops#fn_shops_class')->update(array($_GET['field']=>intval($_GET['value'])),$_GET['classid']);
	saveOperRecordSave('商家分类管理','修改状态');
	baseJosn(array(),'更新成功');
}
//From: Dism·taobao·com
?>