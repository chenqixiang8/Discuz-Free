<?php

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
header("Content-type: text/html; charset=utf-8");
@require_once ('common.php');

if($_GET['op'] == 'init'){
	$data['mealList'] = array();
	foreach(C::t('#fn_shops#fn_shops_group')->fetch_all_by_list() as $key => $val){
		$data['mealList'][] = $val;
	}
	$data['regionList'] = array();
	foreach(C::t('#fn_fenlei#fn_region')->fetch_all_by_list() as $key => $val){
		$data['regionList'][] = $val;
	}
	$data['classList'] = $data['allClassList']  = array();
	foreach(C::t('#fn_shops#fn_shops_class')->fetch_all_by_list() as $key => $val){
		$data['classList'][] = $val;
		$data['allClassList'][$val['classid']] = $val;
	}
	$data['identityList'] = vueFormArray($fn_shops->setting['lang']['identity_id_arr']);
	$data['auditStateList'] = vueFormArray($fn_shops->setting['lang']['audit_state_arr']);
	$data['channelList'] = vueFormArray($fn_shops->setting['lang']['shops_channel_arr']);
	$data['sourceList'] = vueFormArray($fn_shops->setting['lang']['shops_source_arr']);
	$data['actionList'] = vueFormArray($fn_shops->setting['lang']['shops_action_arr']);
	$data['actionFieldList'] = $fn_shops->setting['lang']['shops_action_field_arr'];
	$data['allAlbumList'] = $fn_shops->allAlbumList;
	
	baseJosn($data);
}else if($_GET['op'] == 'list'){//列表
	$res = C::t('#fn_shops#fn_shops')->fetch_all_by_list(array('name'=>$_GET['name'],'uid'=>$_GET['uid'],'identity_id'=>$_GET['identity_id'],'sid'=>$_GET['sid'],'overdue'=>$_GET['overdue'],'regionid'=>$_GET['regionid'],'classid'=>$_GET['classid'],'display'=>$_GET['display'],'channel'=>$_GET['channel'],'group_id'=>$_GET['group_id'],'is_vip'=>$_GET['is_vip'],'expired'=>$_GET['expired'],'source'=>$_GET['source'],'audit_state'=>$_GET['audit_state']),$_GET['sort'],$_GET['order'],$_GET['page'] - 1,$_GET['limit'],true);
	foreach($res['list'] as $key => $val){
		$val = $fn_shops->getFormView($val);
		$val['identity_text'] = $fn_shops->setting['lang']['identity_id_arr'][$val['identity_id']];
		$val['channel_text'] = $fn_shops->setting['lang']['shops_channel_arr'][$val['channel']];
		$val['source_text'] = $fn_shops->setting['lang']['shops_source_arr'][$val['source']];
		$val['audit_state_text'] = $fn_shops->setting['lang']['audit_state_arr'][$val['audit_state']];
		$val['license_audit_text'] = $fn_shops->setting['lang']['audit_state_arr'][$val['license_audit']];
		$val['topdateline'] = $val['top'] ? date('Y-m-d',$val['topdateline']) : ($val['topdateline'] ? $val['topdateline'] : '');
		$res['list'][$key] = $val;
	}
	baseJosn($res['list'],'',0,$res['count']);
}else if($_GET['op'] == 'save'){
	$item = C::t('#fn_shops#fn_shops')->fetch_by_id($postData['id']);
	$data['uid'] = intval($postData['uid']);
	$member = DB::fetch_first('SELECT username FROM '.DB::table('common_member').' where uid = '.$data['uid']);
	$data['username'] = addslashes(strip_tags($member['username']));
	$data['admin'] = $data['uid'];
	$data['name'] = $data['bname'] = addslashes(strip_tags($postData['name']));
	$data['phone'] = addslashes(strip_tags($postData['phone']));
	$data['classid'] = intval($postData['classid']);
	$data['regionid'] = intval($postData['regionid']);
	$data['address'] = addslashes(strip_tags($postData['address']));
	$data['lat'] = addslashes(strip_tags($postData['lat']));
	$data['lng'] = addslashes(strip_tags($postData['lng']));
	$data['wx'] = addslashes(strip_tags($postData['wx']));
	$data['logo'] = addslashes(strip_tags($postData['logo']));
	$data['wx_qr'] = addslashes(strip_tags($postData['wx_qr']));
	$data['video_url'] = addslashes(strip_tags($postData['video_url']));
	$data['pano_url'] = addslashes(strip_tags($postData['pano_url']));
	$data['music_url'] = addslashes(strip_tags($postData['music_url']));
	$data['business_time_start'] = addslashes(strip_tags($postData['business_time_start']));
	$data['business_time_end'] = addslashes(strip_tags($postData['business_time_end']));
	$data['content'] = addslashes($postData['content']);//需保留Html
	$data['notice'] = addslashes($postData['notice']);//需保留Html
	$data['desc'] = addslashes($postData['desc']);//需保留Html
	$data['click'] = intval($postData['click']);
	
	if($item['id']){
		C::t('#fn_shops#fn_shops')->update($data,$item['id']);
		if($data['classid'] != $item['classid']){
			C::t('#fn_shops#fn_shops_class')->update_by_shops_count($data['classid']);
			C::t('#fn_shops#fn_shops_class')->update_by_shops_count($item['classid'],'-');
		}
		saveOperRecordSave('商家管理','更新商家');
	}else{
		$data['channel'] = 1;
		$data['source'] = 4;
		$data['dateline'] = $data['updateline'] = $data['edit_dateline'] = time();
		$id = C::t('#fn_shops#fn_shops')->insert($data,true);
		C::t('#fn_shops#fn_shops_class')->update_by_shops_count($data['classid']);

		//更新信息统计
		C::t('#fn_fenlei#fn_fenlei_info')->uid_update(array('shops_id'=>$id,'role'=>2),$data['uid']);
		C::t('#fn_shops#fn_shops')->update(array('info_count'=>C::t('#fn_fenlei#fn_fenlei_info')->first_by_count(" where i.hide = 1 and i.display = 1 and i.audit_state = 1 and i.pay_state = 1 and i.shops_id = ".$id)),$id);
		C::t('#fn_fenlei#fn_fenlei_member')->uid_update(array('shops_id'=>$id),$data['uid']);
		//更新信息统计 END
		saveOperRecordSave('商家管理','添加商家');
	}
	baseJosn(array(),'更新成功');
}else if($_GET['op'] == 'saveContent'){
	$item = C::t('#fn_shops#fn_shops')->fetch_by_id($postData['id']);
	$data['content'] = addslashes($postData['content']);
	if($item['id']){
		C::t('#fn_shops#fn_shops')->update($data,$item['id']);
		saveOperRecordSave('商家管理','更新详情');
	}
	baseJosn(array(),'更新成功');
}else if($_GET['op'] == 'saveAlbum'){
	$item = C::t('#fn_shops#fn_shops')->fetch_by_id($postData['id']);
	//相册
	$album = $albumCount = $albumList = array();
	foreach($fn_shops->allAlbumList[$item['album_id']]['children'] as $key => $val) {
		foreach($postData['album'][$val] as $k => $v) {
			$album['all'][] = $album[$val][$k] = strpos($v,'http') !== false ? $v : $fn_shops->_G['siteurl'].$v;
		}
	}
	$album['count'] = count($album['all']);
	$albumData['sid'] = $item['id'];
	$albumData['album_id'] = $item['album_id'];
	$albumData['imgs'] = serialize($album);
	$albumItem = C::t('#fn_shops#fn_shops_album')->fetch_by_sid_album($item['id'],$item['album_id']);
	$albumItem ? C::t('#fn_shops#fn_shops_album')->update($albumData,$albumItem['id']) : C::t('#fn_shops#fn_shops_album')->insert($albumData,$albumItem['id']);
	saveOperRecordSave('商家管理','更新相册');
	baseJosn(array(),'更新成功');
}else if($_GET['op'] == 'del'){
	if($_GET['sid']){
		C::t('#fn_shops#fn_shops')->delete_by_id($_GET['sid']);
	}else if($_GET['ids']){
		foreach(array_filter(explode(",",$_GET['ids'])) as $k => $v) {
			C::t('#fn_shops#fn_shops')->delete_by_id($v);
		}
	}
	saveOperRecordSave('商家管理','删除商家');
	baseJosn(array(),'删除成功');
}else if($_GET['op'] == 'field' && $_GET['sid']){
	C::t('#fn_shops#fn_shops')->update(array($_GET['field']=>intval($_GET['value'])),$_GET['sid']);
	saveOperRecordSave('商家管理','修改状态');
	baseJosn(array(),'更新成功');
}else if($_GET['op'] == 'refresh' && $_GET['sid']){
	$data['updateline'] = time();
	C::t('#fn_shops#fn_shops')->update($data,$_GET['sid']);
	saveOperRecordSave('商家管理','刷新商家');
	baseJosn(array(),'刷新成功');
}else if($_GET['op'] == 'topdateline' && $postData['id']){
	C::t('#fn_shops#fn_shops')->update(array('topdateline'=>$postData['topdateline'] ? strtotime($postData['topdateline']) : ''),$postData['id']);
	saveOperRecordSave('商家管理','修改置顶时间');
	baseJosn(array(),'更新成功');
}else if($_GET['op'] == 'audit' && $postData['id']){
	$item = C::t('#fn_shops#fn_shops')->fetch_by_id($postData['id']);
	$data['audit_state'] = intval($postData['audit_state']);
	if($data['audit_state'] == 3){
		$data['refuse_tips'] = addslashes(strip_tags($postData['refuse_tips']));
	}
	if(($data['audit_state'] == 1 && $item['audit_state'] != 1) || ($data['audit_state'] == 3 && $item['audit_state'] != 3)){
		C::t('#fn_shops#fn_shops')->update($data,$postData['id']);
	}
	saveOperRecordSave('商家管理','审核操作');
	baseJosn(array(),'更新成功');
}else if($_GET['op'] == 'licenseAudit' && $postData['id']){
	$item = C::t('#fn_shops#fn_shops')->fetch_by_id($postData['id']);
	$data['license_audit'] = intval($postData['license_audit']);
	if($data['license_audit'] == 3){
		$data['license_tips'] = addslashes(strip_tags($postData['license_tips']));
	}
	if(($data['license_audit'] == 1 && $item['license_audit'] != 1) || ($data['license_audit'] == 3 && $item['license_audit'] != 3)){
		C::t('#fn_shops#fn_shops')->update($data,$postData['id']);
	}
	saveOperRecordSave('商家管理','审核营业执照');
	baseJosn(array(),'更新成功');
}else if($_GET['op'] == 'vip'){
	$item = C::t('#fn_shops#fn_shops')->fetch_by_id($postData['id']);
	$groupItem = C::t('#fn_shops#fn_shops_group')->fetch_by_id($postData['group_id']);
	if(!$groupItem){
		baseJosn(array(),'请选择权限',201);
	}
	$data['identity_id'] = intval($postData['identity_id']);
	$data['group_id'] = intval($postData['group_id']);
	$data['due_time'] = $postData['form_due_time'] ? strtotime($postData['form_due_time']) : '';
	$data['info_nav'] = $data['identity_id'] == 2 && !$item['info_nav'] ? $fn_shops->setting['agent_default_fenlei_classid'] : ($item['info_nav'] ? $item['info_nav'] : '');
	if($postData['vip_type'] == 1 && $groupItem){
		$data['due_time'] = strtotime("+".intval($groupItem['day'])." day",time());
	}
	if($item['id']){
		C::t('#fn_shops#fn_shops')->update($data,$item['id']);
		saveOperRecordSave('商家管理','更新权限');
	}
	baseJosn(array(),'更新成功');
}