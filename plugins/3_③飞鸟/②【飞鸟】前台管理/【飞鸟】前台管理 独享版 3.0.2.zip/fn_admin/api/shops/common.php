<?php

@require_once (DISCUZ_ROOT.'./source/plugin/fn_shops/config.php');