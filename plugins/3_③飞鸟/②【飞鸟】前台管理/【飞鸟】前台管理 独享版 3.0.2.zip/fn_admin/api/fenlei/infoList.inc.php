<?php

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
header("Content-type: text/html; charset=utf-8");
@require_once ('common.php');

if($_GET['op'] == 'init'){
	$data['regionList'] = array();
	foreach(C::t('#fn_fenlei#fn_region')->fetch_all_by_list() as $key => $val){
		$data['regionList'][] = $val;
	}
	$data['classList'] = $data['allClassList']  = array();
	foreach(C::t('#fn_fenlei#fn_fenlei_class')->fetch_all_by_list() as $key => $val){
		$data['classList'][] = $val;
		$data['allClassList'][$val['classid']] = $val;
	}
	$data['payStateList'] = vueFormArray($fn_fenlei->setting['lang']['pay_state_arr']);
	$data['auditStateList'] = vueFormArray($fn_fenlei->setting['lang']['audit_state_arr']);
	$data['pubTypeList'] = vueFormArray($fn_fenlei->setting['lang']['pub_type_arr']);
	$data['pubChannelList'] = vueFormArray($fn_fenlei->setting['lang']['pub_channel_arr']);
	$data['actionList'] = vueFormArray($fn_fenlei->setting['lang']['info_action_arr']);
	$data['actionFieldList'] = $fn_fenlei->setting['lang']['info_action_field_arr'];
	baseJosn($data);
}else if($_GET['op'] == 'list'){//列表
	$res = C::t('#fn_fenlei#fn_fenlei_info')->fetch_all_by_list(array('keyword'=>$_GET['keyword'],'iid'=>$_GET['iid'],'overdue'=>$_GET['overdue'],'regionid'=>$_GET['regionid'],'classid'=>$_GET['classid'],'shops_id'=>$_GET['shops_id'],'display'=>$_GET['display'],'hide'=>$_GET['hide'],'pay_state'=>$_GET['pay_state'],'audit_state'=>$_GET['audit_state'],'pub_type'=>$_GET['pub_type'],'channel'=>$_GET['channel'],'solve'=>$_GET['solve']),$_GET['sort'],$_GET['order'],$_GET['page'] - 1,$_GET['limit'],true);
	foreach($res['list'] as $key => $val){
		$classItem = $fn_fenlei->_G['cache']['fn_fenlei_class'][$val['classid']];
		$classForms = $fn_fenlei->_G['cache']['fn_form_fenlei_info'][$val['classid']];
		$val['forms'] = $val['forms'] ? dunserialize($val['forms']) : '';
		$forms = array();
		$formsReplaceFront = array();
		$formsReplaceAfter = array();
		foreach($classForms as $v){
			$identifier = $val['forms'][$v['identifier']];
			$formsReplaceFront[] = '[--'.$v['identifier'].'--]';
			$formsReplaceAfter[] = $identifier['value'] ? $identifier['content'].$v['unitnew'] : $identifier['content'];
			if($identifier['content']){
				$forms[] = $v['title'].': '.($identifier['value'] ? $identifier['content'].$v['unitnew'] : $identifier['content']);
			}
		}
		$val = $fn_fenlei->getFormInfo($val);
		$val['end'] = $val['end_dateline'] < time() ? true : false;
		$val['end_dateline'] = date('Y-m-d',$val['end_dateline']);
		$val['topdateline'] = $val['topdateline'] > time() ? date('Y-m-d',$val['topdateline']) : '';
		$val['shopsItem'] = $val['shops_id'] && $fn_fenlei->shops ? $fn_fenlei->shops->getView($val['shops_id']) : '';
		$val['audit_state_text'] = $fn_fenlei->setting['lang']['audit_state_arr'][$val['audit_state']];
		$val['channel_text'] = $fn_fenlei->setting['lang']['pub_channel_arr'][$val['channel']];
		$val['pub_type_text'] = $fn_fenlei->setting['lang']['pub_type_arr'][$val['pub_type']];
		$val['content'] = cutstr(strip_tags($val['content']),30);
		$val['formsContent'] = $forms;

		$res['list'][$key] = $val;
	}
	baseJosn($res['list'],'',0,$res['count']);
}else if($_GET['op'] == 'export'){//导出列表

	if($fn_fenlei->setting['QrParameterSwitch']){
		@require_once libfile('class/wechat','plugin/fn_assembly');
		$wechatClient = new Fn_WeChatClient($fn_fenlei->setting['WxAppid'], $fn_fenlei->setting['WxSecret']);
	}
	
	$res = C::t('#fn_fenlei#fn_fenlei_info')->fetch_all_by_list(array('overdue'=>$postData['overdue'],'regionid'=>$postData['regionid'],'classid'=>$postData['classid'],'shops_id'=>$postData['shops_id'],'display'=>$postData['display'],'hide'=>$postData['hide'],'pay_state'=>$postData['pay_state'],'audit_state'=>$postData['audit_state'],'pub_type'=>$postData['pub_type'],'channel'=>$postData['channel'],'solve'=>$postData['solve']),$postData['sort'],$postData['order'],$postData['page'] - 1,$postData['limit'],true);

	foreach($res['list'] as $key => $val){
		$val = $fn_fenlei->getFormInfo($val);
		if($fn_fenlei->setting['QrParameterSwitch']){
			$file = $Config['QrcodePath'].'fn_fenlei__view_'.$val['id'].'.jpg';
			if(!file_exists($file) || !filesize($file) || (filesize($file) && file_exists($file) && filemtime($file) + 1296000 <= time())) {
				@unlink($file);
				$qrUrl = $wechatClient->getQrcodeImgUrlByTicket($wechatClient->getQrcodeTicket(array('scene_str'=>'fn_fenlei____view____'.$val['id'],'expire'=>2592000)));
				DownloadImg($qrUrl,$file);
			}
			$qrcode_url = $_G['siteurl'].str_replace(DISCUZ_ROOT,'',$file);
		}else{
			$qrcode_url = $_G['siteurl'].'plugin.php?id=fn_assembly:qrcode&url='.base64_encode($val['url']);
		}
		$val['info_wx_temp'] = str_replace($val['replaceFront'],$val['replaceAfter'],stripslashes($val['info_wx_temp']));
		$val['info_wx_temp'] = str_replace(array('[--qrcode_url--]'),array($qrcode_url),$val['info_wx_temp']);
		$res['list'][$key] = $val;
	}
	baseJosn($res['list'],'',0,$res['count']);
}else if($_GET['op'] == 'data'){
	$data = C::t('#fn_fenlei#fn_fenlei_info')->fetch_by_id($_GET['iid']);
	if($data){
		$data['album'] = array_filter(explode(',',$data['album']));
		$data['classForm'] = array();
		foreach($fn_fenlei->_G['cache']['fn_form_fenlei_info'][$data['classid']] as $key => $val) {
			if(in_array($val['type'],array('date','datetime')) && $data['forms'][$val['identifier']]['value']){
				$data['forms'][$val['identifier']]['value'] = $val['type'] == 'date' ? date('Y-m-d',$data['forms'][$val['identifier']]['value']) : date('Y-m-d H:i',$data['forms'][$val['identifier']]['value']);
			}
			$data['classForm'][$val['identifier']] = $data['forms'][$val['identifier']]['value'];
		}
	}
	baseJosn($data);
}else if($_GET['op'] == 'save'){
	$item = C::t('#fn_fenlei#fn_fenlei_info')->fetch_by_id($postData['id']);
	$data['uid'] = intval($postData['uid']);
	$member = DB::fetch_first('SELECT username FROM '.DB::table('common_member').' where uid = '.$data['uid']);
	$data['username'] = addslashes(strip_tags($member['username']));
	$data['name'] = addslashes(strip_tags($postData['name']));
	$data['phone'] = addslashes(strip_tags($postData['phone']));
	$data['classid'] = intval($postData['classid']);
	$data['regionid'] = intval($postData['regionid']);
	$data['shops_id'] = intval($postData['shops_id']);
	$data['role'] = $data['shops_id'] ? 2 : 1;
	$data['thumb'] = addslashes(strip_tags($postData['thumb']));
	$data['address'] = addslashes(strip_tags($postData['address']));
	$data['lat'] = addslashes(strip_tags($postData['lat']));
	$data['lng'] = addslashes(strip_tags($postData['lng']));
	$data['title'] = addslashes(strip_tags($postData['title']));
	$data['content'] = addslashes($postData['content']);//需保留Html
	$data['jump'] = intval($postData['jump']);
	$data['jump_url'] = addslashes(strip_tags($postData['jump_url']));
	//$data['click'] = intval($postData['click']);
	//缩略图
	if(!$data['thumb'] && $postData['album'] && $postData['album'][0] != current(array_filter(explode(',',$item['album'])))){
		@require_once libfile('class/image','plugin/fn_assembly');
		$image = new fn_image();
		$image->image(array(
			'imagelib'	=> $fn_fenlei->_G['setting']['imagelib'],
			'imageimpath'	=> $fn_fenlei->_G['setting']['imageimpath'],
			'thumbquality'	=> $fn_fenlei->_G['setting']['thumbquality']
		));
		$thumb = $image->Thumb($postData['album'][0],'forum/202011/12/'.uniqid(time()).'.jpg',300,300, 2);
		if($thumb){
			if($fn_fenlei->setting['common_setting']['Attachment'] == 1){
				@include_once DISCUZ_ROOT.'source/plugin/fn_assembly/lib/OSS/common.php';
				if($ImageUrl = AliOssUpload(uniqid('fn'.time()).'.'.$upload->attach['ext'],$image->target,$fn_fenlei->plugin_id)) {
					@unlink($image->target);
					$data['thumb'] = $ImageUrl;
				}
			}else if($fn_fenlei->setting['common_setting']['Attachment'] == 2){
				@include_once DISCUZ_ROOT.'source/plugin/fn_assembly/lib/qiniu/common.php';
				if($ImageUrl = QiNiuOssUpload(uniqid('fn'.time()).'.'.$upload->attach['ext'],$image->target,$fn_fenlei->plugin_id)) {
					@unlink($image->target);
					$data['thumb'] = $ImageUrl;
				}
			}else{
				dmkdir(DISCUZ_ROOT.$fn_fenlei->setting['common_setting']['StaticPicPath'].'/'.$fn_fenlei->plugin_id.'/');
				$thumbName = uniqid('fn_'.time()).'.'.end(explode('.',$image->target));
				$CopyUrl = DISCUZ_ROOT.$fn_fenlei->setting['common_setting']['StaticPicPath'].'/'.$fn_fenlei->plugin_id.'/'.$thumbName;
				if(copy($image->target,$CopyUrl)){
					@unlink($image->target);
					$data['thumb'] = $fn_fenlei->setting['common_setting']['StaticPicPath'].'/'.$fn_fenlei->plugin_id.'/'.$thumbName;
				}
			}
		}
		$data['thumb'] = strpos($data['thumb'],'http') !== false ? $data['thumb'] : $fn_fenlei->_G['siteurl'].$data['thumb'];
	}

	//缩略图 END
	$data['album'] = is_array($postData['album']) && isset($postData['album']) ? implode(',',array_filter($postData['album'])) : '';
	$classItem = C::t('#fn_fenlei#fn_fenlei_class')->fetch_by_classid($postData['classid']);
	$data['role'] = $postData['role'] && $classItem['param']['info_role_arr'][$postData['role']] ? $postData['role'] : 1;
	$data['tag'] = implode($fn_fenlei->setting['lang']['checkboxStr'],$postData['tag']);
	$tagVal = array();
	foreach(array_filter(explode($fn_fenlei->setting['lang']['checkboxStr'],$data['tag'])) as $k => $v) {
		$tagVal[$v]['value'] = $classItem['param']['info_tag_arr'][$v];
	}
	$data['tag_arr'] = $tagVal ? serialize($tagVal) : '';
	//自定义表单
	//print_r($data);
	$tableName = 'fenlei_info'.$data['classid'];
	$formList = $fn_fenlei->_G['cache']['fn_form_fenlei_info'][$data['classid']];
	foreach($formList as $key => $val) {
		$formData = $postData['classForm'][$val['identifier']];
		if(in_array($val['type'],array('date','datetime')) && $formData){
			$formData = strtotime($formData);
		}
		$data['forms'][$val['identifier']]['title'] = $val['title'];
		$data['forms'][$val['identifier']]['value'] = $formData;
		$data['forms'][$val['identifier']]['content'] = $val['interview'] && !$formData ? $fn_fenlei->setting['lang']['interview'] : $formData;
		$data['forms'][$val['identifier']]['type'] = $val['type'];
		$data['forms'][$val['identifier']]['unitnew'] = $val['unitnew'];
		if($val['type'] == 'pics'){
			$data['forms'][$val['identifier']]['content'] = array_filter($formData);
		}else if($val['type'] == 'select' || $val['type'] == 'radio'){
			$data['forms'][$val['identifier']]['content'] = $val['rules']['choices_arr'][$formData];
		}else if(in_array($val['type'],array('date','datetime')) && $formData){
			$data['forms'][$val['identifier']]['content'] = $val['type'] == 'date' ? date('Y-m-d',$formData) : date('Y-m-d H:i',$formData);
		}else if($val['type'] == 'checkbox'){
			$checkboxVal = array();
			foreach($formData as $k => $v) {
				$checkboxVal[] = $val['rules']['choices_arr'][$v];
			}
			$data['forms'][$val['identifier']]['content'] = implode(' ',$checkboxVal);
			$data['forms'][$val['identifier']]['value'] = array_filter($formData);
		}
	}
	$data['forms'] = $data['forms'] ? serialize($data['forms']) : '';
	if($item['id']){
		$id = $item['id'];
		C::t('#fn_fenlei#fn_fenlei_info')->update($data,$item['id']);
		$formList ? C::t('#fn_fenlei#fn_form_value')->fetch_update($tableName,$formData,$item['id']) : '';
		saveOperRecordSave('信息管理','更新信息');
	}else{
		$data['pub_type'] = 6;
		$data['channel'] = $data['audit_state'] = $data['pay_state'] = 1;
		$data['end_dateline'] = strtotime("+".intval($classItem['info_end_day'])."  day",time());
		$data['updateline'] = $data['dateline'] = time();
		$id = C::t('#fn_fenlei#fn_fenlei_info')->insert($data,true);
		$formList ? C::t('#fn_fenlei#fn_form_value')->fetch_insert($tableName,array_merge($formData,array('iid'=>$id,'classid'=>$data['classid'],'dateline'=>$data['dateline']))) : '';
		saveOperRecordSave('信息管理','添加信息');
	}
	baseJosn(array('id'=>$id,'thumb'=>$data['thumb']),'更新成功');
}else if($_GET['op'] == 'del'){
	if($_GET['iid']){
		C::t('#fn_fenlei#fn_fenlei_info')->delete_by_id($_GET['iid']);
	}else if($_GET['ids']){
		foreach(array_filter(explode(",",$_GET['ids'])) as $k => $v) {
			C::t('#fn_fenlei#fn_fenlei_info')->delete_by_id($v);
		}
	}
	saveOperRecordSave('信息管理','删除信息');
	baseJosn(array(),'删除成功');
}else if($_GET['op'] == 'field' && $_GET['iid']){
	C::t('#fn_fenlei#fn_fenlei_info')->update(array($_GET['field']=>intval($_GET['value'])),$_GET['iid']);
	saveOperRecordSave('信息管理','修改状态');
	baseJosn(array(),'更新成功');
}else if($_GET['op'] == 'refresh' && $_GET['iid']){
	$item = C::t('#fn_fenlei#fn_fenlei_info')->fetch_by_id($_GET['iid']);
	$allClass = C::t('#fn_fenlei#fn_fenlei_class')->fetch_all_by_list();
	$data['updateline'] = time();
	$data['end_dateline'] = strtotime("+".intval($allClass[$item['classid']]['info_end_day'])."  day",time());
	C::t('#fn_fenlei#fn_fenlei_info')->update($data,$item['iid']);
	saveOperRecordSave('信息管理','刷新信息');
	baseJosn(array(),'刷新成功');
}else if($_GET['op'] == 'topdateline' && $postData['id']){
	C::t('#fn_fenlei#fn_fenlei_info')->update(array('topdateline'=>$postData['topdateline'] ? strtotime($postData['topdateline']) : ''),$postData['id']);
	saveOperRecordSave('信息管理','修改置顶时间');
	baseJosn(array(),'更新成功');
}else if($_GET['op'] == 'audit' && $postData['id']){
	$item = C::t('#fn_fenlei#fn_fenlei_info')->fetch_by_id($postData['id']);
	$data['audit_state'] = intval($postData['audit_state']);
	if($data['audit_state'] == 3){
		$data['refuse_tips'] = addslashes(strip_tags($postData['refuse_tips']));
	}
	if(($data['audit_state'] == 1 && $item['audit_state'] != 1) || ($data['audit_state'] == 3 && $item['audit_state'] != 3)){
		C::t('#fn_fenlei#fn_fenlei_info')->update($data,$postData['id']);
	}
	saveOperRecordSave('信息管理','审核操作');
	baseJosn(array(),'更新成功');
}