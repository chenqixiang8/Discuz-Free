<?php

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
header("Content-type: text/html; charset=utf-8");
@require_once ('common.php');
if($_GET['op'] == 'list'){//列表
	$list = array();
	foreach(C::t('#fn_fenlei#fn_fenlei_temp')->fetch_all_by_list() as $key => $val){
		$val['type_text'] = $fn_fenlei->setting['lang']['temp_type_arr'][$val['type']];
		$val['dateline'] = date('Y-m-d',$val['dateline']);
		$val['temp'] = stripslashes($val['temp']);
		$list[] = $val;
	}
	baseJosn($list);
}else if($_GET['op'] == 'save'){
	$item = C::t('#fn_fenlei#fn_fenlei_temp')->fetch_by_id($postData['id']);
	$data['title'] = addslashes(strip_tags($postData['title']));
	$data['type'] = intval($postData['type']);
	$data['temp'] = addslashes($postData['temp']);
	$data['cutst_info_content'] = intval($postData['cutst_info_content']);
	$data['max_album_num'] = intval($postData['max_album_num']);
	if($item['id']){
		C::t('#fn_fenlei#fn_fenlei_temp')->update($data,$item['id']);
		saveOperRecordSave('模板管理','更新模板');
	}else{
		$data['dateline'] = time();
		C::t('#fn_fenlei#fn_fenlei_temp')->insert($data);
		saveOperRecordSave('模板管理','添加模板');
	}
	baseJosn(array(),'更新成功');
}else if($_GET['op'] == 'del'){
	if($_GET['tid']){
		C::t('#fn_fenlei#fn_fenlei_temp')->delete_by_id($_GET['tid']);
	}
	saveOperRecordSave('模板管理','删除模板');
	baseJosn(array(),'删除成功');
}
//From: Dism·taobao·com
?>