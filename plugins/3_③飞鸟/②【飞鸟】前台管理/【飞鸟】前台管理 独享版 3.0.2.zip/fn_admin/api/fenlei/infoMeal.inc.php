<?php

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
header("Content-type: text/html; charset=utf-8");
@require_once ('common.php');
if($_GET['op'] == 'list'){//列表
	$res = C::t('#fn_fenlei#fn_fenlei_info_group')->fetch_all_by_list();
//	foreach($res as $key => $val){
//		$res[$key]['type_text'] = $fn_xiangqin->setting['lang']['meal_type_arr'][$val['type']];
//	}
	baseJosn($res);
}else if($_GET['op'] == 'save'){
	$item = C::t('#fn_fenlei#fn_fenlei_info_group')->fetch_by_id($postData['id']);
	$data['title'] = addslashes(strip_tags($postData['title']));
	$data['price'] = addslashes(strip_tags($postData['price']));
	$data['group_time'] = addslashes(strip_tags($postData['group_time']));
	$data['displayorder'] = intval($postData['displayorder']);
	$data['experience'] = intval($postData['experience']);
	$data['pub_count'] = intval($postData['pub_count']);
	$data['refresh_count'] = intval($postData['refresh_count']);
	$data['top_day'] = intval($postData['top_day']);
	$data['top_discount'] = addslashes(strip_tags($postData['top_discount']));
	$data['audit_state'] = intval($postData['audit_state']);
	$data['content'] = addslashes(strip_tags($postData['content']));
	
	if($item['id']){
		C::t('#fn_fenlei#fn_fenlei_info_group')->update($data,$item['id']);
		saveOperRecordSave('套餐管理','更新套餐');
	}else{
		$data['display'] = 1;
		C::t('#fn_fenlei#fn_fenlei_info_group')->insert($data);
		saveOperRecordSave('套餐管理','添加套餐');
	}
	baseJosn(array(),'更新成功');
}else if($_GET['op'] == 'del'){
	if($_GET['gid']){
		C::t('#fn_fenlei#fn_fenlei_info_group')->delete_by_id($_GET['gid']);
	}
	saveOperRecordSave('套餐管理','删除套餐');
	baseJosn(array(),'删除成功');
}else if($_GET['op'] == 'display' && $_GET['gid']){
	C::t('#fn_fenlei#fn_fenlei_info_group')->update(array('display'=>intval($_GET['value'])),$_GET['gid']);
	saveOperRecordSave('套餐管理','修改显示状态');
	baseJosn(array(),'更新成功');
}
//From: Dism·taobao·com
?>