<?php

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
header("Content-type: text/html; charset=utf-8");
@require_once ('common.php');
@require_once libfile('function/cache');
$rewriteName = 'fn_fenlei_rewrite';
loadcache($rewriteName);
$rewriteSetting = $_G['cache'][$rewriteName];
$rewrite = array(
	'index' => array('rule'=>'info','title'=>'首页','sign'=>''),
	'user' => array('rule'=>'info/user','title'=>'会员中心','sign'=>''),
	'user_setmeal' => array('rule'=>'info/user/setmeal','title'=>'套餐页','sign'=>''),
	'user_info_list' => array('rule'=>'info/user/list','title'=>'我的发布','sign'=>''),
	'user_footprint' => array('rule'=>'info/user/footprint','title'=>'我的足迹','sign'=>''),
	'user_collection' => array('rule'=>'info/user/collection','title'=>'我的收藏','sign'=>''),
	'view' => array('rule'=>'info/{iid}.htm','title'=>'详情页','sign'=>'')
);
if($_GET['op'] == 'check'){
	$data['check'] = file_exists(DISCUZ_ROOT.'./source/plugin/fn_fenlei/rewrite.php') ? true : false;
	$data['checkTips'] = !$data['check'] ? str_replace(array('{url}'),array('https://dism.taobao.com/plugins/fn_fenlei.91219.html'),lang('plugin/fn_assembly','NoPayRewriteTips')) : '';
	baseJosn($data);
}else if($_GET['op'] == 'list'){//列表
	$list = array();
	foreach($rewrite as $key => $val){
		$rule = $rewriteSetting[$key]['rule'] ? $rewriteSetting[$key]['rule'] : $val['rule'];
		$val['id'] = $key;
		$val['rule'] = $rule;
		$val['available'] = $rewriteSetting[$key]['available'] ? $rewriteSetting[$key]['available'] : 0;
		$list[] = $val;
	}
	baseJosn($list);
}else if($_GET['op'] == 'save'){
	$rewriteList = array();
	$i = 0;
	foreach($rewrite as $key => $val){
		$rewriteList[$key]['rule'] = $postData['rule'][$i];
		$rewriteList[$key]['available'] = $postData['available'][$i] ? 1 : 0;
		$i++;
	}
	savecache($rewriteName,$rewriteList);
	saveOperRecordSave('伪静态设置','保存伪静态');
	baseJosn(array(),'更新成功');
}else if($_GET['op'] == 'rule'){
	$rule = array();
	$rewrite = $rewriteSetting;
	$rewritedata = array(
		'rulesearch' => array(
			'index' => $rewrite['index']['rule'],
			'user' => $rewrite['user']['rule'],
			'user_setmeal' => $rewrite['user_setmeal']['rule'],
			'user_info_list' => $rewrite['user_info_list']['rule'],
			'user_footprint' => $rewrite['user_footprint']['rule'],
			'user_collection' => $rewrite['user_collection']['rule'],
			'view' => $rewrite['view']['rule']
		),
		'rulereplace' => array(
			'index' => 'plugin.php?id=fn_fenlei',
			'user' => 'plugin.php?id=fn_fenlei&mod=user',
			'user_setmeal' => 'plugin.php?id=fn_fenlei&mod=user&form=setmeal',
			'user_info_list' => 'plugin.php?id=fn_fenlei&mod=user&form=info_list',
			'user_footprint' => 'plugin.php?id=fn_fenlei&mod=user&form=footprint',
			'user_collection' => 'plugin.php?id=fn_fenlei&mod=user&form=collection',
			'view' => 'plugin.php?id=fn_fenlei&mod=view&iid={iid}'
		),
		'rulevars' => array(
			'index' => array(),
			'user' => array(),
			'user_setmeal' => array(),
			'user_info_list' => array(),
			'user_footprint' => array(),
			'user_collection' => array(),
			'view' => array('{iid}' => '([0-9]+)')
		)
	);
	$rule['{apache1}'] = $rule['{apache2}'] = $rule['{iis}'] = $rule['{iis7}'] = $rule['{zeus}'] = $rule['{nginx}'] = '';
	foreach($rewritedata['rulesearch'] as $k => $v) {
		
		if(!$rewrite[$k]['available']) {
			continue;
		}
		
		$v = !$_G['setting']['rewriterule'][$k] ? $v : $_G['setting']['rewriterule'][$k];
		
		$pvmaxv = count($rewritedata['rulevars'][$k]) + 2;
		$vkeys = array_keys($rewritedata['rulevars'][$k]);
		
		$rewritedata['rulereplace'][$k] = pvsort($vkeys, $v, $rewritedata['rulereplace'][$k]);
		
		$v = str_replace($vkeys, $rewritedata['rulevars'][$k], addcslashes($v, '?*+^$.[]()|'));
		$rule['{apache1}'] .= 'RewriteCond %{QUERY_STRING} ^(.*)$'."\n".'RewriteRule ^(.*/)*'.$v.'$ $1/'.pvadd($rewritedata['rulereplace'][$k])."&%1\n";
		if($k != 'forum_archiver') {
			$rule['{apache2}'] .= 'RewriteCond %{QUERY_STRING} ^(.*)$'."\n".'RewriteRule ^'.$v.'$ '.$rewritedata['rulereplace'][$k]."&%1\n";
		} else {
			$rule['{apache2}'] .= 'RewriteCond %{QUERY_STRING} ^(.*)$'."\n".'RewriteRule ^archiver/'.$v.'$ archiver/'.$rewritedata['rulereplace'][$k]."&%1\n";
		}
		$rule['{iis}'] .= 'RewriteRule ^(.*)/'.$v.'(\?(.*))*$ $1/'.addcslashes(pvadd($rewritedata['rulereplace'][$k]).'&$'.($pvmaxv + 1), '.?')."\n";
		$rule['{iis7}'] .= '&lt;rule name="'.$k.'"&gt;'."\n\t".'&lt;match url="^(.*/)*'.str_replace('\.', '.', $v).'\?*(.*)$" /&gt;'."\n\t".'&lt;action type="Rewrite" url="{R:1}/'.str_replace(array('&', 'page\%3D'), array('&amp;amp;', 'page%3D'), addcslashes(pvadd($rewritedata['rulereplace'][$k], 1).'&{R:'.$pvmaxv.'}', '?')).'" /&gt;'."\n".'&lt;/rule&gt;'."\n";
		$rule['{zeus}'] .= 'match URL into $ with ^(.*)/'.$v.'\?*(.*)$'."\n".'if matched then'."\n\t".'set URL = $1/'.pvadd($rewritedata['rulereplace'][$k]).'&$'.$pvmaxv."\nendif\n";
		$rule['{nginx}'] .= 'rewrite ^([^\.]*)/'.$v.'$ $1/'.stripslashes(pvadd($rewritedata['rulereplace'][$k]))." last;\n";
	}
	if(!$rule['{nginx}']){
		baseJosn('','伪静态未开启',201);
	}else{
		baseJosn(str_replace(array_keys($rule), $rule, cplang('rewrite_message')));
	}
}

function pvsort($key, $v, $s) {
	$r = '/';
	$p = '';
	foreach($key as $k) {
		$r .= $p.preg_quote($k);
		$p = '|';
	}
	$r .= '/';
	preg_match_all($r, $v, $a);
	$a = $a[0];
	$a = array_flip($a);
	foreach($a as $key => $value) {
		$s = str_replace($key, '$'.($value + 1), $s);
	}
	return $s;
}

function pvadd($s, $t = 0) {
	$s = str_replace(array('$5', '$4', '$3', '$2', '$1'), array('~6', '~5', '~4', '~3', '~2'), $s);
	if(!$t) {
		return str_replace(array('~6', '~5', '~4', '~3', '~2'), array('$6', '$5', '$4', '$3', '$2'), $s);
	} else {
		return str_replace(array('~6', '~5', '~4', '~3', '~2'), array('{R:6}', '{R:5}', '{R:4}', '{R:3}', '{R:2}'), $s);
	}

}