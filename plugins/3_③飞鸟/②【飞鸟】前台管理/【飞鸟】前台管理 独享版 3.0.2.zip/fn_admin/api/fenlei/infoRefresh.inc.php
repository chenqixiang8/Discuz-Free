<?php

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
header("Content-type: text/html; charset=utf-8");
@require_once ('common.php');
if($_GET['op'] == 'init'){
	$data['typeList'] = vueFormArray($fn_fenlei->setting['lang']['info_refresh_arr']);
	baseJosn($data);
}else if($_GET['op'] == 'list'){//列表
	$res = C::t('#fn_fenlei#fn_fenlei_info_refresh_log')->fetch_all_by_list(array('keyword'=>$_GET['keyword'],'type'=>$_GET['type'],'iid'=>$_GET['iid']),'dateline',$_GET['page'] - 1,$_GET['limit'],true);
	foreach($res['list'] as $key => $val){
		$res['list'][$key]['dateline'] =  FormatDate($val['dateline'],'Y-m-d H:i');
		$res['list'][$key]['type_text'] = $fn_fenlei->setting['lang']['info_refresh_arr'][$val['type']];
		$res['list'][$key]['content'] = cutstr(strip_tags($val['content']),30);
		$res['list'][$key]['url'] = $fn_fenlei->getUrl('view',array('iid'=>$val['iid']));
		$res['list'][$key]['item'] = $fn_fenlei->getView($val['iid']);
		$res['list'][$key]['item']['info_title'] = cutstr(strip_tags($res['list'][$key]['item']['info_title']),30);
		
	}
	baseJosn($res['list'],'',0, $res['count']);
}else if($_GET['op'] == 'del'){
	if($_GET['lid']){
		C::t('#fn_fenlei#fn_fenlei_info_refresh_log')->delete_by_id($_GET['lid']);
	}else if($_GET['ids']){
		foreach(array_filter(explode(",",$_GET['ids'])) as $k => $v) {
			C::t('#fn_fenlei#fn_fenlei_info_refresh_log')->delete_by_id($v);
		}
	}
	saveOperRecordSave('刷新记录','删除刷新记录');
	baseJosn(array(),'删除成功');
}
//From: Dism·taobao·com
?>