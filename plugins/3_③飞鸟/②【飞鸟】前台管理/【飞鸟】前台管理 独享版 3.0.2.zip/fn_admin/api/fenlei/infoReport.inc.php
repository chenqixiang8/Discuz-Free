<?php

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
header("Content-type: text/html; charset=utf-8");
@require_once ('common.php');

if($_GET['op'] == 'init'){
	$data['reportList'] = vueFormArray($fn_fenlei->setting['lang']['report_arr']);
	$data['stateList'] = vueFormArray($fn_fenlei->setting['lang']['report_state_arr']);
	baseJosn($data);
}else if($_GET['op'] == 'list'){//列表
	$res = C::t('#fn_fenlei#fn_fenlei_info_report')->fetch_all_by_list(array('uid'=>$_GET['uid'],'type'=>$_GET['type'],'state'=>$_GET['state']),'dateline',$_GET['page'] - 1,$_GET['limit'],true);
	foreach($res['list'] as $key => $val){
		$res['list'][$key]['dateline'] = date('Y-m-d H:i',$val['dateline']);
		$res['list'][$key]['handle_dateline'] = date('Y-m-d H:i',$val['handle_dateline']);
		$res['list'][$key]['type_text'] = $fn_fenlei->setting['lang']['report_arr'][$val['type']];
		$res['list'][$key]['state_text'] = $fn_fenlei->setting['lang']['report_state_arr'][$val['state']];
	}
	baseJosn($res['list'],'',0,$res['count']);
}else if($_GET['op'] == 'del'){
	if($_GET['rid']){
		C::t('#fn_fenlei#fn_fenlei_info_report')->delete_by_id($_GET['rid']);
	}else if($_GET['ids']){
		foreach(array_filter(explode(",",$_GET['ids'])) as $k => $v) {
			C::t('#fn_fenlei#fn_fenlei_info_report')->delete_by_id($v);
		}
	}
	saveOperRecordSave('举报记录管理','删除举报记录');
	baseJosn(array(),'删除成功');
}else if($_GET['op'] == 'state' && $_GET['rid']){
	C::t('#fn_fenlei#fn_fenlei_info_report')->update(array('state'=>intval($_GET['value']),'handle_dateline'=>time()),$_GET['rid']);
	saveOperRecordSave('举报记录管理','修改处理状态');
	baseJosn(array(),'更新成功');
}