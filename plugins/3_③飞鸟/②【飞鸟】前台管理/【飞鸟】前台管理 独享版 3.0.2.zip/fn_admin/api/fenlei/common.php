<?php

@require_once (DISCUZ_ROOT.'./source/plugin/fn_fenlei/config.php');