<?php

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
header("Content-type: text/html; charset=utf-8");
@require_once ('common.php');
if($_GET['op'] == 'init'){

	$data['classList'] = $data['allClassList']  = array();
	foreach(C::t('#fn_fenlei#fn_fenlei_class')->fetch_all_by_list() as $key => $val){
		$data['classList'][] = $val;
		$data['allClassList'][$val['classid']] = $val;
	}
	$data['tempList'] = array();
	foreach(C::t('#fn_fenlei#fn_fenlei_temp')->fetch_all_by_list(array('type'=>1)) as $key => $val){
		$data['tempList'][] = array('value'=>$val['id'], 'title'=>$val['title']);
	}
	$data['infoTempList'] = vueFormArray($fn_fenlei->setting['lang']['info_temp_arr']);
	baseJosn($data);
}else if($_GET['op'] == 'list'){//列表
	$res = C::t('#fn_fenlei#fn_fenlei_class')->fetch_all_by_list();
	$list = array();
	foreach($res as $key => $val){
		$list[] = $val;
	}
	$fn_fenlei->checkForm();
	$fn_fenlei->checkClass();
	baseJosn($list);
}else if($_GET['op'] == 'data'){
	$item = C::t('#fn_fenlei#fn_fenlei_class')->fetch_by_classid($_GET['classid']);
	if($item){
		$item['info_wx_temp'] = $item['info_wx_temp'] ? stripslashes($item['info_wx_temp']) : '';
		$item['info_bottom_share_tips_text'] = $item['info_bottom_share_tips_text'] ? stripslashes($item['info_bottom_share_tips_text']) : '';
		$item['param']['topList'] = $item['param']['topList'] ? $item['param']['topList'] : array();
		sort($item['param']['topList']);
	}else{
		$item['nav'] = $item['jump'] = $item['info_login'] = $param['info_bottom_collection'] = $param['info_bottom_pub'] = $param['info_bottom_share'] = $param['info_bottom_share_tips'] = $param['info_bottom_main_share'] = $param['pub_audit'] = $param['pub_edit_audit'] = $param['pub_title'] = $param['pub_role'] = $param['pub_tag'] = $param['pub_tag_fill'] = $param['pub_free'] = 0;
		$item['top_icon'] = '/source/plugin/fn_fenlei/static/images/top.png';
		$item['info_thumb'] = '/source/plugin/fn_fenlei/static/images/info_thumb.jpg';
		$item['info_solve_icon'] = '/source/plugin/fn_fenlei/static/images/solve.png';
		$item['info_like'] = 1;
		$item['info_contact'] = 1;
		$item['info_end_day'] = 30;
		$item['pub_price'] = 2;
		$item['refresh_price'] = 1;
		$item['app_pub_price'] = 1;
		$item['info_title'] = '[--content--]';
		$item['info_share_title'] = '[--content--]';
		$item['info_share_desc'] = '[--content--]';
		$item['info_copy_temp'] = '【[--class_name--]】
[--content--]
联系人：[--name--]
点击查询联系方式：[--url--]
-拼车，二手车，寻人，失物认领就上飞鸟分类信息网-';
		$item['info_wx_temp'] = '<section><section style="margin-bottom: -1em;">
            <section style="width: 100%;text-align: left;" data-width="100%">
                <section style="display: inline-block;box-shadow: #9fbfdb 4px 4px 0px;border-radius:6px ;">
                    <section data-bgless="spin" data-bglessp="180" style="color:#fff;background: #006785;border-radius:6px ;padding: 4px;">
                        <section style="border-radius:6px;border: 1px dashed #fff;">
                            <section class="135brush" data-brushtype="text" style="font-size:17px;font-weight: bold; text-align: center;letter-spacing:1.5px;padding:0em 0.6em;">
                                [--class_name--]
                            </section>
                        </section>
                    </section>
                </section>
            </section>
        </section>
        <section data-bdless="spin" data-bdlessp="220" data-bdopacity="50%" style="width: 100%;border: 1px dashed #9fbfdb;border-radius:6px ;" data-width="100%">
            <section style="padding:4px;">
                <section data-bgless="spin" data-bglessp="280" data-bgopacity="50%" style="background:#cdeaff;color:#2f2f2f;border-radius:6px ;">
                    <section class="135brush" style="padding: 2em 1em 1em; letter-spacing: 1.5px; text-align: justify;">
                        <p style="font-size: 14px;">[--content--]</p>
                        <p style="font-size: 14px;"><strong>联系人</strong>[--name--]</p>
                        <p style="font-size: 14px;"><strong>联系电话</strong>[--phone--]</p>
                        <p><span style="font-size: 14px;">【提醒】<span style="color: #2f2f2f; font-size: 10px; letter-spacing: 1.5px; text-align: justify; background-color: #cdeaff; text-decoration-line: underline;">长按二维码识别查看</span></span></p>
                        <p>[--qr--]</p>
                    </section>
                </section>
            </section>
        </section>
    </section>';
		$param['info_phone_count'] = 5;
		$param['info_click_rand'] = '1-1';
		$param['info_bottom_share_title'] = '分享';
		$param['info_bottom_share_tips_text'] = '已有[--share_count--]帮忙转发';
		$param['info_bottom_main_share_btn'] = '立即分享';
		$param['info_bottom_tel_btn'] = '拨打电话';
		$param['info_chat_tips'] = '下载飞鸟APP马上可以和我在线聊天哦';
		$param['pub_role_title'] = '信息来源';
		$param['pub_role_arr'] = '1=个人
2=商家';
		$param['pub_role_tips'] = '必须真实选择，乱选择将可能被删除及封号，不退款';
		$param['pub_role_err'] = '请选择信息来源';
		$param['pub_price_tips'] = '本信息发布<span class=text-red>{price}</span>，有效期<span class=text-red>30天</span>';
		$param['app_pub_price_tips'] = '该条发布需要支付{price}，有效期<span class=text-red>30天</span>{br}前往APP发布，仅需<span class=text-red>{appprice}</span>，{down}';
		$param['pub_free_tips'] = '本月该分类您还可以免费发布<span class=text-red>{surplus_num}</span>条信息，今日该分类还可以发布<span class=text-red>{surplus_day_count}</span>条信息';
		$param['info_chat'] = $param['pub_top'] = $param['pub_title_fill'] = $param['pub_content'] = $param['pub_content_fill'] = $param['pub_album'] = $param['pub_album_fill'] = $param['pub_name'] = $param['pub_region'] = $param['pub_region_fill'] = $param['pub_address'] = $param['pub_address_fill'] = $param['pub_location'] = $param['pub_location_auto'] = '1';
		$param['pub_free_month_num'] = 5;
		$param['pub_free_day_limit'] = 1;
		$param['topList'] = array(
			array('displayorder'=>'0','id'=>'1','day'=>'30','price'=>'150','title'=>'置顶30天','content'=>'置顶30天送朋友圈公众号群发'),
			array('displayorder'=>'1','id'=>'2','day'=>'15','price'=>'50','title'=>'置顶15天','content'=>'置顶15天送朋友圈'),
			array('displayorder'=>'2','id'=>'3','day'=>'3','price'=>'30','title'=>'置顶3天','content'=>'置顶3天')
		);
		$item['param'] = $param;
		$item = iconvUtf($item);
	}
	baseJosn($item);
}else if($_GET['op'] == 'save'){
	$allClass = C::t('#fn_fenlei#fn_fenlei_class')->fetch_all_by_list();
	$item = C::t('#fn_fenlei#fn_fenlei_class')->fetch_by_classid($postData['classid']);
	$data['bclassid'] = intval($postData['bclassid']);
	$data['name'] = $data['bname'] = addslashes(strip_tags($postData['name']));
	$data['nav'] = intval($postData['nav']);
	$data['ico'] = addslashes(strip_tags($postData['ico']));
	$data['top_icon'] = addslashes(strip_tags($postData['top_icon']));
	$data['info_thumb'] = addslashes(strip_tags($postData['info_thumb']));
	$data['info_solve_icon'] = addslashes(strip_tags($postData['info_solve_icon']));
	$data['share_icon'] = addslashes(strip_tags($postData['share_icon']));
	$data['share_title'] = addslashes(strip_tags($postData['share_title']));
	$data['share_desc'] = addslashes(strip_tags($postData['share_desc']));
	$data['info_end_day'] = intval($postData['info_end_day']);
	$data['info_like'] = intval($postData['info_like']);
	$data['info_login'] = intval($postData['info_login']);
	$data['info_contact'] = intval($postData['info_contact']);
	$data['info_statement'] = addslashes($postData['info_statement']);
	$data['pub_price'] = addslashes(strip_tags($postData['pub_price']));
	$data['info_title'] = addslashes(strip_tags($postData['info_title']));
	$data['info_share_title'] = addslashes(strip_tags($postData['info_share_title']));
	$data['info_share_desc'] = addslashes(strip_tags($postData['info_share_desc']));
	$data['info_wx_temp'] = addslashes($postData['info_wx_temp']);
	$data['info_copy_temp'] = addslashes(strip_tags($postData['info_copy_temp']));
		
	$data['app_pub_price'] = addslashes(strip_tags($postData['app_pub_price']));
	$data['refresh_price'] = addslashes(strip_tags($postData['refresh_price']));
	$data['list_temp_id'] = intval($postData['list_temp_id']);
	$data['info_temp_id'] = addslashes(strip_tags($postData['info_temp_id']));
	$data['jump'] = intval($postData['jump']);
	$data['jump_url'] = addslashes(strip_tags($postData['jump_url']));
	$data['displayorder'] = intval($postData['displayorder']);
	$data['level'] = $data['bclassid'] ? $allClass[$data['bclassid']]['level'] + 1 : '';
		
	$param['info_phone_count'] = intval($postData['param']['info_phone_count']);
	$param['info_click_rand'] = addslashes(strip_tags($postData['param']['info_click_rand']));
	$param['pub_add_push'] = intval($postData['param']['pub_add_push']);
	$param['pub_edit_push'] = intval($postData['param']['pub_edit_push']);
	$param['pub_audit'] = intval($postData['param']['pub_audit']);
	$param['pub_edit_audit'] = intval($postData['param']['pub_edit_audit']);
	$param['pub_top'] = intval($postData['param']['pub_top']);
	$param['pub_title'] = intval($postData['param']['pub_title']);
	$param['pub_title_fill'] = intval($postData['param']['pub_title_fill']);
	$param['pub_content'] = intval($postData['param']['pub_content']);
	$param['pub_content_fill'] = intval($postData['param']['pub_content_fill']);
	$param['pub_album'] = intval($postData['param']['pub_album']);
	$param['pub_album_fill'] = intval($postData['param']['pub_album_fill']);
	$param['pub_name'] = intval($postData['param']['pub_name']);
	$param['pub_region'] = intval($postData['param']['pub_region']);
	$param['pub_region_fill'] = intval($postData['param']['pub_region_fill']);
	$param['pub_address'] = intval($postData['param']['pub_address']);
	$param['pub_address_fill'] = intval($postData['param']['pub_address_fill']);
	$param['pub_location'] = intval($postData['param']['pub_location']);
	$param['pub_location_auto'] = intval($postData['param']['pub_location_auto']);
	$param['pub_role'] = intval($postData['param']['pub_role']);
	$param['pub_role_title'] = addslashes(strip_tags($postData['param']['pub_role_title']));
	$param['pub_role_arr'] = addslashes(strip_tags($postData['param']['pub_role_arr']));
	$param['info_role_arr'] = $param['pub_role_arr'] ? TextareaArray($param['pub_role_arr']) : '';
	$param['pub_role_tips'] = addslashes($postData['param']['pub_role_tips']);
	$param['pub_role_err'] = addslashes(strip_tags($postData['param']['pub_role_err']));
	$param['info_bottom_collection'] = intval($postData['param']['info_bottom_collection']);
	$param['info_bottom_pub'] = intval($postData['param']['info_bottom_pub']);
	$param['info_bottom_share'] = intval($postData['param']['info_bottom_share']);
	$param['info_bottom_share_title'] = addslashes(strip_tags($postData['param']['info_bottom_share_title']));
	$param['info_bottom_share_tips_text'] = addslashes($postData['param']['info_bottom_share_tips_text']);
	$param['info_bottom_share_tips'] = intval($postData['param']['info_bottom_share_tips']);
	$param['info_bottom_main_share'] = intval($postData['param']['info_bottom_main_share']);
	$param['info_bottom_main_share_btn'] = addslashes(strip_tags($postData['param']['info_bottom_main_share_btn']));
	$param['info_bottom_tel_btn'] = addslashes(strip_tags($postData['param']['info_bottom_tel_btn']));
	$param['info_chat'] = intval($postData['param']['info_chat']);
	$param['info_chat_tips'] = addslashes(strip_tags($postData['param']['info_chat_tips']));
	$param['pub_free'] = intval($postData['param']['pub_free']);
	$param['pub_free_month_num'] = intval($postData['param']['pub_free_month_num']);
	$param['pub_free_day_limit'] = intval($postData['param']['pub_free_day_limit']);
	$param['pub_free_tips'] = addslashes($postData['param']['pub_free_tips']);
	$param['pub_tag'] = intval($postData['param']['pub_tag']);
	$param['pub_tag_fill'] = intval($postData['param']['pub_tag_fill']);
	$param['pub_tag_count'] = intval($postData['param']['pub_tag_count']);
	$param['pub_tag_arr'] = addslashes(strip_tags($postData['param']['pub_tag_arr']));
	$param['info_tag_arr'] = $param['pub_tag_arr'] ? TextareaArray($param['pub_tag_arr']) : '';

	$param['pub_price_tips'] = addslashes($postData['param']['pub_price_tips']);
	$param['pub_price_tips_text'] = str_replace(array('{price}','{br}'),array(($data['pub_price'] ? $data['pub_price'].$fn_fenlei->setting['lang']['yuan'] : $fn_fenlei->setting['lang']['mianfei']),'<br>'),$param['pub_price_tips']);
	$param['app_pub_price_tips'] = addslashes($postData['param']['app_pub_price_tips']);
	$param['app_pub_price_tips_text'] = str_replace(array('{price}','{br}'),array(($data['app_pub_price'] ? $data['app_pub_price'].$fn_fenlei->setting['lang']['yuan'] : $fn_fenlei->setting['lang']['mianfei']),'<br>'),$param['pub_price_tips']);
	$param['wrong_app_pub_price_tips_text'] = str_replace(array('{price}','{br}','{appprice}','{down}'),array('<span class="FFFFFColor">'.$data['pub_price'].$fn_fenlei->setting['lang']['yuan'].'</span>','<br>',($data['app_pub_price'] ? $data['app_pub_price'].$fn_fenlei->setting['lang']['yuan'] : $fn_fenlei->setting['lang']['mianfei']),'<a href="'.$Config['PluginVar']['AppLink'].'" class=text-red>'.$fn_fenlei->setting['lang']['down'].'</a>'),$param['app_pub_price_tips']);
	
	//置顶
	foreach($postData['param']['topList'] as $key => $val){
		foreach($val as $k => $v){
			$topList[$key][$k] = addslashes($v);
		}
	}
	foreach(arraySort($topList,'displayorder') as $group){
		$newTopList[$group['id']] = $group; 
	}
	$param['topList'] = $newTopList;
	//置顶 END

	$data['param'] = serialize($param);
	if($item['classid'] && !$_GET['copy']){
		$classid = $item['classid']; 
		C::t('#fn_fenlei#fn_fenlei_class')->update($data,$item['classid']);
		saveOperRecordSave('分类管理','更新分类');
	}else{
		$data['dateline'] = time();
		$data['display'] = 1;
		$classid = C::t('#fn_fenlei#fn_fenlei_class')->insert($data,true);
		saveOperRecordSave('分类管理','添加分类');
	}
	$fn_fenlei->checkForm();
	$fn_fenlei->checkClass();
	baseJosn(array('classid'=>$classid),'更新成功');
}else if($_GET['op'] == 'del'){
	if($_GET['classid']){
		C::t('#fn_fenlei#fn_fenlei_class')->delete_by_id($_GET['classid']);
	}
	saveOperRecordSave('分类管理','删除分类');
	baseJosn(array(),'删除成功');
}else if($_GET['op'] == 'field' && $_GET['classid']){
	C::t('#fn_fenlei#fn_fenlei_class')->update(array($_GET['field']=>intval($_GET['value'])),$_GET['classid']);
	saveOperRecordSave('分类管理','修改状态');
	baseJosn(array(),'更新成功');
}else if($_GET['op'] == 'initForm'){
	$data['typeList'] = vueFormArray($fn_fenlei->setting['lang']['form_arr']);
	baseJosn($data);
}else if($_GET['op'] == 'formList'){
	$list = array();
	foreach(C::t('#fn_fenlei#fn_form')->fetch_all_by_classid('fenlei_info',$_GET['classid']) as $option) {
		$option['type_text'] = $fn_fenlei->setting['lang']['form_arr'][$option['type']];
		//$option['rules'] = dunserialize($option['rules']);
		$list[] = $option;
	}
	$fn_fenlei->checkForm();
	$fn_fenlei->checkClass();
	baseJosn($list);
}else if($_GET['op'] == 'formSave'){
	
	$mysql_keywords = array( 'ADD', 'ALL', 'ALTER', 'ANALYZE', 'AND', 'AS', 'ASC', 'ASENSITIVE', 'BEFORE', 'BETWEEN', 'BIGINT', 'BINARY', 'BLOB', 'BOTH', 'BY', 'CALL', 'CASCADE', 'CASE', 'CHANGE', 'CHAR', 'CHARACTER', 'CHECK', 'COLLATE', 'COLUMN', 'CONDITION', 'CONNECTION', 'CONSTRAINT', 'CONTINUE', 'CONVERT', 'CREATE', 'CROSS', 'CURRENT_DATE', 'CURRENT_TIME', 'CURRENT_TIMESTAMP', 'CURRENT_USER', 'CURSOR', 'DATABASE', 'DATABASES', 'DAY_HOUR', 'DAY_MICROSECOND', 'DAY_MINUTE', 'DAY_SECOND', 'DEC', 'DECIMAL', 'DECLARE', 'DEFAULT', 'DELAYED', 'DELETE', 'DESC', 'DESCRIBE', 'DETERMINISTIC', 'DISTINCT', 'DISTINCTROW', 'DIV', 'DOUBLE', 'DROP', 'DUAL', 'EACH', 'ELSE', 'ELSEIF', 'ENCLOSED', 'ESCAPED', 'EXISTS', 'EXIT', 'EXPLAIN', 'FALSE', 'FETCH', 'FLOAT', 'FLOAT4', 'FLOAT8', 'FOR', 'FORCE', 'FOREIGN', 'FROM', 'FULLTEXT', 'GOTO', 'GRANT', 'GROUP', 'HAVING', 'HIGH_PRIORITY', 'HOUR_MICROSECOND', 'HOUR_MINUTE', 'HOUR_SECOND', 'IF', 'IGNORE', 'IN', 'INDEX', 'INFILE', 'INNER', 'INOUT', 'INSENSITIVE', 'INSERT', 'INT', 'INT1', 'INT2', 'INT3', 'INT4', 'INT8', 'INTEGER', 'INTERVAL', 'INTO', 'IS', 'ITERATE', 'JOIN', 'KEY', 'KEYS', 'KILL', 'LABEL', 'LEADING', 'LEAVE', 'LEFT', 'LIKE', 'LIMIT', 'LINEAR', 'LINES', 'LOAD', 'LOCALTIME', 'LOCALTIMESTAMP', 'LOCK', 'LONG', 'LONGBLOB', 'LONGTEXT', 'LOOP', 'LOW_PRIORITY', 'MATCH', 'MEDIUMBLOB', 'MEDIUMINT', 'MEDIUMTEXT', 'MIDDLEINT', 'MINUTE_MICROSECOND', 'MINUTE_SECOND', 'MOD', 'MODIFIES', 'NATURAL', 'NOT', 'NO_WRITE_TO_BINLOG', 'NULL', 'NUMERIC', 'ON', 'OPTIMIZE', 'OPTION', 'OPTIONALLY', 'OR', 'ORDER', 'OUT', 'OUTER', 'OUTFILE', 'PRECISION', 'PRIMARY', 'PROCEDURE', 'PURGE', 'RAID0', 'RANGE', 'READ', 'READS', 'REAL', 'REFERENCES', 'REGEXP', 'RELEASE', 'RENAME', 'REPEAT', 'REPLACE', 'REQUIRE', 'RESTRICT', 'RETURN', 'REVOKE', 'RIGHT', 'RLIKE', 'SCHEMA', 'SCHEMAS', 'SECOND_MICROSECOND', 'SELECT', 'SENSITIVE', 'SEPARATOR', 'SET', 'SHOW', 'SMALLINT', 'SPATIAL', 'SPECIFIC', 'SQL', 'SQLEXCEPTION', 'SQLSTATE', 'SQLWARNING', 'SQL_BIG_RESULT', 'SQL_CALC_FOUND_ROWS', 'SQL_SMALL_RESULT', 'SSL', 'STARTING', 'STRAIGHT_JOIN', 'TABLE', 'TERMINATED', 'THEN', 'TINYBLOB', 'TINYINT', 'TINYTEXT', 'TO', 'TRAILING', 'TRIGGER', 'TRUE', 'UNDO', 'UNION', 'UNIQUE', 'UNLOCK', 'UNSIGNED', 'UPDATE', 'USAGE', 'USE', 'USING', 'UTC_DATE', 'UTC_TIME', 'UTC_TIMESTAMP', 'VALUES', 'VARBINARY', 'VARCHAR', 'VARCHARACTER', 'VARYING', 'WHEN', 'WHERE', 'WHILE', 'WITH', 'WRITE', 'X509', 'XOR', 'YEAR_MONTH', 'ZEROFILL', 'ACTION', 'BIT', 'DATE', 'ENUM', 'NO', 'TEXT', 'TIME');

	$item = C::t('#fn_fenlei#fn_form')->fetch($postData['optionid']);
	
	$data['models'] = 'fenlei_info';
	$data['classid'] = addslashes(strip_tags($_GET['classid']));
	$data['title'] = addslashes(strip_tags($postData['title']));
	$data['identifier'] = addslashes(strip_tags($postData['identifier']));
	$data['type'] = addslashes(strip_tags($postData['type']));
	$rules = $postData['rules'];
	foreach(explode("\n", $rules['choices']) as $val) {
		list($index, $choice) = explode('=', $val);
		$choices[trim($index)] = trim($choice);
	}
	$rules['choices_arr'] = $rules['choices'] ? $choices : '';
	$data['rules'] = serialize($rules);
	$data['unitnew'] = addslashes(strip_tags($postData['unitnew']));
	$data['description'] = addslashes(strip_tags($postData['description']));
	$data['displayorder'] = intval($postData['displayorder']);
	$data['autoicon'] = addslashes(strip_tags($postData['autoicon']));
	$data['required'] = intval($postData['required']);
	$data['unchangeable'] = intval($postData['unchangeable']);
	$data['formsearch'] = intval($postData['formsearch']);
	$data['range'] = intval($postData['range']);
	$data['autohide'] = intval($postData['autohide']);
	$data['interview'] = intval($postData['interview']);

	if(!$item['optionid']){
		if(in_array(strtoupper($data['identifier']), $mysql_keywords)) {
			baseJosn('','选项变量名不被允许使用',201);
		}
		if(C::t('#fn_fenlei#fn_form')->fetch_all_by_identifier($data['identifier'],$data['models'],$data['classid'], 0, 1) || strlen($data['identifier']) > 40  || !ispluginkey($data['identifier'])) {
			baseJosn('','分类选项变量名重复',202);
		}
		C::t('#fn_fenlei#fn_form')->insert($data);
		$tableName = $data['models'].$data['classid'];
		$formList = C::t('#fn_fenlei#fn_form')->fetch_all_by_classid($data['models'],$data['classid']);
		$insertoptionid = $indexoption = array();
		$create_table_sql = $separator = $create_tableoption_sql = '';
		foreach($formList as $option) {
			$insertoptionid[$option['optionid']]['type'] = $option['type'];
			$insertoptionid[$option['optionid']]['identifier'] = $option['identifier'];
		}
		
		if(!C::t('#fn_fenlei#fn_form_value')->showcolumns($tableName)) {
			$fields = '';
			foreach($formList as $option) {
				$optionid = $option['optionid'];
				$identifier = $insertoptionid[$optionid]['identifier'];
				if($identifier) {
					if(in_array($insertoptionid[$optionid]['type'], array('radio'))) {
						$create_tableoption_sql .= "$separator$identifier smallint(6) UNSIGNED NOT NULL DEFAULT '0'";
					} elseif(in_array($insertoptionid[$optionid]['type'], array('number', 'range'))) {
						$create_tableoption_sql .= "$separator$identifier int(10) UNSIGNED NOT NULL DEFAULT '0'";
					} elseif($insertoptionid[$optionid]['type'] == 'select') {
						$create_tableoption_sql .= "$separator$identifier varchar(50) NOT NULL";
					} else {
						$create_tableoption_sql .= "$separator$identifier mediumtext NOT NULL";
					}
					$separator = ' ,';
					if(in_array($insertoptionid[$optionid]['type'], array('radio', 'select', 'number'))) {
						$indexoption[] = $identifier;
					}
				}
			}
			$fields .= ($create_tableoption_sql ? $create_tableoption_sql.',' : '')."iid int(11) UNSIGNED NOT NULL DEFAULT '0',classid smallint(6) UNSIGNED NOT NULL DEFAULT '0',dateline int(11) UNSIGNED NOT NULL DEFAULT '0',expiration int(10) UNSIGNED NOT NULL DEFAULT '0',";
			$fields .= "KEY (iid), KEY (classid), KEY(dateline)";
			if($indexoption) {
				foreach($indexoption as $index) {
					$fields .= "$separator KEY $index ($index)";
					$separator = ' ,';
				}
			}
			$dbcharset = $_G['config']['db'][1]['dbcharset'];
			$dbcharset = empty($dbcharset) ? str_replace('-','',CHARSET) : $dbcharset;
			C::t('#fn_fenlei#fn_form_value')->create($tableName, $fields, $dbcharset);
		}else{
			$tables = C::t('#fn_fenlei#fn_form_value')->showcolumns($tableName);
			foreach($formList as $option) {
				$optionid = $option['optionid'];
				$identifier = $insertoptionid[$optionid]['identifier'];
				if(!$tables[$identifier]) {
					$fieldname = $identifier;
					if(in_array($insertoptionid[$optionid]['type'], array('radio'))) {
						$fieldtype = 'smallint(6) UNSIGNED NOT NULL DEFAULT \'0\'';
					} elseif(in_array($insertoptionid[$optionid]['type'], array('number', 'range'))) {
						$fieldtype = 'int(10) UNSIGNED NOT NULL DEFAULT \'0\'';
					} elseif($insertoptionid[$optionid]['type'] == 'select') {
						$fieldtype = 'varchar(50) NOT NULL';
					} else {
						$fieldtype = 'mediumtext NOT NULL';
					}
					C::t('#fn_fenlei#fn_form_value')->alter($tableName, "ADD $fieldname $fieldtype");
					if(in_array($insertoptionid[$optionid]['type'], array('radio', 'select', 'number'))) {
						C::t('#fn_fenlei#fn_form_value')->alter($tableName, "ADD INDEX ($fieldname)");
					}  
				}
			}
		}
		saveOperRecordSave('分类表单管理','添加表单');
	}else{
		C::t('#fn_fenlei#fn_form')->update($item['optionid'], $data);
		saveOperRecordSave('分类表单管理','更新表单');
	}
	baseJosn(array(),'更新成功');
}
else if($_GET['op'] == 'formDel'){
	if($_GET['fid']){
		C::t('#fn_fenlei#fn_form')->delete($_GET['fid']);
	}
	saveOperRecordSave('分类表单管理','删除分类表单');
	baseJosn(array(),'删除成功');
}
