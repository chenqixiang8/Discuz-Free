<?php

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
header("Content-type: text/html; charset=utf-8");
@require_once ('common.php');

if($_GET['op'] == 'init'){
	$groupList = array();
	foreach(C::t('#fn_fenlei#fn_fenlei_info_group')->fetch_all_by_list() as $val) {
		$groupList[] = array('value'=>$val['id'],'title'=>$val['title']);
	}
	$data['groupList'] = $groupList;
	baseJosn($data);
}else if($_GET['op'] == 'list'){//列表
	$res = C::t('#fn_fenlei#fn_fenlei_member')->fetch_all_by_list(array('vip'=>$_GET['vip'],'group_id'=>$_GET['group_id'],'keyword'=>$_GET['keyword']),$_GET['page'] - 1,$_GET['limit'],$_GET['sort'],$_GET['order'],true);
	foreach($res['list'] as $key => $val){
		$res['list'][$key]['dateline'] = date('Y-m-d H:i',$val['dateline']);
		$res['list'][$key]['updateline'] = date('Y-m-d H:i',$val['updateline']);
		$res['list'][$key]['vip'] = $val['due_time'] >= time() ? true : false;
		$res['list'][$key]['due_time_form'] = $val['due_time'] ? date('Y-m-d',$val['due_time']) : '';
	}
	baseJosn($res['list'],'',0,$res['count']);
}else if($_GET['op'] == 'save'){
	$item = C::t('#fn_fenlei#fn_fenlei_member')->fetch_by_id($postData['id']);
	$checkUid = C::t('#fn_fenlei#fn_fenlei_member')->fetch_by_uid($postData['uid']);
	if((!$postData['id'] && $checkUid) || ($checkUid && $checkUid['uid'] != $item['uid'])){
		baseJosn(array(),'该用户已存在',201);
	}
	$data['uid'] = intval($postData['uid']);
	$member = DB::fetch_first('SELECT username FROM '.DB::table('common_member').' where uid = '.$data['uid']);
	$data['username'] = addslashes(strip_tags($member['username']));
	$data['name'] = addslashes(strip_tags($postData['name']));
	$data['phone'] = addslashes(strip_tags($postData['phone']));
	$data['phone_verify'] = intval($postData['phone_verify']);
	if($item['id']){
		C::t('#fn_fenlei#fn_fenlei_member')->update($data,$item['id']);
		saveOperRecordSave('用户管理','更新用户');
	}else{
		$data['updateline'] = $data['dateline'] = time();
		C::t('#fn_fenlei#fn_fenlei_member')->insert($data,true);
		saveOperRecordSave('用户管理','添加用户');
	}
	baseJosn(array(),'更新成功');
}else if($_GET['op'] == 'vip'){
	$item = C::t('#fn_fenlei#fn_fenlei_member')->fetch_by_id($postData['id']);
	$groupItem = C::t('#fn_fenlei#fn_fenlei_info_group')->fetch_by_id($postData['group_id']);
	if(!$groupItem){
		baseJosn(array(),'请选择会员级别',201);
	}
	$data['group_id'] = intval($postData['group_id']);
	$data['due_time'] = $postData['due_time_form'] ? strtotime($postData['due_time_form']) : '';
	if($postData['vip_type'] == 1 && $groupItem){
		$groupData['pub_count'] = $groupItem['pub_count'];
		$groupData['refresh_count'] = $groupItem['refresh_count'];
		$groupData['top_day'] = $groupItem['top_day'];
		$groupData['top_discount'] = addslashes(strip_tags($groupItem['top_discount']));
		$groupData['audit_state'] = intval($groupItem['audit_state']);
		$data['vip_expiry_push'] = 0;
		$data['due_time'] = $data['due_time'] > time() ? strtotime("+".intval($groupItem['group_time'])." day",$data['due_time']) : strtotime("+".intval($groupItem['group_time'])." day",time());
	}else if($postData['vip_type'] == 2 && $groupItem){
		$groupData['pub_count'] = intval($postData['pub_count']) + $groupItem['pub_count'];
		$groupData['refresh_count'] = intval($postData['refresh_count']) + $groupItem['refresh_count'];
		$groupData['top_day'] = intval($postData['top_day']) + $groupItem['top_day'];
		$groupData['top_discount'] = addslashes(strip_tags($groupItem['top_discount']));
		$groupData['audit_state'] = intval($groupItem['audit_state']);
		$data['vip_expiry_push'] = 0;
		$data['due_time'] = strtotime("+".intval($groupItem['group_time'])." day",time());
	}else{
		$groupData['pub_count'] = intval($postData['pub_count']);
		$groupData['refresh_count'] = intval($postData['refresh_count']);
		$groupData['top_day'] = intval($postData['top_day']);
		$groupData['top_discount'] = addslashes(strip_tags($postData['top_discount']));
		$groupData['audit_state'] = intval($postData['audit_state']);
	}
	$memberGroupItem = C::t('#fn_fenlei#fn_fenlei_member_group')->fetch_by_mid($item['id']);
	if($item['id']){
		if($groupItem['experience']){
			$data['experience'] = $groupItem['experience'];
		}
		C::t('#fn_fenlei#fn_fenlei_member')->update($data,$item['id']);
		$memberGroupItem ? C::t('#fn_fenlei#fn_fenlei_member_group')->update($groupData,$item['id']) : C::t('#fn_fenlei#fn_fenlei_member_group')->insert(array_merge($groupData,array('mid'=>$item['id'])));
		saveOperRecordSave('用户管理','更新套餐');
	}
	baseJosn(array(),'更新成功');
}