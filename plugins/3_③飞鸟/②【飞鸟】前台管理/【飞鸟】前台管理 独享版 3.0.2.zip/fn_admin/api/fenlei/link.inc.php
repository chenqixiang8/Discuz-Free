<?php

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
header("Content-type: text/html; charset=utf-8");
@require_once ('common.php');
$data = array(
	array('value'=>$fn_fenlei->getUrl('index'),'title'=>'首页链接'),
	array('value'=>$_G['siteurl'].'plugin.php?id=fn_fenlei&app=1','title'=>'首页隐藏底部导航'),
	array('value'=>$fn_fenlei->getUrl('user'),'title'=>'会员中心'),
	array('value'=>$fn_fenlei->getUrl('user',array('form'=>'setmeal')),'title'=>'购买套餐'),
	array('value'=>$fn_fenlei->getUrl('user',array('form'=>'pub')),'title'=>'发布信息')
);
foreach($data as $key => $val){
	$data[$key]['title'] = diconv($val['title'],mb_detect_encoding($val['title'], array('ASCII','UTF-8','GB2312','GBK','BIG5')),CHARSET);
}
baseJosn($data);