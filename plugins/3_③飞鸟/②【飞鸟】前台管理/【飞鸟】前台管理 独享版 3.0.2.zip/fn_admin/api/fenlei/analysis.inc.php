<?php

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
header("Content-type: text/html; charset=utf-8");
@require_once ('common.php');
if($_GET['op'] == 'init'){//列表

	$timesTamp = strtotime(date('Y-m-d'));
	$yesterday = strtotime("-1 day",strtotime(date('Y-m-d')));//昨日
	$endYesterday = strtotime("-1 day",strtotime(date('Y-m-d 23:59:59')));//昨日
	$weekDay = strtotime(date('Y-m-d',$timesTamp - (date('N',$timesTamp)-1) * 86400));//本周第一天
	$endWeekDay = strtotime(date('Y-m-d 23:59:59',strtotime("+6 day",$weekDay)));
	$firstDay = strtotime(date('Y-m-01', strtotime(date("Y-m-d"))));//本月第一天  
	$lastDay = strtotime(date('Y-m-d 23:59:59', strtotime("+1 month -1 day",$firstDay)));//本月最后一天 
	$lastLasDday = strtotime(date('Y-m-01', strtotime('-1 month',$firstDay)));//上个月第一天  
	$lastFirstDay = strtotime(date('Y-m-t 23:59:59', strtotime('-1 month',$firstDay)));//上个月最后一天
	
	//信息统计
	$data['info']['dayCount'] = C::t('#fn_fenlei#fn_fenlei_info')->first_by_count('where i.display = 1 and i.pay_state = 1 and i.dateline >= '.strtotime(date('Y-m-d')).' and i.dateline <='.strtotime(date('Y-m-d 23:59:59')));
	$data['info']['lastDayCount'] = C::t('#fn_fenlei#fn_fenlei_info')->first_by_count('where i.display = 1 and i.pay_state = 1 and i.dateline >='.$yesterday.' and i.dateline <='.$endYesterday);
	$data['info']['weekCount'] = C::t('#fn_fenlei#fn_fenlei_info')->first_by_count('where i.display = 1 and i.pay_state = 1 and i.dateline >= '.$weekDay.' and i.dateline <='.$endWeekDay);
	$data['info']['monthCount'] = C::t('#fn_fenlei#fn_fenlei_info')->first_by_count('where i.display = 1 and i.pay_state = 1 and i.dateline >= '.$firstDay.' and i.dateline <='.$lastDay);
	$data['info']['lastMonthCount'] = C::t('#fn_fenlei#fn_fenlei_info')->first_by_count('where i.display = 1 and i.pay_state = 1 and i.dateline >= '.$lastLasDday.' and i.dateline <='.$lastFirstDay);
	$data['info']['count'] = C::t('#fn_fenlei#fn_fenlei_info')->first_by_count('where i.display = 1 and i.pay_state = 1');

	//销售额
	$source = 'fn_fenlei';
	for($i = 1;$i < 13; $i++){
		$k = $i;
		$YearMonthLast = strtotime(date('Y').'-'.($i > 9 ? $i : '0'.$i).'-01'); 
		$YearMonthFirst = strtotime(date('Y-m-d 23:59:59', strtotime("+1 month -1 day",$YearMonthLast)));
		$saleroomData[$k -1]['month'] = $i.lang('plugin/fn_assembly','month');
		$saleroomData[$k -1]['value'] = C::t('#fn_admin#fn_pay_log')->first_by_money_count('where o.source = \''.$source.'\' and o.refund = 0 and o.state = 1 and o.dateline >= '.$YearMonthLast.' and o.dateline <='.$YearMonthFirst);
		
		$lastSaleroomData[$k -1]['month'] = $i.lang('plugin/fn_assembly','month');
		$lastSaleroomData[$k -1]['value'] = C::t('#fn_admin#fn_pay_log')->first_by_money_count('where o.source = \''.$source.'\' and o.refund = 0 and o.state = 1 and o.dateline >= '.strtotime('-1 year',$YearMonthLast).' and o.dateline <='.strtotime('-1 year',$YearMonthFirst));
	}
	$data['pay']['saleroomData'] = $saleroomData;
	$data['pay']['lastSaleroomData'] = $lastSaleroomData;
	$data['pay']['dayCount'] = C::t('#fn_admin#fn_pay_log')->first_by_money_count('where o.source = \''.$source.'\' and o.refund = 0 and o.state = 1 and o.dateline >= '.strtotime(date('Y-m-d')).' and o.dateline <='.strtotime(date('Y-m-d 23:59:59')));//今日
	$data['pay']['lastDayCount'] = C::t('#fn_admin#fn_pay_log')->first_by_money_count('where o.source = \''.$source.'\' and o.refund = 0 and o.state = 1 and o.dateline >= '.$weekDay.' and o.dateline <='.$endWeekDay);//昨日
	$data['pay']['weekCount'] = C::t('#fn_admin#fn_pay_log')->first_by_money_count('where o.source = \''.$source.'\' and o.refund = 0 and o.state = 1 and o.dateline >= '.$weekDay.' and o.dateline <='.$endWeekDay);//本周
	$data['pay']['monthCount'] = C::t('#fn_admin#fn_pay_log')->first_by_money_count('where o.source = \''.$source.'\' and o.refund = 0 and o.state = 1 and o.dateline >= '.$firstDay.' and o.dateline <='.$lastDay);//本月
	$data['pay']['lastMonthCount'] = C::t('#fn_admin#fn_pay_log')->first_by_money_count('where o.source = \''.$source.'\' and o.refund = 0 and o.state = 1 and o.dateline >= '.$lastLasDday.' and o.dateline <='.$lastFirstDay);//上月
	$data['pay']['count'] = C::t('#fn_admin#fn_pay_log')->first_by_money_count('where o.source = \''.$source.'\' and o.refund = 0 and o.state = 1');//总
	// 销售额 END
	baseJosn($data);
}