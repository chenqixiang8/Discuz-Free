<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}

$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_fn_ad` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `plugin` varchar(30) NOT NULL,
  `classId` varchar(30) NOT NULL,
  `pic` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `startTime` int(11) unsigned NOT NULL,
  `endTime` int(11) unsigned NOT NULL,
  `display` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `displayorder` tinyint(3) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`,`plugin`,`classId`,`display`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_nav` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `plugin` varchar(30) NOT NULL,
  `classId` varchar(30) NOT NULL,
  `icon` varchar(255) NOT NULL,
  `onIcon` varchar(255) NOT NULL,
  `title` varchar(30) NOT NULL,
  `url` varchar(255) NOT NULL,
  `top` tinyint(1) unsigned NOT NULL,
  `display` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `displayorder` tinyint(3) unsigned NOT NULL,
  KEY `id` (`id`,`plugin`,`top`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_html_temp` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `plugin` varchar(30) NOT NULL,
  `classId` varchar(30) NOT NULL,
  `title` varchar(30) NOT NULL,
  `temp` text NOT NULL,
  `display` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `displayorder` tinyint(3) unsigned NOT NULL,
  KEY `id` (`id`,`plugin`,`display`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_notice` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `plugin` varchar(20) NOT NULL,
  `thumb` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `display` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `displayorder` tinyint(3) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`,`plugin`,`display`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_admin_do_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(50) NOT NULL,
  `ip` varchar(20) NOT NULL,
  `action` varchar(255) NOT NULL,
  `doing` varchar(1000) NOT NULL,
  `source` varchar(20) NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_admin_menu` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `parentId` int(11) unsigned NOT NULL,
  `title` varchar(50) NOT NULL,
  `path` varchar(255) NOT NULL,
  `component` varchar(255) NOT NULL,
  `type` tinyint(1) unsigned NOT NULL,
  `openType` tinyint(1) unsigned NOT NULL,
  `sortNumber` tinyint(3) unsigned NOT NULL,
  `authority` varchar(50) NOT NULL,
  `target` varchar(20) NOT NULL DEFAULT '_self',
  `icon` varchar(20) NOT NULL,
  `color` varchar(20) NOT NULL,
  `hide` tinyint(1) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`,`parentId`,`type`,`sortNumber`,`hide`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_admin_oper_record` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userId` int(11) unsigned NOT NULL,
  `project` varchar(30) NOT NULL,
  `model` varchar(50) NOT NULL,
  `description` varchar(30) NOT NULL,
  `url` varchar(255) NOT NULL,
  `requestMethod` varchar(10) NOT NULL,
  `param` text NOT NULL,
  `ip` varchar(20) NOT NULL,
  `state` tinyint(1) unsigned NOT NULL,
  `spendTime` varchar(20) NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`,`userId`,`model`,`description`,`state`),
  KEY `project` (`project`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_admin_organization` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `parentId` int(11) unsigned NOT NULL,
  `type` tinyint(3) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `fullName` varchar(255) NOT NULL,
  `comments` varchar(255) NOT NULL,
  `sortNumber` tinyint(3) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`,`parentId`,`type`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_admin_role` (
  `id` int(1) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(20) NOT NULL,
  `name` varchar(20) NOT NULL,
  `comments` varchar(255) NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`,`code`,`name`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_admin_role_menu` (
  `roleId` int(11) unsigned NOT NULL,
  `menuId` int(11) unsigned NOT NULL,
  KEY `roleId` (`roleId`,`menuId`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_admin_staff` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `bbsUid` int(11) unsigned NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `code` varchar(30) NOT NULL,
  `name` varchar(20) NOT NULL,
  `sex` tinyint(1) unsigned NOT NULL,
  `phone` varchar(20) NOT NULL,
  `wx` varchar(255) NOT NULL,
  `avatar` varchar(255) NOT NULL,
  `introduction` varchar(255) NOT NULL,
  `idCard` varchar(255) NOT NULL,
  `birthDay` varchar(30) NOT NULL,
  `position` varchar(30) NOT NULL,
  `organizationId` int(11) unsigned NOT NULL,
  `state` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `roleId` int(11) unsigned NOT NULL,
  `entryTime` int(11) unsigned NOT NULL,
  `departureTime` int(11) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`,`username`,`name`,`sex`,`organizationId`,`state`,`roleId`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_admin_user` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(50) NOT NULL,
  `groupid` int(11) unsigned NOT NULL,
  `disable` tinyint(1) unsigned NOT NULL,
  `param` mediumtext NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_admin_user_group` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL,
  `groups` text NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

EOF;

runquery($sql);

@require_once (DISCUZ_ROOT .'./source/plugin/fn_admin/initial_data/'.(CHARSET == 'utf-8' ? 'utf-8' : 'gbk').'/admin_menu.php');

@rename(DISCUZ_ROOT.'./source/plugin/fn_admin/admin',DISCUZ_ROOT.'./fadmin');

$finish = TRUE;
?>