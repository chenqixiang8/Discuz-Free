<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

@require_once libfile('class/pay','plugin/fn_assembly');

class Fn_Admin{
	public function __construct() {
		global $_G,$plugin;
		loadcache('plugin');
		$this->Config['PluginVar'] = (array) $_G['cache']['plugin']['fn_admin'];
		$this->Config['LangVar'] = lang('plugin/fn_admin');
		$this->Config['Path'] = 'source/plugin/fn_admin';
		$this->Config['StaticPath'] = $this->Config['Path'].'/static';
		$this->Config['NewStaticPath'] = $this->Config['Path'].'/static/new';
		$this->Config['StaticPicPath'] = $this->Config['Path'].'/attachment/';
		$this->Config['Url'] = ($this->Config['PluginVar']['AdminLink'] ? $this->Config['PluginVar']['AdminLink'] : $this->IsHttps().$_SERVER['HTTP_HOST']).'/plugin.php?id=fn_admin';
	
		$this->TableUser = 'fn_admin_user';
		$this->TableUserGroup = 'fn_admin_user_group';
		$this->TableDoLog = 'fn_admin_do_log';

		$this->Config['AdminUserInfo'] = $this->GetUserInfo();
		$this->Pay = new Fn_PayLog();
	}

	/* �û����� */
	public function GetUserInfo(){
		global $_G;
		$UserInfo = DB::fetch_first('SELECT G.groups,U.* FROM '.DB::table($this->TableUser).' U LEFT JOIN '.DB::table($this->TableUserGroup).' G on G.id = U.groupid where uid = '.$_G['uid']);
		if($UserInfo){
			@require_once libfile('function/forum');
			$UserInfo['param'] = unserialize($UserInfo['param']);
			$UserInfo['groups'] = unserialize($UserInfo['groups']);
			$UserInfo['face'] = discuz_uc_avatar($_G['uid'],middle,true);
		}
		return $UserInfo;

	}

	/* Ȩ���ж� */
	public function CheckUserGroup($Group){
		global $_G;
		return in_array($Group,$this->Config['AdminUserInfo']['groups']) ? true : false;
	}

	/*  ͼƬ�ϴ� */
	public function Upload($Files,$DelUsedFiles=null){
		global $_G;
		require_once (DISCUZ_ROOT.'./source/class/discuz/discuz_upload.php');
		$Upload = new discuz_upload();
		if($Upload->init($Files, 'common') && $Upload->save(0)) {
			$Path = $_G['setting']['attachurl'].'common/'.$Upload->attach['attachment'];
			/*$Name = explode('/',$Upload->attach['attachment']);
			$MPicUrl = DISCUZ_ROOT.$this->Config['StaticPicPath'].$Name[1];
			if(copy($Upload->attach['target'],$MPicUrl)){
				$Path = $this->Config['StaticPicPath'].$Name[1];
				unlink($Upload->attach['target']);
				unlink(DISCUZ_ROOT.$DelUsedFiles);
			}*/
			$File['Path'] = $Path;
			return $File;
		}else{
			$File['Errorcode'] = $Upload->errorcode;
			return $File;
		}
	}

	public function GetFullUrl(){
		# ���ͨ������
		$RequestUri = '';
		if (isset($_SERVER['REQUEST_URI'])) {
			$RequestUri = $_SERVER['REQUEST_URI'];
		}else{
			if(isset($_SERVER['argv'])) {
				$RequestUri = $_SERVER['PHP_SELF'] .'?'. $_SERVER['argv'][0];
			}else if(isset($_SERVER['QUERY_STRING'])) {
				$RequestUri = $_SERVER['PHP_SELF'] .'?'. $_SERVER['QUERY_STRING'];
			}
		}
		//�˿ڻ�������Ҫ�ģ��Ͼ���Ҫ��������ĳ���
		$Port = ($_SERVER["SERVER_PORT"] == "80" || $_SERVER['HTTPS']) ? "" : (":".$_SERVER["SERVER_PORT"]);
		# ��ȡ������url
		$FullUrl = $this->IsHttps().$_SERVER['HTTP_HOST'].$Port.$RequestUri;
		return $FullUrl;
	}

	//����Ƿ�https
	public function IsHttps(){
		$Http = ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https') || (isset($_SERVER['HTTP_X_CLIENT_SCHEME']) && $_SERVER['HTTP_X_CLIENT_SCHEME'] == 'https')) ? 'https://' : 'http://';
		return $Http;
	}
	
	/* һά����ת��ά���� */
	public function DyadicArray($Array){
		$DyadicArray = array();
		foreach($Array as $K => $V) {
			$DyadicArray[] = array($K,$V);
		}
		return $DyadicArray;
	}

	/* ��ѯ���� */
	public function QueryOne($TableName=null,$Id=null,$Where=null){
		$FirstSql = 'SELECT * FROM '.DB::table($TableName).' where id = '.$Id.' '.$Where;
		return DB::fetch_first($FirstSql);	
	}

	/* 
	�޸ı�������
	table_name=>
	ids=>Array
	fields=>�ֶ�
    val=>ֵ
	*/
	public function EditFields($TableName,$Array,$Fields,$Val){
		foreach($Array as $Field => $Ids) {
			if(is_array($Ids)){
				$Ids = implode(',',$Ids);
			}else{
				$Ids = intval($Ids);
			}
			$WhereField = $Field;
		}
		
		$UpData[$Fields] = $Val;
		if(DB::update($TableName,$UpData,$WhereField.' in( '.$Ids.' )')){
			return true;
		}else{
			return false;
		}
	}

	public function uploadFiles($files,$err = true){
		$data = array();
		foreach($files as $file_key => $file_value){
			if(strpos($file_key,'new_') !== false){
				$key = str_replace(array('TMPnew_','new_'),'',$file_key);
				if($files[$file_key]['size']){
					$fileCode = Fn_Upload($files[$file_key]);
					if($fileCode['Errorcode'] && $err){
						fn_cpmsg($this->Config['LangVar']['ImgErr'],'','error');
						exit();
					}else{
						$data[$key] = $fileCode['Path'];
					}
				}else{
					$file_key = str_replace(array('TMPnew_'),array('new_'),$file_key);
					if(!preg_match('/.*(\.png|\.jpg|\.jpeg|\.gif)$/',$_GET[$file_key]) && $_GET[$file_key] && $err){
						fn_cpmsg($this->Config['LangVar']['ImgErr'],'','error');
						exit();
					}else{
						$data[$key] = addslashes(strip_tags($_GET[$file_key]));
					}
				}
			}
		}
		return $data;
	}
}
$Fn_Admin = new Fn_Admin;
?>