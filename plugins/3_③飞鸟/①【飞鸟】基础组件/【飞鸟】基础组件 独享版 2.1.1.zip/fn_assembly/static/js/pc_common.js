var Appbyme = navigator.userAgent.match(/Appbyme/i) ? true : false;
var MagApp = navigator.userAgent.match(/MAGAPPX/i) ? true : false;
var QFApp = navigator.userAgent.match(/QianFan/i) ? true : false;
var WxApp = navigator.userAgent.match(/MicroMessenger/i) ? true : false;
var MinWxApp = window.__wxjs_environment === 'miniprogram' ? true : false;
var Ios = navigator.userAgent.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/) ? true : false; //ios�ն�
var Android = navigator.userAgent.indexOf('Android') > -1 || navigator.userAgent.indexOf('Adr') > -1 ? true : false;

function JumpUrl(Url,Callback){

	if(Appbyme){
		connectSQJavascriptBridge(function(){});
		sq.urlRequest(Url);
	}else if(MagApp){
		mag.newWin(Url);
	}else if(QFApp){
		QFH5.jumpNewWebview(Url);
	}else if(MinWxApp){
		wx.miniProgram.navigateTo({url:'/pages/index/index?url='+encodeURIComponent(Url)});
	}else{
		if (Callback && typeof Callback === 'function' && Android && WxApp) Callback();//ִ�з��غ���
		window.location.href = Url;
	}
}

function WinClose(Url,Back){
	if(Appbyme){
		sq.closeActivity();
	}else if(MagApp){
		mag.closeWin();
	}else if(QFApp){
		QFH5.close();
	}else if(MinWxApp){
		wx.miniProgram.navigateBack();
	}else{
		/*if(Back == true){
			if(document.referrer != ''){
				history.back();
			}else{
				window.location.href = Url;
			}
		}else{*/
			window.location.href = Url;
		//}
	}
}

$.fn.SerializeJson = function(OtherString){
	var SerializeObj = {},array = this.serializeArray();
	$(array).each(function(){
		if(SerializeObj[this.name]){
			SerializeObj[this.name] += ';'+encodeURI(encodeURI(this.value));
		}else{
			SerializeObj[this.name] = encodeURI(encodeURI(this.value));
		}
	});

	if(OtherString != undefined){
		var OtherArray = OtherString.split(';');
		$(OtherArray).each(function(){
			var OtherSplitArray = this.split(':');
			SerializeObj[OtherSplitArray[0]] = URI == true ? encodeURI(encodeURI(OtherSplitArray[1])) : OtherSplitArray[1];
		});
	}

	return SerializeObj;
};

// �ֲ���ͷ��װ
$.fn.slideBtn = function(){
    var that = $(this);
    that.mouseenter(function() {
        that.find(".preBtn,.nextBtn").fadeIn(600);
    }).mouseleave(function() {
        that.find(".preBtn,.nextBtn").fadeOut(600);
    });
}