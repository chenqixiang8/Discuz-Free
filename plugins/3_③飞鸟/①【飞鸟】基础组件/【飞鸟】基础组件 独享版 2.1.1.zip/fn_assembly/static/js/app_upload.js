window['siteroot'] = typeof(window['siteroot']) == 'undefined' ? '' : window['siteroot'];
(function ($) {
    $.fn.AppUpload = function(options) {
		var FnApp = {
			MagApp: function() {
				return navigator.userAgent.match(/MAGAPPX/i) ? true: false;
			},
			Appbyme: function() {
				return navigator.userAgent.match(/Appbyme/i) ? true: false;
			},
			QFApp: function() {
				return navigator.userAgent.match(/QianFan/i) ? true: false;
			},
			WxApp: function() {
				return navigator.userAgent.match(/MicroMessenger/i) && !navigator.userAgent.match(/WindowsWechat/i) ? true: false;
			},
			iPhoneApp: function() {
				return navigator.userAgent.match(/(iPhone|iPad|iPod|iOS)/i) ? true: false;
			}
		};
		var FnHtml = function(ImgLink){
			var ReplaceFiledataInput = '';
			var ImgTitle = '';
			var ImgHref = '';
			if((options.InputTitle == true || options.InputLink == true)){
				var ImgArray = ImgLink.split('|');
				ImgLink = ImgArray[0];
				ImgTitle = ImgArray[1] != undefined ? ImgArray[1] : '';
				ImgHref = ImgArray[2] != undefined ? ImgArray[2] : '';
			}
			var title_html = options.InputTitle == true ? '<div class="ImgTitle"><span class="title">\u6807\u9898</span><input type="text" name="'+options.InputName+'_title[]" value="'+ImgTitle+'"></div>' : '';
			var title_link = options.InputLink == true ? '<div class="ImgLink"><span class="title">\u94fe\u63a5</span><input type="text" name="'+options.InputName+'_link[]" value="'+ImgHref+'"></div>' : '';
			if((!FnApp.MagApp() && !FnApp.Appbyme() && !FnApp.WxApp() && !FnApp.QFApp()) || (FnApp.QFApp() && parseInt(UploadConfig.QFVERSION) < 4)){
				ReplaceFiledataInput = '<input type="file" class="ReplaceFiledata" name="ReplaceFiledata[]"/>';
			}
			return '<div class="PhotoControl PhotoControlApp PhotoControlApp_'+options.InputName+'"><div class="PhotoControlDiv">'+ (options.Move == true ? '<span class="Move">\u524d\u79fb</span>' : '')+'<span class="Close" style="display:block;"></span> <i class="icon-plus">+</i><div class="FilePic" style="display:block;"><table cellpadding="0" cellspacing="0"><tr><td><div class="PhotoControlImg" style="background:url('+ImgLink+') no-repeat center;background-size:contain;"></div><input type="hidden" name="'+options.InputName+'[]" value="'+ImgLink+'" class="InputFile"/></td></tr></table></div>'+ReplaceFiledataInput+'</div>'+title_html+title_link+'</div>';
		}

		function FnAjaxUpload(opt){
			var iName=opt.frameName; // ̫���ˣ���̵�
			var iframe,form,file,fileParent;
			// ����iframe��form����
			iframe = $('<iframe name="'+iName+'" />');
			form = $('<form method="post" style="display:n1one;" target="'+iName+'" action="'+opt.url+'"  name="form_'+iName+'" enctype="multipart/form-data" />');
			file = opt.id; // ͨ��id��ȡflie�ؼ�
			fileParent = file.parent(); // �游��
			file.appendTo(form);
			// ����body
			$(document.body).append(iframe).append(form);

			// ȡ����ѡ�ļ�����չ��
			var fileFormat=/\.[a-zA-Z]+$/.exec(file.val())[0].substring(1);
			if(opt.format.join('-').indexOf(fileFormat)!=-1){
				form.submit();// ��ʽͨ����֤���ύ����;
			}else{
				file.appendTo(fileParent); // ��file�ؼ��Żص�ҳ��
				iframe.remove();
				form.remove();
				alert(UploadConfig.uploadpicfailed);
			};

			// �ļ��ύ���
			iframe.load(function(){
				var data = $(this).contents().find('body').html();
				file.appendTo(fileParent);
				iframe.remove();
				form.remove();
				opt.callBack(data);
			})
		}
		
		return $(this).each(function() { 
			$.fn.AppUpload.deflunt={
				InputName:'imgs',//ͼƬ����Name
				Multiple:false,//�Ƿ񵥸�ͼ
				Move:false,//�����ƶ�
				InputExist:false,//�Ƿ���ر���ͼƬ
				InputTitle:false,//�Ƿ�������д����
				InputLink:false,//�Ƿ�������д����
				InputArray:[]//����
			};
			
			var opts = $.extend({},$.fn.AppUpload.deflunt,options);
			var _This = $(this);
			_This.append('<input type="hidden" name="upload_admin['+opts.InputName+']" value="">');
			if(opts.InputExist){
				for(let i in opts.InputArray) {
					_This.before(FnHtml(opts.InputArray[i]));
				}
			}
			//��App��ͼ�ϴ�
			if((!FnApp.MagApp() && !FnApp.Appbyme() && !FnApp.WxApp() && !FnApp.QFApp()) || (FnApp.QFApp() && parseInt(UploadConfig.QFVERSION) < 4)){
				var Filedata = _This.find('.Filedata');
				Filedata.on('change', function() {//�ϴ�ͼƬ
					if(this.files){
						for(var i = 0; i < this.files.length; i++) {
							$('.fixed_load').show();
							var files1 = [];
							files1.push(this.files[i]);
							$.buildfileupload({
								uploadurl: window['siteroot']+'plugin.php?id=fn_assembly:swf_upload&operation='+UploadConfig.operation+'&type=image&inajax=yes&infloat=yes&simple=2&source='+UploadConfig.source,
								files: files1,
								uploadformdata: {uid:UploadConfig.Uid,hash:UploadConfig.Auth},
								uploadinputname: 'Filedata',
								maxfilesize:UploadConfig.MaxFileSize,
								success: function(Data){
									$('.fixed_load').hide();
									if(UploadConfig.operation == 'upload'){
										if(Data == ''){
											alert(UploadConfig.uploadpicfailed);
											return false;
										}
										var DataArray = Data.split('|');
										if(DataArray[0] == 'DISCUZUPLOAD' && DataArray[2] == 0){
											var ImgLink = DataArray[5];
											if(opts.Multiple){
												_This.siblings('.PhotoControlApp').remove()
											}
											_This.before(FnHtml(ImgLink));
										}else{
											var sizelimit = '';
											if(DataArray[7] == 'ban') {
												sizelimit = UploadConfig.uploadpicatttypeban;
											} else if(DataArray[7] == 'perday') {
												sizelimit = UploadConfig.donotcross+Math.ceil(DataArray[8]/1024)+'K)';
											} else if(DataArray[7] > 0) {
												sizelimit = UploadConfig.donotcross+Math.ceil(DataArray[7]/1024)+'K)';
											}
											alert(STATUSMSG[DataArray[2]] + sizelimit);
										}
									}else if(UploadConfig.operation == 'poll'){
										var DataArray = JSON.parse(Data);
										if(DataArray.errorcode == 0 && DataArray.aid != 0){
											var ImgLink = DataArray.bigimg;
											if(opts.Multiple){
												_This.siblings('.PhotoControlApp').remove()
											}
											_This.before(FnHtml(ImgLink));
										}else{
											alert(STATUSMSG[DataArray.errorcode]);
										}
									}
									
								},
								error:function(){
									$('.fixed_load').hide();
									alert(UploadConfig.uploadpicfailed);
								}
							});
						}
					}else{
						$('.fixed_load').show();
						FnAjaxUpload({
							id:$(this),
							frameName:'frameName',
							url:window['siteroot']+'plugin.php?id=fn_assembly:ie_upload&source='+UploadConfig.source,
							format:['jpg','png','gif','bmp'],
							callBack:function (Data) {
								$('.fixed_load').hide();
								if(UploadConfig.operation == 'upload'){
									if(Data == ''){
										//alert(UploadConfig.uploadpicfailed);
										return false;
									}
									var DataArray = Data.split('|');
									if(DataArray[0] == 'DISCUZUPLOAD' && DataArray[2] == 0){
										var ImgLink = DataArray[5];
										if(opts.Multiple){
											_This.siblings('.PhotoControlApp').remove()
										}
										_This.before(FnHtml(ImgLink));
									}else{
										var sizelimit = '';
										if(DataArray[7] == 'ban') {
											sizelimit = UploadConfig.uploadpicatttypeban;
										} else if(DataArray[7] == 'perday') {
											sizelimit = UploadConfig.donotcross+Math.ceil(DataArray[8]/1024)+'K)';
										} else if(DataArray[7] > 0) {
											sizelimit = UploadConfig.donotcross+Math.ceil(DataArray[7]/1024)+'K)';
										}
										alert(STATUSMSG[DataArray[2]] + sizelimit);
									}
								}else if(UploadConfig.operation == 'poll'){
									var DataArray = Data.split('|');
									if(DataArray[3] == 0 && DataArray[0] != 0){
										var ImgLink = DataArray[2];
										if(opts.Multiple){
											_This.siblings('.PhotoControlApp').remove()
										}
										_This.before(FnHtml(ImgLink));
									}else{
										//alert(STATUSMSG[DataArray[3]]);
									}
								}
							}
						});
					}
				});

				//�滻ͼƬ
				$(document).on('change','.PhotoControlApp_'+opts.InputName+' .ReplaceFiledata',function(){
					var _FilePic =  $(this).siblings('.FilePic');
					var _ImgThis = _FilePic.find('.PhotoControlImg');
					var _InputFile = _FilePic.find('.InputFile');
					if(this.files){
						for(var i = 0; i < this.files.length; i++) {
							$('.fixed_load').show();
							var files1 = [];
							files1.push(this.files[i]);
							$.buildfileupload({
								uploadurl: window['siteroot']+'plugin.php?id=fn_assembly:swf_upload&operation='+UploadConfig.operation+'&type=image&inajax=yes&infloat=yes&simple=2&source='+UploadConfig.source,
								files: files1,
								uploadformdata: {uid:UploadConfig.Uid,hash:UploadConfig.Auth},
								uploadinputname: 'Filedata',
								maxfilesize:UploadConfig.MaxFileSize,
								success: function(Data){
									$('.fixed_load').hide();
									if(UploadConfig.operation == 'upload'){
										if(Data == ''){
											alert(UploadConfig.uploadpicfailed);
											return false;
										}
										var DataArray = Data.split('|');
										if(DataArray[0] == 'DISCUZUPLOAD' && DataArray[2] == 0){
											var ImgLink = DataArray[5];
											_ImgThis.css("background-image",'url('+ImgLink+')');
											_InputFile.val(ImgLink);
										}else{
											var sizelimit = '';
											if(DataArray[7] == 'ban') {
												sizelimit = UploadConfig.uploadpicatttypeban;
											} else if(DataArray[7] == 'perday') {
												sizelimit = UploadConfig.donotcross+Math.ceil(DataArray[8]/1024)+'K)';
											} else if(DataArray[7] > 0) {
												sizelimit = UploadConfig.donotcross+Math.ceil(DataArray[7]/1024)+'K)';
											}
											alert(STATUSMSG[DataArray[2]] + sizelimit);
										}
									}else if(UploadConfig.operation == 'poll'){
										var DataArray = JSON.parse(Data);
										if(DataArray.errorcode == 0 && DataArray.aid != 0){
											var ImgLink = DataArray.bigimg;
											_ImgThis.css("background-image",'url('+ImgLink+')');
											_InputFile.val(ImgLink);
										}else{
											alert(STATUSMSG[DataArray.errorcode]);
										}
									}
								},
								error:function(){
									$('.fixed_load').hide();
									alert(UploadConfig.uploadpicfailed);
								}
							});
						}
					}else{
						$('.fixed_load').show();
						FnAjaxUpload({
							id:$(this),
							frameName:'frameName',
							url:window['siteroot']+'plugin.php?id=fn_assembly:ie_upload&source='+UploadConfig.source,
							format:['jpg','png','gif','bmp'],
							callBack:function (Data) {
								$('.fixed_load').hide();
								if(UploadConfig.operation == 'upload'){
									if(Data == ''){
										//alert(UploadConfig.uploadpicfailed);
										return false;
									}
									var DataArray = Data.split('|');
									if(DataArray[0] == 'DISCUZUPLOAD' && DataArray[2] == 0){
										var ImgLink = DataArray[5];
										_ImgThis.css("background-image",'url('+ImgLink+')');
										_InputFile.val(ImgLink);
									}else{
										var sizelimit = '';
										if(DataArray[7] == 'ban') {
											sizelimit = UploadConfig.uploadpicatttypeban;
										} else if(DataArray[7] == 'perday') {
											sizelimit = UploadConfig.donotcross+Math.ceil(DataArray[8]/1024)+'K)';
										} else if(DataArray[7] > 0) {
											sizelimit = UploadConfig.donotcross+Math.ceil(DataArray[7]/1024)+'K)';
										}
										alert(STATUSMSG[DataArray[2]] + sizelimit);
									}
								}else if(UploadConfig.operation == 'poll'){
									var DataArray = Data.split('|');
									if(DataArray[3] == 0 && DataArray[0] != 0){
										var ImgLink = DataArray[2];
										_ImgThis.css("background-image",'url('+ImgLink+')');
										_InputFile.val(ImgLink);
									}else{
										//alert(STATUSMSG[DataArray[3]]);
									}
								}
							}
						});
					}
					
				});
				//�滻ͼƬ End
			}
			//��App��ͼ�ϴ� End

			/* ΢�ų�ʼ�� */
			if(FnApp.WxApp()){
				wx.config({
					debug:false,
					appId: UploadConfig.appId,
					timestamp: UploadConfig.timestamp,
					nonceStr: UploadConfig.nonceStr,
					signature: UploadConfig.signature,
					jsApiList: ['checkJsApi', 'onMenuShareTimeline', 'onMenuShareAppMessage', 'onMenuShareQQ', 'onMenuShareWeibo', 'hideMenuItems', 'showMenuItems', 'hideAllNonBaseMenuItem', 'showAllNonBaseMenuItem', 'translateVoice', "openLocation", "getLocation", "chooseImage", "previewImage", "uploadImage"]
				});
			}
			/* ΢�ų�ʼ�� End */

			//App�ϴ�ͼƬ
			_This.on('click',function(){
				
				if(FnApp.MagApp()){//����App�ϴ�ͼƬ
					mag.picPick({
					  preview: function(res){
						 $('.fixed_load').show();
					  },
					  success: function(res){
						if(opts.Multiple){
							_This.siblings('.PhotoControlApp').remove()
						}
						var ImgLink = typeof(res.url) == "undefined" || res.url.toLowerCase().indexOf('storage') >= 0 ? UploadConfig.MagDomain+'/core/attachment/attachment/attach?aid='+res.aid : res.url;
						_This.before(FnHtml(ImgLink));
						$('.fixed_load').hide();
					  },
					  fail: function(res){
						$('.fixed_load').hide();
						mag.toast(UploadConfig.uploadpicfailed);
					  },
					});
					return false;
				}else if(FnApp.QFApp() && parseInt(UploadConfig.QFVERSION) >= 4){//ǧ��App�ϴ�ͼƬ
					$('.fixed_load').show();
					var Count = opts.Multiple ? 1 : 9;
					var jsUploadOptions = {
						'picFormat': 0,
						'picMaxSize': 1200,
						'compressOption':UploadConfig.CompressOption,
						'uploadNum': Count,
						'uploadType': 0,
						'showCamera':false
					}
					QFH5.uploadImageOrVideo(0,JSON.stringify(jsUploadOptions), function (State, Data) {
						if(State == 1){
							for(var I in Data){
								if(opts.Multiple){
									_This.siblings('.PhotoControlApp').remove()
								}
								var ImgLink = Data[I].url;
								_This.before(FnHtml(ImgLink));
								if(I == Data.length -1){
									$('.fixed_load').hide();
								}
							}
						}else{
							$('.fixed_load').hide();
						}
					});
					return false;
				}else if(FnApp.Appbyme()){//С��App�ϴ�ͼƬ
					sq3.startPhotoUpload({
						moduleType:'plugin',//�����ϴ���Դģ��('forum�����ӣ�album����ᣬpm��˽�ţ�topic:����, plugin:�����Ĭ�ϣ�plugin)
						beforeAsyncProcess: function(data) {
							$('.fixed_load').show();
						},
						success: function(data) {
							$('.fixed_load').hide();
							$.each(data, function(Index, Obj) {
								if(opts.Multiple){
									_This.siblings('.PhotoControlApp').remove()
								}
								if(FnApp.iPhoneApp()){
									_This.before(FnHtml(Obj.urlName));
								}else{
									_This.before(FnHtml(Obj.picPath));
								}
								
							});
							
						},
						error: function(data) {
							$('.fixed_load').hide();
							sq3.toast({text:data.errMsg,isLong: false});
						},
						complete: function(result) {
							
						}
					});
					return false;
				}else if(FnApp.WxApp()){//΢���ϴ�ͼƬ
					var WxCount = opts.Multiple ? 1 : 9;
					var images = {localId:[]};  
					wx.chooseImage({//ѡ��ͼƬ
						count: WxCount, // ������ѡ���ͼƬ������Ĭ��9
						sizeType: ['compressed'], // original ԭͼ��compressed ѹ��ͼ��Ĭ�϶��߶���
						success: function (res) {
							images.localId = res.localIds;// ����ѡ����Ƭ�ı���ID�б���localId������Ϊimg��ǩ��src������ʾͼƬ
							var i = 0, length = images.localId.length;
							images.serverId = "";
							function Fn_Upload() { 
								wx.uploadImage({ 
									localId: images.localId[i], 
									success: function(res) { 
										i++; 
										images.serverId += ("&serverId[]="+res.serverId);
										if(i < length) { 
											Fn_Upload(); 
										}else{
											$.ajax({
												type: "GET",
												url: window['siteroot']+"plugin.php?id=fn_assembly:wx_download"+images.serverId+'&source='+UploadConfig.source,
												dataType: "json",
												beforeSend:function(XMLHttpRequest){
													$('.fixed_load').show();
												},
												success: function(Data){
													$('.fixed_load').hide();
													if(!Data || Data.length <1) {
														alert(UploadConfig.uploadpicfailed);
														return false;
													}
													for(var i=0; i<Data.length; i++){
														var DataArray = Data[i].split('|');
														if(UploadConfig.operation == 'upload'){
															if(DataArray[0] == 'DISCUZUPLOAD' && DataArray[2] == 0){
																if(opts.Multiple){
																	_This.siblings('.PhotoControlApp').remove()
																}
																var ImgLink = DataArray[5];
																_This.before(FnHtml(ImgLink));
															}else{
																var sizelimit = '';
																if(DataArray[7] == 'ban') {
																	sizelimit = UploadConfig.uploadpicatttypeban;
																} else if(DataArray[7] == 'perday') {
																	sizelimit = UploadConfig.donotcross+Math.ceil(DataArray[8]/1024)+'K)';
																} else if(DataArray[7] > 0) {
																	sizelimit = UploadConfig.donotcross+Math.ceil(DataArray[7]/1024)+'K)';
																}
																alert(STATUSMSG[DataArray[2]] + sizelimit);
															}
														}else if(UploadConfig.operation == 'poll'){
															if(DataArray[3] == 0 && DataArray[0] != 0){
																if(opts.Multiple){
																	_This.siblings('.PhotoControlApp').remove()
																}
																var ImgLink = DataArray[2];
																_This.before(FnHtml(ImgLink));
															}else{
																alert(STATUSMSG[DataArray[3]]);
															}
														}

													}
												},
												error:function(XMLHttpRequest){
													$('.fixed_load').hide();
												}
											});
										}
									}, 
									fail: function(res) { 
										alert(JSON.stringify(res)); 
									} 
								}); 
							} 
							Fn_Upload();
						}
					});
					return false;
				}

			});
			$(document).on('click',".PhotoControlApp .PhotoControlImg",function(){//�滻ͼƬ
				var _ImgThis =  $(this);
				var _InputFile =  $(this).siblings('.InputFile');
				if(FnApp.MagApp()){//����App�滻ͼƬ
					mag.picPick({
						preview: function(res){
							$('.fixed_load').show();
						},
						success: function(res){
							var ImgLink = typeof(res.url) == "undefined" || res.url.toLowerCase().indexOf('storage') >= 0 ? UploadConfig.MagDomain+'/core/attachment/attachment/attach?aid='+res.aid : res.url;
							_ImgThis.css("background-image",'url('+ImgLink+')');
							_InputFile.val(ImgLink);
							$('.fixed_load').hide();
						},
						fail: function(res){
							$('.fixed_load').hide();
							mag.toast(UploadConfig.uploadpicfailed);
						},
					});
				}else if(FnApp.QFApp() && parseInt(UploadConfig.QFVERSION) >= 4){//ǧ��App�ϴ�ͼƬ
					$('.fixed_load').show();
					var Count = 1;
					var jsUploadOptions = {
						'picFormat': 0,
						'picMaxSize': 1200,
						'compressOption':UploadConfig.CompressOption,
						'uploadNum': Count,
						'uploadType': 0,
						'showCamera':false
					}
					QFH5.uploadImageOrVideo(0,JSON.stringify(jsUploadOptions), function (State, Data) {
						if(State == 1){
							for(var I in Data){
								var ImgLink = Data[I].url;
								_ImgThis.css("background-image",'url('+ImgLink+')');
								_InputFile.val(ImgLink);
								$('.fixed_load').hide();
							}
						}else{
							$('.fixed_load').hide();
						}
					});
					return false;
				}else if(FnApp.Appbyme()){//С��App�滻ͼƬ
					sq3.startPhotoUpload({
						moduleType:'plugin',//�����ϴ���Դģ��('forum�����ӣ�album����ᣬpm��˽�ţ�topic:����, plugin:�����Ĭ�ϣ�plugin)
						beforeAsyncProcess: function(data) {
							$('.fixed_load').show();
						},
						success: function(data) {
							$('.fixed_load').hide();
							$.each(data, function(Index, Obj) {
								if(FnApp.iPhoneApp()){
									_ImgThis.css("background-image",'url('+Obj.urlName+')');
									_InputFile.val(Obj.urlName);
								}else{
									_ImgThis.css("background-image",'url('+Obj.picPath+')');
									_InputFile.val(Obj.picPath);
								}
							});
							
						},
						error: function(data) {
							$('.fixed_load').hide();
							sq3.toast({text:data.errMsg,isLong: false});
						},
						complete: function(result) {
							
						}
					});
				}else if(FnApp.WxApp()){//΢���滻ͼƬ
					var images = {localId:[]};
					wx.chooseImage({//ѡ��ͼƬ
						count: 1, // ������ѡ���ͼƬ������Ĭ��9
						sizeType: ['compressed'], // original ԭͼ��compressed ѹ��ͼ��Ĭ�϶��߶���
						success: function (res) {
							images.localId = res.localIds;// ����ѡ����Ƭ�ı���ID�б���localId������Ϊimg��ǩ��src������ʾͼƬ
							var i = 0, length = images.localId.length;
							images.serverId = "";
							function Fn_Upload() { 
								wx.uploadImage({ 
									localId: images.localId[i], 
									success: function(res) { 
										i++; 
										images.serverId += ("&serverId[]="+res.serverId);
										if(i < length) { 
											Fn_Upload(); 
										}else{
											$.ajax({
												type: "GET",
												url: window['siteroot']+"plugin.php?id=fn_assembly:wx_download"+images.serverId+'&source='+UploadConfig.source,
												dataType: "json",
												beforeSend:function(XMLHttpRequest){
													$('.fixed_load').show();
												},
												success: function(Data){
													$('.fixed_load').hide();
													if(!Data || Data.length <1) {
														alert(UploadConfig.uploadpicfailed);
														return false;
													}
													for(var i=0; i<Data.length; i++){
														var DataArray = Data[i].split('|');
														if(UploadConfig.operation == 'upload'){
															if(DataArray[0] == 'DISCUZUPLOAD' && DataArray[2] == 0){
																var ImgLink = DataArray[5];
																_ImgThis.css("background-image",'url('+ImgLink+')');
																_InputFile.val(ImgLink);
															}else{
																var sizelimit = '';
																if(DataArray[7] == 'ban') {
																	sizelimit = UploadConfig.uploadpicatttypeban;
																} else if(DataArray[7] == 'perday') {
																	sizelimit = UploadConfig.donotcross+Math.ceil(DataArray[8]/1024)+'K)';
																} else if(DataArray[7] > 0) {
																	sizelimit = UploadConfig.donotcross+Math.ceil(DataArray[7]/1024)+'K)';
																}
																alert(STATUSMSG[DataArray[2]] + sizelimit);
															}
														}else if(UploadConfig.operation == 'poll'){
															if(DataArray[3] == 0 && DataArray[0] != 0){
																var ImgLink = DataArray[2];
																_ImgThis.css("background-image",'url('+ImgLink+')');
																_InputFile.val(ImgLink);
															}else{
																alert(STATUSMSG[DataArray[3]]);
															}
														}
														
													}
												},
												error:function(XMLHttpRequest){
													$('.fixed_load').hide();
												}
											});
										}
									}, 
									fail: function(res) { 
										alert(JSON.stringify(res)); 
									} 
								}); 
							} 
							Fn_Upload();
						}
					});
				}
			});
			//App�ϴ�ͼƬEnd
		}); 
	}

	$(document).on('click',".PhotoControlApp .Close",function(){
		$(this).parents('.PhotoControlApp').remove();
		return false;
	});

	$(document).on('click',".PhotoControlApp .Move",function(){
		var parent = $(this).parents('.PhotoControlApp');
		if(typeof(parent.prev().html()) == "undefined"){
			alert("\u5df2\u7ecf\u662f\u7b2c\u4e00\u4e2a\u4e86\uff0c\u6ca1\u529e\u6cd5\u524d\u79fb\u4e86");
		}else{
			parent.prev().before(parent.prop("outerHTML"));
			parent.remove();
		}
		return false;
	});
})(jQuery);