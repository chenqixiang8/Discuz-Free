var Appbyme = navigator.userAgent.match(/Appbyme/i) ? true : false;
var MagApp = navigator.userAgent.match(/MAGAPPX/i) ? true : false;
var QFApp = navigator.userAgent.match(/QianFan/i) ? true : false;
var WxApp = navigator.userAgent.match(/MicroMessenger/i) ? true : false;
var MinWxApp = window.__wxjs_environment === 'miniprogram' ? true : false;
var Ios = navigator.userAgent.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/) ? true : false; //ios�ն�
var Android = navigator.userAgent.indexOf('Android') > -1 || navigator.userAgent.indexOf('Adr') > -1 ? true : false;
var APP = Appbyme || MagApp || QFApp ? true : false;
$(function() {  
	FastClick.attach(document.body);  
});

window.addEventListener("DOMContentLoaded", function() {
	if(Ios){
		$("input,textarea").blur(function(){
			setTimeout(function() {
				var scrollHeight = document.documentElement.scrollTop || document.body.scrollTop || 0;
				window.scrollTo(0, Math.max(scrollHeight - 1, 0));
			}, 300);
		});
	}
});


function JumpUrl(Url,Callback){
	if(Appbyme){
		connectSQJavascriptBridge(function(){});
		sq.urlRequest(Url);
	}else if(MagApp){
		mag.newWin(Url);
	}else if(QFApp){
		QFH5.jumpNewWebview(Url);
	}else if(MinWxApp){
		wx.miniProgram.navigateTo({url:'/pages/index/index?url='+encodeURIComponent(Url)});
	}else{
		if (Callback && typeof Callback === 'function' && Android && WxApp) Callback();//ִ�з��غ���
		window.location.href = Url;
	}
}

function WinClose(Url,Back){
	if(Appbyme){
		sq.closeActivity();
	}else if(MagApp){
		mag.closeWin();
	}else if(QFApp){
		QFH5.close();
	}else if(MinWxApp){
		wx.miniProgram.navigateBack();
	}else{
		if(Back == true){
			if(document.referrer != ''){
				history.back();
			}else{
				window.location.href = Url;
			}
		}else{
			window.location.href = Url;
		}
	}
}

function fn_location_reload(){
	if(Android && WxApp){
		window.location.href = updateUrl(window.location.href,'location_time');
	}else{
		setTimeout(function(){location.reload(true)},300);
	}
}

function updateUrl(url,key){
	var key= (key || 't') +'=';  //Ĭ����"t"
	var reg=new RegExp(key+'\\d+');  //����t=1472286066028
	var timestamp=+new Date();
	if(url.indexOf(key)>-1){ //��ʱ�����ֱ�Ӹ���
		return url.replace(reg,key+timestamp);
	}else{  //û��ʱ���������ʱ���
		if(url.indexOf('\?')>-1){
			var urlArr=url.split('\?');
			if(urlArr[1]){
				return urlArr[0]+'?'+key+timestamp+'&'+urlArr[1];
			}else{
				return urlArr[0]+'?'+key+timestamp;
			}
		}else{
			if(url.indexOf('#')>-1){
				return url.split('#')[0]+'?'+key+timestamp+location.hash;
			}else{
				return url+'?'+key+timestamp;
			}
		}
	}
}

function getSerializeJson(array){
	var SerializeObj = {};
	for(let i in array) {
		if(SerializeObj[i]){
			SerializeObj[i] += ';'+encodeURI(encodeURI(array[i]));
		}else{
			SerializeObj[i] = encodeURI(encodeURI(array[i]));
		}
	}
	return SerializeObj;
}

$.fn.SerializeJson = function(OtherString){
	var SerializeObj = {},array = this.serializeArray();
	$(array).each(function(){
		if(SerializeObj[this.name]){
			SerializeObj[this.name] += ';'+encodeURI(encodeURI(this.value));
		}else{
			SerializeObj[this.name] = encodeURI(encodeURI(this.value));
		}
	});

	if(OtherString != undefined){
		var OtherArray = OtherString.split(';');
		$(OtherArray).each(function(){
			var OtherSplitArray = this.split(':');
			SerializeObj[OtherSplitArray[0]] = URI == true ? encodeURI(encodeURI(OtherSplitArray[1])) : OtherSplitArray[1];
		});
	}

	return SerializeObj;
};