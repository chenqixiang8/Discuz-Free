<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: response.class.php 35127 2014-12-02 08:17:18Z nemohou $
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class Response {

	private static $expire = 1296000;
	public static $keyword = 'LOGIN_WSQ';

	public static function text($param) {
		$data = $param;
		self::_init();
		global $_G;
		$data['content'] = diconv($data['content'], 'UTF-8');
		$isloginkeyword = self::_custom('text', $data['content']);
		if(!$_G['wechat']['setting']['wsq_allow']) {
			return;
		}
		$authcode = C::t('#wechat#mobile_wechat_authcode')->fetch_by_code($data['content']);
		if(!$authcode || $authcode['status']) {
			if($isloginkeyword) {
				//wsq::report('loginclick');
				self::_show('access', $data['from']);
			}
		} else {
			//wsq::report('sendnum');
			self::_show('sendnum', $data['from']."\t".$authcode['sid'], 60);
		}
	}
//
//	public static function click($param) {
//		list($data) = $param;
//		self::_init();
//		global $_G;
//		if(!$_G['wechat']['setting']['wsq_allow']) {
//			return;
//		}
//		if($data['key'] == self::$keyword) {
//			wsq::report('loginclick');
//			self::_show('access', $data['from']);
//		} else {
//			self::_custom('text', $data['key']);
//		}
//	}
//
//	public static function custom($param) {
//		self::_init();
//		global $_G;
//		if(!$_G['wechat']['setting']['wsq_allow']) {
//			return;
//		}
//		self::_custom('subscribe');
//	}

	public static function subscribe($param) {
		global $_G;
		$data = $param;
		self::_init();
		if($data['key']) {
			self::scan($param);
		} else {
			self::_show('subscribe', $data['from']);
		}
	}


	public static function scan($param) {
		global $_G;
		$data = $param;
		self::_init();
		if($data['from']){
			list($plugin,$method,$id) = explode('____', $data['key']);
			if(in_array($plugin,array('fn_job'))){//��Ƹ
				@require_once (DISCUZ_ROOT .'./source/plugin/fn_assembly/app.inc.php');
				@require_once (DISCUZ_ROOT .'./source/plugin/fn_job/Function.inc.php');
				if($method == 'index'){
					$content[] = array(
						"title" => $Fn_Job->Config['PluginVar']['WxTitle'],
						"desc" => $Fn_Job->Config['PluginVar']['WxDes'],
						"pic" => strpos($Fn_Job->Config['WxShare']['WxImg'],'http') !== false ? $Fn_Job->Config['WxShare']['WxImg'] : $_G['siteurl'].$Fn_Job->Config['WxShare']['WxImg'],
						"url" => $Fn_Job->Rewrite($method,array()),
					);
					echo Fn_WeChatServer::getXml4RichMsgByArray($content);
					exit();
				}else if($method == 'view_job'){
					$Item = $Fn_Job->GetViewthread($id);
					if($Item){
						$Fn_Job->Config['WxShare']['WxImg'] = $Item['company']['logo'] ? ($Item['company']['logo']) : $Fn_Job->Config['WxShare']['WxImg'];
						$content[] = array(
							"title" => str_replace(array('{id}','{title}','{class}','{classid}','{company_name}','{address}','{month_wages}','{month_wages_text}','{education}','{experience}','{settlement}','{cycle}','{url}','{mobile}','{content}','{contacts}','{tag}'),array($Item['id'],$Item['title'],$Item['classid_min_text'],$Item['classid_min_text'],$Item['company']['name'],$Item['province_text'].'['.$Item['community'].']',$Item['month_wages_text'],$Item['month_wages_text'],$Item['education_text'],$Item['experience_text'],$Item['settlement_text'],$Item['cycle_text'],$Fn_Job->Rewrite('view_job',array('iid'=>$Item['id'])),$Item['mobile'],strip_tags($Item['content']),$Item['c_contacts'],implode('|',$Item['param']['tag_list'])),$Fn_Job->Config['PluginVar']['JobShareTitle']),
							"desc" => $Fn_Job->Config['PluginVar']['WxDes'],
							"pic" => strpos($Fn_Job->Config['WxShare']['WxImg'],'http') !== false ? $Fn_Job->Config['WxShare']['WxImg'] : $_G['siteurl'].$Fn_Job->Config['WxShare']['WxImg'],
							"url" => $Fn_Job->Rewrite($method,array('iid'=>$Item['id'])),
						);
						echo Fn_WeChatServer::getXml4RichMsgByArray($content);
						exit();
					}
				}else if($method == 'view_company'){
					$Item = $Fn_Job->GetViewCompanythread($id);
					if($Item){
						$replaceArray = array('{name}','{mobile}','{scale}','{class}','{content}','{tag}','{job_list}','{url}');
						$isreplaceArray = array($Item['name'],$Item['mobile'],$Item['scale_text'],$Item['class_text'],strip_tags($Item['content']),implode('|',$Item['param']['tag_list']),$info_list,$Fn_Job->Rewrite('view_company',array('cid'=>$Item['id'])));
				

						$Fn_Job->Config['WxShare']['WxImg'] = $Item['logo'] ? $Item['logo'] : $Fn_Job->Config['WxShare']['WxImg'];
						$content[] = array(
							"title" => $Fn_Job->Config['PluginVar']['CompanyShareTitle'] ? str_replace($replaceArray,$isreplaceArray,$Fn_Job->Config['PluginVar']['CompanyShareTitle']) : $Item['name'].'_'.$Fn_Job->Config['PluginVar']['Title'],
							"desc" => $Fn_Job->Config['PluginVar']['WxDes'],
							"pic" => strpos($Fn_Job->Config['WxShare']['WxImg'],'http') !== false ? $Fn_Job->Config['WxShare']['WxImg'] : $_G['siteurl'].$Fn_Job->Config['WxShare']['WxImg'],
							"url" => $Fn_Job->Rewrite($method,array('cid'=>$Item['id'])),
						);
						echo Fn_WeChatServer::getXml4RichMsgByArray($content);
						exit();
					}
				}else if($method == 'view_resume'){
					$Item = $Fn_Job->GetViewResumethread($id);
					file_put_contents(DISCUZ_ROOT.'/source/plugin/fn_assembly/class/'.$method.'.html',$id, FILE_APPEND);
					if($Item){
						file_put_contents(DISCUZ_ROOT.'/source/plugin/fn_assembly/class/'.$method.'1.html',$id, FILE_APPEND);
						$Item['full_name'] = $Fn_Job->Config['PluginVar']['ResumeNameSwitch'] || ($InfoApplyLog && $Fn_Job->Config['PluginVar']['ResumeJobNameSwitch']) ?  $Item['full_name'] : cutstr($Item['full_name'],3,'').$Fn_Job->Config['LangVar']['SexToArray'][$Item['sex']];
					
						$Fn_Job->Config['WxShare']['WxImg'] = $Item['face'] ? $Item['face'] : $Fn_Job->Config['WxShare']['WxImg'];
						$content[] = array(
							"title" => $Item['full_name'].$Fn_Job->Config['LangVar']['ViewResume'].'_'.$Fn_Job->Config['PluginVar']['Title'],
							"desc" => $Fn_Job->Config['PluginVar']['WxDes'],
							"pic" => strpos($Fn_Job->Config['WxShare']['WxImg'],'http') !== false ? $Fn_Job->Config['WxShare']['WxImg'] : $_G['siteurl'].$Fn_Job->Config['WxShare']['WxImg'],
							"url" => $Fn_Job->Rewrite($method,array('rid'=>$Item['uid'])),
						);
						echo Fn_WeChatServer::getXml4RichMsgByArray($content);
						exit();
					}
				}else if($method == 'view_fair'){
					$Item = $Fn_Job->GetViewFairthread($id);
					if($Item){
						$Fn_Job->Config['WxShare']['WxImg'] = $Item['param']['share_img'] ? $Item['param']['share_img'] : $Fn_Job->Config['WxShare']['WxImg'];
						$content[] = array(
							"title" => $Item['param']['share_title'] ? $Item['param']['share_title'] :  $Item['title'],
							"desc" => $Item['param']['share_desc'] ? $Item['param']['share_desc'] :  $Item['title'],
							"pic" => strpos($Fn_Job->Config['WxShare']['WxImg'],'http') !== false ? $Fn_Job->Config['WxShare']['WxImg'] : $_G['siteurl'].$Fn_Job->Config['WxShare']['WxImg'],
							"url" => $Fn_Job->Rewrite($method,array('fid'=>$Item['id'])),
						);
						echo Fn_WeChatServer::getXml4RichMsgByArray($content);
						exit();
					}
				}
			}else if(in_array($plugin,array('fn_house'))){//����
				@require_once (DISCUZ_ROOT .'./source/plugin/fn_assembly/app.inc.php');
				@require_once (DISCUZ_ROOT .'./source/plugin/fn_house/Function.inc.php');
				if($method == 'view'){
					$Item = $Fn_House->GetViewthread($id);
					if($Item){
						$content[] = array(
							"title" =>  str_replace(array('{title}','{class}','{fclass}'),array($Item['title'],$Fn_House->Config['LangVar']['IndexNav'][$Item['class']],$FclassArray[$Item['vice_class']]),$Fn_House->Config['PluginVar']['ViewShareTitle']),
							"desc" => $Fn_House->Config['PluginVar']['WxDes'],
							"pic" => $Item['param']['cover'] ? $Item['param']['cover'] : $Fn_House->Config['WxShare']['WxImg'],
							"url" => $Fn_House->Rewrite($method,array('iid'=>$Item['id'])),
						);
						echo Fn_WeChatServer::getXml4RichMsgByArray($content);
						exit();
					}
				}else if($method == 'view_disc'){
					$Item = $Fn_House->GetViewDiscthread($id);
					if($Item){
						$content[] = array(
							"title" => str_replace(array('{title}'),array($Item['title']),$Fn_House->Config['PluginVar']['ViewDiscShareTitle']),
							"desc" => $Fn_House->Config['PluginVar']['WxDes'],
							"pic" => $Item['param']['cover'] ? $Item['param']['cover'] : $Fn_House->Config['WxShare']['WxImg'],
							"url" => $Fn_House->Rewrite($method,array('iid'=>$Item['id'])),
						);
						echo Fn_WeChatServer::getXml4RichMsgByArray($content);
						exit();
					}
				}else if($method == 'view_agent'){
					$Item = $Fn_House->GetUserInfo($id);
					if($Item){
						$content[] = array(
							"title" => str_replace('{name}',$Item['name'],$Fn_House->Config['LangVar']['ViewAgentTitle']),
							"desc" => $Fn_House->Config['PluginVar']['WxDes'],
							"pic" => $Item['face'] ? $Item['face'] : $Fn_House->Config['WxShare']['WxImg'],
							"url" => $Fn_House->Rewrite($method,array('auid'=>$Item['id'])),
						);
						echo Fn_WeChatServer::getXml4RichMsgByArray($content);
						exit();
					}
				}else if($method == 'store'){
					$Item = $Fn_House->GetAgentthread($id);
					if($Item){
						$content[] = array(
							"title" => $Item['title'].$Fn_House->Config['LangVar']['Store'],
							"desc" => $Fn_House->Config['PluginVar']['WxDes'],
							"pic" => $Item['face'] ? $Item['face'] : $Fn_House->Config['WxShare']['WxImg'],
							"url" => $Fn_House->Rewrite($method,array('aid'=>$Item['id'])),
						);
						echo Fn_WeChatServer::getXml4RichMsgByArray($content);
						exit();
					}
				}
			}else if(in_array($plugin,array('fn_xiangqin'))){//����
				@require_once (DISCUZ_ROOT .'./source/plugin/fn_assembly/app.inc.php');
				@require_once (DISCUZ_ROOT.'./source/plugin/fn_xiangqin/config.php');
				if($method == 'view'){
					$item = $fn_xiangqin->getView($id);
					if($item){
						$content[] = array(
							"title" =>  $item['share_title'],
							"desc" => $item['share_desc'],
							"pic" => $item['share_logo'],
							"url" => $item['url'],
						);
						echo Fn_WeChatServer::getXml4RichMsgByArray($content);
						exit();
					}
				}
			}else if(in_array($plugin,array('fn_hd'))){//�
				@require_once (DISCUZ_ROOT .'./source/plugin/fn_assembly/app.inc.php');
				@require_once (DISCUZ_ROOT .'./source/plugin/fn_hd/Function.inc.php');
				if($method == 'index'){
					$content[] = array(
						"title" => $Fn_Hd->Config['PluginVar']['WxTitle'],
						"desc" => $Fn_Hd->Config['PluginVar']['WxDes'],
						"pic" => strpos($Fn_Hd->Config['WxShare']['WxImg'],'http') !== false ? $Fn_Secret->Config['WxShare']['WxImg'] : $_G['siteurl'].$Fn_Secret->Config['WxShare']['WxImg'],
						"url" => $Fn_Hd->Config['Url'],
					);
					echo Fn_WeChatServer::getXml4RichMsgByArray($content);
					exit();
				}else if($method == 'view'){
					$Item = $Fn_Hd->GetViewthread($id);
					if($Item){
						$Fn_Hd->Config['WxShare']['WxImg'] = $Item['param']['share_logo'] ? $Item['param']['share_logo'] : $Fn_Hd->Config['WxShare']['WxImg'];
						$content[] = array(
							"title" =>  $Item['param']['share_title'] ? $Item['param']['share_title'] : $Item['title'],
							"desc" => $Item['param']['share_desc'] ? $Item['param']['share_desc'] : $Item['title'],
							"pic" => strpos($Fn_Hd->Config['WxShare']['WxImg'],'http') !== false ? $Fn_Hd->Config['WxShare']['WxImg'] : $_G['siteurl'].$Fn_Hd->Config['WxShare']['WxImg'],
							"url" => $Fn_Hd->Config['ViewUrl'].$Item['id'],
						);
						echo Fn_WeChatServer::getXml4RichMsgByArray($content);
						exit();
					}
				}
			}else if(in_array($plugin,array('fn_wxq'))){//΢��Ⱥ
				@require_once (DISCUZ_ROOT .'./source/plugin/fn_assembly/app.inc.php');
				@require_once (DISCUZ_ROOT .'./source/plugin/fn_wxq/Function.inc.php');
				if($method == 'view'){
					$Item = $Fn_Wxq->GetViewthread($id);
					if($Item){
						$Item['param'] = unserialize($Item['param']);
						$Fn_Secret->Config['WxShare']['WxImg'] = $Item['param']['face'] ? $Item['param']['face'] : $Fn_Secret->Config['WxShare']['WxImg'];
						$content[] = array(
							"title" => $Item['title'],
							"desc" => cutstr(strip_tags($Item['content']),80),
							"pic" => $Item['logo'] ? $Item['logo'] : $Fn_Wxq->Config['WxShare']['WxImg'],
							"url" => $Fn_Wxq->Config['ViewUrl'].$Item['id'],
						);
						echo Fn_WeChatServer::getXml4RichMsgByArray($content);
						exit();
					}
				}
			}else if(in_array($plugin,array('fn_secret'))){//����Ȧ
				@require_once (DISCUZ_ROOT .'./source/plugin/fn_assembly/app.inc.php');
				@require_once (DISCUZ_ROOT .'./source/plugin/fn_secret/Function.inc.php');
				if($method == 'index'){
					$content[] = array(
						"title" => $Fn_Secret->Config['PluginVar']['WxTitle'],
						"desc" => $Fn_Secret->Config['PluginVar']['WxDes'],
						"pic" => strpos($Fn_Secret->Config['WxShare']['WxImg'],'http') !== false ? $Fn_Secret->Config['WxShare']['WxImg'] : $_G['siteurl'].$Fn_Secret->Config['WxShare']['WxImg'],
						"url" => $Fn_Secret->Config['Url'],
					);
					echo Fn_WeChatServer::getXml4RichMsgByArray($content);
					exit();
				}else if($method == 'viewthread'){
					$Item = $Fn_Secret->GetViewthread($id);
					if($Item){
						$Item['param'] = unserialize($Item['param']);
						$Fn_Secret->Config['WxShare']['WxImg'] = $Item['param']['face'] ? $Item['param']['face'] : $Fn_Secret->Config['WxShare']['WxImg'];
						$content[] = array(
							"title" => cutstr(strip_tags($Item['content']),60),
							"desc" => $Fn_Secret->Config['WxShare']['WxDes'],
							"pic" => strpos($Fn_Secret->Config['WxShare']['WxImg'],'http') !== false ? $Fn_Secret->Config['WxShare']['WxImg'] : $_G['siteurl'].$Fn_Secret->Config['WxShare']['WxImg'],
							"url" => $Fn_Secret->Config['ViewthreadUrl'].$Item['id'],
						);
						echo Fn_WeChatServer::getXml4RichMsgByArray($content);
						exit();
					}
				}else if($method == 'down_qr'){
					$Item= DB::fetch_first('SELECT B.* FROM '.DB::table($Fn_Secret->TableSecretBusiness).' B  where id='.intval($id));
					if($Item){
						$content[] = array(
							"title" => $Item['title'],
							"desc" => $Fn_Secret->Config['WxShare']['WxDes'],
							"pic" => strpos($Fn_Secret->Config['WxShare']['WxImg'],'http') !== false ? $Fn_Secret->Config['WxShare']['WxImg'] : $_G['siteurl'].$Fn_Secret->Config['WxShare']['WxImg'],
							"url" => $Item['link_wx'],//$Fn_Secret->Config['AddUrl'].'&bid='.$Item['id'],
						);
						echo Fn_WeChatServer::getXml4RichMsgByArray($content);
						exit();
					}
				}
			}else if(in_array($plugin,array('fn_weizhang'))){//Υ��
				@require_once (DISCUZ_ROOT .'./source/plugin/fn_assembly/app.inc.php');
				@require_once (DISCUZ_ROOT .'./source/plugin/fn_weizhang/Function.inc.php');
				if($method == 'index'){
					$content[] = array(
						"title" => $Fn_WeiZhang->Config['PluginVar']['WxTitle'],
						"desc" => $Fn_WeiZhang->Config['PluginVar']['WxDes'],
						"pic" => strpos($Fn_WeiZhang->Config['WxShare']['WxImg'],'http') !== false ? $Fn_WeiZhang->Config['WxShare']['WxImg'] : $_G['siteurl'].$Fn_WeiZhang->Config['WxShare']['WxImg'],
						"url" => $Fn_WeiZhang->Config['Url'],
					);
					echo Fn_WeChatServer::getXml4RichMsgByArray($content);
					exit();
				}
			}else if(in_array($plugin,array('fn_poster'))){//����
				@require_once (DISCUZ_ROOT .'./source/plugin/fn_assembly/app.inc.php');
				@require_once (DISCUZ_ROOT .'./source/plugin/fn_poster/Function.inc.php');
				if($method == 'index'){
					$Item = $Fn_Poster->QueryOne($Fn_Poster->TablePoster,intval($id));
					$Item['param'] = unserialize($Item['param']);
					//����
					$Fn_Poster->Config['WxShare']['WxUrl'] = $Fn_Poster->Config['WxShare']['WxUrl'].'&aid='.$Item['id'];
					$Fn_Poster->Config['WxShare']['WxTitle'] = $Item['param']['sharetitle'] ? $Item['param']['sharetitle'] : $Item['title'];
					$Fn_Poster->Config['WxShare']['WxDes'] = $Item['param']['sharedesc'] ? $Item['param']['sharedesc'] : $Item['title'];
					$Fn_Poster->Config['WxShare']['WxImg'] = $Item['param']['sharelogo'] ? $Item['param']['sharelogo'] : $Item['bg'];
					$Fn_Poster->Config['WxShare']['WxImg'] = strpos($Fn_Poster->Config['WxShare']['WxImg'],'http') !== false ? $Fn_Poster->Config['WxShare']['WxImg'] : $_G['siteurl'].$Fn_Poster->Config['WxShare']['WxImg'];
					//���� End
					$content[] = array(
						"title" =>  $Fn_Poster->Config['WxShare']['WxTitle'],
						"desc" => $Fn_Poster->Config['WxShare']['WxDes'],
						"pic" => $Fn_Poster->Config['WxShare']['WxImg'],
						"url" => $Fn_Poster->Config['WxShare']['WxUrl']
					);
					echo Fn_WeChatServer::getXml4RichMsgByArray($content);
					exit();
				}
			}else if(in_array($plugin,array('fn_live'))){//ֱ��
				@require_once (DISCUZ_ROOT .'./source/plugin/fn_assembly/app.inc.php');
				@require_once (DISCUZ_ROOT .'./source/plugin/'.$plugin.'/Function.inc.php');
				if($method == 'view'){
					list($iid,$uid) = explode('|',$id);
					$Item = $Fn_Live->GetViewthread($iid);
					//����
					$Fn_Live->Config['WxShare']['WxUrl'] = $Fn_Live->Config['ViewUrl'].$Item['id'].($uid && $Item['param']['poster_invite'] ? '&uid='.$uid : '');
					$Fn_Live->Config['WxShare']['WxTitle'] = $Item['param']['share_title'] ? $Item['param']['share_title'] : $Fn_Live->Config['WxShare']['WxTitle'];
					$Fn_Live->Config['WxShare']['WxDes'] = $Item['param']['share_desc'] ? $Item['param']['share_desc'] : $Fn_Live->Config['WxShare']['WxDes'];
					$Fn_Live->Config['WxShare']['WxImg'] = $Item['param']['share_img'] ? $Item['param']['share_img'] : $Fn_Live->Config['WxShare']['WxImg'];
					$Fn_Live->Config['WxShare']['WxImg'] = strpos($Fn_Live->Config['WxShare']['WxImg'],'http') !== false ? $Fn_Live->Config['WxShare']['WxImg'] : $_G['siteurl'].$Fn_Live->Config['WxShare']['WxImg'];
					//����End
					$content[] = array(
						"title" =>  $Fn_Live->Config['WxShare']['WxTitle'],
						"desc" => $Fn_Live->Config['WxShare']['WxDes'],
						"pic" => $Fn_Live->Config['WxShare']['WxImg'],
						"url" => $Fn_Live->Config['WxShare']['WxUrl']
					);
					echo Fn_WeChatServer::getXml4RichMsgByArray($content);
					exit();
				}
			}else if(in_array($plugin,array('fn_scene_qr'))){//������ά��
				if($method == 'view'){
					$Item = DB::fetch_first('SELECT * FROM '.DB::table('fn_wx_scene_qr').' where id = '.intval($id));
					$content[] = array(
						"title" => $Item['title'],
						"desc" => $Item['desc'],
						"pic" => $Item['pic'],
						"url" => $Item['url']
					);
					echo Fn_WeChatServer::getXml4RichMsgByArray($content);
					exit();
				}
			}
		}

		/* XiGua */
        $openid = $data['from'];
        if($openid){
			$FnHttp = ((isset($_SERVER['HTTPS']) && strtolower($_SERVER['HTTPS']) == 'on') || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https') || (isset($_SERVER['HTTP_X_CLIENT_SCHEME']) && $_SERVER['HTTP_X_CLIENT_SCHEME'] == 'https')) ? 'https://' : 'http://';

			$parse_url = parse_url(str_replace(array("http://"),array($FnHttp),$_G['siteurl']));
			$_G['siteroot'] = str_replace('//', '/', $_G['siteroot']);
			$_G['siteurl'] = str_replace(array('source/plugin/fn_assembly/api/','api/mobile/'), array(''),$parse_url['scheme'].'://'.$parse_url['host'].($_G['siteroot'] ? $_G['siteroot'] : '/'));

            if(!$_G['cache']['plugin']){
                loadcache('plugin');
            }
            $content = array();
            global $_G;
            $hb_config = $_G['cache']['plugin']['xigua_hb'];
            $SCRITPTNAME = $hb_config['scriptname'] ? $hb_config['scriptname'] : 'plugin.php';
            $dftlogo = $_G['cache']['plugin']['xigua_f']['defaultlogo'];
            if(strpos($dftlogo, 'https://')===false && strpos($dftlogo, 'http://')===false){
                $dftlogo = $_G['siteurl'].$dftlogo;
            }
            list($datakey, $hhid) = explode('____', $data['key']);
            if($hhid){
                $hhid = '&idu='.intval($hhid);
            }else{
                $hhid = '';
            }

            if(strpos($datakey, 'pub_')!==false) {
                $pubid = str_replace('pub_', '', $datakey);
                if (is_numeric($pubid)) {
                    if (empty($_G['cache']['plugin'])) {
                        loadcache('plugin');
                    }
                    if (!class_exists('WeChatClient')) {
                        include_once DISCUZ_ROOT . 'source/plugin/wechat/wechat.lib.class.php';
                    }
                    include_once libfile('function/cache');


                    $hbdata = C::t('#xigua_hb#xigua_hb_pub')->fetch_by_pubid($pubid, 0);
                    if(!$hbdata['imglist'][0]){
                        $catinfo = C::t('#xigua_hb#xigua_hb_cat')->fetch($hbdata['catid']);
                        $hbdata['imglist'][0] = $catinfo['share_pic'];
                    }

                    if ($hbdata) {
                        $hbdata['title'] = cutstr(strip_tags($hbdata['description']), 60);
                        $hbdata['desc'] = cutstr(strip_tags($hbdata['description']), 100);

                        $desc= cutstr(strip_tags($hbdata['desc']), 100);
                        $content[] = array(
                            "title" => $hbdata['title'],
                            "desc" => $desc,
                            "pic" => ($hbdata['imglist'][0] ? $hbdata['imglist'][0] : $dftlogo),
                            "url" => $_G['siteurl'] . "$SCRITPTNAME?id=xigua_hb&ac=view&pubid=$pubid$hhid",
                        );
                        echo Fn_WeChatServer::getXml4RichMsgByArray($content);
                    }
                }
            }elseif(strpos($datakey, 'hd_')!==false){
                $did_jid = str_replace('hd_', '', $datakey);
                list($did, $jid) = explode('__', $did_jid);
                $hd_config = $_G['cache']['plugin']['xigua_hd'];

                $v = C::t('#xigua_hd#xigua_hd_dis')->fetch_by_id($did);
                $navtitle = $v['title'];
                $desc = $v['jieshao'] ? $v['jieshao'] : $v['append_text_ary'][0];

                if($jid){
                    $jv = C::t('#xigua_hd#xigua_hd_join')->fetch_by_jid($jid);

                    $curuser = getuserbyuid($jv['uid']);
                    $search = array(
                        '{title}',
                        '{user}',
                        '{price}',
                        '{current}',
                        '{times}',
                        '{floor}',
                        '{range}',
                    );
                    $replace = array(
                        $v['title'],
                        $curuser['username'],
                        $v['biaoprice'],
                        $jv['current'],
                        ($v['zong'] ? ($v['zong']-$jv['jians']) : $jv['jians']),
                        $v['disprice'],
                        $v['biaoprice']-$jv['current'],
                    );
                    $navtitle = str_replace($search, $replace, $hd_config['fxt']);
                    $desc = str_replace($search, $replace, $hd_config['fxd']);
                }

                $img = $v['album'][0] ?$v['album'][0]: $dftlogo;



                $desc= cutstr(strip_tags($desc), 100);
                $content[] = array(
                    "title" => $navtitle,
                    "desc" => $desc,
                    "pic" => $img,
                    "url" => $_G['siteurl'] . "$SCRITPTNAME?id=xigua_hd&ac=view&did=$did&jid=$jid$hhid",
                );
//                file_put_contents(DISCUZ_ROOT.'/1.log', var_export($content, 1), FILE_APPEND);
                echo Fn_WeChatServer::getXml4RichMsgByArray($content);



            }elseif(strpos($datakey, 'hm_')!==false){
                $secid = str_replace('hm_', '', $datakey);

                $v = C::t('#xigua_hm#xigua_hm_seckill')->fetch_by_id($secid);
                $navtitle = $v['title'];
                $desc= $v['tuijian'] ? $v['tuijian'] : $v['jieshao'];
                $img = $v['album'][0]?$v['album'][0]:$v['append_img_ary'][0];
                if(!$img){
                    $img = $dftlogo;
                }

                $desc= cutstr(strip_tags($desc), 100);
                $content[] = array(
                    "title" => $navtitle,
                    "desc" => $desc,
                    "pic" => $img,
                    "url" => $_G['siteurl'] . "$SCRITPTNAME?id=xigua_hm&ac=seckill_view&secid=$secid$hhid",
                );
//                file_put_contents(DISCUZ_ROOT.'/1.log', var_export($content, 1), FILE_APPEND);
                echo Fn_WeChatServer::getXml4RichMsgByArray($content);

            }elseif(strpos($datakey, 'sh_')!==false){
                $shid = str_replace('sh_', '', $datakey);

                $v = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_shid($shid, 0);
                $gonggao = C::t('#xigua_hs#xigua_hs_notice')->fetch_allnotice_by_shid($shid, 2);

                $desc = cutstr(strip_tags($v['xuanchuan'] ? $v['xuanchuan'] :($gonggao[0] ? $gonggao[0]['content'] : $v['jieshao'])),80);
                $navtitle = $v['name'];
                $img = $v['logo'];
                if(!$img){
                    $img = $dftlogo;
                }

                $content[] = array(
                    "title" => $navtitle,
                    "desc" => $desc,
                    "pic" => $img,
                    "url" => $_G['siteurl'] . "$SCRITPTNAME?id=xigua_hs&ac=view&shid=$shid$hhid",
                );
//                file_put_contents(DISCUZ_ROOT.'/1.log', var_export($content, 1), FILE_APPEND);
                echo Fn_WeChatServer::getXml4RichMsgByArray($content);
            }elseif(strpos($datakey, 'pt_')!==false){
                $pt_tuan_id = str_replace('pt_', '', $datakey);

                list($gid, $tuan_id) = explode('__', $pt_tuan_id);
                $pt_config = $_G['cache']['plugin']['xigua_pt'];

                $v = C::t('#xigua_pt#xigua_pt_good')->fetch_by_gid($gid);
                if (!$v['album']){
                    $v['album'] = $v['append_img_ary'];
                }
                $navtitle= $v['title'];
                $desc= cutstr(strip_tags($v['jieshao']), 100);
                $img = $v['album'][0] ?$v['album'][0] : $dftlogo;

                $content[] = array(
                    "title" => $navtitle,
                    "desc" => $desc,
                    "pic" => $img,
                    "url" => $_G['siteurl'] . "$SCRITPTNAME?id=xigua_pt&ac=view&gid=$gid&tuan_id=$tuan_id$hhid",
                );
                echo Fn_WeChatServer::getXml4RichMsgByArray($content);

            }elseif(strpos($datakey, 'sp_')!==false){
                $gid = str_replace('sp_', '', $datakey);
                $sp_config = $_G['cache']['plugin']['xigua_sp'];

                $v = C::t('#xigua_sp#xigua_sp_good')->fetch_by_gid($gid);
                if (!$v['album']){
                    $v['album'] = $v['append_img_ary'];
                }
                $navtitle= $v['title'];
                $desc= cutstr(strip_tags($v['jieshao']), 100);
                $img = $v['album'][0] ?$v['album'][0] : $dftlogo;

                $content[] = array(
                    "title" => $navtitle,
                    "desc" => $desc,
                    "pic" => $img,
                    "url" => $_G['siteurl'] . "$SCRITPTNAME?id=xigua_sp&ac=view&gid=$gid$hhid",
                );
                echo Fn_WeChatServer::getXml4RichMsgByArray($content);

            }elseif(strpos($datakey, 'hh_')!==false){
                $idu = str_replace('hh_', '', $datakey);
                $hh_config = $_G['cache']['plugin']['xigua_hh'];

                $memeber = getuserbyuid($idu);

                $navtitle= $memeber['username'].lang('plugin/xigua_hh', 'xntuij').$hb_config['tname'];
                $desc= $hb_config['desc'];
                $img =$dftlogo;// avatar($idu, 'middle', true);

                $content[] = array(
                    "title" => $navtitle,
                    "desc" => $desc,
                    "pic" => $img,
                    "url" => $_G['siteurl']."$SCRITPTNAME?id=xigua_hb&ac=index&idu=$idu$hhid",
                );
                echo Fn_WeChatServer::getXml4RichMsgByArray($content);

            }elseif(strpos($datakey, 'mp_')!==false){
                $mpid = str_replace('mp_', '', $datakey);
                $hp_config = $_G['cache']['plugin']['xigua_hp'];
                $v = C::t('#xigua_hp#xigua_hp_user')->fetch($mpid);
                $myname = $v['name'];

                $navtitle = str_replace(array(
                    '{name}', '{mobile}','{company}','{addr}','{wx}','{zw}','{wfz}','{bm}','{shname}'), array(
                    $myname, $v['mobile'], $v['company'], $v['addr'], $v['wx'], $v['zw'], $v['wfz'], $v['bm'], $v['shname']), $hp_config['viewtitle']
                );
                $desc = str_replace(array(
                    '{name}', '{mobile}','{company}','{addr}','{wx}','{zw}','{wfz}','{bm}','{shname}'), array(
                    $myname, $v['mobile'], $v['company'], $v['addr'], $v['wx'], $v['zw'], $v['wfz'], $v['bm'], $v['shname']), $hp_config['viewdesc']
                );
                $indeximg = $v['avatar'] ? $v['avatar'] : $hp_config['viewimg'];

                $img =$indeximg ? $indeximg : $dftlogo;

                $content[] = array(
                    "title" => $navtitle,
                    "desc" => $desc,
                    "pic" => $img,
                    "url" => $_G['siteurl']."$SCRITPTNAME?id=xigua_hp&ac=view&mpid=$mpid$hhid",
                );
                echo Fn_WeChatServer::getXml4RichMsgByArray($content);

            }elseif(strpos($datakey, 'dh_')!==false){
                $shid = str_replace('dh_', '', $datakey);

                $v = C::t('#xigua_dh#xigua_dh_shangjia')->fetch_by_shid($shid, 0);

                $desc = cutstr(strip_tags( $v['jieshao']),80);
                $navtitle = $v['name'];
                $img = $v['logo'];
                if(!$img){
                    $img = $dftlogo;
                }

                $content[] = array(
                    "title" => strip_tags($navtitle),
                    "desc" => $desc,
                    "pic" => $img,
                    "url" => $_G['siteurl'] . "$SCRITPTNAME?id=xigua_dh&ac=view&shid=$shid$hhid",
                );
                echo Fn_WeChatServer::getXml4RichMsgByArray($content);
            }elseif(strpos($datakey, 'dp_')!==false){
                $cid = str_replace('dp_', '', $datakey);

                $v = C::t('#xigua_dp#xigua_dp_comment')->fetch_by_cid($cid);

                $desc = cutstr(strip_tags(($v['message'])),80);
                $navtitle = $v['subject'];
                $img = $v['album_ary'][0];
                if(!$img){
                    $img = $dftlogo;
                }

                $content[] = array(
                    "title" => strip_tags($navtitle),
                    "desc" => $desc,
                    "pic" => $img,
                    "url" => $_G['siteurl'] . "$SCRITPTNAME?id=xigua_dp&ac=view&cid=$cid$hhid",
                );
                echo Fn_WeChatServer::getXml4RichMsgByArray($content);
            }elseif(strpos($datakey, 'hk_')!==false){
                $cid = str_replace('hk_', '', $datakey);
                $v = C::t('#xigua_hk#xigua_hk_good')->fetch_by_good_id($cid);

                $desc = cutstr(strip_tags(($v['jieshao'])),80);
                $navtitle = $v['title'];
                $img = $v['album'][0];
                if(!$img){
                    $img = $dftlogo;
                }

                $content[] = array(
                    "title" => strip_tags($navtitle),
                    "desc" => $desc,
                    "pic" => $img,
                    "url" => $_G['siteurl'] . "$SCRITPTNAME?id=xigua_hk&ac=view&gid=$cid$hhid",
                );
                echo Fn_WeChatServer::getXml4RichMsgByArray($content);

            }elseif(strpos($datakey, 'job_')!==false){
                $cid = str_replace('job_', '', $datakey);
                $v = C::t('#xigua_job#xigua_job_job')->fetch_by_id($cid);

                $desc = cutstr(strip_tags(($v['miaoshu'])),80);
                $navtitle = $v['name'];
                $img = $v['album'][0];
                if(!$img){
                    $img = $dftlogo;
                }

                $content[] = array(
                    "title" => strip_tags($navtitle),
                    "desc" => $desc,
                    "pic" => $img,
                    "url" => $_G['siteurl'] . "$SCRITPTNAME?id=xigua_job&ac=view&jobid=$cid$hhid",
                );
                echo Fn_WeChatServer::getXml4RichMsgByArray($content);

            }elseif(strpos($datakey, 'shifu_')!==false){
                $cid = str_replace('shifu_', '', $datakey);
                $v = C::t('#xigua_ho#xigua_ho_shifu')->fetch($cid);
                $desc = cutstr($v['jineng_str'].' '.strip_tags(($v['jieshao'])),80);
                $navtitle = $v['realname'];
                $img = $v['avatar'];
                if(!$img){
                    $img = $dftlogo;
                }
                $content[] = array(
                    "title" => strip_tags($navtitle),
                    "desc" => $desc,
                    "pic" => $img,
                    "url" => $_G['siteurl'] . "$SCRITPTNAME?id=xigua_ho&ac=shifu&shifuid=$cid$hhid",
                );
                echo Fn_WeChatServer::getXml4RichMsgByArray($content);
            }
        }
        /* XiGua End*/
	}
//
//	public static function redirect($type) {
//		self::_init();
//		global $_G;
//		if(!$_G['wechat']['setting']['wsq_allow']) {
//			return;
//		}
//		if($_G['wechat']['setting']['wsq_siteid'] && !defined('IN_MOBILE_API')) {
//			$_G['wechat']['setting']['wsq_wapdefault'] = !self::_checkrobot() ? $_G['wechat']['setting']['wsq_wapdefault'] : false;
//			$in_wechat = $_G['wechat']['setting']['wsq_wapdefault'] ? true : strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false;
//			$fromwap = $_G['wechat']['setting']['wsq_wapdefault'] && strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') === false;
//			$url = wsq::$WSQ_DOMAIN.'siteid='.$_G['wechat']['setting']['wsq_siteid'].($fromwap ? '&source=wap' : '').'&c=index&a=';
//			if($type) {
//				$modid = $_G['basescript'].'::'.CURMODULE;
//				if($in_wechat) {
//					if(($modid == 'forum::viewthread' || $modid == 'group::viewthread') && !empty($_GET['tid'])) {
//						dheader('location: '.$url.'viewthread&tid='.$_GET['tid']);
//					} elseif(($modid == 'forum::forumdisplay' || $modid == 'group::forumdisplay') && !empty($_GET['fid'])) {
//						dheader('location: '.$url.'index&fid='.$_GET['fid']);
//					} elseif($modid == 'forum::index') {
//						dheader('location: '.$url.'index');
//					}
//				}
//			} else {
//				if(isset($_GET['referer'])) {
//					return $_GET['referer'];
//				} elseif(isset($_GET['pluginid'])) {
//					return $url.'plugin&pluginid='.urlencode($_GET['pluginid']).'&param='.urlencode($_GET['param']);
//				} else {
//					return $url.'index';
//				}
//			}
//		}
//
//	}
//
	private static function _show($messagekey, $key, $expire = 0) {
		global $_G;
		$expire = $expire ? $expire : self::$expire;
		loadcache(PluginId.'_wechat_response');
		$desc = !empty($_G['cache'][PluginId.'_wechat_response'][$messagekey]) ? $_G['cache'][PluginId.'_wechat_response'][$messagekey] : '';
		$desc ? self::_resource_show($desc) : '';
		exit;
	}

	private static function _custom($type, $keyword = '') {
		global $_G;
		loadcache(PluginId.'_wechat_response');
		$response = & $_G['cache'][PluginId.'_wechat_response'];
		$query = $type == 'text' && $response['query']['text'][$keyword] ? $response['query']['text'][$keyword] : $response['unmatched'];
		if($query) {
			if($query == self::$keyword) {
				return 1;
			}
			self::_resource_show($query);
		}
		return 0;
	}
//
//	public static function masssendFinish($param) {
//	    list($data) = $param;
//	    if(!$data['msg_id']) {
//		exit;
//	    }
//	    $updatedata = array(
//		'res_status' => $data['status'],
//		'res_totalcount' => $data['totalcount'],
//		'res_filtercount' => $data['filtercount'],
//		'res_sentcount' => $data['sentcount'],
//		'res_errorcount' => $data['errorcount'],
//		'res_finish_at' => $data['time']
//	    );
//	    DB::update('mobile_wechat_masssend', $updatedata, "msg_id='$data[msg_id]'");
//	}
//
//	private static function _checkrobot() {
//		return IS_ROBOT || strpos($_SERVER['HTTP_USER_AGENT'], 'spi_der') !== false;
//	}
//
	private static function _init() {
		global $_G;
		if(!$_G['wechat']['setting']) {
			$_G['wechat']['setting'] = unserialize($_G['setting']['mobilewechat']);
		}
	}
	
	private static function _resource_show($query) {
		global $_G;
		if(preg_match("/^\[resource=(\d+)\]/", $query, $r)) {
			$resource = DB::fetch_first('SELECT * FROM '.DB::table('fn_wx_resource').' where id = '.intval($r[1].' and display = 1'));
			if(!$resource['merge']) {
				$list = array(array(
					'title' => $resource['title'],
					'desc' => $resource['desc'],
					'pic' => $resource['pic'],
					'url' => $resource['url'],
				));
			} else {
				$list = array();
				foreach(DB::fetch_all('SELECT * FROM '.DB::table('fn_wx_resource').' where id in ('.$resource['merge_id'].') and display = 1 order by field(id,'.$resource['merge_id'].')') as $key => $val) {
					$list[] = array(
						'title' => $val['title'],
						'desc' => $val['desc'],
						'pic' => $val['pic'],
						'url' => $val['url'],
					);
				}
			}
			echo Fn_WeChatServer::getXml4RichMsgByArray($list);
			exit;
		} else {
			echo Fn_WeChatServer::getXml4Txt($query);
			exit;
		}
	}

}