<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}

$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_fn_pay_log` (
  `order_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(100) NOT NULL,
  `staff_id` int(11) unsigned NOT NULL,
  `source` varchar(50) NOT NULL,
  `pubid` varchar(255) NOT NULL,
  `money` decimal(11,2) unsigned NOT NULL,
  `state` tinyint(1) unsigned NOT NULL,
  `pay_time` int(11) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  `payment_type` varchar(30) NOT NULL,
  `refund` tinyint(1) unsigned NOT NULL,
  `refund_pubid` varchar(255) NOT NULL,
  `refund_dateline` int(11) unsigned NOT NULL,
  `content` varchar(255) NOT NULL,
  `param` mediumtext NOT NULL,
  PRIMARY KEY (`order_id`),
  KEY `uid` (`uid`,`staff_id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_send_sms_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `flow_number` varchar(255) NOT NULL,
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(50) NOT NULL,
  `mobile` varchar(30) NOT NULL,
  `code` int(6) unsigned NOT NULL,
  `content` varchar(2000) NOT NULL,
  `state` tinyint(3) unsigned NOT NULL,
  `msg` varchar(1000) NOT NULL,
  `source` varchar(50) NOT NULL,
  `type` tinyint(1) unsigned NOT NULL,
  `sms_type` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `ip` varchar(30) NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  `cache_dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `type` (`type`),
  KEY `sms_type` (`sms_type`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_wx_menu` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `father_id` int(11) unsigned NOT NULL,
  `plugin` varchar(20) NOT NULL,
  `type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(30) NOT NULL,
  `url` varchar(255) NOT NULL,
  `appid` varchar(255) NOT NULL,
  `pagepath` varchar(255) NOT NULL,
  `displayorder` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`,`father_id`,`plugin`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_wx_resource` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `plugin` varchar(30) NOT NULL,
  `merge` tinyint(1) unsigned NOT NULL,
  `merge_id` varchar(100) NOT NULL,
  `title` varchar(255) NOT NULL,
  `pic` varchar(255) NOT NULL,
  `desc` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `url` varchar(255) NOT NULL,
  `display` tinyint(1) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  `updateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_wx_scene_qr` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `plugin` varchar(30) NOT NULL,
  `title` varchar(255) NOT NULL,
  `desc` varchar(255) NOT NULL,
  `pic` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `qrcode` varchar(255) NOT NULL,
  `qrcode_type` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `qrcode_date` tinyint(3) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

EOF;

runquery($sql);

$finish = TRUE;
?>