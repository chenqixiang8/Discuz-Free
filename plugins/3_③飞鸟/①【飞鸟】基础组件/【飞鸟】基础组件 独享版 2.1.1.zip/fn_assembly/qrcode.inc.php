<?php
/**
 *	[【飞鸟】前台管理(fn_admin.{modulename})] (C)2016-2099 Powered by DisM.Taobao.Com.
 *	Version: 1.0
 *	Date: 2018-5-30 10:27
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
@require_once libfile('class/qrcode','plugin/fn_assembly');
QRcode::png(base64_decode($_GET['url']),false, QR_ECLEVEL_L,5,2);
?>