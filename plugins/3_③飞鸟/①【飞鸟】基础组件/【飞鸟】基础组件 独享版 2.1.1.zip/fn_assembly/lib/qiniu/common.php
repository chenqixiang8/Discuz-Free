<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

include_once DISCUZ_ROOT.'source/plugin/fn_assembly/lib/qiniu/Qiniu/Http/Client.php';
include_once DISCUZ_ROOT.'source/plugin/fn_assembly/lib/qiniu/Qiniu/Http/Error.php';
include_once DISCUZ_ROOT.'source/plugin/fn_assembly/lib/qiniu/Qiniu/Http/Request.php';
include_once DISCUZ_ROOT.'source/plugin/fn_assembly/lib/qiniu/Qiniu/Http/Response.php';
include_once DISCUZ_ROOT.'source/plugin/fn_assembly/lib/qiniu/Qiniu/Processing/ImageUrlBuilder.php';
include_once DISCUZ_ROOT.'source/plugin/fn_assembly/lib/qiniu/Qiniu/Processing/Operation.php';
include_once DISCUZ_ROOT.'source/plugin/fn_assembly/lib/qiniu/Qiniu/Processing/PersistentFop.php';
include_once DISCUZ_ROOT.'source/plugin/fn_assembly/lib/qiniu/Qiniu/Storage/BucketManager.php';
include_once DISCUZ_ROOT.'source/plugin/fn_assembly/lib/qiniu/Qiniu/Storage/FormUploader.php';
include_once DISCUZ_ROOT.'source/plugin/fn_assembly/lib/qiniu/Qiniu/Storage/ResumeUploader.php';
include_once DISCUZ_ROOT.'source/plugin/fn_assembly/lib/qiniu/Qiniu/Storage/UploadManager.php';
include_once DISCUZ_ROOT.'source/plugin/fn_assembly/lib/qiniu/Qiniu/Auth.php';
include_once DISCUZ_ROOT.'source/plugin/fn_assembly/lib/qiniu/Qiniu/Config.php';
include_once DISCUZ_ROOT.'source/plugin/fn_assembly/lib/qiniu/Qiniu/Etag.php';
include_once DISCUZ_ROOT.'source/plugin/fn_assembly/lib/qiniu/Qiniu/functions.php';
include_once DISCUZ_ROOT.'source/plugin/fn_assembly/lib/qiniu/Qiniu/Zone.php';

use Qiniu\Auth;

use Qiniu\Storage\UploadManager;

@require_once (DISCUZ_ROOT .'./source/plugin/fn_assembly/app.inc.php');

function QiNiuOssUpload($Name,$File,$Source=null){
    global $_G,$Config;
	loadcache('plugin');
	try{
        $Auth = new Auth($Config['PluginVar']['QiNiu_AccessKey'],$Config['PluginVar']['QiNiu_SecretKey']);
        $Token = $Auth->uploadToken($Config['PluginVar']['QiNiu_Bucket']);
        $UploadMgr = new UploadManager();
        list($Ret, $Err) = $UploadMgr->putFile($Token,($Source ? $Source.'/' : '').date('Ymd').'/'.$Name,$File);
        if ($Err !== null) {
            $Rs = $Err->message();
        } else {
            $Rs = rtrim($Config['PluginVar']['QiNiu_Url'],'/').'/'.$Ret['key'];
        }
    }catch (Exception $E){
        $Rs = $E->getMessage();
    }
    return $Rs;
}
