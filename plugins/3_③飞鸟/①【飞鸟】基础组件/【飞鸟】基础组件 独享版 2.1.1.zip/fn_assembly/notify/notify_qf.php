<?php

define('FN_IN_API', true);
define('CURSCRIPT', 'api');
define('DISABLEXSSCHECK', true);

require_once '../../../../source/class/class_core.php';
$discuz = C::app();
$discuz->init();
global $_G;
loadcache('plugin');
@require_once (DISCUZ_ROOT .'./source/plugin/fn_assembly/app.inc.php');
@require_once libfile('class/qfapp','plugin/fn_assembly');
if($_POST['sign'] == qf_sign($_POST,$Config['PluginVar']['qf_secret'])){
	$paylog = DB::fetch_first('SELECT * FROM '.DB::table('fn_pay_log').' where pubid = \''.$_POST['order_id'].'\'');
	if($paylog && $paylog['state'] != 1){
		require '../../'.$paylog['source'].'/notify.class.php';
		$state = NotifyUpdatePay($paylog['order_id'],$paylog['source'],$paylog['money'],'app',$paylog['pubid']);
		if($state){
			 echo "success";
			 exit();
		}
	}
}
function qf_sign($params, $secret) {
    unset($params['sign']); // ȥ��sign�ֶ�
    ksort($params);
    $sparams = array();
    foreach ($params as $k => $v) {
        if ("@" != substr($v, 0, 1)) {
            $sparams[] = "$k=$v";
        }
    }
    $sparams[] = "secret=" . $secret;
    return strtoupper(md5(implode("&", $sparams)));
}