<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

loadcache('plugin');

strpos($_SERVER["HTTP_USER_AGENT"],'Appbyme') !== false ? define('Appbyme',true) : define('Appbyme',false);

strpos($_SERVER["HTTP_USER_AGENT"],'MicroMessenger') !== false && strpos($_SERVER["HTTP_USER_AGENT"],'WindowsWechat') === false ? define('WxApp',true) : define('WxApp',false);

strpos($_SERVER["HTTP_USER_AGENT"],'QianFan') !== false ? define('QFApp',true) : define('QFApp',false);

strpos($_SERVER["HTTP_USER_AGENT"],'MAGAPPX') !== false ? define('MagApp',true) : define('MagApp',false);

strpos(strtolower($_SERVER["HTTP_USER_AGENT"]),'iphone') !== false || strpos(strtolower($_SERVER["HTTP_USER_AGENT"]),'ipad') !== false ? define('Iphone',true) : define('Iphone',false);

strpos(strtolower($_SERVER["HTTP_USER_AGENT"]),'android') !== false ? define('Android',true) : define('Android',false);

strpos($_GET['formapp'],'miniprogram') !== false ? define('MinWxApp',true) : define('MinWxApp',false);

Appbyme || QFApp || MagApp ? define('App',true) : define('App',false);

$plugin_id = reset(array_filter(explode(":",$_GET['id'])));
in_array($plugin_id,array('fn_live','fn_renovation','fn_qingming','fn_login','fn_fenlei','fn_xiangqin','fn_shops')) ?  define('weui_frame',true) : define('weui_frame',false);

$FnHttp = ((isset($_SERVER['HTTPS']) && strtolower($_SERVER['HTTPS']) == 'on') || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https') || (isset($_SERVER['HTTP_X_CLIENT_SCHEME']) && $_SERVER['HTTP_X_CLIENT_SCHEME'] == 'https')) ? 'https://' : 'http://';

loadcache('fn_global_domain');
$parse_url = parse_url(str_replace(array("http://"),array($FnHttp),$_G['siteurl']));
$_G['siteroot'] = str_replace('//', '/', $_G['siteroot']);
$_G['siteurl'] = str_replace(array('source/plugin/fn_assembly/api/','source/plugin/fn_assembly/notify/','api/mobile/','fadmin/'), array(''),$parse_url['scheme'].'://'.($_G['cache']['fn_global_domain'][$_GET['id']]['domain'] && !checkmobile() ? $_G['cache']['fn_global_domain'][$_GET['id']]['domain'] : $parse_url['host']).($_G['siteroot'] ? $_G['siteroot'] : '/'));

loadcache('fn_global_setting');
foreach($_G['cache']['fn_global_setting'] as $key => $value) {
	$Config['PluginVar'][$key] = is_array($value) ? $value : stripslashes($value);
}

$Config['LangVar'] = (array) lang('plugin/fn_assembly');

$Config['Path'] = 'source/plugin/fn_assembly';

$Config['StaticPath'] = $_G['siteroot'].'source/plugin/fn_assembly/static';

$Config['StaticPicPath'] = 'source/plugin/fn_assembly/attachment';

$Config['QrcodePath'] = DISCUZ_ROOT.'data/cache/qrcode/';

!is_dir($Config['QrcodePath']) ? dmkdir($Config['QrcodePath']) : '';

$Config['AjaxUrl'] = $_G['siteroot'].'plugin.php?id=fn_assembly:Ajax';

in_array($Config['PluginVar']['AppType'],array(1,2,3)) ? define('AppYes',true) : define('AppYes',false);

@require_once libfile('function/core','plugin/fn_assembly');
$AppDownText = TextareaArray($Config['PluginVar']['AppDownText']);
$AppDownText = array_filter(explode('|',$AppDownText[$plugin_id]));
$AppDownSwitch = in_array($plugin_id,$Config['PluginVar']['AppDownSwitch']) && !App && checkmobile() ? true : false;
if(WxApp){
	@require_once DISCUZ_ROOT.'/'.$Config['Path']."/weixin/jssdk.php";
	$JSSDK = new JSSDK($Config['PluginVar']['WxAppid'], $Config['PluginVar']['WxSecret']);
	$Config['SignPackage'] = $JSSDK->getSignPackage();
}
if(QFApp){
	$AppVersion = intval($_COOKIE['qianfan_appcode']);
	if(!$_G['uid']){
		@require_once libfile('class/qfapp','plugin/fn_assembly');
		$UserQHApp = new QHApp();
		$AutoToKen = json_decode($UserQHApp->GetActionAuthCode($_COOKIE['wap_token']),true);
		if($AutoToKen['uid']){
			require_once libfile('function/member');
			$Member = getuserbyuid($AutoToKen['uid'],1);
			$CookieTime = 2592000;
			setloginstatus($Member, $CookieTime);
			exit('<script>setTimeout(function(){window.location.reload(true)},700);</script>');
		}
	}
}else if(MagApp){
	$AgentArray = array_filter(explode("|",$_SERVER['HTTP_USER_AGENT']));
	$AppVersion = number_format($AgentArray['1'],1);
	$AppSite = $AgentArray[3];
	$MagWalletType = $Config['PluginVar']['MagWalletType'];
	$MagAppWallet = in_array('1',$MagWalletType) ? 1 : 0 ;
	$MagAppAlipay = in_array('2',$MagWalletType) ? 1 : 0 ;
	$MagAppWeixin = in_array('3',$MagWalletType) ? 1 : 0 ;
	
	if(!$_G['uid']){
		@require_once libfile('class/magapp','plugin/fn_assembly');
		$UserMagApp = new MagApp($Config['PluginVar']['MagSecret'],$Config['PluginVar']['MagAssistantSecret']);
		$AutoUserInfo = $UserMagApp->GetUserInfo();
		if($AutoUserInfo['user_id']){
			require_once libfile('function/member');
			$Member = getuserbyuid($AutoUserInfo['user_id'],1);
			$CookieTime = 2592000;
			setloginstatus($Member, $CookieTime);
			exit('<script>setTimeout(function(){window.location.reload(true)},700);</script>');
		}
	}

}

in_array(reset(array_filter(explode(":",$_GET['id']))),$Config['PluginVar']['QrParameterSwitch']) || ($_GET['item'] == 'wx_export_info' && in_array('fn_'.$_GET['mod'],$Config['PluginVar']['QrParameterSwitch'])) ? define('QrParameterSwitch',true) : define('QrParameterSwitch',false);//��ά���������

in_array(reset(array_filter(explode(":",$_GET['id']))),$Config['PluginVar']['DzNoticeSwitch']) ? define('DzNotice',true) : define('DzNotice',false);//��Ϣ֪ͨ��������dz֪ͨ��

if($Config['PluginVar']['LoginSwitch'] && !$_G['uid'] && !in_array($plugin_id,array('fn_login','fn_down_app')) && checkmobile() && !$FnGlobalLogin){
	Fn_Login();
}

$FnRefererCommon = urlencode($_G['siteurl'].'plugin.php?'.$_SERVER["QUERY_STRING"]);

//��¼
function Fn_Login(){
	global $_G,$Config;
	if(Appbyme){//С�Ƶ�¼
		exit('
		<script language="javascript" src="'.$_G['siteroot'].'source/plugin/fn_assembly/static/js/appbyme.js"></script>
		<script>
			connectSQJavascriptBridge(function(bridge){
				sq.login(function(userInfo){
					if(userInfo.userId != 0){
						sq.logout(function(info){
							alert("'.$Config['LangVar']['AppBymeErr'].'");
						});
					}else{
						window.location.reload(true);
					}
				});
			});
			</script>
		');
	}else if(MagApp){//���׵�¼
		@require_once libfile('class/magapp','plugin/fn_assembly');
		$AssemblyMagApp = new MagApp();
		$UserInfo = $AssemblyMagApp->GetUserInfo();
		if($UserInfo['user_id']){
			require_once libfile('function/member');
			$Member = getuserbyuid($UserInfo['user_id'],1);
			$CookieTime = 2592000;
			setloginstatus($Member, $CookieTime);
			exit('<script>setTimeout(function(){window.location.reload(true)},700);</script>');
		}else{
			exit('
				<script src="'.$_G['siteroot'].'source/plugin/fn_assembly/static/js/mag.js"></script>
				<script>
					mag.toLogin(function(rs){
						setTimeout(function(){window.location.reload(true)},700);
					});
				</script>
			');
		}
	}else if(QFApp){//ǧ����¼
		@require_once libfile('class/qfapp','plugin/fn_assembly');
		$AssemblyQHApp = new QHApp();
		$ToKen = json_decode($AssemblyQHApp->GetActionAuthCode($_COOKIE['wap_token']),true);
		if($ToKen['uid']){
			require_once libfile('function/member');
			$Member = getuserbyuid($ToKen['uid'],1);
			$CookieTime = 2592000;
			setloginstatus($Member, $CookieTime);
			exit('<script>setTimeout(function(){window.location.reload(true)},700);</script>');
		}else{
			exit('
				<script>
				function QFH5ready(){
					QFH5.jumpLogin(function(state,data){
						if(state==1){
							QFH5.refresh(1);
						}else if(state == 2){
							QFH5.close();
						}
					});
				}
				</script>
			');	
		}
	}else{
		if(checkmobile()){
			dheader("Location: ".$_G['siteroot']."member.php?mod=logging&action=login&referer=".urlencode($_G['siteurl'].'plugin.php?'.$_SERVER["QUERY_STRING"]));
		}else{
			showmessage('to_login', '', array(), array('showmsg' => true,'login' => 1));
			exit();
		}
	}
}

function baseException($params = array()){
	global $lang;
	$data['code'] = array_key_exists('code',$params) ? $params['code'] : 200;
	$data['msg'] = array_key_exists('msg',$params) ? $params['msg'] : $lang['OpErr'];
	$data['errorCode'] = array_key_exists('errorCode',$params) ? $params['errorCode'] : 999;
	return $data;
}

function baseJosn($data = '', $msg = '', $status = 0, $count = 0, $user = array()){
	@require_once libfile('class/json','plugin/fn_assembly');
	$json = array(
		'msg' => $msg ? diconv($msg,mb_detect_encoding($msg, array('ASCII','UTF-8','GB2312','GBK','BIG5')),CHARSET) : '',
		'code' => $status,
		'status' => !$status ? 200 : $status,
		'count' => (int)$count,
		'data' => $data
    );
	$json = $user ? array_merge($json,array('user'=>$user)) : $json;
	echo CJSON::encode($json);
	exit();
}

function base64Decode($data){
	$newData = array();
    foreach((array)$data as $key => $val){
        // �����ҶԼ�Ҳ������urlencode
        $newData[$key] = is_array($val) ? base64Decode($val) : diconv(base64_decode($val),'UTF-8',CHARSET);
    }
    return $newData;
}

if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_template_message')){//ģ������
	 $TemplateMessageConfig = $_G['cache']['plugin']['fn_template_message'];
	 if($TemplateMessageConfig['AutoPushSwitch'] && $TemplateMessageConfig['WxAppid'] && $TemplateMessageConfig['WxSecret'] && $TemplateMessageConfig['WxTable']){
		$TemplateMessageTimeInterval = intval($TemplateMessageConfig['TimeInterval']) * 1000;
        if($TemplateMessageTimeInterval < 5000){
            $TemplateMessageTimeInterval = 5000;
        }
        $TemplateMessageFormhash = FORMHASH;
		$TemplateMessageHtml = <<<HTML
		<script>
		var TemplateMessageFormhash = '$TemplateMessageFormhash';
		Check_AutoPush();
		var Check_Interval = setInterval(Check_AutoPush, $TemplateMessageTimeInterval);
		function Check_AutoPush(){
			var xhr = new XMLHttpRequest();
			xhr.open("GET", "$_G[siteroot]plugin.php?id=fn_template_message:AutoPush&formhash="+TemplateMessageFormhash, true);
			xhr.setRequestHeader("Content-type","application/x-www-form-urlencoded");
			xhr.onreadystatechange = function(){ if (xhr.readyState == 4 && xhr.status == 200) {
				if(xhr.responseText=='stop' || xhr.responseText.length>20 || xhr.responseText.length<1){
				  clearInterval(Check_Interval);  
				}else{
					TemplateMessageFormhash = xhr.responseText;
				}
			}  };
			xhr.send();
		}
		</script>
HTML;

     }
}
//From: Dism��taobao��com
?>