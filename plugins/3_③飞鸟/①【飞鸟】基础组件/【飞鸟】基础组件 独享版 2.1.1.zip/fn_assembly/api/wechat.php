<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: wechat.php 34480 2014-05-07 01:18:15Z nemohou $
 */

define('DISABLEXSSCHECK', true);

require '../../../../source/class/class_core.php';

$discuz = C::app();

$cachelist = array('plugin');

$discuz->cachelist = $cachelist;
$discuz->init();

@require_once libfile('class/wechat','plugin/fn_assembly');
loadcache('plugin');
define('PluginId',($_GET['plugin_id'] == 'fn_assembly' ? 'fn_global' : $_GET['plugin_id']));
$_GET['plugin_id'] = ($_GET['plugin_id'] == 'fn_assembly' ? 'fn_global' : $_GET['plugin_id']).'_setting';
loadcache($_GET['plugin_id']);
$svr = new Fn_WeChatServer($_G['cache'][$_GET['plugin_id']]['wechat_token'], array(
	'receiveEvent::subscribe' => array('plugin' => 'fn_assembly', 'include' => 'response.class.php', 'class' => 'Response', 'method' => 'subscribe'),
	'receiveEvent::unsubscribe' => array('plugin' => 'fn_assembly', 'include' => 'response.class.php', 'class' => 'Response', 'method' => 'unsubscribe'),
	'receiveEvent::scan' => array('plugin' => 'fn_assembly', 'include' => 'response.class.php', 'class' => 'Response', 'method' => 'scan'),
	'receiveEvent::click' => array('plugin' => 'fn_assembly', 'include' => 'response.class.php', 'class' => 'Response', 'method' => 'click'),
	'receiveMsg::text' => array('plugin' => 'fn_assembly', 'include' => 'response.class.php', 'class' => 'Response', 'method' => 'text'),
	'receiveMsg::text' => array('plugin' => 'fn_assembly', 'include' => 'response.class.php', 'class' => 'Response', 'method' => 'text')
));