<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class QHApp{

	public $AppPaymentId;
	private $AppIncomeId;
	private $AppDomain;
	private $AppToken;
	private $AppFromId;

	public function __construct($AppPaymentId=null,$AppIncomeId = null,$AppFromId = null) {
		global $Config;
		$this->AppDomain = strpos($Config['PluginVar']['qf_hostname'],'http') !== false ? $Config['PluginVar']['qf_hostname'] : 'http://'.$Config['PluginVar']['qf_hostname'].'.qianfanapi.com';
		$this->AppSecret = $Config['PluginVar']['qf_secret'];
		$this->AppToken = $Config['PluginVar']['qf_token'];;
		$this->AppPaymentId = $AppPaymentId ? $AppPaymentId : $Config['PluginVar']['qf_type'];
		$this->AppIncomeId = $AppIncomeId ? $AppIncomeId : $Config['PluginVar']['qf_sr_type'];
		$this->AppFromId = $AppFromId ? $AppFromId : $Config['PluginVar']['qf_from_id'];
	}
	
	public function GetOrdersQuery($QFId){
		global $_G;
		$Data = array(
			'order_id' => $QFId,
			'nonce' => $this->GetNonce()
		);
		$Data['sign'] = $this->GetSign($Data,$this->AppSecret);
		$R = http_build_query($Data);
		$Url = $this->AppDomain.'/api1_2/orders/query?'.$R;
		$QFData = dfsockopen($Url);
		if(!$QFData) {
			$QFData = file_get_contents($Url);
		}

		$QFData = json_decode($QFData,true);

		return $QFData['data'][$QFId]['result'] == 1 ? true : false;
	}

	public function GetBalanceAdd($Uid,$Money){//���д��
		$Uid = intval($Uid);
		$Data = array(
			'uid' => $Uid,
			'amount'=> $Money * 100,
			'type'=> $this->AppIncomeId,
			'nonce' => $this->GetNonce()
		);
		$Data['sign'] = $this->GetSign($Data,$this->AppSecret);
		$Url = $this->AppDomain.'/api1_2/balance/add';
		$QFData = CurlPost($Url,$Data);
		if(!$QFData) {
			$QFData = dfsockopen($Url,0,$Data);
		}
		$Return = json_decode($QFData,true);
		if($Return['data']){
			return array('state'=>200);
		}else{
			return array('msg'=>diconv($Return['text'],'UTF-8',CHARSET));
		}
	}

	public function GetMessagesTemplate($PushData){//ģ����Ϣ����
		$params = array(
			'from'=> $this->AppFromId,
			'target'=> $PushData['Uid'],
			'msg' => $PushData['Msg'],
			'showData'=>json_encode($PushData['Content'])
		);
		$data = $this->post('message/template', $params);
		$data['text'] = diconv($data['text'],'UTF-8');
		return $data;
	}
	
	public function GetActionAuthCode($wap_token = '',$operation = 'DECODE') {
		if(!$this->AppSecret){
			return '';
		}
		$wap_token = str_replace(' ','+',urldecode($wap_token));

		$ckey_length = 4;

		$this->AppSecret = md5($this->AppSecret);
		$keya = md5(substr($this->AppSecret, 0, 16));
		$keyb = md5(substr($this->AppSecret, 16, 16));
		$keyc = $ckey_length ? ($operation == 'DECODE' ? substr($wap_token, 0, $ckey_length): substr(md5(microtime()), -$ckey_length)) : '';

		$cryptkey = $keya.md5($keya.$keyc);
		$key_length = strlen($cryptkey);

		$wap_token = $operation == 'DECODE' ? base64_decode(substr($wap_token, $ckey_length)) : sprintf('%010d', $expiry ? $expiry + time() : 0).substr(md5($wap_token.$keyb), 0, 16).$wap_token;
		$string_length = strlen($wap_token);

		$result = '';
		$box = range(0, 255);

		$rndkey = array();
		for($i = 0; $i <= 255; $i++) {
			$rndkey[$i] = ord($cryptkey[$i % $key_length]);
		}

		for($j = $i = 0; $i < 256; $i++) {
			$j = ($j + $box[$i] + $rndkey[$i]) % 256;
			$tmp = $box[$i];
			$box[$i] = $box[$j];
			$box[$j] = $tmp;
		}

		for($a = $j = $i = 0; $i < $string_length; $i++) {
			$a = ($a + 1) % 256;
			$j = ($j + $box[$a]) % 256;
			$tmp = $box[$a];
			$box[$a] = $box[$j];
			$box[$j] = $tmp;
			$result .= chr(ord($wap_token[$i]) ^ ($box[($box[$a] + $box[$j]) % 256]));
		}

		if($operation == 'DECODE') {
			if((substr($result, 0, 10) == 0 || substr($result, 0, 10) - time() > 0) && substr($result, 10, 16) == substr(md5(substr($result, 26).$keyb), 0, 16)) {
				return substr($result, 26);
			} else {
				return '';
			}
		} else {
			return $keyc.str_replace('=', '', base64_encode($result));
		}
	}

	private function GetNonce($length = 32){
		$chars = "abcdefghijklmnopqrstuvwxyz0123456789";
		$str   = "";
		for ($i = 0; $i < $length; $i++) {
			$str .= substr($chars, mt_rand(0, strlen($chars) - 1), 1);
		}
		return $str;
	}

	private function GetSign($params, $secret){
		ksort($params);
		$sparams = array();
		foreach ($params as $k => $v) {
			if ("@" != substr($v, 0, 1)) {
				$sparams[] = "$k=$v";
			}
		}
		$sparams[] = "secret=" . $secret;
		return strtoupper(md5(implode("&", $sparams)));
	}

	/**
     * @param string $method ����ʽ
     * @param string $path ����·��
     * @param array $requestBody ���������
     * @return array
     * @throws Exception
     */
    private function _request($method, $path = null, $requestBody = null){
		if(!$this->AppToken){
			return '';
		}
        $header = array(
            "Authorization: Bearer {$this->AppToken}",
            "Content-Type: application/x-www-form-urlencoded",
            "Cache-Control: no-cache",
            "Accept: application/json",
            "User-Agent: QianFanHttpClient/1.0.0"
        );
        $url = $this->AppDomain."/openapi/{$path}";
        $curlHandle = curl_init();
        curl_setopt($curlHandle, CURLOPT_URL, $url);
        curl_setopt($curlHandle, CURLOPT_HEADER, 0);
        curl_setopt($curlHandle, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($curlHandle, CURLOPT_HTTPHEADER, $header);
        curl_setopt($curlHandle, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($curlHandle, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($curlHandle, CURLOPT_CUSTOMREQUEST, $method);
        if (count($requestBody)) {
            curl_setopt($curlHandle, CURLOPT_POST, 1);
            curl_setopt($curlHandle, CURLOPT_POSTFIELDS, http_build_query($requestBody));
        }
        curl_setopt($curlHandle, CURLOPT_CONNECTTIMEOUT, 2); // ���ӳ�ʱ
        curl_setopt($curlHandle, CURLOPT_TIMEOUT, 2); // ��Ӧ��ʱ

        $response = curl_exec($curlHandle);
        $error = curl_error($curlHandle);
        $errno = curl_errno($curlHandle);
        // $status = curl_getinfo($curlHandle, CURLINFO_HTTP_CODE);
        curl_close($curlHandle);

        if ($error) {
            throw new Exception("cURL Error #{$errno}. $error", 1);
        }

        $data = json_decode($response, true);
        if (json_last_error() != JSON_ERROR_NONE) {
            $error = json_last_error_msg();
            $errno = json_last_error();
            throw new Exception("Json Parsing Error #{$errno}. $error", 1);
        }
        return $data;
    }
	
	public function get($path){
        return $this->_request('GET', $path,array());
    }

    public function put($path, $data){
        return $this->_request('PUT', $path, $data);
    }

    public function post($path, $data){
        return $this->_request('POST', $path, $data);
    }

    public function delete($path, $data){
        return $this->_request('DELETE', $path, $data);
    }

}
//From: Dism��taobao��com
?>