<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class MagApp{

	private $AppSecret;
	private $app_callback_secret;
	private $AppAssistantSecret;
	private $AppAssistantPush;
	private $AppDomain;

	public function __construct($AppSecret=null,$AppAssistantSecret=null,$AppAssistantPush = null) {
		global $Config;
		$this->AppDomain = $Config['PluginVar']['MagDomain'];
		$this->AppSecret = $AppSecret ? $AppSecret : $Config['PluginVar']['MagSecret'];
		$this->app_callback_secret = $Config['PluginVar']['mag_callback_secret'];
		$this->AppAssistantSecret = $AppAssistantSecret ? $AppAssistantSecret : $Config['PluginVar']['MagAssistantSecret'];
		$this->AppAssistantPush = $AppAssistantPush ? $AppAssistantPush : $Config['PluginVar']['MagAssistantPush'];
	}

	public function GetUserInfo(){
		global $Config;
		$UserAgent = $_SERVER['HTTP_USER_AGENT'];
		$Info = explode("|",$UserAgent);
		$Url = $this->AppDomain.'/mag/cloud/cloud/getUserInfo?token='.$Info[7].'&secret='.$this->AppSecret;
		$Data = dfsockopen($Url);
		if(!$Data) {
			$Data = file_get_contents($Url);
		}
		$Data = json_decode($Data,true);
		if($Data['data']){
			return $Data['data'];
		}
	}

	public function GetUnifiedOrder($uid,$money,$title,$trade_no = null){//下单
		global $_G;
		$uid = intval($uid);
		$title = addslashes(diconv($title,CHARSET,'UTF-8'));
		$trade_no = $trade_no ? $trade_no : rand(1,999).'_'.time();

		$nonce = $this->nonce();
		$callback_data = array(
			'trade_no' => $trade_no,
			'nonce' => $nonce
		);
		$callback_data['sign'] = $this->sign($callback_data,$this->app_callback_secret);

		$Url = $this->AppDomain.'/core/pay/pay/unifiedOrder?trade_no='.$trade_no.'&callback='.urlencode($_G['siteurl'].'source/plugin/fn_assembly/notify/notify_mag.php?'.http_build_query($callback_data)).'&amount='.$money.'&title='.$title.'&user_id='.$uid.'&to_user_id=&des='.$title.'&remark='.$title.'&secret='.$this->AppSecret;
		$Data = dfsockopen($Url);
		if(!$Data){
			$Data = file_get_contents($Url);
		}
		$Result = json_decode($Data,true);
		if($Result['success'] == true){
			$Result['data']['trade_no'] = $trade_no;
		}
		return $Result;
	}

	public function GetOrderStatusQuery($UnionOrderNum){//查询订单状态
		global $_G;
	
		$Url = $this->AppDomain.'/core/pay/pay/orderStatusQuery?unionOrderNum='.$UnionOrderNum.'&secret='.$this->AppSecret;

		$Data = dfsockopen($Url);

		if(!$Data){
			$Data = file_get_contents($Url);
		}

		$Result = json_decode($Data,true);

		return $Result['paycode'] == 1 ? true : false;

	}
	
	public function GetSendAssistantMsg($PushData){//马甲推送
		global $_G;
		$Url = $this->AppDomain.'/mag/operative/v1/assistant/sendAssistantMsg?user_id='.$PushData['Uid'].'&type='.$PushData['Type'].'&content='.urlencode(json_encode($PushData['Content'])).'&assistant_secret='.$this->AppAssistantSecret.'&secret='.$this->AppSecret.'&is_push='.$this->AppAssistantPush;
		$Data = dfsockopen($Url);
		if(!$Data) {
			$Data = file_get_contents($Url);
		}
		return json_decode($Data,true);
	}

	public function GetMagAccountTransfer($Uid,$Amount,$Remark,$OutTradeCode=null){//金额写入
		global $Fn_HB_Share;
		$OutTradeCode = $OutTradeCode ? $OutTradeCode :  time().rand(0,999999999);
		$Uid = intval($Uid);
		$Remark = diconv($Remark,CHARSET,'UTF-8');
		$Url = $this->AppDomain.'/core/pay/pay/accountTransfer?secret='.$this->AppSecret.'&user_id='.$Uid.'&amount='.$Amount.'&remark='.$Remark.'&out_trade_code='.$OutTradeCode;
		$Data = dfsockopen($Url);
		if(!$Data) {
			$Data = file_get_contents($Url);
		}
		$Data = json_decode($Data,true);
		if($Data['success'] && $Data['code'] == 101){
			return array('state'=>200);
		}else{
			return array('msg'=>diconv($Data['msg'],'UTF-8',CHARSET));
		}
	}

	private function nonce($length = 32){
		$chars = "abcdefghijklmnopqrstuvwxyz0123456789";
		$str   = "";
		for ($i = 0; $i < $length; $i++) {
			$str .= substr($chars, mt_rand(0, strlen($chars) - 1), 1);
		}
		return $str;
	}

	private function sign($params, $secret){
		ksort($params);
		$sparams = array();
		foreach ($params as $k => $v) {
			if ("@" != substr($v, 0, 1)) {
				$sparams[] = "$k=$v";
			}
		}
		$sparams[] = "secret=" . $secret;
		return strtoupper(md5(implode("&", $sparams)));
	}

}
//From: dis'.'m.tao'.'bao.com
?>