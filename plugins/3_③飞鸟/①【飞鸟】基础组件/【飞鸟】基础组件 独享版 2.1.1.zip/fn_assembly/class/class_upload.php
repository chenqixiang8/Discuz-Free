<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

@require_once (DISCUZ_ROOT .'./source/plugin/fn_assembly/app.inc.php');

class fn_upload{
	static public function Config(){
		global $_G,$Config;
		loadcache('plugin');
		@require_once DISCUZ_ROOT.'/'.$Config['Path']."/weixin/jssdk.php";
		@require_once libfile('function/upload');
		
		$UploadConfig['SwfConfig'] = getuploadconfig($_G['uid']);
		$UploadConfig = array();
		$WeixinGetSignPackage = WxApp ? self::WeixinGetSignPackage() : '';
		if(!$Config['PluginVar']['RemoteAttachments'] || ($Config['PluginVar']['OssAccessId'] && $Config['PluginVar']['OssAccessKey'] && $Config['PluginVar']['OssEndPoint']) ){
			$UploadConfig['operation'] = 'upload';
		}else{
			$UploadConfig['operation'] = 'poll';
		}
		$JSObj = '<script>
	var STATUSMSG = new Array('.implode(',',$Config['LangVar']['STATUSMSG']).');
	var UploadConfig = new Object();
	UploadConfig.appId = "'.$WeixinGetSignPackage['appId'].'";
	UploadConfig.timestamp = "'.$WeixinGetSignPackage['timestamp'].'";
	UploadConfig.nonceStr = "'.$WeixinGetSignPackage['nonceStr'].'";
	UploadConfig.signature = "'.$WeixinGetSignPackage['signature'].'";
	UploadConfig.Uid = '.$_G['uid'].';
	UploadConfig.Auth = "'.md5(substr(md5($_G['config']['security']['authkey']), 8).$_G['uid']).'";
	UploadConfig.MagDomain = "'.$Config['PluginVar']['MagDomain'].'";
	UploadConfig.MaxFileSize = "'.$UploadConfig['SwfConfig']['max'].'";
	UploadConfig.uploadpicfailed = "'.$Config['LangVar']['uploadpicfailed'].'";
	UploadConfig.uploadpicatttypeban = "'.$Config['LangVar']['uploadpicatttypeban'].'";
	UploadConfig.donotcross = "'.$Config['LangVar']['donotcross'].'";
	UploadConfig.attachurl = "'.$_G['setting']['attachurl'].'";
	UploadConfig.operation = "'.$UploadConfig['operation'].'";
	UploadConfig.source = "'.$_GET['id'].'";
	UploadConfig.CompressOption = "'.$Config['PluginVar']['CompressOption'].'";
	UploadConfig.QFVERSION = "'.$_COOKIE['qianfan_appcode'].'";
		</script>';
		$UploadConfig['CssJsHtml'] = $JSObj.'<link rel="stylesheet" href="'.$_G['siteroot'].'source/plugin/fn_assembly/static/css/'.(checkmobile() ? 'upload' : 'pc_upload').'.css?'.VERHASH.'"><script src="'.$_G['siteroot'].'source/plugin/fn_assembly/static/js/app_buildfileupload.js?'.VERHASH.'"></script><script src="'.$_G['siteroot'].'source/plugin/fn_assembly/static/js/app_upload.js?'.VERHASH.'"></script>';
		$UploadConfig['HtmlUpload'] = (!Appbyme && !MagApp && !WxApp && !QFApp) || (QFApp && intval($_COOKIE['qianfan_appcode']) < 4) ? true : false;
		return $UploadConfig;
	}

	static public function WeixinGetSignPackage(){
		global $_G,$Config;
		loadcache('plugin');
		@require_once DISCUZ_ROOT.'/'.$Config['Path']."/weixin/jssdk.php";
		$JSSDK = new JSSDK($Config['PluginVar']['WxAppid'], $Config['PluginVar']['WxSecret']);
		return $JSSDK->getSignPackage();
	}

}
//From: Dism��taobao��com
?>