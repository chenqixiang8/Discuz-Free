<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function CurlGet($url,$Header = null,$Custom = null) {
	if (!function_exists('curl_init')) {
		return '';
	}
	$header = get_headers($url);
	$url_arr = array();
	if ((strpos($header[0],'301') || strpos($header[0],'302')) && !$Custom['get_url']) {
		foreach($header as $Val) {
			if(strpos(strtolower($Val),'location') !== false){
				$url_arr[] = end(explode('Location: ',$Val));
			}
		}
		if($url_arr) {
			$url = end($url_arr);
		}
	}
	
	$Ip = rand(1,255).".".rand(1,255).".".rand(1,255).".".rand(1,255)."";
	$Header = array();
	$Header[] = 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8';
	$Header[] = 'Accept-Encoding: gzip, deflate, sdch';
	$Header[] = 'Accept-Language: zh-CN,zh;q=0.8';
	$Header[] = 'Cache-Control: max-age=0';
	$Header[] = 'Connection: keep-alive';
	$Header[] = 'Connection: keep-alive';
	$Header[] = 'X-FORWARDED-FOR:'.$Ip;
	$Header[] = 'CLIENT-IP:'.$Ip;

	$ch = curl_init();

	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_HTTPHEADER, $Header);
	curl_setopt($ch, CURLOPT_REFERER, $Custom['referer'] ? $Custom['referer'] : "http://www.baidu.com");   //������·
	curl_setopt($ch, CURLOPT_ENCODING, 'gzip');
	curl_setopt($ch, CURLOPT_USERAGENT, $Custom['user-agent'] ? $Custom['user-agent'] : 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2357.130 Safari/537.36');// ���浽�ַ������������
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);

	if (curl_exec($ch)) {

		$data = curl_multi_getcontent($ch);
	}
	curl_close($ch);
	return $data;
}

function CurlPost($url, $post_data=null,$headers=null) {
	if (!function_exists('curl_init')) {
		return '';
	}
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
	if($headers){
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
	}
	# curl_setopt( $ch, CURLOPT_HEADER, 1);

	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
	curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
	curl_setopt($ch, CURLOPT_POST, 1);
	if($post_data){
		curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
	}
	if(curl_exec($ch)) {
		$data = curl_multi_getcontent($ch);
	}
	curl_close($ch);
	return $data;
}

/* TreelistHtml */
function GetTreelistHtml($Array,$Id,$DefaultVal=null,$DefaultVal2=null,$DefaultVal3=null){
	$TreelistHtml = '<ul id="'.$Id.'" style="display:none;">';
	$I = 0;
	foreach($Array as $Key => $Val) {
		if($Val['level'] == 1){
			$Class = $Val['optionid'] === $DefaultVal ? ' class="Default"' : '';
			$TreelistHtml .= '<li Index="'.$I.'"'.$Class.' DataValue="'.$Val['optionid'].'" DataContnet="'.$Val['content'].'">'.$Val['content'];
			if($Val['children']){
				$J = 0;
				$TreelistHtml .= '<ul class="Children">';
				foreach($Val['children'] as $KK => $VV) {
					$Class2 = $VV === $DefaultVal2 ? ' class="Default"' : '';
					$TreelistHtml .= '<li Index="'.$J.'"'.$Class2.' DataValue="'.$Array[$VV]['optionid'].'" DataContnet="'.$Array[$VV]['content'].'">'.$Array[$VV]['content'];
					if($Array[$VV]['children']){
						$TreelistHtml .= '<ul class="Childrens">';
						$P = 0;
						foreach($Array[$VV]['children'] as $K => $V) {
							$Class3 = $V === $DefaultVal3 ? ' class="Default"' : '';
							$TreelistHtml .= '<li DataValue="'.$Array[$V]['optionid'].'" Index="'.$P.'"'.$Class3.' DataContnet="'.$Array[$V]['content'].'">'.$Array[$V]['content'].'</li>';
							$P++;
						}
						$TreelistHtml .= '</ul>';
					}
					$TreelistHtml .= '</li>';
					$J++;
				}
				$TreelistHtml .= '</ul>';
			}
			$TreelistHtml .= '</li>';
			$I++;
		}
	}
	$TreelistHtml .= '</ul>';
	return $TreelistHtml;
}

/* ��ȡ�ֻ����� */
function GetMobile($Uid=null){
	global $_G,$Config;
	$Uid = $Uid ? intval($Uid) : intval($_G['uid']);
	if($Config['PluginVar']['AppType'] == 2){
		$Mobile = DB::fetch_first('SELECT phone as mobile FROM '.DB::table('phonebind').' where uid = '.$Uid);
	}else{
		$Mobile = DB::fetch_first('SELECT mobile FROM '.DB::table('common_member_profile').' where uid = '.$Uid);
	}
	return $Mobile['mobile'];
}

/* ������ۼ� */
function Click($Table,$Id,$Num=1,$IdField='id',$ClickField='click'){
	DB::query("UPDATE ".DB::table($Table)." SET $ClickField = $ClickField + ".$Num." WHERE $IdField = ".intval($Id));
}

/* һά����ת��ά���� */
function DyadicArray($Array,$String=null){
	$DyadicArray = array();
	$I = 0;
	foreach($Array as $K => $V) {
		if(!$I && $String){
			$DyadicArray[] = array(0,$String);
			$I++;
		}
		$DyadicArray[] = array($K,$V);
			
	}
	return $DyadicArray;
}

/* �ı�ת������ */
function TextareaArray($Textarea){
	$Array = array();
	foreach(explode("\n",$Textarea) as $Option){
		$Option = trim($Option);
		$Item = explode('=', $Option);
		$Array[$Item[0]] = str_replace("\r",'',$Item[1]);
	}
	return $Array;
}

function SelectArray($String){
	$Array = array_filter(explode("\r\n",$String));
	foreach ($Array as $key => $val) {
		$KeyVal = explode("=",$val);
		$SubKey = trim($KeyVal[0]);
		$Subvalue = trim($KeyVal[1]);
		$SelectArrayVar = array(
			'content'=>$Subvalue,
			'optionid'=>$SubKey,
			'foptionid'=>trim(substr($SubKey, 0, strrpos($SubKey, '.'))) ? trim(substr($SubKey, 0, strrpos($SubKey, '.'))) : '0',
			'count'=>count(explode('.', $SubKey))
		);
		$SubKeyarr = explode('.', $SubKey);
			if($CountSubKeyarr = count($SubKeyarr)) {
				$TmpKey = '';
				for($i = 0;$i < $CountSubKeyarr;$i++) {
					$SubKeyarr[$i] = trim($SubKeyarr[$i]);
					if(isset($SelectArrayVar['level'])) {
						if(($CountSubKeyarr - $i) > $SelectArrayVar['level']) {
							$SelectArrayVar['level'] = $CountSubKeyarr - $i;
						}
					} else {
						$SelectArrayVar['level'] = $CountSubKeyarr - $i;
					}
					$TmpKey .= $SubKeyarr[$i].'.';
				}
			}
		$SelectArray[$SubKey] = $SelectArrayVar;
	}
	//ksort($SelectArray);
	foreach ($SelectArray as $key => $val) {
		if(!empty($val['foptionid'])){
			$SelectArray[$val['foptionid']]['children'][] = $val['optionid'];
		}
	}
	return $SelectArray;
}

function MobileSelectJs($Array=null,$Array1=null,$Array2=null,$Array3=null,$Array4=null){
	$JsonArray = array();
	if($Array){
		foreach($Array as $Key => $Val) {
			$ReturnArray['id'] = $Key;
			$ReturnArray['value'] = urlencode($Val);
			$ReturnArrayTo[] = $ReturnArray;
		}
		unset($Array);
		$Array['data'] = $ReturnArrayTo;
		$JsonArray[] = $Array;
	}

	if($Array1){
		foreach($Array1 as $Key => $Val) {
			$ReturnArray1['id'] = $Key;
			$ReturnArray1['value'] = urlencode($Val);
			$ReturnArrayTo1[] = $ReturnArray1;
		}
		unset($Array1);
		$Array1['data'] = $ReturnArrayTo1;

		$JsonArray[] = $Array1;
	}

	if($Array2){
		foreach($Array2 as $Key => $Val) {
			$ReturnArray2['id'] = $Key;
			$ReturnArray2['value'] = urlencode($Val);
			$ReturnArrayTo2[] = $ReturnArray2;
		}
		unset($Array2);
		$Array2['data'] = $ReturnArrayTo2;
		$JsonArray[] = $Array2;
	}

	if($Array3){
		foreach($Array3 as $Key => $Val) {
			$ReturnArray3['id'] = $Key;
			$ReturnArray3['value'] = urlencode($Val);
			$ReturnArrayTo3[] = $ReturnArray3;
		}
		unset($Array3);
		$Array3['data'] = $ReturnArrayTo3;
		$JsonArray[] = $Array3;
	}

	if($Array4){
		foreach($Array4 as $Key => $Val) {
			$ReturnArray4['id'] = $Key;
			$ReturnArray4['value'] = urlencode($Val);
			$ReturnArrayTo4[] = $ReturnArray4;
		}
		unset($Array4);
		$Array4['data'] = $ReturnArrayTo4;
		$JsonArray[] = $Array4;
	}
	
	return urldecode(json_encode($JsonArray));
}

function MobileSelectsJs($Array,$Unlimited = false,$flield = 'id',$content = 'name'){
	global $Config;
	$ReturnArray = array();
	$I = 1;
	foreach($Array as $Key => $Val) {
		if($Val['level'] == 0){
			if($Unlimited && $I == 1){
				$ToArray['id'] = '';
				$ToArray['value'] = $Config['LangVar']['Unlimited'];
				$ReturnArray[] = $ToArray;
				$I++;
			}
			$ToArray = array();
			$ToArray['id'] = $Val[$flield];
			$ToArray['value'] = $Val[$content];
			if($Val['children']){
				$J = 1;
				foreach($Val['children'] as $VV) {
					if($Unlimited && $J == 1){
						$ToArray2['id'] = '';
						$ToArray2['value'] = $Config['LangVar']['Unlimited'];
						$ReturnArray2[] = $ToArray2;
						$J++;
					}
					$ToArray2 = array();
					$ToArray2['id'] = $Array[$VV][$flield];
					$ToArray2['value'] = $Array[$VV][$content];
					if($Array[$VV]['children']){
						$K = 1;
						foreach($Array[$VV]['children'] as $V) {
							if($Unlimited && $K == 1){
								$ToArray3['id'] = '';
								$ToArray3['value'] = $Config['LangVar']['Unlimited'];
								$ReturnArray3[] = $ToArray3;
								$K++;
							}
							$ToArray3 = array();
							$ToArray3['id'] = $Array[$V][$flield];
							$ToArray3['value'] = $Array[$V][$content];
							$ReturnArray3[] = $ToArray3;
						}
						$ToArray2['childs'] = $ReturnArray3;
						unset($ReturnArray3);
					}
					$ReturnArray2[] = $ToArray2;
				}
				$ToArray['childs'] = $ReturnArray2;
				unset($ReturnArray2);
			}
			$ReturnArray[] = $ToArray;
		}
	}
	return $ReturnArray;
}

function MobileSelectAreaJs($Array,$Unlimited = false){
	global $Config;
	$ReturnArray = array();
	$I = 1;
	foreach($Array as $Key => $Val) {
		if($Val['level'] == 1){
			if($Unlimited && $I == 1){
				$ToArray['id'] = '';
				$ToArray['value'] = urlencode($Config['LangVar']['Unlimited']);
				$ReturnArray[] = $ToArray;
				$I++;
			}
			$ToArray = array();
			$ToArray['id'] = $Val['optionid'];
			$ToArray['value'] = urlencode($Val['content']);
			if($Val['children']){
				$J = 1;
				foreach($Val['children'] as $VV) {
					if($Unlimited && $J == 1){
						$ToArray2['id'] = '';
						$ToArray2['value'] = urlencode($Config['LangVar']['Unlimited']);
						$ReturnArray2[] = $ToArray2;
						$J++;
					}
					$ToArray2 = array();
					$ToArray2['id'] = $Array[$VV]['optionid'];
					$ToArray2['value'] = urlencode($Array[$VV]['content']);
					if($Array[$VV]['children']){
						$K = 1;
						foreach($Array[$VV]['children'] as $V) {
							if($Unlimited && $K == 1){
								$ToArray3['id'] = '';
								$ToArray3['value'] = urlencode($Config['LangVar']['Unlimited']);
								$ReturnArray3[] = $ToArray3;
								$K++;
							}
							$ToArray3 = array();
							$ToArray3['id'] = $Array[$V]['optionid'];
							$ToArray3['value'] = urlencode($Array[$V]['content']);
							$ReturnArray3[] = $ToArray3;
						}
						$ToArray2['childs'] = $ReturnArray3;
						unset($ReturnArray3);
					}
					$ReturnArray2[] = $ToArray2;
				}
				$ToArray['childs'] = $ReturnArray2;
				unset($ReturnArray2);
			}
			$ReturnArray[] = $ToArray;
		}
	}
	return urldecode(json_encode($ReturnArray));
}

function vueFormArray($arr){
	$newArr = array();
	foreach($arr as $key => $val) {
		$newArr[] = array('value'=>(string)$key,'title'=>$val);
	}
	return $newArr;
}

/* ����ת�� */
function StrToGBK($string,$ajax_status=null){
	global $_G;
	if($_G['charset'] == 'gbk'){
		if($ajax_status == true){
			if(is_array($string)){
				return eval('return '.iconv("GB2312","UTF-8//IGNORE",var_export($string,true).';')); 
			}else{
				return iconv('GB2312', 'UTF-8', $string);
			}
		}else{
			if(is_array($string)){
				$StringArr = array();
				foreach($string as $key=>$value){
					if(is_array($value)){
						foreach($value as $k=>$v){
							$encode = mb_detect_encoding($v, array('UTF-8','GB2312','GBK'));
							if($encode == 'UTF-8'){
								$StringArr[$key][$k] = iconv('UTF-8','GB2312//IGNORE',$v);
							}else if($encode == 'EUC-CN'){
								$StringArr[$key][$k] = $v;
							}
						}
					}else{
						$encode = mb_detect_encoding($value, array('UTF-8','GB2312','GBK'));
						if($encode == 'UTF-8'){
							$StringArr[$key] = iconv('UTF-8','GB2312//IGNORE',$value);
						}else if($encode == 'EUC-CN'){
							$StringArr[$key] = $value;
						}
					}
				}
				return $StringArr;
			}else{
				$encode = mb_detect_encoding($string, array('UTF-8','GB2312','GBK'));
				if($encode == 'UTF-8'){
					return iconv('UTF-8','GB2312//IGNORE', $string);
				}else if($encode == 'EUC-CN'){
					return $string;
				}
			}
		}
	}else{
		return $string;
	}
}

/* ����ת�� */
function EncodeURIToUrldeCode($Data){
	$NewData = array();
    foreach($Data as $Key => $Val){
        $NewData[$Key] = is_array($Val) ? EncodeURIToUrldeCode($Val) : diconv(urldecode(urldecode($Val)),mb_detect_encoding($Val,array('UTF-8','GB2312','GBK')));
    }
    return $NewData;
}

/* ajaxͼƬ�ϴ� */
function GetAjaxUpload($Files){
	global $_G,$Config;
	$File = Fn_Upload($Files['file']);
	if($File['Path']){
		$Data['State'] = 200;
		$Data['Path'] = strpos($File['Path'],'http') !== false ? urlencode($File['Path']) : $_G['siteurl'].$File['Path'];
	}else{
		$Data['Msg'] = urlencode($Config['LangVar']['ImgErr']);
	}
	return $Data;
}

/*  ͼƬ�ϴ� */
function Fn_Upload($Files,$DelUsedFiles=null,$Copy=false,$Save = 0){
	global $_G,$Config;
	require_once (DISCUZ_ROOT.'./source/class/discuz/discuz_upload.php');
	$Upload = new discuz_upload();
	$Config['StaticPicPath'] = 'source/plugin/fn_assembly/attachment';
	if($Upload->init($Files, 'forum') && $Upload->save($Save)) {
		$Path = $Copy ? $_G['setting']['attachdir'].'forum/'.$Upload->attach['attachment'] : (strpos($_G['setting']['attachurl'],'http') !== false ? '' : $_G['siteroot']).$_G['setting']['attachurl'].'forum/'.$Upload->attach['attachment'];
		/*$Name = explode('/',$Upload->attach['attachment']);
		$MPicUrl = DISCUZ_ROOT.$Config['StaticPicPath'].$Name[1];
		if(copy($Upload->attach['target'],$MPicUrl) && $Copy){
			$Path = $Config['StaticPicPath'].$Name[1];
			unlink($Upload->attach['target']);
			unlink(DISCUZ_ROOT.$DelUsedFiles);
		}*/
		if(in_array(strtolower($Upload->attach['ext']),array('php'))){
			@unlink($Upload->attach['target']);
			$File['Errorcode'] = 2;
			return $File;
		}
		if($Config['PluginVar']['Attachment'] == 1){
			@include_once DISCUZ_ROOT.'source/plugin/fn_assembly/lib/OSS/common.php';
			if($ImageUrl = AliOssUpload(uniqid('fn'.time()).'.'.$Upload->attach['ext'],$Upload->attach['target'],'fn_assembly')) {
				@unlink($Upload->attach['target']);
				$Path = $ImageUrl;
			}
		}else if($Config['PluginVar']['Attachment'] == 2){
			@include_once DISCUZ_ROOT.'source/plugin/fn_assembly/lib/qiniu/common.php';
			if($ImageUrl = QiNiuOssUpload(uniqid('fn'.time()).'.'.$Upload->attach['ext'],$Upload->attach['target'],'fn_assembly')) {
				@unlink($Upload->attach['target']);
				$Path = $ImageUrl;
			}
		}else if(strpos($_G['setting']['attachurl'],'http') === false){
			dmkdir(DISCUZ_ROOT.$Config['StaticPicPath'].'/fn_assembly/');
			$AttachmentName = uniqid('fn_'.time()).'.'.$Upload->attach['ext'];
			$CopyUrl = DISCUZ_ROOT.$Config['StaticPicPath'].'/fn_assembly/'.$AttachmentName;
			if(copy($Upload->attach['target'],$CopyUrl)){
				@unlink($Upload->attach['target']);
				$Path = $Config['StaticPicPath'].'/fn_assembly/'.$AttachmentName;
			}
		}
		

		$File['Path'] = strpos($Path,'http') !== false ? $Path : $_G['siteurl'].$Path;
		$File['Name'] = $Upload->attach['name'];
		return $File;
	}else{
		$File['Errorcode'] = $Upload->errorcode;
		return $File;
	}
}

/**
 * ���ݾ�γ�ȺͰ뾶�������Χ
 * @param string $lat γ��
 * @param String $lng ����
 * @param float $radius �뾶
 * @return Array ��Χ����
 */
function CalcScope($lat, $lng, $radius) {
    $degree = (24901*1609)/360.0;
    $dpmLat = 1/$degree;
 
    $radiusLat = $dpmLat*$radius;
    $minLat = $lat - $radiusLat;       // ��Сγ��
    $maxLat = $lat + $radiusLat;       // ���γ��
 
    $mpdLng = $degree*cos($lat * (PI/180));
    $dpmLng = 1 / $mpdLng;
    $radiusLng = $dpmLng*$radius;
    $minLng = $lng - $radiusLng;      // ��С����
    $maxLng = $lng + $radiusLng;      // ��󾭶�
 
    /** ���ط�Χ���� */
    $scope = array(
        'minLat'    =>  $minLat,
        'maxLat'    =>  $maxLat,
        'minLng'    =>  $minLng,
        'maxLng'    =>  $maxLng
        );
    return $scope;
}

function GetVideoHtml($VideoUrl,$Img=null,$Id=null){
	global $Config;
	$Http = IsHttps();
	$Postfix = end(explode('.',$VideoUrl));
	$Postfix = in_array(array('mp4','mu38'),$Postfix) ? $Postfix : 'mp4';
	if(strpos($VideoUrl,'youku.com') !== false){//�ſ�
		$YouKuArray = array_filter(explode('/id_',$VideoUrl));
		$YouKuArray = explode('.html',$YouKuArray[1]);
		$VideoUrl = $Http.'player.youku.com/embed/'.$YouKuArray[0];
		$VideoHtml = "<iframe height='100%' width='100%' src='".$VideoUrl."' frameborder=0 'allowfullscreen'></iframe>";
	}else if(strpos($VideoUrl,'tudou.com') !== false){//�ſ�
		$TuDouArray = array_filter(explode('/',$VideoUrl));
		$TuDouArray = explode('.html',$TuDouArray[count($TuDouArray)]);
		$VideoUrl = $Http.'player.youku.com/embed/'.$TuDouArray[0];
		$VideoHtml = "<iframe height='100%' width='100%' src='".$VideoUrl."' frameborder=0 'allowfullscreen'></iframe>";
	}else if(strpos($VideoUrl,'v.qq.com') !== false){//��Ѷ
		$TxArray = array_filter(explode('/',$VideoUrl));
		$TxArray = explode('.html',$TxArray[count($TxArray)]);
		$VideoUrl = $Http.'v.qq.com/iframe/player.html?vid='.$TxArray[0].'&tiny=0&auto=0';
		$VideoHtml = "<iframe height='100%' width='100%' src='".$VideoUrl."' frameborder=0 'allowfullscreen'></iframe>";
	}else if(strpos(strtolower($VideoUrl),'.mp4') !== false){
		
		if(!checkmobile()){
			$VideoHtml = "
				<script type='text/javascript' src='".$Config['StaticPath']."/ckplayer/ckplayer.js' charset='utf-8'></script>
				<script type='text/javascript'>
				  var flashvars={
						f:'".$VideoUrl."',
						c:0,
						i:'".$ImgSrc."'
				  };
				  var params={bgcolor:'#FFF',allowFullScreen:true,allowScriptAccess:'always',wmode:'transparent'};
				  var video=['".$VideoUrl."->video/".$Postfix."'];
				  CKobject.embed('".$Config['StaticPath']."/ckplayer/ckplayer.swf','PlayVideo".$Id."','ckplayer_PlayVideo".$Id."','100%','100%',false,flashvars,video,params);
				  </script>
			";
		}else{
			$VideoHtml = '<video controls="" webkit-playsinline="" playsinline="" src="'.$VideoUrl.'" id="Video" poster="'.$Img.'"></video>';
		}
		

	}
	return $VideoHtml;
}

function IsHttps(){
	$Http = ((isset($_SERVER['HTTPS']) && strtolower($_SERVER['HTTPS']) == 'on') || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https') || (isset($_SERVER['HTTP_X_CLIENT_SCHEME']) && $_SERVER['HTTP_X_CLIENT_SCHEME'] == 'https')) ? 'https://' : 'http://';
	return $Http;
}

/**
	* exportExcel($data,$title,$filename);
	* ��������Ϊexcel����
	*@param $data    һ����ά����,�ṹ��ͬ�����ݿ�����������
	*@param $title   excel�ĵ�һ�б���,һ������,���Ϊ����û�б���
	*@param $filename ���ص��ļ���
	*@examlpe
	exportExcel($arr,array('id','�˻�','����','�ǳ�'),'�ļ���!');
*/
function ExportExcel($Data=array(),$Title=array(),$Filename='report'){
	header("Content-type:application/octet-stream");
	header("Accept-Ranges:bytes");
	header("Content-type:application/vnd.ms-excel"); 
	header("Content-Disposition:attachment;filename=".$Filename.".xls");
	header("Pragma: no-cache");
	header("Expires: 0");
	//����xls��ʼ
	if(!empty($Title)){
		foreach ($Title as $K => $V){
			$Title[$K]=  diconv($V,CHARSET,'GB2312');
		}
		$Title = implode("\t", $Title);
		echo "$Title\n";
	}
	if(!empty($Data)){
		foreach($Data as $Key => $Val){
			foreach($Val as $K => $V){
				$Data[$Key][$K] = diconv($V,CHARSET,'GB2312');
			}
			$Data[$Key] = implode("\t", $Data[$Key]); 
		}
		echo implode("\n",$Data);
	}
}

/* ʱ���ʽ */
function FormatDate($Time,$Format = 'Y-m-d H:i'){
	global $Config;
	$T = time() - $Time;
	$F = array(
		'86400'=>$Config['LangVar']['Tian'],
		'3600'=>$Config['LangVar']['XiaoShi'],
		'60'=>$Config['LangVar']['FenZhong'],
		'1'=>$Config['LangVar']['Miao']
	);
	if($T < 0){
		$ReturnTime = Date($Format,$Time);
	}else if($T < 60){
		$ReturnTime = $T.$Config['LangVar']['Miao'].$Config['LangVar']['Qian'];
	}else if($T < 3600){
		$ReturnTime = floor($T/60).$Config['LangVar']['FenZhong'].$Config['LangVar']['Qian']; 
	}else if($T < 86400){
		$ReturnTime = floor($T/3600).$Config['LangVar']['XiaoShi'].$Config['LangVar']['Qian']; 
	}else{
		if($T < 259200){
			$ReturnTime = floor($T/86400).$Config['LangVar']['Tian'].$Config['LangVar']['Qian']; 
		}else{
			$ReturnTime = Date($Format,$Time);
		}
	}
	return $ReturnTime;
}

/* 
�޸ı�������
table_name=>
ids=>id
fields=>�ֶ�
val=>ֵ
*/
function EditFields($TableName,$Ids,$Fields,$Val,$FieldId='id'){
	if(is_array($Ids)){
		$Ids = implode(',',$Ids);
	}else{
		$Ids = $Ids;
	}
	$UpData[$Fields] = $Val;
	if(DB::update($TableName,$UpData,$FieldId.' in( '.$Ids.' )')){
		return true;
	}else{
		return false;
	}
}

/* ����ת��urlencode */
function ArrayUrlencode($Data){
    $NewData = array();
    foreach($Data as $Key => $Val){
        // �����ҶԼ�Ҳ������urlencode
        $NewData[$Key] = is_array($Val) ? ArrayUrlencode($Val) : urlencode($Val);
    }
    return $NewData;
}

/* ����ת��urldecode */
function ArrayUrldecode($Data){
    $NewData = array();
    foreach($Data as $Key => $Val){
        // �����ҶԼ�Ҳ������urlencode
        $NewData[$Key] = is_array($Val) ? ArrayUrldecode($Val) : urldecode($Val);
    }
    return $NewData;
}

/* API����ת��utf8 */
function iconvUtf($data){
	if(is_array($data)){
		$newData = array();
		foreach($data as $key => $val){
			$newData[$key] = is_array($val) ? iconvUtf($val) : diconv($val,mb_detect_encoding($val, array('ASCII','UTF-8','GB2312','GBK','BIG5')),CHARSET);
		}
	}else{
		$newData = diconv($data,mb_detect_encoding($data, array('ASCII','UTF-8','GB2312','GBK','BIG5')),CHARSET);
	}
    
    return $newData;
}

/* ���Html */
function DeleteHtml($Str) { 
	global $Config;
    $Str = addslashes(strip_tags(trim($Str))); //����ַ������ߵĿո�
    $Str = preg_replace("/\t/","",$Str); //ʹ���������ʽ�滻���ݣ��磺�ո񣬻��У������滻Ϊ�ա�
    $Str = preg_replace("/\r\n/","",$Str); 
    $Str = preg_replace("/\r/","",$Str); 
    $Str = preg_replace("/\n/","",$Str); 
    $Str = preg_replace("/ /","",$Str);
    $Str = preg_replace("/  /","",$Str);  //ƥ��html�еĿո�
	$Str = preg_replace("//","",$Str);
	$Str = preg_replace("//","",$Str);
	$Str = preg_replace("//","",$Str);
	$Str = str_replace(array("\\","\/","'","\"",$Config['LangVar']['fenhao'],$Config['LangVar']['wanhao']),array("","","","","",""),$Str);
    return trim($Str); //�����ַ���
}

//��ȡ�ļ���ʽ
function GetFileext($filename){
	return addslashes(strtolower(substr(strrchr($filename, '.'), 1, 10)));
}

function ClickRoundNumber($Number, $MinValue = 1000, $Decimal = 1 ) {
	global $Config;
    if($Number < $MinValue ){
        return $Number;
    }
    $Alphabets = array( 100000000 => $Config['LangVar']['Yi'], 10000 => $Config['LangVar']['Wan'], 1000 => $Config['LangVar']['QianTo'] );
    foreach($Alphabets as $Key => $Value ){
		if( $Number >= $Key ) {
			return round( $Number / $Key, $Decimal ) . '' . $Value;
		}
	}
}

function DownloadImg($Url,$File){
	$return_content = dfsockopen($Url);
	$return_content = $return_content ? $return_content : file_get_contents($Url);
	$return_content = $return_content ? $return_content : CurlGet($Url);
	$fp = @fopen($File,"a"); //���ļ��󶨵���
	fwrite($fp,$return_content); //д���ļ�
	fclose($fp);
}

//ͼƬ·��תBase64
function GetAjaxBase64Image($Array){
	global $_G;
	$Base64ImageArray = array();
	foreach($Array as $Key => $Value){
		if($Value && strpos(strtolower($Value),'.php') === false){
			$Base64 = base64_encode(dfsockopen(strpos($Value,'http') !== false ? $Value : $_G['siteurl'].$Value));
			$Base64 = $Base64 ? $Base64 : (strpos($Value,'http') !== false ? '' : base64_encode(file_get_contents($Value)));
			$Base64 = $Base64 ? $Base64 : base64_encode(CurlGet(str_replace('https','http',strpos($Value,'http') !== false ? $Value : $_G['siteurl'].$Value)));
		}else{
			$Base64 = '';
		}
		$Base64ImageArray[$Key] = $Base64 ? 'data:image/jpeg;base64,'.$Base64 : '';
	}
	return $Base64ImageArray;
}
//From: dis'.'m.tao'.'bao.com
?>