<?php

/**
 *      Copyright 2001-2099 DisM!Ӧ������.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: rewrite.class.php 37712 2018-03-01 17:57:48Z DisM.Taobao.Com $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_zhuzhu_taobao {

	function plugin_zhuzhu_taobao() {
		global $_G;
		$zhuzhu_rewrite = dunserialize($_G['setting']['zhuzhu_taobao']);

		if($zhuzhu_rewrite['taobao']['available']) {
			$_G['setting']['output']['preg']['search']['taobao'] = '/"plugin.php\?id\=zhuzhu_taobao"/';
			$_G['setting']['output']['preg']['replace']['taobao'] = 'plugin_zhuzhu_taobao::rewriteoutput(\'taobao\', 0)';
		}
		if($zhuzhu_rewrite['taobao-tbk']['available']) {
			$_G['setting']['output']['preg']['search']['taobao-tbk'] = '/"plugin.php\?id\=zhuzhu_taobao&(amp;)mod\=tbk"/';
			$_G['setting']['output']['preg']['replace']['taobao-tbk'] = 'plugin_zhuzhu_taobao::rewriteoutput(\'taobao-tbk\', 0)';
		}
		if($zhuzhu_rewrite['taobao-tbk-9k9']['available']) {
			$_G['setting']['output']['preg']['search']['taobao-tbk-9k9'] = '/"plugin.php\?id\=zhuzhu_taobao&(amp;)mod\=tbk&(amp;)?ac\=9k9\"/';
			$_G['setting']['output']['preg']['replace']['taobao-tbk-9k9'] = 'plugin_zhuzhu_taobao::rewriteoutput(\'taobao-tbk-9k9\', 0)';
		}

		if($zhuzhu_rewrite['taobao-tbkcat']['available']) {
			$_G['setting']['output']['preg']['search']['taobao-tbkcat'] = '/"plugin.php\?id\=zhuzhu_taobao&(amp;)?mod\=tbk&(amp;)?cat\=(\d+)\"/';
			$_G['setting']['output']['preg']['replace']['taobao-tbkcat'] = 'plugin_zhuzhu_taobao::rewriteoutput(\'taobao-tbkcat\', 0, 0, $matches[3])';
		}
		if($zhuzhu_rewrite['taobao-tqg']['available']) {
			$_G['setting']['output']['preg']['search']['taobao-tqg'] = '/"plugin.php\?id\=zhuzhu_taobao&(amp;)mod\=tqg\"/';
			$_G['setting']['output']['preg']['replace']['taobao-tqg'] = 'plugin_zhuzhu_taobao::rewriteoutput(\'taobao-tqg\', 0)';
		}
		if($zhuzhu_rewrite['taobao-tbrand']['available']) {
			$_G['setting']['output']['preg']['search']['taobao-tbrand'] = '/"plugin.php\?id\=zhuzhu_taobao&(amp;)mod\=tbrand\"/';
			$_G['setting']['output']['preg']['replace']['taobao-tbrand'] = 'plugin_zhuzhu_taobao::rewriteoutput(\'taobao-tbrand\', 0)';
		}
		if($zhuzhu_rewrite['taobao-tbrandid']['available']) {
			$_G['setting']['output']['preg']['search']['taobao-tbrandid'] = '/"plugin.php\?id\=zhuzhu_taobao&(amp;)?mod\=tbrand&(amp;)?op\=view&(amp;)?brand_id\=(\d+)\"/';
			$_G['setting']['output']['preg']['replace']['taobao-tbrandid'] = 'plugin_zhuzhu_taobao::rewriteoutput(\'taobao-tbrandid\', 0, 0, $matches[4])';
		}
		if($zhuzhu_rewrite['taobao-uatm']['available']) {
			$_G['setting']['output']['preg']['search']['taobao-uatm'] = '/"plugin.php\?id\=zhuzhu_taobao&(amp;)mod\=uatm\"/';
			$_G['setting']['output']['preg']['replace']['taobao-uatm'] = 'plugin_zhuzhu_taobao::rewriteoutput(\'taobao-uatm\', 0)';
		}
		if($zhuzhu_rewrite['taobao-uatm-cat']['available']) {
			$_G['setting']['output']['preg']['search']['taobao-uatm-cat'] = '/"plugin.php\?id\=zhuzhu_taobao&(amp;)mod\=uatm&(amp;)?favorites_id\=(\d+)\"/';
			$_G['setting']['output']['preg']['replace']['taobao-uatm-cat'] = 'plugin_zhuzhu_taobao::rewriteoutput(\'taobao-uatm-cat\', 0, 0, $matches[3])';
		}
		if($zhuzhu_rewrite['taobao-quan']['available']) {
			$_G['setting']['output']['preg']['search']['taobao-quan'] = '/"plugin.php\?id\=zhuzhu_taobao&(amp;)mod\=quan\"/';
			$_G['setting']['output']['preg']['replace']['taobao-quan'] = 'plugin_zhuzhu_taobao::rewriteoutput(\'taobao-quan\', 0)';
		}
		if($zhuzhu_rewrite['taobao-quan-cat']['available']) {
			$_G['setting']['output']['preg']['search']['taobao-quan-cat'] = '/"plugin.php\?id\=zhuzhu_taobao&(amp;)mod\=quan&(amp;)?category_id\=(\d+)\"/';
			$_G['setting']['output']['preg']['replace']['taobao-quan-cat'] = 'plugin_zhuzhu_taobao::rewriteoutput(\'taobao-quan-cat\', 0, $matches[2], $matches[3], $matches[4], $matches[5])';
		}
		if($zhuzhu_rewrite['taobao-view']['available']) {
			$_G['setting']['output']['preg']['search']['taobao-view'] = '/"plugin.php\?id\=zhuzhu_taobao&(amp;)?mod\=jump_url&(amp;)?num_iid\=(\d+)\"/';
			$_G['setting']['output']['preg']['replace']['taobao-view'] = 'plugin_zhuzhu_taobao::rewriteoutput(\'taobao-view\', $matches[1], $matches[2], $matches[3], $matches[4], $matches[5])';
		}

	}

	function global_footer(){
		global $_G;
		return '<!-- rewrite_replace -->';
	}

	function rewriteoutput($type, $returntype) {
		global $_G;
		$fextra = '';

		if($type == 'taobao') {
			list(,,, $extra) = func_get_args();
			$r = array();
		}
		if($type == 'taobao-tbk') {
			list(,,, $extra) = func_get_args();
			$r = array();
		}
		if($type == 'taobao-tbk-9k9') {
			list(,,, $extra) = func_get_args();
			$r = array();
		}
		if($type == 'taobao-tbkcat') {
			list(,,, $cat, $extra) = func_get_args();
			$r = array(
				'{cat}' => $cat ? $cat : 0,
			);
		}
		if($type == 'taobao-tqg') {
			list(,,, $extra) = func_get_args();
			$r = array();
		}
		if($type == 'taobao-view') {
			list(,,, $num_iid, $extra) = func_get_args();
			$r = array(
				'{num_iid}' => $num_iid ? $num_iid : 0,
			);
		}
		if($type == 'taobao-quan') {
			list(,,, $extra) = func_get_args();
			$r = array();
		}
		if($type == 'taobao-quan-cat') {
			list(,,, $category_id, $extra) = func_get_args();
			$r = array(
				'{category_id}' => $category_id ? $category_id : 0,
			);
		}
		if($type == 'taobao-uatm') {
			list(,,, $extra) = func_get_args();
			$r = array();
		}
		if($type == 'taobao-uatm-cat') {
			list(,,, $favorites_id, $extra) = func_get_args();
			$r = array(
				'{favorites_id}' => $favorites_id ? $favorites_id : 0,
			);
		}
		if($type == 'taobao-tbrandid') {
			list(,,, $brand_id, $extra) = func_get_args();
			$r = array(
				'{brand_id}' => $brand_id ? $brand_id : 0,
			);
		}
		$zhuzhu_rewrite = dunserialize($_G['setting']['zhuzhu_taobao']);
		$href = str_replace(array_keys($r), $r, $zhuzhu_rewrite[$type]['rule']).$fextra;

		if(!$returntype) {
			return '"'.$href.'"';
		}
	}
}
//d'.'i'.'sm.ta'.'o'.'bao.com
?>