<?php

/**
 *      Copyright 2001-2099 DisM!Ӧ������.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: uninstall.php 37712 2017-12-10 19:32:26Z DisM.Taobao.Com $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

@unlink('./data/sysdata/cache_zhuzhu_taobao_category.php');
@unlink('./data/sysdata/cache_zhuzhu_taobao_brand.php');

$sql = <<<EOF
DROP TABLE IF EXISTS `pre_zhuzhu_taobao_brand`;
DROP TABLE IF EXISTS `pre_zhuzhu_taobao_category`;
DROP TABLE IF EXISTS `pre_zhuzhu_taobao_order`;
DROP TABLE IF EXISTS `pre_zhuzhu_taobao_tbkorder`;
DROP TABLE IF EXISTS `pre_zhuzhu_taobao_user`;
EOF;

C::t('common_setting')->delete(array('zhuzhu_taobao', 'zhuzhu_taobao_rewrite', 'zhuzhu_seo'));
updatecache('setting');

runquery($sql);

$finish = TRUE;