<?php

/**
 * data
 * @author auto create
 */
class MapData
{
	
	/** 
	 * password
	 **/
	public $model;	
}
//d'.'i'.'sm.ta'.'o'.'bao.com
?>