<?php

/**
 *      Copyright 2001-2099 DisM!Ӧ������.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: zhuzhu_taobao.inc.php 10689 2017-07-31 08:32:33Z DisM.Taobao.Com $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once(DISCUZ_ROOT.'./source/plugin/zhuzhu_taobao/sdk/TopSdk.php');
require_once libfile('function/core', 'plugin/zhuzhu_taobao');
loadcache(array('zhuzhu_taobao_category', 'zhuzhu_taobao_brand', 'zhuzhu_taobao_seo'));

$var = $_G['cache']['plugin']['zhuzhu_taobao'];

$appkey = $var['appkey'];
$secret = $var['appsecret'];
$appadzoneid = explode('_', $var['adzoneid']);
$appadzoneid = $appadzoneid['3'];
$ratio = $var['ratio'] ? $var['ratio']*100 : '100';

$img = './source/plugin/zhuzhu_taobao/static/image/';
$jump_url = 'plugin.php?id=zhuzhu_taobao&mod=jump_url&num_iid=';
$go_taobao = 'plugin.php?id=zhuzhu_taobao&mod=app&backurl=';

foreach(unserialize($var['tao_cat']) as $v){
	$t_cat .= $v.',';
}

$tao_cat = $t_cat ? $t_cat : '16';

$hotkeys =  explode('|', $var['hot_key']);

$extcredit = $_G['setting']['extcredits'][$var['extcredit']];
$member = array_merge(
	C::t('common_member_count')->fetch($_G['uid']), C::t('common_member_profile')->fetch($_G['uid'])
);
$member['credit'] = $member['extcredits'.$var['extcredit']];

$index_slide = explode("\n", $var['index_slide']);
foreach($index_slide as $key => $value) {
	list($pic, $url, $bgcolor) = explode('#', $value);
	$slide[$key]['pic'] = $pic;
	$slide[$key]['url'] = $url;
	$slide[$key]['bgcolor'] =  str_replace(array("\r\n", "\r", "\n"), "", $bgcolor);
	if($key == '0'){
	$bg_arr .= '"#'.$slide[$key]['bgcolor'].'"';
	}else{
	$bg_arr .= ',"#'.$slide[$key]['bgcolor'].'"';
	}
}

$zz_nav = unserialize($var['nav_show']);
$zz_foot_tag = explode("|", $var['foot_tag']);
$zz_seo = unserialize($_G['setting']['zhuzhu_seo']);

$modarray = array('index', 'quan', 'tbk', 'tkl', 'tqg', 'uatm', 'tbrand', 'jump_url', 'app', 'img', 'api', 'my', 'search', 'updata', 'updata_now');
$mod = !in_array($_G['mod'], $modarray) ? 'index' : $_G['mod'];

if($_G['cache']['plugin']['zhuzhu_taobao']['rewrite']){
	require_once libfile('function/rewrite', 'plugin/zhuzhu_taobao');
	zz_rewrite();
}

require DISCUZ_ROOT.'./source/plugin/zhuzhu_taobao/module/taobao_'.$mod.'.php';

?>