<?php

/**
 *      Copyright 2001-2099 DisM!Ӧ������.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: install.php 37712 2019-03-09 19:29:36Z DisM.Taobao.Com $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF

DROP TABLE IF EXISTS `pre_zhuzhu_taobao_brand`;
CREATE TABLE `pre_zhuzhu_taobao_brand`  (
  `brand_id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT,
  `category_id` tinyint(3) NOT NULL DEFAULT 0,
  `displayorder` tinyint(3) NOT NULL DEFAULT 0,
  `name` varchar(100) NOT NULL,
  `logo` varchar(100) NOT NULL,
  `banner` varchar(100) NOT NULL,
  `big_banner` varchar(100) NOT NULL,
  `keyword` varchar(100) NOT NULL,
  `recommend` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY USING BTREE (`brand_id`)
) ENGINE = MyISAM;

DROP TABLE IF EXISTS `pre_zhuzhu_taobao_category`;
CREATE TABLE `pre_zhuzhu_taobao_category`  (
  `category_id` smallint(6) UNSIGNED NOT NULL AUTO_INCREMENT,
  `upid` smallint(6) UNSIGNED NOT NULL DEFAULT 0,
  `displayorder` tinyint(3) NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `pic` varchar(255) NOT NULL,
  `keyword` varchar(100) NOT NULL,
  `available` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY USING BTREE (`category_id`)
) ENGINE = MyISAM;

DROP TABLE IF EXISTS `pre_zhuzhu_taobao_order`;
CREATE TABLE `pre_zhuzhu_taobao_order`  (
  `order_id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` mediumint(8) UNSIGNED NOT NULL DEFAULT 0,
  `num_iid` bigint(19) UNSIGNED NOT NULL DEFAULT 0,
  `order_num` bigint(19) UNSIGNED NOT NULL DEFAULT 0,
  `etxcredit` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `dateline` int(10) UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY USING BTREE (`order_id`)
) ENGINE = MyISAM;

DROP TABLE IF EXISTS `pre_zhuzhu_taobao_tbkorder`;
CREATE TABLE `pre_zhuzhu_taobao_tbkorder`  (
  `order_id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT,
  `auctionTitle` varchar(255) CHARACTER SET gbk COLLATE gbk_chinese_ci NOT NULL COMMENT '��Ʒ����',
  `exShopTitle` varchar(255) CHARACTER SET gbk COLLATE gbk_chinese_ci NOT NULL COMMENT '��������',
  `createTime` varchar(50) CHARACTER SET gbk COLLATE gbk_chinese_ci NOT NULL DEFAULT '0' COMMENT '����ʱ��',
  `adzone_id` varchar(20) CHARACTER SET gbk COLLATE gbk_chinese_ci NOT NULL COMMENT '�ƹ�����',
  `item_id` bigint(11) NOT NULL COMMENT '��Ʒ���',
  `payPrice` decimal(5, 2) NOT NULL DEFAULT 0.00 COMMENT '������',
  `tkPubShareFeeString` decimal(5, 2) NOT NULL DEFAULT 0.00 COMMENT 'Ԥ������',
  `terminalType` varchar(10) CHARACTER SET gbk COLLATE gbk_chinese_ci NOT NULL COMMENT '�ɽ�ƽ̨',
  `order_num` bigint(19) UNSIGNED NOT NULL COMMENT '�������',
  `user_num` mediumint(6) UNSIGNED ZEROFILL NOT NULL COMMENT 'β��ƥ��',
  `status` tinyint(1) UNSIGNED NOT NULL COMMENT '����״̬',
  `from` varchar(20) CHARACTER SET gbk COLLATE gbk_chinese_ci NULL DEFAULT NULL COMMENT '��Ʒ��Դ',
  `uid` mediumint(8) UNSIGNED NOT NULL COMMENT '��ȡUID',
  PRIMARY KEY (`order_id`) USING BTREE
) ENGINE = MyISAM;

DROP TABLE IF EXISTS `pre_zhuzhu_taobao_user`;
CREATE TABLE `pre_zhuzhu_taobao_user`  (
  `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` mediumint(8) UNSIGNED NOT NULL,
  `user_num` mediumint(6) UNSIGNED ZEROFILL NOT NULL,
  PRIMARY KEY USING BTREE (`id`)
) ENGINE = MyISAM;


EOF;

runquery($sql);

$finish = TRUE;

?>