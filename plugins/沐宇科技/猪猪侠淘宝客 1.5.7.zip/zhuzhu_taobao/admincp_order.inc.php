<style type="text/css">
.status_12,.status_14 {color: #0eb773;}
.status_3 {color: #F20}
.status_2 {color: #FFF;background: #F20;padding: 2px 5px;}
.status_13 {text-decoration:line-through}
</style>
<?php

/**
 *      Copyright 2001-2099 DisM!Ӧ������.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: admincp_goods.inc.php 33234 2014-01-08 18:33:16Z DISM.TAOBAO.COM $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$lang = array_merge($lang, $scriptlang['zhuzhu_taobao']);

$ratio = $_G['cache']['plugin']['zhuzhu_taobao'] ? $_G['cache']['plugin']['zhuzhu_taobao']*100 : '100';

if(!submitcheck('listsubmit')) {
	$perpage = 20;
	$start = ($page - 1) * $perpage;
	$mpurl = ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin['pluginid'].'&identifier=zhuzhu_taobao&pmod=admincp_order';

	showformheader('plugins&operation=config&do='.$plugin['pluginid'].'&identifier=zhuzhu_taobao&pmod=admincp_order');
	showtableheader();
	showtablerow('', array('width="50"', 'width="130"', 'width="50"', 'width="50"', 'width="50"', 'width="50"', 'width="50"'), array(
		$lang['order_num'],
		"<input size=\"25\" name=\"order_num\" type=\"text\" value=\"$_GET[order_num]\" />",
		"<input class=\"btn\" type=\"submit\" value=\"$lang[search]\" />",
		"<a href=\"".$mpurl."\">".cplang('all')."</a>",
		"<a href=\"".$mpurl."&status=12\">".cplang('order_status_12')."</a>",
		"<a href=\"".$mpurl."&status=14\">".cplang('order_status_14')."</a>",
		"<a href=\"".$mpurl."&status=3\">".cplang('order_status_3')."</a>",
		"<a href=\"".$mpurl."&status=13\">".cplang('order_status_13')."</a>",
	));
	showtablefooter(); /*dism - taobao - com*/ /*dism��taobao��com*/
	showtableheader();
	showsubtitle(array( 'order_num', 'shop', 'name', 'pingtai', 'payprice', 'etxcredit', 'dateline', 'status', 'take_uid'));
	$param = array(
		array('status', $_GET['status']),
		array('order_num', $_GET['order_num']),
	);
	$count = C::t('#zhuzhu_taobao#zhuzhu_taobao_tbkorder')->count_by_search($param);

	if($count) {
		$query = C::t('#zhuzhu_taobao#zhuzhu_taobao_tbkorder')->fetch_all_by_search($param, $start, $perpage);
		foreach($query as $value) {
			showtablerow('', array('class="td25"'), array(
				$value['order_num'],
				$value['exShopTitle'],
				'<a href="./plugin.php?id=zhuzhu_taobao&mod=jump_url&num_iid='.$value['item_id'].'" target="_blank">'.$value['auctionTitle'].'</a>',
				$value['terminalType'],
				$value['payPrice'],
				$value['tkPubShareFeeString']*$ratio,
				$value['createTime'],
				$value['uid'] ? '<span class="status_2">'.cplang('take_order').'</span>' :'<span class="status_'.$value['status'].'">'.cplang('order_status_'.$value['status']).'</span>',
				$value['uid'] ? '<a target="_blank" href="/home.php?mod=space&uid='.$value['uid'].'">UID '.$value['uid'].'</a>' : '',
			));
		}
		$multipage = multi($count, $perpage, $page, $mpurl);
	}
	showsubmit('', '', '', '', $multipage);
	showtablefooter(); /*dism - taobao - com*/ /*dism��taobao��com*/
	showformfooter(); /*dism . taobao . com*/ /*dis'.'m.tao'.'bao.com*/

}

function array_col($array, $key) {
	global $_G;

	foreach($array as $value) {
		$return[] = $value[$key];
	}
	$return = array_unique($return);

	return $return;
}
//From: Dism_taobao-com
?>