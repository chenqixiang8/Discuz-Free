<?php

/**
 *      Copyright 2001-2099 DisM!Ӧ������.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: setting.php 10455 2019-03-08 02:03:20Z DisM.Taobao.Com $
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once libfile('function/home');

if(submitcheck('settingsubmit')) {
	$user_num = intval($_GET['user_num']);

	if(empty($user_num)) {
		showmessage('zhuzhu_taobao:user_num_tips');
	}

	$num = C::t('#zhuzhu_taobao#zhuzhu_taobao_user')->fetch_by_num($user_num);

	if($num) {
		showmessage('zhuzhu_taobao:num_in');
	}

	$user = C::t('#zhuzhu_taobao#zhuzhu_taobao_user')->fetch_by_user($_G['uid']);

	if($user) {
		showmessage('zhuzhu_taobao:user_in');
	}

	$setarr = array(
		'user_num' => $user_num,
		'uid' => $_G['uid'],
	);
	C::t('#zhuzhu_taobao#zhuzhu_taobao_user')->insert($setarr, true);

	showmessage('zhuzhu_taobao:num_setting', 'plugin.php?id=zhuzhu_taobao&mod=my');
}

//d'.'is'.'m.tao'.'ba'.'o.com
?>