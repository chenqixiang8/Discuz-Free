<?php

/**
 *      Copyright 2001-2099 DisM!Ӧ������.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: my_take.php 10455 2019-03-08 02:03:20Z DisM.Taobao.Com $
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once libfile('function/home');

if($_GET['formhash'] != $_G['formhash']) {
	showmessage('submit_invalid');
}

$order_id = intval($_GET['order_id']);

$tbk_order = C::t('#zhuzhu_taobao#zhuzhu_taobao_tbkorder')->fetch($order_id);

if($tbk_order['status'] !== '3') {
	showmessage('zhuzhu_taobao:order_1_tips');
}elseif($tbk_order['uid']) {
	showmessage('zhuzhu_taobao:order_3_tips');
}elseif($tbk_order['status'] == '13') {
	showmessage('zhuzhu_taobao:order_4_tips');
}

$user = C::t('#zhuzhu_taobao#zhuzhu_taobao_user')->fetch_by_user($_G['uid']);

if($user[0]['user_num'] !== $tbk_order['user_num']) {
	showmessage('zhuzhu_taobao:no_userid');
}
$rebate = intval($tbk_order['tkPubShareFeeString']*$ratio);

$setarr = array(
	'uid' => $_G['uid'],
	'num_iid' => $tbk_order['auctionId'],
	'order_num' => $tbk_order['order_num'],
	'etxcredit' => $rebate,
	'dateline' => $_G['timestamp'],
);

updatemembercount($_G['uid'], array($var['extcredit'] => $rebate),true,'','','','','');
C::t('#zhuzhu_taobao#zhuzhu_taobao_order')->insert($setarr, true);

C::t('#zhuzhu_taobao#zhuzhu_taobao_tbkorder')->update($order_id, array('uid' => $_G['uid']));
showmessage('zhuzhu_taobao:take_succeed', 'plugin.php?id=zhuzhu_taobao&mod=my&ac=order');

?>