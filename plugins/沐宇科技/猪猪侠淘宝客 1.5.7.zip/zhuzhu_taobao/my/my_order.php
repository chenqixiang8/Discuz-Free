<?php

/**
 *      Copyright 2001-2099 DisM!Ӧ������.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: my_index.php 10455 2017-06-28 02:03:20Z DisM.Taobao.Com $
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once libfile('function/home');

$user = C::t('#zhuzhu_taobao#zhuzhu_taobao_user')->fetch_by_user($_G['uid']);

if(empty($user)){
	showmessage('zhuzhu_taobao:no_user_num');
}

$perpage = '10';
$page = max(1, intval($_GET['page']));
$start = ($page - 1) * $perpage;
if($start < 0) $start = 0;

$order_lang = array(
	'1' => lang('plugin/zhuzhu_taobao', 'order_status_1'),
	'3' => lang('plugin/zhuzhu_taobao', 'order_status_3'),
	'12' => lang('plugin/zhuzhu_taobao', 'order_status_12'),
	'13' => lang('plugin/zhuzhu_taobao', 'order_status_13'),
	'14' => lang('plugin/zhuzhu_taobao', 'order_status_14'),
);

$status = intval($_GET['status']);

$param = array(
	array('user_num', $user[0]['user_num']),
	array('status', $_GET['status'])
);

$count = C::t('#zhuzhu_taobao#zhuzhu_taobao_tbkorder')->count_by_search($param);
if($count){
	$query = C::t('#zhuzhu_taobao#zhuzhu_taobao_tbkorder')->fetch_all_by_search($param);
	foreach($query as $value){
		$value['rebate'] = intval($value['tkPubShareFeeString']*$ratio);
		$order_list[] = $value;
	}
	$multi = multi($count, $perpage, $page, $theurl);
}
$page_num = ceil($count/$perpage);

if(!$_G['mobile']) debug('no_data');

include template('zhuzhu_taobao:my_order');
?>