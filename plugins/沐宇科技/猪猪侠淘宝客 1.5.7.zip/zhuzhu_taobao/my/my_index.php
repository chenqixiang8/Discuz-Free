<?php

/**
 *      Copyright 2001-2099 DisM!Ӧ������.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: my_index.php 10455 2017-06-28 02:03:20Z DisM.Taobao.Com $
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once libfile('function/home');

$order_url = 'plugin.php?id=zhuzhu_taobao&mod=my&ac=order';
$user = C::t('#zhuzhu_taobao#zhuzhu_taobao_user')->fetch_by_user($_G['uid']);
$count_order = C::t('#zhuzhu_taobao#zhuzhu_taobao_tbkorder')->count_by_search(array(array('user_num', $user[0]['user_num'])));
$count_favorite = '0';

include template('zhuzhu_taobao:my_index');
?>