<?php

/**
 *      Copyright 2001-2099 DisM!Ӧ������.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: admincp_rewrite.inc.php 37712 2018-03-01 11:31:15Z DisM.Taobao.Com $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$lang = array_merge($lang, $scriptlang['zhuzhu_taobao']);

showtips('no_rewrite');

?>