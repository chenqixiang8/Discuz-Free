<?php

/**
 *      Copyright 2001-2099 DisM!Ӧ������.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: cron_order.php 10455 2018-10-30 02:03:20Z DisM.Taobao.Com $
 */

if (!defined('IN_DISCUZ') && $_G['adminid'] !== '1') {
	exit('Access Denied');
}

require_once libfile('function/home');

$file = "./source/plugin/zhuzhu_taobao/cron/cron_zhuzhu_taobao_upadata.php";
if(file_exists($file)) {
	dheader("Location: ./plugin.php?id=zhuzhu_taobao&mod=updata_now");
}

$query = C::t('#zhuzhu_taobao#zhuzhu_taobao_tbkorder')->fetch_all_by_search('');
foreach($query as $key=>$value){
	$order[] = $value['order_num'];
}

require_once './source/plugin/zhuzhu_taobao/include/excel_reader2.php';
$path = "./source/plugin/zhuzhu_taobao/upload/TaokeDetail.xls";
$data = new Spreadsheet_Excel_Reader();
$data->read($path);

unset($data->sheets[0]['cells'][1]);
$query = $data->sheets[0]['cells'];
$k = '0';

foreach($query as $key=>$value){
	$v['auctionTitle'] = $value['3'];
	$v['exShopTitle'] = $value['6'];
	$v['createTime'] = $value['1'];
	$v['item_id'] = $value['4'];
	$v['payPrice'] = $data->sheets[0]['cellsInfo'][$key][8]['raw'];
	$v['tkPubShareFeeString'] = $data->sheets[0]['cellsInfo'][$key][14]['raw'];
	$v['terminalType'] = $value['24'];
	$v['order_num'] = $value['26'];
	$v['user_num'] = substr($v['order_num'],-6);
	$v['status'] = $value['9'];
	$v['from'] = $value['10'];

	if($_G['charset'] !== 'utf-8'){
		$v['auctionTitle'] = diconv($v['auctionTitle'], 'utf-8', CHARSET);
		$v['exShopTitle'] = diconv($v['exShopTitle'], 'utf-8', CHARSET);
		$v['terminalType'] = diconv($v['terminalType'], 'utf-8', CHARSET);
		$v['status'] = diconv($v['status'], 'utf-8', CHARSET);
		$v['from'] = diconv($v['from'], 'utf-8', CHARSET);
	}

	if($v['status'] == lang('plugin/zhuzhu_taobao', 'order_pay')){
		$v['status'] = '2';
	}elseif($v['status'] == lang('plugin/zhuzhu_taobao', 'order_end')){
		$v['status'] = '4';
	}else{
		$v['status'] = '1';
	}

	if (!in_array($v['order_num'], $order)){
		C::t('#zhuzhu_taobao#zhuzhu_taobao_tbkorder')->insert($v, true);
		$k = $k+1;
	}
	$list[] = $v;
}

$updata_tips = lang('plugin/zhuzhu_taobao', 'updata_succeed').$k.lang('plugin/zhuzhu_taobao', 'updata_succeed_1');

showmessage($updata_tips, 'plugin.php?id=zhuzhu_taobao');

?>