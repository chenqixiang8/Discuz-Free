<?php

/**
 *      Copyright 2001-2099 DisM!Ӧ������.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: taobao_index.php 10455 2017-06-28 02:03:20Z DisM.Taobao.Com $
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once libfile('function/home');


$itemid = $_GET['num_iid'];
$c = new TopClient;
$c->appkey = $appkey;
$c->secretKey = $secret;

$req = new TbkItemInfoGetRequest;
$req->setPlatform("1");
$req->setNumIids("".$itemid."");
$resp = $c->execute($req);
$resp =json_decode(json_encode($resp), true);
$detail = $resp['results']['n_tbk_item'];
if(!$detail && !$_G['mobile']) {
	header('Location:http://g.click.taobao.com/q?pid='.$var['adzoneid'].'&ct=url%3Dhttp%253A%252F%252Fitem.taobao.com%252Fitem.htm%253Fid%253D'.$itemid);
}

$req = new TbkItemRecommendGetRequest;
$req->setFields("num_iid,title,pict_url,small_images,reserve_price,zk_final_price,user_type,volume,provcity,item_url");
$req->setNumIid("".$itemid."");
$req->setCount("20");
$req->setPlatform("1");
$resp = $c->execute($req);
$resp =json_decode(json_encode($resp), true);
$other = $resp['results']['n_tbk_item'];


$req = new TbkCouponGetRequest;
$req->setItemId("".$itemid."");
$req->setActivityId("".$_GET['coupon_id']."");
$resp = $c->execute($req);
$resp =json_decode(json_encode($resp), true);

$quan = $resp['data'];

if($_G['charset'] !== 'utf-8'){
	$other = auto_charset($other);
	$detail = auto_charset($detail);
}

$detail = $detail['0'];

$metakeywords = '';
$navtitle = $metadescription = $detail['title'].' - '.lang('plugin/zhuzhu_taobao', 'lijian').$quan['coupon_amount'].lang('plugin/zhuzhu_taobao', 'j_2').($detail['zk_final_price']-$quan['coupon_amount']).lang('plugin/zhuzhu_taobao', 'j_3').$detail['volume'].lang('plugin/zhuzhu_taobao', 'j_1');

include template('zhuzhu_taobao:jump_url');

?>