<?php

/**
 *      Copyright 2001-2099 DisM!Ӧ������.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: taobao_index.php 10455 2017-06-28 02:03:20Z DisM.Taobao.Com $
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if($_GET['op'] == 'del_history'){
	dsetcookie("sch_history", '', -1);
	return '111111';
}

$sch_history = getcookie('sch_history');

if($_G['mobile']) {
	$sch_history = diconv($sch_history, 'utf-8', CHARSET);
}

$sch_history_list = explode('|', $sch_history);
$sch_history_list = array_unique($sch_history_list);
foreach($sch_history_list as $key=>$v){
	if($v){
		$sch_list[] = $v;
	}
}
include template('zhuzhu_taobao:t_search');
?>