<?php

/**
 *      Copyright 2001-2099 DisM!Ӧ������.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: taobao_index.php 10455 2017-06-28 02:03:20Z DisM.Taobao.Com $
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once libfile('function/home');
@include_once DISCUZ_ROOT.'./data/sysdata/cache_zhuzhu_taobao_category.php';
$_G['cache']['zhuzhu_taobao_category'] = $zhuzhu_taobao_category;

$keyword = $_GET['keyword'] ? $_GET['keyword'] : $var['q_key'];
if($_GET['category_id']){
	$keyword = $zhuzhu_taobao_category[$_GET['category_id']]['keyword'];
}
$category   = CateForChild($_G['cache']['zhuzhu_taobao_category']);
$category_f = getFatherId($_G['cache']['zhuzhu_taobao_category'], $_GET['category_id']);
foreach($category_f as $value) {
	$f_category_id[] = $value['category_id'];
}

$perpage = $_G['mobile'] ? '20' : '20';
$page = max(1, intval($_GET['page']));

$theurl = 'plugin.php?id=zhuzhu_taobao&mod=quan&keyword='.$keyword;

if($_G['mobile'] && $_GET['keyword']) {
	dsetcookie("sch_history", $_G['cookie']['sch_history'].'|'.$keyword);
}

if($_GET['k_id']) {
	$keyword = $hotkeys[$_GET['k_id']];
	$keyword = diconv(urlencode($keyword), CHARSET, 'utf-8');
}

if($_GET['sou'] && $_G['charset'] == 'gbk') {
	$keyword = diconv(urlencode($keyword), CHARSET, 'utf-8');
}

$list = Get_Coupon($perpage, $page, $keyword, $appkey, $secret, $appadzoneid, $tao_cat);

$seo = $zz_seo['quan'];
$navtitle = $seo['seotitle'];
$metakeywords = $seo['seokeywords'];
$metadescription = $seo['seodescription'];

$foot_key = explode(',', $indexseoset['seokeywords']);

if($_G['mobile']){
	include template('zhuzhu_taobao:t_quan');
}else{
	include template('diy:t_quan', '0', 'source/plugin/zhuzhu_taobao/template');
}

function CateForChild($cate, $upid = 0, $pk = 'category_id') {
	$arr = array();
	foreach($cate as $v) {
		if($v['upid'] == $upid) {
			$v['child'] = CateForChild($cate, $v[$pk], $pk);
			$arr[$v[$pk]] = $v;
		}
	}
	return $arr;
}

function getFatherId($cate, $upid, $pk = 'category_id') {
	$arr = array();
	foreach($cate as $v) {
		if($v[$pk] == $upid) {
			$arr[$v[$pk]] = $v;
			$arr = array_merge(getFatherId($cate, $v['upid'], $pk), $arr);
		}
	}
	return $arr;
}
//From: Dism_taobao-com
?>