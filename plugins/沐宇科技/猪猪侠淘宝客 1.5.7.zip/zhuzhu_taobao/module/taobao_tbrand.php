<?php

/**
 *      Copyright 2001-2099 DisM!Ӧ������.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: taobao_index.php 10455 2017-06-28 02:03:20Z DisM.Taobao.Com $
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once libfile('function/home');

$brand_id = intval($_GET['brand_id']);

$theurl = 'plugin.php?id=zhuzhu_taobao&mod=tbrand';
if($_GET['op'] == 'view'){

	$perpage = $_G['mobile'] ? '20' : '20';
	$page = max(1, intval($_GET['page']));
	$brand = C::t('#zhuzhu_taobao#zhuzhu_taobao_brand')->fetch_all($brand_id);
	$keyword = diconv($brand[$brand_id]['keyword'], CHARSET, 'utf-8');
	$list = Get_Coupon($perpage, $page, $keyword, $appkey, $secret, $appadzoneid, $tao_cat);

}else{
	$param = '';
	$perpage = $_G['mobile'] ? '10' : '20';
	$page = max(1, intval($_GET['page']));

	$brand = C::t('#zhuzhu_taobao#zhuzhu_taobao_brand')->fetch_all_by_displayorder($param, $start, $perpage, '', '');
	$count = C::t('#zhuzhu_taobao#zhuzhu_taobao_brand')->count_by_search($param);
	if($count) {
		foreach($brand as $value){
			$value['list'] = Get_Coupon('4', '1', $value['keyword'], $appkey, $secret, $appadzoneid, $tao_cat);
			$brandlist[] = $value;
		}
		$theurl = 'plugin.php?id=zhuzhu_taobao&mod=tbrand&page='.$page;
		$multi = multi($count, $perpage, $page, $theurl);
	}
}

$seo = $zz_seo['brand'];
$navtitle = $seo['seotitle'];
$metakeywords = $seo['seokeywords'];
$metadescription = $seo['seodescription'];
$foot_key = explode(',', $indexseoset['seokeywords']);
list($navtitle, $metadescription, $metakeywords) = get_seosetting($identifier, $mod, $indexseoset);

include template('zhuzhu_taobao:t_brand');

?>