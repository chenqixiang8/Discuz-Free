<?php

/**
 *      Copyright 2001-2099 DisM!Ӧ������.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: taobao_my.php 10455 2018-09-30 02:03:20Z DisM.Taobao.Com $
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(empty($_G['uid'])) {
	showmessage('to_login', '', array(), array('showmsg' => true, 'login' => 1));
}

$acs = array('index', 'order', 'setting', 'take', 'ajax');
$ac = !in_array($_GET['ac'], $acs) ? 'index' : $_GET['ac'];

require (DISCUZ_ROOT.'./source/plugin/zhuzhu_taobao/my/my_'.$ac.'.php');

?>