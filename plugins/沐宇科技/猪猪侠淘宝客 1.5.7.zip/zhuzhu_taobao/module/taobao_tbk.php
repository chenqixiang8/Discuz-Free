<?php

/**
 *      Copyright 2001-2099 DisM!Ӧ������.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: taobao_index.php 10455 2017-06-28 02:03:20Z DisM.Taobao.Com $
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once libfile('function/home');

$ac = $_GET['ac'];

if($_GET['is_tmall']) $_GET['is_tmall'] = 'true';
if($_GET['is_overseas']) $_GET['is_overseas'] = 'true';

$perpage = $_G['mobile'] ? '20' : '100';
$page = max(1, intval($_GET['page']));

$_GET['start_price'] = $_GET['start_price'] ? intval($_GET['start_price']) : '';
$_GET['end_price'] = $_GET['end_price'] ? intval($_GET['end_price']) : '';

$get = array(
	'id' => 'zhuzhu_taobao',
	'mod' => 'tbk',
	'cat' => $_GET['cat'],
	'is_tmall' => $_GET['is_tmall'],
	'sort' => $_GET['sort'],
	'is_overseas' => $_GET['is_overseas'],
	'sort' => $_GET['sort'],
	'ac' => $_GET['ac'],
	'start_price' => $_GET['start_price'],
	'end_price' => $_GET['end_price'],
);

$c = new TopClient;
$c->appkey = $appkey;
$c->secretKey = $secret;

$req = new TbkDgMaterialOptionalRequest;
$req->setAdzoneId($appadzoneid);
$req->setPageSize(''.$perpage.'');
$req->setPageNo(''.$page.'');
$req->setHasCoupon("true");
$req->setCat(''.$tao_cat.'');
$req->setSort("".$_GET['sort']."");
$req->setIsTmall($_GET['is_tmall']);
$req->setIsOverseas($_GET['is_overseas']);
if($_GET['ac'] == '9k9'){
	$req->setStartPrice('9');
	$req->setEndPrice('10');
}elseif($_GET['ac'] == '39k9'){
	$req->setStartPrice("39");
	$req->setEndPrice("40");
}else{
	if($_GET['start_price'] || $_GET['end_price']){
		$req->setStartPrice("".$_GET['start_price']."");
		$req->setEndPrice("".$_GET['end_price']."");
	}elseif($var['StartPrice'] && $var['EndPrice']){
		$req->setStartPrice("".$var['StartPrice']."");
		$req->setEndPrice("".$var['EndPrice']."");
	}
}
$resp = $c->execute($req);
$resp = json_decode(json_encode($resp),true);
$count = $resp['total_results'];
$resp = $resp['result_list']['map_data'];


if($count) {
	foreach($resp as $key=>$v){
		$v['small_images'] = $v['small_images']['string'];
		if($_G['charset'] !== 'utf-8'){
			$v['coupon_info'] = diconv($v['coupon_info'], 'utf-8', CHARSET);
			$v['category_name'] = diconv($v['category_name'], 'utf-8', CHARSET);
			$v['level_one_category_name'] = diconv($v['level_one_category_name'], 'utf-8', CHARSET);
			$v['provcity'] = diconv($v['provcity'], 'utf-8', CHARSET);
			$v['shop_title'] = diconv($v['shop_title'], 'utf-8', CHARSET);
			$v['title'] = diconv($v['title'], 'utf-8', CHARSET);
		}
		$v['e'] = str_replace("//uland.taobao.com/coupon/edetail?e=","", $v['coupon_share_url']);
		$v['e'] = explode('&&', $v['e']);
		$v['e'] = $v['e'][0];
		$list[] = $v;
	}
}

$c = new TopClient;
$c->appkey = $appkey;
$c->secretKey = $secret;
$req = new TbkItemGetRequest;
$req->setFields("num_iid,title,pict_url,small_images,reserve_price,zk_final_price,user_type,provcity,item_url,seller_id,volume,nick");
$req->setQ("".$keyword."");
$req->setCat("".$cat."");
$req->setItemloc("");

$req->setPlatform("1");
$req->setPageNo("".$page."");
$req->setPageSize("".$perpage."");
$resp = $c->execute($req);

$resp = json_decode(json_encode($resp),true);

$count = $resp['total_results'];
$resp = $resp['results']['n_tbk_item'];

$theurl = 'plugin.php?'.url_implode($get);
$url = "plugin.php?id=zhuzhu_taobao&mod=tbk";

$seo = $zz_seo['tbk'];
$navtitle = $seo['seotitle'];
$metakeywords = $seo['seokeywords'];
$metadescription = $seo['seodescription'];

$foot_key = explode(',', $indexseoset['seokeywords']);

include template('zhuzhu_taobao:t_tbk');

function page_url($gets) {
	$arr = array();
	foreach ($gets as $key => $value) {
		if($value) {
			$arr[] = $key.'='.urlencode($value);
		}
	}
	return implode('&', $arr);
}
//d'.'i'.'sm.ta'.'o'.'bao.com
?>