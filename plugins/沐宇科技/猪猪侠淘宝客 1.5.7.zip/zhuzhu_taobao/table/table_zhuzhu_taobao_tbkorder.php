<?php

/**
 *      Copyright 2001-2099 DisM!Ӧ������.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: zhuzhu_taobao_tbkorder.php 33234 2018-09-30 18:29:30Z DISM.TAOBAO.COM $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_zhuzhu_taobao_tbkorder extends discuz_table {

	public function __construct() {
		$this->_table = 'zhuzhu_taobao_tbkorder';
		$this->_pk    = 'order_id';

		parent::__construct(); /*dism��taobao��com*/
	}

	public function count_by_search($param) {
		return DB::result_first('SELECT COUNT(*) FROM %t %i', array($this->_table, $this->wheresql($param)));
	}

	public function fetch_all_by_search($param, $start = 0, $limit = 0, $order = 'order_num', $sort = 'DESC') {
		$ordersql =  $order ? ' ORDER BY '.DB::order($order, $sort) : '';
		return DB::fetch_all('SELECT * FROM %t %i %i '.DB::limit($start, $limit), array($this->_table, $this->wheresql($param), $ordersql));
	}

	public function fetch_by_order_num($order_num) {
		return DB::fetch_all('SELECT * FROM %t WHERE '.DB::field('order_num', $order_num), array($this->_table));
	}

	public function increase($order_id, $setarr) {
		$sql = array();
		$allowkey = array('num_iid', 'etxcredit', 'status');
		foreach($setarr as $key => $value) {
			if(($value = intval($value)) && in_array($key, $allowkey)) {
				$sql[] = "`$key`=`$key`+'$value'";
			}
		}
		$wheresql = DB::field('order_id', $order_id);
		if(!empty($sql)){
			return DB::query('UPDATE %t SET %i WHERE %i', array($this->_table, implode(',', $sql), $wheresql));
		}
	}

	public function wheresql($param) {
		foreach($param as $value) {
			if($value[1]) {
				$wherearr[] = DB::field($value[0], is_array($value[1]) ? $value[1] : $value[3].$value[1].$value[4], $value[2] ? $value[2] : '=');
			}
		}
		$wheresql = $wherearr ? 'WHERE '.implode(' AND ', $wherearr) : '';
		return $wheresql;
	}
}
//From: Dism_taobao-com
?>