<?php

/**
 *      Copyright 2001-2099 DisM!Ӧ������.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: zhuzhu_taobao_user.php 33234 2018-09-30 18:29:30Z DISM.TAOBAO.COM $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_zhuzhu_taobao_user extends discuz_table {

	public function __construct() {
		$this->_table = 'zhuzhu_taobao_user';
		$this->_pk    = 'order_id';

		parent::__construct(); /*dism��taobao��com*/
	}

	public function count_by_search($param) {
		return DB::result_first('SELECT COUNT(*) FROM %t %i', array($this->_table, $this->wheresql($param)));
	}

	public function fetch_all_by_search($param, $start = 0, $limit = 0, $order = 'order_id', $sort = 'DESC') {
		$ordersql =  $order ? ' ORDER BY '.DB::order($order, $sort) : '';
		return DB::fetch_all('SELECT * FROM %t %i %i '.DB::limit($start, $limit), array($this->_table, $this->wheresql($param), $ordersql));
	}

	public function fetch_by_num($user_num) {
		return DB::fetch_all('SELECT * FROM %t WHERE '.DB::field('user_num', $user_num), array($this->_table));
	}

	public function fetch_by_user($uid) {
		return DB::fetch_all('SELECT * FROM %t WHERE '.DB::field('uid', $uid), array($this->_table));
	}

	public function wheresql($param) {
		foreach($param as $value) {
			if($value[1]) {
				$wherearr[] = DB::field($value[0], is_array($value[1]) ? $value[1] : $value[3].$value[1].$value[4], $value[2] ? $value[2] : '=');
			}
		}
		$wheresql = $wherearr ? 'WHERE '.implode(' AND ', $wherearr) : '';
		return $wheresql;
	}
}
//From: Dism_taobao-com
?>