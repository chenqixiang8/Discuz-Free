<?php

/**
 *      Copyright 2001-2099 DisM!Ӧ������.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: upgrade.php 37712 2018-03-09 22:28:39Z DisM.Taobao.Com $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$sql['1.5'] = <<<EOF
ALTER TABLE `pre_zhuzhu_taobao_tbkorder` ADD COLUMN `item_id` bigint(11) NOT NULL DEFAULT '' AFTER `uid`;
EOF;

foreach($sql as $key => $value) {
	if($_GET['fromversion'] < $key) runquery($value);
}

$finish = true;