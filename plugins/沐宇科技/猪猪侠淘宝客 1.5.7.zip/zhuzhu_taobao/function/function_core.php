<?php

/**
 *      Copyright 2001-2099 DisM!Ӧ������.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: function_core.php 37712 2018-03-15 08:30:42Z DisM.Taobao.Com $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


function auto_charset($fContents, $to='gbk', $from='utf-8') {
	$from = strtoupper($from) == 'UTF8' ? 'utf-8' : $from;
	$to = strtoupper($to) == 'UTF8' ? 'utf-8' : $to;
	if(strtoupper($from) === strtoupper($to) || empty($fContents) || (is_scalar($fContents) && !is_string($fContents))) {
		return $fContents;
	}
	if(is_string($fContents)) {
		if (function_exists('mb_convert_encoding')) {
			return mb_convert_encoding($fContents, $to, $from);
		}elseif(function_exists('iconv')) {
			return iconv($from, $to, $fContents);
		}else{
			return $fContents;
		}
	}elseif(is_array($fContents)) {
		foreach ($fContents as $key => $val) {
			$_key = auto_charset($key, $from, $to);
			$fContents[$_key] = auto_charset($val, $from, $to);
			if ($key != $_key) unset($fContents[$key]);
		}
		return $fContents;
	}else{
		return $fContents;
	}
}

function auto_charset_u($fContents, $from='gbk', $to='utf-8') {
	$from = strtoupper($from) == 'UTF8' ? 'utf-8' : $from;
	$to = strtoupper($to) == 'UTF8' ? 'utf-8' : $to;
	if(strtoupper($from) === strtoupper($to) || empty($fContents) || (is_scalar($fContents) && !is_string($fContents))) {
		return $fContents;
	}
	if(is_string($fContents)) {
		if (function_exists('mb_convert_encoding')) {
			return mb_convert_encoding($fContents, $to, $from);
		}elseif(function_exists('iconv')) {
			return iconv($from, $to, $fContents);
		}else{
			return $fContents;
		}
	}elseif(is_array($fContents)) {
		foreach ($fContents as $key => $val) {
			$_key = auto_charset($key, $from, $to);
			$fContents[$_key] = auto_charset($val, $from, $to);
			if ($key != $_key) unset($fContents[$key]);
		}
		return $fContents;
	}else{
		return $fContents;
	}
}

function autowrap($fontsize, $angle, $fontface, $string, $width) {
	$content = "";
	preg_match_all("/./u", $string, $arr);
	$letter = $arr[0];
	foreach ($letter as $l) {
		$teststr = $content." ".$l;
		$testbox = imagettfbbox($fontsize, $angle, $fontface, $teststr);
		if (($testbox[2] > $width) && ($content !== "")) {
			$content .= PHP_EOL;
		}
		$content .= $l;
	}
	return $content;
}

function Get_Coupon($pagesize = '', $pageno = '', $keyword = '', $appkey, $secret, $appadzoneid, $tao_cat) {
	if(CHARSET !== 'utf-8' && empty($_GET['k_id']) && empty($_GET['brand_id'])){
		$keyword = diconv($keyword, CHARSET, 'utf-8');
	}

	$list = [];
	$c = new TopClient;
	$c->appkey = $appkey;
	$c->secretKey = $secret;

	$req = new TbkDgMaterialOptionalRequest;
	$req->setAdzoneId($appadzoneid);
	$req->setPageSize(''.$pagesize.'');
	$req->setPageNo(''.$pageno.'');
	$req->setHasCoupon("true");
	$req->setSort("total_sales_des");
	if($keyword){
		$req->setQ(''.$keyword.'');
	}else{
		$req->setCat(''.$tao_cat.'');
	}
	$resp = $c->execute($req);

	$resp = json_decode(json_encode($resp),true);
	$count = $resp['total_results'];
	$resp = $resp['result_list']['map_data'];
	if($count) {
		foreach($resp as $key=>$v){
			$v['small_images'] = $v['small_images']['string'];
			if(CHARSET !== 'utf-8'){
				$v['coupon_info'] = diconv($v['coupon_info'], 'utf-8', CHARSET);
				$v['category_name'] = diconv($v['category_name'], 'utf-8', CHARSET);
				$v['level_one_category_name'] = diconv($v['level_one_category_name'], 'utf-8', CHARSET);
				$v['provcity'] = diconv($v['provcity'], 'utf-8', CHARSET);
				$v['shop_title'] = diconv($v['shop_title'], 'utf-8', CHARSET);
				$v['title'] = diconv($v['title'], 'utf-8', CHARSET);
			}
			$v['e'] = str_replace("//uland.taobao.com/coupon/edetail?e=","", $v['coupon_share_url']);
			$v['e'] = explode('&&', $v['e']);
			$v['e'] = $v['e'][0];
			$list[] = $v;
		}
	}
	return $list;
}