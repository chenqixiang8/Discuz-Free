<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ') || !defined('IN_EXTAVATAR_API')) {
    exit('Access Denied');
}
authLogin();
function _getAvatarById($id) {
	$item = C::t('#extavatar#extavatar')->getById($id);
	if (empty($item)) throw new Exception('The avatar is deleted');
	return $item;
}
function queryAction() { return C::t('#extavatar#extavatar')->query(); }
function uploadAction() 
{
	global $_G;
	$id = extavatar_validate::getNCParameter('id','id','integer');
	$fileid = extavatar_validate::getNCParameter('fileElementId','fileElementId','string');
	$upfile = extavatar_validate::getNCParameter($fileid,$fileid,'file',50000000);
	if ($id==0) {
		$rd = array (
			'uid' => $_G['uid'],
			'ctime' => date('Y-m-d H:i:s'),
			'isdel' => 1,
		);
		$id = C::t('#extavatar#extavatar')->insert($rd, true);
		if ($id==0) {
			throw new Exception("upload fail");
		}
	}
	$filesys = C::m('#extavatar#extavatar')->getPrepareFile($id);
	$storefile = $filesys['avatarPath'].$filesys['imgBig'];
	move_uploaded_file($upfile['tmp_name'],$storefile);
	extavatar_utils::resizeImg($storefile,$filesys['avatarPath'].$filesys['imgBig'],200);
	extavatar_utils::resizeImg($storefile,$filesys['avatarPath'].$filesys['imgMiddle'],120);
	extavatar_utils::resizeImg($storefile,$filesys['avatarPath'].$filesys['imgSmall'],48);
	$rd = array (
		'imgurl_big' => $filesys['imgBig'],
		'imgurl_middle' => $filesys['imgMiddle'],
		'imgurl_small' => $filesys['imgSmall'],
		'isdel' => 0,
	);
	C::t('#extavatar#extavatar')->update($id,$rd);
	return $filesys;
}
function removeAvatarAction()
{
	global $_G;
	$id = extavatar_validate::getNCParameter('id','id','integer');
	$item = _getAvatarById($id);
	if ($item['uid']!=$_G['uid']) {
	}
	$res = C::t('#extavatar#extavatar')->update($id,array('isdel'=>1));
	$files = array(
		DISCUZ_ROOT."/".$item['imgurl_big'],
		DISCUZ_ROOT."/".$item['imgurl_middle'],
		DISCUZ_ROOT."/".$item['imgurl_small']
	);
	foreach ($files as $file) {
		if (is_file($file)) { 
			unlink($file);
		}
	}
	return $res;
}
function setEnableAction() {
	global $_G;
	$id = extavatar_validate::getNCParameter('id','id','integer');
	$enable = extavatar_validate::getNCParameter('enabled','enabled','integer');
	$res = C::t('#extavatar#extavatar')->update($id,array('enable'=>$enable));
}
//From: Dism��taobao��com
?>