define(function(require){
	var ajax=require("ajax");
    var dict=require("./dict");
	var store,grid,isie=inIE();
    var o={};
    o.init = function(){
		store = new window.mwt.Store({
            proxy: new window.mwt.HttpProxy({
                url: ajax.getAjaxUrl("query")
            })
        });
		grid = new window.MWT.Grid({
            render      : 'grid-div',
            store       : store,
            pagebar     : true,
            pageSize    : 20,
            multiSelect : false, 
            bordered    : false,
			position    : 'fixed',
            striped     : true,     //!< 斑马纹
			bodyStyle   : '',
			tbarStyle   : 'margin-bottom:10px;',
			tbar: [
				{label:"状态",id:"enable-sel",type:'select',value:'-1',
                 options:dict.get_enable_options({text:'不限',value:'-1'}),
                 handler:o.query},
				{type:'search',id:'so-key',width:300,handler:o.query,placeholder:'查询头像编号或上传用户'},
				'->',
				{label:'<i class="sicon-plus"></i> 添加头像',cls:'mwt-btn-success',
				 handler:function(){
					//require('./dialog').open({id:0},o.query);
					require('./imgupload').upload(0,function(res){
						if (res.retcode!=0) mwt.alert(res.retmsg);
						else {
							mwt.notify('添加成功',1500,'success');
							grid.load();
						}
					});
				}}
			],
            cm: new MWT.Grid.ColumnModel([
              {head:'编号',dataIndex:"id",align:'left',width:80,sort:true,render:function(v,item){
				return '#'+v;
			  }},
              {head:"大图",dataIndex:"imgurl_big",width:120,align:'left',render:function(v,item){
				return '<img src="'+v+'" class="mwt-image-view" style="width:80px;">';
			  }},
              {head:"中图",dataIndex:"imgurl_middle",width:100,align:'left',render:function(v,item){
				return '<img src="'+v+'" class="mwt-image-view" style="width:60px;">';
			  }},
              {head:"小图",dataIndex:"imgurl_small",width:80,align:'left',render:function(v,item){
				return '<img src="'+v+'" class="mwt-image-view" style="width:40px;">';
			  }},
              {head:"启用状态",dataIndex:"enable",hide:isie,width:80,align:'left',render:function(v,item){
				if (item.uid==0) return '启用';
				var checked = (v==1) ? 'checked' : ''; 
				var code = '<label class="mwt-cbx-switch-plain" style="width:40px;height:18px;">'+
                        '<input name="adenable" type="checkbox" data-id="'+item.id+'" '+checked+'>'+
                    '<span><i></i></span></label>';
                    return code;
			  }},
              {head:'上传时间',dataIndex:"mtime",align:'left',width:120,sort:true,render:mwt.GridRender.datetime},
              {head:"上传用户",   dataIndex:"username", width:120,sort:true,render:function(v,item){
				if (item.uid==0) return '<span style="color:#999">system</span>';
				return v;
			  }},
              {head:'',dataIndex:"id",align:'left',hide:isie,render:function(id,item){
				var btncls = 'mwt-btn mwt-btn-default mwt-btn-xs';
                var setbtn = '<a name="setbtn" class="'+btncls+'" data-id="'+id+'" href="javascript:;">更新头像</a>';
                var delbtn = '<a name="delbtn" class="'+btncls+'" data-id="'+id+'" href="javascript:;">删除</a>';
                var btns = [setbtn,delbtn];
				if (v.uid!=item.uid) btns=[setbtn];
                return btns.join("&nbsp;&nbsp;");
              }}
            ])
        });
        grid.create();
		store.on('load',function(){
			mwt.initImageView();
			// 启用开关
			jQuery('[name=adenable]').unbind('change').change(function(){
                var id = jQuery(this).data('id');
                var enable = jQuery(this).is(':checked') ? 1 : 0;
                ajax.post('setEnable',{id:id,enabled:enable},function(res){
                    if (res.retcode!=0) mwt.notify(res.retmsg,1500,'danger');
                    mwt.notify('已保存',1500,'success');
                });
            });
			// 删除按钮
			jQuery('[name=delbtn]').unbind('click').click(function(){
				var id = jQuery(this).data('id');
				mwt.confirm('确定要删除吗?',function(res){
					if (res) {
						ajax.post('removeAvatar',{id:id},function(res){
							if (res.retcode!=0) mwt.alert(res.retmsg);
							else grid.load();
						});
					}
				});
			});
			// 编辑按钮
            jQuery('[name=setbtn]').unbind('click').click(function(){
				var id = jQuery(this).data('id');
				require('./imgupload').upload(id,function(res){
					if (res.retcode!=0) mwt.alert(res.retmsg);
					else {
						mwt.notify('头像更新成功，由于浏览器会缓存图片文件，你可能需要清除缓存才能看到更新的头像',1500,'success');
						grid.load();
					}
				});
			});

		});

		if (isie) {
			var msg = "请使用Chrome或Firefox浏览器打开此页面";
			jQuery('#tbar-grid-div').hide();
			jQuery('#msg-div').html(msg);
		}		

		o.query();
    };

	o.query=function() {
		store.baseParams = {
            enable : mwt.get_select_value("enable-sel"),
            key  : mwt.get_value("so-key")
        };
        grid.load();
	};

    return o;
});
