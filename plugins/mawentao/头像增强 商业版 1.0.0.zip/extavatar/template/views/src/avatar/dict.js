define(function(require){
    var o={};
    var enable_dict = {
        '0': '禁用',
        '1': '启用'
    };
   
    o.get_enable=function(id) {
        return enable_dict[id] ? enable_dict[id] : id;
    };

    o.get_enable_options=function(firstoption) {
        return tooptions(enable_dict,firstoption);
    };

	// dict转成options
	function tooptions(dictionary,firstoption) {
		var options = [];
		if (firstoption) options.push(firstoption);
		for(var id in dictionary) {
			options.push({text:dictionary[id],value:id});
		}
		return options;
	}
    return o;
});
