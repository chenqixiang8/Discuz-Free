<?php
define("IN_EXTAVATAR_API", 1);
define("EXTAVATAR_PLUGIN_PATH", dirname(__FILE__));
chdir("../../../");
require './source/class/class_core.php';
$discuz = C::app();
$discuz->init();
require_once EXTAVATAR_PLUGIN_PATH."/class/env.class.php";
$module = isset($_GET['module']) ? $_GET['module'] : ''; 
$action = isset($_GET['action']) ? $_GET['action'] : ''; 
$retcode = 0;
try {
    $modules = array('admin');
    if(!in_array($_GET['module'], $modules)) {
        throw new Exception("module not found[$module]");
    }
	$apifile = EXTAVATAR_PLUGIN_PATH."/api/$module.php";
	if(file_exists($apifile)) {
		require_once $apifile;
		$actionFun = $action."Action";
		if (!function_exists($actionFun)) {
			throw new Exception("unkown action[$action] in api module[$module]");
		}   
		$res = $actionFun();
		apiOutput(array("data"=>$res));
		exit(0);
	}
    throw new Exception("module not found[$module]");
} catch (Exception $e) {
	if ($retcode==0) $retcode = 1001;
    apiOutput(array('retcode'=>$retcode,'retmsg'=>$e->getMessage()));
}
function authLogin()
{
    global $_G,$retcode;
    if ($_G['uid']==0) {
        $retcode = 1002;
        throw new Exception("please login");
    }
}
function authUsergroup(array $groupids)
{
    global $_G,$retcode;
    $groupid = $_G["groupid"];
    if (!empty($groupids) && !in_array($groupid,$groupids)) {
        $retcode = 1003;
        throw new Exception('illegal request');
    }
}
function apiOutput(array $result, $json_header=true)
{
    if (!isset($result['retcode'])) {
        $result['retcode'] = 0;
    }
    if (!isset($result['retmsg'])) {
        $result['retmsg'] = 'succ';
    }
    if ($json_header) {
        header("Content-type: application/json");
    }
    echo json_encode($result);
    exit;
}
//From: Dism��taobao��com
?>