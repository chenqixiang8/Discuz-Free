<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
class extavatar_validate
{
    public static function post_decode($value) 
    {   
        $value = htmlspecialchars_decode($value);
        $value = preg_replace("/&apos;/i", "'", $value);
        $value = preg_replace("/&lk;/i", "(", $value);
        $value = preg_replace("/&gk;/i", ")", $value);
        return $value;
    }
	public static function getNCParameter($key, $name, $valueType='string', $maxlen=1024)
	{
		if (!isset($_REQUEST[$key]) && !isset($_FILES[$key])) {
			$msg = $key." is not set.";
			throw new Exception($msg);
			return null;
		}
        if (isset($_REQUEST[$key])) {
		    $value = trim($_REQUEST[$key]);
            $value = self::post_decode($value); 
		    $_REQUEST[$key] = $value;
        }
		$res = true;
		switch($valueType) {
			case "string"  : $res = self::checkString($value, $maxlen); break;
			case "number"  : $res = self::checkNumber($value); break;
			case "integer" : $res = self::checkInteger($value); break;
			case "url"     : $res = self::checkUrl($key, $maxlen); break;
			case "email"   : $res = self::checkEmail($key); break;
            case "file"    : return self::checkUploadFile($key,$maxlen); break;
			default:
				if (preg_match($valueType, $value)) {
					$res = true;
				} else {
					$res = "is illegal";
				}
				break;
		}
		if ($res !== true) {
			$msg = $name.$res;
			throw new Exception($msg);
		}
        return $_REQUEST[$key];
	}
	public static function getOPParameter($key, $name, $valueType='string', $maxlen=1024, $dafaultValue="")
	{
		if (!isset($_REQUEST[$key]) || $_REQUEST[$key]==="") {
			$_REQUEST[$key] = $dafaultValue;
			return $dafaultValue;
		}
		return self::getNCParameter($key, $name, $valueType, $maxlen);
	}
	private static function checkString($str_utf8, $maxlen)
	{
		if (mb_strlen($str_utf8, "UTF-8") > $maxlen) {
			return " length must less than ".$maxlen;
		}
		$illegalCharacters = array('delete', 'null', '||');
		foreach ($illegalCharacters as &$wd) {
			if (stristr($str_utf8, $wd)) {
				return "can not have $wd";
			}
		}
		return true;
	}
	private static function checkNumber($value)
	{
		if (!is_numeric($value)) {
			return " must be numeric";
		}
		return true;
	}
	private static function checkInteger($value)
	{
		$regex = "/^-?\d+$/";
		if (!preg_match($regex, $value)) {
			return " must be integer";			
		}
		return true;
	}
	private static function checkUrl($key, $maxlen)
	{
		$value = trim($_REQUEST[$key]);
		$res = self::checkString($value, $maxlen);
		if ($res !== true) {
			return $res;
		}
		$regex = "/^(https?:\/\/)?(([0-9a-z_!~*'().&=+$%-]+: )?[0-9a-z_!~*'().&=+$%-]+@)?(([0-9]{1,3}\.){3}[0-9]{1,3}|([0-9a-z_!~*'()-]+\.)*([0-9a-z][0-9a-z-]{0,61})?[0-9a-z]\.[a-z]{2,6})(:[0-9]{1,4})?((\/?)|(\/[^\s]+)+\/?)$/i";
		if (!preg_match($regex, $value)) {
			return " must be url";
		}
		$initial = substr($value, 0, 4);
        if (strcmp($initial, "http") != 0) {
            $_REQUEST[$key] = "http://" . $value;
		}
		return true;
	}
	private static function checkEmail($value, $maxlen)
	{
		$regex = "/^\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/";
		if (!preg_match($regex, $value)) {
			return " must be email";
		}
		return true;
	}
    private static function checkUploadFile($fileid,$maxsize)
    {
        $upfile = $_FILES[$fileid];
        if ($upfile["error"]!==0) {
            $err = $upfile["error"];
            $errMap = array(
                '1' => 'the file size is out of the MAX value',
                '2' => 'UPLOAD_ERR_FORM_SIZE',
                '3' => 'UPLOAD_ERR_PARTIAL',
                '4' => 'UPLOAD_ERR_NO_FILE',
                '5' => 'UPLOAD_ERR_NO_TMP_DIR',
                '6' => 'UPLOAD_ERR_NO_TMP_DIR',
            );
            $errMsg = isset($errMap[$err]) ? $errMap[$err] : " upload file fail";
            throw new Exception($errMsg);
        }
        if ($maxsize>0 && $upfile['size'] > $maxsize) {
            throw new Exception(' the filesize should be less than'.self::get_file_size_string($maxsize));
        }
        return $upfile;
    }
    public static function get_file_size_string($size)
    {
        if ($size<1024) return $size." B";
        if ($size<1024*1024) {
            $s = floatval($size) / 1024;
            return number_format($s, 2)." KB";
        }
        if ($size<1024*1024*1024) {
            $s = floatval($size) / (1024*1024);
            return number_format($s, 2)." MB";
        }
        $s = floatval($size) / (1024*1024*1024);
        return number_format($s, 2)." GB";
    }
}
//From: Dism��taobao��com
?>