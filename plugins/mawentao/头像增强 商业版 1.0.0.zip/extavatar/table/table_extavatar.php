<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class table_extavatar extends discuz_table
{
    public function __construct() {
		$this->_table = 'extavatar';
		$this->_pk = 'id';
		parent::__construct();/*dism_taobao_com*/
	}
	public function getById($id) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d AND isdel=0", array($this->_table,$id));
	}
    public function getMaxId() {
        $res = DB::fetch_first("SELECT max(id) as maxid FROM %t", array($this->_table));
        return empty($res) ? 0 : intval($res['maxid']);
    }
    public function getAvatarByUid($uid)
    {
        $maxid = $this->getMaxId();
        $maxv = ($uid % $maxid)+1;
        $sql = <<<EOF
SELECT id, imgurl_small as small, imgurl_middle as middle, imgurl_big as big
FROM %t
WHERE id<=%d AND enable=1 AND isdel=0
ORDER BY id DESC
LIMIT 1;
EOF;
        return DB::fetch_first($sql, array($this->_table, $maxv));
    }
	public function query() {
		$return = array(
            "totalProperty" => 0,
            "root" => array(),
        );  
        $enable= extavatar_validate::getNCParameter('enable','enable','integer');
        $key   = extavatar_validate::getNCParameter('key','key','string',128);
        $sort  = extavatar_validate::getOPParameter('sort','sort','string',1024,'ctime');
        $dir   = extavatar_validate::getOPParameter('dir','dir','string',1024,'DESC');
        $start = extavatar_validate::getOPParameter('start','start','integer',1024,0);
        $limit = extavatar_validate::getOPParameter('limit','limit','integer',1024,20);
        $where = "a.isdel=0";
        if ($enable>=0)  $where.=" AND enable='$enable'";
        if ($key!="") $where.=" AND (a.id like '%$key%' OR username like '%$key%')";
        if ($sort=='uid') $sort='a.'.$sort;
        $table_common_member = DB::table("common_member");
        $table_extavatar = DB::table($this->_table);
        $sql = <<<EOF
SELECT SQL_CALC_FOUND_ROWS
a.*,b.username
FROM $table_extavatar as a LEFT JOIN $table_common_member as b ON a.uid=b.uid
WHERE $where
ORDER BY $sort $dir
LIMIT $start,$limit
EOF;
        $return["root"] = DB::fetch_all($sql);
        $row = DB::fetch_first("SELECT FOUND_ROWS() AS total");
        $return["totalProperty"] = $row["total"];
		$siteurl = extavatar_env::get_siteurl();
        foreach ($return["root"] as &$row) {
			$row['imgurl_small'] = $siteurl.$row['imgurl_small'];
			$row['imgurl_big'] = $siteurl.$row['imgurl_big'];
			$row['imgurl_middle'] = $siteurl.$row['imgurl_middle'];
        }
        return $return;
	}
}
//From: Dism��taobao��com
?>