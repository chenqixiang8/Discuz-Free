<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
require_once dirname(__FILE__).'/class/env.class.php';
try {
    $m_setting = C::m("#extavatar#extavatar_setting");
    $params = $m_setting->get();
    if (isset($_POST["reset"])) {
		if ($_POST['formhash']!=$_G['formhash']) {
			throw new Exception("illegal request");
		}
        if ($_POST["reset"]==1) {
            $params = array();
        } else {
            foreach ($params as $k => &$v) {
                if (isset($_POST[$k])) {
					$v=$_POST[$k];
				}
            }
        }
        C::t('common_setting')->update("extavatar_config",$params);
        updatecache('setting');
        $landurl = 'action=plugins&operation=config&do='.$pluginid.'&identifier=extavatar&pmod=z_setting';
        cpmsg('plugins_edit_succeed', $landurl, 'succeed');
    }
	$params['checkfuncs'] = array();
    $params["errtips"] = array();
	$mustFunctions = array('imagefttext','imagecreatefromjpeg','imagecreatefromgif','imagecreatefrompng');
	foreach ($mustFunctions as $mfunc) {
		$params['checkfuncs'][$mfunc] = function_exists($mfunc) ? 1 : 0;
	}
    $params['ajaxapi'] = extavatar_env::get_plugin_path()."/index.php?version=4&module=";
	$params['formhash'] = $_G['formhash'];
    $tplVars = array(
        'siteurl' => extavatar_env::get_siteurl(),
        'plugin_path' => extavatar_env::get_plugin_path(),
		'formhash' => $_G['formhash'],
    );
    extavatar_utils::loadtpl(dirname(__FILE__).'/template/views/z_setting.tpl', $params, $tplVars);
} catch (Exception $e) {
    cpmsg($e->getMessage(),null,'error');
}