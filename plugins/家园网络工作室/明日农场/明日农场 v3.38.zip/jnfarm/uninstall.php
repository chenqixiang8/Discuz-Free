<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$sql = <<<EOT

DROP TABLE IF EXISTS pre_game_jnfarm_fset;
DROP TABLE IF EXISTS pre_game_jnfarm_item;
DROP TABLE IF EXISTS pre_game_jnfarm_level;
DROP TABLE IF EXISTS pre_game_jnfarm_log;
DROP TABLE IF EXISTS pre_game_jnfarm_user;
DROP TABLE IF EXISTS pre_game_jnfarm_land;
DROP TABLE IF EXISTS pre_game_jnfarm_market;
DROP TABLE IF EXISTS pre_game_jnfarm_achieve;
DROP TABLE IF EXISTS pre_game_jnfarm_cashout;
DROP TABLE IF EXISTS pre_game_jnfarm_combine;
DROP TABLE IF EXISTS pre_game_jnfarm_pet;
DROP TABLE IF EXISTS pre_game_jnfarm_dailyquest;
DROP TABLE IF EXISTS pre_game_jnfarm_realland;
DROP TABLE IF EXISTS pre_game_jnfarm_realland_record;
DROP TABLE IF EXISTS pre_game_jnfarm_invite;
DROP TABLE IF EXISTS pre_game_jnfarm_season_set;
DROP TABLE IF EXISTS pre_game_jnfarm_season;
DROP TABLE IF EXISTS pre_game_jnfarm_rankcache;
DROP TABLE IF EXISTS pre_game_jnfarm_mall;
DROP TABLE IF EXISTS pre_game_jnfarm_guild;
DROP TABLE IF EXISTS pre_game_jnfarm_guild_gxreward;
DROP TABLE IF EXISTS pre_game_jnfarm_guild_item;
DROP TABLE IF EXISTS pre_game_jnfarm_guild_level;
DROP TABLE IF EXISTS pre_game_jnfarm_guild_reward;
DROP TABLE IF EXISTS pre_game_jnfarm_dateline;
DROP TABLE IF EXISTS pre_game_jnfarm_guild_hzgxreward;
DROP TABLE IF EXISTS pre_game_jnfarm_guild_hzreward;
DROP TABLE IF EXISTS pre_game_jnfarm_card;
DROP TABLE IF EXISTS pre_game_jnfarm_card_hzreward;
DROP TABLE IF EXISTS pre_game_jnfarm_card_hzzlreward;
DROP TABLE IF EXISTS pre_game_jnfarm_card_reward;
DROP TABLE IF EXISTS pre_game_jnfarm_card_user;
DROP TABLE IF EXISTS pre_game_jnfarm_card_zlreward;
DROP TABLE IF EXISTS pre_game_jnfarm_card_cat;
DROP TABLE IF EXISTS pre_game_jnfarm_card_draw;
DROP TABLE IF EXISTS pre_game_jnfarm_card_suit;
DROP TABLE IF EXISTS pre_game_jnfarm_card_suitlog;
DROP TABLE IF EXISTS pre_game_jnfarm_card_adv;
DROP TABLE IF EXISTS pre_game_jnfarm_card_advlist;
DROP TABLE IF EXISTS pre_game_jnfarm_card_pkreward_sat;
DROP TABLE IF EXISTS pre_game_jnfarm_card_pkreward_sat_user;
DROP TABLE IF EXISTS pre_game_jnfarm_card_pkreward_tue;
DROP TABLE IF EXISTS pre_game_jnfarm_card_pkreward_tue_user;

EOT;

runquery($sql);

$finish = true;
?>