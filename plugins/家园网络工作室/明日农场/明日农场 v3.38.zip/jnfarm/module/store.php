<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
};
if (!$_G['uid']) showmessage('not_loggedin','',array(), array('login' => true));
if ($reallanddirecton == '1'){
	exit;
}
if($_GET['do'] == 'store'){
	if($_GET['submit'] == 'true' && $_GET['formhash'] == $_G['formhash']){
	if(!discuz_process::islocked('update_jnfarm'.$_G['uid'])) {
		$userinfo = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_user')." WHERE uid = '".$_G['uid']."'");
		$userinfo['udata'] = json_decode($userinfo['udata'],true);
		if($directextcreditson == '1'){
			$userinfo['udata']['data']['money'] = getuserprofile('extcredits'.$jnc['buyext']);
		}
		$cprod = count($userinfo['udata']['prod']);
		$pass = substr(md5(uniqid(mt_rand(), true)) , 0, 8);
		for($c = 1; $c <= $cprod; $c++){
			//����Ƿ��й�ѡ
			if($_GET['prod'][$c] == '1'){
				$prodsellqty = dintval($_GET['prodqty'][$c]);
				$prodsellqty = fushu($prodsellqty);
				if($prodsellqty <= '0'){
					//showmessage('��ѡ��Ʒ��������С�ڵ���0���޷����г���');
					discuz_process::unlock('update_jnfarm'.$_G['uid']);
					$linkgen = lang("plugin/$jn","s039");
					include template($jn.':'.$jn.'_ajax_plain');
					exit;
				}
				if($userinfo['udata']['prod'][$c][1] < $prodsellqty){
					discuz_process::unlock('update_jnfarm'.$_G['uid']);
					$linkgen = $sdlist[$userinfo['udata']['prod'][$c][0]]['stitle'].lang("plugin/$jn","s040",array('prodsellqty'=>$prodsellqty));
					include template($jn.':'.$jn.'_ajax_plain');
					exit;
				}
				$check = '1';
			}
		}
		$cfert = count($userinfo['udata']['fertilize']);
		for($d = 1; $d <= $cfert; $d++){
			if($_GET['fert'][$d] == '1'){
				$prodsellqty = dintval($_GET['fertqty'][$d]);
				$prodsellqty = fushu($prodsellqty);
				if($prodsellqty <= '0'){
					discuz_process::unlock('update_jnfarm'.$_G['uid']);
					$linkgen = lang("plugin/$jn","s039");
					include template($jn.':'.$jn.'_ajax_plain');
					exit;
				}
				if($userinfo['udata']['fertilize'][$d][1] < $prodsellqty){
					discuz_process::unlock('update_jnfarm'.$_G['uid']);
					$linkgen = $felist[$userinfo['udata']['fertilize'][$d][0]]['stitle'].lang("plugin/$jn","s040",array('prodsellqty'=>$prodsellqty));
					include template($jn.':'.$jn.'_ajax_plain');
					exit;
				}
				$check = '1';
			}
		}
		$cseed = count($userinfo['udata']['seed']);
		for($e = 1; $e <= $cseed; $e++){
			//����Ƿ��й�ѡ
			if($_GET['seed'][$e] == '1'){
				$prodsellqty = dintval($_GET['seedqty'][$e]);
				$prodsellqty = fushu($prodsellqty);
				if($prodsellqty <= '0'){
					discuz_process::unlock('update_jnfarm'.$_G['uid']);
					$linkgen = lang("plugin/$jn","s039");
					include template($jn.':'.$jn.'_ajax_plain');
					exit;
				}
				if($userinfo['udata']['seed'][$e][1] < $prodsellqty){
					discuz_process::unlock('update_jnfarm'.$_G['uid']);
					$linkgen = $sdlist[$userinfo['udata']['seed'][$e][0]]['stitle'].lang("plugin/$jn","s038").lang("plugin/$jn","s040",array('prodsellqty'=>$prodsellqty));
					include template($jn.':'.$jn.'_ajax_plain');
					exit;
				}
				$check = '1';
			}
		}
		$cnitem = count($userinfo['udata']['nitem']);
		for($f = 1; $f <= $cnitem; $f++){
			//����Ƿ��й�ѡ
			if($_GET['nitem'][$f] == '1'){
				$prodsellqty = dintval($_GET['nitemqty'][$f]);
				$prodsellqty = fushu($prodsellqty);
				if($prodsellqty <= '0'){
					discuz_process::unlock('update_jnfarm'.$_G['uid']);
					$linkgen = lang("plugin/$jn","s039");
					include template($jn.':'.$jn.'_ajax_plain');
					exit;
				}
				if($userinfo['udata']['nitem'][$f][1] < $prodsellqty){
					discuz_process::unlock('update_jnfarm'.$_G['uid']);
					$linkgen = $sdlist[$userinfo['udata']['nitem'][$f][0]]['stitle'].lang("plugin/$jn","s038").lang("plugin/$jn","s040",array('prodsellqty'=>$prodsellqty));
					include template($jn.':'.$jn.'_ajax_plain');
					exit;
				}
				$check = '1';
			}
		}
		if($tiliitemon == '1'){
			$ctiliitem = count($userinfo['udata']['tiliitem']);
			for($f = 1; $f <= $ctiliitem; $f++){
				//����Ƿ��й�ѡ
				if($_GET['tiliitem'][$f] == '1'){
					$prodsellqty = dintval($_GET['tiliitemqty'][$f]);
					$prodsellqty = fushu($prodsellqty);
					if($prodsellqty <= '0'){
						discuz_process::unlock('update_jnfarm'.$_G['uid']);
						$linkgen = lang("plugin/$jn","s039");
						include template($jn.':'.$jn.'_ajax_plain');
						exit;
					}
					if($userinfo['udata']['tiliitem'][$f][1] < $prodsellqty){
						discuz_process::unlock('update_jnfarm'.$_G['uid']);
						$linkgen = $sdlist[$userinfo['udata']['tiliitem'][$f][0]]['stitle'].lang("plugin/$jn","s038").lang("plugin/$jn","s040",array('prodsellqty'=>$prodsellqty));
						include template($jn.':'.$jn.'_ajax_plain');
						exit;
					}
					$check = '1';
				}
			}
		}
		
		if(!$check){
			discuz_process::unlock('update_jnfarm'.$_G['uid']);
			$linkgen = iconv($_G['charset'],'UTF-8',lang("plugin/$jn","s041"));
			$final = array('final'=>$linkgen);
			//include template($jn.':'.$jn.'_ajax_plain');
			echo json_encode($final);
			exit;
		}
		//���۳ɹ�
		$orimoney = $userinfo['udata']['data']['money'];
		for($c = 1; $c <= $cprod; $c++){
			//����Ƿ��й�ѡ
			if($_GET['prod'][$c] == '1'){
				$prodsellqty = dintval($_GET['prodqty'][$c]);
				$prodsellqty = fushu($prodsellqty);
				$userinfo['udata']['prod'][$c][1] = $userinfo['udata']['prod'][$c][1] - $prodsellqty;
				$moneyadd = $moneyadd+($sdlist[$userinfo['udata']['prod'][$c][0]]['sdata']['sale']*$prodsellqty);
				$allqty = $allqty+$prodsellqty;
				$logitem = $logitem.$sdlist[$userinfo['udata']['prod'][$c][0]]['stitle'].'x'.$prodsellqty.' ';
				$prodsellqty = 0;
			}
		}
		for($d = 1; $d <= $cfert; $d++){
			if($_GET['fert'][$d] == '1'){
				$prodsellqty = dintval($_GET['fertqty'][$d]);
				$prodsellqty = fushu($prodsellqty);
				$userinfo['udata']['fertilize'][$d][1] = $userinfo['udata']['fertilize'][$d][1] - $prodsellqty;
				$moneyadd = $moneyadd+($felist[$userinfo['udata']['fertilize'][$d][0]]['sdata']['cropsale']*$prodsellqty);
				$allqty = $allqty+$prodsellqty;
				$logitem = $logitem.$felist[$userinfo['udata']['fertilize'][$d][0]]['stitle'].'x'.$prodsellqty.' ';
				$prodsellqty = 0;
			}
		}
		for($e = 1; $e <= $cseed; $e++){
			//����Ƿ��й�ѡ
			if($_GET['seed'][$e] == '1'){
				$prodsellqty = dintval($_GET['seedqty'][$e]);
				$prodsellqty = fushu($prodsellqty);
				$userinfo['udata']['seed'][$e][1] = $userinfo['udata']['seed'][$e][1] - $prodsellqty;
				$moneyadd = $moneyadd+($sdlist[$userinfo['udata']['seed'][$e][0]]['sdata']['cropsale']*$prodsellqty);
				$allqty = $allqty+$prodsellqty;
				$logitem = $logitem.$sdlist[$userinfo['udata']['prod'][$e][0]]['stitle'].lang("plugin/$jn","s038").'x'.$prodsellqty.' ';
				$prodsellqty = 0;
			}
		}
		for($f = 1; $f <= $cnitem; $f++){
			//����Ƿ��й�ѡ
			if($_GET['nitem'][$f] == '1'){
				$prodsellqty = dintval($_GET['nitemqty'][$f]);
				$prodsellqty = fushu($prodsellqty);
				$userinfo['udata']['nitem'][$f][1] = $userinfo['udata']['nitem'][$f][1] - $prodsellqty;
				$moneyadd = $moneyadd+($allist[$userinfo['udata']['nitem'][$f][0]]['sdata']['cropsale']*$prodsellqty);
				$allqty = $allqty+$prodsellqty;
				$logitem = $logitem.$allist[$userinfo['udata']['nitem'][$f][0]]['stitle'].'x'.$prodsellqty.' ';
				$prodsellqty = 0;
			}
		}
		if($tiliitemon == '1'){
			for($f = 1; $f <= $ctiliitem; $f++){
				//����Ƿ��й�ѡ
				if($_GET['tiliitem'][$f] == '1'){
					$prodsellqty = dintval($_GET['tiliitemqty'][$f]);
					$prodsellqty = fushu($prodsellqty);
					$userinfo['udata']['tiliitem'][$f][1] = $userinfo['udata']['tiliitem'][$f][1] - $prodsellqty;
					$moneyadd = $moneyadd+($allist[$userinfo['udata']['tiliitem'][$f][0]]['sdata']['cropsale']*$prodsellqty);
					$allqty = $allqty+$prodsellqty;
					$logitem = $logitem.$allist[$userinfo['udata']['tiliitem
					'][$f][0]]['stitle'].'x'.$prodsellqty.' ';
					$prodsellqty = 0;
				}
			}
		}
		$userinfo['udata']['data']['sales'] = $userinfo['udata']['data']['sales']+$allqty;
		$userinfo['udata']['data']['income'] = $userinfo['udata']['data']['income']+$moneyadd;
		if($directextcreditson == '1'){
			$cdd['extcredits'.$jnc['buyext']] = '+'.$moneyadd;
			updatemembercount($_G['uid'], $cdd, true, '', 0, '',$jnc['title'],lang("plugin/$jn","s169"));
			$userinfo['udata']['data']['money'] = $userinfo['udata']['data']['money']+$moneyadd;
			$cdd = array();
		}else{
			$userinfo['udata']['data']['money'] = $userinfo['udata']['data']['money']+$moneyadd;
		}
		$thislang = lang("plugin/$jn","s065",array('logitem'=>$logitem)).$moneyadd.", ".$orimoney.'->'.$userinfo['udata']['data']['money'];
		nlog($_G['uid'],4,$_G['timestamp'],$thislang);
		
		if($directextcreditson == '1'){
			$userinfo['udata']['data']['money'] = 0;
		}
		$userinfo['udata'] = json_encode($userinfo['udata'],true);
		C::t('#'.$jn.'#'.$jn.'_user')->update($userinfo['juid'],array('udata'=>$userinfo['udata'],'lastsituation'=>$_G['timestamp']));
		
		//$linkgen = lang("plugin/$jn","s042").$moneyadd.'<script>setTimeout(function() {ajaxget(\'plugin.php?id='.$jn.'&do=ajax&ac=store&timestamp='.$_G['timestamp'].'\',\'farmlist\');}, 6000);
//</script>';//���ﲻ��ֱ��ˢ��ȫ���ˣ���Ϊ���Ҫչʾ��ʾ��Ϣ�Ļ�;
		if($_GET['fastbuy'] == 'true'){
			$linkgen = '<script>layer.msg(\''.lang("plugin/$jn","s042").$moneyadd.$jnc['mt'].'\');ajaxget(\'plugin.php?id='.$jn.'&do=normal&ac=userinfo&timestamp='.$_G['timestamp'].$pass.'\',\'userinfo\');</script>';
			discuz_process::unlock('update_jnfarm'.$_G['uid']);
			include template($jn.':'.$jn.'_normal_plain');
			
			exit;
		}else{
			$final = iconv($_G['charset'],'UTF-8',lang("plugin/$jn","s042").$moneyadd.$jnc['mt']);
			$final = array('final'=>$final);
			discuz_process::unlock('update_jnfarm'.$_G['uid']);
			echo json_encode($final);
			exit;
		}
		
		//return $linkgen;
		//$linkgen = '<script>layer.msg(\''.$linkgen.'\')'.$_G['timestamp'].'</script>';
		//include template($jn.':'.$jn.'_ajax_plain');
		//cccc($linkgen);
		//showmessage($linkgen,'plugin.php?id=jnfarm'.$mobilelink);
		discuz_process::unlock('update_jnfarm'.$_G['uid']);
	}
		
	}
}
//From: Dism��taobao��com
?>