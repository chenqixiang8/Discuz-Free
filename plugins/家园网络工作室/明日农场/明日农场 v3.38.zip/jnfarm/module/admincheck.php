<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
};
global $_G;
if (!$_G['uid']) showmessage('not_loggedin','',array(), array('login' => true));

global $_G;
$jn = 'jnfarm';
$jnc = $_G['cache']['plugin'][$jn];
$g_adminids = explode('|',$jnc['adminids']);//����ԱȨ��
if(!in_array($_G['uid'],$g_adminids)){
	exit;
}
$arraycheck = array('pack_01');
$namecheck = array('pack_01'=>'13'.lang("plugin/$jn","s277"));

if($_GET['do'] == 'admincheck'){
	if($_GET['pop'] == 'true'){
		$type = daddslashes($_GET['type']);
		$linkgen = '<div style="padding:0.5em;"><div style="margin-bottom:0.5em;"><b style="color:red">'.lang("plugin/$jn","s274").'</div><div class="layui-btn layui-btn-normal layui-btn-fluid" onclick="layer.close(layer.index);openlink(\'plugin.php?id='.$jn.'&do=admincheck&formhash='.$_G['formhash'].'&ac='.$type.'\');">'.lang("plugin/$jn","s275").' <b style="text-decoration:underline;">'.$namecheck[$type].'</b></div><div style="margin-top:0.5em;"><div class="layui-btn layui-btn-danger layui-btn-fluid" onclick="layer.close(layer.index);openlink(\'plugin.php?id='.$jn.'&do=admincheck&unlink=true&formhash='.$_G['formhash'].'&ac='.$type.'\');">'.lang("plugin/$jn","s276").'</b></div></div></div>';
		include template($jn.':'.$jn.'_normal_plain');
		exit;
	}
	if($_GET['formhash'] == $_G['formhash']){
		$ac = daddslashes($_GET['ac']);
		if(!in_array($ac,$arraycheck)){
			exit;
		}
		if($_GET['unlink'] == 'true'){
			if(file_exists(DISCUZ_ROOT.'source/plugin/'.$jn.'/module/'.$ac.'.php')){
				unlink(DISCUZ_ROOT.'source/plugin/'.$jn.'/module/'.$ac.'.php');
				$linkgen = '<script>layer.close(layer.index);layer.msg(\'FILE DELETED\');'.$_G['timestamp'].';</script>';
				include template($jn.':'.$jn.'_normal_plain');
				exit;
			}
		}
		if(file_exists(DISCUZ_ROOT.'source/plugin/'.$jn.'/module/'.$ac.'.php')){
			require DISCUZ_ROOT.'source/plugin/'.$jn.'/module/'.$ac.'.php';
			if(!file_exists(DISCUZ_ROOT.'source/plugin/'.$jn.'/module/nodelete.php')){//������ʹ��
				unlink(DISCUZ_ROOT.'source/plugin/'.$jn.'/module/'.$ac.'.php');//��װ��ɾ�����ļ�
			}
			$linkgen = '<script>layer.close(layer.index);layer.msg(\'UPGRADE SUCCESSFUL\');'.$_G['timestamp'].';</script>';
			include template($jn.':'.$jn.'_normal_plain');
			exit;
		}
	}else{
		exit;
	}
}
$c = count($arraycheck);
for($x=0;$x<$c;$x++){
	if(file_exists(DISCUZ_ROOT.'source/plugin/'.$jn.'/module/'.$arraycheck[$x].'.php')){
		$admincheck = ' onload ="openlink(\'plugin.php?id='.$jn.'&do=admincheck&pop=true&type='.$arraycheck[$x].'&timestamp='.$_G['timestamp'].'\',\'256\');"';
	}
}
//From: Dism��taobao��com
?>