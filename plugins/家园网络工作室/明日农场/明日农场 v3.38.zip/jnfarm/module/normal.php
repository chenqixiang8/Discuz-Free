<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
};
if (!$_G['uid']) showmessage('not_loggedin','',array(), array('login' => true));
if ($reallanddirecton == '1'){
	exit;
}
$pass = substr(md5(uniqid(mt_rand(), true)) , 0, 8);
if($_GET['ac'] == 'updatefarmpet'){
	include template($jn.':'.$jn.'_normal');
	exit;
}
if($_GET['ac'] == 'tutorial'){
	if($_GET['formhash'] == $_G['formhash']){
		if($_GET['tid'] == 'buy'){
			$userinfo['udata']['tutorial']['buy'] = 1;
			$userinfo['udata'] = json_encode($userinfo['udata']);
			C::t('#jnfarm#jnfarm_user')->update($userinfo['juid'],array('udata'=>$userinfo['udata'],'lastsituation'=>$_G['timestamp']));
		}
	}
}
if($_GET['ac'] == 'updatepetinfo'){
	$petinfo = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_pet')." WHERE jpid = '".$userinfo['udata']['petdata']['nowpet']."'");
	if(!$petinfo){
		exit;
	}
	$petinfo['jpdata'] = json_decode($petinfo['jpdata'],true);
	//generate
	foreach($wslist as $ws){
		$wsarray[$x] = $ws['jsid'];
		$x++;
	}
	//����û��ı���
	$cprod = count($userinfo['udata']['prod']);
	for($cp=1;$cp<=$cprod;$cp++){
		if(in_array($userinfo['udata']['prod'][$cp][0],$wsarray)){
			$wslist[$userinfo['udata']['prod'][$cp][0]]['qtyleft'] = $userinfo['udata']['prod'][$cp][1];
		}
	}
	$cfert = count($userinfo['udata']['fertilize']);
	for($cf=1;$cf<=$cfert;$cf++){
		if(in_array($userinfo['udata']['fertilize'][$cf][0],$wsarray)){
			$wslist[$userinfo['udata']['fertilize'][$cf][0]]['qtyleft'] = $userinfo['udata']['fertilize'][$cf][1];
		}
	}
	$cnite = count($userinfo['udata']['nitem']);
	for($cn=1;$cn<=$cnite;$cn++){
		if(in_array($userinfo['udata']['nitem'][$cn][0],$wsarray)){
			$wslist[$userinfo['udata']['nitem'][$cn][0]]['qtyleft'] = $userinfo['udata']['nitem'][$cn][1];
		}
	}
	$ctili = count($userinfo['udata']['tiliitem']);
	for($ct=1;$ct<=$ctili;$ct++){
		if(in_array($userinfo['udata']['tiliitem'][$ct][0],$wsarray)){
			$wslist[$userinfo['udata']['tiliitem'][$ct][0]]['qtyleft'] = $userinfo['udata']['tiliitem'][$ct][1];
		}
	}
	
	if($userinfo['udata']['petdata']['nowpet'] > 0){
		$petexpired = date("Y-m-d H:i:s",$userinfo['udata']['petdata']['petexpired']);
	}
	include template($jn.':'.$jn.'_normal');
	exit;
}
if($_GET['ac'] == 'pet'){
	if($peton == '1'){
		showmessage("$jn:s143");
	}
	$petinfo = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_pet')." WHERE jpid = '1'");
	$petinfo['jpdata'] = json_decode($petinfo['jpdata'],true);
	
	if($_GET['deactive'] == 'true'){
		if($_GET['formhash'] == $_G['formhash']){
			$userinfo['udata']['petdata']['nowpet'] = 0;
			$userinfo['udata']['petdata']['petexpired'] = $_G['timestamp'];
			$userinfo['udata']['petdata']['petbs'] = 0;
			$json = json_encode($userinfo['udata']);
			C::t('#jnfarm#jnfarm_user')->update($userinfo['juid'],array('udata'=>$json,'lastsituation'=>$_G['timestamp']));
			
			$newlang = lang("plugin/$jn","s144");
			nlog($_G['uid'],8,$_G['timestamp'],$newlang);//�������
			
			$linkgen = lang("plugin/$jn","s144");
			$linkgen = '<script>ajaxget(\'plugin.php?id='.$jn.'&do=normal&ac=updatefarmpet&timestamp='.$_G['timestamp'].'&jhash='.$pass.'\',\'farmpet\');layer.msg(\''.$linkgen.'\');</script>';
			include template($jn.':'.$jn.'_normal_plain');
			exit;
		}
	}
	if($_GET['active'] == 'true'){
		$petid = dintval($_GET['petid']);
		if(!in_array($petid,$userinfo['udata']['petdata']['activepet'])){
			showmessage('error');
		}
		if($_GET['formhash'] == $_G['formhash']){
			$userinfo['udata']['petdata']['nowpet'] = $petid;
			$udata = json_encode($userinfo['udata'],true);
			C::t('#jnfarm#jnfarm_user')->update($userinfo['juid'],array('udata'=>$udata,'lastsituation'=>$_G['timestamp']));
			
			$newlang = lang("plugin/$jn","s145").' ('.$plist[$petid]['jptitle'].')';
			nlog($_G['uid'],8,$_G['timestamp'],$newlang);//�������
			
			$linkgen = lang("plugin/$jn","s145");
			$linkgen = '<script>ajaxget(\'plugin.php?id='.$jn.'&do=normal&ac=updatefarmpet&timestamp='.$_G['timestamp'].'&jhash='.$pass.'\',\'farmpet\');layer.msg(\''.$linkgen.'\');</script>';
			include template($jn.':'.$jn.'_normal_plain');
			exit;
		}
	}
	//generate
	foreach($wslist as $ws){
		$wsarray[$x] = $ws['jsid'];
		$x++;
	}
	//����û��ı���
	$cprod = count($userinfo['udata']['prod']);
	for($cp=1;$cp<=$cprod;$cp++){
		if(in_array($userinfo['udata']['prod'][$cp][0],$wsarray)){
			$wslist[$userinfo['udata']['prod'][$cp][0]]['qtyleft'] = $userinfo['udata']['prod'][$cp][1];
		}
	}
	$cfert = count($userinfo['udata']['fertilize']);
	for($cf=1;$cf<=$cfert;$cf++){
		if(in_array($userinfo['udata']['fertilize'][$cf][0],$wsarray)){
			$wslist[$userinfo['udata']['fertilize'][$cf][0]]['qtyleft'] = $userinfo['udata']['fertilize'][$cf][1];
		}
	}
	$cnite = count($userinfo['udata']['nitem']);
	for($cn=1;$cn<=$cnite;$cn++){
		if(in_array($userinfo['udata']['nitem'][$cn][0],$wsarray)){
			$wslist[$userinfo['udata']['nitem'][$cn][0]]['qtyleft'] = $userinfo['udata']['nitem'][$cn][1];
		}
	}
	$ctili = count($userinfo['udata']['tiliitem']);
	for($ct=1;$ct<=$ctili;$ct++){
		if(in_array($userinfo['udata']['tiliitem'][$ct][0],$wsarray)){
			$wslist[$userinfo['udata']['tiliitem'][$ct][0]]['qtyleft'] = $userinfo['udata']['tiliitem'][$ct][1];
		}
	}
	//��鵱ǰ�Ƿ��Ѿ�ӵ�д˳���
	if(in_array($petinfo['jpid'],$userinfo['udata']['petdata']['activepet'])){//�߼����Ҫ��foreach��
		$thispetactive = 1;
		//�����кͿɼ����ڸ߼������������
		if($petinfo['jpid'] == $userinfo['udata']['petdata']['nowpet']){
			$nowpet = 1;
		}
	}
	
	if($userinfo['udata']['petdata']['nowpet'] > 0){
		$petexpired = date("Y-m-d H:i:s",$userinfo['udata']['petdata']['petexpired']);
	}
	if($_GET['buy'] == 'true' && $_GET['petid'] > 0){
		if($_GET['formhash'] == $_G['formhash']){
			$petid = dintval($_GET['petid']);
			if($userinfo['udata']['data']['money'] >= $petinfo['jpdata']['buyprice']){
				$beforedd = $userinfo['udata']['data']['money'];
				$cpet = count($userinfo['udata']['petdata']['activepet']);
				for($x=0;$x<$cpet;$x++){
					$petarray[$x] = $userinfo['udata']['petdata']['activepet'][$x];
				}
				if(in_array($petid,$petarray)){
					$linkgen = lang("plugin/$jn","s146");
					$linkgen = '<script>layer.msg(\''.$linkgen.'\');'.$_G['timestamp'].'</script>';
					include template($jn.':'.$jn.'_normal_plain');
					exit;
				}
				if($directextcreditson == '1'){
					$cdd['extcredits'.$jnc['buyext']] = '-'.$petinfo['jpdata']['buyprice'];
					updatemembercount($_G['uid'], $cdd, true, '', 0, '',$jnc['title'],lang("plugin/$jn","s172"));
					$cdd = array();
				}
				$userinfo['udata']['data']['money'] = $userinfo['udata']['data']['money']-$petinfo['jpdata']['buyprice'];
				$userinfo['udata']['petdata']['activepet'][$cpet] = $petid;
				$userinfo['udata']['petdata']['nowpet'] = $petid;
				if(!$userinfo['udata']['petdata']['petbs']){
					$userinfo['udata']['petdata']['petbs'] = 0;
				}
				
				$newlang = lang("plugin/$jn","s147").' ('.$plist[$petid]['jptitle'].') '.$jnc['mt'].$beforedd.'->'.$userinfo['udata']['data']['money'];
				nlog($_G['uid'],8,$_G['timestamp'],$newlang);//�������
				
				$userinfo['udata']['petdata']['petexpired'] = $_G['timestamp']+($petinfo['jpdata']['hungrytime']*86400);
				if($directextcreditson == '1'){
					$userinfo['udata']['data']['money'] = 0;
				}
				$userinfo['udata'] = json_encode($userinfo['udata'],true);
				C::t('#jnfarm#jnfarm_user')->update($userinfo['juid'],array('udata'=>$userinfo['udata'],'lastsituation'=>$_G['timestamp']));
				
				$linkgen = lang("plugin/$jn","s147");
				$linkgen = '<script>ajaxget(\'plugin.php?id='.$jn.'&do=normal&ac=updatefarmpet&timestamp='.$_G['timestamp'].'&jhash='.$pass.'\',\'farmpet\');layer.msg(\''.$linkgen.'\');</script>';
				include template($jn.':'.$jn.'_normal_plain');
				exit;
			}
		}
	}
	if($_GET['feedid'] > 0 && $_GET['feedqty'] > 0){
		if($_GET['formhash'] == $_G['formhash']){
			$feedid = dintval($_GET['feedid']);
			$feedqty = fushu($_GET['feedqty']);
			//����û���quantity
			if($allist[$feedid]['type'] == 'seed'){//ũ����
				for($cp=1;$cp<=$cprod;$cp++){
					if($userinfo['udata']['prod'][$cp][0] == $feedid){
						if($userinfo['udata']['prod'][$cp][1] >= $feedqty){
							$qtyb4 = $userinfo['udata']['prod'][$cp][1];
							$userinfo['udata']['prod'][$cp][1] = $userinfo['udata']['prod'][$cp][1]-$feedqty;
							$qtyaf = $userinfo['udata']['prod'][$cp][1];
							$feedsuccess = 1;
							break;
						}
					}
				}
			}
			if($allist[$feedid]['type'] == 'fertilize'){//ũ����
				for($cf=1;$cf<=$cfert;$cf++){
					if($userinfo['udata']['fertilize'][$cf][0] == $feedid){
						if($userinfo['udata']['fertilize'][$cf][1] >= $feedqty){
							$qtyb4 = $userinfo['udata']['fertilize'][$cf][1];
							$userinfo['udata']['fertilize'][$cf][1] = $userinfo['udata']['fertilize'][$cf][1]-$feedqty;
							$qtyaf = $userinfo['udata']['fertilize'][$cf][1];
							$feedsuccess = 1;
							break;
						}
					}
				}
			}
			if($allist[$feedid]['type'] == 'nitem'){//��Ʒ
				for($cn=1;$cn<=$cnite;$cn++){
					if($userinfo['udata']['nitem'][$cn][0] == $feedid){
						if($userinfo['udata']['nitem'][$cn][1] >= $feedqty){
							$qtyb4 = $userinfo['udata']['nitem'][$cn][1];
							$userinfo['udata']['nitem'][$cn][1] = $userinfo['udata']['nitem'][$cn][1]-$feedqty;
							$qtyaf = $userinfo['udata']['nitem'][$cn][1];
							$feedsuccess = 1;
							break;
						}
					}
				}
			}
			
			if($allist[$feedid]['type'] == 'tiliitem'){//��Ʒ
				for($ct=1;$ct<=$ctili;$ct++){
					if($userinfo['udata']['tiliitem'][$ct][0] == $feedid){
						if($userinfo['udata']['tiliitem'][$ct][1] >= $feedqty){
							$qtyb4 = $userinfo['udata']['tiliitem'][$ct][1];
							$userinfo['udata']['tiliitem'][$ct][1] = $userinfo['udata']['tiliitem'][$ct][1]-$feedqty;
							$qtyaf = $userinfo['udata']['tiliitem'][$ct][1];
							$feedsuccess = 1;
							break;
						}
					}
				}
			}
			if(!$feedsuccess){
				$linkgen = lang("plugin/$jn","s148");
			}else{
				$petbsb4 = $userinfo['udata']['petdata']['petbs'];
				$bsadd = $wslist[$feedid]['sdata']['feedadd']*$feedqty;
				$userinfo['udata']['petdata']['petbs'] = $userinfo['udata']['petdata']['petbs']+$bsadd;
				if($userinfo['udata']['petdata']['petbs'] >= $petinfo['jpdata']['hungry']){
					//���������Ӷ���ʱ��
					$addhungrytime = floor($userinfo['udata']['petdata']['petbs']/$petinfo['jpdata']['hungry']);
					if($userinfo['udata']['petdata']['petexpired'] < $_G['timestamp']){//�ѹ���
						$userinfo['udata']['petdata']['petexpired'] = $_G['timestamp']+(86400*$petinfo['jpdata']['hungrytime']*$addhungrytime);
					}else{ //δ����
						$userinfo['udata']['petdata']['petexpired'] = $userinfo['udata']['petdata']['petexpired']+(86400*$petinfo['jpdata']['hungrytime']*$addhungrytime);
					};
					$userinfo['udata']['petdata']['petbs'] = $userinfo['udata']['petdata']['petbs']-($petinfo['jpdata']['hungry']*$addhungrytime);
				}
				$linkgen = lang("plugin/$jn","s149");
				
				$timeend = date("Y-m-d H:i:s",$userinfo['udata']['petdata']['petexpired']);
				$newlang = lang("plugin/$jn","s150",array('feedqty'=>$feedqty,'stitle'=>$allist[$feedid]['stitle'],'petbsb4'=>$petbsb4,'bsadd'=>$userinfo['udata']['petdata']['petbs'],'timeend'=>$timeend)).$qtyb4.'->'.$qtyaf;
				nlog($_G['uid'],8,$_G['timestamp'],$newlang);//�������
			}
			$userinfo['udata'] = json_encode($userinfo['udata'],true);
			C::t('#jnfarm#jnfarm_user')->update($userinfo['juid'],array('udata'=>$userinfo['udata'],'lastsituation'=>$_G['timestamp']));
			$linkgen = '<script>layer.msg(\''.$linkgen.'\');ajaxget(\'plugin.php?id='.$jn.'&do=normal&ac=updatepetinfo&timestamp='.$_G['timestamp'].'&jhash='.$pass.'\',\'mypetinfo\');</script>';
			include template($jn.':'.$jn.'_normal_plain');
			exit;
		}else{
			showmessage('error');
		}
		
	}
	//�������Ա�ιʳ��
}
if($_GET['ac'] == 'water' || $_GET['ac'] == 'worm' || $_GET['ac'] == 'weed'){//��ˮ,����,����
	$userid = $_G['uid'];
	if($_GET['helpfriend'] == 'true'){
		$userid = dintval($_GET['friendid']);
		if($userid == $_G['uid']){
			showmessage("$jn:s023");//�����û��Ըı���
		}
		if($jnc['friend'] == '1'){
			$fhome = DB::fetch_all("SELECT * FROM ".DB::table('home_friend')." WHERE uid = '".$_G['uid']."' AND fuid = '$userid'");
			if(!$fhome){
				showmessage("$jn:s024");//�����û��Ըı���
			}
		}
	}
	$jfid = dintval($_GET['jfid']);
	$jinfo = C::t('#'.$jn.'#'.$jn.'_land')->jinfo($userid);
	if(!$jinfo['jfid']){
		$linkgen = '<script>layer.msg(\''.lang("plugin/$jn","s043").'\')</script>';
		include template($jn.':'.$jn.'_normal_plain');
		exit;
		
	}
	$acarray = array('water','worm','weed');
	if(!in_array($_GET['ac'],$acarray)){
		showmessage('Error');
	}
	$getac = daddslashes($_GET['ac']);
	if($_GET['formhash'] == $_G['formhash']){
		$getjoin = $getac.'cost';
		if(!$sysinfo['setdata'][$getjoin]){
			$sysinfo['setdata'][$getjoin] = '10';
		}
		if($userinfo['udata']['data']['money']-$sysinfo['setdata'][$getjoin] < 0){
			$linkgen = '<script>layer.msg(\''.$jnc['mt'].lang("plugin/$jn","s031").'\')</script>';
			include template($jn.':'.$jn.'_normal_plain');
			exit;
		}
		$jinfo['fdata'] = json_decode($jinfo['fdata'],true);
		if($jinfo['fdata'][$jfid][$getac] > $_G['timestamp']){
			$jinfo['fdata'][$jfid][$getac] = 0;
			
			if($directextcreditson == '1'){
				$cdd['extcredits'.$jnc['buyext']] = '-'.$sysinfo['setdata'][$getjoin];
				updatemembercount($_G['uid'], $cdd, true, '', 0, '',$jnc['title'],lang("plugin/$jn","s173"));
				$cdd = array();
			}
			
			$userinfo['udata']['data']['money'] = $userinfo['udata']['data']['money'] - $sysinfo['setdata'][$getjoin];
			
			$userinfo['udata']['data']['exp'] = $userinfo['udata']['data']['exp']+1;
			$toexp = $userinfo['udata']['data']['exp'];
			
			if($directextcreditson == '1'){
				$userinfo['udata']['data']['money'] = 0;
			}
			$userinfo['udata'] = json_encode($userinfo['udata']);
			$jinfo['fdata'] = json_encode($jinfo['fdata']);
			C::t('#'.$jn.'#'.$jn.'_user')->update($userinfo['juid'],array('udata'=>$userinfo['udata']));
			C::t('#'.$jn.'#'.$jn.'_land')->update($jinfo['jfid'],array('fdata'=>$jinfo['fdata']));
			
			if($_GET['helpfriend'] == 'true'){
				//$linkgen = lang("plugin/$jn","s058");
				$linkgen = '<script>ajaxget(\'plugin.php?id='.$jn.'&do=normal&ac=thisfriend&friendid='.$userid.'&jfid='.$jfid.'&timestamp='.$_G['timestamp'].'&jhash='.$pass.'\',\'thisfarm'.$jfid.'\');layer.msg(\''.lang("plugin/$jn","s076").'\');</script>';
				$thislang = lang("plugin/$jn","s059",array('jfid'=>$jfid)).$userid;//"�Ժ��ѵ�ũ��ID".$jfid."����״̬���� ����UID:$userid";
				nlog($_G['uid'],3,$_G['timestamp'],$thislang);
			}else{
				//$linkgen = lang("plugin/$jn","s058").'<script>ajaxget("plugin.php?id='.$jn.'&do=ajax&ac=updatejfid&jfid='.$jfid.'&timestamp='.$_G['timestamp'].'","jfid'.$jfid.'");ajaxget("plugin.php?id='.$jn.'&do=ajax&ac=updatejrid&jfid='.$jfid.'&timestamp='.$_G['timestamp'].'","jrid'.$jfid.'");</script>';
				$linkgen = '<script>ajaxget(\'plugin.php?id='.$jn.'&do=normal&ac=updateland&formhash='.$_G['formhash'].'&timestamp='.$_G['timestamp'].'&jhash='.$pass.'\',\'jnland\');ajaxget(\'plugin.php?id='.$jn.'&do=normal&ac=thisfarm&jfid='.$jfid.'&timestamp='.$_G['timestamp'].'&jhash='.$pass.'\',\'thisfarm'.$jfid.'\');layer.msg(\''.lang("plugin/$jn","s076").'\');</script>';
				$thislang = lang("plugin/$jn","s060",array('jfid'=>$jfid));//"��ũ��ID".$jfid."����״̬����";
				nlog($_G['uid'],3,$_G['timestamp'],$thislang);
			}
			
			expcheck($_G['uid'],$toexp);

			include template($jn.':'.$jn.'_normal_other');
			exit;
		}
	}
}
if($_GET['ac'] == 'ranklist'){
	$rank = DB::fetch_all("SELECT * FROM ".DB::table('game_jnfarm_user')." LIMIT 10");//���ܿ��԰�����
	foreach($rank as $fr){
		$fr['udata'] = json_decode($fr['udata'],true);
		$moneylist[] = $fr;
		$lvllist[] = $fr;
	}
	usort($moneylist, function($a, $b) { //Sort the array using a user defined function
		return $a['udata']['data']['money'] > $b['udata']['data']['money'] ? -1 : 1; //Compare the scores
	});
	usort($lvllist, function($a, $b) { //Sort the array using a user defined function
		return $a['udata']['data']['farmlvl'] > $b['udata']['data']['farmlvl'] ? -1 : 1; //Compare the scores
	});
}

if($_GET['ac'] == 'kuozhan'){
	$jinfo = C::t('#'.$jn.'#'.$jn.'_land')->jinfo($_G['uid']);
	if(!$jinfo['jfid']){
		showmessage("$jn:o003");
	}
	$jinfo['fdata'] = json_decode($jinfo['fdata'],true);
	$countland = count($jinfo['fdata']);
	$kuozhancost = $sysinfo['setdata']['expandset'][$countland+1]['cost'];
	$kuozhanlvl = $sysinfo['setdata']['expandset'][$countland+1]['lvl'];
	if($_GET['upgrade'] == 'true'){
		if(!discuz_process::islocked('update_jnfarm'.$_G['uid'])) {
			if($_GET['formhash'] == $_G['formhash']){
				if($userinfo['udata']['data']['money'] >= $kuozhancost && $userinfo['udata']['data']['farmlvl'] >= $kuozhanlvl){
					
					if($directextcreditson == '1'){
						$cdd['extcredits'.$jnc['buyext']] = '-'.$kuozhancost;
						updatemembercount($_G['uid'], $cdd, true, '', 0, '',$jnc['title'],lang("plugin/$jn","s174"));
						$cdd = array();
					}
					$userinfo['udata']['data']['money'] = $userinfo['udata']['data']['money']-$kuozhancost;
					
					$jinfo['fdata'][$countland+1]['seed'] = '0';
					$jinfo['fdata'][$countland+1]['type'] = '1';
					$jinfo['fdata'][$countland+1]['prodstart'] = '0';
					$jinfo['fdata'][$countland+1]['prodfinish'] = '0';
					$jinfo['fdata'][$countland+1]['expired'] = '0';
					
					$jinfo['fdata'] = json_encode($jinfo['fdata'],true);
					C::t('#'.$jn.'#'.$jn.'_land')->update($jinfo['jfid'],array('fdata'=>$jinfo['fdata']));
					
					if($directextcreditson == '1'){
						$userinfo['udata']['data']['money'] = 0;
					}
					$userinfo['udata'] = json_encode($userinfo['udata']);
					C::t('#'.$jn.'#'.$jn.'_user')->update($userinfo['juid'],array('udata'=>$userinfo['udata'],'lastsituation'=>$_G['timestamp']));
					
					$linkgen = '<script>ajaxget(\'plugin.php?id='.$jn.'&do=normal&ac=updateland&formhash='.$_G['formhash'].'&timestamp='.$_G['timestamp'].'&jhash='.$pass.'\',\'jnland\');layer.closeAll();layer.msg(\''.lang("plugin/$jn","s034").'\');ajaxget(\'plugin.php?id='.$jn.'&do=normal&ac=userinfo&timestamp='.$_G['timestamp'].$pass.'\',\'userinfo\');</script>';
					discuz_process::unlock('update_jnfarm'.$_G['uid']);
					include template($jn.':'.$jn.'_normal_plain');
					exit;
					//showmessage("$jn:s034",'plugin.php?id='.$jn);
				}else{
					$linkgen = '<script>layer.msg(\''.lang("plugin/$jn","s077",array('jncmt'=>$jnc['mt'])).'\');'.$_G['timestamp'].'</script>';
					discuz_process::unlock('update_jnfarm'.$_G['uid']);
					include template($jn.':'.$jn.'_normal_plain');
					exit;
					//showmessage("$jn:s077",'plugin.php?id='.$jn,array('jncmt'=>$jnc['mt']));
				}
			}
			discuz_process::unlock('update_jnfarm'.$_G['uid']);
		}
	}
	discuz_process::unlock('update_jnfarm'.$_G['uid']);
	include template($jn.':'.$jn.'_normal');
	exit;
}
if($_GET['ac'] == 'updatetopup'){
	if($jnc['topuprecord'] == '1'){
		$topup = DB::fetch_all("SELECT * FROM ".DB::table('game_jnfarm_log')." WHERE uid = '".$_G['uid']."' ORDER BY createtime DESC LIMIT ".$jnc['topuplist']." ");
	}else{
		$topup = DB::fetch_all("SELECT t1.*,t2.username FROM ".DB::table('game_jnfarm_log')." t1 LEFT JOIN ".DB::table('game_jnfarm_user')." t2 ON (t1.uid=t2.uid) ORDER BY t1.createtime DESC LIMIT ".$jnc['topuplist']." ");
		$tt = 1;
	}
	foreach($topup as $tp){
		if($tt == '1'){
			$tp['username'] = $tp['username'];
		}
		$tp['createtime'] = date("m-d H:i",$tp['createtime']);
		$tplist[] = $tp;
	}
}

if($_GET['ac'] == 'viewfriend'){
	$friendid = dintval($_GET['friendid']);
	if($friendid == $_G['uid']){
		showmessage("$jn:s023");//�����û��Ըı���
	}
	if($jnc['friend'] == '1'){
		$fhome = DB::fetch_all("SELECT * FROM ".DB::table('home_friend')." WHERE uid = '".$_G['uid']."' AND fuid = '$friendid'");
		if(!$fhome){
			showmessage("$jn:s024");//�����û��Ըı���
		}
	}
	$flist = array();
	$farm = DB::fetch_all("SELECT * FROM ".DB::table('game_jnfarm_farm')." WHERE uid = '".$friendid."' ORDER BY jfid ASC");
	$frinfo = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_user')." WHERE uid = '".$friendid."'");
	$frinfo['udata'] = json_decode($frinfo['udata'],true);
	$x = 1;
	foreach($farm as $fr){
		$fr['fdata'] = json_decode($fr['fdata'],true);
		if($fr['fdata']['seed'] > 0){
			$fr['name'] = $sdlist[$fr['fdata']['seed']]['stitle'];//$seedname[$fr['fdata']['seed']];
			if($fr['fdata']['expired'] > $_G['timestamp']){
				$fr['images'] = $sdlist[$fr['fdata']['seed']]['sdata']['imgurl'];//����ͼƬ
			}else{
				$fr['images'] = 'kuwei.png';//���ؿ�ήͼƬ
			}
			
			if($fr['fdata']['prodfinish']>$_G['timestamp']){
				$fr['left'] = $fr['fdata']['prodfinish']-$_G['timestamp'];
			}else{
				$fr['left'] = $fr['fdata']['expired']-$_G['timestamp'];
			}
			
		}
		$ct[$x] = $fr['jfid'];
		$fr['x'] = $x;
		$x++;
		$flist[] = $fr;
	}
	//���viewfriend��ǰ�ж�������
	$friendland = C::t('#'.$jn.'#'.$jn.'_farm')->resultmy($_G['uid']);
	for($spanm = 1;$spanm <= $friendland; $spanm++){
		$span_m = $span_m.'<span id="span_miao'.$spanm.'" style="display:none"></span>';
	}
	for($clint = 1;$clint <= $friendland; $clint++){
		$clin_t = $clin_t.'clearInterval(x'.$clint.');';
	}
	if($_GET['thief'] == 'true'){
		$userinfo['udata']['data']['tili'][0] = 0;
		if($userinfo['udata']['data']['tili'][0] <= '0'){
			$linkgen = lang("plugin/$jn","s140");
			include template($jn.':'.$jn.'_ajax_plain');
			exit;
		}
		//showmessage('error');
		$jfid = dintval($_GET['jfid']);
		if(!in_array($jfid,$ct)){
			showmessage("$jn:s024");//�����û��Ըı���
		}
		$jthis = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_farm')." WHERE jfid = '$jfid'");
		$jthis['fdata'] = json_decode($jthis['fdata'],true);
		if($jthis['fdata']['expired'] < $_G['timestamp']){
			$linkgen = lang("plugin/$jn","s025");
			include template($jn.':'.$jn.'_ajax_plain');
			exit;
		}
		if($jthis['fdata']['qtyleft'] < ($jthis['fdata']['oriqty']/2)){
			$linkgen = lang("plugin/$jn","s026");
			include template($jn.':'.$jn.'_ajax_plain');
			exit;
		}
		if($jthis['fdata']['prodfinish'] > $_G['timestamp']){
			$linkgen = lang("plugin/$jn","s027");
			include template($jn.':'.$jn.'_ajax_plain');
			exit;
		}
		
		$thisrand = mt_rand(1,3);
		$jthis['fdata']['qtyleft'] = $jthis['fdata']['qtyleft']-$thisrand;
		
		//����Լ��ı���������û���Ǹ�����
		$cprod = count($userinfo['udata']['prod']);
		for($x = 1; $x <= $cprod; $x++){
			if($userinfo['udata']['prod'][$x][0] == $jthis['fdata']['seed']){
				$ori = $userinfo['udata']['prod'][$x][1];
				$userinfo['udata']['prod'][$x][1] = $userinfo['udata']['prod'][$x][1]+$thisrand;
				$after = $userinfo['udata']['prod'][$x][1];
				$ok = '1';
			}
		}
		if(!$ok){
			//replace
			$ori = '0';
			$userinfo['udata']['prod'][$x][0] = $jthis['fdata']['seed'];
			$userinfo['udata']['prod'][$x][1] = $thisrand;
			$after = $thisrand;
		}
		$note = lang("plugin/$jn","s028",array('username'=>$_G['username'],'thisrand'=>$thisrand,'sdlistjthis'=>$sdlist[$jthis['fdata']['seed']]['stitle']));//'����'.$_G['username'].'͵����'.$thisrand.$sdlist[$jthis['fdata']['seed']]['stitle'];
		if($jnc['notificationonoff'] == '1'){
			notification_add($friendid, 'myapp', $note, '', 0);
		}
		
		
		$thislang = lang("plugin/$jn","s063",array('jfid'=>$jfid,'thisrand'=>$thisrand,'sdlistjthis'=>$sdlist[$jthis['fdata']['seed']]['stitle'],'ori'=>$ori,'after'=>$after));//"͵��ũ��ID".$jfid.$thisrand.$sdlist[$jthis['fdata']['seed']]['stitle']."���� ".$ori."->".$after;
		nlog($_G['uid'],3,$_G['timestamp'],$thislang);
		
		$jthis['fdata'] = json_encode($jthis['fdata'],true);
		C::t('#'.$jn.'#'.$jn.'_farm')->update($jthis['jfid'],array('fdata'=>$jthis['fdata']));
		$userinfo['udata'] = json_encode($userinfo['udata'],true);
		C::t('#'.$jn.'#'.$jn.'_user')->update($userinfo['juid'],array('udata'=>$userinfo['udata']));
		
		
		
		$linkgen = lang("plugin/$jn","s029").$thisrand;
		include template($jn.':'.$jn.'_normal_plain');
		exit;
	}
}

if($_GET['ac'] == 'neighbours'){
	if($jnc['friend'] == '1'){//ǿ������
		$fhome = DB::fetch_all("SELECT fuid,fusername FROM ".DB::table('home_friend')." WHERE uid = '".$_G['uid']."' ");
		foreach($fhome as $fh){
			$fh['username'] = $fh['fusername'];
			$th[$x] = $fh['fuid'];
			$x++;
		}
		$fuid = implode(',',$th);
		
		if($guildon == '1'){
			$friend = DB::fetch_all("SELECT * FROM ".DB::table('game_jnfarm_user')." WHERE uid IN ($fuid)");
		}else{
			$friend = DB::fetch_all("SELECT * FROM ".DB::table('game_jnfarm_user')." WHERE uid IN ($fuid)");
		}
		
	}else{//ȫվ����
		$friend = DB::fetch_all("SELECT * FROM ".DB::table('game_jnfarm_user')." ");//���ܿ��԰�����
	}
	if($_GET['sort'] == 'money'){//������ǰ��Ƹ�����
		foreach($friend as $fr){
			$fr['udata'] = json_decode($fr['udata'],true);
			$fr['money'] = $fr['udata']['data']['money'];
			$frlist[] = $fr;
		}
		usort($frlist, function($a, $b) { //Sort the array using a user defined function
			return $a['udata']['data']['money'] > $b['udata']['data']['money'] ? -1 : 1; //Compare the scores
		});
	}else{//�ȼ�
		foreach($friend as $fr){
			$fr['udata'] = json_decode($fr['udata'],true);
			$fr['money'] = $fr['udata']['data']['money'];
			$frlist[] = $fr;
		}
		usort($frlist, function($a, $b) { //Sort the array using a user defined function
			return $a['udata']['data']['farmlvl'] > $b['udata']['data']['farmlvl'] ? -1 : 1; //Compare the scores
		});
	}
	if($guildon == '1'){
		$sysinfo['guildset'] = explode('|',$sysinfo['guildset']);
		$guildname = DB::fetch_all("SELECT * FROM ".DB::table('game_jnfarm_guild')."");
		$guildname = array_column($guildname,null,'jgid');
	}
	include template($jn.':'.$jn.'_normal');
	exit;
}
if($_GET['ac'] == 'shop'){
	$shop = DB::fetch_all("SELECT * FROM ".DB::table('game_jnfarm_item')." ORDER BY jiorder ASC");
	foreach($shop as $sc){
		$sc['sdata'] = json_decode($sc['sdata'],true);
		$sclist[] = $sc;
	}
	$sclist = array_column($sclist, null, 'jsid');
	$pass = substr(md5(uniqid(mt_rand(), true)) , 0, 8);
	foreach($shop as $sh){
		$sh['sdata'] = json_decode($sh['sdata'],true);
		if($sh['sdata']['buyable'] == '1' && $sh['sdata']['minlvl'] <= $userinfo['udata']['data']['farmlvl']){
			if($sh['type'] == 'seed'){
				$zz = lang("plugin/$jn","s038");
			}else{
				$zz = '';
			}
			if($vipon == '1' && $userinfo['vipexpired'] > $_G['timestamp']){
				$sh['sdata']['newcost'] = $sh['sdata']['cost']-floor($sh['sdata']['cost']*$sysinfo['setdata']['vip']['discount']*0.01);
				$vipword = '<div style="margin-top:0.3em;padding:0.1em 0.5em; border-radius:0.5em; background: rgb(0,0,0,0.3); color:yellow; text-shadow: 1px 1px 3px black"><img src="'.$imgurl.'coin.svg" style="width:1em;"> '.$sh['sdata']['newcost'].'</div>';
			}else{
				$vipword = '<div style="padding:0.1em 0.5em; border-radius:0.5em; background: rgb(0,0,0,0.3); color:yellow; text-shadow: 1px 1px 3px black"><img src="'.$imgurl.'coin.svg" style="width:1em;"> '.$sh['sdata']['cost'].'</div>';
			}
			$text = $text.'<div style="width:33%; display:inline-block;" align="center"><div style="float:left; background: white; ; padding:0.5em; box-shadow:0px 0px 10px rgb(0,0,0,0.1); border-radius:10px; position:relative; margin-right:1em; margin-bottom:1em; font-size:0.9em">
				<a href="javascript:;" onclick="ajaxget(\'plugin.php?id='.$jn.'&do=shop&submit=true&timestamp='.$_G['timestamp'].$pass.'&jsid['.$sh['jsid'].']=1&qty['.$sh['jsid'].']=1&formhash='.$_G['formhash'].'&fastbuy=true&jhash='.$pass.'\',\'aaa\');"><div style="height:7em; line-height:7em">
					<img src="'.$imgurl.'bag.svg" style="width:100%;">
				</div>'.$sh['stitle'].$zz.' <div style="position:absolute; left:0; right:0; top:2.2em"><img src="'.$imgurl.$sh['sdata']['seedurl'].'" style="width:2.8em;"></div><div style="position:absolute;right:0.5em;top:0.5em;">'.$vipword.'</div></a><div class="control-group">
        <label class="control control-checkbox">
            <input type="checkbox" name="jsid['.$sh['jsid'].']" value="1"/>
            <div class="control_indicator"></div>
        </label> <input type="number" style="width:100%; height:1.5em;border-radius:25px; border:1px solid grey; text-align:center;" name="qty['.$sh['jsid'].']">
    </div></div></div>';
		}
		$shlist[] = $sh;
	}
	include template($jn.':'.$jn.'_normal');
	exit;
}
if($_GET['ac'] == 'store'){
	$cprod = count($userinfo['udata']['prod']);
	for($c = 1; $c <= $cprod; $c++){
		//this.parentNode.querySelector(\'input[type=number]\').stepDown(); �����
		if($userinfo['udata']['prod'][$c][1] > 0){//����������ʾ
			$text = $text.'<div style="width:33%; display:inline-block;" align="center" class="aaa-input">
			<div style="float:left; background: white;box-shadow:0px 0px 10px rgb(0,0,0,0.1); padding:0.5em; border-radius:10px; position:relative; margin-right:1em;margin-bottom:1em; font-size:0.9em">
				<a href="javascript:;" onclick="fastbtn('.$c.',\'prod\')"><div style="height:7em; line-height:7em;">
					<img src="'.$imgurl.$sdlist[$userinfo['udata']['prod'][$c][0]]['sdata']['seedurl'].'" style="max-width:70%;">
				</div>'.$sdlist[$userinfo['udata']['prod'][$c][0]]['stitle'].'
				<div style="position:absolute;right:0.5em;top:0.5em;">
					<div style="padding:0.1em 0.5em; border-radius:0.5em; background: rgb(0,0,0,0.3); color:yellow; text-shadow: 1px 1px 3px black"><img src="'.$imgurl.'coin.svg" style="width:1em;"> '.$sdlist[$userinfo['udata']['prod'][$c][0]]['sdata']['sale'].'</div>
				</div></a>
				<div class="control-group">
        		<label class="control control-checkbox">
            		<input type="checkbox" name="prod['.$c.']" value="1"/>
            		<div class="control_indicator"></div>
        		</label> <input type="number" style="width:100%; height:1.5em;border-radius:25px; border:1px solid grey; text-align:center;" value="'.$userinfo['udata']['prod'][$c][1].'" name="prodqty['.$c.']" id="prodqty'.$c.'">
    			</div>
			</div>
		</div>';
		}
	}
	$cfert = count($userinfo['udata']['fertilize']);
	for($d = 1; $d <= $cfert; $d++){
		if($userinfo['udata']['fertilize'][$d][1] > 0){//����������ʾ
			$text = $text.'<div style="width:33%; display:inline-block;" align="center"><div style="float:left; background: white;box-shadow:0px 0px 10px rgb(0,0,0,0.1); padding:0.5em; border-radius:10px; position:relative; margin-right:1em;margin-bottom:1em; font-size:0.9em">
				<a href="javascript:;" onclick="fastbtn('.$d.',\'fert\');"><div style="height:7em; line-height:7em;">
					<img src="'.$imgurl.$felist[$userinfo['udata']['fertilize'][$d][0]]['sdata']['seedurl'].'" style="width:70%;">
				</div>
				'.$felist[$userinfo['udata']['fertilize'][$d][0]]['stitle'].'<div style="position:absolute;right:0.5em;top:0.5em;"><div style="padding:0.1em 0.5em; border-radius:0.5em; background: rgb(0,0,0,0.3); color:yellow; text-shadow: 1px 1px 3px black"><img src="'.$imgurl.'coin.svg" style="width:1em;"> '.$felist[$userinfo['udata']['fertilize'][$d][0]]['sdata']['cropsale'].'</div></div></a><div class="control-group">
			<label class="control control-checkbox">
				<input type="checkbox" name="fert['.$d.']" value="1"/>
				<div class="control_indicator"></div>
			</label> <input type="number" style="width:100%; height:1.5em;border-radius:25px; border:1px solid grey; text-align:center;" value="'.$userinfo['udata']['fertilize'][$d][1].'" name="fertqty['.$d.']" id="fertqty'.$d.'">
		</div></div></div>';
		}
	}
	$cseed = count($userinfo['udata']['seed']);
	for($e = 1; $e <= $cseed; $e++){
		if($userinfo['udata']['seed'][$e][1] > 0){//����������ʾ
			$texta = $texta.'<div style="width:33%; display:inline-block;" align="center">
			<div style="float:left; background: white;box-shadow:0px 0px 10px rgb(0,0,0,0.1); padding:0.5em; border-radius:10px; position:relative; margin-right:1em;margin-bottom:1em; font-size:0.9em">
				<a href="javascript:;" onclick="fastbtn('.$e.',\'seed\');"><div style="height:7em; line-height:7em;"><img src="'.$imgurl.'bag.svg" style="width:100%;"></div>
				'.$sdlist[$userinfo['udata']['seed'][$e][0]]['stitle'].lang("plugin/$jn","s038").' <div style="position:absolute; left:0; right:0; top:2.2em"><img src="'.$imgurl.$sdlist[$userinfo['udata']['seed'][$e][0]]['sdata']['seedurl'].'" style="width:2.8em;"></div><div style="position:absolute;right:0.5em;top:0.5em;"><div style="padding:0.1em 0.5em; border-radius:0.5em; background: rgb(0,0,0,0.3); color:yellow; text-shadow: 1px 1px 3px black"><img src="'.$imgurl.'coin.svg" style="width:1em;"> '.$sdlist[$userinfo['udata']['seed'][$e][0]]['sdata']['cropsale'].'</div></div></a><div class="control-group">
			<label class="control control-checkbox">
				<input type="checkbox" name="seed['.$e.']" value="1"/>
				<div class="control_indicator"></div>
			</label> <input type="number" style="width:100%; height:1.5em;border-radius:25px; border:1px solid grey; text-align:center;" value="'.$userinfo['udata']['seed'][$e][1].'" name="seedqty['.$e.']" id="seedqty'.$e.'">
		</div></div></div>';
		}
	}
	$cnitem = count($userinfo['udata']['nitem']);
	for($f = 1; $f <= $cnitem; $f++){
		if($userinfo['udata']['nitem'][$f][1] > 0){//����������ʾ
			$text = $text.'<div style="width:33%; display:inline-block;" align="center">
			<div style="float:left; background: white;box-shadow:0px 0px 10px rgb(0,0,0,0.1); padding:0.5em; border-radius:10px; position:relative; margin-right:1em;margin-bottom:1em; font-size:0.9em">
				<a href="javascript:;" onclick="fastbtn('.$f.',\'nitem\');"><div style="height:7em; line-height:7em;"><img src="'.$imgurl.$allist[$userinfo['udata']['nitem'][$f][0]]['sdata']['seedurl'].'" style="width:70%;">
				</div>'.$allist[$userinfo['udata']['nitem'][$f][0]]['stitle'].'
				<div style="position:absolute;right:0.5em;top:0.5em;">
					<div style="padding:0.1em 0.5em; border-radius:0.5em; background: rgb(0,0,0,0.3); color:yellow; text-shadow: 1px 1px 3px black"><img src="'.$imgurl.'coin.svg" style="width:1em;"> '.$allist[$userinfo['udata']['nitem'][$f][0]]['sdata']['cropsale'].'</div>
				</div></a>
				<div class="control-group">
        		<label class="control control-checkbox">
            		<input type="checkbox" name="nitem['.$f.']" value="1"/>
            		<div class="control_indicator"></div>
        		</label> <input type="number" style="width:100%; height:1.5em;border-radius:25px; border:1px solid grey; text-align:center;" value="'.$userinfo['udata']['nitem'][$f][1].'" name="nitemqty['.$f.']" id="nitemqty'.$f.'">
    			</div>
			</div>
		</div>';
		}
	}
	if($tiliitemon == '1'){
		$ctiliitem = count($userinfo['udata']['tiliitem']);
		for($f = 1; $f <= $ctiliitem; $f++){
			if($userinfo['udata']['tiliitem'][$f][1] > 0){//����������ʾ
				$text = $text.'<div style="width:33%; display:inline-block;" align="center">
				<div style="float:left; background: white;box-shadow:0px 0px 10px rgb(0,0,0,0.1); padding:0.5em; border-radius:10px; position:relative; margin-right:1em;margin-bottom:1em; font-size:0.9em">
					<a href="javascript:;" onclick="layer.msg(\''.lang("plugin/$jn","s249").'\');"><div style="height:7em; line-height:7em;"><img src="'.$imgurl.$allist[$userinfo['udata']['tiliitem'][$f][0]]['sdata']['seedurl'].'" style="width:70%;">
					</div>'.$allist[$userinfo['udata']['tiliitem'][$f][0]]['stitle'].'
					<div style="position:absolute;right:0.5em;top:0.5em;">
						<div style="padding:0.1em 0.5em; border-radius:0.5em; background: rgb(0,0,0,0.3); color:yellow; text-shadow: 1px 1px 3px black"><img src="'.$imgurl.'coin.svg" style="width:1em;"> '.$allist[$userinfo['udata']['tiliitem'][$f][0]]['sdata']['cropsale'].'
						</div>
					</div></a>
					<a href="javascript:;" onclick="ajaxget(\'plugin.php?id='.$jn.'&do=tiliitem&formhash='.$_G['formhash'].'&jsid='.$f.'&timestamp='.$_G['timestamp'].'\');"><div style="position: absolute; left:0.5em; top:0.5em;">
						<div style="padding:0.1em 0.5em; border-radius:0.5em; background: rgb(15,76,129,0.8); color:yellow; text-shadow: 1px 1px 3px black;">'.lang("plugin/$jn","s248").'</div>
					</div></a>
					<div class="control-group">
					<label class="control control-checkbox">
						<input type="checkbox" name="tiliitem['.$f.']" value="1"/>
						<div class="control_indicator"></div>
					</label> <input type="number" style="width:100%; height:1.5em;border-radius:25px; border:1px solid grey; text-align:center;" value="'.$userinfo['udata']['tiliitem'][$f][1].'" name="tiliitemqty['.$f.']" id="tiliitemqty'.$f.'">
					</div>
				</div>
			</div>';
			}
		}
	}
	
	include template($jn.':'.$jn.'_normal');
	exit;
}
if($_GET['ac'] == 'cut'){
	$jfid = dintval($_GET['jfid']);
	$jinfo = C::t('#'.$jn.'#'.$jn.'_farm')->jinfo($jfid,$_G['uid']);
	if(!$jinfo['jfid']){
		$linkgen = lang("plugin/$jn","s043");
		include template($jn.':'.$jn.'_ajax_plain');
		exit;
		
	}
	if($_GET['formhash'] == $_G['formhash']){
		$jinfo['fdata'] = json_decode($jinfo['fdata'],true);
		$jinfo['fdata']['seed'] = '0';
		$jinfo['fdata']['prodstart'] = '0';
		$jinfo['fdata']['prodfinish'] = '0';
		$jinfo['fdata']['qtyleft'] = '0';
		$jinfo['fdata']['water'] = 0;
		$jinfo['fdata']['worm'] = 0;
		$jinfo['fdata']['weed'] = 0;
		
		$thislang = lang("plugin/$jn","s066",array('jfid'=>$jfid));//"��ũ��ID $jfid ���г���";
		nlog($_G['uid'],3,$_G['timestamp'],$thislang);
		
		$jinfo['fdata'] = json_encode($jinfo['fdata']);
		C::t('#'.$jn.'#'.$jn.'_farm')->update($jinfo['jfid'],array('fdata'=>$jinfo['fdata']));
		$linkgen = '<font color="red">'.lang("plugin/$jn","s044").'</font><script>ajaxget("plugin.php?id='.$jn.'&do=ajax&ac=updatejfid&jfid='.$jfid.'&timestamp='.$_G['timestamp'].'&jhash='.$pass.'","jfid'.$jfid.'");ajaxget("plugin.php?id='.$jn.'&do=ajax&ac=updatejrid&jfid='.$jfid.'&timestamp='.$_G['timestamp'].'&jhash='.$pass.'","jrid'.$jfid.'");</script>';
	}
}
if($_GET['ac'] == 'putseed'){
	//��������div
	$jfid = daddslashes($_GET['jfid']);
	if($_GET['upgrade'] == 'true'){
		if(!discuz_process::islocked('update_jnfarm'.$_G['uid'])) {
			if($_GET['formhash'] == $_G['formhash']){
				if($userinfo['udata']['data']['money'] >= $sysinfo['setdata']['hongtucost']){
					$jinfo = C::t('#'.$jn.'#'.$jn.'_land')->jinfo($_G['uid']);
					if(!$jinfo['jfid']){
						discuz_process::unlock('update_jnfarm'.$_G['uid']);
						showmessage("$jn:o003");
					}
					$jinfo['fdata'] = json_decode($jinfo['fdata'],true);
					$jinfo['fdata'][$jfid]['type'] = '2';
					
					$jinfo['fdata'] = json_encode($jinfo['fdata']);
					C::t('#'.$jn.'#'.$jn.'_land')->update($jinfo['jfid'],array("fdata"=>$jinfo['fdata']));
					
					if($directextcreditson == '1'){
						$cdd['extcredits'.$jnc['buyext']] = '-'.$sysinfo['setdata']['hongtucost'];
						updatemembercount($_G['uid'], $cdd, true, '', 0, '',$jnc['title'],lang("plugin/$jn","s175"));
						$cdd = array();
					}
					$userinfo['udata']['data']['money'] = $userinfo['udata']['data']['money']-$sysinfo['setdata']['hongtucost'];
					if($directextcreditson == '1'){
						$userinfo['udata']['data']['money'] = 0;
					}
					$userinfo['udata'] = json_encode($userinfo['udata']);
					C::t('#'.$jn.'#'.$jn.'_user')->update($userinfo['juid'],array("udata"=>$userinfo['udata']));
					
					$linkgen = '<script>ajaxget(\'plugin.php?id='.$jn.'&do=normal&ac=userinfo&timestamp='.$_G['timestamp'].'&jhash='.$pass.'\',\'userinfo\');ajaxget(\'plugin.php?id='.$jn.'&do=normal&ac=updateland&formhash='.$_G['formhash'].'&timestamp='.$_G['timestamp'].'&jhash='.$pass.'\',\'jnland\');layer.msg(\''.lang("plugin/$jn","s076").'\')</script>';
				}else{
					$linkgen = '<script>layer.closeAll();layer.msg(\''.$jnc['mt'].lang("plugin/$jn","s031").'\')</script>';
				}
				discuz_process::unlock('update_jnfarm'.$_G['uid']);
				include template($jn.':'.$jn.'_normal');
				exit;
			}
		}
	}
	$bagseed = count($userinfo['udata']['seed']);
	for($x = 1;$x <= $bagseed; $x++){
		$patterns = array();
		$string = $userinfo['udata']['seed'][$x][1];
		$string = str_split($string);
		$cst = count($string);
		for($y = 0;$y < $cst; $y++){
			$patterns[$y] = '<img src="'.$imgurl.$string[$y].'.png" style="width:0.8em;">';
		}
		$wording = implode('',$patterns);
		
		//�����Ǳ���������ص�����
		if($userinfo['udata']['seed'][$x][1] > 0){
			if($vipon == '1'){
				if($vipon == '1' && $userinfo['vipexpired'] > $_G['timestamp']){
					$action = ' onclick="layer.closeAll();ajaxget(\'plugin.php?id='.$jn.'&do=vip&ac=fastputseed&formhash='.$_G['formhash'].'&timestamp='.$_G['timestamp'].'&jfid='.$jfid.'&seed='.$userinfo['udata']['seed'][$x][0].'\',\'ok\');"';
				}else{
					$action = ' onclick="layer.msg(\''.lang("plugin/$jn","s278").'\');"';
				}
				$vipword = '<div style="position:absolute;"><a style="padding:0.1em 0.5em; border-radius:0.5em; background: rgb(15,76,129,0.8); color:yellow; text-shadow: 1px 1px 3px black;text-decoration:none;" '.$action.' href="javascript:;">'.lang("plugin/$jn","s279").'</a></div>';
			}
			$text = $text.'<div style="width:33%; display:inline-block;" align="center"><div style="float:left; background: white; ; padding:0.5em; box-shadow:0px 0px 10px rgb(0,0,0,0.1); border-radius:10px; position:relative; margin-right:1em; margin-bottom:1em;">'.$vipword.'<a href="javascript:;" onclick="ajaxget(\'plugin.php?id='.$jn.'&do=plantseed&seed='.$userinfo['udata']['seed'][$x][0].'&jfid='.$jfid.'&formhash='.$_G['formhash'].'&timestamp='.$_G['timestamp'].'&jhash='.$pass.'\',\'theuns\');"><img src="'.$imgurl.$sdlist[$userinfo['udata']['seed'][$x][0]]['sdata']['seedurl'].'" style="width:100%;" id="oooo"></a><br><a href="javascript:;" onclick="ajaxget(\'plugin.php?id='.$jn.'&do=plantseed&seed='.$userinfo['udata']['seed'][$x][0].'&jfid='.$jfid.'&formhash='.$_G['formhash'].'&timestamp='.$_G['timestamp'].'&jhash='.$pass.'\',\'theuns\');">'.$sdlist[$userinfo['udata']['seed'][$x][0]]['stitle'].lang("plugin/$jn","s038").'</a><div style="position:absolute;right:0.5em;bottom:2em;">'.$wording.'</div></div></div>';
		}
		
	}
	include template($jn.':'.$jn.'_normal');
	exit;
}
if($_GET['ac'] == 'updateland' || $_GET['ac'] == 'userinfo'){
	include template($jn.':'.$jn.'_normal');
	exit;
}
if($_GET['ac'] == 'thisfarm'){
	$jfid = dintval($_GET['jfid']);
	$jinfo = C::t('#'.$jn.'#'.$jn.'_land')->jinfo($_G['uid']);
	if(!$jinfo['jfid']){
		showmessage("$jn:o003");
	}
	$jinfo['fdata'] = json_decode($jinfo['fdata'],true);
	if($_GET['eradicate'] == 'true' && $_GET['formhash'] == $_G['formhash']){
		if($jinfo['fdata'][$jfid]['seed'] > 0){
			$jinfo['fdata'][$jfid]['seed'] = 0;
			$jinfo['fdata'][$jfid]['prodstart'] = 0;
			$jinfo['fdata'][$jfid]['prodfinish'] = 0;
			$jinfo['fdata'][$jfid]['expired'] = 0;
			$jinfo['fdata'][$jfid]['qtyleft'] = 0;
			$jinfo['fdata'][$jfid]['oriqty'] = 0;
			$jinfo['fdata'][$jfid]['lastsituation'] = 0;
			$jinfo['fdata'] = json_encode($jinfo['fdata']);
			C::t('#'.$jn.'#'.$jn.'_land')->update($jinfo['jfid'],array('fdata'=>$jinfo['fdata']));
			$linkgen = '<script>ajaxget(\'plugin.php?id='.$jn.'&do=normal&ac=updateland&formhash='.$_G['formhash'].'&timestamp='.$_G['timestamp'].'&jhash='.$pass.'\',\'jnland\')</script>';//����Ҫ���� �������صĸ��� 
			include template($jn.':'.$jn.'_normal');
			exit;
		}else{
			exit;
		}
		
	}
	
	$lefttime = $jinfo['fdata'][$jfid]['prodfinish'] - $_G['timestamp'];
	if($lefttime > 0){
		$step = '1';
		$jmsg = date("Y-m-d H:i:s",$jinfo['fdata'][$jfid]['prodfinish']).lang("plugin/$jn","s078");
	}else{
		$step = '2';
		$jmsg = date("Y-m-d H:i:s",$jinfo['fdata'][$jfid]['expired']).lang("plugin/$jn","s079");
	}
	if($_G['timestamp'] > $jinfo['fdata'][$jfid]['expired']){
		$jinfo['fdata'][$jfid]['qtyleft'] = '0';
		$jinfo['fdata'][$jfid]['oriqty'] = '0';
		$step = '3';
		$jmsg = lang("plugin/$jn","s053");
	}
	if($jinfo['fdata'][$jfid]['worm'] > $_G['timestamp'] || $jinfo['fdata'][$jfid]['weed'] > $_G['timestamp'] || $jinfo['fdata'][$jfid]['water'] > $_G['timestamp']){
		$step = '4';
		if($jinfo['fdata'][$jfid]['worm'] > 0){
			$effect = '<a href="javascript:;" onclick="ajaxget(\'plugin.php?id='.$jn.'&do=normal&ac=worm&jfid='.$jfid.'&formhash='.$_G['formhash'].'&timestamp='.$_G['timestamp'].'\',\'theuns\');" style="color:yellow">'.lang("plugin/$jn","s074").$sysinfo['setdata']['wormcost'].$jnc['mt'].lang("plugin/$jn","s080").'</a>';
		}
		if($jinfo['fdata'][$jfid]['weed'] > 0){
			$effect = '<a href="javascript:;" onclick="ajaxget(\'plugin.php?id='.$jn.'&do=normal&ac=weed&jfid='.$jfid.'&formhash='.$_G['formhash'].'&timestamp='.$_G['timestamp'].'\',\'theuns\');" style="color:yellow">'.lang("plugin/$jn","s074").$sysinfo['setdata']['weedcost'].$jnc['mt'].lang("plugin/$jn","s081").'</a>';
		}
		if($jinfo['fdata'][$jfid]['water'] > 0){
			$effect = '<a href="javascript:;" onclick="ajaxget(\'plugin.php?id='.$jn.'&do=normal&ac=water&jfid='.$jfid.'&formhash='.$_G['formhash'].'&timestamp='.$_G['timestamp'].'\',\'theuns\');" style="color:yellow">'.lang("plugin/$jn","s074").$sysinfo['setdata']['watercost'].$jnc['mt'].lang("plugin/$jn","s082").'</a>';
		}
	}
	//����
	
	$cfer = count($userinfo['udata']['fertilize']);
	for($x=1;$x<=$cfer;$x++){
		if($userinfo['udata']['fertilize'][$x][1] > 0){
			if($vipon == '1'){
				if($vipon == '1' && $userinfo['vipexpired'] > $_G['timestamp']){
					$vipfert = '<a href="javascript:;" onclick="ajaxget(\'plugin.php?id='.$jn.'&do=vip&ac=fastfert&formhash='.$_G['formhash'].'&timestamp='.$_G['timestamp'].'&jfid='.$jfid.'&feid='.$userinfo['udata']['fertilize'][$x][0].'\',\'ok\');" class="layui-btn layui-btn-xs layui-btn-danger" style="margin-bottom:0.2em;">'.lang("plugin/$jn","s280").'</a>';
				}else{
					$vipfert = '<a href="javascript:;" onclick="layer.msg(\''.lang("plugin/$jn","s278").'\');" class="layui-btn layui-btn-xs layui-btn-danger" style="margin-bottom:0.2em;">'.lang("plugin/$jn","s280").'</a>';
				}
			}
			$thisf[$x] = '<a href="javascript:;" onclick="ajaxget(\'plugin.php?id='.$jn.'&do=usefertilize&jfid='.$jfid.'&feid='.$userinfo['udata']['fertilize'][$x][0].'&formhash='.$_G['formhash'].'&timestamp='.$_G['timestamp'].'&jhash='.$pass.'\',\'thisfarm'.$jfid.'\');"><font color="yellow">'.$felist[$userinfo['udata']['fertilize'][$x][0]]['stitle'].'<font style="font-size:0.9em">('.$userinfo['udata']['fertilize'][$x][1].')</font></font></a> '.$vipfert;
		}
	}
	if($step == '3'){
		$thisimg = 'kuwei.png';
	}else{
		$thisimg = $sdlist[$jinfo['fdata'][$jfid]['seed']]['sdata']['imgurl'];
	}
	$thisf = implode('<br> ',$thisf);
	include template($jn.':'.$jn.'_normal');
	exit;
	//���ص�ǰ��Ϣ
}
if($_GET['ac'] == 'thisfriend'){
	$jfid = dintval($_GET['jfid']);
	$friendid = dintval($_GET['friendid']);
	if($friendid == $_G['uid']){
		showmessage("$jn:s023");//�����û��Ըı���
	}
	if($jnc['friend'] == '1'){
		$fhome = DB::fetch_all("SELECT * FROM ".DB::table('home_friend')." WHERE uid = '".$_G['uid']."' AND fuid = '$friendid'");
		if(!$fhome){
			showmessage("$jn:s024");//�����û��Ըı���
		}
	}
	$finfo = C::t('#'.$jn.'#'.$jn.'_user')->userinfo($friendid);
	$finfo['udata'] = json_decode($finfo['udata'],true);
	$jinfo = C::t('#'.$jn.'#'.$jn.'_land')->jinfo($friendid);
	if(!$jinfo['jfid']){
		showmessage("$jn:o003");
	}
	$jinfo['fdata'] = json_decode($jinfo['fdata'],true);
	if($_GET['thief'] == 'true' && $_GET['formhash'] == $_G['formhash']){
		$userinfo['udata']['data']['tili'][0] = tilicheck($_G['uid'],$sysinfo['setdata']['tilihuifu'],$_G['timestamp']);
		if($userinfo['udata']['data']['tili'][0] <= '0'){
			$linkgen = '<script>layer.msg(\''.lang("plugin/$jn","s140").'\');</script>';
			include template($jn.':'.$jn.'_normal_plain');
			exit;
		}
		if($jinfo['fdata'][$jfid]['expired'] < $_G['timestamp']){
			$linkgen = '<script>ajaxget(\'plugin.php?id='.$jn.'&do=neighbours&updateland=true&friendid='.$friendid.'&formhash='.$_G['formhash'].'&timestamp='.$_G['timestamp'].'&jhash='.$pass.'\',\'jnland\');layer.msg(\''.lang("plugin/$jn","s025").'\');</script>';
			include template($jn.':'.$jn.'_normal_plain');
			exit;
		}
		
		$jthis = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_land')." WHERE uid = '$friendid'");
		$jthis['fdata'] = json_decode($jthis['fdata'],true);
		
		if(in_array($_G['uid'],$jthis['fdata'][$jfid]['thief'])){
			$linkgen = '<script>ajaxget(\'plugin.php?id='.$jn.'&do=neighbours&updateland=true&friendid='.$friendid.'&formhash='.$_G['formhash'].'&timestamp='.$_G['timestamp'].'&jhash='.$pass.'\',\'jnland\');layer.msg(\''.lang("plugin/$jn","s141").'\')</script>';
			include template($jn.':'.$jn.'_normal_plain');
			exit;
		}
		
		if($jthis['fdata'][$jfid]['expired'] < $_G['timestamp']){
			$linkgen = '<script>ajaxget(\'plugin.php?id='.$jn.'&do=neighbours&updateland=true&friendid='.$friendid.'&formhash='.$_G['formhash'].'&timestamp='.$_G['timestamp'].'&jhash='.$pass.'\',\'jnland\');layer.msg(\''.lang("plugin/$jn","s025").'\')</script>';
			include template($jn.':'.$jn.'_ajax_plain');
			exit;
		}
		if($jthis['fdata'][$jfid]['qtyleft'] < ceil($jthis['fdata'][$jfid]['oriqty']*0.01*$sysinfo['setdata']['thiefqtymin'])){
			$linkgen = '<script>ajaxget(\'plugin.php?id='.$jn.'&do=neighbours&updateland=true&friendid='.$friendid.'&formhash='.$_G['formhash'].'&timestamp='.$_G['timestamp'].'&jhash='.$pass.'\',\'jnland\');layer.msg(\''.lang("plugin/$jn","s026").'\')</script>';
			include template($jn.':'.$jn.'_ajax_plain');
			exit;
		}
		if($jthis['fdata'][$jfid]['prodfinish'] > $_G['timestamp']){
			$linkgen = '<script>ajaxget(\'plugin.php?id='.$jn.'&do=neighbours&updateland=true&friendid='.$friendid.'&formhash='.$_G['formhash'].'&timestamp='.$_G['timestamp'].'&jhash='.$pass.'\',\'jnland\');layer.msg(\''.lang("plugin/$jn","s027").'\')</script>';
			include template($jn.':'.$jn.'_ajax_plain');
			exit;
		}
		
		$userinfo['dailyquest'] = json_decode($userinfo['dailyquest'],true);
		$userinfo['dailyquest']['toucai'] = $userinfo['dailyquest']['toucai']+1;
		//20200506 ����Ƿ��г���
		if($finfo['udata']['petdata']['nowpet'] > 0 && $finfo['udata']['petdata']['petexpired'] > $_G['timestamp']){
			$friendname = DB::fetch_first("SELECT username FROM ".DB::table('game_jnfarm_user')." WHERE uid = '".$friendid."'");
			$petlist = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_pet')." WHERE jpid = '".$finfo['udata']['petdata']['nowpet']."'");
			$petlist['jpdata'] = json_decode($petlist['jpdata'],true);
			$change = mt_rand(1,100);
			
			if($change <= $petlist['jpdata']['attack']){
				//͵ȡʧ��
				$oriuser = $userinfo['udata']['data']['money'];
				if($directextcreditson == '1'){
					$cdd['extcredits'.$jnc['buyext']] = '-'.$petlist['jpdata']['lostcoin'];
					updatemembercount($_G['uid'], $cdd, true, '', 0, '',$jnc['title'],lang("plugin/$jn","s176"));
					$cdd = array();
				}
				$userinfo['udata']['data']['money'] = $userinfo['udata']['data']['money']-$petlist['jpdata']['lostcoin'];
				
				if($directextcreditson == '1'){
					$userinfo['udata']['data']['money'] = 0;
				}
				$udata = json_encode($userinfo['udata'],true);
				$dailyquest = json_encode($userinfo['dailyquest']);
				
				
				$orifriend = $finfo['udata']['data']['money'];
				if($directextcreditson == '1'){
					//$money = DB::fetch_first("SELECT * FROM ".DB::table('common_member_count')." WHERE uid = '$friendid'");
					$cdd['extcredits'.$jnc['buyext']] = '+'.$petlist['jpdata']['lostcoin'];
					updatemembercount($friendid, $cdd, true, '', 0, '',$jnc['title'],lang("plugin/$jn","s177"));
					$cdd = array();
				}
				$finfo['udata']['data']['money'] = $finfo['udata']['data']['money']+$petlist['jpdata']['lostcoin'];
				if($directextcreditson == '1'){
					$finfo['udata']['data']['money'] = 0;
				}
				
				$newlang = lang("plugin/$jn","s151",array('Gusername'=>$_G['username'],'lostcoin'=>$petlist['jpdata']['lostcoin'],'jncmt'=>$jnc['mt'],'oriuser'=>$oriuser,'money'=>$userinfo['udata']['data']['money'])).$friendname['username'].' '.$orifriend.'->'.$finfo['udata']['data']['money'];
				//$newlang = '͵ȡʧ��, '.$_G['username'].'��ʧ��'.$petlist['jpdata']['lostcoin'].$jnc['mt'].' '.$oriuser.'->'.$userinfo['udata']['data']['money'].' ��������'.$username[$friendid]['username'].' '.$orifriend.'->'.$finfo['udata']['data']['money'];
				nlog($_G['uid'],8,$_G['timestamp'],$newlang);//�������
				
				$fdata = json_encode($finfo['udata'],true);
				
				C::t('#'.$jn.'#'.$jn.'_user')->update($userinfo['juid'],array('udata'=>$udata,'dailyquest'=>$dailyquest));
				C::t('#'.$jn.'#'.$jn.'_user')->update($finfo['juid'],array('udata'=>$fdata));
				//͵ȡʧ��
				if($magappon == '1'){
					MagPushthief($friendid,$_G['username'],2,$petlist['jpdata']['lostcoin'],$jnc['mt']);
				}
				if($qianfanappon == '1'){
					$joinword = lang("plugin/$jn","s158",array('thiefusername'=>$_G['username'])).$petlist['jpdata']['lostcoin'].$jnc['mt'];
					
					$jnc['title'] = iconv($_G['charset'],'UTF-8',$jnc['title']);
					$joinword = iconv($_G['charset'],'UTF-8',$joinword);
					$client->post('pushes/'.$friendid.'/single', array('title' =>$jnc['title'],'content'=>$joinword,'target_type'=>50,'target_value'=>'plugin.php?id=jnfarm','show_alert'=>1));
					//$client->post('pushes/'.$friendid.'/single', ['title' =>$jnc['title'],'content'=>$joinword,'target_type'=>50,'target_value'=>'plugin.php?id=jnfarm','show_alert'=>1]);
				}
				
				$returnlang = lang("plugin/$jn","s152").$petlist['jpdata']['lostcoin'].$jnc['mt'];
				$linkgen = '<script>ajaxget(\'plugin.php?id='.$jn.'&do=neighbours&updateland=true&friendid='.$friendid.'&formhash='.$_G['formhash'].'&timestamp='.$_G['timestamp'].'&jhash='.$pass.'\',\'jnland\');layer.msg(\''.$returnlang.'\')</script>';
				include template($jn.':'.$jn.'_normal_plain');
				exit;
			}
		}
		$addonqty = 0;
		if($vipon == '1'){
			$vrand = mt_rand(1,100);
			if($vrand <= $sysinfo['setdata']['vip']['thiefpercent']){
				$addonqty = $sysinfo['setdata']['vip']['thiefqty'];
			}
		}
		$thisrand = mt_rand($sysinfo['setdata']['thiefqty'][0],$sysinfo['setdata']['thiefqty'][1])+$addonqty;
		$jthis['fdata'][$jfid]['qtyleft'] = $jthis['fdata'][$jfid]['qtyleft']-$thisrand;
		
		//����Լ��ı���������û���Ǹ�����
		$cprod = count($userinfo['udata']['prod']);
		for($x = 1; $x <= $cprod; $x++){
			if($userinfo['udata']['prod'][$x][0] == $jthis['fdata'][$jfid]['seed']){
				$ori = $userinfo['udata']['prod'][$x][1];
				$userinfo['udata']['prod'][$x][1] = $userinfo['udata']['prod'][$x][1]+$thisrand;
				$after = $userinfo['udata']['prod'][$x][1];
				$ok = '1';
			}
		}
		if(!$ok){
			//replace
			$ori = '0';
			$userinfo['udata']['prod'][$x][0] = $jthis['fdata'][$jfid]['seed'];
			$userinfo['udata']['prod'][$x][1] = $thisrand;
			$after = $thisrand;
		}
		if(!$jthis['fdata'][$jfid]['thief']){
			$jthis['fdata'][$jfid]['thief'][0] = $_G['uid'];
		}else{
			$tc = count($jthis['fdata'][$jfid]['thief']);
			$jthis['fdata'][$jfid]['thief'][$tc] = $_G['uid'];
		}
		
		$note = lang("plugin/$jn","s028",array('username'=>$_G['username'],'thisrand'=>$thisrand,'sdlistjthis'=>$sdlist[$jthis['fdata'][$jfid]['seed']]['stitle']));//'����'.$_G['username'].'͵����'.$thisrand.$sdlist[$jthis['fdata']['seed']]['stitle'];
		if($jnc['notificationonoff'] == '1'){
			notification_add($friendid, 'myapp', $note, '', 0);
		}
		
		
		$thislang = lang("plugin/$jn","s063",array('jfid'=>$jfid,'thisrand'=>$thisrand,'sdlistjthis'=>$sdlist[$jthis['fdata'][$jfid]['seed']]['stitle'],'ori'=>$ori,'after'=>$after));//"͵��ũ��ID".$jfid.$thisrand.$sdlist[$jthis['fdata']['seed']]['stitle']."���� ".$ori."->".$after;
		nlog($_G['uid'],3,$_G['timestamp'],$thislang);
		
		$newlang = lang("plugin/$jn","s142",array('Gusername'=>$_G['username'],'thisrand'=>$thisrand,'sdlistjthis'=>$sdlist[$jthis['fdata'][$jfid]['seed']]['stitle'],'jfidqtyleft'=>$jthis['fdata'][$jfid]['qtyleft']));//;$_G['username'].'͵����ũ���'.$thisrand.'��'.$sdlist[$jthis['fdata'][$jfid]['seed']]['stitle'].'��ǰũ��������ʣ��'.$jthis['fdata'][$jfid]['qtyleft'].'��';
		nlog($friendid,3,$_G['timestamp'],$newlang);
		
		$jthis['fdata'] = json_encode($jthis['fdata'],true);
		C::t('#'.$jn.'#'.$jn.'_land')->update($jthis['jfid'],array('fdata'=>$jthis['fdata']));
		
		$userinfo['udata']['data']['tili'][0] = $userinfo['udata']['data']['tili'][0]-1;
		$userinfo['udata']['thiefrecord'][0] = $userinfo['udata']['thiefrecord'][0]+1;
		$userinfo['udata'] = json_encode($userinfo['udata'],true);
		$dailyquest = json_encode($userinfo['dailyquest']);
		C::t('#'.$jn.'#'.$jn.'_user')->update($userinfo['juid'],array('udata'=>$userinfo['udata'],'dailyquest'=>$dailyquest));
		
		if($magappon == '1'){
			MagPushthief($friendid,$_G['username'],1);
		}
		if($qianfanappon == '1'){
			$joinword = lang("plugin/$jn","s157",array('thiefusername'=>$_G['username'])).'...';
			
			$jnc['title'] = iconv($_G['charset'],'UTF-8',$jnc['title']);
			$joinword = iconv($_G['charset'],'UTF-8',$joinword);

			$client->post('pushes/'.$friendid.'/single', array('title' =>$jnc['title'],'content'=>$joinword,'target_type'=>50,'target_value'=>'plugin.php?id=jnfarm','show_alert'=>1));
			//$client->post('pushes/'.$friendid.'/single', ['title' =>$jnc['title'],'content'=>$joinword,'target_type'=>50,'target_value'=>'plugin.php?id=jnfarm','show_alert'=>1]);
		}
		$linkgen = '<script>ajaxget(\'plugin.php?id='.$jn.'&do=neighbours&updateland=true&friendid='.$friendid.'&formhash='.$_G['formhash'].'&timestamp='.$_G['timestamp'].'&jhash='.$pass.'\',\'jnland\');layer.msg(\''.lang("plugin/$jn","s029").$thisrand.'\')</script>';
		include template($jn.':'.$jn.'_normal_plain');
		exit;
	}
	
	$lefttime = $jinfo['fdata'][$jfid]['prodfinish'] - $_G['timestamp'];
	if($lefttime > 0){
		$step = '1';
		$jmsg = date("Y-m-d H:i:s",$jinfo['fdata'][$jfid]['prodfinish']).lang("plugin/$jn","s078");
	}else{
		$step = '2';
		$jmsg = date("Y-m-d H:i:s",$jinfo['fdata'][$jfid]['expired']).lang("plugin/$jn","s079");
	}
	if($_G['timestamp'] > $jinfo['fdata'][$jfid]['expired']){
		$jinfo['fdata'][$jfid]['qtyleft'] = '0';
		$jinfo['fdata'][$jfid]['oriqty'] = '0';
		$sdlist[$jinfo['fdata'][$jfid]['seed']]['sdata']['imgurl'] = 'kuwei.png';
		$step = '3';
		$jmsg = lang("plugin/$jn","s053");
	}
	if($jinfo['fdata'][$jfid]['worm'] > $_G['timestamp'] || $jinfo['fdata'][$jfid]['weed'] > $_G['timestamp'] || $jinfo['fdata'][$jfid]['water'] > $_G['timestamp']){
		$step = '4';
		if($jinfo['fdata'][$jfid]['worm'] > 0){
			$effect = '<a href="javascript:;" onclick="ajaxget(\'plugin.php?id='.$jn.'&do=normal&ac=worm&friendid='.$friendid.'&helpfriend=true&jfid='.$jfid.'&formhash='.$_G['formhash'].'&timestamp='.$_G['timestamp'].'&jhash='.$pass.'\',\'theuns\');" style="color:yellow">'.lang("plugin/$jn","s074").$sysinfo['setdata']['wormcost'].$jnc[mt].lang("plugin/$jn","s080").'</a>';
		}
		if($jinfo['fdata'][$jfid]['weed'] > 0){
			$effect = '<a href="javascript:;" onclick="ajaxget(\'plugin.php?id='.$jn.'&do=normal&ac=weed&friendid='.$friendid.'&helpfriend=true&jfid='.$jfid.'&formhash='.$_G['formhash'].'&timestamp='.$_G['timestamp'].'&jhash='.$pass.'\',\'theuns\');" style="color:yellow">'.lang("plugin/$jn","s074").$sysinfo['setdata']['weedcost'].$jnc[mt].lang("plugin/$jn","s081").'</a>';
		}
		if($jinfo['fdata'][$jfid]['water'] > 0){
			$effect = '<a href="javascript:;" onclick="ajaxget(\'plugin.php?id='.$jn.'&do=normal&ac=water&friendid='.$friendid.'&helpfriend=true&jfid='.$jfid.'&formhash='.$_G['formhash'].'&timestamp='.$_G['timestamp'].'&jhash='.$pass.'\',\'theuns\');" style="color:yellow">'.lang("plugin/$jn","s074").$sysinfo['setdata']['watercost'].$jnc[mt].lang("plugin/$jn","s082").'</a>';
		}
	}
	
	include template($jn.':'.$jn.'_normal');
	exit;
	//���ص�ǰ��Ϣ
}
if($_GET['ac'] == 'topup'){
	if($jnc['topuprecord'] == '1'){
		$topup = DB::fetch_all("SELECT * FROM ".DB::table('game_jnfarm_log')." WHERE uid = '".$_G['uid']."' AND acdo = 2 ORDER BY createtime DESC LIMIT ".$jnc['topuplist']." ");
	}else{
		$topup = DB::fetch_all("SELECT t1.*,t2.username FROM ".DB::table('game_jnfarm_log')." t1 LEFT JOIN ".DB::table('game_jnfarm_user')." t2 ON (t1.uid = t2.uid) WHERE t1.uid = '".$_G['uid']."' AND t1.acdo = 2 ORDER BY t1.createtime DESC LIMIT ".$jnc['topuplist']." ");
		$tt = 1;
	}
	foreach($topup as $tp){
		if($tt == '1'){
			$tp['username'] = $tp['username'];
		}
		$tp['createtime'] = date("m-d H:i",$tp['createtime']);
		$tplist[] = $tp;
	}
	include template($jn.':'.$jn.'_normal');
	exit;
}
if($_GET['ac'] == 'cashout'){
	$cashout = DB::fetch_all("SELECT * FROM ".DB::table('game_jnfarm_log')." WHERE uid = '".$_G['uid']."' AND acdo = 6 ORDER BY createtime DESC LIMIT ".$jnc['cashlist']." ");
	foreach($cashout as $co){
		$co['createtime'] = date("m-d H:i",$co['createtime']);
		$colist[] = $co;
	}
	include template($jn.':'.$jn.'_normal');
	exit;
}
if($_GET['ac'] == 'plantseed'){
	$jfid = dintval($_GET['jfid']);
	$seedid = dintval($_GET['seed']);
	$jinfo = C::t('#'.$jn.'#'.$jn.'_farm')->jinfo($_G['uid']);
	if(!$jinfo['jfid']){
		//showmessage('û���������');
		$linkgen = lang("plugin/$jn","s043");
		include template($jn.':'.$jn.'_ajax_plain');
		exit;
		
	}
	$jinfo['fdata'] = json_decode($jinfo['fdata'],true);
	if($jinfo['fdata'][$jfid]['seed'] > '0'){
		showmessage("$jn:s048");
	}
	$count = count($userinfo['udata']['seed']);
	for($x = 1;$x <= $count; $x++){
		if(!$ss){
			if($userinfo['udata']['seed'][$x][0] == $seedid){
				$oriseed = $userinfo['udata']['seed'][$x][1];
				$userinfo['udata']['seed'][$x][1] = $userinfo['udata']['seed'][$x][1]-1;
				$afterseed = $userinfo['udata']['seed'][$x][1];
				$ss = '1';
				break;
			}
		}
	}
	if(!$ss){
		showmessage("$jn:s049");//���������û������Ըı�����ֱ�ӷ��ش����ü�������
	}
	//$seedinfo
	$jinfo['fdata'][$jfid]['seed'] = $seedid;
	$jinfo['fdata'][$jfid]['prodstart'] = $_G['timestamp'];
	$jimat = 1;
	if($jinfo['fdata'][$jfid]['type'] == '2'){
		$jimat = 0.9;
	}
	$jinfo['fdata'][$jfid]['prodfinish'] = $_G['timestamp']+($sdlist[$seedid]['sdata']['ctime']*$jimat);
	$jinfo['fdata'][$jfid]['expired'] = $jinfo['fdata']['prodfinish']+($sdlist[$seedid]['sdata']['ctime']);
	$jinfo['fdata'][$jfid]['qtyleft'] = mt_rand($sdlist[$seedid]['sdata']['hqty'][0],$sdlist[$seedid]['sdata']['hqty'][1]);
	$jinfo['fdata'][$jfid]['oriqty'] = $jinfo['fdata']['qtyleft'];
	
	$thislang = lang("plugin/$jn","s069",array('jfid'=>$jfid,'sdlistseedid'=>$sdlist[$seedid]['stitle']))." ".$oriseed."->".$afterseed;//"ũ��ID $jfid ��ֲ��".$sdlist[$seedid]['stitle']." �ֿ�����ʣ�� ".$oriseed."->".$afterseed;
	nlog($_G['uid'],3,$_G['timestamp'],$thislang);
	
	$jinfo['fdata'] = json_encode($jinfo['fdata']);
	
	$userinfo['udata'] = json_encode($userinfo['udata']);
	C::t('#'.$jn.'#'.$jn.'_user')->update($userinfo['juid'],array('udata'=>$userinfo['udata']));
	
	C::t('#'.$jn.'#'.$jn.'_farm')->update($jinfo['jfid'],array('fdata'=>$jinfo['fdata']));

	$linkgen = '<script>ajaxget(\'plugin.php?id='.$jn.'&do=normal&ac=updateland&formhash='.$_G['formhash'].'&timestamp='.$_G['timestamp'].'&jhash='.$pass.'\',\'jnland\')</script>';//����Ҫ���� �������صĸ��� 
	include template($jn.':'.$jn.'_normal');
	exit;
}
include template($jn.':'.$jn.'_normal');
exit;
?>