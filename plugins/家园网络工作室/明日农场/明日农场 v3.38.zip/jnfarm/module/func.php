<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined ('IN_DISCUZ')) {
	exit ('Access Denied');
}
/*function dshowmessage($message, $url_forward = '', $values = array(), $extraparam = array(), $custom = 0) {
	
}*/
global $_G;
function jnm($scriptlang){
	global $jn;
	return lang("plugin/$jn","$scriptlang");
}
function getjnuser($uid){
	global $_G; global $jnc;
	$userinfo = C::t('#jnfarm#jnfarm_user')->userinfo($uid);
	$userinfo['udata'] = json_decode($userinfo['udata'],true);
	$userinfo['realland'] = json_decode($userinfo['realland'],true);
	return $userinfo;
}
function bagadd($type,$qty,$jsid,$uid){//���ӵ��߽��ֿ�
	$ok = 0;
	$userinfo = C::t('#jnfarm#jnfarm_user')->userinfo($uid);
	$userinfo['udata'] = json_decode($userinfo['udata'],true);
	$c = count($userinfo['udata'][$type]);
					
	for($x=1;$x<=$c;$x++){
		if($userinfo['udata'][$type][$x][0] == $jsid){
			$userinfo['udata'][$type][$x][1] = $userinfo['udata'][$type][$x][1]+$qty;
			$ok = 1;
			break;
		}
	}
	if($ok == 0){
		$userinfo['udata'][$type][$x][0] = $jsid;
		$userinfo['udata'][$type][$x][1] = $qty;
	}
	$usup['udata'] = json_encode($userinfo['udata']);
	C::t('#jnfarm#jnfarm_user')->update($userinfo['juid'],$usup);
}
function cardadd($type,$qty,$jcid,$uid,$cangku = 0){
	global $sysinfo; global $_G;
	if($type == 'suipian'){//��Ƭ�ͼ���Ƿ��Ѵ�������
		$usercard = C::t('#jnfarm#jnfarm_card_user')->getinfo($uid,$type,$jcid);
		if(!$usercard['jcuid']){
			//���ֿ��Ƿ����㹻λ��
			if($cangku == 1){
				$nosuccess = 1;
				return $nosuccess;
				//jnmsg('�ܱ�Ǹ, ��Ƭ�ֿ�����, ������');
			}
			$data['jcid'] = $jcid;
			$data['uid'] = $uid;
			$data['qty'] = $qty;
			$data['type'] = $type;
			C::t('#jnfarm#jnfarm_card_user')->insert($data);
		}else{
			$data['qty'] = $usercard['qty']+$qty;
			C::t('#jnfarm#jnfarm_card_user')->update($usercard['jcuid'],$data);
		}
	}
	if($type == 'card'){//��Ƭ���ֿ��Ƿ���λ��
		$cardinfo = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_card')." WHERE jcid = '".$jcid."'");
		if($cardinfo['jcid'] > 0){
			//���ֿ��Ƿ����㹻λ��
			if($cangku == 1){
				$nosuccess = 1;
				return $nosuccess;
				//jnmsg('�ܱ�Ǹ, ��Ƭ�ֿ�����, ������');
			}
			$cardinfo['cdata'] = json_decode($cardinfo['cdata'],true);
			
			$cdata['uid'] = $uid;
			$cdata['jcid'] = dintval($jcid);
			$cdata['type'] = 'card';
			$cdata['lvl'] = 1;
			$cdata['qty'] = 1;
			$cdata['nowhp'] = $sysinfo['setdata']['card']['hp'];
			$cdata['maxhp'] = $sysinfo['setdata']['card']['hp'];
			$cdata['basiczhanli'] = mt_rand($cardinfo['cdata']['basiczhanli'][0],$cardinfo['cdata']['basiczhanli'][1])+$cardinfo['cdata']['zhanli'];
			
			C::t('#jnfarm#jnfarm_card_user')->insert($cdata);
		}
	}
}
function jnmsg($word, $rt = 0,$xtrajs = '',$openlink = 0){
	global $_G;
	if($openlink == '1'){
		$layerpop = 'layer.open({
  type: 1,
  title: false,
  closeBtn: 0,
  shadeClose: true,
  skin: \'yourclass\',
  content: \'<div style="padding:1em; width:80%;">'.$word.'</div>\'
});';
	}else{
		if($rt == '1'){
			$closepop = 'layer.closeAll();';
			$layerword = 'layer.msg(\''.$word.'\');';
		}elseif($rt == '3'){
			$closepop = '';
			$layerword = 'layer.msg(\''.$word.'\');';
		}else{
			$closepop = 'layer.close(layer.index);';
			$layerword = 'layer.msg(\''.$word.'\');';
		}
	}
	
	$linkgen = '<script>'.$closepop.$layerword.$layerpop.$xtrajs.$_G['timestamp'].'</script>';
	include template('jnfarm:jnfarm_normal_plain');
	exit;
};
function jnpopmsg($word,$rt = 0){
	global $_G;
	$linkgen = diconv($word,$_G['charset'],'UTF-8');
	$final = array('final'=>$linkgen,'rt'=>$rt);
	echo json_encode($final);
	exit;
}
function fushu($qtycheck){
	$qtycheck = floor(abs($qtycheck));
	return $qtycheck;
}
function nlog($uid,$acdo,$timestamp,$logdesc){
	$data['uid'] = dintval($uid);
	$data['acdo'] = dintval($acdo);
	$data['createtime'] = dintval($timestamp);
	$data['logdesc'] = daddslashes($logdesc);
	C::t('#jnfarm#jnfarm_log')->insert($data);
	//return;
}
function expcheck($uid,$exp){
	$cexp = C::t('#jnfarm#jnfarm_user')->userinfo($uid);
	$cexp['udata'] = json_decode($cexp['udata'],true);
	
	$lvl = C::t('#jnfarm#jnfarm_level')->levelinfo();
	$lvl = array_column($lvl, null, 'lvl');
	$clvl = count($lvl);
	
	$ss = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_fset')." WHERE jfset = '1'");
	$ss['setdata'] = json_decode($ss['setdata'],true);
	if($ss['setdata']['maxlevel'] > 0){
		$maxlevel = $ss['setdata']['maxlevel'];
	}else{
		$maxlevel = 100;
	}
	if($cexp['udata']['data']['farmlvl'] >= $maxlevel){
		return;
	}
	for($x = 1; $x <= $clvl; $x++){
		if($cexp['udata']['data']['farmlvl'] == $x){//���ҵ�ǰ�ȼ�
			$expneed = $lvl[$x+1]['expneed'];
			if($cexp['udata']['data']['exp'] >= $expneed){
				$cexp['udata']['data']['farmlvl'] = $cexp['udata']['data']['farmlvl']+1;
				$cexp['udata']['data']['exp'] = $cexp['udata']['data']['exp']-$expneed;
				
				//v2.1 ����
				$fset = DB::fetch_first("SELECT setdata FROM ".DB::table('game_jnfarm_fset')." WHERE jfset = '1'");
				$fset['setdata'] = json_decode($fset['setdata'],true);
				$cexp['udata']['data']['tili'][1] = ($cexp['udata']['data']['farmlvl']*$fset['setdata']['leveltili'])+$fset['setdata']['newtili'];
				$cexp['udata']['data']['tili'][0] = $cexp['udata']['data']['tili'][1];//��������
				
				$cexp['udata'] = json_encode($cexp['udata'],true);
				C::t('#jnfarm#jnfarm_user')->update($cexp['juid'],array('udata'=>$cexp['udata']));
			}
		}
	}
}
function tilicheck($uid,$timeneed,$gtime){
	if(!$uid){
		exit;
	}
	$c = C::t('#jnfarm#jnfarm_user')->userinfo($uid);
	$c['udata'] = json_decode($c['udata'],true);
	
	if($c['udata']['data']['tili'][2]+$timeneed <= $gtime){//�����ǰ����С��
		$cishu = floor(($gtime-$c['udata']['data']['tili'][2])/$timeneed);
		//$c['udata']['data']['tili'][0] = $c['udata']['data']['tili'][0]+$cishu;
		if($c['udata']['data']['tili'][0]+$cishu >= $c['udata']['data']['tili'][1]){
			$c['udata']['data']['tili'][0] = $c['udata']['data']['tili'][1];
			$c['udata']['data']['tili'][2] = $gtime;
		}else{
			$c['udata']['data']['tili'][0] = $c['udata']['data']['tili'][0]+$cishu;
			$c['udata']['data']['tili'][2] = $c['udata']['data']['tili'][2]+($timeneed*$cishu);
		}
		$newc = $c['udata']['data']['tili'][0];
		$c['udata'] = json_encode($c['udata'],true);
		C::t('#jnfarm#jnfarm_user')->update($c['juid'],array('udata'=>$c['udata'],'lastsituation'=>$gtime));
	}else{
		$newc = $c['udata']['data']['tili'][0];
	}
	return $newc;
}
function dailyquest($uid,$questid){
	global $_G; global $jnc; global $jn; global $allist; global $sysinfo;
	//$success = 0;
	$cuser = C::t('#jnfarm#jnfarm_user')->userinfo($uid);
	$cuser['udata'] = json_decode($cuser['udata'],true);
	$cuser['dailyquest'] = json_decode($cuser['dailyquest'],true);
	if(in_array($questid,$cuser['dailyquest']['questid'])){
		//$wording = iconv($_G['charset'],'UTF-8',lang("plugin/$jn","s161"));//'��������ɸ�����';
		//return json_encode(['final'=>$wording]); exit;
		//showmessage('��������ɸ�����');//�������������Ϊͨ������ֱ������, reject
		$wording = lang("plugin/$jn","s161");
		return $wording;
	}
	$questinfo = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_dailyquest')." WHERE jdid = '".$questid."'");
	if($cuser['udata']['data']['farmlvl'] < $questinfo['minlvl']){
		$wording = lang("plugin/$jn","s162");//iconv($_G['charset'],'UTF-8',lang("plugin/$jn","s162"));//'�ȼ������޷����';
		return $wording;//json_encode(['final'=>$wording]); exit;
		exit;
		//showmessage('�ȼ������޷����');//reject
	}
	$questinfo['jddata'] = json_decode($questinfo['jddata'],true);
	$questinfo['jddata']['groupid'] = explode(',',$questinfo['jddata']['groupid']);
	if($questinfo['jddata']['groupid'][0] == '0' || !$questinfo['jddata']['groupid']){
		$nogroup = 1;
	}
	if($nogroup != '1'){
		if(!in_array($_G['groupid'],$questinfo['jddata']['groupid'])){
			$wording = lang("plugin/$jn","s200");//iconv($_G['charset'],'UTF-8',lang("plugin/$jn","s163"));//'δ�����ɵ�״̬Ӵ';
			return $wording;//json_encode(['final'=>$wording]); exit;
			exit;
		}
	}
	if($questinfo['jddata']['type'] == '2'){//����
		if($nogroup != '1'){
			if(!in_array($_G['groupid'],$questinfo['jddata']['groupid'])){
				$wording = lang("plugin/$jn","s200");//iconv($_G['charset'],'UTF-8',lang("plugin/$jn","s163"));//'δ�����ɵ�״̬Ӵ';
				return $wording;//json_encode(['final'=>$wording]); exit;
				exit;
			}
		}
		if($questinfo['jddata']['rules'] == '1'){
			if(!$cuser['dailyquest']['zhongzhi'] || $cuser['dailyquest']['zhongzhi'] < $questinfo['jddata']['rulesqty']){
				$wording = lang("plugin/$jn","s163");//iconv($_G['charset'],'UTF-8',lang("plugin/$jn","s163"));//'δ�����ɵ�״̬Ӵ';
				return $wording;//json_encode(['final'=>$wording]); exit;
				exit;
			}
		}
		if($questinfo['jddata']['rules'] == '2'){
			if(!$cuser['dailyquest']['shoucheng'] || $cuser['dailyquest']['shoucheng'] < $questinfo['jddata']['rulesqty']){
				$wording = lang("plugin/$jn","s163");//iconv($_G['charset'],'UTF-8',lang("plugin/$jn","s163"));//'δ�����ɵ�״̬Ӵ';
				return $wording;//json_encode(['final'=>$wording]); exit;
				exit;
			}
		}
		if($questinfo['jddata']['rules'] == '3'){
			if(!$cuser['dailyquest']['toucai'] || $cuser['dailyquest']['toucai'] < $questinfo['jddata']['rulesqty']){
				$wording = lang("plugin/$jn","s163");//iconv($_G['charset'],'UTF-8',lang("plugin/$jn","s163"));//'δ�����ɵ�״̬Ӵ';
				return $wording;//json_encode(['final'=>$wording]); exit;
				exit;
			}
		}
		if($questinfo['jddata']['rules'] == '4'){
			$todaytime = strtotime(date("Y-m-d",$_G['timestamp']));
			$count = DB::result_first("SELECT count(*) cnt FROM ".DB::table('forum_thread')." WHERE authorid = '".$uid."' AND dateline >= '".$todaytime."'");
			if($count < $questinfo['jddata']['rulesqty']){
				$wording = lang("plugin/$jn","s163");//iconv($_G['charset'],'UTF-8',lang("plugin/$jn","s163"));//'δ�����ɵ�״̬Ӵ';
				return $wording;//json_encode(['final'=>$wording]); exit;
				exit;
			}
		}
		if($questinfo['jddata']['rules'] == '5'){
			$todaytime = strtotime(date("Y-m-d",$_G['timestamp']));
			$count = DB::result_first("SELECT count(*) cnt FROM ".DB::table('forum_post')." WHERE authorid = '".$uid."' AND dateline >= '".$todaytime."'");
			if($count < $questinfo['jddata']['rulesqty']){
				$wording = lang("plugin/$jn","s163");//iconv($_G['charset'],'UTF-8',lang("plugin/$jn","s163"));//'δ�����ɵ�״̬Ӵ';
				return $wording;//json_encode(['final'=>$wording]); exit;
				exit;
			}
		}
	}
	//$success = 1;
	//��ѵĲ��ü��, ֱ�ӷ��Ž���
	$qtyadd = mt_rand($questinfo['jddata']['giftqtymin'],$questinfo['jddata']['giftqtymax']);
	if($questinfo['jddata']['gifttype'] == '1'){//���
		if($questinfo['jddata']['gtype1'] == '1'){//�������
			//����������������ù������Ӿͺ���, ����Ҫ��ѯ���ӿ�..
			$cseed = count($cuser['udata']['seed']);
			if($cseed <= 0){
				$cseed = 1;
			}
			$mtrand = mt_rand(1,$cseed);
			$qtyprevious = $cuser['udata']['seed'][$mtrand][1];
			$cuser['udata']['seed'][$mtrand][1] = $cuser['udata']['seed'][$mtrand][1]+$qtyadd;
			$qtyafter = $cuser['udata']['seed'][$mtrand][1];
			$itemname = $allist[$cuser['udata']['seed'][$mtrand][0]]['stitle'].lang("plugin/$jn","s038");
		}
		if($questinfo['jddata']['gtype1'] == '2'){//�������
			$cprod = count($cuser['udata']['prod']);
			if($cprod <= 0){
				$cprod = 1;
			}
			$mtrand = mt_rand(1,$cprod);
			$qtyprevious = $cuser['udata']['prod'][$mtrand][1];
			$cuser['udata']['prod'][$mtrand][1] = $cuser['udata']['prod'][$mtrand][1]+$qtyadd;
			$qtyafter = $cuser['udata']['prod'][$mtrand][1];
			$itemname = $allist[$cuser['udata']['prod'][$mtrand][0]]['stitle'];
		}
		if($questinfo['jddata']['gtype1'] == '3'){//�������
			$cfert = count($cuser['udata']['fertilize']);
			if($cfert <= 0){
				$cfert = 1;
			}
			$mtrand = mt_rand(1,$cfert);
			$qtyprevious = $cuser['udata']['fertilize'][$mtrand][1];
			$cuser['udata']['fertilize'][$mtrand][1] = $cuser['udata']['fertilize'][$mtrand][1]+$qtyadd;
			$qtyafter = $cuser['udata']['fertilize'][$mtrand][1];
			$itemname = $allist[$cuser['udata']['fertilize'][$mtrand][0]]['stitle'];
		}
		if($questinfo['jddata']['gtype1'] == '4'){//�������
			$cnite = count($cuser['udata']['nitem']);
			if($cnite <= 0){
				$cnite = 1;
			}
			$mtrand = mt_rand(1,$cnite);
			$qtyprevious = $cuser['udata']['nitem'][$mtrand][1];
			$cuser['udata']['nitem'][$mtrand][1] = $cuser['udata']['nitem'][$mtrand][1]+$qtyadd;
			$qtyafter = $cuser['udata']['nitem'][$mtrand][1];
			$itemname = $allist[$cuser['udata']['nitem'][$mtrand][0]]['stitle'];
		}
		if($questinfo['jddata']['gtype1'] == '5'){//�����Ƭ
			$max = $cuser['spck']+$sysinfo['setdata']['card']['spextend'][2];
			$cnow = DB::result_first("SELECT count(*) cnt FROM ".DB::table('game_jnfarm_card_user')." WHERE uid = '".$uid."' AND type = 'suipian'");
			$cnow >= $max ? $cangku = 1 : $cangku = 0;
			$spid = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_card')." WHERE type = 'suipian' ORDER BY RAND() LIMIT 1");
			cardadd('suipian',$qtyadd,$spid['jcid'],$uid,$cangku);
		}
	}
	if($questinfo['jddata']['gifttype'] == '2'){//ָ������
		$addtrue = 0;
		$cseed = count($cuser['udata']['seed']);
		for($x=1;$x<=$cseed;$x++){
			if($cuser['udata']['seed'][$x][0] == $questinfo['jddata']['gtype2']){
				$qtyprevious = $cuser['udata']['seed'][$x][1];
				$cuser['udata']['seed'][$x][1]=$cuser['udata']['seed'][$x][1]+$qtyadd;
				$qtyafter = $cuser['udata']['seed'][$x][1];
				$itemname = $allist[$cuser['udata']['seed'][$x][0]]['stitle'].lang("plugin/$jn","s038");
				$addtrue = 1;
				break;
			}
		}
		if($addtrue != '1'){
			$qtyprevious = 0;
			$cuser['udata']['seed'][$cseed+1][0] = $questinfo['jddata']['gtype2'];
			$cuser['udata']['seed'][$cseed+1][1] = $qtyadd;
			$qtyafter = $qtyadd;
			$itemname = $allist[$cuser['udata']['seed'][$cseed+1][0]]['stitle'].lang("plugin/$jn","s038");
		}
	}
	if($questinfo['jddata']['gifttype'] == '3'){//ָ����Ʒ
		$citem = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_item')." WHERE jsid = '".$questinfo['jddata']['gtype3']."'");
		$addtrue = 0;
		if($citem['type'] == 'seed'){
			$cseed = count($cuser['udata']['prod']);//����
			for($x=1;$x<=$cseed;$x++){
				if($cuser['udata']['prod'][$x][0] == $questinfo['jddata']['gtype3']){
					$qtyprevious = $cuser['udata']['prod'][$x][1];
					$cuser['udata']['prod'][$x][1]=$cuser['udata']['prod'][$x][1]+$qtyadd;
					$qtyafter = $cuser['udata']['seed'][$x][1];
					$itemname = $allist[$cuser['udata']['prod'][$x][0]]['stitle'];
					$addtrue = 1;
					break;
				}
			}
			if($addtrue != '1'){
				$qtyprevious = 0;
				$cuser['udata']['prod'][$cseed+1][0] = $questinfo['jddata']['gtype2'];
				$cuser['udata']['prod'][$cseed+1][1] = $qtyadd;
				$qtyafter = $qtyadd;
				$itemname = $allist[$cuser['udata']['prod'][$cseed+1][0]]['stitle'];
			}
		}
		if($citem['type'] == 'fertilize'){
			$cfert = count($cuser['udata']['fertilize']);
			for($x=1;$x<=$cfert;$x++){
				if($cuser['udata']['fertilize'][$x][0] == $questinfo['jddata']['gtype3']){
					$qtyprevious = $cuser['udata']['fertilize'][$x][1];
					$cuser['udata']['fertilize'][$x][1]=$cuser['udata']['fertilize'][$x][1]+$qtyadd;
					$qtyafter = $cuser['udata']['fertilize'][$x][1];
					$itemname = $allist[$cuser['udata']['fertilize'][$x][0]]['stitle'];
					$addtrue = 1;
					break;
				}
			}
			if($addtrue != '1'){
				$qtyprevious = 0;
				$cuser['udata']['fertilize'][$cfert+1][0] = $questinfo['jddata']['gtype3'];
				$cuser['udata']['fertilize'][$cfert+1][1] = $qtyadd;
				$qtyafter = $qtyadd;
				$itemname = $allist[$cuser['udata']['fertilize'][$cfert+1][0]]['stitle'];
			}
		}
		if($citem['type'] == 'nitem'){
			$cnite = count($cuser['udata']['nitem']);
			for($x=1;$x<=$cnite;$x++){
				if($cuser['udata']['nitem'][$x][0] == $questinfo['jddata']['gtype3']){
					$qtyprevious = $cuser['udata']['nitem'][$x][1];
					$cuser['udata']['nitem'][$x][1]=$cuser['udata']['nitem'][$x][1]+$qtyadd;
					$qtyafter = $cuser['udata']['nitem'][$x][1];
					$itemname = $allist[$cuser['udata']['nitem'][$x][0]]['stitle'];
					$addtrue = 1;
					break;
				}
			}
			if($addtrue != '1'){
				$qtyprevious = 0;
				$cuser['udata']['nitem'][$cnite+1][0] = $questinfo['jddata']['gtype3'];
				$cuser['udata']['nitem'][$cnite+1][1] = $qtyadd;
				$qtyafter = $qtyadd;
				$itemname = $allist[$cuser['udata']['nitem'][$cfert+1][0]]['stitle'];
			}
		}
		if($citem['type'] == 'tiliitem'){
			$cnite = count($cuser['udata']['tiliitem']);
			for($x=1;$x<=$cnite;$x++){
				if($cuser['udata']['tiliitem'][$x][0] == $questinfo['jddata']['gtype3']){
					$qtyprevious = $cuser['udata']['tiliitem'][$x][1];
					$cuser['udata']['tiliitem'][$x][1]=$cuser['udata']['tiliitem'][$x][1]+$qtyadd;
					$qtyafter = $cuser['udata']['tiliitem'][$x][1];
					$itemname = $allist[$cuser['udata']['tiliitem'][$x][0]]['stitle'];
					$addtrue = 1;
					break;
				}
			}
			if($addtrue != '1'){
				$qtyprevious = 0;
				$cuser['udata']['tiliitem'][$cnite+1][0] = $questinfo['jddata']['gtype3'];
				$cuser['udata']['tiliitem'][$cnite+1][1] = $qtyadd;
				$qtyafter = $qtyadd;
				$itemname = $allist[$cuser['udata']['tiliitem'][$cfert+1][0]]['stitle'];
			}
		}
	}
	if($questinfo['jddata']['gifttype'] == '4'){//ָ������
		$qtyprevious = getuserprofile('extcredits'.$questinfo['jddata']['gtype4']);
		$cdd['extcredits'.$questinfo['jddata']['gtype4']] = '+'.$qtyadd;
		updatemembercount($_G['uid'], $cdd, true, '', 0, '',$jnc['title'],lang("plugin/$jn","s164"));
		$qtyafter = $qtyprevious+$qtyadd;
		$itemname = $_G['setting']['extcredits'][$questinfo['jddata']['gtype4']]['title'];
	}
	if($questinfo['jddata']['gifttype'] == '5'){//ָ����Ƭ
		$max = $cuser['spck']+$sysinfo['setdata']['card']['spextend'][2];
		$cnow = DB::result_first("SELECT count(*) cnt FROM ".DB::table('game_jnfarm_card_user')." WHERE uid = '".$uid."' AND type = 'suipian'");
		$cnow >= $max ? $cangku = 1 : $cangku = 0;
		cardadd('suipian',$qtyadd,$questinfo['jddata']['gtype5'],$uid,$cangku);
	}
	if($questinfo['jddata']['gifttype'] == '6'){//��Ѵ���
		if($questinfo['jddata']['gtype6'] == '1'){//��Ƭ
			$freeadd = 'freedraw';
		}else{
			$freeadd = 'freekpdraw';//����
		}
		DB::query("UPDATE ".DB::table('game_jnfarm_user')." SET $freeadd = $freeadd + $qtyadd WHERE uid = '".$_G['uid']."'");
	}
	$logen = lang("plugin/$jn","s180",array('questinfojdtitle'=>$questinfo['jdtitle'])).$itemname.' '.$qtyprevious.'->'.$qtyafter;
	nlog($_G['uid'],9,$_G['timestamp'],$logen);
	$cquest = count($cuser['dailyquest']['questid']);
	$cuser['dailyquest']['questid'][$cquest] = $questid; //����questid
	
	$cuser['udata'] = json_encode($cuser['udata']);
	$cuser['dailyquest'] = json_encode($cuser['dailyquest']);
	C::t('#jnfarm#jnfarm_user')->update($cuser['juid'],array('udata'=>$cuser['udata'],'dailyquest'=>$cuser['dailyquest']));
	$wording = lang("plugin/$jn","s165");//iconv($_G['charset'],'UTF-8',lang("plugin/$jn","s165"));//'�������';
	return $wording;//json_encode(['final'=>$wording]);
	exit;
}
function seasonqtycheck($uid,$prodid,$qtyadd){
	global $_G;
	$uid = dintval($uid);
	$prodid = dintval($prodid);
	$checkseason = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_season_set')." WHERE jstart < '".$_G['timestamp']."' AND jend > '".$_G['timestamp']."'");
	if($checkseason['jsid'] > 0){
		$checkseason['jdata'] = json_decode($checkseason['jdata'],true);
		if($prodid == $checkseason['jdata']['item']){
			$seasonuser = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_season')." WHERE uid = '$uid' AND jsid = '".$checkseason['jsid']."'");
			if(!$seasonuser){
				DB::query("REPLACE INTO ".DB::table('game_jnfarm_season')." (uid,qty,jsid,createtime) VALUES ('$uid','$qtyadd','".$checkseason['jsid']."','".$_G['timestamp']."') ");
			}else{
				$qty = $seasonuser['qty'] + $qtyadd;
				DB::query("UPDATE ".DB::table('game_jnfarm_season')." SET qty = '$qty' WHERE jdid = '".$seasonuser['jdid']."'");
			}
		}
	}
}
if (!function_exists('array_column')) {
    /**
     * Returns the values from a single column of the input array, identified by
     * the $columnKey.
     *
     * Optionally, you may provide an $indexKey to index the values in the returned
     * array by the values from the $indexKey column in the input array.
     *
     * @param array $input A multi-dimensional array (record set) from which to pull
     *                     a column of values.
     * @param mixed $columnKey The column of values to return. This value may be the
     *                         integer key of the column you wish to retrieve, or it
     *                         may be the string key name for an associative array.
     * @param mixed $indexKey (Optional.) The column to use as the index/keys for
     *                        the returned array. This value may be the integer key
     *                        of the column, or it may be the string key name.
     * @return array
     */
    function array_column($input = null, $columnKey = null, $indexKey = null)
    {
        // Using func_get_args() in order to check for proper number of
        // parameters and trigger errors exactly as the built-in array_column()
        // does in PHP 5.5.
        $argc = func_num_args();
        $params = func_get_args();
        if ($argc < 2) {
            trigger_error("array_column() expects at least 2 parameters, {$argc} given", E_USER_WARNING);
            return null;
        }
        if (!is_array($params[0])) {
            trigger_error(
                'array_column() expects parameter 1 to be array, ' . gettype($params[0]) . ' given',
                E_USER_WARNING
            );
            return null;
        }
        if (!is_int($params[1])
            && !is_float($params[1])
            && !is_string($params[1])
            && $params[1] !== null
            && !(is_object($params[1]) && method_exists($params[1], '__toString'))
        ) {
            trigger_error('array_column(): The column key should be either a string or an integer', E_USER_WARNING);
            return false;
        }
        if (isset($params[2])
            && !is_int($params[2])
            && !is_float($params[2])
            && !is_string($params[2])
            && !(is_object($params[2]) && method_exists($params[2], '__toString'))
        ) {
            trigger_error('array_column(): The index key should be either a string or an integer', E_USER_WARNING);
            return false;
        }
        $paramsInput = $params[0];
        $paramsColumnKey = ($params[1] !== null) ? (string) $params[1] : null;
        $paramsIndexKey = null;
        if (isset($params[2])) {
            if (is_float($params[2]) || is_int($params[2])) {
                $paramsIndexKey = (int) $params[2];
            } else {
                $paramsIndexKey = (string) $params[2];
            }
        }
        $resultArray = array();
        foreach ($paramsInput as $row) {
            $key = $value = null;
            $keySet = $valueSet = false;
            if ($paramsIndexKey !== null && array_key_exists($paramsIndexKey, $row)) {
                $keySet = true;
                $key = (string) $row[$paramsIndexKey];
            }
            if ($paramsColumnKey === null) {
                $valueSet = true;
                $value = $row;
            } elseif (is_array($row) && array_key_exists($paramsColumnKey, $row)) {
                $valueSet = true;
                $value = $row[$paramsColumnKey];
            }
            if ($valueSet) {
                if ($keySet) {
                    $resultArray[$key] = $value;
                } else {
                    $resultArray[] = $value;
                }
            }
        }
        return $resultArray;
    }
}
/*
function checkziyuan($uid,$a = array(),$b = array()) { 
	if(!$uid){
		showmessage('��¼������');
	}
	if($a['farm'] < $b['farm'] || $a['wood'] < $b['wood'] || $a['mine'] < $b['mine'] || $a['money'] < $b['money']){
		showmessage('ĳ��Դ��������ʧ��');
	}
}
function checkduilie($uid,$a,$timestamp) { 
	if(!$uid){
		showmessage('��¼������');
	}
	$co = count($a);
	for($x=1;$x<=$co;$x++){
		if($a[$x] < $timestamp){
			$set = $x;
			return $set;
		}
	}
	if(!$set){
		showmessage('���н���������ȴ��');
	}
}
function addjnlog(){
	
}
function ddziyuan($uid,$a = array(),$b = array()){
	//$userinfo['ziyuan']['ziyuan']['farm'] = $a['farm'] - $b['farm'];
	//after return, ǰ����� $aaa = ddziyuan(xx,xx,xx) vardump $aaa��������;
	//showmessage($a['farm']);
}
function isImage($filePath) { 
	$fileTypeArray=array("jpg","png","bmp","jpeg","gif","ico"); 
	$filePath=strtolower($filePath); 
	$lastPosition=strrpos($filePath,"."); 
	$isImage=false; 
	if($lastPosition>=0) { 
		$fileType=substr($filePath,$lastPosition+1,strlen($filePath)-$lastPosition); 
		if(in_array($fileType,$fileTypeArray)) { 
			$isImage=true; 
		} 
	} 
	return $isImage; 
}*/
?>