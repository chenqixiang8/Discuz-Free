<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
};
if (!$_G['uid']) showmessage('not_loggedin','',array(), array('login' => true));
if ($reallanddirecton == '1'){
	exit;
}
if($_GET['do'] == 'ranklist'){
	if(!$jnc['ranklist']){
		showmessage("$jn:s106");
	}
	if(!$sysinfo['setdata']['ranklimit']){
		$rlimit = 10;
	}else{
		$rlimit = $sysinfo['setdata']['ranklimit'];
	}
	$todaytime = strtotime(date("Y-m-d",$_G['timestamp']));
	if($jnc['rankcache'] == '1'){//��������
		$load = DB::fetch_all("SELECT * FROM ".DB::table('game_jnfarm_rankcache')." WHERE createtime = '$todaytime'");
		if(!$load){
			DB::query("TRUNCATE ".DB::table('game_jnfarm_rankcache')."");
			
			$rank = DB::fetch_all("SELECT * FROM ".DB::table('game_jnfarm_user')."");//���ܿ��԰�����
			$c = count($rank);
			if($c <= $rlimit){
				$rlimit = $c;
			}
			$x=0;
			foreach($rank as $fr){
				$muid[$x] = $fr['uid'];
				$x++;
				$fr['udata'] = json_decode($fr['udata'],true);
				$nmoneylist[] = $fr;
				$nlvllist[] = $fr;
				$nachievelist[] = $fr;
			}
			$moneyuid = implode(',',$muid);
			if(!$moneyuid){
				$moneyuid = 0;
			}

			usort($nlvllist, function($a, $b) { //Sort the array using a user defined function
				return $a['udata']['data']['farmlvl'] > $b['udata']['data']['farmlvl'] ? -1 : 1; //Compare the scores
			});
			usort($nachievelist, function($a, $b) { //Sort the array using a user defined function
				return $a['udata']['achievepoint'] > $b['udata']['achievepoint'] ? -1 : 1; //Compare the scores
			});
			
			$ab = 1;
			$n = 0;
			foreach($nlvllist as $nl){
				$genarateL[$n] = '(\''.$nl['username'].'\','.$nl['uid'].','.$todaytime.','.$ab.','.$nl['udata']['data']['farmlvl'].',\'level\','.$_G['timestamp'].')';
				$ab++;
				$n++;
				if($ab > $rlimit){
					break;
				}
			}
			$genaratelevel = implode(',',$genarateL);
			DB::query("REPLACE INTO ".DB::table('game_jnfarm_rankcache')." (username,uid,createtime,orderby,numqty,type,updatetime) VALUES $genaratelevel ");
			
			$ab = 1;
			$n = 0;
			foreach($nachievelist as $na){
				if(!$na['udata']['achievepoint']){
					$na['udata']['achievepoint'] = 0;
				}
				$genarateA[$n] = '(\''.$na['username'].'\','.$na['uid'].','.$todaytime.','.$ab.','.$na['udata']['achievepoint'].',\'achievepoint\','.$_G['timestamp'].')';
				$ab++;
				$n++;
				if($ab > $rlimit){
					break;
				}
			}
			$genarateachieve = implode(',',$genarateA);
			DB::query("REPLACE INTO ".DB::table('game_jnfarm_rankcache')." (username,uid,createtime,orderby,numqty,type,updatetime) VALUES $genarateachieve ");
			
			if($directextcreditson == '1'){
				$nmoneylist = array();
				$nmoney = DB::fetch_all("SELECT extcredits".$jnc['buyext'].",uid FROM ".DB::table('common_member_count')." WHERE uid IN ($moneyuid) ORDER BY extcredits".$jnc['buyext']." DESC LIMIT $rlimit");
				$x = 0;
				foreach($nmoney as $nmo){
					$nmouid[$x] = $nmo['uid'];
					$x++;
				}
				$nmalluid = implode(',',$nmouid);
				if(!$nmalluid){
					$nmalluid = 0;
				}
				$mname = DB::fetch_all("SELECT uid,username FROM ".DB::table('game_jnfarm_user')." WHERE uid IN ($nmalluid) ");
				$mname = array_column($mname,null,'uid');
				
				$ab = 1;
				$n = 0;
				foreach($nmoney as $nmo){
					$genarateM[$n] = '(\''.$mname[$nmo['uid']]['username'].'\','.$nmo['uid'].','.$todaytime.','.$ab.','.$nmo['extcredits'.$jnc['buyext']].',\'moneylist\','.$_G['timestamp'].')';
					$ab++;
					$n++;
					if($ab > $rlimit){
						break;
					}
				}
				$genaratemoney = implode(',',$genarateM);
				DB::query("REPLACE INTO ".DB::table('game_jnfarm_rankcache')." (username,uid,createtime,orderby,numqty,type,updatetime) VALUES $genaratemoney ");
				
			}else{
				usort($nmoneylist, function($a, $b) { //Sort the array using a user defined function
					return $a['udata']['data']['money'] > $b['udata']['data']['money'] ? -1 : 1; //Compare the scores
				});
				
				$ab = 1;
				$n = 0;
				foreach($nmoneylist as $nmo){
					if(!$nmo['udata']['data']['money']){
						$nmo['udata']['data']['money'] = 0;
					}
					$genarateM[$n] = '(\''.$nmo['username'].'\','.$nmo['uid'].','.$todaytime.','.$ab.','.$nmo['udata']['data']['money'].',\'moneylist\','.$_G['timestamp'].')';
					$ab++;
					$n++;
					if($ab > $rlimit){
						break;
					}
				}
				$genaratemoney = implode(',',$genarateM);
				DB::query("REPLACE INTO ".DB::table('game_jnfarm_rankcache')." (username,uid,createtime,orderby,numqty,type,updatetime) VALUES $genaratemoney ");
			}
			
			$lastupdatetime = date("Y-m-d H:i:s",$_G['timestamp']);
			$lvlr = DB::fetch_all("SELECT * FROM ".DB::table('game_jnfarm_rankcache')." WHERE createtime = '$todaytime' AND type = 'level' ORDER BY orderby ASC");
			foreach($lvlr as $lv){
				$lv['x'] = $lv['orderby'];
				$lv['udata']['data']['farmlvl'] = $lv['numqty'];
				$lvllist[] = $lv;
			}
			
			$aclist = DB::fetch_all("SELECT * FROM ".DB::table('game_jnfarm_rankcache')." WHERE createtime = '$todaytime' AND type = 'achievepoint' ORDER BY orderby ASC");
			foreach($aclist as $lv){
				$lv['x'] = $lv['orderby'];
				$lv['udata']['achievepoint'] = $lv['numqty'];
				$achievelist[] = $lv;
			}
			
			$mlist = DB::fetch_all("SELECT * FROM ".DB::table('game_jnfarm_rankcache')." WHERE createtime = '$todaytime' AND type = 'moneylist' ORDER BY orderby ASC");
			foreach($mlist as $lv){
				$lv['x'] = $lv['orderby'];
				$lv['udata']['data']['money'] = $lv['numqty'];
				$moneylist[] = $lv;
			}
		}else{
			
			$lastup = DB::fetch_first("SELECT updatetime FROM ".DB::table('game_jnfarm_rankcache')." ORDER BY jrid DESC LIMIT 1");
			$lastupdatetime = date("Y-m-d H:i:s",$lastup['updatetime']);
			//load cache;
			$lvlr = DB::fetch_all("SELECT * FROM ".DB::table('game_jnfarm_rankcache')." WHERE createtime = '$todaytime' AND type = 'level' ORDER BY orderby ASC");
			foreach($lvlr as $lv){
				$lv['x'] = $lv['orderby'];
				$lv['udata']['data']['farmlvl'] = $lv['numqty'];
				$lvllist[] = $lv;
			}
			
			$aclist = DB::fetch_all("SELECT * FROM ".DB::table('game_jnfarm_rankcache')." WHERE createtime = '$todaytime' AND type = 'achievepoint' ORDER BY orderby ASC");
			foreach($aclist as $lv){
				$lv['x'] = $lv['orderby'];
				$lv['udata']['achievepoint'] = $lv['numqty'];
				$achievelist[] = $lv;
			}
			
			$mlist = DB::fetch_all("SELECT * FROM ".DB::table('game_jnfarm_rankcache')." WHERE createtime = '$todaytime' AND type = 'moneylist' ORDER BY orderby ASC");
			foreach($mlist as $lv){
				$lv['x'] = $lv['orderby'];
				$lv['udata']['data']['money'] = $lv['numqty'];
				$moneylist[] = $lv;
			}
			
		}
	}else{
		$rank = DB::fetch_all("SELECT * FROM ".DB::table('game_jnfarm_user')."");//���ܿ��԰�����
		$c = count($rank);
		if($c <= $rlimit){
			$rlimit = $c;
		}
		$muid = array();
		$x = 0;
		foreach($rank as $fr){
			$muid[$x] = $fr['uid'];
			$x++;
			$fr['udata'] = json_decode($fr['udata'],true);
			$nmoneylist[] = $fr;
			$nlvllist[] = $fr;
			$nachievelist[] = $fr;
		}
		$moneyuid = implode(',',$muid);
		if(!$moneyuid){
			$moneyuid = 0;
		}
		if($jnc['rankmoneyclose'] == 0){
			if($directextcreditson == '1'){
				$nmoneylist = array();
				$nmoney = DB::fetch_all("SELECT extcredits".$jnc['buyext'].",uid FROM ".DB::table('common_member_count')." WHERE uid IN ($moneyuid) ORDER BY extcredits".$jnc['buyext']." DESC ");
				foreach($nmoney as $ab){
					$ab['udata']['data']['money'] = $ab['extcredits'.$jnc['buyext']];
					$nmoneylist[] = $ab;
				}
			}else{
				usort($nmoneylist, function($a, $b) { //Sort the array using a user defined function
					return $a['udata']['data']['money'] > $b['udata']['data']['money'] ? -1 : 1; //Compare the scores
				});
			}
		}
		
		usort($nlvllist, function($a, $b) { //Sort the array using a user defined function
			if($a['udata']['data']['farmlvl'] == $b['udata']['data']['farmlvl']){
				if($a['udata']['data']['exp'] < $b['udata']['data']['exp']){
					return $a['udata']['data']['farmlvl'] > $b['udata']['data']['farmlvl'] ? -1 : 1;
				}else{
					return $a['udata']['data']['farmlvl'] > $b['udata']['data']['farmlvl'] ? 1 : -1;
				}
				
			}else{
				return $a['udata']['data']['farmlvl'] > $b['udata']['data']['farmlvl'] ? -1 : 1; //Compare the scores
			}
			
		});
		usort($nachievelist, function($a, $b) { //Sort the array using a user defined function
			return $a['udata']['achievepoint'] > $b['udata']['achievepoint'] ? -1 : 1; //Compare the scores
		});
		$ab = 1;
		foreach($nmoneylist as $nm){
			$nm['x'] = $ab;
			$moneylist[] = $nm;
			$ab++;
			if($ab > $rlimit){
				break;
			}
		}
		$ab = 1;
		foreach($nlvllist as $nl){
			$nl['x'] = $ab;
			$lvllist[] = $nl;
			$ab++;
			if($ab > $rlimit){
				break;
			}
		}
		$ab = 1;
		foreach($nachievelist as $na){
			$na['x'] = $ab;
			$achievelist[] = $na;
			$ab++;
			if($ab > $rlimit){
				break;
			}
		}
	}
	
	include template($jn.':'.$jn.'_normal');
	exit;
}
//From: Dism��taobao��com
?>