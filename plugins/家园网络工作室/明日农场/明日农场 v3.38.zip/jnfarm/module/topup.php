<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
};
if (!$_G['uid']) showmessage('not_loggedin','',array(), array('login' => true));
if ($reallanddirecton == '1'){
	exit;
}
if($_GET['do'] == 'topup'){
	if($directextcreditson == '1'){
		$final = iconv($_G['charset'],'UTF-8','This function has been closed');
		$final = array('final'=>$final);
		echo json_encode($final);
		//echo json_encode(['final'=>$final]);
		exit;
		//showmessage('Error');//���ִ�ͨ����������ֵ
	}
	$paymount = dintval($_GET['paymount']);
	$paymount = fushu($paymount);
	if($_GET['submit'] == 'true' && $_GET['formhash'] == $_G['formhash'] && $paymount > 0){
		$jifen = getuserprofile('extcredits'.$jnc['buyext']);
		if(file_exists(DISCUZ_ROOT.'source/plugin/'.$jn.'/module/qianfanjinbi.php') && $qianfanjinbion == '1'){//ʹ��ǧ����ҳ�ֵ
			//require DISCUZ_ROOT.'source/plugin/'.$jn.'/module/qianfanapp.php';
			$rr = $_COOKIE['wap_token'];
			//$wallet = $client->get('wallets/'.$_G['uid'], ['wap_token' =>$rr]);
			$wallet = $client->get('wallets/'.$_G['uid'], array('wap_token'=>$rr));
			$jifen = $wallet['data']['gold'];
		}
		if($paymount <= $jifen){
			if($qianfanjinbion == '1'){//ʹ��ǧ����ҳ�ֵ
				$kjf = 0-$paymount;
				$add = $paymount*$jnc['buyrate'];
				//$putgold = $client->put('wallets/'.$_G['uid'], ['gold' =>$kjf,'reason' =>$jnc['title'].'&#x5145;&#x503C;'.$add.$jnc['mt'],'type'=>$jnc['qianfanjinbiout']]);
				
				$putgold = $client->put('wallets/'.$_G['uid'], array('gold' =>$kjf,'reason' =>$jnc['title'].'&#x5145;&#x503C;'.$add.$jnc['mt'],'type'=>$jnc['qianfanjinbiout']));
				//$client->post('pushes/'.$_G['uid'].'/single', ['title' =>$jnc['title'],'content'=>lang("plugin/$jn","s021"),'target_type'=>50,'target_value'=>'plugin.php?id=jnfarm','show_alert'=>1]);
				$client->post('pushes/'.$_G['uid'].'/single', array('title' =>$jnc['title'],'content'=>lang("plugin/$jn","s021"),'target_type'=>50,'target_value'=>'plugin.php?id=jnfarm','show_alert'=>1));
				$_G['setting']['extcredits'][$jnc['buyext']]['title'] = $jnc['qianfanjb'];
			}else{
				$cdd['extcredits'.$jnc['buyext']] = '-'.$paymount;
				updatemembercount($_G['uid'], $cdd, true, '', 0, '',$jnc['title'],lang("plugin/$jn","s020"));
				$add = $paymount*$jnc['buyrate'];
			}
			
			$userinfo['udata']['data']['money'] = $userinfo['udata']['data']['money']+$add;
			$userinfo['udata'] = json_encode($userinfo['udata'],true);
			C::t('#'.$jn.'#'.$jn.'_user')->update($userinfo['juid'],array('udata'=>$userinfo['udata'],'lastsituation'=>$_G['timestamp']));
			$linkgen = lang("plugin/$jn","s021");
			$thislang = lang("plugin/$jn","s037",array('paymount'=>$paymount,'buyexttitle'=>$_G['setting']['extcredits'][$jnc['buyext']]['title'],'add'=>$add,'jncmt'=>$jnc['mt']));
			nlog($_G['uid'],2,$_G['timestamp'],$thislang);
		}else{
			$linkgen = lang("plugin/$jn","s022");
			$final = iconv($_G['charset'],'UTF-8',$linkgen);
			$final = array('final'=>$final);
			echo json_encode($final);
			exit;
			//showmessage($linkgen,'plugin.php?id=jnfarm'.$mobilelink);
		}
		$final = iconv($_G['charset'],'UTF-8',$linkgen);
		$final = array('final'=>$final);
		echo json_encode($final);
		//echo json_encode(['final'=>$final]);
		exit;
		//showmessage($thislang,'plugin.php?id=jnfarm'.$mobilelink);
	}else{
		$final = iconv($_G['charset'],'UTF-8',lang("plugin/$jn","s022"));
		$final = array('final'=>$final);
		echo json_encode($final);
		//echo json_encode(['final'=>$final]);
		exit;
	}
}
//From: Dism��taobao��com
?>