<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
};
global $_G;
$jn = 'jnfarm';
$jnc = $_G['cache']['plugin'][$jn];
$g_adminids = explode('|',$jnc['adminids']);//����ԱȨ��
if (!$_G['uid']) showmessage('not_loggedin','',array(), array('login' => true));
//require DISCUZ_ROOT.'source/plugin/'.$jn.'/module/func.php';
if(!in_array($_G['uid'],$g_adminids)){
	showmessage("$jn:s002");
}
$page = $_G['page'];
$tpp = 100;
$total = DB::result_first("SELECT count(*) cnt FROM ".DB::table('game_jnfarm_dailyquest')."");
if(@ceil($total/$tpp) < $page) 	$page = 1;
$start_limit = ($page - 1) * $tpp;

if($_GET['do'] == 'dailyquest'){
	$seed = DB::fetch_all("SELECT * FROM ".DB::table('game_jnfarm_item')." WHERE type = 'seed' ORDER BY jsid ASC");
	$item = DB::fetch_all("SELECT * FROM ".DB::table('game_jnfarm_item')."");
	if($cardon == '1'){
		$card = DB::fetch_all("SELECT * FROM ".DB::table('game_jnfarm_card')." WHERE type = 'suipian'");
	}
	
	$jdid = dintval($_GET['jdid']);
	if($jdid > 0){
		$jdinfo = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_dailyquest')." WHERE jdid = '$jdid'");
		$jdinfo['jddata'] = json_decode($jdinfo['jddata'],true);
		$jdinfo['jddata']['jdesc'] = iconv('UTF-8',strtoupper($_G['charset']),$jdinfo['jddata']['jdesc']);
		$jdinfo['jddata']['groupid'] = explode(',',$jdinfo['jddata']['groupid']);
	}
	$jdall = DB::fetch_all("SELECT * FROM ".DB::table('game_jnfarm_dailyquest')."");
	foreach($jdall as $jd){
		$jd['jddata'] = json_decode($jd['jddata'],true);
		$jd['jddata']['jdesc'] = iconv('UTF-8',strtoupper($_G['charset']),$jd['jddata']['jdesc']);
		$jdlist[] = $jd;
	}

	if(submitcheck('editsubmit')){
		$jdid = dintval($_GET['jdid']);
		if($jdid > 0){
			$jdtitle = daddslashes($_GET['jdtitle']);
			$minlvl = dintval($_GET['minlvl']);
			$jdorder = dintval($_GET['jdorder']);
			$jpdata['jddata']['jdesc'] = iconv(strtoupper($_G['charset']),'UTF-8',daddslashes($_GET['jdesc']));
			$jpdata['jddata']['type'] = dintval($_GET['type']);
			$jpdata['jddata']['jimg'] = daddslashes($_GET['jimg']);
			if($jpdata['jddata']['type'] == '2'){
				$jpdata['jddata']['rules'] = dintval($_GET['rules']);
				$jpdata['jddata']['rulesqty'] = dintval($_GET['rulesqty']);
				if(!$jpdata['jddata']['rules'] || !$jpdata['jddata']['rulesqty']){
					showmessage("$jn:o007");
				}
			}
			$jpdata['jddata']['urlredirect'] = daddslashes($_GET['urlredirect']);
			$jpdata['jddata']['gifttype'] = dintval($_GET['gifttype']);
			$jpdata['jddata']['gtype'.$jpdata['jddata']['gifttype']] = dintval($_GET['gtype'.$jpdata['jddata']['gifttype']]);
			$jpdata['jddata']['giftqtymin'] = dintval($_GET['giftqtymin']);
			$jpdata['jddata']['giftqtymax'] = dintval($_GET['giftqtymax']);
			
			foreach ($_GET['usergroup'] as $value){
				if($value == '0'){
					$newvalue[0] = 0;
					break;
				}else{
					$newvalue[$x] = $value;
					$x++;
				}
				
			}
			$jpdata['jddata']['groupid'] = implode(',',$newvalue);
			if(!$jdtitle || !$jpdata['jddata']['type'] || !$jpdata['jddata']['gifttype'] || !$jpdata['jddata']['giftqtymin'] || !$jpdata['jddata']['giftqtymax']){
				showmessage("$jn:o001");
			}
			$jpdata = json_encode($jpdata['jddata']);
			C::t("#jnfarm#jnfarm_dailyquest")->update($jdid,array('jdtitle'=>$jdtitle,'jddata'=>$jpdata,'minlvl'=>$minlvl,'jdorder'=>$jdorder));
			showmessage("$jn:o006",'plugin.php?id='.$jn.':admincp'.$jn.'&do=dailyquest');
		}
	}
	if(submitcheck('newsubmit')){
		$data = array();
		$data['jdtitle'] = daddslashes($_GET['jdtitle']);
		$data['minlvl'] = dintval($_GET['minlvl']);
		$data['jdorder'] = dintval($_GET['jdorder']);
		$jpdata['jddata']['jdesc'] = iconv(strtoupper($_G['charset']),'UTF-8',daddslashes($_GET['jdesc']));
		$jpdata['jddata']['type'] = dintval($_GET['type']);
		$jpdata['jddata']['jimg'] = daddslashes($_GET['jimg']);
		if($jpdata['jddata']['type'] == '2'){
			$jpdata['jddata']['rules'] = dintval($_GET['rules']);
			$jpdata['jddata']['rulesqty'] = dintval($_GET['rulesqty']);
			if(!$jpdata['jddata']['rules'] || !$jpdata['jddata']['rulesqty']){
				showmessage("$jn:o007");
			}
		}
		$jpdata['jddata']['urlredirect'] = daddslashes($_GET['urlredirect']);
		$jpdata['jddata']['gifttype'] = dintval($_GET['gifttype']);
		$jpdata['jddata']['gtype'.$jpdata['jddata']['gifttype']] = dintval($_GET['gtype'.$jpdata['jddata']['gifttype']]);
		$jpdata['jddata']['giftqtymin'] = dintval($_GET['giftqtymin']);
		$jpdata['jddata']['giftqtymax'] = dintval($_GET['giftqtymax']);


		if(!$data['jdtitle'] || !$jpdata['jddata']['type'] || !$jpdata['jddata']['gifttype'] || !$jpdata['jddata']['giftqtymin'] || !$jpdata['jddata']['giftqtymax']){
			showmessage("$jn:o001");
		}
		$data['jddata'] = json_encode($jpdata['jddata'],true);
		C::t("#jnfarm#jnfarm_dailyquest")->insert($data);
		showmessage("$jn:o004",'plugin.php?id='.$jn.':admincp'.$jn.'&do=dailyquest');
	}
	if($_GET['delete'] == 'true'){
		if($_GET['formhash'] == $_G['formhash']){
			$jdid = dintval($_GET['jdid']);
			DB::query("DELETE FROM ".DB::table('game_jnfarm_dailyquest')." WHERE jdid = '$jdid'");
			showmessage("$jn:s008","plugin.php?id=jnfarm:admincp&do=dailyquest");
		}
	}
}
//From: Dism��taobao��com
?>