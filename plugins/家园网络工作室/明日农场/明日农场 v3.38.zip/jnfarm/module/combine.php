<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
};
if (!$_G['uid']) showmessage('not_loggedin','',array(), array('login' => true));
if ($reallanddirecton == '1'){
	exit;
}
if($_GET['do'] == 'combine'){
	$currentlimit = 1;
	//list����û���ǰ�Ѿ�����combine��Ʒ��
	$combine = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_combine')." WHERE uid = '".$_G['uid']."'");
	if($combine['jcid'] > 0){
		$tcombine = json_decode($combine['jcdata'],true);
	}
	
	//list���Ա��ϳɵ���Ʒ
	$citem = DB::fetch_all("SELECT * FROM ".DB::table('game_jnfarm_item')."");
	$cnewitem = array_column($citem, null, 'jsid');
	
	$combineid = dintval($_GET['combineid']);
	if($combineid > 0){
		if($_GET['formhash'] == $_G['formhash']){
			if($tcombine[$combineid]['qty'] > 0 && $tcombine[$combineid]['expiredtime'] < $_G['timestamp']){
				$countprod = count($userinfo['udata']['prod']);
				$countfert = count($userinfo['udata']['fertilize']);
				$countnitem = count($userinfo['udata']['nitem']);
				//��ȡ
				if($cnewitem[$combineid]['type'] == 'seed'){
					for($x = 1; $x<=$countprod;$x++){
						if($userinfo['udata']['prod'][$x][0] == $combineid){
							$pqty = $userinfo['udata']['prod'][$x][1];
							$userinfo['udata']['prod'][$x][1] = $userinfo['udata']['prod'][$x][1]+($tcombine[$combineid]['qty']);
							$success = 1;
						}
					}
					if(!$success){
						$pqty = 0;
						$userinfo['udata']['prod'][$countprod+1][0] = $combineid;
						$userinfo['udata']['prod'][$countprod+1][1] = $tcombine[$combineid]['qty'];
					}
				}
				if($cnewitem[$combineid]['type'] == 'fertilize'){
					for($x = 1; $x<=$countfert;$x++){
						if($userinfo['udata']['fertilize'][$x][0] == $combineid){
							$pqty = $userinfo['udata']['fertilize'][$x][1];
							$userinfo['udata']['fertilize'][$x][1] = $userinfo['udata']['fertilize'][$x][1]+($tcombine[$combineid]['qty']);
							$success = 1;
						}
					}
					if(!$success){
						$pqty = 0;
						$userinfo['udata']['fertilize'][$countfert+1][0] = $combineid;
						$userinfo['udata']['fertilize'][$countfert+1][1] = $tcombine[$combineid]['qty'];
					}
				}
				if($cnewitem[$combineid]['type'] == 'nitem'){
					for($x = 1; $x<=$countnitem;$x++){
						if($userinfo['udata']['nitem'][$x][0] == $combineid){
							$pqty = $userinfo['udata']['nitem'][$x][1];
							$userinfo['udata']['nitem'][$x][1] = $userinfo['udata']['nitem'][$x][1]+($tcombine[$combineid]['qty']);
							$success = 1;
						}
					}
					if(!$success){
						$pqty = 0;
						$userinfo['udata']['nitem'][$countnitem+1][0] = $combineid;
						$userinfo['udata']['nitem'][$countnitem+1][1] = $tcombine[$combineid]['qty'];
					}
				}
				$thislang = lang("plugin/$jn","s133").$tcombine[$combineid]['qty'].$cnewitem[$combineid]['stitle'].lang("plugin/$jn","s134").' ('.$pqty.'->'.($pqty+$tcombine[$combineid]['qty']).')';
				nlog($_G['uid'],7,$_G['timestamp'],$thislang);
				
				unset($tcombine[$combineid]);
				$fcombine = json_encode($tcombine);
				DB::query("UPDATE ".DB::table('game_jnfarm_combine')." SET jcdata = '".$fcombine."' WHERE uid = '".$_G['uid']."'");
				
				$userinfo['udata'] = json_encode($userinfo['udata']);
				C::t('#'.$jn.'#'.$jn.'_user')->update($userinfo['juid'],array('udata'=>$userinfo['udata'],'lastsituation'=>$_G['timestamp']));
				
				 //lang("plugin/$jn","s118",array('cinfogetext'=>$cinfo['getext'],'cinfocashexttitle'=>$_G['setting']['extcredits'][$cinfo['cashext']]['title']));//'�ҳ�'.$cinfo['getext'].$_G['setting']['extcredits'][$cinfo['cashext']]['title'].'�ɹ�';
				
				
				//$linkgen = $fcombine;
			}else{
				showmessage("$jn:s111");
			}
		}
	}
	foreach($citem as $ci){
		if($tcombine[$ci['jsid']]['qty'] > '0'){
			$beencombine = 1;
		}
		$ci['sdata'] = json_decode($ci['sdata'],true);
		if($ci['sdata']['combine']['c'] == '1'){
			$countc = count($ci['sdata']['combine']['data']);
			for($cb = 1; $cb <= $countc; $cb++){
				$name[$cb] = $cnewitem[$ci['sdata']['combine']['data'][$cb][0]]['stitle'].'x'.$ci['sdata']['combine']['data'][$cb][1];
			}
			$tcb = implode(', ',$name);
			if($beencombine == '1'){
				if($_G['timestamp'] > $tcombine[$ci['jsid']]['expiredtime']){
					$thisbtn = '<a class="layui-btn layui-btn-xs layui-btn-danger" onclick="ajaxget(\'plugin.php?id='.$jn.'&do=combine&update=true&formhash='.$_G['formhash'].'&timestamp='.$_G['timestamp'].'&combineid='.$ci['jsid'].'\',\'thiscombine\');layer.msg(\''.lang("plugin/$jn","s114").'\');">'.lang("plugin/$jn","s124").'</a>';
				}else{
					$thisbtn = date("Y-m-d H:i:s", $tcombine[$ci['jsid']]['expiredtime']);
				}
				$text = $text.'<div style="background: #f2f2f2; border:1px #aeaeae solid; padding:1em; border-radius:0.5em; position:relative; margin-bottom:1em; font-family: \'Microsoft Yahei\',Arial;" align="left">
			<div style="float: left;"><img src="'.$imgurl.$ci['sdata']['seedurl'].'" style="width:4em;"></div>
			<div style="float: left; margin-left:1em;"><font color="#00BFFF" style="font-weight: bold; font-size: 1.2em">'.$ci['stitle'].'</font><br>'.lang("plugin/$jn","s125").': '.$tcombine[$ci['jsid']]['qty'].'<br>'.lang("plugin/$jn","s126").' '.$thisbtn.'</div>
			<div style="clear: both"></div>
		</div>';
				$beencombine = 0;
			}else{
				$text = $text.'<div style="background: #f2f2f2; border:1px #aeaeae solid; padding:1em; border-radius:0.5em; position:relative; margin-bottom:1em; font-family: \'Microsoft Yahei\',Arial;" align="left">
			<div style="float: left;"><img src="'.$imgurl.$ci['sdata']['seedurl'].'" style="width:4em;"></div>
			<div style="float: left; margin-left:1em;"><font color="#00BFFF" style="font-weight: bold; font-size: 1.2em">'.$ci['stitle'].'</font><br>'.$tcb.'<br>'.$jnc['mt'].'x'.$ci['sdata']['combine']['cost'].', '.$ci['sdata']['combine']['timeneed'].lang("plugin/$jn","s127").'</div>
			<div class="number-input" align="right" style="float:right;">
	  <span onclick="this.parentNode.querySelector(\'input[type=number]\').stepDown()" >&nbsp;-&nbsp;</span>
	  <input class="quantity" min="0" max="999" name="nitem'.$ci['jsid'].'" type="number" value="0" style="width:30px;">
	  <span onclick="this.parentNode.querySelector(\'input[type=number]\').stepUp()" class="plus">&nbsp;+&nbsp;</span>
	</div>
			<div style="clear: both"></div>
		</div>';
			}
		}
	}
	if($_GET['update'] == 'true'){
		include template($jn.':'.$jn.'_normal');
		exit;
	}
	if($_GET['combinesubmit'] == 'true' && $_G['formhash'] == $_G['formhash']){
	//if(submitcheck('combinesubmit')){
		$clist = DB::fetch_all("SELECT * FROM ".DB::table('game_jnfarm_item')." WHERE type = 'nitem'");
		$alist = DB::fetch_all("SELECT * FROM ".DB::table('game_jnfarm_item')."");
		$alist = array_column($alist, null, 'jsid');
		//$cuserseed = count($userinfo['udata']['data']['seed']); ���Ӳ����źϳ�
		$cuserfert = count($userinfo['udata']['fertilize']);
		$cuserprod = count($userinfo['udata']['prod']);
		$cusernitem = count($userinfo['udata']['nitem']);
		$r = count($tcombine);
		foreach($clist as $cl){
			if($_GET['nitem'.$cl['jsid']] > 0){
				//������ϵ���Ʒ�Ƿ��㹻
				$cl['sdata'] = json_decode($cl['sdata'],true);
				$cl['thisc'] = count($cl['sdata']['combine']['data']);
				$actiontrue = 1;
				for($sc = 1; $sc<=$cl['thisc'];$sc++){
					$proceed = 0;
					$qty = dintval($_GET['nitem'.$cl['jsid']]);
					if($alist[$cl['sdata']['combine']['data'][$sc][0]]['type'] == 'seed'){
						for($x=1;$x<=$cuserprod;$x++){
							if($userinfo['udata']['prod'][$x][0] == $cl['sdata']['combine']['data'][$sc][0]){
								if($userinfo['udata']['prod'][$x][1] >= ($cl['sdata']['combine']['data'][$sc][1]*$qty)){
									$proceed = 1;
								}
							}
						}
					}
					if($alist[$cl['sdata']['combine']['data'][$sc][0]]['type'] == 'fertilize'){
						for($x=1;$x<=$cuserfert;$x++){
							if($userinfo['udata']['fertilize'][$x][0] == $cl['sdata']['combine']['data'][$sc][0]){
								if($userinfo['udata']['fertilize'][$x][1] >= ($cl['sdata']['combine']['data'][$sc][1]*$qty)){
									$proceed = 1;
								}
							}
						}
					}
					if($alist[$cl['sdata']['combine']['data'][$sc][0]]['type'] == 'nitem'){
						for($x=1;$x<=$cusernitem;$x++){
							if($userinfo['udata']['nitem'][$x][0] == $cl['sdata']['combine']['data'][$sc][0]){
								if($userinfo['udata']['nitem'][$x][1] >= ($cl['sdata']['combine']['data'][$sc][1]*$qty)){
									$proceed = 1;
								}
							}
						}
					}
					$thiscost = $thiscost+($cl['sdata']['combine']['cost']*$qty);
					$qtyneed = $cl['sdata']['combine']['data'][$sc][1]*$qty;
					if($proceed <= '0'){
						$final = iconv($_G['charset'],'UTF-8',lang("plugin/$jn","s128",array("stitle"=>$alist[$cl['sdata']['combine']['data'][$sc][0]]['stitle'],"qtyneed"=>$qtyneed)));
						$final = array('final'=>$final);
						echo json_encode($final);
						exit;
						//showmessage("$jn:s128","",array("stitle"=>$alist[$cl['sdata']['combine']['data'][$sc][0]]['stitle'],"qtyneed"=>$qtyneed));
					}
				}
				$r++;
			}
		}
		if(!$actiontrue){//currentlimit��Ҫ����, �Ȱ������Ŀ۳������ϴ�����д��ȥ
			$final = iconv($_G['charset'],'UTF-8','��ѡ��Ҫ�ϳɵ���Ʒ');
			$final = array('final'=>$final,'other'=>1);
			echo json_encode($final);
			exit;
			//showmessage("$jn:s129","",array("currentlimit"=>$currentlimit));
		}
		//���ҵ�ǰ�Ƿ��Ѿ����������е���Ʒ
		
		if($r > $currentlimit){//currentlimit��Ҫ����, �Ȱ������Ŀ۳������ϴ�����д��ȥ
			$final = iconv($_G['charset'],'UTF-8',lang("plugin/$jn","s129",array("currentlimit"=>$currentlimit)));
			$final = array('final'=>$final);
			echo json_encode($final);
			exit;
			//showmessage("$jn:s129","",array("currentlimit"=>$currentlimit));
		}
		if($userinfo['udata']['data']['money'] < $thiscost){
			$final = iconv($_G['charset'],'UTF-8',lang("plugin/$jn","s100",array("jncmt"=>$jnc['mt'])));
			$final = array('final'=>$final);
			echo json_encode($final);
			exit;
			//showmessage("$jn:s100","",array("jncmt"=>$jnc['mt']));
		}
		$combine = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_combine')." WHERE uid = '".$_G['uid']."'");
		if(!$combine){
			DB::query("REPLACE INTO ".DB::table('game_jnfarm_combine')." (uid) VALUES ('".$_G['uid']."')");
			$combine = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_combine')." WHERE uid = '".$_G['uid']."'");
		}
		//��ʼ�۳�
		foreach($clist as $cl){
			if($_GET['nitem'.$cl['jsid']] > 0){
				//������ϵ���Ʒ�Ƿ��㹻
				$cl['sdata'] = json_decode($cl['sdata'],true);
				$cl['thisc'] = count($cl['sdata']['combine']['data']);
				for($sc = 1; $sc<=$cl['thisc'];$sc++){
					$proceed = 0;
					$qty = dintval($_GET['nitem'.$cl['jsid']]);
					if($alist[$cl['sdata']['combine']['data'][$sc][0]]['type'] == 'seed'){
						for($x=1;$x<=$cuserprod;$x++){
							if($userinfo['udata']['prod'][$x][0] == $cl['sdata']['combine']['data'][$sc][0]){
								$qtyactual = $userinfo['udata']['prod'][$x][1];
								$userinfo['udata']['prod'][$x][1] = $userinfo['udata']['prod'][$x][1]-($cl['sdata']['combine']['data'][$sc][1]*$qty);
								$itemcost[$sc] =  $alist[$userinfo['udata']['prod'][$x][0]]['stitle'].'('.$qtyactual.'->'.$userinfo['udata']['prod'][$x][1].')';
							}
						}
					}
					if($alist[$cl['sdata']['combine']['data'][$sc][0]]['type'] == 'fertilize'){
						for($x=1;$x<=$cuserfert;$x++){
							if($userinfo['udata']['fertilize'][$x][0] == $cl['sdata']['combine']['data'][$sc][0]){
								$qtyactual = $userinfo['udata']['fertilize'][$x][1];
								$userinfo['udata']['fertilize'][$x][1] = $userinfo['udata']['fertilize'][$x][1]-($cl['sdata']['combine']['data'][$sc][1]*$qty);
								$itemcost[$sc] =  $alist[$userinfo['udata']['fertilize'][$x][0]]['stitle'].'('.$qtyactual.'->'.$userinfo['udata']['fertilize'][$x][1].')';
							}
						}
					}
					if($alist[$cl['sdata']['combine']['data'][$sc][0]]['type'] == 'nitem'){
						for($x=1;$x<=$cusernitem;$x++){
							if($userinfo['udata']['nitem'][$x][0] == $cl['sdata']['combine']['data'][$sc][0]){
								$qtyactual = $userinfo['udata']['nitem'][$x][1];
								$userinfo['udata']['nitem'][$x][1] = $userinfo['udata']['nitem'][$x][1]-($cl['sdata']['combine']['data'][$sc][1]*$qty);
								$itemcost[$sc] =  $alist[$userinfo['udata']['nitem'][$x][0]]['stitle'].'('.$qtyactual.'->'.$userinfo['udata']['nitem'][$x][1].')';
							}
						}
					}
				}
				//���ĵĲ���
				$itemcost = implode(',',$itemcost);
				//����combine��¼
				$tcombine[$cl['jsid']]['status'] = '1';
				$tcombine[$cl['jsid']]['createtime'] = $_G['timestamp'];
				$tcombine[$cl['jsid']]['expiredtime'] = $_G['timestamp']+($cl['sdata']['combine']['timeneed']*$qty);
				$tcombine[$cl['jsid']]['qty'] = $qty;
				$ctext[$sc] = $qty.'x'.$alist[$cl['jsid']]['stitle'].' '.lang("plugin/$jn","s135").':'.date("Y-m-d H:i:s",$tcombine[$cl['jsid']]['expiredtime']).' '.$itemcost;
			}
		}
		$ctext = implode(',',$ctext);
		$thislang = lang("plugin/$jn","s136").$ctext;
		nlog($_G['uid'],7,$_G['timestamp'],$thislang);
		
		$tcombine = json_encode($tcombine);
		DB::query("UPDATE ".DB::table('game_jnfarm_combine')." SET jcdata = '$tcombine' WHERE uid = '".$_G['uid']."'");
		if($directextcreditson == '1'){
			$cdd['extcredits'.$jnc['buyext']] = '-'.$thiscost;
			updatemembercount($_G['uid'], $cdd, true, '', 0, '',$jnc['title'],lang("plugin/$jn","s136"));
			$cdd = array();
		}else{
			$userinfo['udata']['data']['money'] = $userinfo['udata']['data']['money']- $thiscost;
		}
		//$userinfo['udata']['data']['money'] = $userinfo['udata']['data']['money'] - $thiscost;
		
		if($directextcreditson == '1'){
			$userinfo['udata']['data']['money'] = 0;
		}
		$userinfo['udata'] = json_encode($userinfo['udata']);
		C::t('#'.$jn.'#'.$jn.'_user')->update($userinfo['juid'],array('udata'=>$userinfo['udata'],'lastsituation'=>$_G['timestamp']));
		
		$linkgen = lang("plugin/$jn","s130");
		$final = iconv($_G['charset'],'UTF-8',$linkgen);
		$final = array('final'=>$final);
		echo json_encode($final);
		exit;
		//showmessage("$jn:s130",'plugin.php?id='.$jn);
	}
	//$list = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_combine')." WHERE uid = '".$_G['uid']."'");
	//$linkgen = '<script>ajaxget(\'plugin.php?id='.$jn.'&do=normal&ac=updateland&formhash='.$_G['formhash'].'&timestamp='.$_G['timestamp'].'\',\'jnland\');layer.msg(\''.$linkgen.'\')</script>';//����Ҫ���� �������صĸ��� 
	include template($jn.':'.$jn.'_normal');
	exit;
	//$linkgen = 'hahaha';//����ֱ�Ӹ�������ͼƬ
	//$linkgen = lang("plugin/$jn","s050").'<script>ajaxget("plugin.php?id='.$jn.'&do=ajax&ac=updatejfid&jfid='.$jfid.'&timestamp='.$_G['timestamp'].'","jfid'.$jfid.'");ajaxget("plugin.php?id='.$jn.'&do=ajax&ac=updatejrid&jfid='.$jfid.'&timestamp='.$_G['timestamp'].'","jrid'.$jfid.'");</script>';
}
//From: Dism��taobao��com
?>