<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
};
if (!$_G['uid']) showmessage('not_loggedin','',array(), array('login' => true));
if ($reallanddirecton == '1'){
	exit;
}
if($_GET['do'] == 'achieve'){
	if($cardon == '1'){
		$cardall = C::t('#jnfarm#jnfarm_card')->loadall();
		$cardall = array_column($cardall,null,'jcid');
	}
	if($_GET['success'] == 'true'){
		$jaid = dintval($_GET['jaid']);
		$checkj = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_achieve')." WHERE jaid = '$jaid'");
		if(!$checkj){
			$word = lang("plugin/$jn","s111");
			$linkgen = '<script>ajaxget(\'plugin.php?id='.$jn.'&do=normal&ac=userinfo&timestamp='.$_G['timestamp'].'\',\'userinfo\');layer.msg(\''.$word.'\')</script>';
			include template($jn.':'.$jn.'_normal');
			exit;
		}
		if($_GET['formhash'] == $_G['formhash']){
			$checkj['sucuid'] = explode(',',$checkj['sucuid']);
			if(in_array($_G['uid'],$checkj['sucuid'])){
				$word = lang("plugin/$jn","s112");
				$linkgen = '<script>layer.msg(\''.$word.'\')</script>';
				include template($jn.':'.$jn.'_normal');
				exit;
			}else{
				if($checkj['jatype'] == '1'){
					if($userinfo['udata']['data']['farmlvl'] >= $checkj['jaqty']){
						$checkj['succ'] = '1';
					}
				}
				if($checkj['jatype'] == '2'){
					$cs = '0';
					$cplant = count($sdlist);
					for($x=1;$x<=$cplant;$x++){
						$cs = $cs+$userinfo['udata']['plantrecord'][$x][0]; //������ֲ�ܴ���, ��Ҫ���һ��
					}
					if($cs >= $checkj['jaqty']){
						$checkj['succ'] = '1';
					}
				}

				if($checkj['jatype'] == '3'){//�ճ�������
					$cplant = count($sdlist);
					$cs = '0';
					for($x=1;$x<=$cplant;$x++){
						$cs = $cs+$userinfo['udata']['harvestrecord'][$x][0]; //��Ҫ���һ��
					}
					if($cs >= $checkj['jaqty']){
						$checkj['succ'] = '1';
					}
				}
				if($checkj['jatype'] == '4'){//��Ǯ��
					if($userinfo['udata']['data']['money'] >= $checkj['jaqty']){
						$checkj['succ'] = '1';
					}
				}
				if($checkj['jatype'] == '5'){//��ֲĳ�����
					if($userinfo['udata']['plantrecord'][$checkj['wxtra']][0] >= $checkj['jaqty']){
						$checkj['succ'] = '1';
					}
				}
				if($checkj['jatype'] == '6'){//��ֲĳ�����
					if($userinfo['udata']['harvestrecord'][$checkj['wxtra']][0] >= $checkj['jaqty']){
						$checkj['succ'] = '1';
					}
				}
				if($checkj['jatype'] == '7'){//���˹���
					if($userinfo['uindigx'] >= $checkj['jaqty']){
						$checkj['succ'] = '1';
					}
				}
				if($checkj['jatype'] == '8'){//�̻ṱ��
					if($userinfo['uguildgx'] >= $checkj['jaqty']){
						$checkj['succ'] = '1';
					}
				}
				if($checkj['succ'] == '1'){
					$achieveb4 = $userinfo['udata']['achievepoint'];
					$userinfo['udata']['achievepoint'] = $userinfo['udata']['achievepoint']+$checkj['padd'];
					$achieveat = $userinfo['udata']['achievepoint'];
					$cfist = count($checkj['sucuid']);
					$checkj['sucuid'][$cfist] = $_G['uid'];
					$sucuid = implode(',',$checkj['sucuid']);
					$sucuid = daddslashes($sucuid);
					DB::query("UPDATE ".DB::table('game_jnfarm_achieve')." SET sucuid = '$sucuid' WHERE jaid = '".$checkj['jaid']."'");
					
					//���ӽ���
					if($checkj['gifttype'] == '1'){
						if($directextcreditson == '1'){
							$cdd['extcredits'.$jnc['buyext']] = '+'.$checkj['giftqty'];
							updatemembercount($_G['uid'], $cdd, true, '', 0, '',$jnc['title'],lang("plugin/$jn","s167"));
							$cdd = array();
						}else{
							$userinfo['udata']['data']['money'] = $userinfo['udata']['data']['money']+$checkj['giftqty'];
						}
					}
					if($checkj['gifttype'] == '2'){//��������
						$count = count($userinfo['udata']['seed']);
						for($x = 1;$x <= $count; $x++){
							if($userinfo['udata']['seed'][$x][0] == $checkj['jxtra']){
								$userinfo['udata']['seed'][$x][1] = $userinfo['udata']['seed'][$x][1]+$checkj['giftqty'];
								$ss = '1';
							}
						}
						if(!$ss){
							$userinfo['udata']['seed'][$x][0] = $checkj['jxtra'];
							$userinfo['udata']['seed'][$x][1] = $checkj['giftqty'];
						}
					}
					if($checkj['gifttype'] == '3'){//��������
						$count = count($userinfo['udata']['prod']);
						for($x = 1;$x <= $count; $x++){
							if($userinfo['udata']['prod'][$x][0] == $checkj['jxtra']){
								$userinfo['udata']['prod'][$x][1] = $userinfo['udata']['prod'][$x][1]+$checkj['giftqty'];
								$ss = '1';
							}
						}
						if(!$ss){
							$userinfo['udata']['prod'][$x][0] = $checkj['jxtra'];
							$userinfo['udata']['prod'][$x][1] = $checkj['giftqty'];
						}
					}
					if($checkj['gifttype'] == '4'){//���ӷ���
						$count = count($userinfo['udata']['fertilize']);
						for($x = 1;$x <= $count; $x++){
							if($userinfo['udata']['fertilize'][$x][0] == $checkj['jxtra']){
								$userinfo['udata']['fertilize'][$x][1] = $userinfo['udata']['fertilize'][$x][1]+$checkj['giftqty'];
								$ss = '1';
							}
						}
						if(!$ss){
							$userinfo['udata']['fertilize'][$x][0] = $checkj['jxtra'];
							$userinfo['udata']['fertilize'][$x][1] = $checkj['giftqty'];
						}
					}
					if($checkj['gifttype'] == '5'){//���ӻ���
						$cdd['extcredits'.$checkj['jxtra']] = '+'.$checkj['giftqty'];
						updatemembercount($_G['uid'], $cdd, true, '', 0, '',$jnc['title'],lang("plugin/$jn","s113"));
					}
					if($cardon == '1'){
						if($checkj['gifttype'] == '6'){//���ӿ��ƻ���Ƭ
							$checkcard = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_card')." WHERE jcid = '".$checkj['jxtra']."'");
							if($checkcard['type'] == 'suipian'){
								$c = DB::result_first("SELECT count(*) cnt FROM ".DB::table('game_jnfarm_card_user')." WHERE uid = '".$_G['uid']."' AND type = 'suipian'");
								$max = $userinfo['spck']+$sysinfo['setdata']['card']['spextend'][2];
								$c >= $max ? $cangku = 1 : $cangku = 0;
								$nosuccess = cardadd($checkcard['type'],$checkj['giftqty'],$checkj['jxtra'],$_G['uid'],$cangku);
								if($nosuccess == '1'){
									$itemlost = 1;
								}
							}
							if($checkcard['type'] == 'card'){
								for($x=1;$x<=$checkj['giftqty'];$x++){
									$c = DB::result_first("SELECT count(*) cnt FROM ".DB::table('game_jnfarm_card_user')." WHERE uid = '".$_G['uid']."' AND type = 'card'");
									$max = $userinfo['kpck']+$sysinfo['setdata']['card']['kpextend'][2];
									if($c >= $max){
										$itemlost = 1;
									}else{
										cardadd('card',1,$checkj['jxtra'],$_G['uid'],0);
									}
								}
							}
							if($itemlost == '1'){
								$itemlostlog = lang("plugin/$jn","s454");
							}
						}
					}
					
					
					//��ɳɾ�
					$thislang = lang("plugin/$jn","s115",array('checkjjatitle'=>$checkj['jatitle'],'checkjpadd'=>$checkj['padd'],'achieveb4'=>$achieveb4,'achieveat'=>$achieveat)).$itemlostlog;//"��ɳɾ�".$checkj['jatitle']."���".$checkj['padd']."�ɾ͵�".$achieveb4."->".$achieveat;
					nlog($_G['uid'],0,$_G['timestamp'],$thislang);

					$userinfo['udata'] = json_encode($userinfo['udata']);
					C::t('#'.$jn.'#'.$jn.'_user')->update($userinfo['juid'],array('udata'=>$userinfo['udata'],'lastsituation'=>$_G['timestamp']));

					$word = lang("plugin/$jn","s114");;
					$linkgen = '<script>ajaxget(\'plugin.php?id='.$jn.'&do=normal&ac=userinfo&timestamp='.$_G['timestamp'].'\',\'userinfo\');ajaxget(\'plugin.php?id=jnfarm&do=achieve&type='.$checkj['jatype'].'&timestamp='.$_G['timestamp'].'\',\'achievelist\');layer.msg(\''.$word.'\')</script>';
					include template($jn.':'.$jn.'_normal');
					exit;
				}
			}
		}
	}
	$gtype = dintval($_GET['type']);
	if(!$gtype){
		$gtype = '1';
	}
	$aclist = DB::fetch_all("SELECT * FROM ".DB::table('game_jnfarm_achieve')." WHERE jatype = '$gtype' ORDER BY jaorder ASC");
	foreach($aclist as $acl){
		$acl['sucuid'] = explode(',',$acl['sucuid']);
		if(in_array($_G['uid'],$acl['sucuid'])){
			$acl['complete'] = '1';
			$acl['rr'] = '1';
		}
		//����Ƿ���ǰ��
		if($acl['frontac'] > 0){
			$sfr = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_achieve')." WHERE jatype = '$gtype' AND jaid = '".$acl['frontac']."'");
			$sfr['sucuid'] = explode(',',$sfr['sucuid']);
			if(!in_array($_G['uid'],$sfr['sucuid'])){
				continue;
			}
		}
		//����
		if($acl['gifttype'] == '1'){
			$acl['gtitle'] = $jnc['mt'];
		}
		if($acl['gifttype'] == '2'){
			$acl['gtitle'] = $sdlist[$acl['jxtra']]['stitle'].lang("plugin/$jn","s038");
		}
		if($acl['gifttype'] == '3'){
			$acl['gtitle'] = $sdlist[$acl['jxtra']]['stitle'];
		}
		if($acl['gifttype'] == '4'){
			$acl['gtitle'] = $felist[$acl['jxtra']]['stitle'];
		}
		if($acl['gifttype'] == '5'){
			$acl['gtitle'] = '['.lang("plugin/$jn","s108").']'.$_G['setting']['extcredits'][$acl['jxtra']]['title'];
		}
		if($acl['gifttype'] == '6'){
			$acl['gtitle'] = $cardall[$acl['jxtra']]['ctitle'];
		}
		//��ǰ�����Ƿ��Ѵ��
		if($acl['jatype'] == '1'){//�ȼ�
			$acl['now'] = $userinfo['udata']['data']['farmlvl'];
			if($userinfo['udata']['data']['farmlvl'] >= $acl['jaqty']){
				$acl['succ'] = '1';
			}
		}
		if($acl['jatype'] == '2'){//��ֲ�ܴ���
			$cs = 0;
			$cplant = count($sdlist);
			for($x=1;$x<=$cplant;$x++){
				$cs = $cs+$userinfo['udata']['plantrecord'][$x][0]; //������ֲ�ܴ���, ��Ҫ���һ��
			}
			$acl['now'] = $cs;
			if($cs >= $acl['jaqty']){
				$acl['succ'] = '1';
			}
		}
		if($acl['jatype'] == '3'){//�ճ�������
			$cplant = count($sdlist);
			$cs = 0;
			for($x=1;$x<=$cplant;$x++){
				$cs = $cs+$userinfo['udata']['harvestrecord'][$x][0]; //��Ҫ���һ��
			}
			$acl['now'] = $cs;
			if($cs >= $acl['jaqty']){
				$acl['succ'] = '1';
			}
		}
		if($acl['jatype'] == '4'){//��Ǯ��
			$acl['now'] = $userinfo['udata']['data']['money'];
			if($userinfo['udata']['data']['money'] >= $acl['jaqty']){
				$acl['succ'] = '1';
			}
		}
		if($acl['jatype'] == '5'){//��ֲĳ�����
			if(!$userinfo['udata']['plantrecord'][$acl['wxtra']][0]){
				$userinfo['udata']['plantrecord'][$acl['wxtra']][0] = '0';
			}
			$acl['now'] = $userinfo['udata']['plantrecord'][$acl['wxtra']][0];
			if($userinfo['udata']['plantrecord'][$acl['wxtra']][0] >= $acl['jaqty']){
				$acl['succ'] = '1';
			}
		}
		if($acl['jatype'] == '6'){//��ֲĳ�����
			$acl['now'] = $userinfo['udata']['harvestrecord'][$acl['wxtra']][0];
			if(!$acl['now']){
				$acl['now'] = '0';
			}
			if($userinfo['udata']['harvestrecord'][$acl['wxtra']][0] >= $acl['jaqty']){
				$acl['succ'] = '1';
			}
		}
		if($acl['jatype'] == '7'){//���˹���
			$acl['now'] = $userinfo['uindigx'];
			if(!$acl['now']){
				$acl['now'] = '0';
			}
			if($userinfo['uindigx'] >= $acl['jaqty']){
				$acl['succ'] = '1';
			}
		}
		if($acl['jatype'] == '8'){//���˹���
			$acl['now'] = $userinfo['uguildgx'];
			if(!$acl['now']){
				$acl['now'] = '0';
			}
			if($userinfo['uguildgx'] >= $acl['jaqty']){
				$acl['succ'] = '1';
			}
		}
		$alist[] = $acl;
	}
	
	$rank = DB::fetch_all("SELECT * FROM ".DB::table('game_jnfarm_achieve')." LIMIT 10");//���ܿ��԰�����
	foreach($rank as $fr){
		$fr['udata'] = json_decode($fr['udata'],true);
		$moneylist[] = $fr;
		$lvllist[] = $fr;
	}
	usort($moneylist, function($a, $b) { //Sort the array using a user defined function
		return $a['udata']['data']['money'] > $b['udata']['data']['money'] ? -1 : 1; //Compare the scores
	});
	usort($lvllist, function($a, $b) { //Sort the array using a user defined function
		return $a['udata']['data']['farmlvl'] > $b['udata']['data']['farmlvl'] ? -1 : 1; //Compare the scores
	});
	
	include template($jn.':'.$jn.'_normal');
	exit;
}
//From: Dism��taobao��com
?>