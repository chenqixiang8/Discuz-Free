<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
};
if (!$_G['uid']) showmessage('not_loggedin','',array(), array('login' => true));
if ($reallanddirecton == '1'){
	exit;
}
if($_GET['formhash'] == $_G['formhash']){
	//timetype, 1=guild
	if($guildon == '1'){
		$clast = strtotime("last Sunday");
		$sguild = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_dateline')." WHERE fordate = '".$clast."' AND timetype = 1");
		
		if(!$sguild['jdid']){
			//��������
			$sreward = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_guild_gxreward')." ORDER BY jgrid ASC LIMIT 1");
			//500 single query
			$sreward['jgjoin'] = json_decode($sreward['jgjoin'],true);
			
			$salluser = DB::fetch_all("SELECT * FROM ".DB::table('game_jnfarm_user')." WHERE weekindigx >= '".$sreward['jgjoin']['canyucishu']."' ORDER BY weekindigx DESC, lastjs ASC");
			$x = 1;
			foreach($salluser as $su){
				$newdata[$x] = '('.$x.','.$su['uid'].','.$clast.')';
				$logdesc[$x] = '('.$x.','.$su['uid'].','.date("Y-m-d",$clast).','.$su['weekindigx'].')';
				$x++;
			}
			
			$logdesc = 'Personal Data '.implode(',',$logdesc);
			nlog(0,12,$_G['timestamp'],$logdesc);
			$logdesc = array();
			
			$pagesplit = 500;//500��generateһ��
			$firstpage = 0;
			$tpp = $pagesplit;
			$runningtime = ceil(count($salluser)/$pagesplit);
			for($y=1;$y<=$runningtime;$y++){
				$genewdata = array_slice($newdata, $firstpage, $tpp);
				$tobeupdate = implode(',',$genewdata);
				DB::query("REPLACE INTO ".DB::table('game_jnfarm_guild_reward')." (jgmc,uid,fordate) VALUES ".$tobeupdate."");
				
				$firstpage = $firstpage+$pagesplit;
				$tpp = $tpp+$pagesplit;
				if($tpp >= count($salluser)){
					$tpp = count($salluser);
				}
			}
			
			DB::query("UPDATE ".DB::table('game_jnfarm_user')." SET weekindigx = 0");
			
			//���᳤����
			$hzreward = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_guild_hzgxreward')." ORDER BY jgrid ASC LIMIT 1");
			$hzreward['jgjoin'] = json_decode($hzreward['jgjoin'],true);
			
			$sallhz = DB::fetch_all("SELECT * FROM ".DB::table('game_jnfarm_guild')." WHERE weekgx >= '".$hzreward['jgjoin']['canyucishu']."' ORDER BY weekgx DESC, lastjs ASC");
			$x = 1;
			foreach($sallhz as $sh){
				$newhz[$x] = '('.$x.','.$sh['owner'].','.$clast.')';
				$logdesc[$x] = '('.$x.','.$sh['uid'].','.date("Y-m-d",$clast).','.$sh['weekgx'].')';
				$x++;
			}
			
			$logdesc = 'Huizhang Data '.implode(',',$logdesc);
			nlog(0,12,$_G['timestamp'],$logdesc);
			
			$pagesplit = 500;//500��generateһ��
			$firstpage = 0;
			$tpp = $pagesplit;
			$runningtime = ceil(count($sallhz)/$pagesplit);
			for($y=1;$y<=$runningtime;$y++){
				$genewdata = array_slice($newhz, $firstpage, $tpp);
				$tobeupdate = implode(',',$genewdata);
				DB::query("REPLACE INTO ".DB::table('game_jnfarm_guild_hzreward')." (jgmc,uid,fordate) VALUES ".$tobeupdate."");
				
				$firstpage = $firstpage+$pagesplit;
				$tpp = $tpp+$pagesplit;
				if($tpp >= count($sallhz)){
					$tpp = count($sallhz);
				}
			}
			DB::query("UPDATE ".DB::table('game_jnfarm_guild')." SET weekgx = 0");
			
			DB::query("REPLACE INTO ".DB::table('game_jnfarm_dateline')." (fordate,timetype) VALUES (".$clast.",1)");
		}
		
	}
	if($cardon == '1'){
		if(file_exists(DISCUZ_ROOT.'source/plugin/'.$jn.'/module/card_pk.php')){
			$tuecheck = strtotime("this Tuesday 12:00:00");//���ڶ�
			if($_G['timestamp'] >= $tuecheck){
				$scard = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_dateline')." WHERE fordate = '".$tuecheck."' AND timetype = 1");
				if(!$scard['jdid']){
					//��������
					$sreward = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_card_pkreward_tue')." ORDER BY jgrid ASC LIMIT 1");
					$sreward['jgjoin'] = json_decode($sreward['jgjoin'],true);
					
					$getrank = DB::fetch_all("SELECT * FROM ".DB::table('game_jnfarm_user')." WHERE pkpoint >= '".$sysinfo['setdata']['pk']['tuesday']['basic']."' ORDER BY pkpoint DESC, pktime ASC");
					$x = 1;
					foreach($getrank as $gr){
						$newdata[$x] = '('.$x.','.$gr['uid'].','.$tuecheck.')';
						$x++;
					}
					$pagesplit = 500;//500��generateһ��
					$firstpage = 0;
					$tpp = $pagesplit;
					$runningtime = ceil(count($getrank)/$pagesplit);
					for($y=1;$y<=$runningtime;$y++){
						$genewdata = array_slice($newdata, $firstpage, $tpp);
						$tobeupdate = implode(',',$genewdata);
						DB::query("REPLACE INTO ".DB::table('game_jnfarm_card_pkreward_tue_user')." (jgmc,uid,fordate) VALUES ".$tobeupdate."");
						
						$firstpage = $firstpage+$pagesplit;
						$tpp = $tpp+$pagesplit;
						if($tpp >= count($getrank)){
							$tpp = count($getrank);
						}
					}
					
					$tuelog = 'Tusday rank update data'.json_encode($newdata,true);
					nlog(0,12,$_G['timestamp'],$tuelog);
					DB::query("UPDATE ".DB::table('game_jnfarm_user')." SET pkpoint = 0, pkfreeze = 0, pktime = 0");
					DB::query("REPLACE INTO ".DB::table('game_jnfarm_dateline')." (fordate,timetype) VALUES (".$tuecheck.",1)");
				}
			}
			$satcheck = strtotime("this Saturday 12:00:00");//���ڶ�
			if($_G['timestamp'] >= $satcheck){
				$scard = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_dateline')." WHERE fordate = '".$satcheck."' AND timetype = 1");
				if(!$scard['jdid']){
					//��������
					$sreward = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_card_pkreward_sat')." ORDER BY jgrid ASC LIMIT 1");
					$sreward['jgjoin'] = json_decode($sreward['jgjoin'],true);
					
					$getrank = DB::fetch_all("SELECT * FROM ".DB::table('game_jnfarm_user')." WHERE pkpoint >= '".$sysinfo['setdata']['pk']['saturday']['basic']."' ORDER BY pkpoint DESC, pktime ASC");
					$x = 1;
					foreach($getrank as $gr){
						$newdata[$x] = '('.$x.','.$gr['uid'].','.$satcheck.')';
						$x++;
					}
					$pagesplit = 500;//500��generateһ��
					$firstpage = 0;
					$tpp = $pagesplit;
					$runningtime = ceil(count($getrank)/$pagesplit);
					for($y=1;$y<=$runningtime;$y++){
						$genewdata = array_slice($newdata, $firstpage, $tpp);
						$tobeupdate = implode(',',$genewdata);
						DB::query("REPLACE INTO ".DB::table('game_jnfarm_card_pkreward_sat_user')." (jgmc,uid,fordate) VALUES ".$tobeupdate."");
						
						$firstpage = $firstpage+$pagesplit;
						$tpp = $tpp+$pagesplit;
						if($tpp >= count($getrank)){
							$tpp = count($getrank);
						}
					}
					
					$satlog = 'Tusday rank update data'.json_encode($newdata,true);
					nlog(0,12,$_G['timestamp'],$satlog);
					DB::query("UPDATE ".DB::table('game_jnfarm_user')." SET pkpoint = 0, pkfreeze = 0, pktime = 0");
					DB::query("REPLACE INTO ".DB::table('game_jnfarm_dateline')." (fordate,timetype) VALUES (".$satcheck.",1)");
				}
			}
		}
		$clast = strtotime("this Thursday 12:00:00");
		if($_G['timestamp'] >= $clast){
			$scard = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_dateline')." WHERE fordate = '".$clast."' AND timetype = 1");
			if(!$scard['jdid']){
				//��������
				$sreward = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_card_zlreward')." ORDER BY jgrid ASC LIMIT 1");
				//500 single query
				$sreward['jgjoin'] = json_decode($sreward['jgjoin'],true);
				
				$getrank = DB::fetch_all("SELECT t1.*,t2.jgid,t2.uposition FROM ".DB::table('game_jnfarm_card_user')." t1 LEFT JOIN ".DB::table('game_jnfarm_user')." t2 ON (t1.uid = t2.uid) WHERE t1.type = 'card' AND t1.uid > 0 ORDER BY t1.basiczhanli ASC");
				foreach($getrank as $grl){
					if($grl['jgid'] > 0){
						$guildarray[$grl['uid']] = $allguild[$grl['jgid']]['jgtitle'].$sysinfo['guildset'][$grl['uposition']];
					}
					if($nnarray[$grl['uid']][$grl['jcid']] <= $grl['basiczhanli']){
						$nnarray[$grl['uid']][$grl['jcid']] = $grl['basiczhanli'];
					}
				}
				foreach($nnarray as $key => $value){
					foreach($nnarray[$key] as $nkey => $nvalue){
						$newarray[$key] = $newarray[$key]+$nvalue;
					}
				}
				arsort($newarray);
				
				//$salluser = DB::fetch_all("SELECT * FROM ".DB::table('game_jnfarm_user')." WHERE weekindigx >= '".$sreward['jgjoin']['canyucishu']."' ORDER BY weekindigx DESC, lastjs ASC");
				$x = 1;
				foreach($newarray as $key => $value){
					$newdata[$x] = '('.$x.','.$key.','.$clast.')';
					$x++;
				}
				
				$pagesplit = 500;//500��generateһ��
				$firstpage = 0;
				$tpp = $pagesplit;
				$runningtime = ceil(count($newarray)/$pagesplit);
				for($y=1;$y<=$runningtime;$y++){
					$genewdata = array_slice($newdata, $firstpage, $tpp);
					$tobeupdate = implode(',',$genewdata);
					DB::query("REPLACE INTO ".DB::table('game_jnfarm_card_reward')." (jgmc,uid,fordate) VALUES ".$tobeupdate."");
					
					$firstpage = $firstpage+$pagesplit;
					$tpp = $tpp+$pagesplit;
					if($tpp >= count($newarray)){
						$tpp = count($newarray);
					}
				}
				
				//DB::query("UPDATE ".DB::table('game_jnfarm_user')." SET weekindigx = 0");
				
				//���᳤����
				
				$hzreward = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_card_hzzlreward')." ORDER BY jgrid ASC LIMIT 1");
				$hzreward['jgjoin'] = json_decode($hzreward['jgjoin'],true);
				
				//�ѿ���ս����������
				$getrank = DB::fetch_all("SELECT t1.*,t2.jgid FROM ".DB::table('game_jnfarm_card_user')." t1 LEFT JOIN ".DB::table('game_jnfarm_user')." t2 ON (t1.uid = t2.uid) WHERE t1.type = 'card' AND t1.uid > 0 AND t2.jgid > 0 ORDER BY t1.basiczhanli ASC");
				$newarray = array();
				$guildarray = array();
				$nnarray = array();
				foreach($getrank as $grl){
					//������û��м����̻�
					if($grl['jgid'] > 0){
						//��uid
						$guildarray[$grl['uid']] = $allguild[$grl['jgid']]['jgtitle'].$sysinfo['guildset'][$grl['uposition']];
					}
					if($nnarray[$grl['jgid']][$grl['uid']][$grl['jcid']] <= $grl['basiczhanli']){
						$nnarray[$grl['jgid']][$grl['uid']][$grl['jcid']] = $grl['basiczhanli'];
					}
				}
				foreach($nnarray as $key => $value){
					foreach($nnarray[$key] as $nkey => $nvalue){
						foreach($nnarray[$key][$nkey] as $nnkey => $nnvalue){
							$newarray[$key] = $newarray[$key]+$nnvalue;
						}
						
					}
				}
				arsort($newarray);
				
				$basicnewarray = 'HZKP reward part A: '.json_encode($newarray);
				
				$getowner = DB::fetch_all("SELECT * FROM ".DB::table('game_jnfarm_guild')."");
				$getowner = array_column($getowner,null,'jgid');
				
				$x = 1;
				foreach($newarray as $key => $value){
					$newhz[$x] = '('.$x.','.$getowner[$key]['owner'].','.$clast.')';
					$logdesc[$x] = '('.$x.','.$getowner[$key]['owner'].','.date("Y-m-d",$clast).')';
					$x++;
				}
				
				$logdesc = $basicnewarray.' HZKP reward part B: '.implode(',',$logdesc);
				nlog(0,12,$_G['timestamp'],$logdesc);
				$logdesc = array();
			
				$pagesplit = 500;//500��generateһ��
				$firstpage = 0;
				$tpp = $pagesplit;
				$runningtime = ceil(count($newarray)/$pagesplit);
				for($y=1;$y<=$runningtime;$y++){
					$genewdata = array_slice($newhz, $firstpage, $tpp);
					$tobeupdate = implode(',',$genewdata);
					DB::query("REPLACE INTO ".DB::table('game_jnfarm_card_hzreward')." (jgmc,uid,fordate) VALUES ".$tobeupdate."");
					
					$firstpage = $firstpage+$pagesplit;
					$tpp = $tpp+$pagesplit;
					if($tpp >= count($newarray)){
						$tpp = count($newarray);
					}
				}
				//DB::query("UPDATE ".DB::table('game_jnfarm_guild')." SET weekgx = 0");
				
				DB::query("REPLACE INTO ".DB::table('game_jnfarm_dateline')." (fordate,timetype) VALUES (".$clast.",1)");
				
			}
		}

		
		
	}
}
//From: Dism��taobao��com
?>