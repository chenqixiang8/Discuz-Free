<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
};
if (!$_G['uid']) showmessage('not_loggedin','',array(), array('login' => true));
if ($reallanddirecton == '1'){
	exit;
}
$pass = substr(md5(uniqid(mt_rand(), true)) , 0, 8);
if($_GET['do'] == 'market'){
	if(!$userinfo['udata']['market']){
		$userinfo['udata']['market']['sellqty'] = '0';
		$userinfo['udata']['market']['sellamount'] = '0';
	}
	$market = DB::fetch_all("SELECT * FROM ".DB::table('game_jnfarm_market')."");
	$mksell = '0';
	$mkamount = '0';
	$mkqty = '0';
	foreach($market as $mk){
		$mk['mdata'] = json_decode($mk['mdata'],true);
		if($mk['buytime'] > 0){
			$mkamount = $mkamount+($mk['mdata']['amount']*$mk['mdata']['qty']);
			$mksell = $mksell+1;
		}else{
			if($mk['buyuid'] != $mk['selluid']){
				$mkqty = $mkqty+1;
			}
		}
		$mklist[] = $mk;
	}
	if(!$sysinfo['setdata']['marketmax']){
		$max = '10';
	}else{
		$max = $sysinfo['setdata']['marketmax'];
	}
	$now = DB::result_first("SELECT count(*) cnt FROM ".DB::table('game_jnfarm_market')." WHERE selluid = '".$_G['uid']."' AND buyuid = '0' AND buytime = '0'");
	$left = $max-$now;
	
	if($_GET['ac']){
		$cprod = count($userinfo['udata']['prod']);//��ǰ�û��е���������
		$cfert = count($userinfo['udata']['fertilize']);//��ǰ�û��еķ�������
		$cseed = count($userinfo['udata']['seed']);//��ǰ�û��е���������
		$ctili = count($userinfo['udata']['tiliitem']);
		//�ӽ�ȥ
		$marray = array('1'=>array($cprod,'prod'),'2'=>array($cfert,'fertilize'),'3'=>array($cseed,'seed'));
		$cm = count($marray);
	}
	if($tiliitemon == '1'){
		$tili = DB::fetch_all("SELECT * FROM ".DB::table('game_jnfarm_item')." WHERE type = 'tiliitem' ORDER BY jsid ASC");
		foreach($tili as $tl){
			$tl['sdata'] = json_decode($tl['sdata'],true);
			$tilist[] = $tl;
		}
		$tilist = array_column($tilist,null,'jsid');
	}
	if($cardon == '1'){
		$cardlist = C::t('#jnfarm#jnfarm_card')->loadall();
		foreach($cardlist as $cl){
			$cl['cdata'] = json_decode($cl['cdata'],true);
			$cardall[] = $cl;
		}
		$cardall = array_column($cardall,null,'jcid');
	}
	if($_GET['ac'] == 'takedown'){
		if($_GET['formhash'] == $_G['formhash']){
			$jmid = dintval($_GET['jmid']);
			$jinfo = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_market')." WHERE jmid = '$jmid' AND selluid = '".$_G['uid']."' AND buyuid = '0' AND buytime = '0'");
			if($jinfo['jmid'] > 0){
				$jinfo['mdata'] = json_decode($jinfo['mdata'],true);
				if($jinfo['mtype'] == 'seed'){
					for($x=1;$x<=$cseed;$x++){
						if($userinfo['udata']['seed'][$x][0] == $jinfo['mdata'][0]){
							$itemtitle = $sdlist[$userinfo['udata']['seed'][$x][0]]['stitle'].lang("plugin/$jn","s038");
							$oriqty = $userinfo['udata']['seed'][$x][1];
							$userinfo['udata']['seed'][$x][1] = $userinfo['udata']['seed'][$x][1]+$jinfo['mdata'][2];
							$afterqty = $userinfo['udata']['seed'][$x][1];
						}
					}
				}
				if($jinfo['mtype'] == 'fert'){
					for($x=1;$x<=$cfert;$x++){
						if($userinfo['udata']['fertilize'][$x][0] == $jinfo['mdata'][0]){
							$itemtitle = $sdlist[$userinfo['udata']['fertilize'][$x][0]]['stitle'];
							$oriqty = $userinfo['udata']['fertilize'][$x][1];
							$userinfo['udata']['fertilize'][$x][1] = $userinfo['udata']['fertilize'][$x][1]+$jinfo['mdata'][2];
							$afterqty = $userinfo['udata']['fertilize'][$x][1];
						}
					}
				}
				if($jinfo['mtype'] == 'prod'){
					for($x=1;$x<=$cprod;$x++){
						if($userinfo['udata']['prod'][$x][0] == $jinfo['mdata'][0]){
							$itemtitle = $sdlist[$userinfo['udata']['prod'][$x][0]]['stitle'];
							$oriqty = $userinfo['udata']['prod'][$x][1];
							$userinfo['udata']['prod'][$x][1] = $userinfo['udata']['prod'][$x][1]+$jinfo['mdata'][2];
							$afterqty = $userinfo['udata']['prod'][$x][1];
						}
					}
				}
				if($jinfo['mtype'] == 'tiliitem'){
					for($x=1;$x<=$ctili;$x++){
						if($userinfo['udata']['tiliitem'][$x][0] == $jinfo['mdata'][0]){
							$itemtitle = $allist[$userinfo['udata']['tiliitem'][$x][0]]['stitle'];
							$oriqty = $userinfo['udata']['tiliitem'][$x][1];
							$userinfo['udata']['tiliitem'][$x][1] = $userinfo['udata']['tiliitem'][$x][1]+$jinfo['mdata'][2];
							$afterqty = $userinfo['udata']['tiliitem'][$x][1];
						}
					}
				}
				if($jinfo['mtype'] == 'card'){
					DB::query("UPDATE ".DB::table('game_jnfarm_card_user')." SET uid = '".$_G['uid']."' WHERE jcuid = '".$jinfo['mdata'][0]."'");
				}
				if($jinfo['mtype'] == 'suipian'){
					$ownsp = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_card_user')." WHERE jcid = '".$jinfo['mdata'][3]."' AND uid = '".$_G['uid']."'");
					if($ownsp['jcuid'] > 0 && $ownsp['qty'] > 0){
						$c = DB::result_first("SELECT count(*) cnt FROM ".DB::table('game_jnfarm_card_user')." WHERE uid = '".$_G['uid']."' AND type = 'card'");
						$maxnow = $userinfo['kpck'] + $sysinfo['setdata']['card']['kpextend'][2];
						if($c >= $maxnow){
							jnmsg(lang("plugin/$jn","s454"));
						}
						DB::query("UPDATE ".DB::table('game_jnfarm_card_user')." SET qty = qty+'".$jinfo['mdata'][2]."' WHERE jcid = '".$jinfo['mdata'][3]."' AND uid = '".$_G['uid']."'");
					}else{
						//��鵱ǰ�Ƿ����㹻�ֿ�ռ�λ��
						$max = $userinfo['spck']+$sysinfo['setdata']['card']['spextend'][2];
						$cnow = DB::result_first("SELECT count(*) cnt FROM ".DB::table('game_jnfarm_card_user')." WHERE uid = '".$_G['uid']."' AND type = 'suipian' AND qty > 0 AND jcid > 0");
						$cnow >= $max ? $cangku = 1 : $cangku = 0;
						$nosuccess = cardadd('suipian',$jinfo['mdata'][2],$jinfo['mdata'][3],$_G['uid'],$cangku);
						if($nosuccess == '1'){
							jnmsg(lang("plugin/$jn","s454"));
						}
					}
				}
				
				$userinfo['udata'] = json_encode($userinfo['udata'],true);
				C::t('#'.$jn.'#'.$jn.'_user')->update($userinfo['juid'],array('udata'=>$userinfo['udata'],'lastsituation'=>$_G['timestamp']));
				DB::query("UPDATE ".DB::table('game_jnfarm_market')." SET buyuid = '".$_G['uid']."' WHERE jmid = '$jmid'");
				
				$thislang = lang("plugin/$jn","s102").$itemtitle.'x'.$jinfo['mdata'][2]. '('.$oriqty.'->'.$afterqty.')';
				nlog($_G['uid'],5,$_G['timestamp'],$thislang);

				$linkgen = '<script>ajaxget(\'plugin.php?id='.$jn.'&do=market&ac=takedown&timestamp='.$_G['timestamp'].$pass.'\',\'marketlist\');layer.msg(\''.lang("plugin/$jn","s101").'\');</script>';
				include template($jn.':'.$jn.'_normal_plain');
				exit;
			}
		}
		$sell = DB::fetch_all("SELECT * FROM ".DB::table('game_jnfarm_market')." WHERE selluid = '".$_G['uid']."' AND buyuid != '".$_G['uid']."' AND buytime = '0'");
		foreach($sell as $sl){
			$sl['mdata'] = json_decode($sl['mdata'],true);
			if($sl['mtype'] == 'prod'){
				$currentlist = $sdlist;
				$zhz = '';
			}
			if($sl['mtype'] == 'fert'){
				$currentlist = $felist;
				$zhz = '';
			}
			if($sl['mtype'] == 'seed'){
				$currentlist = $sdlist;
				$zhz = lang("plugin/$jn","s038");
			}
			if($tiliitemon == '1'){
				if($sl['mtype'] == 'tiliitem'){
					$currentlist = $tilist;
					$zhz = '';
				}
			}			
			$sl['price'] = $sl['mdata'][1]*$sl['mdata'][2];
			if($sl['mtype'] == 'card' || $sl['mtype'] == 'suipian'){
				$sl['stitle'] = $cardall[$sl['mdata'][3]]['ctitle'];
			}else{
				$sl['stitle'] = $currentlist[$sl['mdata'][0]]['stitle'].$zhz;
			}
			$sllist[] = $sl;
		}
	}
	if($_GET['ac'] == 'sell'){
		//���û��ֿ���Ķ��������г���
		$gettimestamp = $_GET['timestamp'];
		
		$selltype = dintval($_GET['selltype']);
		if($selltype == '1'){//��ͨ
			$cseed = count($userinfo['udata']['seed']);//��ǰ�û��е���������
			$cprod = count($userinfo['udata']['prod']);//��ǰ�û��е���������
			$cfert = count($userinfo['udata']['fertilize']);//��ǰ�û��еķ�������
			$ctili = count($userinfo['udata']['tiliitem']);
			
			//�ӽ�ȥ
			$marray = array('1'=>array($cprod,'prod'),'2'=>array($cfert,'fertilize'),'3'=>array($cseed,'seed'),'4'=>array($ctili,'tiliitem'));
			$cm = count($marray);
			for($y=1;$y<=$cm;$y++){
				if($y == '1'){
					$currentlist = $sdlist;
				}
				if($y == '2'){
					$currentlist = $felist;
				}
				if($y == '3'){
					$currentlist = $sdlist;
					$zhz = lang("plugin/$jn","s038");
				}
				if($y == '4'){
					$currentlist = $tilist;
					$zhz = '';
				}
				for($x=1;$x<=$marray[$y][0];$x++){
					if($currentlist[$userinfo['udata'][$marray[$y][1]][$x][0]]['sdata']['prodmarket'] == '1'){//prodmarketΪ�ɳ���
						if($userinfo['udata'][$marray[$y][1]][$x][1] > '0'){
							$text .= '<div style="border:1px dotted black; padding:0.5em; margin-top:0.4em;" class="control-group"><label class="control control-checkbox">
					<input type="checkbox" name="'.$marray[$y][1].$x.'" value="1" class="single-checkbox'.$_GET['timestamp'].'"/>
					<div class="control_indicator"></div>
				</label> <span style="margin-left:2.5em;">'.$currentlist[$userinfo['udata'][$marray[$y][1]][$x][0]]['stitle'].$zhz.'</span> <div class="number-input" align="right" style="float:right;">
		  <span onclick="this.parentNode.querySelector(\'input[type=number]\').stepDown()" >&nbsp;-&nbsp;</span>
		  <input class="quantity" min="'.$currentlist[$userinfo['udata'][$marray[$y][1]][$x][0]]['sdata']['prodmprice'][0].'" max="'.$currentlist[$userinfo['udata'][$marray[$y][1]][$x][0]]['sdata']['prodmprice'][1].'" name="'.$marray[$y][1].'sellprice'.$x.'" value="'.$currentlist[$userinfo['udata'][$marray[$y][1]][$x][0]]['sdata']['prodmprice'][0].'" type="number" style="width:30px;">
		  <span onclick="this.parentNode.querySelector(\'input[type=number]\').stepUp()" class="plus">&nbsp;+&nbsp;</span>
		</div><div style="float:right;">&nbsp;&nbsp;'.lang("plugin/$jn","s090").'&nbsp;</div> <div class="number-input" align="right" style="float:right;">
		  <span onclick="this.parentNode.querySelector(\'input[type=number]\').stepDown()" >&nbsp;-&nbsp;</span>
		  <input class="quantity" min="0" max="'.$userinfo['udata'][$marray[$y][1]][$x][1].'" name="'.$marray[$y][1].'sellqty'.$x.'" value="0" type="number" style="width:30px;">
		  <span onclick="this.parentNode.querySelector(\'input[type=number]\').stepUp()" class="plus">&nbsp;+&nbsp;</span>
		</div><div style="float:right">'.lang("plugin/$jn","s091").'&nbsp;</div><div style="clear:both"></div></div>';
						};
					}
				}
			}
		}
		if($selltype == '2'){//����or��Ƭ
			if($cardon == '1'){
				$usercard = C::t('#jnfarm#jnfarm_card_user')->loadusercard($_G['uid'],'card');
				foreach($usercard as $uc){
					if($cardall[$uc['jcid']]['cdata']['prodmarket'] == '1'){
						$text .= '<div style="border:1px dotted black; padding:0.5em; margin-top:0.4em;" class="control-group"><label class="control control-checkbox">
					<input type="checkbox" name="card[]" value="'.$uc['jcuid'].'" class="single-checkbox'.$_GET['timestamp'].'"/>
					<div class="control_indicator"></div>
				</label> <span style="margin-left:2.5em;">'.$cardall[$uc['jcid']]['ctitle'].'('.$uc['lvl'].')</span> <div class="number-input" align="right" style="float:right;">
		  <span onclick="this.parentNode.querySelector(\'input[type=number]\').stepDown()" >&nbsp;-&nbsp;</span>
		  <input class="quantity" min="'.$cardall[$uc['jcid']]['cdata']['prodmprice0'].'" max="'.$cardall[$uc['jcid']]['cdata']['prodmprice1'].'" name="sellprice['.$uc['jcuid'].']" value="'.$cardall[$uc['jcid']]['cdata']['prodmprice0'].'" type="number" style="width:30px;">
		  <span onclick="this.parentNode.querySelector(\'input[type=number]\').stepUp()" class="plus">&nbsp;+&nbsp;</span>
		</div><div style="float:right;">&nbsp;&nbsp;'.lang("plugin/$jn","s090").'&nbsp;</div> <div class="number-input" align="right" style="float:right;">
		  <span onclick="this.parentNode.querySelector(\'input[type=number]\').stepDown()" >&nbsp;-&nbsp;</span>
		  <input class="quantity" min="1" max="1" name="'.$marray[$y][1].'sellqty'.$x.'" value="1" type="number" style="width:30px;">
		  <span onclick="this.parentNode.querySelector(\'input[type=number]\').stepUp()" class="plus">&nbsp;+&nbsp;</span>
		</div><div style="float:right">'.lang("plugin/$jn","s091").'&nbsp;</div><div style="clear:both"></div></div>';
					}
				}
			}
		}
		if($selltype == '3'){//����or��Ƭ
			if($cardon == '1'){				
				$usersp = C::t('#jnfarm#jnfarm_card_user')->loadusercard($_G['uid'],'suipian');
				foreach($usersp as $up){
					if($cardall[$up['jcid']]['cdata']['prodmarket'] == '1'){
						$text .= '<div style="border:1px dotted black; padding:0.5em; margin-top:0.4em;" class="control-group"><label class="control control-checkbox">
					<input type="checkbox" name="suipian[]" value="'.$up['jcuid'].'" class="single-checkbox'.$_GET['timestamp'].'"/>
					<div class="control_indicator"></div>
				</label> <span style="margin-left:2.5em;">'.$cardall[$up['jcid']]['ctitle'].'</span> <div class="number-input" align="right" style="float:right;">
		  <span onclick="this.parentNode.querySelector(\'input[type=number]\').stepDown()" >&nbsp;-&nbsp;</span>
		  <input class="quantity" min="'.$cardall[$up['jcid']]['cdata']['prodmprice0'].'" max="'.$cardall[$up['jcid']]['cdata']['prodmprice1'].'" name="sellprice['.$up['jcuid'].']" value="'.$cardall[$up['jcid']]['cdata']['prodmprice0'].'" type="number" style="width:30px;">
		  <span onclick="this.parentNode.querySelector(\'input[type=number]\').stepUp()" class="plus">&nbsp;+&nbsp;</span>
		</div><div style="float:right;">&nbsp;&nbsp;'.lang("plugin/$jn","s090").'&nbsp;</div> <div class="number-input" align="right" style="float:right;">
		  <span onclick="this.parentNode.querySelector(\'input[type=number]\').stepDown()" >&nbsp;-&nbsp;</span>
		  <input class="quantity" min="0" max="'.$up['qty'].'" name="sellqty['.$up['jcuid'].']" value="1" type="number" style="width:30px;">
		  <span onclick="this.parentNode.querySelector(\'input[type=number]\').stepUp()" class="plus">&nbsp;+&nbsp;</span>
		</div><div style="float:right">'.lang("plugin/$jn","s091").'&nbsp;</div><div style="clear:both"></div></div>';
					}
				}
			}
		}
		
		
		
		if($_GET['sellsubmit'] == 'yes' && $_G['formhash'] == $_GET['formhash']){
		//if(submitcheck('sellsubmit')){
			$rr = 0;
			for($x=1;$x<=$cprod;$x++){
				$prodx = dintval($_GET['prod'.$x]);
				if($prodx == '1'){
					//�������
					if($sdlist[$userinfo['udata']['prod'][$x][0]]['sdata']['prodmarket'] != '1'){
						$linkgen = iconv($_G['charset'],'UTF-8',lang("plugin/$jn","s092"));
						$final = array('final'=>$linkgen);
						echo json_encode($final);
						exit;
						//showmessage("$jn:s092"); //ǰֻ̨��ʾ���ϼ���Ʒ, ����������һ�㶼���Ըı���name
					}
					fushu($_GET['prodsellprice'.$x]);
					fushu($_GET['prodsellqty'.$x]);
					$sellprice = dintval($_GET['prodsellprice'.$x]);
					$sellqty = dintval($_GET['prodsellqty'.$x]);
					if($sellqty > 0 && $sellqty <= $userinfo['udata']['prod'][$x][1] && $sellprice >= $sdlist[$userinfo['udata']['prod'][$x][0]]['sdata']['prodmprice'][0] && $sellprice <= $sdlist[$userinfo['udata']['prod'][$x][0]]['sdata']['prodmprice'][1]){
						$rr++;
					}else{
						$linkgen = iconv($_G['charset'],'UTF-8',lang("plugin/$jn","s093"));
						$final = array('final'=>$linkgen);
						echo json_encode($final);
						exit;
						//showmessage("$jn:s093");
					}
				}
			}
			for($x=1;$x<=$cfert;$x++){
				
				$fertx = dintval($_GET['fertilize'.$x]);
				if($fertx == '1'){
					//�������
					if($felist[$userinfo['udata']['fertilize'][$x][0]]['sdata']['prodmarket'] != '1'){
						$linkgen = iconv($_G['charset'],'UTF-8',lang("plugin/$jn","s092"));
						$final = array('final'=>$linkgen);
						echo json_encode($final);
						exit;
						//showmessage("$jn:s092"); //ǰֻ̨��ʾ���ϼ���Ʒ, ����������һ�㶼���Ըı���name
					}
					
					fushu($_GET['fertilizesellprice'.$x]);
					fushu($_GET['fertilizesellqty'.$x]);
					$sellprice = dintval($_GET['fertilizesellprice'.$x]);
					$sellqty = dintval($_GET['fertilizesellqty'.$x]);
					if($sellqty > 0 && $sellqty <= $userinfo['udata']['fertilize'][$x][1] && $sellprice >= $felist[$userinfo['udata']['fertilize'][$x][0]]['sdata']['prodmprice'][0] && $sellprice <= $felist[$userinfo['udata']['fertilize'][$x][0]]['sdata']['prodmprice'][1]){
						$rr++;
					}else{
						$linkgen = iconv($_G['charset'],'UTF-8',lang("plugin/$jn","s093"));
						$final = array('final'=>$linkgen);
						echo json_encode($final);
						exit;
						//showmessage("$jn:s093");
					}
				}
				
			}
			for($x=1;$x<=$cseed;$x++){
				$seedx = dintval($_GET['seed'.$x]);
				if($seedx == '1'){
					//�������
					if($sdlist[$userinfo['udata']['seed'][$x][0]]['sdata']['prodmarket'] != '1'){
						$linkgen = iconv($_G['charset'],'UTF-8',lang("plugin/$jn","s092"));
						$final = array('final'=>$linkgen);
						echo json_encode($final);
						exit;
						//showmessage("$jn:s092"); //ǰֻ̨��ʾ���ϼ���Ʒ, ����������һ�㶼���Ըı���name
					}
					fushu($_GET['seedsellprice'.$x]);
					fushu($_GET['seedsellqty'.$x]);
					$sellprice = dintval($_GET['seedsellprice'.$x]);
					$sellqty = dintval($_GET['seedsellqty'.$x]);
					if($sellqty > 0 && $sellqty <= $userinfo['udata']['seed'][$x][1] && $sellprice >= $sdlist[$userinfo['udata']['seed'][$x][0]]['sdata']['prodmprice'][0] && $sellprice <= $sdlist[$userinfo['udata']['seed'][$x][0]]['sdata']['prodmprice'][1]){
						$rr++;
					}else{
						$linkgen = iconv($_G['charset'],'UTF-8',lang("plugin/$jn","s093"));
						$final = array('final'=>$linkgen);
						echo json_encode($final);
						exit;
						//showmessage("$jn:s093");
					}
				}
			}
			for($x=1;$x<=$ctili;$x++){
				$tilix = dintval($_GET['tiliitem'.$x]);
				if($tilix == '1'){
					//�������
					if($allist[$userinfo['udata']['tiliitem'][$x][0]]['sdata']['prodmarket'] != '1'){
						$linkgen = iconv($_G['charset'],'UTF-8',lang("plugin/$jn","s092"));
						$final = array('final'=>$linkgen);
						echo json_encode($final);
						exit;
						//showmessage("$jn:s092"); //ǰֻ̨��ʾ���ϼ���Ʒ, ����������һ�㶼���Ըı���name
					}
					fushu($_GET['tiliitemsellprice'.$x]);
					fushu($_GET['tiliitemsellqty'.$x]);
					$sellprice = dintval($_GET['tiliitemsellprice'.$x]);
					$sellqty = dintval($_GET['tiliitemsellqty'.$x]);
					if($sellqty > 0 && $sellqty <= $userinfo['udata']['tiliitem'][$x][1] && $sellprice >= $allist[$userinfo['udata']['tiliitem'][$x][0]]['sdata']['prodmprice'][0] && $sellprice <= $allist[$userinfo['udata']['tiliitem'][$x][0]]['sdata']['prodmprice'][1]){
						$rr++;
					}else{
						$linkgen = iconv($_G['charset'],'UTF-8',lang("plugin/$jn","s093"));
						$final = array('final'=>$linkgen);
						echo json_encode($final);
						exit;
						//showmessage("$jn:s093");
					}
				}
			}
			
			if($cardon == '1'){
				$y = 0;
				foreach($_GET['card'] as $jcuid){
					$jcuidlist[$y] = $jcuid;
					$y++;
				}
				if($y > 0){
					$cardselected = '('.implode(',',$jcuidlist).')';
					$mycardlist = DB::fetch_all("SELECT * FROM ".DB::table('game_jnfarm_card_user')." WHERE jcuid IN $cardselected AND uid = '".$_G['uid']."'");
					foreach($mycardlist as $mcl){
						//����ۼ�
						if($cardall[$mcl['jcid']]['cdata']['prodmarket'] != '1'){
							jnpopmsg(lang("plugin/$jn","s456"));
						}
						$getprice = dintval($_GET['sellprice'][$mcl['jcuid']]);
						if($getprice > $cardall[$mcl['jcid']]['cdata']['prodmprice1'] || $getprice < $cardall[$mcl['jcid']]['cdata']['prodmprice0']){
							jnpopmsg(lang("plugin/$jn","s457"));
						}
						$mcllist[] = $mcl;//mcl�������յ�, ����û��Ըı���, ���ݿ�û���򲻵�һ����
						$rr++;
					}
				}
				
				
				$y = 0;
				foreach($_GET['suipian'] as $spjcuid){
					$spjcuidlist[$y] = $spjcuid;
					$y++;
				}
				if($y > 0){
					$spselected = '('.implode(',',$spjcuidlist).')';
					$mysplist = DB::fetch_all("SELECT * FROM ".DB::table('game_jnfarm_card_user')." WHERE jcuid IN $spselected AND uid = '".$_G['uid']."'");
					foreach($mysplist as $msl){
						if($_GET['sellqty'][$msl['jcuid']] > $msl['qty']){
							jnpopmsg(lang("plugin/$jn","s458"));
						}
						if($cardall[$msl['jcid']]['cdata']['prodmarket'] != '1'){
							jnpopmsg(lang("plugin/$jn","s456"));
						}
						$getprice = dintval($_GET['sellprice'][$msl['jcuid']]);
						if($getprice > $cardall[$msl['jcid']]['cdata']['prodmprice1'] || $getprice < $cardall[$msl['jcid']]['cdata']['prodmprice0']){
							jnpopmsg(lang("plugin/$jn","s457"));
						}
						$msllist[] = $msl;//mcl�������յ�, ����û��Ըı���, ���ݿ�û���򲻵�һ����
						$rr++;
					}
				}
			}

			if($rr > $max){
				$linkgen = iconv($_G['charset'],'UTF-8',lang("plugin/$jn","s094"));
				$final = array('final'=>$linkgen);
				echo json_encode($final);
				exit;
				//showmessage("$jn:s094","",array('max'=>$max));
			}
			if($rr == '0'){
				$linkgen = iconv($_G['charset'],'UTF-8',lang("plugin/$jn","s095"));
				$final = array('final'=>$linkgen);
				echo json_encode($final);
				exit;
				//showmessage("$jn:s095");
			}
			//���ͨ��������д���¼��
			for($x=1;$x<=$cprod;$x++){
				$prodx = dintval($_GET['prod'.$x]);
				if($prodx == '1'){
					fushu($_GET['prodsellprice'.$x]);
					fushu($_GET['prodsellqty'.$x]);
					$mdata = array();
					$mdata[0] = $userinfo['udata']['prod'][$x][0];
					$mdata[1] = dintval($_GET['prodsellprice'.$x]);
					$mdata[2] = dintval($_GET['prodsellqty'.$x]);
					$mtype = 'prod';
					$oriqty = $userinfo['udata']['prod'][$x][1];
					$userinfo['udata']['prod'][$x][1] = $userinfo['udata']['prod'][$x][1]-$mdata[2];
					
					$msign = md5($_G['uid'].$_G['timestamp'].$mdata);
					
					$logitem[$x] = $sdlist[$userinfo['udata']['prod'][$x][0]]['stitle'].'x'.$mdata[2].'('.$oriqty.'->'.$userinfo['udata']['prod'][$x][1].')';
					
					$mdata = json_encode($mdata,true);
					DB::query("REPLACE INTO ".DB::table('game_jnfarm_market')." (selluid,createtime,mdata,mtype,msign) VALUES (".$_G['uid'].",".$_G['timestamp'].",'".$mdata."','$mtype','$msign') ");
				}
			}
			$logprod = implode(',',$logitem);
			$logitem = array();
			for($x=1;$x<=$cfert;$x++){
				$fertx = dintval($_GET['fertilize'.$x]);
				if($fertx == '1'){
					fushu($_GET['fertilizesellprice'.$x]);
					fushu($_GET['fertilizesellqty'.$x]);
					$mdata = array();
					$mdata[0] = $userinfo['udata']['fertilize'][$x][0];
					$mdata[1] = dintval($_GET['fertilizesellprice'.$x]);
					$mdata[2] = dintval($_GET['fertilizesellqty'.$x]);
					$mtype = 'fert';
					$oriqty = $userinfo['udata']['fertilize'][$x][1];
					$userinfo['udata']['fertilize'][$x][1] = $userinfo['udata']['fertilize'][$x][1]-$mdata[2];
					$msign = md5($_G['uid'].$_G['timestamp'].$mdata);
					
					$logitem[$x] = $felist[$userinfo['udata']['fertilize'][$x][0]]['stitle'].'x'.$mdata[2].'('.$oriqty.'->'.$userinfo['udata']['fertilize'][$x][1].')';
					
					$mdata = json_encode($mdata,true);
					DB::query("REPLACE INTO ".DB::table('game_jnfarm_market')." (selluid,createtime,mdata,mtype,msign) VALUES (".$_G['uid'].",".$_G['timestamp'].",'".$mdata."','$mtype','$msign') ");
				}
			}
			$logfert = implode(',',$logitem);
			$logitem = array();
			for($x=1;$x<=$cseed;$x++){
				$seedx = dintval($_GET['seed'.$x]);
				if($seedx == '1'){
					fushu($_GET['seedsellprice'.$x]);
					fushu($_GET['seedsellqty'.$x]);
					$mdata = array();
					$mdata[0] = $userinfo['udata']['seed'][$x][0];
					$mdata[1] = dintval($_GET['seedsellprice'.$x]);
					$mdata[2] = dintval($_GET['seedsellqty'.$x]);
					$mtype = 'seed';
					$oriqty = $userinfo['udata']['seed'][$x][1];
					$userinfo['udata']['seed'][$x][1] = $userinfo['udata']['seed'][$x][1]-$mdata[2];
					$msign = md5($_G['uid'].$_G['timestamp'].$mdata);
					
					$logitem[$x] = $sdxlist[$userinfo['udata']['seed'][$x][0]]['stitle'].lang("plugin/$jn","s038").'x'.$mdata[2].'('.$oriqty.'->'.$userinfo['udata']['seed'][$x][1].')';
					
					$mdata = json_encode($mdata,true);
					DB::query("REPLACE INTO ".DB::table('game_jnfarm_market')." (selluid,createtime,mdata,mtype,msign) VALUES (".$_G['uid'].",".$_G['timestamp'].",'".$mdata."','$mtype','$msign') ");
				}
			}
			$logseed = implode(',',$logitem);
			$logitem = array();
			
			for($x=1;$x<=$ctili;$x++){
				$tilix = dintval($_GET['tiliitem'.$x]);
				if($tilix == '1'){
					fushu($_GET['tiliitemsellprice'.$x]);
					fushu($_GET['tiliitemsellqty'.$x]);
					$mdata = array();
					$mdata[0] = $userinfo['udata']['tiliitem'][$x][0];
					$mdata[1] = dintval($_GET['tiliitemsellprice'.$x]);
					$mdata[2] = dintval($_GET['tiliitemsellqty'.$x]);
					$mtype = 'tiliitem';
					$oriqty = $userinfo['udata']['tiliitem'][$x][1];
					$userinfo['udata']['tiliitem'][$x][1] = $userinfo['udata']['tiliitem'][$x][1]-$mdata[2];
					$msign = md5($_G['uid'].$_G['timestamp'].$mdata);
					
					$logitem[$x] = $tilist[$userinfo['udata']['tiliitem'][$x][0]]['stitle'].'x'.$mdata[2].'('.$oriqty.'->'.$userinfo['udata']['tiliitem'][$x][1].')';
					
					$mdata = json_encode($mdata,true);
					DB::query("REPLACE INTO ".DB::table('game_jnfarm_market')." (selluid,createtime,mdata,mtype,msign) VALUES (".$_G['uid'].",".$_G['timestamp'].",'".$mdata."','$mtype','$msign') ");
				}
			}
			$logtili = implode(',',$logitem);
			$logitem = array();
			
			if($cardon == '1'){
				if($mcllist[0]['jcuid'] > 0){
					$x = 0;
					foreach($mcllist as $mcl){
						$mdata = array();
						$mdata[0] = $mcl['jcuid'];//id
						$mdata[1] = dintval($_GET['sellprice'][$mcl['jcuid']]);//price
						$mdata[2] = 1;//qty
						$mdata[3] = $mcl['jcid'];//id
						$mtype = 'card';
						$logitem[$x] = $cardall[$mcl['jcuid']]['ctitle'].'x1';
						$mdata = json_encode($mdata,true);
						$msign = md5($_G['uid'].$_G['timestamp'].$mdata);
						DB::query("REPLACE INTO ".DB::table('game_jnfarm_market')." (selluid,createtime,mdata,mtype,msign) VALUES (".$_G['uid'].",".$_G['timestamp'].",'".$mdata."','$mtype','$msign') ");
						DB::query("UPDATE ".DB::table('game_jnfarm_card_user')." SET uid = '0' WHERE jcuid = '".$mcl['jcuid']."'");
						//$mcllist[] = $mcl;//mcl�������յ�, ����û��Ըı���, ���ݿ�û���򲻵�һ����
						//$rr++;
					}
					$logcard = implode(',',$logitem);
				}
				$logitem = array();
				if($msllist[0]['jcuid'] > 0){
					$x = 0;
					foreach($msllist as $msl){
						$mdata = array();
						$mdata[0] = $msl['jcuid'];
						$mdata[1] = dintval($_GET['sellprice'][$msl['jcuid']]);
						$mdata[2] = dintval($_GET['sellqty'][$msl['jcuid']]);
						$mdata[3] = $msl['jcid'];
						$mtype = 'suipian';
						//$oriqty = $userinfo['udata']['tiliitem'][$x][1];
						//$userinfo['udata']['tiliitem'][$x][1] = $userinfo['udata']['tiliitem'][$x][1]-$mdata[2];
						
						$logitem[$x] = $cardall[$msl['jcuid']]['ctitle'].'x'.$mdata[2];
						
						$mdata = json_encode($mdata,true);
						$msign = md5($_G['uid'].$_G['timestamp'].$mdata);
						
						DB::query("REPLACE INTO ".DB::table('game_jnfarm_market')." (selluid,createtime,mdata,mtype,msign) VALUES (".$_G['uid'].",".$_G['timestamp'].",'".$mdata."','$mtype','$msign') ");
						
						DB::query("UPDATE ".DB::table('game_jnfarm_card_user')." SET qty = qty-".dintval($_GET['sellqty'][$msl['jcuid']])." WHERE jcuid = '".$msl['jcuid']."' AND uid = '".$_G['uid']."'");
					}
					$logsp = implode(',',$logitem);
				}
			}
			
			$userinfo['udata'] = json_encode($userinfo['udata'],true);
			C::t('#'.$jn.'#'.$jn.'_user')->update($userinfo['juid'],array('udata'=>$userinfo['udata'],'lastsituation'=>$_G['timestamp']));
			
			$thislang = lang("plugin/$jn","s103").$logprod.$logfert.$logseed.$logtili.$logcard.$logsp;
			nlog($_G['uid'],5,$_G['timestamp'],$thislang);
			
			$linkgen = iconv($_G['charset'],'UTF-8',lang("plugin/$jn","s096"));
			$final = array('final'=>$linkgen);
			echo json_encode($final);
			exit;

			//showmessage("$jn:s096",'plugin.php?id='.$jn);
		}
		
	}
	
	if($_GET['ac'] == 'buy'){
		if($_GET['type']){
			$mtype = array(1=>'prod',2=>'fert',3=>'seed',4=>'card',5=>'suipian');
			$type = "AND mtype = '".$mtype[$_GET['type']]."'";
			$retype = '&type='.$_GET['type'];
		}
		$mlist = DB::fetch_all("SELECT * FROM ".DB::table('game_jnfarm_market')." WHERE buytime = 0 $type AND selluid != '".$_G['uid']."' AND buyuid = 0 ORDER BY RAND() limit 50");
		foreach($mlist as $ml){
			$ml['mdata'] = json_decode($ml['mdata'],true);
			if($ml['mtype'] == 'seed'){ //������, ����������seed����prod, ����market�Ǳ�ҲҪ��type��
				$ml['zhz'] = lang("plugin/$jn","s038");
			}
			if($ml['mtype'] == 'suipian' || $ml['mtype'] == 'card'){
				$ml['stitle'] = $cardall[$ml['mdata'][3]]['ctitle'];
			}else{
				$ml['stitle'] = $allist[$ml['mdata'][0]]['stitle'];
			}
			$ml['price'] = $ml['mdata'][1]*$ml['mdata'][2];
			$mkli[] = $ml;
		}
		if($_GET['sign'] && $_GET['formhash'] == $_G['formhash']){
			$sign = daddslashes($_GET['sign']);
			$mbuy = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_market')." WHERE msign = '$sign' AND selluid != '".$_G['uid']."' AND buyuid = 0 AND buytime = 0 ");
			if(!$mbuy){
				showmessage('Error');//�Ըı���
			}
			$mbuy['mdata'] = json_decode($mbuy['mdata'],true);
			$price = $mbuy['mdata'][1]*$mbuy['mdata'][2];
			//�ȼ�鵱ǰ�ȼ��Ƿ��㹻�ſ�����
			$clevel = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_item')." WHERE jsid = '".$mbuy['mdata'][0]."'");
			$clevel['sdata'] = json_decode($clevel['sdata'],true);
			if($userinfo['udata']['data']['farmlvl'] < $clevel['sdata']['minlvl']){
				if($cardon == '1'){
					if($mbuy['mtype'] == 'suipian' || $mbuy['mtype'] == 'card'){
						
					}else{
						$linkgen = '<script>ajaxget(\'plugin.php?id='.$jn.'&do=market&ac=buy'.$retype.'&timestamp='.$_G['timestamp'].'\',\'marketlist\');layer.msg(\''.lang("plugin/$jn","s243").'\');</script>';
						include template($jn.':'.$jn.'_normal_plain');
						exit;
					}
				}else{
					$linkgen = '<script>ajaxget(\'plugin.php?id='.$jn.'&do=market&ac=buy'.$retype.'&timestamp='.$_G['timestamp'].'\',\'marketlist\');layer.msg(\''.lang("plugin/$jn","s243").'\');</script>';
					include template($jn.':'.$jn.'_normal_plain');
					exit;
				}
			}
			if($userinfo['udata']['data']['money'] >= $price){
				$orimoney = $userinfo['udata']['data']['money'];
				$userinfo['udata']['data']['money'] = $userinfo['udata']['data']['money']-$price;
				if($mbuy['mtype'] == 'seed'){
					$cseed = count($userinfo['udata']['seed']);
					for($x=1;$x<=$cseed;$x++){
						if($userinfo['udata']['seed'][$x][0] == $mbuy['mdata'][0]){
							$userinfo['udata']['seed'][$x][1] = $userinfo['udata']['seed'][$x][1]+$mbuy['mdata'][2];
							$ok = '1';
							break;
						}
					}
					if(!$ok){
						$userinfo['udata']['seed'][$x][0] = $mbuy['mdata'][0];
						$userinfo['udata']['seed'][$x][1] = $mbuy['mdata'][2];
					}
					$itemtitle = $sdlist[$mbuy['mdata'][0]]['stitle'];
				}
				if($mbuy['mtype'] == 'fert'){
					$cfert = count($userinfo['udata']['fertilize']);
					for($x=1;$x<=$cfert;$x++){
						if($userinfo['udata']['fertilize'][$x][0] == $mbuy['mdata'][0]){
							$userinfo['udata']['fertilize'][$x][1] = $userinfo['udata']['fertilize'][$x][1]+$mbuy['mdata'][2];
							$ok = '1';
							break;
						}
					}
					if(!$ok){
						$userinfo['udata']['fertilize'][$x][0] = $mbuy['mdata'][0];
						$userinfo['udata']['fertilize'][$x][1] = $mbuy['mdata'][2];
					}
					$itemtitle = $felist[$mbuy['mdata'][0]]['stitle'];
				}
				if($mbuy['mtype'] == 'prod'){
					$cprod = count($userinfo['udata']['prod']);
					for($x=1;$x<=$cprod;$x++){
						if($userinfo['udata']['prod'][$x][0] == $mbuy['mdata'][0]){
							$userinfo['udata']['prod'][$x][1] = $userinfo['udata']['prod'][$x][1]+$mbuy['mdata'][2];
							$ok = '1';
							break;
						}
					}
					if(!$ok){
						$userinfo['udata']['prod'][$x][0] = $mbuy['mdata'][0];
						$userinfo['udata']['prod'][$x][1] = $mbuy['mdata'][2];
					}
					$itemtitle = $sdlist[$mbuy['mdata'][0]]['stitle'].lang("plugin/$jn","s038");
				}
				if($mbuy['mtype'] == 'tiliitem'){
					$ctili = count($userinfo['udata']['tiliitem']);
					for($x=1;$x<=$ctili;$x++){
						if($userinfo['udata']['tiliitem'][$x][0] == $mbuy['mdata'][0]){
							$userinfo['udata']['tiliitem'][$x][1] = $userinfo['udata']['tiliitem'][$x][1]+$mbuy['mdata'][2];
							$ok = '1';
							break;
						}
					}
					if(!$ok){
						$userinfo['udata']['tiliitem'][$x][0] = $mbuy['mdata'][0];
						$userinfo['udata']['tiliitem'][$x][1] = $mbuy['mdata'][2];
					}
					$itemtitle = $allist[$mbuy['mdata'][0]]['stitle'];
				}
				if($mbuy['mtype'] == 'card'){
					$c = DB::result_first("SELECT count(*) cnt FROM ".DB::table('game_jnfarm_card_user')." WHERE uid = '".$_G['uid']."' AND type = 'card'");
					$maxnow = $userinfo['kpck'] + $sysinfo['setdata']['card']['kpextend'][2];
					if($c >= $maxnow){
						jnmsg(lang("plugin/$jn","s454"));
					}
					DB::query("UPDATE ".DB::table('game_jnfarm_card_user')." SET uid = '".$_G['uid']."' WHERE jcuid = '".$mbuy['mdata'][0]."'");
					$itemtitle = $cardall[$mbuy['mdata'][3]]['ctitle'];
				}
				if($mbuy['mtype'] == 'suipian'){
					$max = $userinfo['spck']+$sysinfo['setdata']['card']['spextend'][2];
					$cnow = DB::result_first("SELECT count(*) cnt FROM ".DB::table('game_jnfarm_card_user')." WHERE uid = '".$_G['uid']."' AND type = 'suipian' AND qty > 0 AND jcid > 0");
					$cnow >= $max ? $cangku = 1 : $cangku = 0;
					$nosuccess = cardadd('suipian',$mbuy['mdata'][2],$mbuy['mdata'][3],$_G['uid'],$cangku);
					if($nosuccess == '1'){
						jnmsg(lang("plugin/$jn","s454"));
					}
					$itemtitle = $cardall[$mbuy['mdata'][3]]['ctitle'];
				}
				if($directextcreditson == '1'){
					$cdd['extcredits'.$jnc['buyext']] = '-'.$price;
					updatemembercount($_G['uid'], $cdd, true, '', 0, '',$jnc['title'],lang("plugin/$jn","s178"));
					$cdd = array();
				}
				//����market status
				DB::query("UPDATE ".DB::table('game_jnfarm_market')." SET buyuid = '".$_G['uid']."', buytime = '".$_G['timestamp']."', mstatus = '1' WHERE jmid = '".$mbuy['jmid']."'");
				//����
				
				$seller = C::t('#'.$jn.'#'.$jn.'_user')->userinfo($mbuy['selluid']);
				$seller['udata'] = json_decode($seller['udata'],true);
				if(!$sysinfo['setdata']['marketsuilv']){
					$sysinfo['setdata']['marketsuilv'] = '10';
				}
				$suilv = floor($price*($sysinfo['setdata']['marketsuilv']*0.01));
				$getprice = $price-$suilv;
				$sellori = $seller['udata']['data']['money'];
				if($directextcreditson == '1'){//�������һ���
					$sellext = DB::fetch_first("SELECT * FROM ".DB::table('common_member_count')." WHERE uid = '".$mbuy['selluid']."'");
					$sellori = $sellext['extcredits'.$jnc['buyext']];
				}
				
				$seller['udata']['market']['sellqty'] = $seller['udata']['market']['sellqty']+1;
				$seller['udata']['market']['sellamount'] = $seller['udata']['market']['sellamount']+$getprice;
				$seller['udata']['data']['money'] = $seller['udata']['data']['money']+$getprice;
				
				if($directextcreditson == '1'){//�������һ���
					$cdd['extcredits'.$jnc['buyext']] = '+'.$getprice;
					updatemembercount($mbuy['selluid'], $cdd, true, '', 0, '',$jnc['title'],lang("plugin/$jn","s244"));
					$cdd = array();
				}
				
				
				//��־
				$thislang = lang("plugin/$jn","s097",array('itemtitle'=>$itemtitle,'mbuymdata2'=>$mbuy['mdata'][2],'mbuyjmid'=>$mbuy['jmid'],'price'=>$price,'orimoney'=>$orimoney,'userinfoudatadatamoney'=>$userinfo['udata']['data']['money'],'usernamembuyselluid'=>$username[$mbuy['selluid']],'mbuyselluid'=>$mbuy['selluid'],'getprice'=>$getprice,'sysinfosetdatamarketsuilv'=>$sysinfo['setdata']['marketsuilv'],'sellori'=>$sellori,'sellerudatadatamoney'=>$seller['udata']['data']['money']));//"�г�������".$itemtitle."x".$mbuy['mdata'][2]."(�г�ID:".$mbuy['jmid'].") ������".$price.", ".$orimoney.'->'.$userinfo['udata']['data']['money']." ����(".$username[$mbuy['selluid']]." UID: ".$mbuy['selluid'].") ˰������".$getprice." ��ǰ˰��".$sysinfo['setdata']['marketsuilv']."% ".$sellori."->".$seller['udata']['data']['money'];
				nlog($_G['uid'],5,$_G['timestamp'],$thislang);
				
				if($directextcreditson == '1'){
					$seller['udata']['data']['money'] = 0;
					$userinfo['udata']['data']['money'] = 0;
				}
				
				$seller['udata'] = json_encode($seller['udata'],true);
				C::t('#'.$jn.'#'.$jn.'_user')->update($seller['juid'],array('udata'=>$seller['udata']));
				
				$note = lang("plugin/$jn","s098",array('itemtitle'=>$itemtitle,'mbuymdata2'=>$mbuy['mdata'][2],'getprice'=>$getprice));//"���г����������ϼܵ�".$itemtitle."x".$mbuy['mdata'][2]." ˰������Ϊ".$getprice;
				notification_add($mbuy['selluid'], 'myapp', $note, '', 0);
				
				$userinfo['udata'] = json_encode($userinfo['udata'],true);
				C::t('#'.$jn.'#'.$jn.'_user')->update($userinfo['juid'],array('udata'=>$userinfo['udata']));
				
				$linkgen = '<script>ajaxget(\'plugin.php?id='.$jn.'&do=market&ac=buy'.$retype.'&timestamp='.$_G['timestamp'].'\',\'marketlist\');layer.msg(\''.lang("plugin/$jn","s099").$price.$jnc[mt].'\');ajaxget(\'plugin.php?id='.$jn.'&do=normal&ac=userinfo&timestamp='.$_G['timestamp'].$pass.'\',\'userinfo\');</script>';
				include template($jn.':'.$jn.'_normal_plain');
				exit;
			}else{
				$linkgen = '<script>ajaxget(\'plugin.php?id='.$jn.'&do=market&ac=buy'.$retype.'&timestamp='.$_G['timestamp'].'\',\'marketlist\');layer.msg(\''.lang("plugin/$jn","s100",array('jncmt'=>$jnc['mt'])).'\');'.$_G['timestamp'].'</script>';
				include template($jn.':'.$jn.'_normal_plain');
				exit;
				//showmessage("$jn:s100","plugin.php?id=$jn",array('jncmt'=>$jnc['mt']));
			}
		}
	}
	include template($jn.':'.$jn.'_normal');
	exit;	
}
//From: Dism��taobao��com
?>