<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
};
if (!$_G['uid']) showmessage('not_loggedin','',array(), array('login' => true));
if ($reallanddirecton == '1'){
	exit;
}
if($_GET['do'] == 'neighbours'){
	$friendid = dintval($_GET['friendid']);
	if($friendid == $_G['uid']){
		showmessage("$jn:s023");//�����û��Ըı���
	}
	if($jnc['friend'] == '1'){
		$fhome = DB::fetch_all("SELECT * FROM ".DB::table('home_friend')." WHERE uid = '".$_G['uid']."' AND fuid = '$friendid'");
		if(!$fhome){
			showmessage("$jn:s024");//�����û��Ըı���
		}
	}
	
	//require DISCUZ_ROOT.'source/plugin/'.$jn.'/module/rankimprove.php';
	$flist = array();
	$gmap = array();
	
	$land = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_land')." WHERE uid = '".$friendid."'");
	$frinfo = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_user')." WHERE uid = '".$friendid."'");

	$frinfo['udata'] = json_decode($frinfo['udata'],true);
	if($frinfo['udata']['data']['money'] >= 10000){
		$fmoneyshow = floor($frinfo['udata']['data']['money']/10000).lang("plugin/$jn","s484");
	}
	if($frinfo['udata']['data']['money'] >= 100000000){
		$fmoneyshow = floor($frinfo['udata']['data']['money']/10000).lang("plugin/$jn","s485");
	}
	
	$nextexp = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_level')." WHERE lvl = '".($frinfo['udata']['data']['farmlvl']+1)."'");
	if(!$nextexp){
		$nextexp = '<font size="4em">&#8734;</font>';
	}else{
		$nextexp = $nextexp['expneed'];
	}
	
	//�������Ҫȫ������д��, ��Ϊ�Ѿ�����farm_farm��
	
	$land['fdata'] = json_decode($land['fdata'],true);
	for($nf = 1;$nf <= 24; $nf++){
		if($land['fdata'][$nf]['type'] == '2'){
			$landimg = "r-land.svg";
		}else{
			$landimg = "f-land.svg";
		}
		
		if(!$land['fdata'][$nf]){
			$fmap .= '<div style="position: absolute; top: '.$arraytop[$nf].'px; left: '.$arrayleft[$nf].'px;" id="ok'.$nf.'">
		<div style="position: relative;">
			<div style="position: absolute; width: 100px; left: 15px; top: 1px;">
				<img src="'.$imgurl.$landimg.'" width="100%">
			</div>
			<div style="position: absolute; width: 100px; left: 15px; top: 3px;">
				<img src="'.$imgurl.'kuozhan.png" style="width: 90%;">
			</div>
		</div>
	</div>';
			break;
		}
		if($land['fdata'][$nf]['seed'] > '0'){
			if($land['fdata'][$nf]['expired'] < $_G['timestamp']){
				$thisimg[$nf] = 'kuwei.png';
			}else{
				$thisimg[$nf] = $sdlist[$land['fdata'][$nf]['seed']]['sdata']['imgurl'];
			}
			$seedimg = '<div style="position: absolute; width: 100px; left: 15px; top: -8px;">
				<img src="'.$imgurl.$thisimg[$nf].'" style="width: 70%;" class="cropimg">
			</div>';//��seed�ʹ���ͼƬ
			$acthis = 'thisfriend';//thisfarm
		}else{
			$seedimg = '';
			$acthis = '';
		}
		$fmap .= '<div style="position: absolute; top: '.$arraytop[$nf].'px; left: '.$arrayleft[$nf].'px;" id="ok'.$nf.'">
		<div style="position: relative;">
			<div style="position: absolute; width: 100px; left: 15px; top: 1px;">
				<img src="'.$imgurl.$landimg.'" width="100%">
			</div>
			'.$seedimg.'
			<div style="position: absolute; width: 100px; left: 15px; top: 1px;">
				<a data-method="offset" data-type="auto" data-jfid="'.$nf.'" class="'.$acthis.'"><div class="isometricbtn"></div></a>
			</div>
		</div>
	</div>';
	}
	
	if($_GET['updateland'] == 'true'){
		$linkgen = $fmap;
		include template($jn.':'.$jn.'_normal_other');
		exit;
	}
	include template($jn.':'.$jn);
	exit;
}
//From: Dism��taobao��com
?>