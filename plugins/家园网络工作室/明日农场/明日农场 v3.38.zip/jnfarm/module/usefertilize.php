<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
};
if (!$_G['uid']) showmessage('not_loggedin','',array(), array('login' => true));
if ($reallanddirecton == '1'){
	exit;
}
if($_GET['do'] == 'usefertilize'){
	$jfid = dintval($_GET['jfid']);
	$feid = dintval($_GET['feid']);
	$jinfo = C::t('#'.$jn.'#'.$jn.'_land')->jinfo($_G['uid']);
	if(!$jinfo['jfid']){
		$linkgen = lang("plugin/$jn","s043");
		showmessage($linkgen);
	}
	if($_GET['formhash'] == $_G['formhash']){
		$fertilize = count($userinfo['udata']['fertilize']);
		$jinfo['fdata'] = json_decode($jinfo['fdata'],true);
	
		if($feid > 0){ //�·���
			if($jinfo['fdata'][$jfid]['prodfinish'] > $_G['timestamp']){
				for($x = 1;$x <= $fertilize; $x++){
					if($userinfo['udata']['fertilize'][$x][0] == $feid){
						if($userinfo['udata']['fertilize'][$x][1] <= '0'){
							$linkgen = lang("plugin/$jn","s241",array('nowqty'=>$userinfo['udata']['fertilize'][$x][1]));
							$linkgen = '<script>ajaxget(\'plugin.php?id='.$jn.'&do=normal&ac=thisfarm&jfid='.$jfid.'&timestamp='.$_G['timestamp'].'\',\'thisfarm'.$jfid.'\');layer.msg(\''.$linkgen.'\')</script>';//����Ҫ���� �������صĸ��� 
							include template($jn.':'.$jn.'_normal');
							exit;
						}
						$ori = $userinfo['udata']['fertilize'][$x][1];
						$userinfo['udata']['fertilize'][$x][1] = $userinfo['udata']['fertilize'][$x][1]-1;

						$oritime = date("Y-m-d H:i:s",$jinfo['fdata'][$jfid]['prodfinish']);
						$jinfo['fdata'][$jfid]['prodfinish'] = $jinfo['fdata'][$jfid]['prodfinish']-$felist[$feid]['sdata']['timesave'];
						$aftertime = date("Y-m-d H:i:s",$jinfo['fdata'][$jfid]['prodfinish']);

						$thislang = lang("plugin/$jn","s067",array('jfid'=>$jfid))." ".$felist[$feid]['stitle'].$ori."->".$userinfo['udata']['fertilize'][$x][1]." ".lang("plugin/$jn","s068").$oritime."->".$aftertime;
						nlog($_G['uid'],3,$_G['timestamp'],$thislang);

						$userinfo['udata'] = json_encode($userinfo['udata']);
						C::t('#'.$jn.'#'.$jn.'_user')->update($userinfo['juid'],array('udata'=>$userinfo['udata'],'lastsituation'=>$_G['timestamp']));

						$jinfo['fdata'] = json_encode($jinfo['fdata']);
						C::t('#'.$jn.'#'.$jn.'_land')->update($jinfo['jfid'],array('fdata'=>$jinfo['fdata']));
						$sfcg = '1';
					}
				}
				//$linkgen = lang("plugin/$jn","s045").'<script>ajaxget("plugin.php?id='.$jn.'&do=ajax&ac=updatejfid&jfid='.$jfid.'&timestamp='.$_G['timestamp'].'","jfid'.$jfid.'");ajaxget("plugin.php?id='.$jn.'&do=ajax&ac=updatejrid&jfid='.$jfid.'&timestamp='.$_G['timestamp'].'","jrid'.$jfid.'");</script>';
			}
			if(!$sfcg){
				showmessage("$jn:s046");
			}
			$linkgen = lang("plugin/$jn","s045");
			$linkgen = '<script>ajaxget(\'plugin.php?id='.$jn.'&do=normal&ac=thisfarm&jfid='.$jfid.'&timestamp='.$_G['timestamp'].'\',\'thisfarm'.$jfid.'\');layer.msg(\''.$linkgen.'\')</script>';//����Ҫ���� �������صĸ��� 
			include template($jn.':'.$jn.'_normal');
			exit;
		}
	}else{
		showmessage("$jn:s046");
	}
	
	//$linkgen = 'hahaha';//����ֱ�Ӹ�������ͼƬ
	//$linkgen = lang("plugin/$jn","s050").'<script>ajaxget("plugin.php?id='.$jn.'&do=ajax&ac=updatejfid&jfid='.$jfid.'&timestamp='.$_G['timestamp'].'","jfid'.$jfid.'");ajaxget("plugin.php?id='.$jn.'&do=ajax&ac=updatejrid&jfid='.$jfid.'&timestamp='.$_G['timestamp'].'","jrid'.$jfid.'");</script>';
}
//From: Dism��taobao��com
?>