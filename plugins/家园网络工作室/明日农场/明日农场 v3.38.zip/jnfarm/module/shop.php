<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
};
if (!$_G['uid']) showmessage('not_loggedin','',array(), array('login' => true));
if ($reallanddirecton == '1'){
	exit;
}
if($_GET['do'] == 'shop'){
	if(!discuz_process::islocked('update_jnfarm'.$_G['uid'])) {
	if($_GET['submit'] == 'true' && $_GET['formhash'] == $_G['formhash']){
		$userinfo = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_user')." WHERE uid = '".$_G['uid']."'");
		$userinfo['udata'] = json_decode($userinfo['udata'],true);
		if($directextcreditson == '1'){
			$userinfo['udata']['data']['money'] = getuserprofile('extcredits'.$jnc['buyext']);
		}
		$pass = substr(md5(uniqid(mt_rand(), true)) , 0, 8);
		$shop = DB::fetch_all("SELECT * FROM ".DB::table('game_jnfarm_item')." ORDER BY jsid ASC");
		foreach($shop as $sc){
			$sc['sdata'] = json_decode($sc['sdata'],true);
			$sclist[] = $sc;
		}
		$sclist = array_column($sclist, null, 'jsid');
		$orimoney = $userinfo['udata']['data']['money'];
		$cshop = count($shop);
		//$rr = end($sclist); //20200308����, ���������Ʒid��һ��
		//$aa = $rr['jsid'];
		//check using foreach??
		//$nowmoney = $userinfo['udata']['data']['money'];
		foreach($sclist as $sc){
			$x = $sc['jsid'];
			if($_GET['jsid'][$x] == '1'){
				$qtycheck = dintval($_GET['qty'][$x]);
				$qtycheck = fushu($qtycheck);
				if($sclist[$x]['sdata']['buyable'] != '1' || $sclist[$x]['sdata']['minlvl'] > $userinfo['udata']['data']['farmlvl']){
					discuz_process::unlock('update_jnfarm'.$_G['uid']);
					showmessage("$jn:s030");//�����û��Ըı���
				}
				if($vipon == '1' && $userinfo['vipexpired'] > $_G['timestamp']){
					$sclist[$x]['sdata']['cost'] = $sclist[$x]['sdata']['cost']-floor($sclist[$x]['sdata']['cost']*$sysinfo['setdata']['vip']['discount']*0.01);
				}
				$totalcost = $totalcost+($qtycheck*$sclist[$x]['sdata']['cost']);
				//�����ܹ�����Ǯ
			}
		}
		if($userinfo['udata']['data']['money'] < $totalcost){
			if($_GET['fastbuy'] == 'true'){
				$linkgen = '<script>layer.msg(\''.$jnc['mt'].lang("plugin/$jn","s031").$totalcost.'\');'.$_G['timestamp'].'</script>';
				discuz_process::unlock('update_jnfarm'.$_G['uid']);
				include template($jn.':'.$jn.'_normal_plain');
				exit;
			}else{
				$linkgen = $jnc['mt'].lang("plugin/$jn","s031").$totalcost;
				$linkgen = iconv($_G['charset'],'UTF-8',$linkgen);
				$final = array('final'=>$linkgen);
				echo json_encode($final);
				//showmessage($linkgen);
				//include template($jn.':'.$jn.'_normal_plain');
				discuz_process::unlock('update_jnfarm'.$_G['uid']);
				exit;
			}
			
		}
		//�����û��Ըı���
		if($totalcost <= '0'){
			discuz_process::unlock('update_jnfarm'.$_G['uid']);
			showmessage("$jn:s032");
			$linkgen = lang("plugin/$jn","s032");
			include template($jn.':'.$jn.'_normal_plain');
			exit;	
		};
		
		if($directextcreditson == '1'){
			$cdd['extcredits'.$jnc['buyext']] = '-'.$totalcost;
			updatemembercount($_G['uid'], $cdd, true, '', 0, '',$jnc['title'],lang("plugin/$jn","s170"));
			$cdd = array();
			$moneyafter = $userinfo['udata']['data']['money']-$totalcost;
		}else{
			$userinfo['udata']['data']['money'] = $userinfo['udata']['data']['money']-$totalcost;
			$moneyafter = $userinfo['udata']['data']['money'];
		}
		//������Ʒ
		
		foreach($sclist as $sc){
			$x = $sc['jsid'];
		//for($x = 1; $x <= $aa; $x ++){
			if($_GET['jsid'][$x] == '1'){
				$qtycheck = dintval($_GET['qty'][$x]);
				$qtycheck = fushu($qtycheck);
				//�����û�����
				if($sclist[$x]['type'] == 'seed'){
					$cseed = count($userinfo['udata']['seed']);
					for($y = 1;$y <= $cseed; $y++){
						if($userinfo['udata']['seed'][$y][0] == $x){
							$userinfo['udata']['seed'][$y][1] = $userinfo['udata']['seed'][$y][1]+$qtycheck;
							$ok = '1';
						}
					}
					if(!$ok){
						$userinfo['udata']['seed'][$y][0] = $x;
						$userinfo['udata']['seed'][$y][1] = $qtycheck;
						$ok = '';
					}
					$logitem = $logitem.$sdlist[$x]['stitle'].lang("plugin/$jn","s038").'x'.$qtycheck.' ';
					$ok = '';
				}
				if($sclist[$x]['type'] == 'fertilize'){
					$cfert = count($userinfo['udata']['fertilize']);
					for($y = 1;$y <= $cfert; $y++){
						if($userinfo['udata']['fertilize'][$y][0] == $x){
							$userinfo['udata']['fertilize'][$y][1] = $userinfo['udata']['fertilize'][$y][1]+$qtycheck;
							$ok = '1';
						}
					}
					if(!$ok){
						$userinfo['udata']['fertilize'][$y][0] = $x;
						$userinfo['udata']['fertilize'][$y][1] = $qtycheck;
						$ok = '';
					}
					$ok = '';
					$logitem = $logitem.$felist[$x]['stitle'].'x'.$qtycheck.' ';
				}
				if($sclist[$x]['type'] == 'nitem'){
					$cnitem = count($userinfo['udata']['nitem']);
					for($y = 1;$y <= $cnitem; $y++){
						if($userinfo['udata']['nitem'][$y][0] == $x){
							$userinfo['udata']['nitem'][$y][1] = $userinfo['udata']['nitem'][$y][1]+$qtycheck;
							$ok = '1';
						}
					}
					if(!$ok){
						$userinfo['udata']['nitem'][$y][0] = $x;
						$userinfo['udata']['nitem'][$y][1] = $qtycheck;
						$ok = '';
					}
					$ok = '';
					$logitem = $logitem.$sdlist[$x]['stitle'].'x'.$qtycheck.' ';
				}
				if($tiliitemon == '1'){
					if($sclist[$x]['type'] == 'tiliitem'){
						$ctiliitem = count($userinfo['udata']['tiliitem']);
						for($y = 1;$y <= $ctiliitem; $y++){
							if($userinfo['udata']['tiliitem'][$y][0] == $x){
								$userinfo['udata']['tiliitem'][$y][1] = $userinfo['udata']['tiliitem'][$y][1]+$qtycheck;
								$ok = '1';
							}
						}
						if(!$ok){
							$userinfo['udata']['tiliitem'][$y][0] = $x;
							$userinfo['udata']['tiliitem'][$y][1] = $qtycheck;
							$ok = '';
						}
						$ok = '';
						$logitem = $logitem.$sclist[$x]['stitle'].'x'.$qtycheck.' ';
					}
				}
			}
		}
		
		$thislang = lang("plugin/$jn","s064",array('logitem'=>$logitem)).$totalcost.", ".$orimoney.'->'.$moneyafter;//"������".$logitem."������".$totalcost.", ".$orimoney.'->'.$userinfo['udata']['data']['money'];
		nlog($_G['uid'],4,$_G['timestamp'],$thislang);
		
		if($directextcreditson == '1'){
			$userinfo['udata']['data']['money'] = 0;
		}
		$userinfo['udata'] = json_encode($userinfo['udata'],true);
		C::t('#'.$jn.'#'.$jn.'_user')->update($userinfo['juid'],array('udata'=>$userinfo['udata'],'lastsituation'=>$_G['timestamp']));
		if($_GET['fastbuy'] == 'true'){
			$linkgen = '<script>layer.msg(\''.lang("plugin/$jn","s099").$totalcost.$jnc['mt'].'\');ajaxget(\'plugin.php?id='.$jn.'&do=normal&ac=userinfo&timestamp='.$_G['timestamp'].$pass.'\',\'userinfo\');</script>';
			discuz_process::unlock('update_jnfarm'.$_G['uid']);
			include template($jn.':'.$jn.'_normal_plain');
			exit;
		}else{
			$linkgen = iconv($_G['charset'],'UTF-8',lang("plugin/$jn","s033").$totalcost.$jnc['mt']);
			$final = array('final'=>$linkgen);
			echo json_encode($final);
			discuz_process::unlock('update_jnfarm'.$_G['uid']);
			exit;
		}
	}//if discuzprocess
		discuz_process::unlock('update_jnfarm'.$_G['uid']);
		//showmessage($linkgen,'plugin.php?id=jnfarm'.$mobilelink);
	}
}
//From: Dism��taobao��com
?>