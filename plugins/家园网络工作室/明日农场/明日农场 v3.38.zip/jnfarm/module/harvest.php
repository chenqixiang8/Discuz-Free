<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
};
if (!$_G['uid']) showmessage('not_loggedin','',array(), array('login' => true));
if ($reallanddirecton == '1'){
	exit;
}
if($_GET['do'] == 'harvest'){
	$jfid = dintval($_GET['jfid']);
	if($_GET['formhash'] == $_G['formhash']){
		//$userinfo['udata']['data']['tili'][0] = tilicheck($_G['uid'],$sysinfo['setdata']['tilihuifu'],$_G['timestamp']);
		if($userinfo['udata']['data']['tili'][0] <= '0'){
			$linkgen = lang("plugin/$jn","s140");
			$skip = '1';
		}
		$jinfo = C::t('#'.$jn.'#'.$jn.'_land')->jinfo($_G['uid']);
		if(!$jinfo['jfid']){
			$linkgen = lang("plugin/$jn","s043");
			$skip = '1';
			//include template($jn.':'.$jn.'_ajax_plain');
			//exit;
		}
		$jinfo['fdata'] = json_decode($jinfo['fdata'],true);
		if($jinfo['fdata'][$jfid]['seed'] == '0'){
			$linkgen = lang("plugin/$jn","s051");
			$skip = '1';
			//include template($jn.':'.$jn.'_ajax');
			//exit;
		}
		if($jinfo['fdata'][$jfid]['prodfinish'] > $_G['timestamp']){
			$linkgen = lang("plugin/$jn","s052");
			$skip = '1';
			//include template($jn.':'.$jn.'_ajax');
			//exit;
		}
		if($_G['timestamp'] > $jinfo['fdata'][$jfid]['expired']){
			$linkgen = lang("plugin/$jn","s053");
			$skip = '1';
			//include template($jn.':'.$jn.'_ajax');
			//exit;
		}
		if(!$skip){
			$count = count($userinfo['udata']['prod']);
			for($x = 1;$x <= $count; $x++){
				if($userinfo['udata']['prod'][$x][0] == $jinfo['fdata'][$jfid]['seed']){
					$thisid = $x;
					$updatetoharvest = $jinfo['fdata'][$jfid]['seed'];
					$rr = '1';
				}
				//$userinfo['udata']['prod'][$jinfo['fdata']['seed']] = $userinfo['udata']['prod'][$jinfo['fdata']['seed']]+$jinfo['fdata']['qtyleft'];
			}
			if(!$rr){//���û�и���Ʒ
				$ori = '0';
				$userinfo['udata']['prod'][$x][0] = $jinfo['fdata'][$jfid]['seed'];
				$userinfo['udata']['prod'][$x][1] = $jinfo['fdata'][$jfid]['qtyleft'];
				$after = $userinfo['udata']['prod'][$x][1];
			}else{
				$ori = $userinfo['udata']['prod'][$thisid][1];
				$userinfo['udata']['prod'][$thisid][1] = $userinfo['udata']['prod'][$thisid][1]+$jinfo['fdata'][$jfid]['qtyleft'];
				$after = $userinfo['udata']['prod'][$thisid][1];
			}
			
			if($seasonon == '1'){
				seasonqtycheck($_G['uid'],$jinfo['fdata'][$jfid]['seed'],$jinfo['fdata'][$jfid]['qtyleft']);
			}
			
			$userinfo['udata']['data']['exp'] = $userinfo['udata']['data']['exp']+($jinfo['fdata'][$jfid]['qtyleft']*$sdlist[$jinfo['fdata'][$jfid]['seed']]['sdata']['exp']);
			$toexp = $userinfo['udata']['data']['exp'];
				
			$qtyadd = $jinfo['fdata'][$jfid]['qtyleft'];
			$qtitle = $sdlist[$jinfo['fdata'][$jfid]['seed']]['stitle'];
			$expadd = $jinfo['fdata'][$jfid]['qtyleft']*$sdlist[$jinfo['fdata'][$jfid]['seed']]['sdata']['exp'];
			
			$thislang = lang("plugin/$jn","s070",array('jfid'=>$jfid,'sdlistjinfo'=>$sdlist[$jinfo['fdata'][$jfid]['seed']]['stitle']))." ".$ori."->".$after;//"ũ��ID $jfid �ջ���".$sdlist[$jinfo['fdata']['seed']]['stitle']." �ֿ�ʣ�� ".$ori."->".$after;
			nlog($_G['uid'],3,$_G['timestamp'],$thislang);
			
			unset($jinfo['fdata'][$jfid]['thief']);

			$jinfo['fdata'][$jfid]['seed'] = '0';
			$jinfo['fdata'][$jfid]['prodstart'] = '0';
			$jinfo['fdata'][$jfid]['prodfinish'] = '0';
			$jinfo['fdata'][$jfid]['bug'] = '0';
			$jinfo['fdata'][$jfid]['grass'] = '0';
			$jinfo['fdata'][$jfid]['water'] = '0';
			$jinfo['fdata'][$jfid]['qtyleft'] = '0';
			$jinfo['fdata'][$jfid]['water'] = 0;
			$jinfo['fdata'][$jfid]['worm'] = 0;
			$jinfo['fdata'][$jfid]['weed'] = 0;
			

			$jinfo['fdata'] = json_encode($jinfo['fdata']);
			C::t('#'.$jn.'#'.$jn.'_land')->update($jinfo['jfid'],array('fdata'=>$jinfo['fdata']));

			//$userinfo['udata']['harvestrecord'][$thisid] = $thisid; //�ճɼ�¼������
			$userinfo['udata']['harvestrecord'][$updatetoharvest][0] = $userinfo['udata']['harvestrecord'][$updatetoharvest][0]+$qtyadd;
			
			//v2.1
			if($userinfo['udata']['data']['tili'][0] >= $userinfo['udata']['data']['tili'][1]){
				$userinfo['udata']['data']['tili'][2] = $_G['timestamp'];//�����ǰ����������, �������ָ�����һ������
			}
			$userinfo['udata']['data']['tili'][0] = $userinfo['udata']['data']['tili'][0]-1;
				
			$userinfo['udata'] = json_encode($userinfo['udata']);
			
			$userinfo['dailyquest'] = json_decode($userinfo['dailyquest'],true);
			$userinfo['dailyquest']['shoucheng'] = $userinfo['dailyquest']['shoucheng']+1;
			$dailyquest = json_encode($userinfo['dailyquest']);
			
			C::t('#'.$jn.'#'.$jn.'_user')->update($userinfo['juid'],array('udata'=>$userinfo['udata'],'lastsituation'=>$_G['timestamp'],'dailyquest'=>$dailyquest));

			expcheck($_G['uid'],$toexp);

			$linkgen = lang("plugin/$jn","s054").lang("plugin/$jn","s083",array('qtyadd'=>$qtyadd,'qtitle'=>$qtitle)).$expadd;
			//$linkgen = lang("plugin/$jn","s054").'<script>ajaxget("plugin.php?id='.$jn.'&do=ajax&ac=updatejfid&jfid='.$jfid.'&timestamp='.$_G['timestamp'].'","jfid'.$jfid.'");ajaxget("plugin.php?id='.$jn.'&do=ajax&ac=updatejrid&jfid='.$jfid.'&timestamp='.$_G['timestamp'].'","jrid'.$jfid.'");</script>';
		}
		
	}
	
	$linkgen = '<script>ajaxget(\'plugin.php?id='.$jn.'&do=normal&ac=updateland&formhash='.$_G['formhash'].'&timestamp='.$_G['timestamp'].'&jhash='.$pass.'\',\'jnland\');ajaxget(\'plugin.php?id='.$jn.'&do=normal&ac=userinfo&timestamp='.$_G['timestamp'].'&jhash='.$pass.'\',\'userinfo\');layer.msg(\''.$linkgen.'\')</script>';//����Ҫ���� �������صĸ��� 
	include template($jn.':'.$jn.'_normal');
	exit;
	//$linkgen = 'hahaha';//����ֱ�Ӹ�������ͼƬ
	//$linkgen = lang("plugin/$jn","s050").'<script>ajaxget("plugin.php?id='.$jn.'&do=ajax&ac=updatejfid&jfid='.$jfid.'&timestamp='.$_G['timestamp'].'","jfid'.$jfid.'");ajaxget("plugin.php?id='.$jn.'&do=ajax&ac=updatejrid&jfid='.$jfid.'&timestamp='.$_G['timestamp'].'","jrid'.$jfid.'");</script>';
}
//From: Dism��taobao��com
?>