<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
};
if (!$_G['uid']) showmessage('not_loggedin','',array(), array('login' => true));
if ($reallanddirecton == '1'){
	exit;
}
if($_GET['do'] == 'expandfarm'){
	if($_GET['formhash'] == $_G['formhash']){
		$cland = count($exland);
		for($y = 0;$y <= $cland;$y++){
			if($exlist[$y]['edata']['qty'] == ($cfarm+1)){
				if($userinfo['udata']['data']['farmlvl'] >= $exlist[$y]['edata']['lvl']){
					if($userinfo['udata']['data']['money'] >= $exlist[$y]['edata']['cost']){
						if($directextcreditson == '1'){
							$cdd['extcredits'.$jnc['buyext']] = '-'.$exlist[$y]['edata']['cost'];
							updatemembercount($_G['uid'], $cdd, true, '', 0, '',$jnc['title'],lang("plugin/$jn","s168"));
							$cdd = array();
						}else{
							$userinfo['udata']['data']['money'] = $userinfo['udata']['data']['money']-$exlist[$y]['edata']['cost'];
						}
						
						if($directextcreditson == '1'){
							$userinfo['udata']['data']['money'] = 0;
						}
						$userinfo['udata'] = json_encode($userinfo['udata'],true);
						C::t('#'.$jn.'#'.$jn.'_user')->update($userinfo['juid'],array('udata'=>$userinfo['udata']));
						$data = array();
						$data['uid'] = $_G['uid'];
						$data['createtime'] = $_G['timestamp'];
						$data['fdata'] = '{"seed":"0","prodstart":"0","prodfinish":"0","type":"1","bug":"0","grass":"0","water":"0","qtyleft":"0","expired":0,"oriqty":0}';
						C::t('#'.$jn.'#'.$jn.'_farm')->insert($data);
						showmessage("$jn:s034","plugin.php?id=$jn");
					}else{
						showmessage("$jn:s035","",array("jncmt"=>$jnc['mt']));
					}
				}else{
					showmessage("$jn:s036","",array("jncmt"=>$jnc['mt']));
				}
			}
		}
	}
}
//From: Dism��taobao��com
?>