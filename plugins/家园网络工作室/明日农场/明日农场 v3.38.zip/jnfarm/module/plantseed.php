<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
};
if (!$_G['uid']) showmessage('not_loggedin','',array(), array('login' => true));
if ($reallanddirecton == '1'){
	exit;
}
if($_GET['do'] == 'plantseed'){
	$jfid = daddslashes($_GET['jfid']);
	$seedid = dintval($_GET['seed']);
	$jinfo = C::t('#'.$jn.'#'.$jn.'_land')->jinfo($_G['uid']);
	if(!$jinfo['jfid']){
		//showmessage('û���������');
		discuz_process::unlock('update_jnfarm'.$_G['uid']);
		showmessage("$jn:s043",'plugin.php?id='.$jn);
		//$linkgen = lang("plugin/$jn","s043");
		//include template($jn.':'.$jn.'_ajax_plain');
		//exit;
		
	}
	$jinfo['fdata'] = json_decode($jinfo['fdata'],true);
	if(!discuz_process::islocked('update_jnfarm'.$_G['uid'])) {
		$userinfo = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_user')." WHERE uid = '".$_G['uid']."'");
		$userinfo['udata'] = json_decode($userinfo['udata'],true);
		if($jfid == 'auto'){
			$countland = count($jinfo['fdata']);
			for($x=1;$x<=$countland;$x++){
				if($jinfo['fdata'][$x]['seed'] == '0'){
					$jfid = $x;
					$jfidok = '1';
					break;
				}
			}
			if(!$jfidok){
				discuz_process::unlock('update_jnfarm'.$_G['uid']);
				$linkgen = lang("plugin/$jn","s237");
				$linkgen = '<script>layer.closeAll();ajaxget(\'plugin.php?id='.$jn.'&do=normal&ac=updateland&formhash='.$_G['formhash'].'&timestamp='.$_G['timestamp'].'&jhash='.$pass.'\',\'jnland\');layer.msg(\''.$linkgen.'\');</script>';
				include template($jn.':'.$jn.'_normal_plain');
				exit;
			}
			if($jfid == $countland){
				$autoclose = 'layer.closeAll();';
			}
		}else{
			$jfid = dintval($_GET['jfid']);
		}
		if($jinfo['fdata'][$jfid]['seed'] > '0'){
			//showmessage("��ǰ������������������");
			discuz_process::unlock('update_jnfarm'.$_G['uid']);
			showmessage("$jn:s048",'plugin.php?id='.$jn);
			//$linkgen = lang("plugin/$jn","s048");
			//include template($jn.':'.$jn.'_ajax_plain');
			//exit;
		}
		$count = count($userinfo['udata']['seed']);
		for($x = 1;$x <= $count; $x++){
			if(!$ss){
				if($userinfo['udata']['seed'][$x][0] == $seedid){
					$oriseed = $userinfo['udata']['seed'][$x][1];
					if($oriseed <= '0'){
						$linkgen = lang("plugin/$jn","s075");
						discuz_process::unlock('update_jnfarm'.$_G['uid']);
						$linkgen = '<script>ajaxget(\'plugin.php?id='.$jn.'&do=normal&ac=updateland&formhash='.$_G['formhash'].'&timestamp='.$_G['timestamp'].'\',\'jnland\');layer.msg(\''.$linkgen.'\')</script>';//����Ҫ���� �������صĸ��� 
						include template($jn.':'.$jn.'_normal_plain');
						exit;
					}
					$userinfo['udata']['seed'][$x][1] = $userinfo['udata']['seed'][$x][1]-1;
					//$userinfo['udata']['plantrecord'][$x] = $seedid;
					$userinfo['udata']['plantrecord'][$seedid][0] = $userinfo['udata']['plantrecord'][$seedid][0]+1;
					$afterseed = $userinfo['udata']['seed'][$x][1];
					$ss = '1';
					break;
				}
			}
		}
		if(!$ss){
			discuz_process::unlock('update_jnfarm'.$_G['uid']);
			showmessage("$jn:s049");//���������û������Ըı�����ֱ�ӷ��ش����ü�������
		}else{
			if($jinfo['fdata'][$jfid]['seed'] == 0 && $jinfo['fdata'][$jfid]['type'] >= 1){
				//$seedinfo
				$jinfo['fdata'][$jfid]['seed'] = $seedid;
				$jinfo['fdata'][$jfid]['prodstart'] = $_G['timestamp'];
				//$jimat = 1;
				
				$timedd = $sdlist[$seedid]['sdata']['ctime'];
				if($jinfo['fdata'][$jfid]['type'] == '2'){
					//����ʱ��
					$timedd = $sdlist[$seedid]['sdata']['ctime']-floor($sdlist[$seedid]['sdata']['ctime']*0.01*$sysinfo['setdata']['hongtu']);
				}
				$jinfo['fdata'][$jfid]['prodfinish'] = $_G['timestamp']+$timedd;
				
				if($vipon == '1' && $userinfo['vipexpired'] > $_G['timestamp']){
					$timedd = $timedd-floor($timedd*0.01*$sysinfo['setdata']['vip']['timesave']);
					$jinfo['fdata'][$jfid]['prodfinish'] = $_G['timestamp']+$timedd;
				}
				
				if(!$sdlist[$seedid]['sdata']['expiredtime']){
					$sdlist[$seedid]['sdata']['expiredtime'] = '0';
				}
				$jinfo['fdata'][$jfid]['expired'] = $jinfo['fdata'][$jfid]['prodfinish']+($sdlist[$seedid]['sdata']['expiredtime']);
				$jinfo['fdata'][$jfid]['qtyleft'] = mt_rand($sdlist[$seedid]['sdata']['hqty'][0],$sdlist[$seedid]['sdata']['hqty'][1]);
				$jinfo['fdata'][$jfid]['oriqty'] = $jinfo['fdata'][$jfid]['qtyleft'];

				$thislang = lang("plugin/$jn","s069",array('jfid'=>$jfid,'sdlistseedid'=>$sdlist[$seedid]['stitle']))." ".$oriseed."->".$afterseed;//"ũ��ID $jfid ��ֲ��".$sdlist[$seedid]['stitle']." �ֿ�����ʣ�� ".$oriseed."->".$afterseed;
				nlog($_G['uid'],3,$_G['timestamp'],$thislang);

				$jinfo['fdata'] = json_encode($jinfo['fdata']);

				$userinfo['udata'] = json_encode($userinfo['udata']);

				$userinfo['dailyquest'] = json_decode($userinfo['dailyquest'],true);
				$userinfo['dailyquest']['zhongzhi'] = $userinfo['dailyquest']['zhongzhi']+1;
				$dailyquest = json_encode($userinfo['dailyquest']);
				C::t('#'.$jn.'#'.$jn.'_user')->update($userinfo['juid'],array('udata'=>$userinfo['udata'],'lastsituation'=>$_G['timestamp'],'dailyquest'=>$dailyquest));

				C::t('#'.$jn.'#'.$jn.'_land')->update($jinfo['jfid'],array('fdata'=>$jinfo['fdata']));
				discuz_process::unlock('update_jnfarm'.$_G['uid']);
				$linkgen = lang("plugin/$jn","s050");
			}else{
				discuz_process::unlock('update_jnfarm'.$_G['uid']);
				showmessage('Keep out');
			}

		}


		$linkgen = '<script>'.$autoclose.'ajaxget(\'plugin.php?id='.$jn.'&do=normal&ac=updateland&formhash='.$_G['formhash'].'&timestamp='.$_G['timestamp'].'&jhash='.$pass.'\',\'jnland\');layer.msg(\''.$linkgen.'\');ajaxget(\'plugin.php?id='.$jn.'&do=normal&ac=putseed&jfid=auto&fhash='.$pass.'\',\'try\');</script>';//����Ҫ���� �������صĸ��� 
		discuz_process::unlock('update_jnfarm'.$_G['uid']);
		include template($jn.':'.$jn.'_normal');
		exit;
	}
	//$linkgen = 'hahaha';//����ֱ�Ӹ�������ͼƬ
	//$linkgen = lang("plugin/$jn","s050").'<script>ajaxget("plugin.php?id='.$jn.'&do=ajax&ac=updatejfid&jfid='.$jfid.'&timestamp='.$_G['timestamp'].'","jfid'.$jfid.'");ajaxget("plugin.php?id='.$jn.'&do=ajax&ac=updatejrid&jfid='.$jfid.'&timestamp='.$_G['timestamp'].'","jrid'.$jfid.'");</script>';
}
//From: Dism��taobao��com
?>