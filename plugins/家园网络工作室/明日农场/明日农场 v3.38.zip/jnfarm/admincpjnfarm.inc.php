<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
};
global $_G;
$jn = 'jnfarm';
$jnc = $_G['cache']['plugin'][$jn];
$g_adminids = explode('|',$jnc['adminids']);//����ԱȨ��
if(file_exists(DISCUZ_ROOT.'source/plugin/'.$jn.'/module/magappcheck.php')){
	if (!$_G['uid']){
		if(!$jnc['mgappurl']){
			showmessage('not_loggedin','',array(), array('login' => true));
		}
		header("Location: ".$jnc['mgappurl']."/mag/user/v1/wxwap/toWeiXinAuthorLogin?return_url=plugin.php?id=jnfarm");
	}
}else{
	if (!$_G['uid']) showmessage('not_loggedin','',array(), array('login' => true));
}
require DISCUZ_ROOT.'source/plugin/'.$jn.'/module/func.php';
if(!in_array($_G['uid'],$g_adminids)){
	showmessage("$jn:s002");
}
$geturl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") ."://$_SERVER[HTTP_HOST]";
$gameuid = DB::fetch_all("SELECT uid FROM ".DB::table('game_jnfarm_user')." ");
foreach($gameuid as $gu){
	$ug[$n] = $gu['uid'];
	$n++;
	$glist[] = $gu;
}
$ug = implode(',',$ug);
if($ug){
	$username = DB::fetch_all("SELECT username,uid FROM ".DB::table('common_member')." WHERE uid IN ($ug)");//��usernameץ����
	$username = array_column($username, null, 'uid');
}

$seed = DB::fetch_all("SELECT * FROM ".DB::table('game_jnfarm_item')." WHERE type = 'seed' ORDER BY jsid ASC");
foreach($seed as $sd){
	$sd['sdata'] = json_decode($sd['sdata'],true);
	$sdlist[] = $sd;
}
$sdlist = array_column($sdlist, null, 'jsid'); //��array index key ���� jsid
//fertilize list
$fertilizes = DB::fetch_all("SELECT * FROM ".DB::table('game_jnfarm_item')." WHERE type = 'fertilize' ORDER BY jsid ASC");
foreach($fertilizes as $fe){
	$fe['sdata'] = json_decode($fe['sdata'],true);
	$felist[] = $fe;
}
$felist = array_column($felist, null, 'jsid');

$itemall = DB::fetch_all("SELECT * FROM ".DB::table('game_jnfarm_item')." ");
foreach($itemall as $im){
	$im['sdata'] = json_decode($im['sdata'],true);
	$imlist[] = $im;
}
$imlist = array_column($imlist, null, 'jsid');

foreach($_G['setting']['extcredits'] as $key => $value){
	$ext = 'extcredits'.$key;
	$systemc['extcredits'][$key]['title'] = $value['title'];
	$systemc['extcredits'][$key]['value'] = $_G['member'][$ext];
	$systemc['extcredits'][$key]['key'] = $key;
}
//�����û���
$farmgroup = DB::fetch_all("SELECT * FROM ".DB::table('common_usergroup')." ORDER BY groupid ASC ");

if(!$_GET['do']){ //ϵͳ����
	$fset = DB::fetch_first("SELECT setdata FROM ".DB::table('game_jnfarm_fset')." WHERE jfset = '1'");
	$fset['setdata'] = json_decode($fset['setdata'],true);
	$appdownloadword = iconv('UTF-8',$_G['charset'],$fset['setdata']['appdownloadword']);
	//testing
	for($x=1;$x<=24;$x++){
		$text .= lang("plugin/$jn","s072").$x.': '.lang("plugin/$jn","s073").' <input type="text" class="ps" name="lvl'.$x.'" value="'.$fset['setdata']['expandset'][$x]['lvl'].'"> '.lang("plugin/$jn","s074").' <input type="text" class="ps" name="cost'.$x.'" value="'.$fset['setdata']['expandset'][$x]['cost'].'"> '.$jnc['mt'].'<br>';
	}
}
//ɾ����չ
$extend = array('achieve','cashout','combine','pet','dailyquest','market','directextcredits','magapp','magappredirect','realland','reallanddirect','challenge','invite','season','tiliitem','mall','vip','qianfanapp','qianfanjinbi','guild','card');
if($_GET['do'] == 'deleteextend'){
	$type = daddslashes($_GET['extend']);
	if(in_array($type,$extend)){
		if(file_exists(DISCUZ_ROOT.'source/plugin/'.$jn.'/module/'.$type.'.php')){
			unlink(DISCUZ_ROOT.'source/plugin/'.$jn.'/module/'.$type.'.php');
		}
		if(file_exists(DISCUZ_ROOT.'source/plugin/'.$jn.'/module/admincp/'.$type.'.php')){
			unlink(DISCUZ_ROOT.'source/plugin/'.$jn.'/module/admincp/'.$type.'.php');
		}
		if(file_exists(DISCUZ_ROOT.'source/plugin/'.$jn.'/table/table_jnfarm_'.$type.'.php')){
			unlink(DISCUZ_ROOT.'source/plugin/'.$jn.'/table/table_jnfarm_'.$type.'.php');
		}
		if(file_exists(DISCUZ_ROOT.'source/plugin/'.$jn.'/template/'.$jn.'_'.$type.'.htm')){
			unlink(DISCUZ_ROOT.'source/plugin/'.$jn.'/template/'.$jn.'_'.$type.'.htm');
		}
		if(file_exists(DISCUZ_ROOT.'source/plugin/'.$jn.'/template/touch/'.$jn.'_'.$type.'.htm')){
			unlink(DISCUZ_ROOT.'source/plugin/'.$jn.'/template/touch/'.$jn.'_'.$type.'.htm');
		}
		showmessage("$jn:s179",'plugin.php?id='.$jn.':admincp'.$jn.'&do=viewext',array(),array('showdialog' => 1, 'showmsg' => true, 'alert' => 'right', 'locationtime'=>true));
	}
}
if(file_exists(DISCUZ_ROOT.'source/plugin/'.$jn.'/module/card_adv.php')){
	$advon = 1;
}
if(file_exists(DISCUZ_ROOT.'source/plugin/'.$jn.'/module/card_pk.php')){
	$pkon = 1;
}
if(file_exists(DISCUZ_ROOT.'source/plugin/'.$jn.'/module/magappredirect.php')){
	$magappredirecton = '1';
}
if(file_exists(DISCUZ_ROOT.'source/plugin/'.$jn.'/module/admincp/card.php')){
	$cardon = '1';
	//require DISCUZ_ROOT.'source/plugin/'.$jn.'/module/admincp/card.php';
}
if(file_exists(DISCUZ_ROOT.'source/plugin/'.$jn.'/module/admincp/invite.php')){
	$inviteon = '1';
	require DISCUZ_ROOT.'source/plugin/'.$jn.'/module/admincp/invite.php';
}
if(file_exists(DISCUZ_ROOT.'source/plugin/'.$jn.'/module/achieve.php')){
	$achieveon = '1';
}
if(file_exists(DISCUZ_ROOT.'source/plugin/'.$jn.'/module/cashout.php')){
	$cashouton = '1';
}

if(file_exists(DISCUZ_ROOT.'source/plugin/'.$jn.'/module/combine.php')){
	$combineon = '1';
}
if(file_exists(DISCUZ_ROOT.'source/plugin/'.$jn.'/module/admincp/pet.php')){
	$peton = '1';
}
if(file_exists(DISCUZ_ROOT.'source/plugin/'.$jn.'/module/magapp.php')){
	$magappon = '1';
}
if(file_exists(DISCUZ_ROOT.'source/plugin/'.$jn.'/module/qianfanapp.php')){
	$qianfanappon = '1';
	if(file_exists(DISCUZ_ROOT.'source/plugin/'.$jn.'/module/qianfanjinbi.php')){
		$qianfanjinbion = '1';
	}
}
if($_GET['do'] == 'cashout'){
	if($cashouton == '1'){
		require DISCUZ_ROOT.'source/plugin/'.$jn.'/module/admincp/cashout.php';
	}
}
if(file_exists(DISCUZ_ROOT.'source/plugin/'.$jn.'/module/directextcredits.php')){
	$directextcreditson = '1';
}

if(file_exists(DISCUZ_ROOT.'source/plugin/'.$jn.'/module/magappredirect.php')){
	$magappredirecton = '1';
}
if(file_exists(DISCUZ_ROOT.'source/plugin/'.$jn.'/module/reallanddirect.php')){
	$reallanddirecton = '1';
}
if(file_exists(DISCUZ_ROOT.'source/plugin/'.$jn.'/module/market.php')){
	$marketon = '1';
}
if(file_exists(DISCUZ_ROOT.'source/plugin/'.$jn.'/module/tiliitem.php')){
	$tiliitemon = '1';
}
if(file_exists(DISCUZ_ROOT.'source/plugin/'.$jn.'/module/admincp/challenge.php')){
	$challengeon = '1';
}
if(file_exists(DISCUZ_ROOT.'source/plugin/'.$jn.'/module/admincp/vip.php')){
	$vipon = '1';
}
if(file_exists(DISCUZ_ROOT.'source/plugin/'.$jn.'/module/admincp/mall.php')){
	$mallon = '1';
}
if(file_exists(DISCUZ_ROOT.'source/plugin/'.$jn.'/module/admincp/guild.php')){
	$guildon = '1';
}
if(file_exists(DISCUZ_ROOT.'source/plugin/'.$jn.'/module/admincp/dailyquest.php')){
	$dailyon = '1';
	require DISCUZ_ROOT.'source/plugin/'.$jn.'/module/admincp/dailyquest.php';
}

if(file_exists(DISCUZ_ROOT.'source/plugin/'.$jn.'/module/admincp/realland.php')){
	$reallandon = '1';
	//require DISCUZ_ROOT.'source/plugin/'.$jn.'/module/admincp/realland.php';
}
if(file_exists(DISCUZ_ROOT.'source/plugin/'.$jn.'/module/admincp/season.php')){
	$seasonon = '1';
	require DISCUZ_ROOT.'source/plugin/'.$jn.'/module/admincp/season.php';
}

if($_GET['do'] == 'realland' && $reallandon == '1'){
	require DISCUZ_ROOT.'source/plugin/'.$jn.'/module/admincp/realland.php';
	exit;
}
if($_GET['do'] == 'pet'){
	if($peton == '1'){
		require DISCUZ_ROOT.'source/plugin/'.$jn.'/module/admincp/pet.php';
	}else{
		$petinfo = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_pet')." WHERE jpid = '1'");
		$petinfo['jpdata'] = json_decode($petinfo['jpdata'],true);
		if(submitcheck('editsubmit')){
			$jptitle = daddslashes($_GET['jptitle']);
			$jp['jpdata']['pimg'] = daddslashes($_GET['pimg']);
			$jp['jpdata']['attack'] = dintval($_GET['attack']);
			$jp['jpdata']['hungry'] = dintval($_GET['hungry']);
			$jp['jpdata']['hungrytime'] = dintval($_GET['hungrytime']);
			$jp['jpdata']['buyprice'] = dintval($_GET['buyprice']);
			$jp['jpdata']['lostcoin'] = dintval($_GET['lostcoin']);
			$jp['jpdata']['buytype'] = 1;
			$jpdata = json_encode($jp['jpdata'],true);
			C::t("#jnfarm#jnfarm_pet")->update($petinfo['jpid'],array('jptitle'=>$jptitle,'jpdata'=>$jpdata));
			showmessage("$jn:o006",'plugin.php?id='.$jn.':admincp'.$jn.'&do=pet');
		}
	}
}
if($_GET['do'] == 'mall' && $mallon == '1'){
	require DISCUZ_ROOT.'source/plugin/'.$jn.'/module/admincp/mall.php';
	exit;
}
if($_GET['do'] == 'vip' && $vipon == '1'){
	require DISCUZ_ROOT.'source/plugin/'.$jn.'/module/admincp/vip.php';
	exit;
}
if($_GET['do'] == 'guild' && $guildon == '1'){
	require DISCUZ_ROOT.'source/plugin/'.$jn.'/module/admincp/guild.php';
	exit;
}
if($_GET['do'] == 'card' && $cardon == '1'){
	require DISCUZ_ROOT.'source/plugin/'.$jn.'/module/admincp/card.php';
	exit;
}
if($_GET['do'] == 'achieve'){
	if($cardon == '1'){
		$cardall = C::t('#jnfarm#jnfarm_card')->loadall();
		$cardall = array_column($cardall,null,'jcid');
	}
	if($_GET['jaid']){
		$jaid = dintval($_GET['jaid']);
		$jinfo = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_achieve')." WHERE jaid = '$jaid'");
		if(submitcheck('editsubmit')){
			$jatitle = daddslashes($_GET['jatitle']);
			$jatype = dintval($_GET['jatype']);
			$jaqty = dintval($_GET['jaqty']);
			$gifttype = dintval($_GET['gifttype']);
			if($gifttype > 1){
				$jxtra = dintval($_GET['jxtra'.$gifttype]);
			}
			$wxtra = '';
			if($jatype == 5 || $jatype == 6){
				$wxtra = dintval($_GET['wxtra']);
			}
			$gifttype = dintval($_GET['gifttype']);
			$giftqty = dintval($_GET['giftqty']);
			$jaorder = dintval($_GET['jaorder']);
			$frontac = dintval($_GET['frontac']);
			$padd = dintval($_GET['padd']);
			
			if($frontac == $jaid){
				showmessage("$jn:s107");
			}
			DB::query("UPDATE ".DB::table('game_jnfarm_achieve')." SET jatitle = '$jatitle', jatype = '$jatype', jaqty = '$jaqty', jxtra = '$jxtra', gifttype = '$gifttype', giftqty = '$giftqty', jaorder = '$jaorder', frontac = '$frontac', wxtra = '$wxtra', padd = '$padd' WHERE jaid = '$jaid'");
			showmessage("$jn:s004","plugin.php?id=jnfarm:admincpjnfarm&do=achieve");
		}
	}
	if(submitcheck('newsubmit')){
		$jatitle = daddslashes($_GET['jatitle']);
		$jatype = dintval($_GET['jatype']);
		$jaqty = dintval($_GET['jaqty']);
		$gifttype = dintval($_GET['gifttype']);
		if($gifttype >= 1){
			$jxtra = dintval($_GET['jxtra'.$gifttype]);
		}
		$wxtra = '';
		if($jatype == 5 || $jatype == 6){
			$wxtra = dintval($_GET['wxtra']);
		}
		$gifttype = dintval($_GET['gifttype']);
		$giftqty = dintval($_GET['giftqty']);
		$jaorder = dintval($_GET['jaorder']);
		$frontac = dintval($_GET['frontac']);
		$padd = dintval($_GET['padd']);
		DB::query("REPLACE INTO ".DB::table('game_jnfarm_achieve')." (jatitle,jatype,jaqty,jxtra,gifttype,giftqty,jaorder,frontac,wxtra,padd,sucuid) VALUES ('$jatitle','$jatype','$jaqty','$jxtra','$gifttype','$giftqty','$jaorder','$frontac','$wxtra','$padd','0')");
		showmessage("$jn:o004",'plugin.php?id=jnfarm:admincpjnfarm&do=achieve');
	}
	$listall = DB::fetch_all("SELECT * FROM ".DB::table('game_jnfarm_achieve')." ORDER BY jatype ASC, jaorder ASC ");
	$x = 1;
	foreach($listall as $la){
		if(!$la['sucuid']){
			$la['succppl'] = '0';
		}else{
			$la['succppl'] = count(explode(',',$la['sucuid']))-1;
		}
		if($la['gifttype'] == '1'){
			$la['gtitle'] = $jnc['mt'];
		}
		if($la['gifttype'] == '2'){
			$la['gtitle'] = $sdlist[$la['jxtra']]['stitle'].lang("plugin/$jn","s038");
		}
		if($la['gifttype'] == '3'){
			$la['gtitle'] = $sdlist[$la['jxtra']]['stitle'];
		}
		if($la['gifttype'] == '4'){
			$la['gtitle'] = $felist[$la['jxtra']]['stitle'];
		}
		if($la['gifttype'] == '5'){
			$la['gtitle'] = '['.lang("plugin/$jn","s108").']'.$_G['setting']['extcredits'][$la['jxtra']]['title'];
		}
		if($la['gifttype'] == '6'){
			$la['gtitle'] = $cardall[$la['jxtra']]['ctitle'];
		}
		$la['x'] = $x;
		$x++;
		//$la['succppl'] = count($la['sucuid']);
		$lalist[] = $la;
	}
}
if(file_exists(DISCUZ_ROOT.'source/plugin/'.$jn.'/module/market.php')){
	$marketon = '1';
	$fset = DB::fetch_first("SELECT setdata FROM ".DB::table('game_jnfarm_fset')." WHERE jfset = '1'");
	$fset['setdata'] = json_decode($fset['setdata'],true);
	if($_GET['do'] == 'market'){
		if(submitcheck('syssubmit')){
			$fset['setdata']['marketsuilv'] = dintval($_GET['marketsuilv']);
			$fset['setdata']['marketmax'] = dintval($_GET['marketmax']);
			
			$fset['setdata'] = json_encode($fset['setdata'],true);
			
			DB::query("UPDATE ".DB::table('game_jnfarm_fset')." SET setdata = '".$fset['setdata']."' WHERE jfset = '1'");
			showmessage("$jn:s004","plugin.php?id=$jn:admincp$jn&do=market");
		}
		if($_GET['delete'] == 'true'){
			$jmid = dintval($_GET['jmid']);
			if($_GET['formhash'] == $_G['formhash']){
				$jinfo = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_market')." WHERE jmid = '$jmid' AND buytime = '0'");
				if($jinfo['jmid'] > 0){
					$userinfo = C::t('#'.$jn.'#'.$jn.'_user')->userinfo($jinfo['selluid']);
					$userinfo['udata'] = json_decode($userinfo['udata'],true);
					$jinfo['mdata'] = json_decode($jinfo['mdata'],true);
					
					if($jinfo['mtype'] == 'seed'){
						$cseed = count($userinfo['udata']['seed']);
						for($x=1;$x<=$cseed;$x++){
							if($userinfo['udata']['seed'][$x][0] == $jinfo['mdata'][0]){
								$userinfo['udata']['seed'][$x][1] = $userinfo['udata']['seed'][$x][1]+$jinfo['mdata'][2];
								break;
							}
						}
					}
					if($jinfo['mtype'] == 'fert'){
						$cfert = count($userinfo['udata']['fertilize']);
						for($x=1;$x<=$cfert;$x++){
							if($userinfo['udata']['fertilize'][$x][0] == $jinfo['mdata'][0]){
								$userinfo['udata']['fertilize'][$x][1] = $userinfo['udata']['fertilize'][$x][1]+$jinfo['mdata'][2];
								break;
							}
						}
					}
					if($jinfo['mtype'] == 'prod'){
						$cprod = count($userinfo['udata']['prod']);
						for($x=1;$x<=$cprod;$x++){
							if($userinfo['udata']['prod'][$x][0] == $jinfo['mdata'][0]){
								$userinfo['udata']['prod'][$x][1] = $userinfo['udata']['prod'][$x][1]+$jinfo['mdata'][2];
								break;
							}
						}
					}
					
					DB::query("DELETE FROM ".DB::table('game_jnfarm_market')." WHERE jmid = '$jmid'");
					$userinfo['udata'] = json_encode($userinfo['udata'],true);
					C::t('#'.$jn.'#'.$jn.'_user')->update($userinfo['juid'],array('udata'=>$userinfo['udata']));
					showmessage("$jn:s104",'plugin.php?id=jnfarm&do=market');
				}else{
					showmessage("$jn:s105");
				}
			}
		}
		$page = $_G['page'];
		$tpp = 100;
		$total = DB::result_first("SELECT count(*) cnt FROM ".DB::table('game_jnfarm_market')."");
		if(@ceil($total/$tpp) < $page) 	$page = 1;
		$start_limit = ($page - 1) * $tpp;
		$quserinfo = DB::fetch_all("SELECT * FROM ".DB::table('game_jnfarm_market')." ORDER BY jmid DESC LIMIT {$start_limit},{$tpp}");
		foreach ($quserinfo as $qc) {
			$qc['createtime'] = date("Y-m-d H:i:s",$qc['createtime']);
			if($qc['buytime'] > 0){
				$qc['buytime'] = date("Y-m-d H:i:s",$qc['buytime']);
			}
			$qc['selluser'] = $username[$qc['selluid']]['username'];
			$qc['buyuser'] = $username[$qc['buyuid']]['username'];
			$qc['mdata'] = json_decode($qc['mdata'],true);
			if($qc['mtype'] == 'prod'){
				$qc['itemtitle'] = $sdlist[$qc['mdata'][0]]['stitle'];
			}
			if($qc['mtype'] == 'fert'){
				$qc['itemtitle'] = $felist[$qc['mdata'][0]]['stitle'];
			}
			if($qc['mtype'] == 'seed'){
				$qc['itemtitle'] = $sdlist[$qc['mdata'][0]]['stitle'].lang("plugin/$jn","s038");
			}
			$qc['price'] = $qc['mdata'][1]*$qc['mdata'][2];

			$marketlist[] = $qc;
		};
		$multipage = multi($total, $tpp, $page, "plugin.php?id=".$jn.":admincp$jn&do=market", $_G['setting']['threadmaxpages']);
	}
}
if($_GET['do'] == 'updatesys'){
	if(submitcheck('syssubmit')){
		$fset = DB::fetch_first("SELECT setdata FROM ".DB::table('game_jnfarm_fset')." WHERE jfset = '1'");
		$fset['setdata'] = json_decode($fset['setdata'],true);
		
		$newtili = dintval($_GET['newtili']);
		$leveltili = dintval($_GET['leveltili']);
		if($newtili != $fset['setdata']['newtili'] || $leveltili != $fset['setdata']['leveltili']){
			//�������ҵ������Ž��и���
			$fuser = DB::fetch_all("SELECT * FROM ".DB::table('game_jnfarm_user')."");
			foreach($fuser as $fu){
				$fu['udata'] = json_decode($fu['udata'],true);
				$fu['udata']['data']['tili'][1] = ($fu['udata']['data']['farmlvl']*$leveltili)+$newtili;
				$fu['udata'] = json_encode($fu['udata']);
				C::t('#jnfarm#jnfarm_user')->update($fu['juid'],array('udata'=>$fu['udata']));
			}
		}
		
		$fset['setdata']['hongtu'] = dintval($_GET['hongtu']);
		$fset['setdata']['hongtucost'] = dintval($_GET['hongtucost']);
		$fset['setdata']['situationtime'] = dintval($_GET['situationtime']);
		$fset['setdata']['situation'] = dintval($_GET['situation']);
		$fset['setdata']['savetime'] = dintval($_GET['savetime']);
		$fset['setdata']['qtydd'] = dintval($_GET['qtydd']);
		$fset['setdata']['freeland'] = dintval($_GET['freeland']);
		$fset['setdata']['wormcost'] = dintval($_GET['wormcost']);
		$fset['setdata']['weedcost'] = dintval($_GET['weedcost']);
		$fset['setdata']['watercost'] = dintval($_GET['watercost']);
		$fset['setdata']['newtili'] = dintval($_GET['newtili']);
		$fset['setdata']['leveltili'] = dintval($_GET['leveltili']);
		$fset['setdata']['tilihuifu'] = dintval($_GET['tilihuifu']);
		$fset['setdata']['ranklimit'] = dintval($_GET['ranklimit']);
		$thief = explode(',',$_GET['thiefqty']);
		$fset['setdata']['thiefqty'][0] = dintval($thief[0]);
		$fset['setdata']['thiefqty'][1] = dintval($thief[1]);
		$fset['setdata']['thiefqtymin'] = dintval($_GET['thiefqtymin']);
		$fset['setdata']['pclink'] = daddslashes($_GET['pclink']);
		$fset['setdata']['mobilelink'] = daddslashes($_GET['mobilelink']);
		$fset['setdata']['magapplink'] = daddslashes($_GET['magapplink']);
		$fset['setdata']['appdownloadword'] = iconv($_G['charset'],'UTF-8',daddslashes($_GET['appdownloadword']));
		for($x=1;$x<=24;$x++){
			$fset['setdata']['expandset'][$x]['lvl'] = dintval($_GET['lvl'.$x]); 
			$fset['setdata']['expandset'][$x]['cost'] = dintval($_GET['cost'.$x]);
		}
		if($magappon == '1' || $qianfanappon == '1'){
			$fset['setdata']['sitesituationgap'] = dintval($_GET['sitesituationgap']);
			$fset['setdata']['sitesituationtimecheck'] = dintval($_GET['sitesituationtimecheck']);
		}
		$fset['setdata'] = json_encode($fset['setdata'],true);
		C::t('#'.$jn.'#'.$jn.'_fset')->update(1,array('setdata'=>$fset['setdata']));
		//DB::query("UPDATE ".DB::table('game_jnfarm_fset')." SET setdata = '".$fset['setdata']."' WHERE jfset = '1'");
		showmessage("$jn:s004","plugin.php?id=$jn:admincp$jn");
	}
}
if($_GET['do'] == 'userlist' && !$_GET['userid']){
	$page = $_G['page'];
	$tpp = 500;
	$total = DB::result_first("SELECT count(*) cnt FROM ".DB::table('game_jnfarm_user')."");
	if(@ceil($total/$tpp) < $page) 	$page = 1;
	$start_limit = ($page - 1) * $tpp;
	
	$ulist = DB::fetch_all("SELECT t1.*,t2.username FROM ".DB::table('game_jnfarm_user')." t1 LEFT JOIN ".DB::table('common_member')." t2 ON (t1.uid = t2.uid) ORDER BY t1.juid ASC LIMIT {$start_limit},{$tpp}");
	foreach($ulist as $ul){
		$ul['udata'] = json_decode($ul['udata'],true);
		$ul['createtime'] = date("Y-m-d H:i:s",$ul['createtime']);
		$uslist[] = $ul;
	}
	$multipage = multi($total, $tpp, $page, "plugin.php?id=".$jn.":admincp$jn&do=userlist", $_G['setting']['threadmaxpages']);
}
if($_GET['do'] == 'userlist' && $_GET['userid'] > 0){
	$userid = dintval($_GET['userid']);
	$uinfo = DB::fetch_first("SELECT t1.*,t2.username FROM ".DB::table('game_jnfarm_user')." t1 LEFT JOIN ".DB::table('common_member')." t2 ON (t1.uid = t2.uid) WHERE t1.uid = '$userid'");
	$uinfo['createtime'] = date('Y-m-d H:i:s',$uinfo['createtime']);
	$uinfo['vipexpired'] = date('Y-m-d H:i:s',$uinfo['vipexpired']);
	$uinfo['udata'] = json_decode($uinfo['udata'],true);
	
	$itemall = DB::fetch_all("SELECT * FROM ".DB::table('game_jnfarm_item')." ");
	$itemall = array_column($itemall, null, 'jsid');
	
	$fr = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_land')." WHERE uid = '$userid'");
	$fr['fdata'] = json_decode($fr['fdata'],true);
	$cfr = count($fr['fdata']);
	for($x=1;$x<=$cfr;$x++){
		$fr['fdata'][$x]['prodstart'] = date("Y-m-d H:i:s",$fr['fdata'][$x]['prodstart']);
		$fr['fdata'][$x]['prodfinish'] = date("Y-m-d H:i:s",$fr['fdata'][$x]['prodfinish']);
		$fr['fdata'][$x]['expired'] = date("Y-m-d H:i:s",$fr['fdata'][$x]['expired']);
		if($fr['fdata'][$x]['type'] == '2'){
			$ltitle = lang("plugin/$jn","s084");
		}else{
			$ltitle = '';
		}
		if($fr['fdata'][$x]['seed'] > '0'){
			$prodtitle = $itemall[$fr['fdata'][$x]['seed']]['stitle'].' '.lang("plugin/$jn","s086").':'.$fr['fdata'][$x]['qtyleft'].'/'.$fr['fdata'][$x]['oriqty'].' '.lang("plugin/$jn","s087").':'.$fr['fdata'][$x]['prodstart'].' '.lang("plugin/$jn","s088").':'.$fr['fdata'][$x]['prodfinish'].' '.lang("plugin/$jn","s079").':'.$fr['fdata'][$x]['expired'];
		}else{
			$prodtitle = '-';
		}
		$frtext .= '<div style="padding:10px 0px 10px 0px; border-bottom:1px #CCCCCC solid;"><div style="width:10%; float:left">'.$x.'. '.$ltitle.'</div><div style="width:80%; float:left">'.lang("plugin/$jn","s085").': '.$prodtitle.' </div><div style="width:10%; float:left">'.lang("plugin/$jn","s089").'</div><div style="clear:both"></div></div>';
	}
	
	$gseed = count($uinfo['udata']['seed']);
	
	for($x = 1; $x<=$gseed;$x++){
		$thisr = $thisr.'<div style="padding:10px 0px 10px 0px; border-bottom:1px #CCCCCC solid;"><div style="width:50%; float:left">'.$itemall[$uinfo['udata']['seed'][$x][0]]['stitle'].lang("plugin/$jn","s038").'</div><div style="width:50%; float:left"><input type="number" value="'.$uinfo['udata']['seed'][$x][1].'" name="seed'.$x.'"></div><div style="clear:both"></div></div>';
	}
	
	$gfert = count($uinfo['udata']['fertilize']);
	for($x = 1; $x<=$gfert;$x++){
		$thisr = $thisr.'<div style="padding:10px 0px 10px 0px; border-bottom:1px #CCCCCC solid;"><div style="width:50%; float:left">'.$itemall[$uinfo['udata']['fertilize'][$x][0]]['stitle'].'</div><div style="width:50%; float:left"><input type="number" value="'.$uinfo['udata']['fertilize'][$x][1].'" name="fert'.$x.'"></div><div style="clear:both"></div></div>';
	}
	
	$gprod = count($uinfo['udata']['prod']);
	for($x = 1; $x<=$gprod;$x++){
		$thisr = $thisr.'<div style="padding:10px 0px 10px 0px; border-bottom:1px #CCCCCC solid;"><div style="width:50%; float:left">'.$itemall[$uinfo['udata']['prod'][$x][0]]['stitle'].'</div><div style="width:50%; float:left"><input type="number" value="'.$uinfo['udata']['prod'][$x][1].'" name="prod'.$x.'"></div><div style="clear:both"></div></div>';
	}
	
	$gtili = count($uinfo['udata']['tiliitem']);
	for($x = 1; $x<=$gtili;$x++){
		$thisr = $thisr.'<div style="padding:10px 0px 10px 0px; border-bottom:1px #CCCCCC solid;"><div style="width:50%; float:left">'.$itemall[$uinfo['udata']['tiliitem'][$x][0]]['stitle'].'</div><div style="width:50%; float:left"><input type="number" value="'.$uinfo['udata']['tiliitem'][$x][1].'" name="tiliitem'.$x.'"></div><div style="clear:both"></div></div>';
	}
	
	//�������
	$inviteref = DB::fetch_all("SELECT * FROM ".DB::table('game_jnfarm_user')." WHERE ref = '".$userid."'");
	foreach($inviteref as $ivr){
		$ivr['udata'] = json_decode($ivr['udata'],true);
		$ivrlist[] = $ivr;
	}
	$rlimit = count($inviteref);
	usort($ivrlist, function($a, $b) { //Sort the array using a user defined function
		return $a['udata']['data']['farmlvl'] > $b['udata']['data']['farmlvl'] ? -1 : 1; //Compare the scores
	});
			
	$ab = 1;
	foreach($ivrlist as $nl){
		$nl['x'] = $ab;
		$lvllist[] = $nl;
		$ab++;
		if($ab > $rlimit){
			break;
		}
	}
}
if($_GET['do'] == 'searchuser'){
	$userid = dintval($_GET['userid']);
	$usernamecp = daddslashes($_GET['usernamecp']);
	if(submitcheck('searchusersubmit')){
		if(!$userid && !$usernamecp){
			showmessage("$jn:s149");
		}
		if($userid <= 0){
			$searchuid = DB::fetch_first("SELECT * FROM ".DB::table('common_member')." WHERE username = '$usernamecp'");
			$searchuserid = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_user')." WHERE uid = '$searchuid[uid]'");
		}else{
			$searchuserid = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_user')." WHERE uid = '$userid'");	
		}
		if(!$searchuserid['uid']){
			showmessage("$jn:s163");
		}
		showmessage("$jn:o005",'plugin.php?id='.$jn.':admincp'.$jn.'&do=userlist&userid='.$searchuserid['uid'],array(),array('showdialog' => 1, 'showmsg' => true, 'alert' => 'right', 'locationtime'=>true));
	}
}
if($_GET['do'] == 'updateuser'){
	if(submitcheck('usersubmit')){
		$userid = dintval($_GET['userid']);
		$userinfo = C::t('#'.$jn.'#'.$jn.'_user')->userinfo($userid);
		$userinfo['udata'] = json_decode($userinfo['udata'],true);
		$userinfo['vipexpired'] = strtotime($_GET['vipexpired']);
		
		$data = array();
		$userinfo['udata']['data']['farmlvl'] = dintval($_GET['farmlvl']);
		$userinfo['udata']['data']['money'] = dintval($_GET['money']);
		$userinfo['udata']['data']['sales'] = dintval($_GET['sales']);
		$userinfo['udata']['data']['income'] = dintval($_GET['income']);
		$userinfo['udata']['data']['exp'] = dintval($_GET['exp']);
		$userinfo['udata']['data']['tili'][0] = dintval($_GET['tilinow']);
		$userinfo['udata']['data']['tili'][1] = dintval($_GET['tilimax']);

		$udata = json_encode($userinfo['udata']);

		DB::query("UPDATE ".DB::table('game_jnfarm_user')." SET udata = '$udata', vipexpired = '".$userinfo['vipexpired']."' WHERE uid = '$userid'");
		showmessage("$jn:s004","plugin.php?id=$jn:admincp$jn&do=userlist&userid=$userid",array(),array('showdialog' => 1, 'showmsg' => true, 'alert' => 'right'));
	}
	if(submitcheck('storesubmit')){
		$userid = dintval($_GET['userid']);
		$userinfo = C::t('#'.$jn.'#'.$jn.'_user')->userinfo($userid);
		$userinfo['udata'] = json_decode($userinfo['udata'],true);
		
		$gseed = count($userinfo['udata']['seed']);
		for($x = 1; $x<=$gseed;$x++){
			$userinfo['udata']['seed'][$x][1] = dintval($_GET['seed'.$x]);
		}

		$gfert = count($userinfo['udata']['fertilize']);
		for($x = 1; $x<=$gfert;$x++){
			$userinfo['udata']['fertilize'][$x][1] = dintval($_GET['fert'.$x]);
		}

		$gprod = count($userinfo['udata']['prod']);
		for($x = 1; $x<=$gprod;$x++){
			$userinfo['udata']['prod'][$x][1] = dintval($_GET['prod'.$x]);
		}
		
		$gtili = count($userinfo['udata']['tiliitem']);
		for($x = 1; $x<=$gtili;$x++){
			$userinfo['udata']['tiliitem'][$x][1] = dintval($_GET['tiliitem'.$x]);
		}

		$udata = json_encode($userinfo['udata']);

		DB::query("UPDATE ".DB::table('game_jnfarm_user')." SET udata = '$udata' WHERE uid = '$userid'");
		showmessage("$jn:s004","plugin.php?id=$jn:admincp$jn&do=userlist&userid=$userid",array(),array('showdialog' => 1, 'showmsg' => true, 'alert' => 'right'));
	}
}
if($_GET['do'] == 'level'){
	if(file_exists(DISCUZ_ROOT.'source/plugin/'.$jn.'/module/admincp/maxlevel.php')){
		$maxlevelon = '1';
		require DISCUZ_ROOT.'source/plugin/'.$jn.'/module/admincp/maxlevel.php';
	}else{
		if(submitcheck('levelsubmit')){
			for($x = 1;$x<=100;$x++){
				$expneed = dintval($_GET['lvl'.$x]);
				DB::query("UPDATE ".DB::table('game_jnfarm_level')." SET expneed = '$expneed' WHERE jlid = '$x' ");
			}
			showmessage("$jn:s004","plugin.php?id=$jn:admincp$jn&do=level",array(),array('showdialog' => 1, 'showmsg' => true, 'alert' => 'right'));
		}
		$lvl = DB::fetch_all("SELECT * FROM ".DB::table('game_jnfarm_level')." ORDER BY jlid ASC ");
	}
}
if($_GET['do'] == 'item'){
	$jsid = dintval($_GET['jsid']);
	if($jsid > 0){
		$jsinfo = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_item')." WHERE jsid = '$jsid'");
		if($jsinfo['jsid'] > 0){
			$jsinfo['sdata'] = json_decode($jsinfo['sdata'],true);
			if(submitcheck('updatesubmit')){
				$jstitle = addslashes($_GET['stitle']);
				$jiorder = dintval($_GET['jiorder']);
				$jsinfo['sdata']['minlvl'] = dintval($_GET['minlvl']);
				$jsinfo['sdata']['cost'] = dintval($_GET['cost']);
				$jsinfo['sdata']['cropsale'] = dintval($_GET['cropsale']);
				$jsinfo['sdata']['seedurl'] = daddslashes($_GET['seedurl']);
				$jsinfo['sdata']['buyable'] = dintval($_GET['buyable']);
				
				$jsinfo['sdata']['timesave'] = dintval($_GET['timesave']);
				
				$jsinfo['sdata']['ctime'] = dintval($_GET['ctime']);
				$jsinfo['sdata']['sale'] = dintval($_GET['sale']);
				$jsinfo['sdata']['hqty'][0] = dintval($_GET['hqty1']);
				$jsinfo['sdata']['hqty'][1] = dintval($_GET['hqty2']);
				$jsinfo['sdata']['exp'] = dintval($_GET['exp']);
				$jsinfo['sdata']['expiredtime'] = dintval($_GET['expiredtime']);
				$jsinfo['sdata']['imgurl'] = daddslashes($_GET['imgurl']);
				
				$jsinfo['sdata']['canfeed'] = dintval($_GET['canfeed']);
				if($jsinfo['sdata']['canfeed'] == '1'){
					$jsinfo['sdata']['feedadd'] = dintval($_GET['feedadd']);
				}else{
					$jsinfo['sdata']['feedadd'] = 0;
				}
				
				if($marketon == '1'){
					$jsinfo['sdata']['prodmarket'] = dintval($_GET['prodmarket']);
					$jsinfo['sdata']['prodmprice'][0] = dintval($_GET['prodmprice0']);
					$jsinfo['sdata']['prodmprice'][1] = dintval($_GET['prodmprice1']);
				}
				
				if($combineon == '1'){
					$jsinfo['sdata']['combine'] = array();
					if($_GET['combine'] == '1'){
						for($c=1;$c<=4;$c++){
							if($_GET['c'.$c.'cost'] > 0 && !$_GET['c'.$c] || !$_GET['c'.$c.'cost'] && $_GET['c'.$c] > 0){
								showmessage("$jn:s131");
							}
							if($_GET['c'.$c.'cost'] > 0 && $_GET['c'.$c] > 0){
								$jsinfo['sdata']['combine']['data'][$c][0] = dintval($_GET['c'.$c]);//jsid
								$jsinfo['sdata']['combine']['data'][$c][1] = dintval($_GET['c'.$c.'cost']);//quantityneed
								$jsinfo['sdata']['combine']['c'] = '1';
							}
						}
						if(!$jsinfo['sdata']['combine']['c']){
							showmessage("$jn:s132");
						}
						$jsinfo['sdata']['combine']['cost'] = dintval($_GET['combinecost']);
						$jsinfo['sdata']['combine']['timeneed'] = dintval($_GET['timeneed']);
					}
				}
				
				if($tiliitemon == '1'){
					$jsinfo['sdata']['tilihuifu'] = dintval($_GET['tilihuifu']);
				}
				
				$sdata = json_encode($jsinfo['sdata']);
				DB::query("UPDATE ".DB::table('game_jnfarm_item')." SET stitle = '$jstitle', sdata = '$sdata', jiorder = '$jiorder' WHERE jsid = '$jsid'");
				showmessage("$jn:s004","plugin.php?id=$jn:admincp$jn&do=item");
			}
		}else{
			showmessage("error");
		}
	}
	if(submitcheck('addsubmit')){
		$jstitle = addslashes($_GET['stitle']);
		$type = addslashes($_GET['type']);
		$jiorder = dintval($_GET['jiorder']);
		$jsinfo['sdata']['minlvl'] = dintval($_GET['minlvl']);
		$jsinfo['sdata']['cost'] = dintval($_GET['cost']);
		$jsinfo['sdata']['cropsale'] = dintval($_GET['cropsale']);
		$jsinfo['sdata']['seedurl'] = daddslashes($_GET['seedurl']);
		$jsinfo['sdata']['buyable'] = dintval($_GET['buyable']);
		$jsinfo['sdata']['expiredtime'] = dintval($_GET['expiredtime']);

		if(!$jstitle || !$type || !$jsinfo['sdata']['cost'] || !$jsinfo['sdata']['seedurl']){
				showmessage("$jn:o001");
		}
				
		$jsinfo['sdata']['timesave'] = dintval($_GET['timesave']);
		if($type == 'fertilize'){
			if(!$jsinfo['sdata']['timesave']){
				showmessage("$jn:o001");
			}
		}
				
		$jsinfo['sdata']['ctime'] = dintval($_GET['ctime']);
		$jsinfo['sdata']['sale'] = dintval($_GET['sale']);
		$jsinfo['sdata']['hqty'][0] = dintval($_GET['hqty1']);
		$jsinfo['sdata']['hqty'][1] = dintval($_GET['hqty2']);
		$jsinfo['sdata']['exp'] = dintval($_GET['exp']);
		$jsinfo['sdata']['imgurl'] = daddslashes($_GET['imgurl']);
		
		$jsinfo['sdata']['canfeed'] = dintval($_GET['canfeed']);
		if($jsinfo['sdata']['canfeed'] == '1'){
			$jsinfo['sdata']['feedadd'] = dintval($_GET['feedadd']);
		}else{
			$jsinfo['sdata']['feedadd'] = 0;
		}
		if($marketon == '1'){
			$jsinfo['sdata']['prodmarket'] = dintval($_GET['prodmarket']);
			$jsinfo['sdata']['prodmprice'][0] = dintval($_GET['prodmprice0']);
			$jsinfo['sdata']['prodmprice'][1] = dintval($_GET['prodmprice1']);
		}
				
		if($type == 'seed'){
			if(!$jsinfo['sdata']['ctime'] || !$jsinfo['sdata']['hqty'][0] || !$jsinfo['sdata']['hqty'][1] || !$jsinfo['sdata']['imgurl']){
				showmessage("$jn:o001");
			}
		}
		
		if($type == 'tiliitem'){
			if($tiliitemon == '1'){
				$jsinfo['sdata']['tilihuifu'] = dintval($_GET['tilihuifu']);
				if(!$jsinfo['sdata']['tilihuifu']){
					showmessage("$jn:o007");
				}
			}else{
				showmessage("$jn:s242",'https://dism.taobao.com/?@jnfarm.plugin.90236');
			}
		}
		if($combineon == '1'){
			if($type == 'nitem'){
				if($_GET['combine'] == '1'){
					for($c=1;$c<=4;$c++){
						if($_GET['c'.$c.'cost'] > 0 && !$_GET['c'.$c] || !$_GET['c'.$c.'cost'] && $_GET['c'.$c] > 0){
							showmessage("$jn:s131");
						}
						if($_GET['c'.$c.'cost'] > 0 && $_GET['c'.$c] > 0){
							$jsinfo['sdata']['combine']['data'][$c][0] = dintval($_GET['c'.$c]);//jsid
							$jsinfo['sdata']['combine']['data'][$c][1] = dintval($_GET['c'.$c.'cost']);//quantityneed
							$jsinfo['sdata']['combine']['c'] = '1';
						}
					}
					if(!$jsinfo['sdata']['combine']['c']){
						showmessage("$jn:s132");
					}
					$jsinfo['sdata']['combine']['cost'] = dintval($_GET['combinecost']);
					$jsinfo['sdata']['combine']['timeneed'] = dintval($_GET['timeneed']);
				}
			}
		}
			
		$sdata = json_encode($jsinfo['sdata']);
		DB::query("REPLACE INTO ".DB::table('game_jnfarm_item')." (stitle,sdata,type,createtime,jiorder) VALUES ('$jstitle','$sdata','$type','".$_G['timestamp']."','$jiorder')");
		showmessage("$sdata","plugin.php?id=$jn:admincp$jn&do=item");
	}
	$item = DB::fetch_all("SELECT * FROM ".DB::table('game_jnfarm_item')." ORDER BY jsid ASC ");
	foreach($item as $it){
		$it['sdata'] = json_decode($it['sdata'],true);
		$itlist[] = $it;
	}
}
if($_GET['do'] == 'viewlog'){ //��ʾ�б�
	$userid = dintval($_GET['userid']);
	$typeid = dintval($_GET['typeid']);
	if($userid > 0 && $typeid > 0){ //�����ѯ�û���ĳ���ض�����
		$page = $_G['page'];
		$tpp = 100;
		$total = DB::result_first("SELECT count(*) cnt FROM ".DB::table('game_jnfarm_log')." WHERE uid = '$userid' AND acdo = '$typeid'");
		if(@ceil($total/$tpp) < $page) 	$page = 1;
		$start_limit = ($page - 1) * $tpp;
		$quserinfo = DB::fetch_all("SELECT t1.*,t2.username FROM ".DB::table('game_jnfarm_log')." t1 LEFT JOIN ".DB::table('common_member')." t2 ON (t1.uid=t2.uid) WHERE t1.uid = '$userid' AND t1.acdo = '$typeid' ORDER BY t1.jlid desc limit {$start_limit},{$tpp}");
		foreach ($quserinfo as $qu => $qc) {
			$qc['createtime'] = date("Y-m-d H:i:s",$qc['createtime']);
			$viewlog[] = $qc;
		};
		$multipage = multi($total, $tpp, $page, "plugin.php?id=".$jn.":admincp$jn&do=viewlog&userid".$userid."&typeid=".$typeid, $_G['setting']['threadmaxpages']);
	}elseif($userid == 0 && $typeid > 0){ //�����ѯȫվĳ����������
		$page = $_G['page'];
		$tpp = 100;
		$total = DB::result_first("SELECT count(*) cnt FROM ".DB::table('game_jnfarm_log')." WHERE acdo = '$typeid'");
		if(@ceil($total/$tpp) < $page) 	$page = 1;
		$start_limit = ($page - 1) * $tpp;
		$quserinfo = DB::fetch_all("SELECT t1.*,t2.username FROM ".DB::table('game_jnfarm_log')." t1 LEFT JOIN ".DB::table('common_member')." t2 ON (t1.uid=t2.uid) WHERE t1.acdo = '$typeid' ORDER BY t1.jlid desc limit {$start_limit},{$tpp}");
		foreach ($quserinfo as $qu => $qc) {
			$qc['createtime'] = date("Y-m-d H:i:s",$qc['createtime']);
			$viewlog[] = $qc;
		};
		$multipage = multi($total, $tpp, $page, "plugin.php?id=".$jn.":admincp$jn&do=viewlog&userid".$userid."&typeid=".$typeid, $_G['setting']['threadmaxpages']);
	}elseif($userid > 0 && $typeid == 0){ //�����ѯĳ����Ա��ȫվ��������
		$page = $_G['page'];
		$tpp = 100;
		$total = DB::result_first("SELECT count(*) cnt FROM ".DB::table('game_jnfarm_log')." WHERE uid = '$userid'");
		if(@ceil($total/$tpp) < $page) 	$page = 1;
		$start_limit = ($page - 1) * $tpp;
		$quserinfo = DB::fetch_all("SELECT t1.*,t2.username FROM ".DB::table('game_jnfarm_log')." t1 LEFT JOIN ".DB::table('common_member')." t2 ON (t1.uid=t2.uid) WHERE t1.uid = '$userid' ORDER BY t1.jlid desc limit {$start_limit},{$tpp}");
		foreach ($quserinfo as $qu => $qc) {
			$qc['createtime'] = date("Y-m-d H:i:s",$qc['createtime']);
			$viewlog[] = $qc;
		};
		$multipage = multi($total, $tpp, $page, "plugin.php?id=".$jn.":admincp$jn&do=viewlog&userid".$userid."&typeid=".$typeid, $_G['setting']['threadmaxpages']);
	}else{ //ȫվ��־
		$page = $_G['page'];
		$tpp = 100;
		$total = DB::result_first("SELECT count(*) cnt FROM ".DB::table('game_jnfarm_log'));
		if(@ceil($total/$tpp) < $page) 	$page = 1;
		$start_limit = ($page - 1) * $tpp;
		$quserinfo = DB::fetch_all("SELECT t1.*,t2.username FROM ".DB::table('game_jnfarm_log')." t1 LEFT JOIN ".DB::table('common_member')." t2 ON (t1.uid=t2.uid) ORDER BY t1.jlid desc limit {$start_limit},{$tpp}");
		foreach ($quserinfo as $qu => $qc) {
			$qc['createtime'] = date("Y-m-d H:i:s",$qc['createtime']);
			$viewlog[] = $qc;
		};
		$multipage = multi($total, $tpp, $page, "plugin.php?id=".$jn.":admincp$jn&do=viewlog", $_G['setting']['threadmaxpages']);
	}
}
if($_GET['do'] == 'searchlog'){
	$userid = dintval($_GET['userid']);
	$usernamecp = daddslashes(dhtmlspecialchars(dstripslashes($_GET['usernamecp'])));
	if(submitcheck('searchlogsubmit')){
		$typeid = dintval($_GET['selecttype']);
		if(!$userid && !$usernamecp){
			showmessage("$jn:s007",'plugin.php?id='.$jn.':admincp'.$jn.'&do=viewlog&userid=0&typeid='.$typeid,array(),array('showdialog' => 1, 'showmsg' => true, 'alert' => 'right', 'locationtime'=>true));
		}
		if(!$userid){
			$searchuid = DB::fetch_first("SELECT * FROM ".DB::table('common_member')." WHERE username = '$usernamecp'");
			$searchuserid = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_user')." WHERE uid = '$searchuid[uid]'");
		}else{
			$searchuserid = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_user')." WHERE uid = '$userid'");	
		}
		if(!$searchuserid['uid']){
			showmessage("$jn:o010");
		}
		
		if(!$typeid){
			$nviewlog = DB::result_first("SELECT count(*) cnt FROM ".DB::table('game_jnfarm_log')." WHERE uid = '".$searchuserid['uid']."'");
		}else{
			$nviewlog = DB::result_first("SELECT count(*) cnt FROM ".DB::table('game_jnfarm_log')." WHERE uid = '".$searchuserid['uid']."' AND acdo = '$typeid'");
		}
		if($nviewlog > 0){
			showmessage("$jn:o005",'plugin.php?id='.$jn.':admincp'.$jn.'&do=viewlog&userid='.$searchuserid['uid']."&typeid=".$typeid,array(),array('showdialog' => 1, 'showmsg' => true, 'alert' => 'right', 'locationtime'=>true));
		}else{
			showmessage("$jn:o011");
		}
	}
}
if($_GET['do'] == 'deletelog'){
	if(submitcheck('deletelogsubmit')){
		$deletedate = dintval($_GET['deletedate']);
		if(!$deletedate || $deletedate <= 0){
			showmessage("$jn:o002");
		}else{
			if($_GET['formhash'] == $_G['formhash']){
				$todaytime = strtotime(date("Y-m-d",$_G['timestamp']));
				$deletedatestr = $deletedate * 86400;
				$deletetime = $todaytime - $deletedatestr;
				$nrecord = DB::result_first("SELECT count(*) cnt FROM ".DB::table('game_jnfarm_log')." WHERE createtime < '$deletetime'");
				//$nrecord = DB::num_rows(DB::query("SELECT * FROM ".DB::table('game_jngoldmine_log')." WHERE createtime < '$deletetime'"));
				DB::query("DELETE FROM ".DB::table('game_jnfarm_log')." WHERE createtime < '$deletetime'");
				showmessage("$jn:s169",'plugin.php?id='.$jn.':admincp'.$jn.'&do=viewlog',array('nrecord'=>$nrecord),array('showdialog' => 1, 'showmsg' => true, 'alert' => 'right', 'locationtime'=>true));
			}else{
				showmessage("$jn:o003");
			}
		}
	}else{
		showmessage("$jn:o003");
	}
}
include template('diy:admincp'.$jn, 0, 'source/plugin/'.$jn.'/template');
?>