<?php
/*
 *	Author: Jnhill
 *	Last modified: 2017-01-01 17:42
 *	Filename: upgrade.php
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
//v2.0
//DB::query("ALTER TABLE ".DB::table('game_jnsango_advanture_list')." ADD `afid` INT NOT NULL AFTER `adata`;",'SILENT');
//DB::query("UPDATE ".DB::table('game_jnsango_advanture_list')." SET `afid` = '1' WHERE `afid` = '0';",'SILENT');

$sql = <<<EOF

CREATE TABLE IF NOT EXISTS pre_game_jnfarm_market (
  jmid int(11) NOT NULL AUTO_INCREMENT,
  selluid int(11) NOT NULL,
  buyuid int(11) NOT NULL,
  createtime int(11) NOT NULL,
  buytime int(11) NOT NULL,
  mdata text NOT NULL COMMENT '[itemid,price,qty]',
  mtype text NOT NULL,
  msign text NOT NULL,
  mstatus int(11) NOT NULL,
  PRIMARY KEY (jmid),
  KEY selluid (selluid),
  KEY buyuid (buyuid)
) ENGINE=MyISAM AUTO_INCREMENT=1;

EOF;
//ALTER TABLE  `pre_game_jnsango_tlog` ENGINE = INNODB;
runquery($sql);

$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_game_jnfarm_achieve` (
  `jaid` int(11) NOT NULL AUTO_INCREMENT,
  `jatitle` text NOT NULL,
  `jatype` int(11) NOT NULL COMMENT '1=lvl,2=planttime,3=harvesttime,4=money',
  `wxtra` text NOT NULL,
  `jaqty` int(11) NOT NULL,
  `gifttype` int(11) NOT NULL COMMENT '1=money,2=seedid,3=productid,4=fertilizerid,5=extcredits',
  `jxtra` int(11) NOT NULL,
  `giftqty` int(11) NOT NULL,
  `sucuid` text NOT NULL COMMENT 'successuid',
  `frontac` int(11) NOT NULL,
  `jaorder` int(11) NOT NULL,
  `padd` int(11) NOT NULL,
  PRIMARY KEY (`jaid`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

EOF;
//ALTER TABLE  `pre_game_jnsango_tlog` ENGINE = INNODB;
runquery($sql);

$sql7 = "INSERT INTO ".DB::table('game_jnfarm_achieve')." (`jaid`, `jatitle`, `jatype`, `wxtra`, `jaqty`, `gifttype`, `jxtra`, `giftqty`, `sucuid`, `frontac`, `jaorder`, `padd`) VALUES
(1, '$installlang[u008]', 1, '', 3, 3, 5, 30, '0,1', 0, 1, 5),
(2, '$installlang[u009]', 1, '', 5, 1, 0, 50, '0,1', 0, 2, 5),
(3, '$installlang[u010]', 2, '', 20, 1, 0, 100, '0', 0, 1, 5),
(4, '$installlang[u011]', 2, '', 50, 1, 0, 500, '0', 0, 2, 5),
(5, '$installlang[u012]', 1, '', 10, 1, 0, 1000, '0,1', 0, 3, 5),
(6, '$installlang[u013]', 1, '', 15, 1, 0, 1500, '0,1', 0, 4, 5),
(7, '$installlang[u014]', 3, '', 10, 2, 1, 1, '0,1', 0, 1, 5),
(8, '$installlang[u015]', 3, '', 50, 2, 2, 3, '0', 0, 2, 5),
(9, '$installlang[u016]', 3, '', 150, 2, 5, 3, '0', 0, 3, 5),
(10, '$installlang[u017]', 3, '', 200, 2, 5, 3, '0', 0, 4, 5),
(11, '$installlang[u018]', 3, '', 300, 2, 6, 3, '0', 0, 5, 5),
(12, '$installlang[u019]', 4, '', 10000, 4, 3, 3, '0,1', 0, 1, 3),
(13, '$installlang[u020]', 5, '1', 5, 1, 0, 100, '0', 0, 0, 5),
(14, '$installlang[u021]', 5, '2', 5, 1, 0, 200, '0,1', 0, 2, 5),
(15, '$installlang[u022]', 1, '', 20, 1, 0, 2000, '0,1', 0, 5, 5),
(16, '$installlang[u023]', 1, '', 25, 1, 0, 2500, '0,1', 0, 6, 5),
(17, '$installlang[u024]', 1, '', 30, 1, 0, 3000, '0', 0, 7, 5),
(18, '$installlang[u025]', 1, '', 35, 1, 0, 3500, '0', 0, 8, 10),
(19, '$installlang[u026]', 1, '', 40, 1, 0, 4000, '0', 0, 9, 10),
(20, '$installlang[u027]', 1, '', 50, 1, 0, 5000, '0', 0, 10, 10),
(21, '$installlang[u028]', 2, '', 100, 2, 2, 10, '0', 0, 3, 10),
(22, '$installlang[u029]', 4, '', 100000, 4, 3, 10, '0', 0, 2, 5),
(23, '$installlang[u030]', 6, '1', 10, 2, 1, 3, '0', 0, 1, 5),
(24, '$installlang[u031]', 6, '1', 20, 2, 1, 5, '0', 0, 2, 5);";

DB::query($sql7,'SILENT');

$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_game_jnfarm_cashout` (
  `jcid` int(11) NOT NULL AUTO_INCREMENT,
  `submituid` int(11) NOT NULL,
  `verifyuid` int(11) NOT NULL,
  `getext` int(11) NOT NULL,
  `extcredits` int(11) NOT NULL,
  `costjncmt` int(11) NOT NULL,
  `thischarges` int(11) NOT NULL,
  `allamount` int(11) NOT NULL,
  `createtime` int(11) NOT NULL,
  `updatetime` int(11) NOT NULL,
  `jstatus` int(11) NOT NULL,
  PRIMARY KEY (`jcid`),
  KEY `submituid` (`submituid`),
  KEY `verifyuid` (`verifyuid`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_game_jnfarm_combine` (
  `jcid` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `jcdata` text NOT NULL,
  PRIMARY KEY (`jcid`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

EOF;
//ALTER TABLE  `pre_game_jnsango_tlog` ENGINE = INNODB;
runquery($sql);

//v2.0
$sql7 = "INSERT INTO ".DB::table('game_jnfarm_item')." (`jsid`, `stitle`, `sdata`, `type`, `createtime`) VALUES
(8, '$installlang[u032]', '{\"minlvl\":7,\"cost\":266,\"cropsale\":133,\"seedurl\":\"crop_7_seed.svg\",\"buyable\":1,\"expiredtime\":3600,\"timesave\":0,\"ctime\":3600,\"sale\":50,\"hqty\":[17,21],\"exp\":5,\"imgurl\":\"crop_07.svg\",\"prodmarket\":1,\"prodmprice\":[4,30]}', 'seed', 1583899767),
(9, '$installlang[u033]', '{\"minlvl\":8,\"cost\":296,\"cropsale\":150,\"seedurl\":\"crop_6_seed.svg\",\"buyable\":1,\"timesave\":0,\"ctime\":1200,\"sale\":50,\"hqty\":[10,12],\"exp\":3,\"imgurl\":\"crop_6.svg\",\"prodmarket\":1,\"prodmprice\":[45,55],\"expiredtime\":1200}', 'seed', 1583658253),
(10, '$installlang[u034]', '{\"minlvl\":9,\"cost\":325,\"cropsale\":160,\"seedurl\":\"crop_8_seed.svg\",\"buyable\":1,\"expiredtime\":2400,\"timesave\":0,\"ctime\":2400,\"sale\":26,\"hqty\":[15,18],\"exp\":3,\"imgurl\":\"crop_08.svg\",\"prodmarket\":1,\"prodmprice\":[10,0]}', 'seed', 1584068109),
(11, '$installlang[u035]', '{\"minlvl\":10,\"cost\":605,\"cropsale\":300,\"seedurl\":\"crop_9_seed.svg\",\"buyable\":1,\"expiredtime\":7200,\"timesave\":0,\"ctime\":7200,\"sale\":60,\"hqty\":[15,18],\"exp\":3,\"imgurl\":\"crop_9.svg\",\"prodmarket\":1,\"prodmprice\":[50,55]}', 'seed', 1584068458),
(12, '$installlang[u036]', '{\"minlvl\":1,\"cost\":10,\"cropsale\":5,\"seedurl\":\"crop_12_seed.svg\",\"buyable\":1,\"expiredtime\":0,\"timesave\":0,\"ctime\":0,\"sale\":0,\"hqty\":[0,0],\"exp\":0,\"imgurl\":\"\",\"prodmarket\":1,\"prodmprice\":[10,15],\"combine\":{\"data\":{\"1\":[1,3]},\"c\":\"1\",\"cost\":10,\"timeneed\":0}}', 'nitem', 1584091233),
(13, '$installlang[u037]', '{\"minlvl\":11,\"cost\":600,\"cropsale\":300,\"seedurl\":\"crop_13_seed.svg\",\"buyable\":1,\"expiredtime\":14400,\"timesave\":0,\"ctime\":14400,\"sale\":10,\"hqty\":[15,25],\"exp\":4,\"imgurl\":\"crop_13.svg\",\"prodmarket\":1,\"prodmprice\":[50,55]}', 'seed', 1584337564),
(14, '$installlang[u038]', '{\"minlvl\":1,\"cost\":2,\"cropsale\":1,\"seedurl\":\"crop_14_seed.svg\",\"buyable\":1,\"expiredtime\":0,\"timesave\":0,\"ctime\":0,\"sale\":0,\"hqty\":[0,0],\"exp\":0,\"imgurl\":\"\",\"prodmarket\":1,\"prodmprice\":[5,10],\"combine\":{\"data\":{\"1\":[13,1]},\"c\":\"1\",\"cost\":5,\"timeneed\":10}}', 'nitem', 1584432913),
(15, '$installlang[u039]', '{\"minlvl\":1,\"cost\":100,\"cropsale\":50,\"seedurl\":\"crop_15_seed.svg\",\"buyable\":1,\"expiredtime\":0,\"timesave\":0,\"ctime\":0,\"sale\":0,\"hqty\":[0,0],\"exp\":0,\"imgurl\":\"\",\"prodmarket\":1,\"prodmprice\":[45,55],\"combine\":{\"data\":{\"1\":[12,1],\"2\":[14,1]},\"c\":\"1\",\"cost\":10,\"timeneed\":10}}', 'nitem', 1584433915);";

DB::query($sql7,'SILENT');

//v2.1
$qset = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_fset')." WHERE jfset = '1'");
$qset['setdata'] = json_decode($qset['setdata'],true);
if($qset['setdata']['tili'] != '1'){
	$alluser = DB::fetch_all("SELECT * FROM ".DB::table('game_jnfarm_user')." ");
	foreach($alluser as $al){
		$al['udata'] = json_decode($al['udata'],true);
		$al['udata']['data']['tili'][0] = '20';
		$al['udata']['data']['tili'][1] = '20';//max
		$udata = json_encode($al['udata']);
		DB::query("UPDATE ".DB::table('game_jnfarm_user')." SET udata = '$udata' WHERE uid = '".$al['uid']."'");
	}
	$qset['setdata']['tili'] = '1';
	$qset = json_encode($qset['setdata']);
	DB::query("UPDATE ".DB::table('game_jnfarm_fset')." SET setdata = '$qset'");
}
//v2.14
$qset = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_fset')." WHERE jfset = '1'");
$qset['setdata'] = json_decode($qset['setdata'],true);
if($qset['setdata']['thiefset'] != '1'){
	$qset['setdata']['thiefset'] = '1';
	$qset['setdata']['thiefqty'][0] = 1;
	$qset['setdata']['thiefqty'][1] = 3;
	$qset['setdata']['thiefqtymin'] = 50;
	$qset = json_encode($qset['setdata']);
	DB::query("UPDATE ".DB::table('game_jnfarm_fset')." SET setdata = '$qset'");
}
//v2.20
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_game_jnfarm_pet` (
  `jpid` int(11) NOT NULL AUTO_INCREMENT,
  `jptitle` text NOT NULL,
  `jpdata` text NOT NULL,
  `jpxtra` text NOT NULL,
  PRIMARY KEY (`jpid`)
) ENGINE=MyISAM AUTO_INCREMENT=7;
EOF;
//ALTER TABLE  `pre_game_jnsango_tlog` ENGINE = INNODB;
runquery($sql);

$sql7 = "INSERT INTO ".DB::table('game_jnfarm_pet')." (`jpid`, `jptitle`, `jpdata`, `jpxtra`) VALUES
(1, '$installlang[u040]', '{\"pimg\":\"source\\/plugin\\/jnfarm\\/template\\/images\\/pet1.gif\",\"attack\":10,\"hungry\":100,\"hungrytime\":7,\"buyprice\":100,\"lostcoin\":10,\"buytype\":1}', ''),
(2, '$installlang[u041]', '{\"pimg\":\"source\\/plugin\\/jnfarm\\/template\\/images\\/pet2.gif\",\"attack\":20,\"hungry\":100,\"hungrytime\":7,\"buyprice\":200,\"lostcoin\":12,\"buytype\":1}', ''),
(3, '$installlang[u042]', '{\"pimg\":\"source\\/plugin\\/jnfarm\\/template\\/images\\/pet3.gif\",\"attack\":25,\"hungry\":120,\"hungrytime\":7,\"buyprice\":350,\"lostcoin\":14,\"buytype\":1}', ''),
(4, '$installlang[u043]', '{\"pimg\":\"source\\/plugin\\/jnfarm\\/template\\/images\\/pet4.gif\",\"attack\":30,\"hungry\":150,\"hungrytime\":7,\"buyprice\":800,\"lostcoin\":16,\"buytype\":1}', ''),
(5, '$installlang[u044]', '{\"pimg\":\"source\\/plugin\\/jnfarm\\/template\\/images\\/pet5.gif\",\"attack\":35,\"hungry\":200,\"hungrytime\":7,\"buyprice\":2500,\"lostcoin\":18,\"buytype\":1}', ''),
(6, '$installlang[u045]', '{\"pimg\":\"source\\/plugin\\/jnfarm\\/template\\/images\\/pet6.gif\",\"attack\":40,\"hungry\":300,\"hungrytime\":7,\"buyprice\":10000,\"lostcoin\":18,\"buytype\":1}', '');";

DB::query($sql7,'SILENT');

DB::query("ALTER TABLE ".DB::table('game_jnfarm_user')." ADD `lastsituation` INT NOT NULL AFTER `createtime`;",'SILENT');
DB::query("ALTER TABLE ".DB::table('game_jnfarm_user')." ADD `dailyquest` TEXT NOT NULL AFTER `lastsituation`;",'SILENT');

$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_game_jnfarm_dailyquest` (
	`jdid` INT NOT NULL AUTO_INCREMENT,
	`jdtitle` TEXT NOT NULL,
	`jddata` TEXT NOT NULL,
	`jdother` TEXT NOT NULL,
	`minlvl` INT NOT NULL,
	PRIMARY KEY (`jdid`)
) ENGINE = MyISAM AUTO_INCREMENT=101;
EOF;
//ALTER TABLE  `pre_game_jnsango_tlog` ENGINE = INNODB;
runquery($sql);

$sql8 = "INSERT INTO ".DB::table('game_jnfarm_dailyquest')." (`jdid`, `jdtitle`, `jddata`, `jdother`, `minlvl`) VALUES
(1, '$installlang[u046]', '{\"jdesc\":\"$installlang[u052]\",\"type\":1,\"jimg\":\"source\\/plugin\\/jnfarm\\/template\\/images\\/water.svg\",\"gifttype\":4,\"gtype4\":1,\"giftqtymin\":5,\"giftqtymax\":10}', '', 1),
(2, '$installlang[u047]', '{\"jdesc\":\"$installlang[u053]\",\"type\":2,\"jimg\":\"\",\"rules\":5,\"rulesqty\":5,\"gifttype\":2,\"gtype2\":1,\"giftqtymin\":3,\"giftqtymax\":3}', '', 1),
(3, '$installlang[u048]', '{\"jdesc\":\"$installlang[u054]\",\"type\":2,\"jimg\":\"\",\"rules\":5,\"rulesqty\":10,\"gifttype\":2,\"gtype2\":5,\"giftqtymin\":1,\"giftqtymax\":3}', '', 2),
(4, '$installlang[u049]', '{\"jdesc\":\"$installlang[u055]\",\"type\":2,\"jimg\":\"\",\"rules\":1,\"rulesqty\":3,\"gifttype\":1,\"gtype1\":1,\"giftqtymin\":1,\"giftqtymax\":1}', '', 1),
(5, '$installlang[u050]', '{\"jdesc\":\"$installlang[u056]\",\"type\":2,\"jimg\":\"\",\"rules\":1,\"rulesqty\":10,\"gifttype\":1,\"gtype1\":1,\"giftqtymin\":1,\"giftqtymax\":1}', '', 3),
(6, '$installlang[u051]', '{\"jdesc\":\"$installlang[u057]\",\"type\":2,\"jimg\":\"\",\"rules\":3,\"rulesqty\":3,\"gifttype\":1,\"gtype1\":3,\"giftqtymin\":1,\"giftqtymax\":1}', '', 5);";
DB::query($sql8,'SILENT');

//realland
DB::query("ALTER TABLE ".DB::table('game_jnfarm_user')." ADD `realland` TEXT NOT NULL AFTER `dailyquest`;",'SILENT');

$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_game_jnfarm_realland` (
  `jrid` int(11) NOT NULL AUTO_INCREMENT,
  `jrtitle` text NOT NULL,
  `jrdata` text NOT NULL,
  `jrothers` int(11) NOT NULL,
  `canplant` int(11) NOT NULL,
  PRIMARY KEY (`jrid`),
  KEY `canplant` (`canplant`)
) ENGINE=MyISAM AUTO_INCREMENT=101;

CREATE TABLE IF NOT EXISTS pre_game_jnfarm_realland_record (
  jrrid int(11) NOT NULL AUTO_INCREMENT,
  uid int(11) NOT NULL,
  rinfo text NOT NULL,
  createtime int(11) NOT NULL,
  rstatus int(11) NOT NULL,
  PRIMARY KEY (jrrid),
  KEY uid (uid)
) ENGINE=MyISAM AUTO_INCREMENT=1;
EOF;
//ALTER TABLE  `pre_game_jnsango_tlog` ENGINE = INNODB;
runquery($sql);

$sql8 = "INSERT INTO ".DB::table('game_jnfarm_realland')." (`jrid`, `jrtitle`, `jrdata`, `jrothers`, `canplant`) VALUES
(1, '$installlang[u058]', '{\"small\":\"source\\/plugin\\/jnfarm\\/template\\/images\\/mango-icon.png\",\"jimg1\":\"source\\/plugin\\/jnfarm\\/template\\/images\\/youngTree.png\",\"jimg2\":\"source\\/plugin\\/jnfarm\\/template\\/images\\/mango-small.png\",\"jimg3\":\"source\\/plugin\\/jnfarm\\/template\\/images\\/mango-medium.png\",\"jimg4\":\"source\\/plugin\\/jnfarm\\/template\\/images\\/mango-big.png\",\"jword1\":\"$installlang[u062]\",\"jword2\":\"$installlang[u063]\",\"jword3\":\"$installlang[u064]\",\"jword4\":\"$installlang[u065]\",\"jrsd1\":3,\"jrfl1\":0,\"jrsd2\":3,\"jrfl2\":0,\"jrsd3\":3,\"jrfl3\":1,\"jrsd4\":3,\"jrfl4\":1,\"jdesc\":\"$installlang[u066]\",\"qty\":\"$installlang[u067]\"}', 0, 1),
(2, '$installlang[u059]', '{\"small\":\"source\\/plugin\\/jnfarm\\/template\\/images\\/apple-icon.png\",\"jimg1\":\"source\\/plugin\\/jnfarm\\/template\\/images\\/youngTree.png\",\"jimg2\":\"source\\/plugin\\/jnfarm\\/template\\/images\\/apple-small.png\",\"jimg3\":\"source\\/plugin\\/jnfarm\\/template\\/images\\/apple-medium.png\",\"jimg4\":\"source\\/plugin\\/jnfarm\\/template\\/images\\/apple-big.png\",\"jword1\":\"$installlang[u068]\",\"jword2\":\"$installlang[u069]\",\"jword3\":\"$installlang[u070]\",\"jword4\":\"$installlang[u071]\",\"jrsd1\":30,\"jrfl1\":1,\"jrsd2\":100,\"jrfl2\":2,\"jrsd3\":250,\"jrfl3\":3,\"jrsd4\":2000,\"jrfl4\":4,\"jdesc\":\"$installlang[u072]\",\"qty\":\"$installlang[u067]\"}', 0, 1),
(3, '$installlang[u060]', '{\"small\":\"source\\/plugin\\/jnfarm\\/template\\/images\\/orange-icon.png\",\"jimg1\":\"source\\/plugin\\/jnfarm\\/template\\/images\\/youngTree.png\",\"jimg2\":\"source\\/plugin\\/jnfarm\\/template\\/images\\/orange-small.png\",\"jimg3\":\"source\\/plugin\\/jnfarm\\/template\\/images\\/orange-medium.png\",\"jimg4\":\"source\\/plugin\\/jnfarm\\/template\\/images\\/orange-big.png\",\"jword1\":\"$installlang[u073]\",\"jword2\":\"$installlang[u074]\",\"jword3\":\"$installlang[u075]\",\"jword4\":\"$installlang[u076]\",\"jrsd1\":30,\"jrfl1\":1,\"jrsd2\":100,\"jrfl2\":2,\"jrsd3\":250,\"jrfl3\":3,\"jrsd4\":2000,\"jrfl4\":4,\"jdesc\":\"$installlang[u077]\",\"qty\":\"$installlang[u067]\"}', 0, 1),
(4, '$installlang[u061]', '{\"small\":\"source\\/plugin\\/jnfarm\\/template\\/images\\/dragonfruit-icon.png\",\"jimg1\":\"source\\/plugin\\/jnfarm\\/template\\/images\\/youngTree.png\",\"jimg2\":\"source\\/plugin\\/jnfarm\\/template\\/images\\/dragonfruit-small.png\",\"jimg3\":\"source\\/plugin\\/jnfarm\\/template\\/images\\/dragonfruit-medium.png\",\"jimg4\":\"source\\/plugin\\/jnfarm\\/template\\/images\\/dragonfruit-big.png\",\"jword1\":\"$installlang[u078]\",\"jword2\":\"$installlang[u079]\",\"jword3\":\"$installlang[u080]\",\"jword4\":\"$installlang[u081]\",\"jrsd1\":3,\"jrfl1\":1,\"jrsd2\":3,\"jrfl2\":2,\"jrsd3\":3,\"jrfl3\":3,\"jrsd4\":3,\"jrfl4\":4,\"jdesc\":\"$installlang[u082]\",\"qty\":\"$installlang[u067]\"}', 0, 1);";
DB::query($sql8,'SILENT');

DB::query("ALTER TABLE ".DB::table('game_jnfarm_dailyquest')." ADD `jdorder` INT NOT NULL AFTER `minlvl`;",'SILENT');
DB::query("ALTER TABLE ".DB::table('game_jnfarm_item')." ADD `jiorder` INT NOT NULL AFTER `createtime`;",'SILENT');
DB::query("ALTER TABLE ".DB::table('game_jnfarm_user')." ADD `dayquest` TEXT NOT NULL AFTER `realland`;",'SILENT');
DB::query("ALTER TABLE ".DB::table('game_jnfarm_user')." ADD `ref` INT NOT NULL AFTER `dayquest`, ADD INDEX (`ref`);",'SILENT');

$sql = <<<EOF

CREATE TABLE IF NOT EXISTS pre_game_jnfarm_invite (
  `jiid` INT NOT NULL AUTO_INCREMENT ,
  `uid` INT NOT NULL ,
  `invitecode` TEXT NOT NULL ,
  PRIMARY KEY (`jiid`),
  KEY (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

EOF;
//ALTER TABLE  `pre_game_jnsango_tlog` ENGINE = INNODB;
runquery($sql);

//20200706
$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_game_jnfarm_season_set` (
  `jsid` int(11) NOT NULL AUTO_INCREMENT,
  `jstart` int(11) NOT NULL,
  `jend` int(11) NOT NULL,
  `jdata` text NOT NULL,
  `jstatus` int(11) NOT NULL,
  `mdpass` text NOT NULL,
  `seasondesc` text NOT NULL,
  PRIMARY KEY (`jsid`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_game_jnfarm_season` (
  `jdid` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `jsid` int(11) NOT NULL,
  `prize` int(11) NOT NULL,
  `getprize` int(11) NOT NULL,
  `createtime` int(11) NOT NULL,
  PRIMARY KEY (`jdid`),
  KEY `uid` (`uid`),
  KEY `qty` (`qty`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

EOF;
//ALTER TABLE  `pre_game_jnsango_tlog` ENGINE = INNODB;
runquery($sql);

DB::query("ALTER TABLE ".DB::table('game_jnfarm_fset')." ADD `cword` TEXT NOT NULL AFTER `setdata`",'SILENT');
DB::query("ALTER TABLE ".DB::table('game_jnfarm_fset')." ADD `reallandword` TEXT NOT NULL AFTER `cword`",'SILENT');

$version = DB::fetch_first("SELECT version FROM ".DB::table('common_plugin')." WHERE identifier = 'jnwulin'");

//2.7
DB::query("ALTER TABLE ".DB::table('game_jnfarm_user')." ADD `username` TEXT NOT NULL AFTER `ref`",'SILENT');
if($version['version'] < '2.7'){
	$gameuid = DB::fetch_all("SELECT uid FROM ".DB::table('game_jnfarm_user')." ");
	foreach($gameuid as $gu){
		$upname = DB::fetch_first("SELECT username FROM ".DB::table('common_member')." WHERE uid = '".$gu['uid']."'");
		DB::query("UPDATE ".DB::table('game_jnfarm_user')." SET username = '".$upname['username']."' WHERE uid = '".$gu['uid']."' ",'SILENT');
	}
}

//v2.71
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_game_jnfarm_rankcache` (
  `jrid` int(11) NOT NULL AUTO_INCREMENT,
  `username` text NOT NULL,
  `type` text NOT NULL,
  `createtime` int(11) NOT NULL,
  `orderby` int(11) NOT NULL,
  `numqty` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `updatetime` int(11) NOT NULL,
  PRIMARY KEY (`jrid`)
) ENGINE=MyISAM AUTO_INCREMENT=1;
EOF;
runquery($sql);

//v2.8
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_game_jnfarm_mall` ( 
	`jmid` INT NOT NULL AUTO_INCREMENT ,
	`jmtitle` TEXT NOT NULL ,
	`jmdata` TEXT NOT NULL , 
	`jmext` INT NOT NULL , 
	`jmprice` INT NOT NULL , 
	`dailylimit` INT NOT NULL , 
	`onlyonce` INT NOT NULL ,
	`orderby` INT NOT NULL,
	`onceuid` TEXT NOT NULL,
	`dailyuid` TEXT NOT NULL,
	PRIMARY KEY (`jmid`)
) ENGINE = MyISAM AUTO_INCREMENT=1;
EOF;
runquery($sql);

//v2.9
DB::query("ALTER TABLE ".DB::table('game_jnfarm_user')." ADD `vipexpired` INT NOT NULL AFTER `username`;",'SILENT');

//v3.1
DB::query("ALTER TABLE ".DB::table('game_jnfarm_user')." ADD `uposition` INT NOT NULL AFTER `vipexpired`, ADD `uguildgx` INT NOT NULL AFTER `uposition`, ADD `uindigx` INT NOT NULL AFTER `uguildgx`, ADD `jgid` INT NOT NULL AFTER `uindigx`, ADD `quittime` INT NOT NULL AFTER `jgid`, ADD `jgcs` INT NOT NULL AFTER `quittime`, ADD `weekindigx` INT NOT NULL AFTER `jgcs`, ADD `weekguildgx` INT NOT NULL AFTER `weekindigx`, ADD `todayjscs` INT NOT NULL AFTER `weekguildgx`, ADD `lastjs` INT NOT NULL AFTER `todayjscs`",'SILENT');

$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_game_jnfarm_guild` (
  `jgid` int(11) NOT NULL AUTO_INCREMENT,
  `jgtitle` text NOT NULL,
  `owner` int(11) NOT NULL,
  `createtime` int(11) NOT NULL,
  `gongxian` int(11) NOT NULL,
  `jglvl` int(11) NOT NULL,
  `jgiid` int(11) NOT NULL,
  `jsqtynow` int(11) NOT NULL,
  `jsqtymax` int(11) NOT NULL,
  PRIMARY KEY (`jgid`),
  KEY `owner` (`owner`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_game_jnfarm_guild_gxreward` (
  `jgrid` int(11) NOT NULL AUTO_INCREMENT,
  `jgprice` text NOT NULL,
  `jgmingcimin` int(11) NOT NULL,
  `jgmingcimax` int(11) NOT NULL,
  `jgjoin` text NOT NULL,
  PRIMARY KEY (`jgrid`)
) ENGINE=MyISAM AUTO_INCREMENT=5;

CREATE TABLE IF NOT EXISTS `pre_game_jnfarm_guild_item` (
  `jgiid` int(11) NOT NULL AUTO_INCREMENT,
  `jgititle` text NOT NULL,
  `jgiimg` text NOT NULL,
  `jgicost` text NOT NULL,
  `jgidesc` text NOT NULL,
  `jsicost` text NOT NULL,
  `totaljs` int(11) NOT NULL,
  `jireward` text NOT NULL,
  `btnword` text NOT NULL,
  `indigx` int(11) NOT NULL,
  `guildgx` int(11) NOT NULL,
  `jimemberreward` text NOT NULL,
  `jsjg` int(11) NOT NULL,
  `daijs` int(11) NOT NULL,
  `dailylimit` int(11) NOT NULL,
  `timelimit` int(11) NOT NULL,
  PRIMARY KEY (`jgiid`)
) ENGINE=MyISAM AUTO_INCREMENT=3;

CREATE TABLE IF NOT EXISTS `pre_game_jnfarm_guild_level` (
  `jlid` int(11) NOT NULL AUTO_INCREMENT,
  `lvl` int(11) NOT NULL,
  `expneed` int(11) NOT NULL,
  `createtime` int(11) NOT NULL,
  PRIMARY KEY (`jlid`),
  KEY `lvl` (`lvl`)
) ENGINE=MyISAM AUTO_INCREMENT=11;

CREATE TABLE IF NOT EXISTS `pre_game_jnfarm_guild_reward` (
  `jgrid` int(11) NOT NULL AUTO_INCREMENT,
  `jgmc` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `fordate` int(11) NOT NULL,
  `taken` int(11) NOT NULL,
  PRIMARY KEY (`jgrid`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_game_jnfarm_dateline` (
  `jdid` int(11) NOT NULL AUTO_INCREMENT,
  `fordate` int(11) NOT NULL,
  `timetype` int(11) NOT NULL,
  PRIMARY KEY (`jdid`)
) ENGINE=MyISAM AUTO_INCREMENT=1;
EOF;
runquery($sql);

DB::query("ALTER TABLE ".DB::table('game_jnfarm_fset')." ADD `guildset` TEXT NOT NULL AFTER `reallandword`;",'SILENT');

$sysinfo = DB::fetch_first("SELECT setdata FROM ".DB::table('game_jnfarm_fset')." WHERE jfset = '1'");
$sysinfo['setdata'] = json_decode($sysinfo['setdata'],true);
$sysinfo['setdata']['version'] = dintval($sysinfo['setdata']['version']);
if($sysinfo['setdata']['version'] < 1){
	$sql9 = "INSERT INTO ".DB::table('game_jnfarm_guild_item')." (`jgiid`, `jgititle`, `jgiimg`, `jgicost`, `jgidesc`, `jsicost`, `totaljs`, `jireward`, `btnword`, `indigx`, `guildgx`, `jimemberreward`, `jsjg`, `daijs`, `dailylimit`, `timelimit`) VALUES
	(1, '$installlang[u085]', 'source/plugin/jnfarm/template/images/guild_01.svg', '{\"item\":{\"1\":100,\"2\":100}}', '', '{\"item\":{\"1\":1}}', 1000, '[\"100\",\"80\",\"60\",\"40\",\"20\",\"5\"]', '$installlang[u086]', 1, 1, '{\"item\":{\"3\":1}}', 0, 0, 5, 60),
	(2, '$installlang[u087]', 'source/plugin/jnfarm/template/images/guild_02.gif', '{\"item\":{\"5\":100,\"6\":200}}', '', '{\"item\":{\"5\":1}}', 3000, '[\"200\",\"150\",\"100\",\"50\",\"30\",\"10\"]', '$installlang[u088]', 2, 2, '{\"item\":{\"4\":1}}', 0, 0, 5, 180);";
	DB::query($sql9,'SILENT');

	$sql9 = "INSERT INTO ".DB::table('game_jnfarm_guild_gxreward')." (`jgrid`, `jgprice`, `jgmingcimin`, `jgmingcimax`, `jgjoin`) VALUES
	(1, '{\"item\":{\"1\":10,\"3\":20,\"4\":50}}', 1, 1, '{\"canyucishu\":100,\"item\":{\"3\":3}}'),
	(2, '{\"item\":{\"1\":10,\"3\":20,\"4\":30}}', 2, 2, '{\"canyucishu\":100,\"item\":{\"3\":3}}'),
	(3, '{\"item\":{\"1\":10,\"3\":20,\"4\":10}}', 3, 3, '{\"canyucishu\":100,\"item\":{\"3\":3}}'),
	(4, '{\"item\":{\"1\":10,\"3\":10}}', 4, 10, '{\"canyucishu\":100,\"item\":{\"3\":3}}');";
	DB::query($sql9,'SILENT');

	$sql9 = "INSERT INTO ".DB::table('game_jnfarm_guild_level')." (`jlid`, `lvl`, `expneed`, `createtime`) VALUES
	(1, 1, 20000, 0),
	(2, 2, 60000, 1575644144),
	(3, 3, 180000, 1575644144),
	(4, 4, 540000, 1575644144),
	(5, 5, 1620000, 1575644144),
	(6, 6, 4860000, 1575644144),
	(7, 7, 14580000, 1575644144),
	(8, 8, 43740000, 1575644144),
	(9, 9, 131220000, 1575644144),
	(10, 10, 393660000, 1575644144);";
	DB::query($sql9,'SILENT');

	DB::query("UPDATE ".DB::table('game_jnfarm_fset')." SET guildset = '".$installlang['u089']."'");
	DB::query("ALTER TABLE ".DB::table('game_jnfarm_guild_item')." AUTO_INCREMENT = 1001");
	$sysinfo['setdata']['version'] = 1;
}

//v3.14
DB::query("ALTER TABLE ".DB::table('game_jnfarm_guild')." ADD `weekgx` INT NOT NULL AFTER `jsqtymax`;",'SILENT');
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_game_jnfarm_guild_hzgxreward` (
  `jgrid` int(11) NOT NULL AUTO_INCREMENT,
  `jgprice` text NOT NULL,
  `jgmingcimin` int(11) NOT NULL,
  `jgmingcimax` int(11) NOT NULL,
  `jgjoin` text NOT NULL,
  PRIMARY KEY (`jgrid`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_game_jnfarm_guild_hzreward` (
  `jgrid` int(11) NOT NULL AUTO_INCREMENT,
  `jgmc` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `fordate` int(11) NOT NULL,
  `taken` int(11) NOT NULL,
  PRIMARY KEY (`jgrid`)
) ENGINE=MyISAM;
EOF;
runquery($sql);

if($sysinfo['setdata']['version'] < 2){
	
	$sql9 = "INSERT INTO ".DB::table('game_jnfarm_guild_hzgxreward')." (`jgrid`, `jgprice`, `jgmingcimin`, `jgmingcimax`, `jgjoin`) VALUES
(1, '{\"item\":{\"1\":10,\"3\":20,\"4\":50}}', 1, 1, '{\"canyucishu\":100,\"item\":{\"3\":3}}'),
(2, '{\"item\":{\"1\":10,\"3\":20,\"4\":30}}', 2, 2, '{\"canyucishu\":100,\"item\":{\"3\":3}}'),
(3, '{\"item\":{\"1\":10,\"3\":20,\"4\":10}}', 3, 3, '{\"canyucishu\":100,\"item\":{\"3\":3}}'),
(4, '{\"item\":{\"1\":10,\"3\":10}}', 4, 10, '{\"canyucishu\":100,\"item\":{\"3\":3}}');";
	DB::query($sql9,'SILENT');
	
	$sysinfo['setdata']['version'] = 2;
}

//v3.15
DB::query("ALTER TABLE ".DB::table('game_jnfarm_guild')." ADD `lastjs` INT NOT NULL AFTER `weekgx`",'SILENT');

//v3.2
DB::query("ALTER TABLE  ".DB::table('game_jnfarm_user')." ADD `kpck` INT NOT NULL AFTER `lastjs`, ADD `spck` INT NOT NULL AFTER `kpck`;",'SILENT');
DB::query("ALTER TABLE  ".DB::table('game_jnfarm_user')." ADD `freedraw` INT NOT NULL AFTER `spck`;",'SILENT');
DB::query("ALTER TABLE  ".DB::table('game_jnfarm_guild_item')." ADD `freedraw` TEXT NOT NULL AFTER `timelimit`;",'SILENT');

$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_game_jnfarm_card` (
  `jcid` int(11) NOT NULL AUTO_INCREMENT,
  `ctitle` text NOT NULL,
  `cdata` text NOT NULL,
  `type` text NOT NULL,
  `createtime` int(11) NOT NULL,
  `ciorder` int(11) NOT NULL,
  `jifen` int(11) NOT NULL,
  PRIMARY KEY (`jcid`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_game_jnfarm_card_hzreward` (
  `jgrid` int(11) NOT NULL AUTO_INCREMENT,
  `jgmc` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `fordate` int(11) NOT NULL,
  `taken` int(11) NOT NULL,
  PRIMARY KEY (`jgrid`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_game_jnfarm_card_hzzlreward` (
  `jgrid` int(11) NOT NULL AUTO_INCREMENT,
  `jgprice` text NOT NULL,
  `jgmingcimin` int(11) NOT NULL,
  `jgmingcimax` int(11) NOT NULL,
  `jgjoin` text NOT NULL,
  PRIMARY KEY (`jgrid`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_game_jnfarm_card_reward` (
  `jgrid` int(11) NOT NULL AUTO_INCREMENT,
  `jgmc` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `fordate` int(11) NOT NULL,
  `taken` int(11) NOT NULL,
  PRIMARY KEY (`jgrid`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_game_jnfarm_card_user` (
  `jcuid` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `jcid` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `type` text NOT NULL,
  `lvl` int(11) NOT NULL,
  `basiczhanli` int(11) NOT NULL,
  PRIMARY KEY (`jcuid`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_game_jnfarm_card_zlreward` (
  `jgrid` int(11) NOT NULL AUTO_INCREMENT,
  `jgprice` text NOT NULL,
  `jgmingcimin` int(11) NOT NULL,
  `jgmingcimax` int(11) NOT NULL,
  `jgjoin` text NOT NULL,
  PRIMARY KEY (`jgrid`)
) ENGINE=MyISAM;

EOF;
runquery($sql);

if($sysinfo['setdata']['version'] < 3){
	
	$sql9 = "INSERT INTO `pre_game_jnfarm_card` (`jcid`, `ctitle`, `cdata`, `type`, `createtime`, `ciorder`, `jifen`) VALUES
(1, '$installlang[u090]', '{\"imgurl\":\"source\\/plugin\\/jnfarm\\/template\\/images\\/card_04.png\",\"success\":0,\"zhanli\":0,\"basiczhanli\":[\"\",\"\"],\"maxlvl\":0,\"lvltype\":\"\",\"refundindigx\":0,\"refundguildgx\":0,\"prodmarket\":1,\"prodmprice0\":100,\"prodmprice1\":150}', 'suipian', 0, 1, 0),
(2, '$installlang[u091]', '{\"imgurl\":\"source\\/plugin\\/jnfarm\\/template\\/images\\/card_01.png\",\"spcombine\":[3,100],\"success\":80,\"zhanli\":10,\"lvltype\":\"S\",\"refundindigx\":5,\"refundguildgx\":10,\"maxlvl\":100,\"prodmarket\":1,\"prodmprice0\":10000,\"prodmprice1\":12000,\"kpcombine\":{\"ext\":{\"99\":10000},\"item\":{\"1\":1000}},\"kpuplvl\":{\"ext\":{\"99\":1000}},\"basiczhanli\":[30,\"40\"]}', 'card', 0, 2, 0),
(3, '$installlang[u092]', '{\"imgurl\":\"source\\/plugin\\/jnfarm\\/template\\/images\\/card_01.png\",\"success\":0,\"zhanli\":0,\"basiczhanli\":[\"\",\"\"],\"maxlvl\":0,\"lvltype\":\"\",\"refundindigx\":0,\"refundguildgx\":0,\"prodmarket\":1,\"prodmprice0\":100,\"prodmprice1\":150}', 'suipian', 0, 3, 0),
(4, '$installlang[u093]', '{\"imgurl\":\"source\\/plugin\\/jnfarm\\/template\\/images\\/card_02.png\",\"success\":90,\"zhanli\":10,\"maxlvl\":100,\"lvltype\":\"SS\",\"refundindigx\":10,\"refundguildgx\":20,\"prodmarket\":1,\"prodmprice0\":20000,\"prodmprice1\":25000,\"spcombine\":[5,100],\"kpcombine\":{\"item\":{\"1\":100,\"2\":200,\"5\":300},\"ext\":{\"99\":20000}},\"kpuplvl\":{\"ext\":{\"99\":100}},\"basiczhanli\":[100,\"200\"]}', 'card', 0, 4, 0),
(5, '$installlang[u094]', '{\"imgurl\":\"source\\/plugin\\/jnfarm\\/template\\/images\\/card_02.png\",\"spcombine\":[1,1],\"success\":0,\"zhanli\":0,\"lvltype\":\"\",\"refundindigx\":0,\"refundguildgx\":0,\"kpcombine\":{\"ext\":{\"1\":66,\"2\":99,\"3\":111}},\"basiczhanli\":[\"\",\"\"],\"maxlvl\":0,\"prodmarket\":1,\"prodmprice0\":100,\"prodmprice1\":150}', 'suipian', 0, 5, 0),
(6, '$installlang[u095]', '{\"imgurl\":\"source\\/plugin\\/jnfarm\\/template\\/images\\/card_03.png\",\"success\":80,\"zhanli\":15,\"maxlvl\":100,\"lvltype\":\"SS\",\"refundindigx\":10,\"refundguildgx\":20,\"prodmarket\":1,\"prodmprice0\":30000,\"prodmprice1\":35000,\"spcombine\":[7,100],\"kpcombine\":{\"ext\":{\"99\":30000},\"item\":{\"1\":3000}},\"kpuplvl\":{\"ext\":{\"99\":1200}},\"basiczhanli\":[400,\"500\"]}', 'card', 0, 6, 0),
(7, '$installlang[u096]', '{\"imgurl\":\"source\\/plugin\\/jnfarm\\/template\\/images\\/card_03.png\",\"prodmarket\":1,\"prodmprice0\":100,\"prodmprice1\":150,\"success\":0,\"zhanli\":0,\"basiczhanli\":[\"\",\"\"],\"maxlvl\":0,\"lvltype\":\"\",\"refundindigx\":0,\"refundguildgx\":0}', 'suipian', 0, 7, 0);";
	DB::query($sql9,'SILENT');
	
	$sql9 = "INSERT INTO `pre_game_jnfarm_card_hzzlreward` (`jgrid`, `jgprice`, `jgmingcimin`, `jgmingcimax`, `jgjoin`) VALUES
(1, '{\"item\":{\"1\":10,\"3\":20,\"4\":50}}', 1, 1, '{\"canyucishu\":100,\"item\":{\"3\":3}}'),
(2, '{\"item\":{\"1\":10,\"3\":20,\"4\":30}}', 2, 2, '{\"canyucishu\":100,\"item\":{\"3\":3}}'),
(3, '{\"item\":{\"1\":10,\"3\":20,\"4\":10}}', 3, 3, '{\"canyucishu\":100,\"item\":{\"3\":3}}'),
(4, '{\"item\":{\"1\":10,\"3\":10}}', 4, 10, '{\"canyucishu\":100,\"item\":{\"3\":3}}');";
	DB::query($sql9,'SILENT');
	
	$sql9 = "INSERT INTO `pre_game_jnfarm_card_zlreward` (`jgrid`, `jgprice`, `jgmingcimin`, `jgmingcimax`, `jgjoin`) VALUES
(1, '{\"item\":{\"1\":10,\"3\":20,\"4\":50}}', 1, 1, '{\"canyucishu\":100,\"item\":{\"3\":3}}'),
(2, '{\"item\":{\"1\":10,\"3\":20,\"4\":30}}', 2, 2, '{\"canyucishu\":100,\"item\":{\"3\":3}}'),
(3, '{\"item\":{\"1\":10,\"3\":20,\"4\":10}}', 3, 3, '{\"canyucishu\":100,\"item\":{\"3\":3}}'),
(4, '{\"item\":{\"1\":10,\"3\":10}}', 4, 10, '{\"canyucishu\":100,\"item\":{\"3\":3}}');";
	DB::query($sql9,'SILENT');
	
	$sysinfo['setdata']['version'] = 3;
}

//v3.8
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_game_jnfarm_card_cat` (
  `jccid` int(11) NOT NULL AUTO_INCREMENT,
  `jctitle` text NOT NULL,
  `jcorder` int(11) NOT NULL,
  `createtime` int(11) NOT NULL,
  PRIMARY KEY (`jccid`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_game_jnfarm_card_draw` (
  `jdid` int(11) NOT NULL AUTO_INCREMENT,
  `jdtitle` text NOT NULL,
  `jccid` int(11) NOT NULL,
  `jdata` text NOT NULL,
  `jdorder` int(11) NOT NULL,
  `imgurl` text NOT NULL,
  PRIMARY KEY (`jdid`)
) ENGINE=MyISAM;

EOF;
runquery($sql);

DB::query("ALTER TABLE ".DB::table('game_jnfarm_card')." ADD `jccid` INT NOT NULL AFTER `jifen`;",'SILENT');
DB::query("ALTER TABLE  ".DB::table('game_jnfarm_card_user')." ADD `nowhp` INT NOT NULL AFTER `basiczhanli`, ADD `maxhp` INT NOT NULL AFTER `nowhp`;",'SILENT');
if($sysinfo['setdata']['version'] < 4){
	$sql9 = "INSERT INTO ".DB::table('game_jnfarm_card_cat')." (`jccid`, `jctitle`, `jcorder`, `createtime`) VALUES
	(1, '$installlang[u097]', 1, 1624595865)";
	DB::query($sql9,'SILENT');
	
	DB::query("UPDATE ".DB::table('game_jnfarm_card')." SET jccid = 1");	
	DB::query("ALTER TABLE ".DB::table('game_jnfarm_card_cat')." AUTO_INCREMENT=101");

	//增加一个, 加血的
	$sysinfo['setdata']['card']['hp'] = 100;
	DB::query("UPDATE ".DB::table('game_jnfarm_card_user')." SET maxhp = lvl * '".$sysinfo['setdata']['card']['hp']."' WHERE type = 'card'");
	
	$sql9 = "INSERT INTO ".DB::table('game_jnfarm_card_draw')." (`jdid`, `jdtitle`, `jccid`, `jdata`, `jdorder`, `imgurl`) VALUES
(1, '$installlang[u098]', 0, '{\"kpdrawqty\":100,\"kpdraw\":99,\"drawtime\":1,\"drawtype\":1}', 1, ''),
(2, '$installlang[u099]', 0, '{\"kpdrawqty\":1000,\"kpdraw\":99,\"drawtime\":\"1,9\",\"drawtype\":2,\"freedraw\":1}', 2, '');";
	DB::query($sql9,'SILENT');
	
	DB::query("ALTER TABLE ".DB::table('game_jnfarm_card_draw')." AUTO_INCREMENT=101;");
	
	$sysinfo['setdata']['version'] = 4;
}

//v2.81
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_game_jnfarm_card_suit` (
  `jsid` int(11) NOT NULL AUTO_INCREMENT,
  `jstitle` text NOT NULL,
  `jsrules` text NOT NULL,
  `createtime` int(11) NOT NULL,
  `fprize` text NOT NULL,
  `fuid` int(11) NOT NULL,
  `ftime` int(11) NOT NULL,
  `maxppl` int(11) NOT NULL,
  `getppl` int(11) NOT NULL,
  PRIMARY KEY (`jsid`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_game_jnfarm_card_suitlog` (
  `jslid` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `createtime` int(11) NOT NULL,
  `jsid` int(11) NOT NULL,
  PRIMARY KEY (`jslid`)
) ENGINE=MyISAM;

EOF;
runquery($sql);

if($sysinfo['setdata']['version'] < 5){
	$sql9 = "INSERT INTO ".DB::table('game_jnfarm_card_suit')." (`jsid`, `jstitle`, `jsrules`, `createtime`, `fprize`, `fuid`, `ftime`, `maxppl`, `getppl`) VALUES
(1, '$installlang[u100]', '{\"suit\":{\"6\":1,\"4\":1,\"2\":1},\"reward\":{\"item\":{\"1\":100},\"ext\":{\"99\":100}}}', 1624416098, '{\"reward\":{\"item\":{\"1\":100,\"3\":100,\"4\":50},\"card\":{\"1\":10,\"2\":2}}}', 0, 0, 100, 0),
(2, '$installlang[u101]', '{\"suit\":{\"2\":5,\"4\":5,\"6\":5},\"reward\":{\"item\":{\"3\":20,\"4\":10}}}', 1624459051, '{\"reward\":{\"item\":{\"2\":100,\"3\":200,\"4\":100}}}', 0, 0, 100, 0),
(3, '$installlang[u102]', '{\"suit\":{\"2\":100,\"4\":100,\"6\":100},\"reward\":{\"item\":{\"4\":50}}}', 1624459117, '{\"reward\":{\"item\":{\"4\":1000}}}', 0, 0, 50, 0);";
	DB::query($sql9,'SILENT');
	
	DB::query("ALTER TABLE ".DB::table('game_jnfarm_card_suit')." AUTO_INCREMENT=101;");
	
	$sysinfo['setdata']['version'] = 5;
}

DB::query("ALTER TABLE ".DB::table('game_jnfarm_user')." ADD `freekpdraw` INT NOT NULL AFTER `freedraw`;",'SILENT');

//v3.3
DB::query("ALTER TABLE ".DB::table('game_jnfarm_card_user')." ADD `abletopk` INT NOT NULL AFTER `maxhp`, ADD `inadv` INT NOT NULL AFTER `abletopk`;",'SILENT');
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_game_jnfarm_card_adv` (
  `jcaid` int(11) NOT NULL AUTO_INCREMENT,
  `jctitle` text NOT NULL,
  `jcdesc` text NOT NULL,
  `jcdata` text NOT NULL,
  `jcorder` int(11) NOT NULL,
  PRIMARY KEY (`jcaid`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_game_jnfarm_card_advlist` (
  `jclid` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `createtime` int(11) NOT NULL,
  `finishtime` int(11) NOT NULL,
  `jcaid` int(11) NOT NULL,
  `jcuid` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `jcid` int(11) NOT NULL,
  `lvl` int(11) NOT NULL,
  PRIMARY KEY (`jclid`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM;

EOF;
runquery($sql);

if($sysinfo['setdata']['version'] < 6){
	$sql9 = "INSERT INTO ".DB::table('game_jnfarm_card_adv')." (`jcaid`, `jctitle`, `jcdesc`, `jcdata`, `jcorder`) VALUES
(1, '$installlang[u103]', '$installlang[u103]', '{\"maxppl\":10,\"maxpp\":3,\"times\":1,\"pkjilv\":50,\"pklvl\":100,\"loselvl\":1,\"pkwinup\":50,\"pkfairup\":0,\"reward\":{\"item\":{\"1\":[\"5\",\"10\",100]}},\"cost\":{\"item\":{\"1\":10}},\"lvlin\":[\"10\",\"15\"]}', 1);";
	DB::query($sql9,'SILENT');
	DB::query("ALTER TABLE ".DB::table('game_jnfarm_card_adv')." AUTO_INCREMENT=101;");
	$sysinfo['setdata']['version'] = 6;
};

//v3.31
DB::query("ALTER TABLE ".DB::table('game_jnfarm_user')." ADD `advplace` INT NOT NULL AFTER `freekpdraw`;",'SILENT');
if($sysinfo['setdata']['version'] < 7){
	$sysinfo['setdata']['card']['freeplace'] = 1;
	$sysinfo['setdata']['card']['placecosttype'] = 3;
	$sysinfo['setdata']['card']['placecostid'] = 1;
	$sysinfo['setdata']['card']['placecostqty'] = 1;
	$sysinfo['setdata']['version'] = 7;
};

//v3.5
DB::query("ALTER TABLE ".DB::table('game_jnfarm_user')." ADD `pktime` INT NOT NULL AFTER `advplace`;",'SILENT');

//v3.52
DB::query("ALTER TABLE ".DB::table('game_jnfarm_user')." ADD `pkpoint` INT NOT NULL AFTER `pktime`, ADD `pkfreeze` INT NOT NULL AFTER `pkpoint`;",'SILENT');
DB::query("ALTER TABLE ".DB::table('game_jnfarm_user')." ADD `pklast` INT NOT NULL AFTER `pkfreeze`;",'SILENT');

$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_game_jnfarm_card_pkreward_sat` (
  `jgrid` int(11) NOT NULL AUTO_INCREMENT,
  `jgprice` text NOT NULL,
  `jgmingcimin` int(11) NOT NULL,
  `jgmingcimax` int(11) NOT NULL,
  `jgjoin` text NOT NULL,
  PRIMARY KEY (`jgrid`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_game_jnfarm_card_pkreward_sat_user` (
  `jgrid` int(11) NOT NULL AUTO_INCREMENT,
  `jgmc` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `fordate` int(11) NOT NULL,
  `taken` int(11) NOT NULL,
  PRIMARY KEY (`jgrid`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_game_jnfarm_card_pkreward_tue` (
  `jgrid` int(11) NOT NULL AUTO_INCREMENT,
  `jgprice` text NOT NULL,
  `jgmingcimin` int(11) NOT NULL,
  `jgmingcimax` int(11) NOT NULL,
  `jgjoin` text NOT NULL,
  PRIMARY KEY (`jgrid`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_game_jnfarm_card_pkreward_tue_user` (
  `jgrid` int(11) NOT NULL AUTO_INCREMENT,
  `jgmc` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `fordate` int(11) NOT NULL,
  `taken` int(11) NOT NULL,
  PRIMARY KEY (`jgrid`)
) ENGINE=MyISAM;
EOF;
runquery($sql);

if($sysinfo['setdata']['version'] < 8){
	$sql9 = "INSERT INTO ".DB::table('game_jnfarm_card_pkreward_sat')." (`jgrid`, `jgprice`, `jgmingcimin`, `jgmingcimax`, `jgjoin`) VALUES
(1, '{\"item\":{\"3\":20}}', 3, 5, '{\"item\":{\"1\":10,\"3\":3}}'),
(2, '{\"item\":{\"1\":100,\"2\":50,\"3\":50}}', 1, 1, '{\"item\":{\"1\":10,\"3\":3}}'),
(3, '{\"item\":{\"1\":80,\"2\":30,\"3\":30}}', 2, 2, '{\"item\":{\"1\":10,\"3\":3}}');";
	DB::query($sql9,'SILENT');
	
	$sql9 = "INSERT INTO ".DB::table('game_jnfarm_card_pkreward_tue')." (`jgrid`, `jgprice`, `jgmingcimin`, `jgmingcimax`, `jgjoin`) VALUES
(1, '{\"item\":{\"3\":20}}', 3, 5, '{\"item\":{\"1\":10,\"3\":3}}'),
(2, '{\"item\":{\"1\":100,\"2\":50,\"3\":50}}', 1, 1, '{\"item\":{\"1\":10,\"3\":3}}'),
(3, '{\"item\":{\"1\":80,\"2\":30,\"3\":30}}', 2, 2, '{\"item\":{\"1\":10,\"3\":3}}');";
	DB::query($sql9,'SILENT');
	$sysinfo['setdata']['version'] = 8;
};

//v3.374
DB::query("DELETE FROM ".DB::table('game_jnfarm_card_user')." WHERE jcid = 0 AND type = 'suipian'");

//v3.375
DB::query("ALTER TABLE ".DB::table('game_jnfarm_user')." ADD `todaypkid` TEXT NOT NULL AFTER `pklast`;",'SILENT');

if($sysinfo['setdata']['version'] < 9){
	//,"losespqty":"1,1","noloselvl":1,"pkwinuplvl":1,"winchange":10}}
	$sysinfo['setdata']['pk']['losespqty'] = '1,1';
	$sysinfo['setdata']['pk']['noloselvl'] = 1;
	$sysinfo['setdata']['pk']['pkwinuplvl'] = 0;
	$sysinfo['setdata']['pk']['winchange'] = 0;
	$sysinfo['setdata']['version'] = 9;
};

$sdata = json_encode($sysinfo['setdata']);
DB::query("UPDATE ".DB::table('game_jnfarm_fset')." SET setdata = '".$sdata."' WHERE jfset = '1'");
$finish = true;
?>