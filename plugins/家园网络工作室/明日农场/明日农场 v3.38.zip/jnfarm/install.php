<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF

CREATE TABLE `pre_game_jnfarm_fset` (
  `jfset` int(11) NOT NULL AUTO_INCREMENT,
  `setdata` text NOT NULL,
  `cword` text NOT NULL,
  `reallandword` text NOT NULL,
  `guildset` text NOT NULL,
  PRIMARY KEY (`jfset`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

INSERT INTO `pre_game_jnfarm_fset` (`jfset`, `setdata`, `cword`, `reallandword`, `guildset`) VALUES
(1, '{"version":2,"hongtu":10,"hongtucost":10000,"situationtime":30,"situation":50,"savetime":40,"qtydd":1,"freeland":3,"wormcost":20,"weedcost":30,"watercost":40,"expandset":{"1":{"lvl":1,"cost":100},"2":{"lvl":1,"cost":1000},"3":{"lvl":1,"cost":2000},"4":{"lvl":2,"cost":4000},"5":{"lvl":3,"cost":6000},"6":{"lvl":4,"cost":8000},"7":{"lvl":5,"cost":10000},"8":{"lvl":7,"cost":20000},"9":{"lvl":9,"cost":30000},"10":{"lvl":11,"cost":50000},"11":{"lvl":13,"cost":70000},"12":{"lvl":15,"cost":90000},"13":{"lvl":17,"cost":120000},"14":{"lvl":19,"cost":150000},"15":{"lvl":21,"cost":180000},"16":{"lvl":23,"cost":230000},"17":{"lvl":25,"cost":300000},"18":{"lvl":27,"cost":300000},"19":{"lvl":29,"cost":850000},"20":{"lvl":31,"cost":1100000},"21":{"lvl":33,"cost":1300000},"22":{"lvl":35,"cost":1500000},"23":{"lvl":37,"cost":1700000},"24":{"lvl":39,"cost":2000000}},"tili":"1","newtili":20,"leveltili":1,"tilihuifu":600,"ranklimit":10,"thiefqty":[1,3],"thiefqtymin":50}','$installlang[u083]','$installlang[u084]','$installlang[u089]');

CREATE TABLE `pre_game_jnfarm_item` (
  `jsid` int(11) NOT NULL AUTO_INCREMENT,
  `stitle` text NOT NULL,
  `sdata` text NOT NULL,
  `type` text NOT NULL,
  `createtime` int(11) NOT NULL,
  `jiorder` INT NOT NULL,
  PRIMARY KEY (`jsid`)
) ENGINE=MyISAM AUTO_INCREMENT=101;

INSERT INTO `pre_game_jnfarm_item` (`jsid`, `stitle`, `sdata`, `type`, `createtime`, `jiorder`) VALUES
(1, '$installlang[u001]', '{\"cost\":168,\"sale\":21,\"ctime\":600,\"expiredtime\":600,\"imgurl\":\"crop_1.svg\",\"seedurl\":\"crop_1_seed.svg\",\"hqty\":[17,19],\"exp\":1,\"cropsale\":80,\"buyable\":1,\"minlvl\":1,\"timesave\":0}', 'seed', 1577580863, 1),
(2, '$installlang[u002]', '{\"cost\":163,\"sale\":21,\"ctime\":300,\"expiredtime\":300,\"imgurl\":\"crop_2.svg\",\"seedurl\":\"crop_2_seed.svg\",\"hqty\":[16,18],\"exp\":1,\"cropsale\":80,\"buyable\":1,\"minlvl\":2,\"timesave\":0}', 'seed', 1577580863, 2),
(3, '$installlang[u003]', '{\"cost\":100,\"sale\":0,\"imgurl\":\"\",\"seedurl\":\"shifei.png\",\"hqty\":100,\"timesave\":60,\"exp\":0,\"cropsale\":10,\"buyable\":1,\"minlvl\":1,\"ctime\":0,\"expiredtime\":0}', 'fertilize', 1577580863, 3),
(4, '$installlang[u004]', '{\"cost\":150,\"sale\":\"0\",\"imgurl\":\"\",\"seedurl\":\"shifei.png\",\"hqty\":100,\"timesave\":600,\"exp\":0,\"cropsale\":10,\"buyable\":1,\"minlvl\":5,\"ctime\":0,\"expiredtime\":0}', 'fertilize', 1577580863, 4),
(5, '$installlang[u005]', '{\"minlvl\":3,\"cost\":175,\"cropsale\":80,\"seedurl\":\"crop_3_seed.svg\",\"buyable\":1,\"timesave\":0,\"ctime\":900,\"expiredtime\":900,\"sale\":23,\"hqty\":[18,20],\"exp\":2,\"imgurl\":\"crop_03.png\"}', 'seed', 1577580863, 5),
(6, '$installlang[u006]', '{\"minlvl\":4,\"cost\":188,\"cropsale\":90,\"seedurl\":\"crop_4_seed.svg\",\"buyable\":1,\"timesave\":0,\"ctime\":900,\"expiredtime\":900,\"sale\":24,\"hqty\":[17,19],\"exp\":2,\"imgurl\":\"crop_04.png\"}', 'seed', 1577582401, 6),
(7, '$installlang[u007]', '{\"minlvl\":6,\"cost\":251,\"cropsale\":125,\"seedurl\":\"crop_5_seed.svg\",\"buyable\":1,\"timesave\":0,\"ctime\":1020,\"expiredtime\":1020,\"sale\":26,\"hqty\":[20,22],\"exp\":3,\"imgurl\":\"crop_05.png\"}', 'seed', 1577583059, 7),
(8, '$installlang[u032]', '{\"minlvl\":7,\"cost\":266,\"cropsale\":133,\"seedurl\":\"crop_7_seed.svg\",\"buyable\":1,\"expiredtime\":3600,\"timesave\":0,\"ctime\":3600,\"sale\":50,\"hqty\":[17,21],\"exp\":5,\"imgurl\":\"crop_07.svg\",\"prodmarket\":1,\"prodmprice\":[4,30]}', 'seed', 1583899767, 8),
(9, '$installlang[u033]', '{\"minlvl\":8,\"cost\":296,\"cropsale\":150,\"seedurl\":\"crop_6_seed.svg\",\"buyable\":1,\"timesave\":0,\"ctime\":1200,\"sale\":50,\"hqty\":[10,12],\"exp\":3,\"imgurl\":\"crop_6.svg\",\"prodmarket\":1,\"prodmprice\":[45,55],\"expiredtime\":1200}', 'seed', 1583658253, 9),
(10, '$installlang[u034]', '{\"minlvl\":9,\"cost\":325,\"cropsale\":160,\"seedurl\":\"crop_8_seed.svg\",\"buyable\":1,\"expiredtime\":2400,\"timesave\":0,\"ctime\":2400,\"sale\":26,\"hqty\":[15,18],\"exp\":3,\"imgurl\":\"crop_08.svg\",\"prodmarket\":1,\"prodmprice\":[10,0]}', 'seed', 1584068109, 10),
(11, '$installlang[u035]', '{\"minlvl\":10,\"cost\":605,\"cropsale\":300,\"seedurl\":\"crop_9_seed.svg\",\"buyable\":1,\"expiredtime\":7200,\"timesave\":0,\"ctime\":7200,\"sale\":60,\"hqty\":[15,18],\"exp\":3,\"imgurl\":\"crop_9.svg\",\"prodmarket\":1,\"prodmprice\":[50,55]}', 'seed', 1584068458, 11),
(12, '$installlang[u036]', '{\"minlvl\":1,\"cost\":10,\"cropsale\":5,\"seedurl\":\"crop_12_seed.svg\",\"buyable\":1,\"expiredtime\":0,\"timesave\":0,\"ctime\":0,\"sale\":0,\"hqty\":[0,0],\"exp\":0,\"imgurl\":\"\",\"prodmarket\":1,\"prodmprice\":[10,15],\"combine\":{\"data\":{\"1\":[1,3]},\"c\":\"1\",\"cost\":10,\"timeneed\":0}}', 'nitem', 1584091233, 12),
(13, '$installlang[u037]', '{\"minlvl\":11,\"cost\":600,\"cropsale\":300,\"seedurl\":\"crop_13_seed.svg\",\"buyable\":1,\"expiredtime\":14400,\"timesave\":0,\"ctime\":14400,\"sale\":10,\"hqty\":[15,25],\"exp\":4,\"imgurl\":\"crop_13.svg\",\"prodmarket\":1,\"prodmprice\":[50,55]}', 'seed', 1584337564, 13),
(14, '$installlang[u038]', '{\"minlvl\":1,\"cost\":2,\"cropsale\":1,\"seedurl\":\"crop_14_seed.svg\",\"buyable\":1,\"expiredtime\":0,\"timesave\":0,\"ctime\":0,\"sale\":0,\"hqty\":[0,0],\"exp\":0,\"imgurl\":\"\",\"prodmarket\":1,\"prodmprice\":[5,10],\"combine\":{\"data\":{\"1\":[13,1]},\"c\":\"1\",\"cost\":5,\"timeneed\":10}}', 'nitem', 1584432913, 14),
(15, '$installlang[u039]', '{\"minlvl\":1,\"cost\":100,\"cropsale\":50,\"seedurl\":\"crop_15_seed.svg\",\"buyable\":1,\"expiredtime\":0,\"timesave\":0,\"ctime\":0,\"sale\":0,\"hqty\":[0,0],\"exp\":0,\"imgurl\":\"\",\"prodmarket\":1,\"prodmprice\":[45,55],\"combine\":{\"data\":{\"1\":[12,1],\"2\":[14,1]},\"c\":\"1\",\"cost\":10,\"timeneed\":10}}', 'nitem', 1584433915, 15);


CREATE TABLE `pre_game_jnfarm_level` (
  `jlid` int(11) NOT NULL AUTO_INCREMENT,
  `lvl` int(11) NOT NULL,
  `expneed` int(11) NOT NULL,
  `createtime` int(11) NOT NULL,
  PRIMARY KEY (`jlid`),
  KEY `lvl` (`lvl`)
) ENGINE=MyISAM AUTO_INCREMENT=101;

INSERT INTO `pre_game_jnfarm_level` (`jlid`, `lvl`, `expneed`, `createtime`) VALUES
(1, 1, 200, 0),
(2, 2, 400, 1575644144),
(3, 3, 600, 1575644144),
(4, 4, 800, 1575644144),
(5, 5, 1000, 1575644144),
(6, 6, 1200, 1575644144),
(7, 7, 1400, 1575644144),
(8, 8, 1600, 1575644144),
(9, 9, 1800, 1575644144),
(10, 10, 2000, 1575644144),
(11, 11, 2200, 1575644144),
(12, 12, 2400, 1575644144),
(13, 13, 2600, 1575644144),
(14, 14, 2800, 1575644144),
(15, 15, 3000, 1575644144),
(16, 16, 3200, 1575644144),
(17, 17, 3400, 1575644144),
(18, 18, 3600, 1575644144),
(19, 19, 3800, 1575644144),
(20, 20, 4000, 1575644144),
(21, 21, 4200, 1575644144),
(22, 22, 4400, 1575644144),
(23, 23, 4600, 1575644144),
(24, 24, 4800, 1575644144),
(25, 25, 5000, 1575644144),
(26, 26, 5200, 1575644144),
(27, 27, 5400, 1575644144),
(28, 28, 5600, 1575644144),
(29, 29, 5800, 1575644144),
(30, 30, 6000, 1575644144),
(31, 31, 6200, 1575644144),
(32, 32, 6400, 1575644144),
(33, 33, 6600, 1575644144),
(34, 34, 6800, 1575644144),
(35, 35, 7000, 1575644144),
(36, 36, 7200, 1575644144),
(37, 37, 7400, 1575644144),
(38, 38, 7600, 1575644144),
(39, 39, 7800, 1575644144),
(40, 40, 8000, 1575644144),
(41, 41, 8200, 1575644144),
(42, 42, 8400, 1575644144),
(43, 43, 8600, 1575644144),
(44, 44, 8800, 1575644144),
(45, 45, 9000, 1575644144),
(46, 46, 9200, 1575644144),
(47, 47, 9400, 1575644144),
(48, 48, 9600, 1575644144),
(49, 49, 9800, 1575644144),
(50, 50, 10000, 1575644144),
(51, 51, 10200, 1575644144),
(52, 52, 10400, 1575644144),
(53, 53, 10600, 1575644144),
(54, 54, 10800, 1575644144),
(55, 55, 11000, 1575644144),
(56, 56, 11200, 1575644144),
(57, 57, 11400, 1575644144),
(58, 58, 11600, 1575644144),
(59, 59, 11800, 1575644144),
(60, 60, 12000, 1575644144),
(61, 61, 12200, 1575644144),
(62, 62, 12400, 1575644144),
(63, 63, 12600, 1575644144),
(64, 64, 12800, 1575644144),
(65, 65, 13000, 1575644144),
(66, 66, 13200, 1575644144),
(67, 67, 13400, 1575644144),
(68, 68, 13600, 1575644144),
(69, 69, 13800, 1575644144),
(70, 70, 14000, 1575644144),
(71, 71, 14200, 1575644144),
(72, 72, 14400, 1575644144),
(73, 73, 14600, 1575644144),
(74, 74, 14800, 1575644144),
(75, 75, 15000, 1575644144),
(76, 76, 15200, 1575644144),
(77, 77, 15400, 1575644144),
(78, 78, 15600, 1575644144),
(79, 79, 15800, 1575644144),
(80, 80, 16000, 1575644144),
(81, 81, 16200, 1575644144),
(82, 82, 16400, 1575644144),
(83, 83, 16600, 1575644144),
(84, 84, 16800, 1575644144),
(85, 85, 17000, 1575644144),
(86, 86, 17200, 1575644144),
(87, 87, 17400, 1575644144),
(88, 88, 17600, 1575644144),
(89, 89, 17800, 1575644144),
(90, 90, 18000, 1575644144),
(91, 91, 18200, 1575644144),
(92, 92, 18400, 1575644144),
(93, 93, 18600, 1575644144),
(94, 94, 18800, 1575644144),
(95, 95, 19000, 1575644144),
(96, 96, 19200, 1575644144),
(97, 97, 19400, 1575644144),
(98, 98, 19600, 1575644144),
(99, 99, 19800, 1575644144),
(100, 100, 20000, 1575644144);

CREATE TABLE `pre_game_jnfarm_log` (
  `jlid` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `logdesc` text NOT NULL,
  `createtime` int(11) NOT NULL,
  `acdo` int(11) NOT NULL,
  PRIMARY KEY (`jlid`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_game_jnfarm_user` (
  `juid` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `udata` text NOT NULL,
  `createtime` int(11) NOT NULL,
  `lastsituation` int(11) NOT NULL,
  `dailyquest` text NOT NULL,
  `realland` text NOT NULL,
  `dayquest` text NOT NULL,
  `ref` int(11) NOT NULL,
  `username` text NOT NULL,
  `vipexpired` int(11) NOT NULL,
  `uposition` int(11) NOT NULL,
  `uguildgx` int(11) NOT NULL,
  `uindigx` int(11) NOT NULL,
  `jgid` int(11) NOT NULL,
  `quittime` int(11) NOT NULL,
  `jgcs` int(11) NOT NULL,
  `weekindigx` int(11) NOT NULL,
  `weekguildgx` int(11) NOT NULL,
  `todayjscs` int(11) NOT NULL,
  `lastjs` int(11) NOT NULL,
  `kpck` int(11) NOT NULL,
  `spck` int(11) NOT NULL,
  `freedraw` int(11) NOT NULL,
  `freekpdraw` int(11) NOT NULL,
  `advplace` int(11) NOT NULL,
  `pktime` int(11) NOT NULL,
  `pkpoint` int(11) NOT NULL,
  `pkfreeze` int(11) NOT NULL,
  `pklast` int(11) NOT NULL,
  `todaypkid` text NOT NULL,
  PRIMARY KEY (`juid`),
  KEY `uid` (`uid`),
  KEY `ref` (`ref`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE pre_game_jnfarm_land (
  jfid int(11) NOT NULL AUTO_INCREMENT,
  uid int(11) NOT NULL,
  fdata text NOT NULL,
  createtime int(11) NOT NULL,
  PRIMARY KEY (jfid),
  KEY uid (uid)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS pre_game_jnfarm_market (
  jmid int(11) NOT NULL AUTO_INCREMENT,
  selluid int(11) NOT NULL,
  buyuid int(11) NOT NULL,
  createtime int(11) NOT NULL,
  buytime int(11) NOT NULL,
  mdata text NOT NULL COMMENT '[itemid,price,qty]',
  mtype text NOT NULL,
  msign text NOT NULL,
  mstatus int(11) NOT NULL,
  PRIMARY KEY (jmid),
  KEY selluid (selluid),
  KEY buyuid (buyuid)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_game_jnfarm_achieve` (
  `jaid` int(11) NOT NULL AUTO_INCREMENT,
  `jatitle` text NOT NULL,
  `jatype` int(11) NOT NULL COMMENT '1=lvl,2=planttime,3=harvesttime,4=money',
  `wxtra` text NOT NULL,
  `jaqty` int(11) NOT NULL,
  `gifttype` int(11) NOT NULL COMMENT '1=money,2=seedid,3=productid,4=fertilizerid,5=extcredits',
  `jxtra` int(11) NOT NULL,
  `giftqty` int(11) NOT NULL,
  `sucuid` text NOT NULL COMMENT 'successuid',
  `frontac` int(11) NOT NULL,
  `jaorder` int(11) NOT NULL,
  `padd` int(11) NOT NULL,
  PRIMARY KEY (`jaid`)
) ENGINE=MyISAM AUTO_INCREMENT=25;

INSERT INTO `pre_game_jnfarm_achieve` (`jaid`, `jatitle`, `jatype`, `wxtra`, `jaqty`, `gifttype`, `jxtra`, `giftqty`, `sucuid`, `frontac`, `jaorder`, `padd`) VALUES
(1, '$installlang[u008]', 1, '', 3, 3, 5, 30, '0,1', 0, 1, 5),
(2, '$installlang[u009]', 1, '', 5, 1, 0, 50, '0,1', 0, 2, 5),
(3, '$installlang[u010]', 2, '', 20, 1, 0, 100, '0', 0, 1, 5),
(4, '$installlang[u011]', 2, '', 50, 1, 0, 500, '0', 0, 2, 5),
(5, '$installlang[u012]', 1, '', 10, 1, 0, 1000, '0,1', 0, 3, 5),
(6, '$installlang[u013]', 1, '', 15, 1, 0, 1500, '0,1', 0, 4, 5),
(7, '$installlang[u014]', 3, '', 10, 2, 1, 1, '0,1', 0, 1, 5),
(8, '$installlang[u015]', 3, '', 50, 2, 2, 3, '0', 0, 2, 5),
(9, '$installlang[u016]', 3, '', 150, 2, 5, 3, '0', 0, 3, 5),
(10, '$installlang[u017]', 3, '', 200, 2, 5, 3, '0', 0, 4, 5),
(11, '$installlang[u018]', 3, '', 300, 2, 6, 3, '0', 0, 5, 5),
(12, '$installlang[u019]', 4, '', 10000, 4, 3, 3, '0,1', 0, 1, 3),
(13, '$installlang[u020]', 5, '1', 5, 1, 0, 100, '0', 0, 0, 5),
(14, '$installlang[u021]', 5, '2', 5, 1, 0, 200, '0,1', 0, 2, 5),
(15, '$installlang[u022]', 1, '', 20, 1, 0, 2000, '0,1', 0, 5, 5),
(16, '$installlang[u023]', 1, '', 25, 1, 0, 2500, '0,1', 0, 6, 5),
(17, '$installlang[u024]', 1, '', 30, 1, 0, 3000, '0', 0, 7, 5),
(18, '$installlang[u025]', 1, '', 35, 1, 0, 3500, '0', 0, 8, 10),
(19, '$installlang[u026]', 1, '', 40, 1, 0, 4000, '0', 0, 9, 10),
(20, '$installlang[u027]', 1, '', 50, 1, 0, 5000, '0', 0, 10, 10),
(21, '$installlang[u028]', 2, '', 100, 2, 2, 10, '0', 0, 3, 10),
(22, '$installlang[u029]', 4, '', 100000, 4, 3, 10, '0', 0, 2, 5),
(23, '$installlang[u030]', 6, '1', 10, 2, 1, 3, '0', 0, 1, 5),
(24, '$installlang[u031]', 6, '1', 20, 2, 1, 5, '0', 0, 2, 5);

CREATE TABLE IF NOT EXISTS `pre_game_jnfarm_cashout` (
  `jcid` int(11) NOT NULL AUTO_INCREMENT,
  `submituid` int(11) NOT NULL,
  `verifyuid` int(11) NOT NULL,
  `getext` int(11) NOT NULL,
  `extcredits` int(11) NOT NULL,
  `costjncmt` int(11) NOT NULL,
  `thischarges` int(11) NOT NULL,
  `allamount` int(11) NOT NULL,
  `createtime` int(11) NOT NULL,
  `updatetime` int(11) NOT NULL,
  `jstatus` int(11) NOT NULL,
  PRIMARY KEY (`jcid`),
  KEY `submituid` (`submituid`),
  KEY `verifyuid` (`verifyuid`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_game_jnfarm_combine` (
  `jcid` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `jcdata` text NOT NULL,
  PRIMARY KEY (`jcid`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_game_jnfarm_pet` (
  `jpid` int(11) NOT NULL AUTO_INCREMENT,
  `jptitle` text NOT NULL,
  `jpdata` text NOT NULL,
  `jpxtra` text NOT NULL,
  PRIMARY KEY (`jpid`)
) ENGINE=MyISAM AUTO_INCREMENT=7;

INSERT INTO `pre_game_jnfarm_pet` (`jpid`, `jptitle`, `jpdata`, `jpxtra`) VALUES
(1, '$installlang[u040]', '{\"pimg\":\"source\\/plugin\\/jnfarm\\/template\\/images\\/pet1.gif\",\"attack\":10,\"hungry\":100,\"hungrytime\":7,\"buyprice\":100,\"lostcoin\":10,\"buytype\":1}', ''),
(2, '$installlang[u041]', '{\"pimg\":\"source\\/plugin\\/jnfarm\\/template\\/images\\/pet2.gif\",\"attack\":20,\"hungry\":100,\"hungrytime\":7,\"buyprice\":200,\"lostcoin\":12,\"buytype\":1}', ''),
(3, '$installlang[u042]', '{\"pimg\":\"source\\/plugin\\/jnfarm\\/template\\/images\\/pet3.gif\",\"attack\":25,\"hungry\":120,\"hungrytime\":7,\"buyprice\":350,\"lostcoin\":14,\"buytype\":1}', ''),
(4, '$installlang[u043]', '{\"pimg\":\"source\\/plugin\\/jnfarm\\/template\\/images\\/pet4.gif\",\"attack\":30,\"hungry\":150,\"hungrytime\":7,\"buyprice\":800,\"lostcoin\":16,\"buytype\":1}', ''),
(5, '$installlang[u044]', '{\"pimg\":\"source\\/plugin\\/jnfarm\\/template\\/images\\/pet5.gif\",\"attack\":35,\"hungry\":200,\"hungrytime\":7,\"buyprice\":2500,\"lostcoin\":18,\"buytype\":1}', ''),
(6, '$installlang[u045]', '{\"pimg\":\"source\\/plugin\\/jnfarm\\/template\\/images\\/pet6.gif\",\"attack\":40,\"hungry\":300,\"hungrytime\":7,\"buyprice\":10000,\"lostcoin\":18,\"buytype\":1}', '');

CREATE TABLE IF NOT EXISTS `pre_game_jnfarm_dailyquest` (
	`jdid` INT NOT NULL AUTO_INCREMENT,
	`jdtitle` TEXT NOT NULL,
	`jddata` TEXT NOT NULL,
	`jdother` TEXT NOT NULL,
	`minlvl` INT NOT NULL,
	`jdorder` INT NOT NULL,
	PRIMARY KEY (`jdid`)
) ENGINE = MyISAM AUTO_INCREMENT=101;

INSERT INTO `pre_game_jnfarm_dailyquest` (`jdid`, `jdtitle`, `jddata`, `jdother`, `minlvl`) VALUES
(1, '$installlang[u046]', '{\"jdesc\":\"$installlang[u052]\",\"type\":1,\"jimg\":\"source\\/plugin\\/jnfarm\\/template\\/images\\/water.svg\",\"gifttype\":4,\"gtype4\":1,\"giftqtymin\":5,\"giftqtymax\":10}', '', 1),
(2, '$installlang[u047]', '{\"jdesc\":\"$installlang[u053]\",\"type\":2,\"jimg\":\"\",\"rules\":5,\"rulesqty\":5,\"gifttype\":2,\"gtype2\":1,\"giftqtymin\":3,\"giftqtymax\":3}', '', 1),
(3, '$installlang[u048]', '{\"jdesc\":\"$installlang[u054]\",\"type\":2,\"jimg\":\"\",\"rules\":5,\"rulesqty\":10,\"gifttype\":2,\"gtype2\":5,\"giftqtymin\":1,\"giftqtymax\":3}', '', 2),
(4, '$installlang[u049]', '{\"jdesc\":\"$installlang[u055]\",\"type\":2,\"jimg\":\"\",\"rules\":1,\"rulesqty\":3,\"gifttype\":1,\"gtype1\":1,\"giftqtymin\":1,\"giftqtymax\":1}', '', 1),
(5, '$installlang[u050]', '{\"jdesc\":\"$installlang[u056]\",\"type\":2,\"jimg\":\"\",\"rules\":1,\"rulesqty\":10,\"gifttype\":1,\"gtype1\":1,\"giftqtymin\":1,\"giftqtymax\":1}', '', 3),
(6, '$installlang[u051]', '{\"jdesc\":\"$installlang[u057]\",\"type\":2,\"jimg\":\"\",\"rules\":3,\"rulesqty\":3,\"gifttype\":1,\"gtype1\":3,\"giftqtymin\":1,\"giftqtymax\":1}', '', 5);

CREATE TABLE IF NOT EXISTS `pre_game_jnfarm_realland` (
  `jrid` int(11) NOT NULL AUTO_INCREMENT,
  `jrtitle` text NOT NULL,
  `jrdata` text NOT NULL,
  `jrothers` int(11) NOT NULL,
  `canplant` int(11) NOT NULL,
  PRIMARY KEY (`jrid`),
  KEY `canplant` (`canplant`)
) ENGINE=MyISAM AUTO_INCREMENT=101;

INSERT INTO `pre_game_jnfarm_realland` (`jrid`, `jrtitle`, `jrdata`, `jrothers`, `canplant`) VALUES
(1, '$installlang[u058]', '{\"small\":\"source\\/plugin\\/jnfarm\\/template\\/images\\/mango-icon.png\",\"jimg1\":\"source\\/plugin\\/jnfarm\\/template\\/images\\/youngTree.png\",\"jimg2\":\"source\\/plugin\\/jnfarm\\/template\\/images\\/mango-small.png\",\"jimg3\":\"source\\/plugin\\/jnfarm\\/template\\/images\\/mango-medium.png\",\"jimg4\":\"source\\/plugin\\/jnfarm\\/template\\/images\\/mango-big.png\",\"jword1\":\"$installlang[u062]\",\"jword2\":\"$installlang[u063]\",\"jword3\":\"$installlang[u064]\",\"jword4\":\"$installlang[u065]\",\"jrsd1\":3,\"jrfl1\":0,\"jrsd2\":3,\"jrfl2\":0,\"jrsd3\":3,\"jrfl3\":1,\"jrsd4\":3,\"jrfl4\":1,\"jdesc\":\"$installlang[u066]\",\"qty\":\"$installlang[u067]\"}', 0, 1),
(2, '$installlang[u059]', '{\"small\":\"source\\/plugin\\/jnfarm\\/template\\/images\\/apple-icon.png\",\"jimg1\":\"source\\/plugin\\/jnfarm\\/template\\/images\\/youngTree.png\",\"jimg2\":\"source\\/plugin\\/jnfarm\\/template\\/images\\/apple-small.png\",\"jimg3\":\"source\\/plugin\\/jnfarm\\/template\\/images\\/apple-medium.png\",\"jimg4\":\"source\\/plugin\\/jnfarm\\/template\\/images\\/apple-big.png\",\"jword1\":\"$installlang[u068]\",\"jword2\":\"$installlang[u069]\",\"jword3\":\"$installlang[u070]\",\"jword4\":\"$installlang[u071]\",\"jrsd1\":30,\"jrfl1\":1,\"jrsd2\":100,\"jrfl2\":2,\"jrsd3\":250,\"jrfl3\":3,\"jrsd4\":2000,\"jrfl4\":4,\"jdesc\":\"$installlang[u072]\",\"qty\":\"$installlang[u067]\"}', 0, 1),
(3, '$installlang[u060]', '{\"small\":\"source\\/plugin\\/jnfarm\\/template\\/images\\/orange-icon.png\",\"jimg1\":\"source\\/plugin\\/jnfarm\\/template\\/images\\/youngTree.png\",\"jimg2\":\"source\\/plugin\\/jnfarm\\/template\\/images\\/orange-small.png\",\"jimg3\":\"source\\/plugin\\/jnfarm\\/template\\/images\\/orange-medium.png\",\"jimg4\":\"source\\/plugin\\/jnfarm\\/template\\/images\\/orange-big.png\",\"jword1\":\"$installlang[u073]\",\"jword2\":\"$installlang[u074]\",\"jword3\":\"$installlang[u075]\",\"jword4\":\"$installlang[u076]\",\"jrsd1\":30,\"jrfl1\":1,\"jrsd2\":100,\"jrfl2\":2,\"jrsd3\":250,\"jrfl3\":3,\"jrsd4\":2000,\"jrfl4\":4,\"jdesc\":\"$installlang[u077]\",\"qty\":\"$installlang[u067]\"}', 0, 1),
(4, '$installlang[u061]', '{\"small\":\"source\\/plugin\\/jnfarm\\/template\\/images\\/dragonfruit-icon.png\",\"jimg1\":\"source\\/plugin\\/jnfarm\\/template\\/images\\/youngTree.png\",\"jimg2\":\"source\\/plugin\\/jnfarm\\/template\\/images\\/dragonfruit-small.png\",\"jimg3\":\"source\\/plugin\\/jnfarm\\/template\\/images\\/dragonfruit-medium.png\",\"jimg4\":\"source\\/plugin\\/jnfarm\\/template\\/images\\/dragonfruit-big.png\",\"jword1\":\"$installlang[u078]\",\"jword2\":\"$installlang[u079]\",\"jword3\":\"$installlang[u080]\",\"jword4\":\"$installlang[u081]\",\"jrsd1\":3,\"jrfl1\":1,\"jrsd2\":3,\"jrfl2\":2,\"jrsd3\":3,\"jrfl3\":3,\"jrsd4\":3,\"jrfl4\":4,\"jdesc\":\"$installlang[u082]\",\"qty\":\"$installlang[u067]\"}', 0, 1);

CREATE TABLE IF NOT EXISTS pre_game_jnfarm_realland_record (
  `jrrid` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `rinfo` text NOT NULL,
  `createtime` int(11) NOT NULL,
  `rstatus` int(11) NOT NULL,
  PRIMARY KEY (`jrrid`),
  KEY uid (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS pre_game_jnfarm_invite (
  `jiid` INT NOT NULL AUTO_INCREMENT ,
  `uid` INT NOT NULL ,
  `invitecode` TEXT NOT NULL ,
  PRIMARY KEY (`jiid`),
  KEY uid (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_game_jnfarm_season_set` (
  `jsid` int(11) NOT NULL AUTO_INCREMENT,
  `jstart` int(11) NOT NULL,
  `jend` int(11) NOT NULL,
  `jdata` text NOT NULL,
  `jstatus` int(11) NOT NULL,
  `mdpass` text NOT NULL,
  `seasondesc` text NOT NULL,
  PRIMARY KEY (`jsid`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_game_jnfarm_season` (
  `jdid` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `jsid` int(11) NOT NULL,
  `prize` int(11) NOT NULL,
  `getprize` int(11) NOT NULL,
  `createtime` int(11) NOT NULL,
  PRIMARY KEY (`jdid`),
  KEY `uid` (`uid`),
  KEY `qty` (`qty`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_game_jnfarm_rankcache` (
  `jrid` int(11) NOT NULL AUTO_INCREMENT,
  `username` text NOT NULL,
  `type` text NOT NULL,
  `createtime` int(11) NOT NULL,
  `orderby` int(11) NOT NULL,
  `numqty` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `updatetime` int(11) NOT NULL,
  PRIMARY KEY (`jrid`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_game_jnfarm_mall` ( 
	`jmid` INT NOT NULL AUTO_INCREMENT ,
	`jmtitle` TEXT NOT NULL ,
	`jmdata` TEXT NOT NULL , 
	`jmext` INT NOT NULL , 
	`jmprice` INT NOT NULL , 
	`dailylimit` INT NOT NULL , 
	`onlyonce` INT NOT NULL ,
	`orderby` INT NOT NULL,
	`onceuid` TEXT NOT NULL,
	`dailyuid` TEXT NOT NULL,
	PRIMARY KEY (`jmid`)
) ENGINE = MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_game_jnfarm_guild` (
  `jgid` int(11) NOT NULL AUTO_INCREMENT,
  `jgtitle` text NOT NULL,
  `owner` int(11) NOT NULL,
  `createtime` int(11) NOT NULL,
  `gongxian` int(11) NOT NULL,
  `jglvl` int(11) NOT NULL,
  `jgiid` int(11) NOT NULL,
  `jsqtynow` int(11) NOT NULL,
  `jsqtymax` int(11) NOT NULL,
  `weekgx` int(11) NOT NULL,
  `lastjs` int(11) NOT NULL,
  PRIMARY KEY (`jgid`),
  KEY `owner` (`owner`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_game_jnfarm_guild_gxreward` (
  `jgrid` int(11) NOT NULL AUTO_INCREMENT,
  `jgprice` text NOT NULL,
  `jgmingcimin` int(11) NOT NULL,
  `jgmingcimax` int(11) NOT NULL,
  `jgjoin` text NOT NULL,
  PRIMARY KEY (`jgrid`)
) ENGINE=MyISAM AUTO_INCREMENT=5;

INSERT INTO `pre_game_jnfarm_guild_gxreward` (`jgrid`, `jgprice`, `jgmingcimin`, `jgmingcimax`, `jgjoin`) VALUES
(1, '{\"item\":{\"1\":10,\"3\":20,\"4\":50}}', 1, 1, '{\"canyucishu\":100,\"item\":{\"3\":3}}'),
(2, '{\"item\":{\"1\":10,\"3\":20,\"4\":30}}', 2, 2, '{\"canyucishu\":100,\"item\":{\"3\":3}}'),
(3, '{\"item\":{\"1\":10,\"3\":20,\"4\":10}}', 3, 3, '{\"canyucishu\":100,\"item\":{\"3\":3}}'),
(4, '{\"item\":{\"1\":10,\"3\":10}}', 4, 10, '{\"canyucishu\":100,\"item\":{\"3\":3}}');

CREATE TABLE IF NOT EXISTS `pre_game_jnfarm_guild_item` (
  `jgiid` int(11) NOT NULL AUTO_INCREMENT,
  `jgititle` text NOT NULL,
  `jgiimg` text NOT NULL,
  `jgicost` text NOT NULL,
  `jgidesc` text NOT NULL,
  `jsicost` text NOT NULL,
  `totaljs` int(11) NOT NULL,
  `jireward` text NOT NULL,
  `btnword` text NOT NULL,
  `indigx` int(11) NOT NULL,
  `guildgx` int(11) NOT NULL,
  `jimemberreward` text NOT NULL,
  `jsjg` int(11) NOT NULL,
  `daijs` int(11) NOT NULL,
  `dailylimit` int(11) NOT NULL,
  `timelimit` int(11) NOT NULL,
  PRIMARY KEY (`jgiid`)
) ENGINE=MyISAM AUTO_INCREMENT=3;

INSERT INTO `pre_game_jnfarm_guild_item` (`jgiid`, `jgititle`, `jgiimg`, `jgicost`, `jgidesc`, `jsicost`, `totaljs`, `jireward`, `btnword`, `indigx`, `guildgx`, `jimemberreward`, `jsjg`, `daijs`, `dailylimit`, `timelimit`) VALUES
(1, '$installlang[u085]', 'source/plugin/jnfarm/template/images/guild_01.svg', '{\"item\":{\"1\":100,\"2\":100}}', '', '{\"item\":{\"1\":1}}', 1000, '[\"100\",\"80\",\"60\",\"40\",\"20\",\"5\"]', '$installlang[u086]', 1, 1, '{\"item\":{\"3\":1}}', 0, 0, 5, 60),
(2, '$installlang[u087]', 'source/plugin/jnfarm/template/images/guild_02.gif', '{\"item\":{\"5\":100,\"6\":200}}', '', '{\"item\":{\"5\":1}}', 3000, '[\"200\",\"150\",\"100\",\"50\",\"30\",\"10\"]', '$installlang[u088]', 2, 2, '{\"item\":{\"4\":1}}', 0, 0, 5, 180);

CREATE TABLE IF NOT EXISTS `pre_game_jnfarm_guild_level` (
  `jlid` int(11) NOT NULL AUTO_INCREMENT,
  `lvl` int(11) NOT NULL,
  `expneed` int(11) NOT NULL,
  `createtime` int(11) NOT NULL,
  PRIMARY KEY (`jlid`),
  KEY `lvl` (`lvl`)
) ENGINE=MyISAM AUTO_INCREMENT=11;

INSERT INTO `pre_game_jnfarm_guild_level` (`jlid`, `lvl`, `expneed`, `createtime`) VALUES
(1, 1, 20000, 0),
(2, 2, 60000, 1575644144),
(3, 3, 180000, 1575644144),
(4, 4, 540000, 1575644144),
(5, 5, 1620000, 1575644144),
(6, 6, 4860000, 1575644144),
(7, 7, 14580000, 1575644144),
(8, 8, 43740000, 1575644144),
(9, 9, 131220000, 1575644144),
(10, 10, 393660000, 1575644144);

CREATE TABLE IF NOT EXISTS `pre_game_jnfarm_guild_reward` (
  `jgrid` int(11) NOT NULL AUTO_INCREMENT,
  `jgmc` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `fordate` int(11) NOT NULL,
  `taken` int(11) NOT NULL,
  PRIMARY KEY (`jgrid`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_game_jnfarm_dateline` (
  `jdid` int(11) NOT NULL AUTO_INCREMENT,
  `fordate` int(11) NOT NULL,
  `timetype` int(11) NOT NULL,
  PRIMARY KEY (`jdid`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_game_jnfarm_guild_hzgxreward` (
  `jgrid` int(11) NOT NULL AUTO_INCREMENT,
  `jgprice` text NOT NULL,
  `jgmingcimin` int(11) NOT NULL,
  `jgmingcimax` int(11) NOT NULL,
  `jgjoin` text NOT NULL,
  PRIMARY KEY (`jgrid`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_game_jnfarm_guild_hzreward` (
  `jgrid` int(11) NOT NULL AUTO_INCREMENT,
  `jgmc` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `fordate` int(11) NOT NULL,
  `taken` int(11) NOT NULL,
  PRIMARY KEY (`jgrid`)
) ENGINE=MyISAM;

INSERT INTO `pre_game_jnfarm_guild_hzgxreward` (`jgrid`, `jgprice`, `jgmingcimin`, `jgmingcimax`, `jgjoin`) VALUES
(1, '{\"item\":{\"1\":10,\"3\":20,\"4\":50}}', 1, 1, '{\"canyucishu\":100,\"item\":{\"3\":3}}'),
(2, '{\"item\":{\"1\":10,\"3\":20,\"4\":30}}', 2, 2, '{\"canyucishu\":100,\"item\":{\"3\":3}}'),
(3, '{\"item\":{\"1\":10,\"3\":20,\"4\":10}}', 3, 3, '{\"canyucishu\":100,\"item\":{\"3\":3}}'),
(4, '{\"item\":{\"1\":10,\"3\":10}}', 4, 10, '{\"canyucishu\":100,\"item\":{\"3\":3}}');

CREATE TABLE IF NOT EXISTS `pre_game_jnfarm_card` (
  `jcid` int(11) NOT NULL AUTO_INCREMENT,
  `ctitle` text NOT NULL,
  `cdata` text NOT NULL,
  `type` text NOT NULL,
  `createtime` int(11) NOT NULL,
  `ciorder` int(11) NOT NULL,
  `jifen` int(11) NOT NULL,
  `jccid` int(11) NOT NULL,
  PRIMARY KEY (`jcid`)
) ENGINE=MyISAM;

INSERT INTO `pre_game_jnfarm_card` (`jcid`, `ctitle`, `cdata`, `type`, `createtime`, `ciorder`, `jifen`, `jccid`) VALUES
(1, '$installlang[u090]', '{\"imgurl\":\"source\\/plugin\\/jnfarm\\/template\\/images\\/card_04.png\",\"success\":0,\"zhanli\":0,\"basiczhanli\":[\"\",\"\"],\"maxlvl\":0,\"lvltype\":\"\",\"refundindigx\":0,\"refundguildgx\":0,\"prodmarket\":1,\"prodmprice0\":100,\"prodmprice1\":150}', 'suipian', 0, 1, 0, 1),
(2, '$installlang[u091]', '{\"imgurl\":\"source\\/plugin\\/jnfarm\\/template\\/images\\/card_01.png\",\"spcombine\":[3,100],\"success\":80,\"zhanli\":10,\"lvltype\":\"S\",\"refundindigx\":5,\"refundguildgx\":10,\"maxlvl\":100,\"prodmarket\":1,\"prodmprice0\":10000,\"prodmprice1\":12000,\"kpcombine\":{\"ext\":{\"99\":10000},\"item\":{\"1\":1000}},\"kpuplvl\":{\"ext\":{\"99\":1000}},\"basiczhanli\":[30,\"40\"]}', 'card', 0, 2, 0, 1),
(3, '$installlang[u092]', '{\"imgurl\":\"source\\/plugin\\/jnfarm\\/template\\/images\\/card_01.png\",\"success\":0,\"zhanli\":0,\"basiczhanli\":[\"\",\"\"],\"maxlvl\":0,\"lvltype\":\"\",\"refundindigx\":0,\"refundguildgx\":0,\"prodmarket\":1,\"prodmprice0\":100,\"prodmprice1\":150}', 'suipian', 0, 3, 0, 1),
(4, '$installlang[u093]', '{\"imgurl\":\"source\\/plugin\\/jnfarm\\/template\\/images\\/card_02.png\",\"success\":90,\"zhanli\":10,\"maxlvl\":100,\"lvltype\":\"SS\",\"refundindigx\":10,\"refundguildgx\":20,\"prodmarket\":1,\"prodmprice0\":20000,\"prodmprice1\":25000,\"spcombine\":[5,100],\"kpcombine\":{\"item\":{\"1\":100,\"2\":200,\"5\":300},\"ext\":{\"99\":20000}},\"kpuplvl\":{\"ext\":{\"99\":100}},\"basiczhanli\":[100,\"200\"]}', 'card', 0, 4, 0, 1),
(5, '$installlang[u094]', '{\"imgurl\":\"source\\/plugin\\/jnfarm\\/template\\/images\\/card_02.png\",\"spcombine\":[1,1],\"success\":0,\"zhanli\":0,\"lvltype\":\"\",\"refundindigx\":0,\"refundguildgx\":0,\"kpcombine\":{\"ext\":{\"1\":66,\"2\":99,\"3\":111}},\"basiczhanli\":[\"\",\"\"],\"maxlvl\":0,\"prodmarket\":1,\"prodmprice0\":100,\"prodmprice1\":150}', 'suipian', 0, 5, 0, 1),
(6, '$installlang[u095]', '{\"imgurl\":\"source\\/plugin\\/jnfarm\\/template\\/images\\/card_03.png\",\"success\":80,\"zhanli\":15,\"maxlvl\":100,\"lvltype\":\"SS\",\"refundindigx\":10,\"refundguildgx\":20,\"prodmarket\":1,\"prodmprice0\":30000,\"prodmprice1\":35000,\"spcombine\":[7,100],\"kpcombine\":{\"ext\":{\"99\":30000},\"item\":{\"1\":3000}},\"kpuplvl\":{\"ext\":{\"99\":1200}},\"basiczhanli\":[400,\"500\"]}', 'card', 0, 6, 0, 1),
(7, '$installlang[u096]', '{\"imgurl\":\"source\\/plugin\\/jnfarm\\/template\\/images\\/card_03.png\",\"prodmarket\":1,\"prodmprice0\":100,\"prodmprice1\":150,\"success\":0,\"zhanli\":0,\"basiczhanli\":[\"\",\"\"],\"maxlvl\":0,\"lvltype\":\"\",\"refundindigx\":0,\"refundguildgx\":0}', 'suipian', 0, 7, 0, 1);

CREATE TABLE IF NOT EXISTS `pre_game_jnfarm_card_hzreward` (
  `jgrid` int(11) NOT NULL AUTO_INCREMENT,
  `jgmc` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `fordate` int(11) NOT NULL,
  `taken` int(11) NOT NULL,
  PRIMARY KEY (`jgrid`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_game_jnfarm_card_hzzlreward` (
  `jgrid` int(11) NOT NULL AUTO_INCREMENT,
  `jgprice` text NOT NULL,
  `jgmingcimin` int(11) NOT NULL,
  `jgmingcimax` int(11) NOT NULL,
  `jgjoin` text NOT NULL,
  PRIMARY KEY (`jgrid`)
) ENGINE=MyISAM;

INSERT INTO `pre_game_jnfarm_card_hzzlreward` (`jgrid`, `jgprice`, `jgmingcimin`, `jgmingcimax`, `jgjoin`) VALUES
(1, '{\"item\":{\"1\":10,\"3\":20,\"4\":50}}', 1, 1, '{\"canyucishu\":100,\"item\":{\"3\":3}}'),
(2, '{\"item\":{\"1\":10,\"3\":20,\"4\":30}}', 2, 2, '{\"canyucishu\":100,\"item\":{\"3\":3}}'),
(3, '{\"item\":{\"1\":10,\"3\":20,\"4\":10}}', 3, 3, '{\"canyucishu\":100,\"item\":{\"3\":3}}'),
(4, '{\"item\":{\"1\":10,\"3\":10}}', 4, 10, '{\"canyucishu\":100,\"item\":{\"3\":3}}');


CREATE TABLE IF NOT EXISTS `pre_game_jnfarm_card_reward` (
  `jgrid` int(11) NOT NULL AUTO_INCREMENT,
  `jgmc` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `fordate` int(11) NOT NULL,
  `taken` int(11) NOT NULL,
  PRIMARY KEY (`jgrid`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_game_jnfarm_card_user` (
  `jcuid` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `jcid` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `type` text NOT NULL,
  `lvl` int(11) NOT NULL,
  `basiczhanli` int(11) NOT NULL,
  `nowhp` int(11) NOT NULL,
  `maxhp` int(11) NOT NULL,
  `abletopk` int(11) NOT NULL,
  `inadv` int(11) NOT NULL,
  PRIMARY KEY (`jcuid`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_game_jnfarm_card_zlreward` (
  `jgrid` int(11) NOT NULL AUTO_INCREMENT,
  `jgprice` text NOT NULL,
  `jgmingcimin` int(11) NOT NULL,
  `jgmingcimax` int(11) NOT NULL,
  `jgjoin` text NOT NULL,
  PRIMARY KEY (`jgrid`)
) ENGINE=MyISAM;

INSERT INTO `pre_game_jnfarm_card_zlreward` (`jgrid`, `jgprice`, `jgmingcimin`, `jgmingcimax`, `jgjoin`) VALUES
(1, '{\"item\":{\"1\":10,\"3\":20,\"4\":50}}', 1, 1, '{\"canyucishu\":100,\"item\":{\"3\":3}}'),
(2, '{\"item\":{\"1\":10,\"3\":20,\"4\":30}}', 2, 2, '{\"canyucishu\":100,\"item\":{\"3\":3}}'),
(3, '{\"item\":{\"1\":10,\"3\":20,\"4\":10}}', 3, 3, '{\"canyucishu\":100,\"item\":{\"3\":3}}'),
(4, '{\"item\":{\"1\":10,\"3\":10}}', 4, 10, '{\"canyucishu\":100,\"item\":{\"3\":3}}');

CREATE TABLE IF NOT EXISTS `pre_game_jnfarm_card_cat` (
  `jccid` int(11) NOT NULL AUTO_INCREMENT,
  `jctitle` text NOT NULL,
  `jcorder` int(11) NOT NULL,
  `createtime` int(11) NOT NULL,
  PRIMARY KEY (`jccid`)
) ENGINE=MyISAM;

INSERT INTO `pre_game_jnfarm_card_cat` (`jccid`, `jctitle`, `jcorder`, `createtime`) VALUES
(1, '$installlang[u097]', 1, 1624595865);

CREATE TABLE IF NOT EXISTS `pre_game_jnfarm_card_draw` (
  `jdid` int(11) NOT NULL AUTO_INCREMENT,
  `jdtitle` text NOT NULL,
  `jccid` int(11) NOT NULL,
  `jdata` text NOT NULL,
  `jdorder` int(11) NOT NULL,
  `imgurl` text NOT NULL,
  PRIMARY KEY (`jdid`)
) ENGINE=MyISAM;

INSERT INTO `pre_game_jnfarm_card_draw` (`jdid`, `jdtitle`, `jccid`, `jdata`, `jdorder`, `imgurl`) VALUES
(1, '$installlang[u098]', 0, '{\"kpdrawqty\":100,\"kpdraw\":99,\"drawtime\":1,\"drawtype\":1}', 1, ''),
(2, '$installlang[u099]', 0, '{\"kpdrawqty\":1000,\"kpdraw\":99,\"drawtime\":\"1,9\",\"drawtype\":2,\"freedraw\":1}', 2, '');

ALTER TABLE `pre_game_jnfarm_card_cat`  AUTO_INCREMENT=101;
ALTER TABLE `pre_game_jnfarm_card_draw` AUTO_INCREMENT=101;

CREATE TABLE IF NOT EXISTS `pre_game_jnfarm_card_suit` (
  `jsid` int(11) NOT NULL AUTO_INCREMENT,
  `jstitle` text NOT NULL,
  `jsrules` text NOT NULL,
  `createtime` int(11) NOT NULL,
  `fprize` text NOT NULL,
  `fuid` int(11) NOT NULL,
  `ftime` int(11) NOT NULL,
  `maxppl` int(11) NOT NULL,
  `getppl` int(11) NOT NULL,
  PRIMARY KEY (`jsid`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_game_jnfarm_card_suitlog` (
  `jslid` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `createtime` int(11) NOT NULL,
  `jsid` int(11) NOT NULL,
  PRIMARY KEY (`jslid`)
) ENGINE=MyISAM;

INSERT INTO `pre_game_jnfarm_card_suit` (`jsid`, `jstitle`, `jsrules`, `createtime`, `fprize`, `fuid`, `ftime`, `maxppl`, `getppl`) VALUES
(1, '$installlang[u100]', '{\"suit\":{\"6\":1,\"4\":1,\"2\":1},\"reward\":{\"item\":{\"1\":100},\"ext\":{\"99\":100}}}', 1624416098, '{\"reward\":{\"item\":{\"1\":100,\"3\":100,\"4\":50},\"card\":{\"1\":10,\"2\":2}}}', 0, 0, 100, 0),
(2, '$installlang[u101]', '{\"suit\":{\"2\":5,\"4\":5,\"6\":5},\"reward\":{\"item\":{\"3\":20,\"4\":10}}}', 1624459051, '{\"reward\":{\"item\":{\"2\":100,\"3\":200,\"4\":100}}}', 0, 0, 100, 0),
(3, '$installlang[u102]', '{\"suit\":{\"2\":100,\"4\":100,\"6\":100},\"reward\":{\"item\":{\"4\":50}}}', 1624459117, '{\"reward\":{\"item\":{\"4\":1000}}}', 0, 0, 50, 0);

ALTER TABLE `pre_game_jnfarm_card_suit` AUTO_INCREMENT=101;

CREATE TABLE IF NOT EXISTS `pre_game_jnfarm_card_adv` (
  `jcaid` int(11) NOT NULL AUTO_INCREMENT,
  `jctitle` text NOT NULL,
  `jcdesc` text NOT NULL,
  `jcdata` text NOT NULL,
  `jcorder` int(11) NOT NULL,
  PRIMARY KEY (`jcaid`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_game_jnfarm_card_advlist` (
  `jclid` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `createtime` int(11) NOT NULL,
  `finishtime` int(11) NOT NULL,
  `jcaid` int(11) NOT NULL,
  `jcuid` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `jcid` int(11) NOT NULL,
  `lvl` int(11) NOT NULL,
  PRIMARY KEY (`jclid`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM;

INSERT INTO `pre_game_jnfarm_card_adv` (`jcaid`, `jctitle`, `jcdesc`, `jcdata`, `jcorder`) VALUES
(1, '$installlang[u103]', '$installlang[u103]', '{\"maxppl\":10,\"maxpp\":3,\"times\":1,\"pkjilv\":50,\"pklvl\":100,\"loselvl\":1,\"pkwinup\":50,\"pkfairup\":0,\"reward\":{\"item\":{\"1\":[\"5\",\"10\",100]}},\"cost\":{\"item\":{\"1\":10}},\"lvlin\":[\"10\",\"15\"]}', 1);

ALTER TABLE `pre_game_jnfarm_card_adv` AUTO_INCREMENT=101;

CREATE TABLE IF NOT EXISTS `pre_game_jnfarm_card_pkreward_sat` (
  `jgrid` int(11) NOT NULL AUTO_INCREMENT,
  `jgprice` text NOT NULL,
  `jgmingcimin` int(11) NOT NULL,
  `jgmingcimax` int(11) NOT NULL,
  `jgjoin` text NOT NULL,
  PRIMARY KEY (`jgrid`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_game_jnfarm_card_pkreward_sat_user` (
  `jgrid` int(11) NOT NULL AUTO_INCREMENT,
  `jgmc` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `fordate` int(11) NOT NULL,
  `taken` int(11) NOT NULL,
  PRIMARY KEY (`jgrid`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_game_jnfarm_card_pkreward_tue` (
  `jgrid` int(11) NOT NULL AUTO_INCREMENT,
  `jgprice` text NOT NULL,
  `jgmingcimin` int(11) NOT NULL,
  `jgmingcimax` int(11) NOT NULL,
  `jgjoin` text NOT NULL,
  PRIMARY KEY (`jgrid`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_game_jnfarm_card_pkreward_tue_user` (
  `jgrid` int(11) NOT NULL AUTO_INCREMENT,
  `jgmc` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `fordate` int(11) NOT NULL,
  `taken` int(11) NOT NULL,
  PRIMARY KEY (`jgrid`)
) ENGINE=MyISAM;

INSERT INTO `pre_game_jnfarm_card_pkreward_sat` (`jgrid`, `jgprice`, `jgmingcimin`, `jgmingcimax`, `jgjoin`) VALUES
(1, '{\"item\":{\"3\":20}}', 3, 5, '{\"item\":{\"1\":10,\"3\":3}}'),
(2, '{\"item\":{\"1\":100,\"2\":50,\"3\":50}}', 1, 1, '{\"item\":{\"1\":10,\"3\":3}}'),
(3, '{\"item\":{\"1\":80,\"2\":30,\"3\":30}}', 2, 2, '{\"item\":{\"1\":10,\"3\":3}}');
	
INSERT INTO `pre_game_jnfarm_card_pkreward_tue` (`jgrid`, `jgprice`, `jgmingcimin`, `jgmingcimax`, `jgjoin`) VALUES
(1, '{\"item\":{\"3\":20}}', 3, 5, '{\"item\":{\"1\":10,\"3\":3}}'),
(2, '{\"item\":{\"1\":100,\"2\":50,\"3\":50}}', 1, 1, '{\"item\":{\"1\":10,\"3\":3}}'),
(3, '{\"item\":{\"1\":80,\"2\":30,\"3\":30}}', 2, 2, '{\"item\":{\"1\":10,\"3\":3}}');

COMMIT;

EOF;
//ALTER TABLE  `pre_game_jnsango_tlog` ENGINE = INNODB;
runquery($sql);

$finish = TRUE;
?>