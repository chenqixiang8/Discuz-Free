<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
};
global $_G;
$jn = 'jnfarm';
require DISCUZ_ROOT.'source/plugin/'.$jn.'/config.php';
if (!$_G['uid']) showmessage('not_loggedin','',array(), array('login' => true));
$geturl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") ."://$_SERVER[HTTP_HOST]";
require DISCUZ_ROOT.'source/plugin/'.$jn.'/module/func.php';

$useragent=$_SERVER['HTTP_USER_AGENT'];
if(preg_match('/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i',$useragent)||preg_match('/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i',substr($useragent,0,4))){
	$inmobile = 1;
}
$imgurl = 'source/plugin/'.$jn.'/template/images/';
$dolist = explode(',',$jnc['garray']);
$servertime = date("m/d/Y H:i:s");
$g_adminids = explode('|',$jnc['adminids']);//����ԱȨ��
if($sysinfo['setdata']['newtili'] <= '0'){
	if(!in_array($_G['uid'],$g_adminids)){
		showmessage("$jn:s137");
	}else{
		showmessage("$jn:s137",'plugin.php?id='.$jn.':admincp'.$jn);
	}
}
$userinfo = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_user')." WHERE uid = '".$_G['uid']."'");
if(file_exists(DISCUZ_ROOT.'source/plugin/'.$jn.'/module/invite.php')){
	$inviteon = '1';
}
if(in_array($_G['uid'],$g_adminids)){
	if(file_exists(DISCUZ_ROOT.'source/plugin/'.$jn.'/module/admincheck.php')){
		require DISCUZ_ROOT.'source/plugin/'.$jn.'/module/admincheck.php';
	}
}
if(file_exists(DISCUZ_ROOT.'source/plugin/'.$jn.'/module/guild.php')){
	$guildon = '1';
}
if(file_exists(DISCUZ_ROOT.'source/plugin/'.$jn.'/module/card.php')){
	$cardon = '1';
}
if($cardon == '1'){
	$c = count($sysinfo['setdata']['card']);
	if($c <= 0){
		if(in_array($_G['uid'],$g_adminids)){
			showmessage("$jn:s402","plugin.php?id=$jn:admincp$jn&do=card");
		}else{
			showmessage("$jn:s402");
		}
		
	}
}
if($guildon == '1'){
	$c = dintval($sysinfo['setdata']['guildset']['mpl']);
	if($c <= 0){
		if(in_array($_G['uid'],$g_adminids)){
			showmessage("$jn:s381","plugin.php?id=$jn:admincp$jn&do=guild");
		}else{
			showmessage("$jn:s381");
		}
		
	}
}

if($_GET['do'] == 'autocheck' && $_GET['formhash'] == $_G['formhash']){
	require DISCUZ_ROOT.'source/plugin/'.$jn.'/module/autocheck.php';
}
if($_GET['newuser'] == 'true' && !$userinfo['juid']){
	if($_GET['formhash'] == $_G['formhash']){
		$data = array();
		if($inviteon == '1'){
			$code = addslashes($_GET['invitecode']);
			$refuid = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_invite')." WHERE invitecode = '$code'");
			$data['ref'] = $refuid['uid'];
			DB::query("REPLACE INTO ".DB::table('game_jnfarm_invite')." (uid,invitecode) VALUES ('".$_G['uid']."','$pass')");
		}
		$data['uid'] = $_G['uid'];
		$data['createtime'] = $_G['timestamp'];
		$data['username'] = $_G['username'];
		$data['udata'] = '{"data":{"money":0,"farmlvl":1,"sales":0,"income":0,"exp":0,"tili":['.$sysinfo['setdata']['newtili'].','.$sysinfo['setdata']['newtili'].','.$_G['timestamp'].']},"seed":{"1":[1,5]}}';
		C::t('#'.$jn.'#'.$jn.'_user')->insert($data);
		
		$data = array();
		$data['uid'] = $_G['uid'];
		$data['createtime'] = $_G['timestamp'];
		for($x=1;$x<=$sysinfo['setdata']['freeland'];$x++){
			$landdata[$x]['seed'] = 0;
			$landdata[$x]['prodstart'] = 0;
			$landdata[$x]['prodfinish'] = 0;
			$landdata[$x]['type'] = 1;
			$landdata[$x]['weed'] = 0;
			$landdata[$x]['worm'] = 0;
			$landdata[$x]['water'] = 0;
			$landdata[$x]['expired'] = 0;
			$landdata[$x]['oriqty'] = 0;
		}
		$data['fdata'] = json_encode($landdata);
		C::t('#'.$jn.'#'.$jn.'_land')->insert($data);
		
		$data = array();
		$userinfo = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_user')." WHERE uid = '".$_G['uid']."'");
	}
}
if(file_exists(DISCUZ_ROOT.'source/plugin/'.$jn.'/module/directextcredits.php')){
	$directextcreditson = '1';
}
$userinfo['udata'] = json_decode($userinfo['udata'],true);
//��������ǻ��ִ�ͨ��
if($directextcreditson == '1'){
	$userinfo['udata']['data']['money'] = getuserprofile('extcredits'.$jnc['buyext']);
}
$moneyshow = $userinfo['udata']['data']['money'];
if($userinfo['udata']['data']['money'] >= 10000){
	$moneyshow = floor($userinfo['udata']['data']['money']/10000).lang("plugin/$jn","s484");
}
if($userinfo['udata']['data']['money'] >= 100000000){
	$moneyshow = floor($userinfo['udata']['data']['money']/10000).lang("plugin/$jn","s485");
}
//cardadd('suipian',3,30,$_G['uid']);
//v2.1
//Ҫ�������ظ�ʱ��+���� �Ƿ��д��ڵ�ǰ������, ������ڵ�ǰ������, ��������, �Լ��ظ�����ʱ��������������
$cishu = floor(($_G['timestamp']-$userinfo['udata']['data']['tili'][2])/$sysinfo['setdata']['tilihuifu']);
//showmessage($cishu);
if($userinfo['udata']['data']['tili'][0]+$cishu >= $userinfo['udata']['data']['tili'][1]){
	$userinfo['udata']['data']['tili'][0] = $userinfo['udata']['data']['tili'][1];
	$userinfo['udata']['data']['tili'][2] = $_G['timestamp'];
}else{
	//showmessage($cishu);
	//$beza = $cishu-1;
	$userinfo['udata']['data']['tili'][0] = $userinfo['udata']['data']['tili'][0]+$cishu;
	$showtime = $userinfo['udata']['data']['tili'][2]+(($cishu+1)*$sysinfo['setdata']['tilihuifu']);
	$userinfo['udata']['data']['tili'][2] = $userinfo['udata']['data']['tili'][2]+(($cishu)*$sysinfo['setdata']['tilihuifu']);
	
	//���赱ǰ����+��������С����������, ����Ϊʱ�仹û�е�
}
if($userinfo['udata']['data']['tili'][0] == $userinfo['udata']['data']['tili'][1]){
	$tilimsg = lang("plugin/$jn","s138");
}else{
	$tilimsg = lang("plugin/$jn","s139").' '.date("H:i:s",$showtime);
}
$itemforeach = array('seed','fertilize','nitem','tiliitem','fragments');
//����
/*v1.0������ȡ��
$topnotice = explode("\n", str_replace(array("\r\n", "\r"), "\n", $jnc['listnotice']));
$ncount = count($topnotice);
for($t = 0; $t <= $ncount; $t++){
	$thenotice[$t] = explode('|',$topnotice[$t]);
	if(!$thenotice[$t][1]){
		$noticelink[$t] = $thenotice[$t][0];
	}else{
		$noticelink[$t] = '<a href="'.$thenotice[$t][1].'" target="_blank" style="color:yellow">'.$thenotice[$t][0].'</a>';
	}
}*/
//ALLAJAX
$seed = DB::fetch_all("SELECT * FROM ".DB::table('game_jnfarm_item')." WHERE type = 'seed' ORDER BY jsid ASC");
foreach($seed as $sd){
	$sd['sdata'] = json_decode($sd['sdata'],true);
	$sdlist[] = $sd;
}
$sdlist = array_column($sdlist, null, 'jsid'); //��array index key ���� jsid
//fertilize list
$fertilizes = DB::fetch_all("SELECT * FROM ".DB::table('game_jnfarm_item')." WHERE type = 'fertilize' ORDER BY jsid ASC");
foreach($fertilizes as $fe){
	$fe['sdata'] = json_decode($fe['sdata'],true);
	$felist[] = $fe;
}
$felist = array_column($felist, null, 'jsid');

$alltype = DB::fetch_all("SELECT * FROM ".DB::table('game_jnfarm_item')."");
foreach($alltype as $allt){
	$allt['sdata'] = json_decode($allt['sdata'],true);
	$allist[] = $allt;
}
$allist = array_column($allist, null, 'jsid');

//���Ա�ιʳ��
foreach($alltype as $ws){
	$ws['sdata'] = json_decode($ws['sdata'],true);
	if(!$ws['sdata']['canfeed']){
		//unset($ws['sdata']);
		continue;
	}
	$wslist[] = $ws;
}
$wslist = array_column($wslist, null, 'jsid');

//petlist
$pet = DB::fetch_all("SELECT * FROM ".DB::table('game_jnfarm_pet')."");
foreach($pet as $pe){
	$pe['jpdata'] = json_decode($pe['jpdata'],true);
	$plist[] = $pe;
}
$plist = array_column($plist,null,'jpid');

$nextexp = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_level')." WHERE lvl = '".($userinfo['udata']['data']['farmlvl']+1)."'");
if(!$nextexp){
	$theexper = '99';
	$nextexp = 99999999999999999;
}else{
	$theexper = $userinfo['udata']['data']['exp']/$nextexp['expneed']*100;
	$nextexp = $nextexp['expneed'];
}

$arraytop = array('','150','180','210','180','210','240','270','210','240','270','300','330','270','300','330','360','390','330','360','390','420','390','420','450');
$arrayleft = array('','100','45','-10','155','100','45','-10','210','155','100','45','-10','210','155','100','45','-10','210','155','100','45','210','155','100');
//genarate new farm,map


$land = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_land')." WHERE uid = '$_G[uid]'");
$land['fdata'] = json_decode($land['fdata'],true);
for($nf = 1;$nf <= 24; $nf++){
	if($land['fdata'][$nf]['type'] == '2'){
		$landimg = "r-land.svg";
	}else{
		$landimg = "f-land.svg";
	}
	if(!$land['fdata'][$nf]){
		$gmap .= '<div style="position: absolute; top: '.$arraytop[$nf].'px; left: '.$arrayleft[$nf].'px;" id="ok'.$nf.'">
	<div style="position: relative;">
		<div style="position: absolute; width: 100px; left: 15px; top: 1px;">
			<img src="'.$imgurl.$landimg.'" width="100%">
		</div>
		<div style="position: absolute; width: 100px; left: 15px; top: 3px;">
			<img src="'.$imgurl.'kuozhan.png" style="width: 90%;">
		</div>
		<div style="position: absolute; width: 100px; left: 15px; top: 1px;">
			<a data-method="offset" data-type="auto" data-jfid="'.$nf.'" class="thiskuozhan"><div class="isometricbtn"></div></a>
		</div>
	</div>
</div>';
		break;
	}
	
	if($land['fdata'][$nf]['seed'] > '0'){
		if($land['fdata'][$nf]['expired'] < $_G['timestamp']){
			$thisimg[$nf] = 'kuwei.png';
		}else{
			if($land['fdata'][$nf]['weed'] > 0 || $land['fdata'][$nf]['worm'] > 0 || $land['fdata'][$nf]['water'] > 0){
				$death[$nf] = '<div style="position:absolute;bottom:0.8em;left:40px;z-index:99999; width:20px;"><div class="problemani" style="position:relative; width:20px;"><img src="'.$imgurl.'problem.svg" width="20px;"></div></div>';
			}
			$thisimg[$nf] = $sdlist[$land['fdata'][$nf]['seed']]['sdata']['imgurl'];
		}
		$seedimg = '<div style="position: absolute; width: 100px; left: 15px; top: -8px;">
			<img src="'.$imgurl.$thisimg[$nf].'" style="width: 70%;" class="cropimg">
		</div>';//��seed�ʹ���ͼƬ
		$acthis = 'thisfarm';//thisfarm
	}else{
		$seedimg = '';
		$acthis = 'thispop';
	}
	$gmap .= '<div style="position: absolute; top: '.$arraytop[$nf].'px; left: '.$arrayleft[$nf].'px;" id="ok'.$nf.'">
	<div style="position: relative;">
		<div style="position: absolute; width: 100px; left: 15px; top: 1px;">
			<img src="'.$imgurl.$landimg.'" width="100%">'.$death[$nf].'
		</div>
		'.$seedimg.'
		<div style="position: absolute; width: 100px; left: 15px; top: 1px;">
			<a data-method="offset" data-type="auto" data-jfid="'.$nf.'" class="'.$acthis.'"><div class="isometricbtn"></div></a>
		</div>
	</div>
</div>';
}
if(file_exists(DISCUZ_ROOT.'source/plugin/'.$jn.'/module/market.php')){
	$marketon = '1';
}
if(file_exists(DISCUZ_ROOT.'source/plugin/'.$jn.'/module/season.php')){
	$seasonon = '1';
	//���Ҿɵ���������
	if($_GET['friendid'] > 0){
		$checkid = dintval($_GET['friendid']);
	}else{
		$checkid = $_G['uid'];
	}
	$mymedal = DB::fetch_all("SELECT jsid FROM ".DB::table('game_jnfarm_season')." WHERE uid = '$checkid' AND prize = '1' AND getprize = '1'");
	$cjsid = count($mymedal);
	for($c=0;$c<$cjsid;$c++){
		$cjs[$c] = $mymedal[$c]['jsid'];
	}
	
	$getjsid = implode(',',$cjs);
	//echo $getjsid;
	if($getjsid){
		$medal = DB::fetch_all("SELECT * FROM ".DB::table('game_jnfarm_season_set')." WHERE jsid IN ($getjsid)");
		$medalx = 0;
		foreach($medal as $med){
			$med['jdata'] = json_decode($med['jdata'],true);
			if($med['jdata']['firstprizemedal']){
				$med['medal'] = '<div style="display:inline-block; margin-right:10px;" onclick="layer.msg(\''.lang("plugin/$jn","s235").$med['jsid'].lang("plugin/$jn","s236").'\')"><img src="'.$med['jdata']['firstprizemedal'].'" width="50px;"></div>';
				$medalx++;
				if($medalx == '3'){
					break;
				}
			}
			$medallist[] = $med;
		}
	}
	
}
if(file_exists(DISCUZ_ROOT.'source/plugin/'.$jn.'/module/achieve.php')){
	$achieveon = '1';
}
if(file_exists(DISCUZ_ROOT.'source/plugin/'.$jn.'/module/cashout.php')){
	$cashouton = '1';
}
if(file_exists(DISCUZ_ROOT.'source/plugin/'.$jn.'/module/combine.php')){
	$combineon = '1';
}
if(file_exists(DISCUZ_ROOT.'source/plugin/'.$jn.'/module/dailyquest.php')){
	$dailyqueston = '1';
}
if(file_exists(DISCUZ_ROOT.'source/plugin/'.$jn.'/module/admincp/challenge.php')){
	$challengeon = '1';
}
if(file_exists(DISCUZ_ROOT.'source/plugin/'.$jn.'/module/tiliitem.php')){
	$tiliitemon = '1';
}
if(file_exists(DISCUZ_ROOT.'source/plugin/'.$jn.'/module/mall.php')){
	$mallon = '1';
}
if(file_exists(DISCUZ_ROOT.'source/plugin/'.$jn.'/module/vip.php')){
	$vipon = '1';
}

if(file_exists(DISCUZ_ROOT.'source/plugin/'.$jn.'/module/realland.php')){
	$reallandon = '1';
	if(!$sysinfo['setdata']['rlwaterext'] || !$sysinfo['setdata']['rlfertext'] || !$sysinfo['setdata']['rlwaterrate'] || !$sysinfo['setdata']['rlfertrate']){
		if(!in_array($_G['uid'],$g_adminids)){
			showmessage("$jn:s198");
		}else{
			showmessage("$jn:s198",'plugin.php?id='.$jn.':admincp'.$jn.'&do=realland&ac=topset');
		}
	}
}
if(file_exists(DISCUZ_ROOT.'source/plugin/'.$jn.'/module/pet.php')){
	$peton = '1';
}else{
	$peton = '0';
}
if(file_exists(DISCUZ_ROOT.'source/plugin/'.$jn.'/module/magappredirect.php')){
	$magappredirecton = '1';
	require DISCUZ_ROOT.'source/plugin/'.$jn.'/module/magappredirect.php';
}
if(file_exists(DISCUZ_ROOT.'source/plugin/'.$jn.'/module/magapp.php')){
	if(!$sysinfo['setdata']['sitesituationgap'] || !$sysinfo['setdata']['sitesituationtimecheck']){
		if(!in_array($_G['uid'],$g_adminids)){
			showmessage("$jn:s160");
		}else{
			showmessage("$jn:s160",'plugin.php?id='.$jn.':admincp'.$jn);
		}
	}
	$magappon = '1';
	require DISCUZ_ROOT.'source/plugin/'.$jn.'/module/magapp.php';
}
if(file_exists(DISCUZ_ROOT.'source/plugin/'.$jn.'/module/qianfanapp.php')){
	$qianfanappon = '1';
	if(!$sysinfo['setdata']['sitesituationgap'] || !$sysinfo['setdata']['sitesituationtimecheck']){
		if(!in_array($_G['uid'],$g_adminids)){
			showmessage("$jn:s160");
		}else{
			showmessage("$jn:s160",'plugin.php?id='.$jn.':admincp'.$jn);
		}
		if(!$jnc['qianfanweb'] || !$jnc['qianfantoken']){
			showmessage("$jn:s313");
		}
	}
	require DISCUZ_ROOT.'source/plugin/'.$jn.'/module/qianfanapp.php';
	//userinfo ����� ��Ҵ�ͨ, ������ ��ҳ�ֵ�ȵ�, ����Ҫ����load����ҷ���, 
	//ǧ����Ҫ��, Ǯ������, ���Ǽ����ǳ�ֵ, �ǵ�û��ϵ
	if(file_exists(DISCUZ_ROOT.'source/plugin/'.$jn.'/module/qianfanjinbi.php')){
		if(!$jnc['qianfanjinbiin'] || !$jnc['qianfanjinbiout']){
			showmessage("$jn:s314");
		}
		$qianfanjinbion = 1;
	}
	
}
if(!$expandcost){
	$hideexpand = '1';
}
if($_GET['do'] == 'more'){
	include template($jn.':'.$jn.'_normal');
	exit;
}
if($_GET['do']){
	$doarray = array('ajax','expandland','normal','topup','shop','store','plantseed','harvest','ranklist','neighbours','usefertilize','market','achieve','cashout','combine','situation','pet','dailyquest','realland','challenge','invite','season','tiliitem','mall','admincheck','vip','guild','card');
	if(file_exists(DISCUZ_ROOT.'source/plugin/'.$jn.'/module/reallanddirect.php')){//����
		$reallanddirecton = '1';
		$doarray = array('realland','dailyquest','challenge','invite');
	}
	if(!in_array($_GET['do'],$doarray)){
		showmessage("$jn:s009");
	}else{
		if(file_exists(DISCUZ_ROOT.'source/plugin/'.$jn.'/module/'.addslashes($_GET['do']).'.php')){
			require DISCUZ_ROOT.'source/plugin/'.$jn.'/module/'.addslashes($_GET['do']).'.php';
		}else{
			showmessage('Error');
		}
	}
}
if(file_exists(DISCUZ_ROOT.'source/plugin/'.$jn.'/module/reallanddirect.php')){
	$reallanddirecton = '1';
	require DISCUZ_ROOT.'source/plugin/'.$jn.'/module/reallanddirect.php';
	include template('jnfarm:jnfarm_reallanddirect');
	exit;
}
include template('diy:'.$jn, 0, 'source/plugin/'.$jn.'/template');
?>