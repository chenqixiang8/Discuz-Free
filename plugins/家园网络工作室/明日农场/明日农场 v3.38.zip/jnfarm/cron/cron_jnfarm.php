<?php
//cronname:JNFARM
//week:
//day:
//hour:00
//minute:0

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
};
global $_G;
loadcache('plugin');
$jnconfig = $_G['cache']['plugin']['jnfarm'];

//DB::query("TRUNCATE TABLE ".DB::table('game_jnsango_tlog')."");

//����ظ�����
//DB::query("UPDATE ".DB::table('game_jnsango_market')." SET mqty = mqty + mrefilltarget WHERE mqty < mreqty");
DB::query("UPDATE ".DB::table('game_jnfarm_user')." SET dailyquest = '', dayquest = '', todayjscs = 0, pktime = 0, todaypkid = ''");
DB::query("UPDATE ".DB::table('game_jnfarm_mall')." SET dailyuid = ''");
/*if(file_exists(DISCUZ_ROOT.'source/plugin/jnfarm/module/cashout.php')){
	echo 'haha';
}*/
?>