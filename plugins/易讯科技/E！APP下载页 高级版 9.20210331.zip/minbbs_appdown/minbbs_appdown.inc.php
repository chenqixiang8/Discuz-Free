<?php
/**
 *	Copyright (c) 2021 by dism.taobao.com
 *	Version: 1.20190726
 *	Identifier:minbbs_appdown
 *  ���²����http://t.cn/Aiux1Jx1
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$minbbs = $_G['cache']['plugin']['minbbs_appdown'];
$mod = trim($_GET['mod']);
$mod = in_array($mod,array('qrcode')) ? $mod : "index";
require_once libfile("minbbs_" . $mod, 'plugin/minbbs_appdown/module');
?>