<?php
/**
 *	Copyright (c) 2021 by dism.taobao.com
 *	Version: 1.20190726
 *	Identifier:minbbs_appdown
 *  ���²����http://t.cn/Aiux1Jx1
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$url = $_GET['url'] ? $_GET['url'] : urlencode($_G['siteurl']);
require_once DISCUZ_ROOT . 'source/plugin/mobile/qrcode.class.php';
$size = intval($_GET['size']) ? intval($_GET['size']) : 10;
if (class_exists('QRcode')) {
	QRcode::png($_GET['url'], false, 0, $size, 2);
	exit;
}
//From: di'.'sm.t'.'aoba'.'o.com
?>