<?php
/**
 *	Copyright (c) 2021 by dism.taobao.com
 *	Version: 1.20190726
 *	Identifier:minbbs_appdown
 *  ���²����http://t.cn/Aiux1Jx1
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
loadcache('minbbs_appdownnav', true);
$navtitle = $minbbs['navtitle'];
$membercount = DB::result(DB::query("SELECT count(*) FROM ".DB::table('common_member').""))+$minbbs['data'];
include template('minbbs_appdown:minbbs_index');

?>