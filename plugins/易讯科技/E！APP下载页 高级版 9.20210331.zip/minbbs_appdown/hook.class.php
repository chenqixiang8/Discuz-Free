<?php
/**
 *	Copyright (c) 2021 by dism.taobao.com
 *  ���²����http://t.cn/Aiux1Jx1
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_minbbs_appdown {
	function common(){
		global $_G;
		loadcache('minbbs_appdownnav', true);
		$minbbs = $_G['cache']['plugin']['minbbs_appdown'];
		$minbbs['value'] = str_replace("\r\n", "\n", $minbbs['value']);
        $minbbs['value'] = explode("\n", $minbbs['value']);
		
		foreach ($minbbs['value'] as $key => $words) {
            if(strpos($_SERVER['REQUEST_URI'], $words) !== false){
                $checkwords = 1;
                break;
            }
        }

		if(($_G['groupid'] == 1 && $minbbs['admincp']) || $checkwords){
            $isadmin = '1';
        }
		if(empty($_G['mobile']) && empty($isadmin) && $minbbs['closepc']){
			$codeurl = urlencode($minbbs['codeurl']);
			$navtitle = $minbbs['navtitle'];
			$membercount = DB::result(DB::query("SELECT count(*) FROM ".DB::table('common_member').""))+$minbbs['data'];
			
			include template('minbbs_appdown:minbbs_index');
			exit;
		}
	}
}

class mobileplugin_minbbs_appdown {
	function common(){
		global $_G;
		$minbbs = $_G['cache']['plugin']['minbbs_appdown'];
		$minbbs['value'] = str_replace("\r\n", "\n", $minbbs['value']);
        $minbbs['value'] = explode("\n", $minbbs['value']);
		
		foreach ($minbbs['value'] as $key => $words) {
            if(strpos($_SERVER['REQUEST_URI'], $words) !== false){
                $checkwords = 1;
                break;
            }
        }

		if(($_G['groupid'] == 1 && $minbbs['admincp']) || $checkwords){
            $isadmin = '1';
        }
		if(empty($isadmin) && $minbbs['closewap']){
			$codeurl = urlencode($minbbs['codeurl']);
			$navtitle = $minbbs['navtitle'];
			$membercount = DB::result(DB::query("SELECT count(*) FROM ".DB::table('common_member').""))+$minbbs['data'];
			include template('minbbs_appdown:minbbs_index');
			exit;
		}
	}
}
//From: di'.'sm.t'.'aoba'.'o.com
?>