<?php
/**
 *	Copyright (c) 2021 by dism.taobao.com
 *  ���²����http://t.cn/Aiux1Jx1
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_minbbs_appdown_nav` (
  `id` mediumint(8) NOT NULL AUTO_INCREMENT,
  `displayorder` mediumint(8) NOT NULL,
  `uid` mediumint(10) NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `blank` tinyint(10) NOT NULL DEFAULT '0',
  `display` tinyint(10) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
);
EOF;
runquery($sql);
$finish = TRUE;
?>
