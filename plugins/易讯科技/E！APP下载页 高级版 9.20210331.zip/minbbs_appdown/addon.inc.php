<?php
/**
 *	Copyright (c) 2021 by dism.taobao.com
 *	Version: 2.20190713
 *	Identifier:minbbs_appdown
 *  ���²����http://t.cn/Aiux1Jx1
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
echo dfsockopen('https://www.yixunyun.cc/geturl.php?url='.urlencode($_G['siteurl']).'&pluginname='.$plugin['identifier']);

exit();
?>