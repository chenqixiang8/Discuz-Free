<?php
/**
 *	Copyright (c) 2021 by dism.taobao.com
 *  ���²����http://t.cn/Aiux1Jx1
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$sql = <<<EOF
DROP TABLE IF  EXISTS `pre_minbbs_appdown_nav`;
EOF;

runquery($sql);
$finish = TRUE;
?>
