<?php

/**
 *	Copyright (c) 2021 by dism.taobao.com
 *  ���²����http://t.cn/Aiux1Jx1
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$langs = &$scriptlang['minbbs_appdown'];

if (!submitcheck('submit')) {
	$navlist = DB::fetch_all("SELECT * FROM %t ORDER BY displayorder", array("minbbs_appdown_nav"));
	showformheader('plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod=admincp_nav', 'navsubmit');
	showtableheader($langs['nav_navtitle']);
	showsubtitle(array('', 'display_order', $langs['nav_title'], $langs['nav_url'], $langs['nav_blank'], $langs['nav_display'], '' ), 'header', array('', '', ''));
	foreach ($navlist as $value) {
		showtablerow('class="data"', array('class="td25"', '', '', '', '', '', 'class="td25"'), array(
			'<input type="checkbox" name="delete['.$value['id'].']" value="" class="checkbox">',
            '<input type="text" class="td25" name="displayorder['.$value['id'].']" value="'.$value['displayorder'].'">',
            '<input type="text" class="" name="title['.$value['id'].']" value="'.$value['title'].'">',
            '<input type="text" class="" name="url['.$value['id'].']" value="'.$value['url'].'">',
			'<select name="blank['.$value['id'].']"><option value="1" '.($value['blank'] == 1 ? 'selected': '').'>'.$langs['nav_off'].'</option><option value="2" '.($value['blank'] == 2 ? 'selected': '').'>'.$langs['nav_on'].'</option></select>',
			'<select name="display['.$value['id'].']"><option value="1" '.($value['display'] == 1 ? 'selected': '').'>'.$langs['nav_on'].'</option><option value="2" '.($value['display'] == 2 ? 'selected': '').'>'.$langs['nav_off'].'</option></select>',
			'<input type="hidden" name="id['.$value['id'].']" value="'.$value['id'].'">',
        ));
	}
	showtablerow('id="addnew"', array(''), array("", "<div><a href=\"###\" onclick=\"addnewrecord(this)\" class=\"addtr\">".$langs['nav_add']."</a></div>", "", "", "", ""));
	showsubmit('submit','submit','del','', '');
	showtablefooter(); /*dism��taobao��com*/
	showformfooter(); /*Dism��taobao _com*/
    print <<<EOF
<script type="text/javascript">
	var rowtypedata = [
		[
			[1,'', ''], 
			[1,'<input type="text" class="td25" name="newdisplayorder[]" value="0" />', ''],
			[1,'<input type="text" class="" name="newtitle[]" />', ''],
			[1,'<input type="text" class="" name="newurl[]"/>', ''], 
			[1,'<input type="checkbox" class="checkbox" name="newblank[]"/>', ''], 
			[1,'<input type="checkbox" class="checkbox" name="newdisplay[]"/>', ''], 
			[1, '<div><a href="javascript:;" class="deleterow" onClick="deleterow(this)">$langs[nav_delete]</a></div>', '']
		],
	];
	var newrows = document.getElementsByClassName("data").length;	
	function addnewrecord(v) {
		newrows++;
		addrow(v, 0);
	}
</script>
EOF;
}else{
	if (is_array($_GET['delete'])) {
		foreach ($_GET['delete'] as $key => $delete) {
			if (empty($delete)) {
				continue;
			}
			DB::query("DELETE FROM ".DB::table('minbbs_appdown_nav')." WHERE id = ".$delete);
		}
	}
	if (is_array($_GET['title']) && is_array($_GET['url'])) {
        foreach ($_GET['title'] as $key => $title) {
            if (empty($title)) {
                continue;
            }
            DB::update('minbbs_appdown_nav', array('displayorder' => $_GET['displayorder'][$key], 'title' => $title, 'url' => $_GET['url'][$key], 'blank' => $_GET['blank'][$key], 'display' => $_GET['display'][$key]), array('id'=>$_GET['id'][$key]));
        }
    }
	if(is_array($_GET['newtitle'])){
		$data = array();
		foreach ($_GET['newtitle'] as $key => $newtitle) {
			if (empty($newtitle)) {
                continue;
            }
			DB::insert('minbbs_appdown_nav', array('displayorder' => $_GET['newdisplayorder'][$key], 'title' => $newtitle, 'url' => $_GET['newurl'][$key], 'blank' => $_GET['newblank'][$key], 'display' => $_GET['newdisplay'][$key]));
		}
	}
	$data = DB::fetch_all("SELECT * FROM %t WHERE display = 1 ORDER BY displayorder", array("minbbs_appdown_nav"));
	savecache('minbbs_appdownnav', $data);
	cpmsg($langs['nav_success'], 'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod=admincp_nav', 'succeed');
}
//From: di'.'sm.t'.'aoba'.'o.com
?>