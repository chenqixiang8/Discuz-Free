(function($){
	$(".incremental-counter").incrementalCounter();
})(jQuery);