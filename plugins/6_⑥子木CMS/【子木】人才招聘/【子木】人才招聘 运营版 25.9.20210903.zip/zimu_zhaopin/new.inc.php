<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

header('Access-Control-Allow-Origin:*');
header('Access-Control-Allow-Headers:*');

    $model = addslashes($_GET['model']);
    $model = !empty($model) ? $model : 'new_newindex';

$mytoken = $_SERVER['HTTP_MYTOKEN'];
$client_type = $_SERVER['HTTP_CLIENTTYPE'];
$tocityid = $_SERVER['HTTP_TOCITYID'];
$tocityid2 = $_SERVER['HTTP_TOCITYID2'];
if($mytoken){
    $_GET['token'] = $mytoken;
}

    if($_SERVER['REQUEST_METHOD'] == 'OPTIONS'){
        echo 'ok';exit();
    }

require_once DISCUZ_ROOT . './source/plugin/zimu_zhaopin/module/new/new_config.php';

    use think\Db;

if ($model) {

    if($_SERVER['REQUEST_METHOD'] != 'OPTIONS' && ( $model=='toindex' || $model=='jobs' || $model=='viewjob' || $model=='resume' || $model=='viewresume' || $model=='qiye' || $model=='viewcom' || $model=='news' || $model=='viewnews' || $model=='jobfair_online' || $model=='mycompany' || $model=='mypersonal' || $model=='toindex' ) ){
        Db::name('zimu_zhaopin_setting')->where([['id','>',0]])->inc('views', 1)->update();
    }

    require_once DISCUZ_ROOT . './source/plugin/zimu_zhaopin/module/new/new_' . $model . '.inc.php';
    
}