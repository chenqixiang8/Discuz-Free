<?php
    namespace Laofu\Image;
    class Poster {

        public $errMsg = '';
        public $config = [];
        private $backGroundImage = '';
        private $fontPath = '';
        private $bgImageData = null;
        private $format='png';

        public function __construct($config=[],$font=false){
            if(!$font){
                $this->fontPath=dirname(__FILE__).'/../static/font/';
            }else{
                $this->fontPath=$font;
            }
            $this->backGroundImage = isset($config['bg']) ? $config['bg'] : '';
            $this->format=isset($config['format'])?$config['format']:'png';
            $this->quality=isset($config['quality'])?$config['quality']:90;
            $imageDefault = array(
                'url' => '', //ͼƬ·��
                'left' => 0,//��߾�
                'top' => 0,//�ϱ߾�
                'right' => 0,//�б߾�
                'bottom' => 0,//�±߾�
                'width' => 0,//��
                'height' => 0,//��
                'radius' => 0, //Բ�Ƕ��������ֵΪ��ʾ���ȵ�һ��
                'opacity' => 100//͸����
            );
            $textDefault = array(
                'text' => '',//��ʾ�ı�
                'left' => 0,//��߾�
                'top' => 0,//�ϱ߾�
                'width' => 0, //�ı�����ȣ����ú��ʵ�����ֻ���
                'fontSize' => 32, //�ֺ�
                'fontPath' => 'Alibaba-PuHuiTi-Regular.ttf', //�����ļ�
                'fontColor' => '255,255,255', //������ɫ
                'angle' => 0, //��б�Ƕ�
            );

            if (isset($config['image']) && $config['image']) {
                foreach ($config['image'] as $k => $v) {
                    $this->config['image'][$k] = array_merge($imageDefault, $v);
                }
            } else {
                $this->config['image'] = array();
            }
            if (isset($config['text']) && $config['text']) {
                foreach ($config['text'] as $k => $v) {
                    $this->config['text'][$k] = array_merge($textDefault, $v);
                }
            } else {
                $this->config['text'] = array();
            }
        }

        /*
         * �ϲ����ɺ���
         * @param $fileName string ָ�����ɵ�ͼƬ·����������ֱ�ӷ���ͼƬ������
         * @return string or bool ͼƬ���������ߴ������״̬
         */
        public function make($fileName = ''){
            $formats=['png'=>'imagepng','jpg'=>'imagejpeg','gif'=>'imagegif'];
            if(!in_array($this->format,array_keys($formats))){
                $this->errMsg = '���ͼƬ��ʽ����';
                return false;
            }
            $this->errMsg = null;
            if (!$this->backGroundImage) {
                $this->errMsg = '����������Ч�ĺ�������ͼƬ';
                return false;
            }
            //��������
            if (!$this->bgImageData) {
                $bgRs=$this->getImgData($this->backGroundImage);
                if(!$bgRs){
                    return false;
                }
                $backgroundInfo = $bgRs['info'];
                $bgData = $bgRs['res'];
                $backgroundWidth = imagesx($bgData);    //��������
                $backgroundHeight = imagesy($bgData);   //�����߶�
                $this->bgImageData = imageCreatetruecolor($backgroundWidth, $backgroundHeight);
                //����͸������ɫ����Ҫ127��������������0-255����Ϊ�κ���ɫ��͸������͸��
                $transparent = imagecolorallocatealpha($this->bgImageData, 0, 0, 0, 127);
                //ָ����ɫΪ͸��
                imagecolortransparent($this->bgImageData, $transparent);
                //����͸����ɫ
                imagesavealpha($this->bgImageData, true);
                //���ͼƬ��ɫ
                imagefill($this->bgImageData, 0, 0, $transparent);
                imagecopyresampled($this->bgImageData, $bgData, 0, 0, 0, 0, $backgroundWidth, $backgroundHeight, $backgroundWidth, $backgroundHeight);
            }
            $bgImgData = $this->bgImageData;

            //����ͼƬ
            if ($this->config['image']) {
                foreach ($this->config['image'] as $key => $val) {
                    $imgRs=$this->getImgData($val);
                    if(!$imgRs){
                        return false;
                    }
                    $res=$imgRs['res'];
                    $info=$imgRs['info'];
                    imagesavealpha($res, true); //�������Ҫ;
                    $resWidth = $info[0];
                    $resHeight = $info[1];

                    if ($val['width'] > $resWidth) {
                        $val['width'] = $resWidth;
                    }
                    if ($val['height'] > $resHeight) {
                        $val['height'] = $resHeight;
                    }
                    if($val['width']==$val['height']){
                        $resWidth = $resHeight = $resWidth >= $resHeight ? $resHeight : $resWidth;
                    }

                    if ($val['radius']) {
                        if ($val['radius'] > round($resWidth / 2)) {
                            $val['radius'] = round($resWidth / 2);
                        }
                        $canvas = $this->setRadiusImage($res, $resWidth, $resHeight, $val['width'], $val['height'], $val['radius']);
                    } else {
                        $canvas = imagecreatetruecolor($val['width'], $val['height']);
                        //����͸������ɫ����Ҫ127��������������0-255����Ϊ�κ���ɫ��͸������͸��
                        $transparent = imagecolorallocatealpha($canvas, 0, 0, 0, 127);
                        //ָ����ɫΪ͸��
                        imagecolortransparent($canvas, $transparent);
                        //����͸����ɫ
                        imagesavealpha($canvas, true);
                        //���ͼƬ��ɫ
                        imagefill($canvas, 0, 0, $transparent);
                        //�ؼ�������������Ŀ����Դ��Դ��Ŀ����Դ�Ŀ�ʼ����x,y, Դ��Դ�Ŀ�ʼ����x,y,Ŀ����Դ�Ŀ���w,h,Դ��Դ�Ŀ���w,h��
                        imagecopyresampled($canvas, $res, 0, 0, 0, 0, $val['width'], $val['height'], $resWidth, $resHeight);
                    }
                    //$val['left'] = $val['left'] < 0 ? $backgroundWidth - abs($val['left']) - $val['width'] : $val['left'];
                    if ($val['left'] < 0) {
                        $val['left'] = ceil($backgroundWidth - $val['width']) / 2;
                    }
                    $val['top'] = $val['top'] < 0 ? $backgroundHeight - abs($val['top']) - $val['height'] : $val['top'];
                    //����ͼ��
                    imagecopymerge($bgImgData, $canvas, $val['left'], $val['top'], $val['right'], $val['bottom'], $val['width'], $val['height'], $val['opacity']); //���ϣ��ң��£����ȣ��߶ȣ�͸����
                }
            }

            //��������
            if ($this->config['text']) {
                foreach ($this->config['text'] as $key => $val) {
                    $fontPath = $this->fontPath . $val['fontPath'];
                    if ($val['width']) {
                        $val['text'] = $this->stringAutoWrap($val['text'], $val['fontSize'], $val['angle'], $fontPath, $val['width']);
                    }
                    list($R, $G, $B) = explode(',', $val['fontColor']);
                    $fontColor = imagecolorallocate($bgImgData, $R, $G, $B);
                    //$val['left'] = $val['left'] < 0 ? $backgroundWidth - abs($val['left']) : $val['left'];
                    $text = $this->autowrap($val['fontSize'], 0, $fontPath, $val['text'], $backgroundWidth);
                    if ($val['left'] < 0) {
                        $fontBox = imagettfbbox($val['fontSize'], 0, $fontPath, $text);
                        $val['left'] = ceil(($backgroundWidth - $fontBox[2]) / 2);
                    }
                    if($val['align'] == 'center'){
                        $fontBox = imagettfbbox($val['fontSize'], 0, $fontPath, $text);
                        $val['left'] = ceil($val['width']/2+$val['left']-$fontBox[2]/2);
                    }
                    $val['top'] = $val['top'] < 0 ? $backgroundHeight - abs($val['top']) : $val['top'];
                    imagettftext($bgImgData, $val['fontSize'], $val['angle'], $val['left'], $val['top'], $fontColor, $fontPath, $val['text']);
                }
            }
            $imgFn=$formats[$this->format];
            if($this->format=='png'){
                $this->quality=intval(($this->quality)/10);
            }
            if ($fileName) {
                $res = $imgFn($bgImgData, $fileName, $this->quality); //���浽����
                ImageDestroy($bgImgData);
                if (!$res) {
                    $this->errMsg = 'ͼƬ����ʧ��';
                    return false;
                } else {
                    return true;
                }
            } else {
                ob_start();
                $imgFn($bgImgData,'', $this->quality);
                $content = ob_get_contents();
                ob_end_clean();
                ImageDestroy($bgImgData);
                if (!$content) {
                    $this->errMsg = 'ͼƬ���ݻ�ȡʧ��';
                    return false;
                }
                return $content;
            }
        }

        //����Բ��ͼƬ
        private function setRadiusImage(&$imgData, $resWidth, $resHeight, $w, $h, $radius = 10) {
            $img = imagecreatetruecolor($w, $h);
            //����͸������ɫ����Ҫ127��������������0-255����Ϊ�κ���ɫ��͸������͸��
            $transparent = imagecolorallocatealpha($img, 0, 0, 0, 127);
            //ָ����ɫΪ͸��
            imagecolortransparent($img, $transparent);
            //����͸����ɫ
            imagesavealpha($img, true);
            //���ͼƬ��ɫ
            imagefill($img, 0, 0, $transparent);
            imagecopyresampled($imgData, $imgData, 0, 0, 0, 0, $w, $h, $resWidth, $resHeight); //��ԭͼ���ųߴ����»��������
            $r = $radius; //Բ �ǰ뾶
            for ($x = 0; $x < $w; $x++) {
                for ($y = 0; $y < $h; $y++) {
                    $rgbColor = imagecolorat($imgData, $x, $y);
                    if (($x >= $radius && $x <= ($w - $radius)) || ($y >= $radius && $y <= ($h - $radius))) {
                        //�����Ľǵķ�Χ��,ֱ�ӻ�
                        imagesetpixel($img, $x, $y, $rgbColor);
                    } else {
                        //���Ľǵķ�Χ��ѡ��
                        //����
                        $yx1 = $r; //Բ��X����
                        $yy1 = $r; //Բ��Y����
                        if (((($x - $yx1) * ($x - $yx1) + ($y - $yy1) * ($y - $yy1)) <= ($r * $r))) {
                            imagesetpixel($img, $x, $y, $rgbColor);
                        }
                        //����
                        $yx2 = $w - $r; //Բ��X����
                        $yy2 = $r; //Բ��Y����
                        if (((($x - $yx2) * ($x - $yx2) + ($y - $yy2) * ($y - $yy2)) <= ($r * $r))) {
                            imagesetpixel($img, $x, $y, $rgbColor);
                        }
                        //����
                        $yx3 = $r; //Բ��X����
                        $yy3 = $h - $r; //Բ��Y����
                        if (((($x - $yx3) * ($x - $yx3) + ($y - $yy3) * ($y - $yy3)) <= ($r * $r))) {
                            imagesetpixel($img, $x, $y, $rgbColor);
                        }
                        //����
                        $yx4 = $w - $r; //Բ��X����
                        $yy4 = $h - $r; //Բ��Y����
                        if (((($x - $yx4) * ($x - $yx4) + ($y - $yy4) * ($y - $yy4)) <= ($r * $r))) {
                            imagesetpixel($img, $x, $y, $rgbColor);
                        }
                    }
                }
            }
            return $img;
        }

        //�����Զ�����
        private function stringAutoWrap($string, $fontsize, $angle, $fontface, $width) {
            $content = '';
            $arr = array();
            preg_match_all("/./u", $string, $arr);
            $letter = $arr[0];
            foreach ($letter as $l) {
                $newStr = $content . $l;
                $box = imagettfbbox($fontsize, $angle, $fontface, $newStr);
                if (($box[2] > $width) && ($content !== '')) {
                    $content .= PHP_EOL;
                }
                $content .= $l;
            }
            return $content;
        }
        private function autowrap($fontsize, $angle, $fontface, $string, $width)
        {
            $content = "";
            for ($i = 0; $i < mb_strlen($string); $i++) {
                $letter[] = mb_substr($string, $i, 1);
            }

            foreach ($letter as $l) {
                $teststr = $content . " " . $l;
                $testbox = imagettfbbox($fontsize, $angle, $fontface, $teststr);
                if (($testbox[2] > $width) && ($content !== "")) {
                    $content .= "\n";
                }
                $content .= $l;
            }
            return $content;
        }
        //��������ͼƬ��֧�����û�����header����
        private function downImg($url,$timeout=120,$header=[]){
            global $_G;
            $header['user-agent'] = isset($header['user-agent'])?$header['user-agent']:'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1547.66 Safari/537.36';
            $header['referer'] = $_G['siteurl'];
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            $file = curl_exec($ch);
            curl_close($ch);
            if(!$file){
                $file = file_get_contents($url);
                if(!$file){
                    return false;
                }
            }
            return $file;
        }

        /*
         * ��ȡitem�����õ�ͼƬ��Ϣ
         * @param $val Array or String ͼƬ��Ϣ
         * @return Array infoͼƬ�ߴ� resͼƬ��������Ϣ
         */
        private function getImgData($val){
            if(!is_array($val)){
                $val=['url'=>$val];
            }
            if(preg_match('/^http(.*)$/i',$val['url'])){
                $timeout=isset($val['timeout'])?$val['timeout']:30;
                $header=isset($val['header'])?$val['header']:[];
                $stream=$this->downImg($val['url'],$timeout,$header);
                if(!$stream){
                    $this->errMsg = 'ͼƬ��' . $val['url'] . '������ʧ��';
                    return false;
                }
                $info = getimagesizefromstring($stream);
                $res = imagecreatefromstring($stream);
                return ['info'=>$info,'res'=>$res];
            }else{
                if (!is_file($val['url'])) {
                    $this->errMsg = 'ͼƬ��' . $val['url'] . '��������';
                    return false;
                }
                $info = getimagesize($val['url']);
                $function = 'imagecreatefrom' . image_type_to_extension($info[2], false);
                if (!function_exists($function)) {
                    $this->errMsg = 'ͼƬ��' . $val['url'] . '����ʽ��֧��';
                    return false;
                }
                $res = $function($val['url']);
                return ['info'=>$info,'res'=>$res];
            }
        }
    }
