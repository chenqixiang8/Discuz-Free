<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$baseUrl = rawurldecode(cpurl());
$formUrl = ltrim($baseUrl, 'action=');

if (!submitcheck('operation_submit')) {

    showtagheader('div', 'operation_manage', true);
    showformheader($formUrl);

    showtagheader('div', 'forum_stype', true);
    showtableheader('&#31243;&#24207;&#31532;&#19968;&#27425;&#23433;&#35013;&#38656;&#21021;&#22987;&#21270;&#25968;&#25454;&#12290;&#21518;&#32493;&#28857;&#20987;&#25552;&#20132;&#23558;&#21024;&#38500;&#21407;&#26377;&#22871;&#39184;&#21442;&#25968;&#24182;&#24674;&#22797;&#40664;&#35748;&#12290;');


    showsubmit('operation_submit', 'submit');
    showformfooter(); /*dism_taobao_com*/
    showtagfooter('div');

}else{


$initialization = file_get_contents('http://demo.zimucms.com/source/plugin/zimu_zhaopin/initialization.txt');

if($_G['charset'] == 'utf-8'){
$initialization = diconv($initialization,'gbk','UTF-8');
}

$sql = <<<EOF
DROP TABLE  IF EXISTS pre_zimu_zhaopin_category;
DROP TABLE  IF EXISTS pre_zimu_zhaopin_category_district;
DROP TABLE  IF EXISTS pre_zimu_zhaopin_category_jobs;
DROP TABLE  IF EXISTS pre_zimu_zhaopin_category_major;
DROP TABLE  IF EXISTS pre_zimu_zhaopin_setmeal;
DROP TABLE  IF EXISTS pre_zimu_zhaopin_setmeal_increment;
EOF;

runquery($sql);

$sql = <<<EOF
$initialization
EOF;

$aa = runquery($sql);

echo 'success';

$finish = TRUE;

}