<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if (!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }

    header('Access-Control-Allow-Origin:*');
    header('Access-Control-Allow-Headers:*');
    if($_SERVER['REQUEST_METHOD'] == 'OPTIONS'){
        echo 'ok';exit();
    }
    require_once DISCUZ_ROOT . './source/plugin/zimu_zhaopin/module/new/new_config.php';

    use think\Db;
    $postdata = $old_postdata = file_get_contents('php://input');
    $postdata = json_decode($postdata,true);

    $mytoken = $_SERVER['HTTP_AUTHORIZATION'] ? $_SERVER['HTTP_AUTHORIZATION'] : $_SERVER['HTTP_MYTOKEN'];
    $client_type = $_SERVER['HTTP_CLIENTTYPE'];
    if($mytoken){
        $_GET['token'] = $mytoken;
    }


    $type = addslashes($_GET['type']);
    $type = !empty($type) ? $type : 'dashboard';

    $title = $zmdata['settings']['title'];

    if($_SERVER['REQUEST_METHOD'] != 'OPTIONS' && $type != 'operatelog' && $type != 'menus' && strpos($_SERVER['PHP_SELF'].'?'.$_SERVER['QUERY_STRING'],'op=getdata') == false){
        $token = addslashes($_GET['token']);
        $mytoken2 = explode('uid',$token);
        if($mytoken2[1]=='admin'){
            $operate_log_data['uid'] = 1;
            $operate_log_data['username'] = 'superadmin';
        }else if($mytoken2[1]){
            $isadmin = Db::name('zimu_zhaopin_admin')->where([['id','=',$mytoken2[1]]])->find();
            $operate_log_data['uid'] = $isadmin['id'];
            $operate_log_data['username'] = $isadmin['username'];
        }

        $operate_log_data['type'] = $type;
        $operate_log_data['url'] = $_SERVER['PHP_SELF'].'?'.$_SERVER['QUERY_STRING'];
        $operate_log_data['method'] = $_SERVER['REQUEST_METHOD'];
        $operate_log_data['param'] = zimu_array_utf8tomy($old_postdata);
        $operate_log_data['useragent'] = $_SERVER['HTTP_USER_AGENT'];
        $operate_log_data['ip'] = $_SERVER["REMOTE_ADDR"];
        $operate_log_data['addtime'] = time();
        Db::name('zimu_zhaopin_operate_log')->insert($operate_log_data);
    }

    if($type){

        include DISCUZ_ROOT.'./source/plugin/zimu_zhaopin/module/adminss/adminss_'.$type.'.inc.php';
    }