<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$langfile = DISCUZ_ROOT . './source/plugin/zimu_zhaopin/language.' . currentlang() . '.php';

$includefile = is_file($langfile) ? $langfile : libfile('language', 'plugin/zimu_zhaopin');

include $includefile;

$version = date('YmdH', $_G['timestamp']);

//$version = $_G['timestamp'];

define('ZIMUCMS_PATH', $_G['siteurl'] . 'source/plugin/zimu_zhaopin/');
define('ZIMUCMS_ROOT', dirname(__FILE__));
define('ZIMUCMS_URL', $_G['siteurl'] . 'plugin.php?id=zimu_zhaopin');
define('SITE_URL', $_G['siteurl']);
define('IN_WECHAT', strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false);
define('IN_XIAOYUNAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'Appbyme') !== false);
define('IN_QFAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'QianFan') !== false);
define('IN_MAGAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'MAGAPP') !== false);

if (!$_G['cache']['plugin']){
    loadcache('plugin');
}

    if($_G['uid']>0){
        $mycompany = DB::fetch_first('select * from %t where uid=%d', array(
            'zimu_zhaopin_company_profile',
            $_G['uid']
        ));
        if(!$mycompany){
            $wheresql_iscompany .= " or `admin_uid` LIKE '{$_G['uid']},%' ";
            $wheresql_iscompany .= " or `admin_uid` LIKE '%,{$_G['uid']}' ";
            $is_admin_company = DB::fetch_first('select * from %t where %i order by id desc', array(
                'zimu_zhaopin_company_profile',
                "admin_uid = ".$_G['uid'].$wheresql_iscompany
            ));
            if($is_admin_company){
                $_G['uid'] = $is_admin_company['uid'];
            }
        }
    }

$zmdata = $_G['cache']['plugin']['zimu_zhaopin'];

$setdata = DB::fetch_first('select * from %t order by id desc', array(
        'zimu_zhaopin_setting'
    ));

$zmdata['base'] = $setdata;
$zmdata['settings'] = unserialize($setdata['settings']);

if(!$zmdata['settings']['money_name']){
$zmdata['settings']['money_name'] = $language_zimu['config_php_7'];
}

$company_nologo = $zmdata['settings']['company_nologo_url'] ? $zmdata['settings']['company_nologo_url'] : $_G['siteurl'].'source/plugin/zimu_zhaopin/static/pc/images/company_nologo.jpg';

define('SF_APPID', $zmdata['base']['weixin_appid']);
define('SF_MCHID', $zmdata['settings']['weixin_mchid']);
define('SF_APPSECRET', $zmdata['base']['weixin_appsecret']);
define('SF_WXPAY_KEY', $zmdata['settings']['weixin_mchkey']);



include_once(DISCUZ_ROOT.'source/plugin/zimu_zhaopin/lib/wxpay/lib/WxPay.Config.php');
include_once(DISCUZ_ROOT.'source/plugin/zimu_zhaopin/lib/wxpay/lib/WxPay.Api.php');
include_once(DISCUZ_ROOT.'source/plugin/zimu_zhaopin/lib/wxpay/example/WxPay.JsApiPay.php');
include_once(DISCUZ_ROOT.'source/plugin/zimu_zhaopin/lib/wxpay/example/WxPay.NativePay.php');
include_once(DISCUZ_ROOT.'source/plugin/zimu_zhaopin/lib/wxpay/example/log.php');
include_once(DISCUZ_ROOT.'source/plugin/zimu_zhaopin/lib/wxpay/lib/WxPay.Data.php');


$formhash = $_G['formhash'];

if ($_G['charset'] == 'gbk') {
    $charset = 'gbk';
} elseif ($_G['charset'] == 'utf-8') {
    $charset = 'UTF-8';
} elseif ($_G['charset'] == 'big5') {
    $charset = 'big5';
}

if($_GET['model'] != 'admins' && $zmdata['settings']['change_city'] == 1 && file_exists(DISCUZ_ROOT . './source/plugin/zimu_zhaopin/module/a_change_area.inc.php') && $zmdata['settings']['change_area'] > 0 && $zmdata['settings']['change_area_api']){

require_once DISCUZ_ROOT . './source/plugin/zimu_zhaopin/module/a_change_area.inc.php';

}

function isuid($refererurl='')
{

    global $_G;
    define('IN_XIAOYUNAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'Appbyme') !== false);
    define('IN_QFAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'QianFan') !== false);
    define('IN_MAGAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'MAGAPP') !== false);
    if(!$refererurl){
        $refererurl = $_G['siteurl'] . $_SERVER['REQUEST_URI'];
    }

    if(!checkmobile() && !$_G['uid']){

$zmdata = $_G['cache']['plugin']['zimu_zhaopin'];
$setdata = DB::fetch_first('select * from %t order by id desc', array(
        'zimu_zhaopin_setting'
    ));
$zmdata['base'] = $setdata;
$zmdata['settings'] = unserialize($setdata['settings']);

if($zmdata['settings']['weixin_login_url']){

dheader('Location:' . ZIMUCMS_URL.'&model=login');
    exit();

}

    }
    
    if (IN_MAGAPP && !$_G['uid']){

$mag_paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
    'zimu_zhaopin_parameter2',
    'magapp'
));

$mag_paramter = unserialize($mag_paramter['parameter']);

    }

    if (IN_MAGAPP && !$_G['uid'] && $mag_paramter['magapp_hostname']){
        

        $userAgent = $_SERVER['HTTP_USER_AGENT'];
        $info = strstr($userAgent, "MAGAPPX");
        $info=explode("|",$info);
        $token = $info[7];

        $appurl = $mag_paramter['magapp_hostname'].'/mag/cloud/cloud/getUserInfo?token='.$token.'&secret='.$mag_paramter['magapp_secret'];
        
        $appdata = dfsockopen($appurl);
        if (!$appdata) {
            $appdata = file_get_contents($appurl);
        }
        $r =  json_decode($appdata, true);
        if($r['data']['user_id']>0){

            $member = getuserbyuid($r['data']['user_id'], 1);
            if (!$member) {
                dheader('Location:' . $_G['siteurl'] . 'member.php?mod=logging&action=login&referer=' . urlencode($refererurl));
                exit();
            }
            if (isset($member['_inarchive'])) {
                C::t('common_member_archive')->move_to_master($member['uid']);
            }
            require_once libfile('function/member');
            $cookietime = 1296000;
            setloginstatus($member, $cookietime);
            return true;

        }else{
            exit('<script src="source/plugin/zimu_zhaopin/static/js/magjs-x.js"></script><script>
                mag.toLogin(function(){
                    top.location.href="' . $refererurl . '";
                    });
                    </script>'); 
        }

    }else{

        if (!$_G['uid']) {
            if (IN_XIAOYUNAPP) {
                exit('<script language="javascript" src="source/plugin/zimu_zhaopin/static/js/appbyme.js"></script><script>connectAppbymeJavascriptBridge(function(bridge){
                    AppbymeJavascriptBridge.login(function(data){
                        top.location.href="' . $refererurl . '";
                        });
                        });
                        </script>');
            } else if (IN_MAGAPP) {
                exit('<script src="source/plugin/zimu_zhaopin/static/js/magjs-x.js"></script><script>
                    mag.toLogin(function(){
                        top.location.href="' . $refererurl . '";
                        });
                        </script>');  
            } else if (IN_QFAPP) {
                exit('<script src="source/plugin/zimu_zhaopin/static/js/jquery-2.1.4.js"></script><script> function QFH5ready(){QFH5.jumpLogin(function(state,data){
                    if(state==1){
                        QFH5.refresh(1);
                        }else{
                //��½ʧ��
                            alert(data.error);//data.error: string
                        }
                        });
                    }
                    </script>');
            } else {
                dheader('Location:' . $_G['siteurl'] . '/member.php?mod=logging&action=login&referer=' . urlencode($refererurl));
                exit();
            }
        }
    }
}


function zm_diconv($str)
{
    global $_G;
    $encode = mb_detect_encoding($str, array(
        "UTF-8",
        "GB2312",
        "GBK"
    ));
    if ($encode != strtoupper(CHARSET)) {
        $keytitle = mb_convert_encoding($str, strtoupper(CHARSET), $encode);
    }
    
    $censorexp = '/^(' . str_replace(array(
        '\\*',
        "\r\n",
        ' '
    ), array(
        '.*',
        '|',
        ''
    ), preg_quote(($_G['cache']['plugin']['zimu_zhaopin']['zimu_luanma'] = trim($_G['cache']['plugin']['zimu_zhaopin']['zimu_luanma'])), '/')) . ')$/i';
    if ($_G['cache']['plugin']['zimu_zhaopin']['zimu_luanma'] && @preg_match($censorexp, $keytitle)) {
        $keytitle = $str;
    }
    if (!$keytitle) {
        $keytitle = $str;
    }
    return $keytitle;
}


function tpl_form_field_image($id, $val) {
	if (!$val) {
		$val = 'source/plugin/zimu_zhaopin/static/nopic.jpg';
	}

$langfile = DISCUZ_ROOT . './source/plugin/zimu_zhaopin/language.' . currentlang() . '.php';

$includefile = is_file($langfile) ? $langfile : libfile('language', 'plugin/zimu_zhaopin');

include $includefile;

	return '<div class="input-group "><input type="text" name="textfield_' . $id . '" type="file" id="textfield_' . $id . '" class="form-control valid" /><span class="input-group-btn"><input type="button" name="button" id="button1" value="'.$language_zimu['config_php_0'].'" class="btn btn-primary" /></span><input name="' . $id . '" type="file" class="type-file-file" id="' . $id . '" style="position: absolute;top: 0px;left: 0px;height: 40px;width: 100%;filter: alpha(opacity: 0);opacity: 0;cursor: pointer;" size="200" hidefocus="true">
  </div><div class="input-group " style="margin-top:6px;"><input type="hidden" name="img_' . $id . '" value="' . $val . '"><img src="' . $val . '" class="img-responsive img-thumbnail" width="150" id="img_' . $id . '"><em class="close" style="position:absolute; top: 0px; right: -14px;" onclick="deleteImage(this)">x</em></div>';

}

function zimu_array_utf8($String)
{
    if (is_array($String)) {
        foreach ($String as $key => $val) {
            $String[$key] = zimu_array_utf8($val);
        }
    } else {
        if (preg_match("/^[A-Za-z0-9\s]+$/", $String)) {
            $String = $String;
        } else {
            $String = diconv($String,CHARSET,'UTF-8');
        }
    }
    return $String;
}

function zimu_array_utf8tomy($String)
{
    if (is_array($String)) {
        foreach ($String as $key => $val) {
            $String[$key] = zimu_array_utf8tomy($val);
        }
    } else {
        if (preg_match("/^[A-Za-z0-9\s]+$/", $String)) {
            $String = $String;
        } else {
            $String = diconv($String,'UTF-8',CHARSET);
        }
    }
    return $String;
}

function zm_saveimages($FILES, $type = 'zimucms')
{
    global $_G;

    require_once DISCUZ_ROOT . './source/plugin/zimu_zhaopin/new_discuz_upload.php';

    $upload = new discuz_upload_zimucms();

    $upload->init($FILES, 'uploadzimucms');

    $upload2 = object_array($upload);
    if($upload2['attach']['isimage'] != 1){
        return false;
    }
    
    if ($upload->error()) {
        return '';
    }

    $upload->save();
    if ($upload->error()) {
        return '';
    }

    $pic = $upload->attach['attachment'];

    if ($upload->attach['imageinfo'][0] > 1500 || $upload->attach['imageinfo'][1] > 1500) {
        if ($upload->attach['imageinfo'][0] >= $upload->attach['imageinfo'][1]) {
            $thumb_width = $upload->attach['imageinfo'][0] / 2;
        } else {
            $thumb_width = $upload->attach['imageinfo'][1] / 2;
        }

        require_once libfile('class/image');
        $image = new image();
        $pic2  = $image->Thumb($upload->attach['target'], '', $thumb_width, $thumb_width, 2);
    }

    $oss_paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
        'zimu_zhaopin_parameter2',
        'alioss'
    ));
    
    $oss_paramter = unserialize($oss_paramter['parameter']);

    if(!$oss_paramter['oss_type'] && $oss_paramter['ACCESS_ID'] && $oss_paramter['ACCESS_KEY'] && $oss_paramter['ENDPOINT'] && $oss_paramter['BUCKET']){
        $saved_file = DISCUZ_ROOT.'/source/plugin/zimu_zhaopin/uploadzimucms/'.$pic;
        include_once DISCUZ_ROOT.'source/plugin/zimu_zhaopin/lib/OSS/Common.php';
        if ($surl = zm_oss_upload('zimu_zhaopin/'.$pic, $saved_file)) {
            @unlink($saved_file);
            return $imgurl = $surl;
            exit();
        }
    }elseif ($oss_paramter['oss_type']==1 && $oss_paramter['qn_ak'] && $oss_paramter['qn_sk'] && $oss_paramter['qn_bk']){

        $saved_file = DISCUZ_ROOT.'/source/plugin/zimu_zhaopin/uploadzimucms/'.$pic;
        include_once(DISCUZ_ROOT.'source/plugin/zimu_zhaopin/lib/Qiniu/upload.php');
        if ($surl=zm_qn_upload('zimu_zhaopin/'.$pic,$saved_file)) {
            unlink($saved_file);
            error_reporting(0);
            return $imgurl = $surl;
        }

    }
    
    if ($pic2) {
        return $_G['siteurl'].'source/plugin/zimu_zhaopin/uploadzimucms/' . $pic . '.thumb.jpg';
    } else {
        return $_G['siteurl'].'source/plugin/zimu_zhaopin/uploadzimucms/' . $pic;
    }
}
function pagination($total, $pageIndex, $pageSize = 15, $url = '', $context = array('before' => 5, 'after' => 4, 'ajaxcallback' => '', 'callbackfuncname' => '')) {
    global $_G;

$langfile = DISCUZ_ROOT . './source/plugin/zimu_zhaopin/language.' . currentlang() . '.php';

$includefile = is_file($langfile) ? $langfile : libfile('language', 'plugin/zimu_zhaopin');

include $includefile;

    $pdata = array(
        'tcount' => 0,
        'tpage' => 0,
        'cindex' => 0,
        'findex' => 0,
        'pindex' => 0,
        'nindex' => 0,
        'lindex' => 0,
        'options' => ''
    );
    
    $pdata['tcount'] = $total;
    $pdata['tpage'] = (empty($pageSize) || $pageSize < 0) ? 1 : ceil($total / $pageSize);
    if ($pdata['tpage'] <= 1) {
        return '';
    }
    $cindex = $pageIndex;
    $cindex = min($cindex, $pdata['tpage']);
    $cindex = max($cindex, 1);
    $pdata['cindex'] = $cindex;
    $pdata['findex'] = 1;
    $pdata['pindex'] = $cindex > 1 ? $cindex - 1 : 1;
    $pdata['nindex'] = $cindex < $pdata['tpage'] ? $cindex + 1 : $pdata['tpage'];
    $pdata['lindex'] = $pdata['tpage'];


    $_GET['page'] = $pdata['findex'];
    $pdata['faa'] = 'href="?' . http_build_query($_GET) . '"';
    $_GET['page'] = $pdata['pindex'];
    $pdata['paa'] = 'href="?' . http_build_query($_GET) . '"';
    $_GET['page'] = $pdata['nindex'];
    $pdata['naa'] = 'href="?' . http_build_query($_GET) . '"';
    $_GET['page'] = $pdata['lindex'];
    $pdata['laa'] = 'href="?' . http_build_query($_GET) . '"';

    $html = '<div><ul class="pagination pagination-centered">';
    if ($pdata['cindex'] > 1) {
        $html .= "<li><a {$pdata['faa']} class=\"pager-nav\">".$language_zimu['config_php_1']."</a></li>";
        $html .= "<li><a {$pdata['paa']} class=\"pager-nav\">&laquo;".$language_zimu['config_php_2']."</a></li>";
    }
    if (!$context['before'] && $context['before'] != 0) {
        $context['before'] = 5;
    }
    if (!$context['after'] && $context['after'] != 0) {
        $context['after'] = 4;
    }

    if ($context['after'] != 0 && $context['before'] != 0) {
        $range = array();
        $range['start'] = max(1, $pdata['cindex'] - $context['before']);
        $range['end'] = min($pdata['tpage'], $pdata['cindex'] + $context['after']);
        if ($range['end'] - $range['start'] < $context['before'] + $context['after']) {
            $range['end'] = min($pdata['tpage'], $range['start'] + $context['before'] + $context['after']);
            $range['start'] = max(1, $range['end'] - $context['before'] - $context['after']);
        }
        for ($i = $range['start']; $i <= $range['end']; $i++) {
            if ($context['isajax']) {
                $aa = 'href="javascript:;" page="' . $i . '" '. ($callbackfunc ? 'onclick="'.$callbackfunc.'(\'' . $url . '\', \'' . $i . '\', this);return false;"' : '');
            } else {
                if ($url) {
                    $aa = 'href="?' . str_replace('*', $i, $url) . '"';
                } else {
                    $_GET['page'] = $i;
                    $aa = 'href="?' . http_build_query($_GET) . '"';
                }
            }
            $html .= ($i == $pdata['cindex'] ? '<li class="active"><a href="javascript:;">' . $i . '</a></li>' : "<li><a {$aa}>" . $i . '</a></li>');
        }
    }

    if ($pdata['cindex'] < $pdata['tpage']) {
        $html .= "<li><a {$pdata['naa']} class=\"pager-nav\">".$language_zimu['config_php_3']."&raquo;</a></li>";
        $html .= "<li><a {$pdata['laa']} class=\"pager-nav\">".$language_zimu['config_php_4']."</a></li>";
    }
    $html .= '</ul></div>';
    return $html;
}
function ifilter_url($params) {
    global $_G;
    if(empty($params)) {
        return '';
    }
    $query_arr = array();
    $parse = parse_url($_G['siteurl'].$_SERVER['REQUEST_URI']);
    if(!empty($parse['query'])) {
        $query = $parse['query'];
        parse_str($query, $query_arr);
    }
    $params = explode(',', $params);
    foreach($params as $val) {
        if(!empty($val)) {
            $data = explode(':', $val);
            $query_arr[$data[0]] = trim($data[1]);
        }
    }
    $query_arr['page'] = 1;
    $query = http_build_query($query_arr);
    return './plugin.php?' . $query;
}

function zimu_writetocache($key = 'table_plugin_zimu_zhaopin', $array = array()){

    if(strpos($key,'table_plugin_zimu_zhaopin')<0){
        echo 'no files allow write';exit();
    }

    $datas = $array;
    $cachedata = " return " . var_export($datas, TRUE) . ";";

    global $_G;

    $dir = DISCUZ_ROOT . "./data/sysdata/";
    if (!is_dir($dir)) {
        dmkdir($dir, 0777);
    }
    $file = "$dir/$key.php";
    if ($fp = @fopen($file, 'wb')) {
        fwrite($fp, "<?php\n//Discuz! cache file, DO NOT modify me!\n//Identify: " . md5($key . '.php' . $cachedata . $_G['config']['security']['authkey']) . "\n\n$cachedata?>");
        fclose($fp);
    } else {
        exit('Can not write to cache files, please check directory ./data/ and ./data/sysdata/ .');
    }
}

function zimu_readfromcache($key = 'table_plugin_zimu_zhaopin'){

    if(strpos($key,'table_plugin_zimu_zhaopin')<0){
        echo 'no files allow write';exit();
    }

    $ret = array();

    $file = DISCUZ_ROOT . "./data/sysdata/$key.php";
    if (is_file($file)) {
        $ret = include $file;
    }

    return $ret;
}

function zimu_deletefromcache($key = 'table_plugin_zimu_zhaopin'){

    if(strpos($key,'table_plugin_zimu_zhaopin')<0){
        echo 'no files allow write';exit();
    }

    $cache_file = DISCUZ_ROOT . "./data/sysdata/$key.php";
    if(is_file($cache_file)){
        @unlink($cache_file);
    }
    return TRUE;
}
    function get_tag_pars($par,$value){
        if(is_int($par)){
            $where = "id='{$par}'";
        }else{
            $where = "ename='{$par}'";
        }
        $str = DB::fetch_first('select * from %t where '.$where,array('zimu_marry_parameter'));
        $arrtemp = explode(',',$str['value']);
        if(strpos($value,',')){
            $value2 = explode(',',$value);
            foreach($value2 as $vals){
                $val[] = $arrtemp[$vals-1];
            }
            $val = join(' ',$val);
        }else{
            $val = $arrtemp[$value-1];
        }
        return $val;
    }

function lizimu_post($url, $data) {
        if (!function_exists('curl_init')) {
            return '';
        }
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        # curl_setopt( $ch, CURLOPT_HEADER, 1);

        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);

        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        $data = curl_exec($ch);
        if (!$data) {
            error_log(curl_error($ch));
        }
        curl_close($ch);
        return $data;
}

function zm_curl($url){
    $retfrom=dfsockopen($url);
    if (!$retfrom) {
        $retfrom=zm_curl_get($url);
    }
    return $retfrom;
}
function zm_curl_get($url){
    if (!function_exists('curl_init')) {
        return file_get_contents($url);
    }
    $ch=curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
    curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,false);
    curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,false);
    if (!curl_exec($ch)) {
        error_log(curl_error($ch));
        $data='';
    }else{
        $data=curl_multi_getcontent($ch);
    }
    curl_close($ch);
    return $data;
}

function get_url($name='') {

        global $_G;
        
        $php_self = $_SERVER['PHP_SELF'] ? $_SERVER['PHP_SELF'] : $_SERVER['SCRIPT_NAME'];
        $path_info = isset($_SERVER['PATH_INFO']) ? $_SERVER['PATH_INFO'] : '';
        $relate_url = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : $php_self.(isset($_SERVER['QUERY_STRING']) ? '?'.$_SERVER['QUERY_STRING'] : $path_info);
        if($name){
        $relate_url = str_replace($name, '', $relate_url);    
        }
        if(strpos($relate_url, '?') !== false){
        return rtrim($_G['siteurl'], "/").$relate_url; 
        }else{
        return rtrim($_G['siteurl'], "/").$relate_url.'?'; 
        }
}

function get_url2($name1='',$name2='',$name3='',$name4='',$name5='') {

        global $_G;

        $php_self = $_SERVER['PHP_SELF'] ? $_SERVER['PHP_SELF'] : $_SERVER['SCRIPT_NAME'];
        $path_info = isset($_SERVER['PATH_INFO']) ? $_SERVER['PATH_INFO'] : '';
        $relate_url = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : $php_self.(isset($_SERVER['QUERY_STRING']) ? '?'.$_SERVER['QUERY_STRING'] : $path_info);
        if(strpos($relate_url, '?') !== false){
        $reurl = rtrim($_G['siteurl'], "/").$relate_url; 
        }else{
        $reurl= rtrim($_G['siteurl'], "/").$relate_url.'?zp=zp';
        }

$a = explode('?',$reurl); 
$url_f = $a[0]; 
$query = $a[1]; 
parse_str($query,$arr);
$arr[$key] = $value; 
if($name1){
unset($arr[$name1]);   
}
if($name2){
unset($arr[$name2]);   
}
if($name3){
unset($arr[$name3]);   
}
if($name4){
unset($arr[$name4]);   
}
if($name5){
unset($arr[$name5]);   
}

$tourl = $url_f.'?'.http_build_query($arr);
$tourl = str_replace('?&','?',$tourl);
return $tourl;

}
function get_url3($reurl,$name1='',$name2='',$name3='',$name4='',$name5='') {

        global $_G;

$a = explode('?',$reurl); 
$url_f = $a[0]; 
$query = $a[1]; 
parse_str($query,$arr);
$arr[$key] = $value; 
if($name1){
unset($arr[$name1]);   
}
if($name2){
unset($arr[$name2]);   
}
if($name3){
unset($arr[$name3]);   
}
if($name4){
unset($arr[$name4]);   
}
if($name5){
unset($arr[$name5]);   
}
return $url_f.'?'.http_build_query($arr); 


}
    /**
     * [spell_assembly ����ת�ַ���]
     * @param  [array]     $data    [��ת��������]
     * @param  string      $p       [����ַ�]
     * @return [string]             [�������]
     */
    function spell_assembly($data,$p=',',$s='"'){
        foreach ($data as $key=>$val) {
            $arr[] = $s.$val['spell'].','.$val['categoryname'].$s;
        }
        $arr = implode($p,$arr);
        if(!$s) return '"'.$arr.'"';
        return $arr;
    }
    /**
     * [assembly ����ת�ַ���]
     * @param  [array]     $data    [��ת��������]
     * @param  string      $p       [����ַ�]
     * @return [string]             [�������]
     */
    function assembly($data,$p=',',$s='"'){
        foreach ($data as $key=>$val) {
            $arr[] = $s.$key.','.$val.$s;
        }
        $arr = implode($p,$arr);
        if(!$s) return '"'.$arr.'"';
        return $arr;
    }


    function ajaxReturn($status=1, $msg='', $data='', $dialog='') {
        $data = array(
            'status' => $status,
            'msg' => $msg,
            'data' => $data,
            'dialog' => $dialog,
        );
        $jsondata = zimu_array_utf8($data);
        
        echo json_encode($jsondata);exit();
    }

function I($type,$def='',$fun){
 return $fun($_GET[$type]) ? $fun($_GET[$type]) : $def;
}

function ddate($s,$e){

$langfile = DISCUZ_ROOT . './source/plugin/zimu_zhaopin/language.' . currentlang() . '.php';

$includefile = is_file($langfile) ? $langfile : libfile('language', 'plugin/zimu_zhaopin');

include $includefile;

    $starttime = strtotime($s);
    $endtime = strtotime($e);
    $startyear = date('Y',$starttime);
    $startmonth = date('m',$starttime);
    $endyear = date('Y',$endtime);
    $endmonth = date('m',$endtime);
    $return = '';
    $return_year = $endyear - $startyear;
    $return_month = $endmonth - $startmonth;
    if($return_month<0){
        $return_month += 12;
        $return_year -= 1;
    }

    if($return_year>0){
        $return .= $return_year.$language_zimu['config_php_5'];
    }
    if($return_month>0){
        $return .= $return_month.$language_zimu['config_php_6'];
    }
    return $return;
}

    function _get_duration($list){
        if(!empty($list)){
            foreach ($list as $key => $value) {
                $start = $value['startyear'].'-'.$value['startmonth'];
                $end = $value['todate']==1?date('Y-m'):($value['endyear'].'-'.$value['endmonth']);
                $list[$key]['duration'] = ddate($start,$end);
            }
        }
        return $list;
    }

function _get_total_work_duration($list){

$langfile = DISCUZ_ROOT . './source/plugin/zimu_zhaopin/language.' . currentlang() . '.php';

$includefile = is_file($langfile) ? $langfile : libfile('language', 'plugin/zimu_zhaopin');

include $includefile;

        $total_year = 0;
        $total_month = 0;
        $return = '';
        if(!empty($list)){
            foreach ($list as $key => $value) {
                $current_duration = strpos($value['duration'],$language_zimu['config_php_5']);
                if($current_duration===false){
                    $total_month += intval($value['duration']);
                }else{
                    $arr = explode($language_zimu['config_php_5'], $value['duration']);
                    $total_year += intval($arr[0]);
                    $total_month += intval($arr[1]);
                }
            }
        }
        $add_year = intval($total_month/12);
        $total_year += $add_year;
        $total_month = intval($total_month%12);
        if($total_year>0){
            $return .= $total_year.$language_zimu['config_php_5'];
        }
        if($total_month>0){
            $return .= $total_month.$language_zimu['config_php_6'];
        }
        return $return;
}
function getFile($url, $save_dir = '', $filename = '', $type = 0, $isutf8 = 0) {
    if (trim($url) == '') {
        return false;
    }
    if (trim($save_dir) == '') {
        $save_dir = './';
    }
    if (0 !== strrpos($save_dir, '/')) {
        $save_dir.= '/';
    }

    if (!file_exists($save_dir) && !mkdir($save_dir, 0777, true)) {
        return false;
    }
    if ($type) {
        $ch = curl_init();
        $timeout = 5;
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
        $content = curl_exec($ch);
        curl_close($ch);
    } else {
        ob_start();
        readfile($url);
        $content = ob_get_contents();
        ob_end_clean();
    }
    $size = strlen($content);
    chmod($save_dir.$filename,0755);
    $fp2 = @fopen($save_dir . $filename, 'w+');
    if($isutf8){
      $content = diconv($content,'gbk','UTF-8');
      //$content = utf8_encode($content);
      $content = "\xEF\xBB\xBF".$content;
    }
    fwrite($fp2, $content);
    fclose($fp2);
    unset($content, $url);
    if($isutf8){
    checkBOM($save_dir . $filename);
    }
    return array(
        'file_name' => $filename,
        'save_path' => $save_dir . $filename
    );
}

function checkBOM($filename) 
{ 
    global $auto; 
    $contents   = file_get_contents($filename); 
    $charset[1] = substr($contents, 0, 1); 
    $charset[2] = substr($contents, 1, 1); 
    $charset[3] = substr($contents, 2, 1); 
    if (ord($charset[1]) == 239 && ord($charset[2]) == 187 && ord($charset[3]) == 191) { 
            $rest = substr($contents, 3); 
            rewrite($filename, $rest); 
    }
} 

function rewrite($filename, $data)
{
    $filenum = fopen($filename, "w");
    flock($filenum, LOCK_EX);
    fwrite($filenum, $data);
    fclose($filenum);
}

function zimu_template($name,$defdir='',$ishow=1){
    global $_G;

if(strpos('demo.zimucms.com', 'demo.zimucms.com') !== false){
$debug = 0;
}else{
$debug = 0;
}

if(!$defdir){
if(!checkmobile()){
$defdir = '';
}else{
$defdir = 'touch';
}
}

if($debug == 0){
$oldtpl = file_get_contents(DISCUZ_ROOT . './source/plugin/zimu_zhaopin/template/'.$defdir.'/'.$name.'.htm');

if($oldtpl == 'lizimu' || !$oldtpl){
$newtpl = 'http://demo.zimucms.com/source/plugin/zimu_zhaopin/template_cn/'.$defdir.'/'.$name.'.htm';
$save_dir = DISCUZ_ROOT . './source/plugin/zimu_zhaopin/template/'.$defdir.'/';
$filename = $name.'.htm';
if($_G['charset'] == 'utf-8'){
getFile($newtpl, $save_dir, $filename, 1, 1);
}else{
getFile($newtpl, $save_dir, $filename, 1);
}
}
}
if($ishow){
return template('zimu_zhaopin:'.$name);
}
}

zimu_template('header','touch',0);
zimu_template('zimu_head','touch',0);
zimu_template('footer_min','touch',0);
zimu_template('meta','touch',0);
zimu_template('search','touch',0);

zimu_template('footer_base','common',0);
zimu_template('footer','common',0);
zimu_template('header_base','common',0);
zimu_template('header','common',0);
zimu_template('zimu_head','common',0);
zimu_template('success','common',0);

zimu_template('meta','',0);
zimu_template('header','',0);
zimu_template('zimu_head','',0);
zimu_template('footer','',0);
zimu_template('index_header','',0);
zimu_template('index_head','',0);
zimu_template('index_footer','',0);
zimu_template('left_user','',0);
zimu_template('left_resumes','',0);
zimu_template('left_service','',0);
zimu_template('index_header2','',0);

zimu_template('admins_wapseturl','admins',0);

function object_array($array)
{
    if (is_object($array)) {
        $array = (array) $array;
    }
    if (is_array($array)) {
        foreach ($array as $key => $value) {
            $array[$key] = object_array($value);
        }
    }
    return $array;
}

function zm_fomat($txt){
    $txt=strip_tags(htmlspecialchars_decode($txt),'<a><abbr><acronym><address><applet><area><b><base><basefont><bdo><big><blockquote><body><br><button><caption><center><cite><code><col><colgroup><dd><del><dir><div><dfn><dl><dt><em><fieldset><font><form><frame><frameset><h1><h2><h3><h4><h5><h6><head><hr><html><i><iframe><img><input><ins><isindex><kbd><label><legend><li><link><map><menu><meta><noframes><noscript><object><ol><optgroup><option><p><param><pre><q><s><samp><script><select><small><span><strike><strong><style><sub><sup><table><tbody><td><textarea><tfoot><th><thead><title><tr><tt><u><ul><var><article><aside><audio><bdi><canvas><command><datalist><details><embed><figcaption><figure><footer><header><hgroup><keygen><mark><nav><output><progress><rp><ruby><source><summary><time><track><video><wbr><rt><section>');
    return $txt;
}


function qf_nonce($length = 32)
{
    $chars = "abcdefghijklmnopqrstuvwxyz0123456789";
    $str = "";
    for ($i = 0; $i < $length; $i++) {
        $str .= substr($chars, mt_rand(0, strlen($chars) - 1), 1);
    }
    return $str;
}

function qf_sign($params, $secret)
{
    ksort($params);
    $sparams = array();
    foreach ($params as $k => $v) {
        if ("@" != substr($v, 0, 1)) {
            $sparams[] = "$k=$v";
        }
    }
    $sparams[] = "secret=" . $secret;
    return strtoupper(md5(implode("&", $sparams)));
}

function sub_day($endday,$staday,$range=''){
    $value = $endday - $staday;
    if($value < 0)
    {
        return '';
    }
    elseif($value >= 0 && $value < 59)
    {
        return ($value+1)."\u79d2";
    }
    elseif($value >= 60 && $value < 3600)
    {
        $min = intval($value / 60);
        return $min."\u5206\u949f";
    }
    elseif($value >=3600 && $value < 86400)
    {
        $h = intval($value / 3600);
        return $h."\u5c0f\u65f6";
    }
    elseif($value >= 86400 && $value < 86400*30)
    {
        $d = intval($value / 86400);
        return intval($d)."\u5929";
    }
    elseif($value >= 86400*30 && $value < 86400*30*12)
    {
        $mon  = intval($value / (86400*30));
        return $mon."\u6708";
    }
    else{   
        $y = intval($value / (86400*30*12));
        return $y."\u5e74";
    }
}
function finish_order($order,$trade_no,$postprice=0,$method='')
{
    $_G = $GLOBALS['_G'];
    if (!$_G['cache']['plugin']) {
        loadcache('plugin');
    }

$config = $_G['cache']['plugin']['zimu_zhaopin'];
$setdata = DB::fetch_first('select * from %t order by id desc', array(
        'zimu_zhaopin_setting'
    ));
$config['base'] = $setdata;
$config['settings'] = unserialize($setdata['settings']);
    $config['settings']['jifen_bili'] = $config['settings']['jifen_bili'] ? $config['settings']['jifen_bili'] : 10;
    $config['settings']['jifen_bili'] = intval($config['settings']['jifen_bili']);
            $setsqlarr['is_paid']           = 2; 
            $setsqlarr['order_sn']           = $trade_no;
            $setsqlarr['payment_time']           = time();
            DB::update('zimu_zhaopin_order', $setsqlarr, array(
                'id' => $order['id']
            ));

        if($order['pay_points']>0){
            DB::query("update %t set points=points-%d where uid=%d", array(
                'zimu_zhaopin_members',
                $order['pay_points'],
                $order['uid']
            ));
            $setsqlarr_handsel['uid']     = $order['uid'];
            $setsqlarr_handsel['htype']    = $order['service_name'];
            $setsqlarr_handsel['htype_cn']    = $order['description'];
            $setsqlarr_handsel['operate']    = 2;
            $setsqlarr_handsel['points'] = $order['pay_points'];
            $setsqlarr_handsel['addtime'] = $_G['timestamp'];
            DB::insert('zimu_zhaopin_members_handsel', $setsqlarr_handsel, 1);   
        }

    if ($order['zpid']) {
        switch($order['service_name']){
            case 'jobs_refresh':
            DB::query("update %t set refreshtime=%d where id=%d", array(
                'zimu_zhaopin_jobs',
                time(),
                $order['zpid']
            ));

            $setsqlarr_refresh_log['uid']     = $order['uid'];
            $setsqlarr_refresh_log['mode']    = 2;
            $setsqlarr_refresh_log['addtime'] = $_G['timestamp'];
            $setsqlarr_refresh_log['type']    = 1001;
            DB::insert('zimu_zhaopin_refresh_log', $setsqlarr_refresh_log, 1);

            break;
            case 'jobs_stick':

            $jobinfo = DB::fetch_first('select * from %t where id=%d order by id desc', array(
                'zimu_zhaopin_jobs',
                $order['zpid']
            ));
            if($jobinfo['stick_endtime']>time()){
                DB::query("update %t set stick=1,stick_endtime=stick_endtime+%d where id=%d", array(
                    'zimu_zhaopin_jobs',
                    $order['params']['days']*86400,
                    $order['zpid']
                ));
            }else{
                DB::query("update %t set stick=1,stick_endtime=%d where id=%d", array(
                    'zimu_zhaopin_jobs',
                    strtotime("{$order['params']['days']} day"),
                    $order['zpid']
                ));
            }

            break;
            case 'jobs_pay_add':

            if($config['settings']['com_money_audit']==1){
                DB::query("update %t set audit=1,ispay=0 where id=%d", array(
                    'zimu_zhaopin_jobs',
                    $order['zpid']
                ));
            }else{
                DB::query("update %t set audit=2,ispay=0 where id=%d", array(
                    'zimu_zhaopin_jobs',
                    $order['zpid']
                ));
            }

            if($order['params']['days']>0){
                DB::query("update %t set stick=1,stick_endtime=%d where id=%d", array(
                    'zimu_zhaopin_jobs',
                    strtotime("{$order['params']['days']} day"),
                    $order['zpid']
                ));
            }

            break;
            case 'setmeal_add':


        $setmeal = DB::fetch_first('select * from %t where id=%d and display=1 order by id desc', array(
            'zimu_zhaopin_setmeal',
            $order['setmeal']
        ));

        $user_setmeal = DB::fetch_first('select * from %t where uid=%d order by id desc', array(
            'zimu_zhaopin_members_setmeal',
            $order['uid']
        ));

        $timestamp = time();
        $setmeal_add['expire'] = $setmeal['is_free'] == 1 ? 1 : 0;
        $setmeal_add['uid'] = $order['uid'];
        $setmeal_add['setmeal_id'] = $setmeal['id'];
        $setmeal_add['setmeal_name'] = $setmeal['setmeal_name'];
        $setmeal_add['days'] = $setmeal['days'];
        $setmeal_add['expense']=$setmeal['expense'];
        $setmeal_add['jobs_meanwhile']=$setmeal['jobs_meanwhile'];
        $setmeal_add['refresh_jobs_free']=$setmeal['refresh_jobs_free'];
        $setmeal_add['download_resume'] = $user_setmeal['download_resume'] + $setmeal['download_resume'];
        $setmeal_add['download_resume_max'] = $setmeal['download_resume_max'];
        $setmeal_add['added']=$setmeal['added'];
        if ($setmeal['days']>0){
            $setmeal_add['endtime']=strtotime("".$setmeal['days']." days");
        }else{
            $setmeal_add['endtime']="0";  
        }
        $setmeal_add['show_apply_contact'] = $setmeal['show_apply_contact'];
        $setmeal_add['is_free']=$setmeal['is_free'];
        $setmeal_add['discount_download_resume']=$setmeal['discount_download_resume'];
        $setmeal_add['discount_stick']=$setmeal['discount_stick'];
        $setmeal_add['discount_emergency']=$setmeal['discount_emergency'];
        $setmeal_add['discount_auto_refresh_jobs']=$setmeal['discount_auto_refresh_jobs'];

            DB::update('zimu_zhaopin_members_setmeal', $setmeal_add, array(
                'uid' => $order['uid']
            ));

            DB::query("update %t set setmeal_id=%d,setmeal_name=%s where uid=%d", array(
                'zimu_zhaopin_company_profile',
                $setmeal['id'],
                $setmeal['setmeal_name'],
                $order['uid']
            ));

            if($setmeal['give_points']){
                DB::query("update %t set points=points+%d where uid=%d", array(
                    'zimu_zhaopin_members',
                    $setmeal['give_points']*10/$config['settings']['jifen_bili'],
                    $order['uid']
                ));
            }

            break;
            case 'resume_download':

        $resume_download['resume_id'] = $order['zpid'];
        $resume_download['company_uid'] = $order['uid'];
        $resume_download['down_addtime'] = $_G['timestamp'];
        DB::insert('zimu_zhaopin_company_down_resume', $resume_download);

            break;
            case 'resume_stick':

            if($config['settings']['resume_join_money']){
                DB::query("update %t set audit=1 where id=%d", array(
                    'zimu_zhaopin_resume',
                    $order['zpid']
                ));
            }

            $resumeinfo = DB::fetch_first('select * from %t where id=%d order by id desc', array(
                'zimu_zhaopin_resume',
                $order['zpid']
            ));
            if($resumeinfo['stick_endtime']>time()){
                DB::query("update %t set stick=1,stick_endtime=stick_endtime+%d where id=%d", array(
                    'zimu_zhaopin_resume',
                    $order['params']['days']*86400,
                    $order['zpid']
                ));
            }else{
                DB::query("update %t set stick=1,stick_endtime=%d where id=%d", array(
                    'zimu_zhaopin_resume',
                    strtotime("{$order['params']['days']} day"),
                    $order['zpid']
                ));
            }

            break;

            case 'resume_join_money':

            if($config['settings']['resume_join_money']){
                DB::query("update %t set audit=1 where id=%d", array(
                    'zimu_zhaopin_resume',
                    $order['zpid']
                ));
            }

            break;


            case 'strong_tag':

            DB::query("update %t set strong_tag=%s,strong_tag_endtime=%d where id=%d", array(
                'zimu_zhaopin_resume',
                $order['params']['strong_tag'],
                strtotime("{$order['params']['days']} day"),
                $order['zpid']
            ));

            break;
            case 'jobs_auto_refresh':

            $setmeal_increment = DB::fetch_first('select * from %t where id=%d order by id desc', array(
                'zimu_zhaopin_setmeal_increment',
                $order['setmeal']
            ));
            $days = $setmeal_increment['value'];
            $nowtime = time();
            for ($i = 0; $i < $days * 4; $i++) {
                $timespace = 3600 * 6 * $i;

                $queue_auto_refresh['uid'] = $order['uid'];
                $queue_auto_refresh['pid'] = $order['zpid'];
                $queue_auto_refresh['type'] = 1;
                $queue_auto_refresh['refreshtime'] = $nowtime + $timespace;
                DB::insert('zimu_zhaopin_queue_auto_refresh', $queue_auto_refresh);

            }

            break;
            case 'download_resume':

            DB::query("update %t set download_resume2=download_resume2+%d where uid=%d", array(
                'zimu_zhaopin_members_setmeal',
                $order['params']['nums'],
                $order['uid']
            ));

            break;
            case 'buy_points':

            DB::query("update %t set points=points+%d where uid=%d", array(
                'zimu_zhaopin_members',
                $order['params']['add_num'],
                $order['uid']
            ));

            $setsqlarr_handsel['uid']     = $order['uid'];
            $setsqlarr_handsel['htype']    = $order['service_name'];
            $setsqlarr_handsel['htype_cn']    = $order['description'];
            $setsqlarr_handsel['operate']    = 1;
            $setsqlarr_handsel['points'] = $order['params']['add_num'];
            $setsqlarr_handsel['addtime'] = $_G['timestamp'];
            DB::insert('zimu_zhaopin_members_handsel', $setsqlarr_handsel, 1);

            break;

        }
    }
    //notification_user($order['uid'],array('url'=>$_G['siteurl'].'plugin.php?id=zimu_zhaopin'));
}

function imagecreates($bg) {

    $bgImg = @imagecreatefromjpeg($bg);

    if (FALSE == $bgImg) {

        $bgImg = @imagecreatefrompng($bg);

    }

    if (FALSE == $bgImg) {

        $bgImg = @imagecreatefromgif($bg);

    }

    return $bgImg;

}

function notification_user($uid,$template_id,$postdata){
    global $_G;

$zmdata = $_G['cache']['plugin']['zimu_zhaopin'];

$setdata = DB::fetch_first('select * from %t order by id desc', array(
        'zimu_zhaopin_setting'
    ));

$zmdata['base'] = $setdata;
$zmdata['settings'] = unserialize($setdata['settings']);

if($uid=='admin'){

require_once DISCUZ_ROOT . './source/plugin/zimu_zhaopin/class/wechat.lib.class.php';
$wechat_client = new WeChatClient($zmdata['base']['weixin_appid'], $zmdata['base']['weixin_appsecret']);

$weixin_openid = explode(",", trim($zmdata['settings']['weixin_openid']));

foreach ($weixin_openid as $key => $value) {

            $template = array(
                'touser' => $value,
                'template_id' => $template_id,
                'url' => $postdata['url'],
                'topcolor' => "#7B68EE",
                'data' => array(
                    'first' => array(
                        'value' => urlencode(diconv($postdata['first'], CHARSET, 'utf-8')),
                        'color' => "#FF4040"
                    ),
                    'keyword1' => array(
                        'value' => urlencode(diconv(strip_tags(zm_diconv($postdata['keyword1'])), CHARSET, 'utf-8'))
                    ),
                    'keyword2' => array(
                        'value' => urlencode(diconv(strip_tags(zm_diconv($postdata['keyword2'])), CHARSET, 'utf-8'))
                    ),
                    'remark' => array(
                        'value' => urlencode(diconv(strip_tags(zm_diconv($postdata['remark'])), CHARSET, 'utf-8')),
                        'color' => "#008000"
                    )

                )
            );
            $json     = urldecode(json_encode($template));
            $result   = $wechat_client->send_weixintemplate($json);

}

}else{

    require_once DISCUZ_ROOT . './source/plugin/zimu_zhaopin/class/wechat.lib.class.php';
    $wechat_client = new WeChatClient($zmdata['base']['weixin_appid'], $zmdata['base']['weixin_appsecret']);

    $weixin_openid = DB::fetch_first('select * from %t where uid=%d order by id desc', array(
        'zimu_zhaopin_members',
        $uid
    ));

    if($weixin_openid['openid']){
        $template = array(
            'touser' => $weixin_openid['openid'],
            'template_id' => $template_id,
            'url' => $postdata['url'],
            'topcolor' => "#7B68EE",
            'data' => array(
                'first' => array(
                    'value' => urlencode(diconv($postdata['first'], CHARSET, 'utf-8')),
                    'color' => "#FF4040"
                ),
                'keyword1' => array(
                    'value' => urlencode(diconv(strip_tags(zm_diconv($postdata['keyword1'])), CHARSET, 'utf-8'))
                ),
                'keyword2' => array(
                    'value' => urlencode(diconv(strip_tags(zm_diconv($postdata['keyword2'])), CHARSET, 'utf-8'))
                ),
                'keyword3' => array(
                    'value' => urlencode(diconv(strip_tags(zm_diconv($postdata['keyword3'])), CHARSET, 'utf-8'))
                ),
                'keyword4' => array(
                    'value' => urlencode(diconv(strip_tags(zm_diconv($postdata['keyword4'])), CHARSET, 'utf-8'))
                ),
                'keyword5' => array(
                    'value' => urlencode(diconv(strip_tags(zm_diconv($postdata['keyword5'])), CHARSET, 'utf-8'))
                ),
                'remark' => array(
                    'value' => urlencode(diconv(strip_tags(zm_diconv($postdata['remark'])), CHARSET, 'utf-8')),
                    'color' => "#008000"
                )

            )
        );
        $json     = urldecode(json_encode($template));
        $result   = $wechat_client->send_weixintemplate($json);
        //print_r($result);
    }

}

}


function notification_user2($uid,$template_id,$postdata,$posturl){
    global $_G;

$zmdata = $_G['cache']['plugin']['zimu_zhaopin'];

$setdata = DB::fetch_first('select * from %t order by id desc', array(
        'zimu_zhaopin_setting'
    ));

$zmdata['base'] = $setdata;
$zmdata['settings'] = unserialize($setdata['settings']);

    require_once DISCUZ_ROOT . './source/plugin/zimu_zhaopin/class/wechat.lib.class.php';
    $wechat_client = new WeChatClient($zmdata['base']['weixin_appid'], $zmdata['base']['weixin_appsecret']);

    $weixin_openid = DB::fetch_first('select * from %t where uid=%d order by id desc', array(
        'zimu_zhaopin_members',
        $uid
    ));

    if($weixin_openid['openid']){
        $template = array(
            'touser' => $weixin_openid['openid'],
            'template_id' => $template_id,
            'url' => $posturl,
            'topcolor' => "#7B68EE",
        );
        $template['data'] = $postdata;
        $json     = urldecode(json_encode($template));
        $result   = $wechat_client->send_weixintemplate($json);
    }

}

function notification_user_magapp($uid,$postdata){
    global $_G;

$mag_paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
    'zimu_zhaopin_parameter2',
    'magapp'
));
$mag_paramter = unserialize($mag_paramter['parameter']);

if($uid=='admin'){

$weixin_openid = explode(",", trim($mag_paramter['magapp_uids']));

foreach ($weixin_openid as $key => $value) {

notification_user_magapp($value,$postdata);

}


}else{

    $magurl = $mag_paramter['magapp_hostname'].'/mag/operative/v1/assistant/sendAssistantMsg';
    $magpostdata['user_id'] = $uid;
    $magpostdata['type'] = 'texttemp';
    $magpostdata['content'] = diconv($postdata,CHARSET,'utf-8');
    $magpostdata['assistant_secret'] = $mag_paramter['assistant_secret'];
    $magpostdata['secret'] = $mag_paramter['magapp_secret'];
    $magpostdata['is_push'] = 1;
    $magdata = lizimu_post($magurl,$magpostdata);

}

}


$navtitle = $zmdata['settings']['seo_title'];
$keywords = $zmdata['base']['keywords'];
$description = $zmdata['base']['description'];

$share_title = $zmdata['base']['share_title'];
$share_desc = $zmdata['base']['share_desc'];
$share_url = $_G['siteurl'].$_SERVER['REQUEST_URI'];

if(strpos($zmdata['base']['share_thumb'],'http') !== false){
    $share_thumb = $zmdata['base']['share_thumb'];
}else{
    $share_thumb = $_G['siteurl'].$zmdata['base']['share_thumb'];
}

$zimu_rewrite = dunserialize($_G['setting']['zimu_rewrite']);

$domainlist = $_G['setting']['domain']['list'];
foreach ($domainlist as $k => $v) {
    if ($v['idtype'] == 'plugin') {
        $domainlist2[$v['id']] = $k;
    }
}
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";

if($domainlist2['zimu_zhaopin']){
$zp_url = $protocol.$domainlist2['zimu_zhaopin'].'/';
$zp_url2 = $protocol.$domainlist2['zimu_zhaopin'].'/';
}else{
$zp_url = ZIMUCMS_URL;
$zp_url2 = $_G['siteurl'];
}

if($zimu_rewrite['zp_model']['available']){
$zp_url_jobs = $zp_url2.str_replace(array('{','}','model'),array('','','jobs'),$zimu_rewrite['zp_model']['rule']);
$zp_url_jobs2 = $zp_url_jobs.'?nature=63';
$zp_url_resume = $zp_url2.str_replace(array('{','}','model'),array('','','resume'),$zimu_rewrite['zp_model']['rule']);
$zp_url_qiye = $zp_url2.str_replace(array('{','}','model'),array('','','qiye'),$zimu_rewrite['zp_model']['rule']);
$zp_url_jobfair = $zp_url2.str_replace(array('{','}','model'),array('','','jobfair'),$zimu_rewrite['zp_model']['rule']);
$zp_url_news = $zp_url2.str_replace(array('{','}','model'),array('','','news'),$zimu_rewrite['zp_model']['rule']);
}else{
$zp_url_jobs = ZIMUCMS_URL.'&model=jobs';
$zp_url_jobs2 = $zp_url_jobs.'&nature=63';
$zp_url_resume = ZIMUCMS_URL.'&model=resume';
$zp_url_qiye = ZIMUCMS_URL.'&model=qiye';
$zp_url_jobfair = ZIMUCMS_URL.'&model=jobfair';
$zp_url_news = ZIMUCMS_URL.'&model=news';
}


function get_real_clientip(){
    $onlineip='';
    if (getenv('HTTP_CLIENT_IP') && strcasecmp(getenv('HTTP_CLIENT_IP'),'unknown')) {
        $onlineip=getenv('HTTP_CLIENT_IP');
    }else {
        if (getenv('HTTP_X_FORWARDED_FOR') && strcasecmp(getenv('HTTP_X_FORWARDED_FOR'),'unknown')) {
            $onlineip=getenv('HTTP_X_FORWARDED_FOR');
        }else {
            if (getenv('REMOTE_ADDR') && strcasecmp(getenv('REMOTE_ADDR'),'unknown')) {
                $onlineip=getenv('REMOTE_ADDR');
            }else {
                if (isset($_SERVER['REMOTE_ADDR']) && $_SERVER['REMOTE_ADDR']) {
                    $onlineip=$_SERVER['REMOTE_ADDR'];
                }
            }
        }
    }
    return $onlineip;
}

function zimu_tomedia($src){
        global $_G;
    $src = trim($src);
    if (empty($src)) {
        return '';
    }
    if ((substr($src, 0, 7) == 'http://') || (substr($src, 0, 8) == 'https://')) {
        return $src;
    }else{
        return $_G['siteurl'].$src;
    }
}
function zp_url_add($url,$url2){
if(strpos($url, '?') !== false){
return $url.$url2;
}else{
return $url.'?'.$url2;
}
}

$zimu_rewrite = dunserialize($_G['setting']['zimu_rewrite']);

function zp_url_replace($rulename,$replacename,$replaceid){

    global $_G;

$zimu_rewrite = dunserialize($_G['setting']['zimu_rewrite']);

$domainlist = $_G['setting']['domain']['list'];
foreach ($domainlist as $k => $v) {
    if ($v['idtype'] == 'plugin') {
        $domainlist2[$v['id']] = $k;
    }
}
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";

if($domainlist2['zimu_zhaopin']){
$zp_url = $protocol.$domainlist2['zimu_zhaopin'].'/';
$zp_url2 = $protocol.$domainlist2['zimu_zhaopin'].'/';
}else{
$zp_url = ZIMUCMS_URL;
$zp_url2 = $_G['siteurl'];
}

if($zimu_rewrite['zp_'.$rulename]['available']){
return $zp_url2.str_replace(array('{','}',$replacename),array('','',$replaceid),$zimu_rewrite['zp_'.$rulename]['rule']);

}else{
return ZIMUCMS_URL.'&model='.$rulename.'&'.$replacename.'='.$replaceid;
}

}

function isMobile($mobile) {
    if (!is_numeric($mobile)) {
        return false;
    }
    return preg_match('#^1[3,4,5,6,7,8,9]{1}[\d]{9}$#', $mobile) ? true : false;
}

    function notification_user_sms($mobile,$type,$tip=''){

        global $_G;
        $langfile = DISCUZ_ROOT . './source/plugin/zimu_zhaopin/language.' . currentlang() . '.php';
        $includefile = is_file($langfile) ? $langfile : libfile('language', 'plugin/zimu_zhaopin');
        include $includefile;
        $sms_paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
            'zimu_zhaopin_parameter2',
            'aliyunsms'
        ));
        $sms_paramter = unserialize($sms_paramter['parameter']);

        if($sms_paramter['chanyoo_username'] && $sms_paramter['chanyoo_password']) {
            $sms_url = 'https://api.chanyoo.net/sendsms';
            $postdata['username'] = $sms_paramter['chanyoo_username'];
            $postdata['password'] = $sms_paramter['chanyoo_password'];
            $postdata['mobile'] = $mobile;
            $content = $sms_paramter[$type];
            $content = str_replace('tip',$tip,$content);
            $content = zimu_array_utf8($content);
            $postdata['content'] = $content;
            $smsdata = lizimu_post($sms_url, $postdata);
            return $smsdata;
        }

    }
    function notification_user_sms2($uid,$mobile,$type,$find,$replace){

        global $_G;
        $langfile = DISCUZ_ROOT . './source/plugin/zimu_zhaopin/language.' . currentlang() . '.php';
        $includefile = is_file($langfile) ? $langfile : libfile('language', 'plugin/zimu_zhaopin');
        include $includefile;

        $sms_paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
            'zimu_zhaopin_parameter2',
            'aliyunsms'
        ));
        $sms_paramter = unserialize($sms_paramter['parameter']);
        $lastsms = DB::fetch_first('select * from %t where mobile=%d and type !=%s order by id desc', array(
            'zimu_zhaopin_sendsmslog',
            $mobile,
            'code'
        ));

        if(!$sms_paramter['sms_interval'] || $lastsms['addtime'] < time() - $sms_paramter['sms_interval']){

            if($sms_paramter['marketsms']!=1 && $sms_paramter['chanyoo_username'] && $sms_paramter['chanyoo_password']) {
                $sms_url = 'http://129.204.2.99:8001/sendsms';
                $postdata['username'] = $sms_paramter['chanyoo_username'];
                $postdata['password'] = $sms_paramter['chanyoo_password'];
                $postdata['mobile'] = $mobile;
                $content = $sms_paramter[$type];
                $content = $content2 = str_replace($find,$replace,$content);
                $content = zimu_array_utf8($content);
                $postdata['content'] = $content;
                $smsdata = lizimu_post($sms_url, $postdata);

                $sendsmslog = ['uid' => $uid,'mobile' => $mobile,'con' => $content2,'type' => $type,'addtime' => time()];
                DB::insert('zimu_zhaopin_sendsmslog', $sendsmslog);

                return $smsdata;

            }
        }
    }
    function check_complete_percent($uid){
        $complete_percent = 58;
        $companyname = DB::fetch_first('select * from %t where uid=%d and companyname!=%s order by id desc', array(
            'zimu_zhaopin_resume_work',
            $uid,
            ''
        ));
        if($companyname){
            $complete_percent = $complete_percent+7;
        }
        $jobs = DB::fetch_first('select * from %t where uid=%d and jobs!=%s order by id desc', array(
            'zimu_zhaopin_resume_work',
            $uid,
            ''
        ));
        if($jobs){
            $complete_percent = $complete_percent+7;
        }
        $achievements = DB::fetch_first('select * from %t where uid=%d and achievements!=%s order by id desc', array(
            'zimu_zhaopin_resume_work',
            $uid,
            ''
        ));
        if($achievements){
            $complete_percent = $complete_percent+7;
        }
        $school = DB::fetch_first('select * from %t where uid=%d and school!=%s order by id desc', array(
            'zimu_zhaopin_resume_education',
            $uid,
            ''
        ));
        if($school){
            $complete_percent = $complete_percent+7;
        }
        $speciality = DB::fetch_first('select * from %t where uid=%d and speciality!=%s order by id desc', array(
            'zimu_zhaopin_resume_education',
            $uid,
            ''
        ));
        if($speciality){
            $complete_percent = $complete_percent+7;
        }
        $education_cn = DB::fetch_first('select * from %t where uid=%d and education_cn!=%s order by id desc', array(
            'zimu_zhaopin_resume_education',
            $uid,
            ''
        ));
        if($education_cn){
            $complete_percent = $complete_percent+7;
        }
        return $complete_percent;
    }
    function get_money_currency($appcode,$amount,$tomoney){
        $host = "https://jisuhuilv.market.alicloudapi.com";
        $path = "/exchange/convert";
        $method = "GET";
        $headers = array();
        array_push($headers, "Authorization:APPCODE " . $appcode);
        array_push($headers, "Content-Type".":"."application/json; charset=UTF-8");
        $querys = "amount=".$amount."&from=".$tomoney."&to=CNY";
        $bodys = "null";
        $url = $host . $path . "?" . $querys;
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $method);
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($curl, CURLOPT_FAILONERROR, false);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_HEADER, false);
        if (1 == strpos("$".$host, "https://"))
        {
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
        }
        curl_setopt($curl, CURLOPT_POSTFIELDS, $bodys);
        $res = curl_exec($curl);
        return $res;
    }
    function zimu_cutstr2($string, $length, $dot = '') {
        if(strlen($string) <= $length) {
            return $string;
        }

        $pre = chr(1);
        $end = chr(1);
        $string = str_replace(array('&amp;', '&quot;', '&lt;', '&gt;'), array($pre.'&'.$end, $pre.'"'.$end, $pre.'<'.$end, $pre.'>'.$end), $string);

        $strcut = '';
        if(strtolower(CHARSET) == 'utf-8') {

            $n = $tn = $noc = 0;
            while($n < strlen($string)) {

                $t = ord($string[$n]);
                if($t == 9 || $t == 10 || (32 <= $t && $t <= 126)) {
                    $tn = 1; $n++; $noc++;
                } elseif(194 <= $t && $t <= 223) {
                    $tn = 2; $n += 2; $noc += 2;
                } elseif(224 <= $t && $t <= 239) {
                    $tn = 3; $n += 3; $noc += 2;
                } elseif(240 <= $t && $t <= 247) {
                    $tn = 4; $n += 4; $noc += 2;
                } elseif(248 <= $t && $t <= 251) {
                    $tn = 5; $n += 5; $noc += 2;
                } elseif($t == 252 || $t == 253) {
                    $tn = 6; $n += 6; $noc += 2;
                } else {
                    $n++;
                }

                if($noc >= $length) {
                    break;
                }

            }
            if($noc > $length) {
                $n -= $tn;
            }

            $strcut = substr($string, 0, $n);

        } else {
            $_length = $length - 1;
            for($i = 0; $i < $length; $i++) {
                if(ord($string[$i]) <= 127) {
                    $strcut .= $string[$i];
                } else if($i < $_length) {
                    $strcut .= $string[$i].$string[++$i];
                }
            }
        }

        $strcut = str_replace(array($pre.'&'.$end, $pre.'"'.$end, $pre.'<'.$end, $pre.'>'.$end), array('&amp;', '&quot;', '&lt;', '&gt;'), $strcut);

        $pos = strrpos($strcut, chr(1));
        if($pos !== false) {
            $strcut = substr($strcut,0,$pos);
        }
        return $strcut.$dot;
    }
    function zm_saveimages_base64($img_base64)
    {
        global $_G;
        $filename      = uniqid() . '.jpg';

        if (preg_match('/^(data:\s*image\/(\w+);base64,)/',$img_base64,$result)){


            $pic           = base64_decode(str_replace($result[1],'',$img_base64));

            $date        = date('ym/d/');
            $save_avatar = DISCUZ_ROOT . './source/plugin/zimu_zhaopin/uploadzimucms/' . $date;

            if (!is_dir($save_avatar)) {
                mkdir($save_avatar, 0777, true);
            }

            file_put_contents($save_avatar . $filename, $pic);

            $oss_paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
                'zimu_zhaopin_parameter2',
                'alioss'
            ));
            $oss_paramter = unserialize($oss_paramter['parameter']);

            if(!$oss_paramter['oss_type'] && $oss_paramter['ACCESS_ID'] && $oss_paramter['ACCESS_KEY'] && $oss_paramter['ENDPOINT'] && $oss_paramter['BUCKET']){
                $saved_file = DISCUZ_ROOT.'/source/plugin/zimu_zhaopin/uploadzimucms/' . $date . $filename;
                include_once DISCUZ_ROOT.'source/plugin/zimu_zhaopin/lib/OSS/Common.php';
                if ($surl = zm_oss_upload('zimu_zhaopin/' . $date . $filename, $saved_file)) {
                    @unlink($saved_file);
                    return $imgurl = $surl;
                    exit();
                }
            }elseif ($oss_paramter['oss_type']==1 && $oss_paramter['qn_ak'] && $oss_paramter['qn_sk'] && $oss_paramter['qn_bk']){

                $saved_file = DISCUZ_ROOT.'/source/plugin/zimu_zhaopin/uploadzimucms/' . $date . $filename;
                include_once(DISCUZ_ROOT.'source/plugin/zimu_zhaopin/lib/Qiniu/upload.php');
                if ($surl=zm_qn_upload('zimu_zhaopin/' . $date . $filename,$saved_file)) {
                    unlink($saved_file);
                    error_reporting(0);
                    return $imgurl = $surl;
                }

            }

            $show_path = $_G['siteurl'] . 'source/plugin/zimu_zhaopin/uploadzimucms/' . $date . $filename;

            return $show_path;
        }
    }