<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

include_once DISCUZ_ROOT.'source/plugin/zimu_zhaopin/lib/Qiniu/Qiniu/Http/Client.php';
include_once DISCUZ_ROOT.'source/plugin/zimu_zhaopin/lib/Qiniu/Qiniu/Http/Error.php';
include_once DISCUZ_ROOT.'source/plugin/zimu_zhaopin/lib/Qiniu/Qiniu/Http/Request.php';
include_once DISCUZ_ROOT.'source/plugin/zimu_zhaopin/lib/Qiniu/Qiniu/Http/Response.php';
include_once DISCUZ_ROOT.'source/plugin/zimu_zhaopin/lib/Qiniu/Qiniu/Processing/ImageUrlBuilder.php';
include_once DISCUZ_ROOT.'source/plugin/zimu_zhaopin/lib/Qiniu/Qiniu/Processing/Operation.php';
include_once DISCUZ_ROOT.'source/plugin/zimu_zhaopin/lib/Qiniu/Qiniu/Processing/PersistentFop.php';
include_once DISCUZ_ROOT.'source/plugin/zimu_zhaopin/lib/Qiniu/Qiniu/Storage/BucketManager.php';
include_once DISCUZ_ROOT.'source/plugin/zimu_zhaopin/lib/Qiniu/Qiniu/Storage/FormUploader.php';
include_once DISCUZ_ROOT.'source/plugin/zimu_zhaopin/lib/Qiniu/Qiniu/Storage/ResumeUploader.php';
include_once DISCUZ_ROOT.'source/plugin/zimu_zhaopin/lib/Qiniu/Qiniu/Storage/UploadManager.php';
include_once DISCUZ_ROOT.'source/plugin/zimu_zhaopin/lib/Qiniu/Qiniu/Auth.php';
include_once DISCUZ_ROOT.'source/plugin/zimu_zhaopin/lib/Qiniu/Qiniu/Config.php';
include_once DISCUZ_ROOT.'source/plugin/zimu_zhaopin/lib/Qiniu/Qiniu/Etag.php';
include_once DISCUZ_ROOT.'source/plugin/zimu_zhaopin/lib/Qiniu/Qiniu/functions.php';
include_once DISCUZ_ROOT.'source/plugin/zimu_zhaopin/lib/Qiniu/Qiniu/Zone.php';

use Qiniu\Auth;

use Qiniu\Storage\UploadManager;


function zm_qn_upload($filena, $saved_file){
    global $_G;

    $paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
        'zimu_zhaopin_parameter2',
        'alioss'
    ));

    $paramters = unserialize($paramter['parameter']);

    $accessKey = $paramters['qn_ak'];
    $secretKey = $paramters['qn_sk'];
    $bucket    = $paramters['qn_bk'];

    try{
        $auth = new Auth($accessKey, $secretKey);
        $token = $auth->uploadToken($bucket);
        $uploadMgr = new UploadManager();
        list($ret, $err) = $uploadMgr->putFile($token, $filena, $saved_file);
        if ($err !== null) {
            $rs = $err->message();
        } else {
            $rs = rtrim($paramters['qn_url'], '/').'/'.$ret['key'];
        }
    }catch (Exception $e){
        $rs = $e->getMessage();
    }
    return $rs;
}

function zm_qn_gettoken(){
    global $_G, $ERROR_MSG;

    $paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
        'zimu_zhaopin_parameter2',
        'alioss'
    ));

    $paramters = unserialize($paramter['parameter']);

    $accessKey = $paramters['qn_ak'];
    $secretKey = $paramters['qn_sk'];
    $bucket    = $paramters['qn_bk'];

    try{
        $auth = new Auth($accessKey, $secretKey);
        $token = $auth->uploadToken($bucket);
    }catch (Exception $e){
        $token = '';
        $ERROR_MSG = $e->getMessage();
    }
    return $token;
}

function zm_qn_delete_img($key){
    global $_G, $ERROR_MSG;

    $paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
        'zimu_zhaopin_parameter2',
        'alioss'
    ));

    $paramters = unserialize($paramter['parameter']);

    $accessKey = $paramters['qn_ak'];
    $secretKey = $paramters['qn_sk'];
    $bucket    = $paramters['qn_bk'];

    $auth = new Auth($accessKey, $secretKey);
    $qnconfig = new \Qiniu\Config();
    $bucketManager = new \Qiniu\Storage\BucketManager($auth, $qnconfig);
    $err = $bucketManager->delete($bucket, $key);
    if ($err=='') {
        return 1;
    }else{
        $ERROR_MSG = $err;
        return 0;
    }
}