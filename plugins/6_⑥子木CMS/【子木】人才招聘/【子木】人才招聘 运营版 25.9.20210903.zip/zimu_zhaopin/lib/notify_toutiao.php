<?php

    define('IN_API', true);
    define('CURSCRIPT', 'api');
    define('DISABLEXSSCHECK', true);

    require_once '../../../../source/class/class_core.php';
    $discuz = C::app();
    $discuz->init();

    $_G['siteurl'] = str_replace('source/plugin/zimu_zhaopin/lib/', '', $_G['siteurl']);

    include_once DISCUZ_ROOT .'source/plugin/zimu_zhaopin/config.php';

    global $_G;
    if (!$_G['cache']['plugin']) {
        loadcache('plugin');
    }

    $setdata = DB::fetch_first('select * from %t order by id desc', array(
        'zimu_zhaopin_setting'
    ));
    $zmdata['settings'] = unserialize($setdata['settings']);


    $xml = file_get_contents("php://input");
    $result = json_decode($xml,true);
    $result = json_decode($result['msg'],true);
    $result = zimu_array_utf8tomy($result);
    $order_id  = $result['cp_orderno'];
    if($order_id){
        $order = DB::fetch_first('select * from %t where oid=%s order by id desc', array(
            'zimu_zhaopin_order',
            $order_id
        ));
        $order['params'] = $order['params']?unserialize($order['params']):array();

        if($order && $order['is_paid'] == 1) {

            require_once(DISCUZ_ROOT . './source/plugin/zimu_zhaopin/lib/fengkuipay/vendor/autoload.php');
            $pburl = $_G['siteurl'];
            $bytedanceConfig = [
                'app_id'        => $zmdata['settings']['toutiao_appid'],
                'salt'          => $zmdata['settings']['toutiao_salt'],
                'notify_url'    => $pburl . 'source/plugin/zimu_zhaopin/lib/notify_toutiao.php',
                'thirdparty_id' => '',
            ];
            $pay = new \fengkui\Pay\Bytedance($bytedanceConfig);
            $res = $pay->queryOrder($order_id);
            if($res['payment_info']['order_status']=='SUCCESS'){
                DB::query("update %t set payment=%s where oid=%s", array(
                    'zimu_zhaopin_order',
                    $res['payment_info']['way']==1 ? 'toutiao_wxpay' : 'toutiao_alipay',
                    $order_id
                ));
                finish_order($order, $order['order_sn'], $postprice, 'WECAHT');
            }
        }

    }

    echo '{"err_no": 0,"err_tips": "success"}';exit();