<?php

define('IN_API', true);
define('CURSCRIPT', 'api');
define('DISABLEXSSCHECK', true);

require_once '../../../../source/class/class_core.php';
$discuz = C::app();
$discuz->init();

$_G['siteurl'] = str_replace('source/plugin/zimu_zhaopin/lib/', '', $_G['siteurl']);

include_once DISCUZ_ROOT .'source/plugin/zimu_zhaopin/config.php';

global $_G;
if (!$_G['cache']['plugin']) {
    loadcache('plugin');
}

$qf_paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
    'zimu_zhaopin_parameter2',
    'qfapp'
));
$qf_paramter = unserialize($qf_paramter['parameter']);



$qforder_id = $_REQUEST['order_id'];

    require_once DISCUZ_ROOT . './source/plugin/zimu_zhaopin/class/qfapp.class.php';
    $client = new QF_HTTP_CLIENT($qf_paramter['qf_hostname'], $qf_paramter['qf_secret']);
    $retqf = $client->get('payments/'.$qforder_id);


if ($retqf['data']['pay'] == 1) {

    $order = DB::fetch_first('select * from %t where order_sn=%s and payment=%s order by id desc', array(
        'zimu_zhaopin_order',
        $qforder_id,
        'qfapp'
    ));
    $order['params'] = $order['params']?unserialize($order['params']):array();

        if($order['is_paid'] == 1 && $order['order_sn']){
            finish_order($order, $order['order_sn'], $order['amount'], 'WECAHT');
        }
}

echo "success";exit();