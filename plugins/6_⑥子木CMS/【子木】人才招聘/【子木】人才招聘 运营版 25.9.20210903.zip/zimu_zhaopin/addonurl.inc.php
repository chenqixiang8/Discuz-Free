<?php
    /*
    ��ľCMS http://www.zimucms.com/
    CopyRight 2016 All Rights Reserved
    */
    if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
        exit('Access Denied');
    }

    echo '<div style="height:30px;"></div>';

    echo '<div class="infobox"><h4 class="infotitle3">&#21518;&#21488;&#22320;&#22336;&#20026;&#65306;<a href="'.$_G[siteurl].'plugin.php?id=zimu_zhaopin&model=admins" target="_blank">'.$_G[siteurl].'plugin.php?id=zimu_zhaopin&model=admins</a></h4><p class="marginbot"></p><h4 class="infotitle3">&#80;&#67;&#29256;&#26412;&#21644;&#32769;&#29256;&#25163;&#26426;&#29256;&#35775;&#38382;&#22320;&#22336;&#65306;<a href="'.$_G[siteurl].'plugin.php?id=zimu_zhaopin" target="_blank">'.$_G[siteurl].'plugin.php?id=zimu_zhaopin</a></h4><p class="marginbot"></p><h4 class="infotitle3">&#26032;&#29256;&#25163;&#26426;&#29256;&#35775;&#38382;&#22320;&#22336;&#20026;&#65306;<a href="'.$_G[siteurl].'source/plugin/zimu_zhaopin/h5/" target="_blank">'.$_G[siteurl].'source/plugin/zimu_zhaopin/h5/</a></h4><p class="marginbot"></p><h4 class="infotitle3">&#26032;&#29256;&#80;&#67;&#21518;&#21488;&#35775;&#38382;&#22320;&#22336;&#20026;<a href="'.$_G[siteurl].'source/plugin/zimu_zhaopin/admins/" target="_blank">'.$_G[siteurl].'source/plugin/zimu_zhaopin/admins/</a></h4></div>';
