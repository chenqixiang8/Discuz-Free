const wxApi_xcx = {
	siteurl: null,
	moreurl: null,
	wxRegister(callback) {
		let _this = this;
		let pages = getCurrentPages();
		let route = pages[pages.length - 1].route;
		if(_this.moreurl){
			var tourl = _this.siteurl + ':new&model=wechatsign_xcx'+_this.moreurl;
		}else{
			var tourl = _this.siteurl + ':new&model=wechatsign_xcx';
		}
		uni.request({
			url: tourl,
			method: 'POST',
			data: {
				path: route
			},
			header: {
				'content-type': 'application/x-www-form-urlencoded',
			},
			success: (res) => {
				let data = res.data;

				uni.setNavigationBarTitle({
					title: data.shareOptions.navtitle
				})
				
				callback && callback(data.shareOptions);
			}
		});

	}
}
export default wxApi_xcx
