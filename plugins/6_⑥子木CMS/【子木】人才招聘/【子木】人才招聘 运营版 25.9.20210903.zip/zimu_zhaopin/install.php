<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$sql = <<<SQL


CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_area` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` char(100) NOT NULL,
  `sort` smallint(3) UNSIGNED NOT NULL DEFAULT '100',
  `parentid` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_category` (
  `c_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `c_parentid` int(10) UNSIGNED NOT NULL,
  `c_alias` char(30) NOT NULL,
  `c_name` char(30) NOT NULL,
  `c_order` int(10) NOT NULL,
  `c_index` char(1) NOT NULL,
  `c_note` char(60) NOT NULL,
  `stat_jobs` char(15) NOT NULL,
  `stat_resume` char(15) NOT NULL,
  PRIMARY KEY (`c_id`),
  KEY `c_alias` (`c_alias`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_category_district` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `parentid` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `categoryname` varchar(30) NOT NULL,
  `category_order` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `stat_jobs` varchar(15) NOT NULL,
  `stat_resume` varchar(15) NOT NULL,
  `spell` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_category_jobs` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `parentid` smallint(5) UNSIGNED NOT NULL,
  `categoryname` varchar(80) NOT NULL,
  `category_order` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `stat_jobs` varchar(15) NOT NULL,
  `stat_resume` varchar(15) NOT NULL,
  `content` text,
  `spell` varchar(200) NOT NULL,
  `relation1` varchar(30) DEFAULT NULL,
  `relation1_cn` varchar(30) DEFAULT NULL,
  `relation2` varchar(30) DEFAULT NULL,
  `relation2_cn` varchar(30) DEFAULT NULL,
  `istop` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `parentid` (`parentid`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_category_major` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `parentid` int(10) NOT NULL,
  `categoryname` varchar(50) NOT NULL,
  `category_order` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_company_down_resume` (
  `did` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `resume_id` int(10) UNSIGNED NOT NULL,
  `company_uid` int(10) UNSIGNED NOT NULL,
  `down_addtime` int(10) UNSIGNED NOT NULL,
  `is_reply` tinyint(1) UNSIGNED NOT NULL DEFAULT '1',
  PRIMARY KEY (`did`),
  KEY `down_addtime` (`down_addtime`)
) ENGINE=MyISAM AUTO_INCREMENT=1;



CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_company_favorites` (
  `did` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `resume_id` int(10) UNSIGNED NOT NULL,
  `company_uid` int(10) UNSIGNED NOT NULL,
  `favorites_addtime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`did`),
  KEY `company_uid` (`company_uid`)
) ENGINE=MyISAM AUTO_INCREMENT=1;



CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_company_profile` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` int(10) UNSIGNED NOT NULL,
  `admin_uid` varchar(255) NOT NULL,
  `companyname` varchar(60) NOT NULL,
  `nature` smallint(5) UNSIGNED NOT NULL,
  `nature_cn` varchar(30) NOT NULL,
  `trade` smallint(5) UNSIGNED NOT NULL,
  `trade_cn` varchar(30) NOT NULL,
  `district` varchar(100) NOT NULL DEFAULT '',
  `district_cn` varchar(100) NOT NULL DEFAULT '',
  `scale` smallint(5) UNSIGNED NOT NULL,
  `scale_cn` varchar(30) NOT NULL,
  `address` varchar(250) NOT NULL,
  `contact` varchar(100) NOT NULL,
  `telephone` varchar(130) NOT NULL,
  `landline_tel` varchar(50) NOT NULL,
  `certificate_img` varchar(255) NOT NULL,
  `certificate_img_audit` tinyint(1) NOT NULL,
  `certificate_img_tpl` varchar(255) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `environment` varchar(10000) NOT NULL,
  `contents` text NOT NULL,
  `setmeal_id` smallint(5) UNSIGNED NOT NULL,
  `setmeal_name` varchar(30) NOT NULL,
  `audit` tinyint(4) UNSIGNED NOT NULL DEFAULT '0',
  `map_x` decimal(9,6) NOT NULL,
  `map_y` decimal(9,6) NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  `refreshtime` int(10) UNSIGNED NOT NULL,
  `logintime` int(10) UNSIGNED NOT NULL,
  `click` int(10) UNSIGNED NOT NULL DEFAULT '1',
  `tag` varchar(60) NOT NULL,
  `tag_cn` char(100) NOT NULL,
  `replys` int(10) UNSIGNED NOT NULL,
  `wxtpl` char(200) NOT NULL,
  `is_pcad` tinyint(1) UNSIGNED NOT NULL,
  `pcad` char(200) NOT NULL,
  `company_mingqi` tinyint(1) NOT NULL,
  `kefu_uid` int(10) UNSIGNED NOT NULL,
  `kefu_name` char(20) NOT NULL,
  `weixin` char(30) NOT NULL,
  `bind_weixin` tinyint(1) UNSIGNED NOT NULL,
  `is_contact` tinyint(1) UNSIGNED NOT NULL,
  `is_wechat` tinyint(1) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `audit` (`audit`),
  KEY `companyname` (`companyname`),
  KEY `addtime` (`addtime`),
  KEY `jobs_rtime` (`refreshtime`),
  KEY `setmeal_id` (`setmeal_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;



CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_jobs` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` int(10) UNSIGNED NOT NULL,
  `jobs_name` varchar(50) NOT NULL,
  `companyname` varchar(50) NOT NULL,
  `company_id` int(10) UNSIGNED NOT NULL,
  `company_certificate` tinyint(1) NOT NULL,
  `company_mingqi` tinyint(1) NOT NULL,
  `company_audit` tinyint(1) NOT NULL,
  `emergency` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `stick` tinyint(1) NOT NULL,
  `stick_endtime` int(10) UNSIGNED NOT NULL,
  `nature` int(10) UNSIGNED NOT NULL,
  `nature_cn` varchar(30) NOT NULL,
  `sex` tinyint(1) UNSIGNED NOT NULL DEFAULT '3',
  `sex_cn` varchar(3) NOT NULL,
  `age` varchar(10) NOT NULL,
  `amount` smallint(5) UNSIGNED NOT NULL,
  `topclass` smallint(5) UNSIGNED NOT NULL,
  `category` smallint(5) UNSIGNED NOT NULL,
  `subclass` smallint(5) UNSIGNED NOT NULL,
  `category_cn` varchar(100) NOT NULL DEFAULT '',
  `category_sort` char(100) NOT NULL,
  `trade` smallint(5) UNSIGNED NOT NULL,
  `trade_cn` varchar(30) NOT NULL,
  `scale` smallint(5) UNSIGNED NOT NULL,
  `scale_cn` varchar(30) NOT NULL,
  `district` varchar(100) NOT NULL DEFAULT '',
  `district_cn` varchar(100) NOT NULL,
  `district2` varchar(100) NOT NULL DEFAULT '',
  `district3` varchar(100) NOT NULL DEFAULT '',
  `tag` varchar(50) NOT NULL,
  `tag_cn` varchar(100) NOT NULL,
  `education` smallint(5) UNSIGNED NOT NULL,
  `education_cn` varchar(30) NOT NULL,
  `experience` smallint(5) UNSIGNED NOT NULL,
  `experience_cn` varchar(30) NOT NULL,
  `minwage` int(10) NOT NULL,
  `maxwage` int(10) NOT NULL,
  `wage` smallint(5) UNSIGNED NOT NULL,
  `wage_cn` varchar(50) NOT NULL,
  `contents` text NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  `uptime` int(10) UNSIGNED NOT NULL,
  `refreshtime` int(10) UNSIGNED NOT NULL,
  `stime` int(10) NOT NULL,
  `setmeal_deadline` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `setmeal_id` smallint(5) UNSIGNED NOT NULL,
  `setmeal_name` varchar(60) NOT NULL,
  `audit` tinyint(1) UNSIGNED NOT NULL DEFAULT '1',
  `display` tinyint(1) UNSIGNED NOT NULL DEFAULT '1',
  `click` int(10) UNSIGNED NOT NULL DEFAULT '1',
  `map_x` decimal(9,6) NOT NULL,
  `map_y` decimal(9,6) NOT NULL,
  `allowance_id` int(10) UNSIGNED NOT NULL,
  `wxtpl` char(200) NOT NULL,
  `ispay` tinyint(1) UNSIGNED NOT NULL,
  `parttime_type` tinyint(1) UNSIGNED NOT NULL,
  `parttime_money` varchar(30) NOT NULL,
  `job_tel_apply` tinyint(1) UNSIGNED NOT NULL,
  `contact` varchar(100) NOT NULL,
  `telephone` varchar(20) NOT NULL,
  `resume_complete_percent` tinyint(3) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `company_id` (`company_id`),
  KEY `audit_id` (`audit`,`id`),
  KEY `audit_deadline` (`audit`),
  KEY `audit_addtime` (`audit`,`addtime`),
  KEY `audit_refreshtime` (`audit`,`refreshtime`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_members` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` int(10) UNSIGNED NOT NULL,
  `utype` tinyint(1) UNSIGNED NOT NULL DEFAULT '2',
  `openid` varchar(1000) NOT NULL,
  `unionid` varchar(1000) NOT NULL,
  `telephone` char(100) NOT NULL,
  `verify_code` char(100) NOT NULL,
  `points` int(10) UNSIGNED NOT NULL,
  `token` char(200) NOT NULL,
  `xcx_openid` varchar(1000) NOT NULL,
  `blacklist` tinyint(1) UNSIGNED NOT NULL,
  `onlinetime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_members_setmeal` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `expire` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `uid` int(10) UNSIGNED NOT NULL,
  `setmeal_id` int(10) UNSIGNED NOT NULL,
  `setmeal_name` varchar(200) NOT NULL,
  `days` int(10) UNSIGNED NOT NULL,
  `expense` int(10) UNSIGNED NOT NULL,
  `set_sms` int(10) UNSIGNED NOT NULL,
  `jobs_meanwhile` int(10) UNSIGNED NOT NULL,
  `refresh_jobs_free` int(10) UNSIGNED NOT NULL,
  `download_resume` int(10) UNSIGNED NOT NULL,
  `download_resume2` int(10) UNSIGNED NOT NULL,
  `download_resume_max` int(10) UNSIGNED NOT NULL,
  `added` varchar(250) NOT NULL,
  `starttime` int(10) UNSIGNED NOT NULL,
  `endtime` int(10) UNSIGNED NOT NULL,
  `show_apply_contact` tinyint(1) UNSIGNED NOT NULL,
  `is_free` tinyint(1) UNSIGNED NOT NULL,
  `discount_download_resume` double(2,1) UNSIGNED NOT NULL,
  `discount_sms` double(2,1) UNSIGNED NOT NULL,
  `discount_stick` double(2,1) UNSIGNED NOT NULL,
  `discount_emergency` double(2,1) UNSIGNED NOT NULL,
  `discount_auto_refresh_jobs` double(2,1) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  KEY `effective_setmealid` (`expire`,`setmeal_id`),
  KEY `effective_endtime` (`expire`,`endtime`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_order` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `oid` varchar(200) NOT NULL,
  `zpid` int(10) UNSIGNED NOT NULL,
  `uid` int(10) UNSIGNED NOT NULL,
  `openid` varchar(1000) NOT NULL,
  `utype` tinyint(2) UNSIGNED NOT NULL DEFAULT '1',
  `order_type` int(10) UNSIGNED NOT NULL,
  `pay_type` tinyint(1) UNSIGNED NOT NULL,
  `is_paid` tinyint(3) UNSIGNED NOT NULL DEFAULT '1',
  `order_sn` varchar(100) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `pay_amount` decimal(10,2) NOT NULL,
  `pay_points` int(10) UNSIGNED NOT NULL,
  `payment` varchar(20) NOT NULL,
  `payment_cn` varchar(20) NOT NULL,
  `description` varchar(150) NOT NULL,
  `service_name` varchar(30) NOT NULL,
  `points` int(10) UNSIGNED NOT NULL,
  `setmeal` int(10) UNSIGNED NOT NULL,
  `params` text NOT NULL,
  `notes` varchar(150) NOT NULL,
  `addtime` int(11) UNSIGNED NOT NULL,
  `payment_time` int(10) UNSIGNED NOT NULL,
  `discount` varchar(200) NOT NULL,
  `fee` decimal(10,2) NOT NULL,
  `referer` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `addtime` (`addtime`),
  KEY `payment_name` (`payment`),
  KEY `oid` (`oid`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_parameter2` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` char(100) NOT NULL,
  `parameter` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_personal_favorites` (
  `did` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `personal_uid` int(10) UNSIGNED NOT NULL,
  `jobs_id` int(10) UNSIGNED NOT NULL,
  `jobs_name` varchar(1000) NOT NULL,
  `company_id` int(10) UNSIGNED NOT NULL,
  `company_uid` int(10) UNSIGNED NOT NULL,
  `company_name` char(100) NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`did`),
  KEY `personal_uid` (`personal_uid`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_personal_focus_company` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `addtime` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `company_id` (`company_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_personal_jobs_apply` (
  `did` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `resume_id` int(10) UNSIGNED NOT NULL,
  `resume_name` varchar(60) NOT NULL,
  `personal_uid` int(10) UNSIGNED NOT NULL,
  `jobs_id` int(10) UNSIGNED NOT NULL,
  `jobs_name` varchar(60) NOT NULL,
  `company_id` int(10) UNSIGNED NOT NULL,
  `company_name` varchar(60) NOT NULL,
  `company_uid` int(10) UNSIGNED NOT NULL,
  `apply_addtime` int(10) UNSIGNED NOT NULL,
  `personal_look` tinyint(3) UNSIGNED NOT NULL DEFAULT '1',
  `notes` varchar(200) NOT NULL,
  `is_reply` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `is_apply` tinyint(1) NOT NULL DEFAULT '0',
  `reply_time` int(11) NOT NULL,
  PRIMARY KEY (`did`),
  KEY `personal_uid_id` (`personal_uid`,`resume_id`),
  KEY `company_uid_jobid` (`company_uid`,`jobs_id`),
  KEY `company_uid_look` (`company_uid`,`personal_look`),
  KEY `personal_uid_addtime` (`personal_uid`,`apply_addtime`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_refresh_log` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` int(10) UNSIGNED NOT NULL,
  `mode` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `addtime` int(10) UNSIGNED NOT NULL,
  `type` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_resume` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` int(10) UNSIGNED NOT NULL,
  `admin_uid` varchar(255) NOT NULL,
  `display` tinyint(3) UNSIGNED NOT NULL DEFAULT '1',
  `audit` tinyint(3) UNSIGNED NOT NULL DEFAULT '1',
  `stick` tinyint(1) UNSIGNED NOT NULL,
  `stick_endtime` int(10) UNSIGNED NOT NULL,
  `strong_tag` char(50) NOT NULL,
  `strong_tag_endtime` int(10) UNSIGNED NOT NULL,
  `title` varchar(80) NOT NULL,
  `fullname` varchar(15) NOT NULL,
  `sex` tinyint(3) UNSIGNED NOT NULL,
  `sex_cn` varchar(3) NOT NULL,
  `nature` int(10) UNSIGNED NOT NULL,
  `nature_cn` varchar(30) NOT NULL,
  `trade` varchar(60) NOT NULL,
  `trade_cn` varchar(100) NOT NULL,
  `birthdate` smallint(4) UNSIGNED NOT NULL,
  `age` int(10) UNSIGNED NOT NULL,
  `height` varchar(5) NOT NULL,
  `marriage` tinyint(3) UNSIGNED NOT NULL,
  `marriage_cn` varchar(5) NOT NULL,
  `experience` smallint(5) NOT NULL,
  `experience_cn` varchar(30) NOT NULL,
  `district` varchar(100) NOT NULL,
  `district_cn` varchar(255) NOT NULL DEFAULT '',
  `wage` smallint(5) UNSIGNED NOT NULL,
  `wage_cn` varchar(30) NOT NULL,
  `education` smallint(5) UNSIGNED NOT NULL,
  `education_cn` varchar(30) NOT NULL,
  `major` smallint(5) NOT NULL,
  `major_cn` varchar(50) NOT NULL,
  `tag` varchar(50) NOT NULL,
  `tag_cn` varchar(100) NOT NULL,
  `telephone` varchar(50) NOT NULL,
  `intention_jobs_id` varchar(100) NOT NULL,
  `intention_jobs` varchar(255) NOT NULL,
  `specialty` varchar(1000) NOT NULL,
  `photo` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `photo_img` varchar(255) NOT NULL,
  `photo_audit` tinyint(1) UNSIGNED NOT NULL DEFAULT '1',
  `photo_display` tinyint(1) UNSIGNED NOT NULL DEFAULT '1',
  `qq` varchar(30) NOT NULL,
  `weixin` varchar(30) NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  `refreshtime` int(10) UNSIGNED NOT NULL,
  `logintime` int(10) UNSIGNED NOT NULL,
  `stime` int(10) NOT NULL,
  `entrust` tinyint(2) UNSIGNED NOT NULL DEFAULT '0',
  `talent` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `level` tinyint(1) UNSIGNED NOT NULL,
  `complete_percent` tinyint(3) UNSIGNED NOT NULL DEFAULT '0',
  `current` smallint(5) UNSIGNED NOT NULL,
  `current_cn` varchar(50) NOT NULL DEFAULT '',
  `click` int(10) UNSIGNED NOT NULL DEFAULT '1',
  `resume_from_pc` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `def` tinyint(1) NOT NULL,
  `mobile_audit` tinyint(1) NOT NULL,
  `comment_content` varchar(255) NOT NULL,
  `is_quick` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `wxtpl` char(200) NOT NULL,
  `bind_weixin` tinyint(1) UNSIGNED NOT NULL,
  `is_contact` tinyint(1) UNSIGNED NOT NULL,
  `is_wechat` tinyint(1) UNSIGNED NOT NULL,
  `kefu_uid` int(10) UNSIGNED NOT NULL,
  `kefu_name` char(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `refreshtime` (`refreshtime`),
  KEY `addtime` (`addtime`),
  KEY `audit_addtime` (`audit`,`addtime`),
  KEY `audit_display` (`audit`,`display`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_resume_credent` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `pid` int(10) UNSIGNED NOT NULL,
  `uid` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `year` int(4) NOT NULL,
  `month` int(2) NOT NULL,
  `images` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_resume_education` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `pid` int(10) UNSIGNED NOT NULL,
  `uid` int(10) UNSIGNED NOT NULL,
  `startyear` smallint(4) UNSIGNED NOT NULL,
  `startmonth` smallint(2) UNSIGNED NOT NULL,
  `endyear` smallint(4) UNSIGNED NOT NULL,
  `endmonth` smallint(2) UNSIGNED NOT NULL,
  `school` varchar(50) NOT NULL,
  `speciality` varchar(50) NOT NULL,
  `education` smallint(5) UNSIGNED NOT NULL,
  `education_cn` varchar(30) NOT NULL DEFAULT '',
  `todate` int(10) UNSIGNED NOT NULL,
  `campus_id` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_resume_img` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` int(10) UNSIGNED NOT NULL,
  `resume_id` int(10) UNSIGNED NOT NULL,
  `img` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(20) NOT NULL DEFAULT '',
  `addtime` int(10) UNSIGNED NOT NULL,
  `audit` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `resume_id` (`resume_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_resume_language` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `pid` int(10) UNSIGNED NOT NULL,
  `uid` int(10) UNSIGNED NOT NULL,
  `language` smallint(5) NOT NULL,
  `language_cn` varchar(50) NOT NULL,
  `level` smallint(5) UNSIGNED NOT NULL,
  `level_cn` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_resume_training` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `pid` int(10) UNSIGNED NOT NULL,
  `uid` int(10) UNSIGNED NOT NULL,
  `startyear` smallint(4) UNSIGNED NOT NULL,
  `startmonth` smallint(2) UNSIGNED NOT NULL,
  `endyear` smallint(4) UNSIGNED NOT NULL,
  `endmonth` smallint(2) UNSIGNED NOT NULL,
  `agency` varchar(50) NOT NULL,
  `course` varchar(50) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `todate` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=1;



CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_resume_work` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `pid` int(10) UNSIGNED NOT NULL,
  `uid` int(10) UNSIGNED NOT NULL,
  `startyear` smallint(4) UNSIGNED NOT NULL,
  `startmonth` smallint(2) UNSIGNED NOT NULL,
  `endyear` smallint(4) UNSIGNED NOT NULL,
  `endmonth` smallint(2) UNSIGNED NOT NULL,
  `companyname` varchar(50) NOT NULL,
  `jobs` varchar(30) NOT NULL,
  `achievements` varchar(1000) NOT NULL,
  `todate` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_setmeal` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `display` tinyint(3) UNSIGNED NOT NULL DEFAULT '1',
  `apply` tinyint(3) UNSIGNED NOT NULL DEFAULT '1',
  `setmeal_name` varchar(200) NOT NULL,
  `days` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `expense` int(10) UNSIGNED NOT NULL,
  `jobs_meanwhile` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `refresh_jobs_free` int(10) UNSIGNED NOT NULL,
  `download_resume` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `download_resume_max` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `added` varchar(255) NOT NULL,
  `show_order` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `set_sms` int(10) UNSIGNED NOT NULL,
  `setmeal_img` varchar(200) NOT NULL,
  `show_apply_contact` tinyint(1) UNSIGNED NOT NULL,
  `is_free` tinyint(1) UNSIGNED NOT NULL,
  `discount_sms` double(2,1) UNSIGNED NOT NULL,
  `discount_download_resume` double(2,1) UNSIGNED NOT NULL,
  `discount_stick` double(2,1) UNSIGNED NOT NULL,
  `discount_emergency` double(2,1) UNSIGNED NOT NULL,
  `discount_auto_refresh_jobs` double(2,1) UNSIGNED NOT NULL,
  `resume_apply_free` tinyint(1) UNSIGNED NOT NULL,
  `give_points` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_setmeal_increment` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `cat` varchar(30) NOT NULL,
  `name` varchar(30) NOT NULL,
  `value` int(10) UNSIGNED NOT NULL,
  `price` varchar(10) NOT NULL,
  `sort` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_setting` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` char(100) NOT NULL,
  `keywords` char(100) NOT NULL,
  `description` char(255) NOT NULL,
  `logo` varchar(300) NOT NULL,
  `weixin_appid` char(255) NOT NULL,
  `weixin_appsecret` char(255) NOT NULL,
  `share_title` char(255) NOT NULL,
  `share_desc` char(255) NOT NULL,
  `share_thumb` char(255) NOT NULL,
  `settings` longtext NOT NULL,
  `views` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_view_resume` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` int(10) UNSIGNED NOT NULL,
  `resumeid` int(10) UNSIGNED NOT NULL,
  `company_id` int(10) UNSIGNED NOT NULL,
  `companyname` char(100) NOT NULL,
  `hasdown` tinyint(1) UNSIGNED NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_per_viewlog` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` int(10) UNSIGNED NOT NULL,
  `jid` int(10) UNSIGNED NOT NULL,
  `jobname` char(100) NOT NULL,
  `cid` int(10) UNSIGNED NOT NULL,
  `comname` char(100) NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_com_viewlog` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` int(10) UNSIGNED NOT NULL,
  `rid` int(10) UNSIGNED NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_report` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` int(10) UNSIGNED NOT NULL,
  `username` varchar(30) NOT NULL,
  `jobs_id` int(10) UNSIGNED NOT NULL,
  `report_type` int(10) NOT NULL,
  `telephone` varchar(15) NOT NULL,
  `audit` int(10) NOT NULL DEFAULT '1',
  `content` varchar(250) NOT NULL,
  `type` tinyint(1) UNSIGNED NOT NULL DEFAULT '1',
  `addtime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_share_refresh` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` int(10) UNSIGNED NOT NULL,
  `model` char(50) NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_kefu` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` int(10) UNSIGNED NOT NULL,
  `admin_uid` int(10) UNSIGNED NOT NULL,
  `kefu_name` char(30) NOT NULL,
  `kefu_mobile` char(20) NOT NULL,
  `kefu_tel` char(20) NOT NULL,
  `kefu_wxid` char(20) NOT NULL,
  `kefu_qrcode_url` char(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_news` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` char(50) NOT NULL,
  `cid` int(10) UNSIGNED NOT NULL,
  `catname` char(20) NOT NULL,
  `keyword` char(50) NOT NULL,
  `description` char(200) NOT NULL,
  `thumb` char(255) NOT NULL,
  `tag` char(20) NOT NULL,
  `author` char(30) NOT NULL,
  `views` int(10) UNSIGNED NOT NULL,
  `con` text NOT NULL,
  `toutiao` tinyint(1) UNSIGNED NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_news_cat` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` char(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_crm_company` (
  `rid` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `com_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `com_uid` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `crm_uid` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `level` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `funnel` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `follow_time` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `next_time` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `receive_time` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `give_up_time` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `remark` text,
  PRIMARY KEY (`rid`),
  KEY `com_id` (`com_id`),
  KEY `crm_uid` (`crm_uid`),
  KEY `level` (`level`),
  KEY `funnel` (`funnel`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_crm_custom_log` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `custom_type` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `custom_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `crm_uid` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `op_type` char(20) NOT NULL DEFAULT '',
  `note` varchar(100) NOT NULL DEFAULT '',
  `remark` varchar(255) NOT NULL DEFAULT '',
  `add_time` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `ip` varchar(15) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `custom_type` (`custom_type`),
  KEY `custom_id` (`custom_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_crm_custom_feedback` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `custom_type` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `custom_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `crm_uid` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `type_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `contact_name` char(50) NOT NULL DEFAULT '',
  `add_time` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `comment` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `custom_type` (`custom_type`),
  KEY `custom_id` (`custom_id`),
  KEY `crm_uid` (`crm_uid`),
  KEY `type_id` (`type_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_crm_person` (
  `rid` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `resume_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `resume_uid` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `crm_uid` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `funnel` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `source` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `label` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `level` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `follow_time` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `next_time` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `receive_time` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `give_up_time` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `remark` text,
  PRIMARY KEY (`rid`),
  KEY `resume_id` (`resume_id`),
  KEY `crm_uid` (`crm_uid`),
  KEY `funnel` (`funnel`),
  KEY `source` (`source`),
  KEY `label` (`label`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_queue_auto_refresh` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `pid` int(10) UNSIGNED NOT NULL,
  `type` tinyint(1) UNSIGNED NOT NULL,
  `uid` int(10) UNSIGNED NOT NULL,
  `refreshtime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_jobfair_online` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` char(255) NOT NULL,
  `catcn` char(200) NOT NULL,
  `summary` varchar(5000) NOT NULL,
  `starttime` int(10) UNSIGNED NOT NULL,
  `endtime` int(10) UNSIGNED NOT NULL,
  `thumb` char(255) NOT NULL,
  `pc_poster` char(255) NOT NULL,
  `poster` char(255) NOT NULL,
  `contact` char(100) NOT NULL,
  `tel` char(100) NOT NULL,
  `price` char(20) NOT NULL,
  `intro` text NOT NULL,
  `views` int(10) UNSIGNED NOT NULL,
  `bgcolor` char(20) NOT NULL,
  `kefu_tip` char(100) NOT NULL,
  `kefu_qrcode` char(255) NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_jobfair_online_com` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `fid` int(10) UNSIGNED NOT NULL,
  `uid` int(10) UNSIGNED NOT NULL,
  `com_id` int(10) UNSIGNED NOT NULL,
  `com_name` char(255) NOT NULL,
  `catcn` char(30) NOT NULL,
  `sort` smallint(5) UNSIGNED NOT NULL DEFAULT '100',
  `zhiding` tinyint(1) UNSIGNED NOT NULL,
  `note` varchar(5000) NOT NULL,
  `status` tinyint(1) UNSIGNED NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_company_interview` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `resume_id` int(10) UNSIGNED NOT NULL,
  `resume_name` varchar(30) NOT NULL,
  `resume_uid` int(10) UNSIGNED NOT NULL,
  `jobs_id` int(10) UNSIGNED NOT NULL,
  `jobs_name` varchar(60) NOT NULL,
  `company_id` int(10) UNSIGNED NOT NULL,
  `company_name` varchar(60) NOT NULL,
  `company_uid` int(10) UNSIGNED NOT NULL,
  `interview_addtime` int(10) UNSIGNED NOT NULL,
  `notes` varchar(255) NOT NULL DEFAULT '',
  `personal_look` tinyint(3) UNSIGNED NOT NULL DEFAULT '1',
  `interview_time` varchar(20) NOT NULL DEFAULT '',
  `address` varchar(255) NOT NULL,
  `contact` varchar(60) NOT NULL,
  `telephone` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `resume_uid_resumeid` (`resume_uid`,`resume_id`),
  KEY `company_uid_jobid` (`company_uid`,`jobs_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_members_handsel` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) UNSIGNED NOT NULL,
  `htype` varchar(60) NOT NULL,
  `htype_cn` varchar(30) NOT NULL,
  `operate` tinyint(1) UNSIGNED NOT NULL DEFAULT '1',
  `points` int(10) UNSIGNED NOT NULL,
  `addtime` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`,`htype`,`addtime`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_mptpl` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `type` char(20) NOT NULL,
  `tpl` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_wxscene` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `keyword` char(200) NOT NULL,
  `keyword2` char(200) NOT NULL,
  `tip` char(200) NOT NULL,
  `con` text NOT NULL,
  `type` char(30) NOT NULL,
  `etime` int(10) NOT NULL,
  `times` int(10) UNSIGNED NOT NULL,
  `subscribe` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_members_setmeal2` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `expire` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `uid` int(10) UNSIGNED NOT NULL,
  `setmeal_id` int(10) UNSIGNED NOT NULL,
  `setmeal_name` varchar(200) NOT NULL,
  `days` int(10) UNSIGNED NOT NULL,
  `expense` int(10) UNSIGNED NOT NULL,
  `set_sms` int(10) UNSIGNED NOT NULL,
  `jobs_meanwhile` int(10) UNSIGNED NOT NULL,
  `refresh_jobs_free` int(10) UNSIGNED NOT NULL,
  `download_resume` int(10) UNSIGNED NOT NULL,
  `download_resume_max` int(10) UNSIGNED NOT NULL,
  `added` varchar(250) NOT NULL,
  `starttime` int(10) UNSIGNED NOT NULL,
  `endtime` int(10) UNSIGNED NOT NULL,
  `show_apply_contact` tinyint(1) UNSIGNED NOT NULL,
  `is_free` tinyint(1) UNSIGNED NOT NULL,
  `discount_download_resume` double(2,1) UNSIGNED NOT NULL,
  `discount_sms` double(2,1) UNSIGNED NOT NULL,
  `discount_stick` double(2,1) UNSIGNED NOT NULL,
  `discount_emergency` double(2,1) UNSIGNED NOT NULL,
  `discount_auto_refresh_jobs` double(2,1) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  KEY `effective_setmealid` (`expire`,`setmeal_id`),
  KEY `effective_endtime` (`expire`,`endtime`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_company_profile2` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` int(10) UNSIGNED NOT NULL,
  `admin_uid` varchar(255) NOT NULL,
  `companyname` varchar(60) NOT NULL,
  `address` varchar(250) NOT NULL,
  `contact` varchar(100) NOT NULL,
  `telephone` varchar(130) NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  `kefu_uid` int(10) UNSIGNED NOT NULL,
  `kefu_name` char(20) NOT NULL,
  `weixin` char(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_crm_custom_feedback2` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `custom_type` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `custom_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `crm_uid` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `type_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `contact_name` char(50) NOT NULL DEFAULT '',
  `add_time` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `comment` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `custom_type` (`custom_type`),
  KEY `custom_id` (`custom_id`),
  KEY `crm_uid` (`crm_uid`),
  KEY `type_id` (`type_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_sendsmslog` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` int(10) UNSIGNED NOT NULL,
  `mobile` char(20) NOT NULL,
  `con` varchar(300) NOT NULL,
  `type` char(50) NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_adlist` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `con` char(255) NOT NULL,
  `adimg` char(255) NOT NULL,
  `type` tinyint(1) UNSIGNED NOT NULL,
  `catid` int(10) UNSIGNED NOT NULL,
  `url` char(255) NOT NULL,
  `views` int(10) UNSIGNED NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  `toptime` int(10) UNSIGNED NOT NULL,
  `catname` char(100) NOT NULL,
  `position` int(10) UNSIGNED NOT NULL,
  `newtype` char(255) NOT NULL,
  `newcatid` char(255) NOT NULL,
  `noapp` tinyint(1) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_menus` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `pid` int(10) UNSIGNED NOT NULL,
  `title` char(100) NOT NULL,
  `icon` char(255) NOT NULL,
  `path` char(255) NOT NULL,
  `component` char(255) NOT NULL,
  `hide` tinyint(1) UNSIGNED NOT NULL,
  `sort` smallint(3) UNSIGNED NOT NULL DEFAULT '100',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_admin_role` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(15) NOT NULL,
  `code` char(30) NOT NULL,
  `access` text NOT NULL,
  `access_mobile` text NOT NULL,
  `comments` char(100) NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_admin` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `username` char(20) NOT NULL,
  `password` char(20) NOT NULL,
  `code` char(20) NOT NULL,
  `roleid` int(10) UNSIGNED NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_mptpl2` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `type` char(100) NOT NULL,
  `name` char(100) NOT NULL,
  `parameter` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_resume_audit` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` int(10) UNSIGNED NOT NULL,
  `fullname` varchar(15) NOT NULL,
  `sex` tinyint(3) UNSIGNED NOT NULL,
  `sex_cn` varchar(3) NOT NULL,
  `nature` int(10) UNSIGNED NOT NULL,
  `nature_cn` varchar(30) NOT NULL,
  `trade` varchar(60) NOT NULL,
  `trade_cn` varchar(100) NOT NULL,
  `birthdate` smallint(4) UNSIGNED NOT NULL,
  `age` int(10) UNSIGNED NOT NULL,
  `height` varchar(5) NOT NULL,
  `marriage` tinyint(3) UNSIGNED NOT NULL,
  `marriage_cn` varchar(5) NOT NULL,
  `experience` smallint(5) NOT NULL,
  `experience_cn` varchar(30) NOT NULL,
  `district` varchar(100) NOT NULL,
  `district_cn` varchar(255) NOT NULL DEFAULT '',
  `wage` smallint(5) UNSIGNED NOT NULL,
  `wage_cn` varchar(30) NOT NULL,
  `education` smallint(5) UNSIGNED NOT NULL,
  `education_cn` varchar(30) NOT NULL,
  `major` smallint(5) NOT NULL,
  `major_cn` varchar(50) NOT NULL,
  `tag` varchar(50) NOT NULL,
  `tag_cn` varchar(100) NOT NULL,
  `telephone` varchar(50) NOT NULL,
  `intention_jobs_id` varchar(100) NOT NULL,
  `intention_jobs` varchar(255) NOT NULL,
  `specialty` varchar(1000) NOT NULL,
  `photo` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `photo_img` varchar(255) NOT NULL,
  `photo_audit` tinyint(1) UNSIGNED NOT NULL DEFAULT '1',
  `photo_display` tinyint(1) UNSIGNED NOT NULL DEFAULT '1',
  `complete_percent` tinyint(3) UNSIGNED NOT NULL DEFAULT '0',
  `current` smallint(5) UNSIGNED NOT NULL,
  `current_cn` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_jobs_audit` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `ids` int(10) UNSIGNED NOT NULL,
  `uid` int(10) UNSIGNED NOT NULL,
  `jobs_name` varchar(50) NOT NULL,
  `companyname` varchar(50) NOT NULL,
  `company_id` int(10) UNSIGNED NOT NULL,
  `emergency` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `nature` int(10) UNSIGNED NOT NULL,
  `nature_cn` varchar(30) NOT NULL,
  `sex` tinyint(1) UNSIGNED NOT NULL DEFAULT '3',
  `sex_cn` varchar(3) NOT NULL,
  `age` varchar(10) NOT NULL,
  `amount` smallint(5) UNSIGNED NOT NULL,
  `topclass` smallint(5) UNSIGNED NOT NULL,
  `category` smallint(5) UNSIGNED NOT NULL,
  `subclass` smallint(5) UNSIGNED NOT NULL,
  `category_cn` varchar(100) NOT NULL DEFAULT '',
  `category_sort` char(100) NOT NULL,
  `trade` smallint(5) UNSIGNED NOT NULL,
  `trade_cn` varchar(30) NOT NULL,
  `scale` smallint(5) UNSIGNED NOT NULL,
  `scale_cn` varchar(30) NOT NULL,
  `district` varchar(100) NOT NULL DEFAULT '',
  `district_cn` varchar(100) NOT NULL,
  `district2` varchar(100) NOT NULL,
  `district3` char(100) NOT NULL,
  `tag` varchar(50) NOT NULL,
  `tag_cn` varchar(100) NOT NULL,
  `education` smallint(5) UNSIGNED NOT NULL,
  `education_cn` varchar(30) NOT NULL,
  `experience` smallint(5) UNSIGNED NOT NULL,
  `experience_cn` varchar(30) NOT NULL,
  `minwage` int(10) NOT NULL,
  `maxwage` int(10) NOT NULL,
  `wage` smallint(5) UNSIGNED NOT NULL,
  `wage_cn` varchar(50) NOT NULL,
  `contents` text NOT NULL,
  `uptime` int(10) UNSIGNED NOT NULL,
  `stime` int(10) NOT NULL,
  `parttime_type` tinyint(1) UNSIGNED NOT NULL,
  `parttime_money` char(30) NOT NULL,
  `contact` char(100) NOT NULL,
  `telephone` char(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_diyposter` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` char(100) NOT NULL,
  `imgurl` char(255) NOT NULL,
  `type` char(30) NOT NULL,
  `data` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_operate_log` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` int(10) UNSIGNED NOT NULL,
  `username` char(30) NOT NULL,
  `type` char(30) NOT NULL,
  `url` char(255) NOT NULL,
  `method` char(20) NOT NULL,
  `param` varchar(3000) NOT NULL,
  `useragent` varchar(1000) NOT NULL,
  `ip` char(20) NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_im_token` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` int(10) UNSIGNED NOT NULL,
  `im_userid` varchar(50) NOT NULL,
  `token` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_im_message` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `utype` tinyint(1) UNSIGNED NOT NULL,
  `uid` int(10) UNSIGNED NOT NULL,
  `touid` int(10) UNSIGNED NOT NULL,
  `message` varchar(5000) NOT NULL,
  `jsontype` char(30) NOT NULL,
  `josnids` int(10) UNSIGNED NOT NULL,
  `jsontext` varchar(5000) NOT NULL,
  `isread` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `addtime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_sendtpllog` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` int(10) UNSIGNED NOT NULL,
  `openid` char(200) NOT NULL,
  `con` varchar(3000) NOT NULL,
  `type` char(50) NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  `issend` tinyint(1) UNSIGNED NOT NULL DEFAULT '1',
  `sendtime` int(10) UNSIGNED NOT NULL,
  `sendback` char(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_regsmslog` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` int(10) UNSIGNED NOT NULL,
  `mobile` char(20) NOT NULL,
  `code` char(50) NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

SQL;

runquery($sql);

    $initialization2 = file_get_contents('http://demo.zimucms.com/source/plugin/zimu_zhaopin/initialization2.txt');

    if($_G['charset'] == 'utf-8'){
        $initialization2 = diconv($initialization2,'gbk','UTF-8');
    }

    $sql = <<<EOF
DROP TABLE  IF EXISTS pre_zimu_zhaopin_menus;
EOF;

    runquery($sql);

    $sql = <<<EOF
$initialization2
EOF;

    $aa = runquery($sql);

$finish = TRUE;
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL3ppbXVfemhhb3Bpbi9hZG1pbnMvY29weS5odG1s'));