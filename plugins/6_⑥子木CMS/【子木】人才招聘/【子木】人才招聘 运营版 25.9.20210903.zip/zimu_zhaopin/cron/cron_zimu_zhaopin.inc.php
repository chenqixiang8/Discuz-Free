<?php

//cronname:zimu_zhaopin
//week:
//day:
//hour:
//minute:0,5,10,15,20,25,30,35,40,45,50,55

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

    $paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
        'zimu_zhaopin_parameter2',
        'aliyunsms'
    ));
    $paramters = unserialize($paramter['parameter']);