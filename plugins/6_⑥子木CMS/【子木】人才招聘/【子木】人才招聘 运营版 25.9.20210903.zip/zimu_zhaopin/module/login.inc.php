<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(!$_G['uid']){


if(!$zmdata['settings']['weixin_login_url']){

isuid();

}


$referer = urldecode($_GET['referer']);

$op = addslashes($_GET['op']);


if($op=='loging'){

$username = zimu_array_utf8tomy($_GET['username']);
$password = addslashes($_GET['password']);

    $qqpostdata = hui_v_captcha($_GET['qqticket'], $_POST['qqrandstr']);
    if($qqpostdata!='ok'){
        $returndata['status'] = 0;
        $returndata['msg'] = zimu_array_utf8($qqpostdata);
        echo json_encode($returndata);exit();
    }

if (isMobile($username)) {

    if(!$uid){
        $uid = DB::result_first('select uid from %t where telephone=%s order by id desc', array(
            'zimu_zhaopin_company_profile',
            $username
        ));
    }
    if(!$uid){
        $uid = DB::result_first('select uid from %t where telephone=%s order by id desc', array(
            'zimu_zhaopin_resume',
            $username
        ));
    }
    if($zmdata['settings']['h5_isapp']==1 && !$uid){
        $uid = DB::result_first('select userid from %t where phone=%s order by id desc', array(
            'user_mobile_relations',
            $username
        ));
    }
    if($zmdata['settings']['h5_isapp']==2 && !$uid){
        $uid = DB::result_first('select uid from %t where phone=%s order by id desc', array(
            'phonebind',
            $username
        ));
    }
    if($zmdata['settings']['h5_isapp']==3 && !$uid){
        $uid = DB::result_first('select uid from %t where mobile=%s order by id desc', array(
            'appbyme_sendsms',
            $username
        ));
    }

    if ($uid) {
        $userinfo = getuserbyuid($uid);
        $username          = $userinfo['username'];
    }

}

    loaducenter();
    list($result) = uc_user_login($username, $password, 0, 0); 
  
    if($result >= 0) {

    $mycompany = DB::fetch_first('select uid from %t where uid=%d order by id desc', array(
        'zimu_zhaopin_company_profile',
        $result
    ));
    if(!$mycompany){
        $wheresql = " where `admin_uid` LIKE '%,{$result},%' ";
        $is_admin_company = DB::fetch_first("select * from %t %i", array(
            "zimu_zhaopin_company_profile",
            $wheresql
        ));
        if($is_admin_company['uid']>0){
            $result = $is_admin_company['uid'];
        }
    }

    $member = getuserbyuid($result, 1);
    require_once libfile('function/member');
    $cookietime = 1296000;
    setloginstatus($member, $cookietime);
    
    C::t('common_member_status')->update($result, array(
        'lastip' => $_G['clientip'],
        'lastvisit' => TIMESTAMP,
        'lastactivity' => TIMESTAMP
    ));

    $ucsynlogin = '';
    if ($_G['setting']['allowsynlogin']) {
        $ucsynlogin = uc_user_synlogin($result);
    }

    $url = urldecode($_GET['url']);

    $returndata['status'] = 1;
    $returndata['data'] = $url ? $url : ZIMUCMS_URL;


    }else{

    $returndata['status'] = 0;
    $returndata['msg'] = zimu_array_utf8($language_zimu['login_inc_php_0']);

    }

    echo json_encode($returndata);exit();


}else if($op == 'loging2'){

$mobile = addslashes($_GET['mobile']);
$mobile_vcode = addslashes($_GET['mobile_vcode']);


    $uid = DB::result_first('select uid from %t where telephone=%s and verify_code=%d order by id desc', array(
        'zimu_zhaopin_members',
        $mobile,
        $mobile_vcode
    ));
    
    if ($uid) {

        $mycompany = DB::fetch_first('select uid from %t where uid=%d order by id desc', array(
            'zimu_zhaopin_company_profile',
            $uid
        ));
        if(!$mycompany){
            $wheresql = " where `admin_uid` LIKE '%,{$uid},%' ";
            $is_admin_company = DB::fetch_first("select * from %t %i", array(
                "zimu_zhaopin_company_profile",
                $wheresql
            ));
            if($is_admin_company['uid']>0){
                $uid = $is_admin_company['uid'];
            }
        }

    $member = getuserbyuid($uid, 1);
    if (!$member) {
        return false;
    }
    if (isset($member['_inarchive'])) {
        C::t('common_member_archive')->move_to_master($member['uid']);
    }
    require_once libfile('function/member');
    $cookietime = 1296000;
    setloginstatus($member, $cookietime);


    $url = urldecode($_GET['url']);

    $returndata['status'] = 1;
    $returndata['data'] = $url ? $url : ZIMUCMS_URL;


    }else{

    $returndata['status'] = 0;
    $returndata['msg'] = zimu_array_utf8($language_zimu['login_inc_php_1']);

    }

    echo json_encode($returndata);exit();


}else if($op == 'ajax_check'){

        $param = addslashes($_GET['param']);

        $user = DB::fetch_first('select * from %t where telephone=%s order by id desc', array(
                    'zimu_zhaopin_members',
                    $param
                ));

        if(!$user){
            $user = DB::fetch_first('select uid from %t where telephone=%s order by id desc', array(
                'zimu_zhaopin_company_profile',
                $param
            ));
        }
        if(!$user){
            $user = DB::fetch_first('select uid from %t where telephone=%s order by id desc', array(
                'zimu_zhaopin_resume',
                $param
            ));
        }

        if($user['uid']){

        $rand = mt_rand(1000, 9999);

        $sms_paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
            'zimu_zhaopin_parameter2',
            'aliyunsms'
        ));
        $sms_paramter = unserialize($sms_paramter['parameter']);
    
        $app_key = $sms_paramter['smsAppKey']; 
        $app_secret = $sms_paramter['smssecretKey']; 
        $sign_name = mb_convert_encoding($sms_paramter['smsFreeSignName'],'UTF-8',CHARSET);
        $smsdata['code'] = $rand;
    
        $requestUrl = "http://dysmsapi.aliyuncs.com/";
        $params['PhoneNumbers']= $param;
        $params['SignName']= $sign_name;
        if(isMobile($param)){
        $params['TemplateCode']= $sms_paramter['smsTemplateCode'];
        }else{
        $params['TemplateCode']= $sms_paramter['smsTemplateCode2'];
        }
        $params['TemplateParam']= json_encode($smsdata);
        $params['OutId']= "3333";
        $params['RegionId']= "cn-hangzhou";
        $params['AccessKeyId']= $app_key;
        $params['Format']= "JSON";
        $params['SignatureMethod']= "HMAC-SHA1";
        $params['SignatureVersion']= "1.0";
        $params['SignatureNonce']= uniqid();
        date_default_timezone_set("GMT");
        $params['Timestamp']= date("Y-m-d\TH:i:s\Z");
        $params['Action']= "SendSms";
        $params['Version']= "2017-05-25";
        $params['Signature']= aliyun_signature($params,$app_secret);
    
        include_once DISCUZ_ROOT . './source/plugin/zimu_zhaopin/class/Aliyun_HttpHelper.class.php';
    
        $Aliyun_HttpHelper = new Aliyun_HttpHelper();
        $result = $Aliyun_HttpHelper->curl($requestUrl,'POST',$params,array('x-sdk-client' => 'php/2.0.0'));
    
        $aaa = object_array(json_decode($result));
    
            if ($aaa['alibaba_aliqin_fc_sms_num_send_response']['result']['success'] == 1 || $aaa['success'] == 1 || $aaa['Code'] == 'OK') {
    
                DB::query("update %t set verify_code=%d,telephone=%s where uid=%d", array(
                    'zimu_zhaopin_members',
                    $rand,
                    $param,
                    $user['uid'],
                ));
    
                ajaxReturn(1,'ok');
            }else{
                ajaxReturn(0,mb_convert_encoding($aaa['Message'], CHARSET, 'UTF-8'));
            }


        }else{
            ajaxReturn(0,'nouser');
        }






}else{

    $qcaptcha_paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
        'zimu_zhaopin_parameter2',
        'qcaptcha'
    ));
    $qcaptcha_paramter = unserialize($qcaptcha_paramter['parameter']);

include zimu_template('login');

}

}else{

if($utype == 1){

dheader('Location:' . ZIMUCMS_URL);

}else{

dheader('Location:' . ZIMUCMS_URL);

}

}


function aliyun_signature($params,$AccessKeySecret){
    ksort($params);

    $canonicalizedQueryString = '';
    foreach($params as $key => $value){
        $canonicalizedQueryString .= '&' . percentEncode($key). '=' . percentEncode($value);
    }

    $stringToSign = 'POST&%2F&' . percentEncode(substr($canonicalizedQueryString, 1));

    $signature = base64_encode(hash_hmac('sha1', $stringToSign, $AccessKeySecret."&", true));
    return $signature;
}

function percentEncode($str){
    $res = urlencode($str);
    $res = preg_replace('/\+/', '%20', $res);
    $res = preg_replace('/\*/', '%2A', $res);
    $res = preg_replace('/%7E/', '~', $res);
    return $res;
}

    function hui_ip(){
        if(!empty($_SERVER["HTTP_CLIENT_IP"])){
            return $_SERVER["HTTP_CLIENT_IP"];
        } elseif (!empty($_SERVER["HTTP_X_FORWARDED_FOR"])){
            return $_SERVER["HTTP_X_FORWARDED_FOR"];
        } elseif (!empty($_SERVER["REMOTE_ADDR"])){
            return $_SERVER["REMOTE_ADDR"];
        }
        return "none";
    }

    function hui_v_captcha($Ticket, $Randstr){

        $qcaptcha_paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
            'zimu_zhaopin_parameter2',
            'qcaptcha'
        ));
        $qcaptcha_paramter = unserialize($qcaptcha_paramter['parameter']);
        if(!$qcaptcha_paramter['appid']){
            return 'ok';
        }


        $CaptchaAppId = $qcaptcha_paramter['appid'];
        $AppSecretKey = $qcaptcha_paramter['appkey'];
        $secretId = $qcaptcha_paramter['secretid'];
        $secretKey = $qcaptcha_paramter['secretkey'];

        if( !$CaptchaAppId || !$AppSecretKey || !$secretId || !$secretKey || !$Ticket || !$Randstr ){
            return false;
        }

        $CaptchaAppId = (int) $CaptchaAppId;

        $host = "captcha.tencentcloudapi.com";
        $service = "captcha";
        $version = "2019-07-22";
        $action = "DescribeCaptchaResult";
        $timestamp = time();

        $payload = array(
            'CaptchaType' => 9,
            'Ticket' => $Ticket,
            'Randstr' => $Randstr,
            'UserIp' => hui_ip(),
            'CaptchaAppId' => $CaptchaAppId,
            'AppSecretKey' => $AppSecretKey,
        );

        $algorithm = "TC3-HMAC-SHA256";
        $httpRequestMethod = "POST";
        $canonicalUri = "/";
        $canonicalQueryString = "";
        $canonicalHeaders = "content-type:application/json\n"."host:".$host."\n";
        $signedHeaders = "content-type;host";
        $hashedRequestPayload = hash("SHA256", json_encode($payload));
        $canonicalRequest = $httpRequestMethod."\n"
            .$canonicalUri."\n"
            .$canonicalQueryString."\n"
            .$canonicalHeaders."\n"
            .$signedHeaders."\n"
            .$hashedRequestPayload;
        $date = gmdate("Y-m-d", $timestamp);
        $credentialScope = $date."/".$service."/tc3_request";
        $hashedCanonicalRequest = hash("SHA256", $canonicalRequest);
        $stringToSign = $algorithm."\n"
            .$timestamp."\n"
            .$credentialScope."\n"
            .$hashedCanonicalRequest;
        $secretDate = hash_hmac("SHA256", $date, "TC3".$secretKey, true);
        $secretService = hash_hmac("SHA256", $service, $secretDate, true);
        $secretSigning = hash_hmac("SHA256", "tc3_request", $secretService, true);
        $signature = hash_hmac("SHA256", $stringToSign, $secretSigning);
        $authorization = $algorithm
            ." Credential=".$secretId."/".$credentialScope
            .", SignedHeaders=content-type;host, Signature=".$signature;
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://'.$host);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $httpRequestMethod);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Authorization: '.$authorization,
            'Content-Type: application/json',
            'Host: '.$host,
            'X-TC-Action: '.$action,
            'X-TC-Version: '.$version,
            'X-TC-Timestamp: '.$timestamp,
        ));
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
        $output = curl_exec($ch);
        curl_close($ch);

        $output = json_decode($output);

        if( isset($output->Response) && isset($output->Response->CaptchaCode) && $output->Response->CaptchaCode == 1 ){
            return 'ok';
        }else{
            return $output->Response->CaptchaMsg ? $output->Response->CaptchaMsg : $output->Response->Error->Code;
        }
    }