<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}


$jobcategory = intval($_GET['jobcategory']);
$citycategory = intval($_GET['citycategory']);
$citycategory2 = intval($_GET['citycategory2']);
$citycategory3 = intval($_GET['citycategory3']);
$experience = intval($_GET['experience']);
$education = intval($_GET['education']);
$sex = intval($_GET['sex']);
$age = intval($_GET['age']);
$major = intval($_GET['major']);
$wage = intval($_GET['wage']);
$resumetag = intval($_GET['resumetag']);
$settr = intval($_GET['settr']);
$lat = addslashes($_GET['lat']);
$lng = addslashes($_GET['lng']);

if($_GET['all'] !=1 && !$citycategory && !$citycategory2 && file_exists(DISCUZ_ROOT . './source/plugin/zimu_zhaopin/module/a_change_area.inc.php') && ( $zmdata['settings']['change_city'] == 1 || $zmdata['settings']['change_area'] > 0) ){
$citycategory  = getcookie('citycategory');
$citycategory2 = getcookie('citycategory2');  
}

$paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
    'zimu_zhaopin_parameter2',
    'resumead'
));

$paramters_indexad = unserialize($paramter['parameter']);

$category_jobs = DB::fetch_all('select * from %t where parentid=0 order by category_order asc,id asc', array(
        'zimu_zhaopin_category_jobs'
    ),'id');

foreach ($category_jobs as $key => $value) {

$category_jobs[$key]['list'] = DB::fetch_all('select * from %t where parentid=%d order by category_order asc,id asc', array(
        'zimu_zhaopin_category_jobs',
        $value['id']
    ));

}

$districtlist = DB::fetch_all('select * from %t where parentid=0 order by sort asc,id asc', array(
    'zimu_zhaopin_area'
), 'id');

foreach ($districtlist as $key => $value) {
    if (!$cityone) {
        $cityone = $key;
    }
    $districtlist[$key]['list'] = DB::fetch_all('select * from %t where parentid=%d order by sort asc,id asc', array(
        'zimu_zhaopin_area',
        $value['id']
    ),'id');
    
}


$experiencelist = DB::fetch_all('select * from %t where c_alias=%s order by c_order asc,c_id asc', array(
        'zimu_zhaopin_category',
        'ZM_experience'
    ));

$experiencelist = array_column($experiencelist, null, 'c_id');

$educationlist = DB::fetch_all('select * from %t where c_alias=%s order by c_order asc,c_id asc', array(
        'zimu_zhaopin_category',
        'ZM_education'
    ));

$educationlist = array_column($educationlist, null, 'c_id');


$agelist = DB::fetch_all('select * from %t where c_alias=%s order by c_order asc,c_id asc', array(
        'zimu_zhaopin_category',
        'ZM_age'
    ));

$agelist = array_column($agelist, null, 'c_id');


$majorlist = DB::fetch_all('select * from %t where parentid !=0 order by category_order asc,id asc', array(
        'zimu_zhaopin_category_major',
    ));

$majorlist = array_column($majorlist, null, 'id');


$wagelist = DB::fetch_all('select * from %t where c_alias=%s order by c_order asc,c_id asc', array(
        'zimu_zhaopin_category',
        'ZM_wage'
    ));

$wagelist = array_column($wagelist, null, 'c_id');


$taglist = DB::fetch_all('select * from %t where c_alias=%s order by c_order asc,c_id asc', array(
        'zimu_zhaopin_category',
        'ZM_resumetag'
    ));

$taglist = array_column($taglist, null, 'c_id');


$pindex = max(1, intval($_GET['page']));
$psize = 15;

$wherearr[] = ' audit !=3 ';
$wherearr[] = ' display !=2 ';

$key = dhtmlspecialchars($_GET['key']);
$key = stripsearchkey($key);
$key = daddslashes($key);

if($zmdata['settings']['area_three'] && $citycategory2){

    $area_three = DB::fetch_all('select * from %t where parentid=%d order by sort asc,id asc', array(
        'zimu_zhaopin_area',
        $citycategory2
    ), 'id');

}


$wherearr[]=' (fullname LIKE \'%'.$key.'%\' OR trade_cn LIKE \'%'.$key.'%\' OR education_cn LIKE \'%'.$key.'%\' OR intention_jobs LIKE \'%'.$key.'%\' OR specialty LIKE \'%'.$key.'%\') ';

if($citycategory3){
$wherearr[]=' district LIKE \'%.'.$citycategory3.'%\' ';
$select_city = $districtlist[$citycategory]['list'][$citycategory2]['name'];
}elseif($citycategory2){
$wherearr[]=' district LIKE \'%.'.$citycategory2.'.%\' ';
$select_city = $districtlist[$citycategory]['list'][$citycategory2]['name'];
}elseif($citycategory){
$wherearr[]=' district LIKE \'%'.$citycategory.'.%\' ';
$select_city = $districtlist[$citycategory]['name'];
}


$jobcategory = intval($_GET['jobcategory']);
$jobcategory2  = intval($_GET['topcat']) ? $jobcategory : intval($_GET['jobcategory2']);
if($jobcategory){
$topcat = intval($_GET['topcat']) ? $jobcategory.'.' : '.'.$jobcategory;
$wherearr[]=' intention_jobs_id LIKE \'%'.$topcat.'%\' ';
}

$experience = intval($_GET['experience']);
if($experience){
$wherearr[]=' experience = '.$experience;
}
$education = intval($_GET['education']);
if($education){
$wherearr[]=' education = '.$education;
}
$sex = intval($_GET['sex']);
if($sex){
$wherearr[]=' sex = '.$sex;
}
$major = intval($_GET['major']);
if($major){
$wherearr[]=' major = '.$major;
}
$wage = intval($_GET['wage']);
if($wage){
$wherearr[]=' wage = '.$wage;
}

$photo = intval($_GET['photo']);
if($photo){
$wherearr[]=' photo_img != \'\'';
}

$wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';


$top_resumelist = array();

if($pindex==1){

$top_resumelist = DB::fetch_all('select * from %t %i and stick_endtime > %d '.$noauditwheresql2.' order by refreshtime desc,stick_endtime desc,id desc', array(
    'zimu_zhaopin_resume',
    $wheresql,
    $_G['timestamp']
));

}

$resumelist2 = array();

$resumelist2 = DB::fetch_all('select * from %t %i and stick_endtime < %d '.$noauditwheresql2.' order by refreshtime desc,id desc limit %d,%d', array(
	'zimu_zhaopin_resume',
	$wheresql,
    $_G['timestamp'],
	($pindex - 1) * $psize,
	$psize
));

$resumelist = array_merge($top_resumelist,$resumelist2);


if($_G['uid']){
    foreach ($resumelist as $key => $value) {

        $resumelist[$key]['hasfav'] = DB::fetch_first('select * from %t where company_uid=%d and resume_id=%d order by did desc', array(
            'zimu_zhaopin_company_favorites',
            $_G['uid'],
            $value['id']
        ));

        $resumelist[$key]['isresume'] = DB::fetch_first('select * from %t where company_uid=%d and resume_id=%d order by did desc', array(
            'zimu_zhaopin_company_down_resume',
            $_G['uid'],
            $value['id']
        ));

    }
}

$total = DB::result_first("SELECT count(*) FROM %t %i and stick_endtime < %d".$noauditwheresql2, array(
    "zimu_zhaopin_resume",
    $wheresql,
    $_G['timestamp'],
));

$totalPages = ceil($total/$psize);

$pager = pagination($total, $pindex, $psize);

$resume_info = DB::fetch_first('select * from %t where uid=%d '.$noauditwheresql2.' order by id asc', array(
        'zimu_zhaopin_resume',
        $_G['uid']
    ));

if($_G['uid'] && $zmdata['settings']['no_user_num']!=0){
$myresume = DB::fetch_first('select * from %t where uid=%d order by id asc', array(
    'zimu_zhaopin_resume',
    $_G['uid']
));
$mycom = DB::fetch_first('select * from %t where uid=%d order by id asc', array(
    'zimu_zhaopin_company_profile',
    $_G['uid']
));
if($myresume || $mycom){
$zmdata['settings']['no_user_num'] = 0;
}
}

$navtitle = $share_title = $zmdata['settings']['resume_seo_title'] ? $zmdata['settings']['resume_seo_title'] : $navtitle;
$keywords = $zmdata['settings']['resume_seo_keyword'] ? $zmdata['settings']['resume_seo_keyword'] : $navtitle;
$description = $share_desc = $zmdata['settings']['resume_seo_desc'] ? $zmdata['settings']['resume_seo_desc'] : $navtitle;
    if(checkmobile() && $zmdata['settings']['open_newwap']==1){
        dheader('Location:' . $_G['siteurl'] . 'source/plugin/zimu_zhaopin/h5/pages/index/resume');
        exit();
    }
include zimu_template('resume');