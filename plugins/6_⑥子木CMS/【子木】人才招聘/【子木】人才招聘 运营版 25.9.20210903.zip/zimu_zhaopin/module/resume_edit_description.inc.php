<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$tosubmit = intval($_GET['tosubmit']);
$rid = intval($_GET['rid']);
$specialty = addslashes($_GET['specialty']);

if($tosubmit == 1){


            $uid = $_G['uid'];

    DB::query("update %t set specialty=%s where id=%d and uid=%d", array(
        'zimu_zhaopin_resume',
        $specialty,
        $rid,
        $uid
    ));

            echo ajaxReturn(1,$language_zimu['resume_edit_description_inc_php_0'],array('url'=>ZIMUCMS_URL.'&model=resume_replenish&rid='.$rid));
            exit();

}else{


$resume = DB::fetch_first('select * from %t where uid=%d and id=%d order by id asc', array(
        'zimu_zhaopin_resume',
        $_G['uid'],
        $rid
    ));

include zimu_template('resume_edit_description');

}