<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$op = addslashes($_GET['op']);
$op = $op ? $op : 'index';

if ($op == 'edit') {
    

    if (submitcheck('submit')) {

        $data['tip']        = strip_tags($_GET['tip']);
        $data['con']        = $_GET['con'];
        $data['id']      = intval($_GET['ids']);


        if ($data['id'] > 0) {

        DB::update('zimu_zhaopin_wxscene', $data, array(
            'id' => $data['id']
        ));
            
        } else {
           
        $data['keyword']        = strip_tags($_GET['keyword']);
        $data['type']        = 'diy';
        $data['etime']        = time()+2591000;
        $result = DB::insert('zimu_zhaopin_wxscene', $data, 1);

        }
        
        include template('zimu_zhaopin:common/success');
        
        
    } else {

        
        $ids = intval($_GET['ids']);
        
        $listdata = DB::fetch_first('select * from %t where id=%d', array(
            'zimu_zhaopin_wxscene',
            $ids
        ));

        include zimu_template('admins/admins_' . $type,'');
        
    }
    
    
} else {
    
    $wheresql = 'where 1=1 ';

    $pindex = max(1, intval($_GET['page']));
    $psize  = 30;
    
    $total = DB::result_first("SELECT count(*) FROM %t %i", array(
        "zimu_zhaopin_wxscene",
        $wheresql
    ));

    $listdata = DB::fetch_all('select * from %t %i order by id desc limit %d,%d', array(
        'zimu_zhaopin_wxscene',
        $wheresql,
        ($pindex - 1) * $psize,
        $psize
    ));
    
    $pager = pagination($total, $pindex, $psize);
    
    include zimu_template('admins/admins_' . $type,'');
    
    
}