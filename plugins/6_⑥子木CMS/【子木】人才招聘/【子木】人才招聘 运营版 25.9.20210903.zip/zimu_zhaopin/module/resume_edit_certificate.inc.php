<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$tosubmit = intval($_GET['tosubmit']);
$wid = intval($_GET['wid']);

if($tosubmit == 1){

$pid = intval($_GET['pid']);

            $uid = $_G['uid'];


            $setsqlarr['uid'] = $uid;
            $setsqlarr['name'] = I('name','','trim');
            $setsqlarr['year'] = I('year','','trim');
            $setsqlarr['month'] = I('month','','trim');

            if(!$pid) ajaxReturn(0,$language_zimu['resume_edit_certificate_inc_php_0']);
            $setsqlarr['pid'] = $pid;

            if(!$setsqlarr['year'] || !$setsqlarr['month']) ajaxReturn(0,$language_zimu['resume_edit_certificate_inc_php_1']);
            if($setsqlarr['year'] > intval(date('Y'))) ajaxReturn(0,$language_zimu['resume_edit_certificate_inc_php_2']);
            if($setsqlarr['year'] == intval(date('Y')) && $setsqlarr['month'] > intval(date('m'))) ajaxReturn(0,$language_zimu['resume_edit_certificate_inc_php_3']);
           
            $credent = DB::fetch_all('select * from %t where uid=%d and pid=%d order by id asc', array(
                'zimu_zhaopin_resume_credent',
                $_G['uid'],
                $pid
            ));

            if(count($credent)>=6) ajaxReturn(0,$language_zimu['resume_edit_certificate_inc_php_4']);

            if($wid){
            
            $setsqlarr['id'] = $wid;

            $result = DB::update('zimu_zhaopin_resume_credent', $setsqlarr, array(
                'id' => $wid,
                'uid' => $uid,
                'pid' => $pid,
            ));

            }else{

            $result = DB::insert('zimu_zhaopin_resume_credent', $setsqlarr, 1);

            }

            ajaxReturn(1,$language_zimu['resume_edit_certificate_inc_php_5'],array('url'=>ZIMUCMS_URL.'&model=resume_replenish&rid='.$pid));
            exit();

}else{

$pid = intval($_GET['rid']);

$info = DB::fetch_first('select * from %t where uid=%d and id=%d and pid=%d order by id asc', array(
        'zimu_zhaopin_resume_credent',
        $_G['uid'],
        $wid,
        $pid
    ));

include zimu_template('resume_edit_certificate');

}