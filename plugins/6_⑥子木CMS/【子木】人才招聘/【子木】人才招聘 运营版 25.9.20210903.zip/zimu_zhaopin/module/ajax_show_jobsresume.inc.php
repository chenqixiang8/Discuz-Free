<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$utype = intval($_GET['utype']);

$wheresql = 'where audit !=3 ';
$pindex = max(1, intval($_GET['page']));
$psize = 10;

if($zmdata['settings']['show_noaudit']){
$noauditwheresql = ' where audit = 1 ';
$noauditwheresql2 = ' and audit = 1 ';
}else{
$noauditwheresql = ' where 1 = 1 ';
$noauditwheresql2 = ' and 1 = 1 ';
}

if(file_exists(DISCUZ_ROOT . './source/plugin/zimu_zhaopin/module/a_change_area.inc.php') && ( $zmdata['settings']['change_city'] == 1 || $zmdata['settings']['change_area'] > 0) ){
$citycategory  = getcookie('citycategory');
$citycategory2 = getcookie('citycategory2');
if($zmdata['settings']['change_area']==2 && getcookie('citycategory2')){
$jobs_wheresql = ' and district2 = '.getcookie('citycategory2').' ';
$resume_wheresql = ' and district LIKE \'%.'.getcookie('citycategory2').'.%\' ';
}elseif(getcookie('citycategory')){
$jobs_wheresql = ' and district = '.getcookie('citycategory').' ';
$resume_wheresql = ' and district LIKE \'%'.getcookie('citycategory').'.%\' ';
}
}


if($utype==1){

$totalPages = ceil(DB::result_first("SELECT count(*) FROM %t".$noauditwheresql, array(
    "zimu_zhaopin_resume"
))/$psize);

$top_jobslist = array();

if($pindex==1){

$top_jobslist = DB::fetch_all('select * from %t where audit !=3 and display != 2 and stick_endtime > %d '.$noauditwheresql2.' %i order by refreshtime desc,stick_endtime desc,id desc', array(
    'zimu_zhaopin_resume',
    $_G['timestamp'],
    $resume_wheresql
));

}


$jobslist2 = array();

$jobslist2 = DB::fetch_all('select * from %t where audit !=3 and display !=2 and stick_endtime < %d '.$noauditwheresql2.' %i order by refreshtime desc,id desc limit %d,%d', array(
	'zimu_zhaopin_resume',
    $_G['timestamp'],
    $resume_wheresql,
	($pindex - 1) * $psize,
	$psize
));

$jobslist = array_merge($top_jobslist,$jobslist2);


foreach ($jobslist as $key => $value) {

$jobslist[$key]['fullname'] = cutstr($value['fullname'],2,'').($value['sex']==1 ? $language_zimu['ajax_show_jobsresume_inc_php_0'] : $language_zimu['ajax_show_jobsresume_inc_php_1']);
$jobslist[$key]['tag_cn'] = explode(',', $value['tag_cn']);
$jobslist[$key]['refreshtime_cn'] = date('m'.$language_zimu['ajax_show_jobsresume_inc_php_2'].'d'.$language_zimu['ajax_show_jobsresume_inc_php_3'],$value['refreshtime']);
$jobslist[$key]['age_cn'] = date('Y')-$value['birthdate'].$language_zimu['ajax_show_jobsresume_inc_php_4'];
$jobslist[$key]['sex_icon'] = $value['sex']==1 ? 'men' : 'women';
$jobslist[$key]['photo_img'] = $value['photo_img'] ? $value['photo_img'] : ($value['sex']==1 ? '/source/plugin/zimu_zhaopin/static/wap/images/no_photo_male.png' : '/source/plugin/zimu_zhaopin/static/wap/images/no_photo_female.png');
$jobslist[$key]['resume_url'] = ZIMUCMS_URL.'&model=viewresume&rid='.$value['id'];
$jobslist[$key]['stick_cn'] = $value['stick_endtime'] > $_G['timestamp'] ? $language_zimu['ajax_show_jobsresume_inc_php_5'] : '';
$jobslist[$key]['strong_tag'] = $value['strong_tag_endtime'] > $_G['timestamp'] ? $value['strong_tag'] : '';

}


$data['type'] = 'resume';
$data['nowPage'] = $pindex;
$data['totalPages'] = $totalPages;
$data['data_list'] = $jobslist;


}else{

$totalPages = DB::result_first("SELECT count(*) FROM %t".$noauditwheresql.' %i ', array(
    "zimu_zhaopin_jobs",
    $jobs_wheresql
));

$top_jobslist = array();

if($pindex==1){

if($zmdata['settings']['auth_sort']){

$top_jobslist = DB::fetch_all('select * from %t where company_audit !=3 and audit !=3 and display != 2 and stick_endtime > %d '.$noauditwheresql2.' %i order by company_certificate desc,refreshtime desc,stick_endtime desc,id desc', array(
    'zimu_zhaopin_jobs',
    $_G['timestamp'],
    $jobs_wheresql
));

}else{

$top_jobslist = DB::fetch_all('select * from %t where company_audit !=3 and audit !=3 and display != 2 and stick_endtime > %d '.$noauditwheresql2.' %i order by refreshtime desc,stick_endtime desc,id desc', array(
    'zimu_zhaopin_jobs',
    $_G['timestamp'],
    $jobs_wheresql
));

}

}

$jobslist2 = array();

if($zmdata['settings']['auth_sort']){

$jobslist2 = DB::fetch_all('select * from %t where company_audit !=3 and audit !=3 and display != 2 and stick_endtime < %d '.$noauditwheresql2.' %i order by company_certificate desc,refreshtime desc,id desc limit %d,%d', array(
    'zimu_zhaopin_jobs',
    $_G['timestamp'],
    $jobs_wheresql,
    ($pindex - 1) * $psize,
    $psize
));

}else{

$jobslist2 = DB::fetch_all('select * from %t where company_audit !=3 and audit !=3 and display != 2 and stick_endtime < %d '.$noauditwheresql2.' %i order by refreshtime desc,id desc limit %d,%d', array(
	'zimu_zhaopin_jobs',
    $_G['timestamp'],
    $jobs_wheresql,
	($pindex - 1) * $psize,
	$psize
));

}

$jobslist = array_merge($top_jobslist,$jobslist2);

foreach ($jobslist as $key => $value) {

$jobslist[$key]['tag_cn'] = explode(',', $value['tag_cn']);
$jobslist[$key]['refreshtime_cn'] = date('m'.$language_zimu['ajax_show_jobsresume_inc_php_6'].'d'.$language_zimu['ajax_show_jobsresume_inc_php_7'],$value['refreshtime']);
$jobslist[$key]['jobs_url'] = ZIMUCMS_URL.'&model=viewjob&jid='.$value['id'];
$jobslist[$key]['stick_cn'] = $value['stick_endtime'] > $_G['timestamp'] ? $language_zimu['ajax_show_jobsresume_inc_php_8'] : '';

}


$data['type'] = 'jobs';
$data['nowPage'] = $pindex;
$data['totalPages'] = $totalPages;
$data['data_list'] = $jobslist;

}

ajaxReturn(1,$language_zimu['ajax_show_jobsresume_inc_php_9'],$data);