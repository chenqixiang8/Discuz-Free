<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$ids = intval($_GET['ids']);
$audit = intval($_GET['audit']);
$wxtpl = zm_diconv(strip_tags($_GET['wxtpl']));
$op = addslashes($_GET['op']);

$manage_uids = explode(',', $zmdata['manage_uids']);

if(!in_array($_G['uid'],$manage_uids)){
echo 'error';exit();
}

if($op == 'jobs' ){


$listdata = DB::fetch_first('select * from %t where id=%d', array(
    'zimu_zhaopin_jobs',
    $ids
));

$paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
    'zimu_zhaopin_parameter2',
    'wxtpl'
));

$paramters = unserialize($paramter['parameter']);

$first = $language_zimu['towapaudit_inc_php_0'] . ($audit == 1 ? $language_zimu['towapaudit_inc_php_1'] : $language_zimu['towapaudit_inc_php_2']);

notification_user($listdata['uid'], $paramters['wxtpl_jobs'], array(
    'first' => $first,
    'keyword1' => $listdata['jobs_name'],
    'keyword2' => $audit == 1 ? $language_zimu['towapaudit_inc_php_3'] : $language_zimu['towapaudit_inc_php_4'],
    'keyword3' => $wxtpl,
    'remark' => $language_zimu['towapaudit_inc_php_5'],
    'url' => ZIMUCMS_URL . '&model=company&ac=jobs_add&jid=' . $ids
));

$magcon = '{"tag":"' . $language_zimu['towapaudit_inc_php_6'] . '","title":"' . $language_zimu['towapaudit_inc_php_7'] . ($audit == 1 ? $language_zimu['towapaudit_inc_php_8'] : $language_zimu['towapaudit_inc_php_9']) . '","title_themecolor":"#ff0000","link":"' . ZIMUCMS_URL . '&model=mycompany&jid=' . $ids . '","extra_info":[{"key":"' . $language_zimu['towapaudit_inc_php_10'] . '","val":"' . $listdata['jobs_name'] . '"},{"key":"' . $language_zimu['towapaudit_inc_php_11'] . '","val":"' . ($audit == 1 ? $language_zimu['towapaudit_inc_php_12'] : $language_zimu['towapaudit_inc_php_13']) . '"},{"key":"' . $language_zimu['towapaudit_inc_php_14'] . '","val":"' . $wxtpl . '"}],"des":"' . $language_zimu['towapaudit_inc_php_15'] . '","des_themecolor":"#008000"}';

notification_user_magapp($listdata['uid'], $magcon);


    DB::query("update %t set audit=%d where id=%d", array(
        'zimu_zhaopin_jobs',
        $audit,
        $ids
    ));

    ajaxReturn(1,$language_zimu['towapaudit_inc_php_16']);

}


if($op == 'resume' ){


$data = DB::fetch_first('select * from %t where id=%d', array(
    'zimu_zhaopin_resume',
    $ids
));

$paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
    'zimu_zhaopin_parameter2',
    'wxtpl'
));

$paramters = unserialize($paramter['parameter']);

$first = $language_zimu['towapaudit_inc_php_17'];

notification_user($data['uid'],$paramters['wxtpl_resume'],array('first'=>$first,'keyword1'=>$data['fullname'].$language_zimu['towapaudit_inc_php_18'],'keyword2'=>date('Y-m-d H:i',$_G['timestamp']),'keyword3'=>$audit==1 ? $language_zimu['towapaudit_inc_php_19'] : $language_zimu['towapaudit_inc_php_20'],'keyword4'=>$wxtpl,'remark'=>$language_zimu['towapaudit_inc_php_21'],'url'=>ZIMUCMS_URL.'&model=mypersonal'));

$magcon = '{"tag":"'.$language_zimu['towapaudit_inc_php_22'].'","title":"'.$language_zimu['towapaudit_inc_php_23'].'","title_themecolor":"#ff0000","link":"'.ZIMUCMS_URL.'&model=mypersonal","extra_info":[{"key":"'.$language_zimu['towapaudit_inc_php_24'].'","val":"'.$data['fullname'].$language_zimu['towapaudit_inc_php_25'].'"},{"key":"'.$language_zimu['towapaudit_inc_php_26'].'","val":"'.($audit==1 ? $language_zimu['towapaudit_inc_php_27'] : $language_zimu['towapaudit_inc_php_28']).'"},{"key":"'.$language_zimu['towapaudit_inc_php_29'].'","val":"'.$wxtpl.'"}],"des":"'.$language_zimu['towapaudit_inc_php_30'].'","des_themecolor":"#008000"}';

    notification_user_magapp($data['uid'],$magcon);


    DB::query("update %t set audit=%d where id=%d", array(
        'zimu_zhaopin_resume',
        $audit,
        $ids
    ));

    ajaxReturn(1,$language_zimu['towapaudit_inc_php_31']);

}


if($op == 'com' ){


$data = DB::fetch_first('select * from %t where id=%d', array(
    'zimu_zhaopin_company_profile',
    $ids
));

$paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
    'zimu_zhaopin_parameter2',
    'wxtpl'
));

$paramters = unserialize($paramter['parameter']);

notification_user($data['uid'],$paramters['wxtpl_admin'],array('first'=>$data['companyname'].$language_zimu['towapaudit_inc_php_32'],'keyword1'=>$audit==1 ? $language_zimu['towapaudit_inc_php_33'] : $language_zimu['towapaudit_inc_php_34'],'keyword2'=>date('Y-m-d H:i',$_G['timestamp']),'remark'=>$wxtpl.'\r\n'.$language_zimu['towapaudit_inc_php_35'],'url'=>ZIMUCMS_URL.'&model=mycompany'));


$magcon = '{"tag":"'.$language_zimu['towapaudit_inc_php_36'].'","title":"'.$data['companyname'].$language_zimu['towapaudit_inc_php_37'].'","title_themecolor":"#ff0000","link":"'.ZIMUCMS_URL.'&model=mycompany","extra_info":[{"key":"'.$language_zimu['towapaudit_inc_php_38'].'","val":"'.($audit==1 ? $language_zimu['towapaudit_inc_php_39'] : $language_zimu['towapaudit_inc_php_40']).'"}],"des":"'.$wxtpl.'<br>'.$language_zimu['towapaudit_inc_php_41'].'","des_themecolor":"#008000"}';

    notification_user_magapp($data['uid'],$magcon);

    DB::query("update %t set audit=%d where id=%d", array(
        'zimu_zhaopin_company_profile',
        $audit,
        $ids
    ));

    ajaxReturn(1,$language_zimu['towapaudit_inc_php_42']);

}