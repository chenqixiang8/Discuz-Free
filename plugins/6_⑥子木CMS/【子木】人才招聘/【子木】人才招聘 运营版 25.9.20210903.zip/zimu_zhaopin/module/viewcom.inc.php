<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$cid = intval($_GET['cid']);

$companydata = DB::fetch_first('select * from %t where id=%d order by id asc', array(
        'zimu_zhaopin_company_profile',
        $cid
    ));

$companydata['logo'] = $companydata['logo'] ? $companydata['logo'] : $company_nologo;

$companyjob = DB::fetch_all('select * from %t where audit !=3 and display != 2 and company_id=%d '.$noauditwheresql2.' and display!=2 order by id asc', array(
        'zimu_zhaopin_jobs',
        $cid
    ));

$utype = DB::result_first('select utype from %t where uid=%d order by id desc', array(
        'zimu_zhaopin_members',
        $_G['uid']
    ));

$isfav = DB::fetch_first('select * from %t where uid=%d and company_id=%d order by id desc', array(
	'zimu_zhaopin_personal_focus_company',
	$_G['uid'],
	$cid
));

$isresume = DB::fetch_first('select * from %t where uid=%d '.$noauditwheresql2.' order by id desc', array(
    'zimu_zhaopin_resume',
    $_G['uid']
));

$isapply= DB::fetch_first('select * from %t where personal_uid=%d and company_id=%d order by did desc', array(
    'zimu_zhaopin_personal_jobs_apply',
    $_G['uid'],
    $cid
));


if(!$isresume || ($zmdata['settings']['resume_tocomtel'] && $isresume['audit']!=1) ){

$companydata['telephone'] = substr_replace($companydata['telephone'],'****',3,4);
$companydata['landline_tel'] = substr_replace($companydata['landline_tel'],'****',5,4);

}

$manage_uids = str_replace(';', ',', $zmdata['manage_uids']);
$manage_uids = explode(',', $manage_uids);

$audit_tip1 = explode(PHP_EOL, trim($zmdata['settings']['audit_tip1']));
$audit_tip2 = explode(PHP_EOL, trim($zmdata['settings']['audit_tip2']));


$navtitle = $companydata['companyname'].'_'.$zmdata['base']['title'];
$keywords = $companydata['companyname'].','.$zmdata['base']['title'];
$description = cutstr($companydata['contents'],100,'...');

$share_title = $companydata['companyname'].'_'.$zmdata['base']['title'];
$share_desc = $zmdata['base']['share_desc'];
$share_url = rtrim($_G['siteurl'], '/').$_SERVER['REQUEST_URI'];
if ($companydata['logo'] && !preg_match('/^(http|\.)/i', $companydata['logo'])) {
   $companydata['logo'] = $_G['siteurl'].$companydata['logo'];
}
$share_thumb = $companydata['logo'] ? $companydata['logo'] : $zmdata['base']['share_thumb'];
    if(checkmobile() && $zmdata['settings']['open_newwap']==1){
        dheader('Location:' . $_G['siteurl'] . 'source/plugin/zimu_zhaopin/h5/pages/qiye/view?ids='.$cid.'&mobile=2');
        exit();
    }
include zimu_template('viewcom');