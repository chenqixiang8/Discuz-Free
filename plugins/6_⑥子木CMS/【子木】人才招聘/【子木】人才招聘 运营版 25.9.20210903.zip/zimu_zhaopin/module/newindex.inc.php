<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if($zmdata['settings']['show_noaudit']){
$noauditwheresql = ' where audit = 1 ';
$noauditwheresql2 = ' and audit = 1 ';
}else{
$noauditwheresql = ' where 1 = 1 ';
$noauditwheresql2 = ' and 1 = 1 ';
}

if(file_exists(DISCUZ_ROOT . './source/plugin/zimu_zhaopin/module/a_change_area.inc.php') && ( $zmdata['settings']['change_city'] == 1 || $zmdata['settings']['change_area'] > 0) ){
$citycategory  = getcookie('citycategory');
$citycategory2 = getcookie('citycategory2');
if($zmdata['settings']['change_area']==2 && getcookie('citycategory2')){
$jobs_wheresql = ' and district2 = '.getcookie('citycategory2').' ';
$resume_wheresql = ' and district LIKE \'%.'.getcookie('citycategory2').'.%\' ';
$company_wheresql = ' and district LIKE \'%.'.getcookie('citycategory2').'.%\' ';

$navtitle = str_replace('city', getcookie('citycategory2_cn'), $zmdata['settings']['seo_title_city']);
$keywords = str_replace('city', getcookie('citycategory2_cn'), $zmdata['settings']['seo_keywords_city']);
$description = str_replace('city', getcookie('citycategory2_cn'), $zmdata['settings']['seo_description_city']);


}elseif(getcookie('citycategory')){
$jobs_wheresql = ' and district = '.getcookie('citycategory').' ';
$resume_wheresql = ' and district LIKE \'%'.getcookie('citycategory').'.%\' ';
$company_wheresql = ' and district LIKE \'%'.getcookie('citycategory').'.%\' ';

$navtitle = str_replace('city', getcookie('citycategory_cn'), $zmdata['settings']['seo_title_city']);
$keywords = str_replace('city', getcookie('citycategory_cn'), $zmdata['settings']['seo_keywords_city']);
$description = str_replace('city', getcookie('citycategory_cn'), $zmdata['settings']['seo_description_city']);


}
}


$paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
	'zimu_zhaopin_parameter2',
	'indexad'
));

$paramters_indexad = unserialize($paramter['parameter']);

$index_company = DB::fetch_all('select * from %t where setmeal_id > 1 '.$noauditwheresql2.' %i order by id asc limit 50', array(
        'zimu_zhaopin_company_profile',
        $company_wheresql
    ));

$index_job = DB::fetch_all('select * from %t '.$noauditwheresql.' %i order by id desc limit 50', array(
        'zimu_zhaopin_jobs',
        $jobs_wheresql.' and company_audit !=3 '
    ));

if($_G['uid']){

$utype = DB::result_first('select utype from %t where uid=%d order by id desc', array(
        'zimu_zhaopin_members',
        $_G['uid']
    ));

if(!$utype){

	$setsqlarr['uid']        = $_G['uid'];
	$setsqlarr['utype']        = 2;
	DB::insert('zimu_zhaopin_members', $setsqlarr, 1);

}


}

$resume_info = DB::fetch_first('select * from %t where uid=%d '.$noauditwheresql2.' %i order by id asc limit 50', array(
        'zimu_zhaopin_resume',
        $_G['uid'],
        $resume_wheresql
    ));


$alltopcat2 = DB::fetch_all('select * from %t where parentid=0 order by category_order asc,id asc', array(
        'zimu_zhaopin_category_jobs'
    ));
  
$jobsCount = DB::result_first("SELECT count(*) FROM %t", array(
        "zimu_zhaopin_jobs"
    )); 

$jobsCount = $zmdata['settings']['jobscount'] + $jobsCount;

$resumeCount = DB::result_first("SELECT count(*) FROM %t", array(
        "zimu_zhaopin_resume"
    )); 

$resumeCount = $zmdata['settings']['resumeCount'] + $resumeCount;

$comcount = DB::result_first("SELECT count(*) FROM %t", array(
        "zimu_zhaopin_company_profile"
    )); 

$comcount = $zmdata['settings']['comcount'] + $comcount;

$views = $zmdata['settings']['views'] + $zmdata['base']['views'];

if (!checkmobile()){

$alltopcat = DB::fetch_all('select * from %t where parentid=0 order by category_order asc,id asc limit 7', array(
        'zimu_zhaopin_category_jobs'
    ));

foreach ($alltopcat as $key => $value) {

$alltopcat[$key]['list'] = DB::fetch_all('select * from %t where parentid=%d order by category_order asc,id asc', array(
        'zimu_zhaopin_category_jobs',
        $value['id']
    ));

}

$top_jobslist = DB::fetch_all('select * from %t where company_audit !=3 and audit !=3 and display !=2 and stick_endtime > %d '.$noauditwheresql2.' %i order by refreshtime desc,stick_endtime desc,id desc', array(
    'zimu_zhaopin_jobs',
    $_G['timestamp'],
    $jobs_wheresql
));

$jobslist2 = DB::fetch_all('select * from %t where company_audit !=3 and audit !=3 and display !=2 and stick_endtime < %d '.$noauditwheresql2.' %i order by refreshtime desc,id desc limit 30', array(
    'zimu_zhaopin_jobs',
    $_G['timestamp'],
    $jobs_wheresql
));

$jobslist = array_merge($top_jobslist,$jobslist2);

$qiyelist = DB::fetch_all('select * from %t where audit !=3 '.$noauditwheresql2.' %i order by rand() limit 12', array(
    'zimu_zhaopin_company_profile',
    $company_wheresql
));

$paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
    'zimu_zhaopin_parameter2',
    'pcindexad'
));

$pcindexad_paramters = unserialize($paramter['parameter']);

$adlist1 = explode(PHP_EOL, trim($zmdata['settings']['adlist1']));
foreach ($adlist1 as $key => $v) {
    $adlist1[$key] = explode('|', $v);
}

$adlist2 = explode(PHP_EOL, trim($zmdata['settings']['adlist2']));
foreach ($adlist2 as $key => $v) {
    $adlist2[$key] = explode('|', $v);
}
$adlist3 = explode(PHP_EOL, trim($zmdata['settings']['adlist3']));
foreach ($adlist3 as $key => $v) {
    $adlist3[$key] = explode('|', $v);
}
$adlist4 = explode(PHP_EOL, trim($zmdata['settings']['adlist4']));
foreach ($adlist4 as $key => $v) {
    $adlist4[$key] = explode('|', $v);
}
$adlist5 = explode(PHP_EOL, trim($zmdata['settings']['adlist5']));
foreach ($adlist5 as $key => $v) {
    $adlist5[$key] = explode('|', $v);
}
$adlist6 = explode(PHP_EOL, trim($zmdata['settings']['adlist6']));
foreach ($adlist6 as $key => $v) {
    $adlist6[$key] = explode('|', $v);
}

}

$pcadlist = DB::fetch_all('select * from %t where is_pcad>0 '.$noauditwheresql2.' %i order by is_pcad asc,id asc', array(
        'zimu_zhaopin_company_profile',
        $company_wheresql
    ));

$topnews = DB::fetch_all('select * from %t where toutiao = 1 order by id desc limit 10', array(
    'zimu_zhaopin_news'
));

$hotnews = DB::fetch_all('select * from %t order by views desc limit 10', array(
    'zimu_zhaopin_news'
));

$addnews = DB::fetch_all('select * from %t order by id desc limit 22', array(
    'zimu_zhaopin_news'
));


$resumelist = DB::fetch_all('select * from %t where audit !=3 and display=1 '.$noauditwheresql2.' %i order by rand() limit 15', array(
    'zimu_zhaopin_resume',
    $resume_wheresql
));

if($_G['uid'] && $zmdata['settings']['no_user_num']!=0){
$myresume = DB::fetch_first('select * from %t where uid=%d order by id asc', array(
    'zimu_zhaopin_resume',
    $_G['uid']
));
$mycom = DB::fetch_first('select * from %t where uid=%d order by id asc', array(
    'zimu_zhaopin_company_profile',
    $_G['uid']
));
if($myresume || $mycom){
$zmdata['settings']['no_user_num'] = 0;
}
}

if(checkmobile() && $zmdata['settings']['open_newwap']==1){
    dheader('Location:' . $_G['siteurl'] . 'source/plugin/zimu_zhaopin/h5/');
    exit();
}
include zimu_template('newindex');