<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$tosubmit = intval($_GET['tosubmit']);
$iid = intval($_GET['iid']);

if($tosubmit == 1){

            $pid = intval($_GET['pid']);

            $uid = $_G['uid'];

            $count = DB::result_first('select count(*) from %t where uid=%d and resume_id=%d order by id asc', array(
                'zimu_zhaopin_resume_img',
                $_G['uid'],
                $pid
            ));

            if($count >= 6) $this->ajaxReturn(0,$language_zimu['resume_edit_img_inc_php_0']);
            $data['resume_id'] = $pid;
            $data['uid'] = $uid;
            $data['title'] = I('title','','trim');
            $data['img'] = I('img','','trim');
            $data['addtime'] = $_G['timestamp'];
            $data['audit'] = 2;

            if($iid){

            $data['id'] = $iid;

            $result = DB::update('zimu_zhaopin_resume_img', $data, array(
                'id' => $iid,
                'uid' => $uid,
                'resume_id' => $pid,

            ));


            }else{


            $result = DB::insert('zimu_zhaopin_resume_img', $data, 1);

            }

            ajaxReturn(1,$language_zimu['resume_edit_img_inc_php_1'],array('url'=>ZIMUCMS_URL.'&model=resume_replenish&rid='.$pid));
            exit();


}else{

$pid = intval($_GET['pid']);

$info = DB::fetch_first('select * from %t where uid=%d and id=%d and resume_id=%d order by id asc', array(
        'zimu_zhaopin_resume_img',
        $_G['uid'],
        $iid,
        $pid
    ));

include zimu_template('resume_edit_img');

}