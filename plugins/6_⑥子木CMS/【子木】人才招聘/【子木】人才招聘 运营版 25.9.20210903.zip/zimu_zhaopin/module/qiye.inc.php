<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
    'zimu_zhaopin_parameter2',
    'indexad'
));

$paramters_indexad = unserialize($paramter['parameter']);


$category_jobs = DB::fetch_all('select * from %t where parentid=0 order by category_order asc,id asc', array(
        'zimu_zhaopin_category_jobs'
    ));

foreach ($category_jobs as $key => $value) {

$category_jobs[$key]['list'] = DB::fetch_all('select * from %t where parentid=%d order by category_order asc,id asc', array(
        'zimu_zhaopin_category_jobs',
        $value['id']
    ));

}


    $districtlist = DB::fetch_all('select * from %t order by sort asc,id asc', array(
        'zimu_zhaopin_area'
    ));

$category = array();

$categoryData = DB::fetch_all('select c_id,c_alias,c_name from %t order by c_order asc,c_id asc', array(
    'zimu_zhaopin_category'
));

foreach ($categoryData as $key=>$val){
    $category[$val['c_alias']][$val['c_id']] = $val['c_name'];
}

$wagelist = $category['ZM_wage'];

$explist = $category['ZM_experience'];

$naturelist = $category['ZM_jobs_nature'];

$edulist = $category['ZM_education'];

$taglist = $category['ZM_jobtag'];

$tradelist = $category['ZM_trade'];


$citycategory = intval($_GET['citycategory']);
$jobcategory = intval($_GET['jobcategory']);
$wage = intval($_GET['wage']);

if(!$citycategory && file_exists(DISCUZ_ROOT . './source/plugin/zimu_zhaopin/module/a_change_area.inc.php') && ( $zmdata['settings']['change_city'] == 1 || $zmdata['settings']['change_area'] > 0) ){
$citycategory  = getcookie('citycategory');
$citycategory2 = getcookie('citycategory2');
}



$wherearr = array();
if($citycategory2){
$citycategory2 = stripsearchkey($citycategory2);
$wherearr[]=' district LIKE \'%.'.$citycategory2.'.%\' ';
}elseif($citycategory){
$citycategory=stripsearchkey($citycategory);
$wherearr[]=' district LIKE \'%'.$citycategory.'.%\' ';
}

if($jobcategory){
$topcat = intval($_GET['topcat']) ? 'topclass' : 'category';
$wherearr[]=' '.$topcat.' = '.$jobcategory.' ';
}

$wherearr[] = ' audit !=3 ';


$wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';


$pindex = max(1, intval($_GET['page']));
$psize = 100;

$qiyelist = DB::fetch_all('select * from %t %i '.$noauditwheresql2.' order by logintime desc,setmeal_id desc,certificate_img_audit desc,id desc limit %d,%d', array(
	'zimu_zhaopin_company_profile',
	$wheresql,
	($pindex - 1) * $psize,
	$psize
));

    $total = DB::result_first('select count(*) from %t %i '.$noauditwheresql2.' order by logintime desc,setmeal_id desc,certificate_img_audit desc,id desc', array(
        'zimu_zhaopin_company_profile',
        $wheresql
    ));

    $totalPages = ceil($total / $psize);

    $pager = pagination($total, $pindex, $psize);


if(!checkmobile()){

$randqiye = DB::fetch_all('select * from %t where audit !=3 and setmeal_id>0 '.$noauditwheresql2.' order by rand() limit 12', array(
    'zimu_zhaopin_company_profile'
));

}

$navtitle = $zmdata['settings']['qiye_seo_title'] ? $zmdata['settings']['qiye_seo_title'] : $navtitle;
$keywords = $zmdata['settings']['qiye_seo_keyword'] ? $zmdata['settings']['qiye_seo_keyword'] : $navtitle;
$description = $zmdata['settings']['qiye_seo_desc'] ? $zmdata['settings']['qiye_seo_desc'] : $navtitle;
    if(checkmobile() && $zmdata['settings']['open_newwap']==1){
        dheader('Location:' . $_G['siteurl'] . 'source/plugin/zimu_zhaopin/h5/pages/index/qiye');
        exit();
    }
include zimu_template('qiye');