<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if ($_G['uid']) {
    
    $tomodel = addslashes($_GET['tomodel']);
    $jid     = intval($_GET['jid']);
    
    if ($tomodel == 'viewresume') {
        
        $resume_info = DB::fetch_first('select * from %t where uid=%d order by id asc', array(
            'zimu_zhaopin_resume',
            $_G['uid']
        ));
        
        if ($resume_info) {
            
            $nums = DB::result_first("SELECT count(*) FROM %t where model=%s and uid=%d and addtime>%d", array(
                'zimu_zhaopin_share_refresh',
                $tomodel,
                $_G['uid'],
                strtotime(date('Y-m-d', $_G['timestamp']))
            ));
            
            
            if ($nums < $zmdata['settings']['resume_share_refresh_nums']) {
                
                $setsqlarr['refreshtime'] = $_G['timestamp'];
                DB::update('zimu_zhaopin_resume', $setsqlarr, array(
                    'id' => $resume_info['id'],
                    'uid' => $_G['uid']
                ));
                $share_refresh_data = array(
                    'uid' => $_G['uid'],
                    'model' => $tomodel,
                    'addtime' => $_G['timestamp']
                );
                DB::insert('zimu_zhaopin_share_refresh', $share_refresh_data);
                
                
                echo json_encode(array(
                    'ok' => 1
                ), true);
                
            }
            
        }
        
        
    }
    
    if ($tomodel == 'viewjob' && $jid > 0) {
        
        $job = DB::fetch_first('select * from %t where id=%d and uid=%d order by id desc', array(
            'zimu_zhaopin_jobs',
            $jid,
            $_G['uid']
        ));
        
        if ($job) {
            
            
            $nums = DB::result_first("SELECT count(*) FROM %t where model=%s and uid=%d and addtime>%d", array(
                'zimu_zhaopin_share_refresh',
                $tomodel,
                $_G['uid'],
                strtotime(date('Y-m-d', $_G['timestamp']))
            ));
            
            
            if ($nums < $zmdata['settings']['jobs_share_refresh_nums']) {
                
                $setsqlarr['refreshtime'] = $_G['timestamp'];
                DB::update('zimu_zhaopin_jobs', $setsqlarr, array(
                    'id' => $jid,
                    'uid' => $_G['uid']
                ));
                $share_refresh_data = array(
                    'uid' => $_G['uid'],
                    'model' => $tomodel,
                    'addtime' => $_G['timestamp']
                );
                DB::insert('zimu_zhaopin_share_refresh', $share_refresh_data);
                
                
                echo json_encode(array(
                    'ok' => 1
                ), true);
                
            }
            
        }
        
    }
    
}