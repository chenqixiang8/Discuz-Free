<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$tosubmit = intval($_GET['tosubmit']);
$wid = intval($_GET['wid']);


$category = array();

$categoryData = DB::fetch_all('select c_id,c_alias,c_name from %t order by c_order asc,c_id asc', array(
    'zimu_zhaopin_category'
));

foreach ($categoryData as $key=>$val){
    $category[$val['c_alias']][$val['c_id']] = $val['c_name'];
}

$languages = $category['ZM_language'];

$levels = $category['ZM_language_level'];

if($tosubmit == 1 ){

$pid = intval($_GET['pid']);

            $uid = $_G['uid'];

            $count = DB::result_first('select count(*) from %t where uid=%d and pid=%d order by id asc', array(
                'zimu_zhaopin_resume_language',
                $_G['uid'],
                $pid
            ));

            if ($count>6) ajaxReturn(0,$language_zimu['resume_edit_lang_inc_php_0']);

            $language['uid'] = $uid;
            $language['pid'] = $pid;
            $language['language'] = I('language',0,'intval');
            $language['level'] = I('level',0,'intval');
            $language['language_cn'] = $category['ZM_language'][$language['language']];
            $language['level_cn'] = $category['ZM_language_level'][$language['level']];
            if($wid){

                $language['id'] = $wid;

                if($lan['language'] != $language['language']){

                $is = DB::fetch_first('select * from %t where uid=%d and language=%d and pid=%d order by id asc', array(
                    'zimu_zhaopin_resume_language',
                    $_G['uid'],
                    $language['language'],
                    $pid
                ));

                $is && ajaxReturn(0,$language_zimu['resume_edit_lang_inc_php_1']);

            $result = DB::update('zimu_zhaopin_resume_education', $language, array(
                'id' => $wid,
                'uid' => $uid,
                'pid' => $pid,
            ));


                }

            }else{

                $is = DB::fetch_first('select * from %t where uid=%d and language=%d and pid=%d order by id asc', array(
                    'zimu_zhaopin_resume_language',
                    $_G['uid'],
                    $language['language'],
                    $pid
                ));

                $is && ajaxReturn(0,$language_zimu['resume_edit_lang_inc_php_2']);

            $result = DB::insert('zimu_zhaopin_resume_language', $language, 1);

            }

            ajaxReturn(1,$language_zimu['resume_edit_lang_inc_php_3'],array('url'=>ZIMUCMS_URL.'&model=resume_replenish&rid='.$pid));
            exit();


}else{

$pid = intval($_GET['rid']);

$info = DB::fetch_first('select * from %t where uid=%d and id=%d and pid=%d order by id asc', array(
        'zimu_zhaopin_resume_language',
        $_G['uid'],
        $wid,
        $pid
    ));

include zimu_template('resume_edit_lang');

}