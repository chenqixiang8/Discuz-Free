<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if (!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }

    use think\Db;

    $token = addslashes($_GET['token']);
    $myuid = checktoken($token);
    if($myuid['uid']>0){
        $check_company_setmeal = check_company_setmeal($myuid['uid']);
    }
    $op = addslashes($_GET['op']);
    $ids = intval($_GET['ids']);

    if($op=='123'){

    }elseif($op == 'service_stick' ){

        $service_id = intval($_GET['service_id']);

        $setmeal = Db::name('zimu_zhaopin_members_setmeal')->where([['uid','=',$myuid['uid']]])->find();
        $service_info = Db::name('zimu_zhaopin_setmeal_increment')->where([['id','=',$service_id]])->find();

        $new_price = $setmeal['discount_stick'] > 0 ? round($service_info['price'] * $setmeal['discount_stick'] / 10, 2) : $service_info['price'];

        $params['oid']           = date('YmdHis') . mt_rand(100000, 999999);
        $params['zpid']          = $ids;
        $params['uid']           = $myuid['uid'];
        $params['openid']        = $myuid['openid'];
        $params['utype']         = 1;
        $params['order_type']    = 8;
        $params['pay_type']      = 2;
        $params['is_paid']       = 1;
        $params['amount']        = $new_price;
        $params['pay_amount']    = $new_price;
        $params['payment']      = 'wxpay';
        $params['payment_cn']   = $language_zimu['new_companyservice_inc_php_0'];
        $params['description']   = $service_info['name'];
        $params['service_name']  = 'jobs_stick';
        $params_array            = array(
            'days' => $service_info['value']
        );
        $params_array['jobs_id'] = $ids;
        $params['params']        = serialize($params_array);
        $params['addtime']       = time();
        $params['discount'] = $language_zimu['new_companyservice_inc_php_1'] . $setmeal['discount_stick'] . $language_zimu['new_companyservice_inc_php_2'];
        $return_order_info['order_id'] = Db::name('zimu_zhaopin_order')->insertGetId($params);
        zimu_json($return_order_info);

    }elseif($op == 'service_refresh' ){

        $service_id = intval($_GET['service_id']);

        $setmeal = Db::name('zimu_zhaopin_members_setmeal')->where([['uid','=',$myuid['uid']]])->find();
        $service_info = Db::name('zimu_zhaopin_setmeal_increment')->where([['id','=',$service_id]])->find();

        $new_price = $setmeal['discount_auto_refresh_jobs'] > 0 ? round($service_info['price'] * $setmeal['discount_auto_refresh_jobs'] / 10, 2) : $service_info['price'];

        $params['oid']           = date('YmdHis') . mt_rand(100000, 999999);
        $params['zpid']          = $ids;
        $params['uid']           = $myuid['uid'];
        $params['openid']        = $myuid['openid'];
        $params['utype']         = 1;
        $params['order_type']    = 8;
        $params['pay_type']      = 2;
        $params['is_paid']       = 1;
        $params['amount']        = $new_price;
        $params['pay_amount']    = $new_price;
        $params['payment']      = 'wxpay';
        $params['payment_cn']   = $language_zimu['new_companyservice_inc_php_3'];
        $params['description']   = $service_info['name'];
        $params['service_name']  = 'jobs_auto_refresh';
        $params['setmeal']  = $service_id;
        $params_array = array('days'=>$service_info['value']);
        $params_array['starttime'] = time();
        for ($i=0; $i < $service_info['value']*4; $i++) {
            $timespace = 3600*6*$i;
            if($i+1==$service_info['value']*4){
                $params_array['endtime'] = $params_array['starttime']+$timespace;
            }
        }
        $params_array['jobs_id'] = $ids;
        $params['params']        = serialize($params_array);
        $params['addtime']       = time();
        $params['discount'] = $language_zimu['new_companyservice_inc_php_4'] . $setmeal['discount_auto_refresh_jobs'] . $language_zimu['new_companyservice_inc_php_5'];
        $return_order_info['order_id'] = Db::name('zimu_zhaopin_order')->insertGetId($params);
        zimu_json($return_order_info);

    }elseif($op == 'torefresh' ){

        $my_setmeal = Db::name('zimu_zhaopin_members_setmeal')->where([['uid','=',$myuid['uid']]])->find();

        $refresh_time = Db::name('zimu_zhaopin_refresh_log')->where([['uid','=',$myuid['uid']],['type','=',1001],['mode','=',2],['addtime','>',strtotime(date('Y-m-d', time()))]])->count();


        if ($refresh_time >= $my_setmeal['refresh_jobs_free']) {
            $res['type'] = 'norefresh';
            $res['tip'] = $language_zimu['new_companyservice_inc_php_6'];
            $res['text'] = $zmdata['settings']['refresh_jobs_price'].$zmdata['settings']['money_name'].$language_zimu['new_companyservice_inc_php_7'];
            zimu_json($res);
        }

        Db::name('zimu_zhaopin_jobs')->where('id', $ids)->data(['refreshtime' => time()])->update();

        $setsqlarr_refresh_log['uid']     = $myuid['uid'];
        $setsqlarr_refresh_log['mode']    = 2;
        $setsqlarr_refresh_log['addtime'] = time();
        $setsqlarr_refresh_log['type']    = 1001;

        Db::name('zimu_zhaopin_refresh_log')->insert($setsqlarr_refresh_log);

        $res['type'] = 'success';
        $res['tip'] = $language_zimu['new_companyservice_inc_php_8'];
        zimu_json($res);

    }elseif($op == 'againpay' ){

        $orderdata = Db::name('zimu_zhaopin_order')->where([['uid','=',$myuid['uid']],['zpid','=',$ids],['service_name','=','jobs_pay_add']])->order(['id'=>'desc'])->find();
        $params = unserialize($orderdata['params']);

        if($params['days']>0){
            $params['oid']           = date('YmdHis') . mt_rand(100000, 999999);
            $params['amount']        = round($zmdata['settings']['add_jobs_price'], 2);
            $params['pay_amount']    = round($zmdata['settings']['add_jobs_price'], 2);
            $params['description']   = $language_zimu['new_companyservice_inc_php_9'];
            $params['service_name']  = 'jobs_pay_add';
            $params_array['jobs_id'] = $ids;
            $params['params']        = serialize($params_array);
            $params['openid'] =   $params['openid'] ? $params['openid'] : $myuid['openid'];
            Db::name('zimu_zhaopin_order')->where([['id','=',$orderdata['id']]])->data($params)->update();
        }elseif(!$params['openid']){
            Db::name('zimu_zhaopin_order')->where('id', $orderdata['id'])->data(['openid' => $myuid['openid']])->update();
        }

        $return_order_info['order_id'] = $orderdata['id'];
        zimu_json($return_order_info);


    }elseif($op == 'refresh_one' ){

        $params['oid']           = date('YmdHis') . mt_rand(100000, 999999);
        $params['zpid']          = $ids;
        $params['uid']           = $myuid['uid'];
        $params['openid']        = $myuid['openid'];
        $params['utype']         = 1;
        $params['order_type']    = 13;
        $params['pay_type']      = 2;
        $params['is_paid']       = 1;
        $params['amount']        = $zmdata['settings']['refresh_jobs_price'];
        $params['pay_amount']    = $zmdata['settings']['refresh_jobs_price'];
        $params['payment']       = 'wxpay';
        $params['payment_cn']    = $language_zimu['new_companyservice_inc_php_10'];
        $params['description']   = $language_zimu['new_companyservice_inc_php_11'] . $language_zimu['new_companyservice_inc_php_12'] . $params['pay_amount'] . $zmdata['settings']['money_name'];
        $params['service_name']  = 'jobs_refresh';
        $params_array['jobs_id'] = $ids;
        $params_array['type']    = 'jobs_refresh';
        $params['params']        = serialize($params_array);
        $params['addtime']       = time();

        $return_order_info['order_id'] = Db::name('zimu_zhaopin_order')->insertGetId($params);
        zimu_json($return_order_info);

    }elseif($op == 'download_resume' ){

        $service_id = intval($_GET['service_id']);

        $setmeal = Db::name('zimu_zhaopin_members_setmeal')->where([['uid','=',$myuid['uid']]])->find();
        $service_info = Db::name('zimu_zhaopin_setmeal_increment')->where([['id','=',$service_id]])->find();

        $new_price = $setmeal['discount_download_resume'] > 0 ? round($service_info['price'] * $setmeal['discount_download_resume'] / 10, 2) : $service_info['price'];

        $params['oid']           = date('YmdHis') . mt_rand(100000, 999999);
        $params['zpid']          = 888;
        $params['uid']           = $myuid['uid'];
        $params['openid']        = $myuid['openid'];
        $params['utype']         = 1;
        $params['order_type']    = 6;
        $params['pay_type']      = 2;
        $params['is_paid']       = 1;
        $params['amount']        = $new_price;
        $params['pay_amount']    = $new_price;
        $params['payment']      = 'wxpay';
        $params['payment_cn']   = $language_zimu['new_companyservice_inc_php_13'];
        $params['description']   = $service_info['name'];
        $params['service_name']  = 'download_resume';
        $params_array           = array(
            'nums' => $service_info['value']
        );
        $params['params']        = serialize($params_array);
        $params['addtime']       = time();
        $params['discount'] = $language_zimu['new_companyservice_inc_php_14'] . $setmeal['discount_download_resume'] . $language_zimu['new_companyservice_inc_php_15'];
        $return_order_info['order_id'] = Db::name('zimu_zhaopin_order')->insertGetId($params);
        zimu_json($return_order_info);

    }elseif($op == 'down_resume_one' ){

        $params['oid']          = date('YmdHis') . mt_rand(100000, 999999);
        $params['zpid']         = $ids;
        $params['uid']          = $myuid['uid'];
        $params['openid']       = $myuid['openid'];
        $params['utype']        = 1;
        $params['order_type']   = 14;
        $params['pay_type']     = 2;
        $params['is_paid']      = 1;
        $params['amount']       = $zmdata['settings']['download_resume_price'];
        $params['pay_amount']   = $zmdata['settings']['download_resume_price'];
        $params['payment']      = 'wxpay';
        $params['payment_cn']   = $language_zimu['new_companyservice_inc_php_16'];
        $params['description']  = $language_zimu['new_companyservice_inc_php_17'];
        $params['service_name'] = 'resume_download';
        $params['addtime']      = time();
        $return_order_info['order_id'] = Db::name('zimu_zhaopin_order')->insertGetId($params);
        zimu_json($return_order_info);

    }elseif($op == 'get_setmeal' ){

        $res['setmeal'] = Db::name('zimu_zhaopin_setmeal')->where([['display','=',1],['apply','=',1]])->order(['show_order'=>'desc','id'=>'asc'])->select()->toArray();

        foreach ($res['setmeal'] as $key => $value) {
            $res['setmeal'][$key]['discount'] = get_discount_for_setmeal_one($value);
        }

        $res['mysetmeal'] = Db::name('zimu_zhaopin_members_setmeal')->where([['uid','=',$myuid['uid']]])->order(['id'=>'asc'])->find();
        $res['company'] = Db::name('zimu_zhaopin_company_profile')->where([['uid','=',$myuid['uid']]])->order(['id'=>'asc'])->find();

        $myjobs = Db::name('zimu_zhaopin_jobs')->where('uid', $myuid['uid'])->count();
        $res['mysetmeal']['jobs_meanwhile2'] = $res['mysetmeal']['jobs_meanwhile'] - $myjobs;
        $res['mysetmeal']['toutiao_audit'] = $zmdata['settings']['toutiao_audit'];
        zimu_json2($res);

    }elseif($op == 'buy_setmeal' ){

        $setmeal_id = intval($_GET['setmeal_id']);

        $setmeal = Db::name('zimu_zhaopin_setmeal')->where([['display','=',1],['apply','=',1]])->order(['show_order'=>'desc','id'=>'asc'])->select()->toArray();

        $params['oid'] = date('YmdHis') . mt_rand(100000, 999999);
        $params['zpid'] = 888;
        $params['uid'] = $myuid['uid'];
        $params['openid'] = $myuid['openid'];
        $params['utype']        = 1;
        $params['order_type']   = 1;
        $params['pay_type']     = 2;
        $params['is_paid']      = 1;
        $params['amount'] = $setmeal[$setmeal_id]['expense'];
        $params['pay_amount'] = $setmeal[$setmeal_id]['expense'];
        $params['payment'] = 'wxpay';
        $params['payment_cn'] = $language_zimu['new_companyservice_inc_php_18'];
        $params['description'] = $setmeal[$setmeal_id]['setmeal_name'];
        $params['service_name'] = 'setmeal_add';
        $params_array['uid'] = $myuid['uid'];
        $params_array['setmeal_id'] = $setmeal[$setmeal_id]['id'];
        $params_array['setmeal_name'] = $setmeal[$setmeal_id]['setmeal_name'];
        $params['params'] = serialize($params_array);
        $params['addtime'] = time();
        $params['setmeal'] = $setmeal[$setmeal_id]['id'];
        $return_order_info['order_id'] = Db::name('zimu_zhaopin_order')->insertGetId($params);
        zimu_json($return_order_info);

    }elseif($op == 'pay_chat' ){

        $touid = intval($_GET['touid']);
        $tomoney = intval($_GET['tomoney'])/$zmdata['settings']['jifen_bili'];

        $params['oid'] = date('YmdHis') . mt_rand(100000, 999999);
        $params['zpid'] = $touid;
        $params['uid'] = $myuid['uid'];
        $params['openid'] = $myuid['openid'];
        $params['utype']        = 1;
        $params['order_type']   = 8;
        $params['pay_type']     = 2;
        $params['is_paid']      = 1;
        $params['amount'] = $tomoney;
        $params['pay_amount'] = $tomoney;
        $params['payment'] = 'wxpay';
        $params['payment_cn'] = $language_zimu['new_companyservice_inc_php_19'];
        $params['description'] = $language_zimu['new_companyservice_inc_php_20'];
        $params['service_name'] = 'pay_chat';
        $params['addtime'] = time();
        $return_order_info['order_id'] = Db::name('zimu_zhaopin_order')->insertGetId($params);
        zimu_json($return_order_info);

    }else{

    }