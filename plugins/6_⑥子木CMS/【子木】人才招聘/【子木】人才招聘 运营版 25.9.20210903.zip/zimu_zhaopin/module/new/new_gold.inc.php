<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if (!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }

    use think\Db;

    $token = addslashes($_GET['token']);
    $myuid = checktoken($token);
    $op = addslashes($_GET['op']);
    $ids = intval($_GET['ids']);

    if($op=='123'){

    }elseif($op == 'mygold' ){

        $res['myinfo'] = $myuid;
        $res['myinfo']['jifen_name'] = $zmdata['settings']['jifen_name'];
        $res['myinfo']['jifen_bili'] = $zmdata['settings']['jifen_bili'];
        $res['myinfo']['points'] = $res['myinfo']['points']/10*$zmdata['settings']['jifen_bili'];
        $res['myinfo']['title'] = $zmdata['base']['title'];
        $res['handsel'] = Db::name('zimu_zhaopin_members_handsel')->where([['uid','=',$myuid['uid']]])->order(['id'=>'desc'])->select()->toArray();
        zimu_json($res);


    }elseif($op == 'paygold' ){

        $add_num = intval($_GET['addnum']);
        $params['oid']           = date('YmdHis') . mt_rand(100000, 999999);
        $params['zpid']          = 888;
        $params['uid']           = $myuid['uid'];
        $params['openid']        = $myuid['openid'];
        $params['utype']         = 1;
        $params['order_type']    = 2;
        $params['pay_type']      = 2;
        $params['is_paid']       = 1;
        $params['amount']        = $add_num/$zmdata['settings']['jifen_bili'];
        $params['pay_amount']    = $add_num/$zmdata['settings']['jifen_bili'];
        $params['payment']      = 'wxpay';
        $params['payment_cn']   = $language_zimu['new_gold_inc_php_0'];
        $params['description']   = $language_zimu['new_gold_inc_php_1'];
        $params['service_name']  = 'buy_points';
        $params_array            = array(
            'add_num' => $add_num*10/$zmdata['settings']['jifen_bili']
        );
        $params['params']        = serialize($params_array);
        $params['addtime']       = time();
        $params['referer']  = $rl;

        $return_order_info['order_id'] = Db::name('zimu_zhaopin_order')->insertGetId($params);
        zimu_json($return_order_info);


    }