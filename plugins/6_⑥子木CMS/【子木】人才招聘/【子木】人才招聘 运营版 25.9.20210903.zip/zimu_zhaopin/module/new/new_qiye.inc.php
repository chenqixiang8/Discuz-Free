<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if (!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }

    use think\Db;

    $token = addslashes($_GET['token']);
    $myuid = checktoken($token,0);
    $op = addslashes($_GET['op']);
    $zimu_get = zimu_array_gbk($_GET);
    $page = intval($_GET['page']);


    if($op == 'gethongniang') {


    }else{

        $districtlist = Db::name('zimu_zhaopin_area')->where([['parentid','=',0]])->order(['sort'=>'asc','id'=>'asc'])->select()->toArray();

        foreach ($districtlist as $key => $value) {
            $districtlist[$key]['list'] = Db::name('zimu_zhaopin_area')->where([['parentid','=',$value['id']]])->order(['sort'=>'asc','id'=>'asc'])->select()->toArray();
            if($zmdata['settings']['area_three']==1){
                foreach ($districtlist[$key]['list'] as $key2 => $value2) {
                    $districtlist[$key]['list'][$key2]['area_three'] = $zmdata['settings']['area_three'];
                    $districtlist[$key]['list'][$key2]['list'] = Db::name('zimu_zhaopin_area')->where([['parentid','=',$value2['id']]])->order(['sort'=>'asc','id'=>'asc'])->select()->toArray();
                }
            }
        }
        $res['districtlist'] = $districtlist;

        $res['tradelist'] = Db::name('zimu_zhaopin_category')->where([['c_alias','=','ZM_trade']])->order(['c_order'=>'asc','c_id'=>'asc'])->select()->toArray();

        $res['morelist']['taglist'] = Db::name('zimu_zhaopin_category')->where([['c_alias','=','ZM_jobtag']])->order(['c_order'=>'asc','c_id'=>'asc'])->select()->toArray();


        $selecttxt = json_decode(zimu_array_utf8($_GET['selecttxt']),true);
        $selecttxt = zimu_array_gbk($selecttxt);

        $wheresql2[] = ['audit','<>',3];
        $whereraw = '1=1';

        if($zmdata['settings']['area_three']==1){
            if($selecttxt['city3']){
                $wheresql2[] = ['district','like','%.'.$selecttxt['city3'].'%'];
            }elseif ($selecttxt['city2']){
                $wheresql2[] = ['district','like',['%'.$selecttxt['city1'].'.0%','%'.$selecttxt['city1'].'.'.$selecttxt['city2'].'.%'],'OR'];
            }elseif ($selecttxt['city1']){
                $wheresql2[] = ['district','like','%'.$selecttxt['city1'].'.%'];
            }
        }else{
            if($selecttxt['city2']){
                $wheresql2[] = ['district','like','%'.$selecttxt['city1'].'.'.$selecttxt['city2'].'.%'];
            }elseif ($selecttxt['city1']){
                $wheresql2[] = ['district','like',$selecttxt['city1'].'.%'];
            }
        }

        if($selecttxt['trade']){
            $wheresql2[] = ['trade','=',$selecttxt['trade']];
        }
        if($selecttxt['tag']){
            $wheresql2[] = ['tag','like','%'.$selecttxt['tag'].'%'];
        }

        if($selecttxt['sotxt']){
            $whereraw = $whereraw . ' and ( companyname like \'%'.$selecttxt['sotxt'].'%\' or contents like \'%'.$selecttxt['sotxt'].'%\' ) ';
        }


        if($zmdata['settings']['show_noaudit']){
            $wheresql2[] = ['audit','=',1];
        }

        $newqiye = Db::name('zimu_zhaopin_company_profile')->where($wheresql2)->whereRaw($whereraw)->order(['logintime'=>'desc','id'=>'desc'])->page($page,10)->select()->toArray();
        $res['newqiye'] = format_qiye($newqiye,$zmdata);
        if($zmdata['settings']['toutiao_audit']!=1){
            $res['newqiye'] = zimu_ad_system($res['newqiye'],'zhaopin4',0);
        }
        $res['wapfooter'] = $zmdata['settings']['wapfooterhtml'];
        $paramter = Db::name('zimu_zhaopin_parameter2')->where([['name','=','wappopup']])->order(['id'=>'asc'])->find();
        $res['wappopup'] = unserialize($paramter['parameter']);
        zimu_json($res);

    }
