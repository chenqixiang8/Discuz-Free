<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if (!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }

    use think\Db;

    $token = addslashes($_GET['token']);
    $islogin = intval($_GET['islogin']);
    $myuid = checktoken($token,$islogin);
    if($myuid['uid']>0){
        $check_company_setmeal = check_company_setmeal($myuid['uid']);
    }
    $op = addslashes($_GET['op']);
    $ids = intval($_GET['ids']);

    if($op == 'tofav') {

        $myuid = checktoken($token);
        $has = Db::name('zimu_zhaopin_personal_favorites')->where([['personal_uid','=',$myuid['uid']],['jobs_id','=',$ids]])->find();
        if($has){
            Db::name('zimu_zhaopin_personal_favorites')->where('did', $has['did'])->delete();
            $res['tip'] = $language_zimu['new_viewjob_inc_php_0'];
        }else{
            $jobsinfo = Db::name('zimu_zhaopin_jobs')->where([['id','=',$ids]])->find();
            $data['personal_uid']       = $myuid['uid'];
            $data['jobs_id']        = $ids;
            $data['jobs_name']       = $jobsinfo['jobs_name'];
            $data['company_id']       = $jobsinfo['company_id'];
            $data['company_name']       = $jobsinfo['companyname'];
            $data['company_uid']       = $jobsinfo['uid'];
            $data['addtime']     = time();
            Db::name('zimu_zhaopin_personal_favorites')->insert($data);
            $res['tip'] = $language_zimu['new_viewjob_inc_php_1'];
        }

        zimu_json($res);

    }elseif($op == 'toapply' ){

        $myuid = checktoken($token);
        $resume_info = Db::name('zimu_zhaopin_resume')->where([['uid','=',$myuid['uid']]])->find();

        $isapply = Db::name('zimu_zhaopin_personal_jobs_apply')->where([['personal_uid','=',$myuid['uid']],['jobs_id','=',$ids]])->find();

        if($isapply){
            $res['type'] = 'tip';
            $res['tip'] = $language_zimu['new_viewjob_inc_php_2'];
            zimu_json($res);
        }

        if(!$resume_info){
            $res['type'] = 'noresume';
            $res['tip'] = $language_zimu['new_viewjob_inc_php_3'];
            zimu_json($res);
        }

        if($resume_info['display']==2){
            $res['type'] = 'tip';
            $res['tip'] = $language_zimu['new_viewjob_inc_php_4'];
            zimu_json($res);
        }

        if($resume_info['audit']==3){
            $res['type'] = 'error';
            $res['tip'] = $language_zimu['new_viewjob_inc_php_5'].'<br>'.$resume_info['wxtpl'].'<br>'.$language_zimu['new_viewjob_inc_php_6'].'<img style="width:200px;" src="'.$zmdata['settings']['kefu_qrcode_url'].'"><p style="color:#ff552e;font-size:15px;">'.$language_zimu['new_viewjob_inc_php_7'].'</p>';
            zimu_json($res);
        }

        if($zmdata['settings']['resume_tocomtel'] && $resume_info && $resume_info['audit'] !=1 ){
            $res['type'] = 'error';
            $res['tip'] = $language_zimu['new_viewjob_inc_php_8'].'<br>'.$language_zimu['new_viewjob_inc_php_9'].'<br><img style="width:200px;" src="'.$zmdata['settings']['kefu_qrcode_url'].'"><p style="color:#ff552e;font-size:15px;">'.$language_zimu['new_viewjob_inc_php_10'].'</p>';
            zimu_json($res);
        }

        $today_total = Db::name('zimu_zhaopin_personal_jobs_apply')->where([['personal_uid','=',$myuid['uid']],['apply_addtime','>',strtotime(date('Y-m-d', time()))]])->count();

        if($zmdata['settings']['max_apply_jobs'] && $today_total >= $zmdata['settings']['max_apply_jobs']){
            $res['type'] = 'tip';
            $res['tip'] = $language_zimu['new_viewjob_inc_php_11'].$zmdata['settings']['max_apply_jobs'].$language_zimu['new_viewjob_inc_php_12'];
            zimu_json($res);
        }

        $job = Db::name('zimu_zhaopin_jobs')->where([['id','=',$ids]])->find();
        if($job['resume_complete_percent']){
            $zmdata['settings']['resume_complete_percent'] = $job['resume_complete_percent'];
        }
        if($resume_info['complete_percent'] < intval($zmdata['settings']['resume_complete_percent'])){
            $res['type'] = 'complete_percent';
            $res['tip'] = $language_zimu['new_viewjob_inc_php_13'];
            zimu_json($res);
        }

        $data['resume_id']       = $resume_info['id'];
        $data['resume_name']        = $resume_info['title'];
        $data['personal_uid']     = $myuid['uid'];
        $data['jobs_id']       = $ids;
        $data['jobs_name']       = addslashes(zm_diconv($_GET['jobs_name']));
        $data['company_id']       = intval($_GET['company_id']);
        $data['company_name']       = addslashes(zm_diconv($_GET['company_name']));
        $data['company_uid']       = intval($_GET['company_uid']);
        $data['apply_addtime']       = time();
        $data['notes']       = '';
        $data['is_apply']       = 2;
        Db::name('zimu_zhaopin_personal_jobs_apply')->insert($data);

        Db::name('zimu_zhaopin_resume')->where([['uid','=',$myuid['uid']]])->data(['refreshtime' => time()])->update();

        $company_profile = Db::name('zimu_zhaopin_company_profile')->where([['id','=',$data['company_id']]])->find();
        $tip = $resume_info['fullname'].$language_zimu['new_viewjob_inc_php_14'];
        notification_user_sms($company_profile['telephone'],'chanyoo_sms_tp1','tip',$tip);

        $tip = $language_zimu['new_viewjob_inc_php_15'].$data['jobs_name'].$language_zimu['new_viewjob_inc_php_16'];
        $templatedata['first']['value'] = $tip;
        $templatedata['first']['color'] = "#FF4040";
        $templatedata['keyword1']['value'] = $resume_info['fullname'];
        $templatedata['keyword2']['value'] = $resume_info['education_cn'];
        $templatedata['keyword3']['value'] = $resume_info['experience_cn'];
        $templatedata['keyword4']['value'] = $resume_info['district_cn'];
        $templatedata['keyword5']['value'] = $resume_info['wage_cn'];
        $templatedata['remark']['value'] = $language_zimu['new_viewjob_inc_php_17'];
        $apptpl['magapp']['tag'] = $tip;
        $apptpl['magapp']['title'] = $resume_info['fullname'].$resume_info['education_cn'].$resume_info['experience_cn'].$resume_info['wage_cn'];
        $apptpl['magapp']['des'] = $language_zimu['new_viewjob_inc_php_18'];
        $apptpl['qfapp']['msg'] = $apptpl['magapp']['tag'];
        $apptpl['qfapp']['title'] = $apptpl['magapp']['title'];
        $apptpl['qfapp']['content'] = $apptpl['magapp']['des'];
        $tourl = $_G['siteurl'].'source/plugin/zimu_zhaopin/h5/pages/resume/view?ids='.$resume_info['id'];
        $link = $_G['siteurl'].'plugin.php?id=zimu_zhaopin:new&model=newindex&tourl='.urlencode($tourl);
        notification_all($company_profile['uid'],'wxtpl_jobs_apply',$templatedata,$apptpl,$link);

        if($job['contact'] && $job['telephone']){
            $company_profile['telephone'] = $job['telephone'];
        }
        $res['type'] = 'success';
        $res['telephone'] = $company_profile['telephone'];
        zimu_json($res);

    }elseif($op == 'toreport' ){

        $myuid = checktoken($token);
        $report_type = intval($_GET['report_type']);;
        $content = addslashes(zm_diconv($_GET['content']));
        $telephone = addslashes($_GET['telephone']);
        $data['uid'] = $myuid['uid'];
        $data['username'] = '';
        $data['jobs_id'] = $ids;
        $data['report_type'] = $report_type;
        $data['telephone'] = $telephone;
        $data['content'] = $content;
        $data['type'] = 1;
        $data['addtime'] = time();
        Db::name('zimu_zhaopin_report')->insert($data);

        zimu_json($res);

    }elseif($op == 'quick_audit' ){

        $audit = intval($_GET['audit']);
        $reason = zimu_array_gbk($_GET['reason']);
        $auditinfo = Db::name('zimu_zhaopin_jobs_audit')->where([['ids','=',$ids]])->find();
        if($auditinfo && $audit==1){
            $auditinfo['audit'] = $audit;
            $auditinfo['wxtpl'] = $reason;
            unset($auditinfo['id']);
            unset($auditinfo['ids']);
            Db::name('zimu_zhaopin_jobs')->where('id', $ids)->data($auditinfo)->update();
        }else{
            Db::name('zimu_zhaopin_jobs')->where('id', $ids)->data(['company_audit' => $audit,'audit' => $audit,'wxtpl' => $reason])->update();
        }
        Db::name('zimu_zhaopin_jobs_audit')->where('ids', $ids)->delete();
        jobs_push($ids,$audit,$reason);

        zimu_json($res);

    }elseif($op == 'haibao' ){

        $ids = intval($_GET['ids']);
        $qrsize = 5;
        $dir = DISCUZ_ROOT.'/source/plugin/zimu_zhaopin/uploadzimucms/';
        $xcx_tip = $client_type == 'xcx' ? 'xcx_' : 'h5_';
        if($zmdata['settings']['wx_create_qrcode'] == 1){
            $client_type = 'wechat_';
        }
        $qrcode_file = $dir.'qrcode/jobs_'.$client_type.$ids.'.jpg';
        $qrcode_url = $_G['siteurl'].'source/plugin/zimu_zhaopin/h5/pages/jobs/view?ids='.$ids.'&mobile=2';

        if(!file_exists(DISCUZ_ROOT . 'source/plugin/zimu_zhaopin/static/font/Alibaba-PuHuiTi-Heavy.ttf') || !file_exists(DISCUZ_ROOT . 'source/plugin/zimu_zhaopin/static/font/Alibaba-PuHuiTi-Regular.ttf')){
            zimu_json($res,$language_zimu['new_viewjob_inc_php_19'],202);
        }


        if(!file_exists($dir.'qrcode/jobs_xcx_'.$ids.'.jpg') || !filesize($dir.'qrcode/jobs_xcx_'.$ids.'.jpg') || filemtime($dir.'qrcode/jobs_xcx_'.$ids.'.jpg') < time() - 2590000 ) {
            if($zmdata['settings']['xcx_appid']){
                require_once DISCUZ_ROOT . './source/plugin/zimu_zhaopin/class/wechat.lib.class.php';
                $wechat_client_xcx = new WeChatClient($zmdata['settings']['xcx_appid'], $zmdata['settings']['xcx_appsecret']);
                $token         = $wechat_client_xcx->getAccessToken(1);
                $postdata = array(
                    'scene' => "type=viewjob&ids=".$ids,
                    'page' => 'pages/jobs/view',
                    'auto_color' => true
                );
                $qrcodedata = lizimu_post('https://api.weixin.qq.com/wxa/getwxacodeunlimit?access_token='.$token,json_encode($postdata));
                $fp = fopen($dir.'qrcode/jobs_xcx_'.$ids.'.jpg', 'wb');
                flock($fp, 2);
                fwrite($fp,$qrcodedata);
                fclose($fp);
            }
        }

        if(!file_exists($dir.'qrcode/jobs_wechat_'.$ids.'.jpg') || !filesize($dir.'qrcode/jobs_wechat_'.$ids.'.jpg') || filemtime($dir.'qrcode/jobs_wechat_'.$ids.'.jpg') < time() - 2590000 ) {
            if ($zmdata['settings']['wx_create_qrcode'] == 1) {
                require_once DISCUZ_ROOT . './source/plugin/zimu_zhaopin/class/wechat.lib.class.php';
                $wechat_client = new WeChatClient($zmdata['base']['weixin_appid'], $zmdata['base']['weixin_appsecret']);
                $qrcode_url2 = $wechat_client->getQrcodeImgUrlByTicket($wechat_client->getQrcodeTicket(array(
                    'scene_str' =>  'viewjob2zimuyun' . $ids,
                    'expire' => 2591000
                )));
                $qrcode_img = dfsockopen($qrcode_url2);
                $qrcode_img = $qrcode_img ? $qrcode_img : file_get_contents($qrcode_url2);
                $fp = fopen($dir.'qrcode/jobs_wechat_'.$ids.'.jpg', 'wb');
                flock($fp, 2);
                fwrite($fp,$qrcode_img);
                fclose($fp);
            }
        }

        if(!file_exists($dir.'qrcode/jobs_h5_'.$ids.'.jpg') || !filesize($dir.'qrcode/jobs_h5_'.$ids.'.jpg')) {
            require_once DISCUZ_ROOT.'source/plugin/zimu_zhaopin/class/qrcode.class.php';
            QRcode::png($qrcode_url, $dir.'qrcode/jobs_h5_'.$ids.'.jpg', QR_ECLEVEL_L, $qrsize);
        }


        require_once DISCUZ_ROOT.'source/plugin/zimu_zhaopin/class/poster_laofu110.php';

        $jobdata = Db::name('zimu_zhaopin_jobs')->where([['id','=',$ids]])->find();

        if ($jobdata['nature']==63 && $jobdata['parttime_money']) {
            if($jobdata['parttime_type']==1){
                $jobdata['wage_cn'] = $jobdata['parttime_money'].$zmdata['settings']['money_name'].'/'.$language_zimu['new_viewjob_inc_php_20'];
            }
            if($jobdata['parttime_type']==2){
                $jobdata['wage_cn'] = $jobdata['parttime_money'].$zmdata['settings']['money_name'].'/'.$language_zimu['new_viewjob_inc_php_21'];
            }
            if($jobdata['parttime_type']==0){
                $jobdata['wage_cn'] = $jobdata['parttime_money'].$zmdata['settings']['money_name'].'/'.$language_zimu['new_viewjob_inc_php_22'];
            }
            if($jobdata['parttime_type']==3){
                $jobdata['wage_cn'] = $jobdata['parttime_money'].$zmdata['settings']['money_name'].'/'.$language_zimu['new_viewjob_inc_php_23'];
            }
        }elseif ($jobdata['nature']==63){
            $jobdata['wage_cn'] = $language_zimu['new_viewjob_inc_php_24'];
        }


        $companydata = Db::name('zimu_zhaopin_company_profile')->where([['id','=',$jobdata['company_id']]])->find();
        $myinfo['qrcode_url'] = $_G['siteurl'].'source/plugin/zimu_zhaopin/uploadzimucms/qrcode/jobs_'.$xcx_tip.$ids.'.jpg';

        $haibaoid = intval($_GET['haibaoid']);

        if(!$haibaoid){
            $new_diyposter = Db::name('zimu_zhaopin_diyposter')->orderRaw('rand()')->find();
        }else{
            $new_diyposter = Db::name('zimu_zhaopin_diyposter')->where([['id','>',$haibaoid]])->order(['id'=>'asc'])->find();
        }
        if(!$new_diyposter){
            $new_diyposter = Db::name('zimu_zhaopin_diyposter')->order(['id'=>'asc'])->find();
        }
        if(file_exists($dir.'haibao/jobs_'.$xcx_tip.$ids.'_'.$new_diyposter['id'].'.png') && filesize($dir.'haibao/jobs_'.$xcx_tip.$ids.'_'.$new_diyposter['id'].'.png') && filemtime($dir.'haibao/jobs_'.$xcx_tip.$ids.'_'.$new_diyposter['id'].'.png') > time() - 3600 ) {
            $res['hbimg'] = $_G['siteurl'].'/source/plugin/zimu_zhaopin/uploadzimucms/haibao/jobs_'.$xcx_tip.$ids.'_'.$new_diyposter['id'].'.png';
            $res['haibaoid'] = $new_diyposter['id'];
            zimu_json($res);
        }

        if($new_diyposter){
            $diyposter['bg'] = $new_diyposter['imgurl'];
            $hbimg = $_G['siteurl'].'/source/plugin/zimu_zhaopin/uploadzimucms/haibao/jobs_'.$xcx_tip.$ids.'_'.$new_diyposter['id'].'.png';
            $hbpath = DISCUZ_ROOT . '/source/plugin/zimu_zhaopin/uploadzimucms/haibao/jobs_'.$xcx_tip.$ids.'_'.$new_diyposter['id'].'.png';
            $backgroundInfo = getimagesize($new_diyposter['imgurl']);
            $percent = $backgroundInfo[0]/750 ? $backgroundInfo[0]/750 : 1;

            $diyposter2 = explode(PHP_EOL, trim($new_diyposter['data']));
            foreach ($diyposter2 as $key => $v) {
                $diyposter2[$key] = explode('|', $v);
            }

            foreach ($diyposter2 as $key => $value) {

                if($value[0]=='text'){
                    $value[1] = str_replace('jobs_name',$jobdata['jobs_name'],$value[1]);
                    $value[1] = str_replace('jobs_wage',$jobdata['wage_cn'],$value[1]);
                    $value[1] = str_replace('jobs_tag',$jobdata['tag_cn'],$value[1]);
                    $value[1] = str_replace('com_name',$companydata['companyname'],$value[1]);
                    $value[1] = str_replace('jobs_address',$companydata['address'],$value[1]);
                    $value[1] = str_replace('district_cn',$jobdata['district_cn'],$value[1]);
                    $value[1] = str_replace('experience_cn',$jobdata['experience_cn'],$value[1]);
                    $value[1] = str_replace('education_cn',$jobdata['education_cn'],$value[1]);
                    $config_text[] = array(
                        'text' => zimu_array_utf8($value[1]),
                        'left' => $value[5]*$percent,
                        'top' => $value[4]*$percent,
                        'width' => 750*$percent,
                        'fontSize' => intval($value[2])*$percent,
                        'fontPath' => $value[6],
                        'fontColor' => implode(',',hex2rgb($value[3])),
                        'angle' => 0
                    );
                }
                if($value[0]=='img'){
                    $value[1] = str_replace('com_logo',$companydata['logo'],$value[1]);
                    if($value[1]=='qr_xcx'){
                        $value[1] = str_replace('qr_xcx',$dir.'qrcode/jobs_xcx_'.$ids.'.jpg',$value[1]);
                    }
                    if($value[1]=='qr_wechat'){
                        $value[1] = str_replace('qr_wechat',$dir.'qrcode/jobs_wechat_'.$ids.'.jpg',$value[1]);
                    }
                    if($value[1]=='qr_h5'){
                        $value[1] = str_replace('qr_h5',$dir.'qrcode/jobs_h5_'.$ids.'.jpg',$value[1]);
                    }

                    $config_image[] = array(
                        'url' => $value[1],
                        'left' => intval($value[5])*$percent,
                        'top' => intval($value[4])*$percent,
                        'width' => intval($value[2])*$percent,
                        'height' => intval($value[3])*$percent,
                        'radius' => intval($value[6]),
                        'opacity' => 100,
                    );
                }
            }

        }else{

            $hbimg = $_G['siteurl'].'/source/plugin/zimu_zhaopin/uploadzimucms/haibao/jobs_'.$xcx_tip.$ids.'.png';
            $hbpath = DISCUZ_ROOT . '/source/plugin/zimu_zhaopin/uploadzimucms/haibao/jobs_'.$xcx_tip.$ids.'.png';
            $paramter = Db::name('zimu_zhaopin_parameter2')->where('name','diyposter')->order(['id'=>'asc'])->find();
            $diyposter = unserialize($paramter['parameter']);
            $backgroundInfo = getimagesize($diyposter['bg']);
            $percent = $backgroundInfo[0]/450 ? $backgroundInfo[0]/450 : 1;

            foreach ($diyposter['data'] as $key => $value) {

                if( ($value['type']=='jobs_name' || $value['type']=='jobs_wage' || $value['type']=='jobs_tag' || $value['type']=='com_name' || $value['type']=='jobs_address' || $value['type']=='text') && $value['words']){
                    $fontColor = hex2rgb($value['color']);
                    if($value['type']=='jobs_name'){
                        $value['words'] = $jobdata['jobs_name'];
                    }
                    if($value['type']=='jobs_wage'){
                        $value['words'] = $jobdata['wage_cn'];
                    }
                    if($value['type']=='jobs_tag'){
                        $value['words'] = $jobdata['tag_cn'];
                    }
                    if($value['type']=='com_name'){
                        $value['words'] = $companydata['companyname'];
                    }
                    if($value['type']=='jobs_address'){
                        $value['words'] = $companydata['address'];
                    }
                    $config_text[] = array(
                        'text' => zimu_array_utf8($value['words']),
                        'left' => intval($value['left'])*$percent,
                        'align' => $value['align'],
                        'top' => (intval($value['top'])+(intval($value['height'])/2))*$percent,
                        'width' => intval($value['width'])*$percent,
                        'fontSize' => intval($value['size'])*$percent,
                        'fontColor' => $fontColor['r'].','.$fontColor['g'].','.$fontColor['b'],
                        'angle' => 0
                    );
                }

                if($value['type']=='com_logo' || $value['type']=='qr' || $value['type']=='img'){
                    if($value['type']=='com_logo'){
                        $value['src'] = $companydata['logo'];
                    }
                    if($value['type']=='qr'){
                        $value['src'] = $qrcode_file;
                    }
                    if($value['src']){
                        $config_image[] = array(
                            'url' => $value['src'],
                            'left' => intval($value['left'])*$percent,
                            'top' => intval($value['top'])*$percent,
                            'width' => intval($value['width'])*$percent,
                            'height' => intval($value['height'])*$percent,
                            'radius' => $value['border']=='radius' ? 30 : ($value['border']=='circle' ? intval($value['width'])*$percent/2 : 0),
                            'opacity' => 100,
                        );
                    }
                }
            }

        }

        $config = array(
            'bg' => $diyposter['bg'],
            'format'=>'jpg',
            'quality'=>88,
            'text' => $config_text,
            'image' => $config_image,
        );
        $Poster=new \Laofu\Image\Poster($config);
        $img=$Poster->make($hbpath);
        if(!$img){
            $err=$Poster->errMsg;
        }
        $res['hbimg'] = $hbimg;
        $res['haibaoid'] = intval($new_diyposter['id']);
        zimu_json($res);

    }else{

        $job = Db::name('zimu_zhaopin_jobs')->where([['id','=',$ids]])->select()->toArray();
        $job1 = $job[0];
        if(!$job1){
            $res['type'] = 'nojob';
            $res['tip'] = $language_zimu['new_viewjob_inc_php_25'];
            zimu_json($res);
        }

        $job = format_jobs($job,$zmdata);
        $res['job'] = $job[0];

        $res['job']['applynums'] = Db::name('zimu_zhaopin_personal_jobs_apply')->where([['jobs_id','=',$res['job']['id']]])->count();

        if($myuid['uid']>0){
            $res['job']['hasfav'] = Db::name('zimu_zhaopin_personal_favorites')->where([['jobs_id','=',$res['job']['id']],['personal_uid','=',$myuid['uid']]])->count();
            $res['job']['isresume'] = Db::name('zimu_zhaopin_personal_jobs_apply')->where([['jobs_id','=',$res['job']['id']],['personal_uid','=',$myuid['uid']]])->count();
        }

        if($zmdata['settings']['always_show_mobile']==1){
            $res['job']['isresume'] = 'always_show_mobile';
        }

        $res['company'] = $company1 = Db::name('zimu_zhaopin_company_profile')->where([['id','=',$res['job']['company_id']]])->find();
        $res['company']['logo'] = $res['company']['logo'] ? $res['company']['logo'] : ZIMUCMS_PATH.'static/pc/images/company_nologo.jpg';
        $res['company']['environment'] = explode(',',$res['company']['environment']);

        if($job1['contact'] && $job1['telephone']){
            $res['company']['contact'] = $job1['contact'];
            $res['company']['telephone'] = $job1['telephone'];
        }

        $manage_uids = str_replace(';', ',', $zmdata['manage_uids']);
        $manage_uids = explode(',', $manage_uids);
        if($myuid['uid'] && (in_array($myuid['uid'],$manage_uids) || $myuid['uid']==$res['company']['kefu_uid'])){
            $res['company']['isadmin'] = 1;
        }

        if(($job1['audit']==3 || $job1['display']==2) && $res['company']['isadmin'] != 1){
            $res['type'] = 'noshowjob';
            $res['tip'] = $language_zimu['new_viewjob_inc_php_26'];
            zimu_json($res);
        }

        if($res['job']['job_tel_apply']){
            $res['job']['job_tel_apply'] = $res['job']['job_tel_apply'] == 3 ? 0 : $res['job']['job_tel_apply'];
        }else{
            $res['job']['job_tel_apply'] = $zmdata['settings']['job_tel_apply'];
        }
        if($res['job']['job_tel_apply']==1){
            $res['job']['isresume'] = 1;
        }

        if(!$res['job']['isresume'] && $res['company']['isadmin'] != 1){
            $res['company']['telephone'] = substr_replace($res['company']['telephone'], '****', 3, 4);
        }
        if($res['company']['isadmin'] == 1){
            $res['job']['isresume'] = 1;
        }

        $companyjob = Db::name('zimu_zhaopin_jobs')->where([['audit','<>',3],['display','<>',2],['company_id','=',$res['job']['company_id']],['id','<>',$ids]])->order(['refreshtime'=>'desc','id'=>'desc'])->select()->toArray();
        $res['companyjob'] = format_jobs($companyjob,$zmdata);

        $randjob = Db::name('zimu_zhaopin_jobs')->where([['audit','<>',3],['display','<>',2],['topclass','=',$res['job']['topclass']]])->orderRaw('rand()')->limit(10)->select()->toArray();
        $res['randjob'] = format_jobs($randjob,$zmdata);

        $res['jubao_tip'] = $zmdata['settings']['jubao_tip'];
        $res['wapfooter'] = $zmdata['settings']['wapfooterhtml'];

        $audit_tip1 = explode(PHP_EOL, trim($zmdata['settings']['audit_tip1']));
        $audit_tip2 = explode(PHP_EOL, trim($zmdata['settings']['audit_tip2']));

        foreach ($audit_tip1 as $key => $value) {
            $res['audit_tip1'][$key]['text'] = $value;
        }
        foreach ($audit_tip2 as $key => $value) {
            $res['audit_tip2'][$key]['text'] = $value;
        }

        if($myuid['uid']){
            $is_viewlog = Db::name('zimu_zhaopin_per_viewlog')->where([['uid','=',$myuid['uid']],['jid','=',$ids]])->find();
            if ($is_viewlog) {
                Db::name('zimu_zhaopin_per_viewlog')->where('id', $is_viewlog['id'])->data(['addtime' => time()])->update();
            } else {
                $per_viewlog['uid']     = $myuid['uid'];
                $per_viewlog['jid']     = $ids;
                $per_viewlog['jobname'] = $res['job']['jobs_name'];
                $per_viewlog['cid']     = $res['job']['company_id'];
                $per_viewlog['comname'] = $res['job']['companyname'];
                $per_viewlog['addtime'] = time();
                Db::name('zimu_zhaopin_per_viewlog')->insert($per_viewlog);
            }
        }


        if($_SERVER['REQUEST_METHOD'] != 'OPTIONS'){
            Db::name('zimu_zhaopin_jobs')->where('id', $ids)->inc('click', 1)->update();
        }

        $paramter = Db::name('zimu_zhaopin_parameter2')->where([['name','=','wappopup']])->order(['id'=>'asc'])->find();
        $res['wappopup'] = unserialize($paramter['parameter']);
        $res['sitename'] = $zmdata['base']['title'];
        $res['zmdata']['job_show_views'] = $zmdata['settings']['job_show_views'];
        $res['zmdata']['job_show_apply'] = $zmdata['settings']['job_show_apply'];
        $res['zmdata']['randad'] = zimu_ad_system2('zhaopin5');
        $res['zmdata']['randad2'] = zimu_ad_system2('zhaopin8');
        $res['zmdata']['open_sixin'] = $zmdata['settings']['open_sixin'];
        $res['zmdata']['app_url'] = $zmdata['settings']['app_url'];
        $res['zmdata']['show_noaudit'] = intval($zmdata['settings']['show_noaudit']);
        $res['zmdata']['diyposter'] = 1;
        $res['zmdata']['toutiao_audit'] = $zmdata['settings']['toutiao_audit'];
        if(file_exists(DISCUZ_ROOT . './source/plugin/zimu_zhaopin/module/adminss/adminss_imconfig.inc.php')){
            $imchat_parameter = Db::name('zimu_zhaopin_parameter2')->where('name', 'imchat')->order('id','desc')->find();
            $imchat_parameter = unserialize($imchat_parameter['parameter']);
            if($imchat_parameter['open_im']){
                $res['zmdata']['open_sixin'] = 1;
                $res['zmdata']['open_im'] = 1;
                if($myuid['uid']){
                    $res['zmdata']['myuid'] = $myuid;
                }
            }
        }
        if($myuid['utype']==1){
            $res['zmdata']['open_sixin'] = 0;
        }

        if($zmdata['settings']['job_copytext']){

            if($zmdata['settings']['open_newwap']==1){
                $tourl = zp_url_replace('viewjob','jid',$ids);
            }else{
                $tourl = $_G['siteurl'].'source/plugin/zimu_zhaopin/h5/pages/jobs/view?ids='.$ids;
            }

            $res['zmdata']['job_copytext'] = preg_replace(array(
                '/jobs_name/',
                '/wage_cn/',
                '/amount/',
                '/experience_cn/',
                '/education_cn/',
                '/sex_cn/',
                '/district_cn/',
                '/companyname/',
                '/tag_cn/',
                '/contents/',
                '/tourl/'
            ), array(
                $job[0]['jobs_name'],
                $job[0]['wage_cn'],
                $job[0]['amount'],
                $job[0]['experience_cn'],
                $job[0]['education_cn'],
                $job[0]['sex_cn'],
                '['.$job[0]['district_cn'].']'.$res['company']['address'],
                $job[0]['companyname'],
                $job[0]['tag_cn'],
                $job[0]['contents'],
                $tourl
            ), $zmdata['settings']['job_copytext']);

        }

        if($res['job']['uid'] == $myuid['uid'] || $res['company']['isadmin']==1){
            $auditinfo = Db::name('zimu_zhaopin_jobs_audit')->where('ids', $res['job']['id'])->find();
            if($auditinfo){
                unset($auditinfo['id']);
                if($res['job']['uid'] == $myuid['uid'] && $res['company']['isadmin']!=1){
                    $res['job'] = array_merge($res['job'],$auditinfo);
                }
                $oldinfo = $job1;
                $diff_info = array_merge($oldinfo,$auditinfo);
                $diff_info2 = array_diff_assoc($diff_info,$oldinfo);
                $res['job']['diff_info'] = $diff_info2;
            }
        }

        zimu_json($res);

    }
