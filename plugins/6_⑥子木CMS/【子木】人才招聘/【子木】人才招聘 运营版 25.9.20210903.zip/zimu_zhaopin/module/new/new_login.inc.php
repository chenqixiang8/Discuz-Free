<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if (!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }

    use think\Db;
    $op = addslashes($_GET['op']);

    if($op=='tokenlogin'){

        $token = addslashes($_GET['token']);
        $myuid = checktoken($token);
        $res['myinfo'] = $myuid;
        if($zmdata['settings']['h5_isapp']>0 && !$res['myinfo']['telephone']){
            $res['myinfo']['telephone'] = tongbu_h5_mobile($myuid,$zmdata);
        }
        $res['myinfo']['sitename'] = $zmdata['base']['title'];
        $res['myinfo']['sitelogo'] = $zmdata['base']['share_thumb'];
        $res['myinfo']['bind_mobile'] = $zmdata['settings']['bind_mobile'];


    }elseif($op == 'updatemyphone2' ){

        $token = addslashes($_GET['token']);
        $myuid = checktoken($token);

        $mobile = intval($_GET['mobile']);
        $code = addslashes($_GET['code']);

        $isreal = Db::name('zimu_zhaopin_members')->where([['uid','=',$myuid['uid']],['verify_code','=',$code]])->order('id', 'desc')->find();
        if(!$mobile || !$isreal){
            zimu_json('',$language_zimu['new_login_inc_php_0'],1);
        }

        Db::name('zimu_zhaopin_members')->where('uid', $myuid['uid'])->data(['telephone' => $mobile])->update();

        $res['myinfo'] = $myuid;
        $res['myinfo']['telephone'] = $mobile;

        if($zmdata['settings']['h5_isapp'] == 1 && $mobile){
            $isreg = Db::name('user_mobile_relations')->where([['phone','=',$mobile],['userid','>',0]])->find();
            if(!$isreg){
                $appdata = array(
                    'userid' => $myuid['uid'],
                    'phone' => $mobile,
                    'create_time' => time()
                );
                Db::name('user_mobile_relations')->insert($appdata);
            }
        }
        if($zmdata['settings']['h5_isapp'] == 2 && $mobile){
            $isreg = Db::name('phonebind')->where([['phone','=',$mobile],['uid','>',0]])->find();
            if(!$isreg){
                $appdata = array(
                    'uid' => $myuid['uid'],
                    'phone' => $mobile,
                    'dateline' => time()
                );
                Db::name('phonebind')->insert($appdata);
            }
        }
        if($zmdata['settings']['h5_isapp'] == 3 && $mobile){
            $isreg = Db::name('appbyme_sendsms')->where([['mobile','=',$mobile],['uid','>',0]])->find();
            if(!$isreg){
                $appdata = array(
                    'uid' => $myuid['uid'],
                    'code' => 'jishi',
                    'mobile' => $mobile,
                    'time' => time()
                );
                Db::name('appbyme_sendsms')->insert($appdata);
            }
        }
        zimu_json($res);


    }else{
        $res['sitename'] = $zmdata['base']['title'];
        $res['sitelogo'] = $zmdata['base']['share_thumb'];
        $res['zmdata']['toutiao_phone'] = $zmdata['settings']['toutiao_phone'] ? $zmdata['settings']['toutiao_phone'] : 0;
    }

    zimu_json($res);