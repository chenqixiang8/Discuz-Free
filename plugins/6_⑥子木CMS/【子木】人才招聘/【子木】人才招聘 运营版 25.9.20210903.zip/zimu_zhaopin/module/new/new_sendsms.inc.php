<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if (!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }

    use think\Db;

    $token = addslashes($_GET['token']);
    $myuid = checktoken($token);

    $mobile = strip_tags($_GET['mobile']) ? strip_tags($_GET['mobile']) : $_REQUEST['mobile'];

    if(getcookie('zhaopin_verify_mobile_time') && (time()-getcookie('zhaopin_verify_mobile_time'))<60){
        zimu_json('',$language_zimu['new_sendsms_inc_php_0'].'60'.$language_zimu['new_sendsms_inc_php_1'],1);
    }

    $rand = mt_rand(1000, 9999);

    $sms_paramter = Db::name('zimu_zhaopin_parameter2')->where('name', 'aliyunsms')->find();

    $sms_paramter = unserialize($sms_paramter['parameter']);

        $app_key = $sms_paramter['smsAppKey'];
        $app_secret = $sms_paramter['smssecretKey'];
        $sign_name = mb_convert_encoding($sms_paramter['smsFreeSignName'],'UTF-8',CHARSET);
        $smsdata['code'] = $rand;

        $requestUrl = "http://dysmsapi.aliyuncs.com/";
        $params['PhoneNumbers']= $mobile;
        $params['SignName']= $sign_name;
        $params['TemplateCode']= $sms_paramter['smsTemplateCode'];
        $params['TemplateParam']= json_encode($smsdata);
        $params['OutId']= "3333";
        $params['RegionId']= "cn-hangzhou";
        $params['AccessKeyId']= $app_key;
        $params['Format']= "JSON";
        $params['SignatureMethod']= "HMAC-SHA1";
        $params['SignatureVersion']= "1.0";
        $params['SignatureNonce']= uniqid();
        date_default_timezone_set("GMT");
        $params['Timestamp']= date("Y-m-d\TH:i:s\Z");
        $params['Action']= "SendSms";
        $params['Version']= "2017-05-25";
        $params['Signature']= aliyun_signature($params,$app_secret);

        include_once DISCUZ_ROOT . './source/plugin/zimu_zhaopin/class/Aliyun_HttpHelper.class.php';

        $Aliyun_HttpHelper = new Aliyun_HttpHelper();
        $result = $Aliyun_HttpHelper->curl($requestUrl,'POST',$params,array('x-sdk-client' => 'php/2.0.0'));

        $aaa = json_decode($result,true);

        if ($aaa['alibaba_aliqin_fc_sms_num_send_response']['result']['success'] == 1 || $aaa['success'] == 1 || $aaa['Code'] == 'OK') {

            Db::name('zimu_zhaopin_members')->where([['uid','=',$myuid['uid']]])->data(['verify_code' => $rand])->update();

            dsetcookie('zhaopin_verify_mobile_time',time(),7200);

            $sendsmslog = ['uid' => $myuid['uid'],'mobile' => $mobile,'con' => $language_zimu['new_sendsms_inc_php_2'].$rand,'type' => 'code','addtime' => time()];
            Db::name('zimu_zhaopin_sendsmslog')->insert($sendsmslog);

            zimu_json($res);
        }else{
            zimu_json('',mb_convert_encoding($aaa['Message'], CHARSET, 'UTF-8'),1);
        }

    function aliyun_signature($params,$AccessKeySecret){
        ksort($params);

        $canonicalizedQueryString = '';
        foreach($params as $key => $value){
            $canonicalizedQueryString .= '&' . percentEncode($key). '=' . percentEncode($value);
        }

        $stringToSign = 'POST&%2F&' . percentEncode(substr($canonicalizedQueryString, 1));

        $signature = base64_encode(hash_hmac('sha1', $stringToSign, $AccessKeySecret."&", true));
        return $signature;
    }

    function percentEncode($str){
        $res = urlencode($str);
        $res = preg_replace('/\+/', '%20', $res);
        $res = preg_replace('/\*/', '%2A', $res);
        $res = preg_replace('/%7E/', '~', $res);
        return $res;
    }