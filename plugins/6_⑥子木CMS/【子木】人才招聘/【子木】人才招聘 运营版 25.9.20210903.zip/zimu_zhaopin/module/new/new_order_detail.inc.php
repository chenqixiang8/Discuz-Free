<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if (!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }

    use think\Db;

    $oldtoken = $_GET['token'];
    $token = addslashes($_GET['token']);
    $myuid = checktoken($token);
    $op = addslashes($_GET['op']);
    $zimu_get = zimu_array_gbk($_GET);

    $ids = intval($_GET['ids']);
    $toreferer = addslashes($_GET['toreferer']);
    $order = Db::name('zimu_zhaopin_order')->where('id', $ids)->find();

    if(strpos($toreferer,'pub') !== false || strpos($toreferer,'pub2') !== false){
        $toreferer = $_G['siteurl'].'source/plugin/zimu_zhaopin/h5/?mobile=2';
    }

    if(!$order['openid']){
        Db::name('zimu_zhaopin_order')->where('id', $order['id'])->data(['openid' => $myuid['openid']])->update();
        $order['openid'] = $myuid['openid'];
    }

    if($toreferer){
        Db::name('zimu_zhaopin_order')->where('id', $ids)->update(['referer' => $toreferer]);
        $order['referer'] = $toreferer;
    }

    $qf_paramter = Db::name('zimu_zhaopin_parameter2')->where('name', 'qfapp')->find();
    $qf_paramter = unserialize($qf_paramter['parameter']);

    $order['qf_type'] = intval($qf_paramter['qf_type']);

    /*
    if($myuid['uid'] != $_G['uid'] && $_G['uid'] > 0){
        $olduid = Db::name('zimu_zhaopin_members')->where('uid', $_G['uid'])->find();
        if(strlen($olduid['openid']) < 10 || strlen($olduid['openid']) > 50){
            $olduid['openid'] = '';
            Db::name('zimu_zhaopin_members')->where('uid', $_G['uid'])->data(['openid' => ''])->update();
        }
        $order['openid'] = $olduid['openid'];
    }elseif($myuid['uid'] > 0 && $_G['uid'] == 0){
        $order['openid'] = '';
    }else{
        $order['openid'] = $myuid['openid'];
    }
    */

    if(strlen($order['openid']) < 10 || strlen($order['openid']) > 50){
        $order['openid'] = '';
    }

    if($order['service_name'] != 'buy_points' && $order['pay_amount'] && $zmdata['settings']['money_appcode'] && $zmdata['settings']['money_currency']){
        $tomoney = get_money_currency($zmdata['settings']['money_appcode'],$order['pay_amount'],$zmdata['settings']['money_currency']);
        $tomoney = json_decode($tomoney,true);
        if($tomoney['msg']=='ok' && $tomoney['result']['rate']){
            $order['money_currency'] = $zmdata['settings']['money_currency'];
            $order['money_name'] = $zmdata['settings']['money_name'];
            $order['money_rate'] = $tomoney['result']['rate'];
            $order['money_updatetime'] = $tomoney['result']['updatetime'];
            $order['pay_amount'] = round($tomoney['result']['camount'],2);
        }
    }

    $order['mymoney'] = $myuid['points'];
    $order['money_name'] = $zmdata['settings']['money_name'];
    if($client_type=='xcx' && (strpos($_SERVER['HTTP_USER_AGENT'], 'iPhone')||strpos($_SERVER['HTTP_USER_AGENT'], 'iPad'))){
        $order['money_name'] = $zmdata['settings']['xcx_money_name'];
    }else{
        $order['money_name'] = $zmdata['settings']['money_name'];
    }

    $order['jifen_name'] = $zmdata['settings']['open_jifen'] ? $zmdata['settings']['jifen_name'] : '';
    $order['mypoints'] = $myuid['points']/10*$zmdata['settings']['jifen_bili'];;
    $order['mymoney'] = $myuid['points']/10;
    $order['jifen_bili'] = $zmdata['settings']['jifen_bili'];
    $order['toutiao_audit'] = $zmdata['settings']['toutiao_audit'];
    zimu_json($order);
