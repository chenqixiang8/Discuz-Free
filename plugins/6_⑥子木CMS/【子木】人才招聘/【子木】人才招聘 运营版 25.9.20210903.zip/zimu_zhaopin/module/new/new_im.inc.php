<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if (!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }

    use think\Db;

    $token = addslashes($_GET['token']);
    $myuid = checktoken($token);
    $op = addslashes($_GET['op']);
    $ids = intval($_GET['ids']);

    if($op=='123'){

    }elseif($op == 'getmessage' ){

        $touid = intval($_GET['touid']);

        $res['lists'] = get_im_message($myuid,$touid);

        if($_GET['onlymsg']==1){
            zimu_json($res);
        }

        $parameter = Db::name('zimu_zhaopin_parameter2')->where('name', 'imchat')->order('id','desc')->find();
        $parameter = unserialize($parameter['parameter']);
        $parameter['quick_msg_resume'] = explode(PHP_EOL, trim($parameter['quick_msg_resume']));
        $parameter['quick_msg_company'] = explode(PHP_EOL, trim($parameter['quick_msg_company']));
        foreach ($parameter['quick_msg_resume'] as $key => $value) {
            $parameter2['quick_msg_resume'][$key]['text'] = $value;
        }
        foreach ($parameter['quick_msg_company'] as $key => $value) {
            $parameter2['quick_msg_company'][$key]['text'] = $value;
        }
        $res['parameter'] = $parameter;
        $res['parameter']['quick_msg'] = $myuid['utype']==2 ? $parameter2['quick_msg_resume'] : $parameter2['quick_msg_company'];

        if($myuid['utype']==1){
            $res['uidinfo'] = Db::name('zimu_zhaopin_company_profile')->where([['uid','=',$myuid['uid']]])->order(['id'=>'desc'])->find();
            $res['uidinfo']['avatar'] = $res['uidinfo']['logo'];
            $res['uidinfo']['utype'] = 'company';
            $res['touidinfo'] = Db::name('zimu_zhaopin_resume')->where([['uid','=',$touid]])->order(['id'=>'desc'])->find();
            if($res['touidinfo']['sex']==1){
                $res['touidinfo']['fullname'] = cutstr($res['touidinfo']['fullname'],2,'').$language_zimu['new_im_inc_php_0'];
            }else{
                $res['touidinfo']['fullname'] = cutstr($res['touidinfo']['fullname'],2,'').$language_zimu['new_im_inc_php_1'];
            }
            $res['touidinfo']['avatar'] = $res['touidinfo']['photo_img'];
            $res['touidinfo']['utype'] = 'resume';
        }

        if($myuid['utype']==2){
            $res['uidinfo'] = Db::name('zimu_zhaopin_resume')->where([['uid','=',$myuid['uid']]])->order(['id'=>'desc'])->find();
            if($res['uidinfo']['sex']==1){
                $res['uidinfo']['fullname'] = cutstr($res['uidinfo']['fullname'],2,'').$language_zimu['new_im_inc_php_2'];
            }else{
                $res['uidinfo']['fullname'] = cutstr($res['uidinfo']['fullname'],2,'').$language_zimu['new_im_inc_php_3'];
            }
            $res['uidinfo']['avatar'] = $res['uidinfo']['photo_img'];
            $res['uidinfo']['utype'] = 'resume';
            if($res['parameter']['system_im_need_wechat'] && $res['uidinfo']['bind_weixin']==0 && IN_WECHAT){
                $dir = DISCUZ_ROOT.'/source/plugin/zimu_zhaopin/uploadzimucms/';
                $qrcode_name = 'bindmp_qrcode_'.time().'.jpg';
                $qrcode_file = $dir.'qrcode/'.$qrcode_name;
                require_once DISCUZ_ROOT . './source/plugin/zimu_zhaopin/class/wechat.lib.class.php';
                $wechat_client = new WeChatClient($zmdata['base']['weixin_appid'], $zmdata['base']['weixin_appsecret']);
                $qrcode_url2 = $wechat_client->getQrcodeImgUrlByTicket($wechat_client->getQrcodeTicket(array(
                    'scene_str' =>  'bindmp_imzimuyun' . ($myuid['old_uid'] ? $myuid['old_uid'] : $myuid['uid']).'job'.$ids,
                    'expire' => 2591000
                )));
                $qrcode_img = dfsockopen($qrcode_url2);
                $qrcode_img = $qrcode_img ? $qrcode_img : file_get_contents($qrcode_url2);
                $fp = fopen($qrcode_file, 'wb');
                flock($fp, 2);
                fwrite($fp,$qrcode_img);
                fclose($fp);
                $res['zmdata']['bindmp_qrcode_url'] = $_G['siteurl'].'source/plugin/zimu_zhaopin/uploadzimucms/qrcode/'.$qrcode_name.'?v='.time();
                $res['zmdata']['show_nosend'] = 1;
                $res['zmdata']['nosend_type'] = 'show_bindmp';
                $res['zmdata']['nosend_tip'] = '<p><img src="'.$res['zmdata']['bindmp_qrcode_url'].'" style="width:150px;"></p>'.$language_zimu['new_im_inc_php_4'];
                $res['zmdata']['nosend_btn_text'] = $language_zimu['new_im_inc_php_5'];
            }
            $res['touidinfo'] = Db::name('zimu_zhaopin_company_profile')->where([['uid','=',$touid]])->order(['id'=>'desc'])->find();
            $res['touidinfo']['avatar'] = $res['touidinfo']['logo'];
            $res['touidinfo']['utype'] = 'company';
            $res['idsinfo'] = Db::name('zimu_zhaopin_jobs')->where([['uid','=',$touid],['id','=',$ids]])->order(['id'=>'desc'])->select()->toArray();
        }

        if($myuid['utype']==1){
            $res = get_im_nosend($res,$myuid,$touid,$zmdata);
        }
        if($res['zmdata']['show_nosend'] != 1 && $myuid['utype']==2){

            $isadd = Db::name('zimu_zhaopin_im_message')->where([['utype','=',$myuid['utype']],['uid','=',$myuid['uid']],['touid','=',$touid],['jsontype','=','resume'],['addtime','>',time()-259200]])->order(['id'=>'desc'])->find();
            if(!$isadd){
                $im_message['utype'] = $myuid['utype'];
                $im_message['uid'] = $myuid['uid'];
                $im_message['touid'] = $touid;
                $im_message['message'] = $language_zimu['new_im_inc_php_6'];
                $im_message['jsontype'] = 'resume';
                $im_message['josnids'] = $myuid['uid'];
                $im_message['addtime'] = time();
                Db::name('zimu_zhaopin_im_message')->insert($im_message);
            }
            if($ids){

                $isadd2 = Db::name('zimu_zhaopin_im_message')->where([['utype','=',$myuid['utype']],['uid','=',$myuid['uid']],['touid','=',$touid],['jsontype','=','job'],['josnids','=',$ids],['addtime','>',time()-259200]])->order(['id'=>'desc'])->find();
                if(!$isadd2){
                    $im_message['utype'] = $myuid['utype'];
                    $im_message['uid'] = $myuid['uid'];
                    $im_message['touid'] = $touid;
                    $im_message['message'] = $language_zimu['new_im_inc_php_7'];
                    $im_message['jsontype'] = 'job';
                    $im_message['josnids'] = $ids;
                    $im_message['addtime'] = time();
                    Db::name('zimu_zhaopin_im_message')->insert($im_message);
                }

            }


        }

        zimu_json($res);

    }elseif($op == 'getjobinfo' ){
        $res = Db::name('zimu_zhaopin_jobs')->where([['id','=',$ids]])->order(['id'=>'desc'])->select()->toArray();
        zimu_json3($res);
    }elseif($op == 'getresumeinfo' ){
        $res = Db::name('zimu_zhaopin_resume')->where([['uid','=',$ids]])->order(['id'=>'desc'])->select()->toArray();
        zimu_json3($res);
    }elseif($op == 'sendmessage' ){

        $formtxt = json_decode(zimu_array_utf8($_GET['formtxt']),true);
        $formtxt = zimu_array_gbk($formtxt);
        $formtxt['message'] = preg_replace('/([0-9]{11,})|([0-9]{3,4}-[0-9]{7,10})|([0-9]{3,4}-[0-9]{2,5}-[0-9]{2,5})/', '', $formtxt['message']);
        $formtxt['message']=preg_replace('|[0-9a-zA-Z/]+|','',$formtxt['message']);
        $formtxt['message'] = filterComment($formtxt['message'],$zmdata['settings']['notwords']);
        //$formtxt['message'] = zimu_array_utf8($formtxt['message']);
        //preg_match_all('/[\x{4e00}-\x{9fa5}]+/u', $formtxt['message'], $matches);
        //$formtxt['message'] = join('', $matches[0]);
        //$formtxt['message'] = zimu_array_utf8tomy($formtxt['message']);

        if($formtxt['uid'] == $myuid['uid'] && $formtxt['touid'] && $formtxt['message']){
            $im_message['utype'] = $myuid['utype'];
            $im_message['uid'] = $myuid['uid'];
            $im_message['touid'] = $formtxt['touid'];
            $im_message['message'] = $formtxt['message'];
            $im_message['addtime'] = time();
            Db::name('zimu_zhaopin_im_message')->insert($im_message);
            $lasttpl = Db::name('zimu_zhaopin_sendtpllog')->where([['uid','=',$formtxt['touid']]])->order('id','desc')->find();
            $touidinfo = Db::name('zimu_zhaopin_members')->where([['uid','=',$formtxt['touid']]])->order('id','desc')->find();
            if($myuid['utype']==1 && time() - $touidinfo['onlinetime'] > 300 && time() - $lasttpl['sendtime'] > 600){
                resume_imchat_push($formtxt['touid'],$formtxt['message']);
            }else if($myuid['utype']==2 && time() - $touidinfo['onlinetime'] > 300 && time() - $lasttpl['sendtime'] > 600){
                company_imchat_push($formtxt['touid'],$formtxt['message']);
            }
        }
        zimu_json($res);

    }elseif($op == 'getlist' ){
        $res = get_im_list($myuid);
        zimu_json3($res);
    }elseif($op == 'im_noread_counts' ){
        if(file_exists(DISCUZ_ROOT . './source/plugin/zimu_zhaopin/module/adminss/adminss_imconfig.inc.php')) {
            $res['open_im'] = 1;
            $res['im_counts'] = get_im_noread_counts($myuid);
        }else{
            $res['open_im'] = 0;
            $res['im_counts'] = 0;
        }
        zimu_json3($res);
    }