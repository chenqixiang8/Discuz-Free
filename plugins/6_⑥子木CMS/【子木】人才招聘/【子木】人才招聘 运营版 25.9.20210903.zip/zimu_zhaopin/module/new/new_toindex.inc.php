<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

    use think\Db;

    $token = addslashes($_GET['token']);
    $myuid = checktoken($token,0);
    $op = addslashes($_GET['op']);
    $zimu_get = zimu_array_gbk($_GET);
    $page = intval($_GET['page']);


    if($op == 'gethongniang') {


    }elseif($op == 'iospay' ){

        if($client_type=='toutiao'){
            $res['iospay'] = $zmdata['settings']['toutiao_money_tip'];
        }else{
            $res['iospay'] = $zmdata['settings']['xcx_money_tip'];
        }
        $res['iospay'] = str_replace('src="source/plugin/zimu_zhaopin/static/ueditor/upload','src="'.$_G['siteurl'].'source/plugin/zimu_zhaopin/static/ueditor/upload',$res['iospay']);
        zimu_json($res);

    }else{

        $indexad = Db::name('zimu_zhaopin_parameter2')->where('name','indexad')->find();
        $res['indexad'] = unserialize($indexad['parameter']);
        $wapcat = Db::name('zimu_zhaopin_parameter2')->where('name','wapcat')->find();
        $catlist = unserialize($wapcat['parameter']);
        $cat_style = $zmdata['settings']['cat_style'] ? $zmdata['settings']['cat_style'] : '5|2';
        $res['cat_style'] = $cat_style = explode('|',$cat_style);
        foreach ($catlist as $key => $value) {
            $res['catlist'][floor($key/$cat_style[0]/$cat_style[1])][] = $value;
        }
        $jobsCount = Db::name('zimu_zhaopin_jobs')->count();
        $res['jobsCount'] = $zmdata['settings']['jobscount'] + $jobsCount;
        $resumeCount = Db::name('zimu_zhaopin_resume')->count();
        $res['resumeCount'] = $zmdata['settings']['resumeCount'] + $resumeCount;
        $comcount = Db::name('zimu_zhaopin_company_profile')->count();
        $res['comcount'] = $zmdata['settings']['comcount'] + $comcount;
        $res['views'] = $zmdata['settings']['views'] + $zmdata['base']['views'];
        $res['views'] = $res['views']>10000 ? round($res['views']/10000,1).$language_zimu['new_toindex_inc_php_0'] : $res['views'];
        $res['wap_ad'] = $zmdata['settings']['wap_ad'];

        $pcadlist = Db::name('zimu_zhaopin_company_profile')->where([['is_pcad','>',0]])->order(['is_pcad'=>'asc','id'=>'asc'])->select()->toArray();
        foreach ($pcadlist as $key => $value) {
            $pcadlist[$key]['jobs_count'] = Db::name('zimu_zhaopin_jobs')->where([['company_id','=',$value['id']],['audit','<>',3],['display','<>',2]])->count();
        }
        foreach ($pcadlist as $key => $value) {
            $res['pcadlist'][floor($key/2/1)][] = $value;
        }

        $res['alltopcat2'] = Db::name('zimu_zhaopin_category_jobs')->where([['parentid','=',0]])->order(['category_order'=>'asc','id'=>'asc'])->select()->toArray();

        if(file_exists(DISCUZ_ROOT . './source/plugin/zimu_zhaopin/module/a_change_area.inc.php') && ( $zmdata['settings']['change_city'] == 1 || $zmdata['settings']['change_area'] > 0) ){
            if($tocityid2){
                $wheresql_tocity[] = ['district2','=',$tocityid2];
            }elseif($tocityid){
                $wheresql_tocity[] = ['district','=',$tocityid];
            }
        }

        if($zmdata['settings']['show_noaudit']){
            $wheresql_tocity[] = ['audit','=',1];
        }

        $topjobs = Db::name('zimu_zhaopin_jobs')->where($wheresql_tocity)->where([['company_audit','<>',3],['audit','<>',3],['display','<>',2],['stick_endtime','>',time()]])->order(['refreshtime'=>'desc','stick_endtime'=>'desc','id'=>'desc'])->select()->toArray();
        $res['topjobs'] = format_jobs($topjobs,$zmdata);

        $newjobs = Db::name('zimu_zhaopin_jobs')->where($wheresql_tocity)->where([['company_audit','<>',3],['audit','<>',3],['display','<>',2],['stick_endtime','<',time()]])->order(['refreshtime'=>'desc','id'=>'desc'])->page($page,30)->select()->toArray();
        $res['newjobs'] = format_jobs($newjobs,$zmdata);
        $res['newjobs'] = zimu_ad_system($res['newjobs'],'zhaopin1',0);

        $res['wapfooter'] = $zmdata['settings']['wapfooterhtml'];

        $paramter = Db::name('zimu_zhaopin_parameter2')->where([['name','=','wappopup']])->order(['id'=>'asc'])->find();
        $res['wappopup'] = unserialize($paramter['parameter']);

        $vuex_color2 = hex2rgb($zmdata['settings']['vuex_color2']);
        $res['vuex_color2'] = 'rgba('.$vuex_color2['r'].','.$vuex_color2['g'].','.$vuex_color2['b'].',0.1)';
        $res['appinfo']['app_name'] = $zmdata['settings']['app_name'];
        $res['appinfo']['app_url'] = $zmdata['settings']['app_url'];
        $res['appinfo']['wap_ad'] = $zmdata['settings']['wap_ad'];

        if(file_exists(DISCUZ_ROOT . './source/plugin/zimu_zhaopin/module/a_change_area.inc.php') && $zmdata['settings']['change_city'] == 1 ){
            $res['fenzhan'] = 1;
        }


        if($myuid['openid'] && IN_WECHAT && $zmdata['settings']['mp_qrcode_time']){
            require_once DISCUZ_ROOT . './source/plugin/zimu_zhaopin/class/wechat.lib.class.php';
            $wechat_client = new WeChatClient($zmdata['base']['weixin_appid'], $zmdata['base']['weixin_appsecret']);
            $wechatinfo    = $wechat_client->getUserInfoById($myuid['openid']);
            if ($wechatinfo['subscribe'] == 1) {
                dsetcookie('zimu_zhaopin_subscribe', 1, 6000);
                Db::name('zimu_zhaopin_company_profile')->where('uid', $myuid['uid'])->data(['bind_weixin' => 1])->update();
                Db::name('zimu_zhaopin_resume')->where('uid', $myuid['uid'])->data(['bind_weixin' => 1])->update();
            } elseif ($wechatinfo['openid'] && $wechatinfo['subscribe'] == 0 && getcookie('zimu_zhaopin_subscribe') != 1) {
                $res['zmdata']['show_mp_qrcode'] = 1;
                dsetcookie('zimu_zhaopin_subscribe', 1, $zmdata['settings']['mp_qrcode_time']);
                Db::name('zimu_zhaopin_company_profile')->where('uid', $myuid['uid'])->data(['bind_weixin' => 0])->update();
                Db::name('zimu_zhaopin_resume')->where('uid', $myuid['uid'])->data(['bind_weixin' => 0])->update();
            }
        }

        $res['zmdata']['mp_qrcode_url'] = $zmdata['settings']['mp_qrcode_url'];
        $res['zmdata']['mp_qrcode_text'] = $zmdata['settings']['mp_qrcode_text'];
        $res['zmdata']['kefu_wxid'] = $zmdata['settings']['kefu_wxid'];
        $res['zmdata']['noshow_tongji'] = $zmdata['settings']['noshow_tongji'];
        $res['zmdata']['zhiding_cn'] = $zmdata['settings']['zhiding_cn'] ? $zmdata['settings']['zhiding_cn'] : $language_zimu['new_toindex_inc_php_1'];
        $res['zmdata']['toutiao_audit'] = $zmdata['settings']['toutiao_audit'];
        $res['zmdata']['index_hidecat'] = $zmdata['settings']['index_hidecat'];
        zimu_json($res);

    }
