<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if (!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }

    use think\Db;

    $op = addslashes($_GET['op']);

    if(!empty($_FILES['file'])){

        //��ȡ��չ��
        $pathinfo      = pathinfo($_FILES['file']['name']);
        $exename  = strtolower($pathinfo['extension']);
        if($exename != 'png'  && $exename != 'jpeg' && $exename != 'jpg' && $exename != 'gif'){
            exit('error');
        }
        $imageSavePath = uniqid().'.'.$exename;

        $date        = date('ym/d/');
        $save_avatar = DISCUZ_ROOT . './source/plugin/zimu_zhaopin/uploadzimucms/' . $date;

        if (!is_dir($save_avatar)) {
            mkdir($save_avatar, 0777, true);
        }

        if(move_uploaded_file($_FILES['file']['tmp_name'], $save_avatar.$imageSavePath)){

            $oss_paramter = Db::name('zimu_zhaopin_parameter2')->where('name', 'alioss')->find();
            $oss_paramter = unserialize($oss_paramter['parameter']);

            if(!$oss_paramter['oss_type'] && $oss_paramter['ACCESS_ID'] && $oss_paramter['ACCESS_KEY'] && $oss_paramter['ENDPOINT'] && $oss_paramter['BUCKET']){
                $saved_file = $save_avatar.$imageSavePath;
                include_once DISCUZ_ROOT.'source/plugin/zimu_zhaopin/lib/OSS/Common.php';
                if ($surl = zm_oss_upload('zimu_zhaopin/' . $date . $imageSavePath, $saved_file)) {
                    @unlink($saved_file);
                    $imgurl = $surl;
                }
            }elseif ($oss_paramter['oss_type']==1 && $oss_paramter['qn_ak'] && $oss_paramter['qn_sk'] && $oss_paramter['qn_bk']){

                $saved_file = $save_avatar.$imageSavePath;
                include_once(DISCUZ_ROOT.'source/plugin/zimu_zhaopin/lib/Qiniu/upload.php');
                if ($surl=zm_qn_upload('zimu_zhaopin/' . $date . $imageSavePath,$saved_file)) {
                    unlink($saved_file);
                    error_reporting(0);
                    $imgurl = $surl;
                }

            }else{
                $imgurl =  $_G['siteurl'].'source/plugin/zimu_zhaopin/uploadzimucms/' . $date.$imageSavePath;
            }

            if($_GET['op']=='h5'){
                echo $imgurl;
            }else{
                $res['imgurl'] = $imgurl;
                zimu_json($res);
            }
        }
    }