<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if (!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }

    use think\Db;

    $token = addslashes($_GET['token']);
    $myuid = checktoken($token);
    $op = addslashes($_GET['op']);
    $zimu_get = zimu_array_gbk($_GET);
    $page = intval($_GET['page']);

    $login_code = addslashes($_GET['login_code']);
    $encryptedData = addslashes($_GET['encryptedData']);
    $iv = addslashes($_GET['iv']);

    $xcxurl = 'https://api.weixin.qq.com/sns/jscode2session?appid='.$zmdata['settings']['xcx_appid'].'&secret='.$zmdata['settings']['xcx_appsecret'].'&js_code='.$login_code.'&grant_type=authorization_code';
    $xcxdata = zm_curl($xcxurl);
    $xcxdata2 = json_decode($xcxdata,true);

    require_once DISCUZ_ROOT . 'source/plugin/zimu_zhaopin/class/wxBizDataCrypt.php';

    $appid = $zmdata['settings']['xcx_appid'];
    $sessionKey = $xcxdata2['session_key'];

    $pc = new WXBizDataCrypt($appid, $sessionKey);
    $errCode = $pc->decryptData($encryptedData, $iv, $data );
    $xcxdata3 = json_decode($data,true);

    Db::name('zimu_zhaopin_members')->where('id', $myuid['id'])->data(['telephone' => $xcxdata3['purePhoneNumber']])->update();

    $res['myinfo'] = $myuid;
    $res['myinfo']['telephone'] = $xcxdata3['purePhoneNumber'];

    if($zmdata['settings']['xcx_isapp'] == 1 && $xcxdata3['purePhoneNumber']){
        $isreg = Db::name('user_mobile_relations')->where([['phone','=',$xcxdata3['purePhoneNumber']],['userid','>',0]])->find();
        if(!$isreg){
            $appdata = array(
                'userid' => $myuid['uid'],
                'phone' => $xcxdata3['purePhoneNumber'],
                'create_time' => time()
            );
            Db::name('user_mobile_relations')->insert($appdata);
        }
    }
    if($zmdata['settings']['xcx_isapp'] == 2 && $xcxdata3['purePhoneNumber']){
        $isreg = Db::name('phonebind')->where([['phone','=',$xcxdata3['purePhoneNumber']],['uid','>',0]])->find();
        if(!$isreg){
            $appdata = array(
                'uid' => $myuid['uid'],
                'phone' => $xcxdata3['purePhoneNumber'],
                'dateline' => time()
            );
            Db::name('phonebind')->insert($appdata);
        }
    }
    if($zmdata['settings']['xcx_isapp'] == 3 && $xcxdata3['purePhoneNumber']){
        $isreg = Db::name('appbyme_sendsms')->where([['mobile','=',$xcxdata3['purePhoneNumber']],['uid','>',0]])->find();
        if(!$isreg){
            $appdata = array(
                'uid' => $myuid['uid'],
                'code' => 'zhaopin',
                'mobile' => $xcxdata3['purePhoneNumber'],
                'time' => time()
            );
            Db::name('appbyme_sendsms')->insert($appdata);
        }
    }

    zimu_json($res);