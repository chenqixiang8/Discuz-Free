<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if (!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }

    use think\Db;

    $token = addslashes($_GET['token']);
    $myuid = checktoken($token,0);
    $op = addslashes($_GET['op']);
    $zimu_get = zimu_array_gbk($_GET);
    $page = intval($_GET['page']);

    if($op == 'zimuyun') {

    }elseif($op == 'viewnews' ){

        $ids = intval($_GET['ids']);
        $wheresql2[] = ['id','=',$ids];
        $res['news'] = Db::name('zimu_zhaopin_news')->where($wheresql2)->order(['id'=>'desc'])->find();
        $res['news']['con'] = htmlspecialchars_decode($res['news']['con']);
        $res['wapfooter'] = $zmdata['settings']['wapfooterhtml'];
        $res['zmdata']['randad'] = zimu_ad_system2('zhaopin10');
        $res['zmdata']['randad2'] = zimu_ad_system2('zhaopin11');
        $res['zmdata']['toutiao_bannerid'] = $zmdata['settings']['toutiao_bannerid'];
        Db::name('zimu_zhaopin_news')->where('id', $ids)->inc('views', 1)->update();
        zimu_json($res);

    }else{
        $cat1 = [['id'=>0,'name'=>$language_zimu['new_news_inc_php_0']]];
        $cat2 = Db::name('zimu_zhaopin_news_cat')->order(['id'=>'asc'])->select()->toArray();
        $res['cat'] = array_merge($cat1,$cat2);
        foreach ($res['cat'] as $key => $value) {
            $res['cat2'][$key]['name'] = $value['name'];
        }
        $cid = intval($_GET['cid']);
        if($cid){
            $wheresql2[] = ['cid','=',$cid];
        }

        $res['news'] = Db::name('zimu_zhaopin_news')->where($wheresql2)->order(['id'=>'desc'])->page($page,10)->select()->toArray();

        $res['wapfooter'] = $zmdata['settings']['wapfooterhtml'];

        zimu_json($res);


    }