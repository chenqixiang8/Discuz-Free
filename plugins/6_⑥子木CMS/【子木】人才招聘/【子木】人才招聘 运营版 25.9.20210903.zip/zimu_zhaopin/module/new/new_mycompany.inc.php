<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if (!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }

    use think\Db;
    $op = addslashes($_GET['op']);
    $token = addslashes($_GET['token']);
    if($op=='viewcom' || $op=='haibao'){
        $myuid = checktoken($token,0);
    }else{
        $myuid = checktoken($token);
    }
    if($myuid['uid']>0){
        $check_company_setmeal = check_company_setmeal($myuid['uid']);
    }
    $ids = intval($_GET['ids']);

    if($op=='123'){

    }elseif($op == 'com_info' ){

        $category = Db::name('zimu_zhaopin_category')->order(['c_order'=>'asc','c_id'=>'asc'])->select()->toArray();

        foreach ($category as $key => $value) {
            $category2[$value['c_alias']][$value['c_id']]['value'] = $value['c_id'];
            $category2[$value['c_alias']][$value['c_id']]['label'] = $value['c_name'];
        }

        $nature_list = $category2['ZM_company_type'];
        array_multisort($nature_list);
        $res['nature_list'] = $nature_list;

        $res['zmdata']['wapfooter'] = $zmdata['settings']['wapfooterhtml'];
        $job_input_paramter = Db::name('zimu_zhaopin_parameter2')->where([['name','=','job_input']])->find();
        $res['zmdata']['job_input'] = unserialize($job_input_paramter['parameter']);
        if($zmdata['settings']['area_three']==1){
            $res['zmdata']['area_three'] = 3;
        }else{
            $isarea = Db::name('zimu_zhaopin_area')->where([['parentid','>',0]])->find();
            if($isarea){
                $res['zmdata']['area_three'] = 2;
            }else{
                $res['zmdata']['area_three'] = 1;
            }
        }

        $sms_paramter = Db::name('zimu_zhaopin_parameter2')->where('name', 'aliyunsms')->find();
        $sms_paramter = unserialize($sms_paramter['parameter']);
        if ($sms_paramter['smsAppKey']) {
            $res['zmdata']['showcode'] = 1;
        }else{
            $res['zmdata']['showcode'] = 0;
        }


        $arealist = Db::name('zimu_zhaopin_area')->field('id as value,name as label')->where([['parentid','=',0]])->order(['sort'=>'asc','id'=>'asc'])->select()->toArray();

        foreach ($arealist as $key => $value) {
            $arealist[$key]['children'] = Db::name('zimu_zhaopin_area')->field('id as value,name as label')->where([['parentid','=',$value['value']]])->order(['sort'=>'asc','id'=>'asc'])->select()->toArray();

            if($zmdata['settings']['area_three']){
                foreach ($arealist[$key]['children'] as $key2 => $value2) {
                    $arealist[$key]['children'][$key2]['children'] = Db::name('zimu_zhaopin_area')->field('id as value,name as label')->where([['parentid','=',$value2['value']]])->order(['sort'=>'asc','id'=>'asc'])->select()->toArray();
                }
            }

        }
        $res['district_list'] = $arealist;
        $trade_list = $category2['ZM_trade'];
        array_multisort($trade_list);
        $res['trade_list'] = $trade_list;
        $scale_list = $category2['ZM_scale'];
        array_multisort($scale_list);
        $res['scale_list'] = $scale_list;
        $res['company'] = Db::name('zimu_zhaopin_company_profile')->where([['uid','=',$myuid['uid']]])->find();
        $res['company']['logo2'][] = $res['company']['logo'];
        $res['company']['certificate_img2'][] = $res['company']['certificate_img'];
        $res['company']['environment'] = explode(',',$res['company']['environment']);

        $tag_list = $category2['ZM_jobtag'];
        array_multisort($tag_list);
        foreach ($tag_list as $key => $value) {
            if(strpos($res['company']['tag_cn'],$value['label']) !== false){
                $tag_list[$key]['select'] = true;
            }else{
                $tag_list[$key]['select'] = false;
            }
        }
        $res['tag_list'] = $tag_list;

        $com_input_paramter = Db::name('zimu_zhaopin_parameter2')->where('name', 'com_input')->find();
        $res['com_input'] = unserialize($com_input_paramter['parameter']);
        $mag_paramter = Db::name('zimu_zhaopin_parameter2')->where('name', 'magapp')->find();
        $mag_paramter = unserialize($mag_paramter['parameter']);
        $res['magapp_hostname'] = $mag_paramter['magapp_hostname'];

        if($res['company']['telephone'] && (!$myuid['telephone'] || $res['company']['telephone'] != $myuid['telephone'])){
            Db::name('zimu_zhaopin_members')->where('uid', $myuid['uid'])->data(['telephone' => $res['company']['telephone']])->update();
        }

        $agreement_paramter = Db::name('zimu_zhaopin_parameter2')->where('name', 'agreement')->find();
        $agreement_paramter = unserialize($agreement_paramter['parameter']);
        $res['zmdata']['agreement'] = $agreement_paramter['agreement'];
        $res['zmdata']['close_testmobile'] = $zmdata['settings']['close_testmobile'];
        $res['myinfo'] = $myuid;

        zimu_json($res);

    }elseif($op == 'viewcom' ){

        $res['company'] = Db::name('zimu_zhaopin_company_profile')->where([['id','=',$ids]])->find();
        $res['company']['logo'] = $res['company']['logo'] ? $res['company']['logo'] : $company_nologo;
        $res['company']['telephone'] = '13212345678';
        $companyjob = Db::name('zimu_zhaopin_jobs')->where([['audit','<>',3],['display','<>',2],['company_id','=',$ids]])->order(['refreshtime'=>'desc','id'=>'desc'])->select()->toArray();
        $res['companyjob'] = format_jobs($companyjob,$zmdata);

        if($myuid['uid']>0){
            $res['company']['isfav'] = Db::name('zimu_zhaopin_personal_focus_company')->where([['company_id','=',$ids],['uid','=',$myuid['uid']]])->count();
        }

        $res['company']['environment'] = explode(',',$res['company']['environment']);
        $res['wapfooter'] = $zmdata['settings']['wapfooterhtml'];

        $manage_uids = str_replace(';', ',', $zmdata['manage_uids']);
        $manage_uids = explode(',', $manage_uids);
        if($myuid['uid'] && (in_array($myuid['uid'],$manage_uids) || $myuid['uid']==$res['company']['kefu_uid'])){
            $res['company']['isadmin'] = 1;
        }
        $audit_tip1 = explode(PHP_EOL, trim($zmdata['settings']['audit_tip1']));
        $audit_tip2 = explode(PHP_EOL, trim($zmdata['settings']['audit_tip2']));
        foreach ($audit_tip1 as $key => $value) {
            $res['audit_tip1'][$key]['text'] = $value;
        }
        foreach ($audit_tip2 as $key => $value) {
            $res['audit_tip2'][$key]['text'] = $value;
        }
        if($zmdata['settings']['toutiao_audit']!=1){
            $res['zmdata']['randad'] = zimu_ad_system2('zhaopin7');
        }
        $res['zmdata']['toutiao_audit'] = $zmdata['settings']['toutiao_audit'];
        if($res['company']['isadmin']==1){
            $res['company']['blacklist'] = Db::name('zimu_zhaopin_members')->where([['uid','=',$res['company']['uid']]])->order(['id'=>'asc'])->value('blacklist');
        }

        zimu_json($res);

    }elseif($op == 'tofav' ){

        $has = Db::name('zimu_zhaopin_personal_focus_company')->where([['uid','=',$myuid['uid']],['company_id','=',$ids]])->find();
        if($has){
            Db::name('zimu_zhaopin_personal_focus_company')->where('id', $has['id'])->delete();
            $res['tip'] = $language_zimu['new_mycompany_inc_php_0'];
        }else{
            $data['uid']       = $myuid['uid'];
            $data['company_id']        = $ids;
            $data['addtime']     = time();
            Db::name('zimu_zhaopin_personal_focus_company')->insert($data);
            $res['tip'] = $language_zimu['new_mycompany_inc_php_1'];
        }

        zimu_json($res);


    }elseif($op == 'com_info_edit' ){

        $sms_paramter = Db::name('zimu_zhaopin_parameter2')->where('name', 'aliyunsms')->find();
        $sms_paramter = unserialize($sms_paramter['parameter']);

        $formtxt = json_decode(zimu_array_utf8($_GET['formtxt']),true);
        $formtxt = zimu_array_gbk($formtxt);
        $company_profile = Db::name('zimu_zhaopin_company_profile')->where([['uid','=',$myuid['uid']]])->find();

        if (!$myuid['telephone'] && $sms_paramter['smsAppKey'] && !$company_profile['telephone']) {
            $telephone    = trim($formtxt['telephone']);
            $mobile_vcode = trim($formtxt['code']);
            $sendsmslog = Db::name('zimu_zhaopin_sendsmslog')->where([['uid','=',$myuid['uid']],['type','=','code']])->order(['id'=>'desc'])->find();
            if ($myuid['verify_code'] != $mobile_vcode || $sendsmslog['mobile'] != $telephone) {
                zimu_json('',$language_zimu['new_mycompany_inc_php_2'],202);
            }
        }

        if ($myuid['telephone'] && $myuid['telephone'] != $formtxt['telephone'] && $sms_paramter['smsAppKey']) {
            $telephone    = trim($formtxt['telephone']);
            $mobile_vcode = trim($formtxt['code']);
            $sendsmslog = Db::name('zimu_zhaopin_sendsmslog')->where([['uid','=',$myuid['uid']],['type','=','code']])->order(['id'=>'desc'])->find();
            if (!$mobile_vcode || $myuid['verify_code'] != $mobile_vcode || $sendsmslog['mobile'] != $telephone) {
                zimu_json('',$language_zimu['new_mycompany_inc_php_3'],202);
            }
        }

        if($myuid['telephone'] != $formtxt['telephone']){
            Db::name('zimu_zhaopin_members')->where('uid', $myuid['uid'])->data(['telephone' => $formtxt['telephone']])->update();
            Db::name('common_member_profile')->where('uid', $myuid['uid'])->data(['mobile' => $formtxt['telephone']])->update();
        }

        $setsqlarr['uid']         = $myuid['uid'];
        $setsqlarr['companyname'] = $formtxt['companyname'];
        $setsqlarr['nature'] = $formtxt['nature'];
        $setsqlarr['nature_cn'] = $formtxt['nature_cn'];
        $setsqlarr['trade'] = $formtxt['trade'];
        $setsqlarr['trade_cn'] = $formtxt['trade_cn'];
        $setsqlarr['district'] = intval($formtxt['district'][0]).'.'.intval($formtxt['district'][1]).'.'.intval($formtxt['district'][2]);
        $setsqlarr['district_cn'] = $formtxt['district_cn'];
        $setsqlarr['scale'] = $formtxt['scale'];
        $setsqlarr['scale_cn'] = $formtxt['scale_cn'];
        $setsqlarr['address'] = $formtxt['address'];
        $setsqlarr['map_x'] = $formtxt['latitude'];
        $setsqlarr['map_y'] = $formtxt['longitude'];
        $setsqlarr['contact'] = $formtxt['contact'];
        $setsqlarr['telephone'] = $formtxt['telephone'];
        $setsqlarr['logo'] = $_GET['logo'] ? $_GET['logo'] : $company_nologo;
        $setsqlarr['environment'] = $_GET['environment'] && $_GET['environment'] != 'undefined' ? $_GET['environment'] : '';
        if($_GET['certificate_img']){
            $setsqlarr['certificate_img'] = $_GET['certificate_img'];
        }
        $setsqlarr['contents'] = $formtxt['contents'];
        $setsqlarr['contents'] = preg_replace('/([0-9]{11,})|([0-9]{3,4}-[0-9]{7,10})|([0-9]{3,4}-[0-9]{2,5}-[0-9]{2,5})/', '', $setsqlarr['contents']);
        $setsqlarr['contents'] = filterComment($setsqlarr['contents'],$zmdata['settings']['notwords']);

        $setsqlarr['audit'] = 2;
        $setsqlarr['tag'] = implode(',',$formtxt['tag']);
        $setsqlarr['tag_cn'] = implode(',',$formtxt['tag_cn']);

        if($company_profile){

            if ($company_profile['audit'] == 3) {
                $setsqlarr['audit'] = 2;
            }

            Db::name('zimu_zhaopin_company_profile')->where([['id','=',$company_profile['id']]])->update($setsqlarr);

        }else{

            $freesetmeal = Db::name('zimu_zhaopin_setmeal')->where([['id','=',1]])->find();
            $setsqlarr['setmeal_id'] = $freesetmeal['id'];
            $setsqlarr['setmeal_name'] = $freesetmeal['setmeal_name'];

            $setsqlarr['addtime'] = time();
            $setsqlarr['refreshtime'] = time();
            $setsqlarr['logintime'] = time();
            $setsqlarr['certificate_img'] = $_GET['certificate_img'];
            $setsqlarr['certificate_img_audit'] = 0;

            $is_company_profile2 = Db::name('zimu_zhaopin_company_profile2')->where([['telephone','=',$setsqlarr['telephone']]])->find();

            if($is_company_profile2){
                $setsqlarr['kefu_uid'] = $is_company_profile2['kefu_uid'];
                $setsqlarr['kefu_name'] = $is_company_profile2['kefu_name'];
            }
            if($setsqlarr['uid']){
                $newids = Db::name('zimu_zhaopin_company_profile')->insertGetId($setsqlarr);
            }

            $tip = $language_zimu['new_mycompany_inc_php_4'];
            $keyword1 = $setsqlarr['companyname'].$setsqlarr['address'].$setsqlarr['contact'].$setsqlarr['telephone'];
            $remark = $language_zimu['new_mycompany_inc_php_5'];
            $templatedata['first']['value'] = $tip;
            $templatedata['first']['color'] = "#FF4040";
            $templatedata['keyword1']['value'] = $keyword1;
            $templatedata['keyword2']['value'] = date('Y-m-d H:i', time());
            $templatedata['remark']['value'] = $remark;
            $apptpl['magapp']['tag'] = $tip;
            $apptpl['magapp']['title'] = $keyword1;
            $apptpl['magapp']['des'] = $remark;
            $apptpl['qfapp']['msg'] = $apptpl['magapp']['tag'];
            $apptpl['qfapp']['title'] = $apptpl['magapp']['title'];
            $apptpl['qfapp']['content'] = $apptpl['magapp']['des'];
            $tourl = $_G['siteurl'].'source/plugin/zimu_zhaopin/h5/pages/qiye/view?ids='.$newids.'&mobile=2';
            $link = $_G['siteurl'].'plugin.php?id=zimu_zhaopin:new&model=newindex&tourl='.urlencode($tourl);
            notification_all('admin','wxtpl_admin',$templatedata,$apptpl,$link);

            to_create_setmeal($myuid);

            if($is_company_profile2){

                $custom_feedback2 = Db::name('zimu_zhaopin_crm_custom_feedback2')->where([['custom_id','=',$is_company_profile2['id']]])->order(['id'=>'asc'])->select()->toArray();

                foreach ($custom_feedback2 as $key => $value) {
                    $custom_feedback = $value;
                    unset($custom_feedback['id']);
                    $custom_feedback['custom_id'] = $newids;
                    Db::name('zimu_zhaopin_crm_custom_feedback')->insert($custom_feedback);
                    Db::name('zimu_zhaopin_crm_custom_feedback2')->where([['id','=',$value['id']]])->delete();
                }

                $custom_feedback['custom_type'] = 1;
                $custom_feedback['custom_id'] = $newids;
                $custom_feedback['crm_uid'] = $is_company_profile2['kefu_uid'];
                $custom_feedback['type_id'] = 1;
                $custom_feedback['contact_name'] = $language_zimu['new_mycompany_inc_php_6'];
                $custom_feedback['add_time'] = time();
                $custom_feedback['comment'] = $is_company_profile2['contact'].$is_company_profile2['telephone'].$is_company_profile2['weixin'].$is_company_profile2['address'];
                Db::name('zimu_zhaopin_crm_custom_feedback')->insert($custom_feedback);
                Db::name('zimu_zhaopin_company_profile2')->where([['id','=',$is_company_profile2['id']]])->delete();

            }

        }

        zimu_json($res);

    }elseif($op == 'jobs_add' ){

        $category_jobs = Db::name('zimu_zhaopin_category_jobs')->field('id as value,categoryname as label')->where([['parentid','=',0]])->order(['category_order'=>'asc','id'=>'asc'])->select()->toArray();

        foreach ($category_jobs as $key => $value) {
            $category_jobs[$key]['children'] = Db::name('zimu_zhaopin_category_jobs')->field('id as value,categoryname as label')->where([['parentid','=',$value['value']]])->order(['category_order'=>'asc','id'=>'asc'])->select()->toArray();
        }

        $category = Db::name('zimu_zhaopin_category')->order(['c_order'=>'asc','c_id'=>'asc'])->select()->toArray();

        foreach ($category as $key => $value) {
            $category2[$value['c_alias']][$value['c_id']]['value'] = $value['c_id'];
            $category2[$value['c_alias']][$value['c_id']]['label'] = $value['c_name'];
        }

        $nature_list = $category2['ZM_jobs_nature'];
        array_multisort($nature_list);
        $res['nature_list'] = $nature_list;
        $res['jobcat_list'] = $category_jobs;

        $arealist = Db::name('zimu_zhaopin_area')->field('id as value,name as label')->where([['parentid','=',0]])->order(['sort'=>'asc','id'=>'asc'])->select()->toArray();

        foreach ($arealist as $key => $value) {
            $arealist[$key]['children'] = Db::name('zimu_zhaopin_area')->field('id as value,name as label')->where([['parentid','=',$value['value']]])->order(['sort'=>'asc','id'=>'asc'])->select()->toArray();

            if($zmdata['settings']['area_three']){
                foreach ($arealist[$key]['children'] as $key2 => $value2) {
                    $arealist[$key]['children'][$key2]['children'] = Db::name('zimu_zhaopin_area')->field('id as value,name as label')->where([['parentid','=',$value2['value']]])->order(['sort'=>'asc','id'=>'asc'])->select()->toArray();
                }
            }

        }
        $res['district_list'] = $arealist;
        if($zmdata['settings']['area_three']==1){
            $res['area_three'] = 3;
        }else{
            $isarea = Db::name('zimu_zhaopin_area')->where([['parentid','>',0]])->find();
            if($isarea){
                $res['area_three'] = 2;
            }else{
                $res['area_three'] = 1;
            }
        }
        $experience_list = $category2['ZM_experience'];
        array_multisort($experience_list);
        $res['experience_list'] = $experience_list;

        $education_list = $category2['ZM_education'];
        array_multisort($education_list);
        $noeducation[0]['value'] = 0;
        $noeducation[0]['label'] = $language_zimu['new_mycompany_inc_php_7'];
        $res['education_list'] = array_merge($noeducation,$education_list);

        $education_list = $category2['ZM_education'];
        array_multisort($education_list);
        $noeducation[0]['value'] = 0;
        $noeducation[0]['label'] = $language_zimu['new_mycompany_inc_php_8'];
        $res['education_list'] = array_merge($noeducation,$education_list);

        $res['company'] = Db::name('zimu_zhaopin_company_profile')->where([['uid','=',$myuid['uid']]])->find();

        if($ids){
            $job_info = Db::name('zimu_zhaopin_jobs')->where([['id','=',$ids]])->find();
            $auditinfo = Db::name('zimu_zhaopin_jobs_audit')->where('ids', $ids)->find();
            if($auditinfo){
                unset($auditinfo['id']);
                $job_info = array_merge($job_info,$auditinfo);
            }
            if($job_info['contact'] && $job_info['telephone']){
                $res['company']['contact'] = $job_info['contact'];
                $res['company']['telephone'] = $job_info['telephone'];
            }
            if(!$job_info['minwage'] && !$job_info['maxwage'] && $job_info['wage_cn']){
                $wage_cn = explode('~',$job_info['wage_cn']);
                $job_info['minwage'] = intval($wage_cn[0]);
                $job_info['maxwage'] = intval($wage_cn[1]);
            }
        }

        $tag_list = $category2['ZM_jobtag'];
        array_multisort($tag_list);
        foreach ($tag_list as $key => $value) {
            if(strpos($job_info['tag_cn'],$value['label']) !== false){
                $tag_list[$key]['select'] = true;
            }else{
                $tag_list[$key]['select'] = false;
            }
        }
        $res['tag_list'] = $tag_list;

        $stick_list = Db::name('zimu_zhaopin_setmeal_increment')->where([['cat','=','stick']])->order(['sort'=>'asc','id'=>'asc'])->select()->toArray();
        $res['stick_list'] = $stick_list;

        $res['job_info'] = $job_info;

        if(!$res['company']){
            $setmeal = Db::name('zimu_zhaopin_setmeal')->where([['id','=',1]])->find();
        }else{
            $setmeal = Db::name('zimu_zhaopin_members_setmeal')->where([['uid','=',$myuid['uid']]])->find();
        }

        $jobs_num = Db::name('zimu_zhaopin_jobs')->where([['uid','=',$myuid['uid']]])->count();

        $res['zmdata']['total'] = $setmeal['jobs_meanwhile'] - $jobs_num;

        $res['zmdata']['add_jobs_price'] = $zmdata['settings']['add_jobs_price'];
        $res['zmdata']['jobs_money'] = $zmdata['settings']['jobs_money'];
        $res['zmdata']['wapfooter'] = $zmdata['settings']['wapfooterhtml'];
        $res['zmdata']['com_quickadd'] = $zmdata['settings']['com_quickadd'];
        $res['zmdata']['close_testmobile'] = $zmdata['settings']['close_testmobile'];

        $sms_paramter = Db::name('zimu_zhaopin_parameter2')->where('name', 'aliyunsms')->find();
        $sms_paramter = unserialize($sms_paramter['parameter']);
        if ($sms_paramter['smsAppKey']) {
            $res['zmdata']['showcode'] = 1;
        }else{
            $res['zmdata']['showcode'] = 0;
        }

        $job_input_paramter = Db::name('zimu_zhaopin_parameter2')->where([['name','=','job_input']])->find();
        $res['job_input'] = unserialize($job_input_paramter['parameter']);
        $res['job_input']['jobs_amount'] = $zmdata['settings']['jobs_amount'];
        $mag_paramter = Db::name('zimu_zhaopin_parameter2')->where('name', 'magapp')->find();
        $mag_paramter = unserialize($mag_paramter['parameter']);
        $res['magapp_hostname'] = $mag_paramter['magapp_hostname'];

        $com_input_paramter = Db::name('zimu_zhaopin_parameter2')->where([['name','=','com_input']])->find();
        $res['com_input'] = unserialize($com_input_paramter['parameter']);

        $agreement_paramter = Db::name('zimu_zhaopin_parameter2')->where('name', 'agreement')->find();
        $agreement_paramter = unserialize($agreement_paramter['parameter']);
        $res['zmdata']['agreement'] = $agreement_paramter['agreement'];
        if($zmdata['settings']['toutiao_audit']==1){
            $res['zmdata']['jobs_money'] = 0;
        }
        $res['myinfo'] = $myuid;

        zimu_json($res);

    }elseif($op == 'jobs_edit' ){

        $formtxt = json_decode(zimu_array_utf8($_GET['formtxt']),true);
        $formtxt = zimu_array_gbk($formtxt);
        $company_profile = Db::name('zimu_zhaopin_company_profile')->where([['uid','=',$myuid['uid']]])->find();

        if(!$company_profile){

            $sms_paramter = Db::name('zimu_zhaopin_parameter2')->where('name', 'aliyunsms')->find();
            $sms_paramter = unserialize($sms_paramter['parameter']);

            if(trim($formtxt['telephone']) != $myuid['telephone']){
                if ($sms_paramter['smsAppKey']) {
                    $telephone    = trim($formtxt['telephone']);
                    $mobile_vcode = trim($formtxt['code']);
                    if (!$mobile_vcode || $myuid['verify_code'] != $mobile_vcode) {
                        zimu_json('',$language_zimu['new_mycompany_inc_php_9'],202);
                    }
                }
            }

            Db::name('zimu_zhaopin_members')->where('uid', $myuid['uid'])->data(['telephone' => $formtxt['telephone']])->update();
            Db::name('common_member_profile')->where('uid', $myuid['uid'])->data(['mobile' => $formtxt['telephone']])->update();

            $i_company_profile['uid'] = $myuid['uid'];
            $i_company_profile['companyname'] = $formtxt['companyname'];
            $i_company_profile['address'] = $formtxt['address'];
            $i_company_profile['map_x'] = $formtxt['latitude'];
            $i_company_profile['map_y'] = $formtxt['longitude'];
            $i_company_profile['contact'] = $formtxt['contact'];
            $i_company_profile['telephone'] = $formtxt['telephone'];
            $i_company_profile['district'] = intval($formtxt['district'][0]).'.'.intval($formtxt['district'][1]).'.'.intval($formtxt['district'][2]);
            $i_company_profile['district_cn'] = $formtxt['district_cn'];
            $i_company_profile['logo'] = $company_nologo;
            $i_company_profile['logo'] = $_GET['logo'] ? $_GET['logo'] : $company_nologo;
            $i_company_profile['environment'] = $_GET['environment'] && $_GET['environment'] != 'undefined' ? $_GET['environment'] : '';
            if($_GET['certificate_img']){
                $i_company_profile['certificate_img'] = $_GET['certificate_img'];
            }
            $i_company_profile['addtime'] = time();
            $i_company_profile['refreshtime'] = time();
            $i_company_profile['logintime'] = time();
            $i_company_profile['audit'] = 2;

            $is_company_profile2 = Db::name('zimu_zhaopin_company_profile2')->where([['telephone','=',$i_company_profile['telephone']]])->find();

            if($is_company_profile2){
                $i_company_profile['kefu_uid'] = $is_company_profile2['kefu_uid'];
                $i_company_profile['kefu_name'] = $is_company_profile2['kefu_name'];
            }
            if($i_company_profile['uid']){
                $newids = Db::name('zimu_zhaopin_company_profile')->insertGetId($i_company_profile);
            }

            to_create_setmeal($myuid);
            if($is_company_profile2){
                $custom_feedback2 = Db::name('zimu_zhaopin_crm_custom_feedback2')->where([['custom_id','=',$is_company_profile2['id']]])->order(['id'=>'asc'])->select()->toArray();
                foreach ($custom_feedback2 as $key => $value) {
                    $custom_feedback = $value;
                    unset($custom_feedback['id']);
                    $custom_feedback['custom_id'] = $newids;
                    Db::name('zimu_zhaopin_crm_custom_feedback')->insert($custom_feedback);
                    Db::name('zimu_zhaopin_crm_custom_feedback2')->where([['id','=',$value['id']]])->delete();
                }
                $custom_feedback['custom_type'] = 1;
                $custom_feedback['custom_id'] = $newids;
                $custom_feedback['crm_uid'] = $is_company_profile2['kefu_uid'];
                $custom_feedback['type_id'] = 1;
                $custom_feedback['contact_name'] = $language_zimu['new_mycompany_inc_php_10'];
                $custom_feedback['add_time'] = time();
                $custom_feedback['comment'] = $is_company_profile2['contact'].$is_company_profile2['telephone'].$is_company_profile2['weixin'].$is_company_profile2['address'];
                Db::name('zimu_zhaopin_crm_custom_feedback')->insert($custom_feedback);
                Db::name('zimu_zhaopin_company_profile2')->where([['id','=',$is_company_profile2['id']]])->delete();
            }

        }

        $company_profile = Db::name('zimu_zhaopin_company_profile')->where([['uid','=',$myuid['uid']]])->find();



        $setsqlarr['uid']       = $myuid['uid'];
        $setsqlarr['jobs_name'] = $formtxt['jobs_name'];
        $setsqlarr['jobs_name'] = filterComment($setsqlarr['jobs_name'],$zmdata['settings']['notwords']);
        $setsqlarr['companyname'] = $company_profile['companyname'];
        $setsqlarr['company_id'] = $company_profile['id'];
        $setsqlarr['company_certificate'] = $company_profile['certificate_img_audit'];
        $setsqlarr['company_mingqi'] = $company_profile['company_mingqi'];
        $setsqlarr['nature'] = $formtxt['nature'];
        $setsqlarr['nature_cn'] = $formtxt['nature_cn'];
        $setsqlarr['sex'] = $formtxt['sex'];
        $setsqlarr['sex_cn'] = $formtxt['sex_cn'] ? $formtxt['sex_cn'] : $language_zimu['new_mycompany_inc_php_11'];
        $setsqlarr['amount'] = $formtxt['amount'];
        $setsqlarr['topclass'] = $formtxt['jobcat'][0];
        $setsqlarr['category'] = $formtxt['jobcat'][1];
        $setsqlarr['subclass'] = $formtxt['jobcat'][2];
        $setsqlarr['category_cn'] = $formtxt['jobcat_cn'];
        $setsqlarr['trade'] = $company_profile['trade'];
        $setsqlarr['trade_cn'] = $company_profile['trade_cn'];
        $setsqlarr['scale'] = $company_profile['scale'];
        $setsqlarr['scale_cn'] = $company_profile['scale_cn'];
        $setsqlarr['district'] = $formtxt['district'][0];
        $setsqlarr['district2'] = $formtxt['district'][1];
        $setsqlarr['district3'] = $formtxt['district'][2];
        $setsqlarr['district_cn'] = $formtxt['district_cn'];
        $setsqlarr['tag'] = implode(',',$formtxt['tag']);
        $setsqlarr['tag_cn'] = implode(',',$formtxt['tag_cn']);
        $setsqlarr['education'] = $formtxt['education'];
        $setsqlarr['education_cn'] = $formtxt['education_cn'] ? $formtxt['education_cn'] : $language_zimu['new_mycompany_inc_php_12'];
        $setsqlarr['experience'] = $formtxt['experience'];
        $setsqlarr['experience_cn'] = $formtxt['experience_cn'] ? $formtxt['experience_cn'] : $language_zimu['new_mycompany_inc_php_13'];
        $setsqlarr['minwage'] = $formtxt['minwage'];
        $setsqlarr['maxwage'] = $formtxt['maxwage'];
        if( ($setsqlarr['minwage'] || $setsqlarr['maxwage']) && $setsqlarr['minwage'] != $setsqlarr['maxwage']){
            $setsqlarr['wage_cn'] = $setsqlarr['minwage'].'~'.$setsqlarr['maxwage'].$zmdata['settings']['money_name'].'/'.$language_zimu['new_mycompany_inc_php_14'];
        }elseif( ($setsqlarr['minwage'] || $setsqlarr['maxwage']) && $setsqlarr['minwage'] == $setsqlarr['maxwage']){
            $setsqlarr['wage_cn'] = $setsqlarr['minwage'].$zmdata['settings']['money_name'].'/'.$language_zimu['new_mycompany_inc_php_15'];
        }else{
            $setsqlarr['wage_cn'] = $language_zimu['new_mycompany_inc_php_16'];
        }
        $setsqlarr['contents'] = $formtxt['contents'];
        $setsqlarr['contents'] = preg_replace('/([0-9]{11,})|([0-9]{3,4}-[0-9]{7,10})|([0-9]{3,4}-[0-9]{2,5}-[0-9]{2,5})/', '', $setsqlarr['contents']);
        $setsqlarr['contents'] = filterComment($setsqlarr['contents'],$zmdata['settings']['notwords']);
        $setsqlarr['uptime'] = time();
        $setsqlarr['setmeal_id'] = $company_profile['setmeal_id'];
        $setsqlarr['setmeal_name'] = $company_profile['setmeal_name'];
        $setsqlarr['parttime_type']          = intval($formtxt['parttime_type']);
        $setsqlarr['parttime_money']       = addslashes($formtxt['parttime_money']);
        if($formtxt['contact'] != $company_profile['contact'] || $formtxt['telephone'] != $company_profile['telephone']){
            $setsqlarr['contact']          = $formtxt['contact'];
            $setsqlarr['telephone']       = $formtxt['telephone'];
        }

        if($ids){

            if($company_profile['setmeal_id'] > 1 && $zmdata['settings']['com_money_audit']==1){
                $setsqlarr['audit'] = 1;
                Db::name('zimu_zhaopin_jobs')->where([['id','=',$ids],['uid','=',$myuid['uid']]])->update($setsqlarr);
            }elseif($zmdata['settings']['job_edit_audit']==0){
                $oldinfo = Db::name('zimu_zhaopin_jobs')->where([['id','=',$ids]])->find();
                $diff_info = array_merge($oldinfo,$setsqlarr);
                $diff_info2 = array_diff_assoc($diff_info,$oldinfo);
            }else{
                Db::name('zimu_zhaopin_jobs')->where([['id','=',$ids],['uid','=',$myuid['uid']]])->update($setsqlarr);
            }

            if($diff_info2){

                $isadd = Db::name('zimu_zhaopin_jobs_audit')->where('ids', $ids)->find();

                if(!$isadd){
                    $setsqlarr['ids'] = $ids;
                    Db::name('zimu_zhaopin_jobs_audit')->insertGetId($setsqlarr);
                }else{
                    Db::name('zimu_zhaopin_jobs_audit')->where('ids', $ids)->update($setsqlarr);
                }

                $tip = $language_zimu['new_mycompany_inc_php_17'];
                $keyword1 = $setsqlarr['jobs_name'].$setsqlarr['wage_cn'].$setsqlarr['companyname'].$setsqlarr['contact'].$setsqlarr['telephone'];
                $remark = $language_zimu['new_mycompany_inc_php_18'];
                $templatedata['first']['value'] = $tip;
                $templatedata['first']['color'] = "#FF4040";
                $templatedata['keyword1']['value'] = $keyword1;
                $templatedata['keyword2']['value'] = date('Y-m-d H:i', time());
                $templatedata['remark']['value'] = $remark;
                $apptpl['magapp']['tag'] = $tip;
                $apptpl['magapp']['title'] = $keyword1;
                $apptpl['magapp']['des'] = $remark;
                $apptpl['qfapp']['msg'] = $apptpl['magapp']['tag'];
                $apptpl['qfapp']['title'] = $apptpl['magapp']['title'];
                $apptpl['qfapp']['content'] = $apptpl['magapp']['des'];
                $tourl = $_G['siteurl'].'source/plugin/zimu_zhaopin/h5/pages/jobs/view?ids='.$ids.'&mobile=2';
                $link = $_G['siteurl'].'plugin.php?id=zimu_zhaopin:new&model=newindex&tourl='.urlencode($tourl);
                notification_all('admin','wxtpl_admin',$templatedata,$apptpl,$link);

            }

        }else{

            $jobs_num = Db::name('zimu_zhaopin_jobs')->where([['uid','=',$myuid['uid']]])->count();
            $setmeal = Db::name('zimu_zhaopin_members_setmeal')->where([['uid','=',$myuid['uid']]])->find();
            $total = $setmeal['jobs_meanwhile'] - $jobs_num;

            if ($total <= 0 && $company_profile && !$zmdata['settings']['add_jobs_price']) {
                zimu_json('',$language_zimu['new_mycompany_inc_php_19'],202);
            }

            if ($total <= 0 && $zmdata['settings']['add_jobs_price'] > 0) {
                $setsqlarr['audit'] = 3;
                $setsqlarr['ispay'] = 1;
            } else if($company_profile['setmeal_id']>1) {
                $setsqlarr['audit'] = 1;
            }else{
                $setsqlarr['audit'] = $zmdata['settings']['job_new_audit'] == 1 ? 1 : 2;
            }
            $setsqlarr['addtime']     = time();
            $setsqlarr['refreshtime'] = time();
            $newids = Db::name('zimu_zhaopin_jobs')->insertGetId($setsqlarr);

            $tip = $language_zimu['new_mycompany_inc_php_20'];
            $keyword1 = $setsqlarr['jobs_name'].$setsqlarr['wage_cn'].$setsqlarr['companyname'].$setsqlarr['contact'].$setsqlarr['telephone'];
            $remark = $language_zimu['new_mycompany_inc_php_21'];
            $templatedata['first']['value'] = $tip;
            $templatedata['first']['color'] = "#FF4040";
            $templatedata['keyword1']['value'] = $keyword1;
            $templatedata['keyword2']['value'] = date('Y-m-d H:i', time());
            $templatedata['remark']['value'] = $remark;
            $apptpl['magapp']['tag'] = $tip;
            $apptpl['magapp']['title'] = $keyword1;
            $apptpl['magapp']['des'] = $remark;
            $apptpl['qfapp']['msg'] = $apptpl['magapp']['tag'];
            $apptpl['qfapp']['title'] = $apptpl['magapp']['title'];
            $apptpl['qfapp']['content'] = $apptpl['magapp']['des'];
            $tourl = $_G['siteurl'].'source/plugin/zimu_zhaopin/h5/pages/jobs/view?ids='.$newids.'&mobile=2';
            $link = $_G['siteurl'].'plugin.php?id=zimu_zhaopin:new&model=newindex&tourl='.urlencode($tourl);
            notification_all('admin','wxtpl_admin',$templatedata,$apptpl,$link);

        }

        $service_id = $formtxt['stick_index'];
        if ($service_id) {
            $service_info = Db::name('zimu_zhaopin_setmeal_increment')->where([['cat','=','stick'],['id','=',$service_id]])->order('id', 'desc')->find();
        }
        if ($service_info) {

            $my_setmeal = Db::name('zimu_zhaopin_members_setmeal')->where([['uid','=',$myuid['uid']]])->find();

            $my_discount = $my_setmeal;
            $new_price   = $my_discount['discount_stick'] > 0 ? round($service_info['price'] * $my_discount['discount_stick'] / 10, 2) : $service_info['price'];
            if ($setsqlarr['ispay'] == 1) {
                $new_price = $new_price + round($zmdata['settings']['add_jobs_price'], 2);
            }
            $params['oid']        = date('YmdHis') . mt_rand(100000, 999999);
            $params['zpid']       = $newids;
            $params['uid']        = $myuid['uid'];
            $params['openid']     = $myuid['openid'];
            $params['utype']      = 1;
            $params['order_type'] = 8;
            $params['pay_type']   = 2;
            $params['is_paid']    = 1;
            $params['amount']     = $new_price;
            $params['pay_amount'] = $new_price;
            $params['payment']    = 'wxpay';
            $params['payment_cn'] = $language_zimu['new_mycompany_inc_php_22'];
            if ($setsqlarr['ispay'] == 1) {
                $params['description']  = $service_info['name'] . '+'.$language_zimu['new_mycompany_inc_php_23'];
                $params['service_name'] = 'jobs_pay_add';
            } else {
                $params['description']  = $service_info['name'];
                $params['service_name'] = 'jobs_stick';
            }
            $params_array            = array(
                'days' => $service_info['value']
            );
            $params_array['jobs_id'] = $newids;
            $params['params']        = serialize($params_array);
            $params['addtime']       = time();
            $params['setmeal']       = $service_id;
            $params['discount']      = $language_zimu['new_mycompany_inc_php_24'] . $my_discount['discount_stick'] . $language_zimu['new_mycompany_inc_php_25'];

            $return_order_info['order_id'] = Db::name('zimu_zhaopin_order')->insertGetId($params);
            zimu_json($return_order_info);

        }

        if ($setsqlarr['ispay'] == 1) {

            $params['oid']           = date('YmdHis') . mt_rand(100000, 999999);
            $params['zpid']          = $newids;
            $params['uid']           = $myuid['uid'];
            $params['openid']        = $myuid['openid'];
            $params['utype']         = 1;
            $params['order_type']    = 15;
            $params['pay_type']      = 2;
            $params['is_paid']       = 1;
            $params['amount']        = round($zmdata['settings']['add_jobs_price'], 2);
            $params['pay_amount']    = round($zmdata['settings']['add_jobs_price'], 2);
            $params['payment']       = 'wxpay';
            $params['payment_cn']    = $language_zimu['new_mycompany_inc_php_26'];
            $params['description']   = $language_zimu['new_mycompany_inc_php_27'];
            $params['service_name']  = 'jobs_pay_add';
            $params_array['jobs_id'] = $newids;
            $params['params']        = serialize($params_array);
            $params['addtime']       = time();

            $return_order_info['order_id'] = Db::name('zimu_zhaopin_order')->insertGetId($params);
            zimu_json($return_order_info);

        }

        zimu_json($res);

    }elseif($op == 'jobs_list' ){

        $type = intval($_GET['type']);
        $whereraw = '1=1';
        $wherearr[] = ['uid','=',$myuid['uid']];
        if ($type == 1) {
            $wherearr[] = ['audit','<>',3];
            $wherearr[] = ['display','<>',2];
        } elseif ($type == 2) {
            $whereraw = 'audit = 3 or display = 2';
        } elseif ($type == 3) {
            $wherearr[] = ['audit','<>',3];
            $wherearr[] = ['display','<>',2];
            $wherearr[] = ['stick_endtime','>',time()];
        }
        $res['jobs_list'] = Db::name('zimu_zhaopin_jobs')->where($wherearr)->whereRaw($whereraw)->order('id', 'desc')->select()->toArray();

        foreach ($res['jobs_list'] as $key => $value) {
            $res['jobs_list'][$key]['has_auto'] = Db::name('zimu_zhaopin_queue_auto_refresh')->where([['type','=',1],['pid','=',$value['id']]])->order(['id'=>'desc'])->find();
            $where_matching = [];
            if($value['sex']){
                $where_matching[] = ['sex','=',$value['sex']];
            }
            if($value['experience']){
                $where_matching[] = ['experience','>=',$value['experience']];
            }
            if($value['education']){
                $where_matching[] = ['education','>=',$value['education']];
            }
            if($value['topclass']){
                $where_matching[] = ['intention_jobs_id','like','%'.$value['topclass'].'.%'];
            }
            $res['jobs_list'][$key]['matching'] = Db::name('zimu_zhaopin_resume')->where($where_matching)->count();
            $res['jobs_list'][$key]['auditinfo'] = Db::name('zimu_zhaopin_jobs_audit')->where([['ids','=',$value['id']]])->find();
        }

        $setmeal = Db::name('zimu_zhaopin_members_setmeal')->where([['uid','=',$myuid['uid']]])->find();

        $res['sticklist'] = Db::name('zimu_zhaopin_setmeal_increment')->where([['cat','=','stick']])->order(['sort'=>'desc','id'=>'asc'])->select()->toArray();

        foreach ($res['sticklist'] as $key => $value) {
            if($setmeal['discount_stick']>0){
                $res['sticklist2'][$key]['text'] = $value['name'];
                $res['sticklist2'][$key]['description'] = $language_zimu['new_mycompany_inc_php_28'].round($value['price']*$setmeal['discount_stick']/10,2).$zmdata['settings']['money_name'].$language_zimu['new_mycompany_inc_php_29'].round($value['price']*$setmeal['discount_stick']/10/$value['value'],2).$zmdata['settings']['money_name'].'/'.$language_zimu['new_mycompany_inc_php_30'].'('.$language_zimu['new_mycompany_inc_php_31'].$value['price'].$zmdata['settings']['money_name'].')';
            }else{
                $res['sticklist2'][$key]['text'] = $value['name'];
                $res['sticklist2'][$key]['description'] = $language_zimu['new_mycompany_inc_php_32'].round($value['price']/$value['value'],2).$zmdata['settings']['money_name'].'/'.$language_zimu['new_mycompany_inc_php_33'].'('.$language_zimu['new_mycompany_inc_php_34'].$value['price'].$zmdata['settings']['money_name'].')';
            }
        }

        $res['autorefresh'] = Db::name('zimu_zhaopin_setmeal_increment')->where([['cat','=','auto_refresh_jobs']])->order(['sort'=>'desc','id'=>'asc'])->select()->toArray();

        foreach ($res['autorefresh'] as $key => $value) {
            if($setmeal['discount_auto_refresh_jobs']>0){
                $res['autorefresh2'][$key]['text'] = $value['name'];
                $res['autorefresh2'][$key]['description'] = $language_zimu['new_mycompany_inc_php_35'].round($value['price']*$setmeal['discount_auto_refresh_jobs']/10,2).$zmdata['settings']['money_name'].$language_zimu['new_mycompany_inc_php_36'].round($value['price']*$setmeal['discount_auto_refresh_jobs']/10/$value['value'],2).$zmdata['settings']['money_name'].'/'.$language_zimu['new_mycompany_inc_php_37'].'('.$language_zimu['new_mycompany_inc_php_38'].$value['price'].$zmdata['settings']['money_name'].')';
            }else{
                $res['autorefresh2'][$key]['text'] = $value['name'];
                $res['autorefresh2'][$key]['description'] = $language_zimu['new_mycompany_inc_php_39'].round($value['price']/$value['value'],2).$zmdata['settings']['money_name'].'/'.$language_zimu['new_mycompany_inc_php_40'].'('.$language_zimu['new_mycompany_inc_php_41'].$value['price'].$zmdata['settings']['money_name'].')';
            }
        }

        $res['zmdata']['toutiao_audit'] = $zmdata['settings']['toutiao_audit'];

        zimu_json($res);

    }elseif($op == 'close_job' ){

        Db::name('zimu_zhaopin_jobs')->where([['uid','=',$myuid['uid']],['id','=',$ids]])->data(['display' => 2])->update();

        zimu_json($res);

    }elseif($op == 'open_job' ){

        Db::name('zimu_zhaopin_jobs')->where([['uid','=',$myuid['uid']],['id','=',$ids]])->data(['display' => 1])->update();

        zimu_json($res);

    }elseif($op == 'jobs_refresh_all' ){

        $jobsid_arr = Db::name('zimu_zhaopin_jobs')->where([['uid','=',$myuid['uid']],['audit','<>',3],['display','<>',2]])->select()->toArray();

        $user_jobs = count($jobsid_arr);

        if ($user_jobs == 0) {
            $res['type'] = 'error';
            $res['tip'] = $language_zimu['new_mycompany_inc_php_42'];
            zimu_json($res);
        }

        $my_setmeal = Db::name('zimu_zhaopin_members_setmeal')->where([['uid','=',$myuid['uid']]])->find();

        $refresh_time = Db::name('zimu_zhaopin_refresh_log')->where([['uid','=',$myuid['uid']],['type','=',1001],['mode','=',2],['addtime','>',strtotime(date('Y-m-d', time()))]])->count();

        if ($user_jobs + $refresh_time > $my_setmeal['refresh_jobs_free']) {
            $surplus = $my_setmeal['refresh_jobs_free'] - $refresh_time;
            $res['type'] = 'no_refresh_nums';
            $res['tip'] = $language_zimu['new_mycompany_inc_php_43'] . ' <span class="font_yellow">' . $user_jobs . '</span> ' . $language_zimu['new_mycompany_inc_php_44'] . ' <span class="font_yellow">' . $surplus . '</span> ' . $language_zimu['new_mycompany_inc_php_45'];
            zimu_json($res);
        } else {


            $yid = array();
            foreach ($jobsid_arr as $key => $value) {
                $yid[] = $value['id'];
                $setsqlarr2['uid']     = $myuid['uid'];
                $setsqlarr2['mode']    = 2;
                $setsqlarr2['addtime'] = time();
                $setsqlarr2['type']    = 1001;
                Db::name('zimu_zhaopin_refresh_log')->insert($setsqlarr2);
            }

            Db::name('zimu_zhaopin_jobs')->where([['uid','=',$myuid['uid']],['id','in',$yid]])->data(['refreshtime' => time()])->update();

            $res['type'] = 'success';
            $res['tip'] = $language_zimu['new_mycompany_inc_php_46'];
            zimu_json($res);

        }


    }elseif($op == 'del_job' ){

        Db::name('zimu_zhaopin_jobs')->where([['uid','=',$myuid['uid']],['id','=',$ids]])->delete();
        Db::name('zimu_zhaopin_company_interview')->where([['company_uid','=',$myuid['uid']],['jobs_id','=',$ids]])->delete();
        Db::name('zimu_zhaopin_personal_favorites')->where([['company_uid','=',$myuid['uid']],['jobs_id','=',$ids]])->delete();
        Db::name('zimu_zhaopin_personal_jobs_apply')->where([['company_uid','=',$myuid['uid']],['jobs_id','=',$ids]])->delete();
        Db::name('zimu_zhaopin_per_viewlog')->where([['jid','=',$ids]])->delete();
        zimu_json($res);

    }elseif($op == 'resume_favorites' ){

        $res['explist'] = Db::name('zimu_zhaopin_category')->field('c_id as id,c_name as name')->where([['c_alias','=','ZM_experience']])->order(['c_order'=>'asc','c_id'=>'asc'])->select()->toArray();
        array_shift($res['explist']);
        $res['edulist'] = Db::name('zimu_zhaopin_category')->field('c_id as id,c_name as name')->where([['c_alias','=','ZM_education']])->order(['c_order'=>'asc','c_id'=>'asc'])->select()->toArray();

        $selecttxt = json_decode(zimu_array_utf8($_GET['selecttxt']),true);
        $selecttxt = zimu_array_gbk($selecttxt);

        $wheresql2[] = ['company_uid','=',$myuid['uid']];
        if($selecttxt['diy1']){
            $wheresql2[] = ['a.education','=',$selecttxt['diy1']];
        }
        if($selecttxt['diy2']){
            $wheresql2[] = ['a.experience','=',$selecttxt['diy2']];
        }

        $res['plists'] = Db::name('zimu_zhaopin_resume')->alias('a')->join('zimu_zhaopin_company_favorites b','b.resume_id = a.id')->where([$wheresql2])->select()->toArray();

        foreach ($res['plists'] as $key => $value) {
            if ($res['plists'][$key]['tag_cn']) {
                $res['plists'][$key]['tag_cn2'] = explode(',',$res['plists'][$key]['tag_cn']);
            }
            if($value['sex']==1){
                $res['plists'][$key]['fullname'] = cutstr($value['fullname'],2,'').$language_zimu['new_mycompany_inc_php_47'];
                $res['plists'][$key]['photo_img'] = $value['photo_img'] ? $value['photo_img'] : ZIMUCMS_PATH.'static/wap/images/no_photo_male.png';
            }else{
                $res['plists'][$key]['fullname'] = cutstr($value['fullname'],2,'').$language_zimu['new_mycompany_inc_php_48'];
                $res['plists'][$key]['photo_img'] = $value['photo_img'] ? $value['photo_img'] : ZIMUCMS_PATH.'static/wap/images/no_photo_female.png';
            }
            $res['plists'][$key]['refreshtime'] = $value['favorites_addtime'];
        }

        zimu_json($res);

    }elseif($op == 'resume_down' ){

        $res['diy1list'][0] = array('id'=>'1','name'=>$language_zimu['new_mycompany_inc_php_49']);
        $res['diy1list'][1] = array('id'=>'2','name'=>$language_zimu['new_mycompany_inc_php_50']);
        $res['diy1list'][2] = array('id'=>'3','name'=>$language_zimu['new_mycompany_inc_php_51']);
        $res['diy1list'][3] = array('id'=>'4','name'=>$language_zimu['new_mycompany_inc_php_52']);

        $selecttxt = json_decode(zimu_array_utf8($_GET['selecttxt']),true);
        $selecttxt = zimu_array_gbk($selecttxt);

        $wheresql2[] = ['b.company_uid','=',$myuid['uid']];
        if($selecttxt['diy1']){
            $wheresql2[] = ['b.is_reply','=',$selecttxt['diy1']];
        }

        $res['plists'] = Db::name('zimu_zhaopin_resume')->alias('a')->join('zimu_zhaopin_company_down_resume b','b.resume_id = a.id')->where([$wheresql2])->order(['did'=>'desc'])->select()->toArray();

        foreach ($res['plists'] as $key => $value) {
            if ($res['plists'][$key]['tag_cn']) {
                $res['plists'][$key]['tag_cn2'] = explode(',',$res['plists'][$key]['tag_cn']);
            }
            if($value['sex']==1){
                $res['plists'][$key]['photo_img'] = $value['photo_img'] ? $value['photo_img'] : ZIMUCMS_PATH.'static/wap/images/no_photo_male.png';
            }else{
                $res['plists'][$key]['photo_img'] = $value['photo_img'] ? $value['photo_img'] : ZIMUCMS_PATH.'static/wap/images/no_photo_female.png';
            }
            if($value['is_reply']==1){
                $res['plists'][$key]['reply_cn'] = $language_zimu['new_mycompany_inc_php_53'];
            }elseif ($value['is_reply']==2){
                $res['plists'][$key]['reply_cn'] = $language_zimu['new_mycompany_inc_php_54'];
            }elseif ($value['is_reply']==3){
                $res['plists'][$key]['reply_cn'] = $language_zimu['new_mycompany_inc_php_55'];
            }elseif ($value['is_reply']==4){
                $res['plists'][$key]['reply_cn'] = $language_zimu['new_mycompany_inc_php_56'];
            }
            $res['plists'][$key]['refreshtime'] = $value['down_addtime'];
            $res['plists'][$key]['interview'] = Db::name('zimu_zhaopin_company_interview')->where([['company_uid','=',$myuid['uid']],['resume_id','=',$value['id']]])->order(['id'=>'desc'])->find();
        }

        zimu_json($res);

    }elseif($op == 'state_resume_down' ){

        $state = intval($_GET['state']);

        Db::name('zimu_zhaopin_company_down_resume')->where([['company_uid','=',$myuid['uid']],['resume_id','=',$ids]])->data(['is_reply' => $state])->update();

        zimu_json($res);

    }elseif($op == 'jobs_interview_add' ){

        $res['resume'] = Db::name('zimu_zhaopin_resume')->where([['id','=',$ids]])->order(['addtime'=>'desc'])->findOrEmpty();
        $res['mycompany'] = Db::name('zimu_zhaopin_company_profile')->where([['uid','=',$myuid['uid']]])->order(['addtime'=>'desc'])->findOrEmpty();
        $res['myjobs'] = Db::name('zimu_zhaopin_jobs')->field('id as value,jobs_name as label,contact,telephone')->where([['audit','<>',3],['display','<>',2],['uid','=',$myuid['uid']]])->order(['id'=>'desc'])->select()->toArray();
        $res['interview'] = Db::name('zimu_zhaopin_company_interview')->where([['company_uid','=',$myuid['uid']],['resume_id','=',$ids]])->order(['id'=>'desc'])->find();
        zimu_json($res);

    }elseif($op == 'jobs_interview_add2' ){

        $formtxt = json_decode(zimu_array_utf8($_GET['formtxt']),true);
        $formtxt = zimu_array_gbk($formtxt);

        $resume = Db::name('zimu_zhaopin_resume')->where([['id','=',$ids]])->order(['addtime'=>'desc'])->findOrEmpty();
        $jobs = Db::name('zimu_zhaopin_jobs')->where([['id','=',$formtxt['jobs_id']]])->order(['addtime'=>'desc'])->findOrEmpty();

        $company_interview_data['resume_id'] = $ids;
        $company_interview_data['resume_name'] = $resume['fullname'];
        $company_interview_data['resume_uid'] = $resume['uid'];
        $company_interview_data['jobs_id'] = $formtxt['jobs_id'];
        $company_interview_data['jobs_name'] = $jobs['jobs_name'];
        $company_interview_data['company_id'] = $jobs['company_id'];
        $company_interview_data['company_name'] = $jobs['companyname'];
        $company_interview_data['company_uid'] = $jobs['uid'];
        $company_interview_data['address'] = $formtxt['address'];
        $company_interview_data['contact'] = $formtxt['contact'];
        $company_interview_data['telephone'] = $formtxt['telephone'];
        $company_interview_data['interview_time'] = $formtxt['intime'];
        $company_interview_data['notes'] = $formtxt['notes'] ? $formtxt['notes'] : $language_zimu['new_mycompany_inc_php_57'];
        $company_interview_data['interview_addtime'] = time();
        Db::name('zimu_zhaopin_company_interview')->insert($company_interview_data);

        $paramter = Db::name('zimu_zhaopin_parameter2')->where('name', 'wxtpl')->find();
        $paramters = unserialize($paramter['parameter']);


        $tip = $jobs['companyname'].$language_zimu['new_mycompany_inc_php_58'];
        $find = ['jobs_name','company_name','interview_time','address','contact','telephone','notes'];
        $replace = [$company_interview_data['jobs_name'],$company_interview_data['company_name'],$company_interview_data['interview_time'],zimu_cutstr($company_interview_data['address'],20),$company_interview_data['contact'],$company_interview_data['telephone'],zimu_cutstr($company_interview_data['notes'],20)];
        notification_user_sms($resume['telephone'],'chanyoo_sms_tp2',$find,$replace);

        $templatedata['first']['value'] = $tip;
        $templatedata['first']['color'] = "#FF4040";
        $templatedata['job']['value'] = $jobs['jobs_name'];
        $templatedata['company']['value'] = $jobs['companyname'];
        $templatedata['time']['value'] = $formtxt['intime'];
        $templatedata['address']['value'] = $formtxt['address'];
        $templatedata['contact']['value'] = $formtxt['contact'];
        $templatedata['tel']['value'] = $formtxt['telephone'];
        $templatedata['remark']['value'] = $jobs['companyname'].$language_zimu['new_mycompany_inc_php_59'].$formtxt['notes'];
        $apptpl['magapp']['tag'] = $tip;
        $apptpl['magapp']['title'] = $language_zimu['new_mycompany_inc_php_60'].$formtxt['intime'].$language_zimu['new_mycompany_inc_php_61'].$formtxt['telephone'].$language_zimu['new_mycompany_inc_php_62'].$formtxt['telephone'].$language_zimu['new_mycompany_inc_php_63'].$formtxt['address'];
        $apptpl['magapp']['des'] = $jobs['companyname'].$language_zimu['new_mycompany_inc_php_64'].$formtxt['notes'];
        $apptpl['qfapp']['msg'] = $apptpl['magapp']['tag'];
        $apptpl['qfapp']['title'] = $apptpl['magapp']['title'];
        $apptpl['qfapp']['content'] = $apptpl['magapp']['des'];
        $tourl = $_G['siteurl'].'source/plugin/zimu_zhaopin/h5/pages/jobs/view?ids='.$formtxt['jobs_id'];
        $link = $_G['siteurl'].'plugin.php?id=zimu_zhaopin:new&model=newindex&tourl='.urlencode($tourl);
        notification_all($resume['uid'],'wxtpl_jobs_mianshi',$templatedata,$apptpl,$link);

        zimu_json($res);

    }elseif($op == 'jobs_apply' ){

        $res['diy2list'][0] = array('id'=>'1','name'=>$language_zimu['new_mycompany_inc_php_65']);
        $res['diy2list'][1] = array('id'=>'2','name'=>$language_zimu['new_mycompany_inc_php_66']);
        $res['diy2list'][2] = array('id'=>'3','name'=>$language_zimu['new_mycompany_inc_php_67']);

        $selecttxt = json_decode(zimu_array_utf8($_GET['selecttxt']),true);
        $selecttxt = zimu_array_gbk($selecttxt);

        $wheresql2[] = ['b.company_uid','=',$myuid['uid']];
        if($selecttxt['diy1']){
            $wheresql2[] = ['b.jobs_id','=',$selecttxt['diy1']];
        }
        if($selecttxt['diy2']){
            $wheresql2[] = ['b.is_reply','=',$selecttxt['diy2']];
            $res['plists'] = Db::name('zimu_zhaopin_resume')->alias('a')->join('zimu_zhaopin_personal_jobs_apply b','b.resume_id = a.id')->where([$wheresql2])->order(['did'=>'desc'])->select()->toArray();
        }else{

            $plists1 = Db::name('zimu_zhaopin_resume')->alias('a')->join('zimu_zhaopin_personal_jobs_apply b','b.resume_id = a.id')->where([$wheresql2])->where([['b.is_reply','=',0]])->order(['did'=>'desc'])->select()->toArray();

            $plists2 = Db::name('zimu_zhaopin_resume')->alias('a')->join('zimu_zhaopin_personal_jobs_apply b','b.resume_id = a.id')->where([$wheresql2])->where([['b.is_reply','>',0]])->order(['did'=>'desc'])->select()->toArray();

            $res['plists'] = array_merge($plists1,$plists2);

        }

        foreach ($res['plists'] as $key => $value) {
            if ($res['plists'][$key]['tag_cn']) {
                $res['plists'][$key]['tag_cn2'] = explode(',',$res['plists'][$key]['tag_cn']);
            }
            if($value['sex']==1){
                $res['plists'][$key]['photo_img'] = $value['photo_img'] ? $value['photo_img'] : ZIMUCMS_PATH.'static/wap/images/no_photo_male.png';
            }else{
                $res['plists'][$key]['photo_img'] = $value['photo_img'] ? $value['photo_img'] : ZIMUCMS_PATH.'static/wap/images/no_photo_female.png';
            }
            if($value['is_reply']==1){
                $res['plists'][$key]['reply_cn'] = $language_zimu['new_mycompany_inc_php_68'];
            }elseif ($value['is_reply']==2){
                $res['plists'][$key]['reply_cn'] = $language_zimu['new_mycompany_inc_php_69'];
            }elseif ($value['is_reply']==3){
                $res['plists'][$key]['reply_cn'] = $language_zimu['new_mycompany_inc_php_70'];
            }elseif ($value['is_reply']==0){
                $res['plists'][$key]['reply_cn'] = $language_zimu['new_mycompany_inc_php_71'];
            }
            $res['plists'][$key]['refreshtime'] = $value['apply_addtime'];
            $res['plists'][$key]['isdown'] = Db::name('zimu_zhaopin_company_down_resume')->where([['company_uid','=',$myuid['uid']],['resume_id','=',$value['id']]])->order(['did'=>'desc'])->find();
        }

        $res['myjobs'] = Db::name('zimu_zhaopin_jobs')->field('id,jobs_name as name')->where([['audit','<>',3],['display','<>',2],['uid','=',$myuid['uid']]])->order(['id'=>'desc'])->select()->toArray();

        zimu_json($res);

    }elseif($op == 'state_jobs_apply' ){

        $did = intval($_GET['did']);
        $state = intval($_GET['state']);

        Db::name('zimu_zhaopin_personal_jobs_apply')->where([['company_uid','=',$myuid['uid']],['did','=',$did]])->data(['personal_look' => 2,'is_reply' => $state,'reply_time' => time()])->update();


        if($state==2){

            $applydata = Db::name('zimu_zhaopin_personal_jobs_apply')->where([['did','=',$did]])->order(['did'=>'desc'])->find();
            $tip = $language_zimu['new_mycompany_inc_php_72'];
            $templatedata['first']['value'] = $tip;
            $templatedata['first']['color'] = "#FF4040";
            $templatedata['keyword1']['value'] = $language_zimu['new_mycompany_inc_php_73'].$applydata['jobs_name'].'('.$applydata['company_name'].')'.$language_zimu['new_mycompany_inc_php_74'];
            $templatedata['keyword2']['value'] = date('Y-m-d H:i',time());
            $templatedata['remark']['value'] = $language_zimu['new_mycompany_inc_php_75'];
            $apptpl['magapp']['tag'] = $tip;
            $apptpl['magapp']['title'] = $templatedata['keyword1']['value'];
            $apptpl['magapp']['des'] = $templatedata['remark']['value'];
            $apptpl['qfapp']['msg'] = $apptpl['magapp']['tag'];
            $apptpl['qfapp']['title'] = $apptpl['magapp']['title'];
            $apptpl['qfapp']['content'] = $apptpl['magapp']['des'];
            $tourl = $_G['siteurl'].'source/plugin/zimu_zhaopin/h5/?mobile=2';
            $link = $_G['siteurl'].'plugin.php?id=zimu_zhaopin:new&model=newindex&tourl='.urlencode($tourl);
            notification_all($applydata['personal_uid'],'wxtpl_admin',$templatedata,$apptpl,$link);

        }


        zimu_json($res);

    }elseif($op == 'jobs_interview' ){

        $selecttxt = json_decode(zimu_array_utf8($_GET['selecttxt']),true);
        $selecttxt = zimu_array_gbk($selecttxt);

        if($selecttxt['diy1']){
            $plist = Db::name('zimu_zhaopin_company_interview')->where([['company_uid','=',$myuid['uid']],['jobs_id','=',$selecttxt['diy1']]])->order(['interview_addtime'=>'desc'])->select()->toArray();
        }else{
            $plist = Db::name('zimu_zhaopin_company_interview')->where([['company_uid','=',$myuid['uid']]])->order(['interview_addtime'=>'desc'])->select()->toArray();
        }
        foreach ($plist as $key => $value) {
            $res['plists'][$key] = Db::name('zimu_zhaopin_resume')->where([['uid','=',$value['resume_uid']]])->order(['addtime'=>'desc'])->findOrEmpty();
            if ($res['plists'][$key]['tag_cn']) {
                $res['plists'][$key]['tag_cn2'] = explode(',',$res['plists'][$key]['tag_cn']);
            }
            $res['plists'][$key]['refreshtime'] = $value['interview_addtime'];
            $res['plists'][$key]['interview'] = $value;
        }

        $res['myjobs'] = Db::name('zimu_zhaopin_jobs')->field('id,jobs_name as name')->where([['audit','<>',3],['display','<>',2],['uid','=',$myuid['uid']]])->order(['id'=>'desc'])->select()->toArray();


        zimu_json($res);

    }elseif($op == 'jobs_resume' ){


        $job_info = Db::name('zimu_zhaopin_jobs')->where([['id','=',$ids]])->order(['id'=>'desc'])->find();
        $where_matching = [];
        if($job_info['sex']){
            $where_matching[] = ['sex','=',$job_info['sex']];
        }
        if($job_info['experience']){
            $where_matching[] = ['experience','>=',$job_info['experience']];
        }
        if($job_info['education']){
            $where_matching[] = ['education','>=',$job_info['education']];
        }
        if($job_info['topclass']){
            $where_matching[] = ['intention_jobs_id','like','%'.$job_info['topclass'].'.%'];
        }
        $where_matching[] = ['display','<>',2];
        $where_matching[] = ['audit','<>',3];

        $res['plists'] = Db::name('zimu_zhaopin_resume')->where($where_matching)->order(['refreshtime'=>'desc','id'=>'desc'])->limit(100)->select()->toArray();
        foreach ($res['plists'] as $key => $value) {
            if ($res['plists'][$key]['tag_cn']) {
                $res['plists'][$key]['tag_cn2'] = explode(',',$res['plists'][$key]['tag_cn']);
            }
            if($value['sex']==1){
                $res['plists'][$key]['photo_img'] = $value['photo_img'] ? $value['photo_img'] : ZIMUCMS_PATH.'static/wap/images/no_photo_male.png';
            }else{
                $res['plists'][$key]['photo_img'] = $value['photo_img'] ? $value['photo_img'] : ZIMUCMS_PATH.'static/wap/images/no_photo_female.png';
            }
            $res['plists'][$key]['telephone'] = '13212345678';
            $res['plists'][$key]['isdown'] = Db::name('zimu_zhaopin_company_down_resume')->where([['company_uid','=',$myuid['uid']],['resume_id','=',$value['id']]])->order(['did'=>'desc'])->find();
        }

        zimu_json($res);

    }elseif($op == 'quick_audit' ){

        $audit = intval($_GET['audit']);
        $reason = zimu_array_gbk($_GET['reason']);
        Db::name('zimu_zhaopin_company_profile')->where('id', $ids)->data(['audit' => $audit,'wxtpl' => $reason])->update();
        company_push($ids,$audit,$reason);

        zimu_json($res);

    }elseif($op == 'haibao' ){

        $ids = intval($_GET['ids']);
        $qrsize = 5;
        $dir = DISCUZ_ROOT.'/source/plugin/zimu_zhaopin/uploadzimucms/';
        $xcx_tip = $client_type == 'xcx' ? 'xcx_' : 'h5_';
        $qrcode_file = $dir.'qrcode/company_'.$xcx_tip.$ids.'.jpg';
        $qrcode_url = $_G['siteurl'].'source/plugin/zimu_zhaopin/h5/pages/qiye/view?ids='.$ids.'&mobile=2';

        if(!file_exists(DISCUZ_ROOT . 'source/plugin/zimu_zhaopin/static/font/Alibaba-PuHuiTi-Heavy.ttf') || !file_exists(DISCUZ_ROOT . 'source/plugin/zimu_zhaopin/static/font/Alibaba-PuHuiTi-Regular.ttf')){
            zimu_json($res,$language_zimu['new_mycompany_inc_php_76'],202);
        }

        if(!file_exists($qrcode_file) || !filesize($qrcode_file) || filemtime($qrcode_file) < time() - 43200 ) {
            if($client_type=='xcx'){
                require_once DISCUZ_ROOT . './source/plugin/zimu_zhaopin/class/wechat.lib.class.php';
                $wechat_client_xcx = new WeChatClient($zmdata['settings']['xcx_appid'], $zmdata['settings']['xcx_appsecret']);
                $token         = $wechat_client_xcx->getAccessToken(1);
                $postdata = array(
                    'scene' => "type=viewqiye&ids=".$ids,
                    'page' => 'pages/qiye/view',
                    'auto_color' => true
                );
                $qrcodedata = lizimu_post('https://api.weixin.qq.com/wxa/getwxacodeunlimit?access_token='.$token,json_encode($postdata));
                $fp = fopen($qrcode_file, 'wb');
                flock($fp, 2);
                fwrite($fp,$qrcodedata);
                fclose($fp);
            }else{
                if ($zmdata['settings']['wx_create_qrcode'] == 1) {
                    require_once DISCUZ_ROOT . './source/plugin/zimu_zhaopin/class/wechat.lib.class.php';
                    $wechat_client = new WeChatClient($zmdata['base']['weixin_appid'], $zmdata['base']['weixin_appsecret']);
                    $qrcode_url2 = $wechat_client->getQrcodeImgUrlByTicket($wechat_client->getQrcodeTicket(array(
                        'scene_str' =>  'viewcom2zimuyun' . $ids,
                        'expire' => 2591000
                    )));
                    $qrcode_img = dfsockopen($qrcode_url2);
                    $qrcode_img = $qrcode_img ? $qrcode_img : file_get_contents($qrcode_url2);
                    $fp = fopen($qrcode_file, 'wb');
                    flock($fp, 2);
                    fwrite($fp,$qrcode_img);
                    fclose($fp);
                }else{
                    require_once DISCUZ_ROOT.'source/plugin/zimu_zhaopin/class/qrcode.class.php';
                    QRcode::png($qrcode_url, $qrcode_file, QR_ECLEVEL_L, $qrsize);
                }
            }
        }
        require_once DISCUZ_ROOT.'source/plugin/zimu_zhaopin/class/poster_laofu110.php';

        $myinfo = Db::name('zimu_zhaopin_company_profile')->where([['id','=',$ids]])->find();
        $myinfo['qrcode_url'] = $_G['siteurl'].'source/plugin/zimu_zhaopin/uploadzimucms/qrcode/company_'.$xcx_tip.$ids.'.jpg';
        $myinfo['jobs'] = Db::name('zimu_zhaopin_jobs')->where([['audit','<>',3],['display','<>',2],['company_id','=',$ids]])->order(['refreshtime'=>'desc','id'=>'desc'])->select()->toArray();

        $hbpath = DISCUZ_ROOT . '/source/plugin/zimu_zhaopin/uploadzimucms/haibao/company_'.$xcx_tip.$ids.'.png';

        $config_text[] = array(
            'text' => zimu_array_utf8($myinfo['companyname']),
            'left' => -3,
            'top' => 500,
            'fontSize' => 56,
            'fontColor' => '51,51,51',
            'angle' => 0,
            'fontPath' => 'Alibaba-PuHuiTi-Heavy.ttf',
        );
        $config_text[] = array(
            'text' => zimu_array_utf8($myinfo['trade_cn'].' | '.$myinfo['scale_cn']),
            'left' => -3,
            'top' => 600,
            'fontSize' => 32,
            'fontColor' => '153,153,153',
            'angle' => 0,
        );
        $config_text[] = array(
            'text' => zimu_array_utf8($myinfo['jobs'][0]['jobs_name']),
            'left' => 150,
            'top' => 850,
            'fontSize' => 34,
            'fontColor' => '51,51,51',
            'angle' => 0,
        );
        $config_text[] = array(
            'text' => zimu_array_utf8($myinfo['jobs'][0]['wage_cn']),
            'left' => 940,
            'top' => 850,
            'fontSize' => 34,
            'fontColor' => '51,51,51',
            'angle' => 0,
        );
        $config_text[] = array(
            'text' => zimu_array_utf8($myinfo['jobs'][1]['jobs_name']),
            'left' => 150,
            'top' => 950,
            'fontSize' => 34,
            'fontColor' => '51,51,51',
            'angle' => 0,
        );
        $config_text[] = array(
            'text' => zimu_array_utf8($myinfo['jobs'][1]['wage_cn']),
            'left' => 940,
            'top' => 950,
            'fontSize' => 34,
            'fontColor' => '51,51,51',
            'angle' => 0,
        );
        $config_text[] = array(
            'text' => zimu_array_utf8($myinfo['jobs'][2]['jobs_name']),
            'left' => 150,
            'top' => 1050,
            'fontSize' => 34,
            'fontColor' => '51,51,51',
            'angle' => 0,
        );
        $config_text[] = array(
            'text' => zimu_array_utf8($myinfo['jobs'][2]['wage_cn']),
            'left' => 940,
            'top' => 1050,
            'fontSize' => 34,
            'fontColor' => '51,51,51',
            'angle' => 0,
        );
        $config_text[] = array(
            'text' => zimu_array_utf8($myinfo['jobs'][3]['jobs_name']),
            'left' => 150,
            'top' => 1150,
            'fontSize' => 34,
            'fontColor' => '51,51,51',
            'angle' => 0,
        );
        $config_text[] = array(
            'text' => zimu_array_utf8($myinfo['jobs'][3]['wage_cn']),
            'left' => 940,
            'top' => 1150,
            'fontSize' => 34,
            'fontColor' => '51,51,51',
            'angle' => 0,
        );
        $config_text[] = array(
            'text' => zimu_array_utf8($myinfo['jobs'][4]['jobs_name']),
            'left' => 150,
            'top' => 1250,
            'fontSize' => 34,
            'fontColor' => '51,51,51',
            'angle' => 0,
        );
        $config_text[] = array(
            'text' => zimu_array_utf8($myinfo['jobs'][4]['wage_cn']),
            'left' => 940,
            'top' => 1250,
            'fontSize' => 34,
            'fontColor' => '51,51,51',
            'angle' => 0,
        );

        $config_image[] = array(
            'url' => $myinfo['qrcode_url'],
            'left' => -3,
            'top' => 1300,
            'width' => 400,
            'height' => 400,
            'radius' => 0,
            'opacity' => 100,
        );

        $config = array(
            'bg' => DISCUZ_ROOT . '/source/plugin/zimu_zhaopin/static/wap/images/combg.jpg',
            'format'=>'jpg',
            'quality'=>88,
            'text' => $config_text,
            'image' => $config_image,
        );
        $Poster=new \Laofu\Image\Poster($config);
        $img=$Poster->make($hbpath);
        if(!$img){
            $err=$Poster->errMsg;
        }
        $res['hbimg'] = $_G['siteurl'].'/source/plugin/zimu_zhaopin/uploadzimucms/haibao/company_'.$xcx_tip.$ids.'.png';
        zimu_json($res);

    }elseif($op == 'buy_resumes' ){

        $res['setmeal'] = $setmeal = Db::name('zimu_zhaopin_members_setmeal')->where([['uid','=',$myuid['uid']]])->find();

        $res['dlresume_list'] = Db::name('zimu_zhaopin_setmeal_increment')->where([['cat','=','download_resume']])->order(['sort'=>'desc','id'=>'asc'])->select()->toArray();

        foreach ($res['dlresume_list'] as $key => $value) {
            $res['dlresume_list2'][$key]['id'] = $value['id'];
            $res['dlresume_list2'][$key]['price'] = $value['price'];
            if($setmeal['discount_download_resume']>0){
                $res['dlresume_list2'][$key]['text'] = $value['name'];
                $res['dlresume_list2'][$key]['description'] = 'VIP'.$language_zimu['new_mycompany_inc_php_77'].round($value['price']*$setmeal['discount_download_resume']/10,2).$zmdata['settings']['money_name'];
                $res['dlresume_list2'][$key]['description2'] = $language_zimu['new_mycompany_inc_php_78'].round($value['price']*$setmeal['discount_download_resume']/10/$value['value'],2).$zmdata['settings']['money_name'].'/'.$language_zimu['new_mycompany_inc_php_79'];
                $res['dlresume_list2'][$key]['myprice'] = round($value['price']*$setmeal['discount_download_resume']/10,2);
            }else{
                $res['dlresume_list2'][$key]['myprice'] = $value['price'];
                $res['dlresume_list2'][$key]['text'] = $value['name'];
                $res['dlresume_list2'][$key]['description'] = $language_zimu['new_mycompany_inc_php_80'].round($value['price']/$value['value'],2).$zmdata['settings']['money_name'].'/'.$language_zimu['new_mycompany_inc_php_81'];
            }
        }

        zimu_json2($res);

    }else{

        $res['company_profile'] = $company_profile = Db::name('zimu_zhaopin_company_profile')->where([['uid','=',$myuid['uid']]])->find();
        if($res['company_profile']){
            Db::name('zimu_zhaopin_company_profile')->where('uid', $myuid['uid'])->data(['logintime' => time()])->update();
            Db::name('zimu_zhaopin_members')->where('uid', $myuid['uid'])->data(['utype' => 1])->update();
        }

        $res['setmeal'] = $setmeal = Db::name('zimu_zhaopin_members_setmeal')->where([['uid','=',$myuid['uid']]])->find();

        if ($company_profile && !$setmeal) {

            $freesetmeal = Db::name('zimu_zhaopin_setmeal')->where([['id','=',1]])->find();

            $setsqlarr2['expire']              = $freesetmeal['is_free'] == 1 ? 1 : 0;
            $setsqlarr2['uid']                 = $myuid['uid'];
            $setsqlarr2['setmeal_id']          = $freesetmeal['id'];
            $setsqlarr2['setmeal_name']        = $freesetmeal['setmeal_name'];
            $setsqlarr2['days']                = $freesetmeal['days'];
            $setsqlarr2['expense']             = $freesetmeal['expense'];
            $setsqlarr2['jobs_meanwhile']      = $freesetmeal['jobs_meanwhile'];
            $setsqlarr2['refresh_jobs_free']   = $freesetmeal['refresh_jobs_free'];
            $setsqlarr2['download_resume']     = $freesetmeal['download_resume'];
            $setsqlarr2['download_resume_max'] = $freesetmeal['download_resume_max'];
            $setsqlarr2['added']               = $freesetmeal['added'];
            $setsqlarr2['starttime']           = time();
            if ($freesetmeal['days'] > 0) {
                $setsqlarr2['endtime'] = strtotime("" . $freesetmeal['days'] . " days");
            } else {
                $setsqlarr2['endtime'] = "0";
            }

            $setsqlarr2['set_sms'] = $freesetmeal['set_sms'];

            $setsqlarr2['show_apply_contact']         = $freesetmeal['show_apply_contact'];
            $setsqlarr2['is_free']                    = $freesetmeal['is_free'];
            $setsqlarr2['discount_download_resume']   = $freesetmeal['discount_download_resume'];
            $setsqlarr2['discount_sms']               = $freesetmeal['discount_sms'];
            $setsqlarr2['discount_stick']             = $freesetmeal['discount_stick'];
            $setsqlarr2['discount_emergency']         = $freesetmeal['discount_emergency'];
            $setsqlarr2['discount_auto_refresh_jobs'] = $freesetmeal['discount_auto_refresh_jobs'];

            Db::name('zimu_zhaopin_members_setmeal')->insert($setsqlarr2);

            Db::name('zimu_zhaopin_company_profile')->where('uid', $myuid['uid'])->data(['setmeal_id' => $setsqlarr2['setmeal_id'],'setmeal_name' => $setsqlarr2['setmeal_name']])->update();

            Db::name('zimu_zhaopin_jobs')->where('uid', $myuid['uid'])->data(['setmeal_deadline' => $setsqlarr2['endtime'],'setmeal_id' => $setsqlarr2['setmeal_id'],'setmeal_name' => $setsqlarr2['setmeal_name']])->update();

            $res['setmeal'] = $setmeal = Db::name('zimu_zhaopin_members_setmeal')->where([['uid','=',$myuid['uid']]])->find();

            $res['company_profile'] = $company_profile = Db::name('zimu_zhaopin_company_profile')->where([['uid','=',$myuid['uid']]])->find();

        } elseif ($company_profile && $setmeal['setmeal_id'] > 0 && $setmeal['endtime'] < time() && $setmeal['endtime'] > 0) {

            $freesetmeal = Db::name('zimu_zhaopin_setmeal')->where([['id','=',1]])->find();

            $setsqlarr2['expire']              = $freesetmeal['is_free'] == 1 ? 1 : 0;
            $setsqlarr2['uid']                 = $myuid['uid'];
            $setsqlarr2['setmeal_id']          = $freesetmeal['id'];
            $setsqlarr2['setmeal_name']        = $freesetmeal['setmeal_name'];
            $setsqlarr2['days']                = $freesetmeal['days'];
            $setsqlarr2['expense']             = $freesetmeal['expense'];
            $setsqlarr2['jobs_meanwhile']      = $freesetmeal['jobs_meanwhile'];
            $setsqlarr2['refresh_jobs_free']   = $freesetmeal['refresh_jobs_free'];
            $setsqlarr2['download_resume']     = 0;
            $setsqlarr2['download_resume2']     = $setmeal['download_resume2'];
            $setsqlarr2['download_resume_max'] = $freesetmeal['download_resume_max'];
            $setsqlarr2['added']               = $freesetmeal['added'];
            $setsqlarr2['starttime']           = time();
            if ($freesetmeal['days'] > 0) {
                $setsqlarr2['endtime'] = strtotime("" . $freesetmeal['days'] . " days");
            } else {
                $setsqlarr2['endtime'] = "0";
            }

            $setsqlarr2['set_sms'] = $setmeal['set_sms'] + $freesetmeal['set_sms'];

            $setsqlarr2['show_apply_contact']         = $freesetmeal['show_apply_contact'];
            $setsqlarr2['is_free']                    = $freesetmeal['is_free'];
            $setsqlarr2['discount_download_resume']   = $freesetmeal['discount_download_resume'];
            $setsqlarr2['discount_sms']               = $freesetmeal['discount_sms'];
            $setsqlarr2['discount_stick']             = $freesetmeal['discount_stick'];
            $setsqlarr2['discount_emergency']         = $freesetmeal['discount_emergency'];
            $setsqlarr2['discount_auto_refresh_jobs'] = $freesetmeal['discount_auto_refresh_jobs'];

            Db::name('zimu_zhaopin_members_setmeal')->where('uid', $myuid['uid'])->data($setsqlarr2)->update();

            Db::name('zimu_zhaopin_company_profile')->where('uid', $myuid['uid'])->data(['setmeal_id' => $setsqlarr2['setmeal_id'],'setmeal_name' => $setsqlarr2['setmeal_name']])->update();

            Db::name('zimu_zhaopin_jobs')->where('uid', $myuid['uid'])->data(['setmeal_deadline' => $setsqlarr2['endtime'],'setmeal_id' => $setsqlarr2['setmeal_id'],'setmeal_name' => $setsqlarr2['setmeal_name']])->update();

            $res['setmeal'] = $setmeal = Db::name('zimu_zhaopin_members_setmeal')->where([['uid','=',$myuid['uid']]])->find();

            $res['company_profile'] = $company_profile = Db::name('zimu_zhaopin_company_profile')->where([['uid','=',$myuid['uid']]])->find();


        }

        if($res['company_profile']['setmeal_id'] != $res['setmeal']['setmeal_id']){
            Db::name('zimu_zhaopin_company_profile')->where('id', $res['company_profile']['id'])->data(['setmeal_id' => $res['setmeal']['setmeal_id'],'setmeal_name' => $res['setmeal']['setmeal_name']])->update();
            Db::name('zimu_zhaopin_jobs')->where('uid', $res['company_profile']['uid'])->data(['setmeal_id' => $res['setmeal']['setmeal_id'],'setmeal_name' => $res['setmeal']['setmeal_name']])->update();
        }


        $res['company_profile']['total_jobs_apply'] = Db::name('zimu_zhaopin_personal_jobs_apply')->where([['company_uid','=',$myuid['uid']]])->count();

        $res['company_profile']['total_resume_down'] = Db::name('zimu_zhaopin_company_down_resume')->where([['company_uid','=',$myuid['uid']]])->count();

        $res['company_profile']['total_resume_favorites'] = Db::name('zimu_zhaopin_company_favorites')->where([['company_uid','=',$myuid['uid']]])->count();

        $res['company_profile']['count_viewlog'] = Db::name('zimu_zhaopin_com_viewlog')->where([['uid','=',$myuid['uid']]])->count();

        $res['company_profile']['total_jobs_interview'] = Db::name('zimu_zhaopin_company_interview')->where([['company_uid','=',$myuid['uid']]])->count();

        if($res['company_profile']['kefu_uid']){
            $kefudata = Db::name('zimu_zhaopin_kefu')->where([['uid','=',$res['company_profile']['kefu_uid']]])->find();
            $res['company_profile']['kefu_mobile'] = $kefudata['kefu_mobile'];
            $res['company_profile']['kefu_wxid'] = $kefudata['kefu_wxid'];
        }else{
            $res['company_profile']['kefu_mobile'] = $zmdata['settings']['qiye_kefu_mobile'] ? $zmdata['settings']['qiye_kefu_mobile'] : $zmdata['settings']['kefu_mobile'];
            $res['company_profile']['kefu_wxid'] = $zmdata['settings']['qiye_kefu_wxid'] ? $zmdata['settings']['qiye_kefu_wxid'] : $zmdata['settings']['kefu_wxid'];
        }

        Db::name('zimu_zhaopin_members')->where('uid', $myuid['uid'])->data(['utype' => 1])->update();

        $setmeal = Db::name('zimu_zhaopin_members_setmeal')->where([['uid','=',$myuid['uid']]])->find();

        $res['dlresume_list'] = Db::name('zimu_zhaopin_setmeal_increment')->where([['cat','=','download_resume']])->order(['sort'=>'desc','id'=>'asc'])->select()->toArray();

        foreach ($res['dlresume_list'] as $key => $value) {
            if($setmeal['discount_download_resume']>0){
                $res['dlresume_list2'][$key]['text'] = $value['name'];
                $res['dlresume_list2'][$key]['description'] = $language_zimu['new_mycompany_inc_php_82'].round($value['price']*$setmeal['discount_download_resume']/10,2).$zmdata['settings']['money_name'].$language_zimu['new_mycompany_inc_php_83'].round($value['price']*$setmeal['discount_download_resume']/10/$value['value'],2).$zmdata['settings']['money_name'].'/'.$language_zimu['new_mycompany_inc_php_84'].'('.$language_zimu['new_mycompany_inc_php_85'].$value['price'].$zmdata['settings']['money_name'].')';
            }else{
                $res['dlresume_list2'][$key]['text'] = $value['name'];
                $res['dlresume_list2'][$key]['description'] = $language_zimu['new_mycompany_inc_php_86'].round($value['price']/$value['value'],2).$zmdata['settings']['money_name'].'/'.$language_zimu['new_mycompany_inc_php_87'].'('.$language_zimu['new_mycompany_inc_php_88'].$value['price'].$zmdata['settings']['money_name'].')';
            }
        }


        $myjobs = Db::name('zimu_zhaopin_jobs')->where('uid', $myuid['uid'])->count();
        $res['setmeal']['jobs_meanwhile2'] = max($res['setmeal']['jobs_meanwhile'] - $myjobs,0);
        if(!$zmdata['settings']['download_resume2']){
            $res['setmeal']['download_resume'] = $res['setmeal']['download_resume']+$res['setmeal']['download_resume2'];
        }

        $myrefresh = Db::name('zimu_zhaopin_refresh_log')->where([['uid','=',$myuid['uid']],['type','=',1001],['mode','=',2],['addtime','>',strtotime(date('Y-m-d', time()))]])->count();
        $res['setmeal']['refresh_jobs_free2'] = $myrefresh;
        $res['setmeal']['endtime_cn'] = date('Y-m-d',$res['setmeal']['endtime']);

        $res['company_profile']['jifen_name'] = $zmdata['settings']['open_jifen'] ? $language_zimu['new_mycompany_inc_php_89'].$zmdata['settings']['jifen_name'] : '';
        $paramter = Db::name('zimu_zhaopin_parameter2')->where([['name','=','wappopup']])->order(['id'=>'asc'])->find();
        $res['wappopup'] = unserialize($paramter['parameter']);
        $res['wapfooter'] = $zmdata['settings']['wapfooterhtml'];
        $res['download_resume2'] = $zmdata['settings']['download_resume2'];
        $res['zmdata']['show_bindmp_qrcode'] = 0;

        if(strlen($myuid['openid']) < 10 || strlen($myuid['openid']) > 50){
            $myuid['openid'] = '';
            Db::name('zimu_zhaopin_members')->where('uid', $myuid['uid'])->data(['openid' => ''])->update();
        }

        if(file_exists(DISCUZ_ROOT . './source/plugin/zimu_zhaopin/module/adminss/adminss_imconfig.inc.php')){
            $imchat_parameter = Db::name('zimu_zhaopin_parameter2')->where('name', 'imchat')->order('id','desc')->find();
            $imchat_parameter = unserialize($imchat_parameter['parameter']);
            if($imchat_parameter['open_im']){
                $res['zmdata']['open_im'] = 1;
                $res['zmdata']['im_counts'] = get_im_noread_counts($myuid);
            }
        }

        if($myuid['openid'] && IN_WECHAT){
            require_once DISCUZ_ROOT . './source/plugin/zimu_zhaopin/class/wechat.lib.class.php';
            $wechat_client = new WeChatClient($zmdata['base']['weixin_appid'], $zmdata['base']['weixin_appsecret']);
            $wechatinfo    = $wechat_client->getUserInfoById($myuid['openid']);
            if ($wechatinfo['subscribe'] == 1) {
                Db::name('zimu_zhaopin_company_profile')->where('uid', $myuid['uid'])->data(['bind_weixin' => 1])->update();
                Db::name('zimu_zhaopin_resume')->where('uid', $myuid['uid'])->data(['bind_weixin' => 1])->update();
            } elseif ($wechatinfo['openid'] && $wechatinfo['subscribe'] == 0) {
                $res['zmdata']['show_bindmp_qrcode'] = 1;
                $res['zmdata']['bindmp_qrcode_url'] = $zmdata['settings']['mp_qrcode_url'];
                $res['zmdata']['bindmpmp_qrcode_text1'] = $zmdata['settings']['mp_qrcode_text'];
                $res['zmdata']['bindmpmp_qrcode_text2'] = $language_zimu['new_mycompany_inc_php_90'];
                Db::name('zimu_zhaopin_company_profile')->where('uid', $myuid['uid'])->data(['bind_weixin' => 0])->update();
                Db::name('zimu_zhaopin_resume')->where('uid', $myuid['uid'])->data(['bind_weixin' => 0])->update();
            }
        }elseif (!$myuid['openid'] && IN_WECHAT){
            $res['zmdata']['show_bindmp_qrcode'] = 1;
            $dir = DISCUZ_ROOT.'/source/plugin/zimu_zhaopin/uploadzimucms/';
            $qrcode_name = 'bindmp_qrcode_'.time().'.jpg';
            $qrcode_file = $dir.'qrcode/'.$qrcode_name;
            require_once DISCUZ_ROOT . './source/plugin/zimu_zhaopin/class/wechat.lib.class.php';
            $wechat_client = new WeChatClient($zmdata['base']['weixin_appid'], $zmdata['base']['weixin_appsecret']);
            $qrcode_url2 = $wechat_client->getQrcodeImgUrlByTicket($wechat_client->getQrcodeTicket(array(
                'scene_str' =>  'bindmp_qrcodezimuyun' . ($myuid['old_uid'] ? $myuid['old_uid'] : $myuid['uid']),
                'expire' => 2591000
            )));
            $qrcode_img = dfsockopen($qrcode_url2);
            $qrcode_img = $qrcode_img ? $qrcode_img : file_get_contents($qrcode_url2);
            $fp = fopen($qrcode_file, 'wb');
            flock($fp, 2);
            fwrite($fp,$qrcode_img);
            fclose($fp);
            $res['zmdata']['bindmp_qrcode_url'] = $_G['siteurl'].'source/plugin/zimu_zhaopin/uploadzimucms/qrcode/'.$qrcode_name.'?v='.time();
            $res['zmdata']['bindmpmp_qrcode_text1'] = $language_zimu['new_mycompany_inc_php_91'];
            $res['zmdata']['bindmpmp_qrcode_text2'] = $language_zimu['new_mycompany_inc_php_92'];
        }

        $res['zmdata']['uid'] = $myuid['old_uid'] ? $myuid['old_uid'] : $myuid['uid'];
        $res['zmdata']['toutiao_audit'] = $zmdata['settings']['toutiao_audit'];
        zimu_json2($res);

    }