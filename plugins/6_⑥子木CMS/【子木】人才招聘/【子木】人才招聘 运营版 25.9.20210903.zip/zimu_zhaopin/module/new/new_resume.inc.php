<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if (!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }

    use think\Db;

    $token = addslashes($_GET['token']);
    $myuid = checktoken($token,0);
    $op = addslashes($_GET['op']);
    $zimu_get = zimu_array_gbk($_GET);
    $page = intval($_GET['page']);


    if($op == 'gethongniang') {


    }else{

        $todaytime = strtotime(date('Y-m-d', time()));
        $begintime = $todaytime + $zmdata['settings']['refresh_resume_hour']*3600;
        if(time() > $begintime && $zmdata['settings']['refresh_resume_days'] && $zmdata['settings']['refresh_resume_hour']){
            $refresh_resume_list = Db::name('zimu_zhaopin_resume')->where([['display','=',1],['audit','<>',3],['addtime','>',$todaytime-86400*$zmdata['settings']['refresh_resume_days']],['refreshtime','<',$todaytime]])->order(['id'=>'asc'])->select()->toArray();
            foreach ($refresh_resume_list as $key => $value) {
                $refreshtime = $value['addtime'] - strtotime(date('Y-m-d H:0:0', $value['addtime']))+$begintime;
                if($refreshtime > time() ){
                    $refreshtime = $refreshtime - 3600;
                }
                Db::name('zimu_zhaopin_resume')->where('uid', $value['uid'])->data(['refreshtime' => $refreshtime])->update();
            }
        }


        $indexad = Db::name('zimu_zhaopin_parameter2')->where('name','resumead')->find();
        $res['indexad'] = unserialize($indexad['parameter']);

        $districtlist = Db::name('zimu_zhaopin_area')->where([['parentid','=',0]])->order(['sort'=>'asc','id'=>'asc'])->select()->toArray();

        foreach ($districtlist as $key => $value) {
            $districtlist[$key]['list'] = Db::name('zimu_zhaopin_area')->where([['parentid','=',$value['id']]])->order(['sort'=>'asc','id'=>'asc'])->select()->toArray();
            if($zmdata['settings']['area_three']==1){
                foreach ($districtlist[$key]['list'] as $key2 => $value2) {
                    $districtlist[$key]['list'][$key2]['area_three'] = $zmdata['settings']['area_three'];
                    $districtlist[$key]['list'][$key2]['list'] = Db::name('zimu_zhaopin_area')->where([['parentid','=',$value2['id']]])->order(['sort'=>'asc','id'=>'asc'])->select()->toArray();
                }
            }
        }
        $res['districtlist'] = $districtlist;

        $jobcatlist = Db::name('zimu_zhaopin_category_jobs')->where([['parentid','=',0]])->order(['category_order'=>'asc','id'=>'asc'])->select()->toArray();

        foreach ($jobcatlist as $key => $value) {
            $jobcatlist[$key]['list'] = Db::name('zimu_zhaopin_category_jobs')->where([['parentid','=',$value['id']]])->order(['category_order'=>'asc','id'=>'asc'])->select()->toArray();
        }
        $res['jobcatlist'] = $jobcatlist;

        $res['morelist']['explist'] = Db::name('zimu_zhaopin_category')->where([['c_alias','=','ZM_experience']])->order(['c_order'=>'asc','c_id'=>'asc'])->select()->toArray();
        array_shift($res['morelist']['explist']);
        $res['morelist']['naturelist'] = Db::name('zimu_zhaopin_category')->where([['c_alias','=','ZM_jobs_nature']])->order(['c_order'=>'asc','c_id'=>'asc'])->select()->toArray();

        $res['morelist']['edulist'] = Db::name('zimu_zhaopin_category')->where([['c_alias','=','ZM_education']])->order(['c_order'=>'asc','c_id'=>'asc'])->select()->toArray();

        $selecttxt = json_decode(zimu_array_utf8($_GET['selecttxt']),true);
        $selecttxt = zimu_array_gbk($selecttxt);

        $wheresql2[] = ['display','=',1];
        $wheresql2[] = ['audit','<>',3];

        if($selecttxt['sex']){
            $wheresql2[] = ['sex','=',$selecttxt['sex']];
        }
        if($selecttxt['exp']){
            $wheresql2[] = ['experience','>=',$selecttxt['exp']];
        }
        if($selecttxt['edu']){
            $wheresql2[] = ['education','>=',$selecttxt['edu']];
        }
        if($selecttxt['nature']){
            $wheresql2[] = ['nature','=',$selecttxt['nature']];
        }
        if($selecttxt['jobcate2']){
            $wheresql2[] = ['intention_jobs_id','like','%.'.$selecttxt['jobcate2'].'%'];
        }elseif ($selecttxt['jobcate1']){
            $wheresql2[] = ['intention_jobs_id','like','%'.$selecttxt['jobcate1'].'.%'];
        }
        if($zmdata['settings']['area_three']==1){
            if($selecttxt['city3']){
                $wheresql2[] = ['district','like','%.'.$selecttxt['city3'].'%'];
            }elseif ($selecttxt['city2']){
                $wheresql2[] = ['district','like',['%'.$selecttxt['city1'].'.0%','%'.$selecttxt['city1'].'.'.$selecttxt['city2'].'.%'],'OR'];
            }elseif ($selecttxt['city1']){
                $wheresql2[] = ['district','like','%'.$selecttxt['city1'].'.%'];
            }
        }else{
            if($selecttxt['city2']){
                $wheresql2[] = ['district','like','%'.$selecttxt['city1'].'.'.$selecttxt['city2'].'.%'];
            }elseif ($selecttxt['city1']){
                $wheresql2[] = ['district','like',$selecttxt['city1'].'.%'];
            }
        }

        if($selecttxt['sotxt']){
            $wheresql2[] = ['fullname','like','%'.$selecttxt['sotxt'].'%'];
        }

        if($zmdata['settings']['show_noaudit']){
            $wheresql2[] = ['audit','=',1];
        }

        if(file_exists(DISCUZ_ROOT . './source/plugin/zimu_zhaopin/module/a_change_area.inc.php') && ( $zmdata['settings']['change_city'] == 1 || $zmdata['settings']['change_area'] > 0) && !$selecttxt['city1'] && !$selecttxt['city2']){
            if($tocityid2){
                $wheresql_tocity[] = ['district','like','%.'.$tocityid2.'.%'];
            }elseif($tocityid){
                $wheresql_tocity[] = ['district','like','%'.$tocityid.'.%'];
            }
        }

        if($page==1){
            $topresume = Db::name('zimu_zhaopin_resume')->where($wheresql_tocity)->where([['stick_endtime','>',time()]])->where([$wheresql2])->order(['refreshtime'=>'desc','stick_endtime'=>'desc','id'=>'desc'])->select()->toArray();
            $res['topresume'] = format_resume($topresume,$zmdata);
        }

        $newresume = Db::name('zimu_zhaopin_resume')->where($wheresql_tocity)->where([['stick_endtime','<',time()]])->where($wheresql2)->order(['refreshtime'=>'desc','id'=>'desc'])->page($page,10)->select()->toArray();
        $res['newresume'] = format_resume($newresume,$zmdata);
        if($zmdata['settings']['toutiao_audit']!=1){
            $res['newresume'] = zimu_ad_system($res['newresume'],'zhaopin3',0);
        }
        $res['wapfooter'] = $zmdata['settings']['wapfooterhtml'];
        $paramter = Db::name('zimu_zhaopin_parameter2')->where([['name','=','wappopup']])->order(['id'=>'asc'])->find();
        $res['wappopup'] = unserialize($paramter['parameter']);
        zimu_json($res);

    }
