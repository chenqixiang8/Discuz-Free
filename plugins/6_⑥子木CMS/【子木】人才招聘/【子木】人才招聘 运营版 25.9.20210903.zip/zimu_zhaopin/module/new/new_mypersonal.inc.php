<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if (!defined('IN_DISCUZ')) {
    }

    use think\Db;

    $token = addslashes($_GET['token']);
    $myuid = checktoken($token);
    $op = addslashes($_GET['op']);
    $ids = intval($_GET['ids']);

    if($op=='123'){

    }elseif($op == 'refresh_resume' ){

        $myresume = Db::name('zimu_zhaopin_resume')->where([['uid','=',$myuid['uid']]])->order(['id'=>'desc'])->find();
        if (!$myresume) {
            $res['type'] = 'error';
            $res['tip'] = $language_zimu['new_mypersonal_inc_php_0'];
            zimu_json($res);
        }
        if ($myresume['audit'] == 3) {
            $res['type'] = 'error';
            $res['tip'] = $language_zimu['new_mypersonal_inc_php_1'];
            zimu_json($res);
        }

        $refrestime = Db::name('zimu_zhaopin_refresh_log')->where([['uid','=',$myuid['uid']],['type','=',2001],['addtime','>',strtotime(date('Y-m-d', time()))]])->count();
        if($zmdata['settings']['per_refresh_resume_time'] != 0 && ( $refrestime >= $zmdata['settings']['per_refresh_resume_time'] ) ){
            if ($myresume) {
                $res['type'] = 'error';
                $res['tip'] = $language_zimu['new_mypersonal_inc_php_2'].$zmdata['settings']['per_refresh_resume_time'].$language_zimu['new_mypersonal_inc_php_3'];
                zimu_json($res);
            }
        }else{
            $setsqlarr['refreshtime'] = time();
            $setsqlarr['display'] = 1;
            Db::name('zimu_zhaopin_resume')->where([['uid','=',$myuid['uid']]])->data($setsqlarr)->update();
            $setsqlarr2['uid'] = $myuid['uid'];
            $setsqlarr2['mode'] = 0;
            $setsqlarr2['addtime'] = time();
            $setsqlarr2['type'] = 2001;
            Db::name('zimu_zhaopin_refresh_log')->insert($setsqlarr2);
            $res['type'] = 'success';
            $res['tip'] = $language_zimu['new_mypersonal_inc_php_4'];
            zimu_json($res);
        }

    }elseif($op == 'resume_edit' ){

        $myresume = Db::name('zimu_zhaopin_resume')->where([['uid','=',$myuid['uid']]])->order(['id'=>'desc'])->find();
        $auditinfo = Db::name('zimu_zhaopin_resume_audit')->where('uid', $myuid['uid'])->find();
        if($auditinfo){
            unset($auditinfo['id']);
            $myresume = array_merge($myresume,$auditinfo);
        }
        if($_GET['op2']=='percent'){

            $myresume['work_nums'] = Db::name('zimu_zhaopin_resume_work')->where([['uid','=',$myuid['uid']]])->order(['id'=>'asc'])->count();
            $myresume['education_nums'] = Db::name('zimu_zhaopin_resume_education')->where([['uid','=',$myuid['uid']]])->order(['id'=>'asc'])->count();

            $res['myresume'] = $myresume;
            zimu_json($res);

        }

        $category = Db::name('zimu_zhaopin_category')->order(['c_order'=>'asc','c_id'=>'asc'])->select()->toArray();

        foreach ($category as $key => $value) {
            $category2[$value['c_alias']][$value['c_id']]['value'] = $value['c_id'];
            $category2[$value['c_alias']][$value['c_id']]['label'] = $value['c_name'];
        }

        $res['birthdate_list'] = range(date('Y') - 16, date('Y') - 65);
        $education_list = $category2['ZM_education'];
        array_multisort($education_list);
        $res['education_list'] = $education_list;
        $experience_list = $category2['ZM_experience'];
        array_shift($experience_list);
        array_multisort($experience_list);
        $res['experience_list'] = $experience_list;
        $current_list = $category2['ZM_current'];
        array_multisort($current_list);
        $res['current_list'] = $current_list;
        $nature_list = $category2['ZM_jobs_nature'];
        array_multisort($nature_list);
        $res['nature_list'] = $nature_list;
        $wage_list = $category2['ZM_wage'];
        array_multisort($wage_list);
        $res['wage_list'] = $wage_list;

        $trade_list = $category2['ZM_trade'];
        array_multisort($trade_list);
        foreach ($trade_list as $key => $value) {
            if(strpos($myresume['trade_cn'],$value['label']) !== false){
                $trade_list[$key]['select'] = true;
            }else{
                $trade_list[$key]['select'] = false;
            }
        }
        $res['trade_list'] = $trade_list;

        $jobcatlist = Db::name('zimu_zhaopin_category_jobs')->where([['parentid','=',0]])->order(['category_order'=>'asc','id'=>'asc'])->select()->toArray();

        foreach ($jobcatlist as $key => $value) {
            if(strpos($myresume['intention_jobs_id'],$value['id'].'.') !== false){
                $jobcatlist[$key]['select'] = true;
            }else{
                $jobcatlist[$key]['select'] = false;
            }
        }

        foreach ($jobcatlist as $key => $value) {
            $jobcatlist[$key]['list'] = Db::name('zimu_zhaopin_category_jobs')->where([['parentid','=',$value['id']]])->order(['category_order'=>'asc','id'=>'asc'])->select()->toArray();
            foreach ($jobcatlist[$key]['list'] as $key2 => $value2) {
                if(strpos($myresume['intention_jobs'],$value2['categoryname']) !== false){
                    $jobcatlist[$key]['list'][$key2]['select'] = true;
                }else{
                    $jobcatlist[$key]['list'][$key2]['select'] = false;
                }
            }
        }
        $res['jobcat_list'] = $jobcatlist;

        $districtlist = $district_list_tree = Db::name('zimu_zhaopin_area')->where([['parentid','=',0]])->order(['sort'=>'asc','id'=>'asc'])->select()->toArray();

        $district_string = ','.$myresume['district'];
        foreach ($districtlist as $key => $value) {
            if(strpos($district_string,','.$value['id'].'.') !== false){
                $districtlist[$key]['select'] = true;
            }else{
                $districtlist[$key]['select'] = false;
            }
        }

        $district_empty[] = array('id'=>0,'name'=>$language_zimu['new_mypersonal_inc_php_5']);

        foreach ($districtlist as $key => $value) {
            $districtlist[$key]['list'] = Db::name('zimu_zhaopin_area')->where([['parentid','=',$value['id']]])->order(['sort'=>'asc','id'=>'asc'])->select()->toArray();
            $districtlist[$key]['list'] = array_merge($district_empty,$districtlist[$key]['list']);
            $districtlist[$key]['children_select'] = false;
            foreach ($districtlist[$key]['list'] as $key2 => $value2) {
                if(strpos($myresume['district_cn'],$value2['name']) !== false){
                    $districtlist[$key]['list'][$key2]['select'] = true;
                    $districtlist[$key]['children_select'] = true;
                }else{
                    $districtlist[$key]['list'][$key2]['select'] = false;
                }
            }
            if(($districtlist[$key]['children_select'] == false && $districtlist[$key]['select'] == true) || (count($districtlist[$key]['list'])==1)){
                $districtlist[$key]['list'][0]['select'] = $districtlist[$key]['select'];
            }
        }

        foreach ($district_list_tree as $key => $value) {
            $district_list_tree[$key]['children'] = Db::name('zimu_zhaopin_area')->where([['parentid','=',$value['id']],['parentid','<>',0]])->order(['sort'=>'asc','id'=>'asc'])->select()->toArray();
            $district_empty[0]['parentid'] = $value['id'];
            $district_empty[0]['parentname'] = $value['name'];
            $district_list_tree[$key]['children'] = array_merge($district_empty,$district_list_tree[$key]['children']);
            if($zmdata['settings']['area_three']==1){
                foreach ($district_list_tree[$key]['children'] as $key2 => $value2) {
                    $district_list_tree[$key]['children'][$key2]['area_three'] = $zmdata['settings']['area_three'];
                    $district_list_tree[$key]['children'][$key2]['children'] = Db::name('zimu_zhaopin_area')->where([['parentid','=',$value2['id']],['parentid','<>',0]])->order(['sort'=>'asc','id'=>'asc'])->select()->toArray();
                    if($district_list_tree[$key]['children'][$key2]['id']!=0){
                        $district_empty[0]['parentid'] = $value2['id'];
                        $district_empty[0]['parentname'] = $value2['name'];
                        $district_list_tree[$key]['children'][$key2]['children'] = array_merge($district_empty,$district_list_tree[$key]['children'][$key2]['children']);
                    }
                }
            }
        }

        $res['district_list'] = $districtlist;
        $res['district_list_tree'] = $district_list_tree;


        $tag_list = $category2['ZM_resumetag'];
        array_multisort($tag_list);
        foreach ($tag_list as $key => $value) {
            if(strpos($myresume['tag_cn'],$value['label']) !== false){
                $tag_list[$key]['select'] = true;
            }else{
                $tag_list[$key]['select'] = false;
            }
        }
        $res['tag_list'] = $tag_list;
        $res['myresume'] = $myresume;
        $res['myresume']['photo_img2'][] = $res['myresume']['photo_img'];
        $res['myresume']['trade2'] = explode(',',$myresume['trade']);
        $res['myresume']['trade_cn2'] = explode(',',$myresume['trade_cn']);

        $sms_paramter = Db::name('zimu_zhaopin_parameter2')->where('name', 'aliyunsms')->find();
        $sms_paramter = unserialize($sms_paramter['parameter']);
        if ($sms_paramter['smsAppKey']) {
            $res['zmdata']['showcode'] = 1;
        }else{
            $res['zmdata']['showcode'] = 0;
        }

        $res['zmdata']['add_jobs_price'] = $zmdata['settings']['add_jobs_price'];
        $res['zmdata']['wapfooter'] = $zmdata['settings']['wapfooterhtml'];
        $res['zmdata']['close_testmobile'] = $zmdata['settings']['close_testmobile'];

        $resume_input_paramter = Db::name('zimu_zhaopin_parameter2')->where('name', 'resume_input')->find();
        $res['resume_input'] = unserialize($resume_input_paramter['parameter']);
        $mag_paramter = Db::name('zimu_zhaopin_parameter2')->where('name', 'magapp')->find();
        $mag_paramter = unserialize($mag_paramter['parameter']);
        $res['magapp_hostname'] = $mag_paramter['magapp_hostname'];

        $res['myresume']['trade2'] = explode(',',$res['myresume']['trade']);
        $res['myresume']['trade_cn2'] = explode(',',$res['myresume']['trade_cn']);
        $res['myresume']['trade2'] = array_filter($res['myresume']['trade2']);
        $res['myresume']['trade_cn2'] = array_filter($res['myresume']['trade_cn2']);

        $res['myresume']['intention_jobs_id2'] = explode(',',$res['myresume']['intention_jobs_id']);
        $res['myresume']['intention_jobs2'] = explode(',',$res['myresume']['intention_jobs']);
        $res['myresume']['intention_jobs_id2'] = array_filter($res['myresume']['intention_jobs_id2']);
        $res['myresume']['intention_jobs2'] = array_filter($res['myresume']['intention_jobs2']);

        $res['myresume']['district2'] = explode(',',$res['myresume']['district']);
        $res['myresume']['district_cn2'] = explode(',',$res['myresume']['district_cn']);
        $res['myresume']['district2'] = array_filter($res['myresume']['district2']);
        $res['myresume']['district_cn2'] = array_filter($res['myresume']['district_cn2']);

        if($res['myresume']['telephone'] && (!$myuid['telephone'] || $res['myresume']['telephone'] != $myuid['telephone']) ){
            Db::name('zimu_zhaopin_members')->where('uid', $myuid['uid'])->data(['telephone' => $res['myresume']['telephone']])->update();
        }

        $agreement_paramter = Db::name('zimu_zhaopin_parameter2')->where('name', 'agreement')->find();
        $agreement_paramter = unserialize($agreement_paramter['parameter']);
        $res['zmdata']['agreement'] = $agreement_paramter['agreement'];
        $res['myinfo'] = $myuid;


        zimu_json($res);

    }elseif($op == 'sojobcat' ){

        $myresume = Db::name('zimu_zhaopin_resume')->where([['uid','=',$myuid['uid']]])->order(['id'=>'desc'])->find();

        $selecttxt = zimu_array_utf8tomy($_GET['sotxt']);
        $jobcatlist = Db::name('zimu_zhaopin_category_jobs')->where([['parentid','=',0]])->order(['category_order'=>'asc','id'=>'asc'])->select()->toArray();
        foreach ($jobcatlist as $key => $value) {
            if(strpos($myresume['intention_jobs_id'],$value['id'].'.') !== false){
                $jobcatlist[$key]['select'] = true;
            }else{
                $jobcatlist[$key]['select'] = false;
            }
        }
        foreach ($jobcatlist as $key => $value) {
            $jobcatlist[$key]['list'] = Db::name('zimu_zhaopin_category_jobs')->where([['parentid','=',$value['id']]])->order(['category_order'=>'asc','id'=>'asc'])->select()->toArray();
            foreach ($jobcatlist[$key]['list'] as $key2 => $value2) {
                if(strpos($myresume['intention_jobs'],$value2['categoryname']) !== false){
                    $jobcatlist[$key]['list'][$key2]['select'] = true;
                }else{
                    $jobcatlist[$key]['list'][$key2]['select'] = false;
                }
                if(strpos($value2['categoryname'],$selecttxt) !== false){
                    $jobcatlist[$key]['list'][$key2]['isshow'] = true;
                    $jobcatlist[$key]['isshow'] = true;
                }else{
                    $jobcatlist[$key]['list'][$key2]['isshow'] = false;
                }
            }
        }
        $res['jobcat_list'] = $jobcatlist;

        zimu_json($res);

    }elseif($op == 'resume_edit_save' ){

        $sms_paramter = Db::name('zimu_zhaopin_parameter2')->where('name', 'aliyunsms')->find();
        $sms_paramter = unserialize($sms_paramter['parameter']);

        $formtxt = json_decode(zimu_array_utf8($_GET['formtxt']),true);
        $formtxt = zimu_array_gbk($formtxt);
        $myresume = Db::name('zimu_zhaopin_resume')->where([['uid','=',$myuid['uid']]])->find();

        if (!$myuid['telephone'] && $sms_paramter['smsAppKey'] && !$myresume['telephone']) {
            $telephone    = trim($formtxt['telephone']);
            $mobile_vcode = trim($formtxt['code']);
            $sendsmslog = Db::name('zimu_zhaopin_sendsmslog')->where([['uid','=',$myuid['uid']],['type','=','code']])->order(['id'=>'desc'])->find();
            if ($myuid['verify_code'] != $mobile_vcode || $sendsmslog['mobile'] != $telephone) {
                zimu_json('',$language_zimu['new_mypersonal_inc_php_6'],202);
            }
        }

        if ($myuid['telephone'] && $myuid['telephone'] != $formtxt['telephone'] && $sms_paramter['smsAppKey']) {
            $telephone    = trim($formtxt['telephone']);
            $mobile_vcode = trim($formtxt['code']);
            $sendsmslog = Db::name('zimu_zhaopin_sendsmslog')->where([['uid','=',$myuid['uid']],['type','=','code']])->order(['id'=>'desc'])->find();
            if (!$mobile_vcode || $myuid['verify_code'] != $mobile_vcode || $sendsmslog['mobile'] != $telephone) {
                zimu_json('',$language_zimu['new_mypersonal_inc_php_7'],202);
            }
        }

        if($myuid['telephone'] != $formtxt['telephone']){
            Db::name('zimu_zhaopin_members')->where('uid', $myuid['uid'])->data(['telephone' => $formtxt['telephone']])->update();
            Db::name('common_member_profile')->where('uid', $myuid['uid'])->data(['mobile' => $formtxt['telephone']])->update();
        }


        $myresume['work_nums'] = Db::name('zimu_zhaopin_resume_work')->where([['uid','=',$myuid['uid']]])->order(['id'=>'asc'])->count();
        $myresume['education_nums'] = Db::name('zimu_zhaopin_resume_education')->where([['uid','=',$myuid['uid']]])->order(['id'=>'asc'])->count();

        $setsqlarr['complete_percent'] = 0;
        $setsqlarr['uid']   = $myuid['uid'];
        $setsqlarr['title'] = $language_zimu['new_mypersonal_inc_php_8'] . date('Ymd');
        $setsqlarr['fullname'] = $formtxt['fullname'];
        $setsqlarr['complete_percent'] = $setsqlarr['fullname'] ? ($setsqlarr['complete_percent']+10) : $setsqlarr['complete_percent'];
        $setsqlarr['sex'] = $formtxt['sex'];
        $setsqlarr['sex_cn'] = $formtxt['sex_cn'];
        $setsqlarr['nature'] = $formtxt['nature'];
        $setsqlarr['nature_cn'] = $formtxt['nature_cn'];
        $setsqlarr['trade'] = implode(',',$formtxt['trade']);
        $setsqlarr['trade_cn'] = trim($formtxt['trade_cn2'],',');
        $setsqlarr['complete_percent'] = $setsqlarr['trade'] ? ($setsqlarr['complete_percent']+0) : $setsqlarr['complete_percent'];
        $setsqlarr['birthdate'] = $formtxt['birthdate'];
        $setsqlarr['complete_percent'] = $setsqlarr['birthdate'] ? ($setsqlarr['complete_percent']+5) : $setsqlarr['complete_percent'];
        $setsqlarr['age'] = date('Y') - $setsqlarr['birthdate'];
        $setsqlarr['experience'] = $formtxt['experience'];
        $setsqlarr['experience_cn'] = $formtxt['experience_cn'];
        $setsqlarr['complete_percent'] = $setsqlarr['experience'] ? ($setsqlarr['complete_percent']+5) : $setsqlarr['complete_percent'];
        $setsqlarr['district'] = implode(',',$formtxt['district']);
        $setsqlarr['district_cn'] = trim($formtxt['district_cn2'],',');
        $setsqlarr['complete_percent'] = $setsqlarr['district'] ? ($setsqlarr['complete_percent']+5) : $setsqlarr['complete_percent'];
        $setsqlarr['wage'] = $formtxt['wage'];
        $setsqlarr['wage_cn'] = $formtxt['wage_cn'];
        $setsqlarr['education'] = $formtxt['education'];
        $setsqlarr['education_cn'] = $formtxt['education_cn'];
        $setsqlarr['complete_percent'] = $setsqlarr['education'] ? ($setsqlarr['complete_percent']+5) : $setsqlarr['complete_percent'];
        $setsqlarr['tag'] = implode(',',$formtxt['tag']);
        $setsqlarr['tag_cn'] = implode(',',$formtxt['tag_cn']);
        $setsqlarr['telephone'] = $formtxt['telephone'];
        $setsqlarr['intention_jobs_id'] = implode(',',$formtxt['jobcat']);
        $setsqlarr['intention_jobs'] = trim($formtxt['jobcat_cn2'],',');
        $setsqlarr['complete_percent'] = $setsqlarr['intention_jobs_id'] ? ($setsqlarr['complete_percent']+5) : $setsqlarr['complete_percent'];
        $setsqlarr['specialty'] = $formtxt['specialty'];
        $setsqlarr['specialty'] = preg_replace('/([0-9]{11,})|([0-9]{3,4}-[0-9]{7,10})|([0-9]{3,4}-[0-9]{2,5}-[0-9]{2,5})/', '', $setsqlarr['specialty']);
        $setsqlarr['specialty'] = filterComment($setsqlarr['specialty'],$zmdata['settings']['notwords']);
        $setsqlarr['complete_percent'] = $setsqlarr['specialty'] ? ($setsqlarr['complete_percent']+15) : $setsqlarr['complete_percent'];
        if($setsqlarr['sex']==1){
            $photo_img = $_G['siteurl'].'source/plugin/zimu_zhaopin/static/wap/images/no_photo_male.png';
        }else{
            $photo_img = $_G['siteurl'].'source/plugin/zimu_zhaopin/static/wap/images/no_photo_female.png';
        }
        $setsqlarr['photo_img'] = $_GET['logo'] ? $_GET['logo'] : $photo_img;
        $setsqlarr['complete_percent'] = $setsqlarr['photo_img'] ? ($setsqlarr['complete_percent']+10) : $setsqlarr['complete_percent'];
        $setsqlarr['photo'] = 1;
        $setsqlarr['current'] = $formtxt['current'];
        $setsqlarr['current_cn'] = $formtxt['current_cn'];
        $setsqlarr['def'] = 1;

        $setsqlarr['complete_percent'] = $myresume['work_nums'] ? ($setsqlarr['complete_percent']+20) : $setsqlarr['complete_percent'];
        $setsqlarr['complete_percent'] = $myresume['education_nums'] ? ($setsqlarr['complete_percent']+20) : $setsqlarr['complete_percent'];

        if ($myresume['id']) {

            if($zmdata['settings']['resume_edit_audit']==0){
                $oldinfo = $myresume;
                $diff_info = array_merge($oldinfo,$setsqlarr);
                $diff_info2 = array_diff_assoc($diff_info,$oldinfo);
            }else{
                Db::name('zimu_zhaopin_resume')->where([['uid','=',$myuid['uid']]])->update($setsqlarr);
            }
            if($myresume['audit']==3){
                Db::name('zimu_zhaopin_resume')->where('uid', $myuid['uid'])->data(['audit' => 2])->update();
            }

            $rid = $myresume['id'];

            if ($diff_info2) {

                $isadd = Db::name('zimu_zhaopin_resume_audit')->where('uid', $myresume['uid'])->find();

                if(!$isadd){
                    Db::name('zimu_zhaopin_resume_audit')->insertGetId($setsqlarr);
                }else{
                    Db::name('zimu_zhaopin_resume_audit')->where('uid', $myresume['uid'])->update($setsqlarr);
                }

                $tip = $language_zimu['new_mypersonal_inc_php_9'];
                $keyword1 = $setsqlarr['fullname'].$setsqlarr['sex_cn'].$setsqlarr['age'].$setsqlarr['education_cn'];
                $remark = $language_zimu['new_mypersonal_inc_php_10'];
                $templatedata['first']['value'] = $tip;
                $templatedata['first']['color'] = "#FF4040";
                $templatedata['keyword1']['value'] = $keyword1;
                $templatedata['keyword2']['value'] = date('Y-m-d H:i', time());
                $templatedata['remark']['value'] = $remark;
                $apptpl['magapp']['tag'] = $tip;
                $apptpl['magapp']['title'] = $keyword1;
                $apptpl['magapp']['des'] = $remark;
                $apptpl['qfapp']['msg'] = $apptpl['magapp']['tag'];
                $apptpl['qfapp']['title'] = $apptpl['magapp']['title'];
                $apptpl['qfapp']['content'] = $apptpl['magapp']['des'];
                $tourl = $_G['siteurl'].'source/plugin/zimu_zhaopin/h5/pages/resume/view?ids='.$myresume['id'].'&mobile=2';
                $link = $_G['siteurl'].'plugin.php?id=zimu_zhaopin:new&model=newindex&tourl='.urlencode($tourl);
                notification_all('admin','wxtpl_admin',$templatedata,$apptpl,$link);

            }

        }else{

            $setsqlarr['audit'] = $zmdata['settings']['resume_new_audit'] ==1 ? 1 : 2;
            $setsqlarr['addtime'] = $setsqlarr['refreshtime'] = $setsqlarr['logintime'] = time();
            $newids = Db::name('zimu_zhaopin_resume')->insertGetId($setsqlarr);
            $rid = $newids;
            $tip = $language_zimu['new_mypersonal_inc_php_11'];
            $keyword1 = $setsqlarr['fullname'].$setsqlarr['sex_cn'].$setsqlarr['age'].$setsqlarr['education_cn'];
            $remark = $language_zimu['new_mypersonal_inc_php_12'];
            $templatedata['first']['value'] = $tip;
            $templatedata['first']['color'] = "#FF4040";
            $templatedata['keyword1']['value'] = $keyword1;
            $templatedata['keyword2']['value'] = date('Y-m-d H:i', time());
            $templatedata['remark']['value'] = $remark;
            $apptpl['magapp']['tag'] = $tip;
            $apptpl['magapp']['title'] = $keyword1;
            $apptpl['magapp']['des'] = $remark;
            $apptpl['qfapp']['msg'] = $apptpl['magapp']['tag'];
            $apptpl['qfapp']['title'] = $apptpl['magapp']['title'];
            $apptpl['qfapp']['content'] = $apptpl['magapp']['des'];
            $tourl = $_G['siteurl'].'source/plugin/zimu_zhaopin/h5/pages/resume/view?ids='.$newids.'&mobile=2';
            $link = $_G['siteurl'].'plugin.php?id=zimu_zhaopin:new&model=newindex&tourl='.urlencode($tourl);
            notification_all('admin','wxtpl_admin',$templatedata,$apptpl,$link);

        }

        if($zmdata['settings']['resume_join_money']){

            $is_resume_join_money = Db::name('zimu_zhaopin_order')->where([['service_name','=','resume_stick'],['uid','=',$myuid['uid']],['is_paid','=','2']])->order(['id'=>'desc'])->find();
            $is_resume_join_money2 = Db::name('zimu_zhaopin_order')->where([['service_name','=','resume_join_money'],['uid','=',$myuid['uid']],['is_paid','=','2']])->order(['id'=>'desc'])->find();

            if(!$is_resume_join_money && $is_resume_join_money2){
                $resume_join_money = $zmdata['settings']['resume_join_money'];
            }

        }

        if($resume_join_money){

            $params['oid']             = date('YmdHis') . mt_rand(100000, 999999);
            $params['zpid']            = $rid;
            $params['uid']             = $myuid['uid'];
            $params['openid']          = $myuid['openid'];
            $params['utype']           = 2;
            $params['order_type']      = 3;
            $params['pay_type']        = 2;
            $params['is_paid']         = 1;
            $params['amount']          = $resume_join_money;
            $params['pay_amount']      = $resume_join_money;
            $params['payment']         = 'wxpay';
            $params['payment_cn']      = $language_zimu['new_mypersonal_inc_php_13'];
            $params['description']     = $language_zimu['new_mypersonal_inc_php_14'];
            $params['service_name']    = 'resume_join_money';
            $params['addtime']         = time();
            $return_order_info['order_id'] = Db::name('zimu_zhaopin_order')->insertGetId($params);
            zimu_json($return_order_info);
        }

        zimu_json($res);

    }elseif($op == 'viewlog' ){

        $addtime = time() - 86400*7;
        $plist = Db::name('zimu_zhaopin_per_viewlog')->where([['uid','=',$myuid['uid']],['addtime','>',$addtime]])->order(['addtime'=>'desc'])->select()->toArray();

        foreach ($plist as $key => $value) {
            $res['plists'][$key] = Db::name('zimu_zhaopin_jobs')->where([['id','=',$value['jid']]])->order(['addtime'=>'desc'])->findOrEmpty();
            $res['plists'][$key]['refreshtime'] = $value['addtime'];
        }

        zimu_json($res);

    }elseif($op == 'jobs_favorites' ){

        $plist = Db::name('zimu_zhaopin_personal_favorites')->where([['personal_uid','=',$myuid['uid']]])->order(['addtime'=>'desc'])->select()->toArray();

        foreach ($plist as $key => $value) {
            $res['plists'][$key] = Db::name('zimu_zhaopin_jobs')->where([['id','=',$value['jobs_id']]])->order(['addtime'=>'desc'])->findOrEmpty();
            $res['plists'][$key]['refreshtime'] = $value['addtime'];
        }

        zimu_json($res);

    }elseif($op == 'attention_com' ){

        $plist = Db::name('zimu_zhaopin_personal_focus_company')->where([['uid','=',$myuid['uid']]])->order(['addtime'=>'desc'])->select()->toArray();

        foreach ($plist as $key => $value) {
            $res['plists'][$key] = Db::name('zimu_zhaopin_company_profile')->where([['id','=',$value['company_id']]])->order(['addtime'=>'desc'])->findOrEmpty();
            $res['plists'][$key]['refreshtime'] = $value['addtime'];
            if ($res['plists'][$key]['tag_cn']) {
                $res['plists'][$key]['tag_cn2'] = explode(',',$res['plists'][$key]['tag_cn']);
            }
            $res['plists'][$key]['logo'] = $res['plists'][$key]['logo'] ? $res['plists'][$key]['logo'] : $company_nologo;
            $res['plists'][$key]['telephone'] = substr_replace($res['plists'][$key]['telephone'], '****', 3, 4);
            $res['plists'][$key]['jobs'] = Db::name('zimu_zhaopin_jobs')->where([['company_id','=',$value['company_id']],['audit','<>',3],['display','<>',2]])->count();
        }

        zimu_json($res);

    }elseif($op == 'jobs_apply' ){

        $plist = Db::name('zimu_zhaopin_personal_jobs_apply')->where([['personal_uid','=',$myuid['uid']]])->order(['apply_addtime'=>'desc'])->select()->toArray();

        foreach ($plist as $key => $value) {
            $res['plists'][$key] = Db::name('zimu_zhaopin_jobs')->where([['id','=',$value['jobs_id']]])->order(['addtime'=>'desc'])->findOrEmpty();
            $res['plists'][$key]['refreshtime'] = $value['apply_addtime'];
        }

        zimu_json($res);

    }elseif($op == 'jobs_interview' ){

        $plist = Db::name('zimu_zhaopin_company_interview')->where([['resume_uid','=',$myuid['uid']]])->order(['interview_addtime'=>'desc'])->select()->toArray();

        foreach ($plist as $key => $value) {
            $res['plists'][$key] = Db::name('zimu_zhaopin_jobs')->where([['id','=',$value['jobs_id']]])->order(['addtime'=>'desc'])->findOrEmpty();
            $res['plists'][$key]['refreshtime'] = $value['interview_addtime'];
            $res['plists'][$key]['interview'] = $value;
        }

        zimu_json($res);

    }elseif($op == 'service_stick' ){

        $service_id = intval($_GET['service_id']);

        $service_info = Db::name('zimu_zhaopin_setmeal_increment')->where([['id','=',$service_id]])->find();

        $new_price = $service_info['price'];

        $myresume = Db::name('zimu_zhaopin_resume')->where([['uid','=',$myuid['uid']]])->find();

        $params['oid']           = date('YmdHis') . mt_rand(100000, 999999);
        $params['zpid']          = $myresume['id'];
        $params['uid']           = $myuid['uid'];
        $params['openid']        = $myuid['openid'];
        $params['utype']           = 2;
        $params['order_type']      = 3;
        $params['pay_type']        = 2;
        $params['is_paid']         = 1;
        $params['amount']        = $new_price;
        $params['pay_amount']    = $new_price;
        $params['payment']      = 'wxpay';
        $params['payment_cn']   = $language_zimu['new_mypersonal_inc_php_15'];
        $params['description']   = $service_info['name'];
        $params['service_name']  = 'resume_stick';
        $params_array            = array(
            'days' => $service_info['value']
        );
        $params_array['resume_id'] = $myresume['id'];
        $params['params']        = serialize($params_array);
        $params['addtime']       = time();
        $return_order_info['order_id'] = Db::name('zimu_zhaopin_order')->insertGetId($params);
        zimu_json($return_order_info);

    }elseif($op == 'resume_replenish' ){

        $resume = Db::name('zimu_zhaopin_resume')->where([['uid','=',$myuid['uid']]])->find();
        if(!$resume){
            $res['type'] = 'noresume';
            zimu_json($res);
        }
        $res['resume'] = $resume;
        $res['resume']['age'] = date('Y') - $resume['birthdate'];

        $work_list = Db::name('zimu_zhaopin_resume_work')->where([['uid','=',$resume['uid']]])->order(['id'=>'desc'])->select()->toArray();
        $res['resume']['work_list'] = _get_duration($work_list);

        $edulist = Db::name('zimu_zhaopin_resume_education')->where([['uid','=',$resume['uid']]])->order(['id'=>'desc'])->select()->toArray();
        $res['resume']['edulist'] = _get_duration($edulist);

        $res['resume']['complete_percent_base'] = updata_resume_percent($res['resume'],'getbase');

        $res['wapfooter'] = $zmdata['settings']['wapfooterhtml'];

        zimu_json($res);

    }elseif($op == 'getwork' ){

        if($ids){
            $res['work'] = Db::name('zimu_zhaopin_resume_work')->where([['id','=',$ids]])->order(['id'=>'desc'])->find();
        }
        zimu_json($res);

    }elseif($op == 'editwork' ){

        $formtxt = json_decode(zimu_array_utf8($_GET['formtxt']),true);
        $formtxt = zimu_array_gbk($formtxt);
        $myresume = Db::name('zimu_zhaopin_resume')->where([['uid','=',$myuid['uid']]])->find();

        $i_resume_work['pid'] = $myresume['id'];
        $i_resume_work['uid'] = $myuid['uid'];
        $i_resume_work['startyear'] = $formtxt['startyear'];
        $i_resume_work['startmonth'] = $formtxt['startmonth'];
        $i_resume_work['endyear'] = $formtxt['endyear'];
        $i_resume_work['endmonth'] = $formtxt['endmonth'];
        $i_resume_work['companyname'] = $formtxt['companyname'];
        $i_resume_work['jobs'] = $formtxt['jobs'];
        $i_resume_work['achievements'] = $formtxt['achievements'];
        $i_resume_work['todate'] = $formtxt['todate'];
        if($ids){
            Db::name('zimu_zhaopin_resume_work')->where([['id','=',$ids]])->data($i_resume_work)->update();
        }else{
            Db::name('zimu_zhaopin_resume_work')->insert($i_resume_work);
        }

        $tip = $ids ? $language_zimu['new_mypersonal_inc_php_16'] : $language_zimu['new_mypersonal_inc_php_17'];
        $keyword1 = $myresume['fullname'].$myresume['sex_cn'].$myresume['age'].$formtxt['companyname'];
        $remark = $language_zimu['new_mypersonal_inc_php_18'];
        $templatedata['first']['value'] = $tip;
        $templatedata['first']['color'] = "#FF4040";
        $templatedata['keyword1']['value'] = $keyword1;
        $templatedata['keyword2']['value'] = date('Y-m-d H:i', time());
        $templatedata['remark']['value'] = $remark;
        $apptpl['magapp']['tag'] = $tip;
        $apptpl['magapp']['title'] = $keyword1;
        $apptpl['magapp']['des'] = $remark;
        $apptpl['qfapp']['msg'] = $apptpl['magapp']['tag'];
        $apptpl['qfapp']['title'] = $apptpl['magapp']['title'];
        $apptpl['qfapp']['content'] = $apptpl['magapp']['des'];
        $tourl = $_G['siteurl'].'source/plugin/zimu_zhaopin/h5/pages/resume/view?ids='.$myresume['id'].'&mobile=2';
        $link = $_G['siteurl'].'plugin.php?id=zimu_zhaopin:new&model=newindex&tourl='.urlencode($tourl);
        notification_all('admin','wxtpl_admin',$templatedata,$apptpl,$link);

        updata_resume_percent($myresume);
        zimu_json($res);

    }elseif($op == 'delwork' ){
        Db::name('zimu_zhaopin_resume_work')->where([['id','=',$ids]])->delete();
        $myresume = Db::name('zimu_zhaopin_resume')->where([['uid','=',$myuid['uid']]])->find();
        updata_resume_percent($myresume);
        zimu_json($res);

    }elseif($op == 'getedu' ){

        if($ids){
            $res['edu'] = Db::name('zimu_zhaopin_resume_education')->where([['id','=',$ids]])->order(['id'=>'desc'])->find();
        }
        $res['education_list'] = Db::name('zimu_zhaopin_category')->field('c_id as value,c_name as label')->where([['c_alias','=','ZM_education']])->order(['c_id'=>'asc'])->select()->toArray();
        zimu_json($res);

    }elseif($op == 'editedu' ){

        $formtxt = json_decode(zimu_array_utf8($_GET['formtxt']),true);
        $formtxt = zimu_array_gbk($formtxt);
        $myresume = Db::name('zimu_zhaopin_resume')->where([['uid','=',$myuid['uid']]])->find();

        $i_resume_education['pid'] = $myresume['id'];
        $i_resume_education['uid'] = $myuid['uid'];
        $i_resume_education['startyear'] = $formtxt['startyear'];
        $i_resume_education['startmonth'] = $formtxt['startmonth'];
        $i_resume_education['endyear'] = $formtxt['endyear'];
        $i_resume_education['endmonth'] = $formtxt['endmonth'];
        $i_resume_education['school'] = $formtxt['school'];
        $i_resume_education['speciality'] = $formtxt['speciality'];
        $i_resume_education['education'] = $formtxt['education'];
        $i_resume_education['education_cn'] = $formtxt['education_cn'];
        $i_resume_education['todate'] = $formtxt['todate'];
        if($ids){
            Db::name('zimu_zhaopin_resume_education')->where([['id','=',$ids]])->data($i_resume_education)->update();
        }else{
            Db::name('zimu_zhaopin_resume_education')->insert($i_resume_education);
        }

        $tip = $ids ? $language_zimu['new_mypersonal_inc_php_19'] : $language_zimu['new_mypersonal_inc_php_20'];
        $keyword1 = $myresume['fullname'].$myresume['sex_cn'].$myresume['age'].$formtxt['school'];
        $remark = $language_zimu['new_mypersonal_inc_php_21'];
        $templatedata['first']['value'] = $tip;
        $templatedata['first']['color'] = "#FF4040";
        $templatedata['keyword1']['value'] = $keyword1;
        $templatedata['keyword2']['value'] = date('Y-m-d H:i', time());
        $templatedata['remark']['value'] = $remark;
        $apptpl['magapp']['tag'] = $tip;
        $apptpl['magapp']['title'] = $keyword1;
        $apptpl['magapp']['des'] = $remark;
        $apptpl['qfapp']['msg'] = $apptpl['magapp']['tag'];
        $apptpl['qfapp']['title'] = $apptpl['magapp']['title'];
        $apptpl['qfapp']['content'] = $apptpl['magapp']['des'];
        $tourl = $_G['siteurl'].'source/plugin/zimu_zhaopin/h5/pages/resume/view?ids='.$myresume['id'].'&mobile=2';
        $link = $_G['siteurl'].'plugin.php?id=zimu_zhaopin:new&model=newindex&tourl='.urlencode($tourl);
        notification_all('admin','wxtpl_admin',$templatedata,$apptpl,$link);


        updata_resume_percent($myresume);
        zimu_json($res);

    }elseif($op == 'deledu' ){
        Db::name('zimu_zhaopin_resume_education')->where([['id','=',$ids]])->delete();
        $myresume = Db::name('zimu_zhaopin_resume')->where([['uid','=',$myuid['uid']]])->find();
        updata_resume_percent($myresume);
        zimu_json($res);

    }elseif($op == 'change_current' ){
        $current_id = intval($_GET['current_id']);
        $current_name = zimu_array_gbk($_GET['current_name']);

        if($current_id==888){
            Db::name('zimu_zhaopin_resume')->where('uid', $myuid['uid'])->data(['display' => 2])->update();
        }else{
            Db::name('zimu_zhaopin_resume')->where('uid', $myuid['uid'])->data(['display' => 1,'current' => $current_id,'current_cn' => $current_name])->update();
        }
        zimu_json($res);

    }elseif($op == 'mypersonal' ){

        $res['resume'] = $resume = Db::name('zimu_zhaopin_resume')->where([['uid','=',$myuid['uid']]])->find();
        if($res['resume']){
            updata_resume_percent($res['resume']);
            $res['resume']['auditinfo'] = Db::name('zimu_zhaopin_resume_audit')->where('uid', $myuid['uid'])->find();
            $work_list = Db::name('zimu_zhaopin_resume_work')->where([['uid','=',$myuid['uid']]])->order(['id'=>'desc'])->select()->toArray();
            $res['resume']['work_list'] = count($work_list);

            $edulist = Db::name('zimu_zhaopin_resume_education')->where([['uid','=',$myuid['uid']]])->order(['id'=>'desc'])->select()->toArray();
            $res['resume']['edulist'] = count($edulist);
            Db::name('zimu_zhaopin_members')->where('uid', $myuid['uid'])->data(['utype' => 2])->update();
        }

        if($zmdata['settings']['login_replenish_resume']==1 && $res['resume']['refreshtime'] < strtotime(date('Y-m-d', time())) ){
            $res['resume']['refreshtime'] = time();
            Db::name('zimu_zhaopin_resume')->where('uid', $myuid['uid'])->data(['refreshtime' => time()])->update();
        }

        $category = Db::name('zimu_zhaopin_category')->order(['c_order'=>'asc','c_id'=>'asc'])->select()->toArray();

        foreach ($category as $key => $value) {
            $category2[$value['c_alias']][$value['c_id']]['value'] = $value['c_id'];
            $category2[$value['c_alias']][$value['c_id']]['label'] = $value['c_name'];
        }

        $current_list = $category2['ZM_current'];
        array_multisort($current_list);
        $res['current_list'] = $current_list;
        foreach ($res['current_list'] as $key => $value) {
            $res['current_list2'][$key]['text'] = $value['label'];
            if($res['resume']['current'] == $value['value'] && $res['resume']['display'] != 2){
                $res['current_list2'][$key]['color'] = '#FF6600';
            }
        }
        $current_list2[0]['text'] = $language_zimu['new_mypersonal_inc_php_22'];
        if($res['resume']['display'] == 2){
            $current_list2[0]['color'] = '#FF6600';
        }
        $res['current_list2'] = array_merge($res['current_list2'],$current_list2);

        $res['resume']['countapply'] = Db::name('zimu_zhaopin_personal_jobs_apply')->where([['personal_uid','=',$myuid['uid']]])->count();
        $res['resume']['count_jobs_interview'] = Db::name('zimu_zhaopin_company_interview')->where([['resume_uid','=',$myuid['uid']]])->count();
        $res['resume']['count_fav_jobs'] = Db::name('zimu_zhaopin_personal_favorites')->where([['personal_uid','=',$myuid['uid']]])->count();
        $res['resume']['count_fav_company'] = Db::name('zimu_zhaopin_personal_focus_company')->where([['uid','=',$myuid['uid']]])->count();
        $res['resume']['count_fav'] = intval($res['resume']['count_fav_jobs'])+intval($res['resume']['count_fav_company']);

        if($res['resume']['kefu_uid']){
            $kefudata = Db::name('zimu_zhaopin_kefu')->where([['uid','=',$res['resume']['kefu_uid']]])->find();
            $res['resume']['kefu_mobile'] = $kefudata['kefu_mobile'];
            $res['resume']['kefu_wxid'] = $kefudata['kefu_wxid'];
        }else{
            $res['resume']['kefu_mobile'] = $zmdata['settings']['kefu_mobile'];
            $res['resume']['kefu_wxid'] = $zmdata['settings']['kefu_wxid'];
        }

        $res['sticklist'] = Db::name('zimu_zhaopin_setmeal_increment')->where([['cat','=','resume_stick']])->order(['sort'=>'desc','id'=>'asc'])->select()->toArray();

        foreach ($res['sticklist'] as $key => $value) {
            $res['sticklist2'][$key]['text'] = $value['name'].'('.$value['price'].$zmdata['settings']['money_name'].')';
        }

        $paramter = Db::name('zimu_zhaopin_parameter2')->where([['name','=','wappopup']])->order(['id'=>'asc'])->find();
        $res['wappopup'] = unserialize($paramter['parameter']);
        $res['wapfooter'] = $zmdata['settings']['wapfooterhtml'];
        $res['zmdata']['show_bindmp_qrcode'] = 0;

        if(strlen($myuid['openid']) < 10 || strlen($myuid['openid']) > 50){
            $myuid['openid'] = '';
            Db::name('zimu_zhaopin_members')->where('uid', $myuid['uid'])->data(['openid' => ''])->update();
        }

        if(file_exists(DISCUZ_ROOT . './source/plugin/zimu_zhaopin/module/adminss/adminss_imconfig.inc.php')){
            $imchat_parameter = Db::name('zimu_zhaopin_parameter2')->where('name', 'imchat')->order('id','desc')->find();
            $imchat_parameter = unserialize($imchat_parameter['parameter']);
            if($imchat_parameter['open_im']) {
                $res['zmdata']['open_im'] = 1;
                $res['zmdata']['im_counts'] = get_im_noread_counts($myuid);
            }
        }

        if($myuid['openid'] && IN_WECHAT){
            require_once DISCUZ_ROOT . './source/plugin/zimu_zhaopin/class/wechat.lib.class.php';
            $wechat_client = new WeChatClient($zmdata['base']['weixin_appid'], $zmdata['base']['weixin_appsecret']);
            $wechatinfo    = $wechat_client->getUserInfoById($myuid['openid']);
            if ($wechatinfo['subscribe'] == 1) {
                Db::name('zimu_zhaopin_company_profile')->where('uid', $myuid['uid'])->data(['bind_weixin' => 1])->update();
                Db::name('zimu_zhaopin_resume')->where('uid', $myuid['uid'])->data(['bind_weixin' => 1])->update();
            } elseif ($wechatinfo['openid'] && $wechatinfo['subscribe'] == 0) {
                $res['zmdata']['show_bindmp_qrcode'] = 1;
                $res['zmdata']['bindmp_qrcode_url'] = $zmdata['settings']['mp_qrcode_url'];
                $res['zmdata']['bindmpmp_qrcode_text1'] = $zmdata['settings']['mp_qrcode_text'];
                $res['zmdata']['bindmpmp_qrcode_text2'] = $language_zimu['new_mypersonal_inc_php_23'];
                Db::name('zimu_zhaopin_company_profile')->where('uid', $myuid['uid'])->data(['bind_weixin' => 0])->update();
                Db::name('zimu_zhaopin_resume')->where('uid', $myuid['uid'])->data(['bind_weixin' => 0])->update();
            }
        }elseif (!$myuid['openid'] && IN_WECHAT){
            $res['zmdata']['show_bindmp_qrcode'] = 1;
            $bind_url = ZIMUCMS_URL.':new&model=newindex&tourl='.urlencode(ZIMUCMS_URL2.'pages/index/my?mobile=2');
            $res['zmdata']['bindmp_qrcode_url'] = ZIMUCMS_URL.'&model=toqrcode&url='.urlencode($bind_url);
            $res['zmdata']['bindmpmp_qrcode_text1'] = $language_zimu['new_mypersonal_inc_php_24'];
            $res['zmdata']['bindmpmp_qrcode_text2'] = $language_zimu['new_mypersonal_inc_php_25'];
        }
        $res['zmdata']['uid'] = $myuid['old_uid'] ? $myuid['old_uid'] : $myuid['uid'];
        $res['zmdata']['toutiao_audit'] = $zmdata['settings']['toutiao_audit'];
        zimu_json($res);

    }