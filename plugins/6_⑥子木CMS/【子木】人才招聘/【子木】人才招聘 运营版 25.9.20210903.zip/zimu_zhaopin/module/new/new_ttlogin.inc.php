<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if (!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }

    use think\Db;

    $mobile = addslashes($_GET['mobile']);
    $code = addslashes($_GET['code']);

    $isreal = Db::name('zimu_zhaopin_sendsmslog')->where([['mobile','=',$mobile],['con','=',$language_zimu['new_ttlogin_inc_php_0'].$code],['type','=','toutiao_code']])->order('id', 'desc')->find();
    if(!$mobile || !$isreal){
        zimu_json('',$language_zimu['new_ttlogin_inc_php_1'],1);
    }

    $isuid = Db::name('zimu_zhaopin_company_profile')->where([['telephone','=',$mobile]])->order('id', 'desc')->value('uid');
    if(!$isuid){
        $isuid = Db::name('zimu_zhaopin_resume')->where([['telephone','=',$mobile]])->order('id', 'desc')->value('uid');
    }
    if($zmdata['settings']['h5_isapp']==1 && !$isuid){
        $isuid = Db::name('user_mobile_relations')->where([['phone','=',$mobile]])->order('id', 'desc')->value('userid');
    }
    if($zmdata['settings']['h5_isapp']==2 && !$isuid){
        $isuid = Db::name('phonebind')->where([['phone','=',$mobile]])->order('id', 'desc')->value('uid');
    }
    if($zmdata['settings']['h5_isapp']==3 && !$isuid){
        $isuid = Db::name('appbyme_sendsms')->where([['mobile','=',$mobile]])->order('id', 'desc')->value('uid');
    }

    if($isuid){
        $myuid = Db::name('zimu_zhaopin_members')->where([['uid','=',$isuid]])->order('id', 'desc')->find();
        if(!$myuid){
            $myuid = array(
                'uid' => $isuid,
                'utype' => 1,
                'telephone' => $mobile,
                'verify_code' => $code,
                'token' => getRandChar(64),
                'onlinetime' => time(),
            );
            Db::name('zimu_zhaopin_members')->insert($myuid);
        }
        if(!$myuid['token']){
            $myuid['token'] = $tokeninfo['token'] = getRandChar(32);
            Db::name('zimu_zhaopin_members')->where('uid', $myuid['uid'])->update(['token' => $tokeninfo['token']]);
        }
        tongbu_h5_mobile2($mobile,$isuid,$zmdata);
        $res['myinfo'] = $myuid;
        zimu_json($res);
    }else{
        $xcx_zimu_data['username'] = 'DouYin';
        $xcx_zimu_data['username2'] = 'DouYin';
        $xcx_zimu_data['gender'] = 1;
        $xcx_zimu_data['avatar'] = '';
        $reguid = xcx_reg_user($xcx_zimu_data,$zmdata);
        $istoken = array(
            'uid' => $reguid,
            'utype' => 1,
            'telephone' => $mobile,
            'verify_code' => $code,
            'token' => getRandChar(64),
            'onlinetime' => time(),
        );
        Db::name('zimu_zhaopin_members')->insert($istoken);
        $res['myinfo'] = $istoken;
        tongbu_h5_mobile2($mobile,$reguid,$zmdata);
        zimu_json($res);
    }


