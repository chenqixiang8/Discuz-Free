<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if (!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }

    use think\Db;

    $token = addslashes($_GET['token']);
    $islogin = intval($_GET['islogin']);
    $myuid = checktoken($token,$islogin);
    if($myuid['uid']>0){
        $check_company_setmeal = check_company_setmeal($myuid['uid']);
    }
    $op = addslashes($_GET['op']);
    $ids = intval($_GET['ids']);

    if($op == 'tofav') {

        $has = Db::name('zimu_zhaopin_company_favorites')->where([['company_uid','=',$myuid['uid']],['resume_id','=',$ids]])->find();

        if($has){
            Db::name('zimu_zhaopin_company_favorites')->where('did', $has['did'])->delete();
            $res['tip'] = $language_zimu['new_viewresume_inc_php_0'];
        }else{
            $data['company_uid']       = $myuid['uid'];
            $data['resume_id']        = $ids;
            $data['favorites_addtime']     = time();
            Db::name('zimu_zhaopin_company_favorites')->insert($data);
            $res['tip'] = $language_zimu['new_viewresume_inc_php_1'];
        }

        zimu_json($res);

    }elseif($op == 'todown' ){

        $company_profile = Db::name('zimu_zhaopin_company_profile')->where([['uid','=',$myuid['uid']]])->find();

        if(!$company_profile){
            $res['type'] = 'nocompany';
            $res['tip'] = $language_zimu['new_viewresume_inc_php_2'];
            zimu_json($res);
        }

        $company_jobs = Db::name('zimu_zhaopin_jobs')->where([['uid','=',$myuid['uid']]])->find();

        if(!$company_jobs){
            $res['type'] = 'nocompany';
            $res['tip'] = $language_zimu['new_viewresume_inc_php_3'];
            zimu_json($res);
        }


        if($zmdata['settings']['com_down_resume_audit'] && $company_profile['audit'] !=1 ){
            $res['type'] = 'error';
            $res['tip'] = $language_zimu['new_viewresume_inc_php_4'].'<br>'.$language_zimu['new_viewresume_inc_php_5'].'<br><img style="width:200px;" src="'.$zmdata['settings']['kefu_qrcode_url'].'">';
            zimu_json($res);
        }

        $my_setmeal = Db::name('zimu_zhaopin_members_setmeal')->where([['uid','=',$myuid['uid']]])->find();
        $my_setmeal['download_resume'] = $my_setmeal['download_resume']+$my_setmeal['download_resume2'];

        $isdown = Db::name('zimu_zhaopin_company_down_resume')->where([['company_uid','=',$myuid['uid']],['resume_id','=',$ids]])->find();
        if($isdown){
            $res['type'] = 'error';
            $res['tip'] = $language_zimu['new_viewresume_inc_php_6'];
            zimu_json($res);
        }

        $zp_setmeal = Db::name('zimu_zhaopin_setmeal')->where([['id','=',$my_setmeal['setmeal_id']]])->find();
        $is_apply = Db::name('zimu_zhaopin_personal_jobs_apply')->where([['company_uid','=',$myuid['uid']],['resume_id','=',$ids]])->find();

        if($zp_setmeal['resume_apply_free']==1 && $is_apply){
            $tip = $language_zimu['new_viewresume_inc_php_7'];
            $res['tip'] = $tip;
            $res['type'] = 'to_down_true';
            zimu_json($res);
        }

        $downnum = Db::name('zimu_zhaopin_company_down_resume')->where([['company_uid','=',$myuid['uid']],['down_addtime','>',strtotime(date('Y-m-d', time()))]])->count();

        if($my_setmeal['download_resume_max'] > 0){
            if($downnum >= $my_setmeal['download_resume_max']){
                if($zmdata['settings']['resume_download_quick'] == 1){
                    $tip = $language_zimu['new_viewresume_inc_php_8'].$downnum.$language_zimu['new_viewresume_inc_php_9'];
                    $res['type'] = 'to_setmeal_pay';
                }else{
                    $tip = $language_zimu['new_viewresume_inc_php_10'].$downnum.$language_zimu['new_viewresume_inc_php_11'];
                    $res['type'] = 'to_setmeal';
                }
                $res['text'] = $language_zimu['new_viewresume_inc_php_12'];
                $res['tip'] = $tip;
                zimu_json($res);
            }
        }

        if ($my_setmeal['download_resume']<=0){
            if($zmdata['settings']['resume_download_quick'] == 1){
                $tip = $language_zimu['new_viewresume_inc_php_13'];
                $res['type'] = 'to_setmeal_pay_bao';
            }else{
                $tip = $language_zimu['new_viewresume_inc_php_14'];
                $res['type'] = 'to_setmeal_bao';
            }
            $res['tip'] = $tip;
            $res['text'] = $language_zimu['new_viewresume_inc_php_15'];

            $setmeal = Db::name('zimu_zhaopin_members_setmeal')->where([['uid','=',$myuid['uid']]])->find();

            $res['dlresume_list'] = Db::name('zimu_zhaopin_setmeal_increment')->where([['cat','=','download_resume']])->order(['sort'=>'desc','id'=>'asc'])->select()->toArray();

            foreach ($res['dlresume_list'] as $key => $value) {
                if($setmeal['discount_download_resume']>0){
                    $res['dlresume_list2'][$key]['text'] = $value['name'];
                    $res['dlresume_list2'][$key]['description'] = $language_zimu['new_viewresume_inc_php_16'].round($value['price']*$setmeal['discount_download_resume']/10,2).$zmdata['settings']['money_name'].$language_zimu['new_viewresume_inc_php_17'].round($value['price']*$setmeal['discount_download_resume']/10/$value['value'],2).$zmdata['settings']['money_name'].'/'.$language_zimu['new_viewresume_inc_php_18'].'('.$language_zimu['new_viewresume_inc_php_19'].$value['price'].$zmdata['settings']['money_name'].')';
                }else{
                    $res['dlresume_list2'][$key]['text'] = $value['name'];
                    $res['dlresume_list2'][$key]['description'] = $language_zimu['new_viewresume_inc_php_20'].round($value['price']/$value['value'],2).$zmdata['settings']['money_name'].'/'.$language_zimu['new_viewresume_inc_php_21'].'('.$language_zimu['new_viewresume_inc_php_22'].$value['price'].$zmdata['settings']['money_name'].')';
                }
            }

            zimu_json($res);
        }else{
            $tip = $language_zimu['new_viewresume_inc_php_23'].$my_setmeal['download_resume'].$language_zimu['new_viewresume_inc_php_24'];
            $res['tip'] = $tip;
            $res['type'] = 'to_down_true';
            zimu_json($res);
        }

    }elseif($op == 'todown_true' ){

        $setsqlarr2['resume_id'] = $ids;
        $setsqlarr2['company_uid'] = $myuid['uid'];
        $setsqlarr2['down_addtime'] = time();
        Db::name('zimu_zhaopin_company_down_resume')->insert($setsqlarr2);
        $my_setmeal = Db::name('zimu_zhaopin_members_setmeal')->where([['uid','=',$myuid['uid']]])->find();
        $zp_setmeal = Db::name('zimu_zhaopin_setmeal')->where([['id','=',$my_setmeal['setmeal_id']]])->find();

        $is_apply = Db::name('zimu_zhaopin_personal_jobs_apply')->where([['company_uid','=',$myuid['uid']],['resume_id','=',$ids]])->find();

        if($zp_setmeal['resume_apply_free'] ==1 && $is_apply){

        }else{
            if($my_setmeal['download_resume']>0){
                Db::name('zimu_zhaopin_members_setmeal')->where('uid', $myuid['uid'])->dec('download_resume')->update();
            }else{
                Db::name('zimu_zhaopin_members_setmeal')->where('uid', $myuid['uid'])->dec('download_resume2')->update();
            }
        }

        $resume = Db::name('zimu_zhaopin_resume')->where([['id','=',$ids]])->find();

        $res['telephone'] = $resume['telephone'];
        zimu_json($res);

    }elseif($op == 'down_all_apply_resume' ){

        $selecttxt = json_decode(zimu_array_utf8($_GET['selecttxt']),true);
        $selecttxt = zimu_array_gbk($selecttxt);

        $wheresql2[] = ['b.company_uid','=',$myuid['uid']];
        if($selecttxt['diy1']){
            $wheresql2[] = ['b.jobs_id','=',$selecttxt['diy1']];
        }
        if($selecttxt['diy2']){
            $wheresql2[] = ['b.is_reply','=',$selecttxt['diy2']];
            $plists = Db::name('zimu_zhaopin_resume')->alias('a')->join('zimu_zhaopin_personal_jobs_apply b','b.resume_id = a.id')->where([$wheresql2])->order(['did'=>'desc'])->select()->toArray();
        }else{

            $plists1 = Db::name('zimu_zhaopin_resume')->alias('a')->join('zimu_zhaopin_personal_jobs_apply b','b.resume_id = a.id')->where([$wheresql2])->where([['b.is_reply','=',0]])->order(['did'=>'desc'])->select()->toArray();

            $plists2 = Db::name('zimu_zhaopin_resume')->alias('a')->join('zimu_zhaopin_personal_jobs_apply b','b.resume_id = a.id')->where([$wheresql2])->where([['b.is_reply','>',0]])->order(['did'=>'desc'])->select()->toArray();

            $plists = array_merge($plists1,$plists2);

        }

        $my_setmeal = Db::name('zimu_zhaopin_members_setmeal')->where([['uid','=',$myuid['uid']]])->find();
        $down_nums = 0;
        $zp_setmeal = Db::name('zimu_zhaopin_setmeal')->where([['id','=',$my_setmeal['setmeal_id']]])->find();

        foreach ($plists as $key => $value) {
            $isdown = Db::name('zimu_zhaopin_company_down_resume')->where([['company_uid','=',$myuid['uid']],['resume_id','=',$value['id']]])->find();

            $is_apply = Db::name('zimu_zhaopin_personal_jobs_apply')->where([['company_uid','=',$myuid['uid']],['resume_id','=',$value['id']]])->find();

            if(!$isdown){
                if($zp_setmeal['resume_apply_free'] ==1 && $is_apply){
                    $setsqlarr2['resume_id'] = $value['id'];
                    $setsqlarr2['company_uid'] = $myuid['uid'];
                    $setsqlarr2['down_addtime'] = time();
                    Db::name('zimu_zhaopin_company_down_resume')->insert($setsqlarr2);
                }else{
                    if($my_setmeal['download_resume'] > 0){
                        Db::name('zimu_zhaopin_members_setmeal')->where('uid', $myuid['uid'])->dec('download_resume')->update();
                        $my_setmeal['download_resume'] = $my_setmeal['download_resume']-1;
                        $setsqlarr2['resume_id'] = $value['id'];
                        $setsqlarr2['company_uid'] = $myuid['uid'];
                        $setsqlarr2['down_addtime'] = time();
                        Db::name('zimu_zhaopin_company_down_resume')->insert($setsqlarr2);
                        $down_nums = $down_nums + 1;
                    }elseif($my_setmeal['download_resume2'] > 0){
                        Db::name('zimu_zhaopin_members_setmeal')->where('uid', $myuid['uid'])->dec('download_resume2')->update();
                        $my_setmeal['download_resume2'] = $my_setmeal['download_resume2']-1;
                        $setsqlarr2['resume_id'] = $value['id'];
                        $setsqlarr2['company_uid'] = $myuid['uid'];
                        $setsqlarr2['down_addtime'] = time();
                        Db::name('zimu_zhaopin_company_down_resume')->insert($setsqlarr2);
                        $down_nums = $down_nums + 1;
                    }else{
                        break;
                    }
                }

            }
        }

        $tip = $language_zimu['new_viewresume_inc_php_25'].$down_nums.$language_zimu['new_viewresume_inc_php_26'];
        $res['tip'] = $tip;
        zimu_json($res);

    }elseif($op == 'toreport' ){

        $myuid = checktoken($token);
        $report_type = intval($_GET['report_type']);;
        $content = addslashes(zm_diconv($_GET['content']));
        $telephone = addslashes($_GET['telephone']);
        $data['uid'] = $myuid['uid'];
        $data['username'] = '';
        $data['jobs_id'] = $ids;
        $data['report_type'] = $report_type;
        $data['telephone'] = $telephone;
        $data['content'] = $content;
        $data['type'] = 2;
        $data['addtime'] = time();
        Db::name('zimu_zhaopin_report')->insert($data);

        zimu_json($res);


    }elseif($op == 'quick_audit' ){

        $audit = intval($_GET['audit']);
        $reason = zimu_array_gbk($_GET['reason']);
        $touid = intval($_GET['touid']);
        $auditinfo = Db::name('zimu_zhaopin_resume_audit')->where([['uid','=',$touid]])->find();
        if($auditinfo && $audit == 1){
            $auditinfo['audit'] = $audit;
            $auditinfo['wxtpl'] = $reason;
            unset($auditinfo['id']);
            Db::name('zimu_zhaopin_resume')->where('id', $ids)->data($auditinfo)->update();
        }else{
            Db::name('zimu_zhaopin_resume')->where('id', $ids)->data(['audit' => $audit,'wxtpl' => $reason])->update();
        }
        Db::name('zimu_zhaopin_resume_audit')->where('uid', $touid)->delete();
        resume_push($ids,$audit,$reason);
        zimu_json($res);

    }elseif($op == 'quick_blacklist' ){

        $touid = intval($_GET['touid']);
        $toblacklist = intval($_GET['toblacklist']) ? 0 : 1;
        $resume = Db::name('zimu_zhaopin_resume')->where([['uid','=',$touid]])->find();
        $company = Db::name('zimu_zhaopin_company_profile')->where([['uid','=',$touid]])->find();

        $manage_uids = str_replace(';', ',', $zmdata['manage_uids']);
        $manage_uids = explode(',', $manage_uids);
        if($myuid['uid'] && (in_array($myuid['uid'],$manage_uids) || $myuid['uid']==$resume['kefu_uid'] || $myuid['uid']==$company['kefu_uid'])){
            Db::name('zimu_zhaopin_members')->where('uid', $touid)->data(['blacklist' => $toblacklist])->update();
            $toaudit = $toblacklist ? 3 : 1;
            Db::name('zimu_zhaopin_resume')->where('uid', $touid)->data(['audit' => $toaudit])->update();
            Db::name('zimu_zhaopin_company_profile')->where('uid', $touid)->data(['audit' => $toaudit])->update();
            Db::name('zimu_zhaopin_jobs')->where('uid', $touid)->data(['company_audit' => $toaudit])->update();
        }
        zimu_json($res);

    }else{

        $resume = Db::name('zimu_zhaopin_resume')->where([['id','=',$ids]])->select()->toArray();
        $real_telephone = $resume[0]['telephone'];
        $real_fullname = $resume[0]['fullname'];
        $resume = format_resume($resume,$zmdata);
        $resume = $resume[0];

        if(!$resume){
            $res['type'] = 'noresume';
            $res['tip'] = $language_zimu['new_viewresume_inc_php_27'];
            zimu_json($res);
        }

        $res['resume'] = $resume;

        $manage_uids = str_replace(';', ',', $zmdata['manage_uids']);
        $manage_uids = explode(',', $manage_uids);
        if($myuid['uid'] && (in_array($myuid['uid'],$manage_uids) || $myuid['uid']==$res['resume']['kefu_uid'])){
            $res['resume']['isadmin'] = 1;
        }

        if(($resume['audit']==3 || $resume['display']==2) && $resume['uid'] != $myuid['uid'] && $res['resume']['isadmin'] != 1){
            $res['type'] = 'noshowresume';
            $res['tip'] = $language_zimu['new_viewresume_inc_php_28'];
            zimu_json($res);
        }

        $res['resume']['age'] = date('Y') - $resume['birthdate'];

        if($myuid['uid']>0){
            $res['company'] = Db::name('zimu_zhaopin_company_profile')->where([['uid','=',$myuid['uid']]])->find();
            $res['resume']['isresume'] = Db::name('zimu_zhaopin_company_down_resume')->where([['resume_id','=',$ids],['company_uid','=',$myuid['uid']]])->count();
            $res['resume']['hasfav'] = Db::name('zimu_zhaopin_company_favorites')->where([['resume_id','=',$ids],['company_uid','=',$myuid['uid']]])->count();
            if($res['company']){
                Db::name('zimu_zhaopin_personal_jobs_apply')->where([['company_uid','=',$myuid['uid']],['resume_id','=',$ids],['personal_look','=',1]])->data(['personal_look' => 2])->update();
            }
        }

        if($res['resume']['isresume']){
            $res['resume']['telephone'] = $real_telephone;
            $res['resume']['fullname'] = $real_fullname;
            $res['resume']['interview'] = Db::name('zimu_zhaopin_company_interview')->where([['company_uid','=',$myuid['uid']],['resume_id','=',$ids]])->order(['id'=>'desc'])->count();
        }

        $res['resume']['refreshtime'] = $res['resume']['refreshtime'] ? $res['resume']['refreshtime'] : $res['resume']['addtime'];
        if($res['resume']['refreshtime']>time()-86400){
            $res['resume']['activation'] = 100;
        }elseif ($res['resume']['refreshtime']>time()-86400*2){
            $res['resume']['activation'] = 80;
        }elseif ($res['resume']['refreshtime']>time()-86400*3){
            $res['resume']['activation'] = 60;
        }else{
            $res['resume']['activation'] = 50;
        }
        $res['resume']['downnums'] = Db::name('zimu_zhaopin_company_down_resume')->where([['resume_id','=',$ids]])->count();

        $work_list = Db::name('zimu_zhaopin_resume_work')->where([['uid','=',$resume['uid']]])->order(['startyear'=>'asc','id'=>'asc'])->select()->toArray();
        $res['resume']['work_list'] = _get_duration($work_list);
        $edulist = Db::name('zimu_zhaopin_resume_education')->where([['uid','=',$resume['uid']]])->order(['startyear'=>'asc','id'=>'asc'])->select()->toArray();
        $res['resume']['edulist'] = _get_duration($edulist);
        $res['resume']['ismy'] = $res['resume']['uid'] == $myuid['uid'] ? 1 : 0 ;
        $res['resume']['kefu_name'] = $zmdata['settings']['kefu_name'];
        $res['resume']['kefu_tel'] = $zmdata['settings']['kefu_tel'];
        $res['wapfooter'] = $zmdata['settings']['wapfooterhtml'];

        $setmeal = Db::name('zimu_zhaopin_members_setmeal')->where([['uid','=',intval($myuid['uid'])]])->find();

        $res['dlresume_list'] = Db::name('zimu_zhaopin_setmeal_increment')->where([['cat','=','download_resume']])->order(['sort'=>'desc','id'=>'asc'])->select()->toArray();

        foreach ($res['dlresume_list'] as $key => $value) {
            if($setmeal['discount_download_resume']>0){
                $res['dlresume_list2'][$key]['text'] = $value['name'];
                $res['dlresume_list2'][$key]['description'] = $language_zimu['new_viewresume_inc_php_29'].round($value['price']*$setmeal['discount_download_resume']/10,2).$zmdata['settings']['money_name'].$language_zimu['new_viewresume_inc_php_30'].round($value['price']*$setmeal['discount_download_resume']/10/$value['value'],2).$zmdata['settings']['money_name'].'/'.$language_zimu['new_viewresume_inc_php_31'].'('.$language_zimu['new_viewresume_inc_php_32'].$value['price'].$zmdata['settings']['money_name'].')';
            }else{
                $res['dlresume_list2'][$key]['text'] = $value['name'];
                $res['dlresume_list2'][$key]['description'] = $language_zimu['new_viewresume_inc_php_33'].round($value['price']/$value['value'],2).$zmdata['settings']['money_name'].'/'.$language_zimu['new_viewresume_inc_php_34'].'('.$language_zimu['new_viewresume_inc_php_35'].$value['price'].$zmdata['settings']['money_name'].')';
            }
        }

        if($res['resume']['isadmin']==1){
            $res['resume']['isresume'] = 1;
            $res['resume']['telephone'] = $real_telephone;
            $res['resume']['fullname'] = $real_fullname;
            $res['resume']['blacklist'] = Db::name('zimu_zhaopin_members')->where([['uid','=',$res['resume']['uid']]])->order(['id'=>'asc'])->value('blacklist');
        }

        $audit_tip1 = explode(PHP_EOL, trim($zmdata['settings']['audit_tip1']));
        $audit_tip2 = explode(PHP_EOL, trim($zmdata['settings']['audit_tip2']));

        foreach ($audit_tip1 as $key => $value) {
            $res['audit_tip1'][$key]['text'] = $value;
        }
        foreach ($audit_tip2 as $key => $value) {
            $res['audit_tip2'][$key]['text'] = $value;
        }

        if($_SERVER['REQUEST_METHOD'] != 'OPTIONS'){
            Db::name('zimu_zhaopin_resume')->where('id', $ids)->inc('click', 1)->update();
        }

        $paramter = Db::name('zimu_zhaopin_parameter2')->where([['name','=','wappopup']])->order(['id'=>'asc'])->find();
        $res['wappopup'] = unserialize($paramter['parameter']);
        $res['sitename'] = $zmdata['base']['title'];
        $res['view_resume_more'] = intval($zmdata['settings']['view_resume_more']);
        $res['zmdata']['randad'] = zimu_ad_system2('zhaopin6');
        $res['zmdata']['randad2'] = zimu_ad_system2('zhaopin9');
        $res['zmdata']['show_noaudit'] = intval($zmdata['settings']['show_noaudit']);
        $res['zmdata']['app_url'] = $zmdata['settings']['app_url'];
        $res['zmdata']['toutiao_audit'] = $zmdata['settings']['toutiao_audit'];
        if(file_exists(DISCUZ_ROOT . './source/plugin/zimu_zhaopin/module/adminss/adminss_imconfig.inc.php')){
            $imchat_parameter = Db::name('zimu_zhaopin_parameter2')->where('name', 'imchat')->order('id','desc')->find();
            $imchat_parameter = unserialize($imchat_parameter['parameter']);
            if($imchat_parameter['open_im']) {
                $res['zmdata']['open_sixin'] = 1;
                $res['zmdata']['open_im'] = 1;
                $res['zmdata']['app_url'] = $zmdata['settings']['app_url'];
                if ($myuid['uid']) {
                    $res['zmdata']['myuid'] = $myuid;
                }
            }
        }
        if($myuid['utype']==2){
            $res['zmdata']['open_sixin'] = 0;
        }

        if($zmdata['settings']['resume_copytext']){

            if($zmdata['settings']['open_newwap']==1){
                $tourl = zp_url_replace('viewresume','rid',$ids);
            }else{
                $tourl = $_G['siteurl'].'source/plugin/zimu_zhaopin/h5/pages/resume/view?ids='.$ids;
            }

            $res['zmdata']['resume_copytext'] = preg_replace(array('/fullname/','/sex_cn/','/education_cn/','/experience_cn/','/tag_cn/','/wage_cn/','/intention_jobs/','/specialty/','/current_cn/','/age/','/district_cn/','/tourl/'), array($resume['fullname'],$resume['sex_cn'],$resume['education_cn'],$resume['experience_cn'],$resume['tag_cn'],$resume['wage_cn'],$resume['intention_jobs'],$resume['specialty'],$resume['current_cn'],$resume['age'],$resume['district_cn'],$tourl), $zmdata['settings']['resume_copytext']);

        }

        if($res['resume']['uid'] == $myuid['uid'] || $res['resume']['isadmin']==1){
            $auditinfo = Db::name('zimu_zhaopin_resume_audit')->where('uid', $res['resume']['uid'])->find();
            if($auditinfo){
                unset($auditinfo['id']);
                if($res['resume']['uid'] == $myuid['uid'] && $res['resume']['isadmin']!=1){
                    $res['resume'] = array_merge($res['resume'],$auditinfo);
                }
                $oldinfo = $resume;
                $diff_info = array_merge($oldinfo,$auditinfo);
                $diff_info2 = array_diff_assoc($diff_info,$oldinfo);
                $res['resume']['diff_info'] = $diff_info2;
            }
        }

        zimu_json($res);

    }
