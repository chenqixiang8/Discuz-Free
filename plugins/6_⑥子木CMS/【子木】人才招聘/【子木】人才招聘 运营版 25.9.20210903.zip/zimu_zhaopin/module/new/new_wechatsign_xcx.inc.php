<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if (!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }

    use think\Db;

    $url = addslashes($_GET['sign_url']);
    $path = addslashes($_GET['path']);
    $toreferer = urldecode($_GET['toreferer']);

    $name1 = 'mytoken';
    $a = explode('?',$toreferer);
    $url_f = $a[0];
    $query = $a[1];
    parse_str($query,$arr);
    $arr[$key] = $value;
    if($name1){
        unset($arr[$name1]);
    }
    $toreferer = $url_f.'?'.http_build_query($arr);


    $url = str_replace('?from=timeline&isappinstalled=0','',$url);
    $url = str_replace('?from=timeline&isappinstalled=1','',$url);
    $url = str_replace('?from=groupmessage&isappinstalled=0','',$url);
    $url = str_replace('?from=groupmessage&isappinstalled=1','',$url);
    $url = str_replace('?from=singlemessage&isappinstalled=0','',$url);
    $url = str_replace('?from=singlemessage&isappinstalled=1','',$url);

    $ids = intval($_GET['ids']);

    if ($zmdata['base']['weixin_appid'] && $zmdata['base']['weixin_appsecret']) {
        require_once DISCUZ_ROOT . './source/plugin/zimu_zhaopin/class/wechat.lib.class.php';
        $wechat_client = new WeChatClient($zmdata['base']['weixin_appid'], $zmdata['base']['weixin_appsecret']);
        $jssdkvalue    = $wechat_client->getSignPackage($url);

        if($path=='pages/index/view'){


        }elseif($path=='pages/jobs/view'){

            $jobdata = Db::name('zimu_zhaopin_jobs')->where('id', $ids)->findOrEmpty();

            if ($jobdata['nature']==63 && $jobdata['parttime_money']) {
                if($jobdata['parttime_type']==1){
                    $jobdata['wage_cn'] = $jobdata['parttime_money'].$zmdata['settings']['money_name'].'/'.$language_zimu['new_wechatsign_xcx_inc_php_0'];
                }
                if($jobdata['parttime_type']==2){
                    $jobdata['wage_cn'] = $jobdata['parttime_money'].$zmdata['settings']['money_name'].'/'.$language_zimu['new_wechatsign_xcx_inc_php_1'];
                }
                if($jobdata['parttime_type']==0){
                    $jobdata['wage_cn'] = $jobdata['parttime_money'].$zmdata['settings']['money_name'].'/'.$language_zimu['new_wechatsign_xcx_inc_php_2'];
                }
                if($jobdata['parttime_type']==3){
                    $jobdata['wage_cn'] = $jobdata['parttime_money'].$zmdata['settings']['money_name'].'/'.$language_zimu['new_wechatsign_xcx_inc_php_3'];
                }
            }elseif ($jobdata['nature']==63){
                $jobdata['wage_cn'] = $language_zimu['new_wechatsign_xcx_inc_php_4'];
            }

            $zmdata['settings']['viewjob_seo_title'] = $zmdata['settings']['viewjob_share_title'] ? $zmdata['settings']['viewjob_share_title'] : $zmdata['settings']['viewjob_seo_title'];

            $viewjob_seo_title = preg_replace(array(
                '/jobs_name/',
                '/wage_cn/',
                '/amount/',
                '/experience_cn/',
                '/education_cn/',
                '/sex_cn/',
                '/district_cn/',
                '/companyname/',
                '/tag_cn/',
                '/contents/',
                '/fenzhan/'
            ), array(
                $jobdata['jobs_name'],
                $jobdata['wage_cn'],
                $jobdata['amount'],
                $jobdata['experience_cn'],
                $jobdata['education_cn'],
                $jobdata['sex_cn'],
                $jobdata['district_cn'],
                $jobdata['companyname'],
                $jobdata['tag_cn'],
                $jobdata['contents'],
                $fenzhan_name
            ), $zmdata['settings']['viewjob_seo_title']);

            $viewjob_seo_keyword = preg_replace(array(
                '/jobs_name/',
                '/wage_cn/',
                '/amount/',
                '/experience_cn/',
                '/education_cn/',
                '/sex_cn/',
                '/district_cn/',
                '/companyname/',
                '/tag_cn/',
                '/contents/',
                '/fenzhan/'
            ), array(
                $jobdata['jobs_name'],
                $jobdata['wage_cn'],
                $jobdata['amount'],
                $jobdata['experience_cn'],
                $jobdata['education_cn'],
                $jobdata['sex_cn'],
                $jobdata['district_cn'],
                $jobdata['companyname'],
                $jobdata['tag_cn'],
                $jobdata['contents'],
                $fenzhan_name
            ), $zmdata['settings']['viewjob_seo_keyword']);

            $zmdata['settings']['viewjob_seo_desc'] = $zmdata['settings']['viewjob_share_desc'] ? $zmdata['settings']['viewjob_share_desc'] : $zmdata['settings']['viewjob_seo_desc'];

            $viewjob_seo_desc = preg_replace(array(
                '/jobs_name/',
                '/wage_cn/',
                '/amount/',
                '/experience_cn/',
                '/education_cn/',
                '/sex_cn/',
                '/district_cn/',
                '/companyname/',
                '/tag_cn/',
                '/contents/',
                '/fenzhan/'
            ), array(
                $jobdata['jobs_name'],
                $jobdata['wage_cn'],
                $jobdata['amount'],
                $jobdata['experience_cn'],
                $jobdata['education_cn'],
                $jobdata['sex_cn'],
                $jobdata['district_cn'],
                $jobdata['companyname'],
                $jobdata['tag_cn'],
                $jobdata['contents'],
                $fenzhan_name
            ), $zmdata['settings']['viewjob_seo_desc']);


            $viewjob_seo_desc = str_replace(array(
                "\r\n",
                "\r",
                "\n"
            ), "", $viewjob_seo_desc);

            $navtitle = $zmdata['base']['title'];
            $share_title = $viewjob_seo_title ? $viewjob_seo_title : $navtitle;
            $share_title = str_replace($language_zimu['new_wechatsign_xcx_inc_php_5'].'0'.$language_zimu['new_wechatsign_xcx_inc_php_6'],'',$share_title);
            $share_title = str_replace($language_zimu['new_wechatsign_xcx_inc_php_7'].'0'.$language_zimu['new_wechatsign_xcx_inc_php_8'],'',$share_title);
            $keywords    = $viewjob_seo_keyword ? $viewjob_seo_keyword : $share_title;
            $description = $share_desc = $viewjob_seo_desc ? $viewjob_seo_desc : $share_title;
            $description = str_replace($language_zimu['new_wechatsign_xcx_inc_php_9'].'0'.$language_zimu['new_wechatsign_xcx_inc_php_10'],'',$description);
            $description = str_replace($language_zimu['new_wechatsign_xcx_inc_php_11'].'0'.$language_zimu['new_wechatsign_xcx_inc_php_12'],'',$description);

        }elseif($path=='pages/resume/view'){

            $info = Db::name('zimu_zhaopin_resume')->where('id', $ids)->findOrEmpty();

            $zmdata['settings']['viewresume_seo_title'] = $zmdata['settings']['viewresume_share_title'] ? $zmdata['settings']['viewresume_share_title'] : $zmdata['settings']['viewresume_seo_title'];
            $zmdata['settings']['viewresume_seo_desc'] = $zmdata['settings']['viewresume_share_desc'] ? $zmdata['settings']['viewresume_share_desc'] : $zmdata['settings']['viewresume_seo_desc'];

            $viewresume_seo_title = preg_replace(array('/fullname/','/sex_cn/','/wage_cn/','/age/','/education_cn/','/experience_cn/','/tag_cn/','/intention_jobs/','/specialty/','/fenzhan/'), array($info['fullname'],$info['sex_cn'],$info['wage_cn'],$info['age'],$info['education_cn'],$info['experience_cn'],$info['tag_cn'],$info['intention_jobs'],$info['specialty'],$fenzhan_name), $zmdata['settings']['viewresume_seo_title']);

            $viewresume_seo_keyword = preg_replace(array('/fullname/','/sex_cn/','/wage_cn/','/age/','/education_cn/','/experience_cn/','/tag_cn/','/intention_jobs/','/specialty/','/fenzhan/'), array($info['fullname'],$info['sex_cn'],$info['wage_cn'],$info['age'],$info['education_cn'],$info['experience_cn'],$info['tag_cn'],$info['intention_jobs'],$info['specialty'],$fenzhan_name), $zmdata['settings']['viewresume_seo_keyword']);

            $viewresume_seo_desc = preg_replace(array('/fullname/','/sex_cn/','/wage_cn/','/age/','/education_cn/','/experience_cn/','/tag_cn/','/intention_jobs/','/specialty/','/fenzhan/'), array($info['fullname'],$info['sex_cn'],$info['wage_cn'],$info['age'],$info['education_cn'],$info['experience_cn'],$info['tag_cn'],$info['intention_jobs'],$info['specialty'],$fenzhan_name), $zmdata['settings']['viewresume_seo_desc']);

            $viewresume_seo_desc = str_replace(array("\r\n", "\r", "\n"), "", $viewresume_seo_desc);
            $navtitle = $zmdata['base']['title'];
            $share_title = $viewresume_seo_title ? $viewresume_seo_title : $navtitle;
            $keywords = $viewresume_seo_keyword ? $viewresume_seo_keyword : $share_title;
            $description = $share_desc = $viewresume_seo_desc ? $viewresume_seo_desc : $share_title;

        }elseif($path=='pages/news/view'){

            $newsdata = Db::name('zimu_zhaopin_news')->where('id', $ids)->findOrEmpty();

            $navtitle = $share_title = $newsdata['title'] ? $newsdata['title'].' - '.$zmdata['base']['title'] : $navtitle;
            $keywords = $newsdata['keyword'] ? $newsdata['keyword'] : $navtitle;
            $description = $share_desc = $newsdata['description'] ? $newsdata['description'] : $navtitle;

        }elseif($path=='pages/qiye/view'){

            $companydata = Db::name('zimu_zhaopin_company_profile')->where('id', $ids)->findOrEmpty();

            $navtitle = $share_title = $companydata['companyname'].' - '.$zmdata['base']['title'];
            $share_desc = $zmdata['base']['share_desc'];
            $share_thumb = $companydata['logo'] ? $companydata['logo'] : $zmdata['base']['share_thumb'];


        }elseif($path=='pages/index/jobs'){

            $navtitle = $share_title = $zmdata['settings']['jobs_seo_title'] ? $zmdata['settings']['jobs_seo_title'] : $navtitle;
            $share_desc = $zmdata['settings']['jobs_seo_desc'] ? $zmdata['settings']['jobs_seo_desc'] : $navtitle;

        }elseif($path=='pages/index/resume'){

            $navtitle = $share_title = $zmdata['settings']['resume_seo_title'] ? $zmdata['settings']['resume_seo_title'] : $navtitle;
            $description = $share_desc = $zmdata['settings']['resume_seo_desc'] ? $zmdata['settings']['resume_seo_desc'] : $navtitle;

        }elseif($path=='pages/index/qiye'){

            $navtitle = $zmdata['settings']['qiye_seo_title'] ? $zmdata['settings']['qiye_seo_title'] : $navtitle;
            $keywords = $zmdata['settings']['qiye_seo_keyword'] ? $zmdata['settings']['qiye_seo_keyword'] : $navtitle;
            $description = $zmdata['settings']['qiye_seo_desc'] ? $zmdata['settings']['qiye_seo_desc'] : $navtitle;

        }elseif($path=='pages/jobfair_online/show'){

            $jobfair = Db::name('zimu_zhaopin_jobfair_online')->where('id', $ids)->findOrEmpty();

            $navtitle    = $zmdata['base']['title'];
            $share_title = $jobfair['title'] ? $jobfair['title'] : $navtitle;
            $keywords    = $jobfair['summary'] ? $jobfair['summary'] : $navtitle;
            $jobfair['summary'] = str_replace(array(
                "\r\n",
                "\r",
                "\n"
            ), "", $jobfair['summary']);
            $description = $share_desc = cutstr($jobfair['summary'], 160);
        }

        if(!$share_thumb){
            if(strpos($toreferer,'?') !== false){
                $share_url = $_G['siteurl'].'source/plugin/zimu_zhaopin/h5'.$toreferer.'&mobile=2';
            }else{
                $share_url = $_G['siteurl'].'source/plugin/zimu_zhaopin/h5'.$toreferer.'?mobile=2';
            }
        }

        if($path=='pages/index/index' && file_exists(DISCUZ_ROOT . './source/plugin/zimu_zhaopin/module/a_change_area.inc.php') && ( $zmdata['settings']['change_city'] == 1 || $zmdata['settings']['change_area'] > 0) && $_GET['vuex_citycn'] && $_GET['vuex_citycn'] != undefined){

                $navtitle = $share_title = str_replace('city', $_GET['vuex_citycn'], $zmdata['settings']['seo_title_city']);
                $keywords = str_replace('city', $_GET['vuex_citycn'], $zmdata['settings']['seo_keywords_city']);
                $description = $share_desc = str_replace('city', $_GET['vuex_citycn'], $zmdata['settings']['seo_description_city']);

        }

        $jssdkvalue['shareOptions']['navtitle'] = $navtitle ? $navtitle : $zmdata['base']['title'];
        $jssdkvalue['shareOptions']['title'] = $share_title ? $share_title : $zmdata['base']['share_title'];
        $jssdkvalue['shareOptions']['desc'] = $share_desc ? $share_desc : $zmdata['base']['share_desc'];
        $jssdkvalue['shareOptions']['link'] = $share_url;
        $jssdkvalue['shareOptions']['imgUrl'] = $share_thumb ? $share_thumb : $zmdata['base']['share_thumb'];

        echo json_encode(zimu_array_utf8($jssdkvalue),true);
    }
