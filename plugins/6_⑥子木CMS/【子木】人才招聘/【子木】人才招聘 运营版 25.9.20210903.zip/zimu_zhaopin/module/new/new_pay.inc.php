<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if (!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }

    use think\Db;

    $oldtoken = $_GET['token'];
    $token = addslashes($_GET['token']);
    $myuid = checktoken($token);
    if($myuid['uid'] != $_G['uid'] && $_G['uid'] > 0){
        $olduid = Db::name('zimu_zhaopin_members')->where('uid', $_G['uid'])->find();
        $myuid['openid'] = $olduid['openid'];
    }

    $op = addslashes($_GET['op']);
    $ids = intval($_GET['ids']);
    $order = Db::name('zimu_zhaopin_order')->where('id', $ids)->find();
    $order['params'] = unserialize($order['params']);

    $body = diconv(cutstr(strip_tags($order['description']),20),CHARSET,'UTF-8');

    if($order['pay_amount']==0){
        Db::name('zimu_zhaopin_order')->where('id', $ids)->data('pay_amount', 0)->update();
        finish_order2($order,'free');
        zimu_json($order);
    }

    if($order['service_name'] != 'buy_points' && $order['pay_amount'] && $zmdata['settings']['money_appcode'] && $zmdata['settings']['money_currency']){
        $tomoney = get_money_currency($zmdata['settings']['money_appcode'],$order['pay_amount'],$zmdata['settings']['money_currency']);
        $tomoney = json_decode($tomoney,true);
        if($tomoney['msg']=='ok' && $tomoney['result']['rate']){
            $order['pay_amount'] = round($tomoney['result']['camount'],2);
        }
    }

    if($op == 'yue'){

        $pay_points = intval($order['pay_amount']*10);
        Db::name('zimu_zhaopin_order')->where('id', $ids)->data(['pay_points' => $pay_points])->update();
        finish_order2($order['oid'],'yue');
        zimu_json($order);exit();

    }


    if($op == 'xcx'){
        $tools = new JsApiPaySF();
        $notify = new NativePaySF();
        $input = new WxPayUnifiedOrderSF();
        $input->SetBody($body);
        $input->SetAttach($body);
        $input->SetOut_trade_no($order['oid']);
        $input->SetTotal_fee($order['pay_amount'] * 100);
        $input->SetTime_start(date('YmdHis'));
        $input->SetGoods_tag($body);
        $pburl = $_G['siteurl'];
        $input->SetNotify_url($pburl . 'source/plugin/zimu_zhaopin/lib/notify_wx.php');
        $input->SetTrade_type((IN_WECHAT ? 'JSAPI' : (checkmobile() ? 'MWEB' : 'NATIVE')));
        if($myuid['old_uid']){
            $olduid = Db::name('zimu_zhaopin_members')->where('uid', $myuid['old_uid'])->find();
            $openid = $olduid['xcx_openid'];
        }else{
            $openid = $myuid['xcx_openid'];
        }
        $input->SetOpenid($openid);
        $order2 = WxPayApiSF::unifiedOrder($input);
        $jsApiParameters = $tools->GetJsApiParameters($order2);
        if ($order2['prepay_id'] == '') {
            $jsApiParameters = json_encode(array('error' => $openid . ' error'));
        }
        echo $jsApiParameters;
        exit();
    }

    if($op == 'daliaowang') {

        $tools = new JsApiPaySF();
        $notify = new NativePaySF();
        $input = new WxPayUnifiedOrderSF();
        $input->SetBody($body);
        $input->SetAttach($body);
        $input->SetOut_trade_no($order['oid']);
        $input->SetTotal_fee($order['pay_amount'] * 100);
        $input->SetTime_start(date('YmdHis'));
        $input->SetGoods_tag($body);
        $pburl = $_G['siteurl'];
        $input->SetNotify_url($pburl . 'source/plugin/zimu_zhaopin/lib/notify_wx.php');
        $input->SetTrade_type((IN_WECHAT ? 'JSAPI' : (checkmobile() ? 'MWEB' : 'NATIVE')));

        $input->SetTrade_type('APP');
        $postObj=WxPayApiSF::unifiedOrder($input);
        $noncestr=WxPayApiSF::getNonceStr();
        $timestamp=$_G['timestamp'];
        $apppay=array();
        $apppay['appid']=SF_APPID;
        $apppay['partnerid']=SF_MCHID;
        $apppay['prepayid']=$postObj['prepay_id'];
        $apppay['noncestr']=$noncestr;
        $apppay['timestamp']=$timestamp;
        $apppay['package']='Sign=WXPay';
        $apppay['sign']=zm_getSign($apppay);
        echo json_encode($apppay);
        exit();
    }


    if(IN_WECHAT) {
        $tools = new JsApiPaySF();
        $notify = new NativePaySF();
        $input = new WxPayUnifiedOrderSF();
        $input->SetBody($body);
        $input->SetAttach($body);
        $input->SetOut_trade_no($order['oid']);
        $input->SetTotal_fee($order['pay_amount'] * 100);
        $input->SetTime_start(date('YmdHis'));
        $input->SetGoods_tag($body);
        $pburl = $_G['siteurl'];
        $input->SetNotify_url($pburl . 'source/plugin/zimu_zhaopin/lib/notify_wx.php');
        $input->SetTrade_type((IN_WECHAT ? 'JSAPI' : (checkmobile() ? 'MWEB' : 'NATIVE')));

        $openid = $myuid['openid'];
        $input->SetOpenid($openid);
        $order2 = WxPayApiSF::unifiedOrder($input);
        $jsApiParameters = $tools->GetJsApiParameters($order2);
        if ($order2['prepay_id'] == '') {
            $jsApiParameters = json_encode(array('error' => $openid . ' error'));
        }
        echo $jsApiParameters;
        exit();
    }

    if(IN_MAGAPP){

        $mag_paramter = Db::name('zimu_zhaopin_parameter2')->where('name', 'magapp')->find();
        $mag_paramter = unserialize($mag_paramter['parameter']);

        $call_back = $_G['siteurl'].'source/plugin/zimu_zhaopin/lib/notify_magapp.php?trade_no='.$order['oid'].'&userid='.$myuid['uid'];

        $mag_parameter=array('trade_no'=>$order['oid'],'callback'=>$call_back,'amount'=>$order['pay_amount'],'title'=>$body,'user_id'=>$myuid['uid'],'des'=>$body,'remark'=>$body,'secret'=>$mag_paramter['magapp_secret']);

        $mag_url = $mag_paramter['magapp_hostname'].'/core/pay/pay/unifiedOrder?'.http_build_query($mag_parameter);

        $mag_ret = json_decode(zm_curl($mag_url),true);

        if ($mag_ret) {
            if ($unionOrderNum = $mag_ret['data']['unionOrderNum']) {
                Db::name('zimu_zhaopin_order')->where('id', $ids)->update(['payment' => 'magapp','payment_cn' => $language_zimu['new_pay_inc_php_0'].'APP'.$language_zimu['new_pay_inc_php_1'],'order_sn' => $mag_ret['data']['unionOrderNum']]);
            }
            $order['order_sn'] = $mag_ret['data']['unionOrderNum'];

            zimu_json($order);

        }else{
            zimu_json('',$mag_ret["msg"],201);
        }


    }

    if(IN_QFAPP){

        $qfoid = addslashes($_GET['qfoid']);

        Db::name('zimu_zhaopin_order')->where('id', $ids)->update(['payment' => 'qfapp','payment_cn' => $language_zimu['new_pay_inc_php_2'].'APP'.$language_zimu['new_pay_inc_php_3'],'order_sn' => $qfoid]);

        $order['order_sn'] = $qfoid;

        zimu_json($order);

    }

    if($op == 'toutiao') {

        require_once(DISCUZ_ROOT . './source/plugin/zimu_zhaopin/lib/fengkuipay/vendor/autoload.php');
        $pburl = $_G['siteurl'];
        $bytedanceConfig = [
            'app_id'        => $zmdata['settings']['toutiao_appid'],
            'salt'          => $zmdata['settings']['toutiao_salt'],
            'notify_url'    => $pburl . 'source/plugin/zimu_zhaopin/lib/notify_toutiao.php',
            'thirdparty_id' => '',
        ];

        $pay = new \fengkui\Pay\Bytedance($bytedanceConfig);
        $order2 = [
            'order_sn' => $order['oid'],
            'total_amount' => $order['pay_amount'] * 100,
            'body' => $body,
        ];
        $res = $pay->createOrder($order2);
        if($res['data']['order_id']){
            Db::name('zimu_zhaopin_order')->where('id', $ids)->update(['payment' => 'toutiao','payment_cn' => $language_zimu['new_pay_inc_php_4'],'order_sn' => $res['data']['order_id']]);
        }
        $res['err_tips'] = diconv($res['err_tips'],'UTF-8',CHARSET);
        zimu_json($res);

    }