<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if (!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }

    use think\Db;

    $tourl = $_G['siteurl'].'source/plugin/zimu_zhaopin/h5/pages/my/login?mobile=2';

    $op = addslashes($_GET['op']);

    if($op=='deltoken'){

        $deltoken = addslashes($_GET['deltoken']);
        $tourl = str_replace('&mytoken='.$mytoken, '', $tourl);
        dheader('Location:' . $tourl);
        exit();

    }else {

        dsetcookie('zimu_referer', $_G['siteurl'].'plugin.php?id=zimu_zhaopin:new&model=loginapi&istourl=1', 30);

        isuid($_G['siteurl'].'plugin.php?id=zimu_zhaopin:new&model=loginapi&istourl=1');

        if (IN_WECHAT && $zmdata['base']['weixin_appid'] && $zmdata['base']['weixin_appsecret']) {

            $zp_openid = zm_wechat_auth($_G['siteurl'] . $_SERVER['REQUEST_URI']);
            if(strlen($zp_openid) > 50){
                $zp_openid = '';
            }

            list($zp_unionid, $uptime) = getcookie('zimu_zhaopin_unionid') ? explode("\t", authcode(getcookie('zimu_zhaopin_unionid'), 'DECODE')) : array();

        }

        if ($_G['uid']) {

            $tokeninfo = Db::name('zimu_zhaopin_members')->where('uid', $_G['uid'])->find();

            if ($tokeninfo && (!$tokeninfo['openid'] || strlen($tokeninfo['openid']) > 50) && $zp_openid) {

                Db::name('zimu_zhaopin_members')->where('uid', $_G['uid'])->update(['openid' => $zp_openid,'unionid' => $zp_unionid]);

            }
            if($tokeninfo['id'] && !$tokeninfo['token']){
                $tokeninfo['token'] = getRandChar(32);
                Db::name('zimu_zhaopin_members')->where('uid', $_G['uid'])->update(['token' => $tokeninfo['token']]);
            }

            if (!$tokeninfo) {
                $token_data['uid'] = $_G['uid'];
                $token_data['utype'] = 1;
                $token_data['token'] = getRandChar(32);
                $token_data['openid'] = $zp_openid ? $zp_openid : '';
                $token_data['unionid'] = $zp_unionid ? $zp_unionid : '';
                $token_data['telephone'] = '';
                $token_data['verify_code'] = '';
                $token_data['points'] = 0;
                Db::name('zimu_zhaopin_members')->insert($token_data);
                $tokeninfo = $token_data;
            }

        }

        $name1 = 'mytoken';
        $a = explode('?',$tourl);
        $url_f = $a[0];
        $query = $a[1];
        parse_str($query,$arr);
        $arr[$key] = $value;
        if($name1){
            unset($arr[$name1]);
        }
        $tourl = $url_f.'?'.http_build_query($arr);

        dheader('Location:' . $tourl . '&mytoken=' . $tokeninfo['token']);
        exit();

    }
