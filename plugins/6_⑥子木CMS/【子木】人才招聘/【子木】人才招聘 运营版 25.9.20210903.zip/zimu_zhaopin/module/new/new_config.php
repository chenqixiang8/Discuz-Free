<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if (!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }

    $langfile = DISCUZ_ROOT . './source/plugin/zimu_zhaopin/language.' . currentlang() . '.php';
    $includefile = is_file($langfile) ? $langfile : libfile('language', 'plugin/zimu_zhaopin');
    include $includefile;

    define('ZIMUCMS_PATH', $_G['siteurl'] . 'source/plugin/zimu_zhaopin/');
    define('ZIMUCMS_ROOT', dirname(__FILE__));
    define('ZIMUCMS_URL', $_G['siteurl'] . 'plugin.php?id=zimu_zhaopin');
    define('ZIMUCMS_URL2', $_G['siteurl'] . 'source/plugin/zimu_zhaopin/h5/');
    define('SITE_URL', $_G['siteurl']);
    define('IN_WECHAT', strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false);
    define('IN_XIAOYUNAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'Appbyme') !== false);
    define('IN_QFAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'QianFan') !== false);
    define('IN_MAGAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'MAGAPP') !== false);

    require DISCUZ_ROOT . './source/plugin/zimu_zhaopin/lib/thinkorm/v1/vendor/autoload.php';

    use think\Db;

    Db::setConfig([
        'type'     => 'mysql',
        'hostname' => $_G['config']['db'][1]['dbhost'],
        'username' => $_G['config']['db'][1]['dbuser'],
        'database' => $_G['config']['db'][1]['dbname'],
        'password'    => $_G['config']['db'][1]['dbpw'],
        'charset'  => $_G['config']['db'][1]['dbcharset'],
        'prefix'   => $_G['config']['db'][1]['tablepre'],
        'resultset_type' => 'collection',
        'fields_strict'  => false,
        'debug'    => false,
    ]);

    $zmdata = $_G['cache']['plugin']['zimu_zhaopin'];
    $setdata = Db::name('zimu_zhaopin_setting')->find();
    $zmdata['base'] = $setdata;
    $zmdata['settings'] = unserialize($setdata['settings']);
    $zmdata['settings']['money_name'] = $zmdata['settings']['money_name'] ? $zmdata['settings']['money_name'] : $language_zimu['new_config_php_0'];
    $zmdata['settings']['jifen_bili'] = $zmdata['settings']['jifen_bili'] ? $zmdata['settings']['jifen_bili'] : 10;
    $zmdata['settings']['jifen_bili'] = intval($zmdata['settings']['jifen_bili']);
    if($client_type=='toutiao' && (strpos($_SERVER['HTTP_USER_AGENT'], 'iPhone')||strpos($_SERVER['HTTP_USER_AGENT'], 'iPad'))){
        $zmdata['settings']['toutiao_audit'] = $zmdata['settings']['toutiao_audit'];
    } elseif ($client_type=='toutiao') {
        $zmdata['settings']['toutiao_audit'] = $zmdata['settings']['toutiao_salt'] ? 0 : 1;
    }else{
        $zmdata['settings']['toutiao_audit'] = 0;
    }

    $company_nologo = $zmdata['settings']['company_nologo_url'] ? $zmdata['settings']['company_nologo_url'] : $_G['siteurl'].'source/plugin/zimu_zhaopin/static/pc/images/company_nologo.jpg';

    $formhash = $_G['formhash'];

    if ($_G['charset'] == 'gbk') {
        $charset = 'gbk';
    } elseif ($_G['charset'] == 'utf-8') {
        $charset = 'UTF-8';
    } elseif ($_G['charset'] == 'big5') {
        $charset = 'big5';
    }

    $wheresql['noaudit'][] = ['audit','=',1];

    $op = addslashes($_GET['op']);

    if($op=='xcx'){
        define('SF_APPID', $zmdata['settings']['xcx_appid']);
        define('SF_MCHID', $zmdata['settings']['xcx_mchid']);
        define('SF_APPSECRET', $zmdata['settings']['xcx_appsecret']);
        define('SF_WXPAY_KEY', $zmdata['settings']['xcx_mchkey']);
    }else if($op=='daliaowang'){
        define('SF_APPID', $zmdata['settings']['app_appid']);
        define('SF_MCHID', $zmdata['settings']['app_mchid']);
        define('SF_APPSECRET', $zmdata['settings']['app_appsecret']);
        define('SF_WXPAY_KEY', $zmdata['settings']['app_mchkey']);
    }else{
        define('SF_APPID', $zmdata['base']['weixin_appid']);
        define('SF_MCHID', $zmdata['settings']['weixin_mchid']);
        define('SF_APPSECRET', $zmdata['base']['weixin_appsecret']);
        define('SF_WXPAY_KEY', $zmdata['settings']['weixin_mchkey']);
    }



    include_once(DISCUZ_ROOT.'source/plugin/zimu_zhaopin/lib/wxpay/lib/WxPay.Config.php');
    include_once(DISCUZ_ROOT.'source/plugin/zimu_zhaopin/lib/wxpay/lib/WxPay.Api.php');
    include_once(DISCUZ_ROOT.'source/plugin/zimu_zhaopin/lib/wxpay/example/WxPay.JsApiPay.php');
    include_once(DISCUZ_ROOT.'source/plugin/zimu_zhaopin/lib/wxpay/example/WxPay.NativePay.php');
    include_once(DISCUZ_ROOT.'source/plugin/zimu_zhaopin/lib/wxpay/example/log.php');
    include_once(DISCUZ_ROOT.'source/plugin/zimu_zhaopin/lib/wxpay/lib/WxPay.Data.php');

    function isuid($refererurl='')
    {

        global $_G;
        define('IN_XIAOYUNAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'Appbyme') !== false);
        define('IN_QFAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'QianFan') !== false);
        define('IN_MAGAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'MAGAPP') !== false);
        if(!$refererurl){
            $refererurl = $_G['siteurl'] . $_SERVER['REQUEST_URI'];
        }

        if(!checkmobile() && !$_G['uid']){

            $zmdata = $_G['cache']['plugin']['zimu_zhaopin'];
            $setdata = Db::name('zimu_zhaopin_setting')->find();
            $zmdata['base'] = $setdata;
            $zmdata['settings'] = unserialize($setdata['settings']);

            if($zmdata['settings']['weixin_login_url']){

                dheader('Location:' . ZIMUCMS_URL.'&model=login');
                exit();

            }

        }

        if (IN_MAGAPP && !$_G['uid']){

            $mag_paramter = Db::name('zimu_zhaopin_parameter2')->where('name', 'magapp')->find();
            $mag_paramter = unserialize($mag_paramter['parameter']);

        }

        if (IN_MAGAPP && !$_G['uid'] && $mag_paramter['magapp_hostname']){


            $userAgent = $_SERVER['HTTP_USER_AGENT'];
            $info = strstr($userAgent, "MAGAPPX");
            $info=explode("|",$info);
            $token = $info[7];

            $appurl = $mag_paramter['magapp_hostname'].'/mag/cloud/cloud/getUserInfo?token='.$token.'&secret='.$mag_paramter['magapp_secret'];

            $appdata = dfsockopen($appurl);
            if (!$appdata) {
                $appdata = file_get_contents($appurl);
            }
            $r =  json_decode($appdata, true);
            if($r['data']['user_id']>0){

                $member = getuserbyuid($r['data']['user_id'], 1);
                if (!$member) {
                    dheader('Location:' . $_G['siteurl'] . 'member.php?mod=logging&action=login&referer=' . urlencode($refererurl));
                    exit();
                }
                if (isset($member['_inarchive'])) {
                    C::t('common_member_archive')->move_to_master($member['uid']);
                }
                require_once libfile('function/member');
                $cookietime = 1296000;
                setloginstatus($member, $cookietime);
                return true;

            }else{
                exit('<script src="source/plugin/zimu_zhaopin/static/js/magjs-x.js"></script><script>
                mag.toLogin(function(){
                    top.location.href="' . $refererurl . '";
                    });
                    </script>');
            }

        }else{

            if (!$_G['uid']) {
                if (IN_XIAOYUNAPP) {
                    exit('<script language="javascript" src="source/plugin/zimu_zhaopin/static/js/appbyme.js"></script><script>connectAppbymeJavascriptBridge(function(bridge){
                    AppbymeJavascriptBridge.login(function(data){
                        top.location.href="' . $refererurl . '";
                        });
                        });
                        </script>');
                } else if (IN_MAGAPP) {
                    exit('<script src="source/plugin/zimu_zhaopin/static/js/magjs-x.js"></script><script>
                    mag.toLogin(function(){
                        top.location.href="' . $refererurl . '";
                        });
                        </script>');
                } else if (IN_QFAPP) {
                    exit('<script src="source/plugin/zimu_zhaopin/static/js/jquery-2.1.4.js"></script><script> function QFH5ready(){QFH5.jumpLogin(function(state,data){
                    if(state==1){
                        QFH5.refresh(1);
                        }else{
                //��½ʧ��
                            alert(data.error);//data.error: string
                        }
                        });
                    }
                    </script>');
                } else {
                    dheader('Location:' . $_G['siteurl'] . '/member.php?mod=logging&action=login&referer=' . urlencode($refererurl));
                    exit();
                }
            }
        }
    }

    function zm_diconv($str)
    {
        global $_G;
        $encode = mb_detect_encoding($str, array(
            "UTF-8",
            "GB2312",
            "GBK"
        ));
        if ($encode != strtoupper(CHARSET)) {
            $keytitle = mb_convert_encoding($str, strtoupper(CHARSET), $encode);
        }

        $censorexp = '/^(' . str_replace(array(
                '\\*',
                "\r\n",
                ' '
            ), array(
                '.*',
                '|',
                ''
            ), preg_quote(($_G['cache']['plugin']['zimu_zhaopin']['zimu_luanma'] = trim($_G['cache']['plugin']['zimu_zhaopin']['zimu_luanma'])), '/')) . ')$/i';
        if ($_G['cache']['plugin']['zimu_zhaopin']['zimu_luanma'] && @preg_match($censorexp, $keytitle)) {
            $keytitle = $str;
        }
        if (!$keytitle) {
            $keytitle = $str;
        }
        return $keytitle;
    }

    function zimu_json($data = '', $msg = '', $status = 200)
    {
        global $_G;
        require_once DISCUZ_ROOT . './source/plugin/zimu_zhaopin/class/json.class.php';
        $data['timestamp'] = $_G['timestamp'];
        $data              = array(
            'status' => $status,
            'msg' => $msg,
            'data' => $data
        );
        echo $jsondata = CJSON::encode($data);
        exit();
    }

    function zimu_json2($data = '', $msg = '', $status = 200)
    {
        $data['timestamp'] = time();
        $data              = array(
            'status' => $status,
            'msg' => $msg,
            'data' => $data
        );
        $data = zimu_array_utf8($data);
        echo $jsondata = json_encode($data,true);
        exit();
    }

    function zimu_json3($data = '', $msg = '', $status = 0, $count = 0)
    {
        global $_G;

        $langfile = DISCUZ_ROOT . './source/plugin/zimu_zhaopin/language.' . currentlang() . '.php';
        $includefile = is_file($langfile) ? $langfile : libfile('language', 'plugin/zimu_zhaopin');
        include $includefile;

        require_once DISCUZ_ROOT . './source/plugin/zimu_zhaopin/class/json.class.php';
        $data              = array(
            'msg' => $msg ? $msg : $language_zimu['new_config_php_2'],
            'code' => $status,
            'status' => !$status ? 200 : $status,
            'count' => $count,
            'data' => $data
        );
        echo $jsondata = CJSON::encode($data);
        exit();
    }

    function zimu_array_gbk($string,$ajax_status=null){
        global $_G;
        if($_G['charset'] == 'gbk'){
            if($ajax_status == true){
                if(is_array($string)){
                    return eval('return '.iconv("GB2312","UTF-8//IGNORE",var_export($string,true).';'));
                }else{
                    return iconv('GB2312', 'UTF-8', $string);
                }
            }else{
                if(is_array($string)){
                    $StringArr = array();
                    foreach($string as $key=>$value){
                        if(is_array($value)){
                            foreach($value as $k=>$v){
                                $encode = mb_detect_encoding($v, array('UTF-8','GB2312','GBK'));
                                if($encode == 'UTF-8'){
                                    $StringArr[$key][$k] = iconv('UTF-8','GB2312//IGNORE',$v);
                                }else if($encode == 'EUC-CN'){
                                    $StringArr[$key][$k] = $v;
                                }
                            }
                        }else{
                            $encode = mb_detect_encoding($value, array('UTF-8','GB2312','GBK'));
                            if($encode == 'UTF-8'){
                                $StringArr[$key] = iconv('UTF-8','GB2312//IGNORE',$value);
                            }else if($encode == 'EUC-CN'){
                                $StringArr[$key] = $value;
                            }
                        }
                    }
                    return $StringArr;
                }else{
                    $encode = mb_detect_encoding($string, array('UTF-8','GB2312','GBK'));
                    if($encode == 'UTF-8'){
                        return iconv('UTF-8','GB2312//IGNORE', $string);
                    }else if($encode == 'EUC-CN'){
                        return $string;
                    }
                }
            }
        }else{
            return $string;
        }
    }

    function zimu_array_utf8($String)
    {
        if (is_array($String)) {
            foreach ($String as $key => $val) {
                $String[$key] = zimu_array_utf8($val);
            }
        } else {
            if (preg_match("/^[A-Za-z0-9\s]+$/", $String)) {
                $String = $String;
            } else {
                $String = diconv($String,CHARSET,'UTF-8');
            }
        }
        return $String;
    }

    function zimu_array_utf8tomy($String)
    {
        if (is_array($String)) {
            foreach ($String as $key => $val) {
                $String[$key] = zimu_array_utf8tomy($val);
            }
        } else {
            if (preg_match("/^[A-Za-z0-9\s]+$/", $String)) {
                $String = $String;
            } else {
                $String = diconv($String,'UTF-8',CHARSET);
            }
        }
        return $String;
    }

    function checktoken($mytoken,$needlogin=1)
    {
        global $_G;
        $langfile = DISCUZ_ROOT . './source/plugin/zimu_zhaopin/language.' . currentlang() . '.php';
        $includefile = is_file($langfile) ? $langfile : libfile('language', 'plugin/zimu_zhaopin');
        include $includefile;
        if ($mytoken) {
            $isuid = Db::name('zimu_zhaopin_members')->where('token', $mytoken)->find();
        }
        if($isuid && time() - $isuid['onlinetime'] > 60){
            Db::name('zimu_zhaopin_members')->where('id', $isuid['id'])->update(['onlinetime' => time()]);
        }
        if($isuid['uid'] > 0 && $isuid['blacklist'] == 1){
            $setdata = Db::name('zimu_zhaopin_setting')->find();
            $zmdata['settings'] = unserialize($setdata['settings']);
            $res['token'] = 'error';
            zimu_json($res,$language_zimu['new_config_php_3'].$zmdata['settings']['kefu_mobile'],202);
            exit();
        }

        if($isuid['uid'] > 0){
            $mycompany = Db::name('zimu_zhaopin_company_profile')->where('uid',$isuid['uid'])->find();
            if(!$mycompany){
                $wheresql_iscompany = ['admin_uid','like','%,'.$isuid['uid'].',%'];
                $is_admin_company = Db::name('zimu_zhaopin_company_profile')->where([$wheresql_iscompany])->find();
                if($is_admin_company['uid']>0){
                    $old_uid = $isuid;
                    $isuid = Db::name('zimu_zhaopin_members')->where('uid',$is_admin_company['uid'])->find();
                    $isuid['old_uid'] = $old_uid['uid'];
                    $isuid['token'] = $old_uid['token'];
                    $isuid['openid'] = $old_uid['openid'];

                    if(!$isuid['id']){
                        $token_data['uid'] = $is_admin_company['uid'];
                        $token_data['utype'] = 1;
                        $token_data['token'] = getRandChar(32);
                        $token_data['openid'] = '';
                        $token_data['unionid'] = '';
                        $token_data['telephone'] = $is_admin_company['telephone'];
                        $token_data['verify_code'] = '';
                        $token_data['points'] = 0;
                        $isuid = $token_data;
                        $isuid['id'] = Db::name('zimu_zhaopin_members')->insertGetId($token_data);
                    }elseif ($isuid['id'] && !$isuid['token']){
                        $isuid['token'] = $tokeninfo['token'] = getRandChar(32);
                        Db::name('zimu_zhaopin_members')->where('id', $isuid['id'])->update(['token' => $tokeninfo['token']]);
                    }
                }
            }
        }

        if ($needlogin == 0 || $isuid['uid'] > 0) {

            return $isuid;

        } else {

            $res['token'] = 'error';
            zimu_json($res,'',201);
            exit();

        }

    }

    function format_jobs($list,$zmdata){
        $langfile = DISCUZ_ROOT . './source/plugin/zimu_zhaopin/language.' . currentlang() . '.php';
        $includefile = is_file($langfile) ? $langfile : libfile('language', 'plugin/zimu_zhaopin');
        include $includefile;
        foreach ($list as $key => $value) {
            if ($value['tag_cn']) {
                $list[$key]['tag_cn2'] = explode(',',$value['tag_cn']);
            }
            if ($value['nature']==63 && $value['parttime_money']) {
                if($value['parttime_type']==1){
                    $list[$key]['wage_cn'] = $value['parttime_money'].$zmdata['settings']['money_name'].'/'.$language_zimu['new_config_php_4'];
                }
                if($value['parttime_type']==2){
                    $list[$key]['wage_cn'] = $value['parttime_money'].$zmdata['settings']['money_name'].'/'.$language_zimu['new_config_php_5'];
                }
                if($value['parttime_type']==0){
                    $list[$key]['wage_cn'] = $value['parttime_money'].$zmdata['settings']['money_name'].'/'.$language_zimu['new_config_php_6'];
                }
                if($value['parttime_type']==3){
                    $list[$key]['wage_cn'] = $value['parttime_money'].$zmdata['settings']['money_name'].'/'.$language_zimu['new_config_php_7'];
                }
            }elseif ($value['nature']==63){
                $list[$key]['wage_cn'] = $language_zimu['new_config_php_8'];
            }
            if($value['telephone']){
                $list[$key]['telephone'] = substr_replace($value['telephone'], '****', 3, 4);
            }
            if($zmdata['settings']['job_amplify_views'] && $_GET['model'] != 'viewjob'){
                $add_views = mt_rand(1,$zmdata['settings']['job_amplify_views']);
            }else{
                $add_views = 1;
            }
            if($_SERVER['REQUEST_METHOD'] != 'OPTIONS' && $_GET['model'] != 'viewjob'){
                Db::name('zimu_zhaopin_jobs')->where('id', $value['id'])->inc('click', $add_views)->update();
            }
        }
        return $list;
    }

    function format_jobs2($value,$zmdata){
        $langfile = DISCUZ_ROOT . './source/plugin/zimu_zhaopin/language.' . currentlang() . '.php';
        $includefile = is_file($langfile) ? $langfile : libfile('language', 'plugin/zimu_zhaopin');
        include $includefile;
            if ($value['tag_cn']) {
                $list[$key]['tag_cn2'] = explode(',',$value['tag_cn']);
            }
            if ($value['nature']==63 && $value['parttime_money']) {
                if($value['parttime_type']==1){
                    $list[$key]['wage_cn'] = $value['parttime_money'].$zmdata['settings']['money_name'].'/'.$language_zimu['new_config_php_9'];
                }
                if($value['parttime_type']==2){
                    $list[$key]['wage_cn'] = $value['parttime_money'].$zmdata['settings']['money_name'].'/'.$language_zimu['new_config_php_10'];
                }
                if($value['parttime_type']==0){
                    $list[$key]['wage_cn'] = $value['parttime_money'].$zmdata['settings']['money_name'].'/'.$language_zimu['new_config_php_11'];
                }
                if($value['parttime_type']==3){
                    $list[$key]['wage_cn'] = $value['parttime_money'].$zmdata['settings']['money_name'].'/'.$language_zimu['new_config_php_12'];
                }
            }elseif ($value['nature']==63){
                $list[$key]['wage_cn'] = $language_zimu['new_config_php_13'];
            }
        return $value;
    }

    function format_resume($list,$zmdata){
        $langfile = DISCUZ_ROOT . './source/plugin/zimu_zhaopin/language.' . currentlang() . '.php';
        $includefile = is_file($langfile) ? $langfile : libfile('language', 'plugin/zimu_zhaopin');
        include $includefile;
        foreach ($list as $key => $value) {
            if ($value['tag_cn']) {
                $list[$key]['tag_cn2'] = explode(',',$value['tag_cn']);
            }
            $list[$key]['telephone'] = substr_replace($value['telephone'], '****', 3, 4);
            if($value['sex']==1){
                $list[$key]['fullname'] = cutstr($value['fullname'],2,'').$language_zimu['new_config_php_14'];
                $list[$key]['photo_img'] = $zmdata['settings']['show_resume_photo'] != 1 &&  $value['photo_img'] ? $value['photo_img'] : ZIMUCMS_PATH.'static/wap/images/no_photo_male.png';
            }else{
                $list[$key]['fullname'] = cutstr($value['fullname'],2,'').$language_zimu['new_config_php_15'];
                $list[$key]['photo_img'] = $zmdata['settings']['show_resume_photo'] != 1 && $value['photo_img'] ? $value['photo_img'] : ZIMUCMS_PATH.'static/wap/images/no_photo_female.png';
            }
            $list[$key]['wage_cn'] = $value['wage_cn']==$language_zimu['new_config_php_16'] ? $language_zimu['new_config_php_17'] : $value['wage_cn'];
            if($zmdata['settings']['resume_amplify_views'] && $_GET['model'] != 'viewresume'){
                $add_views = mt_rand(1,$zmdata['settings']['resume_amplify_views']);
            }else{
                $add_views = 1;
            }
            if($_SERVER['REQUEST_METHOD'] != 'OPTIONS' && $_GET['model'] != 'viewresume'){
                Db::name('zimu_zhaopin_resume')->where('id', $value['id'])->inc('click', $add_views)->update();
            }
        }
        return $list;
    }

    function format_qiye($list,$zmdata){
        $company_nologo = $zmdata['settings']['company_nologo_url'] ? $zmdata['settings']['company_nologo_url'] : $_G['siteurl'].'source/plugin/zimu_zhaopin/static/pc/images/company_nologo.jpg';
        foreach ($list as $key => $value) {
            if ($value['tag_cn']) {
                $list[$key]['tag_cn2'] = explode(',',$value['tag_cn']);
            }
            $list[$key]['logo'] = $value['logo'] ? $value['logo'] : $company_nologo;
            $list[$key]['telephone'] = substr_replace($value['telephone'], '****', 3, 4);
            $list[$key]['jobs'] = Db::name('zimu_zhaopin_jobs')->where([['company_id','=',$value['id']],['audit','<>',3],['display','<>',2]])->count();
        }
        return $list;
    }


    function ddate($s,$e){
        $langfile = DISCUZ_ROOT . './source/plugin/zimu_zhaopin/language.' . currentlang() . '.php';
        $includefile = is_file($langfile) ? $langfile : libfile('language', 'plugin/zimu_zhaopin');
        include $includefile;
        $starttime = strtotime($s);
        $endtime = strtotime($e);
        $startyear = date('Y',$starttime);
        $startmonth = date('m',$starttime);
        $endyear = date('Y',$endtime);
        $endmonth = date('m',$endtime);
        $return = '';
        $return_year = $endyear - $startyear;
        $return_month = $endmonth - $startmonth;
        if($return_month<0){
            $return_month += 12;
            $return_year -= 1;
        }

        if($return_year>0){
            $return .= $return_year.$language_zimu['new_config_php_18'];
        }
        if($return_month>0){
            $return .= $return_month.$language_zimu['new_config_php_19'];
        }
        return $return;
    }

    function _get_duration($list){
        if(!empty($list)){
            foreach ($list as $key => $value) {
                $start = $value['startyear'].'-'.$value['startmonth'];
                $end = $value['todate'] == 1 ? date('Y-m') : ($value['endyear'].'-'.$value['endmonth']);
                $list[$key]['duration'] = ddate($start,$end);
            }
        }
        return $list;
    }

    function getRandChar($length)
    {
        $str    = null;
        $strPol = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz";
        $max    = strlen($strPol) - 1;

        for ($i = 0; $i < $length; $i++) {
            $str .= $strPol[rand(0, $max)];
        }

        return $str.time();
    }

    function notification_all($uid,$template_name,$templatedata,$apptpl,$link){

            $paramter = Db::name('zimu_zhaopin_parameter2')->where('name', 'wxtpl')->find();
            $paramters = unserialize($paramter['parameter']);

            if($uid !='admin' && $uid){
                $tocompany = Db::name('zimu_zhaopin_company_profile')->where('uid',$uid)->find();
                if($tocompany['admin_uid']){
                    $admin_uid = explode(',',$tocompany['admin_uid']);
                    $admin_uid = array_filter($admin_uid);
                }
            }

            notification_user($uid, $paramters[$template_name], $templatedata,$link,$template_name);

            foreach ($admin_uid as $key => $value) {
                if($value>0){
                    notification_user($value, $paramters[$template_name], $templatedata,$link,$template_name);
                }
            }

        $magcon = '{"tag":"'.$apptpl['magapp']['tag'].'","title":"'.$apptpl['magapp']['title'].'","title_themecolor":"#ff0000","link":"'.$link.'","extra_info":[{"key":"","val":""}],"des":"'.$apptpl['magapp']['des'].'","des_themecolor":"#008000"}';

        notification_user_magapp($uid, $magcon);

        foreach ($admin_uid as $key => $value) {
            notification_user_magapp($value, $magcon);
        }

        $qfcon['msg'] = $apptpl['qfapp']['msg'];
        $qfcon['showdata'] = '';
        $qfcon['showdata'] = array(
            'title'=>diconv($apptpl['qfapp']['title'], CHARSET, 'utf-8'),
            'date'=>date('Y-m-d H:i:s'),
            'setting'=>array(),
            'content' => diconv($apptpl['qfapp']['content'],CHARSET,'UTF-8'),
            'url'=>$link
        );
        notification_user_qfapp($uid, $qfcon);

        foreach ($admin_uid as $key => $value) {
            notification_user_qfapp($value, $qfcon);
        }

    }

    function notification_user($uid,$template_id,$postdata,$posturl,$template_name=''){
        global $_G;

        $zmdata = $_G['cache']['plugin']['zimu_zhaopin'];
        $setdata = Db::name('zimu_zhaopin_setting')->order('id','desc')->find();
        $zmdata['base'] = $setdata;
        $zmdata['settings'] = unserialize($setdata['settings']);

        require_once DISCUZ_ROOT . './source/plugin/zimu_zhaopin/class/wechat.lib.class.php';
        $wechat_client = new WeChatClient($zmdata['base']['weixin_appid'],$zmdata['base']['weixin_appsecret']);

        if ($uid == 'admin') {
            $weixin_openid = explode(",", trim($zmdata['settings']['weixin_openid']));
            foreach ($weixin_openid as $key => $value) {
                if($value){
                    $template = array(
                        'touser' => $value,
                        'template_id' => $template_id,
                        'url' => $posturl,
                        'topcolor' => "#7B68EE",
                    );
                    $template['data'] = $postdata;
                    $template = zimu_array_utf8($template);
                    $json     = json_encode($template,true);
                    $result   = $wechat_client->send_weixintemplate($json);

                    $sendtpllog['uid'] = $uid;
                    $sendtpllog['openid'] = $value;
                    $sendtpllog['con'] = $json;
                    $sendtpllog['type'] = $template_name;
                    $sendtpllog['addtime'] = time();
                    $sendtpllog['issend'] = 1;
                    $sendtpllog['sendtime'] = time();
                    $sendtpllog['sendback'] = $result['errmsg'];
                    Db::name('zimu_zhaopin_sendtpllog')->insert($sendtpllog);
                }
            }
        }elseif($uid>0){
            $weixin_openid = Db::name('zimu_zhaopin_members')->where('uid', $uid)->order('id','desc')->find();
            if($weixin_openid['openid']){
                $template = array(
                    'touser' => $weixin_openid['openid'],
                    'template_id' => $template_id,
                    'url' => $posturl,
                    'topcolor' => "#7B68EE",
                );
                $template['data'] = $postdata;
                $template = zimu_array_utf8($template);
                $json     = json_encode($template,true);
                $result   = $wechat_client->send_weixintemplate($json);
                $sendtpllog['uid'] = $uid;
                $sendtpllog['openid'] = $weixin_openid['openid'];
                $sendtpllog['con'] = $json;
                $sendtpllog['type'] = $template_name;
                $sendtpllog['addtime'] = time();
                $sendtpllog['issend'] = 1;
                $sendtpllog['sendtime'] = time();
                $sendtpllog['sendback'] = $result['errmsg'];
                Db::name('zimu_zhaopin_sendtpllog')->insert($sendtpllog);
            }
        }

    }

    function notification_user_magapp($uid,$postdata){
        global $_G;

        $mag_paramter = Db::name('zimu_zhaopin_parameter2')->where('name', 'magapp')->order('id','desc')->find();
        $mag_paramter = unserialize($mag_paramter['parameter']);

        if($mag_paramter['magapp_hostname']) {
            if ($uid == 'admin') {

                $weixin_openid = explode(",", trim($mag_paramter['magapp_uids']));

                foreach ($weixin_openid as $key => $value) {

                    notification_user_magapp($value, $postdata);

                }


            }elseif($uid>0){

                $magurl = $mag_paramter['magapp_hostname'] . '/mag/operative/v1/assistant/sendAssistantMsg';
                $magpostdata['user_id'] = $uid;
                $magpostdata['type'] = 'texttemp';
                $magpostdata['content'] = diconv($postdata, CHARSET, 'utf-8');
                $magpostdata['assistant_secret'] = $mag_paramter['assistant_secret'];
                $magpostdata['secret'] = $mag_paramter['magapp_secret'];
                $magpostdata['is_push'] = 1;
                $magdata = lizimu_post($magurl, $magpostdata);

            }
        }

    }


    function notification_user_qfapp($uid,$postdata){
        global $_G;

        $qf_paramter = Db::name('zimu_zhaopin_parameter2')->where('name', 'qfapp')->order('id','desc')->find();
        $qf_paramter = unserialize($qf_paramter['parameter']);

        if($qf_paramter['qf_hostname']) {
            if ($uid == 'admin') {

                $weixin_openid = explode(",", trim($qf_paramter['qfapp_uids']));

                foreach ($weixin_openid as $key => $value) {

                    notification_user_qfapp($value, $postdata);

                }


            }elseif($uid>0){

                require_once DISCUZ_ROOT . './source/plugin/zimu_zhaopin/class/qfapp.class.php';
                $client = new QF_HTTP_CLIENT($qf_paramter['qf_hostname'], $qf_paramter['qf_secret']);

                $showdata = array(
                    'from' => $qf_paramter['qfapp_from_uid'],
                    'target' => $uid,
                    'msg' => $postdata['msg'],
                    'showData' => json_encode($postdata['showdata'])
                );

                $data = $client->post('message/template', $showdata);

            }
        }

    }

    function notification_user_sms($mobile,$type,$find,$replace){

        global $_G;
        $langfile = DISCUZ_ROOT . './source/plugin/zimu_zhaopin/language.' . currentlang() . '.php';
        $includefile = is_file($langfile) ? $langfile : libfile('language', 'plugin/zimu_zhaopin');
        include $includefile;

        $sms_paramter = Db::name('zimu_zhaopin_parameter2')->where('name', 'aliyunsms')->order('id','desc')->find();
        $sms_paramter = unserialize($sms_paramter['parameter']);
        $lastsms = Db::name('zimu_zhaopin_sendsmslog')->where([['mobile','=',$mobile],['type','<>','code']])->order('id','desc')->find();

        if(!$sms_paramter['sms_interval'] || $lastsms['addtime'] < time() - $sms_paramter['sms_interval']){

        if($sms_paramter['marketsms']!=1 && $sms_paramter['chanyoo_username'] && $sms_paramter['chanyoo_password']) {
            $sms_url = 'https://api.chanyoo.net/sendsms';
            $postdata['username'] = $sms_paramter['chanyoo_username'];
            $postdata['password'] = $sms_paramter['chanyoo_password'];
            $postdata['mobile'] = $mobile;
            $content = $sms_paramter[$type];
            $content = $content2 = str_replace($find,$replace,$content);
            $content = zimu_array_utf8($content);
            $postdata['content'] = $content;
            $smsdata = lizimu_post($sms_url, $postdata);

            $myuid2 = checktoken($_GET['token'],0);

            $sendsmslog = ['uid' => $myuid2['uid'],'mobile' => $mobile,'con' => $content2,'type' => $type,'addtime' => time()];
            Db::name('zimu_zhaopin_sendsmslog')->insert($sendsmslog);

            return $smsdata;

        }elseif($sms_paramter['marketsms']==1){

            $app_key = $sms_paramter['smsAppKey'];
            $app_secret = $sms_paramter['smssecretKey'];
            $sign_name = mb_convert_encoding($sms_paramter['smsFreeSignName'],'UTF-8',CHARSET);
            if($type=='chanyoo_sms_tp1'){
                $smsdata['remark'] = $replace;
            }elseif ($type=='chanyoo_sms_tp2'){
                $content = $language_zimu['new_config_php_20'].'company_name';
                $smsdata['remark'] = str_replace($find,$replace,$content);
            }
            $smsdata['remark'] = zimu_array_utf8($smsdata['remark']);

            $requestUrl = "http://dysmsapi.aliyuncs.com/";
            $params['PhoneNumbers']= $mobile;
            $params['SignName']= $sign_name;
            $params['TemplateCode']= $sms_paramter['smsTemplateCode2'];
            $params['TemplateParam']= json_encode($smsdata);
            $params['OutId']= "3333";
            $params['RegionId']= "cn-hangzhou";
            $params['AccessKeyId']= $app_key;
            $params['Format']= "JSON";
            $params['SignatureMethod']= "HMAC-SHA1";
            $params['SignatureVersion']= "1.0";
            $params['SignatureNonce']= uniqid();
            date_default_timezone_set("GMT");
            $params['Timestamp']= date("Y-m-d\TH:i:s\Z");
            $params['Action']= "SendSms";
            $params['Version']= "2017-05-25";
            $params['Signature']= zimu_aliyun_signature($params,$app_secret);

            include_once DISCUZ_ROOT . './source/plugin/zimu_zhaopin/class/Aliyun_HttpHelper.class.php';

            $Aliyun_HttpHelper = new Aliyun_HttpHelper();
            $result = $Aliyun_HttpHelper->curl($requestUrl,'POST',$params,array('x-sdk-client' => 'php/2.0.0'));

        }
        }
    }

    function lizimu_post($url, $data) {
        if (!function_exists('curl_init')) {
            return '';
        }
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        # curl_setopt( $ch, CURLOPT_HEADER, 1);

        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);

        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        $data = curl_exec($ch);
        if (!$data) {
            error_log(curl_error($ch));
        }
        curl_close($ch);
        return $data;
    }

    function zm_curl($url){
        $retfrom=dfsockopen($url);
        if (!$retfrom) {
            $retfrom=zm_curl_get($url);
        }
        return $retfrom;
    }
    function zm_curl_get($url){
        if (!function_exists('curl_init')) {
            return file_get_contents($url);
        }
        $ch=curl_init();
        curl_setopt($ch,CURLOPT_URL,$url);
        curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
        curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,false);
        curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,false);
        if (!curl_exec($ch)) {
            error_log(curl_error($ch));
            $data='';
        }else{
            $data=curl_multi_getcontent($ch);
        }
        curl_close($ch);
        return $data;
    }

    function get_discount_for_setmeal_one($setmeal)
    {
        $arr[0] = $setmeal['discount_download_resume'];
        $arr[1] = $setmeal['discount_stick'];
        $arr[2] = $setmeal['discount_auto_refresh_jobs'];
        unset($arr[array_search(0, $arr)]);
        $pos    = array_search(min($arr), $arr);
        $return = $arr[$pos];
        return _format_discount($return);
    }
    function _format_discount($value)
    {
        $value_arr = explode(".", $value);
        if ($value_arr[1] == 0) {
            return $value_arr[0];
        } else {
            return $value;
        }
    }



    function zm_wechat_auth($tourl)
    {
        global $_G;

        if (!IN_WECHAT) {
            return;
        }

        $zmdata = $_G['cache']['plugin']['zimu_zhaopin'];

        $setdata = Db::name('zimu_zhaopin_setting')->order('id','desc')->find();
        $zmdata['base'] = $setdata;
        $zmdata['settings'] = unserialize($setdata['settings']);


        require_once DISCUZ_ROOT . './source/plugin/zimu_zhaopin/class/wechat.lib.class.php';
        $wechat_client2 = new WeChatClient($zmdata['base']['weixin_appid'], $zmdata['base']['weixin_appsecret']);

        $code = addslashes($_GET['code']);

        if ($code && $_GET['codewx'] == 1) {
            $token = $wechat_client2->getAccessTokenByCode($code);

            if (!$token['openid'] && !$zimu_zhaopin_openid) {
                showmessage('error' . ($token['errmsg'] ? ' AccessToken: ' . $token['errmsg'] : ''), $tourl);
            }

            if (!$token['openid']) {
                $newtoken = $wechat_client2->getAccessToken(1, 0);
            }

            $userinfo = $wechat_client2->getUserInfoByAuth($token['access_token'], $token['openid']);

            if($userinfo['openid']) {
                dsetcookie('zimu_zhaopin_openid', authcode($userinfo['openid'] . "\t" . TIMESTAMP, 'ENCODE'), 12000, 1, true);
                dsetcookie('zimu_zhaopin_unionid', authcode($userinfo['unionid'] . "\t" . TIMESTAMP, 'ENCODE'), 12000, 1, true);
                return $userinfo['openid'];
            }

        } else {

            if ($_G['cache']['plugin']['zimu_zhaopin']['oauth2_url']) {

                $login_url = $_G['cache']['plugin']['zimu_zhaopin']['oauth2_url'] . '?appid=' . $zmdata['base']['weixin_appid'] . '&scope=snsapi_userinfo&state=' . md5(FORMHASH) . '&redirect_uri=' . urlencode($tourl . '&codewx=1');

            } else {

                $login_url = 'https://open.weixin.qq.com/connect/oauth2/authorize?appid=' . $zmdata['base']['weixin_appid'] . '&redirect_uri=' . urlencode($tourl . '&codewx=1') . '&response_type=code&scope=snsapi_userinfo&state=' . md5(FORMHASH) . '#wechat_redirect';

            }

            dheader('Location:' . $login_url);

        }

    }
    function updata_resume_percent($setsqlarr,$type='all'){
        $setsqlarr['complete_percent'] = 0;
        $setsqlarr['complete_percent'] = $setsqlarr['fullname'] ? ($setsqlarr['complete_percent']+10) : $setsqlarr['complete_percent'];
        $setsqlarr['complete_percent'] = $setsqlarr['trade'] ? ($setsqlarr['complete_percent']+0) : $setsqlarr['complete_percent'];
        $setsqlarr['complete_percent'] = $setsqlarr['birthdate'] ? ($setsqlarr['complete_percent']+5) : $setsqlarr['complete_percent'];
        $setsqlarr['complete_percent'] = $setsqlarr['experience'] ? ($setsqlarr['complete_percent']+5) : $setsqlarr['complete_percent'];
        $setsqlarr['complete_percent'] = $setsqlarr['district'] ? ($setsqlarr['complete_percent']+5) : $setsqlarr['complete_percent'];
        $setsqlarr['complete_percent'] = $setsqlarr['education'] ? ($setsqlarr['complete_percent']+5) : $setsqlarr['complete_percent'];
        $setsqlarr['complete_percent'] = $setsqlarr['intention_jobs_id'] ? ($setsqlarr['complete_percent']+5) : $setsqlarr['complete_percent'];
        $setsqlarr['complete_percent'] = $setsqlarr['specialty'] ? ($setsqlarr['complete_percent']+15) : $setsqlarr['complete_percent'];
        $setsqlarr['complete_percent'] = $setsqlarr['photo_img'] ? ($setsqlarr['complete_percent']+10) : $setsqlarr['complete_percent'];
        if($type=='getbase'){
            return $setsqlarr['complete_percent'];
        }

        $myresume['work_nums'] = Db::name('zimu_zhaopin_resume_work')->where([['uid','=',$setsqlarr['uid']]])->order(['id'=>'asc'])->count();
        $myresume['education_nums'] = Db::name('zimu_zhaopin_resume_education')->where([['uid','=',$setsqlarr['uid']]])->order(['id'=>'asc'])->count();

        $setsqlarr['complete_percent'] = $myresume['work_nums'] ? ($setsqlarr['complete_percent']+20) : $setsqlarr['complete_percent'];
        $setsqlarr['complete_percent'] = $myresume['education_nums'] ? ($setsqlarr['complete_percent']+20) : $setsqlarr['complete_percent'];

        Db::name('zimu_zhaopin_resume')->where([['uid','=',$setsqlarr['uid']]])->data(['complete_percent' => $setsqlarr['complete_percent']])->update();

    }
    function hex2rgb($hexColor){
        $color=str_replace('#','',$hexColor);
        if (strlen($color)> 3){
            $rgb=array(
                'r'=>hexdec(substr($color,0,2)),
                'g'=>hexdec(substr($color,2,2)),
                'b'=>hexdec(substr($color,4,2))
            );
        }else{
            $r=substr($color,0,1). substr($color,0,1);
            $g=substr($color,1,1). substr($color,1,1);
            $b=substr($color,2,1). substr($color,2,1);
            $rgb=array(
                'r'=>hexdec($r),
                'g'=>hexdec($g),
                'b'=>hexdec($b)
            );
        }
        return $rgb;
    }
    function zimu_aliyun_signature($params,$AccessKeySecret){
        ksort($params);

        $canonicalizedQueryString = '';
        foreach($params as $key => $value){
            $canonicalizedQueryString .= '&' . zimu_percentEncode($key). '=' . zimu_percentEncode($value);
        }

        $stringToSign = 'POST&%2F&' . zimu_percentEncode(substr($canonicalizedQueryString, 1));

        $signature = base64_encode(hash_hmac('sha1', $stringToSign, $AccessKeySecret."&", true));
        return $signature;
    }

    function zimu_percentEncode($str){
        $res = urlencode($str);
        $res = preg_replace('/\+/', '%20', $res);
        $res = preg_replace('/\*/', '%2A', $res);
        $res = preg_replace('/%7E/', '~', $res);
        return $res;
    }
    function zimu_ad_system($list,$newtype,$catid){
        if($_SERVER['HTTP_CLIENTTYPE'] != 'xcx' && $_SERVER['REQUEST_METHOD'] != 'OPTIONS' && $list){
            if($catid){
                $where_catid[] = ['newcatid','like','%'.$catid.',%'];
            }else{
                $where_catid[] = ['1','=',1];
            }
            if($_SERVER['HTTP_CLIENTTYPE'] == 'magapp' || $_SERVER['HTTP_CLIENTTYPE'] == 'qianfan'){
                $where_catid[] = ['noapp','<>',1];
            }

            $positionad = Db::name('zimu_zhaopin_adlist')->where($where_catid)->where([['newtype','like','%'.$newtype.',%'],['position','>',($_GET['page']-1)*10],['position','<=',$_GET['page']*10]])->orderRaw('rand()')->limit(1)->select()->toArray();
            if($positionad[0]){
                $positionad[0] = array_merge($list[0],$positionad[0]);
                Db::name('zimu_zhaopin_adlist')->where('id', $positionad[0]['id'])->inc('views', 1)->update();
                array_splice($list,$positionad[0]['position']-1,0,$positionad);
            }elseif ($list && $_GET['page']%2!=0){
                $randad = Db::name('zimu_zhaopin_adlist')->where($where_catid)->where([['newtype','like','%'.$newtype.',%'],['position','=',0]])->orderRaw('rand()')->limit(1)->select()->toArray();
                if($randad[0]){
                    $randad[0] = array_merge($list[0],$randad[0]);
                    $rand = mt_rand(0,9);
                    Db::name('zimu_zhaopin_adlist')->where('id', $randad[0]['id'])->inc('views', 1)->update();
                    array_splice($list,$rand,0,$randad);
                }
            }
            return $list;
        }
        return $list;
    }
    function zimu_ad_system2($newtype){
        if($_SERVER['REQUEST_METHOD'] != 'OPTIONS' && $newtype) {
            if($_SERVER['HTTP_CLIENTTYPE'] == 'magapp' || $_SERVER['HTTP_CLIENTTYPE'] == 'qianfan'){
                $where_catid[] = ['noapp','<>',1];
            }else{
                $where_catid[] = ['1','=',1];
            }
            $randad = Db::name('zimu_zhaopin_adlist')->where($where_catid)->where([['newtype', 'like', '%' . $newtype . ',%'], ['position', '=', 0]])->orderRaw('rand()')->limit(1)->select()->toArray();
            if ($randad[0]) {
                Db::name('zimu_zhaopin_adlist')->where('id', $randad[0]['id'])->inc('views', 1)->update();
            }
            return $randad[0];
        }
    }
    function zp_url_replace($rulename,$replacename,$replaceid){

        global $_G;

        $zimu_rewrite = dunserialize($_G['setting']['zimu_rewrite']);

        $domainlist = $_G['setting']['domain']['list'];
        foreach ($domainlist as $k => $v) {
            if ($v['idtype'] == 'plugin') {
                $domainlist2[$v['id']] = $k;
            }
        }
        $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";

        if($domainlist2['zimu_zhaopin']){
            $zp_url = $protocol.$domainlist2['zimu_zhaopin'].'/';
            $zp_url2 = $protocol.$domainlist2['zimu_zhaopin'].'/';
        }else{
            $zp_url = ZIMUCMS_URL;
            $zp_url2 = $_G['siteurl'];
        }

        if($zimu_rewrite['zp_'.$rulename]['available']){
            return $zp_url2.str_replace(array('{','}',$replacename),array('','',$replaceid),$zimu_rewrite['zp_'.$rulename]['rule']);

        }else{
            return ZIMUCMS_URL.'&model='.$rulename.'&'.$replacename.'='.$replaceid;
        }

    }
    function finish_order2($order_id,$trade_no)
    {
        $_G = $GLOBALS['_G'];
        if (!$_G['cache']['plugin']) {
            loadcache('plugin');
        }

        $config = $_G['cache']['plugin']['zimu_zhaopin'];
        $setdata = Db::name('zimu_zhaopin_setting')->find();
        $config['base'] = $setdata;
        $config['settings'] = unserialize($setdata['settings']);
        $config['settings']['jifen_bili'] = $config['settings']['jifen_bili'] ? $config['settings']['jifen_bili'] : 10;
        $config['settings']['jifen_bili'] = intval($config['settings']['jifen_bili']);

        $order = Db::name('zimu_zhaopin_order')->where('oid', $order_id)->find();
        $order['params'] = $order['params']?unserialize($order['params']):array();

        if($order && $order['is_paid'] == 1) {

        $setsqlarr['is_paid']           = 2;
        $setsqlarr['order_sn']           = $trade_no;
        $setsqlarr['payment_time']           = time();
        Db::name('zimu_zhaopin_order')->where('id' ,$order['id'])->update($setsqlarr);

        if($order['pay_points']>0){
            Db::name('zimu_zhaopin_members')->where('uid', $order['uid'])->dec('points', $order['pay_points'])->update();
            $setsqlarr_handsel['uid']     = $order['uid'];
            $setsqlarr_handsel['htype']    = $order['service_name'];
            $setsqlarr_handsel['htype_cn']    = $order['description'];
            $setsqlarr_handsel['operate']    = 2;
            $setsqlarr_handsel['points'] = $order['pay_points'];
            $setsqlarr_handsel['addtime'] = time();
            Db::name('zimu_zhaopin_members_handsel')->insert($setsqlarr_handsel);
        }

        if ($order['zpid']) {
            switch($order['service_name']){
                case 'jobs_refresh':
                    Db::name('zimu_zhaopin_jobs')->where('id', $order['zpid'])->data(['refreshtime' => time()])->update();
                    $setsqlarr_refresh_log['uid']     = $order['uid'];
                    $setsqlarr_refresh_log['mode']    = 2;
                    $setsqlarr_refresh_log['addtime'] = time();
                    $setsqlarr_refresh_log['type']    = 1001;
                    Db::name('zimu_zhaopin_refresh_log')->insert($setsqlarr_refresh_log);

                    break;
                case 'jobs_stick':

                    $jobinfo = Db::name('zimu_zhaopin_jobs')->where([['id','=',$order['zpid']]])->order(['id'=>'desc'])->find();
                    if($jobinfo['stick_endtime']>time()){
                        Db::name('zimu_zhaopin_jobs')->where('id', $order['zpid'])->data(['stick' => 1])->update();
                        Db::name('zimu_zhaopin_jobs')->where('id', $order['zpid'])->inc('stick_endtime', $order['params']['days']*86400)->update();
                    }else{
                        Db::name('zimu_zhaopin_jobs')->where('id', $order['zpid'])->data(['stick' => 1,'stick_endtime' => strtotime("{$order['params']['days']} day")])->update();
                    }

                    break;
                case 'jobs_pay_add':

                    if($config['settings']['com_money_audit']==1){
                        Db::name('zimu_zhaopin_jobs')->where('id', $order['zpid'])->data(['audit' => 1,'ispay' => 0])->update();
                    }else{
                        Db::name('zimu_zhaopin_jobs')->where('id', $order['zpid'])->data(['audit' => 2,'ispay' => 0])->update();
                    }

                    if($order['params']['days']>0){
                        Db::name('zimu_zhaopin_jobs')->where('id', $order['zpid'])->data(['stick' => 1,'stick_endtime' => strtotime("{$order['params']['days']} day")])->update();
                    }

                    break;
                case 'setmeal_add':

                    $setmeal = Db::name('zimu_zhaopin_setmeal')->where([['id','=',$order['setmeal']],['display','=',1]])->order(['id'=>'desc'])->find();

                    $user_setmeal = Db::name('zimu_zhaopin_members_setmeal')->where([['uid','=',$order['uid']]])->order(['id'=>'desc'])->find();

                    $timestamp = time();
                    $setmeal_add['expire'] = $setmeal['is_free'] == 1 ? 1 : 0;
                    $setmeal_add['uid'] = $order['uid'];
                    $setmeal_add['setmeal_id'] = $setmeal['id'];
                    $setmeal_add['setmeal_name'] = $setmeal['setmeal_name'];
                    $setmeal_add['days'] = $setmeal['days'];
                    $setmeal_add['expense']=$setmeal['expense'];
                    $setmeal_add['jobs_meanwhile']=$setmeal['jobs_meanwhile'];
                    $setmeal_add['refresh_jobs_free']=$setmeal['refresh_jobs_free'];
                    $setmeal_add['download_resume'] = $user_setmeal['download_resume'] + $setmeal['download_resume'];
                    $setmeal_add['download_resume_max'] = $setmeal['download_resume_max'];
                    $setmeal_add['added']=$setmeal['added'];
                    if ($setmeal['days']>0){
                        $setmeal_add['endtime']=strtotime("".$setmeal['days']." days");
                    }else{
                        $setmeal_add['endtime']="0";
                    }
                    $setmeal_add['show_apply_contact'] = $setmeal['show_apply_contact'];
                    $setmeal_add['is_free']=$setmeal['is_free'];
                    $setmeal_add['discount_download_resume']=$setmeal['discount_download_resume'];
                    $setmeal_add['discount_stick']=$setmeal['discount_stick'];
                    $setmeal_add['discount_emergency']=$setmeal['discount_emergency'];
                    $setmeal_add['discount_auto_refresh_jobs']=$setmeal['discount_auto_refresh_jobs'];

                    Db::name('zimu_zhaopin_members_setmeal')->where('uid', $order['uid'])->data($setmeal_add)->update();

                    Db::name('zimu_zhaopin_company_profile')->where('uid', $order['uid'])->data(['setmeal_id' => $setmeal['id'],'setmeal_name' => $setmeal['setmeal_name']])->update();

                    if($setmeal['give_points']){
                        Db::name('zimu_zhaopin_members')->where('uid', $order['uid'])->inc('points', $setmeal['give_points']*10/$config['settings']['jifen_bili'])->update();
                    }

                    break;
                case 'resume_download':

                    $resume_download['resume_id'] = $order['zpid'];
                    $resume_download['company_uid'] = $order['uid'];
                    $resume_download['down_addtime'] = time();
                    Db::name('zimu_zhaopin_company_down_resume')->insert($resume_download);

                    break;
                case 'resume_stick':

                    if($config['settings']['resume_join_money']){
                        Db::name('zimu_zhaopin_resume')->where('id', $order['zpid'])->data(['audit' => 1])->update();
                    }

                    $resumeinfo = Db::name('zimu_zhaopin_resume')->where([['id','=',$order['zpid']]])->order(['id'=>'desc'])->find();

                    if($resumeinfo['stick_endtime']>time()){
                        Db::name('zimu_zhaopin_resume')->where('id', $order['zpid'])->data(['stick' => 1])->update();
                        Db::name('zimu_zhaopin_resume')->where('id', $order['zpid'])->inc('stick_endtime', $order['params']['days']*86400)->update();
                    }else{
                        Db::name('zimu_zhaopin_resume')->where('id', $order['zpid'])->data(['stick' => 1,'stick_endtime' => strtotime("{$order['params']['days']} day")])->update();
                    }

                    break;

                case 'resume_join_money':

                    if($config['settings']['resume_join_money']){
                        Db::name('zimu_zhaopin_resume')->where('id', $order['zpid'])->data(['audit' => 1])->update();
                    }

                    break;


                case 'strong_tag':

                    Db::name('zimu_zhaopin_resume')->where('id', $order['zpid'])->data(['strong_tag' => $order['params']['strong_tag'],'strong_tag_endtime' => strtotime("{$order['params']['days']} day")])->update();

                    break;
                case 'jobs_auto_refresh':

                    $setmeal_increment = Db::name('zimu_zhaopin_setmeal_increment')->where([['id','=',$order['setmeal']]])->order(['id'=>'desc'])->find();

                    $days = $setmeal_increment['value'];
                    $nowtime = time();
                    for ($i = 0; $i < $days * 4; $i++) {
                        $timespace = 3600 * 6 * $i;

                        $queue_auto_refresh['uid'] = $order['uid'];
                        $queue_auto_refresh['pid'] = $order['zpid'];
                        $queue_auto_refresh['type'] = 1;
                        $queue_auto_refresh['refreshtime'] = $nowtime + $timespace;
                        Db::name('zimu_zhaopin_queue_auto_refresh')->insert($queue_auto_refresh);

                    }

                    break;
                case 'download_resume':

                    Db::name('zimu_zhaopin_members_setmeal')->where('uid', $order['uid'])->inc('download_resume2', $order['params']['nums'])->update();

                    break;
                case 'buy_points':

                    Db::name('zimu_zhaopin_members')->where('uid', $order['uid'])->inc('points', $order['params']['add_num'])->update();

                    $setsqlarr_handsel['uid']     = $order['uid'];
                    $setsqlarr_handsel['htype']    = $order['service_name'];
                    $setsqlarr_handsel['htype_cn']    = $order['description'];
                    $setsqlarr_handsel['operate']    = 1;
                    $setsqlarr_handsel['points'] = $order['params']['add_num'];
                    $setsqlarr_handsel['addtime'] = time();
                    Db::name('zimu_zhaopin_members_handsel')->insert($setsqlarr_handsel);

                    break;

            }
        }
        }
    }
    function get_money_currency($appcode,$amount,$tomoney){
        $host = "https://jisuhuilv.market.alicloudapi.com";
        $path = "/exchange/convert";
        $method = "GET";
        $headers = array();
        array_push($headers, "Authorization:APPCODE " . $appcode);
        array_push($headers, "Content-Type".":"."application/json; charset=UTF-8");
        $querys = "amount=".$amount."&from=".$tomoney."&to=CNY";
        $bodys = "null";
        $url = $host . $path . "?" . $querys;
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $method);
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($curl, CURLOPT_FAILONERROR, false);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_HEADER, false);
        if (1 == strpos("$".$host, "https://"))
        {
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
        }
        curl_setopt($curl, CURLOPT_POSTFIELDS, $bodys);
        $res = curl_exec($curl);
        return $res;
    }
    function to_create_setmeal($myuid){

            $company_profile = Db::name('zimu_zhaopin_company_profile')->where([['uid','=',$myuid['uid']]])->find();
            $setmeal = Db::name('zimu_zhaopin_members_setmeal')->where([['uid','=',$myuid['uid']]])->find();

            if($company_profile && !$setmeal){
                $freesetmeal = Db::name('zimu_zhaopin_setmeal')->where([['id','=',1]])->find();
                $setsqlarr2['expire']              = $freesetmeal['is_free'] == 1 ? 1 : 0;
                $setsqlarr2['uid']                 = $myuid['uid'];
                $setsqlarr2['setmeal_id']          = $freesetmeal['id'];
                $setsqlarr2['setmeal_name']        = $freesetmeal['setmeal_name'];
                $setsqlarr2['days']                = $freesetmeal['days'];
                $setsqlarr2['expense']             = $freesetmeal['expense'];
                $setsqlarr2['jobs_meanwhile']      = $freesetmeal['jobs_meanwhile'];
                $setsqlarr2['refresh_jobs_free']   = $freesetmeal['refresh_jobs_free'];
                $setsqlarr2['download_resume']     = $freesetmeal['download_resume'];
                $setsqlarr2['download_resume_max'] = $freesetmeal['download_resume_max'];
                $setsqlarr2['added']               = $freesetmeal['added'];
                $setsqlarr2['starttime']           = time();
                if ($freesetmeal['days'] > 0) {
                    $setsqlarr2['endtime'] = strtotime("" . $freesetmeal['days'] . " days");
                } else {
                    $setsqlarr2['endtime'] = "0";
                }
                $setsqlarr2['set_sms'] = $freesetmeal['set_sms'];
                $setsqlarr2['show_apply_contact']         = $freesetmeal['show_apply_contact'];
                $setsqlarr2['is_free']                    = $freesetmeal['is_free'];
                $setsqlarr2['discount_download_resume']   = $freesetmeal['discount_download_resume'];
                $setsqlarr2['discount_sms']               = $freesetmeal['discount_sms'];
                $setsqlarr2['discount_stick']             = $freesetmeal['discount_stick'];
                $setsqlarr2['discount_emergency']         = $freesetmeal['discount_emergency'];
                $setsqlarr2['discount_auto_refresh_jobs'] = $freesetmeal['discount_auto_refresh_jobs'];
                Db::name('zimu_zhaopin_members_setmeal')->insert($setsqlarr2);
            }
    }
    function zimu_cutstr($string, $length, $dot = '') {
        if(strlen($string) <= $length) {
            return $string;
        }

        $pre = chr(1);
        $end = chr(1);
        $string = str_replace(array('&amp;', '&quot;', '&lt;', '&gt;'), array($pre.'&'.$end, $pre.'"'.$end, $pre.'<'.$end, $pre.'>'.$end), $string);

        $strcut = '';
        if(strtolower(CHARSET) == 'utf-8') {

            $n = $tn = $noc = 0;
            while($n < strlen($string)) {

                $t = ord($string[$n]);
                if($t == 9 || $t == 10 || (32 <= $t && $t <= 126)) {
                    $tn = 1; $n++; $noc++;
                } elseif(194 <= $t && $t <= 223) {
                    $tn = 2; $n += 2; $noc += 2;
                } elseif(224 <= $t && $t <= 239) {
                    $tn = 3; $n += 3; $noc += 2;
                } elseif(240 <= $t && $t <= 247) {
                    $tn = 4; $n += 4; $noc += 2;
                } elseif(248 <= $t && $t <= 251) {
                    $tn = 5; $n += 5; $noc += 2;
                } elseif($t == 252 || $t == 253) {
                    $tn = 6; $n += 6; $noc += 2;
                } else {
                    $n++;
                }

                if($noc >= $length) {
                    break;
                }

            }
            if($noc > $length) {
                $n -= $tn;
            }

            $strcut = substr($string, 0, $n);

        } else {
            $_length = $length - 1;
            for($i = 0; $i < $length; $i++) {
                if(ord($string[$i]) <= 127) {
                    $strcut .= $string[$i];
                } else if($i < $_length) {
                    $strcut .= $string[$i].$string[++$i];
                }
            }
        }

        $strcut = str_replace(array($pre.'&'.$end, $pre.'"'.$end, $pre.'<'.$end, $pre.'>'.$end), array('&amp;', '&quot;', '&lt;', '&gt;'), $strcut);

        $pos = strrpos($strcut, chr(1));
        if($pos !== false) {
            $strcut = substr($strcut,0,$pos);
        }
        return $strcut.$dot;
    }
    function xcx_select_uid($xcx_zimu_data){
        if($xcx_zimu_data['unionid']){
            $isuid = Db::name('zimu_zhaopin_members')->where('unionid',$xcx_zimu_data['unionid'])->find();
            if(!$isuid['xcx_openid'] && $xcx_zimu_data['openid']){
                Db::name('zimu_zhaopin_members')->where('uid', $isuid['uid'])->data(['xcx_openid' => $xcx_zimu_data['openid']])->update();
                $isuid['xcx_openid'] = $xcx_zimu_data['openid'];
            }
        }else{
            $isuid = Db::name('zimu_zhaopin_members')->where('xcx_openid',$xcx_zimu_data['openid'])->find();
        }
        return $isuid;
    }
    function xcx_reg_user($xcx_zimu_data,$zmdata) {

        $regname = getnewname($xcx_zimu_data['username']);
        $uid = register($regname, 1, 0, $xcx_zimu_data['gender']);
        if ($uid) {
            syncAvatar($uid, $xcx_zimu_data['avatar']);
            if ($zmdata['settings']['xcx_isapp'] == 2 && $xcx_zimu_data['unionid']) {
                $appdata = array(
                    'uid' => $uid,
                    'nickname' => $regname,
                    'dateline' => $_G['timestamp'],
                    'unionid' => $xcx_zimu_data['unionid'],
                    'weibotype' => 'wechat',
                );
                Db::name('thirdbind')->insert($appdata);
            }
            if ($zmdata['settings']['xcx_isapp'] == 1 && $xcx_zimu_data['unionid']) {
                $appdata = array(
                    'userid' => $uid,
                    'name' => $regname,
                    'create_time' => $_G['timestamp'],
                    'unionid' => $xcx_zimu_data['unionid'],
                );
                Db::name('user_weixin_relations')->insert($appdata);
            }
            if ($zmdata['settings']['xcx_isapp'] == 3 && $xcx_zimu_data['unionid']) {
                $appdata = array(
                    'uid' => $uid,
                    'username' => $regname,
                    'openid' => '',
                    'status' => '2',
                    'type' => '1',
                    'param' => $xcx_zimu_data['unionid'],
                    'unionid' => $xcx_zimu_data['unionid'],
                    'wx_nickname' => $xcx_zimu_data['username'],
                    'wx_sex' => $xcx_zimu_data['gender'],
                    'wx_headimgurl' => $xcx_zimu_data['avatar']
                );
                Db::name('appbyme_connection')->insert($appdata);
            }
            if ($zmdata['settings']['xcx_isapp'] == 4 && $xcx_zimu_data['unionid']) {
                $appdata = array(
                    'uid' => $uid,
                    'username' => $regname,
                    'nickname' => $regname,
                    'openid' => '',
                    'dateline' => time(),
                    'type' => '1',
                    'unionid' => $xcx_zimu_data['unionid'],
                    'isregister' => 1,
                    'sex' => $xcx_zimu_data['gender'],
                    'lastauth' => time()
                );
                Db::name('zimucms_weixin_binduser')->insert($appdata);
            }
            return $uid;
        }
    }
    function getnewname($username)
    {
        global $_G;
        include_once DISCUZ_ROOT . './source/plugin/zimu_zhaopin/class/filter_biaoqing.php';
        $username = zm_login_clear($username);
        $username = zm_diconv($username);
        $newname = cutstr($username, 12, '');

        if ($newname) {
            $censorexp = '/^(' . str_replace(array(
                    '\\*',
                    "\r\n",
                    ' '
                ), array(
                    '.*',
                    '|',
                    ''
                ), preg_quote(($_G['setting']['censoruser'] = trim($_G['setting']['censoruser'])), '/')) . ')$/i';
            $newname   = preg_replace($censorexp, '', $newname);

            $guestexp = '\xA1\xA1|\xAC\xA3|^Guest|^\xD3\xCE\xBF\xCD|\xB9\x43\xAB\xC8';
            $newname  = preg_replace("/\s+|^c:\\con\\con|[%,\*\"\s\<\>\&]|$guestexp/is", '', $newname);
        }

        if (dstrlen($newname) >= 3) {
            loaducenter();
            if (uc_get_user($newname)) {
                $nums = 1;
                $oldname = $newname;
                do {
                    $newname = $oldname.$nums;
                    $nums++;
                } while (uc_get_user($newname));
                $newname = cutstr($newname, 14, '');
            }
        } else if ($newname) {
            $newname = $newname . '_' . random(5);
        } else {
            $newname = 'wx_' . random(5);
        }

        return $newname;
    }
    function register($username, $inapi = 0, $groupid = 0, $sex = 0)
    {
        global $_G;

        require_once libfile('function/member');

        if (!$username) {
            showmessage('undefined_action');
        }

        loaducenter();
        $groupid = !$groupid ? $_G['setting']['newusergroupid'] : $groupid;

        $password = md5(random(10));
        $email    = 'xcx_' . strtolower(random(10)) . '@null.null';

        $uid = uc_user_register(addslashes($username), $password, $email, '', '', $_G['clientip']);
        if ($uid <= 0) {
            if (!IN_WECHATAPI) {
                if ($uid == -1) {
                    showmessage('profile_username_illegal');
                } elseif ($uid == -2) {
                    showmessage('profile_username_protect');
                } elseif ($uid == -3) {
                    showmessage('profile_username_duplicate');
                } elseif ($uid == -4) {
                    showmessage('profile_email_illegal');
                } elseif ($uid == -5) {
                    showmessage('profile_email_domain_illegal');
                } elseif ($uid == -6) {
                    showmessage('profile_email_duplicate');
                } else {
                    showmessage('undefined_action');
                }
            } else {
                if ($uid == -1) {
                    echo WeChatServer::getXml4Txt(lang('message', 'profile_username_illegal'));
                } elseif ($uid == -2) {
                    echo WeChatServer::getXml4Txt(lang('message', 'profile_username_protect'));
                } elseif ($uid == -3) {
                    echo WeChatServer::getXml4Txt(lang('message', 'profile_username_duplicate'));
                } elseif ($uid == -4) {
                    echo WeChatServer::getXml4Txt(lang('message', 'profile_email_illegal'));
                } elseif ($uid == -5) {
                    echo WeChatServer::getXml4Txt(lang('message', 'profile_email_domain_illegal'));
                } elseif ($uid == -6) {
                    echo WeChatServer::getXml4Txt(lang('message', 'profile_email_duplicate'));
                } else {
                    echo WeChatServer::getXml4Txt(lang('message', 'undefined_action'));
                }
                exit;
            }
        }

        $init_arr = array(
            'credits' => explode(',', $_G['setting']['initcredits']),
            'profile' => array(
                'gender' => $sex
            )
        );
        C::t('common_member')->insert($uid, $username, $password, $email, $_G['clientip'], $groupid, $init_arr);

        if ($_G['setting']['regctrl'] || $_G['setting']['regfloodctrl']) {
            C::t('common_regip')->delete_by_dateline($_G['timestamp'] - ($_G['setting']['regctrl'] > 72 ? $_G['setting']['regctrl'] : 72) * 3600);
            if ($_G['setting']['regctrl']) {
                C::t('common_regip')->insert(array(
                    'ip' => $_G['clientip'],
                    'count' => -1,
                    'dateline' => $_G['timestamp']
                ));
            }
        }

        if ($_G['setting']['regverify'] == 2) {
            C::t('common_member_validate')->insert(array(
                'uid' => $uid,
                'submitdate' => $_G['timestamp'],
                'moddate' => 0,
                'admin' => '',
                'submittimes' => 1,
                'status' => 0,
                'message' => '',
                'remark' => ''
            ), false, true);
            manage_addnotify('verifyuser');
        }

        setloginstatus(array(
            'uid' => $uid,
            'username' => $username,
            'password' => $password,
            'groupid' => $groupid
        ), 0);


        include_once libfile('function/stat');
        updatestat('register');

        return $uid;
    }


    function syncAvatar($uid, $avatar)
    {

        if (!$uid || !$avatar) {
            return false;
        }

        if (!$content = dfsockopen($avatar)) {
            return false;
        }

        $tmpFile = DISCUZ_ROOT . './data/avatar/' . TIMESTAMP . random(6);
        file_put_contents($tmpFile, $content);

        if (!is_file($tmpFile)) {
            return false;
        }
        $result = uploadUcAvatar($uid, $tmpFile);
        unlink($tmpFile);

        C::t('common_member')->update($uid, array(
            'avatarstatus' => '1'
        ));
        return $result;
    }

    function uploadUcAvatar($uid, $localFile)
    {

        global $_G;
        if (!$uid || !$localFile) {
            return false;
        }

        list($width, $height, $type, $attr) = getimagesize($localFile);
        if (!$width) {
            return false;
        }
        if ($width < 10 || $height < 10 || $type == 4) {
            return false;
        }

        $imageType = array(
            1 => '.gif',
            2 => '.jpg',
            3 => '.png'
        );
        $fileType  = $imgType[$type];
        if (!$fileType) {
            $fileType = '.jpg';
        }
        $avatarPath = $_G['setting']['attachdir'];
        $tmpAvatar  = $avatarPath . './temp/upload' . $uid . $fileType;
        file_exists($tmpAvatar) && @unlink($tmpAvatar);
        file_put_contents($tmpAvatar, file_get_contents($localFile));

        if (!is_file($tmpAvatar)) {
            return false;
        }

        $tmpAvatarBig    = './temp/upload' . $uid . 'big' . $fileType;
        $tmpAvatarMiddle = './temp/upload' . $uid . 'middle' . $fileType;
        $tmpAvatarSmall  = './temp/upload' . $uid . 'small' . $fileType;

        $image = new image;
        if ($image->Thumb($tmpAvatar, $tmpAvatarBig, 200, 250, 1) <= 0) {
            return false;
        }
        if ($image->Thumb($tmpAvatar, $tmpAvatarMiddle, 120, 120, 1) <= 0) {
            return false;
        }
        if ($image->Thumb($tmpAvatar, $tmpAvatarSmall, 48, 48, 2) <= 0) {
            return false;
        }

        $tmpAvatarBig    = $avatarPath . $tmpAvatarBig;
        $tmpAvatarMiddle = $avatarPath . $tmpAvatarMiddle;
        $tmpAvatarSmall  = $avatarPath . $tmpAvatarSmall;
        $avatar1         = byte2hex(file_get_contents($tmpAvatarBig));
        $avatar2         = byte2hex(file_get_contents($tmpAvatarMiddle));
        $avatar3         = byte2hex(file_get_contents($tmpAvatarSmall));

        $extra  = '&avatar1=' . $avatar1 . '&avatar2=' . $avatar2 . '&avatar3=' . $avatar3;
        $result = uc_api_post_ex('user', 'rectavatar', array(
            'uid' => $uid
        ), $extra);

        @unlink($tmpAvatar);
        @unlink($tmpAvatarBig);
        @unlink($tmpAvatarMiddle);
        @unlink($tmpAvatarSmall);
        return true;
    }

    function byte2hex($string)
    {
        $buffer = '';
        $value  = unpack('H*', $string);
        $value  = str_split($value[1], 2);
        $b      = '';
        foreach ($value as $k => $v) {
            $b .= strtoupper($v);
        }

        return $b;
    }

    function uc_api_post_ex($module, $action, $arg = array(), $extra = '')
    {
        $s = $sep = '';
        foreach ($arg as $k => $v) {
            $k = urlencode($k);
            if (is_array($v)) {
                $s2 = $sep2 = '';
                foreach ($v as $k2 => $v2) {
                    $k2 = urlencode($k2);
                    $s2 .= "$sep2{$k}[$k2]=" . urlencode(uc_stripslashes($v2));
                    $sep2 = '&';
                }
                $s .= $sep . $s2;
            } else {
                $s .= "$sep$k=" . urlencode(uc_stripslashes($v));
            }
            $sep = '&';
        }
        $postdata = uc_api_requestdata($module, $action, $s, $extra);
        return uc_fopen2(UC_API . '/index.php', 500000, $postdata, '', true, UC_IP, 20);
    }
    function check_company_setmeal($uid){
        $company_profile = Db::name('zimu_zhaopin_company_profile')->where([['uid','=',$uid]])->find();
        if($company_profile){
            Db::name('zimu_zhaopin_company_profile')->where('uid', $uid)->data(['logintime' => time()])->update();
        }
        $setmeal = Db::name('zimu_zhaopin_members_setmeal')->where([['uid','=',$uid]])->find();
        if($company_profile && $setmeal['setmeal_id'] > 0 && $setmeal['endtime'] < time() && $setmeal['endtime'] > 0){
            $freesetmeal = Db::name('zimu_zhaopin_setmeal')->where([['id','=',1]])->find();

            $setsqlarr2['expire']              = $freesetmeal['is_free'] == 1 ? 1 : 0;
            $setsqlarr2['uid']                 = $uid;
            $setsqlarr2['setmeal_id']          = $freesetmeal['id'];
            $setsqlarr2['setmeal_name']        = $freesetmeal['setmeal_name'];
            $setsqlarr2['days']                = $freesetmeal['days'];
            $setsqlarr2['expense']             = $freesetmeal['expense'];
            $setsqlarr2['jobs_meanwhile']      = $freesetmeal['jobs_meanwhile'];
            $setsqlarr2['refresh_jobs_free']   = $freesetmeal['refresh_jobs_free'];
            $setsqlarr2['download_resume']     = 0;
            $setsqlarr2['download_resume2']     = $setmeal['download_resume2'];
            $setsqlarr2['download_resume_max'] = $freesetmeal['download_resume_max'];
            $setsqlarr2['added']               = $freesetmeal['added'];
            $setsqlarr2['starttime']           = time();
            if ($freesetmeal['days'] > 0) {
                $setsqlarr2['endtime'] = strtotime("" . $freesetmeal['days'] . " days");
            } else {
                $setsqlarr2['endtime'] = "0";
            }

            $setsqlarr2['set_sms'] = $setmeal['set_sms'] + $freesetmeal['set_sms'];

            $setsqlarr2['show_apply_contact']         = $freesetmeal['show_apply_contact'];
            $setsqlarr2['is_free']                    = $freesetmeal['is_free'];
            $setsqlarr2['discount_download_resume']   = $freesetmeal['discount_download_resume'];
            $setsqlarr2['discount_sms']               = $freesetmeal['discount_sms'];
            $setsqlarr2['discount_stick']             = $freesetmeal['discount_stick'];
            $setsqlarr2['discount_emergency']         = $freesetmeal['discount_emergency'];
            $setsqlarr2['discount_auto_refresh_jobs'] = $freesetmeal['discount_auto_refresh_jobs'];

            Db::name('zimu_zhaopin_members_setmeal')->where('uid', $uid)->data($setsqlarr2)->update();

            Db::name('zimu_zhaopin_company_profile')->where('uid', $uid)->data(['setmeal_id' => $setsqlarr2['setmeal_id'],'setmeal_name' => $setsqlarr2['setmeal_name']])->update();

            Db::name('zimu_zhaopin_jobs')->where('uid', $uid)->data(['setmeal_deadline' => $setsqlarr2['endtime'],'setmeal_id' => $setsqlarr2['setmeal_id'],'setmeal_name' => $setsqlarr2['setmeal_name']])->update();

        }

    }
    function tongbu_h5_mobile($myuid,$zmdata){
        if($zmdata['settings']['h5_isapp'] == 1){
            $isreg = Db::name('user_mobile_relations')->where([['userid','=',$myuid['uid']]])->find();
            if($isreg && !$myuid['telephone']){
                Db::name('zimu_zhaopin_members')->where('uid', $myuid['uid'])->data(['telephone' => $isreg['phone']])->update();
                $mobile = $isreg['phone'];
            }
        }
        if($zmdata['settings']['h5_isapp'] == 2){
            $isreg = Db::name('phonebind')->where([['uid','=',$myuid['uid']]])->find();
            if($isreg && !$myuid['telephone']){
                Db::name('zimu_zhaopin_members')->where('uid', $myuid['uid'])->data(['telephone' => $isreg['phone']])->update();
                $mobile = $isreg['phone'];
            }
        }
        if($zmdata['settings']['h5_isapp'] == 3){
            $isreg = Db::name('appbyme_sendsms')->where([['uid','=',$myuid['uid']]])->find();
            if($isreg && !$myuid['telephone']){
                Db::name('zimu_zhaopin_members')->where('uid', $myuid['uid'])->data(['telephone' => $isreg['mobile']])->update();
                $mobile = $isreg['mobile'];
            }
        }
        return $mobile;
    }
    function tongbu_h5_mobile2($mobile,$uid,$zmdata){
        if($zmdata['settings']['xcx_isapp'] == 1 && $mobile){
            $isreg = Db::name('user_mobile_relations')->where([['phone','=',$mobile],['userid','>',0]])->find();
            if(!$isreg){
                $appdata = array(
                    'userid' => $uid,
                    'phone' => $mobile,
                    'create_time' => time()
                );
                Db::name('user_mobile_relations')->insert($appdata);
            }
        }
        if($zmdata['settings']['xcx_isapp'] == 2 && $mobile){
            $isreg = Db::name('phonebind')->where([['phone','=',$mobile],['uid','>',0]])->find();
            if(!$isreg){
                $appdata = array(
                    'uid' => $uid,
                    'phone' => $mobile,
                    'dateline' => time()
                );
                Db::name('phonebind')->insert($appdata);
            }
        }
        if($zmdata['settings']['xcx_isapp'] == 3 && $mobile){
            $isreg = Db::name('appbyme_sendsms')->where([['mobile','=',$mobile],['uid','>',0]])->find();
            if(!$isreg){
                $appdata = array(
                    'uid' => $uid,
                    'code' => 'zhaopin',
                    'mobile' => $mobile,
                    'time' => time()
                );
                Db::name('appbyme_sendsms')->insert($appdata);
            }
        }
    }
    function checktoken_admin($mytoken)
    {
        global $_G;

        $zmdata = $_G['cache']['plugin']['zimu_zhaopin'];

        if ($mytoken) {
            $mytoken2 = explode('uid',$mytoken);
            if($mytoken2[1]=='admin'){
                $access_token1 = substr(md5($zmdata['admin_name']),0,20);
                $access_token2 = substr(md5($zmdata['admin_password']),0,20);
                $access_token3 = substr(md5($zmdata['admin_code']),0,20);
                $access_token4 = 'uidadmin';
                $access_token = $access_token1.$access_token2.$access_token3.$access_token4;
            }else if($mytoken2[1]){
                $isadmin = Db::name('zimu_zhaopin_admin')->where([['id','=',$mytoken2[1]]])->find();
                $access_token1 = substr(md5($isadmin['username']),0,20);
                $access_token2 = substr(md5($isadmin['password']),0,20);
                $access_token3 = substr(md5($isadmin['code']),0,20);
                $access_token4 = 'uid'.$isadmin['id'];
                $access_token = $access_token1.$access_token2.$access_token3.$access_token4;
            }

            if($mytoken == $access_token){


            }else{

                $res['token'] = 'error';
                zimu_json3($res,'',401);
                exit();

            }

        }else {

            $res['token'] = 'error';
            zimu_json3($res,'',401);
            exit();

        }

    }
    function get_admin_uid($token){

        global $_G;

        $zmdata = $_G['cache']['plugin']['zimu_zhaopin'];

            $mytoken2 = explode('uid',$token);
            if($mytoken2[1]=='admin'){
                $access_token1 = substr(md5($zmdata['admin_name']),0,20);
                $access_token2 = substr(md5($zmdata['admin_password']),0,20);
                $access_token3 = substr(md5($zmdata['admin_code']),0,20);
                $access_token4 = 'uidadmin';
                $access_token = $access_token1.$access_token2.$access_token3.$access_token4;
                if($token==$access_token){
                    return 0;
                }
            }else if($mytoken2[1]){
                $isadmin = Db::name('zimu_zhaopin_admin')->where([['id','=',$mytoken2[1]]])->find();
                $access_token1 = substr(md5($isadmin['username']),0,20);
                $access_token2 = substr(md5($isadmin['password']),0,20);
                $access_token3 = substr(md5($isadmin['code']),0,20);
                $access_token4 = 'uid'.$isadmin['id'];
                $access_token = $access_token1.$access_token2.$access_token3.$access_token4;
                if($token==$access_token){
                    return $mytoken2[1];
                }
            }
    }
    function get_admin_name($token){

        global $_G;

        $zmdata = $_G['cache']['plugin']['zimu_zhaopin'];

        $mytoken2 = explode('uid',$token);
        if($mytoken2[1]=='admin'){
            return 'admin';
        }else if($mytoken2[1]){
            $isadmin = Db::name('zimu_zhaopin_admin')->where([['id','=',$mytoken2[1]]])->find();
            if($isadmin){
                return $isadmin['username'];
            }
        }
    }
    function get_kefu_uid($token){

        global $_G;

        $zmdata = $_G['cache']['plugin']['zimu_zhaopin'];

        $mytoken2 = explode('uid',$token);
        if($mytoken2[1]=='admin'){
            return 0;
        }else if($mytoken2[1]){
            $iskefu = Db::name('zimu_zhaopin_kefu')->where([['admin_uid','=',$mytoken2[1]]])->find();
            if($iskefu){
                return $iskefu['uid'];
            }
        }
    }
    function company_push($ids,$audit,$reason){
        global $_G;
        $langfile = DISCUZ_ROOT . './source/plugin/zimu_zhaopin/language.' . currentlang() . '.php';
        $includefile = is_file($langfile) ? $langfile : libfile('language', 'plugin/zimu_zhaopin');
        include $includefile;
        $mycompany = Db::name('zimu_zhaopin_company_profile')->where([['id','=',$ids]])->order(['id'=>'desc'])->find();
        $tip = $language_zimu['new_config_php_21'];
        $templatedata['first']['value'] = $tip;
        $templatedata['first']['color'] = "#FF4040";
        $templatedata['keyword1']['value'] = $mycompany['companyname'].($audit == 1 ? $language_zimu['new_config_php_22'] : $language_zimu['new_config_php_23']);
        $templatedata['keyword2']['value'] = $reason;
        $templatedata['remark']['value'] = $language_zimu['new_config_php_24'];
        $apptpl['magapp']['tag'] = $tip;
        $apptpl['magapp']['title'] = $templatedata['keyword1']['value'];
        $apptpl['magapp']['des'] = $templatedata['remark']['value'];
        $apptpl['qfapp']['msg'] = $apptpl['magapp']['tag'];
        $apptpl['qfapp']['title'] = $apptpl['magapp']['title'];
        $apptpl['qfapp']['content'] = $apptpl['magapp']['des'];
        $tourl = $_G['siteurl'].'source/plugin/zimu_zhaopin/h5/pages/index/my?mobile=2';
        $link = $_G['siteurl'].'plugin.php?id=zimu_zhaopin:new&model=newindex&tourl='.urlencode($tourl);
        notification_all($mycompany['uid'],'wxtpl_admin',$templatedata,$apptpl,$link);

        $find = ['audit','reason'];
        $replace = [$audit == 1 ? $language_zimu['new_config_php_25'] : $language_zimu['new_config_php_26'],zimu_cutstr($reason,40)];
        notification_user_sms($mycompany['telephone'],'chanyoo_sms_tp3',$find,$replace);
    }
    function jobs_push($ids,$audit,$reason){
        global $_G;
        $langfile = DISCUZ_ROOT . './source/plugin/zimu_zhaopin/language.' . currentlang() . '.php';
        $includefile = is_file($langfile) ? $langfile : libfile('language', 'plugin/zimu_zhaopin');
        include $includefile;
        $myjobs = Db::name('zimu_zhaopin_jobs')->where([['id','=',$ids]])->order(['id'=>'desc'])->find();
        $tip = $language_zimu['new_config_php_27'];
        $templatedata['first']['value'] = $tip;
        $templatedata['first']['color'] = "#FF4040";
        $templatedata['keyword1']['value'] = $myjobs['jobs_name'];
        $templatedata['keyword2']['value'] = $audit == 1 ? $language_zimu['new_config_php_28'] : $language_zimu['new_config_php_29'];
        $templatedata['keyword3']['value'] = $reason;
        $templatedata['remark']['value'] = $language_zimu['new_config_php_30'];
        $apptpl['magapp']['tag'] = $tip;
        $apptpl['magapp']['title'] = $templatedata['keyword3']['value'];
        $apptpl['magapp']['des'] = $templatedata['remark']['value'];
        $apptpl['qfapp']['msg'] = $apptpl['magapp']['tag'];
        $apptpl['qfapp']['title'] = $apptpl['magapp']['title'];
        $apptpl['qfapp']['content'] = $apptpl['magapp']['des'];
        $tourl = $_G['siteurl'].'source/plugin/zimu_zhaopin/h5/pages/index/my?mobile=2';
        $link = $_G['siteurl'].'plugin.php?id=zimu_zhaopin:new&model=newindex&tourl='.urlencode($tourl);
        notification_all($myjobs['uid'],'wxtpl_jobs',$templatedata,$apptpl,$link);
    }
    function resume_push($ids,$audit,$reason,$isuid=0){
        global $_G;
        $langfile = DISCUZ_ROOT . './source/plugin/zimu_zhaopin/language.' . currentlang() . '.php';
        $includefile = is_file($langfile) ? $langfile : libfile('language', 'plugin/zimu_zhaopin');
        include $includefile;
        if($isuid==1){
            $myresume = Db::name('zimu_zhaopin_resume')->where([['uid','=',$ids]])->order(['id'=>'desc'])->find();
        }else{
            $myresume = Db::name('zimu_zhaopin_resume')->where([['id','=',$ids]])->order(['id'=>'desc'])->find();
        }
        $tip = $language_zimu['new_config_php_31'];
        $templatedata['first']['value'] = $tip;
        $templatedata['first']['color'] = "#FF4040";
        $templatedata['keyword1']['value'] = $myresume['fullname'];
        $templatedata['keyword2']['value'] = date('Y-m-d H:i',time());
        $templatedata['keyword3']['value'] = $audit == 1 ? $language_zimu['new_config_php_32'] : $language_zimu['new_config_php_33'];
        $templatedata['keyword4']['value'] = $reason;
        $templatedata['remark']['value'] = $language_zimu['new_config_php_34'];
        $apptpl['magapp']['tag'] = $tip;
        $apptpl['magapp']['title'] = $templatedata['keyword3']['value'];
        $apptpl['magapp']['des'] = $templatedata['remark']['value'];
        $apptpl['qfapp']['msg'] = $apptpl['magapp']['tag'];
        $apptpl['qfapp']['title'] = $apptpl['magapp']['title'];
        $apptpl['qfapp']['content'] = $apptpl['magapp']['des'];
        $tourl = $_G['siteurl'].'source/plugin/zimu_zhaopin/h5/pages/index/my?mobile=2';
        $link = $_G['siteurl'].'plugin.php?id=zimu_zhaopin:new&model=newindex&tourl='.urlencode($tourl);
        notification_all($myresume['uid'],'wxtpl_resume',$templatedata,$apptpl,$link);

        $find = ['audit','reason'];
        $replace = [$audit == 1 ? $language_zimu['new_config_php_35'] : $language_zimu['new_config_php_36'],zimu_cutstr($reason,20)];
        notification_user_sms($myresume['telephone'],'chanyoo_sms_tp4',$find,$replace);
    }
    function company_imchat_push($ids,$message){
        global $_G;
        $langfile = DISCUZ_ROOT . './source/plugin/zimu_zhaopin/language.' . currentlang() . '.php';
        $includefile = is_file($langfile) ? $langfile : libfile('language', 'plugin/zimu_zhaopin');
        include $includefile;
        $mycompany = Db::name('zimu_zhaopin_company_profile')->where([['uid','=',$ids]])->order(['id'=>'desc'])->find();
        $tip = $language_zimu['new_config_php_37'];
        $templatedata['first']['value'] = $tip;
        $templatedata['first']['color'] = "#FF4040";
        $templatedata['keyword1']['value'] = zimu_cutstr($message,40);
        $templatedata['keyword2']['value'] = date('Y-m-d H:i',time());
        $templatedata['remark']['value'] = $language_zimu['new_config_php_38'];
        $apptpl['magapp']['tag'] = $tip;
        $apptpl['magapp']['title'] = $templatedata['keyword1']['value'];
        $apptpl['magapp']['des'] = $templatedata['remark']['value'];
        $apptpl['qfapp']['msg'] = $apptpl['magapp']['tag'];
        $apptpl['qfapp']['title'] = $apptpl['magapp']['title'];
        $apptpl['qfapp']['content'] = $apptpl['magapp']['des'];
        $tourl = $_G['siteurl'].'source/plugin/zimu_zhaopin/h5/pages/index/my?mobile=2';
        $link = $_G['siteurl'].'plugin.php?id=zimu_zhaopin:new&model=newindex&tourl='.urlencode($tourl);
        notification_all($mycompany['uid'],'wxtpl_imchat',$templatedata,$apptpl,$link);

        $find = ['audit','reason'];
        $replace = ['audit','reason'];
        notification_user_sms($mycompany['telephone'],'chanyoo_sms_tp5',$find,$replace);
    }
    function resume_imchat_push($ids,$message){
        global $_G;
        $langfile = DISCUZ_ROOT . './source/plugin/zimu_zhaopin/language.' . currentlang() . '.php';
        $includefile = is_file($langfile) ? $langfile : libfile('language', 'plugin/zimu_zhaopin');
        include $includefile;
        $myresume = Db::name('zimu_zhaopin_resume')->where([['uid','=',$ids]])->order(['id'=>'desc'])->find();
        $tip = $language_zimu['new_config_php_39'];
        $templatedata['first']['value'] = $tip;
        $templatedata['first']['color'] = "#FF4040";
        $templatedata['keyword1']['value'] = zimu_cutstr($message,40);
        $templatedata['keyword2']['value'] = date('Y-m-d H:i',time());
        $templatedata['remark']['value'] = $language_zimu['new_config_php_40'];
        $apptpl['magapp']['tag'] = $tip;
        $apptpl['magapp']['title'] = $templatedata['keyword1']['value'];
        $apptpl['magapp']['des'] = $templatedata['remark']['value'];
        $apptpl['qfapp']['msg'] = $apptpl['magapp']['tag'];
        $apptpl['qfapp']['title'] = $apptpl['magapp']['title'];
        $apptpl['qfapp']['content'] = $apptpl['magapp']['des'];
        $tourl = $_G['siteurl'].'source/plugin/zimu_zhaopin/h5/pages/index/my?mobile=2';
        $link = $_G['siteurl'].'plugin.php?id=zimu_zhaopin:new&model=newindex&tourl='.urlencode($tourl);
        notification_all($myresume['uid'],'wxtpl_imchat',$templatedata,$apptpl,$link);

        $find = ['audit','reason'];
        $replace = ['audit','reason'];
        notification_user_sms($myresume['telephone'],'chanyoo_sms_tp5',$find,$replace);
    }
    function filterComment($content,$string){
        $arr = explode('|',$string);
        foreach($arr as $v){
            $array[] = trim($v);
        }
        return str_replace($array,'',$content);
    }
    function get_im_token($uid){
        $isadd = Db::name('zimu_zhaopin_im_token')->where([['uid','=',$uid]])->find();
        if(!$isadd){
            $isadd['uid'] = $uid;
            $isadd['im_userid'] = authcode($uid);
            $isadd['token'] = $_SERVER['PHP_SELF'];
            //Db::name('zimu_zhaopin_im_token')->insert($isadd);
        }
        return $isadd;
    }
    function get_im_message($myuid,$touid){
        Db::name('zimu_zhaopin_im_message')->where([['utype','=',($myuid['utype']==1 ? 2 : 1)],['touid','=',$myuid['uid']],['uid','=',$touid]])->data(['isread' => 1])->update();
        $whereraw2 = '1=1';
        $whereraw[] = '( utype = '.$myuid['utype'].' and uid = '.$myuid['uid'].' and touid = '.$touid.' )';
        $whereraw[] = '( utype = '.($myuid['utype']==1 ? 2 : 1).' and touid = '.$myuid['uid'].' and uid = '.$touid.' )';
        $whereraw2 = implode('or',$whereraw);
        $lists = Db::name('zimu_zhaopin_im_message')->whereRaw($whereraw2)->order(['id'=>'asc'])->select()->toArray();
        return $lists;
    }
    function get_im_list($myuid){

        $langfile = DISCUZ_ROOT . './source/plugin/zimu_zhaopin/language.' . currentlang() . '.php';
        $includefile = is_file($langfile) ? $langfile : libfile('language', 'plugin/zimu_zhaopin');
        include $includefile;

        $whereraw[] = '( utype = '.$myuid['utype'].' and uid = '.$myuid['uid'].' )';
        $whereraw[] = '( utype = '.($myuid['utype']==1 ? 2 : 1).' and touid = '.$myuid['uid'].' )';
        $whereraw2 = implode('or',$whereraw);

        $res2 = Db::name('zimu_zhaopin_im_message')->whereRaw($whereraw2)->group('uid,touid')->order(['id'=>'desc'])->select()->toArray();

        foreach ($res2 as $key => $value) {
            $newkey = $value['touid']+$value['uid'];
            $touid = $value['uid'] == $myuid['uid'] ? $value['touid'] : $value['uid'];
            $whereraw3 = [];
            $whereraw3[] = '( utype = '.$myuid['utype'].' and uid = '.$myuid['uid'].' and touid = '.$touid.' )';
            $whereraw3[] = '( utype = '.($myuid['utype']==1 ? 2 : 1).' and touid = '.$myuid['uid'].' and uid = '.$touid.' )';
            $whereraw4 = implode('or',$whereraw3);
            $res[$newkey]['counts'] = Db::name('zimu_zhaopin_im_message')->whereRaw('( utype = '.($myuid['utype']==1 ? 2 : 1).' and touid = '.$myuid['uid'].' and uid = '.$touid.' )')->where([['isread','=',0]])->count();
            $lastmessage = Db::name('zimu_zhaopin_im_message')->whereRaw($whereraw4)->order(['id'=>'desc'])->findOrEmpty();
            $res[$newkey]['message'] = $lastmessage['message'];
            $res[$newkey]['addtime'] = $lastmessage['addtime'];

            if($myuid['utype']==2){
                $res[$newkey]['touidinfo'] = Db::name('zimu_zhaopin_company_profile')->where([['uid','=',$touid]])->order(['id'=>'desc'])->find();
                $res[$newkey]['touidinfo']['avatar'] = $res[$newkey]['touidinfo']['logo'];
                $res[$newkey]['touidinfo']['name'] = $res[$newkey]['touidinfo']['companyname'];
            }
            if($myuid['utype']==1){
                $res[$newkey]['touidinfo'] = Db::name('zimu_zhaopin_resume')->where([['uid','=',$touid]])->order(['id'=>'desc'])->find();
                if($res[$newkey]['touidinfo']['sex']==1){
                    $res[$newkey]['touidinfo']['fullname'] = cutstr($res[$newkey]['touidinfo']['fullname'],2,'').$language_zimu['new_config_php_41'];
                }else{
                    $res[$newkey]['touidinfo']['fullname'] = cutstr($res[$newkey]['touidinfo']['fullname'],2,'').$language_zimu['new_config_php_42'];
                }
                $res[$newkey]['touidinfo']['avatar'] = $res[$newkey]['touidinfo']['photo_img'];
                $res[$newkey]['touidinfo']['name'] = $res[$newkey]['touidinfo']['fullname'];
            }
            $res[$newkey]['touid'] = $touid;
        }
        $hot_cat = array_sort($res,'addtime','desc');
        return $hot_cat;
    }
    function array_sort($array,$keys,$type='asc'){
        $keysvalue = $new_array = array();
        foreach ($array as $k=>$v){
            $keysvalue[$k] = $v[$keys];
        }
        if($type == 'asc'){
            asort($keysvalue);
        }else{
            arsort($keysvalue);
        }
        reset($keysvalue);
        $new_keysvalue = array_keys($keysvalue);
        foreach ($new_keysvalue as $k=>$v){
            $new_array[$k] = $array[$v];
        }
        return $new_array;
    }
    function get_im_noread_counts($myuid){
        $im_counts = Db::name('zimu_zhaopin_im_message')->where([['utype','=',($myuid['utype']==1 ? 2 : 1)],['touid','=',$myuid['uid']],['isread','=',0]])->count();
        return $im_counts;
    }
    function get_im_nosend($res,$myuid,$touid,$zmdata){
        $langfile = DISCUZ_ROOT . './source/plugin/zimu_zhaopin/language.' . currentlang() . '.php';
        $includefile = is_file($langfile) ? $langfile : libfile('language', 'plugin/zimu_zhaopin');
        include $includefile;
        $parameter = Db::name('zimu_zhaopin_parameter2')->where('name', 'imchat')->order('id','desc')->find();
        $parameter = unserialize($parameter['parameter']);
        $mysetmeal = Db::name('zimu_zhaopin_members_setmeal')->where([['uid','=',$myuid['uid']]])->find();
        $istochat = Db::name('zimu_zhaopin_im_message')->where([['uid','=',$touid],['touid','=',$myuid['uid']],['addtime','>',time() - 86400*$parameter['system_im_user_to_company_days']]])->find();
        if(!$parameter['system_im_common_c_to_u_switch'] && !$istochat && $mysetmeal['setmeal_id']==1){
            $res['zmdata']['show_nosend'] = 1;
            $res['zmdata']['nosend_type'] = 'no_allow_send';
            $res['zmdata']['nosend_tip'] = $language_zimu['new_config_php_43'].'VIP'.$language_zimu['new_config_php_44'];
            $res['zmdata']['nosend_btn_text'] = $language_zimu['new_config_php_45'];
            return $res;
        }
        $is_pay = Db::name('zimu_zhaopin_order')->where([['service_name','=','pay_chat'],['is_paid','=',2],['uid','=',$myuid['uid']],['zpid','=',$touid]])->order(['id'=>'desc'])->find();
        if($is_pay){
            return $res;
        }
        $lastmessage = Db::name('zimu_zhaopin_im_message')->where([['utype','=',2],['uid','=',$touid],['touid','=',$myuid['uid']]])->order(['id'=>'desc'])->find();
        if(time() > $lastmessage['addtime'] + 86400*$parameter['system_im_user_to_company_days']){
            $isapply = Db::name('zimu_zhaopin_personal_jobs_apply')->where([['company_uid','=',$myuid['uid']],['personal_uid','=',$touid]])->order(['did'=>'desc'])->find();
            $is_apply_free = $mysetmeal['setmeal_id'] > 1 ? $parameter['system_im_vip_resume_enable'] : $parameter['system_im_common_resume_enable'];
            $is_apply_days = $mysetmeal['setmeal_id'] > 1 ? $parameter['system_im_vip_resume_free'] : $parameter['system_im_common_resume_free'];
            if(time() > $isapply['apply_addtime'] + 86400*$is_apply_days || !$is_apply_free){
                $setmeal_reply_limit = $mysetmeal['setmeal_id'] > 1 ? $parameter['system_im_vip_reply_limit'] : $parameter['system_im_common_reply_limit'];
                $setmeal_reply_money = $mysetmeal['setmeal_id'] > 1 ? $parameter['system_im_vip_c_to_u_money'] : $parameter['system_im_common_c_to_u_money'];
                $todaytime = strtotime(date('Y-m-d', time()));
                $today_free_chat = Db::name('zimu_zhaopin_order')->where([['service_name','=','pay_chat'],['is_paid','=',2],['uid','=',$myuid['uid']],['amount','=',0],['addtime','>',$todaytime]])->order(['id'=>'desc'])->count();
                $today_chat = Db::name('zimu_zhaopin_im_message')->where([['utype','=',1],['uid','=',$myuid['uid']],['message','<>',''],['addtime','>',$todaytime]])->group('uid')->column('touid');
                $today_chat_pay = Db::name('zimu_zhaopin_order')->where([['service_name','=','pay_chat'],['is_paid','=',2],['uid','in',$today_chat],['amount','>',0]])->order(['id'=>'desc'])->count();
                $today_free_chat = $today_free_chat + count($today_chat)-$today_chat_pay;
                if($today_free_chat >= $setmeal_reply_limit){
                    $res['zmdata']['show_nosend'] = 1;
                    $res['zmdata']['nosend_type'] = 'to_pay_chat';
                    $res['zmdata']['nosend_tip'] = $language_zimu['new_config_php_46'].$setmeal_reply_money.$language_zimu['new_config_php_47'].$zmdata['settings']['jifen_name'].$language_zimu['new_config_php_48'].($setmeal_reply_money/$zmdata['settings']['jifen_bili']).$language_zimu['new_config_php_49'];
                    $res['zmdata']['nosend_money'] = $setmeal_reply_money;
                    $res['zmdata']['nosend_btn_text'] = $language_zimu['new_config_php_50'];
                    return $res;
                }
            }
        }else{
            $setmeal_reply_limit = $mysetmeal['setmeal_id'] > 1 ? $parameter['system_im_vip_reply_limit'] : $parameter['system_im_common_reply_limit'];
            $setmeal_reply_money = $mysetmeal['setmeal_id'] > 1 ? $parameter['system_im_vip_c_to_u_money'] : $parameter['system_im_common_c_to_u_money'];
            $todaytime = strtotime(date('Y-m-d', time()));
            $today_free_chat = Db::name('zimu_zhaopin_order')->where([['service_name','=','pay_chat'],['is_paid','=',2],['uid','=',$myuid['uid']],['amount','=',0],['addtime','>',$todaytime]])->order(['id'=>'desc'])->count();
            $today_chat = Db::name('zimu_zhaopin_im_message')->where([['utype','=',1],['uid','=',$myuid['uid']],['message','<>',''],['addtime','>',$todaytime]])->group('uid')->column('touid');
            $today_chat_pay = Db::name('zimu_zhaopin_order')->where([['service_name','=','pay_chat'],['is_paid','=',2],['uid','in',$today_chat],['amount','>',0]])->order(['id'=>'desc'])->count();
            $today_free_chat = $today_free_chat + count($today_chat)-$today_chat_pay;
            if($today_free_chat >= $setmeal_reply_limit){
                $res['zmdata']['show_nosend'] = 1;
                $res['zmdata']['nosend_type'] = 'to_pay_chat';
                $res['zmdata']['nosend_tip'] = $language_zimu['new_config_php_51'].$setmeal_reply_money.$language_zimu['new_config_php_52'].$zmdata['settings']['jifen_name'].$language_zimu['new_config_php_53'].($setmeal_reply_money/$zmdata['settings']['jifen_bili']).$language_zimu['new_config_php_54'];
                $res['zmdata']['nosend_money'] = $setmeal_reply_money;
                $res['zmdata']['nosend_btn_text'] = $language_zimu['new_config_php_55'];
                return $res;
            }
        }
        $is_add = Db::name('zimu_zhaopin_order')->where([['service_name','=','pay_chat'],['is_paid','=',2],['uid','=',$myuid['uid']],['zpid','=',$touid]])->order(['id'=>'desc'])->find();
        if(!$is_add){
            $params['oid']        = date('YmdHis') . mt_rand(100000, 999999);
            $params['zpid']       = $touid;
            $params['uid']        = $myuid['uid'];
            $params['openid']     = $myuid['openid'];
            $params['utype']      = 1;
            $params['order_type'] = 8;
            $params['pay_type']   = 2;
            $params['is_paid']    = 2;
            $params['amount']     = 0;
            $params['pay_amount'] = 0;
            $params['payment']    = 'wxpay';
            $params['payment_cn'] = $language_zimu['new_config_php_56'];
            $params['description']  = $language_zimu['new_config_php_57'];
            $params['service_name'] = 'pay_chat';
            $params['addtime']       = time();
            $return_order_info['order_id'] = Db::name('zimu_zhaopin_order')->insertGetId($params);
        }
        return $res;
    }
    function company_uid_touid($uid,$touid){
        Db::name('zimu_zhaopin_company_down_resume')->where('company_uid', $uid)->data(['company_uid' => $touid])->update();
        Db::name('zimu_zhaopin_company_favorites')->where('company_uid', $uid)->data(['company_uid' => $touid])->update();
        Db::name('zimu_zhaopin_company_interview')->where('company_uid', $uid)->data(['company_uid' => $touid])->update();
        Db::name('zimu_zhaopin_crm_company')->where('com_uid', $uid)->data(['com_uid' => $touid])->update();
        Db::name('zimu_zhaopin_crm_custom_feedback')->where([['custom_id','=',$uid],['custom_type','=',1]])->data(['custom_id' => $touid])->update();
        Db::name('zimu_zhaopin_crm_custom_log')->where([['custom_id','=',$uid],['custom_type','=',1]])->data(['custom_id' => $touid])->update();
        Db::name('zimu_zhaopin_jobs')->where([['uid','=',$uid]])->data(['uid' => $touid])->update();
        Db::name('zimu_zhaopin_members')->where([['uid','=',$uid]])->delete();
        Db::name('zimu_zhaopin_members')->where([['uid','=',$touid]])->delete();
        Db::name('zimu_zhaopin_members_setmeal')->where([['uid','=',$uid]])->data(['uid' => $touid])->update();
        Db::name('zimu_zhaopin_members_setmeal2')->where([['uid','=',$uid]])->data(['uid' => $touid])->update();
        Db::name('zimu_zhaopin_order')->where([['uid','=',$uid]])->data(['uid' => $touid])->update();
        Db::name('zimu_zhaopin_personal_favorites')->where([['company_uid','=',$uid]])->data(['company_uid' => $touid])->update();
        Db::name('zimu_zhaopin_personal_jobs_apply')->where([['company_uid','=',$uid]])->data(['company_uid' => $touid])->update();
        Db::name('zimu_zhaopin_com_viewlog')->where([['uid','=',$uid]])->data(['uid' => $touid])->update();
    }