<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if (!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }

    use think\Db;

    $token = addslashes($_GET['token']);
    $myuid = checktoken($token,0);
    $op = addslashes($_GET['op']);
    $zimu_get = zimu_array_gbk($_GET);
    $page = intval($_GET['page']);


    if($op == 'gethongniang') {


    }else{

        $indexad = Db::name('zimu_zhaopin_parameter2')->where('name','jobsad')->find();
        $res['indexad'] = unserialize($indexad['parameter']);

        $districtlist = Db::name('zimu_zhaopin_area')->where([['parentid','=',0]])->order(['sort'=>'asc','id'=>'asc'])->select()->toArray();

        foreach ($districtlist as $key => $value) {
            $districtlist[$key]['list'] = Db::name('zimu_zhaopin_area')->where([['parentid','=',$value['id']]])->order(['sort'=>'asc','id'=>'asc'])->select()->toArray();
            if($zmdata['settings']['area_three']==1){
                foreach ($districtlist[$key]['list'] as $key2 => $value2) {
                    $districtlist[$key]['list'][$key2]['area_three'] = $zmdata['settings']['area_three'];
                    $districtlist[$key]['list'][$key2]['list'] = Db::name('zimu_zhaopin_area')->where([['parentid','=',$value2['id']]])->order(['sort'=>'asc','id'=>'asc'])->select()->toArray();
                }
            }
        }
        $res['districtlist'] = $districtlist;

        $jobcatlist = Db::name('zimu_zhaopin_category_jobs')->where([['parentid','=',0]])->order(['category_order'=>'asc','id'=>'asc'])->select()->toArray();

        foreach ($jobcatlist as $key => $value) {
            $jobcatlist[$key]['list'] = Db::name('zimu_zhaopin_category_jobs')->where([['parentid','=',$value['id']]])->order(['category_order'=>'asc','id'=>'asc'])->select()->toArray();
        }
        $res['jobcatlist'] = $jobcatlist;

        $res['wagelist'] = Db::name('zimu_zhaopin_category')->where([['c_alias','=','ZM_wage']])->order(['c_order'=>'asc','c_id'=>'asc'])->select()->toArray();

        $res['morelist']['explist'] = Db::name('zimu_zhaopin_category')->where([['c_alias','=','ZM_experience']])->order(['c_order'=>'asc','c_id'=>'asc'])->select()->toArray();

        $res['morelist']['naturelist'] = Db::name('zimu_zhaopin_category')->where([['c_alias','=','ZM_jobs_nature']])->order(['c_order'=>'asc','c_id'=>'asc'])->select()->toArray();

        $res['morelist']['edulist'] = Db::name('zimu_zhaopin_category')->where([['c_alias','=','ZM_education']])->order(['c_order'=>'asc','c_id'=>'asc'])->select()->toArray();

        $selecttxt = json_decode(zimu_array_utf8($_GET['selecttxt']),true);
        $selecttxt = zimu_array_gbk($selecttxt);

        $wheresql2[] = ['display','=',1];
        $wheresql2[] = ['audit','<>',3];
        $wheresql2[] = ['company_audit','<>',3];
        $whereraw = '1=1';
        if($selecttxt['wage']){
            $wagewage = Db::name('zimu_zhaopin_category')->where([['c_alias','=','ZM_wage'],['c_id','=',$selecttxt['wage']]])->find();
            $wagearray = explode('~',$wagewage['c_name']);
            if($wagewage['c_name'] != $language_zimu['new_jobs_inc_php_0']){
                $minwage = intval($wagearray[0]);
                $maxwage = intval($wagearray[1]) > 0 ? intval($wagearray[1]) : 999999;
                if($minwage && $maxwage){
                    $whereraw = '( wage = '.$selecttxt['wage'].' ) or ( maxwage >= '.$minwage.' and minwage <= '.$maxwage.' )';
                }
            }else{
                $wheresql2[] = ['wage','=',$selecttxt['wage']];
            }
        }

        if($selecttxt['exp']){
            $wheresql2[] = ['experience','>=',$selecttxt['exp']];
        }
        if($selecttxt['edu']){
            $wheresql2[] = ['education','>=',$selecttxt['edu']];
        }
        if($selecttxt['nature']){
            $wheresql2[] = ['nature','=',$selecttxt['nature']];
        }
        if($selecttxt['jobcate2']){
            $wheresql2[] = ['category','=',$selecttxt['jobcate2']];
        }elseif ($selecttxt['jobcate1']){
            $wheresql2[] = ['topclass','=',$selecttxt['jobcate1']];
        }

        if($zmdata['settings']['area_three']==1){
            if($selecttxt['city3']){
                $wheresql2[] = ['district3','=',$selecttxt['city3']];
            }elseif ($selecttxt['city2']){
                $wheresql2[] = ['district2','=',$selecttxt['city2']];
            }elseif ($selecttxt['city1']){
                $wheresql2[] = ['district','=',$selecttxt['city1']];
            }
        }else{
            if($selecttxt['city2']){
                $wheresql2[] = ['district2','=',$selecttxt['city2']];
            }elseif ($selecttxt['city1']){
                $wheresql2[] = ['district','=',$selecttxt['city1']];
            }
        }

        if($zmdata['settings']['show_noaudit']){
            $wheresql2[] = ['audit','=',1];
        }

        if($selecttxt['sotxt']){
            $whereraw = $whereraw . ' and ( jobs_name like \'%'.$selecttxt['sotxt'].'%\' or companyname like \'%'.$selecttxt['sotxt'].'%\' or category_cn like \'%'.$selecttxt['sotxt'].'%\' or contents like \'%'.$selecttxt['sotxt'].'%\' ) ';
            //$wheresql2[] = 'jobs_name|companyname','like','%'.$selecttxt['sotxt'].'%'];
        }

        if(file_exists(DISCUZ_ROOT . './source/plugin/zimu_zhaopin/module/a_change_area.inc.php') && $zmdata['settings']['change_city'] == 1 && !$selecttxt['city1'] && !$selecttxt['city2']){
            if($tocityid2){
                $wheresql_tocity[] = ['district2','=',$tocityid2];
            }elseif($tocityid){
                $wheresql_tocity[] = ['district','=',$tocityid];
            }
        }

        if($page==1){
            $topjobs = Db::name('zimu_zhaopin_jobs')->where($wheresql_tocity)->where([['stick_endtime','>',time()]])->where([$wheresql2])->whereRaw($whereraw)->order(['refreshtime'=>'desc','stick_endtime'=>'desc','id'=>'desc'])->select()->toArray();
            $res['topjobs'] = format_jobs($topjobs,$zmdata);
        }

        $newjobs = Db::name('zimu_zhaopin_jobs')->where($wheresql_tocity)->where([['stick_endtime','<',time()]])->where($wheresql2)->whereRaw($whereraw)->order(['refreshtime'=>'desc','id'=>'desc'])->page($page,10)->select()->toArray();
        $res['newjobs'] = format_jobs($newjobs,$zmdata);
        if($zmdata['settings']['toutiao_audit']!=1){
            $res['newjobs'] = zimu_ad_system($res['newjobs'],'zhaopin2',0);
        }

        $res['wapfooter'] = $zmdata['settings']['wapfooterhtml'];
        $paramter = Db::name('zimu_zhaopin_parameter2')->where([['name','=','wappopup']])->order(['id'=>'asc'])->find();
        $res['wappopup'] = unserialize($paramter['parameter']);

        if($zmdata['settings']['no_user_num'] != 0){

        }
        zimu_json($res);

    }
