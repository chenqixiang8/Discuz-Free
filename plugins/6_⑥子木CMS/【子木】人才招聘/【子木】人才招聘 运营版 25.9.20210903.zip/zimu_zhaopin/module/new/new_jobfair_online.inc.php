<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if (!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }

    use think\Db;

    $token = addslashes($_GET['token']);
    $myuid = checktoken($token,0);
    $op = addslashes($_GET['op']);
    $zimu_get = zimu_array_gbk($_GET);
    $page = intval($_GET['page']);

    if($op == 'zimuyun') {

    }elseif($op == 'list' ){

        $jobfair = Db::name('zimu_zhaopin_jobfair_online')->order(['id'=>'desc'])->select()->toArray();
        foreach ($jobfair as $key => $value) {

            $companys = Db::name('zimu_zhaopin_jobfair_online_com')->where([['fid','=',$value['id']],['status','=',1]])->column('uid');
            $jobfair[$key]['allcoms'] = count($companys);
            $jobs = Db::name('zimu_zhaopin_jobs')->where([['uid','in',$companys]])->column('id');
            $jobfair[$key]['alljobs'] = count($jobs);

        }

        $res['jobfair'] = $jobfair;
        $res['wapfooter'] = $zmdata['settings']['wapfooterhtml'];
        zimu_json($res);

    }elseif($op == 'view' ){

        $ids = intval($_GET['ids']);
        $jobfair = Db::name('zimu_zhaopin_jobfair_online')->where([['id','=',$ids]])->order(['id'=>'desc'])->find();
        if (!$jobfair['bgcolor']) {
            $jobfair['bgcolor'] = '#0486fe';
        }
        $jobfair['catcn2'] = explode(',',$jobfair['catcn']);
        if($myuid['uid']){
            $jobfair['hasapply'] = Db::name('zimu_zhaopin_jobfair_online_com')->where([['fid','=',$ids],['uid','=',$myuid['uid']]])->order(['id'=>'desc'])->find();
            $jobfair['hasresume'] = Db::name('zimu_zhaopin_resume')->where([['uid','=',$myuid['uid']]])->order(['id'=>'desc'])->find();
        }
        $res['jobfair'] = $jobfair;

        $companys = Db::name('zimu_zhaopin_jobfair_online_com')->where([['fid','=',$ids],['status','=',1]])->order(['zhiding'=>'desc','sort'=>'desc','addtime'=>'asc'])->select()->toArray();
        $res['jobfair']['allcoms'] = count($companys);
        $res['jobfair']['alljobs'] = 0;

        foreach ($companys as $key => $value) {

            $companys[$key]['profile'] = Db::name('zimu_zhaopin_company_profile')->where([['id','=',$value['com_id']]])->order(['id'=>'desc'])->find();

            $companys[$key]['jobs'] = Db::name('zimu_zhaopin_jobs')->where([['company_id','=',$value['com_id']],['audit','<>',3],['display','<>',2]])->order(['id'=>'desc'])->select()->toArray();
            $companys[$key]['profile']['jobs'] = count($companys[$key]['jobs']);

            $res['jobfair']['alljobs'] = $res['jobfair']['alljobs'] + count($companys[$key]['jobs']);

        }
        $res['companys'] = $companys;

        $res['wapfooter'] = $zmdata['settings']['wapfooterhtml'];
        Db::name('zimu_zhaopin_jobfair_online')->where('id', $ids)->inc('views', 1)->update();
        zimu_json($res);

    }elseif($op == 'apply' ){

        $ids = intval($_GET['ids']);
        $hasapply = Db::name('zimu_zhaopin_jobfair_online_com')->where([['fid','=',$ids],['uid','=',$myuid['uid']]])->order(['id'=>'desc'])->find();
        if($hasapply){
            $res['tip'] = $language_zimu['new_jobfair_online_inc_php_0'];
            zimu_json($res);
        }
        $hascom = Db::name('zimu_zhaopin_company_profile')->where([['uid','=',$myuid['uid']]])->order(['id'=>'desc'])->find();
        if(!$hascom){
            $res['tip'] = $language_zimu['new_jobfair_online_inc_php_1'];
            zimu_json($res);
        }

        $apply_data['fid']      = $ids;
        $apply_data['uid']      = $myuid['uid'];
        $apply_data['com_id']   = $hascom['id'];
        $apply_data['com_name'] = $hascom['companyname'];
        $apply_data['note']     = '';
        $apply_data['addtime']  = time();
        Db::name('zimu_zhaopin_jobfair_online_com')->insert($apply_data);
        zimu_json($res);


    }else{




    }