<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$ac = addslashes($_GET['ac']);
$isurl = intval($_GET['isurl']);
$imgurl = addslashes($_GET['imgurl']);

if ($ac == 'resume_img') {

if($isurl==1){

$config_params['save_path'] = $imgurl;

}else{

    $config_params = savepic('resume_img');
    $data          = array(
        'path' => $config_params['show_path'],
        'img' => $config_params['save_path']
    );

}

    $rid = intval($_GET['rid']);

if($rid){
    DB::query("update %t set photo_img=%s,photo=1 where uid=%d and id=%d", array(
        'zimu_zhaopin_resume',
        $config_params['save_path'],
        $_G['uid'],
        $rid
    ));
}

    ajaxReturn(1, $language_zimu['upload_inc_php_0'], $data);
    
    
} elseif ($ac == 'avatar') {
    
    $tosubmit = intval($_GET['tosubmit']);
    
    if ($tosubmit == 1) {
        
        $pid = intval($_GET['pid']);
        
        $config_params = savepic('avatar');
        
        $data = array(
            'path' => $config_params['show_path'],
            'img' => $config_params['save_path']
        );
        
        
        $data2['photo']     = 1;
        $data2['photo_img'] = $config_params['save_path'];
        
        DB::update('zimu_zhaopin_resume', $data2, array(
            'id' => $pid,
            'uid' => $_G['uid']
        ));
        
        ajaxReturn(1, $language_zimu['upload_inc_php_1'], $data);
        
    }
    
} elseif ($ac == 'company_logo') {

    $company_id = $_GET['company_id'];

    if($isurl==1){

    $config_params['save_path'] = $imgurl;

    }else{

    $config_params = savepic('company_logo');
    
    $data = array(
        'path' => $config_params['show_path'],
        'img' => $config_params['save_path']
    );

    }

    DB::query("update %t set logo=%s where uid=%d and id=%d", array(
        'zimu_zhaopin_company_profile',
        $config_params['save_path'],
        $_G['uid'],
        $company_id
    ));


    ajaxReturn(1, $language_zimu['upload_inc_php_2'], $data);

} elseif ($ac == 'certificate_img') {

    $company_id = $_GET['company_id'];

    if($isurl==1){

    $config_params['save_path'] = $imgurl;

    }else{

    $config_params = savepic('certificate_img');
    
    $data = array(
        'path' => $config_params['show_path'],
        'img' => $config_params['save_path']
    );

    }
    
    DB::query("update %t set certificate_img=%s where uid=%d and id=%d", array(
        'zimu_zhaopin_company_profile',
        $config_params['save_path'],
        $_G['uid'],
        $company_id
    ));


    ajaxReturn(1, $language_zimu['upload_inc_php_3'], $data);
        
}


function savepic($type){
    global $_G;

    $config_params = array(
        'upload_ok' => false,
        'save_path' => '',
        'show_path' => ''
    );
    $filename      = uniqid() . '.jpg';
    $uid           = $_G['uid'];
    $pic           = base64_decode($_GET['base64_string']);

    $sids = $_GET['serverId'];

if(!$pic && !$sids){

    $picurl = zm_saveimages($_FILES[$type]);

    $config_params['save_path'] = $picurl;
    $config_params['show_path'] = $picurl;
    ;
    $config_params['upload_ok'] = true;
    return $config_params;

}


    $date        = date('ym/d/');
    $save_avatar = DISCUZ_ROOT . './source/plugin/zimu_zhaopin/uploadzimucms/' . $type . '/' . $date;

    if (!is_dir($save_avatar)) {
        mkdir($save_avatar, 0777, true);
    }

    if($sids){

    require_once DISCUZ_ROOT . './source/plugin/zimu_zhaopin/class/wechat.lib.class.php';
    $wechat_client = new WeChatClient(SF_APPID, SF_APPSECRET);
    $temp = $wechat_client->download($sids);
    if(!empty($temp)) {
            $content = '';
            if (preg_match('/^(http|\.)/i', $temp)) {
                $content = zm_curl($temp);
            }else{
                $content = $temp;
            }
                $fp = fopen($save_avatar . $filename, 'wb');
                flock($fp, 2);
                fwrite($fp, $content);
                fclose($fp);
    }


    }else{

    file_put_contents($save_avatar . $filename, $pic);

    }

    $oss_paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
        'zimu_zhaopin_parameter2',
        'alioss'
    ));
    $oss_paramter = unserialize($oss_paramter['parameter']);

    if(!$oss_paramter['oss_type'] && $oss_paramter['ACCESS_ID'] && $oss_paramter['ACCESS_KEY'] && $oss_paramter['ENDPOINT'] && $oss_paramter['BUCKET']){
        $saved_file = DISCUZ_ROOT.'/source/plugin/zimu_zhaopin/uploadzimucms/' . $type . '/' . $date . $filename;
        include_once DISCUZ_ROOT.'source/plugin/zimu_zhaopin/lib/OSS/Common.php';
        if ($surl = zm_oss_upload('zimu_zhaopin/'. $type . '/' . $date . $filename, $saved_file)) {
            @unlink($saved_file);
        $imgurl = $surl;
        $config_params['save_path'] = $imgurl;
        $config_params['show_path'] = $imgurl;
        $config_params['upload_ok'] = true;
        return $config_params;
        exit();
        }
    }elseif ($oss_paramter['oss_type']==1 && $oss_paramter['qn_ak'] && $oss_paramter['qn_sk'] && $oss_paramter['qn_bk']){

        $saved_file = DISCUZ_ROOT.'/source/plugin/zimu_zhaopin/uploadzimucms/' . $type . '/' . $date . $filename;
        include_once(DISCUZ_ROOT.'source/plugin/zimu_zhaopin/lib/Qiniu/upload.php');
        if ($surl=zm_qn_upload('zimu_zhaopin/'. $type . '/' . $date . $filename, $saved_file)) {
            unlink($saved_file);
            error_reporting(0);
            $imgurl = $surl;
            $config_params['save_path'] = $imgurl;
            $config_params['show_path'] = $imgurl;
            $config_params['upload_ok'] = true;
            return $config_params;
        }

    }

    $config_params['save_path'] = $_G['siteurl'].'source/plugin/zimu_zhaopin/uploadzimucms/' . $type . '/' . $date . $filename;
    $config_params['show_path'] = $_G['siteurl'] . 'source/plugin/zimu_zhaopin/uploadzimucms/' . $type . '/' . $date . $filename;
    ;
    $config_params['upload_ok'] = true;
    return $config_params;
    
}