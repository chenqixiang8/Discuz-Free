<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if (!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }
    use think\Db;
    $token = addslashes($_GET['token']);
    $myuid = checktoken_admin($token);
    $op = addslashes($_GET['op']);
    $op = $op ? $op : 'list';

    if ($op == 'edit') {

        $ids = intval($postdata['id']);
        $area_data['name'] = zm_diconv($postdata['name']);
        $area_data['sort'] = intval($postdata['sort']);
        $area_data['parentid'] = intval($postdata['parentid']);


        if($ids>0){
            Db::name('zimu_zhaopin_area')->where('id', $ids)->data($area_data)->update();
        }else{
            $area_data['parentid'] = intval($postdata['dictId']);
            Db::name('zimu_zhaopin_area')->insert($area_data);
        }

        zimu_json3($res);

    } else if ($op == 'del') {

        $ids = intval($_GET['ids']);
        Db::name('zimu_zhaopin_area')->where([['id','=',$ids]])->delete();

        zimu_json3($res);

    } else if ($op == 'area2') {

        $res = Db::name('zimu_zhaopin_area')->where([['parentid','=',0]])->order(['sort' =>'asc','id'=>'asc'])->select()->toArray();
        foreach ($res as $key => $value) {
            $res[$key]['children'] = Db::name('zimu_zhaopin_area')->where([['parentid','=',$value['id']]])->order(['sort' =>'desc','id'=>'asc'])->select()->toArray();
            if(!$res[$key]['children']){
                unset($res[$key]['children']);
            }
        }
        zimu_json3($res);


    } else {

        $parentid = intval($_GET['dictId']);

        $res = Db::name('zimu_zhaopin_area')->where([['parentid','=',$parentid]])->order(['sort' =>'asc','id'=>'asc'])->select()->toArray();

        zimu_json3($res);
    }