<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if (!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }
    use think\Db;
    $token = addslashes($_GET['token']);
    $myuid = checktoken_admin($token);
    $op = addslashes($_GET['op']);
    $op = $op ? $op : 'list';

    if ($op == 'lizimu') {


    } else if ($op == 'toedit') {

        $setmeal_data = zimu_array_utf8tomy($postdata);

        $ids = $setmeal_data['id'];
        if($ids>0){
            Db::name('zimu_zhaopin_setmeal')->where('id', $ids)->data($setmeal_data)->update();
        }else{
            Db::name('zimu_zhaopin_setmeal')->insert($setmeal_data);
        }

        zimu_json3($res);


    } else if ($op == 'del') {

        Db::name('zimu_zhaopin_setmeal')->where('id', $postdata['ids'])->delete();

        zimu_json3($res);

    } else if ($op == 'increment') {

        $wheresql = [];

        $wheresql = [];
        $cat = strip_tags($_GET['cat']);
        if($cat){
            $wheresql[] = ['cat','=',$cat];
        }

        $page = intval($_GET['page']);
        $limit = 100;
        $res = Db::name('zimu_zhaopin_setmeal_increment')->where($wheresql)->order(['id'=>'asc'])->page($page,$limit)->select()->toArray();
        $count = Db::name('zimu_zhaopin_setmeal_increment')->where($wheresql)->order($ordersql)->count();
        zimu_json3($res,'',0,$count);

    } else if ($op == 'toedit_increment') {

        $setmeal_data = zimu_array_utf8tomy($postdata);

        $ids = $setmeal_data['id'];
        if($ids>0){
            Db::name('zimu_zhaopin_setmeal_increment')->where('id', $ids)->data($setmeal_data)->update();
        }else{
            Db::name('zimu_zhaopin_setmeal_increment')->insert($setmeal_data);
        }

        zimu_json3($res);

    } else if ($op == 'del_increment') {

        Db::name('zimu_zhaopin_setmeal_increment')->where('id', $postdata['ids'])->delete();

        zimu_json3($res);

    } else if ($op == 'socompany') {
        $wheresql = [];
        $keyword = zimu_array_utf8tomy($_GET['keyword']);
        if (!empty($keyword)) {
            $wheresql[] = ['uid|companyname|telephone','like','%'.$keyword.'%'];
        }
        $order = strip_tags($_GET['order']) ? strip_tags($_GET['order']) : 'addtime';
        $ordersql[$order] = 'desc';
        $ordersql['id'] = 'desc';
        $page = 1;
        $limit = 20;
        $res['company'] = Db::name('zimu_zhaopin_company_profile')->field('id as value,companyname as label,uid')->where($wheresql)->order($ordersql)->page($page,$limit)->select()->toArray();
        $res['zmdata']['setmeal'] = Db::name('zimu_zhaopin_setmeal')->order(['id'=>'asc'])->page($page,$limit)->select()->toArray();

        zimu_json3($res);
    } else if ($op == 'company_setmeal') {

        $ids = intval($_GET['ids']);
        $res = Db::name('zimu_zhaopin_members_setmeal')->where('uid', $ids)->order(['id'=>'asc'])->find();
        zimu_json3($res);

    } else if ($op == 'toedit_setmeal') {

        if($postdata['tosetmea']==1 || $postdata['tosetmea']==2){

            $user_setmeal = Db::name('zimu_zhaopin_members_setmeal')->where([['uid','=',$postdata['touid']]])->order(['id'=>'asc'])->find();
            $user_company = Db::name('zimu_zhaopin_company_profile')->where([['uid','=',$postdata['touid']]])->order(['id'=>'asc'])->find();
            $tosetmeal = Db::name('zimu_zhaopin_setmeal')->where([['id','=',$postdata['setmealid']]])->order(['id'=>'asc'])->find();
            $new_setmeal['expire']              = $setmeal['is_free'] == 1 ? 1 : 0;
            $new_setmeal['uid']                 = $postdata['touid'];;
            $new_setmeal['setmeal_id']          = $tosetmeal['id'];
            $new_setmeal['setmeal_name']        = $tosetmeal['setmeal_name'];
            $new_setmeal['days']                = $tosetmeal['days'];
            $new_setmeal['expense']             = $tosetmeal['expense'];
            $new_setmeal['jobs_meanwhile']      = $tosetmeal['jobs_meanwhile'];
            $new_setmeal['refresh_jobs_free']   = $tosetmeal['refresh_jobs_free'];
            $setmeal_add['download_resume']     = $tosetmeal['download_resume'];
            $new_setmeal['download_resume_max'] = $tosetmeal['download_resume_max'];
            $new_setmeal['added']               = $tosetmeal['added'];
            $new_setmeal['starttime']           = time();
            if ($tosetmeal['days'] > 0) {
                $new_setmeal['endtime'] = strtotime("" . $tosetmeal['days'] . " days");
            } else {
                $new_setmeal['endtime'] = "0";
            }
            $new_setmeal['show_apply_contact']         = $tosetmeal['show_apply_contact'];
            $new_setmeal['is_free']                    = $tosetmeal['is_free'];
            $new_setmeal['discount_download_resume']   = $tosetmeal['discount_download_resume'];
            $new_setmeal['discount_stick']             = $tosetmeal['discount_stick'];
            $new_setmeal['discount_emergency']         = $tosetmeal['discount_emergency'];
            $new_setmeal['discount_auto_refresh_jobs'] = $tosetmeal['discount_auto_refresh_jobs'];

            if ($postdata['tosetmea'] == 1) {
                $new_setmeal['download_resume'] = $tosetmeal['download_resume'];
                $setmeal_add['starttime']       = time();
            } elseif ($postdata['tosetmea'] == 2) {
                $new_setmeal['download_resume'] = $user_setmeal['download_resume'] + $tosetmeal['download_resume'];
            }

            $crm_custom_log_data['custom_type']       = 1;
            $crm_custom_log_data['custom_id']        = $user_company['id'];
            $crm_custom_log_data['crm_uid']     = get_kefu_uid($token);
            $crm_custom_log_data['op_type']       = 'toedit_setmeal';
            $crm_custom_log_data['note']       = $language_zimu['adminss_setmeal_inc_php_0'];
            $crm_custom_log_data['remark']       = '���ײ�����:'.$new_setmeal['setmeal_name'].'���ײ�����:'.$user_setmeal['setmeal_name'];
            $crm_custom_log_data['add_time']     = time();
            $crm_custom_log_data['ip']     = $_SERVER["REMOTE_ADDR"];
            Db::name('zimu_zhaopin_crm_custom_log')->insert($crm_custom_log_data);

            if($user_setmeal){
                Db::name('zimu_zhaopin_members_setmeal')->where('uid', $postdata['touid'])->data($new_setmeal)->update();
            }else{
                Db::name('zimu_zhaopin_members_setmeal')->insert($new_setmeal);
            }

            Db::name('zimu_zhaopin_company_profile')->where('uid', $postdata['touid'])->data(['setmeal_id' => $new_setmeal['setmeal_id'],'setmeal_name' => $new_setmeal['setmeal_name']])->update();
            Db::name('zimu_zhaopin_jobs')->where('uid', $postdata['touid'])->data(['setmeal_id' => $new_setmeal['setmeal_id'],'setmeal_name' => $new_setmeal['setmeal_name']])->update();

        }

    } else if ($op == 'company_points') {

        $ids = intval($_GET['ids']);
        $res = Db::name('zimu_zhaopin_members')->where('uid', $ids)->order(['id'=>'asc'])->find();
        $res['points'] = $res['points']/10*$zmdata['settings']['jifen_bili'];
        zimu_json3($res);

    } else if ($op == 'toedit_points') {

        $postdata['topoints'] = $postdata['topoints']*10/$zmdata['settings']['jifen_bili'];

        if($postdata['operate']==1){
            Db::name('zimu_zhaopin_members')->where('uid', $postdata['touid'])->inc('points',$postdata['topoints'])->update();
        }elseif ($postdata['operate']==2){
            Db::name('zimu_zhaopin_members')->where('uid', $postdata['touid'])->dec('points',$postdata['topoints'])->update();
        }

        $setsqlarr_handsel['uid']     = $postdata['touid'];
        $setsqlarr_handsel['htype']    = 'give_points';
        $setsqlarr_handsel['htype_cn']    = get_kefu_uid($token).$language_zimu['adminss_setmeal_inc_php_3'];
        $setsqlarr_handsel['operate']    = $postdata['operate'];
        $setsqlarr_handsel['points'] = $postdata['topoints'];
        $setsqlarr_handsel['addtime'] = time();
        Db::name('zimu_zhaopin_members_handsel')->insert($setsqlarr_handsel);

        zimu_json3($res);

    } else if ($op == 'toedit_resume') {

        if($postdata['operate']==1){
            $table_name = $postdata['operate2'] == 1 ? 'download_resume' : 'download_resume2';
            Db::name('zimu_zhaopin_members_setmeal')->where('uid', $postdata['touid'])->inc($table_name,$postdata['topoints'])->update();
        }elseif ($postdata['operate']==2){
            Db::name('zimu_zhaopin_members_setmeal')->where('uid', $postdata['touid'])->dec($table_name,$postdata['topoints'])->update();
        }

        $user_company = Db::name('zimu_zhaopin_company_profile')->where([['uid','=',$postdata['touid']]])->order(['id'=>'asc'])->find();

        $crm_custom_log_data['custom_type']       = 1;
        $crm_custom_log_data['custom_id']        = $user_company['id'];
        $crm_custom_log_data['crm_uid']     = get_kefu_uid($token);
        $crm_custom_log_data['op_type']       = 'download_resume';
        $crm_custom_log_data['note']       = get_admin_name($token).$language_zimu['adminss_setmeal_inc_php_4'];
        $crm_custom_log_data['remark']       = ($postdata['operate']==1 ? $language_zimu['adminss_setmeal_inc_php_5'] : $language_zimu['adminss_setmeal_inc_php_6']).$postdata['topoints'];
        $crm_custom_log_data['add_time']     = time();
        $crm_custom_log_data['ip']     = $_SERVER["REMOTE_ADDR"];
        Db::name('zimu_zhaopin_crm_custom_log')->insert($crm_custom_log_data);

    } else if ($op == 'toedit_setmeal2') {

        $postdata = zimu_array_utf8tomy($postdata);
        $postdata['endtime'] = $postdata['endtime']/1000;
        Db::name('zimu_zhaopin_members_setmeal')->where('uid', $postdata['touid'])->data($postdata)->update();
        zimu_json3($res);

    } else {

        $wheresql = [];

        $page = intval($_GET['page']);
        $limit = intval($_GET['limit']);
        $res = Db::name('zimu_zhaopin_setmeal')->where($wheresql)->order(['id'=>'asc'])->page($page,$limit)->select()->toArray();
        $count = Db::name('zimu_zhaopin_setmeal')->where($wheresql)->order($ordersql)->count();
        zimu_json3($res,'',0,$count);

    }