<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if (!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }
    use think\Db;
    $token = addslashes($_GET['token']);
    $myuid = checktoken_admin($token);
    $op = addslashes($_GET['op']);
    $op = $op ? $op : 'list';

    if ($op == 'edit') {


    } else if ($op == 'tosavetpl') {

        $postdata = zimu_array_utf8tomy($postdata);
        $class_type = strip_tags($_GET['class_type']);
        //$isadd = Db::name('zimu_zhaopin_mptpl2')->where([['type','=','mptpl'],['name','=',$postdata['mptpltitle']]])->order('id','desc')->find();
        $data['type'] = $class_type;
        $data['name'] = $postdata['mptpltitle'];
        $data['parameter'] = $postdata['mptplhtml'];
        if($postdata['mptplid']){
            Db::name('zimu_zhaopin_mptpl2')->where('id', $postdata['mptplid'])->data($data)->update();
        }else{
            Db::name('zimu_zhaopin_mptpl2')->insert($data);
        }
        zimu_json($res);

    } else if ($op == 'todeltpl') {

        $postdata = zimu_array_utf8tomy($postdata);
        $class_type = strip_tags($_GET['class_type']);
        Db::name('zimu_zhaopin_mptpl2')->where([['type','=',$class_type],['id','=',$postdata['mptplid']]])->delete();
        zimu_json($res);


    } else if ($op == 'getdata') {

        $arealist = Db::name('zimu_zhaopin_area')->where([['parentid','=',0]])->order(['sort' =>'desc','id'=>'asc'])->select()->toArray();
        foreach ($arealist as $key => $value) {
            $arealist[$key]['children'] = Db::name('zimu_zhaopin_area')->where([['parentid','=',$value['id']]])->order(['sort' =>'desc','id'=>'asc'])->select()->toArray();
            if(!$arealist[$key]['children']){
                unset($arealist[$key]['children']);
            }
        }
        $res['arealist'] = $arealist;
        $class_type = strip_tags($_GET['class_type']);

        $category_jobs = Db::name('zimu_zhaopin_category_jobs')->where([['parentid','=',0]])->order(['category_order' =>'desc','id'=>'asc'])->select()->toArray();
        foreach ($category_jobs as $key => $value) {
            $category_jobs[$key]['children'] = Db::name('zimu_zhaopin_category_jobs')->where([['parentid','=',$value['id']]])->order(['category_order' =>'desc','id'=>'asc'])->select()->toArray();
            if(!$category_jobs[$key]['children']){
                unset($category_jobs[$key]['children']);
            }
        }
        $res['category_jobs'] = $category_jobs;


        $res['mptpllist'] = Db::name('zimu_zhaopin_mptpl2')->where('type', $class_type)->order('id','asc')->select()->toArray();

        zimu_json3($res);

    } else if ($op == 'tososo_job') {

        $postdata = zimu_array_utf8tomy($postdata);

        $wheresql = [];
        $whereraw2 = '1=1';
        if($postdata['area']){
            $whereraw = [];
            foreach ($postdata['area'] as $key => $value) {
                if($value[1]){
                    $whereraw[] = '( district2 = '.$value['1'].' )';
                }else{
                    $whereraw[] = '( district = '.$value['0'].' )';
                }
            }
            $whereraw2 = implode('or',$whereraw);
        }

        if($postdata['categorys']){
            $whereraw = [];
            foreach ($postdata['categorys'] as $key => $value) {
                if($value[1]){
                    $whereraw[] = '( category = '.$value['1'].' )';
                }else{
                    $whereraw[] = '( topclass = '.$value['0'].' )';
                }
            }
            $whereraw2 = implode('or',$whereraw);
        }

        if($postdata['job_ids']){
            $wheresql[] = ['id','in',$postdata['job_ids']];
        }

        if($postdata['company_ids']){
            $wheresql[] = ['company_id','in',$postdata['company_ids']];
        }


        $istop = intval($postdata['istop']);
        if($istop==1){
            $wheresql[] = ['stick_endtime','>',time()];
        }

        $todate = intval($postdata['todate']);
        if (!empty($todate)) {
            $wheresql[] = ['addtime','>',(time()-(86400*$todate))];
        }

        $order = strip_tags($postdata['order']) ? strip_tags($postdata['order']) : 'addtime';
        $ordersql[$order] = 'desc';
        $ordersql['id'] = 'desc';

        $page = 1;
        $limit = intval($postdata['limit']) ? intval($postdata['limit']) : 1;

        $wheresql[] = ['display','=',1];
        $wheresql[] = ['audit','=',1];

        $res = Db::name('zimu_zhaopin_jobs')->where($wheresql)->whereRaw($whereraw2)->order($ordersql)->limit($limit)->select()->toArray();

        require_once DISCUZ_ROOT . './source/plugin/zimu_zhaopin/class/wechat.lib.class.php';
        $wechat_client = new WeChatClient($zmdata['base']['weixin_appid'], $zmdata['base']['weixin_appsecret']);


        foreach ($res as $key => $value) {
            $res[$key]['zp_tolink'] = $_G['siteurl'].'plugin.php?id=zimu_zhaopin&model=viewjob&jid='.$value['id'];
            $res[$key]['zp_qrcode'] = ZIMUCMS_URL.':toqrcode&url=' . urlencode($res[$key]['zp_tolink']);

            if ($value['nature']==63 && $value['parttime_money']) {
                if($value['parttime_type']==1){
                    $res[$key]['wage_cn'] = $value['parttime_money'].$zmdata['settings']['money_name'].'/'.$language_zimu['adminss_mptpl_inc_php_0'];
                }
                if($value['parttime_type']==2){
                    $res[$key]['wage_cn'] = $value['parttime_money'].$zmdata['settings']['money_name'].'/'.$language_zimu['adminss_mptpl_inc_php_1'];
                }
                if($value['parttime_type']==0){
                    $res[$key]['wage_cn'] = $value['parttime_money'].$zmdata['settings']['money_name'].'/'.$language_zimu['adminss_mptpl_inc_php_2'];
                }
                if($value['parttime_type']==3){
                    $res[$key]['wage_cn'] = $value['parttime_money'].$zmdata['settings']['money_name'].'/'.$language_zimu['adminss_mptpl_inc_php_3'];
                }
            }elseif ($value['nature']==63){
                $res[$key]['wage_cn'] = $language_zimu['adminss_mptpl_inc_php_4'];
            }
            $res[$key]['contents'] = str_replace(array(
                "\r\n",
                "\r",
                "\n"
            ), "", $value['contents']);

            $dir = DISCUZ_ROOT.'/source/plugin/zimu_zhaopin/uploadzimucms/';
            $xcx_tip = $client_type == 'xcx' ? 'xcx_' : 'h5_';
            $qrcode_file = $dir.'qrcode/'.$postdata['class_type'].'_'.$xcx_tip.$value['id'].'.jpg';

            if(!file_exists($qrcode_file) || !filesize($qrcode_file) || filemtime($qrcode_file) < time() - 2590000 ) {
                $qrcode_url = $wechat_client->getQrcodeImgUrlByTicket($wechat_client->getQrcodeTicket(array(
                    'scene_str' =>  'viewjob'.'zimuyun' . $value['id'],
                    'expire' => 2591000
                )));
                $qrcode_img = dfsockopen($qrcode_url);
                $qrcode_img = $qrcode_img ? $qrcode_img : file_get_contents($qrcode_url2);
                $fp = fopen($qrcode_file, 'wb');
                flock($fp, 2);
                fwrite($fp,$qrcode_img);
                fclose($fp);
            }
            $res[$key]['zp_qrcode2'] = $_G['siteurl'].'/source/plugin/zimu_zhaopin/uploadzimucms/qrcode/'.$postdata['class_type'].'_'.$xcx_tip.$value['id'].'.jpg';
            $res[$key]['companyname_address'] = Db::name('zimu_zhaopin_company_profile')->where([['uid','=',$value['uid']]])->value('address');

        }


        zimu_json3($res);

    } else if ($op == 'tososo_resume') {

        $postdata = zimu_array_utf8tomy($postdata);

        $wheresql = [];
        $whereraw2 = '1=1';
        if($postdata['area']){
            $whereraw = [];
            foreach ($postdata['area'] as $key => $value) {
                $whereraw[] = ' ( district like \'%'.implode('.',$value).'.0'.'%\' ) ';
            }
            $whereraw2 = implode('or',$whereraw);
        }

        $istop = intval($postdata['istop']);
        if($istop==1){
            $wheresql[] = ['stick_endtime','>',time()];
        }

        $todate = intval($postdata['todate']);
        if (!empty($todate)) {
            $wheresql[] = ['addtime','>',(time()-(86400*$todate))];
        }

        $order = strip_tags($postdata['order']) ? strip_tags($postdata['order']) : 'addtime';
        $ordersql[$order] = 'desc';
        $ordersql['id'] = 'desc';

        $page = 1;
        $limit = intval($postdata['limit']) ? intval($postdata['limit']) : 1;

        $wheresql[] = ['display','=',1];
        $wheresql[] = ['audit','=',3];


        $res = Db::name('zimu_zhaopin_resume')->where($wheresql)->whereRaw($whereraw2)->order($ordersql)->limit($limit)->select()->toArray();

        require_once DISCUZ_ROOT . './source/plugin/zimu_zhaopin/class/wechat.lib.class.php';
        $wechat_client = new WeChatClient($zmdata['base']['weixin_appid'], $zmdata['base']['weixin_appsecret']);


        foreach ($res as $key => $value) {
            if($value['sex']==1){
                $res[$key]['fullname'] = cutstr($value['fullname'],2,'').$language_zimu['adminss_mptpl_inc_php_5'];
                $res[$key]['photo_img'] = $zmdata['settings']['show_resume_photo'] != 1 &&  $value['photo_img'] ? $value['photo_img'] : ZIMUCMS_PATH.'static/wap/images/no_photo_male.png';
            }else{
                $res[$key]['fullname'] = cutstr($value['fullname'],2,'').$language_zimu['adminss_mptpl_inc_php_6'];
                $res[$key]['photo_img'] = $zmdata['settings']['show_resume_photo'] != 1 && $value['photo_img'] ? $value['photo_img'] : ZIMUCMS_PATH.'static/wap/images/no_photo_female.png';
            }
            $res[$key]['zp_tolink'] = $_G['siteurl'].'plugin.php?id=zimu_zhaopin&model=viewresume&rid='.$value['id'];
            $res[$key]['zp_qrcode'] = ZIMUCMS_URL.':toqrcode&url=' . urlencode($res[$key]['zp_tolink']);

            $res[$key]['specialty'] = str_replace(array(
                "\r\n",
                "\r",
                "\n"
            ), "", $value['specialty']);

            $dir = DISCUZ_ROOT.'/source/plugin/zimu_zhaopin/uploadzimucms/';
            $xcx_tip = $client_type == 'xcx' ? 'xcx_' : 'h5_';
            $qrcode_file = $dir.'qrcode/'.$postdata['class_type'].'_'.$xcx_tip.$value['id'].'.jpg';

            if(!file_exists($qrcode_file) || !filesize($qrcode_file) || filemtime($qrcode_file) < time() - 2590000 ) {
                $qrcode_url = $wechat_client->getQrcodeImgUrlByTicket($wechat_client->getQrcodeTicket(array(
                    'scene_str' =>  'viewresume'.'zimuyun' . $value['id'],
                    'expire' => 2591000
                )));
                $qrcode_img = dfsockopen($qrcode_url);
                $qrcode_img = $qrcode_img ? $qrcode_img : file_get_contents($qrcode_url2);
                $fp = fopen($qrcode_file, 'wb');
                flock($fp, 2);
                fwrite($fp,$qrcode_img);
                fclose($fp);
            }
            $res[$key]['zp_qrcode2'] = $_G['siteurl'].'/source/plugin/zimu_zhaopin/uploadzimucms/qrcode/'.$postdata['class_type'].'_'.$xcx_tip.$value['id'].'.jpg';

        }


        zimu_json3($res);

    }