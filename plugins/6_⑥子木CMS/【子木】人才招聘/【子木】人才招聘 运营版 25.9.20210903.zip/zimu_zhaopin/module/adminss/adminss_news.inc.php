<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if (!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }
    use think\Db;
    $token = addslashes($_GET['token']);
    $myuid = checktoken_admin($token);
    $op = addslashes($_GET['op']);
    $op = $op ? $op : 'list';

    if ($op == 'edit') {

    } else if ($op == 'editcat') {

        $news_cat_data = zimu_array_utf8tomy($postdata);
        if($news_cat_data['id']){
            Db::name('zimu_zhaopin_news_cat')->where('id', $news_cat_data['id'])->data($news_cat_data)->update();
        }else{
            Db::name('zimu_zhaopin_news_cat')->insert($news_cat_data);
        }
        zimu_json3($res);

    } else if ($op == 'delcat') {

        Db::name('zimu_zhaopin_news_cat')->where([['id','=',$postdata['id']]])->delete();

        zimu_json3($res);

    } else if ($op == 'catlist') {

        $res['list'] = Db::name('zimu_zhaopin_news_cat')->order(['id'=>'asc'])->select()->toArray();

        zimu_json3($res);

    } else if ($op == 'newslist') {

        $cid = intval($_GET['cid']);
        unset($wheresql);
        if($cid){
            $wheresql[] = ['cid','=',$cid];
        }

        $page = intval($_GET['page']);
        $limit = intval($_GET['limit']);

        $res = Db::name('zimu_zhaopin_news')->where($wheresql)->order(['id'=>'desc'])->page($page,$limit)->select()->toArray();

        $count = Db::name('zimu_zhaopin_news')->where($wheresql)->order($ordersql)->count();
        zimu_json3($res,'',0,$count);

    } else if ($op == 'editnews2') {

        $ids = intval($_GET['ids']);
        $res = Db::name('zimu_zhaopin_news')->where([['id','=',$ids]])->findOrEmpty();

        zimu_json3($res);

    } else if ($op == 'editnews') {

        $news_data = zimu_array_utf8tomy($postdata);
        $news_data['addtime'] = $news_data['addtime'] ? $news_data['addtime']/1000 : time();
        if($news_data['id']){
            Db::name('zimu_zhaopin_news')->where('id', $news_data['id'])->data($news_data)->update();
        }else{
            Db::name('zimu_zhaopin_news')->insert($news_data);
        }

        zimu_json3($res);

    } else if ($op == 'delnews') {

        Db::name('zimu_zhaopin_news')->where([['id','=',$postdata['ids']]])->delete();

        zimu_json3($res);


    } else if ($op == 'getdata') {

        $res['zmdata']['catlist'] = Db::name('zimu_zhaopin_news_cat')->order(['id'=>'asc'])->select()->toArray();
        zimu_json3($res);


    } else {


    }