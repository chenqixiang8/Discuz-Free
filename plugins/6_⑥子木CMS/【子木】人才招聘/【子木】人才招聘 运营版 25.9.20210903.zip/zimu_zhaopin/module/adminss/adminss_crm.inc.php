<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if (!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }

    use think\Db;
    $token = addslashes($_GET['token']);
    $myuid = checktoken_admin($token);
    $op = addslashes($_GET['op']);
    $op = $op ? $op : 'list';
    $ids = intval($_GET['ids']);
    $postdata = zimu_array_utf8tomy($postdata);

    if(!file_exists(DISCUZ_ROOT . './source/plugin/zimu_zhaopin/module/admins/admins_crm.inc.php')){
        zimu_json3($res,'CRM error',201);
    }


    if ($op == 'zimu') {

    } else if ($op == 'edit') {



    } else if ($op == 'toedit') {


    }elseif($op == 'getdata' ){

        $paramter = Db::name('zimu_zhaopin_parameter2')->where([['name','=','crm_companyset']])->order(['id'=>'asc'])->findOrEmpty();

        $crm_companyset = unserialize($paramter['parameter']);
        $crm_companyset['funnel'] = explode(',', $crm_companyset['company_funnel']);
        $crm_companyset['level'] = explode(',', $crm_companyset['company_level']);
        $crm_companyset['feedback'] = explode(',', $crm_companyset['company_feedback']);
        $crm_companyset['service'] = explode(',', $crm_companyset['company_service']);

        zimu_json3($crm_companyset);

    }elseif($op == 'feedbacklist' ){

        $wheresql = [];
        $audit = intval($_GET['audit']);
        if($audit){
            $wheresql[] = ['audit','=',$audit];
        }
        $wheresql[] = ['custom_type','=',1];

        $keyword = zimu_array_utf8tomy($_GET['keyword']);
        $keywordtype = intval($_GET['keywordtype']);
        if (!empty($keyword)) {
            if ($keywordtype == 1) {
                $wheresql[] = ['custom_id','=',$keyword];
            } elseif ($keywordtype == 2) {
                $wheresql[] = ['crm_uid','=',$keyword];
            }
        }

        $page = intval($_GET['page']);
        $limit = intval($_GET['limit']);
        $res = Db::name('zimu_zhaopin_crm_custom_feedback')->where($wheresql)->order(['id'=>'desc'])->page($page,$limit)->select()->toArray();

        foreach ($res as $key => $value) {
                $res[$key]['info'] = Db::name('zimu_zhaopin_company_profile')->where([['id','=',$value['custom_id']]])->findOrEmpty();
                $res[$key]['crminfo'] = Db::name('zimu_zhaopin_crm_company')->where([['com_id','=',$value['custom_id']]])->findOrEmpty();
            if(!$res[$key]['info']){
                unset($res[$key]);
            }
        }
        array_multisort($res,SORT_DESC);
        $count = Db::name('zimu_zhaopin_crm_custom_feedback')->where($wheresql)->count();

        zimu_json3($res,'',0,$count);

    }elseif($op == 'customlog' ){

        $wheresql = [];
        $com_id = intval($_GET['com_id']);
        if($com_id){
            $wheresql[] = ['custom_id','=',$com_id];
        }
        $wheresql[] = ['custom_type','=',1];

        $page = intval($_GET['page']);
        $limit = 1000;
        $res = Db::name('zimu_zhaopin_crm_custom_log')->where($wheresql)->order(['id'=>'desc'])->page($page,$limit)->select()->toArray();

        $count = Db::name('zimu_zhaopin_crm_custom_log')->where($wheresql)->count();

        zimu_json3($res,'',0,$count);

    }elseif($op == 'mycompanylist' ){

        $wheresql = [];
        $kefu_uid = get_kefu_uid($token);
        if($kefu_uid){
            $wheresql[] = ['crm_uid','=',$kefu_uid];
        }


        $keyword = zimu_array_utf8tomy($_GET['keyword']);
        $keywordtype = intval($_GET['keywordtype']);
        if (!empty($keyword)) {
            if ($keywordtype == 1) {
                $wheresql[] = ['com_id','=',$keyword];
            } elseif ($keywordtype == 2) {
                $wheresql[] = ['com_uid','=',$keyword];
            }
        }
        $level = intval($_GET['level']);
        if($level){
            $wheresql[] = ['level','=',$level];
        }
        $funnel = intval($_GET['funnel']);
        if($funnel){
            $wheresql[] = ['funnel','=',$funnel];
        }

        $ordersql['rid'] = 'desc';
        $page = intval($_GET['page']);
        $limit = intval($_GET['limit']);

        $res2 = Db::name('zimu_zhaopin_crm_company')->where($wheresql)->order($ordersql)->page($page,$limit)->select()->toArray();

        foreach ($res2 as $key => $value) {
            $res2[$key]['info'] = Db::name('zimu_zhaopin_company_profile')->where([['id','=',$value['com_id']]])->findOrEmpty();
            $res2[$key]['info']['comsetmea'] = Db::name('zimu_zhaopin_members_setmeal')->where([['uid','=',$value['com_uid']]])->find();
            $res2[$key]['crminfo'] = $value;
            $res2[$key]['myjobs'] = Db::name('zimu_zhaopin_jobs')->where([['uid','=',$value['com_uid']]])->count();
            $res2[$key]['feedback'] = Db::name('zimu_zhaopin_crm_custom_feedback')->where([['custom_id','=',$value['com_id']]])->order(['id'=>'desc'])->find();
            if($res2[$key]['feedback']){
                $res2[$key]['crminfo']['nofeedback'] = round(((time()-$res2[$key]['feedback']['add_time'])/86400),1).$language_zimu['adminss_crm_inc_php_0'];
            }else{
                $res2[$key]['crminfo']['nofeedback'] = $language_zimu['adminss_crm_inc_php_1'];
            }
            if(!$res2[$key]['info']['id']){
                unset($res2[$key]);
                Db::name('zimu_zhaopin_crm_company')->where([['rid','=',$value['rid']]])->delete();
            }
        }
        array_multisort($res2);
        $count = Db::name('zimu_zhaopin_crm_company')->where($wheresql)->order($ordersql)->count();

        zimu_json3($res2,'',0,$count);

    }elseif($op == 'companylist' ){

        $wheresql = [];

        $keyword = zimu_array_utf8tomy($_GET['keyword']);
        $keywordtype = intval($_GET['keywordtype']);
        if (!empty($keyword)) {
            if ($keywordtype == 1) {
                $wheresql[] = ['id','=',$keyword];
            } elseif ($keywordtype == 2) {
                $wheresql[] = ['uid','=',$keyword];
            } elseif ($keywordtype == 3) {
                $wheresql[] = ['companyname','like','%'.$keyword.'%'];
            }
        }
        $wheresql[] = ['kefu_uid','=',0];

        $ordersql['id'] = 'desc';
        $page = intval($_GET['page']);
        $limit = intval($_GET['limit']);

        $res2 = Db::name('zimu_zhaopin_company_profile')->where($wheresql)->order($ordersql)->page($page,$limit)->select()->toArray();


        foreach ($res2 as $key => $value) {
            $res2[$key]['myjobs'] = Db::name('zimu_zhaopin_jobs')->where([['uid','=',$value['uid']]])->count();
        }

        $count = Db::name('zimu_zhaopin_company_profile')->where($wheresql)->order($ordersql)->count();

        zimu_json3($res2,'',0,$count);


    }elseif($op == 'companyindex' ){

        $ids = intval($_GET['ids']);
        $wheresql = [];
        $wheresql[] = ['id','=',$ids];
        $res['company'] = Db::name('zimu_zhaopin_company_profile')->where($wheresql)->findOrEmpty();
        $res['company']['crminfo'] = Db::name('zimu_zhaopin_crm_company')->where([['com_id','=',$res['company']['id']]])->findOrEmpty();

        $paramter = Db::name('zimu_zhaopin_parameter2')->where([['name','=','crm_companyset']])->order(['id'=>'asc'])->findOrEmpty();

        $crm_companyset = unserialize($paramter['parameter']);
        $crm_companyset['funnel'] = explode(',', $crm_companyset['company_funnel']);
        $crm_companyset['level'] = explode(',', $crm_companyset['company_level']);
        $crm_companyset['feedback'] = explode(',', $crm_companyset['company_feedback']);
        $crm_companyset['service'] = explode(',', $crm_companyset['company_service']);

        $res['zmdata'] = $crm_companyset;

        zimu_json3($res);

    }elseif($op == 'addfeedback' ){
        $postdata['crm_uid'] = get_kefu_uid($token);
        $postdata['contact_name'] = $postdata['contact'].$postdata['telephone'];
        $postdata['add_time'] = $postdata['add_time'] ? $postdata['add_time']/1000 : time();
        Db::name('zimu_zhaopin_crm_custom_feedback')->insert($postdata);
        if($postdata['add_time']>time()){
            Db::name('zimu_zhaopin_crm_company')->where('com_id', $postdata['custom_id'])->data(['next_time' => $postdata['add_time']])->update();
        }else{
            Db::name('zimu_zhaopin_crm_company')->where('com_id', $postdata['custom_id'])->data(['follow_time' => $postdata['add_time']])->update();
        }
        zimu_json3($res);

    }elseif($op == 'addremark' ){
        Db::name('zimu_zhaopin_crm_company')->where('com_id', $postdata['com_id'])->data(['remark' => $postdata['remark']])->update();
        zimu_json3($res);
    }elseif($op == 'edit_funnel' ){
        Db::name('zimu_zhaopin_crm_company')->where('com_id', $postdata['ids'])->data(['funnel' => $postdata['funnel']])->update();
        $crm_custom_log_data['custom_type']       = 1;
        $crm_custom_log_data['custom_id']        = $postdata['ids'];
        $crm_custom_log_data['crm_uid']     = get_kefu_uid($token);
        $crm_custom_log_data['op_type']       = 'funnel';
        $crm_custom_log_data['note']       = $language_zimu['adminss_crm_inc_php_2'].$postdata['funnel_cn'];
        $crm_custom_log_data['remark']       = $language_zimu['adminss_crm_inc_php_3'].get_admin_name($token);
        $crm_custom_log_data['add_time']     = time();
        $crm_custom_log_data['ip']     = $_SERVER["REMOTE_ADDR"];
        Db::name('zimu_zhaopin_crm_custom_log')->insert($crm_custom_log_data);
        zimu_json3($res);
    }elseif($op == 'edit_level' ){
        Db::name('zimu_zhaopin_crm_company')->where('com_id', $postdata['ids'])->data(['level' => $postdata['level']])->update();
        $crm_custom_log_data['custom_type']       = 1;
        $crm_custom_log_data['custom_id']        = $postdata['ids'];
        $crm_custom_log_data['crm_uid']     = get_kefu_uid($token);
        $crm_custom_log_data['op_type']       = 'level';
        $crm_custom_log_data['note']       = $language_zimu['adminss_crm_inc_php_4'].$postdata['level_cn'];
        $crm_custom_log_data['remark']       = $language_zimu['adminss_crm_inc_php_5'].get_admin_name($token);
        $crm_custom_log_data['add_time']     = time();
        $crm_custom_log_data['ip']     = $_SERVER["REMOTE_ADDR"];
        Db::name('zimu_zhaopin_crm_custom_log')->insert($crm_custom_log_data);
        zimu_json3($res);

    }elseif($op == 'allocation' ){

        if($postdata['type']=='getcrm'){
            $postdata['kefu_uid'] = get_kefu_uid($token);
        }
        if($postdata['type']=='giveup'){
            $postdata['kefu_uid'] = get_kefu_uid($token);
        }

        if($postdata['kefu_uid']){
            $kefu = Db::name('zimu_zhaopin_kefu')->where([['uid','=',$postdata['kefu_uid']]])->findOrEmpty();
            $postdata['kefu_name'] = $kefu['kefu_name'];

            foreach ($postdata['postids'] as $key => $value) {

                if($postdata['type']=='giveup'){
                    $postdata['kefu_uid'] = $postdata['kefu_name'] = '';
                    Db::name('zimu_zhaopin_company_profile')->where('id', $value)->data(['kefu_uid' => $postdata['kefu_uid'],'kefu_name' => $postdata['kefu_name']])->update();
                    Db::name('zimu_zhaopin_crm_company')->where('com_id',$value)->delete();
                }else{
                    Db::name('zimu_zhaopin_company_profile')->where('id', $value)->data(['kefu_uid' => $postdata['kefu_uid'],'kefu_name' => $postdata['kefu_name']])->update();
                    $companydata = Db::name('zimu_zhaopin_company_profile')->where([['id','=',$value]])->findOrEmpty();
                    $crm_company = Db::name('zimu_zhaopin_crm_company')->where([['com_id','=',$value]])->find();
                    if(!$crm_company){
                        $crm_company_data['com_id']       = $value;
                        $crm_company_data['com_uid']        = $companydata['uid'];
                        $crm_company_data['crm_uid']     = $postdata['kefu_uid'];
                        $crm_company_data['receive_time']     = time();
                        Db::name('zimu_zhaopin_crm_company')->insert($crm_company_data);
                    }else{
                        Db::name('zimu_zhaopin_crm_company')->where('rid', $crm_company['rid'])->data(['crm_uid' => $postdata['kefu_uid']])->update();
                    }
                }

                $crm_custom_log_data['custom_type']       = 1;
                $crm_custom_log_data['custom_id']        = $value;
                $crm_custom_log_data['crm_uid']     = $postdata['kefu_uid'];
                $crm_custom_log_data['op_type']       = $postdata['type']=='giveup' ? 'giveup' : 'receive';
                $crm_custom_log_data['note']       = $postdata['type']=='giveup' ? $language_zimu['adminss_crm_inc_php_6'] : $language_zimu['adminss_crm_inc_php_7'];
                $crm_custom_log_data['remark']       = $language_zimu['adminss_crm_inc_php_8'].get_admin_name($token).$postdata['tpl'];
                $crm_custom_log_data['add_time']     = time();
                $crm_custom_log_data['ip']     = $_SERVER["REMOTE_ADDR"];
                Db::name('zimu_zhaopin_crm_custom_log')->insert($crm_custom_log_data);
            }
            zimu_json3($res);

        }else{
            zimu_json3($res,$language_zimu['adminss_crm_inc_php_9'],201);
        }

    }elseif($op == 'statistics' ){

        $wheresql = [];
        $kefu_uid = get_kefu_uid($token);
        if($kefu_uid){
            $wheresql[] = ['kefu_uid','=',$kefu_uid];
        }

        $res['zmdata']['company_nums'] = Db::name('zimu_zhaopin_company_profile')->count();
        $res['zmdata']['company_nums2'] = Db::name('zimu_zhaopin_company_profile')->where([['addtime','>',strtotime(date('Y-m-d', time()))]])->count();
        $res['zmdata']['company_nums3'] = Db::name('zimu_zhaopin_company_profile')->where([['setmeal_id','>',1]])->count();
        $res['zmdata']['todayfollow'] = Db::name('zimu_zhaopin_crm_custom_feedback')->where([['add_time','>',strtotime(date('Y-m-d', time()))]])->group('custom_id')->count();
        $res['zmdata']['quickexpire'] = Db::name('zimu_zhaopin_members_setmeal')->where([['endtime','>',strtotime(date('Y-m-d', time()))-1296000],['setmeal_id','>',1]])->count();
        $res['zmdata']['day15beforefollow'] = Db::name('zimu_zhaopin_crm_company')->where([['follow_time','<',strtotime(date('Y-m-d', time()))-1296000]])->count();
        $res['zmdata']['day30beforefollow'] = Db::name('zimu_zhaopin_crm_company')->where([['follow_time','<',strtotime(date('Y-m-d', time()))-2592000]])->count();

        $parameter = Db::name('zimu_zhaopin_parameter2')->where('name', 'crm_companyset')->order('id','desc')->find();
        $parameters = unserialize($parameter['parameter']);
        $company_level = explode(',',$parameters['company_level']);

        foreach ($company_level as $key => $value) {
            $res['zmdata']['company_level']['company_level'.($key+1)]['name'] = $value;
            $res['zmdata']['company_level']['company_level'.($key+1)]['nums'] = Db::name('zimu_zhaopin_crm_company')->where([['level','=',($key+1)]])->count();
        }
        zimu_json3($res);

    }elseif($op == 'statistics_sales' ){

        $kefu = Db::name('zimu_zhaopin_kefu')->order(['id'=>'asc'])->select()->toArray();
        foreach ($kefu as $key => $value) {
            $kefu[$key]['alCrmSum'] = Db::name('zimu_zhaopin_crm_company')->where([['crm_uid','=',$value['uid']]])->count();
            $kefu[$key]['todayNewAddSum'] = Db::name('zimu_zhaopin_crm_company')->where([['receive_time','>',strtotime(date('Y-m-d', time()))],['crm_uid','=',$value['uid']]])->count();
            $kefu[$key]['contactCrmSum'] = Db::name('zimu_zhaopin_crm_company')->where([['follow_time','>',0],['crm_uid','=',$value['uid']]])->count();
            $kefu[$key]['vipSum'] = Db::name('zimu_zhaopin_company_profile')->where([['setmeal_id','>',1],['uid','=',$value['uid']]])->count();
            $kefu[$key]['yesterdayVipFollowSum'] = Db::name('zimu_zhaopin_crm_custom_feedback')->where([['add_time','>',strtotime(date('Y-m-d', time()))-86400],['add_time','<',strtotime(date('Y-m-d', time()))],['crm_uid','=',$value['uid']]])->count();

            $com_uids = Db::name('zimu_zhaopin_company_profile')->where([['kefu_uid','=',$value['uid']]])->column('uid');
            $kefu[$key]['afterDays15Sum'] = Db::name('zimu_zhaopin_members_setmeal')->where([['uid','in',$com_uids],['endtime','>',strtotime(date('Y-m-d', time()))-1296000],['setmeal_id','>',1]])->count();
            $PostJobSum = Db::name('zimu_zhaopin_jobs')->where([['uid','in',$com_uids]])->group('uid')->count();
            $kefu[$key]['notPostJobSum'] = $kefu[$key]['alCrmSum'] - $PostJobSum;

            $kefu[$key]['follow7daySum'] = Db::name('zimu_zhaopin_crm_custom_feedback')->where([['add_time','>',strtotime(date('Y-m-d', time()))-518400],['add_time','<',strtotime(date('Y-m-d', time()))+86400],['crm_uid','=',$value['uid']]])->count();


        }
        zimu_json3($kefu);

    }elseif($op == 'saledashboard' ){

        $begin_time = strtotime($_GET['month']);
        $end_time = mktime(23,59,59,date('m',strtotime($_GET['month']))+1,00);

        $kefu_uid2 = get_kefu_uid($token);
        $kefu_uid = intval($_GET['ids']);

        if($kefu_uid2) {
            $kefu_uid = $kefu_uid2;
            $res['kefu'] = Db::name('zimu_zhaopin_kefu')->where([['uid', '=', $kefu_uid]])->order(['id' => 'asc'])->select()->toArray();
        }elseif($kefu_uid){
            $res['kefu'] = Db::name('zimu_zhaopin_kefu')->where([['uid', '=', $kefu_uid]])->order(['id' => 'asc'])->select()->toArray();
            $kefu = Db::name('zimu_zhaopin_kefu')->where([['uid', '<>', $kefu_uid]])->order(['id' => 'asc'])->select()->toArray();
            $res['kefu'] = array_merge($res['kefu'], $kefu);
        }else{
            $res['kefu'] = Db::name('zimu_zhaopin_kefu')->order(['id'=>'asc'])->select()->toArray();
            $kefu_uid = $res['kefu'][0]['uid'];
        }

        if($kefu_uid){
            $com_uids = Db::name('zimu_zhaopin_company_profile')->where([['kefu_uid','=',$kefu_uid]])->column('uid');
            $res['saledata']['newAdd'] = Db::name('zimu_zhaopin_order')->where([['payment_time','>',$begin_time],['payment_time','<',$end_time],['is_paid','=',2],['pay_type','=',2],['service_name','=','setmeal_add'],['uid','in',$com_uids]])->group('uid')->count();
            $res['saledata']['newAmount'] = Db::name('zimu_zhaopin_order')->where([['payment_time','>',$begin_time],['payment_time','<',$end_time],['is_paid','=',2],['pay_type','=',2],['uid','in',$com_uids]])->sum('pay_amount');
            $res['saledata']['renew'] = $res['saledata']['renewAmount'] = 0;
            $res['saledata']['allCustomer'] = Db::name('zimu_zhaopin_crm_company')->where([['crm_uid','=',$kefu_uid]])->count();
            $res['saledata']['todayAppointment'] = Db::name('zimu_zhaopin_crm_custom_feedback')->where([['add_time','>',time()],['add_time','<',strtotime(date('Y-m-d', time()))+86400],['crm_uid','=',$kefu_uid]])->count();
            $res['saledata']['todayFollow'] = Db::name('zimu_zhaopin_crm_custom_feedback')->where([['add_time','>',strtotime(date('Y-m-d', time()))],['add_time','<',time()],['crm_uid','=',$kefu_uid]])->count();
            $res['saledata']['newGetNoFollow'] = Db::name('zimu_zhaopin_crm_company')->where([['follow_time','=',0],['crm_uid','=',$kefu_uid]])->count();
            $res['saledata']['vipSum'] = Db::name('zimu_zhaopin_company_profile')->where([['setmeal_id','>',1],['uid','=',$kefu_uid]])->count();

            $parameter = Db::name('zimu_zhaopin_parameter2')->where('name', 'crm_companyset')->order('id','desc')->find();
            $parameters = unserialize($parameter['parameter']);
            $company_level = explode(',',$parameters['company_level']);

            foreach ($company_level as $key => $value) {
                $res['saledata']['company_level']['company_level'.($key+1)]['name'] = $value;
                $res['saledata']['company_level']['company_level'.($key+1)]['nums'] = Db::name('zimu_zhaopin_crm_company')->where([['level','=',($key+1)],['crm_uid','=',$kefu_uid]])->count();
            }


        }

        zimu_json3($res);

    }elseif($op == 'onedayfeedback' ){

        $kefu_uid = intval($_GET['ids']);
        $day = strtotime($_GET['day']);

        $parameter = Db::name('zimu_zhaopin_parameter2')->where('name', 'crm_companyset')->order('id','desc')->find();
        $parameters = unserialize($parameter['parameter']);
        $company_feedback = explode(',',$parameters['company_feedback']);


        $res = Db::name('zimu_zhaopin_crm_custom_feedback')->where([['add_time','>',$day],['add_time','<',$day+86400],['crm_uid','=',$kefu_uid]])->order(['id'=>'asc'])->select()->toArray();
        foreach ($res as $key => $value) {
            $res[$key]['add_time2'] = date("m-d H:i",$value['add_time']);
            $res[$key]['type_cn'] = $company_feedback[$value['type_id']-1];
            $res[$key]['info'] = Db::name('zimu_zhaopin_company_profile')->where([['id','=',$value['custom_id']]])->field('companyname')->findOrEmpty();
        }

        zimu_json3($res);

    } else {



    }