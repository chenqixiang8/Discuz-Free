<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if (!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }

    use think\Db;
    $token = addslashes($_GET['token']);
    $myuid = checktoken_admin($token);
    $op = addslashes($_GET['op']);
    $op = $op ? $op : 'list';
    $ids = intval($_GET['ids']);
    $postdata = zimu_array_utf8tomy($postdata);

    if ($op == 'zimu') {

    } else if ($op == 'edit') {

        $ids = intval($_GET['ids']);

        $res['resume'] = Db::name('zimu_zhaopin_resume')->where([['id','=',$ids]])->find();
        $auditinfo = Db::name('zimu_zhaopin_resume_audit')->where('uid', $res['resume']['uid'])->find();
        if($auditinfo){
            unset($auditinfo['id']);
            $res['resume'] = array_merge($res['resume'],$auditinfo);
        }

        if($ids){
            $res['resume']['blacklist'] = Db::name('zimu_zhaopin_members')->where([['uid','=',$res['resume']['uid']]])->value('blacklist');
            $jobcategory = explode(',',$res['resume']['intention_jobs_id']);
            foreach ($jobcategory as $key => $value) {
                $jobcategory[$key] = explode('.',$value);
            }
            $res['resume']['jobcategory'] = $jobcategory;

            $area2 = explode(',',$res['resume']['district']);
            foreach ($area2 as $key => $value) {
                $area2[$key] = explode('.',$value);
                if($zmdata['settings']['area_three']!=1){
                    unset($area2[$key][2]);
                }
                if(!$area2[$key][1]){
                    unset($area2[$key][1]);
                }
            }
            $res['resume']['area2'] = $area2;
            $work_list = Db::name('zimu_zhaopin_resume_work')->where([['uid','=',$res['resume']['uid']]])->order(['id'=>'desc'])->select()->toArray();
            $res['resume']['work_list'] = _get_duration($work_list);

            $edulist = Db::name('zimu_zhaopin_resume_education')->where([['uid','=',$res['resume']['uid']]])->order(['id'=>'desc'])->select()->toArray();
            $res['resume']['edulist'] = _get_duration($edulist);
        }


        $category = Db::name('zimu_zhaopin_category')->order(['c_order'=>'asc','c_id'=>'asc'])->select()->toArray();

        foreach ($category as $key => $value) {
            $category2[$value['c_alias']][$value['c_id']]['value'] = $value['c_id'];
            $category2[$value['c_alias']][$value['c_id']]['label'] = $value['c_name'];
        }

        $education_list = $category2['ZM_education'];
        $res['zmdata']['education_list'] = $education_list;
        $experience_list = $category2['ZM_experience'];
        $res['zmdata']['experience_list'] = $experience_list;
        $current_list = $category2['ZM_current'];
        $res['zmdata']['current_list'] = $current_list;
        $nature_list = $category2['ZM_jobs_nature'];
        $res['zmdata']['nature_list'] = $nature_list;
        $wage_list = $category2['ZM_wage'];
        $res['zmdata']['wage_list'] = $wage_list;

        $trade_list = $category2['ZM_trade'];
        $res['zmdata']['trade_list'] = $trade_list;

        $category_jobs = Db::name('zimu_zhaopin_category_jobs')->field('id as value,categoryname as label')->where([['parentid','=',0]])->order(['category_order'=>'asc','id'=>'asc'])->select()->toArray();
        foreach ($category_jobs as $key => $value) {
            $category_jobs[$key]['children'] = Db::name('zimu_zhaopin_category_jobs')->field('id as value,categoryname as label')->where([['parentid','=',$value['value']]])->order(['category_order'=>'asc','id'=>'asc'])->select()->toArray();
        }

        $res['zmdata']['jobcat_list'] = $category_jobs;

        $arealist = Db::name('zimu_zhaopin_area')->field('id as value,name as label')->where([['parentid','=',0]])->order(['sort'=>'asc','id'=>'asc'])->select()->toArray();

        foreach ($arealist as $key => $value) {
            $arealist[$key]['children'] = Db::name('zimu_zhaopin_area')->field('id as value,name as label')->where([['parentid','=',$value['value']]])->order(['sort'=>'asc','id'=>'asc'])->select()->toArray();

            if($zmdata['settings']['area_three']){
                foreach ($arealist[$key]['children'] as $key2 => $value2) {
                    $arealist[$key]['children'][$key2]['children'] = Db::name('zimu_zhaopin_area')->field('id as value,name as label')->where([['parentid','=',$value2['value']]])->order(['sort'=>'asc','id'=>'asc'])->select()->toArray();
                }
            }

        }
        $res['zmdata']['district_list'] = $arealist;
        $res['zmdata']['area_three'] = $zmdata['settings']['area_three'];
        $tag_list = $category2['ZM_resumetag'];
        $res['zmdata']['tag_list'] = $tag_list;

        $res['zmdata']['kefu_list'] = Db::name('zimu_zhaopin_kefu')->order(['id'=>'asc'])->column('uid as value,kefu_name as label','uid');

        $audit_tip1 = explode(PHP_EOL, trim($zmdata['settings']['audit_tip1']));
        $audit_tip2 = explode(PHP_EOL, trim($zmdata['settings']['audit_tip2']));
        foreach ($audit_tip1 as $key => $value) {
            $res['zmdata']['audit_tip1'][$key]['value'] = $value;
        }
        foreach ($audit_tip2 as $key => $value) {
            $res['zmdata']['audit_tip2'][$key]['value'] = $value;
        }

        zimu_json3($res);

    } else if ($op == 'toedit') {

        $setsqlarr = $postdata;
        $setsqlarr['addtime'] = $setsqlarr['addtime']/1000;
        $setsqlarr['stick_endtime'] = $setsqlarr['stick_endtime']/1000;
        $setsqlarr['refreshtime'] = $setsqlarr['refreshtime']/1000;
        $setsqlarr['logintime'] = $setsqlarr['logintime']/1000;

        $setsqlarr['age'] = date('Y') - $setsqlarr['birthdate'];
        $setsqlarr['tag'] = implode(',',$setsqlarr['tag']);
        $setsqlarr['tag_cn'] = implode(',',$setsqlarr['tag_cn']);
        $setsqlarr['trade'] = implode(',',$setsqlarr['trade']);
        $setsqlarr['trade_cn'] = implode(',',$setsqlarr['trade_cn']);
        if($setsqlarr['district2']){
            $setsqlarr['district'] = implode(',',$setsqlarr['district2']);
            $setsqlarr['district_cn'] = implode(',',$setsqlarr['district_cn2']);
        }
        if($setsqlarr['intention_jobs_id2']){
            $setsqlarr['intention_jobs_id'] = implode(',',$setsqlarr['intention_jobs_id2']);
            $setsqlarr['intention_jobs'] = implode(',',$setsqlarr['intention_jobs2']);
        }

        if($setsqlarr['sex']==1){
            $photo_img = $_G['siteurl'].'source/plugin/zimu_zhaopin/static/wap/images/no_photo_male.png';
        }else{
            $photo_img = $_G['siteurl'].'source/plugin/zimu_zhaopin/static/wap/images/no_photo_female.png';
        }
        $setsqlarr['photo_img'] = $setsqlarr['photo_img'] ? $setsqlarr['photo_img'] : $photo_img;
        $setsqlarr['photo'] = 1;
        $setsqlarr['def'] = 1;

        if ($postdata['id']) {
            $old = Db::name('zimu_zhaopin_resume')->where([['id','=',$postdata['id']]])->order(['id'=>'desc'])->find();
            if($postdata['audit'] != $old['audit']) {
                resume_push($postdata['id'], $postdata['audit'], $postdata['wxtpl']);
            }
            Db::name('zimu_zhaopin_resume')->where([['id','=',$postdata['id']]])->update($setsqlarr);
            Db::name('zimu_zhaopin_resume_audit')->where('uid', $postdata['uid'])->delete();
        }else{
            $setsqlarr['title'] = $language_zimu['adminss_resume_inc_php_0'] . date('Ymd');
            $setsqlarr['addtime'] = $setsqlarr['refreshtime'] = $setsqlarr['logintime'] = time();
            $newids = Db::name('zimu_zhaopin_resume')->insertGetId($setsqlarr);
        }

        Db::name('zimu_zhaopin_members')->where('uid', $postdata['uid'])->data(['blacklist' => $postdata['blacklist']])->update();

        zimu_json3($res);

    } else if ($op == 'toaudit') {

        $old = Db::name('zimu_zhaopin_resume')->where([['id','=',$postdata['ids']]])->order(['id'=>'desc'])->find();
        if($postdata['audit'] != $old['audit']){
            resume_push($postdata['ids'],$postdata['audit'],$postdata['tpl']);
        }

        $auditinfo = Db::name('zimu_zhaopin_resume_audit')->where([['uid','=',$old['uid']]])->find();
        if($auditinfo && $postdata['audit']==1){
            $auditinfo['audit'] = $postdata['audit'];
            $auditinfo['wxtpl'] = $postdata['tpl'];
            unset($auditinfo['id']);
            Db::name('zimu_zhaopin_resume')->where('id', $postdata['ids'])->data($auditinfo)->update();
        }else{
            Db::name('zimu_zhaopin_resume')->where('id', $postdata['ids'])->data(['audit' => $postdata['audit'],'wxtpl' => $postdata['tpl']])->update();
        }
        Db::name('zimu_zhaopin_resume_audit')->where('uid', $old['uid'])->delete();
        zimu_json3($res);

    }elseif($op == 'editwork' ){

        $formtxt = $postdata;
        $myresume = Db::name('zimu_zhaopin_resume')->where([['uid','=',$formtxt['uid']]])->find();

        $i_resume_work['pid'] = $formtxt['pid'];
        $i_resume_work['uid'] = $formtxt['uid'];
        $i_resume_work['startyear'] = $formtxt['startyear'];
        $i_resume_work['startmonth'] = $formtxt['startmonth'];
        if($formtxt['starttime']){
            $starttime = explode('-',$formtxt['starttime']);
            $i_resume_work['startyear'] = intval($starttime[0]);
            $i_resume_work['startmonth'] = intval($starttime[1]);
        }
        $i_resume_work['endyear'] = $formtxt['endyear'];
        $i_resume_work['endmonth'] = $formtxt['endmonth'];
        if($formtxt['endtime']){
            $endtime = explode('-',$formtxt['endtime']);
            $i_resume_work['endyear'] = intval($endtime[0]);
            $i_resume_work['endmonth'] = intval($endtime[1]);
        }
        $i_resume_work['companyname'] = $formtxt['companyname'];
        $i_resume_work['jobs'] = $formtxt['jobs'];
        $i_resume_work['achievements'] = $formtxt['achievements'];
        $i_resume_work['todate'] = $formtxt['todate'];
        if($formtxt['id']){
            Db::name('zimu_zhaopin_resume_work')->where([['id','=',$formtxt['id']]])->data($i_resume_work)->update();
        }else{
            Db::name('zimu_zhaopin_resume_work')->insert($i_resume_work);
        }
        updata_resume_percent($myresume);
        zimu_json3($res);

    }elseif($op == 'delwork' ){

        Db::name('zimu_zhaopin_resume_work')->where([['id','=',$postdata['ids']]])->delete();
        $myresume = Db::name('zimu_zhaopin_resume')->where([['uid','=',$postdata['uid']]])->find();
        updata_resume_percent($myresume);
        zimu_json3($res);

    }elseif($op == 'editedu' ){

        $formtxt = $postdata;
        $myresume = Db::name('zimu_zhaopin_resume')->where([['uid','=',$formtxt['uid']]])->find();

        $i_resume_education['pid'] = $formtxt['pid'];
        $i_resume_education['uid'] = $formtxt['uid'];
        $i_resume_education['startyear'] = $formtxt['startyear'];
        $i_resume_education['startmonth'] = $formtxt['startmonth'];
        if($formtxt['starttime']){
            $starttime = explode('-',$formtxt['starttime']);
            $i_resume_education['startyear'] = intval($starttime[0]);
            $i_resume_education['startmonth'] = intval($starttime[1]);
        }
        $i_resume_education['endyear'] = $formtxt['endyear'];
        $i_resume_education['endmonth'] = $formtxt['endmonth'];
        if($formtxt['endtime']){
            $endtime = explode('-',$formtxt['endtime']);
            $i_resume_education['endyear'] = intval($endtime[0]);
            $i_resume_education['endmonth'] = intval($endtime[1]);
        }
        $i_resume_education['school'] = $formtxt['school'];
        $i_resume_education['speciality'] = $formtxt['speciality'];
        $i_resume_education['education'] = $formtxt['education'];
        $i_resume_education['education_cn'] = $formtxt['education_cn'];
        if($formtxt['id']){
            Db::name('zimu_zhaopin_resume_education')->where([['id','=',$formtxt['id']]])->data($i_resume_education)->update();
        }else{
            Db::name('zimu_zhaopin_resume_education')->insert($i_resume_education);
        }

        updata_resume_percent($myresume);
        zimu_json3($res);

    }elseif($op == 'deledu' ){
        Db::name('zimu_zhaopin_resume_education')->where([['id','=',$postdata['ids']]])->delete();
        $myresume = Db::name('zimu_zhaopin_resume')->where([['uid','=',$postdata['uid']]])->find();
        updata_resume_percent($myresume);
        zimu_json3($res);

    }elseif($op == 'delinfo' ){

        Db::name('zimu_zhaopin_resume')->where([['uid','=',$postdata['uid']]])->delete();
        Db::name('zimu_zhaopin_resume_audit')->where([['uid','=',$postdata['uid']]])->delete();
        Db::name('zimu_zhaopin_resume_education')->where([['uid','=',$postdata['uid']]])->delete();
        Db::name('zimu_zhaopin_resume_work')->where([['uid','=',$postdata['uid']]])->delete();
        Db::name('zimu_zhaopin_personal_jobs_apply')->where([['personal_uid','=',$postdata['uid']]])->delete();
        Db::name('zimu_zhaopin_personal_focus_company')->where([['uid','=',$postdata['uid']]])->delete();
        Db::name('zimu_zhaopin_personal_favorites')->where([['personal_uid','=',$postdata['uid']]])->delete();
        Db::name('zimu_zhaopin_per_viewlog')->where([['uid','=',$postdata['uid']]])->delete();
        Db::name('zimu_zhaopin_company_down_resume')->where([['resume_id','=',$postdata['id']]])->delete();
        Db::name('zimu_zhaopin_company_favorites')->where([['resume_id','=',$postdata['id']]])->delete();
        Db::name('zimu_zhaopin_company_interview')->where([['resume_uid','=',$postdata['uid']]])->delete();
        Db::name('zimu_zhaopin_com_viewlog')->where([['rid','=',$postdata['id']]])->delete();
        zimu_json3($res);


    } else if ($op == 'quickaction') {

        $opp = addslashes($_GET['opp']);
        if($opp=='check'){
            foreach ($postdata as $key => $value) {
                $auditinfo = Db::name('zimu_zhaopin_resume_audit')->where([['uid','=',$value]])->find();
                $auditinfo['audit'] = 1;
                unset($auditinfo['id']);
                Db::name('zimu_zhaopin_resume')->where('uid', $value)->data($auditinfo)->update();
                Db::name('zimu_zhaopin_resume_audit')->where('uid', $value)->delete();
                resume_push($value,1,$language_zimu['adminss_resume_inc_php_1'],1);
            }
        }
        if($opp=='refresh'){
            Db::name('zimu_zhaopin_resume')->where([['uid','in',$postdata]])->data(['refreshtime' => time()])->update();
        }
        if($opp=='del'){
            Db::name('zimu_zhaopin_resume')->where([['uid','in',$postdata]])->delete();
            Db::name('zimu_zhaopin_resume_education')->where([['uid','in',$postdata]])->delete();
            Db::name('zimu_zhaopin_resume_work')->where([['uid','in',$postdata]])->delete();
        }
        zimu_json3($res);

    } else if ($op == 'contact_weixin') {

        Db::name('zimu_zhaopin_resume')->where('id', $postdata['id'])->data(['is_wechat' => $postdata['is_wechat'],'is_contact' => $postdata['is_contact']])->update();
        zimu_json3($res);

    }elseif($op == 'resume_copytext' ){

        $ids = intval($_GET['ids']);
        $resume = Db::name('zimu_zhaopin_resume')->where([['id','=',$ids]])->findOrEmpty();

        if($zmdata['settings']['resume_copytext']){

            if($zmdata['settings']['open_newwap']==1){
                $tourl = zp_url_replace('viewresume','rid',$ids);
            }else{
                $tourl = $_G['siteurl'].'source/plugin/zimu_zhaopin/h5/pages/resume/view?ids='.$ids;
            }

            $res['zmdata']['resume_copytext'] = preg_replace(array('/fullname/','/sex_cn/','/education_cn/','/experience_cn/','/tag_cn/','/wage_cn/','/intention_jobs/','/specialty/','/current_cn/','/age/','/district_cn/','/tourl/'), array($resume['fullname'],$resume['sex_cn'],$resume['education_cn'],$resume['experience_cn'],$resume['tag_cn'],$resume['wage_cn'],$resume['intention_jobs'],$resume['specialty'],$resume['current_cn'],$resume['age'],$resume['district_cn'],$tourl), $zmdata['settings']['resume_copytext']);

        }
        zimu_json3($res['zmdata']);

    } else {

        $wheresql = [];
        $whereraw2 = '1=1';

        $audit = intval($_GET['audit']);
        if($audit){
            if($audit==2){
                $audituids = Db::name('zimu_zhaopin_resume_audit')->column('uid');
                if($audituids){
                    $whereraw[] = '( audit = '.$audit.' )';
                    $whereraw[] = '( uid in ('.implode(',',$audituids).') )';
                    $whereraw2 = implode('or',$whereraw);
                }else{
                    $wheresql[] = ['audit','=',$audit];
                }
            }else{
                $wheresql[] = ['audit','=',$audit];
            }
        }
        $keyword = zimu_array_utf8tomy($_GET['keyword']);
        $keywordtype = intval($_GET['keywordtype']);
        if (!empty($keyword)) {
            if ($keywordtype == 1) {
                $wheresql[] = ['id','=',$keyword];
            } elseif ($keywordtype == 2) {
                $wheresql[] = ['fullname','like','%'.$keyword.'%'];
            } elseif ($keywordtype == 3) {
                $wheresql[] = ['telephone','=',$keyword];
            } elseif ($keywordtype == 4) {
                $wheresql[] = ['intention_jobs','like','%'.$keyword.'%'];
            } elseif ($keywordtype == 5) {
                $wheresql[] = ['uid','=',$keyword];
            }
        }

        $sex = intval($_GET['sex']);
        if($sex){
            $wheresql[] = ['sex','=',$sex];
        }


        $order = strip_tags($_GET['order']) ? strip_tags($_GET['order']) : 'addtime';
        $ordersql[$order] = 'desc';
        $ordersql['id'] = 'desc';
        $page = intval($_GET['page']);
        $limit = intval($_GET['limit']);
        $res = Db::name('zimu_zhaopin_resume')->where($wheresql)->whereRaw($whereraw2)->order($ordersql)->page($page,$limit)->select()->toArray();

        foreach ($res as $key => $value) {
            updata_resume_percent($value);
            $res[$key]['myapply'] = Db::name('zimu_zhaopin_personal_jobs_apply')->where([['personal_uid','=',$value['uid']]])->count();
            $res[$key]['mydown'] = Db::name('zimu_zhaopin_company_down_resume')->where([['resume_id','=',$value['id']]])->count();
            $res[$key]['auditinfo'] = Db::name('zimu_zhaopin_resume_audit')->where([['uid','=',$value['uid']]])->find();
            if($res[$key]['auditinfo']){
                $oldinfo = $res[$key];
                $diff_info = array_merge($oldinfo,$res[$key]['auditinfo']);
                $diff_info2 = array_diff_assoc($diff_info,$oldinfo);
                $res[$key]['auditinfo'] = $diff_info2;
                $res[$key]['auditinfo']['uid'] = $res[$key]['uid'];
                $res[$key]['audit'] = 2;
            }
        }

        $count = Db::name('zimu_zhaopin_resume')->where($wheresql)->order($ordersql)->count();

        zimu_json3($res,'',0,$count);

    }