<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if (!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }

    use think\Db;
    $token = addslashes($_GET['token']);
    $myuid = checktoken_admin($token);
    $op = addslashes($_GET['op']);
    $op = $op ? $op : 'list';
    $ids = intval($_GET['ids']);
    $postdata = zimu_array_utf8tomy($postdata);

    if ($op == 'zimu') {

    } else if ($op == 'edit') {

        $ids = intval($_GET['ids']);

        $res['resume'] = Db::name('zimu_zhaopin_resume')->where([['id','=',$ids]])->find();
        if($ids){
            $res['resume']['blacklist'] = Db::name('zimu_zhaopin_members')->where([['uid','=',$res['resume']['uid']]])->value('blacklist');
            $jobcategory = explode(',',$res['resume']['intention_jobs_id']);
            foreach ($jobcategory as $key => $value) {
                $jobcategory[$key] = explode('.',$value);
            }
            $res['resume']['jobcategory'] = $jobcategory;

            $area2 = explode(',',$res['resume']['district']);
            foreach ($area2 as $key => $value) {
                $area2[$key] = explode('.',$value);
                if($zmdata['settings']['area_three']!=1){
                    unset($area2[$key][2]);
                }
                if(!$area2[$key][1]){
                    unset($area2[$key][1]);
                }
            }
            $res['resume']['area2'] = $area2;
            $work_list = Db::name('zimu_zhaopin_resume_work')->where([['uid','=',$res['resume']['uid']]])->order(['id'=>'desc'])->select()->toArray();
            $res['resume']['work_list'] = _get_duration($work_list);

            $edulist = Db::name('zimu_zhaopin_resume_education')->where([['uid','=',$res['resume']['uid']]])->order(['id'=>'desc'])->select()->toArray();
            $res['resume']['edulist'] = _get_duration($edulist);
        }


        $category = Db::name('zimu_zhaopin_category')->order(['c_order'=>'asc','c_id'=>'asc'])->select()->toArray();

        foreach ($category as $key => $value) {
            $category2[$value['c_alias']][$value['c_id']]['value'] = $value['c_id'];
            $category2[$value['c_alias']][$value['c_id']]['label'] = $value['c_name'];
        }

        $education_list = $category2['ZM_education'];
        $res['zmdata']['education_list'] = $education_list;
        $experience_list = $category2['ZM_experience'];
        $res['zmdata']['experience_list'] = $experience_list;
        $current_list = $category2['ZM_current'];
        $res['zmdata']['current_list'] = $current_list;
        $nature_list = $category2['ZM_jobs_nature'];
        $res['zmdata']['nature_list'] = $nature_list;
        $wage_list = $category2['ZM_wage'];
        $res['zmdata']['wage_list'] = $wage_list;

        $trade_list = $category2['ZM_trade'];
        $res['zmdata']['trade_list'] = $trade_list;

        $category_jobs = Db::name('zimu_zhaopin_category_jobs')->field('id as value,categoryname as label')->where([['parentid','=',0]])->order(['category_order'=>'asc','id'=>'asc'])->select()->toArray();
        foreach ($category_jobs as $key => $value) {
            $category_jobs[$key]['children'] = Db::name('zimu_zhaopin_category_jobs')->field('id as value,categoryname as label')->where([['parentid','=',$value['value']]])->order(['category_order'=>'asc','id'=>'asc'])->select()->toArray();
        }

        $res['zmdata']['jobcat_list'] = $category_jobs;

        $arealist = Db::name('zimu_zhaopin_area')->field('id as value,name as label')->where([['parentid','=',0]])->order(['sort'=>'asc','id'=>'asc'])->select()->toArray();

        foreach ($arealist as $key => $value) {
            $arealist[$key]['children'] = Db::name('zimu_zhaopin_area')->field('id as value,name as label')->where([['parentid','=',$value['value']]])->order(['sort'=>'asc','id'=>'asc'])->select()->toArray();

            if($zmdata['settings']['area_three']){
                foreach ($arealist[$key]['children'] as $key2 => $value2) {
                    $arealist[$key]['children'][$key2]['children'] = Db::name('zimu_zhaopin_area')->field('id as value,name as label')->where([['parentid','=',$value2['value']]])->order(['sort'=>'asc','id'=>'asc'])->select()->toArray();
                }
            }

        }
        $res['zmdata']['district_list'] = $arealist;
        $res['zmdata']['area_three'] = $zmdata['settings']['area_three'];
        $tag_list = $category2['ZM_resumetag'];
        $res['zmdata']['tag_list'] = $tag_list;

        $res['zmdata']['kefu_list'] = Db::name('zimu_zhaopin_kefu')->order(['id'=>'asc'])->column('uid as value,kefu_name as label','uid');

        zimu_json3($res);

    } else if ($op == 'toedit') {

        $setsqlarr = $postdata;
        $setsqlarr['addtime'] = $setsqlarr['addtime']/1000;
        $setsqlarr['stick_endtime'] = $setsqlarr['stick_endtime']/1000;
        $setsqlarr['refreshtime'] = $setsqlarr['refreshtime']/1000;
        $setsqlarr['logintime'] = $setsqlarr['logintime']/1000;

        $setsqlarr['age'] = date('Y') - $setsqlarr['birthdate'];
        $setsqlarr['tag'] = implode(',',$setsqlarr['tag']);
        $setsqlarr['tag_cn'] = implode(',',$setsqlarr['tag_cn']);
        $setsqlarr['trade'] = implode(',',$setsqlarr['trade']);
        $setsqlarr['trade_cn'] = implode(',',$setsqlarr['trade_cn']);
        if($setsqlarr['district2']){
            $setsqlarr['district'] = implode(',',$setsqlarr['district2']);
            $setsqlarr['district_cn'] = implode(',',$setsqlarr['district_cn2']);
        }
        if($setsqlarr['intention_jobs_id2']){
            $setsqlarr['intention_jobs_id'] = implode(',',$setsqlarr['intention_jobs_id2']);
            $setsqlarr['intention_jobs'] = implode(',',$setsqlarr['intention_jobs2']);
        }

        if($setsqlarr['sex']==1){
            $photo_img = $_G['siteurl'].'source/plugin/zimu_zhaopin/static/wap/images/no_photo_male.png';
        }else{
            $photo_img = $_G['siteurl'].'source/plugin/zimu_zhaopin/static/wap/images/no_photo_female.png';
        }
        $setsqlarr['photo_img'] = $setsqlarr['photo_img'] ? $setsqlarr['photo_img'] : $photo_img;
        $setsqlarr['photo'] = 1;
        $setsqlarr['def'] = 1;

        if ($postdata['id']) {
            Db::name('zimu_zhaopin_resume')->where([['id','=',$postdata['id']]])->update($setsqlarr);
        }else{
            $setsqlarr['title'] = $language_zimu['adminss_urm_inc_php_0'] . date('Ymd');
            $setsqlarr['addtime'] = $setsqlarr['refreshtime'] = $setsqlarr['logintime'] = time();
            $newids = Db::name('zimu_zhaopin_resume')->insertGetId($setsqlarr);
        }

        Db::name('zimu_zhaopin_members')->where('uid', $postdata['uid'])->data(['blacklist' => $postdata['blacklist']])->update();

        zimu_json3($res);

    } else if ($op == 'toaudit') {

        $postdata = zimu_array_utf8tomy($postdata);
        Db::name('zimu_zhaopin_resume')->where('id', $postdata['ids'])->data(['audit' => $postdata['audit'],'wxtpl' => $postdata['tpl']])->update();
        zimu_json3($res);

    }elseif($op == 'editwork' ){

        $formtxt = zimu_array_utf8tomy($postdata);
        $myresume = Db::name('zimu_zhaopin_resume')->where([['uid','=',$formtxt['uid']]])->find();

        $i_resume_work['pid'] = $formtxt['pid'];
        $i_resume_work['uid'] = $formtxt['uid'];
        $i_resume_work['startyear'] = $formtxt['startyear'];
        $i_resume_work['startmonth'] = $formtxt['startmonth'];
        if($formtxt['starttime']){
            $starttime = explode('-',$formtxt['starttime']);
            $i_resume_work['startyear'] = intval($starttime[0]);
            $i_resume_work['startmonth'] = intval($starttime[1]);
        }
        $i_resume_work['endyear'] = $formtxt['endyear'];
        $i_resume_work['endmonth'] = $formtxt['endmonth'];
        if($formtxt['endtime']){
            $endtime = explode('-',$formtxt['endtime']);
            $i_resume_work['endyear'] = intval($endtime[0]);
            $i_resume_work['endmonth'] = intval($endtime[1]);
        }
        $i_resume_work['companyname'] = $formtxt['companyname'];
        $i_resume_work['jobs'] = $formtxt['jobs'];
        $i_resume_work['achievements'] = $formtxt['achievements'];
        $i_resume_work['todate'] = $formtxt['todate'];
        if($formtxt['id']){
            Db::name('zimu_zhaopin_resume_work')->where([['id','=',$formtxt['id']]])->data($i_resume_work)->update();
        }else{
            Db::name('zimu_zhaopin_resume_work')->insert($i_resume_work);
        }
        updata_resume_percent($myresume);
        zimu_json3($res);

    }elseif($op == 'delwork' ){

        Db::name('zimu_zhaopin_resume_work')->where([['id','=',$postdata['ids']]])->delete();
        $myresume = Db::name('zimu_zhaopin_resume')->where([['uid','=',$postdata['uid']]])->find();
        updata_resume_percent($myresume);
        zimu_json3($res);

    }elseif($op == 'editedu' ){

        $formtxt = $postdata;
        $myresume = Db::name('zimu_zhaopin_resume')->where([['uid','=',$formtxt['uid']]])->find();

        $i_resume_education['pid'] = $formtxt['pid'];
        $i_resume_education['uid'] = $formtxt['uid'];
        $i_resume_education['startyear'] = $formtxt['startyear'];
        $i_resume_education['startmonth'] = $formtxt['startmonth'];
        if($formtxt['starttime']){
            $starttime = explode('-',$formtxt['starttime']);
            $i_resume_education['startyear'] = intval($starttime[0]);
            $i_resume_education['startmonth'] = intval($starttime[1]);
        }
        $i_resume_education['endyear'] = $formtxt['endyear'];
        $i_resume_education['endmonth'] = $formtxt['endmonth'];
        if($formtxt['endtime']){
            $endtime = explode('-',$formtxt['endtime']);
            $i_resume_education['endyear'] = intval($endtime[0]);
            $i_resume_education['endmonth'] = intval($endtime[1]);
        }
        $i_resume_education['school'] = $formtxt['school'];
        $i_resume_education['speciality'] = $formtxt['speciality'];
        $i_resume_education['education'] = $formtxt['education'];
        $i_resume_education['education_cn'] = $formtxt['education_cn'];
        if($formtxt['id']){
            Db::name('zimu_zhaopin_resume_education')->where([['id','=',$formtxt['id']]])->data($i_resume_education)->update();
        }else{
            Db::name('zimu_zhaopin_resume_education')->insert($i_resume_education);
        }

        updata_resume_percent($myresume);
        zimu_json3($res);

    }elseif($op == 'deledu' ){
        Db::name('zimu_zhaopin_resume_education')->where([['id','=',$postdata['ids']]])->delete();
        $myresume = Db::name('zimu_zhaopin_resume')->where([['uid','=',$postdata['uid']]])->find();
        updata_resume_percent($myresume);
        zimu_json3($res);

    }elseif($op == 'getdata' ){

        $paramter = Db::name('zimu_zhaopin_parameter2')->where([['name','=','crm_companyset']])->order(['id'=>'asc'])->findOrEmpty();

        $crm_companyset = unserialize($paramter['parameter']);
        $crm_companyset['funnel'] = explode(',', $crm_companyset['company_funnel']);
        $crm_companyset['level'] = explode(',', $crm_companyset['company_level']);
        $crm_companyset['feedback'] = explode(',', $crm_companyset['company_feedback']);
        $crm_companyset['service'] = explode(',', $crm_companyset['company_service']);
        $zmdata['crm_companyset'] = $crm_companyset;

        $paramter = Db::name('zimu_zhaopin_parameter2')->where([['name','=','crm_resumeset']])->order(['id'=>'asc'])->findOrEmpty();

        $crm_resumeset = unserialize($paramter['parameter']);
        $crm_resumeset['funnel'] = explode(',', $crm_resumeset['person_funnel']);
        $crm_resumeset['level'] = explode(',', $crm_resumeset['person_level']);
        $crm_resumeset['feedback'] = explode(',', $crm_resumeset['person_feedback']);
        $crm_resumeset['service'] = explode(',', $crm_resumeset['person_service']);
        $zmdata['crm_resumeset'] = $crm_resumeset;

        zimu_json3($zmdata);

    }elseif($op == 'feedbacklist' ){

        $wheresql = [];
        $audit = intval($_GET['audit']);
        if($audit){
            $wheresql[] = ['audit','=',$audit];
        }
        $keyword = zimu_array_utf8tomy($_GET['keyword']);
        $keywordtype = intval($_GET['keywordtype']);
        if (!empty($keyword)) {
            if ($keywordtype == 1) {
                $wheresql[] = ['id','=',$keyword];
            } elseif ($keywordtype == 2) {
                $wheresql[] = ['fullname','like','%'.$keyword.'%'];
            } elseif ($keywordtype == 3) {
                $wheresql[] = ['telephone','=',$keyword];
            } elseif ($keywordtype == 4) {
                $wheresql[] = ['intention_jobs','like','%'.$keyword.'%'];
            } elseif ($keywordtype == 5) {
                $wheresql[] = ['uid','=',$keyword];
            }
        }

        $page = intval($_GET['page']);
        $limit = intval($_GET['limit']);
        $res = Db::name('zimu_zhaopin_crm_custom_feedback')->where($wheresql)->order(['id'=>'desc'])->page($page,$limit)->select()->toArray();

        foreach ($res as $key => $value) {
            if($value['custom_type']==1){
                $res[$key]['info'] = Db::name('zimu_zhaopin_company_profile')->where([['id','=',$value['custom_id']]])->findOrEmpty();
                $res[$key]['crminfo'] = Db::name('zimu_zhaopin_crm_company')->where([['com_id','=',$value['custom_id']]])->findOrEmpty();
            }
            if($value['custom_type']==2){
                $res[$key]['info'] = Db::name('zimu_zhaopin_resume')->where([['id','=',$value['custom_id']]])->findOrEmpty();
                $res[$key]['crminfo'] = Db::name('zimu_zhaopin_crm_person')->where([['resume_id','=',$value['custom_id']]])->findOrEmpty();
            }
            if(!$res[$key]['info']){
                unset($res[$key]);
            }
        }
        array_multisort($res,SORT_DESC);
        $count = Db::name('zimu_zhaopin_crm_custom_feedback')->where($wheresql)->count();

        zimu_json3($res,'',0,$count);


    } else {

        $wheresql = [];
        $audit = intval($_GET['audit']);
        if($audit){
            $wheresql[] = ['audit','=',$audit];
        }
        $keyword = zimu_array_utf8tomy($_GET['keyword']);
        $keywordtype = intval($_GET['keywordtype']);
        if (!empty($keyword)) {
            if ($keywordtype == 1) {
                $wheresql[] = ['id','=',$keyword];
            } elseif ($keywordtype == 2) {
                $wheresql[] = ['fullname','like','%'.$keyword.'%'];
            } elseif ($keywordtype == 3) {
                $wheresql[] = ['telephone','=',$keyword];
            } elseif ($keywordtype == 4) {
                $wheresql[] = ['intention_jobs','like','%'.$keyword.'%'];
            } elseif ($keywordtype == 5) {
                $wheresql[] = ['uid','=',$keyword];
            }
        }

        $order = strip_tags($_GET['order']) ? strip_tags($_GET['order']) : 'addtime';
        $ordersql[$order] = 'desc';
        $ordersql['id'] = 'desc';
        $page = intval($_GET['page']);
        $limit = intval($_GET['limit']);
        $res = Db::name('zimu_zhaopin_resume')->where($wheresql)->order($ordersql)->page($page,$limit)->select()->toArray();

        foreach ($res as $key => $value) {
            $res[$key]['myapply'] = Db::name('zimu_zhaopin_personal_jobs_apply')->where([['personal_uid','=',$value['uid']]])->count();
            $res[$key]['mydown'] = Db::name('zimu_zhaopin_company_down_resume')->where([['resume_id','=',$value['id']]])->count();
        }

        $count = Db::name('zimu_zhaopin_resume')->where($wheresql)->order($ordersql)->count();

        zimu_json3($res,'',0,$count);

    }