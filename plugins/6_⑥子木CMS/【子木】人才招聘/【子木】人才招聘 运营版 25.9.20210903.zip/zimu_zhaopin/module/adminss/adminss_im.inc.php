<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if (!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }

    use think\Db;
    $token = addslashes($_GET['token']);
    $myuid = checktoken_admin($token);
    $op = addslashes($_GET['op']);
    $op = $op ? $op : 'list';
    $ids = intval($_GET['ids']);
    $postdata = zimu_array_utf8tomy($postdata);

    if(!file_exists(DISCUZ_ROOT . './source/plugin/zimu_zhaopin/module/adminss/adminss_imconfig.inc.php')){
        zimu_json3($res,'imchat error',201);
    }

    if ($op == 'zimu') {

    } else if ($op == 'edit') {


    }elseif($op == 'getreport' ){

        $todaytime = strtotime(date('Y-m-d', time()));
        $res['zmdata']['all_online'] = Db::name('zimu_zhaopin_members')->where([['onlinetime','>',time()-600]])->count();
        $today_online_uid = Db::name('zimu_zhaopin_members')->where([['onlinetime','>',$todaytime]])->column('uid');
        $res['zmdata']['all_chat_online'] = Db::name('zimu_zhaopin_im_message')->where([['addtime','>',$todaytime]])->group('uid')->count();
        $res['zmdata']['all_chat_online_company'] = Db::name('zimu_zhaopin_im_message')->where([['utype','=',1],['addtime','>',$todaytime]])->group('uid')->count();
        $res['zmdata']['all_chat_online_resume'] = Db::name('zimu_zhaopin_im_message')->where([['utype','=',2],['addtime','>',$todaytime]])->group('uid')->count();
        $res['zmdata']['all_message'] = Db::name('zimu_zhaopin_im_message')->where([['addtime','>',$todaytime]])->count();

        zimu_json3($res);

    }elseif($op == 'getreport_chart' ){

        if($postdata['datetype'] && $postdata['type']=='chatuser'){
            $todaytime = strtotime(date('Y-m-d', time()))+86400;
            for ($i=0; $i<$postdata['datetype']; $i++) {
                $begintime = $todaytime-(($postdata['datetype']-$i)*86400);
                $endtime = $todaytime-(($postdata['datetype']-$i)*86400)+86400;
                $res[$i]['time'] = date('m-d', $begintime);
                $res[$i]['company'] = Db::name('zimu_zhaopin_im_message')->where([['utype','=',1],['addtime','>',$begintime],['addtime','<',$endtime]])->group('uid')->count();
                $res[$i]['resume'] = Db::name('zimu_zhaopin_im_message')->where([['utype','=',2],['addtime','>',$begintime],['addtime','<',$endtime]])->group('uid')->count();
            }
        }

        if($postdata['datetype'] && $postdata['type']=='message'){
            $todaytime = strtotime(date('Y-m-d', time()))+86400;
            for ($i=0; $i<$postdata['datetype']; $i++) {
                $begintime = $todaytime-(($postdata['datetype']-$i)*86400);
                $endtime = $todaytime-(($postdata['datetype']-$i)*86400)+86400;
                $res[$i]['time'] = date('m-d', $begintime);
                $res[$i]['company'] = Db::name('zimu_zhaopin_im_message')->where([['utype','=',1],['addtime','>',$begintime],['addtime','<',$endtime]])->count();
                $res[$i]['resume'] = Db::name('zimu_zhaopin_im_message')->where([['utype','=',2],['addtime','>',$begintime],['addtime','<',$endtime]])->count();
            }
        }

        zimu_json3($res);

    }elseif($op == 'getimopen' ){

        if(file_exists(DISCUZ_ROOT . './source/plugin/zimu_zhaopin/module/adminss/adminss_imconfig.inc.php')){
            $res['showim'] = 1;
        }
        zimu_json3($res);
    }elseif($op == 'messagelist' ){

        $wheresql = [];
        $uid = intval($_GET['uid']);
        if($uid){
            $wheresql[] = ['uid','=',$uid];
        }
        $touid = intval($_GET['touid']);
        if($touid){
            $wheresql[] = ['touid','=',$touid];
        }

        $keyword = zimu_array_utf8tomy($_GET['keyword']);
        if (!empty($keyword)) {
            $wheresql[] = ['message','like','%'.$keyword.'%'];
        }

        $page = intval($_GET['page']);
        $limit = intval($_GET['limit']);

        $res = Db::name('zimu_zhaopin_im_message')->where($wheresql)->order(['id'=>'desc'])->page($page,$limit)->select()->toArray();

        foreach ($res as $key => $value) {
            if($value['utype']==1){
                $res[$key]['uidinfo'] = Db::name('zimu_zhaopin_company_profile')->where([['uid','=',$value['uid']]])->order(['id'=>'desc'])->find();
                $res[$key]['touidinfo'] = Db::name('zimu_zhaopin_resume')->where([['uid','=',$value['touid']]])->order(['id'=>'desc'])->find();
            }
            if($value['utype']==2){
                $res[$key]['touidinfo'] = Db::name('zimu_zhaopin_company_profile')->where([['uid','=',$value['touid']]])->order(['id'=>'desc'])->find();
                $res[$key]['uidinfo'] = Db::name('zimu_zhaopin_resume')->where([['uid','=',$value['uid']]])->order(['id'=>'desc'])->find();
            }
        }


        $count = Db::name('zimu_zhaopin_im_message')->where($wheresql)->order($ordersql)->count();
        zimu_json3($res,'',0,$count);

    }elseif($op == 'delmsg' ){
        Db::name('zimu_zhaopin_im_message')->where([['id','=',$postdata['ids']]])->delete();
        zimu_json3($res);

    } else {



    }