<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if (!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }
    use think\Db;
    $token = addslashes($_GET['token']);
    $myuid = checktoken_admin($token);
    $op = addslashes($_GET['op']);
    $op = $op ? $op : 'list';

    if ($op == 'edit') {

        $ids = intval($postdata['id']);
        $postdata = zimu_array_utf8tomy($postdata);

        $data['title'] = strip_tags($postdata['title']) ? strip_tags($postdata['title']) : $zmdata['title'];
        $data['keywords'] = strip_tags($postdata['keywords']) ? strip_tags($postdata['keywords']) : $zmdata['keywords'];
        $data['description'] = strip_tags($postdata['description']) ? strip_tags($postdata['description']) : $zmdata['description'];
        $data['logo'] = strip_tags($postdata['settings']['pc_logo_url']) ? strip_tags($postdata['settings']['pc_logo_url']) : $zmdata['logo'];
        $data['share_title'] = strip_tags($postdata['share_title']) ? strip_tags($postdata['share_title']) : $zmdata['share_title'];
        $data['share_desc'] = strip_tags($postdata['share_desc']) ? strip_tags($postdata['share_desc']) : $zmdata['share_desc'];
        $data['share_thumb'] = strip_tags($postdata['share_thumb']) ? strip_tags($postdata['share_thumb']) : $zmdata['share_thumb'];
        $data['weixin_appid'] = strip_tags($postdata['weixin_appid']) ? strip_tags($postdata['weixin_appid']) : $zmdata['weixin_appid'];
        $data['weixin_appsecret'] = strip_tags($postdata['weixin_appsecret']) ? strip_tags($postdata['weixin_appsecret']) : $zmdata['weixin_appsecret'];

        if ($ids) {
            $settings = $zmdata['settings'];
        }

        if($settings){
            $newsettings = array_merge($settings,$postdata['settings']);
        }else{
            $newsettings = $postdata['settings'];
        }

        $data['settings'] = serialize($newsettings);

        if($ids>0){
            Db::name('zimu_zhaopin_setting')->where('id', $ids)->data($data)->update();
        }else{
            Db::name('zimu_zhaopin_setting')->insert($data);
        }

        zimu_json3($res);

    } else if ($op == 'toparameter2') {

        $name = strip_tags($_GET['name']);
        $isadd = Db::name('zimu_zhaopin_parameter2')->where('name', $name)->order('id','desc')->find();
        $data['parameter'] = serialize(zimu_array_utf8tomy($postdata));
        if($isadd){
            Db::name('zimu_zhaopin_parameter2')->where('id', $isadd['id'])->data($data)->update();
        }else{
            $data['name'] = $name;
            Db::name('zimu_zhaopin_parameter2')->insert($data);
        }
        zimu_json3($res);

    } else if ($op == 'getparameter2') {
        $name = strip_tags($_GET['name']);
        $isadd = Db::name('zimu_zhaopin_parameter2')->where('name', $name)->order('id','desc')->find();
        $res = unserialize($isadd['parameter']);
        zimu_json3($res);

    } else {

        $setdata = Db::name('zimu_zhaopin_setting')->order('id','desc')->findOrEmpty();
        $zmdata['settings'] = unserialize($setdata['settings']);
        $res['base'] = $zmdata['base'];
        unset($res['base']['settings']);
        $res['settings'] = $zmdata['settings'];

        $magapp = Db::name('zimu_zhaopin_parameter2')->where('name', 'magapp')->order('id','desc')->findOrEmpty();
        $res['magapp'] = unserialize($magapp['parameter']);
        $qfapp = Db::name('zimu_zhaopin_parameter2')->where('name', 'qfapp')->order('id','desc')->findOrEmpty();
        $res['qfapp'] = unserialize($qfapp['parameter']);
        $aliyunsms = Db::name('zimu_zhaopin_parameter2')->where('name', 'aliyunsms')->order('id','desc')->findOrEmpty();
        $res['aliyunsms'] = unserialize($aliyunsms['parameter']);
        $alioss = Db::name('zimu_zhaopin_parameter2')->where('name', 'alioss')->order('id','desc')->findOrEmpty();
        $res['alioss'] = unserialize($alioss['parameter']);
        $wxtpl = Db::name('zimu_zhaopin_parameter2')->where('name', 'wxtpl')->order('id','desc')->findOrEmpty();
        $res['wxtpl'] = unserialize($wxtpl['parameter']);
        $qcaptcha = Db::name('zimu_zhaopin_parameter2')->where('name', 'qcaptcha')->order('id','desc')->findOrEmpty();
        $res['qcaptcha'] = unserialize($qcaptcha['parameter']);
        $agreement = Db::name('zimu_zhaopin_parameter2')->where('name', 'agreement')->order('id','desc')->findOrEmpty();
        $res['agreement'] = unserialize($agreement['parameter']);
        zimu_json3($res);
    }