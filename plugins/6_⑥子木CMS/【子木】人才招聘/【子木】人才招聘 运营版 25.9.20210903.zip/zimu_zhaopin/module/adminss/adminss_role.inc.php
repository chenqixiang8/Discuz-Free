<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if (!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }
    use think\Db;
    $token = addslashes($_GET['token']);
    $myuid = checktoken_admin($token);
    $op = addslashes($_GET['op']);
    $op = $op ? $op : 'list';

    if ($op == 'edit') {

        $ids = intval($postdata['id']);
        $postdata = zimu_array_utf8tomy($postdata);

        if($ids>0){
            Db::name('zimu_zhaopin_admin_role')->where('id', $ids)->data($postdata)->update();
        }else{
            $postdata['addtime'] = time();
            Db::name('zimu_zhaopin_admin_role')->insert($postdata);
        }

        zimu_json3($res);

    } else if ($op == 'del') {

        $ids = intval($_GET['roleid']);
        Db::name('zimu_zhaopin_admin_role')->where([['id','=',$ids]])->delete();

        zimu_json3($res);

    } else if ($op == 'menu') {

        $res = Db::name('zimu_zhaopin_menus')->order(['id'=>'asc'])->select()->toArray();
        $ids = intval($_GET['roleid']);
        $role = Db::name('zimu_zhaopin_admin_role')->where([['id','=',$ids]])->find();
        $role = unserialize($role['access']);
        foreach ($res as $key => $value) {
            $res[$key]['checked'] = in_array($value['id'], $role) ? true : false;
        }

        zimu_json3($res);

    } else if ($op == 'tomenu') {

        $ids = intval($_GET['roleid']);
        $postdata2['access'] = serialize($postdata);
        Db::name('zimu_zhaopin_admin_role')->where('id', $ids)->data($postdata2)->update();

        zimu_json3($res);

    } else {

        $wheresql = [];
        $page = intval($_GET['page']);
        $limit = intval($_GET['limit']);

        $res = Db::name('zimu_zhaopin_admin_role')->where($wheresql)->order(['id'=>'asc'])->page($page,$limit)->select()->toArray();

        $count = Db::name('zimu_zhaopin_admin_role')->where($wheresql)->order($ordersql)->count();
        zimu_json3($res,'',0,$count);

    }