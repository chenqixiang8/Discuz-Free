<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if (!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }

    use think\Db;
    $token = addslashes($_GET['token']);
    $myuid = checktoken_admin($token);
    $op = addslashes($_GET['op']);
    $op = $op ? $op : 'list';


    if ($op == 'zimu') {

    } else if ($op == 'edit') {

        $ids = intval($_GET['ids']);

        $res['jobs'] = Db::name('zimu_zhaopin_jobs')->where([['id','=',$ids]])->find();
        $auditinfo = Db::name('zimu_zhaopin_jobs_audit')->where('ids', $ids)->find();
        if($auditinfo){
            unset($auditinfo['id']);
            $res['jobs'] = array_merge($res['jobs'],$auditinfo);
        }
        $category_jobs = Db::name('zimu_zhaopin_category_jobs')->field('id as value,categoryname as label')->where([['parentid','=',0]])->order(['category_order'=>'asc','id'=>'asc'])->select()->toArray();

        foreach ($category_jobs as $key => $value) {
            $category_jobs[$key]['children'] = Db::name('zimu_zhaopin_category_jobs')->field('id as value,categoryname as label')->where([['parentid','=',$value['value']]])->order(['category_order'=>'asc','id'=>'asc'])->select()->toArray();
        }

        $res['zmdata']['jobcat_list'] = $category_jobs;

        $category = Db::name('zimu_zhaopin_category')->order(['c_order'=>'asc','c_id'=>'asc'])->select()->toArray();

        foreach ($category as $key => $value) {
            $category2[$value['c_alias']][$value['c_id']]['value'] = $value['c_id'];
            $category2[$value['c_alias']][$value['c_id']]['label'] = $value['c_name'];
        }

        $education_list = $category2['ZM_education'];
        $res['zmdata']['education_list'] = $education_list;
        $experience_list = $category2['ZM_experience'];
        $res['zmdata']['experience_list'] = $experience_list;
        $nature_list = $category2['ZM_jobs_nature'];
        $res['zmdata']['nature_list'] = $nature_list;

        $arealist = Db::name('zimu_zhaopin_area')->field('id as value,name as label')->where([['parentid','=',0]])->order(['sort'=>'asc','id'=>'asc'])->select()->toArray();

        foreach ($arealist as $key => $value) {
            $arealist[$key]['children'] = Db::name('zimu_zhaopin_area')->field('id as value,name as label')->where([['parentid','=',$value['value']]])->order(['sort'=>'asc','id'=>'asc'])->select()->toArray();

            if($zmdata['settings']['area_three']){
                foreach ($arealist[$key]['children'] as $key2 => $value2) {
                    $arealist[$key]['children'][$key2]['children'] = Db::name('zimu_zhaopin_area')->field('id as value,name as label')->where([['parentid','=',$value2['value']]])->order(['sort'=>'asc','id'=>'asc'])->select()->toArray();
                }
            }

        }
        $res['zmdata']['district_list'] = $arealist;
        $res['zmdata']['area_three'] = $zmdata['settings']['area_three'];

        $tag_list = $category2['ZM_jobtag'];
        $res['zmdata']['tag_list'] = $tag_list;
        $audit_tip1 = explode(PHP_EOL, trim($zmdata['settings']['audit_tip1']));
        $audit_tip2 = explode(PHP_EOL, trim($zmdata['settings']['audit_tip2']));
        foreach ($audit_tip1 as $key => $value) {
            $res['zmdata']['audit_tip1'][$key]['value'] = $value;
        }
        foreach ($audit_tip2 as $key => $value) {
            $res['zmdata']['audit_tip2'][$key]['value'] = $value;
        }


        zimu_json3($res);

    } else if ($op == 'toedit') {

        $setsqlarr = zimu_array_utf8tomy($postdata);
        $setsqlarr['addtime'] = $setsqlarr['addtime']/1000;
        $setsqlarr['stick_endtime'] = $setsqlarr['stick_endtime']/1000;
        $setsqlarr['refreshtime'] = $setsqlarr['refreshtime']/1000;
        $setsqlarr['uptime'] = $setsqlarr['uptime']/1000;
        if($setsqlarr['jobcategory']){
            $setsqlarr['topclass'] = $setsqlarr['jobcategory'][0];
            $setsqlarr['category'] = $setsqlarr['jobcategory'][1];
        }
        if($setsqlarr['area2']){
            $setsqlarr['district'] = $setsqlarr['area2'][0];
            $setsqlarr['district2'] = $setsqlarr['area2'][1];
            $setsqlarr['district3'] = $setsqlarr['area2'][2];
        }
        $setsqlarr['district_cn'] = str_replace(' / ','',$setsqlarr['district_cn']);

        $setsqlarr['tag'] = implode(',',$setsqlarr['tag']);
        $setsqlarr['tag_cn'] = implode(',',$setsqlarr['tag_cn']);
        if( ($setsqlarr['minwage'] || $setsqlarr['maxwage']) && $setsqlarr['minwage'] != $setsqlarr['maxwage']){
            $setsqlarr['wage_cn'] = $setsqlarr['minwage'].'~'.$setsqlarr['maxwage'].$zmdata['settings']['money_name'].'/'.$language_zimu['adminss_job_inc_php_0'];
        }elseif( ($setsqlarr['minwage'] || $setsqlarr['maxwage']) && $setsqlarr['minwage'] == $setsqlarr['maxwage']){
            $setsqlarr['wage_cn'] = $setsqlarr['minwage'].$zmdata['settings']['money_name'].'/'.$language_zimu['adminss_job_inc_php_1'];
        }else{
            $setsqlarr['wage_cn'] = $language_zimu['adminss_job_inc_php_2'];
        }

        $company_profile = Db::name('zimu_zhaopin_company_profile')->where([['uid','=',$setsqlarr['uid']]])->find();

        $setsqlarr['companyname'] = $company_profile['companyname'];
        $setsqlarr['company_id'] = $company_profile['id'];
        $setsqlarr['company_certificate'] = $company_profile['certificate_img_audit'];
        $setsqlarr['company_mingqi'] = $company_profile['company_mingqi'];
        $setsqlarr['trade'] = $company_profile['trade'];
        $setsqlarr['trade_cn'] = $company_profile['trade_cn'];
        $setsqlarr['scale'] = $company_profile['scale'];
        $setsqlarr['scale_cn'] = $company_profile['scale_cn'];
        $setsqlarr['setmeal_id'] = $company_profile['setmeal_id'];
        $setsqlarr['setmeal_name'] = $company_profile['setmeal_name'];

        if($setsqlarr['id']){
            $old = Db::name('zimu_zhaopin_jobs')->where([['id','=',$setsqlarr['id']]])->order(['id'=>'desc'])->find();
            if($setsqlarr['audit'] != $old['audit']) {
                jobs_push($setsqlarr['id'], $setsqlarr['audit'], $setsqlarr['wxtpl']);
            }
            Db::name('zimu_zhaopin_jobs')->where([['id','=',$setsqlarr['id']]])->update($setsqlarr);
            Db::name('zimu_zhaopin_jobs_audit')->where('ids', $setsqlarr['id'])->delete();
        }else{
            $newids = Db::name('zimu_zhaopin_jobs')->insertGetId($setsqlarr);
        }

        zimu_json3($res);

    } else if ($op == 'toaudit') {

        $postdata = zimu_array_utf8tomy($postdata);

        $old = Db::name('zimu_zhaopin_jobs')->where([['id','=',$postdata['ids']]])->order(['id'=>'desc'])->find();
        if($postdata['audit'] != $old['audit']){
            jobs_push($postdata['ids'],$postdata['audit'],$postdata['tpl']);
        }

        $auditinfo = Db::name('zimu_zhaopin_jobs_audit')->where([['ids','=',$postdata['ids']]])->find();
        if($auditinfo && $postdata['audit']==1){
            $auditinfo['audit'] = $postdata['audit'];
            $auditinfo['wxtpl'] = $postdata['tpl'];
            unset($auditinfo['id']);
            unset($auditinfo['ids']);
            Db::name('zimu_zhaopin_jobs')->where('id', $postdata['ids'])->data($auditinfo)->update();
        }else{
            Db::name('zimu_zhaopin_jobs')->where('id', $postdata['ids'])->data(['audit' => $postdata['audit'],'wxtpl' => $postdata['tpl']])->update();
        }
        Db::name('zimu_zhaopin_jobs_audit')->where('ids', $postdata['ids'])->delete();
        zimu_json3($res);


    } else if ($op == 'refreshjob') {

        Db::name('zimu_zhaopin_jobs')->where('id', $postdata['ids'])->data(['refreshtime' => time()])->update();
        zimu_json3($res);

    } else if ($op == 'getrefresh') {

        $res = Db::name('zimu_zhaopin_setmeal_increment')->where([['cat','=','auto_refresh_jobs']])->select()->toArray();
        zimu_json3($res);

    } else if ($op == 'torefreshjob') {

        $setmeal_increment = Db::name('zimu_zhaopin_setmeal_increment')->where([['id','=',$postdata['refresh']]])->find();
        $days = $setmeal_increment['value'];
        $nowtime = time();
        for ($i = 0; $i < $days * 4; $i++) {
            $timespace = 3600 * 6 * $i;
            $queue_auto_refresh['uid'] = $postdata['uid'];
            $queue_auto_refresh['pid'] = $postdata['id'];;
            $queue_auto_refresh['type'] = 1;
            $queue_auto_refresh['refreshtime'] = $nowtime + $timespace;
            Db::name('zimu_zhaopin_queue_auto_refresh')->insertGetId($queue_auto_refresh);
        }
        zimu_json3($res);

    }elseif($op == 'delinfo' ){

        Db::name('zimu_zhaopin_jobs')->where([['id','=',$postdata['ids']]])->delete();
        Db::name('zimu_zhaopin_jobs_audit')->where([['ids','=',$postdata['id']]])->delete();
        Db::name('zimu_zhaopin_company_interview')->where([['jobs_id','=',$postdata['ids']]])->delete();
        Db::name('zimu_zhaopin_personal_jobs_apply')->where([['jobs_id','=',$postdata['ids']]])->delete();
        Db::name('zimu_zhaopin_per_viewlog')->where([['jid','=',$postdata['ids']]])->delete();
        zimu_json3($res);

    } else if ($op == 'quickaction') {

        $opp = addslashes($_GET['opp']);
        if($opp=='check'){
            foreach ($postdata as $key => $value) {
                $auditinfo = Db::name('zimu_zhaopin_jobs_audit')->where([['ids','=',$value]])->find();
                $auditinfo['audit'] = 1;
                unset($auditinfo['id']);
                unset($auditinfo['ids']);
                Db::name('zimu_zhaopin_jobs')->where('id', $value)->data($auditinfo)->update();
                Db::name('zimu_zhaopin_jobs_audit')->where('ids', $value)->delete();
                jobs_push($value,1,$language_zimu['adminss_job_inc_php_3']);
            }
        }
        if($opp=='refresh'){
            Db::name('zimu_zhaopin_jobs')->where([['id','in',$postdata]])->data(['refreshtime' => time()])->update();
        }
        if($opp=='del'){
            Db::name('zimu_zhaopin_jobs')->where([['id','in',$postdata]])->delete();
        }
        zimu_json3($res);


    }elseif($op == 'job_copytext' ){

        if($zmdata['settings']['job_copytext']){

            $ids = intval($_GET['ids']);

            $job = Db::name('zimu_zhaopin_jobs')->where([['id','=',$ids]])->select()->toArray();
            $job1 = $job[0];


            if($zmdata['settings']['open_newwap']==1){
                $tourl = zp_url_replace('viewjob','jid',$ids);
            }else{
                $tourl = $_G['siteurl'].'source/plugin/zimu_zhaopin/h5/pages/jobs/view?ids='.$ids;
            }

            $res['zmdata']['job_copytext'] = preg_replace(array(
                '/jobs_name/',
                '/wage_cn/',
                '/amount/',
                '/experience_cn/',
                '/education_cn/',
                '/sex_cn/',
                '/district_cn/',
                '/companyname/',
                '/tag_cn/',
                '/contents/',
                '/tourl/'
            ), array(
                $job[0]['jobs_name'],
                $job[0]['wage_cn'],
                $job[0]['amount'],
                $job[0]['experience_cn'],
                $job[0]['education_cn'],
                $job[0]['sex_cn'],
                '['.$job[0]['district_cn'].']'.$res['company']['address'],
                $job[0]['companyname'],
                $job[0]['tag_cn'],
                $job[0]['contents'],
                $tourl
            ), $zmdata['settings']['job_copytext']);

        }

        zimu_json3($res['zmdata']);

    } else {

        $wheresql = [];
        $whereraw2 = '1=1';
        $kefu_uid = get_kefu_uid($token);
        if($kefu_uid){
            $com_ids = Db::name('zimu_zhaopin_company_profile')->where([['kefu_uid','=',$kefu_uid]])->column('id');
            $wheresql[] = ['company_id','in',$com_ids];
        }


        $audit = intval($_GET['audit']);
        if($audit){
            if($audit==2){
                $audituids = Db::name('zimu_zhaopin_jobs_audit')->column('ids');
                if($audituids){
                    $whereraw[] = '( audit = '.$audit.' )';
                    $whereraw[] = '( id in ('.implode(',',$audituids).') )';
                    $whereraw2 = implode('or',$whereraw);
                }else{
                    $wheresql[] = ['audit','=',$audit];
                }
            }else{
                $wheresql[] = ['audit','=',$audit];
            }
        }
        $setmeal_id = intval($_GET['setmeal_id']);
        if (!empty($setmeal_id) && $setmeal_id!=99) {
            $wheresql[] = ['setmeal_id','>',$setmeal_id];
        }

        $display = intval($_GET['display']);
        if($display){
            $wheresql[] = ['display','=',$display];
        }

        $nature = intval($_GET['nature']);
        if($nature){
            $wheresql[] = ['nature','=',$nature];
        }
        $sex = intval($_GET['sex']);
        if($sex){
            $wheresql[] = ['sex','=',$sex];
        }

        $iszhiding = intval($_GET['iszhiding']);
        if ($iszhiding==1) {
            $wheresql[] = ['stick_endtime','>',$sex];
        }

        $keyword = zimu_array_utf8tomy($_GET['keyword']);
        $keywordtype = intval($_GET['keywordtype']);
        if (!empty($keyword)) {
            if ($keywordtype == 1) {
                $wheresql[] = ['id','=',$keyword];
            } elseif ($keywordtype == 2) {
                $wheresql[] = ['jobs_name','like','%'.$keyword.'%'];
            } elseif ($keywordtype == 3) {
                $wheresql[] = ['company_id','=',$keyword];
            } elseif ($keywordtype == 4) {
                $wheresql[] = ['companyname','like','%'.$keyword.'%'];
            } elseif ($keywordtype == 5) {
                $wheresql[] = ['uid', '=', $keyword];
            } elseif ($keywordtype == 10) {
                if(is_numeric($keyword)){
                    $wheresql[] = ['id','=',$keyword];
                }else{
                    $wheresql[] = ['jobs_name','like','%'.$keyword.'%'];
                }
            }
        }

        $order = strip_tags($_GET['order']) ? strip_tags($_GET['order']) : 'addtime';
        $ordersql[$order] = 'desc';
        $ordersql['id'] = 'desc';
        $page = intval($_GET['page']);
        $limit = intval($_GET['limit']);
        $res = Db::name('zimu_zhaopin_jobs')->where($wheresql)->whereRaw($whereraw2)->order($ordersql)->page($page,$limit)->select()->toArray();

        foreach ($res as $key => $value) {
            $res[$key]['company'] = Db::name('zimu_zhaopin_company_profile')->where([['uid','=',$value['uid']]])->findOrEmpty();
            $res[$key]['myapply'] = Db::name('zimu_zhaopin_personal_jobs_apply')->where([['company_uid','=',$value['uid']],['jobs_id','=',$value['id']]])->count();
            $res[$key]['auditinfo'] = Db::name('zimu_zhaopin_jobs_audit')->where([['ids','=',$value['id']]])->find();
            if($res[$key]['auditinfo']){
                $oldinfo = $res[$key];
                $diff_info = array_merge($oldinfo,$res[$key]['auditinfo']);
                $diff_info2 = array_diff_assoc($diff_info,$oldinfo);
                $res[$key]['auditinfo'] = $diff_info2;
                $res[$key]['auditinfo']['uid'] = $res[$key]['uid'];
                $res[$key]['audit'] = 2;
            }
        }

        $count = Db::name('zimu_zhaopin_jobs')->where($wheresql)->order($ordersql)->count();

        zimu_json3($res,'',0,$count);

    }