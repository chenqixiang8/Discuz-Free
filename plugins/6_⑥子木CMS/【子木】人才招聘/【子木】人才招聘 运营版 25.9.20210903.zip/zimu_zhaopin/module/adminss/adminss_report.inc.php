<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if (!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }
    use think\Db;
    $token = addslashes($_GET['token']);
    $myuid = checktoken_admin($token);
    $op = addslashes($_GET['op']);
    $op = $op ? $op : 'list';

    if ($op == 'edit') {

    } else if ($op == 'quickaudit') {

        $ids = intval($postdata['ids']);
        $audit = intval($postdata['audit']);
        Db::name('zimu_zhaopin_report')->where('id', $ids)->data('audit', $audit)->update();
        zimu_json3($res);

    } else if ($op == 'delinfo') {

        Db::name('zimu_zhaopin_report')->where('id', $postdata['ids'])->delete();

        zimu_json3($res);

    } else {

        $wheresql = [];

        $audit = intval($_GET['audit']);
        if (!empty($audit)) {
            $wheresql[] = ['audit','=',$audit];
        }

        $typeid = intval($_GET['typeid']);
        if (!empty($typeid)) {
            $wheresql[] = ['type','=',$typeid];
        }

        $page = intval($_GET['page']);
        $limit = intval($_GET['limit']);

        $report = Db::name('zimu_zhaopin_report')->where($wheresql)->order(['id'=>'desc'])->page($page,$limit)->select()->toArray();

        foreach ($report as $key => $value) {
            if($value['type']==1){
                $report[$key]['info'] = Db::name('zimu_zhaopin_jobs')->where([['id', '=', $value['jobs_id']]])->find();
            }
            if($value['type']==2){
                $report[$key]['info'] = Db::name('zimu_zhaopin_resume')->where([['id', '=', $value['jobs_id']]])->find();
            }
        }
        $res = $report;

        $count = Db::name('zimu_zhaopin_report')->where($wheresql)->order($ordersql)->count();
        zimu_json3($res,'',0,$count);
    }