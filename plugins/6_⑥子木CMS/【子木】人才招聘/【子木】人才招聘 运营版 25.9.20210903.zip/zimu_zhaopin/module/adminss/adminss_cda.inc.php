<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if (!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }

    use think\Db;
    $token = addslashes($_GET['token']);
    $myuid = checktoken_admin($token);
    $op = addslashes($_GET['op']);
    $op = $op ? $op : 'com_jobs_apply';
    $ids = intval($_GET['ids']);
    $postdata = zimu_array_utf8tomy($postdata);

    if ($op == 'zimu') {

    } else if ($op == 'com_resume_down') {

        $wheresql = [];
        $keyword = zimu_array_utf8tomy($_GET['keyword']);
        $keywordtype = intval($_GET['keywordtype']);
        if (!empty($keyword)) {
            if ($keywordtype == 3) {
                $wheresql[] = ['resume_id','=',$keyword];
            } else {
                $mycomid = Db::name('zimu_zhaopin_company_profile')->where([['id','=',$keyword]])->find();
                $wheresql[] = ['company_uid','=',$mycomid['uid']];
            }
        }

        $ordersql['did'] = 'desc';
        $page = intval($_GET['page']);
        $limit = intval($_GET['limit']);
        $res = Db::name('zimu_zhaopin_company_down_resume')->where($wheresql)->order($ordersql)->page($page,$limit)->select()->toArray();

        foreach ($res as $key => $value) {
            $res[$key]['resume'] = Db::name('zimu_zhaopin_resume')->where([['id','=',$value['resume_id']]])->find();
            $res[$key]['company'] = Db::name('zimu_zhaopin_company_profile')->where([['uid','=',$value['company_uid']]])->find();
            if(!$res[$key]['company']){
                unset($res[$key]);
                Db::name('zimu_zhaopin_company_down_resume')->where([['did','=',$value['did']]])->delete();
            }
        }

        $count = Db::name('zimu_zhaopin_company_down_resume')->where($wheresql)->order($ordersql)->count();

        zimu_json3($res,'',0,$count);

    } else if ($op == 'com_resume_favorites') {

        $wheresql = [];
        $keyword = zimu_array_utf8tomy($_GET['keyword']);
        $keywordtype = intval($_GET['keywordtype']);
        if (!empty($keyword)) {
            $mycomid = Db::name('zimu_zhaopin_company_profile')->where([['id','=',$keyword]])->find();
            $wheresql[] = ['company_uid','=',$mycomid['uid']];
        }

        $ordersql['did'] = 'desc';
        $page = intval($_GET['page']);
        $limit = intval($_GET['limit']);
        $res = Db::name('zimu_zhaopin_company_favorites')->where($wheresql)->order($ordersql)->page($page,$limit)->select()->toArray();

        foreach ($res as $key => $value) {
            $res[$key]['resume'] = Db::name('zimu_zhaopin_resume')->where([['id','=',$value['resume_id']]])->find();
            $res[$key]['company'] = Db::name('zimu_zhaopin_company_profile')->where([['uid','=',$value['company_uid']]])->find();
        }

        $count = Db::name('zimu_zhaopin_company_favorites')->where($wheresql)->order($ordersql)->count();

        zimu_json3($res,'',0,$count);

    } else if ($op == 'per_jobs_apply') {

        $wheresql = [];
        $keyword = zimu_array_utf8tomy($_GET['keyword']);
        $keywordtype = intval($_GET['keywordtype']);
        if (!empty($keyword)) {
            $wheresql[] = ['resume_id','=',$keyword];
        }

        $ordersql['did'] = 'desc';
        $page = intval($_GET['page']);
        $limit = intval($_GET['limit']);
        $res = Db::name('zimu_zhaopin_personal_jobs_apply')->where($wheresql)->order($ordersql)->page($page,$limit)->select()->toArray();

        foreach ($res as $key => $value) {
            $res[$key]['resume'] = Db::name('zimu_zhaopin_resume')->where([['uid','=',$value['personal_uid']]])->findOrEmpty();
        }

        $count = Db::name('zimu_zhaopin_personal_jobs_apply')->where($wheresql)->order($ordersql)->count();

        zimu_json3($res,'',0,$count);

    } else if ($op == 'per_jobs_favorites') {

        $wheresql = [];
        $keyword = zimu_array_utf8tomy($_GET['keyword']);
        $keywordtype = intval($_GET['keywordtype']);
        if (!empty($keyword)) {
            $mycomid = Db::name('zimu_zhaopin_resume')->where([['id','=',$keyword]])->find();
            $wheresql[] = ['personal_uid','=',$mycomid['uid']];
        }

        $ordersql['did'] = 'desc';
        $page = intval($_GET['page']);
        $limit = intval($_GET['limit']);
        $res = Db::name('zimu_zhaopin_personal_favorites')->where($wheresql)->order($ordersql)->page($page,$limit)->select()->toArray();

        foreach ($res as $key => $value) {
            $res[$key]['resume'] = Db::name('zimu_zhaopin_resume')->where([['uid','=',$value['personal_uid']]])->findOrEmpty();
            if(!$res[$key]['resume']){
                unset($res[$key]);
                Db::name('zimu_zhaopin_personal_favorites')->where([['did','=',$value['did']]])->delete();
            }
        }
        array_multisort($res);
        $count = Db::name('zimu_zhaopin_personal_favorites')->where($wheresql)->order($ordersql)->count();

        zimu_json3($res,'',0,$count);

    } else if ($op == 'per_attention_com') {

        $wheresql = [];
        $keyword = zimu_array_utf8tomy($_GET['keyword']);
        $keywordtype = intval($_GET['keywordtype']);
        if (!empty($keyword)) {
            $mycomid = Db::name('zimu_zhaopin_resume')->where([['id','=',$keyword]])->find();
            $wheresql[] = ['uid','=',$mycomid['uid']];
        }

        $ordersql['id'] = 'desc';
        $page = intval($_GET['page']);
        $limit = intval($_GET['limit']);
        $res = Db::name('zimu_zhaopin_personal_focus_company')->where($wheresql)->order($ordersql)->page($page,$limit)->select()->toArray();

        foreach ($res as $key => $value) {
            $res[$key]['resume'] = Db::name('zimu_zhaopin_resume')->where([['uid','=',$value['uid']]])->findOrEmpty();
            $res[$key]['company'] = Db::name('zimu_zhaopin_company_profile')->where([['id','=',$value['company_id']]])->findOrEmpty();
            if(!$res[$key]['resume'] || !$res[$key]['company']){
                unset($res[$key]);
                Db::name('zimu_zhaopin_personal_focus_company')->where([['id','=',$value['id']]])->delete();
            }
        }
        array_multisort($res);

        $count = Db::name('zimu_zhaopin_personal_focus_company')->where($wheresql)->order($ordersql)->count();

        zimu_json3($res,'',0,$count);

    } else if ($op == 'quickaction') {

        $opp = addslashes($_GET['opp']);
        $oppp = addslashes($_GET['oppp']);
        if($opp=='del'){
            if($oppp=='com_jobs_apply' || $oppp=='per_jobs_apply'){
                Db::name('zimu_zhaopin_personal_jobs_apply')->where([['did','in',$postdata]])->delete();
            }
            if($oppp=='com_resume_down'){
                Db::name('zimu_zhaopin_company_down_resume')->where([['did','in',$postdata]])->delete();
            }
            if($oppp=='com_resume_favorites'){
                Db::name('zimu_zhaopin_company_favorites')->where([['did','in',$postdata]])->delete();
            }
            if($oppp=='per_jobs_favorites'){
                Db::name('zimu_zhaopin_personal_favorites')->where([['did','in',$postdata]])->delete();
            }
            if($oppp=='per_attention_com'){
                Db::name('zimu_zhaopin_personal_focus_company')->where([['id','in',$postdata]])->delete();
            }
        }
        zimu_json3($res);


    } else {

        $wheresql = [];
        $keyword = zimu_array_utf8tomy($_GET['keyword']);
        $keywordtype = intval($_GET['keywordtype']);
        if (!empty($keyword)) {
            if ($keywordtype == 1) {
                $wheresql[] = ['company_id','=',$keyword];
            } elseif ($keywordtype == 2) {
                $wheresql[] = ['jobs_id','=',$keyword];
            }
        }

        $ordersql['did'] = 'desc';
        $page = intval($_GET['page']);
        $limit = intval($_GET['limit']);
        $res = Db::name('zimu_zhaopin_personal_jobs_apply')->where($wheresql)->order($ordersql)->page($page,$limit)->select()->toArray();

        foreach ($res as $key => $value) {
            $res[$key]['resume'] = Db::name('zimu_zhaopin_resume')->where([['uid','=',$value['personal_uid']]])->find();
        }

        $count = Db::name('zimu_zhaopin_personal_jobs_apply')->where($wheresql)->order($ordersql)->count();

        zimu_json3($res,'',0,$count);

    }