<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if (!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }

    use think\Db;
    $token = addslashes($_GET['token']);
    $myuid = checktoken_admin($token);
    $op = addslashes($_GET['op']);
    $op = $op ? $op : 'list';

    if ($op == 'edit') {


    } else if ($op == 'password') {

        $mytoken2 = explode('uid',$token);

        if($mytoken2[1]=='admin'){
            zimu_json3($res,$language_zimu['adminss_user_inc_php_0'],201);
        }else if($mytoken2[1]){
            $isadmin = Db::name('zimu_zhaopin_admin')->where([['id','=',$mytoken2[1]]])->find();
            if($postdata['old'] != $isadmin['password']){
                zimu_json3($res,$language_zimu['adminss_user_inc_php_1'],201);
            }
            Db::name('zimu_zhaopin_admin')->where('id', $mytoken2[1])->data(['password' => $postdata['password'],'code' => $postdata['code']])->update();
            zimu_json3($res);
        }

    } else {

        $mytoken2 = explode('uid',$token);

        if($mytoken2[1]=='admin'){
            $res['nickname'] = $zmdata['admin_name'];
            $res['avatar'] = $_G['siteurl'].'source/plugin/zimu_zhaopin/static/image/avatar.jpg';
            $res['roles'][0]['roleCode'] = 'admin';
            $res['authorities'][0]['authority'] = 'dashboard:workplace';
            $res['authorities'][1]['authority'] = 'system:settings';
        }else if($mytoken2[1]){
            $isadmin = Db::name('zimu_zhaopin_admin')->where([['id','=',$mytoken2[1]]])->find();
            $iskefu = Db::name('zimu_zhaopin_kefu')->where([['admin_uid','=',$mytoken2[1]]])->find();
            $res['nickname'] = $iskefu['kefu_name'] ? $isadmin['username'].'('.$language_zimu['adminss_user_inc_php_2'].$iskefu['kefu_name'].')' : $isadmin['username'];
            $res['avatar'] = $_G['siteurl'].'source/plugin/zimu_zhaopin/static/image/avatar.jpg';
            $res['roles'][0]['roleCode'] = 'user';
            $res['authorities'][0]['authority'] = 'dashboard:workplace';
            $res['authorities'][1]['authority'] = 'system:settings';
        }

            zimu_json3($res);

    }