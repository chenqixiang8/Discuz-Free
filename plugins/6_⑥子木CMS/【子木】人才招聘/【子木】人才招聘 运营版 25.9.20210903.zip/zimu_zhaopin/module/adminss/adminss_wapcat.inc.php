<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if (!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }
    use think\Db;
    $token = addslashes($_GET['token']);
    $myuid = checktoken_admin($token);
    $op = addslashes($_GET['op']);
    $opp = addslashes($_GET['opp']);
    $op = $op ? $op : 'list';

    if ($op == 'edit') {

        $postdata = zimu_array_utf8tomy($postdata);
        $paramter = Db::name('zimu_zhaopin_parameter2')->where('name', $opp)->find();

        if($paramter['id']>0){
            Db::name('zimu_zhaopin_parameter2')->where('id', $paramter['id'])->data(['parameter' => serialize($postdata)])->update();
        }else{
            $paramters = $postdata;
            $adddata = array(
                'name'=>$opp,
                'parameter'=>serialize($paramters),
            );
            Db::name('zimu_zhaopin_parameter2')->insert($adddata);
        }

        zimu_json3($res);

    }elseif($op == 'com_input' ){

        $empty = array('value'=>0,'label'=>$language_zimu['adminss_wapcat_inc_php_0']);
        $category = Db::name('zimu_zhaopin_category')->order(['c_order'=>'asc','c_id'=>'asc'])->select()->toArray();
        foreach ($category as $key => $value) {
            $category2[$value['c_alias']][$value['c_id']]['value'] = $value['c_id'];
            $category2[$value['c_alias']][$value['c_id']]['label'] = $value['c_name'];
        }
        $nature_list = $category2['ZM_company_type'];
        $res['zmdata']['nature_list'] = $nature_list;
        $res['zmdata']['nature_list'][0] = $empty;
        $trade_list = $category2['ZM_trade'];
        $res['zmdata']['trade_list'] = $trade_list;
        $res['zmdata']['trade_list'][0] = $empty;
        $scale_list = $category2['ZM_scale'];
        $res['zmdata']['scale_list'] = $scale_list;
        $res['zmdata']['scale_list'][0] = $empty;

        $arealist = Db::name('zimu_zhaopin_area')->where([['parentid','=',0]])->order(['sort'=>'asc','id'=>'asc'])->column('id as value,name as label','id');
        $res['zmdata']['district_list'] = $arealist;
        $res['zmdata']['district_list'][0] = $empty;

        $paramter = Db::name('zimu_zhaopin_parameter2')->where('name', $op)->findOrEmpty();
        $res[$op] = unserialize($paramter['parameter']) ? unserialize($paramter['parameter']) : [];

        zimu_json3($res);

    }elseif($op == 'job_input' ){

        $empty = array('value'=>0,'label'=>$language_zimu['adminss_wapcat_inc_php_1']);
        $category = Db::name('zimu_zhaopin_category')->order(['c_order'=>'asc','c_id'=>'asc'])->select()->toArray();
        foreach ($category as $key => $value) {
            $category2[$value['c_alias']][$value['c_id']]['value'] = $value['c_id'];
            $category2[$value['c_alias']][$value['c_id']]['label'] = $value['c_name'];
        }
        $nature_list = $category2['ZM_jobs_nature'];
        $res['zmdata']['nature_list'] = $nature_list;
        $res['zmdata']['nature_list'][0] = $empty;
        $experience_list = $category2['ZM_experience'];
        $res['zmdata']['experience_list'] = $experience_list;
        $res['zmdata']['experience_list'][0] = $empty;
        $education_list = $category2['ZM_education'];
        $res['zmdata']['education_list'] = $education_list;
        $res['zmdata']['education_list'][0] = $empty;
        $wage_list = $category2['ZM_wage'];
        $res['zmdata']['wage_list'] = $wage_list;
        $res['zmdata']['wage_list'][0] = $empty;

        $arealist = Db::name('zimu_zhaopin_area')->where([['parentid','=',0]])->order(['sort'=>'asc','id'=>'asc'])->column('id as value,name as label','id');
        $res['zmdata']['district_list'] = $arealist;
        $res['zmdata']['district_list'][0] = $empty;

        $paramter = Db::name('zimu_zhaopin_parameter2')->where('name', $op)->findOrEmpty();
        $res[$op] = unserialize($paramter['parameter']);

        zimu_json3($res);

    }elseif($op == 'resume_input' ){

        $empty = array('value'=>0,'label'=>$language_zimu['adminss_wapcat_inc_php_2']);

        $category = Db::name('zimu_zhaopin_category')->order(['c_order'=>'asc','c_id'=>'asc'])->select()->toArray();

        foreach ($category as $key => $value) {
            $category2[$value['c_alias']][$value['c_id']]['value'] = $value['c_id'];
            $category2[$value['c_alias']][$value['c_id']]['label'] = $value['c_name'];
        }

        $education_list = $category2['ZM_education'];
        $res['zmdata']['education_list'] = $education_list;
        $res['zmdata']['education_list'][0] = $empty;
        $experience_list = $category2['ZM_experience'];
        $res['zmdata']['experience_list'] = $experience_list;
        $res['zmdata']['experience_list'][0] = $empty;
        $current_list = $category2['ZM_current'];
        $res['zmdata']['current_list'] = $current_list;
        $res['zmdata']['current_list'][0] = $empty;
        $nature_list = $category2['ZM_jobs_nature'];
        $res['zmdata']['nature_list'] = $nature_list;
        $res['zmdata']['nature_list'][0] = $empty;
        $wage_list = $category2['ZM_wage'];
        $res['zmdata']['wage_list'] = $wage_list;
        $res['zmdata']['wage_list'][0] = $empty;

        $trade_list = $category2['ZM_trade'];
        $res['zmdata']['trade_list'] = $trade_list;

        $paramter = Db::name('zimu_zhaopin_parameter2')->where('name', $op)->findOrEmpty();
        $res[$op] = unserialize($paramter['parameter']);

        zimu_json3($res);

    }elseif($op == 'wxtpl' ){
        $paramter = Db::name('zimu_zhaopin_parameter2')->where('name', $op)->findOrEmpty();
        $res[$op] = unserialize($paramter['parameter']);

        zimu_json3($res);
    } else {

        $paramter = Db::name('zimu_zhaopin_parameter2')->where('name', $opp)->find();
        $res = unserialize($paramter['parameter']);
        $res = $res ? $res : [];
        zimu_json3($res);
    }