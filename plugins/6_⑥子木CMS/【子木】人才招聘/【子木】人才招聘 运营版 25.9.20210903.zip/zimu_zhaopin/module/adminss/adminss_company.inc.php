<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if (!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }

    use think\Db;
    $token = addslashes($_GET['token']);
    $myuid = checktoken_admin($token);
    $op = addslashes($_GET['op']);
    $op = $op ? $op : 'list';


    if ($op == 'zimu') {

    } else if ($op == 'edit') {

        $ids = intval($_GET['ids']);
        if($ids) {
            $res['company'] = Db::name('zimu_zhaopin_company_profile')->where([['id', '=', $ids]])->findOrEmpty();
            $res['company']['admin_uid'] =  trim($res['company']['admin_uid'],',');
            $res['company']['blacklist'] = Db::name('zimu_zhaopin_members')->where([['uid', '=', $res['company']['uid']]])->value('blacklist');
        }
        $category = Db::name('zimu_zhaopin_category')->order(['c_order'=>'asc','c_id'=>'asc'])->select()->toArray();
        foreach ($category as $key => $value) {
            $category2[$value['c_alias']][$value['c_id']]['value'] = $value['c_id'];
            $category2[$value['c_alias']][$value['c_id']]['label'] = $value['c_name'];
        }
        $nature_list = $category2['ZM_company_type'];
        //array_multisort($nature_list);
        $res['zmdata']['nature_list'] = $nature_list;

        $arealist = Db::name('zimu_zhaopin_area')->field('id as value,name as label')->where([['parentid','=',0]])->order(['sort'=>'asc','id'=>'asc'])->select()->toArray();

        foreach ($arealist as $key => $value) {
            $arealist[$key]['children'] = Db::name('zimu_zhaopin_area')->field('id as value,name as label')->where([['parentid','=',$value['value']]])->order(['sort'=>'asc','id'=>'asc'])->select()->toArray();

            if($zmdata['settings']['area_three']){
                foreach ($arealist[$key]['children'] as $key2 => $value2) {
                    $arealist[$key]['children'][$key2]['children'] = Db::name('zimu_zhaopin_area')->field('id as value,name as label')->where([['parentid','=',$value2['value']]])->order(['sort'=>'asc','id'=>'asc'])->select()->toArray();
                }
            }

        }
        $res['zmdata']['district_list'] = $arealist;
        $res['zmdata']['area_three'] = $zmdata['settings']['area_three'];
        $trade_list = $category2['ZM_trade'];
        //array_multisort($trade_list);
        $res['zmdata']['trade_list'] = $trade_list;
        $scale_list = $category2['ZM_scale'];
        //array_multisort($scale_list);
        $res['zmdata']['scale_list'] = $scale_list;

        $tag_list = $category2['ZM_jobtag'];
        //array_multisort($tag_list);
        foreach ($tag_list as $key => $value) {
            if(strpos($res['company']['tag_cn'],$value['label']) !== false){
                $tag_list[$key]['select'] = true;
            }else{
                $tag_list[$key]['select'] = false;
            }
        }
        $res['zmdata']['tag_list'] = $tag_list;

        $res['zmdata']['kefu_list'] = Db::name('zimu_zhaopin_kefu')->order(['id'=>'asc'])->column('uid as value,kefu_name as label','uid');

        $audit_tip1 = explode(PHP_EOL, trim($zmdata['settings']['audit_tip1']));
        $audit_tip2 = explode(PHP_EOL, trim($zmdata['settings']['audit_tip2']));
        foreach ($audit_tip1 as $key => $value) {
            $res['zmdata']['audit_tip1'][$key]['value'] = $value;
        }
        foreach ($audit_tip2 as $key => $value) {
            $res['zmdata']['audit_tip2'][$key]['value'] = $value;
        }

        zimu_json3($res);

    } else if ($op == 'toedit') {

        $company_profile_data = zimu_array_utf8tomy($postdata);
        if($company_profile_data['area2']){
            if(!$company_profile_data['area2'][1]){
                $company_profile_data['area2'][1] = 0;
            }
            if(!$company_profile_data['area2'][2]){
                $company_profile_data['area2'][2] = 0;
            }
            $company_profile_data['district'] = implode('.',$company_profile_data['area2']);
        }
        $company_profile_data['district_cn'] = str_replace(' / ','',$company_profile_data['district_cn']);
        $company_profile_data['addtime'] = $company_profile_data['addtime'] ? $company_profile_data['addtime'] : time();
        $company_profile_data['tag'] = implode(',',$company_profile_data['tag']);
        $company_profile_data['tag_cn'] = implode(',',$company_profile_data['tag_cn']);

        $company_profile_data['admin_uid'] =  trim($company_profile_data['admin_uid'],',');
        $company_profile_data['admin_uid'] = ','.$company_profile_data['admin_uid'].',';

        if($company_profile_data['id']){
            $old = Db::name('zimu_zhaopin_company_profile')->where([['id','=',$company_profile_data['id']]])->order(['id'=>'desc'])->find();
            if($company_profile_data['audit'] != $old['audit']){
                company_push($company_profile_data['id'],$company_profile_data['audit'],$company_profile_data['wxtpl']);
            }
            Db::name('zimu_zhaopin_company_profile')->where([['id','=',$company_profile_data['id']]])->update($company_profile_data);

            Db::name('zimu_zhaopin_jobs')->where('uid', $company_profile_data['uid'])->data(['companyname' => $company_profile_data['companyname'],'company_certificate' => $company_profile_data['certificate_img_audit'],'company_mingqi' => $company_profile_data['company_mingqi'],'company_audit' => $company_profile_data['audit'],'trade' => $company_profile_data['trade'],'trade_cn' => $company_profile_data['trade_cn']])->update();

            if($company_profile_data['uid'] != $old['uid'] && $company_profile_data['uid'] && $old['uid']){
                company_uid_touid($old['uid'],$company_profile_data['uid']);
            }

        }else{
            $newids = Db::name('zimu_zhaopin_company_profile')->insertGetId($company_profile_data);
        }
        Db::name('zimu_zhaopin_members')->where('uid', $company_profile_data['uid'])->data(['blacklist' => $company_profile_data['blacklist'],'telephone' => $company_profile_data['telephone']])->update();

        zimu_json3($res);

    } else if ($op == 'save_certificate') {

        $postdata = zimu_array_utf8tomy($postdata);
        Db::name('zimu_zhaopin_company_profile')->where('id', $postdata['id'])->data(['certificate_img_audit' => $postdata['certificate_img_audit'],'certificate_img_tpl' => $postdata['certificate_img_tpl']])->update();
        zimu_json3($res);

    } else if ($op == 'toaudit') {

        $postdata = zimu_array_utf8tomy($postdata);

        $old = Db::name('zimu_zhaopin_company_profile')->where([['id','=',$postdata['ids']]])->order(['id'=>'desc'])->find();
        if($postdata['audit'] != $old['audit']){
            company_push($postdata['ids'],$postdata['audit'],$postdata['tpl']);
        }

        Db::name('zimu_zhaopin_company_profile')->where('id', $postdata['ids'])->data(['audit' => $postdata['audit'],'wxtpl' => $postdata['tpl']])->update();

        zimu_json3($res);

    }elseif($op == 'delinfo' ){

        Db::name('zimu_zhaopin_company_profile')->where([['id','=',$postdata['id']]])->delete();
        Db::name('zimu_zhaopin_company_down_resume')->where([['company_uid','=',$postdata['uid']]])->delete();
        Db::name('zimu_zhaopin_company_favorites')->where([['company_uid','=',$postdata['uid']]])->delete();
        Db::name('zimu_zhaopin_company_interview')->where([['company_id','=',$postdata['id']]])->delete();
        Db::name('zimu_zhaopin_com_viewlog')->where([['uid','=',$postdata['uid']]])->delete();
        Db::name('zimu_zhaopin_jobs')->where([['company_id','=',$postdata['id']]])->delete();
        Db::name('zimu_zhaopin_jobs_audit')->where([['company_id','=',$postdata['id']]])->delete();
        Db::name('zimu_zhaopin_personal_favorites')->where([['company_id','=',$postdata['id']]])->delete();
        Db::name('zimu_zhaopin_personal_focus_company')->where([['company_id','=',$postdata['id']]])->delete();
        Db::name('zimu_zhaopin_personal_jobs_apply')->where([['company_id','=',$postdata['id']]])->delete();
        Db::name('zimu_zhaopin_per_viewlog')->where([['cid','=',$postdata['id']]])->delete();
        Db::name('zimu_zhaopin_view_resume')->where([['company_id','=',$postdata['id']]])->delete();
        zimu_json3($res);

    } else if ($op == 'contact_weixin') {

        Db::name('zimu_zhaopin_company_profile')->where('id', $postdata['id'])->data(['is_wechat' => $postdata['is_wechat'],'is_contact' => $postdata['is_contact']])->update();
        zimu_json3($res);

    } else if ($op == 'quickaction') {

        $opp = addslashes($_GET['opp']);
        if($opp=='check'){
            Db::name('zimu_zhaopin_company_profile')->where([['id','in',$postdata]])->data(['audit' => 1])->update();
            foreach ($postdata as $key => $value) {
                company_push($value,1,$language_zimu['adminss_company_inc_php_0']);
            }
        }
        zimu_json3($res);

    } else {

        $wheresql = [];
        $kefu_uid = get_kefu_uid($token);
        if($kefu_uid){
            $wheresql[] = ['kefu_uid','=',$kefu_uid];
        }

        $audit = intval($_GET['audit']);
        if($audit){
            $wheresql[] = ['audit','=',$audit];
        }
        $setmeal_id = intval($_GET['setmeal_id']);
        if (!empty($setmeal_id) && $setmeal_id!=99) {
            $wheresql[] = ['setmeal_id','>',$setmeal_id];
        }
        $certificate_img_audit = intval($_GET['certificate_img_audit']);
        if($certificate_img_audit==1){
            $wheresql[] = ['certificate_img_audit','=',1];
        } elseif ($certificate_img_audit == 2) {
            $wheresql[] = ['certificate_img_audit','=',0];
        }
        $keyword = zimu_array_utf8tomy($_GET['keyword']);
        $keywordtype = intval($_GET['keywordtype']);
        if (!empty($keyword)) {
            if ($keywordtype == 1) {
                $wheresql[] = ['id','=',$keyword];
            } elseif ($keywordtype == 2) {
                $wheresql[] = ['companyname','like','%'.$keyword.'%'];
            } elseif ($keywordtype == 3) {
                $wheresql[] = ['uid','=',$keyword];
            } elseif ($keywordtype == 4) {
                $wheresql[] = ['telephone','like','%'.$keyword.'%'];
            } elseif ($keywordtype == 10) {
                if(is_numeric($keyword)){
                    $wheresql[] = ['id','=',$keyword];
                }else{
                    $wheresql[] = ['companyname','like','%'.$keyword.'%'];
                }
            }
        }

        $order = strip_tags($_GET['order']) ? strip_tags($_GET['order']) : 'addtime';
        $ordersql[$order] = 'desc';
        $ordersql['id'] = 'desc';
        $page = intval($_GET['page']);
        $limit = intval($_GET['limit']);
        $res = Db::name('zimu_zhaopin_company_profile')->where($wheresql)->order($ordersql)->page($page,$limit)->select()->toArray();

        foreach ($res as $key => $value) {
            $res[$key]['comsetmea'] = Db::name('zimu_zhaopin_members_setmeal')->where([['uid','=',$value['uid']]])->findOrEmpty();
            $res[$key]['myjobs'] = Db::name('zimu_zhaopin_jobs')->where([['uid','=',$value['uid']]])->count();
            $res[$key]['myapply'] = Db::name('zimu_zhaopin_personal_jobs_apply')->where([['company_uid','=',$value['uid']]])->count();
            $res[$key]['mydown'] = Db::name('zimu_zhaopin_company_down_resume')->where([['company_uid','=',$value['uid']]])->count();
        }

        $count = Db::name('zimu_zhaopin_company_profile')->where($wheresql)->order($ordersql)->count();

        zimu_json3($res,'',0,$count);

    }