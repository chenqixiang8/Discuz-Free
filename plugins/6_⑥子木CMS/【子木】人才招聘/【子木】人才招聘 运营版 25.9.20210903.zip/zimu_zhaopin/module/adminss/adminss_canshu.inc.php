<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if (!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }
    use think\Db;
    $token = addslashes($_GET['token']);
    $myuid = checktoken_admin($token);
    $op = addslashes($_GET['op']);
    $op = $op ? $op : 'list';

    if ($op == 'edit') {

        $ids = intval($postdata['c_id']);
        $area_data['c_name'] = zm_diconv($postdata['c_name']);
        $area_data['c_order'] = intval($postdata['c_order']);

        if($ids>0){
            Db::name('zimu_zhaopin_category')->where('c_id', $ids)->data($area_data)->update();
        }else{
            $area_data['c_alias'] = strip_tags($postdata['dictId']);
            Db::name('zimu_zhaopin_category')->insert($area_data);
        }

        zimu_json3($res);

    } else if ($op == 'del') {

        $ids = intval($_GET['ids']);
        Db::name('zimu_zhaopin_category')->where([['c_id','=',$ids]])->delete();

        zimu_json3($res);

    } else if ($op == 'area2') {

        $res = Db::name('zimu_zhaopin_area')->where([['parentid','=',0]])->order(['sort' =>'desc','id'=>'asc'])->select()->toArray();
        foreach ($res as $key => $value) {
            $res[$key]['children'] = Db::name('zimu_zhaopin_area')->where([['parentid','=',$value['id']]])->order(['sort' =>'desc','id'=>'asc'])->select()->toArray();
            if(!$res[$key]['children']){
                unset($res[$key]['children']);
            }
        }
        zimu_json3($res);

    } else if ($op == 'getlist') {

        $res[0] = ['name'=>$language_zimu['adminss_canshu_inc_php_0'],'c_alias'=>'ZM_trade'];
        $res[1] = ['name'=>$language_zimu['adminss_canshu_inc_php_1'],'c_alias'=>'ZM_company_type'];
        $res[2] = ['name'=>$language_zimu['adminss_canshu_inc_php_2'],'c_alias'=>'ZM_wage'];
        $res[3] = ['name'=>$language_zimu['adminss_canshu_inc_php_3'],'c_alias'=>'ZM_jobs_nature'];
        $res[4] = ['name'=>$language_zimu['adminss_canshu_inc_php_4'],'c_alias'=>'ZM_education'];
        $res[5] = ['name'=>$language_zimu['adminss_canshu_inc_php_5'],'c_alias'=>'ZM_experience'];
        $res[6] = ['name'=>$language_zimu['adminss_canshu_inc_php_6'],'c_alias'=>'ZM_jobtag'];
        $res[7] = ['name'=>$language_zimu['adminss_canshu_inc_php_7'],'c_alias'=>'ZM_resumetag'];
        $res[8] = ['name'=>$language_zimu['adminss_canshu_inc_php_8'],'c_alias'=>'ZM_current'];
        zimu_json3($res);


    } else {

        $parentid = strip_tags($_GET['dictId']);

        $res = Db::name('zimu_zhaopin_category')->where([['c_alias','=',$parentid]])->order(['c_order' =>'desc','c_id'=>'asc'])->select()->toArray();

        zimu_json3($res);
    }