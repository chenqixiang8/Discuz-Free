<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if (!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }
    use think\Db;
    $token = addslashes($_GET['token']);
    $myuid = checktoken_admin($token);
    $op = addslashes($_GET['op']);
    $op = $op ? $op : 'list';

    if ($op == 'lizimu') {

    } else if ($op == 'comlist') {

    } else {

        $wheresql = [];
        $is_paid = intval($_GET['is_paid']);
        if($is_paid){
            $wheresql[] = ['is_paid','=',$is_paid];
        }
        $service_name = strip_tags($_GET['service_name']);
        if($service_name){
            $wheresql[] = ['service_name','=',$service_name];
        }

        $keyword = strip_tags($_GET['keyword']);
        if (!empty($keyword)) {
            $wheresql[] = ['uid','=',$keyword];
        }

        $time_start = strtotime($_GET['time_start']);
        $time_end = strtotime($_GET['time_end']);
        if($time_start){
            $wheresql[] = ['addtime','>',$time_start];
        }
        if($time_end){
            $wheresql[] = ['addtime','<',$time_end];
        }

        $kefu_uid = get_kefu_uid($token);
        if($kefu_uid){
            $com_uids = Db::name('zimu_zhaopin_company_profile')->where([['kefu_uid','=',$kefu_uid]])->column('uid');
            $wheresql[] = ['uid','in',$com_uids];
        }

        $page = intval($_GET['page']);
        $limit = intval($_GET['limit']);

        $res = Db::name('zimu_zhaopin_order')->where($wheresql)->order(['id'=>'desc'])->page($page,$limit)->select()->toArray();

        foreach ($res as $key => $value) {
            if($value['service_name']=='setmeal_add' || $value['service_name']=='jobs_pay_add' || $value['service_name']=='download_resume'){
                $res[$key]['orderdata'] = Db::name('zimu_zhaopin_company_profile')->where([['uid','=',$value['uid']]])->findOrEmpty();
            }
            if($value['service_name']=='jobs_stick' || $value['service_name']=='jobs_refresh' || $value['service_name']=='jobs_auto_refresh'){
                $res[$key]['orderdata'] = Db::name('zimu_zhaopin_jobs')->where([['id','=',$value['zpid']]])->findOrEmpty();
            }
            if($value['service_name']=='resume_stick'){
                $res[$key]['orderdata'] = Db::name('zimu_zhaopin_resume')->where([['uid','=',$value['uid']]])->findOrEmpty();
            }
        }


        $count = Db::name('zimu_zhaopin_order')->where($wheresql)->order($ordersql)->count();
        zimu_json3($res,'',0,$count);

    }