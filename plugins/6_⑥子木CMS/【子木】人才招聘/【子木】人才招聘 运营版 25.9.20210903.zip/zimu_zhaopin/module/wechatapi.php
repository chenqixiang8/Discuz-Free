<?php
define('IN_API', true);
define('CURSCRIPT', 'api');
define('DISABLEXSSCHECK', true);

require_once '../../../../source/class/class_core.php';
$discuz = C::app();
$discuz->init();

$_G['siteurl'] = str_replace('source/plugin/zimu_zhaopin/lib/', '', $_G['siteurl']);

global $_G;
$zmdata = $_G['cache']['plugin']['zimu_zhaopin'];

$setdata = DB::fetch_first('select * from %t order by id desc', array(
    'zimu_zhaopin_setting'
));

$zmdata['base']     = $setdata;
$zmdata['settings'] = unserialize($setdata['settings']);


define("TOKEN", $zmdata['settings']['wx_token']);

$wechatObj = new wechatCallbackapiTest();
if (!isset($_GET['echostr'])) {
    $wechatObj->responseMsg();
} else {
    $wechatObj->valid();
}

class wechatCallbackapiTest
{
    //��֤ǩ��
    public function valid()
    {
        $echoStr   = $_GET["echostr"];
        $signature = $_GET["signature"];
        $timestamp = $_GET["timestamp"];
        $nonce     = $_GET["nonce"];
        $token     = TOKEN;
        $tmpArr    = array(
            $token,
            $timestamp,
            $nonce
        );
        sort($tmpArr, SORT_STRING);
        $tmpStr = implode($tmpArr);
        $tmpStr = sha1($tmpStr);
        if ($tmpStr == $signature) {
            echo $echoStr;
            exit;
        }
    }
    
    //��Ӧ��Ϣ
    public function responseMsg()
    {
        //$postStr = $GLOBALS["HTTP_RAW_POST_DATA"];
        $postStr = file_get_contents("php://input");
        if (!empty($postStr)) {
            $postObj = simplexml_load_string($postStr, 'SimpleXMLElement', LIBXML_NOCDATA);
            $RX_TYPE = trim($postObj->MsgType);
            
            if (($postObj->MsgType == "event") && ($postObj->Event == "subscribe" || $postObj->Event == "unsubscribe")) {
                //���˹�ע��ȡ����ע�¼�
            } else {
                
            }
            
            //��Ϣ���ͷ���
            switch ($RX_TYPE) {
                case "event":
                    $result = $this->receiveEvent($postObj);
                    break;
                case "text":
                    $result = $this->receiveText($postObj);
                    break;
                default:
                    //$result = "unknown msg type: ".$RX_TYPE;
                    break;
            }
            echo $result;
        } else {
            echo "";
            exit;
        }
    }
    
    //�����¼���Ϣ
    private function receiveEvent($object)
    {
        $content = "";
        global $_G;
        $zmdata = $_G['cache']['plugin']['zimu_zhaopin'];
        
        $setdata = DB::fetch_first('select * from %t order by id desc', array(
            'zimu_zhaopin_setting'
        ));
        
        $zmdata['base']     = $setdata;
        $zmdata['settings'] = unserialize($setdata['settings']);
        
        $langfile = DISCUZ_ROOT . './source/plugin/zimu_zhaopin/language.' . currentlang() . '.php';
        $includefile = is_file($langfile) ? $langfile : libfile('language', 'plugin/zimu_zhaopin');
        include $includefile;
        
        
        if ($object->Event == 'subscribe') {
            
            $this->zimu_sendTextMsg(trim($object->FromUserName), diconv($zmdata['settings']['subscribe_text'], CHARSET, 'UTF-8'));
            $object->Event2    = $object->Event;
            $object->Event    = 'SCAN';
            $object->EventKey = str_replace("qrscene_", "", $object->EventKey);
        }
        switch ($object->Event) {
            case "SCAN":
                
                list($model, $ids) = explode('zimuyun', $object->EventKey);
                if($model=='bindmp_im'){
                    $im = explode('job', $ids);
                    DB::query("update %t set bind_weixin=1 where uid=%d", array(
                        'zimu_zhaopin_resume',
                        $im[0]
                    ));
                    $model = 'viewjob';
                    $ids = $im[1];
                }
                if (($model == 'viewjob' || $model == 'viewjob2') && $ids) {
                    
                    $jobdata = DB::fetch_first('select * from %t where id=%d order by id asc', array(
                        'zimu_zhaopin_jobs',
                        $ids
                    ));
                    
                    $companydata = DB::fetch_first('select * from %t where id=%d order by id asc', array(
                        'zimu_zhaopin_company_profile',
                        $jobdata['company_id']
                    ));

                    if($model == 'viewjob2'){
                        $tourl = $_G['siteurl'] . 'source/plugin/zimu_zhaopin/h5/pages/jobs/view?ids=' . $ids.'&mobile=2';
                    }else{
                        $tourl = $_G['siteurl'] . 'plugin.php?id=zimu_zhaopin&model=viewjob&jid=' . $ids;
                    }

                    $content = $jobdata['companyname'] . '

' . $language_zimu['wechatapi_php_5'] . $jobdata['jobs_name'] . '

' . $language_zimu['wechatapi_php_6'] . $jobdata['wage_cn'] . '

' . $language_zimu['wechatapi_php_7'] . $companydata['address'] . '
 
' . '<a href="' . $tourl . '">' . $language_zimu['wechatapi_php_8'] . '</a>' . '

' . $language_zimu['wechatapi_php_9'] . $zmdata['base']['title'];
                    
                    $content = diconv($content, CHARSET, 'UTF-8');
                    
                    
                } elseif ($model == 'viewresume' && $ids) {
                    
                    $jobdata = DB::fetch_first('select * from %t where id=%d order by id asc', array(
                        'zimu_zhaopin_resume',
                        $ids
                    ));
                    
                    $content = $jobdata['fullname'] . '

' . $language_zimu['wechatapi_php_10'] . $jobdata['sex_cn'] . '

' . $language_zimu['wechatapi_php_11'] . (date('Y', $_G['timestamp']) - $jobdata['birthdate']) . '

' . $language_zimu['wechatapi_php_12'] . $jobdata['current_cn'] . '

' . $language_zimu['wechatapi_php_13'] . $jobdata['intention_jobs'] . '

' . $language_zimu['wechatapi_php_14'] . $jobdata['wage_cn'] . '
 
' . '<a href="' . $_G['siteurl'] . 'plugin.php?id=zimu_zhaopin&model=viewresume&rid=' . $ids . '">' . $language_zimu['wechatapi_php_15'] . '</a>' . '

' . $language_zimu['wechatapi_php_16'] . $zmdata['base']['title'];
                    
                    $content = diconv($content, CHARSET, 'UTF-8');

                } elseif (($model == 'viewcom' || $model == 'viewcom2') && $ids) {

                    $companydata = DB::fetch_first('select * from %t where id=%d order by id asc', array(
                        'zimu_zhaopin_company_profile',
                        $ids
                    ));
                    if($model == 'viewcom2'){
                        $tourl = $_G['siteurl'] . 'source/plugin/zimu_zhaopin/h5/pages/qiye/view?ids=' . $ids.'&mobile=2';
                    }else{
                        $tourl = $_G['siteurl'] . 'plugin.php?id=zimu_zhaopin&model=viewcom&cid=' . $ids;
                    }
                    $content = $companydata['companyname'] . '
 
' . '<a href="' . $tourl . '">' . $language_zimu['wechatapi_php_17'] . '</a>' . '

' . $language_zimu['wechatapi_php_18'] . $zmdata['base']['title'];

                    $content = diconv($content, CHARSET, 'UTF-8');

                } elseif ($model == 'bindmp_qrcode' && $ids) {
                    DB::query("update %t set bind_weixin=1 where uid=%d", array(
                        'zimu_zhaopin_company_profile',
                        $ids
                    ));
                    DB::query("update %t set bind_weixin=1 where uid=%d", array(
                        'zimu_zhaopin_resume',
                        $ids
                    ));
                    DB::query("update %t set openid=%s where uid=%d", array(
                        'zimu_zhaopin_members',
                        $object->FromUserName,
                        $ids
                    ));
                    $this->zimu_sendTextMsg(trim($object->FromUserName), diconv('ok'.$ids, CHARSET, 'UTF-8'));
                }
                
                $diy_scene = str_replace('diy_scene_', '', $object->EventKey);
                $diy_scene_data = DB::fetch_first('select * from %t where keyword=%s order by id desc', array(
                    'zimu_zhaopin_wxscene',
                    $diy_scene
                ));
                if($diy_scene_data['con']){
                    DB::query("update %t set times=times+1 where id=%d", array(
                        'zimu_zhaopin_wxscene',
                        $diy_scene_data['id']
                    ));
                    if($object->Event2=='subscribe'){
                    DB::query("update %t set subscribe=subscribe+1 where id=%d", array(
                        'zimu_zhaopin_wxscene',
                        $diy_scene_data['id']
                    ));
                    }
                    $this->zimu_sendTextMsg(trim($object->FromUserName), diconv($diy_scene_data['con'], CHARSET, 'UTF-8'));
                }


                break;
            default:
                //$content = "receive a new event: ".$object->Event;
                break;
        }
        
        if (is_array($content)) {
            if (isset($content[0]['PicUrl'])) {
                $result = $this->transmitNews($object, $content);
            } else if (isset($content['MusicUrl'])) {
                $result = $this->transmitMusic($object, $content);
            }
        } else {
            $result = $this->transmitText($object, $content);
        }
        
        return $result;
    }
    
    private function zimu_sendTextMsg($to, $msg)
    {
        global $_G;
        $zmdata = $_G['cache']['plugin']['zimu_zhaopin'];
        
        $setdata = DB::fetch_first('select * from %t order by id desc', array(
            'zimu_zhaopin_setting'
        ));
        
        $zmdata['base']     = $setdata;
        $zmdata['settings'] = unserialize($setdata['settings']);
        
        require_once DISCUZ_ROOT . './source/plugin/zimu_zhaopin/class/wechat.lib.class.php';
        $wechat_client = new WeChatClient($zmdata['base']['weixin_appid'], $zmdata['base']['weixin_appsecret']);
        
        $wechat_client->sendTextMsg($to, $msg);
        
    }
    
    
    //�����ı���Ϣ
    private function receiveText($object)
    {
        $keyword = trim($object->Content);
        $keyword = diconv($keyword,'UTF-8',CHARSET);
        if($keyword){
            $diy_scene_data = DB::fetch_first('select * from %t where keyword2=%s order by id desc', array(
                'zimu_zhaopin_wxscene',
                $keyword
            ));
            $diy_scene_data['con'] = diconv($diy_scene_data['con'], CHARSET, 'UTF-8');
            if($diy_scene_data['con']){
                return $this->transmitText($object,$diy_scene_data['con']);
            }else{
                return $this->receivesoText($keyword,$object);
            }
        }
    }

    private function receivesoText($keyword,$object)
    {
        global $_G;
        $setdata = DB::fetch_first('select * from %t order by id desc', array(
            'zimu_zhaopin_setting'
        ));
        $zmdata['base']     = $setdata;
        $zmdata['settings'] = unserialize($setdata['settings']);
        $langfile = DISCUZ_ROOT . './source/plugin/zimu_zhaopin/language.' . currentlang() . '.php';
        $includefile = is_file($langfile) ? $langfile : libfile('language', 'plugin/zimu_zhaopin');
        include $includefile;
        $wherearr[] = ' audit !=3 ';
        $wherearr[] = ' company_audit !=3 ';
        $wherearr[] = ' display !=2 ';
        $wherearr[] = ' (jobs_name LIKE \'%' . $keyword . '%\' OR companyname LIKE \'%' . $keyword . '%\' OR category_cn LIKE \'%' . $keyword . '%\' OR contents LIKE \'%' . $keyword . '%\') ';
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE ' . implode(' AND ', $wherearr) : '';

        $jobslist = DB::fetch_all('select * from %t %i order by refreshtime desc,id desc limit 8', array(
            'zimu_zhaopin_jobs',
            $wheresql
        ));
        if($jobslist){
            $tocon = str_replace('keyword',$keyword,$zmdata['settings']['wx_reply_f']);
            $huanhang = "\n";
            foreach ($jobslist as $key => $value) {
                $tocon = $tocon.$huanhang.$huanhang.($key+1).$language_zimu['wechatapi_php_20'].'<a href="'.$_G['siteurl'].'source/plugin/zimu_zhaopin/h5/pages/jobs/view?ids='.$value['id'].'">'.$language_zimu['wechatapi_php_21'].$value['jobs_name'].'</a>'.$huanhang.$language_zimu['wechatapi_php_22'].$value['companyname'];
            }
            $tocon = $tocon.$huanhang.$huanhang.$zmdata['settings']['wx_reply_b'];
            $tocon = diconv($tocon, CHARSET, 'UTF-8');
        }else{
            $tocon = diconv($zmdata['settings']['wx_reply_no'], CHARSET, 'UTF-8');
        }
        return $this->transmitText($object,$tocon);


    }

    //����ͼƬ��Ϣ
    private function receiveImage($object)
    {
        $content = array(
            "MediaId" => $object->MediaId
        );
        $result  = $this->transmitImage($object, $content);
        return $result;
    }
    
    //����λ����Ϣ
    private function receiveLocation($object)
    {
        return $result;
    }
    
    //����������Ϣ
    private function receiveVoice($object)
    {
        return $result;
    }
    
    //������Ƶ��Ϣ
    private function receiveVideo($object)
    {
        return $result;
    }
    
    //����������Ϣ
    private function receiveLink($object)
    {
        return $result;
    }
    
    //�ظ��ı���Ϣ
    private function transmitText($object, $content)
    {
        if (!isset($content) || empty($content)) {
            return "";
        }
        
        $xmlTpl = "<xml>
    <ToUserName><![CDATA[%s]]></ToUserName>
    <FromUserName><![CDATA[%s]]></FromUserName>
    <CreateTime>%s</CreateTime>
    <MsgType><![CDATA[text]]></MsgType>
    <Content><![CDATA[%s]]></Content>
</xml>";
        $result = sprintf($xmlTpl, $object->FromUserName, $object->ToUserName, time(), $content);
        
        return $result;
    }
    
    //�ظ�ͼ����Ϣ
    private function transmitNews($object, $newsArray)
    {
        if (!is_array($newsArray)) {
            return "";
        }
        $itemTpl  = "        <item>
            <Title><![CDATA[%s]]></Title>
            <Description><![CDATA[%s]]></Description>
            <PicUrl><![CDATA[%s]]></PicUrl>
            <Url><![CDATA[%s]]></Url>
        </item>
";
        $item_str = "";
        foreach ($newsArray as $item) {
            $item_str .= sprintf($itemTpl, $item['Title'], $item['Description'], $item['PicUrl'], $item['Url']);
        }
        $xmlTpl = "<xml>
    <ToUserName><![CDATA[%s]]></ToUserName>
    <FromUserName><![CDATA[%s]]></FromUserName>
    <CreateTime>%s</CreateTime>
    <MsgType><![CDATA[news]]></MsgType>
    <ArticleCount>%s</ArticleCount>
    <Articles>
$item_str    </Articles>
</xml>";
        
        $result = sprintf($xmlTpl, $object->FromUserName, $object->ToUserName, time(), count($newsArray));
        return $result;
    }
    
    //�ظ�������Ϣ
    private function transmitMusic($object, $musicArray)
    {
        if (!is_array($musicArray)) {
            return "";
        }
        $itemTpl = "<Music>
        <Title><![CDATA[%s]]></Title>
        <Description><![CDATA[%s]]></Description>
        <MusicUrl><![CDATA[%s]]></MusicUrl>
        <HQMusicUrl><![CDATA[%s]]></HQMusicUrl>
    </Music>";
        
        $item_str = sprintf($itemTpl, $musicArray['Title'], $musicArray['Description'], $musicArray['MusicUrl'], $musicArray['HQMusicUrl']);
        
        $xmlTpl = "<xml>
    <ToUserName><![CDATA[%s]]></ToUserName>
    <FromUserName><![CDATA[%s]]></FromUserName>
    <CreateTime>%s</CreateTime>
    <MsgType><![CDATA[music]]></MsgType>
    $item_str
</xml>";
        
        $result = sprintf($xmlTpl, $object->FromUserName, $object->ToUserName, time());
        return $result;
    }
    
    //�ظ�ͼƬ��Ϣ
    private function transmitImage($object, $imageArray)
    {
        $itemTpl = "<Image>
        <MediaId><![CDATA[%s]]></MediaId>
    </Image>";
        
        $item_str = sprintf($itemTpl, $imageArray['MediaId']);
        
        $xmlTpl = "<xml>
    <ToUserName><![CDATA[%s]]></ToUserName>
    <FromUserName><![CDATA[%s]]></FromUserName>
    <CreateTime>%s</CreateTime>
    <MsgType><![CDATA[image]]></MsgType>
    $item_str
</xml>";
        
        $result = sprintf($xmlTpl, $object->FromUserName, $object->ToUserName, time());
        return $result;
    }
    
    //�ظ�������Ϣ
    private function transmitVoice($object, $voiceArray)
    {
        $itemTpl = "<Voice>
        <MediaId><![CDATA[%s]]></MediaId>
    </Voice>";
        
        $item_str = sprintf($itemTpl, $voiceArray['MediaId']);
        $xmlTpl   = "<xml>
    <ToUserName><![CDATA[%s]]></ToUserName>
    <FromUserName><![CDATA[%s]]></FromUserName>
    <CreateTime>%s</CreateTime>
    <MsgType><![CDATA[voice]]></MsgType>
    $item_str
</xml>";
        
        $result = sprintf($xmlTpl, $object->FromUserName, $object->ToUserName, time());
        return $result;
    }
    
    //�ظ���Ƶ��Ϣ
    private function transmitVideo($object, $videoArray)
    {
        $itemTpl = "<Video>
        <MediaId><![CDATA[%s]]></MediaId>
        <ThumbMediaId><![CDATA[%s]]></ThumbMediaId>
        <Title><![CDATA[%s]]></Title>
        <Description><![CDATA[%s]]></Description>
    </Video>";
        
        $item_str = sprintf($itemTpl, $videoArray['MediaId'], $videoArray['ThumbMediaId'], $videoArray['Title'], $videoArray['Description']);
        
        $xmlTpl = "<xml>
    <ToUserName><![CDATA[%s]]></ToUserName>
    <FromUserName><![CDATA[%s]]></FromUserName>
    <CreateTime>%s</CreateTime>
    <MsgType><![CDATA[video]]></MsgType>
    $item_str
</xml>";
        
        $result = sprintf($xmlTpl, $object->FromUserName, $object->ToUserName, time());
        return $result;
    }
    
    //�ظ���ͷ���Ϣ
    private function transmitService($object)
    {
        $xmlTpl = "<xml>
    <ToUserName><![CDATA[%s]]></ToUserName>
    <FromUserName><![CDATA[%s]]></FromUserName>
    <CreateTime>%s</CreateTime>
    <MsgType><![CDATA[transfer_customer_service]]></MsgType>
</xml>";
        $result = sprintf($xmlTpl, $object->FromUserName, $object->ToUserName, time());
        return $result;
    }
    
    //�ظ��������ӿ���Ϣ
    private function relayPart3($url, $rawData)
    {
        $headers = array(
            "Content-Type: text/xml; charset=utf-8"
        );
        $ch      = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $rawData);
        $output = curl_exec($ch);
        curl_close($ch);
        return $output;
    }
    
    //�ֽ�תEmoji����
    function bytes_to_emoji($cp)
    {
        if ($cp > 0x10000) { # 4 bytes
            return chr(0xF0 | (($cp & 0x1C0000) >> 18)) . chr(0x80 | (($cp & 0x3F000) >> 12)) . chr(0x80 | (($cp & 0xFC0) >> 6)) . chr(0x80 | ($cp & 0x3F));
        } else if ($cp > 0x800) { # 3 bytes
            return chr(0xE0 | (($cp & 0xF000) >> 12)) . chr(0x80 | (($cp & 0xFC0) >> 6)) . chr(0x80 | ($cp & 0x3F));
        } else if ($cp > 0x80) { # 2 bytes
            return chr(0xC0 | (($cp & 0x7C0) >> 6)) . chr(0x80 | ($cp & 0x3F));
        } else { # 1 byte
            return chr($cp);
        }
    }
}