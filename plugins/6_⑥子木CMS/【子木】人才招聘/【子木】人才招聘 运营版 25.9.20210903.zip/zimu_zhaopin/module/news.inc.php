<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$wherearr = array();
$cid = intval($_GET['cid']);
if($cid){
$wherearr[]=' cid= '.$cid.' ';
}


$wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';

$pindex = max(1, intval($_GET['page']));
$psize = 10;


$catdata = DB::fetch_all('select * from %t order by id asc', array(
	'zimu_zhaopin_news_cat'
));

$newslist = DB::fetch_all('select * from %t %i order by id desc limit %d,%d', array(
    'zimu_zhaopin_news',
    $wheresql,
	($pindex - 1) * $psize,
	$psize
));


$total = DB::result_first("SELECT count(*) FROM %t %i", array(
    "zimu_zhaopin_news",
    $wheresql,
    $_G['timestamp'],
));

$totalPages = ceil($total/$psize);

$pager = pagination($total, $pindex, $psize);

    $rand=array();
$rand_nums = $total > 30 ? 30 : $total;
    while(count($arr) < $rand_nums){
        $arr[]=rand(1,$total);
        $arr=array_unique($arr);
    }
    $rand_ids = implode(",",$arr);

$randnews = DB::fetch_all('select * from %t where id in (%n)', array(
    'zimu_zhaopin_news',
    $arr
));

$navtitle = $share_title = $zmdata['settings']['news_seo_title'] ? $zmdata['settings']['news_seo_title'] : $navtitle;
$keywords = $zmdata['settings']['news_seo_keyword'] ? $zmdata['settings']['news_seo_keyword'] : $navtitle;
$description = $share_desc = $zmdata['settings']['news_seo_desc'] ? $zmdata['settings']['news_seo_desc'] : $navtitle;

include zimu_template('news');