<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}


    $manage_uids = str_replace(';', ',', $zmdata['manage_uids']);
    $manage_uids = explode(',', $manage_uids);

    if($_G['uid'] && (in_array($_G['uid'],$manage_uids) || $_G['uid']==$res['company']['kefu_uid'])){
        $isadmin = 1;
    }


$rid = intval($_GET['rid']);

$resume_info = $info = DB::fetch_first('select * from %t where id=%d order by id asc', array(
        'zimu_zhaopin_resume',
        $rid
    ));


$info['work_list'] = _get_duration(DB::fetch_all('select * from %t where uid=%d and pid=%d order by id asc', array(
        'zimu_zhaopin_resume_work',
        $resume_info['uid'],
        $rid
    )));

$info['work_duration'] = _get_total_work_duration($info['work_list']);
$info['work_count'] = count($info['work_list']);


$info['education_list'] = _get_duration(DB::fetch_all('select * from %t where uid=%d and pid=%d order by id asc', array(
        'zimu_zhaopin_resume_education',
        $resume_info['uid'],
        $rid
    )));

$info['education_count'] = count($info['education_list']);

$utype = DB::result_first('select utype from %t where uid=%d order by id desc', array(
        'zimu_zhaopin_members',
        $_G['uid']
    ));

$hasfav = DB::fetch_first('select * from %t where company_uid=%d and resume_id=%d order by did desc', array(
    'zimu_zhaopin_company_favorites',
    $_G['uid'],
    $rid
));

$isresume = DB::fetch_first('select * from %t where company_uid=%d and resume_id=%d order by did desc', array(
    'zimu_zhaopin_company_down_resume',
    $_G['uid'],
    $rid
));

if($isadmin==1){
    $isresume['id'] = 'always_show_mobile';
}

if(!$isresume){

$info['telephone'] = substr_replace($info['telephone'],'****',3,4);
$info['fullname'] = cutstr($info['fullname'],2,'').($info['sex']==1 ? $language_zimu['viewresume_inc_php_0'] : $language_zimu['viewresume_inc_php_1']);

}

$company_info = DB::fetch_first('select * from %t where uid=%d order by id asc', array(
        'zimu_zhaopin_company_profile',
        $_G['uid']
    ));


$navtitle = $info['fullname'].$language_zimu['viewresume_inc_php_2'].$info['intention_jobs'].'_'.$zmdata['base']['title'];
$keywords = $info['fullname'].$language_zimu['viewresume_inc_php_3'].$zmdata['base']['title'];
$description = $info['specialty'];

$share_title = $info['fullname'].$language_zimu['viewresume_inc_php_4'].$info['intention_jobs'].'_'.$zmdata['base']['title'];
$share_desc = $zmdata['base']['share_desc'];
$share_url = rtrim($_G['siteurl'], '/').$_SERVER['REQUEST_URI'];
if ($info['photo_img'] && !preg_match('/^(http|\.)/i', $info['photo_img'])) {
   $info['photo_img'] = $_G['siteurl'].$info['photo_img'];
}
$share_thumb = $info['photo_img'] ? $info['photo_img'] : $share_thumb;

if($company_info){

$is_view_resume = DB::fetch_first('select * from %t where uid=%d and resumeid=%d order by id desc', array(
        'zimu_zhaopin_view_resume',
        $_G['uid'],
        $rid
    ));

if($is_view_resume){

    DB::query("update %t set hasdown=%d,addtime=%d where id=%d", array(
        'zimu_zhaopin_view_resume',
        $isresume ? 1 : 0,
        $_G['timestamp'],
        $is_view_resume['id']
    ));

}else{

        $view_resume_data['uid'] = $_G['uid'];
        $view_resume_data['resumeid'] = $rid;
        $view_resume_data['company_id'] = $company_info['id'];
        $view_resume_data['companyname'] = $company_info['companyname'];
        $view_resume_data['hasdown'] = $isresume ? 1 : 0;
        $view_resume_data['addtime'] = $_G['timestamp'];
        DB::insert('zimu_zhaopin_view_resume', $view_resume_data);
}

}

if($_G['uid']){

$is_interview = DB::fetch_first('select * from %t where resume_id=%d and company_uid=%d order by id desc', array(
        'zimu_zhaopin_company_interview',
        $rid,
        $_G['uid']
    ));

$is_viewlog = DB::fetch_first('select * from %t where uid=%d and rid=%d order by id desc', array(
        'zimu_zhaopin_com_viewlog',
        $_G['uid'],
        $rid
    ));

if($is_viewlog){

    DB::query("update %t set addtime=%d where id=%d", array(
        'zimu_zhaopin_com_viewlog',
        $_G['timestamp'],
        $is_viewlog['id']
    ));

}else{

        $com_viewlog['uid'] = $_G['uid'];
        $com_viewlog['rid'] = $rid;
        $com_viewlog['addtime'] = $_G['timestamp'];
        DB::insert('zimu_zhaopin_com_viewlog', $com_viewlog);
}

}

$manage_uids = str_replace(';', ',', $zmdata['manage_uids']);
$manage_uids = explode(',', $manage_uids);

$audit_tip1 = explode(PHP_EOL, trim($zmdata['settings']['audit_tip1']));
$audit_tip2 = explode(PHP_EOL, trim($zmdata['settings']['audit_tip2']));

if(file_exists(DISCUZ_ROOT . './source/plugin/zimu_zhaopin/module/a_change_area.inc.php') && ( $zmdata['settings']['change_city'] == 1 || $zmdata['settings']['change_area'] > 0) ){
$citycategory  = getcookie('citycategory');
$citycategory2 = getcookie('citycategory2');
if($zmdata['settings']['change_area']==2 && getcookie('citycategory2')){
$jobs_wheresql = ' and district2 = '.getcookie('citycategory2').' ';
$resume_wheresql = ' and district LIKE \'%.'.getcookie('citycategory2').'.%\' ';
$fenzhan_name2 = getcookie('citycategory2_cn');
}elseif(getcookie('citycategory')){
$jobs_wheresql = ' and district = '.getcookie('citycategory').' ';
$resume_wheresql = ' and district LIKE \'%'.getcookie('citycategory').'.%\' ';
$fenzhan_name1 = getcookie('citycategory_cn');
}
$fenzhan_name = getcookie('citycategory2_cn') ? getcookie('citycategory2_cn') : (getcookie('citycategory_cn') ? getcookie('citycategory_cn') : '');
}


$viewresume_seo_title = preg_replace(array('/fullname/','/sex_cn/','/age/','/education_cn/','/experience_cn/','/tag_cn/','/wage_cn/','/intention_jobs/','/specialty/','/fenzhan/'), array($info['fullname'],$info['sex_cn'],$info['age'],$info['education_cn'],$info['experience_cn'],$info['tag_cn'],$info['wage_cn'],$info['intention_jobs'],$info['specialty'],$fenzhan_name), $zmdata['settings']['viewresume_seo_title']);

$viewresume_seo_keyword = preg_replace(array('/fullname/','/sex_cn/','/age/','/education_cn/','/experience_cn/','/tag_cn/','/wage_cn/','/intention_jobs/','/specialty/','/fenzhan/'), array($info['fullname'],$info['sex_cn'],$info['age'],$info['education_cn'],$info['experience_cn'],$info['tag_cn'],$info['wage_cn'],$info['intention_jobs'],$info['specialty'],$fenzhan_name), $zmdata['settings']['viewresume_seo_keyword']);

$viewresume_seo_desc = preg_replace(array('/fullname/','/sex_cn/','/age/','/education_cn/','/experience_cn/','/tag_cn/','/wage_cn/','/intention_jobs/','/specialty/','/fenzhan/'), array($info['fullname'],$info['sex_cn'],$info['age'],$info['education_cn'],$info['experience_cn'],$info['tag_cn'],$info['wage_cn'],$info['intention_jobs'],$info['specialty'],$fenzhan_name), $zmdata['settings']['viewresume_seo_desc']);

$viewresume_seo_desc = str_replace(array("\r\n", "\r", "\n"), "", $viewresume_seo_desc);

$navtitle = $share_title = $viewresume_seo_title ? $viewresume_seo_title : $navtitle;
$keywords = $viewresume_seo_keyword ? $viewresume_seo_keyword : $navtitle;
$description = $share_desc = $viewresume_seo_desc ? $viewresume_seo_desc : $navtitle;

$setmeal = DB::fetch_first('select * from %t where uid = %d order by id desc', array(
    'zimu_zhaopin_members_setmeal',
    $_G['uid']
));

if ($company_info && $setmeal['setmeal_id'] > 0 && $setmeal['endtime'] < $_G['timestamp'] && $setmeal['endtime'] > 0) {
    
    
    $freesetmeal = DB::fetch_first('select * from %t where id=1 order by id desc', array(
        'zimu_zhaopin_setmeal'
    ));
    
    $timestamp                         = time();
    $setsqlarr2['expire']              = $freesetmeal['is_free'] == 1 ? 1 : 0;
    $setsqlarr2['uid']                 = $_G['uid'];
    $setsqlarr2['setmeal_id']          = $freesetmeal['id'];
    $setsqlarr2['setmeal_name']        = $freesetmeal['setmeal_name'];
    $setsqlarr2['days']                = $freesetmeal['days'];
    $setsqlarr2['expense']             = $freesetmeal['expense'];
    $setsqlarr2['jobs_meanwhile']      = $freesetmeal['jobs_meanwhile'];
    $setsqlarr2['refresh_jobs_free']   = $freesetmeal['refresh_jobs_free'];
    $setsqlarr2['download_resume']     = $freesetmeal['download_resume'];
    $setsqlarr2['download_resume_max'] = $freesetmeal['download_resume_max'];
    $setsqlarr2['added']               = $freesetmeal['added'];
    $setsqlarr2['starttime']           = $_G['timestamp'];
    if ($freesetmeal['days'] > 0) {
        $setsqlarr2['endtime'] = strtotime("" . $freesetmeal['days'] . " days");
    } else {
        $setsqlarr2['endtime'] = "0";
    }
    
    $setsqlarr2['set_sms'] = $setmeal['set_sms'] + $freesetmeal['set_sms'];
    
    $setsqlarr2['show_apply_contact']         = $freesetmeal['show_apply_contact'];
    $setsqlarr2['is_free']                    = $freesetmeal['is_free'];
    $setsqlarr2['discount_download_resume']   = $freesetmeal['discount_download_resume'];
    $setsqlarr2['discount_sms']               = $freesetmeal['discount_sms'];
    $setsqlarr2['discount_stick']             = $freesetmeal['discount_stick'];
    $setsqlarr2['discount_emergency']         = $freesetmeal['discount_emergency'];
    $setsqlarr2['discount_auto_refresh_jobs'] = $freesetmeal['discount_auto_refresh_jobs'];
    

    DB::update('zimu_zhaopin_members_setmeal', $setsqlarr2, array(
        'uid' => $_G['uid']
    ));
    
    DB::update('zimu_zhaopin_company_profile', array(
        'setmeal_id' => $setsqlarr2['setmeal_id'],
        'setmeal_name' => $setsqlarr2['setmeal_name']
    ), array(
        'uid' => $_G['uid']
    ));


    DB::update('zimu_zhaopin_jobs', array(
        'setmeal_deadline' => $setsqlarr2['endtime'],
        'setmeal_id' => $setsqlarr2['setmeal_id'],
        'setmeal_name' => $setsqlarr2['setmeal_name']
    ), array(
        'uid' => $_G['uid']
    ));
    
}

    DB::query("update %t set click=click+1 where id=%d", array(
        'zimu_zhaopin_resume',
        $rid
    ));

    if(checkmobile() && $zmdata['settings']['open_newwap']==1){
        dheader('Location:' . $_G['siteurl'] . 'source/plugin/zimu_zhaopin/h5/pages/resume/view?ids='.$rid.'&mobile=2');
        exit();
    }

include zimu_template('viewresume');