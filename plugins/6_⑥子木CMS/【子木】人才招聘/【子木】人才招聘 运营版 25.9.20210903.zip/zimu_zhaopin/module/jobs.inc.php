<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
    'zimu_zhaopin_parameter2',
    'jobsad'
));

$paramters_indexad = unserialize($paramter['parameter']);

$category_jobs = DB::fetch_all('select * from %t where parentid=0 order by category_order asc,id asc', array(
    'zimu_zhaopin_category_jobs'
),'id');

foreach ($category_jobs as $key => $value) {
    
    $category_jobs[$key]['list'] = DB::fetch_all('select * from %t where parentid=%d order by category_order asc,id asc', array(
        'zimu_zhaopin_category_jobs',
        $value['id']
    ));
    
}


$districtlist = DB::fetch_all('select * from %t where parentid=0 order by sort asc,id asc', array(
    'zimu_zhaopin_area'
), 'id');

foreach ($districtlist as $key => $value) {
    if (!$cityone) {
        $cityone = $key;
    }
    $districtlist[$key]['list'] = DB::fetch_all('select * from %t where parentid=%d order by sort asc,id asc', array(
        'zimu_zhaopin_area',
        $value['id']
    ),'id');
    
}

$category = array();

$categoryData = DB::fetch_all('select c_id,c_alias,c_name from %t order by c_order asc,c_id asc', array(
    'zimu_zhaopin_category'
));

foreach ($categoryData as $key => $val) {
    $category[$val['c_alias']][$val['c_id']] = $val['c_name'];
}

$wagelist = $category['ZM_wage'];

$explist = $category['ZM_experience'];

$naturelist = $category['ZM_jobs_nature'];

$edulist = $category['ZM_education'];

$taglist = $category['ZM_jobtag'];

$tradelist = $category['ZM_trade'];


$citycategory  = intval($_GET['citycategory']);
$citycategory2 = intval($_GET['citycategory2']);
$citycategory3 = intval($_GET['citycategory3']);

if($_GET['all'] !=1 && !$citycategory && file_exists(DISCUZ_ROOT . './source/plugin/zimu_zhaopin/module/a_change_area.inc.php') && ( $zmdata['settings']['change_city'] == 1 || $zmdata['settings']['change_area'] > 0) ){
$citycategory  = getcookie('citycategory');
$citycategory2 = getcookie('citycategory2');  
}

$jobcategory   = intval($_GET['jobcategory']);
$jobcategory2  = intval($_GET['topcat']) ? $jobcategory : intval($_GET['jobcategory2']);
$wage          = intval($_GET['wage']); 

if($zmdata['settings']['area_three'] && $citycategory2){

    $area_three = DB::fetch_all('select * from %t where parentid=%d order by sort asc,id asc', array(
        'zimu_zhaopin_area',
        $citycategory2
    ), 'id');

}


$wherearr = array();
if ($citycategory3) {
    $wherearr[] = ' district3 = ' . $citycategory3;
    $select_city = $districtlist[$citycategory]['list'][$citycategory2]['name'];
} elseif ($citycategory2) {
    $wherearr[] = ' district2 = ' . $citycategory2;
    $select_city = $districtlist[$citycategory]['list'][$citycategory2]['name'];
} elseif ($citycategory) {
    $wherearr[] = ' district = ' . $citycategory;
    $select_city = $districtlist[$citycategory]['name'];
}
if ($jobcategory) {
    $topcat     = intval($_GET['topcat']) ? 'topclass' : 'category';
    $wherearr[] = ' ' . $topcat . ' = ' . $jobcategory . ' ';
}

if ($wage) {
    $wagewage = DB::fetch_first('select * from %t where c_alias=%s and c_id=%d order by c_id desc', array(
        'zimu_zhaopin_category',
        'ZM_wage',
        $wage
    ));
    $wagearray = explode('~',$wagewage['c_name']);
    if($wagewage['c_name'] != $language_zimu['jobs_inc_php_0']){
        $minwage = intval($wagearray[0]);
        $maxwage = intval($wagearray[1]) > 0 ? intval($wagearray[1]) : 999999;
        if($minwage && $maxwage){
            $wherearr[] = '(( wage = '.$wage.' ) or ( maxwage >= '.$minwage.' and minwage <= '.$maxwage.' ))';
        }
    }else{
        $wherearr[] = ' wage = ' . $wage;
    }
    //$wherearr[] = ' wage = ' . $wage;
}

$trade = intval($_GET['trade']);
if ($trade) {
    $wherearr[] = ' trade = ' . $trade;
}
$exp = intval($_GET['exp']);
if ($exp) {
    $wherearr[] = ' experience = ' . $exp;
}
$nature = intval($_GET['nature']);
if ($nature) {
    $wherearr[] = ' nature = ' . $nature;
}
$edu = intval($_GET['edu']);
if ($edu) {
    $wherearr[] = ' education = ' . $edu;
}

$certificate = intval($_GET['certificate']);
if ($certificate) {
    $wherearr[] = ' company_certificate = 1';
}

$wherearr[] = ' audit !=3 ';
$wherearr[] = ' company_audit !=3 ';
$wherearr[] = ' display !=2 ';

$key = dhtmlspecialchars($_GET['key']);
$key = stripsearchkey($key);
$key = daddslashes($key);

$wherearr[] = ' (jobs_name LIKE \'%' . $key . '%\' OR companyname LIKE \'%' . $key . '%\' OR category_cn LIKE \'%' . $key . '%\' OR contents LIKE \'%' . $key . '%\') ';

$wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE ' . implode(' AND ', $wherearr) : '';

$pindex = max(1, intval($_GET['page']));
$psize  = 10;

$top_jobslist = array();

if ($pindex == 1) {
    
    if ($zmdata['settings']['auth_sort']) {
        
        $top_jobslist = DB::fetch_all('select * from %t %i and stick_endtime > %d ' . $noauditwheresql2 . ' order by company_certificate desc,refreshtime desc,stick_endtime desc,id desc', array(
            'zimu_zhaopin_jobs',
            $wheresql,
            $_G['timestamp']
        ));
        
    } else {
        
        $top_jobslist = DB::fetch_all('select * from %t %i and stick_endtime > %d ' . $noauditwheresql2 . ' order by refreshtime desc,stick_endtime desc,id desc', array(
            'zimu_zhaopin_jobs',
            $wheresql,
            $_G['timestamp']
        ));
        
    }
    
}

$jobslist2 = array();

if ($zmdata['settings']['auth_sort']) {
    
    $jobslist2 = DB::fetch_all('select * from %t %i and stick_endtime < %d ' . $noauditwheresql2 . ' order by company_certificate desc,refreshtime desc,id desc limit %d,%d', array(
        'zimu_zhaopin_jobs',
        $wheresql,
        $_G['timestamp'],
        ($pindex - 1) * $psize,
        $psize
    ));
    
} else {
    
    $jobslist2 = DB::fetch_all('select * from %t %i and stick_endtime < %d ' . $noauditwheresql2 . ' order by refreshtime desc,id desc limit %d,%d', array(
        'zimu_zhaopin_jobs',
        $wheresql,
        $_G['timestamp'],
        ($pindex - 1) * $psize,
        $psize
    ));
    
}

$jobslist = array_merge($top_jobslist, $jobslist2);

if ($_G['uid']) {
    foreach ($jobslist as $key => $value) {
        
        $jobslist[$key]['hasfav'] = DB::fetch_first('select * from %t where personal_uid=%d and jobs_id=%d order by did desc', array(
            'zimu_zhaopin_personal_favorites',
            $_G['uid'],
            $value['id']
        ));
        
        $jobslist[$key]['isresume'] = DB::fetch_first('select * from %t where personal_uid=%d and jobs_id=%d order by did desc', array(
            'zimu_zhaopin_personal_jobs_apply',
            $_G['uid'],
            $value['id']
        ));
        
    }
}


$total = DB::result_first("SELECT count(*) FROM %t %i and stick_endtime < %d" . $noauditwheresql2, array(
    "zimu_zhaopin_jobs",
    $wheresql,
    $_G['timestamp']
));

$totalPages = ceil($total / $psize);

$pager = pagination($total, $pindex, $psize);

$resume_info = DB::fetch_first('select * from %t where uid=%d ' . $noauditwheresql2 . ' order by id asc', array(
    'zimu_zhaopin_resume',
    $_G['uid']
));

if (!checkmobile()) {
    
    $randjobslist = DB::fetch_all('select * from %t where audit !=3 and display !=2 ' . $noauditwheresql2 . ' order by rand() limit 10', array(
        'zimu_zhaopin_jobs'
    ));
    
}


if($_G['uid'] && $zmdata['settings']['no_user_num']!=0){
$myresume = DB::fetch_first('select * from %t where uid=%d order by id asc', array(
    'zimu_zhaopin_resume',
    $_G['uid']
));
$mycom = DB::fetch_first('select * from %t where uid=%d order by id asc', array(
    'zimu_zhaopin_company_profile',
    $_G['uid']
));
if($myresume || $mycom){
$zmdata['settings']['no_user_num'] = 0;
}
}

$navtitle    = $share_title = $zmdata['settings']['jobs_seo_title'] ? $zmdata['settings']['jobs_seo_title'] : $navtitle;
$keywords    = $zmdata['settings']['jobs_seo_keyword'] ? $zmdata['settings']['jobs_seo_keyword'] : $navtitle;
$description = $share_desc = $zmdata['settings']['jobs_seo_desc'] ? $zmdata['settings']['jobs_seo_desc'] : $navtitle;
    if(checkmobile() && $zmdata['settings']['open_newwap']==1){
        dheader('Location:' . $_G['siteurl'] . 'source/plugin/zimu_zhaopin/h5/pages/index/jobs');
        exit();
    }
include zimu_template('jobs');
