<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$op = addslashes($_GET['op']);
$op = $op ? $op : 'list';

$category_jobs = DB::fetch_all('select * from %t order by c_order asc,c_id asc', array(
    'zimu_zhaopin_category'
));

foreach ($category_jobs as $key => $value) {

$category_jobs2[$value['c_alias']][$value['c_id']] = $value['c_name'];

}

if ($op == 'ajaxtpl') {
  
    $infotype = intval($_GET['infotype']);

    $tpl = intval($_GET['tpl']);

    if ($infotype==2) {

        $wheresql    = 'where audit !=3 and display != 2 ';
        $keywordtype = intval($_GET['keywordtype']);
        $keyword     = trim(zm_diconv($_GET['keyword']));
        $keyword     = dhtmlspecialchars($keyword);
        $keyword     = stripsearchkey($keyword);
        $keyword     = daddslashes($keyword);
    
        if (!empty($keyword)) {
            if ($keywordtype == 1) {
                $wheresql .= " and `id` = '{$keyword}' ";
            } elseif ($keywordtype == 2) {
                $wheresql .= " and `fullname` LIKE '%{$keyword}%' ";
            } elseif ($keywordtype == 3) {
                $wheresql .= " and `telephone` = '{$keyword}' ";
            } elseif ($keywordtype == 4) {
                $wheresql .= " and `intention_jobs` LIKE '%{$keyword}%' ";
            } elseif ($keywordtype == 5) {
                $wheresql .= " and `uid` = '{$keyword}' ";
            }
        }
    
        $audit = intval($_GET['audit']);
        if (!empty($audit)) {
            $wheresql .= " and audit = " . $audit;
        }

        $sex = intval($_GET['sex']);
        if (!empty($sex)) {
            $wheresql .= " and sex = " . $sex;
        }

        $education = intval($_GET['education']);
        if (!empty($education)) {
            $wheresql .= " and education >= " . $education;
        }

        $experience = intval($_GET['experience']);
        if (!empty($experience)) {
            $wheresql .= " and experience >= " . $experience;
        }

        $area = addslashes($_GET['area']);
        if (!empty($area)) {
            $wheresql .= " and ( `district` LIKE '%{$area}%' ) ";
        }

        $order = intval($_GET['order']);
        if ($order==1) {
            $whereorder = 'refreshtime';
        } else {
            $whereorder = 'id';
        }

        $todate = intval($_GET['todate']);
        if (!empty($todate)) {
            $wheresql .= " and addtime > ".(time()-(86400*$todate))." ";
        }

        $istop = intval($_GET['istop']);
        if (!empty($istop)) {
            $wheresql .= " and stick_endtime > ".time()." ";
        }

        $limit = intval($_GET['limit']) ? intval($_GET['limit']) : 1;

        $mp_jobs = DB::fetch_all('select * from %t %i order by %i desc limit %d', array(
        'zimu_zhaopin_resume',
        $wheresql,
        $whereorder,
        $limit
    ));

        foreach ($mp_jobs as $key => $value) {
            if ($zmdata['settings']['wx_create_qrcode']==1) {
                require_once DISCUZ_ROOT . './source/plugin/zimu_zhaopin/class/wechat.lib.class.php';
                $wechat_client = new WeChatClient($zmdata['base']['weixin_appid'], $zmdata['base']['weixin_appsecret']);
                
                $qrcode_url = $wechat_client->getQrcodeImgUrlByTicket($wechat_client->getQrcodeTicket(array('scene_str'=>'viewresume'.'zimuyun'.$value['id'],'expire'=>2591000)));
                $qrcode_img = 'data:image/jpeg;base64,'.base64_encode(dfsockopen($qrcode_url));
                $mp_jobs[$key]['qrcode_img'] = $qrcode_img && $qrcode_img != 'data:image/jpeg;base64,' ? $qrcode_img : 'data:image/jpeg;base64,'.base64_encode(file_get_contents($qrcode_url));
            } else {
                $mp_jobs[$key]['qrcode_img'] = ZIMUCMS_URL.':toqrcode&url=' . urlencode(ZIMUCMS_URL . '&model=viewresume&rid=' . $value['id']);
            }
        }

        include zimu_template('admins/mptpl_resume_'.$tpl, '');

    }else if($infotype==3){

        $wheresql    = 'where 1=1 ';
        $keyword = intval($_GET['keyword']) ? intval($_GET['keyword']) : 1;
        if (!empty($keyword)) {
            $wheresql .= " and id = " . $keyword;
        }

        $limit = intval($_GET['limit']) ? intval($_GET['limit']) : 1;

        $mp_company = DB::fetch_first('select * from %t where id=%d order by id asc', array(
            'zimu_zhaopin_company_profile',
            $keyword
        ));

        $mp_company['list'] = DB::fetch_all('select * from %t where company_id=%d and audit!=3 and display !=2 order by id asc limit %d', array(
            'zimu_zhaopin_jobs',
            $keyword,
            $limit
        ));

        foreach ($mp_company['list'] as $key => $value) {
        
            if ($zmdata['settings']['wx_create_qrcode']==1) {
                require_once DISCUZ_ROOT . './source/plugin/zimu_zhaopin/class/wechat.lib.class.php';
                $wechat_client = new WeChatClient($zmdata['base']['weixin_appid'], $zmdata['base']['weixin_appsecret']);

                $qrcode_url = $wechat_client->getQrcodeImgUrlByTicket($wechat_client->getQrcodeTicket(array('scene_str'=>'viewjob'.'zimuyun'.$value['id'],'expire'=>2591000)));
                $qrcode_img = 'data:image/jpeg;base64,'.base64_encode(dfsockopen($qrcode_url));
                $mp_company['list'][$key]['qrcode_img'] = $qrcode_img && $qrcode_img != 'data:image/jpeg;base64,' ? $qrcode_img : 'data:image/jpeg;base64,'.base64_encode(file_get_contents($qrcode_url));
            } else {
                $mp_company['list'][$key]['qrcode_img'] = ZIMUCMS_URL.':toqrcode&url=' . urlencode(ZIMUCMS_URL . '&model=viewjob&jid=' . $value['id']);
            }
        }


        include zimu_template('admins/mptpl_qiye_'.$tpl, '');


    }else{
        
        $wheresql    = 'where audit !=3 and display != 2 ';
        $keywordtype = intval($_GET['keywordtype']);
        $keyword     = trim(zm_diconv($_GET['keyword']));
        $keyword     = dhtmlspecialchars($keyword);
        $keyword     = stripsearchkey($keyword);
        $keyword     = daddslashes($keyword);
    
        if (!empty($keyword)) {
            if ($keywordtype == 1) {
                $wheresql .= " and `id` = '{$keyword}' ";
            } elseif ($keywordtype == 2) {
                $wheresql .= " and `jobs_name` LIKE '%{$keyword}%' ";
            } elseif ($keywordtype == 3) {
                $wheresql .= " and `company_id` = '{$keyword}' ";
            } elseif ($keywordtype == 4) {
                $wheresql .= " and `companyname` LIKE '%{$keyword}%' ";
            } elseif ($keywordtype == 5) {
                $wheresql .= " and `uid` = '{$keyword}' ";
            }
        }
    
        $audit = intval($_GET['audit']);
        if (!empty($audit)) {
            $wheresql .= " and audit = " . $audit;
        }

        $area = intval($_GET['area']);
        if (!empty($area)) {
            $wheresql .= " and (`district` = '{$area}' or `district2` = '{$area}' or `district3` = '{$area}') ";
        }

        $order = intval($_GET['order']);
        if ($order==1) {
            $whereorder = 'refreshtime';
        } else {
            $whereorder = 'id';
        }

        $todate = intval($_GET['todate']);
        if (!empty($todate)) {
            $wheresql .= " and addtime > ".(time()-(86400*$todate))." ";
        }

        $istop = intval($_GET['istop']);
        if (!empty($istop)) {
            $wheresql .= " and stick_endtime > ".time()." ";
        }

        $limit = intval($_GET['limit']) ? intval($_GET['limit']) : 1;

        $mp_jobs = DB::fetch_all('select * from %t %i order by %i desc limit %d', array(
        'zimu_zhaopin_jobs',
        $wheresql,
        $whereorder,
        $limit
    ));

        foreach ($mp_jobs as $key => $value) {
            $mp_jobs[$key]['company'] = DB::fetch_first('select * from %t where id=%d order by id asc', array(
            'zimu_zhaopin_company_profile',
            $value['company_id']
        ));
        
            if ($zmdata['settings']['wx_create_qrcode']==1) {
                require_once DISCUZ_ROOT . './source/plugin/zimu_zhaopin/class/wechat.lib.class.php';
                $wechat_client = new WeChatClient($zmdata['base']['weixin_appid'], $zmdata['base']['weixin_appsecret']);

                $qrcode_url = $wechat_client->getQrcodeImgUrlByTicket($wechat_client->getQrcodeTicket(array('scene_str'=>'viewjob'.'zimuyun'.$value['id'],'expire'=>2591000)));
                $qrcode_img = 'data:image/jpeg;base64,'.base64_encode(dfsockopen($qrcode_url));
                $mp_jobs[$key]['qrcode_img'] = $qrcode_img && $qrcode_img != 'data:image/jpeg;base64,' ? $qrcode_img : 'data:image/jpeg;base64,'.base64_encode(file_get_contents($qrcode_url));
            } else {
                $mp_jobs[$key]['qrcode_img'] = ZIMUCMS_URL.':toqrcode&url=' . urlencode(ZIMUCMS_URL . '&model=viewjob&jid=' . $value['id']);
            }
        }

        include zimu_template('admins/mptpl_job_'.$tpl, '');
    }
    


} else {
    

    $infotype = intval($_GET['infotype']);
    $infotype = $infotype ? $infotype : '1';

    include zimu_template('admins/admins_' . $type.'_'.$infotype, '');
    
    
}