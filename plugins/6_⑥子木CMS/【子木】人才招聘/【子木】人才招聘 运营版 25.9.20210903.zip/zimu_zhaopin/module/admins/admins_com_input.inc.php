<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}


$category_jobs = DB::fetch_all('select * from %t order by c_order asc,c_id asc', array(
    'zimu_zhaopin_category'
));

foreach ($category_jobs as $key => $value) {

    $category_jobs2[$value['c_alias']][$value['c_id']] = $value['c_name'];

}

$tag_arr = $category_jobs2['ZM_jobtag'];

$arealist = DB::fetch_all('select * from %t where parentid=0 order by sort asc,id asc', array(
    'zimu_zhaopin_area'
));


if(submitcheck('submit')) {

        $paramters = $_GET['options'];

        $isadd = DB::fetch_first('select * from %t where name=%s order by id desc', array(
            'zimu_zhaopin_parameter2',
            'com_input'
        ));

        if ($isadd['id'] > 0) {

        DB::query("update %t set parameter=%s where id=%d", array(
            'zimu_zhaopin_parameter2',
            serialize($paramters),
            $isadd['id']
        ));
            
        } else {

        $adddata = array(
                'name'=>'com_input',
                'parameter'=>serialize($paramters),
        );

            DB::insert('zimu_zhaopin_parameter2', $adddata);
            
        }
        
        
        include template('zimu_zhaopin:common/success');
        


}else{


        $paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
            'zimu_zhaopin_parameter2',
            'com_input'
        ));
        
        $paramters = unserialize($paramter['parameter']);

include zimu_template('admins/admins_'.$type,'');


}