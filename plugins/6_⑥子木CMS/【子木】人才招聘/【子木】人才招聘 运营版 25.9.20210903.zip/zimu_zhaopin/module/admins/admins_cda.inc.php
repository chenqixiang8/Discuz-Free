<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$op = addslashes($_GET['op']);
$op = $op ? $op : 'com_jobs_apply';

if ($op == 'com_jobs_apply') {

        $state_arr = array('1'=>$language_zimu['admins_cda_inc_php_0'],'2'=>$language_zimu['admins_cda_inc_php_1'],'3'=>$language_zimu['admins_cda_inc_php_2'],'4'=>$language_zimu['admins_cda_inc_php_3']);

        if(strpos($_GET['company_id'],'jobs') !== false){
            $company_id = $_GET['company_id'];
            $company_id2 = str_replace('jobs','',$company_id);
            if($company_id2){
                $wheresql = ' where jobs_id='.$company_id2;
            }
        }else{
            $company_id = intval($_GET['company_id']);
            if($company_id){
                $wheresql = ' where company_id='.$company_id;
            }
        }

    $pindex = max(1, intval($_GET['page']));
    $psize  = 30;

        $total = DB::result_first('select count(*) from %t %i order by did desc', array(
            'zimu_zhaopin_personal_jobs_apply',
            $wheresql
        ));

        $apply_list = DB::fetch_all('select * from %t %i order by did desc limit %d,%d', array(
            'zimu_zhaopin_personal_jobs_apply',
            $wheresql,
        ($pindex - 1) * $psize,
        $psize
        ));

    $pager = pagination($total, $pindex, $psize);
    
    
}

if ($op == 'com_resume_down') {

        $state=I('state',0,'intval');   
        $state_arr = array('1'=>$language_zimu['admins_cda_inc_php_4'],'2'=>$language_zimu['admins_cda_inc_php_5'],'3'=>$language_zimu['admins_cda_inc_php_6'],'4'=>$language_zimu['admins_cda_inc_php_7']);

        $company_id = intval($_GET['company_id']);
        $down_type = intval($_GET['down_type']);

        if($down_type==2){
                $wheresql = ' where resume_id='.$company_id;
        }else{
            if($company_id){
                $mycomid = DB::fetch_first('select * from %t where id=%d order by id desc', array(
                    'zimu_zhaopin_company_profile',
                    $company_id
                ));
                $wheresql = ' where company_uid='.$mycomid['uid'];
            }
        }

        $pindex = max(1, intval($_GET['page']));
        $psize  = 30;

        $total = DB::result_first('select count(*) from %t %i order by did desc', array(
            'zimu_zhaopin_company_down_resume',
            $wheresql
        ));

        $down_list = DB::fetch_all('select * from %t %i order by did desc limit %d,%d', array(
            'zimu_zhaopin_company_down_resume',
            $wheresql,
        ($pindex - 1) * $psize,
        $psize
        ));

        $pager = pagination($total, $pindex, $psize);

}

if ($op == 'com_resume_favorites') {

$education_list = $category_jobs2['ZM_education'];
$experience_list = $category_jobs2['ZM_experience'];

$education_id = intval($_GET['education']);
$experience_id = intval($_GET['experience']);

$company_id = intval($_GET['company_id']);
if($company_id){
    $wheresql = ' where a.company_id='.$company_id;
}


$aaa = DB::query('select a.did,a.favorites_addtime,a.resume_id,a.company_uid,b.* from %t a left join %t b on a.resume_id=b.id where %i order by favorites_addtime desc', array('zimu_zhaopin_company_favorites','zimu_zhaopin_resume',$_G['uid'],$wheresql));

while($res = DB::fetch($aaa)){
 $favorites[] = $res;
}

}

if ($op == 'com_viewlog') {

$company_id = intval($_GET['company_id']);

        $pindex = max(1, intval($_GET['page']));
        $psize  = 30;

if($company_id){

    $mycomid = DB::fetch_first('select * from %t where id=%d order by id desc', array(
            'zimu_zhaopin_company_profile',
            $company_id
        ));

    $wheresql = ' where uid='.$mycomid['uid'];
}

        $total = DB::result_first('select count(*) from %t %i order by addtime desc', array(
            'zimu_zhaopin_com_viewlog',
            $wheresql
        ));

        $favorites = DB::fetch_all('select * from %t %i order by addtime desc limit %d,%d', array(
            'zimu_zhaopin_com_viewlog',
            $wheresql,
            ($pindex - 1) * $psize,
            $psize
        ));

        $pager = pagination($total, $pindex, $psize);


}


if ($op == 'com_jobs_viewlog') {

$company_id = intval($_GET['company_id']);

        $pindex = max(1, intval($_GET['page']));
        $psize  = 30;

if($company_id){

    $wheresql = ' where cid='.$company_id;
}

        $total = DB::result_first('select count(*) from %t %i order by addtime desc', array(
            'zimu_zhaopin_per_viewlog',
            $wheresql
        ));

        $favorites = DB::fetch_all('select * from %t %i order by addtime desc limit %d,%d', array(
            'zimu_zhaopin_per_viewlog',
            $wheresql,
            ($pindex - 1) * $psize,
            $psize
        ));

        $pager = pagination($total, $pindex, $psize);

}

if ($op == 'per_jobs_apply') {

$company_id = intval($_GET['company_id']);
if($company_id){
    $wheresql = ' where resume_id='.$company_id;
}

$pindex = max(1, intval($_GET['page']));
$psize  = 30;

$feedbackArr = array(2=>$language_zimu['admins_cda_inc_php_8'],3=>$language_zimu['admins_cda_inc_php_9'],4=>$language_zimu['admins_cda_inc_php_10'],5=>$language_zimu['admins_cda_inc_php_11'],6=>$language_zimu['admins_cda_inc_php_12']);

$total = DB::result_first('select count(*) from %t %i order by did desc', array(
    'zimu_zhaopin_personal_jobs_apply',
    $wheresql
));

$listdata = DB::fetch_all('select * from %t %i order by did desc limit %d,%d', array(
    'zimu_zhaopin_personal_jobs_apply',
    $wheresql,
    ($pindex - 1) * $psize,
    $psize
));

$pager = pagination($total, $pindex, $psize);


}

    if ($op == 'del_per_jobs_apply' && $_GET['md5hash'] == formhash()) {

        $ids = intval($_GET['ids']);

        $result = DB::delete('zimu_zhaopin_personal_jobs_apply', array(
            'did' => $ids
        ));

        include template('zimu_zhaopin:common/success');


    }

if ($op == 'per_attention_me') {

$company_id = intval($_GET['company_id']);
if($company_id){
    $wheresql = ' where resumeid='.$company_id;
}

$pindex = max(1, intval($_GET['page']));
$psize  = 30;


$total = DB::result_first('select count(*) from %t %i order by id desc', array(
    'zimu_zhaopin_view_resume',
    $wheresql
));

$listdata = DB::fetch_all('select * from %t %i order by id desc limit %d,%d', array(
    'zimu_zhaopin_view_resume',
    $wheresql,
    ($pindex - 1) * $psize,
    $psize
));

$pager = pagination($total, $pindex, $psize);


}

if ($op == 'per_viewlog') {

$company_id = intval($_GET['company_id']);

if($company_id){
    $myresid = DB::fetch_first('select * from %t where id=%d order by id desc', array(
            'zimu_zhaopin_resume',
            $company_id
        ));
    $wheresql = ' where uid='.$myresid['uid'];
}

$pindex = max(1, intval($_GET['page']));
$psize  = 30;


$total = DB::result_first('select count(*) from %t %i order by id desc', array(
    'zimu_zhaopin_per_viewlog',
    $wheresql
));

$listdata = DB::fetch_all('select * from %t %i order by id desc limit %d,%d', array(
    'zimu_zhaopin_per_viewlog',
    $wheresql,
    ($pindex - 1) * $psize,
    $psize
));

$pager = pagination($total, $pindex, $psize);


}

if ($op == 'per_jobs_favorites') {

$company_id = intval($_GET['company_id']);

if($company_id){
    $myresid = DB::fetch_first('select * from %t where id=%d order by id desc', array(
            'zimu_zhaopin_resume',
            $company_id
        ));
    $wheresql = ' where personal_uid='.$myresid['uid'];
}

$pindex = max(1, intval($_GET['page']));
$psize  = 30;


$total = DB::result_first('select count(*) from %t %i order by did desc', array(
    'zimu_zhaopin_personal_favorites',
    $wheresql
));

$listdata = DB::fetch_all('select * from %t %i order by did desc limit %d,%d', array(
    'zimu_zhaopin_personal_favorites',
    $wheresql,
    ($pindex - 1) * $psize,
    $psize
));

$pager = pagination($total, $pindex, $psize);


}

if ($op == 'per_attention_com') {

$company_id = intval($_GET['company_id']);

if($company_id){
    $myresid = DB::fetch_first('select * from %t where id=%d order by id desc', array(
            'zimu_zhaopin_resume',
            $company_id
        ));
    $wheresql = ' where uid='.$myresid['uid'];
}

$pindex = max(1, intval($_GET['page']));
$psize  = 30;


$total = DB::result_first('select count(*) from %t %i order by id desc', array(
    'zimu_zhaopin_personal_focus_company',
    $wheresql
));

$listdata = DB::fetch_all('select * from %t %i order by id desc limit %d,%d', array(
    'zimu_zhaopin_personal_focus_company',
    $wheresql,
    ($pindex - 1) * $psize,
    $psize
));

$pager = pagination($total, $pindex, $psize);


}

include zimu_template('admins/admins_' . $type,'');