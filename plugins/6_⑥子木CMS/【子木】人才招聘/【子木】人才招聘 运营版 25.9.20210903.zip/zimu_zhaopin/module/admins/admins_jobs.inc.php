<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$op = addslashes($_GET['op']);
$op = $op ? $op : 'list';

if ($op == 'edit') {
    
    $category_jobs = DB::fetch_all('select * from %t order by c_order asc,c_id asc', array(
        'zimu_zhaopin_category'
    ));
    
    foreach ($category_jobs as $key => $value) {
        
        $category_jobs2[$value['c_alias']][$value['c_id']] = $value['c_name'];
        
    }
    
    $tag_arr = $category_jobs2['ZM_jobtag'];
    
    if (submitcheck('submit')) {
        
        $data['uid'] = intval($_GET['uid']);
        
        if ($data['uid']) {
            
            $company_profile = DB::fetch_first('select * from %t where uid=%d', array(
                'zimu_zhaopin_company_profile',
                $data['uid']
            ));
            
            $data['company_id'] = $company_profile['id'];
            
            $array = array(
                'companyname',
                'trade',
                'trade_cn',
                'scale',
                'scale_cn'
            );
            foreach ($array as $val) {
                $data[$val] = $company_profile[$val];
            }
        }

        $data['company_certificate'] = $company_profile['certificate_img_audit'];
        $data['company_mingqi'] = $company_profile['company_mingqi'];


        $data['topclass']      = intval($_GET['topclass']);
        $data['category']      = intval($_GET['category' . $data['topclass']]);
        $data['category_cn']   = strip_tags($_GET['category' . $data['topclass'] . '_cn']);
        $data['category_sort'] = intval($_GET['topclass_index']) . ',' . intval($_GET['category_index']);
        
        $data['jobs_name']     = strip_tags($_GET['jobs_name']);
        $data['audit']         = intval($_GET['audit']);
        $data['nature']        = intval($_GET['nature']);
        $data['nature_cn']     = strip_tags($_GET['nature_cn']);
        $data['amount']        = intval($_GET['amount']);
        $data['sex']           = intval($_GET['sex']);
        $data['sex_cn']        = strip_tags($_GET['sex_cn']);
        $data['experience']    = intval($_GET['experience']);
        $data['experience_cn'] = strip_tags($_GET['experience_cn']) ? strip_tags($_GET['experience_cn']) : $language_zimu['admins_jobs_inc_php_0'];
        $data['education']     = intval($_GET['education']);
        $data['education_cn']  = strip_tags($_GET['education_cn']) ? strip_tags($_GET['education_cn']) : $language_zimu['admins_jobs_inc_php_1'];
        $data['minwage'] = $_GET['minwage'];
        $data['maxwage'] = $_GET['maxwage'];
        if( ($data['minwage'] || $data['maxwage']) && $data['minwage'] != $data['maxwage']){
            $data['wage_cn'] = $_GET['minwage'].'~'.$_GET['maxwage'].$zmdata['settings']['money_name'].'/'.$language_zimu['admins_jobs_inc_php_2'];
        }elseif( ($data['minwage'] || $data['maxwage']) && $data['minwage'] == $data['maxwage']){
            $data['wage_cn'] = $_GET['minwage'].$zmdata['settings']['money_name'].'/'.$language_zimu['admins_jobs_inc_php_3'];
        }else{
            $data['wage_cn'] = $language_zimu['admins_jobs_inc_php_4'];
        }
        $data['contents']      = strip_tags($_GET['contents']);
        $data['addtime']       = strtotime($_GET['addtime']);
        $data['uptime']        = time();
        $data['refreshtime']   = strtotime($_GET['refreshtime']);
        $data['tag']           = $posttag = trim($_GET['tag']);
        $data['display']       = intval($_GET['display']) ? intval($_GET['display']) : 1;
        $data['job_tel_apply']           = intval($_GET['job_tel_apply']);
        $data['contact']      = strip_tags($_GET['contact']);
        $data['telephone']      = strip_tags($_GET['telephone']);
        $data['resume_complete_percent']     = intval($_GET['resume_complete_percent']);
        $data['click']     = intval($_GET['click']);
        $data['parttime_type']          = intval($_GET['parttime_type']);
        $data['parttime_money']       = addslashes($_GET['parttime_money']);

        $districtcategory_arr            = explode(".", $_GET['district']);
        $data['district']  = $districtcategory_arr[0];
        $data['district2'] = $districtcategory_arr[1];
        $data['district3'] = $districtcategory_arr[2];
        $district_cn1 = DB::result_first('select name from %t where id=%d order by id desc', array(
            'zimu_zhaopin_area',
            $data['district']
        ));
        $district_cn2 = DB::result_first('select name from %t where id=%d order by id desc', array(
            'zimu_zhaopin_area',
            $data['district2']
        ));
        $district_cn3 = DB::result_first('select name from %t where id=%d order by id desc', array(
            'zimu_zhaopin_area',
            $data['district3']
        ));
        
        if($zmdata['settings']['area_three']==1){
        $data['district_cn'] = $district_cn2.$district_cn3;
        }else{
        $data['district_cn'] = $district_cn1.$district_cn2;
        }
        
        if ($posttag) {
            $tagArr = explode(",", $posttag);
            $r_arr  = array();
            foreach ($tagArr as $key => $value) {
                $r_arr[] = $category_jobs2['ZM_jobtag'][$value];
            }
            if (!empty($r_arr)) {
                $data['tag_cn'] = implode(",", $r_arr);
            } else {
                $data['tag_cn'] = '';
            }
        }
        $data['wxtpl'] = strip_tags($_GET['wxtpl']);
        $data['id']    = intval($_GET['ids']);
        
        $stick_endtime = strtotime($_GET['stick_endtime']);

        if ($stick_endtime > $_G['timestamp']) {
            $data['stick']         = 1;
            $data['stick_endtime'] = strtotime($_GET['stick_endtime']);
        }else{
            $data['stick']         = 0;
            $data['stick_endtime'] = strtotime($_GET['stick_endtime']);
        }
        
        if ($data['id'] > 0) {
            
            
            $listdata = DB::fetch_first('select * from %t where id=%d', array(
                'zimu_zhaopin_jobs',
                $data['id']
            ));
            
            if ($data['wxtpl'] && $data['audit'] != 2 && $data['audit'] != $listdata['audit']) {
                
                $paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
                    'zimu_zhaopin_parameter2',
                    'wxtpl'
                ));
                
                $paramters = unserialize($paramter['parameter']);
                
                $first = $language_zimu['admins_jobs_inc_php_5'] . ($data['audit'] == 1 ? $language_zimu['admins_jobs_inc_php_6'] : $language_zimu['admins_jobs_inc_php_7']);
                
                notification_user($data['uid'], $paramters['wxtpl_jobs'], array(
                    'first' => $first,
                    'keyword1' => $data['jobs_name'],
                    'keyword2' => $data['audit'] == 1 ? $language_zimu['admins_jobs_inc_php_8'] : $language_zimu['admins_jobs_inc_php_9'],
                    'keyword3' => $data['wxtpl'],
                    'remark' => $language_zimu['admins_jobs_inc_php_10'],
                    'url' => ZIMUCMS_URL . '&model=company&ac=jobs_add&jid=' . $data['id']
                ));
                
                $magcon = '{"tag":"' . $language_zimu['admins_jobs_inc_php_11'] . '","title":"' . $language_zimu['admins_jobs_inc_php_12'] . ($data['audit'] == 1 ? $language_zimu['admins_jobs_inc_php_13'] : $language_zimu['admins_jobs_inc_php_14']) . '","title_themecolor":"#ff0000","link":"' . ZIMUCMS_URL . '&model=mycompany&jid=' . $data['id'] . '","extra_info":[{"key":"' . $language_zimu['admins_jobs_inc_php_15'] . '","val":"' . $data['jobs_name'] . '"},{"key":"' . $language_zimu['admins_jobs_inc_php_16'] . '","val":"' . ($data['audit'] == 1 ? $language_zimu['admins_jobs_inc_php_17'] : $language_zimu['admins_jobs_inc_php_18']) . '"},{"key":"' . $language_zimu['admins_jobs_inc_php_19'] . '","val":"' . $data['wxtpl'] . '"}],"des":"' . $language_zimu['admins_jobs_inc_php_20'] . '","des_themecolor":"#008000"}';
                
                notification_user_magapp($data['uid'], $magcon);

            }
            
            
            DB::update('zimu_zhaopin_jobs', $data, array(
                'id' => $data['id']
            ));

        } else {
            
            $result = DB::insert('zimu_zhaopin_jobs', $data, 1);
            
        }
        
        
        include template('zimu_zhaopin:common/success');
        
        
    } else {
        
        $ids = intval($_GET['ids']);
        
        $listdata = DB::fetch_first('select * from %t where id=%d', array(
            'zimu_zhaopin_jobs',
            $ids
        ));

        if(!$listdata['minwage'] && !$listdata['maxwage'] && $listdata['wage_cn']){
            $wage_cn = explode('~',$listdata['wage_cn']);
            $listdata['minwage'] = intval($wage_cn[0]);
            $listdata['maxwage'] = intval($wage_cn[1]);
        }

        $arealist = DB::fetch_all('select * from %t where parentid=0 order by sort asc,id asc', array(
            'zimu_zhaopin_area'
        ));
        
        $category_jobs = DB::fetch_all('select * from %t where parentid=0 order by category_order asc,id asc', array(
            'zimu_zhaopin_category_jobs'
        ));
        
        foreach ($category_jobs as $key => $value) {
            
            $category_jobs[$key]['childs'] = DB::fetch_all('select * from %t where parentid=%d order by category_order asc,id asc', array(
                'zimu_zhaopin_category_jobs',
                $value['id']
            ));
            
        }
        
        include zimu_template('admins/admins_' . $type, '');
        
    }
    
    
} else if ($op == 'del' && $_GET['md5hash'] == formhash()) {
    
    $ids = intval($_GET['ids']);
    
    $result = DB::delete('zimu_zhaopin_jobs', array(
        'id' => $ids
    ));
    
    include template('zimu_zhaopin:common/success');
    
} else if ($op == 'mp_tpl') {
    
    
    $mp_jobs = DB::fetch_all('select * from %t where audit=1 and display!=2 order by id desc limit 100', array(
        'zimu_zhaopin_jobs'
    ));
    
    foreach ($mp_jobs as $key => $value) {
        
        $mp_jobs[$key]['companyname_address'] = DB::result_first('select address from %t where id=%d order by id asc', array(
            'zimu_zhaopin_company_profile',
            $value['company_id']
        ));
        
if($zmdata['settings']['wx_create_qrcode']==1){

require_once DISCUZ_ROOT . './source/plugin/zimu_zhaopin/class/wechat.lib.class.php';
$wechat_client = new WeChatClient($zmdata['base']['weixin_appid'], $zmdata['base']['weixin_appsecret']);

$qrcode_url = $wechat_client->getQrcodeImgUrlByTicket($wechat_client->getQrcodeTicket(array('scene_str'=>'viewjob'.'zimuyun'.$value['id'],'expire'=>2591000)));
$qrcode_img = 'data:image/jpeg;base64,'.base64_encode(dfsockopen($qrcode_url));
$qrcode_img = $qrcode_img ? $qrcode_img : 'data:image/jpeg;base64,'.base64_encode(file_get_contents($qrcode_url));

}else{
$qrcode_img = 'http://www.kuaizhan.com/common/encode-png?large=true&data=' . urlencode(ZIMUCMS_URL . '&model=viewjob&jid=' . $value['id']); 
}

        $thistpl = preg_replace(array(
            '/jobs_name/',
            '/companyname_address/',
            '/companyname/',
            '/sex_cn/',
            '/category_cn/',
            '/tag_cn/',
            '/education_cn/',
            '/experience_cn/',
            '/wage_cn/',
            '/contents/',
            '/jobid/',
            '/mp_qrcode/',
            '/zp_tolink/'
        ), array(
            $value['jobs_name'],
            $mp_jobs[$key]['companyname_address'],
            $value['companyname'],
            $value['sex_cn'],
            $value['category_cn'],
            $value['tag_cn'],
            $value['education_cn'],
            $value['experience_cn'],
            $value['wage_cn'],
            $value['contents'],
            $value['id'],
            $qrcode_img,
            ZIMUCMS_URL . '&model=viewjob&jid=' . $value['id']
        ), $zmdata['settings']['mp_tpl']);
        
        $mp_tpl = $mp_tpl . $thistpl;
        
    }
    
    
    echo $mp_tpl;
    
} elseif ($op == 'refreshjob') {
    
    
    $ids = intval($_GET['ids']);

    $listdata = DB::fetch_first('select * from %t where id=%d', array(
        'zimu_zhaopin_jobs',
        $ids
    ));
        
    DB::query("update %t set refreshtime=%d where id=%d", array(
        'zimu_zhaopin_jobs',
        $_G['timestamp'],
        $ids
    ));

    $setsqlarr_refresh_log['uid']     = $listdata['uid'];
    $setsqlarr_refresh_log['mode']    = 2;
    $setsqlarr_refresh_log['addtime'] = $_G['timestamp'];
    $setsqlarr_refresh_log['type']    = 1001;
    
    DB::insert('zimu_zhaopin_refresh_log', $setsqlarr_refresh_log, 1);


    ajaxReturn(1, 1);

}elseif ($op == 'changeaudit') {

DB::query("update %t set audit=1 where id in (%n)", array(
    'zimu_zhaopin_jobs',
    $_GET['ids']
));

ajaxReturn(1,1);

} elseif ($op == 'autorefreshjob') {

    $refresh = intval($_GET['refresh']);
    $refreshjid = intval($_GET['refreshjid']);
    $refreshuid = intval($_GET['refreshuid']);


    $setmeal_increment = DB::fetch_first('select * from %t where id=%d order by id desc', array(
        'zimu_zhaopin_setmeal_increment',
        $refresh
    ));
    $days = $setmeal_increment['value'];
    $nowtime = time();
    for ($i = 0; $i < $days * 4; $i++) {
        $timespace = 3600 * 6 * $i;

        $queue_auto_refresh['uid'] = $refreshuid;
        $queue_auto_refresh['pid'] = $refreshjid;
        $queue_auto_refresh['type'] = 1;
        $queue_auto_refresh['refreshtime'] = $nowtime + $timespace;
        DB::insert('zimu_zhaopin_queue_auto_refresh', $queue_auto_refresh);

    }

    ajaxReturn(200, $language_zimu['admins_jobs_inc_php_21']);

} elseif ($op == 'matching') {
    $jid = intval($_GET['jid']);
    $listview = DB::fetch_first('select * from %t where id=%d', array(
        'zimu_zhaopin_jobs',
        $jid
    ));
    $where_mathcing = 'where 1=1 ';
    if($listview['sex']){
        $where_mathcing .= " and `sex` = '{$listview['sex']}' ";
    }
    if($listview['experience']){
        $where_mathcing .= " and `experience` >= '{$listview['experience']}' ";
    }
    if($listview['education']){
        $where_mathcing .= " and `education` >= '{$listview['education']}' ";
    }
    if($listview['topclass']){
        $where_mathcing .= " and `intention_jobs_id` LIKE '%{$listview['topclass']}.%' ";
    }
    $where_mathcing .= " and `display` != 2 ";
    $where_mathcing .= " and `audit` != 3 ";

    $mymatching2 = DB::fetch_all("SELECT uid FROM %t %i", array(
        "zimu_zhaopin_resume",
        $where_mathcing
    ),'uid');
    $alluids = implode(',', array_keys($mymatching2));

    $listdata = DB::fetch_all('select * from %t where uid in (%i) order by refreshtime desc', array(
        'zimu_zhaopin_resume',
        $alluids
    ));
    include zimu_template('admins/admins_jobs_mathcing', '');

} else {
    
    $category_jobs = DB::fetch_all('select * from %t where parentid=0 order by category_order asc,id asc', array(
        'zimu_zhaopin_category_jobs'
    ));
    
    foreach ($category_jobs as $key => $value) {
        
        $category_jobs[$key]['childs'] = DB::fetch_all('select * from %t where parentid=%d order by category_order asc,id asc', array(
            'zimu_zhaopin_category_jobs',
            $value['id']
        ));
        
    }

    $category = DB::fetch_all('select * from %t order by c_order asc,c_id asc', array(
        'zimu_zhaopin_category'
    ));
    
    foreach ($category as $key => $value) {
        
        $category_jobs2[$value['c_alias']][$value['c_id']] = $value['c_name'];
        
    }

    $wheresql    = 'where 1=1 ';
    $keywordtype = intval($_GET['keywordtype']);
    $keyword     = trim($_GET['keyword']);
    $keyword     = dhtmlspecialchars($keyword);
    $keyword     = stripsearchkey($keyword);
    $keyword     = daddslashes($keyword);
    
    if (!empty($keyword)) {
        if ($keywordtype == 1) {
            $wheresql .= " and `id` = '{$keyword}' ";
        } elseif ($keywordtype == 2) {
            $wheresql .= " and `jobs_name` LIKE '%{$keyword}%' ";
        } elseif ($keywordtype == 3) {
            $wheresql .= " and `company_id` = '{$keyword}' ";
        } elseif ($keywordtype == 4) {
            $wheresql .= " and `companyname` LIKE '%{$keyword}%' ";
        } elseif ($keywordtype == 5) {
            $wheresql .= " and `uid` = '{$keyword}' ";
        }
    }
    
    $audit = intval($_GET['audit']);
    if (!empty($audit)) {
        $wheresql .= " and audit = " . $audit;
    }

    $display = intval($_GET['display']);
    if (!empty($display)) {
        $wheresql .= " and display = " . $display;
    }

    $iszhiding = intval($_GET['iszhiding']);
    if ($iszhiding==1) {
        $wheresql .= " and stick_endtime > " . time();
    }


    $nature = intval($_GET['nature']);
    if (!empty($nature)) {
        $wheresql .= " and nature = " . $nature;
    }

    $sex = intval($_GET['sex']);
    if (!empty($sex)) {
        $wheresql .= " and sex = " . $sex;
    }

    $topclass = intval($_GET['topclass']);
    if (!empty($topclass)) {
        $wheresql .= " and topclass = " . $topclass;
    }

    $experience = intval($_GET['experience']);
    if (!empty($experience)) {
        $wheresql .= " and experience >= " . $experience;
    }

    $education = intval($_GET['education']);
    if (!empty($education)) {
        $wheresql .= " and education >= " . $education;
    }

    $wage = intval($_GET['wage']);
    if (!empty($wage)) {
        $wheresql .= " and wage >= " . $wage;
    }

    $wheresql = $wheresql.$wherekefu;

    $click_order = intval($_GET['click_order']);
    if($click_order==1) {
        $whereorder = 'click desc,';
    }elseif($click_order==2){
        $whereorder = 'click asc,';
    }


    $order = intval($_GET['order']);
    if($order==1) {
        $whereorder .= 'refreshtime desc';
    }elseif($order==2){
        $whereorder .= 'id desc';
    }else{
        $whereorder .= 'uptime desc,id desc';
    }

    $pindex = max(1, intval($_GET['page']));
    $psize  = 30;
    
    $total = DB::result_first("SELECT count(*) FROM %t %i", array(
        "zimu_zhaopin_jobs",
        $wheresql
    ));
    
    $total2 = DB::result_first("SELECT count(*) FROM %t %i", array(
        "zimu_zhaopin_jobs",
        "where 1=1 and audit=2"
    ));
    
    $listdata = DB::fetch_all('select * from %t %i order by %i limit %d,%d', array(
        'zimu_zhaopin_jobs',
        $wheresql,
        $whereorder,
        ($pindex - 1) * $psize,
        $psize
    ));
    
    $pager = pagination($total, $pindex, $psize);
    
   
       $auto_refresh = DB::fetch_all("SELECT * FROM %t WHERE cat=%s order by id asc", array(
        "zimu_zhaopin_setmeal_increment",
        "auto_refresh_jobs"
        ));


    include zimu_template('admins/admins_' . $type, '');
    
    
}