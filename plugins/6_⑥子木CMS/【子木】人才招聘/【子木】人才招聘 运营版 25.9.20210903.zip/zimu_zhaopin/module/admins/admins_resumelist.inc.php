<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$op = addslashes($_GET['op']);
$op = $op ? $op : 'list';

if ($op == 'edit') {

$category_jobs = DB::fetch_all('select * from %t order by c_order asc,c_id asc', array(
        'zimu_zhaopin_category'
    ));

foreach ($category_jobs as $key => $value) {

$category_jobs2[$value['c_alias']][$value['c_id']] = $value['c_name'];

}

    $tag_arr = $category_jobs2['ZM_resumetag'];
    

    if (submitcheck('submit')) {

        $data['uid']        = strip_tags($_GET['uid']);
        $data['fullname']        = strip_tags($_GET['fullname']);
        $data['audit']         = intval($_GET['audit']);
        $data['addtime'] = strtotime($_GET['addtime']);
        $data['refreshtime'] = strtotime($_GET['refreshtime']);
        $data['sex']         = intval($_GET['sex']);
        $data['sex_cn']         = strip_tags($_GET['sex_cn']);
        $data['birthdate']         = intval($_GET['birthdate']);
        if($data['birthdate']){
            $data['age'] = date('Y')-$data['birthdate'];
        }
        $data['education']         = intval($_GET['education']);
        $data['education_cn']         = strip_tags($_GET['education_cn']);
        $data['experience']         = intval($_GET['experience']);
        $data['experience_cn']         = strip_tags($_GET['experience_cn']);
        $data['telephone']         = strip_tags($_GET['telephone']);
        $data['current']         = intval($_GET['current']);
        $data['current_cn']         = strip_tags($_GET['current_cn']);
        $data['nature']         = intval($_GET['nature']);
        $data['nature_cn']         = strip_tags($_GET['nature_cn']);
        $data['wage']         = intval($_GET['wage']);
        $data['wage_cn']         = strip_tags($_GET['wage_cn']);
        $data['specialty']        = strip_tags($_GET['specialty']);
        $data['display']         = intval($_GET['display']) ? intval($_GET['display']) : 1;
        
        if ($_FILES['photo_img']['tmp_name']) {
            $data['photo_img'] = zm_saveimages($_FILES['photo_img']);
        }
        if($_GET['img_photo_img']=='nopic'){
            $data['photo_img'] = '';
        }
        
        $stick_endtime = strtotime($_GET['stick_endtime']);
        if($stick_endtime > $_G['timestamp']){
        $data['stick'] = 1;
        $data['stick_endtime'] = strtotime($_GET['stick_endtime']);
        }else{
        $data['stick'] = 0;
        $data['stick_endtime'] = strtotime($_GET['stick_endtime']);
        }
        $data['strong_tag'] = strip_tags($_GET['strong_tag']);
        $data['strong_tag_endtime'] = strtotime($_GET['strong_tag_endtime']);
        $data['tag'] = $posttag = trim($_GET['tag']);
        if ($posttag) {
            $tagArr = explode(",", $posttag);
            $r_arr  = array();
            foreach ($tagArr as $key => $value) {
                $r_arr[] = $category_jobs2['ZM_resumetag'][$value];
            }
            if (!empty($r_arr)) {
                $data['tag_cn'] = implode(",", $r_arr);
            } else {
                $data['tag_cn'] = '';
            }
        }

        if($_GET['trade']){
            foreach(explode(',',$_GET['trade']) as $val) {
                $trade_cn[] = $category_jobs2['ZM_trade'][$val];
            }
        $data['trade'] = strip_tags($_GET['trade']);
        $data['trade_cn']           = implode(',',$trade_cn);
        }
        
        $data['district']         = strip_tags($_GET['district']);
        $data['district_cn']         = strip_tags($_GET['district_cn']);

        $data['intention_jobs_id']        = strip_tags($_GET['intention_jobs_id']);
        $data['intention_jobs']        = strip_tags($_GET['intention_jobs_cn']);
        $data['wxtpl']        = strip_tags($_GET['wxtpl']);

        $data['id']      = intval($_GET['ids']);
        $data['weixin']         = strip_tags($_GET['weixin']);
        
        $data['kefu_uid']      = intval($_GET['kefu_uid']);
        if ($data['kefu_uid']) {
            $data['kefu_name'] = DB::result_first('select kefu_name from %t where uid=%d', array(
                'zimu_zhaopin_kefu',
                $data['kefu_uid'],
            ));
        }

        if ($data['id'] > 0) {

        $listdata = DB::fetch_first('select * from %t where id=%d', array(
            'zimu_zhaopin_resume',
            $data['id']
        ));

        DB::query("update %t set blacklist=%d where uid=%d", array(
            'zimu_zhaopin_members',
            $_GET['blacklist'],
            $listdata['uid']
        ));

        DB::query("update %t set blacklist=%d where uid=%d", array(
            'zimu_zhaopin_members',
            $data['uid'],
            $_GET['blacklist']
        ));

        $worklist = explode('zimuyun',$_GET['worklist']);
        foreach ($worklist as $key => $value) {
            $valuelist = explode('|',$value);
            if(intval($valuelist[0]) > 0 && trim($valuelist[1]) == 'del'){
                DB::delete('zimu_zhaopin_resume_work', array(
                    'id' => intval($valuelist[0])
                ));
            }
            if(intval($valuelist[0]) > 0 && trim($valuelist[1]) != 'del'){
                $startyear = explode('-',$valuelist[3]);
                $endyear = explode('-',$valuelist[4]);
                $todate = $endyear[0]==0 && $endyear[1]==0 ? 1 : 0;
                DB::query("update %t set pid=%d,uid=%d,startyear=%d,startmonth=%d,endyear=%d,endmonth=%d,companyname=%s,jobs=%s,achievements=%s,todate=%d where id=%d", array(
                    'zimu_zhaopin_resume_work',
                    $data['id'],
                    $data['uid'],
                    intval($startyear[0]),
                    intval($startyear[1]),
                    intval($endyear[0]),
                    intval($endyear[1]),
                    $valuelist[1],
                    $valuelist[2],
                    $valuelist[5],
                    $todate,
                    intval($valuelist[0])
                ));
            }
            if(trim($valuelist[0]) == 'add'){
                $startyear = explode('-',$valuelist[3]);
                $endyear = explode('-',$valuelist[4]);
                $todate = $endyear[0]==0 && $endyear[1]==0 ? 1 : 0;
                $setsqlarr['pid'] = $data['id'];
                $setsqlarr['uid'] = $data['uid'];
                $setsqlarr['companyname'] = $valuelist[1];
                $setsqlarr['achievements'] = $valuelist[5];
                $setsqlarr['jobs'] = $valuelist[2];
                $setsqlarr['startyear'] = intval($startyear[0]);
                $setsqlarr['startmonth'] = intval($startyear[1]);
                $setsqlarr['endyear'] = intval($endyear[0]);
                $setsqlarr['endmonth'] = intval($endyear[0]);
                $setsqlarr['todate'] = $todate;
                DB::insert('zimu_zhaopin_resume_work', $setsqlarr);
            }

        }

            $edulist = explode('zimuyun',$_GET['edulist']);
            foreach ($edulist as $key => $value) {
                $valuelist = explode('|',$value);
                if(intval($valuelist[0]) > 0 && trim($valuelist[1]) == 'del'){
                    DB::delete('zimu_zhaopin_resume_education', array(
                        'id' => intval($valuelist[0])
                    ));
                }
                if(intval($valuelist[0]) > 0 && trim($valuelist[1]) != 'del'){
                    $startyear = explode('-',$valuelist[4]);
                    $endyear = explode('-',$valuelist[5]);
                    $todate = $endyear[0]==0 && $endyear[1]==0 ? 1 : 0;
                    DB::query("update %t set pid=%d,uid=%d,startyear=%d,startmonth=%d,endyear=%d,endmonth=%d,school=%s,speciality=%s,education_cn=%s,todate=%d where id=%d", array(
                        'zimu_zhaopin_resume_education',
                        $data['id'],
                        $data['uid'],
                        intval($startyear[0]),
                        intval($startyear[1]),
                        intval($endyear[0]),
                        intval($endyear[1]),
                        $valuelist[1],
                        $valuelist[2],
                        $valuelist[3],
                        $todate,
                        intval($valuelist[0])
                    ));
                }
                if(trim($valuelist[0]) == 'add'){
                    $startyear = explode('-',$valuelist[4]);
                    $endyear = explode('-',$valuelist[5]);
                    $todate = $endyear[0]==0 && $endyear[1]==0 ? 1 : 0;
                    $setsqlarr['pid'] = $data['id'];
                    $setsqlarr['uid'] = $data['uid'];
                    $setsqlarr['school'] = $valuelist[1];
                    $setsqlarr['speciality'] = $valuelist[2];
                    $setsqlarr['education_cn'] = $valuelist[3];
                    $setsqlarr['startyear'] = intval($startyear[0]);
                    $setsqlarr['startmonth'] = intval($startyear[1]);
                    $setsqlarr['endyear'] = intval($endyear[0]);
                    $setsqlarr['endmonth'] = intval($endyear[0]);
                    $setsqlarr['todate'] = $todate;
                    DB::insert('zimu_zhaopin_resume_education', $setsqlarr);
                }

            }


        if($data['wxtpl'] && $data['audit']!=2 && $data['audit'] != $listdata['audit']){

            $paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
                'zimu_zhaopin_parameter2',
                'wxtpl'
            ));

            $paramters = unserialize($paramter['parameter']);

            $first = $language_zimu['admins_resumelist_inc_php_0'];

            notification_user($data['uid'],$paramters['wxtpl_resume'],array('first'=>$first,'keyword1'=>$data['fullname'].$language_zimu['admins_resumelist_inc_php_1'],'keyword2'=>date('Y-m-d H:i',$_G['timestamp']),'keyword3'=>$data['audit']==1 ? $language_zimu['admins_resumelist_inc_php_2'] : $language_zimu['admins_resumelist_inc_php_3'],'keyword4'=>$data['wxtpl'],'remark'=>$language_zimu['admins_resumelist_inc_php_4'],'url'=>ZIMUCMS_URL.'&model=mypersonal'));

$magcon = '{"tag":"'.$language_zimu['admins_resumelist_inc_php_5'].'","title":"'.$language_zimu['admins_resumelist_inc_php_6'].'","title_themecolor":"#ff0000","link":"'.ZIMUCMS_URL.'&model=mypersonal","extra_info":[{"key":"'.$language_zimu['admins_resumelist_inc_php_7'].'","val":"'.$data['fullname'].$language_zimu['admins_resumelist_inc_php_8'].'"},{"key":"'.$language_zimu['admins_resumelist_inc_php_9'].'","val":"'.($data['audit']==1 ? $language_zimu['admins_resumelist_inc_php_10'] : $language_zimu['admins_resumelist_inc_php_11']).'"},{"key":"'.$language_zimu['admins_resumelist_inc_php_12'].'","val":"'.$data['wxtpl'].'"}],"des":"'.$language_zimu['admins_resumelist_inc_php_13'].'","des_themecolor":"#008000"}';

    notification_user_magapp($data['uid'],$magcon);

            $find = ['audit','reason'];
            $replace = [$data['audit'] == 1 ? $language_zimu['admins_resumelist_inc_php_14'] : $language_zimu['admins_resumelist_inc_php_15'],zimu_cutstr2($data['wxtpl'],20)];
            notification_user_sms2($data['uid'],$data['telephone'],'chanyoo_sms_tp4',$find,$replace);

        }

            if($data['telephone']){
                DB::query("update %t set telephone=%s where uid=%d", array(
                    'zimu_zhaopin_members',
                    $$data['telephone'],
                    $data['uid']
                ));
            }
            
            DB::update('zimu_zhaopin_resume', $data, array(
                'id' => $data['id']
            ));
            
        } else {
            
            $result = DB::insert('zimu_zhaopin_resume', $data, 1);
            
        }
        
        
        include template('zimu_zhaopin:common/success');
        
        
    } else {

        $resume_input_paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
            'zimu_zhaopin_parameter2',
            'resume_input'
        ));

        $resume_input_paramters = unserialize($resume_input_paramter['parameter']);
        
        $ids = intval($_GET['ids']);
        
        $listdata = DB::fetch_first('select * from %t where id=%d', array(
            'zimu_zhaopin_resume',
            $ids
        ));

        $kefudata = DB::fetch_all('select * from %t order by id asc', array(
            'zimu_zhaopin_kefu'
        ));

        $listdata['worklist'] = DB::fetch_all('select * from %t where pid=%d order by id asc', array(
            'zimu_zhaopin_resume_work',
            $ids
        ));

        $listdata['edulist'] = DB::fetch_all('select * from %t where pid=%d order by id asc', array(
            'zimu_zhaopin_resume_education',
            $ids
        ));

        $listdata['blacklist'] = DB::result_first('select blacklist from %t where uid=%d', array(
            'zimu_zhaopin_members',
            $listdata['uid']
        ));


        include zimu_template('admins/admins_' . $type,'');
        
    }
    
    
} else if ($op == 'del' && $_GET['md5hash'] == formhash()) {
    
    $ids = intval($_GET['ids']);
    
    $result = DB::delete('zimu_zhaopin_resume', array(
        'id' => $ids
    ));
    
    include template('zimu_zhaopin:common/success');


} else if ($op == 'changedisplay') {

$rid = intval($_GET['rid']);
$display = intval($_GET['display']);

DB::query("update %t set display=%d where id=%d", array(
    'zimu_zhaopin_resume',
    $display,
    $rid
));

ajaxReturn(1,1);

} else if ($op == 'changecontact') {

$rid = intval($_GET['rid']);
$display = intval($_GET['display']);

DB::query("update %t set is_contact=%d where id=%d", array(
    'zimu_zhaopin_resume',
    $display,
    $rid
));

ajaxReturn(1,1);

} else if ($op == 'changeweixin') {

$rid = intval($_GET['rid']);
$display = addslashes($_GET['display']);

DB::query("update %t set weixin=%s where id=%d", array(
    'zimu_zhaopin_resume',
    $display,
    $rid
));

ajaxReturn(1,1);

}elseif ($op == 'changeaudit') {

DB::query("update %t set audit=1 where id in (%n)", array(
    'zimu_zhaopin_resume',
    $_GET['ids']
));

ajaxReturn(1,1);

} else if ($op == 'mp_tpl') {


    $mp_jobs = DB::fetch_all('select * from %t where audit=1 and display!=2 order by id desc limit 100', array(
            'zimu_zhaopin_resume'
        ));
    
    foreach ($mp_jobs as $key => $value) {

if($zmdata['settings']['wx_create_qrcode']==1){

require_once DISCUZ_ROOT . './source/plugin/zimu_zhaopin/class/wechat.lib.class.php';
$wechat_client = new WeChatClient($zmdata['base']['weixin_appid'], $zmdata['base']['weixin_appsecret']);

$qrcode_url = $wechat_client->getQrcodeImgUrlByTicket($wechat_client->getQrcodeTicket(array('scene_str'=>'viewresume'.'zimuyun'.$value['id'],'expire'=>2591000)));
$qrcode_img = 'data:image/jpeg;base64,'.base64_encode(dfsockopen($qrcode_url));
$qrcode_img = $qrcode_img ? $qrcode_img : 'data:image/jpeg;base64,'.base64_encode(file_get_contents($qrcode_url));

}else{
$qrcode_img = 'http://www.kuaizhan.com/common/encode-png?large=true&data=' . urlencode(ZIMUCMS_URL . '&model=viewresume&rid=' . $value['id']); 
}

    $thistpl = preg_replace(array('/fullname/','/sex_cn/','/trade_cn/','/experience_cn/','/wage_cn/','/education_cn/','/tag_cn/','/intention_jobs/','/specialty/','/resumeid/','/mp_qrcode/','/zp_tolink/','/birthdate_cn/','/current_cn/','/district_cn/'), array($value['fullname'],$value['sex_cn'],$value['trade_cn'],$value['experience_cn'],$value['wage_cn'],$value['education_cn'],$value['tag_cn'],$value['intention_jobs'],$value['specialty'],$value['id'],$qrcode_img,ZIMUCMS_URL.'&model=viewresume&rid='.$value['id'],date('Y',$_G['timestamp'])-$value['birthdate'],$value['current_cn'],$value['district_cn']), $zmdata['settings']['mp_tpl2']);
    
    $mp_tpl = $mp_tpl.$thistpl;
    
    }
    
    
    echo $mp_tpl;

} else {

    $category_jobs = DB::fetch_all('select * from %t where parentid=0 order by category_order asc,id asc', array(
        'zimu_zhaopin_category_jobs'
    ));
    
    foreach ($category_jobs as $key => $value) {
        
        $category_jobs[$key]['childs'] = DB::fetch_all('select * from %t where parentid=%d order by category_order asc,id asc', array(
            'zimu_zhaopin_category_jobs',
            $value['id']
        ));
        
    }

    $category = DB::fetch_all('select * from %t order by c_order asc,c_id asc', array(
        'zimu_zhaopin_category'
    ));
    
    foreach ($category as $key => $value) {
        
        $category_jobs2[$value['c_alias']][$value['c_id']] = $value['c_name'];
        
    }

    $wheresql = 'where 1=1 ';
    $keywordtype = intval($_GET['keywordtype']);
    $keyword = trim($_GET['keyword']);
    $keyword = dhtmlspecialchars($keyword);
    $keyword = stripsearchkey($keyword);
    $keyword = daddslashes($keyword);

    if (!empty($keyword)) {
        if ($keywordtype == 1) {
            $wheresql .= " and `id` = '{$keyword}' ";
        } elseif ($keywordtype == 2) {
            $wheresql .= " and `fullname` LIKE '%{$keyword}%' ";
        } elseif ($keywordtype == 3) {
            $wheresql .= " and `telephone` = '{$keyword}' ";
        } elseif ($keywordtype == 4) {
            $wheresql .= " and `intention_jobs` LIKE '%{$keyword}%' ";
        } elseif ($keywordtype == 5) {
            $wheresql .= " and `uid` = '{$keyword}' ";
        }
    }

    $audit = intval($_GET['audit']);
    if (!empty($audit)) {
        $wheresql .= " and audit = ".$audit;
    }

    $nature = intval($_GET['nature']);
    if (!empty($nature)) {
        $wheresql .= " and nature = " . $nature;
    }

    $sex = intval($_GET['sex']);
    if (!empty($sex)) {
        $wheresql .= " and sex = " . $sex;
    }

    $experience = intval($_GET['experience']);
    if (!empty($experience)) {
        $wheresql .= " and experience >= " . $experience;
    }

    $education = intval($_GET['education']);
    if (!empty($education)) {
        $wheresql .= " and education >= " . $education;
    }

    $wage = intval($_GET['wage']);
    if (!empty($wage)) {
        $wheresql .= " and wage >= " . $wage;
    }

    $wheresql = $wheresql.$wherekefu2;

    $order = intval($_GET['order']);
    if($order==1){
        $whereorder = 'refreshtime';
    }else if($order==2){
        $whereorder = 'logintime';
    }else{
        $whereorder = 'id';
    }

    $pindex = max(1, intval($_GET['page']));
    $psize  = 30;
    
    $total = DB::result_first("SELECT count(*) FROM %t %i", array(
        "zimu_zhaopin_resume",
        $wheresql
    ));
    
    $total2 = DB::result_first("SELECT count(*) FROM %t %i", array(
        "zimu_zhaopin_resume",
        "where 1=1 and audit=2".$wherekefu2
    ));

    $listdata = DB::fetch_all('select * from %t %i order by %i desc limit %d,%d', array(
        'zimu_zhaopin_resume',
        $wheresql,
        $whereorder,
        ($pindex - 1) * $psize,
        $psize
    ));
    
    $pager = pagination($total, $pindex, $psize);
    
    
    include zimu_template('admins/admins_' . $type,'');
    
    
}