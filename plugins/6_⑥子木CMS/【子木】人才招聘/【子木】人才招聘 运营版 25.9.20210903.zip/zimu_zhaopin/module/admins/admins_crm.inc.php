<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$op = addslashes($_GET['op']);
$op = $op ? $op : 'mycompanylist';

if ($op == 'companyset') {


if(submitcheck('submit')) {

        $paramters = $_GET['options'];

        $isadd = DB::fetch_first('select * from %t where name=%s order by id desc', array(
            'zimu_zhaopin_parameter2',
            'crm_companyset'
        ));

        if ($isadd['id'] > 0) {

        DB::query("update %t set parameter=%s where id=%d", array(
            'zimu_zhaopin_parameter2',
            serialize($paramters),
            $isadd['id']
        ));
            
        } else {

        $adddata = array(
                'name'=>'crm_companyset',
                'parameter'=>serialize($paramters),
        );

            DB::insert('zimu_zhaopin_parameter2', $adddata);
            
        }
        
        
        include template('zimu_zhaopin:common/success');
        


}else{


        $paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
            'zimu_zhaopin_parameter2',
            'crm_companyset'
        ));
        
        $paramters = unserialize($paramter['parameter']);

        include zimu_template('admins/admins_' . $type .'_'. $op,'');


}


} else if ($op == 'resumeset') {

if(submitcheck('submit')) {

        $paramters = $_GET['options'];

        $isadd = DB::fetch_first('select * from %t where name=%s order by id desc', array(
            'zimu_zhaopin_parameter2',
            'crm_resumeset'
        ));

        if ($isadd['id'] > 0) {

        DB::query("update %t set parameter=%s where id=%d", array(
            'zimu_zhaopin_parameter2',
            serialize($paramters),
            $isadd['id']
        ));
            
        } else {

        $adddata = array(
                'name'=>'crm_resumeset',
                'parameter'=>serialize($paramters),
        );

            DB::insert('zimu_zhaopin_parameter2', $adddata);
            
        }
        
        
        include template('zimu_zhaopin:common/success');
        


}else{


        $paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
            'zimu_zhaopin_parameter2',
            'crm_resumeset'
        ));
        
        $paramters = unserialize($paramter['parameter']);

        include zimu_template('admins/admins_' . $type .'_'. $op,'');


}

} else if ($op == 'companyindex') {

    $ids    = intval($_GET['ids']);

    $listdata = DB::fetch_first('select * from %t where id=%d order by id asc', array(
        'zimu_zhaopin_company_profile',
        $ids
    ));

    $comsetmea = DB::fetch_first('select * from %t where uid=%d order by id desc', array(
            'zimu_zhaopin_members_setmeal',
            $listdata['uid']
        ));

    $crm_company = DB::fetch_first('select * from %t where com_id=%d order by com_id desc', array(
        'zimu_zhaopin_crm_company',
        $ids
    ));

    if(!$crm_company && $listdata['kefu_uid'] == $_G['uid']){

        $crm_company_data['com_id']       = $ids;
        $crm_company_data['com_uid']        = $listdata['uid'];
        $crm_company_data['crm_uid']     = $_G['uid'];
        $crm_company_data['receive_time']     = $_G['timestamp'];
        DB::insert('zimu_zhaopin_crm_company', $crm_company_data);

        $crm_custom_log_data['custom_type']       = 1;
        $crm_custom_log_data['custom_id']        = $ids;
        $crm_custom_log_data['crm_uid']     = $_G['uid'];
        $crm_custom_log_data['op_type']       = 'receive';
        $crm_custom_log_data['note']       = $language_zimu['admins_crm_inc_php_0'];
        $crm_custom_log_data['add_time']     = $_G['timestamp'];
        $crm_custom_log_data['ip']     = $_G['clientip'];
        DB::insert('zimu_zhaopin_crm_custom_log', $crm_custom_log_data);

    }


    $totaljobs = DB::result_first("SELECT count(*) FROM %t where uid=%d and display=1", array(
        "zimu_zhaopin_jobs",
        $listdata['uid']
    ));

    $totalapply = DB::result_first('select count(*) from %t where company_uid=%d and apply_addtime>%d', array(
        'zimu_zhaopin_personal_jobs_apply',
        $listdata['uid'],
        $_G['timestamp']-86400*30
    ));

    $totaldown = DB::result_first('select count(*) from %t where company_uid=%d and down_addtime>%d', array(
        'zimu_zhaopin_company_down_resume',
        $listdata['uid'],
        $_G['timestamp']-86400*30
    ));

    $totalviewlog = DB::result_first('select count(*) from %t where uid=%d and addtime>%d', array(
        'zimu_zhaopin_com_viewlog',
        $listdata['uid'],
        $_G['timestamp']-86400*30
    ));

    $paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
        'zimu_zhaopin_parameter2',
        'crm_companyset'
    ));
    
    $crm_companyset = unserialize($paramter['parameter']);
    $crm_companyset['company_funnel'] = explode(',', $crm_companyset['company_funnel']);
    $crm_companyset['company_level'] = explode(',', $crm_companyset['company_level']);
    $crm_companyset['company_feedback'] = explode(',', $crm_companyset['company_feedback']);
    $crm_companyset['company_service'] = explode(',', $crm_companyset['company_service']);

    $feedbacklist = DB::fetch_all('select * from %t where custom_id=%d and custom_type=1 order by add_time desc', array(
        'zimu_zhaopin_crm_custom_feedback',
        $ids
    ));

    $loglist = DB::fetch_all('select * from %t where custom_id=%d and custom_type=1 order by id desc', array(
        'zimu_zhaopin_crm_custom_log',
        $ids
    ));


    $kefudata = DB::fetch_all('select * from %t order by id asc', array(
        'zimu_zhaopin_kefu'
    ),'uid');

    include zimu_template('admins/admins_' . $type .'_'. $op,'');


} else if ($op == 'companyindex2') {

    $ids    = intval($_GET['ids']);

    $listdata = DB::fetch_first('select * from %t where id=%d order by id asc', array(
        'zimu_zhaopin_company_profile2',
        $ids
    ));

    $paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
        'zimu_zhaopin_parameter2',
        'crm_companyset'
    ));

    $crm_companyset = unserialize($paramter['parameter']);
    $crm_companyset['company_funnel'] = explode(',', $crm_companyset['company_funnel']);
    $crm_companyset['company_level'] = explode(',', $crm_companyset['company_level']);
    $crm_companyset['company_feedback'] = explode(',', $crm_companyset['company_feedback']);
    $crm_companyset['company_service'] = explode(',', $crm_companyset['company_service']);

    $feedbacklist = DB::fetch_all('select * from %t where custom_id=%d and custom_type=1 order by add_time desc', array(
        'zimu_zhaopin_crm_custom_feedback2',
        $ids
    ));

    include zimu_template('admins/admins_' . $type .'_'. $op,'');


} else if ($op == 'resumeindex') {

    $ids    = intval($_GET['ids']);

    $listdata = DB::fetch_first('select * from %t where id=%d order by id asc', array(
        'zimu_zhaopin_resume',
        $ids
    ));

    $crm_person = DB::fetch_first('select * from %t where resume_id=%d order by resume_id desc', array(
        'zimu_zhaopin_crm_person',
        $ids
    ));

    if(!$crm_person && $listdata['kefu_uid'] == $_G['uid']){

        $crm_company_data['resume_id']       = $ids;
        $crm_company_data['resume_uid']        = $listdata['uid'];
        $crm_company_data['crm_uid']     = $_G['uid'];
        $crm_company_data['receive_time']     = $_G['timestamp'];
        DB::insert('zimu_zhaopin_crm_person', $crm_company_data);

        $crm_custom_log_data['custom_type']       = 2;
        $crm_custom_log_data['custom_id']        = $ids;
        $crm_custom_log_data['crm_uid']     = $_G['uid'];
        $crm_custom_log_data['op_type']       = 'receive';
        $crm_custom_log_data['note']       = $language_zimu['admins_crm_inc_php_1'];
        $crm_custom_log_data['add_time']     = $_G['timestamp'];
        $crm_custom_log_data['ip']     = $_G['clientip'];
        DB::insert('zimu_zhaopin_crm_custom_log', $crm_custom_log_data);

    }


    $totaljobs = DB::result_first("SELECT count(*) FROM %t where uid=%d and display=1", array(
        "zimu_zhaopin_jobs",
        $listdata['uid']
    ));

    $totalapply = DB::result_first('select count(*) from %t where personal_uid=%d and apply_addtime>%d', array(
        'zimu_zhaopin_personal_jobs_apply',
        $listdata['uid'],
        $_G['timestamp']-86400*30
    ));

    $totalviewlog = DB::result_first('select count(*) from %t where uid=%d and addtime>%d', array(
        'zimu_zhaopin_per_viewlog',
        $listdata['uid'],
        $_G['timestamp']-86400*30
    ));

    $paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
        'zimu_zhaopin_parameter2',
        'crm_resumeset'
    ));
    
    $crm_resumeset = unserialize($paramter['parameter']);
    $crm_resumeset['person_funnel'] = explode(',', $crm_resumeset['person_funnel']);
    $crm_resumeset['person_level'] = explode(',', $crm_resumeset['person_level']);
    $crm_resumeset['person_feedback'] = explode(',', $crm_resumeset['person_feedback']);
    $crm_resumeset['person_service'] = explode(',', $crm_resumeset['person_service']);

    $feedbacklist = DB::fetch_all('select * from %t where custom_id=%d and custom_type=2 order by add_time desc', array(
        'zimu_zhaopin_crm_custom_feedback',
        $ids
    ));

    $loglist = DB::fetch_all('select * from %t where custom_id=%d and custom_type=2 order by id desc', array(
        'zimu_zhaopin_crm_custom_log',
        $ids
    ));


    $kefudata = DB::fetch_all('select * from %t order by id asc', array(
        'zimu_zhaopin_kefu'
    ),'uid');

    include zimu_template('admins/admins_' . $type .'_'. $op,'');

} else if ($op == 'receive_company') {

    $ids    = intval($_GET['ids']);
    !$ids &&  ajaxReturn(0,$language_zimu['admins_crm_inc_php_2']);
    $kefudata = DB::fetch_first('select * from %t where uid=%d order by id asc', array(
        'zimu_zhaopin_kefu',
        $_G['uid']
    ));
    !$kefudata && ajaxReturn(0,$language_zimu['admins_crm_inc_php_3']);
    $companydata = DB::fetch_first('select * from %t where id=%d order by id asc', array(
        'zimu_zhaopin_company_profile',
        $ids
    ));
    $companydata['kefu_uid'] > 0 &&  ajaxReturn(0,$language_zimu['admins_crm_inc_php_4']);

    DB::query("update %t set kefu_uid=%d,kefu_name=%s where id=%d", array(
        'zimu_zhaopin_company_profile',
        $_G['uid'],
        $kefudata['kefu_name'],
        $ids
    ));

    $crm_company_data['com_id']       = $ids;
    $crm_company_data['com_uid']        = $companydata['uid'];
    $crm_company_data['crm_uid']     = $_G['uid'];
    $crm_company_data['receive_time']     = $_G['timestamp'];
    DB::insert('zimu_zhaopin_crm_company', $crm_company_data);

    $crm_custom_log_data['custom_type']       = 1;
    $crm_custom_log_data['custom_id']        = $ids;
    $crm_custom_log_data['crm_uid']     = $_G['uid'];
    $crm_custom_log_data['op_type']       = 'receive';
    $crm_custom_log_data['note']       = $language_zimu['admins_crm_inc_php_5'];
    $crm_custom_log_data['add_time']     = $_G['timestamp'];
    $crm_custom_log_data['ip']     = $_G['clientip'];
    DB::insert('zimu_zhaopin_crm_custom_log', $crm_custom_log_data);

    ajaxReturn(1,$language_zimu['admins_crm_inc_php_6']);

} else if ($op == 'receive_resume') {

    $ids    = intval($_GET['ids']);
    !$ids &&  ajaxReturn(0,$language_zimu['admins_crm_inc_php_7']);
    $kefudata = DB::fetch_first('select * from %t where uid=%d order by id asc', array(
        'zimu_zhaopin_kefu',
        $_G['uid']
    ));
    !$kefudata && ajaxReturn(0,$language_zimu['admins_crm_inc_php_8']);
    $resumedata = DB::fetch_first('select * from %t where id=%d order by id asc', array(
        'zimu_zhaopin_resume',
        $ids
    ));
    $resumedata['kefu_uid'] > 0 &&  ajaxReturn(0,$language_zimu['admins_crm_inc_php_9']);

    DB::query("update %t set kefu_uid=%d,kefu_name=%s where id=%d", array(
        'zimu_zhaopin_resume',
        $_G['uid'],
        $kefudata['kefu_name'],
        $ids
    ));

    $crm_person_data['resume_id']       = $ids;
    $crm_person_data['resume_uid']        = $resumedata['uid'];
    $crm_person_data['crm_uid']     = $_G['uid'];
    $crm_person_data['receive_time']     = $_G['timestamp'];
    DB::insert('zimu_zhaopin_crm_person', $crm_person_data);

    $crm_custom_log_data['custom_type']       = 2;
    $crm_custom_log_data['custom_id']        = $ids;
    $crm_custom_log_data['crm_uid']     = $_G['uid'];
    $crm_custom_log_data['op_type']       = 'receive';
    $crm_custom_log_data['note']       = $language_zimu['admins_crm_inc_php_10'];
    $crm_custom_log_data['add_time']     = $_G['timestamp'];
    $crm_custom_log_data['ip']     = $_G['clientip'];
    DB::insert('zimu_zhaopin_crm_custom_log', $crm_custom_log_data);

    ajaxReturn(1,$language_zimu['admins_crm_inc_php_11']);


} else if ($op == 'companylist') {
 
    $wheresql = 'where 1=1 ';

    $keyword = trim($_GET['keyword']);
    $keyword = dhtmlspecialchars($keyword);
    $keyword = stripsearchkey($keyword);
    $keyword = daddslashes($keyword);

    if (!empty($keyword)) {
        $wheresql .= " and (`companyname` LIKE '%{$keyword}%' or `uid` = '{$keyword}' or `telephone` = '{$keyword}') ";
    }
    
    $audit = intval($_GET['audit']);
    if (!empty($audit)) {
        $wheresql .= " and audit = ".$audit;
    }
    $setmeal_id = intval($_GET['setmeal_id']);
    if (!empty($setmeal_id)) {
        $wheresql .= " and setmeal_id > ".$setmeal_id;
    }
    $certificate_img_audit = intval($_GET['certificate_img_audit']);
    if($certificate_img_audit==1){
        $wheresql .= " and certificate_img_audit = ".$certificate_img_audit;
    }elseif($certificate_img_audit==2){
        $wheresql .= " and certificate_img_audit = 0";
    }

    $wheresql .= " and kefu_uid = 0 ";

    $pindex = max(1, intval($_GET['page']));
    $psize  = 30;
    
    $total = DB::result_first("SELECT count(*) FROM %t %i", array(
        "zimu_zhaopin_company_profile",
        $wheresql
    ));

    $total2 = DB::result_first("SELECT count(*) FROM %t %i", array(
        "zimu_zhaopin_company_profile",
        "where 1=1 and audit=2"
    ));

    $listdata = DB::fetch_all('select * from %t %i order by id desc limit %d,%d', array(
        'zimu_zhaopin_company_profile',
        $wheresql,
        ($pindex - 1) * $psize,
        $psize
    ));
    
    $pager = pagination($total, $pindex, $psize);
    
    
    include zimu_template('admins/admins_' . $type .'_'. $op,'');

} else if ($op == 'resumelist') {

    $wheresql = 'where 1=1 ';
    $keywordtype = intval($_GET['keywordtype']);
    $keyword = trim($_GET['keyword']);
    $keyword = dhtmlspecialchars($keyword);
    $keyword = stripsearchkey($keyword);
    $keyword = daddslashes($keyword);

    if (!empty($keyword)) {
        if ($keywordtype == 1) {
            $wheresql .= " and `id` = '{$keyword}' ";
        } elseif ($keywordtype == 2) {
            $wheresql .= " and `fullname` LIKE '%{$keyword}%' ";
        } elseif ($keywordtype == 3) {
            $wheresql .= " and `telephone` = '{$keyword}' ";
        } elseif ($keywordtype == 4) {
            $wheresql .= " and `intention_jobs` LIKE '%{$keyword}%' ";
        } elseif ($keywordtype == 5) {
            $wheresql .= " and `uid` = '{$keyword}' ";
        }
    }

    $audit = intval($_GET['audit']);
    if (!empty($audit)) {
        $wheresql .= " and audit = ".$audit;
    }

    $wheresql .= " and kefu_uid = 0 ";

    $pindex = max(1, intval($_GET['page']));
    $psize  = 30;
    
    $total = DB::result_first("SELECT count(*) FROM %t %i", array(
        "zimu_zhaopin_resume",
        $wheresql
    ));
    
    $total2 = DB::result_first("SELECT count(*) FROM %t %i", array(
        "zimu_zhaopin_resume",
        "where 1=1 and audit=2"
    ));

    $listdata = DB::fetch_all('select * from %t %i order by id desc limit %d,%d', array(
        'zimu_zhaopin_resume',
        $wheresql,
        ($pindex - 1) * $psize,
        $psize
    ));
    
    $pager = pagination($total, $pindex, $psize);
    
    
    include zimu_template('admins/admins_' . $type .'_'. $op,'');


} else if ($op == 'set_company_funnel') {

    $ids    = intval($_GET['ids']);
    !$ids &&  ajaxReturn(0,$language_zimu['admins_crm_inc_php_12']);
    $funnel    = intval($_GET['funnel']);
    !$funnel &&  ajaxReturn(0,$language_zimu['admins_crm_inc_php_13']);
    $remark = zm_diconv(trim($_GET['remark']));

    DB::query("update %t set funnel=%d where com_id=%d", array(
        'zimu_zhaopin_crm_company',
        $funnel,
        $ids
    ));

    $paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
        'zimu_zhaopin_parameter2',
        'crm_companyset'
    ));
    
    $crm_companyset = unserialize($paramter['parameter']);
    $crm_companyset['company_funnel'] = explode(',', $crm_companyset['company_funnel']);

    $crm_custom_log_data['custom_type']       = 1;
    $crm_custom_log_data['custom_id']        = $ids;
    $crm_custom_log_data['crm_uid']     = $_G['uid'];
    $crm_custom_log_data['op_type']       = 'funnel';
    $crm_custom_log_data['note']       = $language_zimu['admins_crm_inc_php_14'].' '.$language_zimu['admins_crm_inc_php_15'].' '.$crm_companyset['company_funnel'][$funnel-1];
    $crm_custom_log_data['remark']       = $remark;
    $crm_custom_log_data['add_time']     = $_G['timestamp'];
    $crm_custom_log_data['ip']     = $_G['clientip'];
    DB::insert('zimu_zhaopin_crm_custom_log', $crm_custom_log_data);

    ajaxReturn(1,$language_zimu['admins_crm_inc_php_16']);


} else if ($op == 'set_resume_funnel') {

    $ids    = intval($_GET['ids']);
    !$ids &&  ajaxReturn(0,$language_zimu['admins_crm_inc_php_17']);
    $funnel    = intval($_GET['funnel']);
    !$funnel &&  ajaxReturn(0,$language_zimu['admins_crm_inc_php_18']);
    $remark = zm_diconv(trim($_GET['remark']));

    DB::query("update %t set funnel=%d where resume_id=%d", array(
        'zimu_zhaopin_crm_person',
        $funnel,
        $ids
    ));

    $paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
        'zimu_zhaopin_parameter2',
        'crm_resumeset'
    ));
    
    $crm_resumeset = unserialize($paramter['parameter']);
    $crm_resumeset['person_funnel'] = explode(',', $crm_resumeset['person_funnel']);

    $crm_custom_log_data['custom_type']       = 2;
    $crm_custom_log_data['custom_id']        = $ids;
    $crm_custom_log_data['crm_uid']     = $_G['uid'];
    $crm_custom_log_data['op_type']       = 'funnel';
    $crm_custom_log_data['note']       = $language_zimu['admins_crm_inc_php_19'].' '.$language_zimu['admins_crm_inc_php_20'].' '.$crm_resumeset['person_funnel'][$funnel-1];
    $crm_custom_log_data['remark']       = $remark;
    $crm_custom_log_data['add_time']     = $_G['timestamp'];
    $crm_custom_log_data['ip']     = $_G['clientip'];
    DB::insert('zimu_zhaopin_crm_custom_log', $crm_custom_log_data);

    ajaxReturn(1,$language_zimu['admins_crm_inc_php_21']);


} else if ($op == 'set_company_level') {

    $ids    = intval($_GET['ids']);
    !$ids &&  ajaxReturn(0,$language_zimu['admins_crm_inc_php_22']);
    $level    = intval($_GET['level']);
    !$level &&  ajaxReturn(0,$language_zimu['admins_crm_inc_php_23']);
    $remark = zm_diconv(trim($_GET['remark']));

    DB::query("update %t set level=%d where com_id=%d", array(
        'zimu_zhaopin_crm_company',
        $level,
        $ids
    ));

    $paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
        'zimu_zhaopin_parameter2',
        'crm_companyset'
    ));
    
    $crm_companyset = unserialize($paramter['parameter']);
    $crm_companyset['company_level'] = explode(',', $crm_companyset['company_level']);

    $crm_custom_log_data['custom_type']       = 1;
    $crm_custom_log_data['custom_id']        = $ids;
    $crm_custom_log_data['crm_uid']     = $_G['uid'];
    $crm_custom_log_data['op_type']       = 'level';
    $crm_custom_log_data['note']       = $language_zimu['admins_crm_inc_php_24'].' '.$language_zimu['admins_crm_inc_php_25'].' '.$crm_companyset['company_level'][$level-1];
    $crm_custom_log_data['remark']       = $remark;
    $crm_custom_log_data['add_time']     = $_G['timestamp'];
    $crm_custom_log_data['ip']     = $_G['clientip'];
    DB::insert('zimu_zhaopin_crm_custom_log', $crm_custom_log_data);

    ajaxReturn(1,$language_zimu['admins_crm_inc_php_26']);

} else if ($op == 'set_resume_level') {

    $ids    = intval($_GET['ids']);
    !$ids &&  ajaxReturn(0,$language_zimu['admins_crm_inc_php_27']);
    $level    = intval($_GET['level']);
    !$level &&  ajaxReturn(0,$language_zimu['admins_crm_inc_php_28']);
    $remark = zm_diconv(trim($_GET['remark']));

    DB::query("update %t set level=%d where resume_id=%d", array(
        'zimu_zhaopin_crm_person',
        $level,
        $ids
    ));

    $paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
        'zimu_zhaopin_parameter2',
        'crm_resumeset'
    ));
    
    $crm_resumeset = unserialize($paramter['parameter']);
    $crm_resumeset['person_level'] = explode(',', $crm_resumeset['person_level']);

    $crm_custom_log_data['custom_type']       = 2;
    $crm_custom_log_data['custom_id']        = $ids;
    $crm_custom_log_data['crm_uid']     = $_G['uid'];
    $crm_custom_log_data['op_type']       = 'level';
    $crm_custom_log_data['note']       = $language_zimu['admins_crm_inc_php_29'].' '.$language_zimu['admins_crm_inc_php_30'].' '.$crm_resumeset['person_level'][$level-1];
    $crm_custom_log_data['remark']       = $remark;
    $crm_custom_log_data['add_time']     = $_G['timestamp'];
    $crm_custom_log_data['ip']     = $_G['clientip'];
    DB::insert('zimu_zhaopin_crm_custom_log', $crm_custom_log_data);

    ajaxReturn(1,$language_zimu['admins_crm_inc_php_31']);

} else if ($op == 'feedback') {

    $ids    = intval($_GET['ids']);
    !$ids &&  ajaxReturn(0,$language_zimu['admins_crm_inc_php_32']);

    $crm_custom_feedback['custom_type']       = intval($_GET['custom_type']);
    $crm_custom_feedback['custom_id']        = $ids;
    $crm_custom_feedback['crm_uid']     = $_G['uid'];
    $crm_custom_feedback['type_id']       = intval($_GET['type_id']);
    $crm_custom_feedback['contact_name']       = zm_diconv(trim($_GET['contact'])).zm_diconv(trim($_GET['telephone']));
    $is_next = intval($_GET['is_next']);
    if($is_next==1){
    $crm_custom_feedback['add_time']     = strtotime($_GET['next_time']);
    }else{
    $crm_custom_feedback['add_time']     = $_G['timestamp'];
    }
    $crm_custom_feedback['comment']     = zm_diconv(trim($_GET['comment']));
    DB::insert('zimu_zhaopin_crm_custom_feedback', $crm_custom_feedback);

    if($crm_custom_feedback['custom_type']==1){
        if($is_next==1){
        DB::query("update %t set next_time=%d where com_id=%d", array(
            'zimu_zhaopin_crm_company',
            $crm_custom_feedback['add_time'],
            $ids
        )); 
        }else{
        DB::query("update %t set follow_time=%d where com_id=%d", array(
            'zimu_zhaopin_crm_company',
            $crm_custom_feedback['add_time'],
            $ids
        )); 
        } 
    }

    if($crm_custom_feedback['custom_type']==2){
        if($is_next==1){
        DB::query("update %t set next_time=%d where resume_id=%d", array(
            'zimu_zhaopin_crm_person',
            $crm_custom_feedback['add_time'],
            $ids
        )); 
        }else{
        DB::query("update %t set follow_time=%d where resume_id=%d", array(
            'zimu_zhaopin_crm_person',
            $crm_custom_feedback['add_time'],
            $ids
        )); 
        } 
    }


    ajaxReturn(1,$language_zimu['admins_crm_inc_php_33']);

} else if ($op == 'feedback2') {

    $ids    = intval($_GET['ids']);
    !$ids &&  ajaxReturn(0,$language_zimu['admins_crm_inc_php_34']);

    $crm_custom_feedback['custom_type']       = intval($_GET['custom_type']);
    $crm_custom_feedback['custom_id']        = $ids;
    $crm_custom_feedback['crm_uid']     = $_G['uid'];
    $crm_custom_feedback['type_id']       = intval($_GET['type_id']);
    $crm_custom_feedback['contact_name']       = zm_diconv(trim($_GET['contact'])).zm_diconv(trim($_GET['telephone']));
    $is_next = intval($_GET['is_next']);
    if($is_next==1){
        $crm_custom_feedback['add_time']     = strtotime($_GET['next_time']);
    }else{
        $crm_custom_feedback['add_time']     = $_G['timestamp'];
    }
    $crm_custom_feedback['comment']     = zm_diconv(trim($_GET['comment']));
    DB::insert('zimu_zhaopin_crm_custom_feedback2', $crm_custom_feedback);

    ajaxReturn(1,$language_zimu['admins_crm_inc_php_35']);

} else if ($op == 'setremark') {

    $ids    = intval($_GET['ids']);
    !$ids &&  ajaxReturn(0,$language_zimu['admins_crm_inc_php_36']);
    $custom_type       = intval($_GET['custom_type']);
    $remark = zm_diconv(trim($_GET['remark']));

    if($custom_type==1){
    DB::query("update %t set remark=%s where com_id=%d", array(
        'zimu_zhaopin_crm_company',
        $remark,
        $ids
    ));
    }
    if($custom_type==2){
    DB::query("update %t set remark=%s where resume_id=%d", array(
        'zimu_zhaopin_crm_person',
        $remark,
        $ids
    ));
    }
    ajaxReturn(1,$language_zimu['admins_crm_inc_php_37']);

} else if ($op == 'setinfo') {

    $ids    = intval($_GET['ids']);
    !$ids &&  ajaxReturn(0,$language_zimu['admins_crm_inc_php_38']);
    $custom_type       = intval($_GET['custom_type']);
    $contact = zm_diconv(trim($_GET['contact']));
    $telephone = zm_diconv(trim($_GET['telephone']));

    if($custom_type==1){
    DB::query("update %t set contact=%s,telephone=%s where id=%d", array(
        'zimu_zhaopin_company_profile',
        $contact,
        $telephone,
        $ids
    ));
    $crm_custom_log_data['custom_type']       = 1;
    $crm_custom_log_data['custom_id']        = $ids;
    $crm_custom_log_data['crm_uid']     = $_G['uid'];
    $crm_custom_log_data['op_type']       = 'update_contact';
    $crm_custom_log_data['note']       = $language_zimu['admins_crm_inc_php_39'];
    $crm_custom_log_data['remark']       = $contact.':'.$telephone;
    $crm_custom_log_data['add_time']     = $_G['timestamp'];
    $crm_custom_log_data['ip']     = $_G['clientip'];
    DB::insert('zimu_zhaopin_crm_custom_log', $crm_custom_log_data);
    }
    ajaxReturn(1,$language_zimu['admins_crm_inc_php_40']);


} else if ($op == 'myresumelist') {

    $paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
        'zimu_zhaopin_parameter2',
        'crm_resumeset'
    ));
    
    $crm_resumeset = unserialize($paramter['parameter']);
    $crm_resumeset['person_funnel'] = explode(',', $crm_resumeset['person_funnel']);
    $crm_resumeset['person_level'] = explode(',', $crm_resumeset['person_level']);
    $crm_resumeset['person_feedback'] = explode(',', $crm_resumeset['person_feedback']);
    $crm_resumeset['person_service'] = explode(',', $crm_resumeset['person_service']);

    
    $wheresql = 'where 1=1 ';
    $keywordtype = intval($_GET['keywordtype']);
    $keyword = trim($_GET['keyword']);
    $keyword = dhtmlspecialchars($keyword);
    $keyword = stripsearchkey($keyword);
    $keyword = daddslashes($keyword);

    if (!empty($keyword)) {
        if ($keywordtype == 1) {
            $wheresql .= " and `id` = '{$keyword}' ";
        } elseif ($keywordtype == 2) {
            $wheresql .= " and `fullname` LIKE '%{$keyword}%' ";
        } elseif ($keywordtype == 3) {
            $wheresql .= " and `telephone` = '{$keyword}' ";
        } elseif ($keywordtype == 4) {
            $wheresql .= " and `intention_jobs` LIKE '%{$keyword}%' ";
        } elseif ($keywordtype == 5) {
            $wheresql .= " and `uid` = '{$keyword}' ";
        }
    }

    $audit = intval($_GET['audit']);
    if (!empty($audit)) {
        $wheresql .= " and audit = ".$audit;
    }

    if($manage_type == 'admins'){
    $wheresql .= " and kefu_uid > 0 ";
    }else{
    $wheresql .= " and kefu_uid = ".$_G['uid'];
    }

    $pindex = max(1, intval($_GET['page']));
    $psize  = 30;
    
    $total = DB::result_first("SELECT count(*) FROM %t %i", array(
        "zimu_zhaopin_resume",
        $wheresql
    ));
    
    $total2 = DB::result_first("SELECT count(*) FROM %t %i", array(
        "zimu_zhaopin_resume",
        "where 1=1 and audit=2"
    ));

    $listdata = DB::fetch_all('select * from %t %i order by id desc limit %d,%d', array(
        'zimu_zhaopin_resume',
        $wheresql,
        ($pindex - 1) * $psize,
        $psize
    ));
    
    $pager = pagination($total, $pindex, $psize);
    
    
    include zimu_template('admins/admins_' . $type .'_'. $op,'');

} else if ($op == 'mycompanylist2') {

    $paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
        'zimu_zhaopin_parameter2',
        'crm_companyset'
    ));

    $crm_companyset = unserialize($paramter['parameter']);
    $crm_companyset['company_funnel'] = explode(',', $crm_companyset['company_funnel']);
    $crm_companyset['company_level'] = explode(',', $crm_companyset['company_level']);
    $crm_companyset['company_feedback'] = explode(',', $crm_companyset['company_feedback']);
    $crm_companyset['company_service'] = explode(',', $crm_companyset['company_service']);

    $wheresql = 'where 1=1 ';

    if($manage_type == 'admins'){
        $wheresql .= " and kefu_uid > 0 ";
    }else{
        $wheresql .= " and kefu_uid = ".$_G['uid'];
    }

    $pindex = max(1, intval($_GET['page']));
    $psize  = 30;

    $total = DB::result_first("SELECT count(*) FROM %t", array(
        "zimu_zhaopin_company_profile2"
    ));

    $total2 = DB::result_first("SELECT count(*) FROM %t", array(
        "zimu_zhaopin_company_profile2"
    ));

    $listdata = DB::fetch_all('select * from %t %i order by id desc limit %d,%d', array(
        'zimu_zhaopin_company_profile2',
        $wheresql,
        ($pindex - 1) * $psize,
        $psize
    ));

    $pager = pagination($total, $pindex, $psize);


    include zimu_template('admins/admins_' . $type .'_'. $op,'');

} else if ($op == 'edit_company2') {

    if (submitcheck('submit')) {

        $isadd = DB::fetch_first('select * from %t where telephone=%s', array(
            'zimu_zhaopin_company_profile',
            $_GET['telephone']
        ));

        $isadd2 = DB::fetch_first('select * from %t where telephone=%s and id !=%d', array(
            'zimu_zhaopin_company_profile2',
            $_GET['telephone'],
            $_GET['ids']
        ));

        if($isadd || $isadd2){
            $tip = $language_zimu['admins_crm_inc_php_41'];
            include template('zimu_zhaopin:common/success');
            exit();
        }


        $data['companyname'] = strip_tags($_GET['companyname']);
        $data['contact']      = strip_tags($_GET['contact']);
        $data['telephone']    = strip_tags($_GET['telephone']);
        $data['address']      = strip_tags($_GET['address']);
        $data['weixin']     = strip_tags($_GET['weixin']);
        $data['addtime']    = time();
        $data['kefu_uid']              = $_G['uid'];
        $data['kefu_name'] = DB::result_first('select kefu_name from %t where uid=%d', array(
            'zimu_zhaopin_kefu',
            $_G['uid']
        ));
        $data['id'] = intval($_GET['ids']);
        if ($data['id'] > 0) {
            DB::update('zimu_zhaopin_company_profile2', $data, array(
                'id' => $data['id']
            ));
        }else{
            $result = DB::insert('zimu_zhaopin_company_profile2', $data, 1);
        }
        include template('zimu_zhaopin:common/success');


    }else{

        $ids = intval($_GET['ids']);

        $listdata = DB::fetch_first('select * from %t where id=%d', array(
            'zimu_zhaopin_company_profile2',
            $ids
        ));

        include zimu_template('admins/admins_' . $type .'_'. $op,'');

    }

} else if ($op == 'feedbacklist') {

    $paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
        'zimu_zhaopin_parameter2',
        'crm_companyset'
    ));

    $crm_companyset = unserialize($paramter['parameter']);
    $crm_companyset['company_funnel'] = explode(',', $crm_companyset['company_funnel']);
    $crm_companyset['company_level'] = explode(',', $crm_companyset['company_level']);
    $crm_companyset['company_feedback'] = explode(',', $crm_companyset['company_feedback']);
    $crm_companyset['company_service'] = explode(',', $crm_companyset['company_service']);

    $kefudata = DB::fetch_all('select * from %t order by id asc', array(
        'zimu_zhaopin_kefu'
    ),'uid');

    if($manage_type == 'admins'){
        $wheresql .= " where custom_type=1 ";
    }else{
        $wheresql .= " where custom_type=1 and crm_uid = ".$_G['uid'];
    }

    $time_start2 = strtotime($_GET['time_start']);
    $time_end2 = strtotime($_GET['time_end']);
    if (!empty($time_start2) && !empty($time_end2)) {
        $wheresql .= " and add_time >= ".$time_start2." and add_time <= ".$time_end2;
    }
    $keyword = intval($_GET['keyword']);
    if (!empty($keyword)) {
        $wheresql .= " and crm_uid = ".$keyword;
    }


    $pindex = max(1, intval($_GET['page']));
    $psize  = 20;

    $total = DB::result_first("SELECT count(*) FROM %t %i", array(
        "zimu_zhaopin_crm_custom_feedback",
        $wheresql
    ));

    $feedbacklist = DB::fetch_all('select * from %t %i order by add_time desc limit %d,%d', array(
        'zimu_zhaopin_crm_custom_feedback',
        $wheresql,
        ($pindex - 1) * $psize,
        $psize
    ));

    $pager = pagination($total, $pindex, $psize);

    include zimu_template('admins/admins_' . $type .'_'. $op,'');


} else {

    $paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
        'zimu_zhaopin_parameter2',
        'crm_companyset'
    ));

    $crm_companyset = unserialize($paramter['parameter']);
    $crm_companyset['company_funnel'] = explode(',', $crm_companyset['company_funnel']);
    $crm_companyset['company_level'] = explode(',', $crm_companyset['company_level']);
    $crm_companyset['company_feedback'] = explode(',', $crm_companyset['company_feedback']);
    $crm_companyset['company_service'] = explode(',', $crm_companyset['company_service']);

    $wheresql = 'where 1=1 ';

    $keyword = trim($_GET['keyword']);
    $keyword = dhtmlspecialchars($keyword);
    $keyword = stripsearchkey($keyword);
    $keyword = daddslashes($keyword);
    if (!empty($keyword)) {
        $wheresql .= " and (`companyname` LIKE '%{$keyword}%' or `uid` = '{$keyword}' or `telephone` = '{$keyword}') ";
    }

    $audit = intval($_GET['audit']);
    if (!empty($audit)) {
        $wheresql .= " and b.audit = ".$audit;
    }
    $setmeal_id = intval($_GET['setmeal_id']);
    if (!empty($setmeal_id)) {
        $wheresql .= " and b.setmeal_id > ".$setmeal_id;
    }
    $certificate_img_audit = intval($_GET['certificate_img_audit']);
    if($certificate_img_audit==1){
        $wheresql .= " and b.certificate_img_audit = ".$certificate_img_audit;
    }elseif($certificate_img_audit==2){
        $wheresql .= " and b.certificate_img_audit = 0";
    }

    if($manage_type == 'admins'){
    $wheresql .= " and a.crm_uid > 0 ";
    }else{
    $wheresql .= " and a.crm_uid = ".$_G['uid'];
    }

    $company_funnel = intval($_GET['company_funnel']);
    if (!empty($company_funnel)) {
        $wheresql .= " and a.funnel = ".$company_funnel;
    }
    $company_level = intval($_GET['company_level']);
    if (!empty($company_level)) {
        $wheresql .= " and a.level = ".$company_level;
    }


    $pindex = max(1, intval($_GET['page']));
    $psize  = 30;

    $aaa = DB::query('select a.*,b.* from %t a left join %t b on a.com_id=b.id %i order by rid desc', array('zimu_zhaopin_crm_company','zimu_zhaopin_company_profile',$wheresql));

    while($res = DB::fetch($aaa)){
        $listdata2[] = $res;
    }
    $total = count($listdata2);

    $aaa = DB::query('select a.*,b.* from %t a left join %t b on a.com_id=b.id %i order by rid desc limit %d,%d', array('zimu_zhaopin_crm_company','zimu_zhaopin_company_profile',$wheresql,($pindex - 1) * $psize,$psize));

    while($res = DB::fetch($aaa)){
        $listdata[] = $res;
    }
    
    $pager = pagination($total, $pindex, $psize);
    
    
    include zimu_template('admins/admins_' . $type .'_'. $op,'');
    
    
}