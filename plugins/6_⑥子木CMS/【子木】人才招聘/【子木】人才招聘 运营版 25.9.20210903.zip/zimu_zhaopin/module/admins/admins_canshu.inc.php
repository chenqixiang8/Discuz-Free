<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$op = addslashes($_GET['op']);
$op = $op ? $op : 'list';
$name = addslashes($_GET['name']);
$name = $name ? $name : 'trade';

if($op == 'list'){

if(submitcheck('submit')) {


		if (!empty($_GET['ids'])) {
			foreach ($_GET['ids'] as $k => $v) {

if($v){
		$data = array('c_name' => trim($_GET['c_name'][$k]), 'c_order' => intval($_GET['c_order'][$k]));

            DB::update('zimu_zhaopin_category', $data, array(
                'c_alias' => 'ZM_'.$name,
                'c_id' => $v
            ));

}elseif(trim($_GET['c_name'][$k])){

        $data = array('c_alias' => 'ZM_'.$name,'c_name' => trim($_GET['c_name'][$k]), 'c_order' => intval($_GET['c_order'][$k]));

        DB::insert('zimu_zhaopin_category', $data);

}

}
		}

        include template('zimu_zhaopin:common/success');

}else{

$lists = DB::fetch_all('select * from %t where c_alias=%s order by c_order asc,c_id asc', array(
        'zimu_zhaopin_category',
        'ZM_'.$name
    ));

include zimu_template('admins/admins_'.$type,'');

}


}


if ($op == 'post') {

if(submitcheck('submit')) {

        $data['name'] = strip_tags($_GET['name']);
        $data['sort'] = intval($_GET['sort']);

        DB::insert('zimu_zhaopin_area', $data);

        include template('zimu_zhaopin:common/success');

}else{

include zimu_template('admins/admins_'.$type,'');

}

}


if ($op == 'del' && $_GET['md5hash'] == formhash() ) {
	$ids = intval($_GET['ids']);

    $result = DB::delete('zimu_zhaopin_category', array(
        'c_id' => $ids
    ));

    include template('zimu_zhaopin:common/success');

}