<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$op = addslashes($_GET['op']);
$op = $op ? $op : 'list';

if ($op == 'del' && $_GET['md5hash'] == formhash()) {
    
    $ids = intval($_GET['ids']);
    
    $result = DB::delete('zimu_zhaopin_report', array(
        'id' => $ids
    ));
    
    include template('zimu_zhaopin:common/success');


} else {

if(submitcheck('submit')) {

    if (!empty($_GET['ids'])) {
        foreach ($_GET['ids'] as $k => $v) {

            if($v){
                $data = array('audit' => intval($_GET['audit'][$k]));

                DB::update('zimu_zhaopin_report', $data, array(
                    'id' => $v
                ));

            }

        }
    }
        include template('zimu_zhaopin:common/success');


}else{

    $wheresql = 'where 1=1 ';

    $keyword = trim($_GET['keyword']);
    $keyword = dhtmlspecialchars($keyword);
    $keyword = stripsearchkey($keyword);
    $keyword = daddslashes($keyword);
    if (!empty($keyword)) {
        $wheresql .= " and (`fullname` LIKE '%{$keyword}%' or `uid` = '{$keyword}' or `telephone` = '{$keyword}') ";
    }

    $audit = intval($_GET['audit']);
    if (!empty($audit)) {
        $wheresql .= " and audit = ".$audit;
    }


    $typeid = intval($_GET['typeid']);
    if (!empty($typeid)) {
        $wheresql .= " and type = ".$typeid;
    }

    $wheresql = $wheresql.$wherekefu;

    $pindex = max(1, intval($_GET['page']));
    $psize  = 30;
    
    $total = DB::result_first("SELECT count(*) FROM %t %i", array(
        "zimu_zhaopin_report",
        $wheresql
    ));
    
    $listdata = DB::fetch_all('select * from %t %i order by id desc limit %d,%d', array(
        'zimu_zhaopin_report',
        $wheresql,
        ($pindex - 1) * $psize,
        $psize
    ));
    
    $pager = pagination($total, $pindex, $psize);
    
    
    include zimu_template('admins/admins_' . $type,'');
    
}

}