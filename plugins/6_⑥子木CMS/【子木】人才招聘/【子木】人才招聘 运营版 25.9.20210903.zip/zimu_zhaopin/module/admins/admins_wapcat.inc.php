<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}


    if (submitcheck('submit')) {

        $data_url = array_filter($_GET['data_url']);
        $data_name = array_filter($_GET['data_name']);

        if(is_array($data_url)){
        $len      = count($data_url);
        }

        $data2 = array();
        for ($k = 0; $k < $len; $k++) {

    $data_img['name'] = $_FILES['data_img']['name'][$k];
    $data_img['type'] = $_FILES['data_img']['type'][$k];
    $data_img['tmp_name'] = $_FILES['data_img']['tmp_name'][$k];
    $data_img['error'] = $_FILES['data_img']['error'][$k];
    $data_img['size'] = $_FILES['data_img']['size'][$k];
    $upimgurl = zm_saveimages($data_img);
            $data2[$k]['data_img'] = $upimgurl ? $upimgurl : $_GET['img_data_img'][$k];
            $data2[$k]['data_url'] = $data_url[$k];
            $data2[$k]['data_name'] = $data_name[$k];
        }

        $paramters = $data2;

        $isadd = DB::fetch_first('select * from %t where name=%s order by id desc', array(
            'zimu_zhaopin_parameter2',
            'wapcat'
        ));
        

        
        if ($isadd['id'] > 0) {

        DB::query("update %t set parameter=%s where id=%d", array(
            'zimu_zhaopin_parameter2',
            serialize($paramters),
            $isadd['id']
        ));
            
        } else {

        $adddata = array(
                'name'=>'wapcat',
                'parameter'=>serialize($paramters),
        );

            DB::insert('zimu_zhaopin_parameter2', $adddata);
            
        }
        
        include template('zimu_zhaopin:common/success');
        
        
    } else {
        
        $paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
            'zimu_zhaopin_parameter2',
            'wapcat'
        ));
        
        $paramters = unserialize($paramter['parameter']);

        include zimu_template('admins/admins_' . $type,'');
        
    }