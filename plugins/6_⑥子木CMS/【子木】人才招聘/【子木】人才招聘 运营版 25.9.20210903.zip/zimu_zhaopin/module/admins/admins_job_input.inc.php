<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}


$category_jobs = DB::fetch_all('select * from %t order by c_order asc,c_id asc', array(
    'zimu_zhaopin_category'
));

foreach ($category_jobs as $key => $value) {

    $category_jobs2[$value['c_alias']][$value['c_id']] = $value['c_name'];

}

$tag_arr = $category_jobs2['ZM_jobtag'];

$arealist = DB::fetch_all('select * from %t where parentid=0 order by sort asc,id asc', array(
    'zimu_zhaopin_area'
));


$category_jobs = DB::fetch_all('select * from %t where parentid=0 order by category_order asc,id asc', array(
        'zimu_zhaopin_category_jobs'
    ));

foreach ($category_jobs as $key => $value) {

$category_jobs[$key]['childs'] = DB::fetch_all('select * from %t where parentid=%d order by category_order asc,id asc', array(
        'zimu_zhaopin_category_jobs',
        $value['id']
    ));

}


if(submitcheck('submit')) {


        $paramters['topclass']         = intval($_GET['topclass']);
        $paramters['category']         = intval($_GET['category'.$paramters['topclass']]);
        $paramters['category_cn']         = strip_tags($_GET['category'.$paramters['topclass'].'_cn']);
        $paramters['category_sort']         = intval($_GET['topclass_index']).','.intval($_GET['category_index']);
        $paramters['nature']        = intval($_GET['nature']);
        $paramters['nature_cn']        = strip_tags($_GET['nature_cn']);
        $paramters['district']         = intval($_GET['district']);
        $paramters['district_cn']         = strip_tags($_GET['district_cn']);
        $paramters['experience']         = intval($_GET['experience']);
        $paramters['experience_cn']         = strip_tags($_GET['experience_cn']);
        $paramters['education']         = intval($_GET['education']);
        $paramters['education_cn']         = strip_tags($_GET['education_cn']);
        $paramters['wage']         = intval($_GET['wage']);
        $paramters['wage_cn']         = strip_tags($_GET['wage_cn']);
        $paramters['category_cn']         = intval($_GET['category_cn']);
        $paramters['sex']         = intval($_GET['sex']);
        $paramters['tag']         = intval($_GET['tag']);

        
        $isadd = DB::fetch_first('select * from %t where name=%s order by id desc', array(
            'zimu_zhaopin_parameter2',
            'job_input'
        ));

        if ($isadd['id'] > 0) {

        DB::query("update %t set parameter=%s where id=%d", array(
            'zimu_zhaopin_parameter2',
            serialize($paramters),
            $isadd['id']
        ));
            
        } else {

        $adddata = array(
                'name'=>'job_input',
                'parameter'=>serialize($paramters),
        );

            DB::insert('zimu_zhaopin_parameter2', $adddata);
            
        }
        
        
        include template('zimu_zhaopin:common/success');
        


}else{


        $paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
            'zimu_zhaopin_parameter2',
            'job_input'
        ));
        
        $paramters = unserialize($paramter['parameter']);



include zimu_template('admins/admins_'.$type,'');


}