<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$op = addslashes($_GET['op']);
$op = $op ? $op : 'list';

$parentid = intval($_GET['parentid']);


if($op == 'list'){

if(submitcheck('submit')) {


		if (!empty($_GET['ids'])) {
			foreach ($_GET['ids'] as $k => $v) {

if($v){

		$data = array('name' => trim($_GET['name'][$k]), 'sort' => intval($_GET['sort'][$k]));

            DB::update('zimu_zhaopin_area', $data, array(
                'id' => $v
            ));

}elseif(trim($_GET['name'][$k])){

        $data = array('parentid' => $parentid,'name' => trim($_GET['name'][$k]), 'sort' => intval($_GET['sort'][$k]));

        DB::insert('zimu_zhaopin_area', $data);

}

			}
		}

        include template('zimu_zhaopin:common/success');

}else{


$top_lists = DB::fetch_all('select * from %t where parentid=0 order by sort asc,id asc', array(
        'zimu_zhaopin_area'
    ));

$lists = DB::fetch_all('select * from %t where parentid=%d order by sort asc,id asc', array(
        'zimu_zhaopin_area',
        $parentid
    ));

    $parentid2 = intval($_GET['parentid2']);

    $lists2 = DB::fetch_all('select * from %t where parentid=%d and parentid != 0 order by sort asc,id asc', array(
        'zimu_zhaopin_area',
        $parentid2
    ));

include zimu_template('admins/admins_'.$type,'');

}


}


if ($op == 'post') {

if(submitcheck('submit')) {

        $data['name'] = strip_tags($_GET['name']);
        $data['sort'] = intval($_GET['sort']);

        DB::insert('zimu_zhaopin_area', $data);

        include template('zimu_zhaopin:common/success');

}else{

include zimu_template('admins/admins_'.$type,'');

}

}


if ($op == 'del' && $_GET['md5hash'] == formhash() ) {
	$ids = intval($_GET['ids']);

    $result = DB::delete('zimu_zhaopin_area', array(
        'id' => $ids
    ));

    include template('zimu_zhaopin:common/success');

}