<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
    require DISCUZ_ROOT . './source/plugin/zimu_zhaopin/lib/thinkorm/v1/vendor/autoload.php';

    use think\Db;

    Db::setConfig([
        'type'     => 'mysql',
        'hostname' => $_G['config']['db'][1]['dbhost'],
        'username' => $_G['config']['db'][1]['dbuser'],
        'database' => $_G['config']['db'][1]['dbname'],
        'password'    => $_G['config']['db'][1]['dbpw'],
        'charset'  => $_G['config']['db'][1]['dbcharset'],
        'prefix'   => $_G['config']['db'][1]['tablepre'],
        'resultset_type' => 'collection',
        'fields_strict'  => false,
        'debug'    => false,
    ]);
$op = addslashes($_GET['op']);
$op = $op ? $op : 'list';

if ($op == 'edit') {

    if (submitcheck('submit')) {

        $data['con']        = strip_tags($_GET['con']);
        $data['newtype']         = strip_tags($_GET['newtype']);
        $data['newcatid']         = strip_tags($_GET['newcatid']);
        $data['url']        = strip_tags($_GET['url']);
        $data['views']         = intval($_GET['views']);
        $data['position']         = intval($_GET['position']);
        $data['noapp']         = intval($_GET['noapp']);
        if ($_FILES['adimg']['tmp_name']) {
            $data['adimg'] = zm_saveimages($_FILES['adimg']);
        }
        $data['addtime'] = strtotime($_GET['addtime']);

        $data['id']      = intval($_GET['ids']);


        if ($data['id'] > 0) {

            $ids = intval($_GET['ids']);

            Db::name('zimu_zhaopin_adlist')->where('id' ,$data['id'])->update($data);
            
        }else{

            Db::name('zimu_zhaopin_adlist')->insert($data);

        }

        include template('zimu_zhaopin:common/success');
        
        
    } else {

        $ids = intval($_GET['ids']);
        $listdata = Db::name('zimu_zhaopin_adlist')->where('id', $ids)->find();
        include zimu_template('admins/admins_' . $type,'');
        
    }

} else if ($op == 'del' && $_GET['md5hash'] == formhash()) {
    
    $ids = intval($_GET['ids']);

    Db::name('zimu_zhaopin_adlist')->where('id', $ids)->delete();

    include template('zimu_zhaopin:common/success');


} else {

    $typetype = intval($_GET['typetype']);

    if (!empty($keyword)) {
        $wheresql[] = ['type','=',$typetype];
    }

    $whereorder = 'id';

    $pindex = max(1, intval($_GET['page']));
    $psize  = 200;

    $total = Db::name('zimu_zhaopin_adlist')->where($wheresql)->count();

    $listdata = Db::name('zimu_zhaopin_adlist')->where($wheresql)->order([$whereorder =>'desc','id'=>'desc'])->page($pindex,200)->select()->toArray();
    $pager = pagination($total, $pindex, $psize);

    include zimu_template('admins/admins_' . $type,'');
    
    
}