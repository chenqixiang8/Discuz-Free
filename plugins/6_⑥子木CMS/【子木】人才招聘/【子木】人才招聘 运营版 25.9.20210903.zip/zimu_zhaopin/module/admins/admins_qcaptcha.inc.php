<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(submitcheck('submit')) {

        $paramters = $_GET['options'];

        $isadd = DB::fetch_first('select * from %t where name=%s order by id desc', array(
            'zimu_zhaopin_parameter2',
            'qcaptcha'
        ));

        if ($isadd['id'] > 0) {

        DB::query("update %t set parameter=%s where id=%d", array(
            'zimu_zhaopin_parameter2',
            serialize($paramters),
            $isadd['id']
        ));
            
        } else {

        $adddata = array(
                'name'=>'qcaptcha',
                'parameter'=>serialize($paramters),
        );

            DB::insert('zimu_zhaopin_parameter2', $adddata);
            
        }
        
        
        include template('zimu_zhaopin:common/success');
        


}else{


        $paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
            'zimu_zhaopin_parameter2',
            'qcaptcha'
        ));
        
        $paramters = unserialize($paramter['parameter']);

include zimu_template('admins/admins_'.$type,'');


}