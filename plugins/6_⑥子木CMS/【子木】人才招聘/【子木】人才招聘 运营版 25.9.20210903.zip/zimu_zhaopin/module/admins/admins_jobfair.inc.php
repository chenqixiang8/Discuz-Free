<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$op = addslashes($_GET['op']);
$op = $op ? $op : 'jobfairlist';

if ($op == 'editjobfair') {

if(submitcheck('submit')) {

        $data['title']        = strip_tags($_GET['title']);
        $data['starttime'] = strtotime($_GET['starttime']);
        $data['endtime'] = strtotime($_GET['endtime']);
        $data['contact']        = strip_tags($_GET['contact']);
        $data['tel']        = strip_tags($_GET['tel']);
        if ($_FILES['thumb']['tmp_name']) {
            $data['thumb'] = zm_saveimages($_FILES['thumb']);
        }
        $data['address']        = strip_tags($_GET['address']);
        $data['bus']        = strip_tags($_GET['bus']);
        $data['addtime'] = strtotime($_GET['addtime']);
        $data['intro']    = dhtmlspecialchars($_GET['intro']);
        $data['registration']        = strip_tags($_GET['registration']);
        $data['price']        = strip_tags($_GET['price']);
        $data['id']      = intval($_GET['ids']);
        
        if ($data['id'] > 0) {

        DB::update('zimu_zhaopin_jobfair', $data, array(
            'id' => $data['id']
        ));
            
        } else {
            
            $result = DB::insert('zimu_zhaopin_jobfair', $data, 1);
            
        }
          
        include template('zimu_zhaopin:common/success');

}else{

        $ids = intval($_GET['ids']);
        
        $listdata = DB::fetch_first('select * from %t where id=%d', array(
            'zimu_zhaopin_jobfair',
            $ids
        ));

        include zimu_template('admins/admins_' . $type .'_'. $op,'');

}

} else if ($op == 'jobfair_position' ) {

    $ids = $jobfair_id = intval($_GET['ids']);

    $pre = range('A','Z');

    $area = DB::fetch_all('select * from %t where jobfair_id=%d order by area asc', array(
        'zimu_zhaopin_jobfair_area',
        $ids
    ));

    $position_arr = DB::fetch_all('select * from %t where jobfair_id=%d order by area_id asc,orderid asc', array(
        'zimu_zhaopin_jobfair_position',
        $ids
    ));

    $position = array();

    foreach ($position_arr as $key => $value) {

        $position[$value['area_id']][] = $value;

    }

    include zimu_template('admins/admins_' . $type .'_'. $op,'');


} else if ($op == 'area_add' && $_GET['md5hash'] == formhash()) {

    $ids = $jobfair_id = intval($_GET['jobfair_id']);
    $area = $_GET['area'];
    $position_start = $_GET['position_start'];
    $position_end = $_GET['position_end'];

    $area_arr2 = DB::fetch_all('select * from %t where jobfair_id=%d order by area asc', array(
        'zimu_zhaopin_jobfair_area',
        $ids
    ),'area');

    $area_arr = array();
    foreach ($area_arr2 as $key => $value) {
        $area_arr[$value['area']] = $value['id'];
    }


    $position_arr2 = DB::fetch_all('select * from %t where jobfair_id=%d order by position asc', array(
        'zimu_zhaopin_jobfair_position',
        $ids
    ),'position');

    $position_arr = array();
    foreach ($position_arr2 as $key => $value) {
        $position_arr[$value['position']] = $value['id'];
    }

        if (is_array($area) && count($area)>0)

        {

            for ($i =0; $i <count($area);$i++){

                if (!empty($area[$i]))

                {   

                    //���չ��������

                    if(!isset($area_arr[$area[$i]])){

                        $area_sqlarr['jobfair_id'] = intval($jobfair_id);

                        $area_sqlarr['area'] = trim($area[$i]);

                        $insertid = DB::insert('zimu_zhaopin_jobfair_area', $area_sqlarr,1);

                    }else{

                        //չ�����ڣ�������չ������

                        $insertid = $area_arr[$area[$i]];

                    }

                    $area_word = $area[$i];

                    if(!empty($position_start[$i]) && !empty($position_end[$i])){

                        for ($x = $position_start[$i]; $x <= $position_end[$i]; $x++) { 

                            if(isset($position_arr[$area_word.$x])){

                                continue;

                            }

                            $position_sqlarr['jobfair_id'] = intval($jobfair_id);

                            $position_sqlarr['area_id'] = $insertid;

                            $position_sqlarr['position'] = $area_word.$x;

                            $position_sqlarr['orderid'] = $x;

                            DB::insert('zimu_zhaopin_jobfair_position', $position_sqlarr);

                        }

                    }

                }

            }

        }

        include template('zimu_zhaopin:common/success');


} else if ($op == 'area_delete' && $_GET['md5hash'] == formhash()) {

    $ids = $jobfair_id = intval($_GET['jobfair_id']);
    $area = intval($_GET['area']);

    DB::delete('zimu_zhaopin_jobfair_area', array(
        'jobfair_id' => $ids,
        'id' => $area
    ));

    DB::delete('zimu_zhaopin_jobfair_position', array(
        'jobfair_id' => $ids,
        'area_id' => $area
    ));

    include template('zimu_zhaopin:common/success');

} else if ($op == 'position_pause' ) {

    $ids = intval($_GET['ids']);
    $pause = intval($_GET['pause']);

    if($pause==1){

    DB::query("update %t set status=3 where id=%d", array(
        'zimu_zhaopin_jobfair_position',
        $ids
    ));

    }else{

    DB::query("update %t set status=0 where id=%d", array(
        'zimu_zhaopin_jobfair_position',
        $ids
    ));

    }

    ajaxReturn(1,$language_zimu['admins_jobfair_inc_php_2'],$status);exit();

} else if ($op == 'position_delete' ) {

    $ids = intval($_GET['ids']);

    DB::delete('zimu_zhaopin_jobfair_position', array(
        'id' => $ids
    ));

    ajaxReturn(1,$language_zimu['admins_jobfair_inc_php_3']);exit();

} else if ($op == 'del' && $_GET['md5hash'] == formhash()) {
    
    $ids = intval($_GET['ids']);
    
    $result = DB::delete('zimu_zhaopin_jobfair', array(
        'id' => $ids
    ));
    
    include template('zimu_zhaopin:common/success');


} else {


        
    $wheresql = 'where 1=1 ';

    $pindex = max(1, intval($_GET['page']));
    $psize  = 30;
    
    $total = DB::result_first("SELECT count(*) FROM %t %i", array(
        "zimu_zhaopin_jobfair",
        $wheresql
    ));

    $listdata = DB::fetch_all('select * from %t %i order by id desc limit %d,%d', array(
        'zimu_zhaopin_jobfair',
        $wheresql,
        ($pindex - 1) * $psize,
        $psize
    ));
    
    $pager = pagination($total, $pindex, $psize);
    
    
    include zimu_template('admins/admins_' . $type .'_'. $op,'');
    
    
}