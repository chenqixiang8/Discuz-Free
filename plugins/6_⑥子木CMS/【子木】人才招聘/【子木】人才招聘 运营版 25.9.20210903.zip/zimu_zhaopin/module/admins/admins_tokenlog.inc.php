<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if (!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }

    $op = addslashes($_GET['op']);
    $op = $op ? $op : 'list';

    if ($op == 'edit') {

        if (submitcheck('submit')) {

            $data['uid']         = intval($_GET['uid']);
            $data['telephone'] = strip_tags($_GET['telephone']);
            $data['openid']   = strip_tags($_GET['openid']);
            $data['unionid']   = strip_tags($_GET['unionid']);
            $data['xcx_openid']   = strip_tags($_GET['xcx_openid']);
            $data['token']   = strip_tags($_GET['token']);
            $data['points']   = intval($_GET['points']);
            $data['blacklist']   = intval($_GET['blacklist']);
            $data['id'] = intval($_GET['ids']);

            if ($data['id'] > 0) {

                DB::update('zimu_zhaopin_members', $data, array(
                    'id' => $data['id']
                ));

            }


            include template('zimu_zhaopin:common/success');


        } else {

            $ids = intval($_GET['ids']);

            $listdata = DB::fetch_first('select * from %t where id=%d', array(
                'zimu_zhaopin_members',
                $ids
            ));

            include zimu_template('admins/admins_' . $type, '');

        }


    } else if ($op == 'del' && $_GET['md5hash'] == formhash()) {

        $ids = intval($_GET['ids']);

        $result = DB::delete('zimu_zhaopin_company_profile', array(
            'uid' => $ids
        ));

        $result = DB::delete('zimu_zhaopin_jobs', array(
            'uid' => $ids
        ));

        $result = DB::delete('zimu_zhaopin_members_setmeal', array(
            'uid' => $ids
        ));

        include template('zimu_zhaopin:common/success');

    } else {

        $wheresql    = 'where 1=1 ';
        $keywordtype = intval($_GET['keywordtype']);
        $keyword     = trim($_GET['keyword']);
        $keyword     = dhtmlspecialchars($keyword);
        $keyword     = stripsearchkey($keyword);
        $keyword     = daddslashes($keyword);

        if (!empty($keyword)) {
            if ($keywordtype == 1) {
                $wheresql .= " and `id` = '{$keyword}' ";
            } elseif ($keywordtype == 2) {
                $wheresql .= " and `companyname` LIKE '%{$keyword}%' ";
            } elseif ($keywordtype == 3) {
                $wheresql .= " and `uid` = '{$keyword}' ";
            } elseif ($keywordtype == 4) {
                $wheresql .= " and `telephone` LIKE '%{$keyword}%' ";
            }
        }

        $pindex = max(1, intval($_GET['page']));
        $psize  = 30;


        $total = DB::result_first("SELECT count(*) FROM %t %i", array(
            "zimu_zhaopin_members",
            $wheresql
        ));

        $listdata = DB::fetch_all('select * from %t %i order by id desc limit %d,%d', array(
            'zimu_zhaopin_members',
            $wheresql,
            ($pindex - 1) * $psize,
            $psize
        ));

        $pager = pagination($total, $pindex, $psize);


        include zimu_template('admins/admins_' . $type, '');


    }