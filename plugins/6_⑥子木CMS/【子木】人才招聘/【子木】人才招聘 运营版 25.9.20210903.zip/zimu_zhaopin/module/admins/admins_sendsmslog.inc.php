<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

    require DISCUZ_ROOT . './source/plugin/zimu_zhaopin/lib/thinkorm/v1/vendor/autoload.php';

    use think\Db;

    Db::setConfig([
        'type'     => 'mysql',
        'hostname' => $_G['config']['db'][1]['dbhost'],
        'username' => $_G['config']['db'][1]['dbuser'],
        'database' => $_G['config']['db'][1]['dbname'],
        'password'    => $_G['config']['db'][1]['dbpw'],
        'charset'  => $_G['config']['db'][1]['dbcharset'],
        'prefix'   => $_G['config']['db'][1]['tablepre'],
        'resultset_type' => 'collection',
        'fields_strict'  => false,
        'debug'    => false,
    ]);

$op = addslashes($_GET['op']);
$op = $op ? $op : 'list';


if ($op == 'del' && $_GET['md5hash'] == formhash()) {


} else {


    $pindex = max(1, intval($_GET['page']));
    $psize  = 30;

    $total = Db::name('zimu_zhaopin_sendsmslog')->count();

    $listdata = Db::name('zimu_zhaopin_sendsmslog')->order('id', 'desc')->page($pindex,30)->select()->toArray();
    
    $pager = pagination($total, $pindex, $psize);
    
    
    include zimu_template('admins/admins_' . $type,'');
    
    
}