<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$wheresql = 'where 1=1 ';
$wheresql2 = 'where 1=1 ';
$wheresql3 = 'where 1=1 ';

    if($manage_type == 'kefu'){
        $wheresql = $wheresql.$wherekefu;
        $wheresql2 = $wheresql2.$wherekefu2;
        $wheresql3 = $wheresql3.$wherekefu3;
    }

$company_nums = DB::result_first("SELECT count(*) FROM %t %i", array(
    "zimu_zhaopin_company_profile",
    $wheresql
));

$company_nums2 = DB::result_first("SELECT count(*) FROM %t where addtime>%d %i", array(
    "zimu_zhaopin_company_profile",
    strtotime(date('Y-m-d', $_G['timestamp'])),
    $wherekefu
));

$jobs_nums = DB::result_first("SELECT count(*) FROM %t %i", array(
    "zimu_zhaopin_jobs",
    $wheresql
));

$jobs_nums2 = DB::result_first("SELECT count(*) FROM %t where addtime>%d %i", array(
    "zimu_zhaopin_jobs",
    strtotime(date('Y-m-d', $_G['timestamp'])),
    $wherekefu
));


$resume_nums = DB::result_first("SELECT count(*) FROM %t %i", array(
    "zimu_zhaopin_resume",
    $wheresql2
));

$resume_nums2 = DB::result_first("SELECT count(*) FROM %t where addtime>%d %i", array(
    "zimu_zhaopin_resume",
    strtotime(date('Y-m-d', $_G['timestamp'])),
    $wherekefu2
));


$order_nums = DB::result_first("SELECT sum(amount) FROM %t where is_paid=2 %i", array(
    "zimu_zhaopin_order",
    $wherekefu3
));

$order_nums2 = DB::result_first("SELECT sum(amount) FROM %t where pay_points=0 and is_paid=2 and addtime>%d %i", array(
    "zimu_zhaopin_order",
    strtotime(date('Y-m-d', $_G['timestamp'])),
    $wherekefu3
));

$order_nums2 = intval($order_nums2);

$oldcom_data = DB::fetch_all('select * from %t where setmeal_id>1 and endtime<%d %i order by id desc', array(
    'zimu_zhaopin_members_setmeal',
    $_G['timestamp'],
    $wherekefu
));


$audit_com = DB::result_first("SELECT count(*) FROM %t where audit=2 %i", array(
    "zimu_zhaopin_company_profile",
    $wherekefu
));

$audit_jobs = DB::result_first("SELECT count(*) FROM %t where audit=2 %i", array(
    "zimu_zhaopin_jobs",
    $wherekefu
));

$audit_resume = DB::result_first("SELECT count(*) FROM %t where audit=2 %i", array(
    "zimu_zhaopin_resume",
    $wherekefu2
));

$audit_report = DB::result_first("SELECT count(*) FROM %t where audit=1", array(
    "zimu_zhaopin_report"
));

$bind_weixin_company = DB::result_first("SELECT count(*) FROM %t where bind_weixin=1 %i", array(
    "zimu_zhaopin_company_profile",
    $wherekefu
));

$bind_weixin_resume = DB::result_first("SELECT count(*) FROM %t where bind_weixin=1 %i", array(
    "zimu_zhaopin_resume",
    $wherekefu2
));

$month_nums = DB::result_first("SELECT sum(amount) FROM %t where pay_points=0 and is_paid=2 and addtime>=%d and addtime<=%d %i", array(
    "zimu_zhaopin_order",
    mktime(0,0,0,date('m'),1,date('Y')),
    mktime(23,59,59,date('m'),date('t'),date('Y')),
    $wherekefu3
));
$month_nums = intval($month_nums);

$month_nums2 = DB::result_first("SELECT sum(amount) FROM %t where pay_points=0 and is_paid=2 and addtime>=%d and addtime<=%d %i", array(
    "zimu_zhaopin_order",
    strtotime(date('Y-m-01 00:00:00',strtotime('-1 month'))),
    strtotime(date("Y-m-d 23:59:59", strtotime(-date('d').'day'))),
    $wherekefu3
));
$month_nums2 = intval($month_nums2);

include zimu_template('admins/admins_'.$type,'');

