<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if (!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }

    isuid();
    $ac       = addslashes($_GET['ac']);
    $tosubmit = intval($_GET['tosubmit']);

    if (IN_WECHAT) {
        $openid = $_G['cookie']['zimu_zhaopin_openid'] ? $_G['cookie']['zimu_zhaopin_openid'] : '';
        if (!$openid) {
            $tools    = new JsApiPaySF();
            $opendata = $tools->GetFollowOpenid(get_url() . '&oauth=yes');
            if ($openid = $opendata['openid']) {
                dsetcookie('zimu_zhaopin_openid', $openid, 86400);
            }
        }
        if ($openid) {
            DB::query("update %t set openid=%s where uid=%d", array(
                'zimu_zhaopin_members',
                $openid,
                $_G['uid']
            ));
        }
    }


    $resume_info = DB::fetch_first('select * from %t where uid=%d order by id asc', array(
        'zimu_zhaopin_resume',
        $_G['uid']
    ));

    if (!$resume_info && checkmobile() && !$zmdata['settings']['view_jobs_mobile']) {
        dheader('Location: ' . ZIMUCMS_URL . '&model=resume_edit_basis');
    }

    $rid = $resume_info['id'];

    if ($ac == 'service_stick') {

        if ($tosubmit == 1) {


            $resume_id = $rid;
            if (!$resume_id) {
                ajaxReturn(0, $language_zimu['personalservice_inc_php_0']);
            }

            $service_id   = I('service_id', 0, 'intval');
            $service_info = DB::fetch_first('select * from %t where cat=%s and id=%d order by id desc', array(
                'zimu_zhaopin_setmeal_increment',
                'resume_stick',
                $service_id
            ));

            if (!$service_info) {
                ajaxReturn(0, $language_zimu['personalservice_inc_php_1']);
            }


            $params['oid']             = date('YmdHis') . mt_rand(100000, 999999);
            $params['zpid']            = $resume_id;
            $params['uid']             = $_G['uid'];
            $params['openid']          = $openid;
            $params['utype']           = 2;
            $params['order_type']      = 3;
            $params['pay_type']        = 2;
            $params['is_paid']         = 1;
            $params['amount']          = $service_info['price'];
            $params['pay_amount']      = $service_info['price'];
            $params['payment']         = $_GET['payment_name'] == 'remittance' ? 'remittance' : 'wxpay';
            $params['payment_cn']      = $_GET['payment_name'] == 'remittance' ? $language_zimu['personalservice_inc_php_2'] : $language_zimu['personalservice_inc_php_3'];
            $params['description']     = $service_info['name'];
            $params['service_name']    = 'resume_stick';
            $params_array              = array(
                'days' => $service_info['value']
            );
            $params_array['resume_id'] = $resume_id;
            $params['params']          = serialize($params_array);
            $params['addtime']         = $_G['timestamp'];

            $params['setmeal'] = $service_id;
            $params['referer'] = addslashes($_GET['referer']);

            $return_order_info = DB::insert('zimu_zhaopin_order', $params, 1);

            if (checkmobile()) {

                ajaxReturn(1, $language_zimu['personalservice_inc_php_4'], ZIMUCMS_URL . '&model=personalservice&ac=order_detail&order_id=' . $return_order_info);
                exit();

            } else {

                if ($_GET['payment_name'] == 'remittance') {

                    $data['qrurl']    = '333';
                    $data['order_id'] = $return_order_info;
                    ajaxReturn(1, $language_zimu['personalservice_inc_php_5'], $data);
                    exit();

                }

                $subject = $service_info['name'];
                $body    = diconv(cutstr(strip_tags($subject), 20), CHARSET, 'UTF-8');

                $tools  = new JsApiPaySF();
                $notify = new NativePaySF();
                $input  = new WxPayUnifiedOrderSF();
                $input->SetBody($body);
                $input->SetAttach($body);
                $input->SetOut_trade_no($params['oid']);
                $input->SetTotal_fee($service_info['price'] * 100);
                $input->SetTime_start(date('YmdHis'));
                $input->SetGoods_tag($body);
                $pburl = $_G['siteurl'];
                $input->SetNotify_url($pburl . 'source/plugin/zimu_zhaopin/lib/notify_wx.php');
                //$input->SetTrade_type((IN_WECHAT ? 'JSAPI' : (checkmobile() ? 'MWEB' : 'NATIVE')));
                $input->SetTrade_type('NATIVE');

                $input->SetProduct_id($params['oid']);
                $result = $notify->GetPayUrl($input);
                $url2   = $result['code_url'];
                if (!$url2) {
                    $msg = diconv($result['return_msg'], 'utf-8');
                    ajaxReturn(0, $msg);
                    exit();

                } else {
                    $data['qrurl']    = ZIMUCMS_URL.'&model=toqrcode&url=' . urlencode($url2);
                    $data['order_id'] = $return_order_info;
                    ajaxReturn(1, $language_zimu['personalservice_inc_php_6'], $data);
                    exit();

                }


            }



        } else {

            $increment_arr = DB::fetch_all('select * from %t where cat=%s order by sort asc,id asc', array(
                'zimu_zhaopin_setmeal_increment',
                'resume_stick'
            ));
            if ($resume_info['stick'] == 1 && $resume_info['stick_endtime'] > $_G['timestamp']) {
                $resume_buy = 1;
            }
        }


    } elseif ($ac == 'service_tag') {


        $tag_arr = explode(',', $zmdata['settings']['strong_tag']);

        if ($tosubmit == 1) {


            $resume_id = $rid;
            if (!$resume_id) {
                ajaxReturn(0, $language_zimu['personalservice_inc_php_7']);
            }

            $service_id   = I('service_id', 0, 'intval');
            $service_info = DB::fetch_first('select * from %t where cat=%s and id=%d order by id desc', array(
                'zimu_zhaopin_setmeal_increment',
                'strong_tag',
                $service_id
            ));
            if (!$service_info) {
                ajaxReturn(0, $language_zimu['personalservice_inc_php_8']);
            }


            $params['oid']              = date('YmdHis') . mt_rand(100000, 999999);
            $params['zpid']             = $resume_id;
            $params['uid']              = $_G['uid'];
            $params['openid']           = $openid;
            $params['utype']            = 2;
            $params['order_type']       = 4;
            $params['pay_type']         = 2;
            $params['is_paid']          = 1;
            $params['amount']           = $service_info['price'];
            $params['pay_amount']       = $service_info['price'];
            $params['payment']          = $_GET['payment_name'] == 'remittance' ? 'remittance' : 'wxpay';
            $params['payment_cn']       = $_GET['payment_name'] == 'remittance' ? $language_zimu['personalservice_inc_php_9'] : $language_zimu['personalservice_inc_php_10'];
            $params['description']      = $service_info['name'];
            $params['service_name']     = 'strong_tag';
            $params_array               = array(
                'days' => $service_info['value']
            );
            $params_array['resume_id']  = $resume_id;
            $params_array['strong_tag'] = addslashes(zm_diconv($_GET['tag_id']));
            $params['params']           = serialize($params_array);
            $params['addtime']          = $_G['timestamp'];

            $params['setmeal'] = $service_id;

            $return_order_info = DB::insert('zimu_zhaopin_order', $params, 1);

            if (checkmobile()) {

                ajaxReturn(1, $language_zimu['personalservice_inc_php_11'], ZIMUCMS_URL . '&model=personalservice&ac=order_detail&order_id=' . $return_order_info);
                exit();

            } else {

                if ($_GET['payment_name'] == 'remittance') {

                    $data['qrurl']    = '333';
                    $data['order_id'] = $return_order_info;
                    ajaxReturn(1, $language_zimu['personalservice_inc_php_12'], $data);
                    exit();

                }

                $subject = $service_info['name'];
                $body    = diconv(cutstr(strip_tags($subject), 20), CHARSET, 'UTF-8');

                $tools  = new JsApiPaySF();
                $notify = new NativePaySF();
                $input  = new WxPayUnifiedOrderSF();
                $input->SetBody($body);
                $input->SetAttach($body);
                $input->SetOut_trade_no($params['oid']);
                $input->SetTotal_fee($service_info['price'] * 100);
                $input->SetTime_start(date('YmdHis'));
                $input->SetGoods_tag($body);
                $pburl = $_G['siteurl'];
                $input->SetNotify_url($pburl . 'source/plugin/zimu_zhaopin/lib/notify_wx.php');
                $input->SetTrade_type('NATIVE');

                $input->SetProduct_id($params['oid']);
                $result = $notify->GetPayUrl($input);
                $url2   = $result['code_url'];
                if (!$url2) {
                    $msg = diconv($result['return_msg'], 'utf-8');
                    ajaxReturn(0, $msg);
                    exit();

                } else {
                    $data['qrurl']    = ZIMUCMS_URL.'&model=toqrcode&url=' . urlencode($url2);
                    $data['order_id'] = $return_order_info;
                    ajaxReturn(1, $language_zimu['personalservice_inc_php_13'], $data);
                    exit();

                }


            }




        } else {

            $increment_arr = DB::fetch_all('select * from %t where cat=%s order by sort asc,id asc', array(
                'zimu_zhaopin_setmeal_increment',
                'strong_tag'
            ));
            if ($resume_info['strong_tag'] && $resume_info['strong_tag_endtime'] > $_G['timestamp']) {
                $resume_buy = 1;
            }

        }


    } elseif ($ac == 'check_weixinpay_notify') {

        $order_id = intval($_GET['order_id']);

        $order = DB::fetch_first('select * from %t where uid=%d and id=%d order by id desc', array(
            'zimu_zhaopin_order',
            $_G['uid'],
            $order_id
        ));

        if ($order['is_paid'] == 2) {

            ajaxReturn(1, $language_zimu['personalservice_inc_php_14'], ZIMUCMS_URL . '&model=personalservice&ac=order_detail&order_id=' . $order_id);

        } else {

            ajaxReturn(0, $language_zimu['personalservice_inc_php_15']);

        }

    } elseif ($ac == 'order_list') {

        $type         = I('type', '', 'trim');
        $function_arr = array(
            'setmeal',
            'increment',
            'points'
        );

        switch ($type) {
            case 'setmeal':
                $wherearr[] = ' order_type = 1';
                break;
            case 'increment':
                $wherearr[] = ' (order_type = 6 or order_type = 7 or order_type = 8 or order_type = 9 or order_type = 10 or order_type = 11 or order_type = 12 or order_type = 13 or order_type = 14 )';
                break;
        }
        $is_paid = I('is_paid', 0, 'intval');
        if ($is_paid > 0) {
            $wherearr[] = ' is_paid = ' . $is_paid;
        }

        $wherearr[] = ' uid = ' . $_G['uid'];

        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE ' . implode(' AND ', $wherearr) : '';


        $order = DB::fetch_all('select * from %t %i order by id desc', array(
            'zimu_zhaopin_order',
            $wheresql
        ));

    } elseif ($ac == 'order_pay_repeat') {

        $order_id = intval($_GET['order_id']);

        $order = DB::fetch_first('select * from %t where uid=%d and id=%d order by id desc', array(
            'zimu_zhaopin_order',
            $_G['uid'],
            $order_id
        ));

        $subject = $order['description'];
        $body    = diconv(cutstr(strip_tags($subject), 20), CHARSET, 'UTF-8');

        $tools  = new JsApiPaySF();
        $notify = new NativePaySF();
        $input  = new WxPayUnifiedOrderSF();
        $input->SetBody($body);
        $input->SetAttach($body);
        $input->SetOut_trade_no($order['oid']);
        $input->SetTotal_fee($order['amount'] * 100);
        $input->SetTime_start(date('YmdHis'));
        $input->SetGoods_tag($body);
        $pburl = $_G['siteurl'];
        $input->SetNotify_url($pburl . 'source/plugin/zimu_zhaopin/lib/notify_wx.php');
        $input->SetTrade_type('NATIVE');

        $input->SetProduct_id($order['oid']);
        $result = $notify->GetPayUrl($input);
        $url2   = $result['code_url'];
        if (!$url2) {
            $msg = diconv($result['return_msg'], 'utf-8');
            ajaxReturn(0, $msg);
            exit();

        } else {
            $data['qrurl']    = ZIMUCMS_URL.'&model=toqrcode&url=' . urlencode($url2);
            $data['order_id'] = $order_id;
            ajaxReturn(1, $language_zimu['personalservice_inc_php_16'], $data);
            exit();

        }
    } elseif ($ac == 'view_jobs_mobile') {

        $jid = intval($_GET['jid']);
        $params['oid']             = date('YmdHis') . mt_rand(100000, 999999);
        $params['zpid']            = $jid;
        $params['uid']             = $_G['uid'];
        $params['openid']          = $openid;
        $params['utype']           = 2;
        $params['order_type']      = 3;
        $params['pay_type']        = 2;
        $params['is_paid']         = 1;
        $params['amount']          = $zmdata['settings']['view_jobs_mobile'];
        $params['pay_amount']      = $zmdata['settings']['view_jobs_mobile'];
        $params['payment']         = $_GET['payment_name'] == 'remittance' ? 'remittance' : 'wxpay';
        $params['payment_cn']      = $_GET['payment_name'] == 'remittance' ? $language_zimu['personalservice_inc_php_17'] : $language_zimu['personalservice_inc_php_18'];
        $params['description']     = $language_zimu['personalservice_inc_php_19'];
        $params['service_name']    = 'view_jobs_mobile';
        $params_array['jid'] = $jid;
        $params['params']          = serialize($params_array);
        $params['addtime']         = $_G['timestamp'];
        $params['referer'] = addslashes($_GET['referer']);

        $return_order_info = DB::insert('zimu_zhaopin_order', $params, 1);

        if (checkmobile()) {

            dheader('Location:' . ZIMUCMS_URL . '&model=personalservice&ac=order_detail&order_id=' . $return_order_info);
            exit();
        }



    } elseif ($ac == 'order_detail') {

        $order_id = intval($_GET['order_id']);

        $order           = DB::fetch_first('select * from %t where uid=%d and id=%d order by id desc', array(
            'zimu_zhaopin_order',
            $_G['uid'],
            $order_id
        ));
        $order['params'] = $order['params'] ? unserialize($order['params']) : array();

        $rl = $order['referer'] ? $order['referer'] : dreferer();

        if (IN_MAGAPP) {

            $mag_paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
                'zimu_zhaopin_parameter2',
                'magapp'
            ));
            $mag_paramter = unserialize($mag_paramter['parameter']);

        }

        if (IN_QFAPP) {

            $qf_paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
                'zimu_zhaopin_parameter2',
                'qfapp'
            ));
            $qf_paramter = unserialize($qf_paramter['parameter']);

        }

        if($order['pay_amount'] && $zmdata['settings']['money_appcode'] && $zmdata['settings']['money_currency']){
            $tomoney = get_money_currency($zmdata['settings']['money_appcode'],$order['pay_amount'],$zmdata['settings']['money_currency']);
            $tomoney = json_decode($tomoney,true);
            if($tomoney['msg']=='ok' && $tomoney['result']['rate']){
                $order['money_currency'] = $zmdata['settings']['money_currency'];
                $order['money_name'] = $zmdata['settings']['money_name'];
                $order['money_rate'] = $tomoney['result']['rate'];
                $order['money_updatetime'] = $tomoney['result']['updatetime'];
                $order['pay_amount'] = round($tomoney['result']['camount'],2);
            }
        }

    }

    include zimu_template('personalservice_' . $ac);