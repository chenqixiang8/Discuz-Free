<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(!$_G['uid']){

if(!$zmdata['settings']['weixin_login_url']){

isuid();
exit();

}else{

dheader('Location:' . $_G['siteurl'] . 'plugin.php?id=zimu_zhaopin&model=login&referer=' . urlencode(ZIMUCMS_URL.'&model=admins'));
exit();

}

}

$type = addslashes($_GET['type']);
$type = !empty($type) ? $type : 'dashboard';

$ac = addslashes($_GET['ac']);
$ac = !empty($ac) ? $ac : 'index';

$manage_groups = explode(';', $zmdata['manage_uids']);

foreach ($manage_groups as $key => $value) {
  $manage_uids[$key] = explode(',', $value);
}

    $iskefu = DB::fetch_first('select * from %t where uid=%d', array(
        'zimu_zhaopin_kefu',
        $_G['uid']
    ));

if(!in_array($_G['uid'],$manage_uids[0]) && !in_array($_G['uid'],$manage_uids[1]) && !$iskefu){
echo 'error';exit();
}

if(in_array($_G['uid'],$manage_uids[0])){
$manage_type = 'admins';
}elseif(in_array($_G['uid'],$manage_uids[1])){
$manage_type = 'operator';
}
$wherekefu = '';
if(!$manage_type && $iskefu){
    $manage_type = 'kefu';
    $kefu_mycompany = DB::fetch_all('select * from %t where kefu_uid=%d', array(
        'zimu_zhaopin_company_profile',
        $_G['uid']
    ),'uid');
    $kefu_myresume = DB::fetch_all('select * from %t where kefu_uid=%d', array(
        'zimu_zhaopin_resume',
        $_G['uid']
    ),'uid');

    $kefu_mycompany_uid = array_keys($kefu_mycompany);
    $kefu_myresume_uid = array_keys($kefu_myresume);
    $kefu_all_uid = array_merge($kefu_mycompany_uid,$kefu_myresume_uid);
    $kefu_all_uid = array_unique($kefu_all_uid);
    $kefu_all_uid = implode(',',$kefu_all_uid);
    $kefu_mycompany_uid = implode(',',$kefu_mycompany_uid);
    $kefu_myresume_uid = implode(',',$kefu_myresume_uid);
    if(!$kefu_mycompany_uid){
        $kefu_mycompany_uid = 0;
    }
    if(!$kefu_myresume_uid){
        $kefu_myresume_uid = 0;
    }
    if(!$kefu_all_uid){
        $kefu_all_uid = 0;
    }
    $wherekefu = ' and uid IN ('.$kefu_mycompany_uid.') ';
    $wherekefu2 = ' and uid IN ('.$kefu_myresume_uid.') ';
    $wherekefu3 = ' and uid IN ('.$kefu_all_uid.') ';

}

$title = $zmdata['base']['title'].$language_zimu['admins_inc_php_0'];

if($type){
    include DISCUZ_ROOT.'./source/plugin/zimu_zhaopin/module/admins/admins_'.$type.'.inc.php';
}