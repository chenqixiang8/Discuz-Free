<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

    $paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
        'zimu_zhaopin_parameter2',
        'zpreport'
    ));
    $paramters = unserialize($paramter['parameter']);

    $ids = intval($_GET['ids']);

    if($ids=='88888'){
        isuid();

        $companydata = DB::fetch_first('select * from %t where uid=%d order by id asc', array(
            'zimu_zhaopin_company_profile',
            $_G['uid']
        ));

        $ids = $companydata['id'];
    }

    if($ids){

    $companydata = DB::fetch_first('select * from %t where id=%d order by id asc', array(
        'zimu_zhaopin_company_profile',
        $ids
    ));

    $companydata['allnums'] = DB::result_first("SELECT count(*) FROM %t where company_id=%d", array(
        "zimu_zhaopin_jobs",
        $ids
    ));

    $companydata['downnums'] = DB::result_first("SELECT count(*) FROM %t where company_uid=%d", array(
        "zimu_zhaopin_company_down_resume",
        $companydata['uid']
    ));

    $companydata['applynums'] = DB::result_first("SELECT count(*) FROM %t where company_uid=%d", array(
        "zimu_zhaopin_personal_jobs_apply",
        $companydata['uid']
    ));

    $alljob = DB::fetch_all('select * from %t where company_id=%d order by addtime asc', array(
        'zimu_zhaopin_jobs',
        $ids
    ));

    $all_mymatching = array();
    foreach ($alljob as $key => $value) {
        $companydata['allclick'] = $companydata['allclick'] + $value['click'];

        $where_mathcing = 'where 1=1 ';
        if($value['sex']){
            $where_mathcing .= " and `sex` = '{$value['sex']}' ";
        }
        if($value['experience']){
            $where_mathcing .= " and `experience` >= '{$value['experience']}' ";
        }
        if($value['education']){
            $where_mathcing .= " and `education` >= '{$value['education']}' ";
        }
        if($value['topclass']){
            $where_mathcing .= " and `intention_jobs_id` LIKE '%{$value['topclass']}.%' ";
        }
        $mymatching2 = DB::fetch_all("SELECT uid FROM %t %i", array(
            "zimu_zhaopin_resume",
            $where_mathcing
        ),'uid');
        $all_mymatching = $all_mymatching + $mymatching2;
    }

    $companydata['matching'] = count($all_mymatching);

    $companyjob = $alljob[0];

    $downresume = DB::fetch_first('select * from %t where company_uid=%d order by did asc', array(
        'zimu_zhaopin_company_down_resume',
        $companydata['uid']
    ));

    if($downresume['resume_id']){
        $downresume2 = DB::fetch_first('select * from %t where id=%d order by id asc', array(
            'zimu_zhaopin_resume',
            $downresume['resume_id']
        ));
    }

    $applyresume = DB::fetch_first('select * from %t where company_uid=%d order by did asc', array(
        'zimu_zhaopin_personal_jobs_apply',
        $companydata['uid']
    ));
    if($applyresume['resume_id']){
        $applyresume2 = DB::fetch_first('select * from %t where id=%d order by id asc', array(
            'zimu_zhaopin_resume',
            $applyresume['resume_id']
        ));
    }
    }


    $share_title = preg_replace(array(
        '/companyname/'
    ), array(
        $companydata['companyname'] ? $companydata['companyname'] : $zmdata['base']['title']
    ), $paramters['share_title']);

    $share_desc = preg_replace(array(
        '/companyname/'
    ), array(
        $companydata['companyname'] ? $companydata['companyname'] : $zmdata['base']['title']
    ), $paramters['share_desc']);
    $share_thumb = $paramters['shareimg_url'];

    require_once DISCUZ_ROOT . './source/plugin/zimu_zhaopin/class/wechat.lib.class.php';
    $wechat_client = new WeChatClient($zmdata['base']['weixin_appid'], $zmdata['base']['weixin_appsecret']);
    $jssdkvalue    = $wechat_client->getSignPackage($url);


    include zimu_template('zpreport');

