<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

isuid();

$ac       = addslashes($_GET['ac']);
$ac = !empty($ac) ? $ac : 'index';
$tosubmit = intval($_GET['tosubmit']);

if($ac=='refresh_resume'){

            $pid = I('pid',0,'intval');
            !$pid && ajaxReturn(0,$language_zimu['personal_inc_php_0']);
            $uid = $_G['uid'];
            $r = DB::fetch_first('select * from %t where uid=%d and id=%d order by id desc', array(
                    'zimu_zhaopin_resume',
                    $uid,
                    $pid
                ));
            !$r && ajaxReturn(0,$language_zimu['personal_inc_php_1']);
            $r['audit'] != 1 && ajaxReturn(0,$language_zimu['personal_inc_php_2']);
            $r['display'] != 1 && ajaxReturn(0,$language_zimu['personal_inc_php_3']);

        $refrestime = DB::result_first("SELECT count(*) FROM %t where uid=%d and type=%d and addtime>%d", array(
            "zimu_zhaopin_refresh_log",
            $_G['uid'],
            2001,
            strtotime(date('Y-m-d', $_G['timestamp']))
        ));

            if($zmdata['settings']['per_refresh_resume_time'] != 0 && ( $refrestime >= $zmdata['settings']['per_refresh_resume_time'] ) ){
                ajaxReturn(0,$language_zimu['personal_inc_php_4'].$zmdata['settings']['per_refresh_resume_time'].$language_zimu['personal_inc_php_5']);
            }else{

        $setsqlarr['refreshtime'] = $_G['timestamp'];
        DB::update('zimu_zhaopin_resume', $setsqlarr, array(
            'id' => $pid,
            'uid' => $_G['uid']
        ));

        $setsqlarr2['uid'] = $_G['uid'];
        $setsqlarr2['mode'] = 0;
        $setsqlarr2['addtime'] = $_G['timestamp'];
        $setsqlarr2['type'] = 2001;

        DB::insert('zimu_zhaopin_refresh_log', $setsqlarr2, 1);

        ajaxReturn(1,$language_zimu['personal_inc_php_6']);

                $this->ajaxReturn(1,$language_zimu['personal_inc_php_7'],$r['data']);
            }

}elseif($ac=='jobs_favorites'){

$favorites['list'] = DB::fetch_all('select * from %t where personal_uid=%d order by did desc', array(
        'zimu_zhaopin_personal_favorites',
        $_G['uid']
    ));

}elseif($ac=='attention_com'){

$company['list'] = DB::fetch_all('select * from %t where uid=%d order by id desc', array(
        'zimu_zhaopin_personal_focus_company',
        $_G['uid']
    ));

}elseif($ac=='set_privacy'){

    $pid = I('pid',0,'intval');
    $display = I('display',0,'intval');

    DB::query("update %t set display=%d where id=%d and uid=%d", array(
        'zimu_zhaopin_resume',
        $display,
        $pid,
        $_G['uid']
    ));

    ajaxReturn(1,$language_zimu['personal_inc_php_8']);

}elseif($ac=='del_work'){

        $pid = I('pid',0,'intval');
        if(!$pid) ajaxReturn(0,$language_zimu['personal_inc_php_9']);

    $result = DB::delete('zimu_zhaopin_resume_work', array(
        'id' => $pid,
        'uid' => $_G['uid'],
    ));

ajaxReturn(1,$language_zimu['personal_inc_php_10']);

}elseif($ac=='del_education'){

        $pid = I('pid',0,'intval');
        if(!$pid) ajaxReturn(0,$language_zimu['personal_inc_php_11']);

    $result = DB::delete('zimu_zhaopin_resume_education', array(
        'id' => $pid,
        'uid' => $_G['uid'],
    ));

ajaxReturn(1,$language_zimu['personal_inc_php_12']);


}elseif($ac=='jobs_interview'){

        $resume_info = DB::fetch_first('select * from %t where uid=%d order by id asc', array(
                'zimu_zhaopin_resume',
                $_G['uid']
            ));


        $settr=I('settr',0,'intval');
        $settr && $where[] = 'apply_addtime > '.strtotime("-".$settr." day");

        $lookArr = array(1=>$language_zimu['personal_inc_php_13'],2=>$language_zimu['personal_inc_php_14']);
        $look=I('look',0,'intval');

        switch ($feedback) 
        {
            case 1:
                $where[] = 'personal_look = 1';
                break;
            case 2:
                $where[] = 'personal_look = 2';
                $where[]='is_reply = 0';
                break;
            default:
                break;
        }

$where[] = 'resume_uid = '.$_G['uid'];

$wheresql = !empty($where) && is_array($where) ? ' WHERE '.implode(' AND ', $where) : '';


$apply_list = DB::fetch_all('select * from %t %i order by id desc', array(
        'zimu_zhaopin_company_interview',
        $wheresql
    ));

foreach ($apply_list as $key => $value) {

$apply_list[$key]['job'] = DB::fetch_first('select * from %t where id=%d order by id asc', array(
        'zimu_zhaopin_jobs',
        $value['jobs_id']
    ));

}

}elseif($ac=='jobs_interview_del'){

        $y_id = I('y_id',0,'intval');
        if(!$y_id) ajaxReturn(0,$language_zimu['personal_inc_php_15']);

    $result = DB::delete('zimu_zhaopin_company_interview', array(
        'id' => $y_id,
        'resume_uid' => $_G['uid'],
    ));

ajaxReturn(1,$language_zimu['personal_inc_php_16']);

}elseif($ac=='jobs_apply'){

$resume_info = DB::fetch_first('select * from %t where uid=%d order by id asc', array(
        'zimu_zhaopin_resume',
        $_G['uid']
    ));


        $settr=I('settr',0,'intval');
        $settr && $where[] = 'apply_addtime > '.strtotime("-".$settr." day");

        $feedbackArr = array(2=>$language_zimu['personal_inc_php_17'],3=>$language_zimu['personal_inc_php_18'],4=>$language_zimu['personal_inc_php_19'],5=>$language_zimu['personal_inc_php_20'],6=>$language_zimu['personal_inc_php_21']);
        $feedback=I('feedback',0,'intval');

        switch ($feedback) 
        {
            case 1:
                $where[] = 'personal_look = 1';
                break;
            case 2:
                $where[] = 'personal_look = 2';
                $where[]='is_reply = 0';
                break;
            case 3:
                $where[] = 'personal_look = 2';
                $where[]='is_reply = 1';
                break;
            case 4:
                $where[] = 'personal_look = 2';
                $where[]='is_reply = 2';
                break;
            case 5:
                $where[] = 'personal_look = 2';
                $where[]='is_reply = 3';
                break;
            case 6:
                $where[] = 'personal_look = 2';
                $where[]='is_reply = 4';
                break;
            default:
                break;
        }

$where[] = 'personal_uid = '.$_G['uid'];

$wheresql = !empty($where) && is_array($where) ? ' WHERE '.implode(' AND ', $where) : '';


$apply_list = DB::fetch_all('select * from %t %i order by did desc', array(
        'zimu_zhaopin_personal_jobs_apply',
        $wheresql
    ));

foreach ($apply_list as $key => $value) {

$apply_list[$key]['job'] = DB::fetch_first('select * from %t where id=%d order by id asc', array(
        'zimu_zhaopin_jobs',
        $value['jobs_id']
    ));

}

}elseif($ac=='jobs_apply_del'){

        $y_id = I('y_id',0,'intval');
        if(!$y_id) ajaxReturn(0,$language_zimu['personal_inc_php_22']);

    $result = DB::delete('zimu_zhaopin_personal_jobs_apply', array(
        'did' => $y_id,
        'personal_uid' => $_G['uid'],
    ));

ajaxReturn(1,$language_zimu['personal_inc_php_23']);

}elseif($ac=='attention_me'){


$resume_info = DB::fetch_first('select * from %t where uid=%d order by id asc', array(
        'zimu_zhaopin_resume',
        $_G['uid']
    ));

if(!$resume_info){$resume_info['id']=0;}

        $where[]= 'resumeid = '.$resume_info['id']; //ɸѡ����

        $hasdown = I('hasdown',0,'intval');
        if($hasdown){
            if($hasdown==2){
           $where[] = 'hasdown = 0';
            }else{
           $where[] = 'hasdown = '.$hasdown;
            }
        }

        $settr=I('settr',0,'intval');
        $settr && $where[] = 'addtime > '.strtotime("-".$settr." day");

$wheresql = !empty($where) && is_array($where) ? ' WHERE '.implode(' AND ', $where) : '';

$view_list['list'] = DB::fetch_all('select * from %t %i order by id desc', array(
        'zimu_zhaopin_view_resume',
        $wheresql
    ));

}elseif($ac=='attention_me_del'){

        $y_id = I('y_id',0,'intval');
        if(!$y_id) ajaxReturn(0,$language_zimu['personal_inc_php_25']);

    $result = DB::delete('zimu_zhaopin_view_resume', array(
        'id' => $y_id,
        'uid' => $_G['uid'],
    ));

ajaxReturn(1,$language_zimu['personal_inc_php_26']);

}elseif($ac=='viewlog' ){

$favorites['list'] = DB::fetch_all('select * from %t where uid=%d order by addtime desc', array(
        'zimu_zhaopin_per_viewlog',
        $_G['uid']
    ));

}elseif($ac=='report_jobs' ){

        $jobs_id = I('jobs_id',0,'intval');
        if(!$jobs_id){
            ajaxReturn(0,$language_zimu['personal_inc_php_27']);
        }
        if($tosubmit == 1){

            $report_type = I('report_type',1,'intval');
            $content = I('content','','trim');
            !$content && ajaxReturn(0,$language_zimu['personal_inc_php_28']);
            $telephone = I('telephone','','trim');
            !$telephone && ajaxReturn(0,$language_zimu['personal_inc_php_29']);
            $data['uid'] = $_G['uid'];
            $data['username'] = $_G['username'];
            $data['jobs_id'] = $jobs_id;
            $data['report_type'] = $report_type;
            $data['telephone'] = $telephone;
            $data['content'] = $content;
            $data['addtime'] = $_G['timestamp'];
            DB::insert('zimu_zhaopin_report', $data, 1);
            ajaxReturn(1,$language_zimu['personal_inc_php_30']);

        }else{

$myphone = DB::result_first("SELECT telephone FROM %t where uid=%d", array(
    "zimu_zhaopin_members",
    $_G['uid']
));

        }


}elseif($ac=='index' ){

    DB::query("update %t set utype=2 where uid=%d", array(
        'zimu_zhaopin_members',
        $_G['uid'],
    ));
    
$category_jobs = DB::fetch_all('select * from %t order by c_order asc,c_id asc', array(
        'zimu_zhaopin_category'
    ));

foreach ($category_jobs as $key => $value) {

$category_jobs2[$value['c_alias']][$value['c_id']] = $value['c_name'];

}

$resume = DB::fetch_first('select * from %t where uid=%d order by id desc', array(
        'zimu_zhaopin_resume',
        $_G['uid']
    ));
            $resume['work'] = DB::fetch_all('select * from %t where uid=%d and pid=%d order by id asc', array(
                'zimu_zhaopin_resume_work',
                $_G['uid'],
                $resume['id']
            ));

            $resume['educationlist'] = DB::fetch_all('select * from %t where uid=%d and pid=%d order by id asc', array(
                'zimu_zhaopin_resume_education',
                $_G['uid'],
                $resume['id']
            ));

}elseif($ac=='edit_work' ){

$wid = intval($_GET['wid']);

$work = DB::fetch_first('select * from %t where uid=%d and id=%d order by id asc', array(
        'zimu_zhaopin_resume_work',
        $_G['uid'],
        $wid
    ));

ajaxReturn(1,'ok',$work);

}elseif($ac=='edit_education' ){

$eid = intval($_GET['eid']);

$education = DB::fetch_first('select * from %t where uid=%d and id=%d order by id asc', array(
        'zimu_zhaopin_resume_education',
        $_G['uid'],
        $eid
    ));

ajaxReturn(1,'ok',$education);

}

include zimu_template('personal_' . $ac);