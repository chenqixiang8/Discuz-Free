<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

isuid();

if ($_G['uid']) {

$sms_paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
    'zimu_zhaopin_parameter2',
    'aliyunsms'
));
$sms_paramter = unserialize($sms_paramter['parameter']);

if($sms_paramter['appsms']==1){
    $appmobile = DB::result_first('select phone from %t where userid=%d order by id desc', array(
        'user_mobile_relations',
        $_G['uid']
    ));
    $setsqlarr_creatmember['telephone'] = $appmobile;
}elseif($sms_paramter['appsms']==2){
    $appmobile = DB::result_first('select phone from %t where uid=%d order by dateline desc', array(
        'phonebind',
        $_G['uid']
    ));
    $setsqlarr_creatmember['telephone'] = $appmobile;
}


    $utype = DB::result_first('select utype from %t where uid=%d order by id desc', array(
        'zimu_zhaopin_members',
        $_G['uid']
    ));
    if (!$utype) {

        $setsqlarr_creatmember['uid'] = $_G['uid'];
        $utype            = $setsqlarr_creatmember['utype'] = 2;
        DB::insert('zimu_zhaopin_members', $setsqlarr_creatmember, 1);

    }else{

if($setsqlarr_creatmember['telephone']){

    DB::query("update %t set telephone=%s where uid=%d", array(
        'zimu_zhaopin_members',
        $setsqlarr_creatmember['telephone'],
        $_G['uid']
    ));
}

    }
}