<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$tosubmit = intval($_GET['tosubmit']);
$wid = intval($_GET['wid']);


$category = array();

$categoryData = DB::fetch_all('select c_id,c_alias,c_name from %t order by c_order asc,c_id asc', array(
    'zimu_zhaopin_category'
));

foreach ($categoryData as $key=>$val){
    $category[$val['c_alias']][$val['c_id']] = $val['c_name'];
}

$educationlist = $category['ZM_education'];


if($tosubmit == 1){

$pid = intval($_GET['pid']);

            $uid = $_G['uid'];

            $setsqlarr['uid'] = $uid;
            $setsqlarr['school'] = zm_diconv(I('school','','trim'));
            $setsqlarr['speciality'] = zm_diconv(I('speciality','','trim'));
            $setsqlarr['education'] = I('education',0,'intval');
            $setsqlarr['startyear'] = I('startyear',0,'intval');
            $setsqlarr['startmonth'] = I('startmonth',0,'intval');
            $setsqlarr['endyear'] = I('endyear',0,'intval');
            $setsqlarr['endmonth'] = I('endmonth',0,'intval');
            $setsqlarr['todate'] = I('todate',0,'intval');

            if ($setsqlarr['todate'] == 1) {
                if(!$setsqlarr['startyear'] || !$setsqlarr['startmonth']) ajaxReturn(0,$language_zimu['resume_edit_edu_inc_php_0']);
                if($setsqlarr['startyear'] > intval(date('Y'))) ajaxReturn(0,$language_zimu['resume_edit_edu_inc_php_1']);
                if($setsqlarr['startyear'] == intval(date('Y')) && $setsqlarr['startmonth'] >= intval(date('m'))) ajaxReturn(0,$language_zimu['resume_edit_edu_inc_php_2']);
            } else {
                if(!$setsqlarr['startyear'] || !$setsqlarr['startmonth'] || !$setsqlarr['endyear'] || !$setsqlarr['endmonth']) ajaxReturn(0,$language_zimu['resume_edit_edu_inc_php_3']);

                if($setsqlarr['startyear'] > intval(date('Y'))) ajaxReturn(0,$language_zimu['resume_edit_edu_inc_php_4']);
                if($setsqlarr['startyear'] == intval(date('Y')) && $setsqlarr['startmonth'] >= intval(date('m'))) ajaxReturn(0,$language_zimu['resume_edit_edu_inc_php_5']);

                if($setsqlarr['startyear'] > $setsqlarr['endyear']) ajaxReturn(0,$language_zimu['resume_edit_edu_inc_php_6']);
                if($setsqlarr['startyear'] == $setsqlarr['endyear'] && $setsqlarr['startmonth'] >= $setsqlarr['endmonth']) ajaxReturn(0,$language_zimu['resume_edit_edu_inc_php_7']);
            }

            $setsqlarr['education_cn'] = $educationlist[$setsqlarr['education']];

            if(!$pid) ajaxReturn(0,$language_zimu['resume_edit_edu_inc_php_8']);
            $setsqlarr['pid'] = $pid;
            $education = DB::fetch_all('select * from %t where uid=%d and pid=%d order by id asc', array(
                'zimu_zhaopin_resume_education',
                $_G['uid'],
                $pid
            ));
            if (count($education)>=6) ajaxReturn(0,$language_zimu['resume_edit_edu_inc_php_9']);
            if($wid){
                $setsqlarr['id'] = $wid;

            $result = DB::update('zimu_zhaopin_resume_education', $setsqlarr, array(
                'id' => $wid,
                'uid' => $uid,
                'pid' => $pid,
            ));

            ajaxReturn(1,$language_zimu['resume_edit_edu_inc_php_10'],array('url'=>ZIMUCMS_URL.'&model=resume_replenish_edu&rid='.$pid));
            exit();

            }else{

            $result = DB::insert('zimu_zhaopin_resume_education', $setsqlarr, 1);

            $news = intval($_GET['news']);
            if($news==1){

            $html = '<div class="expmod " type="education"><div class="exptr1 substring">'.$setsqlarr['school'].'<span class="font13">'.$setsqlarr['education_cn'].'</span></div><div class="exptr2 substring font13">'.$setsqlarr['startyear'].'-'.$setsqlarr['startmonth'].' '.$language_zimu['resume_edit_edu_inc_php_11'].' '.$setsqlarr['endyear'].'-'.$setsqlarr['endmonth'].'&nbsp;|&nbsp;'.$setsqlarr['speciality'].'</div></div>';

            ajaxReturn(1,$language_zimu['resume_edit_edu_inc_php_12'],array('url'=>ZIMUCMS_URL.'&model=resume_guidance&rid='.$pid,'html'=>$html));

            }else{

            ajaxReturn(1,$language_zimu['resume_edit_edu_inc_php_13'],array('url'=>ZIMUCMS_URL.'&model=resume_replenish_edu&rid='.$pid));

            }
            exit();

            }


}else{

$pid = intval($_GET['rid']);

$info = DB::fetch_first('select * from %t where uid=%d and id=%d and pid=%d order by id asc', array(
        'zimu_zhaopin_resume_education',
        $_G['uid'],
        $wid,
        $pid
    ));

include zimu_template('resume_edit_edu');

}