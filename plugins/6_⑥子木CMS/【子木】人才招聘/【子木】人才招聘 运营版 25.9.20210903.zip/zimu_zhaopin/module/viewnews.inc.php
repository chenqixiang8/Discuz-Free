<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}


$nid = intval($_GET['nid']);

    if(checkmobile() && $zmdata['settings']['open_newwap']==1){
        dheader('Location:' . $_G['siteurl'] . 'source/plugin/zimu_zhaopin/h5/pages/news/view?ids='.$nid.'&mobile=2');
        exit();
    }

$catdata = DB::fetch_all('select * from %t order by id asc', array(
	'zimu_zhaopin_news_cat'
));

$newsdata = DB::fetch_first('select * from %t where id=%d order by id desc', array(
    'zimu_zhaopin_news',
    $nid
));


DB::query("update %t set views=views+1 where id=%d", array(
    'zimu_zhaopin_news',
    $nid
));

    $total = DB::result_first("SELECT count(*) FROM %t", array(
        "zimu_zhaopin_news"
    ));

    $rand=array();
    $rand_nums = $total > 20 ? 20 : $total;
    while(count($arr) < $rand_nums){
        $arr[]=rand(1,$total);
        $arr=array_unique($arr);
    }
    $rand_ids = implode(",",$arr);

    $randnews = DB::fetch_all('select * from %t where id in (%n)', array(
        'zimu_zhaopin_news',
        $arr
    ));

$navtitle = $share_title = $newsdata['title'] ? $newsdata['title'].' - '.$zmdata['base']['title'] : $navtitle;
$keywords = $newsdata['keyword'] ? $newsdata['keyword'] : $navtitle;
$description = $share_desc = $newsdata['description'] ? $newsdata['description'] : $navtitle;


include zimu_template('news_con');