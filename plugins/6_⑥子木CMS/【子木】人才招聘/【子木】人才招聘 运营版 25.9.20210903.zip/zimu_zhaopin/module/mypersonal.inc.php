<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

isuid();

require_once DISCUZ_ROOT . './source/plugin/zimu_zhaopin/module/creatmember.inc.php';

    $category_jobs = DB::fetch_all('select * from %t order by c_order asc,c_id asc', array(
        'zimu_zhaopin_category'
    ));

    foreach ($category_jobs as $key => $value) {

        $category_jobs2[$value['c_alias']][$value['c_id']] = $value['c_name'];

    }

$paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
    'zimu_zhaopin_parameter2',
    'indexad'
));

$paramters_indexad = unserialize($paramter['parameter']);

$resume_info = DB::fetch_first('select * from %t where uid=%d order by id asc', array(
        'zimu_zhaopin_resume',
        $_G['uid']
    ));

$resume_info['countapply'] = DB::result_first("SELECT count(*) FROM %t where personal_uid=%d", array(
    "zimu_zhaopin_personal_jobs_apply",
    $_G['uid']
));

$resume_info['count_favorite_focus'] = DB::result_first("SELECT count(*) FROM %t where personal_uid=%d", array(
    "zimu_zhaopin_personal_jobs_apply",
    $_G['uid']
));

$resume_info['count_view_resume'] = DB::result_first("SELECT count(*) FROM %t where resumeid=%d", array(
    "zimu_zhaopin_view_resume",
    $resume_info['id']
));

$resume_info['count_viewlog'] = DB::result_first("SELECT count(*) FROM %t where uid=%d", array(
    "zimu_zhaopin_per_viewlog",
    $_G['uid']
));

$resume_info['count_jobs_interview'] = DB::result_first("SELECT count(*) FROM %t where resume_uid=%d", array(
    "zimu_zhaopin_company_interview",
    $_G['uid']
));

$is_hide_share_text = DB::result_first("SELECT id FROM %t where uid=%d and audit=1", array(
    "zimu_zhaopin_resume",
    $_G['uid']
));

$utype = 2;

if($resume_info){
    $resume_info['complete_percent'] = check_complete_percent($_G['uid']);
    DB::query("update %t set complete_percent=%d where uid=%d", array(
        'zimu_zhaopin_resume',
        $resume_info['complete_percent'],
        $_G['uid'],
    ));
}

    DB::query("update %t set utype=2 where uid=%d", array(
        'zimu_zhaopin_members',
        $_G['uid'],
    ));

    if(checkmobile() && $zmdata['settings']['open_newwap']==1){
        dheader('Location:' . $_G['siteurl'] . 'source/plugin/zimu_zhaopin/h5/pages/index/my');
        exit();
    }

include zimu_template('mypersonal');