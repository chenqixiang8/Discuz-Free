<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if (!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }

    $ids = intval($_GET['ids']);
    $qrsize = 5;
    $dir = DISCUZ_ROOT.'/source/plugin/zimu_zhaopin/uploadzimucms/';
    $qrcode_file = $dir.'qrcode/company_'.$ids.'.jpg';
    $qrcode_url = ZIMUCMS_URL.'&model=viewcom&cid='.$ids;

    if(!file_exists(DISCUZ_ROOT . 'source/plugin/zimu_zhaopin/static/font/Alibaba-PuHuiTi-Heavy.ttf') || !file_exists(DISCUZ_ROOT . 'source/plugin/zimu_zhaopin/static/font/Alibaba-PuHuiTi-Regular.ttf')){

        ajaxReturn(0,$language_zimu['poster_com_inc_php_0']);

    }

    if(!file_exists($qrcode_file) || !filesize($qrcode_file) || filemtime($qrcode_file) < time()-86400 ) {

        if ($zmdata['settings']['wx_create_qrcode'] == 1) {
            require_once DISCUZ_ROOT . './source/plugin/zimu_zhaopin/class/wechat.lib.class.php';
            $wechat_client = new WeChatClient($zmdata['base']['weixin_appid'], $zmdata['base']['weixin_appsecret']);
            $qrcode_url2 = $wechat_client->getQrcodeImgUrlByTicket($wechat_client->getQrcodeTicket(array(
                'scene_str' =>  'viewcomzimuyun' . $ids,
                'expire' => 2591000
            )));
            $qrcode_img = dfsockopen($qrcode_url2);
            $qrcode_img = $qrcode_img ? $qrcode_img : file_get_contents($qrcode_url2);
            $fp = fopen($qrcode_file, 'wb');
            flock($fp, 2);
            fwrite($fp,$qrcode_img);
            fclose($fp);

        }else{
            require_once DISCUZ_ROOT.'source/plugin/zimu_zhaopin/class/qrcode.class.php';
            QRcode::png($qrcode_url, $qrcode_file, QR_ECLEVEL_L, $qrsize);
        }
    }

    $myinfo = DB::fetch_first('select * from %t where id=%d order by id asc', array(
        'zimu_zhaopin_company_profile',
        $ids
    ));

    $myinfo['qrcode_url'] = $_G['siteurl'].'source/plugin/zimu_zhaopin/uploadzimucms/qrcode/company_'.$ids.'.jpg';

    $myinfo['jobs'] = DB::fetch_all('select * from %t where company_id=%d '.$noauditwheresql2.' and display!=2 order by id asc limit 6', array(
        'zimu_zhaopin_jobs',
        $ids
    ));


    $config = array(
        'image' => array(
            array(
                'url' => $myinfo['qrcode_url'],
                'is_yuan' => false,
                'stream' => 0,
                'left' => 500,
                'top' => 1650,
                'right' => 0,
                'width' => 400,
                'height' => 400,
                'opacity' => 100
            ),
        ),
        'text' => array(
            array(
                'text' => $myinfo['companyname'],
                'left' => -3,
                'top' => 650,
                'fontSize' => 56,
                'fontColor' => '51,51,51',
                'angle' => 0,
                'fontPath' => DISCUZ_ROOT . 'source/plugin/zimu_zhaopin/static/font/Alibaba-PuHuiTi-Heavy.ttf',
            ),
            array(
                'text' => $myinfo['trade_cn'].' | '.$myinfo['scale_cn'],
                'left' => -3,
                'top' => 750,
                'fontSize' => 32,
                'fontColor' => '153,153,153',
                'angle' => 0,
                'fontPath' => DISCUZ_ROOT . 'source/plugin/zimu_zhaopin/static/font/Alibaba-PuHuiTi-Regular.ttf',
            ),
            array(
                'text' => $myinfo['jobs'][0]['jobs_name'],
                'left' => 150,
                'top' => 1040,
                'fontSize' => 34,
                'fontColor' => '51,51,51',
                'angle' => 0,
                'fontPath' => DISCUZ_ROOT . 'source/plugin/zimu_zhaopin/static/font/Alibaba-PuHuiTi-Regular.ttf',
            ),
            array(
                'text' => $myinfo['jobs'][0]['wage_cn'],
                'left' => 940,
                'top' => 1040,
                'fontSize' => 34,
                'fontColor' => '51,51,51',
                'angle' => 0,
                'fontPath' => DISCUZ_ROOT . 'source/plugin/zimu_zhaopin/static/font/Alibaba-PuHuiTi-Regular.ttf',
            ),
            array(
                'text' => $myinfo['jobs'][1]['jobs_name'],
                'left' => 150,
                'top' => 1140,
                'fontSize' => 34,
                'fontColor' => '51,51,51',
                'angle' => 0,
                'fontPath' => DISCUZ_ROOT . 'source/plugin/zimu_zhaopin/static/font/Alibaba-PuHuiTi-Regular.ttf',
            ),
            array(
                'text' => $myinfo['jobs'][1]['wage_cn'],
                'left' => 940,
                'top' => 1140,
                'fontSize' => 34,
                'fontColor' => '51,51,51',
                'angle' => 0,
                'fontPath' => DISCUZ_ROOT . 'source/plugin/zimu_zhaopin/static/font/Alibaba-PuHuiTi-Regular.ttf',
            ),
            array(
                'text' => $myinfo['jobs'][2]['jobs_name'],
                'left' => 150,
                'top' => 1240,
                'fontSize' => 34,
                'fontColor' => '51,51,51',
                'angle' => 0,
                'fontPath' => DISCUZ_ROOT . 'source/plugin/zimu_zhaopin/static/font/Alibaba-PuHuiTi-Regular.ttf',
            ),
            array(
                'text' => $myinfo['jobs'][2]['wage_cn'],
                'left' => 940,
                'top' => 1240,
                'fontSize' => 34,
                'fontColor' => '51,51,51',
                'angle' => 0,
                'fontPath' => DISCUZ_ROOT . 'source/plugin/zimu_zhaopin/static/font/Alibaba-PuHuiTi-Regular.ttf',
            ),
            array(
                'text' => $myinfo['jobs'][3]['jobs_name'],
                'left' => 150,
                'top' => 1340,
                'fontSize' => 34,
                'fontColor' => '51,51,51',
                'angle' => 0,
                'fontPath' => DISCUZ_ROOT . 'source/plugin/zimu_zhaopin/static/font/Alibaba-PuHuiTi-Regular.ttf',
            ),
            array(
                'text' => $myinfo['jobs'][3]['wage_cn'],
                'left' => 940,
                'top' => 1340,
                'fontSize' => 34,
                'fontColor' => '51,51,51',
                'angle' => 0,
                'fontPath' => DISCUZ_ROOT . 'source/plugin/zimu_zhaopin/static/font/Alibaba-PuHuiTi-Regular.ttf',
            ),
            array(
                'text' => $myinfo['jobs'][4]['jobs_name'],
                'left' => 150,
                'top' => 1440,
                'fontSize' => 34,
                'fontColor' => '51,51,51',
                'angle' => 0,
                'fontPath' => DISCUZ_ROOT . 'source/plugin/zimu_zhaopin/static/font/Alibaba-PuHuiTi-Regular.ttf',
            ),
            array(
                'text' => $myinfo['jobs'][4]['wage_cn'],
                'left' => 940,
                'top' => 1440,
                'fontSize' => 34,
                'fontColor' => '51,51,51',
                'angle' => 0,
                'fontPath' => DISCUZ_ROOT . 'source/plugin/zimu_zhaopin/static/font/Alibaba-PuHuiTi-Regular.ttf',
            ),
            array(
                'text' => $myinfo['jobs'][5]['jobs_name'],
                'left' => 150,
                'top' => 1540,
                'fontSize' => 34,
                'fontColor' => '51,51,51',
                'angle' => 0,
                'fontPath' => DISCUZ_ROOT . 'source/plugin/zimu_zhaopin/static/font/Alibaba-PuHuiTi-Regular.ttf',
            ),
            array(
                'text' => $myinfo['jobs'][5]['wage_cn'],
                'left' => 940,
                'top' => 1540,
                'fontSize' => 34,
                'fontColor' => '51,51,51',
                'angle' => 0,
                'fontPath' => DISCUZ_ROOT . 'source/plugin/zimu_zhaopin/static/font/Alibaba-PuHuiTi-Regular.ttf',
            ),
        ),
        'background' => DISCUZ_ROOT . '/source/plugin/zimu_zhaopin/static/wap/images/combg.jpg',
    );

    $hbpath = DISCUZ_ROOT . '/source/plugin/zimu_zhaopin/uploadzimucms/haibao/company_'.$ids.'.png';
    
    if(!file_exists($hbpath) || !filesize($hbpath) || filemtime($hbpath) < time()-86400) {
        $hbimg = createMiniWechat($config,$myinfo);
    }else{
        $hbimg = $_G['siteurl'].'source/plugin/zimu_zhaopin/uploadzimucms/haibao/company_'.$ids.'.png';
    }

    $myinfo2['hbimg'] = $hbimg;

    ajaxReturn(1, $language_zimu['poster_com_inc_php_1'], $myinfo2);


    function createMiniWechat($config,$myinfo)
    {
        global $_G;

        $filename = DISCUZ_ROOT . '/source/plugin/zimu_zhaopin/uploadzimucms/haibao/company_'.$myinfo['id'].'.png';
        $rest = createPoster1($config, $filename);
        if ($rest) {
            $image = $_G['siteurl'].'source/plugin/zimu_zhaopin/uploadzimucms/haibao/company_'.$myinfo['id'].'.png';
            return $image;
        }
        return false;
    }

    function createPoster1($config = array(), $filename = "")
    {
        if (empty($filename)) header("content-type: image/png");
        $imageDefault = array(
            'left' => 0,
            'top' => 0,
            'right' => 0,
            'bottom' => 0,
            'width' => 100,
            'height' => 100,
            'opacity' => 100
        );
        $textDefault = array(
            'text' => '',
            'left' => 0,
            'top' => 0,
            'fontSize' => 32,
            'fontColor' => '255,255,255',
            'angle' => 0,
        );
        $background = $config['background'];
        $backgroundInfo = getimagesize($background);
        $backgroundFun = 'imagecreatefrom' . image_type_to_extension($backgroundInfo[2], false);
        $background = $backgroundFun($background);
        $backgroundWidth = imagesx($background);
        $backgroundHeight = imagesy($background);
        $imageRes = imageCreatetruecolor($backgroundWidth, $backgroundHeight);
        $color = imagecolorallocate($imageRes, 0, 0, 0);
        imagefill($imageRes, 0, 0, $color);
        imagecopyresampled($imageRes, $background, 0, 0, 0, 0, imagesx($background), imagesy($background), imagesx($background), imagesy($background));
        if (!empty($config['image'])) {
            foreach ($config['image'] as $key => $val) {

                    $val = array_merge($imageDefault, $val);
                    $info = getimagesize($val['url']);
                    $function = 'imagecreatefrom' . image_type_to_extension($info[2], false);
                    if ($val['stream']) {
                        $info = getimagesizefromstring($val['url']);
                        $function = 'imagecreatefromstring';
                    }
                    $res = $function($val['url']);
                    $resWidth = $info[0];
                    $resHeight = $info[1];
                    $canvas = imagecreatetruecolor($val['width'], $val['height']);
                    imagefill($canvas, 0, 0, $color);
                    $ext = pathinfo($val['url']);
                    if (array_key_exists('extension', $ext)) {
                        if ($ext['extension'] == 'gif' || $ext['extension'] == 'png') {
                            imageColorTransparent($canvas, $color);

                        }
                    }

                imagecopyresampled($canvas, $res, 0, 0, 0, 0, $val['width'], $val['height'], $resWidth, $resHeight);
                //$val['left'] = $val['left']<0?$backgroundWidth- abs($val['left']) - $val['width']:$val['left'];
                if ($val['left'] < 0) {
                    $val['left'] = ceil($backgroundWidth - $val['width']) / 2;
                }
                $val['top'] = $val['top'] < 0 ? $backgroundHeight - abs($val['top']) - $val['height'] : $val['top'];
                imagecopymerge($imageRes, $canvas, $val['left'], $val['top'], $val['right'], $val['bottom'], $val['width'], $val['height'], $val['opacity']);

            }
        }
        if (!empty($config['text'])) {
            foreach ($config['text'] as $key => $val) {
                $val = array_merge($textDefault, $val);
                $val['text'] = diconv($val['text'],CHARSET,'UTF-8');
                list($R, $G, $B) = explode(',', $val['fontColor']);
                $fontColor = imagecolorallocate($imageRes, $R, $G, $B);
                //$val['left'] = $val['left']<0?$backgroundWidth- abs($val['left']):$val['left'];
                $text = autowrap($val['fontSize'], 0, $val['fontPath'], $val['text'], 1000);
                if ($val['left'] < 0) {
                    $fontBox = imagettfbbox($val['fontSize'], 0, $val['fontPath'], $text);
                    $val['left'] = ceil(($backgroundWidth - $fontBox[2]) / 2);
                }
                $val['top'] = $val['top'] < 0 ? $backgroundHeight - abs($val['top']) : $val['top'];
                imagettftext($imageRes, $val['fontSize'], $val['angle'], $val['left'], $val['top'], $fontColor, $val['fontPath'], $text);
            }
        }
        if (!empty($filename)) {
            $res = imagejpeg($imageRes, $filename, 90);
            imagedestroy($imageRes);
            if (!$res) return false;
            return $filename;
        } else {
            header("Content-type:image/png");
            imagejpeg($imageRes);
            imagedestroy($imageRes);
        }
    }

    function autowrap($fontsize, $angle, $fontface, $string, $width)
    {
        $content = "";
        for ($i = 0; $i < mb_strlen($string); $i++) {
            $letter[] = mb_substr($string, $i, 1);
        }

        foreach ($letter as $l) {
            $teststr = $content . " " . $l;
            $testbox = imagettfbbox($fontsize, $angle, $fontface, $teststr);
            if (($testbox[2] > $width) && ($content !== "")) {
                $content .= "\n";
            }
            $content .= $l;
        }
        return $content;
    }