<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$cid1  = intval($_GET['cid1']);
$cid2  = intval($_GET['cid2']);
$url   = addslashes($_GET['url']);
$modelname   = addslashes($_GET['modelname']);


$returnhtml = '<li style="width: 88%;background-color: #f7f7f7;color: #4ba1ee;font-size: 12px;height: 30px;line-height: 30px;margin: 10px auto;">'.$language_zimu['area_three_inc_php_0'].'</li><li><a href="'.get_url3($url,'model','citycategory','citycategory2','citycategory3').'&model='.$modelname.'&citycategory='.$cid1.'&citycategory2='.$cid2.'" class="haha">'.$language_zimu['area_three_inc_php_1'].'</a></li>';
if($zmdata['settings']['area_three']){

    $area_three = DB::fetch_all('select * from %t where parentid=%d order by sort asc,id asc', array(
        'zimu_zhaopin_area',
        $cid2
    ), 'id');


    foreach ($area_three as $key => $value) {
        
     $returnhtml = $returnhtml.'<li><a href="'.get_url3($url,'model','citycategory','citycategory2','citycategory3').'&model='.$modelname.'&citycategory='.$cid1.'&citycategory2='.$cid2.'&citycategory3='.$value[id].'" class="haha">'.$value['name'].'</a></li>';
        
    }

echo $returnhtml;
}