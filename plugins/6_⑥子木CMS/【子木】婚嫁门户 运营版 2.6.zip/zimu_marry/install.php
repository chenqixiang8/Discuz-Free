<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$sql = <<<SQL

CREATE TABLE IF NOT EXISTS `pre_zimu_marry_activity` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `mtype` int(10) UNSIGNED NOT NULL,
  `sid` int(10) UNSIGNED NOT NULL,
  `mintitle` char(30) NOT NULL,
  `color` char(30) NOT NULL,
  `title` char(100) NOT NULL,
  `thumb` varchar(1000) NOT NULL,
  `starttime` int(10) UNSIGNED NOT NULL,
  `endtime` int(10) UNSIGNED NOT NULL,
  `con` longtext NOT NULL,
  `recommend` tinyint(1) UNSIGNED NOT NULL,
  `sort` int(10) UNSIGNED NOT NULL,
  `views` int(10) UNSIGNED NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  KEY `mtype` (`mtype`),
  KEY `sid` (`sid`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimu_marry_activityuser` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `sid` int(10) UNSIGNED NOT NULL,
  `aid` int(10) UNSIGNED NOT NULL,
  `aidtitle` char(100) NOT NULL,
  `name` char(100) NOT NULL,
  `phone` char(20) NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  `beizhu` varchar(2000) NOT NULL,
  `status` tinyint(2) UNSIGNED NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `sid` (`sid`),
  KEY `aid` (`aid`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimu_marry_hotel_hall` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `sid` int(10) UNSIGNED NOT NULL,
  `name` char(255) NOT NULL,
  `thumb` varchar(500) NOT NULL,
  `min_table` tinyint(3) UNSIGNED NOT NULL,
  `max_table` tinyint(3) UNSIGNED NOT NULL,
  `area` char(20) NOT NULL,
  `height` char(20) NOT NULL,
  `pillar` char(20) NOT NULL,
  `con` mediumtext NOT NULL,
  `sort` tinyint(3) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sid` (`sid`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_marry_hotel_menu` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `sid` int(10) UNSIGNED NOT NULL,
  `name` char(255) NOT NULL,
  `price` char(100) NOT NULL,
  `con` text NOT NULL,
  `sort` tinyint(3) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sid` (`sid`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimu_marry_news_cat` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` char(100) NOT NULL,
  `sort` tinyint(3) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimu_marry_news_list` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` char(200) NOT NULL,
  `thumb` varchar(500) NOT NULL,
  `cid` int(10) UNSIGNED NOT NULL,
  `cname` char(100) NOT NULL,
  `con` mediumtext NOT NULL,
  `views` int(10) UNSIGNED NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cid` (`cid`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimu_marry_parameter` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` char(100) NOT NULL,
  `ename` char(100) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimu_marry_parameter2` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` char(100) NOT NULL,
  `parameter` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimu_marry_setting` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` char(100) NOT NULL,
  `keywords` char(100) NOT NULL,
  `description` char(255) NOT NULL,
  `logo` varchar(300) NOT NULL,
  `weixin_appid` char(255) NOT NULL,
  `weixin_appsecret` char(255) NOT NULL,
  `share_title` char(255) NOT NULL,
  `share_desc` char(255) NOT NULL,
  `share_thumb` char(255) NOT NULL,
  `settings` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimu_marry_shop` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` int(10) UNSIGNED NOT NULL,
  `name` char(100) NOT NULL,
  `thumb` varchar(1000) NOT NULL,
  `intro` mediumtext NOT NULL,
  `notice` varchar(5000) NOT NULL,
  `shopgift` char(200) NOT NULL,
  `address` char(255) NOT NULL,
  `banners` longtext NOT NULL,
  `lng` char(100) NOT NULL,
  `lat` char(100) NOT NULL,
  `tel` char(11) NOT NULL,
  `qrcode` varchar(300) NOT NULL,
  `type` tinyint(1) UNSIGNED NOT NULL,
  `quyu` tinyint(3) UNSIGNED NOT NULL,
  `series` int(10) UNSIGNED NOT NULL,
  `photo` int(10) UNSIGNED NOT NULL,
  `hotel_stars` tinyint(3) UNSIGNED NOT NULL,
  `hotel_minprice` int(10) UNSIGNED NOT NULL,
  `hotel_maxprice` int(10) UNSIGNED NOT NULL,
  `hotel_table` tinyint(3) UNSIGNED NOT NULL,
  `views` int(10) UNSIGNED NOT NULL,
  `sort` tinyint(3) UNSIGNED NOT NULL,
  `openid` text NOT NULL,
  `status` tinyint(1) UNSIGNED NOT NULL DEFAULT '1',
  `recommend` tinyint(3) UNSIGNED NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_marry_shop_photo` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `sid` int(10) UNSIGNED NOT NULL,
  `name` char(255) NOT NULL,
  `thumb` varchar(500) NOT NULL,
  `paramter` text NOT NULL,
  `con` longtext NOT NULL,
  `sort` tinyint(3) NOT NULL,
  `views` int(10) UNSIGNED NOT NULL,
  `recommend` tinyint(1) UNSIGNED NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sid` (`sid`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimu_marry_shop_series` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `sid` int(10) UNSIGNED NOT NULL,
  `name` char(255) NOT NULL,
  `price` char(30) NOT NULL,
  `marketprice` char(30) NOT NULL,
  `pszs` int(10) UNSIGNED NOT NULL,
  `rczs` int(10) UNSIGNED NOT NULL,
  `fzzx` int(10) UNSIGNED NOT NULL,
  `thumb` varchar(200) NOT NULL,
  `paramter` longtext NOT NULL,
  `seriesgift` char(200) NOT NULL,
  `con` longtext NOT NULL,
  `sort` tinyint(3) UNSIGNED NOT NULL,
  `views` int(10) UNSIGNED NOT NULL,
  `recommend` tinyint(1) UNSIGNED NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sid` (`sid`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimu_marry_yuyue` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` char(20) NOT NULL,
  `phone` char(20) NOT NULL,
  `sid` int(10) UNSIGNED DEFAULT NULL,
  `content` varchar(2000) DEFAULT NULL,
  `beizhu` varchar(2000) NOT NULL,
  `type` tinyint(3) UNSIGNED NOT NULL DEFAULT '1',
  `addtime` int(10) UNSIGNED NOT NULL,
  `typename` char(20) NOT NULL,
  `uid` int(10) UNSIGNED NOT NULL,
  `status` smallint(2) UNSIGNED DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `sid` (`sid`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_marry_marryday` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` int(10) UNSIGNED NOT NULL,
  `username` char(30) NOT NULL,
  `tel` char(20) NOT NULL,
  `marrytime` int(10) UNSIGNED NOT NULL,
  `note` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

SQL;

runquery($sql);

$finish = TRUE;
?>