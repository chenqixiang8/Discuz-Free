<?php

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/zimu_marry/config.php';

$model = addslashes($_GET['model']);
$model = !empty($model) ? $model : 'newindex';

if (!checkmobile() && $model !='admins' && $model !='members' && $model !='toqrcode' ) {
	include(template('zimu_marry:index_guide'));
	exit();
}

if ($zmdata['base']['weixin_appid'] && $zmdata['base']['weixin_appsecret']) {
    require_once DISCUZ_ROOT . './source/plugin/zimu_marry/class/wechat.lib.class.php';
    $wechat_client = new WeChatClient($zmdata['base']['weixin_appid'], $zmdata['base']['weixin_appsecret']);
    $jssdkvalue    = $wechat_client->getSignPackage();
}
    
include DISCUZ_ROOT . './source/plugin/zimu_marry/module/' . $model . '.inc.php';
    
