<?php
/*
 *DisM!应用中心：dism.taobao.com
 *更多商业插件/模版下载 就在DisM!应用中心
 *本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 *如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$langfile = DISCUZ_ROOT . './source/plugin/zimu_marry/language.' . currentlang() . '.php';

$includefile = is_file($langfile) ? $langfile : libfile('language', 'plugin/zimu_marry');

include $includefile;

define('ZIMUCMS_PATH', $_G['siteurl'] . 'source/plugin/zimu_marry/');
define('ZIMUCMS_ROOT', dirname(__FILE__));
define('ZIMUCMS_URL', $_G['siteurl'] . 'plugin.php?id=zimu_marry');
define('SITE_URL', $_G['siteurl']);
define('IN_WECHAT', strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false);
define('IN_XIAOYUNAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'Appbyme') !== false);
define('IN_QFAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'QianFan') !== false);
define('IN_MAGAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'MAGAPP') !== false);

$zmdata = $_G['cache']['plugin']['zimu_marry'];

$setdata = DB::fetch_first('select * from %t order by id desc', array(
        'zimu_marry_setting'
    ));

$zmdata['base'] = $setdata;
$zmdata['settings'] = unserialize($setdata['settings']);

$formhash = $_G['formhash'];

if ($_G['charset'] == 'gbk') {
    $charset = 'gbk';
} elseif ($_G['charset'] == 'utf-8') {
    $charset = 'UTF-8';
} elseif ($_G['charset'] == 'big5') {
    $charset = 'big5';
}



function isuid($refererurl='')
{
    global $_G;
    define('IN_XIAOYUNAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'Appbyme') !== false);
    define('IN_QFAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'QianFan') !== false);
    define('IN_MAGAPP', strpos($_SERVER['HTTP_USER_AGENT'], 'MAGAPP') !== false);
    if(!$refererurl){
        $refererurl = $_G['siteurl'] . $_SERVER['REQUEST_URI'];
    }

    if (IN_MAGAPP && !$_G['uid']){

$mag_paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
    'zimu_marry_parameter2',
    'magapp'
));

$mag_paramter = unserialize($mag_paramter['parameter']);

    }

    if (IN_MAGAPP && !$_G['uid'] && $mag_paramter['magapp_hostname']){
        

        $userAgent = $_SERVER['HTTP_USER_AGENT'];
        $info = strstr($userAgent, "MAGAPPX");
        $info=explode("|",$info);
        $token = $info[7];

        $appurl = $mag_paramter['magapp_hostname'].'/mag/cloud/cloud/getUserInfo?token='.$token.'&secret='.$mag_paramter['magapp_secret'];
        
        $appdata = dfsockopen($appurl);
        if (!$appdata) {
            $appdata = file_get_contents($appurl);
        }
        $r =  json_decode($appdata, true);
        if($r['data']['user_id']>0){

            $member = getuserbyuid($r['data']['user_id'], 1);
            if (!$member) {
                dheader('Location:' . $_G['siteurl'] . 'member.php?mod=logging&action=login&referer=' . urlencode($refererurl));
                exit();
            }
            if (isset($member['_inarchive'])) {
                C::t('common_member_archive')->move_to_master($member['uid']);
            }
            require_once libfile('function/member');
            $cookietime = 1296000;
            setloginstatus($member, $cookietime);
            return true;

        }else{
            exit('<script src="source/plugin/zimu_marry/static/js/magjs-x.js"></script><script>
                mag.toLogin(function(){
                    top.location.href="' . $refererurl . '";
                    });
                    </script>'); 
        }

    }else{

        if (!$_G['uid']) {
            if (IN_XIAOYUNAPP) {
                exit('<script language="javascript" src="source/plugin/zimu_marry/static/js/appbyme.js"></script><script>connectAppbymeJavascriptBridge(function(bridge){
                    AppbymeJavascriptBridge.login(function(data){
                        top.location.href="' . $refererurl . '";
                        });
                        });
                        </script>');
            } else if (IN_MAGAPP) {
                exit('<script src="source/plugin/zimu_marry/static/js/magjs-x.js"></script><script>
                    mag.toLogin(function(){
                        top.location.href="' . $refererurl . '";
                        });
                        </script>');  
            } else if (IN_QFAPP) {
                exit('<script src="source/plugin/zimu_marry/static/js/jquery-2.1.4.js"></script><script> function QFH5ready(){QFH5.jumpLogin(function(state,data){
                    if(state==1){
                        QFH5.refresh(1);
                        }else{
                //登陆失败
                            alert(data.error);//data.error: string
                        }
                        });
                    }
                    </script>');
            } else {
                dheader('Location:' . SITE_URL . '/member.php?mod=logging&action=login&referer=' . urlencode($refererurl));
                exit();
            }
        }
    }
}


function zm_diconv($str)
{
    global $_G;
    $encode = mb_detect_encoding($str, array(
        "UTF-8",
        "GB2312",
        "GBK"
    ));
    if ($encode != strtoupper(CHARSET)) {
        $keytitle = mb_convert_encoding($str, strtoupper(CHARSET), $encode);
    }
    
    $censorexp = '/^(' . str_replace(array(
        '\\*',
        "\r\n",
        ' '
    ), array(
        '.*',
        '|',
        ''
    ), preg_quote(($_G['cache']['plugin']['zimu_marry']['zimu_luanma'] = trim($_G['cache']['plugin']['zimu_marry']['zimu_luanma'])), '/')) . ')$/i';
    if ($_G['cache']['plugin']['zimu_marry']['zimu_luanma'] && @preg_match($censorexp, $keytitle)) {
        $keytitle = $str;
    }
    if (!$keytitle) {
        $keytitle = $str;
    }
    return $keytitle;
}


function tpl_form_field_image($id, $val) {
	if (!$val) {
		$val = 'source/plugin/zimu_marry/static/nopic.jpg';
	}

$langfile = DISCUZ_ROOT . './source/plugin/zimu_marry/language.' . currentlang() . '.php';

$includefile = is_file($langfile) ? $langfile : libfile('language', 'plugin/zimu_marry');

include $includefile;

	return '<div class="input-group "><input type="text" name="textfield_' . $id . '" type="file" id="textfield_' . $id . '" class="form-control valid" /><span class="input-group-btn"><input type="button" name="button" id="button1" value="'.$language_zimu['config_php_0'].'" class="btn btn-primary" /></span><input name="' . $id . '" type="file" class="type-file-file" id="' . $id . '" style="position: absolute;top: 0px;left: 0px;height: 40px;width: 100%;filter: alpha(opacity: 0);opacity: 0;cursor: pointer;" size="200" hidefocus="true">
  </div><div class="input-group " style="margin-top:6px;"><input type="hidden" name="img_' . $id . '" value="' . $val . '"><img src="' . $val . '" class="img-responsive img-thumbnail" width="150" id="img_' . $id . '"></div>';

}

function zimu_array_utf8($String)
{
    if (is_array($String)) {
        foreach ($String as $key => $val) {
            $String[$key] = zimu_array_utf8($val);
        }
    } else {
        if (preg_match("/^[A-Za-z0-9\s]+$/", $String)) {
            $String = $String;
        } else {
            $String = diconv($String,CHARSET,'UTF-8');
        }
    }
    return $String;
}

function zm_saveimages($FILES, $type = 'zimucms')
{
    global $_G;

    require_once DISCUZ_ROOT . './source/plugin/zimu_marry/new_discuz_upload.php';

    $upload = new discuz_upload_zimucms();

    $upload->init($FILES, 'uploadzimucms');
    
    $upload2 = object_array($upload);
    if($upload2['attach']['isimage'] != 1){
        return false;
    }

    if ($upload->error()) {
        return '';
    }

    $upload->save();
    if ($upload->error()) {
        return '';
    }

    $pic = $upload->attach['attachment'];

    if ($upload->attach['imageinfo'][0] > 1500 || $upload->attach['imageinfo'][1] > 1500) {
        if ($upload->attach['imageinfo'][0] >= $upload->attach['imageinfo'][1]) {
            $thumb_width = $upload->attach['imageinfo'][0] / 2;
        } else {
            $thumb_width = $upload->attach['imageinfo'][1] / 2;
        }

        require_once libfile('class/image');
        $image = new image();
        $pic2  = $image->Thumb($upload->attach['target'], '', $thumb_width, $thumb_width, 2);
    }

    $oss_paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
        'zimu_marry_parameter2',
        'alioss'
    ));
    
    $oss_paramter = unserialize($oss_paramter['parameter']);

    if($oss_paramter['ACCESS_ID'] && $oss_paramter['ACCESS_KEY'] && $oss_paramter['ENDPOINT'] && $oss_paramter['BUCKET']){
        $saved_file = DISCUZ_ROOT.'/source/plugin/zimu_marry/uploadzimucms/'.$pic;
        include_once DISCUZ_ROOT.'source/plugin/zimu_marry/lib/OSS/Common.php';
        if ($surl = zm_oss_upload('zimu_marry/'.$pic, $saved_file)) {
            @unlink($saved_file);
            return $imgurl = $surl;
            exit();
        }
    }
    
    if ($pic2) {
        return '/source/plugin/zimu_marry/uploadzimucms/' . $pic . '.thumb.jpg';
    } else {
        return '/source/plugin/zimu_marry/uploadzimucms/' . $pic;
    }
}


function pagination($total, $pageIndex, $pageSize = 15, $url = '', $context = array('before' => 5, 'after' => 4, 'ajaxcallback' => '', 'callbackfuncname' => '')) {
    global $_G;
    $pdata = array(
        'tcount' => 0,
        'tpage' => 0,
        'cindex' => 0,
        'findex' => 0,
        'pindex' => 0,
        'nindex' => 0,
        'lindex' => 0,
        'options' => ''
    );
    
    $pdata['tcount'] = $total;
    $pdata['tpage'] = (empty($pageSize) || $pageSize < 0) ? 1 : ceil($total / $pageSize);
    if ($pdata['tpage'] <= 1) {
        return '';
    }
    $cindex = $pageIndex;
    $cindex = min($cindex, $pdata['tpage']);
    $cindex = max($cindex, 1);
    $pdata['cindex'] = $cindex;
    $pdata['findex'] = 1;
    $pdata['pindex'] = $cindex > 1 ? $cindex - 1 : 1;
    $pdata['nindex'] = $cindex < $pdata['tpage'] ? $cindex + 1 : $pdata['tpage'];
    $pdata['lindex'] = $pdata['tpage'];


    $_GET['page'] = $pdata['findex'];
    $pdata['faa'] = 'href="' . $_G['script_name'] . '?' . http_build_query($_GET) . '"';
    $_GET['page'] = $pdata['pindex'];
    $pdata['paa'] = 'href="' . $_G['script_name'] . '?' . http_build_query($_GET) . '"';
    $_GET['page'] = $pdata['nindex'];
    $pdata['naa'] = 'href="' . $_G['script_name'] . '?' . http_build_query($_GET) . '"';
    $_GET['page'] = $pdata['lindex'];
    $pdata['laa'] = 'href="' . $_G['script_name'] . '?' . http_build_query($_GET) . '"';

    $html = '<div><ul class="pagination pagination-centered">';
    if ($pdata['cindex'] > 1) {
        $html .= "<li><a {$pdata['faa']} class=\"pager-nav\">".$language_zimu['config_php_1']."</a></li>";
        $html .= "<li><a {$pdata['paa']} class=\"pager-nav\">&laquo;".$language_zimu['config_php_2']."</a></li>";
    }
    if (!$context['before'] && $context['before'] != 0) {
        $context['before'] = 5;
    }
    if (!$context['after'] && $context['after'] != 0) {
        $context['after'] = 4;
    }

    if ($context['after'] != 0 && $context['before'] != 0) {
        $range = array();
        $range['start'] = max(1, $pdata['cindex'] - $context['before']);
        $range['end'] = min($pdata['tpage'], $pdata['cindex'] + $context['after']);
        if ($range['end'] - $range['start'] < $context['before'] + $context['after']) {
            $range['end'] = min($pdata['tpage'], $range['start'] + $context['before'] + $context['after']);
            $range['start'] = max(1, $range['end'] - $context['before'] - $context['after']);
        }
        for ($i = $range['start']; $i <= $range['end']; $i++) {
            if ($context['isajax']) {
                $aa = 'href="javascript:;" page="' . $i . '" '. ($callbackfunc ? 'onclick="'.$callbackfunc.'(\'' . $url . '\', \'' . $i . '\', this);return false;"' : '');
            } else {
                if ($url) {
                    $aa = 'href="?' . str_replace('*', $i, $url) . '"';
                } else {
                    $_GET['page'] = $i;
                    $aa = 'href="?' . http_build_query($_GET) . '"';
                }
            }
            $html .= ($i == $pdata['cindex'] ? '<li class="active"><a href="javascript:;">' . $i . '</a></li>' : "<li><a {$aa}>" . $i . '</a></li>');
        }
    }

    if ($pdata['cindex'] < $pdata['tpage']) {
        $html .= "<li><a {$pdata['naa']} class=\"pager-nav\">".$language_zimu['config_php_3']."&raquo;</a></li>";
        $html .= "<li><a {$pdata['laa']} class=\"pager-nav\">".$language_zimu['config_php_4']."</a></li>";
    }
    $html .= '</ul></div>';
    return $html;
}
function ifilter_url($params) {
    global $_G;
    if(empty($params)) {
        return '';
    }
    $query_arr = array();
    $parse = parse_url('https://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']);
    if(!empty($parse['query'])) {
        $query = $parse['query'];
        parse_str($query, $query_arr);
    }
    $params = explode(',', $params);
    foreach($params as $val) {
        if(!empty($val)) {
            $data = explode(':', $val);
            $query_arr[$data[0]] = trim($data[1]);
        }
    }
    $query_arr['page'] = 1;
    $query = http_build_query($query_arr);
    return './plugin.php?' . $query;
}

function zimu_writetocache($key = 'table_plugin_zimu_marry', $array = array()){

    if(strpos($key,'table_plugin_zimu_marry')<0){
        echo 'no files allow write';exit();
    }

    $datas = $array;
    $cachedata = " return " . var_export($datas, TRUE) . ";";

    global $_G;

    $dir = DISCUZ_ROOT . "./data/sysdata/";
    if (!is_dir($dir)) {
        dmkdir($dir, 0777);
    }
    $file = "$dir/$key.php";
    if ($fp = @fopen($file, 'wb')) {
        fwrite($fp, "<?php\n//Discuz! cache file, DO NOT modify me!\n//Identify: " . md5($key . '.php' . $cachedata . $_G['config']['security']['authkey']) . "\n\n$cachedata?>");
        fclose($fp);
    } else {
        exit('Can not write to cache files, please check directory ./data/ and ./data/sysdata/ .');
    }
}

function zimu_readfromcache($key = 'table_plugin_zimu_marry'){

    if(strpos($key,'table_plugin_zimu_marry')<0){
        echo 'no files allow write';exit();
    }

    $ret = array();

    $file = DISCUZ_ROOT . "./data/sysdata/$key.php";
    if (is_file($file)) {
        $ret = include $file;
    }

    return $ret;
}

function zimu_deletefromcache($key = 'table_plugin_zimu_marry'){

    if(strpos($key,'table_plugin_zimu_marry')<0){
        echo 'no files allow write';exit();
    }

    $cache_file = DISCUZ_ROOT . "./data/sysdata/$key.php";
    if(is_file($cache_file)){
        @unlink($cache_file);
    }
    return TRUE;
}
    function get_tag_pars($par,$value){
        if(is_int($par)){
            $where = "id='{$par}'";
        }else{
            $where = "ename='{$par}'";
        }
        $str = DB::fetch_first('select * from %t where '.$where,array('zimu_marry_parameter'));
        $arrtemp = explode(',',$str['value']);
        if(strpos($value,',')){
            $value2 = explode(',',$value);
            foreach($value2 as $vals){
                $val[] = $arrtemp[$vals-1];
            }
            $val = join(' ',$val);
        }else{
            $val = $arrtemp[$value-1];
        }
        return $val;
    }

function lizimu_post($url, $data) {
        if (!function_exists('curl_init')) {
            return '';
        }
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        # curl_setopt( $ch, CURLOPT_HEADER, 1);

        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);

        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        $data = curl_exec($ch);
        if (!$data) {
            error_log(curl_error($ch));
        }
        curl_close($ch);
        return $data;
    }


function getFile($url, $save_dir = '', $filename = '', $type = 0, $isutf8 = 0) {
    if (trim($url) == '') {
        return false;
    }
    if (trim($save_dir) == '') {
        $save_dir = './';
    }
    if (0 !== strrpos($save_dir, '/')) {
        $save_dir.= '/';
    }

    if (!file_exists($save_dir) && !mkdir($save_dir, 0777, true)) {
        return false;
    }
    if ($type) {
        $ch = curl_init();
        $timeout = 5;
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
        $content = curl_exec($ch);
        curl_close($ch);
    } else {
        ob_start();
        readfile($url);
        $content = ob_get_contents();
        ob_end_clean();
    }
    $size = strlen($content);
    $fp2 = @fopen($save_dir . $filename, 'w+');
    if($isutf8){
      $content = diconv($content,'gbk','UTF-8');
      //$content = utf8_encode($content);
      $content = "\xEF\xBB\xBF".$content;
    }
    fwrite($fp2, $content);
    fclose($fp2);
    unset($content, $url);
    if($isutf8){
    checkBOM($save_dir . $filename);
    }
    return array(
        'file_name' => $filename,
        'save_path' => $save_dir . $filename
    );
}

function checkBOM($filename) 
{ 
    global $auto; 
    $contents   = file_get_contents($filename); 
    $charset[1] = substr($contents, 0, 1); 
    $charset[2] = substr($contents, 1, 1); 
    $charset[3] = substr($contents, 2, 1); 
    if (ord($charset[1]) == 239 && ord($charset[2]) == 187 && ord($charset[3]) == 191) { 
            $rest = substr($contents, 3); 
            rewrite($filename, $rest); 
    }
} 

function rewrite($filename, $data)
{
    $filenum = fopen($filename, "w");
    flock($filenum, LOCK_EX);
    fwrite($filenum, $data);
    fclose($filenum);
}

function zimu_template($name,$defdir='',$ishow=1){
    global $_G;

if(strpos('www.0575marry.com', 'demo.zimucms.com') !== false){
$debug = 1;
}else{
$debug = 0;
}

if(!$defdir){
if(!checkmobile()){
$defdir = '';
}else{
$defdir = 'touch';
}
}

if($debug == 0){
$oldtpl = file_get_contents(DISCUZ_ROOT . './source/plugin/zimu_marry/template/'.$defdir.'/'.$name.'.htm');

if($oldtpl == 'lizimu' || !$oldtpl){
$newtpl = 'http://demo.zimucms.com/source/plugin/zimu_marry/template_cn/'.$defdir.'/'.$name.'.htm';
$save_dir = DISCUZ_ROOT . './source/plugin/zimu_marry/template/'.$defdir.'/';
$filename = $name.'.htm';
if($_G['charset'] == 'utf-8'){
getFile($newtpl, $save_dir, $filename, 1, 1);
}else{
getFile($newtpl, $save_dir, $filename, 1);
}
}
}
if($ishow){
return template('zimu_marry:'.$name);
}
}

zimu_template('common_header','touch',0);
zimu_template('common_footer','touch',0);
zimu_template('site_tabbar','touch',0);
zimu_template('shop_header','touch',0);
zimu_template('shop_footerbar','touch',0);


zimu_template('footer_base','common',0);
zimu_template('footer','common',0);
zimu_template('header_base','common',0);
zimu_template('header','common',0);
zimu_template('success','common',0);
zimu_template('members_header','common',0);

function object_array($array)
{
    if (is_object($array)) {
        $array = (array) $array;
    }
    if (is_array($array)) {
        foreach ($array as $key => $value) {
            $array[$key] = object_array($value);
        }
    }
    return $array;
}

$title = $zmdata['base']['title'];
$keywords = $zmdata['base']['keywords'];
$description = $zmdata['base']['description'];

$share_title = $zmdata['base']['title'];
$share_desc = $zmdata['base']['share_desc'];
$share_url = $_G['siteurl'].$_SERVER['REQUEST_URI'];
$share_thumb = $_G['siteurl'].$zmdata['base']['share_thumb'];