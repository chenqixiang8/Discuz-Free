<?php
//Discuz! cache file, DO NOT modify me!
//Identify: 

 return array (
  'config_php_0' => '上傳圖片',
  'config_php_1' => '首頁',
  'config_php_2' => '上一頁',
  'config_php_3' => '下一頁',
  'config_php_4' => '尾頁',
  'config_php_5' => '您好，您有新的預約訂單',
  'activitybtn_inc_php_0' => '您好，您有新的預約訂單',
  'activitybtn_inc_php_1' => '您好，您有新的預約訂單',
  'admins_activitylist_inc_php_0' => '姓名',
  'admins_activitylist_inc_php_1' => '電話',
  'admins_activitylist_inc_php_2' => '備注',
  'dengji_inc_php_0' => '結婚登記処',
  'jiri_inc_php_0' => '結婚吉日',
  'my_inc_php_0' => '我的',
  'ruzhu_inc_php_0' => '請填寫商家名稱',
  'ruzhu_inc_php_1' => '請選擇商家類型',
  'ruzhu_inc_php_2' => '請選擇商家地區',
  'ruzhu_inc_php_3' => '請輸入詳細地址',
  'ruzhu_inc_php_4' => '請填寫商家介紹',
  'ruzhu_inc_php_5' => '請上傳商家',
  'ruzhu_inc_php_6' => '或客戶微信二維碼',
  'ruzhu_inc_php_7' => '入駐成功',
  'shoplist_inc_php_0' => '所有商家',
  'toyuyue_inc_php_0' => '您好，您有新的預約訂單',
  'toyuyue_inc_php_1' => '您好，您有新的預約訂單',
  'yusuan_inc_php_0' => '結婚預算',
);?>