<?php
//Discuz! cache file, DO NOT modify me!
//Identify: 

 return array (
  'config_php_0' => '上传图片',
  'config_php_1' => '首页',
  'config_php_2' => '上一页',
  'config_php_3' => '下一页',
  'config_php_4' => '尾页',
  'config_php_5' => '您好，您有新的预约订单',
  'activitybtn_inc_php_0' => '您好，您有新的预约订单',
  'activitybtn_inc_php_1' => '您好，您有新的预约订单',
  'admins_activitylist_inc_php_0' => '姓名',
  'admins_activitylist_inc_php_1' => '电话',
  'admins_activitylist_inc_php_2' => '备注',
  'dengji_inc_php_0' => '结婚登记处',
  'jiri_inc_php_0' => '结婚吉日',
  'my_inc_php_0' => '我的',
  'ruzhu_inc_php_0' => '请填写商家名称',
  'ruzhu_inc_php_1' => '请选择商家类型',
  'ruzhu_inc_php_2' => '请选择商家地区',
  'ruzhu_inc_php_3' => '请输入详细地址',
  'ruzhu_inc_php_4' => '请填写商家介绍',
  'ruzhu_inc_php_5' => '请上传商家',
  'ruzhu_inc_php_6' => '或客户微信二维码',
  'ruzhu_inc_php_7' => '入驻成功',
  'shoplist_inc_php_0' => '所有商家',
  'toyuyue_inc_php_0' => '您好，您有新的预约订单',
  'toyuyue_inc_php_1' => '您好，您有新的预约订单',
  'yusuan_inc_php_0' => '结婚预算',
);?>