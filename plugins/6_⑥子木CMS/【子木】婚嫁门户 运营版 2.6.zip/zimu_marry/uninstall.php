<?php

if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$sql = <<<EOF
DROP TABLE  IF EXISTS pre_zimu_marry_activity;
DROP TABLE  IF EXISTS pre_zimu_marry_activityuser;
DROP TABLE  IF EXISTS pre_zimu_marry_hotel_hall;
DROP TABLE  IF EXISTS pre_zimu_marry_hotel_menu;
DROP TABLE  IF EXISTS pre_zimu_marry_news_cat;
DROP TABLE  IF EXISTS pre_zimu_marry_news_list;
DROP TABLE  IF EXISTS pre_zimu_marry_parameter;
DROP TABLE  IF EXISTS pre_zimu_marry_parameter2;
DROP TABLE  IF EXISTS pre_zimu_marry_setting;
DROP TABLE  IF EXISTS pre_zimu_marry_shop;
DROP TABLE  IF EXISTS pre_zimu_marry_shop_photo;
DROP TABLE  IF EXISTS pre_zimu_marry_shop_series;
DROP TABLE  IF EXISTS pre_zimu_marry_yuyue;
EOF;

runquery($sql);

deldirfile(DISCUZ_ROOT . "./source/plugin/zimu_marry/uploadzimucms");

deldirfile(DISCUZ_ROOT . "./source/plugin/zimu_marry/static/kindeditor/attached/image");


$finish = TRUE;



function deldirfile($directory, $empty = false) {
    if(substr($directory,-1) == "/") {
        $directory = substr($directory,0,-1);
    }

    if(!file_exists($directory) || !is_dir($directory)) {
        return false;
    } elseif(!is_readable($directory)) {
        return false;
    } else {
        @$directoryHandle = opendir($directory);

        while ($contents = @readdir($directoryHandle)) {
            if($contents != '.' && $contents != '..') {
                $path = $directory . "/" . $contents;

                if(is_dir($path)) {
                    @deldirfile($path, $empty);
                } else {
                    @unlink($path);
                }
            }
        }

        @closedir($directoryHandle);

        if($empty == false) {
            if(!@rmdir($directory)) {
                return false;
            }
        }

        return true;
    }
}
function deletecache($cachenames) {  
    if(!empty($cachenames)) {  
  DB::delete('common_syscache', array('cname' => $cachenames));
    }  
}