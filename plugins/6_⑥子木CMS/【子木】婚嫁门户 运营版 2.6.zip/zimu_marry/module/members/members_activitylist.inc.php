<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$op = addslashes($_GET['op']);
$op = $op ? $op : 'list';

if ($op == 'edit') {
    
    if (submitcheck('submit')) {

        $data['mtype']         = intval($myshopdata['type']);
        $data['sid']         = intval($myshopdata['id']);
        $data['mintitle']        = strip_tags($_GET['mintitle']);
        $data['color']        = strip_tags($_GET['mintitle_color']);
        $data['title']        = strip_tags($_GET['title']);
        if ($_FILES['thumb']['tmp_name']) {
            $data['thumb'] = zm_saveimages($_FILES['thumb']);
        }
        $data['starttime'] = strtotime($_GET['starttime']);
        $data['endtime'] = strtotime($_GET['endtime']);
        $data['con']    = dhtmlspecialchars($_GET['con']);
        $data['sort']   = intval($_GET['sort']);
        $data['addtime'] = strtotime($_GET['addtime']);
        $data['id']      = intval($_GET['ids']);        
        
        if ($data['id'] > 0) {
            
            DB::update('zimu_marry_activity', $data, array(
                'id' => $data['id'],
                'sid' => $myshopdata['id'],
            ));
            
        } else {
            
            $result = DB::insert('zimu_marry_activity', $data, 1);
            
        }
        
        
        include template('zimu_marry:common/success');
        
        
    } else {
        
        $ids = intval($_GET['ids']);
        
        $listdata = DB::fetch_first('select * from %t where sid=% and id=%d', array(
            'zimu_marry_activity',
            $myshopdata['id'],
            $ids
        ));
        
        include zimu_template('members/members_' . $type);
        
    }

} else if ($op == 'del' && $_GET['md5hash'] == formhash()) {
    
    $ids = intval($_GET['ids']);
    
    $result = DB::delete('zimu_marry_activity', array(
        'id' => $ids,
        'sid' => $myshopdata['id']
    ));
    
    include template('zimu_marry:common/success');

} else if ($op == 'viewdata') {


        $aid = intval($_GET['ids']);

  if (submitcheck('edityuyue') || submitcheck('edityuyue2') || submitcheck('edityuyue3') || submitcheck('edityuyue4')) {

      $editdata['id']     = intval($_GET['yuyueid']);
      $editdata['beizhu'] = strip_tags($_GET['beizhu']);

      if ($_GET['edityuyue2']) {
          $editdata['status'] = 2;
      } else if ($_GET['edityuyue3']) {
          $editdata['status'] = 3;
      } else if ($_GET['edityuyue4']) {
          $editdata['status'] = 4;
      }

      if ($editdata['id'] > 0) {
          $result = DB::update('zimu_marry_activityuser', $editdata, array(
              'id' => $editdata['id'],
              'sid' => $myshopdata['id'],
          ));
      } else {
          $editdata['name']    = strip_tags($_GET['name']);
          $editdata['phone']   = strip_tags($_GET['phone']);
          $editdata['addtime'] = $_G['timestamp'];
          $result              = DB::insert('zimu_marry_activityuser', $editdata);
      }

        include template('zimu_marry:common/success');

  } else {

        $page   = $_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;
        $page   = intval($page);
        $status = $_GET['status'] = $_GET['status'] ? $_GET['status'] : 1;
        $status = intval($status);

        $wheresql = ' where sid='.$myshopdata['id'].' and status=' . $status;

        if($aid){
            $wheresql .= ' and aid=' . $aid;
        }

        $count = DB::result_first("SELECT count(*) FROM %t" . $wheresql, array(
            "zimu_marry_activityuser"
        ));

        $limit    = 20;
        $start    = ($page - 1) * $limit;
        $page_num = ceil($count / $limit);


        $yuyuedata = DB::fetch_all('select * from %t ' . $wheresql . ' order by id desc limit %d,%d', array(
            'zimu_marry_activityuser',
            $start,
            $limit
        ));

        if ($page_num > 1) {
            $multipage = pagination($count, $page, $limit);
        }

        include zimu_template('members/members_activity_viewdata');

        }


} else {
    
    $wheresql = 'where sid='.$myshopdata['id'];

    $keyword = trim($_GET['keyword']);
    if (!empty($keyword)) {
        $wheresql .= " and (`name` LIKE '%{$keyword}%') ";
    }
    
    $mtype = intval($_GET['mtype']);
    if ($mtype) {
        $wheresql .= ' and mtype=' . $mtype;
    }
    
    $pindex = max(1, intval($_GET['page']));
    $psize  = 10;
    
    $total = DB::result_first("SELECT count(*) FROM %t %i", array(
        "zimu_marry_activity",
        $wheresql
    ));
    
    $listdata = DB::fetch_all('select * from %t %i order by id desc limit %d,%d', array(
        'zimu_marry_activity',
        $wheresql,
        ($pindex - 1) * $psize,
        $psize
    ));
    
    
    $pager = pagination($total, $pindex, $psize);
    
    include zimu_template('members/members_' . $type);
    
    
}