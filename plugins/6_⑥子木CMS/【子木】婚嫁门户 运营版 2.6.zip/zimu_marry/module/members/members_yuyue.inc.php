<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/zimu_marry/config.php';

$op = addslashes($_GET['op']);
$op = $op ? $op : 'yuyue';


if ($op == 'yuyue') {
    
    if (submitcheck('edityuyue') || submitcheck('edityuyue2') || submitcheck('edityuyue3') || submitcheck('edityuyue4')) {
        
        $editdata['id']     = intval($_GET['yuyueid']);
        $editdata['beizhu'] = strip_tags($_GET['beizhu']);
        
        if ($_GET['edityuyue2']) {
            $editdata['status'] = 2;
        } else if ($_GET['edityuyue3']) {
            $editdata['status'] = 3;
        } else if ($_GET['edityuyue4']) {
            $editdata['status'] = 4;
        }
        
        if ($editdata['id'] > 0) {
            $result = DB::update('zimu_marry_yuyue', $editdata, array(
                'id' => $editdata['id'],
                'sid' => $myshopdata['id']
            ));
        } else {

            $editdata['sid']    = $myshopdata['id'];
            $editdata['name']    = strip_tags($_GET['name']);
            $editdata['phone']   = strip_tags($_GET['phone']);
            $editdata['content'] = strip_tags($_GET['content']);
            $editdata['addtime'] = $_G['timestamp'];
            $result              = DB::insert('zimu_marry_yuyue', $editdata);
        }
        
        include template('zimu_marry:common/success');
        
    } else {

        $page   = $_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;
        $page   = intval($page);
        $status = $_GET['status'] = $_GET['status'] ? $_GET['status'] : 1;
        $status = intval($status);
        
        $wheresql = ' where sid='.$myshopdata['id'].' and status=' . $status;
        
        $count = DB::result_first("SELECT count(*) FROM %t" . $wheresql, array(
            "zimu_marry_yuyue"
        ));
        
        $limit    = 20;
        $start    = ($page - 1) * $limit;
        $page_num = ceil($count / $limit);
        
        
        $yuyuedata = DB::fetch_all('select * from %t ' . $wheresql . ' order by id desc limit %d,%d', array(
            'zimu_marry_yuyue',
            $start,
            $limit
        ));

        $multipage = pagination($count, $page, $limit);
        
        include zimu_template('members/members_yuyue');
        
    }
    
    
} else if ($op == 'delyuyue' && $_GET['md5formhash'] = formhash()) {
    
    $delid  = intval($_GET['delid']);
    $result = DB::delete('zimu_marry_yuyue', array(
        'id' => $delid,
        'sid' => $myshopdata['id']
    ));
    include template('zimu_marry:common/success');
}