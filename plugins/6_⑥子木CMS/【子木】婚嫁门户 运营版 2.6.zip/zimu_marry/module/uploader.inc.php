<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if(!$_G['uid']){
    exit;
}
$maxwidth = 800;
$maxheight = 1200;

function resizeImage($fromfile ,$maxwidth,$maxheight, $name, $filetype)
{
    if(!function_exists('imagejpeg')){
        return false;
    }

    $imagefunc = 'imagejpeg';
    $imagecreatefromfunc = 'imagecreatefromjpeg';
    switch($filetype) {
        case 'image/jpeg':
            $imagecreatefromfunc = function_exists('imagecreatefromjpeg') ? 'imagecreatefromjpeg' : '';
            $imagefunc = function_exists('imagejpeg') ? 'imagejpeg' : '';
            break;
        case 'image/gif':
            $imagecreatefromfunc = function_exists('imagecreatefromgif') ? 'imagecreatefromgif' : '';
            $imagefunc = function_exists('imagegif') ? 'imagegif' : '';
            break;
        case 'image/png':
            $imagecreatefromfunc = function_exists('imagecreatefrompng') ? 'imagecreatefrompng' : '';
            $imagefunc = function_exists('imagepng') ? 'imagepng' : '';
            break;
    }

    $im = $imagecreatefromfunc($fromfile);
    $pic_width = imagesx($im);
    $pic_height = imagesy($im);

    if(($maxwidth && $pic_width > $maxwidth) || ($maxheight && $pic_height > $maxheight))
    {
        if($maxwidth && $pic_width>$maxwidth)
        {
            $widthratio = $maxwidth/$pic_width;
            $resizewidth_tag = true;
        }
        if($maxheight && $pic_height>$maxheight)
        {
            $heightratio = $maxheight/$pic_height;
            $resizeheight_tag = true;
        }
        if($resizewidth_tag && $resizeheight_tag)
        {
            if($widthratio<$heightratio)
                $ratio = $widthratio;
            else
                $ratio = $heightratio;
        }
        if($resizewidth_tag && !$resizeheight_tag)
            $ratio = $widthratio;
        if($resizeheight_tag && !$resizewidth_tag)
            $ratio = $heightratio;
        $newwidth = $pic_width * $ratio;
        $newheight = $pic_height * $ratio;
        if(function_exists("imagecopyresampled"))
        {
            $newim = imagecreatetruecolor($newwidth,$newheight);
            imagecopyresampled($newim,$im,0,0,0,0,$newwidth,$newheight,$pic_width,$pic_height);
        }
        else
        {
            $newim = imagecreate($newwidth,$newheight);
            imagecopyresized($newim,$im,0,0,0,0,$newwidth,$newheight,$pic_width,$pic_height);
        }

        $imagefunc($newim, $name);
        imagedestroy($newim);
    }
    else
    {
        $imagefunc($im,$name);
    }
    @unlink($fromfile);
    return filesize($name)>0 ? $name : false;
}


if(submitcheck('formhash', 1) && $_GET['formhash'] == $formhash){

    echo $res = zm_saveimages($_FILES['file']);exit();


}