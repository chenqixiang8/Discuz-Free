<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$op = addslashes($_GET['op']);
$op = $op ? $op : 'list';

$parameterdata = zimu_readfromcache('table_plugin_zimu_marry_parameter');

if (!$parameterdata) {
    $parameterdata = DB::fetch_all('select * from %t order by id asc', array(
        'zimu_marry_parameter'
    ));
    zimu_writetocache('table_plugin_zimu_marry_parameter', $parameterdata);
}
foreach ($parameterdata as $key => $value) {
    $parameterdata2[$parameterdata[$key]['ename']] = explode(",", $parameterdata[$key]['value']);
}

if ($op == 'edit') {
    
    if (submitcheck('submit')) {

        $data['mtype']         = intval($_GET['mtype']);
        $data['sid']         = intval($_GET['sid']);
        $data['mintitle']        = strip_tags($_GET['mintitle']);
        $data['color']        = strip_tags($_GET['mintitle_color']);
        $data['title']        = strip_tags($_GET['title']);
        if ($_FILES['thumb']['tmp_name']) {
            $data['thumb'] = zm_saveimages($_FILES['thumb']);
        }
        $data['starttime'] = strtotime($_GET['starttime']);
        $data['endtime'] = strtotime($_GET['endtime']);
        $data['con']    = dhtmlspecialchars($_GET['con']);
        $data['recommend']   = intval($_GET['recommend']);
        $data['sort']   = intval($_GET['sort']);
        $data['views']   = intval($_GET['views']);
        $data['addtime'] = strtotime($_GET['addtime']);
        $data['id']      = intval($_GET['ids']);        
        
        if ($data['id'] > 0) {
            
            DB::update('zimu_marry_activity', $data, array(
                'id' => $data['id']
            ));
            
        } else {
            
            $result = DB::insert('zimu_marry_activity', $data, 1);
            
        }
        
        
        include template('zimu_marry:common/success');
        
        
    } else {
        
        $ids = intval($_GET['ids']);
        
        $listdata = DB::fetch_first('select * from %t where id=%d', array(
            'zimu_marry_activity',
            $ids
        ));
        
        include zimu_template('admins/admins_' . $type);
        
    }

} else if ($op == 'del' && $_GET['md5hash'] == formhash()) {
    
    $ids = intval($_GET['ids']);
    
    $result = DB::delete('zimu_marry_activity', array(
        'id' => $ids
    ));
    
    include template('zimu_marry:common/success');

} else if ($op == 'viewdata') {


    $aid = intval($_GET['ids']);

    $ac = addslashes($_GET['ac']);

    $page   = $_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;
    $page   = intval($page);
    $status = $_GET['status'] = $_GET['status'] ? $_GET['status'] : 1;
    $status = intval($status);

    $wheresql = ' where status=' . $status;

    if($aid){
        $wheresql .= ' and aid=' . $aid;
    }


if($ac=='toexcel'){

    $detail = '';

    $yuyuedata = DB::fetch_all('select name,phone,beizhu from %t ' . $wheresql . ' order by id desc', array(
        'zimu_marry_activityuser'
    ));

    foreach($yuyuedata as $key=>$value) {
        foreach($value as $key2 => $value2) {
            $value2 = preg_replace('/\s+/', ' ', $value2);
            $detail .= strlen($value2) > 11 && is_numeric($value2) ? '['.$value2.'],' : $value2.',';
        }
        $detail = $detail."\n";
    }

    $detail = "����,�绰,��ע,"."\n".$detail;
    $filename = date('Ymd', TIMESTAMP).'.csv';
    ob_end_clean();
    header('Content-Encoding: none');
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename='.$filename);
    header('Pragma: no-cache');
    header('Expires: 0');
    if($_G['charset'] != 'gbk') {
        $detail = diconv($detail, $_G['charset'], 'GBK');
    }
    echo $detail;
    exit();
}


  if (submitcheck('edityuyue') || submitcheck('edityuyue2') || submitcheck('edityuyue3') || submitcheck('edityuyue4')) {

      $editdata['id']     = intval($_GET['yuyueid']);
      $editdata['beizhu'] = strip_tags($_GET['beizhu']);

      if ($_GET['edityuyue2']) {
          $editdata['status'] = 2;
      } else if ($_GET['edityuyue3']) {
          $editdata['status'] = 3;
      } else if ($_GET['edityuyue4']) {
          $editdata['status'] = 4;
      }

      if ($editdata['id'] > 0) {
          $result = DB::update('zimu_marry_activityuser', $editdata, array(
              'id' => $editdata['id']
          ));
      } else {
          $editdata['name']    = strip_tags($_GET['name']);
          $editdata['phone']   = strip_tags($_GET['phone']);
          $editdata['addtime'] = $_G['timestamp'];
          $result              = DB::insert('zimu_marry_activityuser', $editdata);
      }

        include template('zimu_marry:common/success');

  } else {

        $count = DB::result_first("SELECT count(*) FROM %t" . $wheresql, array(
            "zimu_marry_activityuser"
        ));

        $limit    = 20;
        $start    = ($page - 1) * $limit;
        $page_num = ceil($count / $limit);


        $yuyuedata = DB::fetch_all('select * from %t ' . $wheresql . ' order by id desc limit %d,%d', array(
            'zimu_marry_activityuser',
            $start,
            $limit
        ));

        if ($page_num > 1) {
            $multipage = pagination($count, $page, $limit);
        }

        include zimu_template('admins/admins_activity_viewdata');

        }


} else {
    
    $wheresql = 'where 1=1 ';

    $keyword = trim($_GET['keyword']);
    if (!empty($keyword)) {
        $wheresql .= " and (`name` LIKE '%{$keyword}%') ";
    }
    
    $mtype = intval($_GET['mtype']);
    if ($mtype) {
        $wheresql .= ' and mtype=' . $mtype;
    }
    
    $pindex = max(1, intval($_GET['page']));
    $psize  = 10;
    
    $total = DB::result_first("SELECT count(*) FROM %t %i", array(
        "zimu_marry_activity",
        $wheresql
    ));
    
    $listdata = DB::fetch_all('select * from %t %i order by id desc limit %d,%d', array(
        'zimu_marry_activity',
        $wheresql,
        ($pindex - 1) * $psize,
        $psize
    ));
    
    
    $pager = pagination($total, $pindex, $psize);
    
    
    include zimu_template('admins/admins_' . $type);
    
    
}