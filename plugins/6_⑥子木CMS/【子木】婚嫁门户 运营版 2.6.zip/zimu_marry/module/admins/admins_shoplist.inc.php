<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$op = addslashes($_GET['op']);
$op = $op ? $op : 'list';

$parameterdata = zimu_readfromcache('table_plugin_zimu_marry_parameter');

if (!$parameterdata) {
    $parameterdata = DB::fetch_all('select * from %t order by id asc', array(
        'zimu_marry_parameter'
    ));
    zimu_writetocache('table_plugin_zimu_marry_parameter', $parameterdata);
}
foreach ($parameterdata as $key => $value) {
    $parameterdata2[$parameterdata[$key]['ename']] = explode(",", $parameterdata[$key]['value']);
}

if ($op == 'edit') {
    
    if (submitcheck('submit')) {

        $data_url = array_filter($_GET['data_url']);

        if(is_array($data_url)){
        $len      = count($data_url);
        }

        $data2 = array();
        for ($k = 0; $k < $len; $k++) {

    $data_img['name'] = $_FILES['data_img']['name'][$k];
    $data_img['type'] = $_FILES['data_img']['type'][$k];
    $data_img['tmp_name'] = $_FILES['data_img']['tmp_name'][$k];
    $data_img['error'] = $_FILES['data_img']['error'][$k];
    $data_img['size'] = $_FILES['data_img']['size'][$k];
    $upimgurl = zm_saveimages($data_img);
            $data2[$k]['data_img'] = $upimgurl ? $upimgurl : $_GET['img_data_img'][$k];
            $data2[$k]['data_url'] = $data_url[$k];
        }

        $data['type']         = intval($_GET['main_type']);   
        $data['quyu']         = intval($_GET['quyu']);  
        $data['uid']         = intval($_GET['uid']);
        $data['name']        = strip_tags($_GET['name']);
        $data['hotel_stars'] = intval($_GET['hotel_stars']);
        $data['hotel_table'] = intval($_GET['hotel_table']);
        if ($_FILES['thumb']['tmp_name']) {
            $data['thumb'] = zm_saveimages($_FILES['thumb']);
        }
        $data['intro']    = dhtmlspecialchars($_GET['intro']);
        $data['notice']   = strip_tags($_GET['notice']);
        $data['shopgift'] = strip_tags($_GET['shopgift']);
        $data['banners'] = serialize($data2);
        $data['address']  = strip_tags($_GET['address']);
        $data['lng']      = strip_tags($_GET['lng']);
        $data['lat']      = strip_tags($_GET['lat']);
        $data['tel']      = strip_tags($_GET['tel']);
        if ($_FILES['qrcode']['tmp_name']) {
            $data['qrcode'] = zm_saveimages($_FILES['qrcode']);
        }
        $data['views']   = intval($_GET['views']);
        $data['sort']    = intval($_GET['sort']);
        $data['openid']    = strip_tags($_GET['openid']);
        $data['status']      = intval($_GET['status']);
        $data['recommend']      = intval($_GET['recommend']);
        $data['addtime'] = strtotime($_GET['addtime']);
        $data['id']      = intval($_GET['ids']);
        
        
        
        if ($data['id'] > 0) {

            DB::update('zimu_marry_shop', $data, array(
                'id' => $data['id']
            ));
            
        } else {
            
            $result = DB::insert('zimu_marry_shop', $data, 1);
            
        }
        
        
        include template('zimu_marry:common/success');
        
        
    } else {
        
        $ids = intval($_GET['ids']);
        
        $listdata = DB::fetch_first('select * from %t where id=%d', array(
            'zimu_marry_shop',
            $ids
        ));
        
        $banners = unserialize($listdata['banners']);

        include zimu_template('admins/admins_' . $type);
        
    }
    
    
} else if ($op == 'del' && $_GET['md5hash'] == formhash()) {
    
    $ids = intval($_GET['ids']);
    
    $result = DB::delete('zimu_marry_shop', array(
        'id' => $ids
    ));
    
    include template('zimu_marry:common/success');
    
} else if ($op == 'halllist') {

    $sid = intval($_GET['sid']);

    $wheresql = 'where sid='.$sid;
    
    $pindex = max(1, intval($_GET['page']));
    $psize  = 15;
    
    $total = DB::result_first("SELECT count(*) FROM %t %i", array(
        "zimu_marry_hotel_hall",
        $wheresql
    ));
    
    $listdata = DB::fetch_all('select * from %t %i order by sort desc,id desc limit %d,%d', array(
        'zimu_marry_hotel_hall',
        $wheresql,
        ($pindex - 1) * $psize,
        $psize
    ));
    
    
    $pager = pagination($total, $pindex, $psize);
    
    
    include zimu_template('admins/admins_halllist');

} else if ($op == 'edithall') {

    if (submitcheck('submit')) {

        $data['sid']    = intval($_GET['sid']);
        $data['name']        = strip_tags($_GET['name']);
        if ($_FILES['thumb']['tmp_name']) {
            $data['thumb'] = zm_saveimages($_FILES['thumb']);
        }
        $data['min_table']    = intval($_GET['min_table']);
        $data['max_table']    = intval($_GET['max_table']);
        $data['area']   = strip_tags($_GET['area']);
        $data['height']   = strip_tags($_GET['height']);
        $data['pillar']   = strip_tags($_GET['pillar']);
        $data['con']    = dhtmlspecialchars($_GET['con']);
        $data['sort']    = intval($_GET['sort']);
        $data['id']      = intval($_GET['ids']);
        
        
        if ($data['id'] > 0) {
            
            DB::update('zimu_marry_hotel_hall', $data, array(
                'id' => $data['id']
            ));
            
        } else {
            
            $result = DB::insert('zimu_marry_hotel_hall', $data, 1);
            
        }
        
        
        include template('zimu_marry:common/success');
        
        
    } else {

        $sid = intval($_GET['sid']);        
        $ids = intval($_GET['ids']);
        
        $listdata = DB::fetch_first('select * from %t where id=%d', array(
            'zimu_marry_hotel_hall',
            $ids
        ));
        
        include zimu_template('admins/admins_halllist');
        
    }

} else if ($op == 'delhall' && $_GET['md5hash'] == formhash()) {
    
    $ids = intval($_GET['ids']);
    
    $result = DB::delete('zimu_marry_hotel_hall', array(
        'id' => $ids
    ));
    
    include template('zimu_marry:common/success');

} else if ($op == 'menulist') {

    $sid = intval($_GET['sid']);

    $wheresql = 'where sid='.$sid;
    
    $pindex = max(1, intval($_GET['page']));
    $psize  = 15;
    
    $total = DB::result_first("SELECT count(*) FROM %t %i", array(
        "zimu_marry_hotel_menu",
        $wheresql
    ));
    
    $listdata = DB::fetch_all('select * from %t %i order by sort desc,id desc limit %d,%d', array(
        'zimu_marry_hotel_menu',
        $wheresql,
        ($pindex - 1) * $psize,
        $psize
    ));
    
    
    $pager = pagination($total, $pindex, $psize);
    
    include zimu_template('admins/admins_menulist');

} else if ($op == 'editmenu') {

    if (submitcheck('submit')) {

        $data['sid']    = intval($_GET['sid']);
        $data['name']        = strip_tags($_GET['name']);
        $data['price']   = strip_tags($_GET['price']);
        $data['con']    = dhtmlspecialchars($_GET['con']);
        $data['sort']    = intval($_GET['sort']);
        $data['id']      = intval($_GET['ids']);
        
        if ($data['id'] > 0) {
            
            DB::update('zimu_marry_hotel_menu', $data, array(
                'id' => $data['id']
            ));
            
        } else {
            
            $result = DB::insert('zimu_marry_hotel_menu', $data, 1);
            
        }

        $shopdata = DB::fetch_first('select * from %t where id=%d order by id desc', array(
            'zimu_marry_shop',
            $data['sid']
        ));

        $hotel_minprice = DB::result_first('select price from %t where sid=%d order by price+0 asc', array(
            'zimu_marry_hotel_menu',
            $data['sid']
        ));

        $hotel_maxprice = DB::result_first('select price from %t where sid=%d order by price+0 desc', array(
            'zimu_marry_hotel_menu',
            $data['sid']
        ));


        if($shopdata['hotel_minprice'] != $hotel_minprice){
            DB::query("update %t set hotel_minprice=%d where id=%d", array(
                'zimu_marry_shop',
                $data['price'],
                $data['sid']
            ));
        }
        if($shopdata['hotel_maxprice'] != $hotel_maxprice){
            DB::query("update %t set hotel_maxprice=%d where id=%d", array(
                'zimu_marry_shop',
                $data['price'],
                $data['sid']
            ));
        }
        
        include template('zimu_marry:common/success');
        
        
    } else {

        $sid = intval($_GET['sid']);       
        $ids = intval($_GET['ids']);
        
        $listdata = DB::fetch_first('select * from %t where id=%d', array(
            'zimu_marry_hotel_menu',
            $ids
        ));
        
        include zimu_template('admins/admins_menulist');
        
    }

} else if ($op == 'delmenu' && $_GET['md5hash'] == formhash()) {
    
    $ids = intval($_GET['ids']);
    
    $result = DB::delete('zimu_marry_hotel_menu', array(
        'id' => $ids
    ));
    
    include template('zimu_marry:common/success');

} else if ($op == 'serieslist') {

    $sid = intval($_GET['sid']);

    $wheresql = 'where sid='.$sid;

    $keyword = trim($_GET['keyword']);
    if (!empty($keyword)) {
        $wheresql .= " and (`name` LIKE '%{$keyword}%') ";
    }

    $pindex = max(1, intval($_GET['page']));
    $psize  = 15;
    
    $total = DB::result_first("SELECT count(*) FROM %t %i", array(
        "zimu_marry_shop_series",
        $wheresql
    ));
    
    $listdata = DB::fetch_all('select * from %t %i order by sort desc,id desc limit %d,%d', array(
        'zimu_marry_shop_series',
        $wheresql,
        ($pindex - 1) * $psize,
        $psize
    ));
    
    
    $pager = pagination($total, $pindex, $psize);
    
    include zimu_template('admins/admins_serieslist');

} else if ($op == 'editseries') {


    if (submitcheck('submit')) {

        $data['sid']    = intval($_GET['sid']);
        $data['name']        = strip_tags($_GET['name']);
        $data['price']   = strip_tags($_GET['price']);
        $data['marketprice']   = strip_tags($_GET['marketprice']);
        if ($_FILES['thumb']['tmp_name']) {
            $data['thumb'] = zm_saveimages($_FILES['thumb']);
        }
        $data['pszs']    = intval($_GET['series1_pszs']);
        $data['rczs']    = intval($_GET['series1_rczs']);
        $data['fzzx']    = intval($_GET['series1_fzzx']);
        $data['paramter'] = serialize($_GET['options']);
        $data['seriesgift']   = strip_tags($_GET['seriesgift']);
        $data['con']    = dhtmlspecialchars($_GET['con']);
        $data['sort']    = intval($_GET['sort']);
        $data['views']    = intval($_GET['views']);
        $data['recommend']    = intval($_GET['recommend']);
        $data['addtime'] = strtotime($_GET['addtime']);
        $data['id']      = intval($_GET['ids']);
        
        
        if ($data['id'] > 0) {

    $total = DB::result_first("SELECT count(*) FROM %t where sid=%d", array(
        "zimu_marry_shop_series",
        $data['sid']
    ));

    DB::query("update %t set series=%d where id=%d", array(
        'zimu_marry_shop',
        $total,
        $data['sid']
    ));

            DB::update('zimu_marry_shop_series', $data, array(
                'id' => $data['id']
            ));
            
        } else {

    $total = DB::result_first("SELECT count(*) FROM %t where sid=%d", array(
        "zimu_marry_shop_series",
        $data['sid']
    ));

    DB::query("update %t set series=%d where id=%d", array(
        'zimu_marry_shop',
        $total+1,
        $data['sid']
    ));

            $result = DB::insert('zimu_marry_shop_series', $data, 1);
            
        }
        
        
        include template('zimu_marry:common/success');
        
        
    } else {

        $sid = intval($_GET['sid']);
        $ids = intval($_GET['ids']);

        $listdata = DB::fetch_first('select * from %t where id=%d', array(
            'zimu_marry_shop_series',
            $ids
        ));

        $shopdata = DB::fetch_first('select * from %t where id=%d', array(
            'zimu_marry_shop',
            $sid
        ));

        $paramter = unserialize($listdata['paramter']);

        include zimu_template('admins/admins_serieslist');
        
    }

} else if ($op == 'delseries' && $_GET['md5hash'] == formhash()) {
    
    $ids = intval($_GET['ids']);
    
    $result = DB::delete('zimu_marry_shop_series', array(
        'id' => $ids
    ));
    
    include template('zimu_marry:common/success');

} else if ($op == 'photolist') {

    $sid = intval($_GET['sid']);

    $wheresql = 'where sid='.$sid;

    $keyword = trim($_GET['keyword']);
    if (!empty($keyword)) {
        $wheresql .= " and (`name` LIKE '%{$keyword}%') ";
    }

    $pindex = max(1, intval($_GET['page']));
    $psize  = 15;
    
    $total = DB::result_first("SELECT count(*) FROM %t %i", array(
        "zimu_marry_shop_photo",
        $wheresql
    ));
    
    $listdata = DB::fetch_all('select * from %t %i order by sort desc,id desc limit %d,%d', array(
        'zimu_marry_shop_photo',
        $wheresql,
        ($pindex - 1) * $psize,
        $psize
    ));
    
    
    $pager = pagination($total, $pindex, $psize);
    
    include zimu_template('admins/admins_photolist');

} else if ($op == 'editphoto') {

    if (submitcheck('submit')) {

        $data['sid']    = intval($_GET['sid']);
        $data['name']        = strip_tags($_GET['name']);
        if ($_FILES['thumb']['tmp_name']) {
            $data['thumb'] = zm_saveimages($_FILES['thumb']);
        }
        $data['paramter'] = serialize($_GET['options']);
        $data['con']    = dhtmlspecialchars($_GET['con']);
        $data['sort']    = intval($_GET['sort']);
        $data['views']    = intval($_GET['views']);
        $data['recommend']    = intval($_GET['recommend']);
        $data['addtime'] = strtotime($_GET['addtime']);
        $data['id']      = intval($_GET['ids']);
        
        
        if ($data['id'] > 0) {

    $total = DB::result_first("SELECT count(*) FROM %t where sid=%d", array(
        "zimu_marry_shop_photo",
        $data['sid']
    ));

    DB::query("update %t set photo=%d where id=%d", array(
        'zimu_marry_shop',
        $total,
        $data['sid']
    ));

            DB::update('zimu_marry_shop_photo', $data, array(
                'id' => $data['id']
            ));
            
        } else {
            
            $result = DB::insert('zimu_marry_shop_photo', $data, 1);
            
        }
        
        
        include template('zimu_marry:common/success');
        
        
    } else {

        $sid = intval($_GET['sid']);
        $ids = intval($_GET['ids']);

        $listdata = DB::fetch_first('select * from %t where id=%d', array(
            'zimu_marry_shop_photo',
            $ids
        ));

        $shopdata = DB::fetch_first('select * from %t where id=%d', array(
            'zimu_marry_shop',
            $sid
        ));

        $paramter = unserialize($listdata['paramter']);

        include zimu_template('admins/admins_photolist');
        
    }

} else {
    
    $wheresql = 'where 1=1 ';
    
    $keyword = trim($_GET['keyword']);
    if (!empty($keyword)) {
        $wheresql .= " and (`name` LIKE '%{$keyword}%') ";
    }
    
    $main_type = intval($_GET['mtype']);
    if ($main_type) {
        $wheresql .= ' and type=' . $main_type;
    }
    
    $pindex = max(1, intval($_GET['page']));
    $psize  = 10;
    
    $total = DB::result_first("SELECT count(*) FROM %t %i", array(
        "zimu_marry_shop",
        $wheresql
    ));
    
    $listdata = DB::fetch_all('select * from %t %i order by id desc limit %d,%d', array(
        'zimu_marry_shop',
        $wheresql,
        ($pindex - 1) * $psize,
        $psize
    ));
    
    
    $pager = pagination($total, $pindex, $psize);
    
    
    include zimu_template('admins/admins_' . $type);
    
    
    
}