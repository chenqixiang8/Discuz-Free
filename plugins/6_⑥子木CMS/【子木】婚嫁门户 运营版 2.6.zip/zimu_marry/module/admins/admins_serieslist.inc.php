<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$op = addslashes($_GET['op']);
$op = $op ? $op : 'list';

$parameterdata = zimu_readfromcache('table_plugin_zimu_marry_parameter');

if (!$parameterdata) {
    $parameterdata = DB::fetch_all('select * from %t order by id asc', array(
        'zimu_marry_parameter'
    ));
    zimu_writetocache('table_plugin_zimu_marry_parameter', $parameterdata);
}
foreach ($parameterdata as $key => $value) {
    $parameterdata2[$parameterdata[$key]['ename']] =  explode(",",$parameterdata[$key]['value']);
}

if($op == 'edit'){

if(submitcheck('submit')) {

        $data['uid'] = intval($_GET['uid']);
        $data['name'] = strip_tags($_GET['name']);
        $data['hotel_stars'] = intval($_GET['hotel_stars']);
        $data['hotel_table'] = intval($_GET['hotel_table']);
        if ($_FILES['thumb']['tmp_name']) {
            $data['thumb'] = zm_saveimages($_FILES['thumb']);
        }
        $data['intro'] = dhtmlspecialchars($_GET['intro']);
        $data['notice'] = strip_tags($_GET['notice']);
        $data['shopgift'] = strip_tags($_GET['shopgift']);
        $data['address'] = strip_tags($_GET['address']);
        $data['lng'] = strip_tags($_GET['lng']);
        $data['lat'] = strip_tags($_GET['lat']);
        $data['tel'] = strip_tags($_GET['tel']);
        if ($_FILES['qrcode']['tmp_name']) {
            $data['qrcode'] = zm_saveimages($_FILES['qrcode']);
        }
        $data['views'] = intval($_GET['views']);
        $data['sort'] = intval($_GET['sort']);
        $data['addtime'] = strtotime($_GET['addtime']);
        $data['id'] = intval($_GET['ids']);



if($data['id']>0){

        DB::update('zimu_marry_shop', $data, array(
                'id' => $data['id'],
                ));

}else{

        $result = DB::insert('zimu_marry_shop',$data,1);

}


        include template('zimu_marry:common/success');


}else{

$ids = intval($_GET['ids']);

$listdata = DB::fetch_first('select * from %t where id=%d', array(
        'zimu_marry_shop',
        $ids
    ));

include zimu_template('admins/admins_' . $type);

}


}else if ($op == 'del' && $_GET['md5hash'] == formhash() ) {

	$ids = intval($_GET['ids']);
    
    $result = DB::delete('zimu_marry_shop', array(
        'id' => $ids
    ));

    include template('zimu_marry:common/success');


}else{

    $wheresql = 'where 1=1 ';

    $keyword = trim($_GET['keyword']);
    if(!empty($keyword)) {
        $wheresql .= " and (`name` LIKE '%{$keyword}%') ";
    }

$main_type = intval($_GET['mtype']);
if($main_type){
    $wheresql .= ' and type='.$main_type;
}

$pindex = max(1, intval($_GET['page']));
$psize = 15;

$total = DB::result_first("SELECT count(*) FROM %t %i", array(
    "zimu_marry_shop_series",
    $wheresql
));

$listdata = DB::fetch_all('select * from %t %i order by id desc limit %d,%d', array(
        'zimu_marry_shop_series',
        $wheresql,
        ($pindex - 1) * $psize,
        $psize
    ));


    $pager = pagination($total, $pindex, $psize);


include zimu_template('admins/admins_' . $type);


}