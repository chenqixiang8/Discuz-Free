<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$op = addslashes($_GET['op']);
$op = $op ? $op : 'list';

$catdata = DB::fetch_all('select * from %t order by sort desc,id asc', array(
    'zimu_marry_news_cat'
));

if ($op == 'edit') {
    
    if (submitcheck('submit')) {

        $data['cid']         = intval($_GET['cid']);   
        $data['name']        = strip_tags($_GET['name']);
        if ($_FILES['thumb']['tmp_name']) {
            $data['thumb'] = zm_saveimages($_FILES['thumb']);
        }
        $data['cname'] = DB::result_first('select name from %t where id=%d', array(
            'zimu_marry_news_cat',
            $data['cid']
        ));
        $data['con']    = dhtmlspecialchars($_GET['con']);
        $data['views']   = intval($_GET['views']);
        $data['addtime'] = strtotime($_GET['addtime']);
        $data['id']      = intval($_GET['ids']);
        
        
        
        if ($data['id'] > 0) {
            
            DB::update('zimu_marry_news_list', $data, array(
                'id' => $data['id']
            ));
            
        } else {
            
            $result = DB::insert('zimu_marry_news_list', $data, 1);
            
        }
        
        
        include template('zimu_marry:common/success');
        
        
    } else {
        
        $ids = intval($_GET['ids']);
        
        $listdata = DB::fetch_first('select * from %t where id=%d', array(
            'zimu_marry_news_list',
            $ids
        ));
        
        include zimu_template('admins/admins_' . $type);
        
    }

} else if ($op == 'del' && $_GET['md5hash'] == formhash()) {
    
    $ids = intval($_GET['ids']);
    
    $result = DB::delete('zimu_marry_news_list', array(
        'id' => $ids
    ));
    
    include template('zimu_marry:common/success');
    
} else if ($op == 'catlist') {
    
    $pindex = max(1, intval($_GET['page']));
    $psize  = 15;
    
    $total = DB::result_first("SELECT count(*) FROM %t", array(
        "zimu_marry_news_cat"
    ));
    
    $listdata = DB::fetch_all('select * from %t order by sort desc,id asc limit %d,%d', array(
        'zimu_marry_news_cat',
        ($pindex - 1) * $psize,
        $psize
    ));
    
    
    $pager = pagination($total, $pindex, $psize);
    
    
    include zimu_template('admins/admins_catlist');

} else if ($op == 'editcat') {

    if (submitcheck('submit')) {


        $data['name']        = strip_tags($_GET['name']);
        $data['sort']    = intval($_GET['sort']);
        $data['id']      = intval($_GET['ids']);
        
        
        if ($data['id'] > 0) {
            
            DB::update('zimu_marry_news_cat', $data, array(
                'id' => $data['id']
            ));
            
        } else {
            
            $result = DB::insert('zimu_marry_news_cat', $data, 1);
            
        }
        
        
        include template('zimu_marry:common/success');
        
        
    } else {
     
        $ids = intval($_GET['ids']);
        
        $listdata = DB::fetch_first('select * from %t where id=%d', array(
            'zimu_marry_news_cat',
            $ids
        ));
        
        include zimu_template('admins/admins_catlist');
        
    }

} else if ($op == 'delcat' && $_GET['md5hash'] == formhash()) {
    
    $ids = intval($_GET['ids']);
    
    $result = DB::delete('zimu_marry_news_cat', array(
        'id' => $ids
    ));
    
    include template('zimu_marry:common/success');

} else {
    
    $wheresql = 'where 1=1 ';

    $keyword = trim($_GET['keyword']);
    if (!empty($keyword)) {
        $wheresql .= " and (`name` LIKE '%{$keyword}%') ";
    }
    
    $cid = intval($_GET['cid']);
    if ($cid) {
        $wheresql .= ' and cid=' . $cid;
    }
    
    $pindex = max(1, intval($_GET['page']));
    $psize  = 10;
    
    $total = DB::result_first("SELECT count(*) FROM %t %i", array(
        "zimu_marry_news_list",
        $wheresql
    ));
    
    $listdata = DB::fetch_all('select * from %t %i order by id desc limit %d,%d', array(
        'zimu_marry_news_list',
        $wheresql,
        ($pindex - 1) * $psize,
        $psize
    ));
    
    
    $pager = pagination($total, $pindex, $psize);
    
    
    include zimu_template('admins/admins_' . $type);
    
    
}