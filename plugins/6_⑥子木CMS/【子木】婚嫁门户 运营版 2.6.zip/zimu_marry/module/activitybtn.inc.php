<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$magapp_paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
    'zimu_marry_parameter2',
    'magapp'
));

$magapp_paramter = unserialize($magapp_paramter['parameter']);

if ($_GET['md5hash'] == formhash()) {
    
    $adddata['sid']      = intval($_GET['sid']);
    $adddata['aid']      = intval($_GET['aid']);
    $adddata['aidtitle'] = addslashes($_GET['aidtitle']);
    $adddata['name']     = addslashes($_GET['name']);
    $adddata['phone']    = addslashes($_GET['phone']);
    $adddata['addtime']  = $_G['timestamp'];

    if ($adddata['name'] && $adddata['phone']) {
        
        DB::insert('zimu_marry_activityuser', $adddata);
        
        echo json_encode(array(
            'status' => 1
        ));
        
        $weixin_openid = trim($zmdata['settings']['weixin_openid']);
        $weixin_openid = explode(',', $weixin_openid);
        foreach ($weixin_openid as $key => $value) {
            $template = array(
                'touser' => $value,
                'template_id' => $zmdata['settings']['weixin_template'],
                'url' => '',
                'topcolor' => "#7B68EE",
                'data' => array(
                    'first' => array(
                        'value' => urlencode(diconv($language_zimu['activitybtn_inc_php_0'], CHARSET, 'utf-8')),
                        'color' => "#FF4040"
                    ),
                    'keyword1' => array(
                        'value' => urlencode(diconv(strip_tags(zm_diconv($adddata['aidtitle'])), CHARSET, 'utf-8'))
                    ),
                    'keyword2' => array(
                        'value' => urlencode(diconv(strip_tags(zm_diconv($adddata['aidtitle'])), CHARSET, 'utf-8'))
                    ),
                    'remark' => array(
                        'value' => urlencode(diconv(strip_tags(zm_diconv($adddata['name'])) . strip_tags($adddata['phone']) . str_replace('<br>', '', strip_tags(zm_diconv($_GET['moreinfo']))), CHARSET, 'utf-8')),
                        'color' => "#008000"
                    )
                    
                )
            );
            $json     = urldecode(json_encode($template));
            if ($adddata['name'] && $adddata['phone']) {
                $result = $wechat_client->send_weixintemplate($json);
            }
        }
        
        if ($adddata['sid']) {
            $shopopenid  = DB::fetch_first('select * from %t where id=%d order by id desc', array(
                'zimu_marry_shop',
                $adddata['sid']
            ));
            $shopopenids = explode(',', trim($shopopenid['openid']));
            foreach ($shopopenids as $key => $value) {
                $template = array(
                    'touser' => $value,
                    'template_id' => $zmdata['settings']['weixin_template'],
                    'url' => '',
                    'topcolor' => "#7B68EE",
                    'data' => array(
                        'first' => array(
                            'value' => urlencode(diconv($language_zimu['activitybtn_inc_php_1'], CHARSET, 'utf-8')),
                            'color' => "#FF4040"
                        ),
                        'keyword1' => array(
                            'value' => urlencode(diconv(strip_tags(zm_diconv($adddata['aidtitle'])), CHARSET, 'utf-8'))
                        ),
                        'keyword2' => array(
                            'value' => urlencode(diconv(strip_tags(zm_diconv($adddata['aidtitle'])), CHARSET, 'utf-8'))
                        ),
                        'remark' => array(
                            'value' => urlencode(diconv(strip_tags(zm_diconv($adddata['name'])) . strip_tags($adddata['phone']) . str_replace('<br>', '', strip_tags(zm_diconv($_GET['moreinfo']))), CHARSET, 'utf-8')),
                            'color' => "#008000"
                        )
                        
                    )
                );
                $json     = urldecode(json_encode($template));
                if ($adddata['name'] && $adddata['phone']) {
                    $result = $wechat_client->send_weixintemplate($json);
                }
            }
            
            
            if ($magapp_paramter['magapp_hostname'] && $magapp_paramter['magapp_secret']) {
                
                $magurl                               = $magapp_paramter['magapp_hostname'] . '/mag/operative/v1/assistant/sendAssistantMsg';
                $magpostdata['user_id']               = $shopopenid['uid'];
                $magpostdata['type']                  = 'remind';
                $magapp_paramter['assistant_content'] = str_replace('#type#', $adddata['aidtitle'], $magapp_paramter['assistant_content']);
                $magapp_paramter['assistant_content'] = str_replace('#name#', $adddata['name'], $magapp_paramter['assistant_content']);
                $magapp_paramter['assistant_content'] = str_replace('#phone#', $adddata['phone'], $magapp_paramter['assistant_content']);
                $magpostdata['content']               = diconv($magapp_paramter['assistant_content'], CHARSET, 'utf-8');
                $magpostdata['assistant_secret']      = $magapp_paramter['assistant_secret'];
                $magpostdata['secret']                = $magapp_paramter['magapp_secret'];
                $magpostdata['is_push']               = 1;
                $magdata                              = lizimu_post($magurl, $magpostdata);
                
            }
            
            
        }

        $magapp_uids = trim($magapp_paramter['magapp_uids']);
        $magapp_uids = explode(',', $magapp_uids);
        foreach ($magapp_uids as $key => $value) {
            
            if ($magapp_paramter['magapp_hostname'] && $magapp_paramter['magapp_secret']) {
                
                $magurl                               = $magapp_paramter['magapp_hostname'] . '/mag/operative/v1/assistant/sendAssistantMsg';
                $magpostdata['user_id']               = $value;
                $magpostdata['type']                  = 'remind';
                $magapp_paramter['assistant_content'] = str_replace('#type#', $adddata['aidtitle'], $magapp_paramter['assistant_content']);
                $magapp_paramter['assistant_content'] = str_replace('#name#', $adddata['name'], $magapp_paramter['assistant_content']);
                $magapp_paramter['assistant_content'] = str_replace('#phone#', $adddata['phone'], $magapp_paramter['assistant_content']);
                $magpostdata['content']               = diconv($magapp_paramter['assistant_content'], CHARSET, 'utf-8');
                $magpostdata['assistant_secret']      = $magapp_paramter['assistant_secret'];
                $magpostdata['secret']                = $magapp_paramter['magapp_secret'];
                $magpostdata['is_push']               = 1;
                $magdata                              = lizimu_post($magurl, $magpostdata);
                
            }
            
            
        }
        
    }
    
}