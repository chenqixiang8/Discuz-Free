<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

isuid();

$tosubmit = intval($_GET['tosubmit']);

	$isshop = DB::fetch_first('select * from %t where uid=%d order by id asc', array(
		'zimu_marry_shop',
		$_G['uid']
	));


    if ($tosubmit == 1 && $_GET['md5hash'] == formhash()) {


        $data['type']         = intval($_GET['form']['type'])+1;   
        $data['quyu']         = intval($_GET['form']['quyu'])+1;  
        $data['uid']         = $_G['uid'];
        $data['name']        = strip_tags(zm_diconv($_GET['form']['name']));
        $data['address']        = strip_tags(zm_diconv($_GET['form']['address']));
        $data['tel']      = strip_tags($_GET['form']['tel']);
        $data['shopgift']        = strip_tags(zm_diconv($_GET['form']['shopgift']));
        $data['notice']        = strip_tags(zm_diconv($_GET['form']['notice']));
        $data['intro']        = dhtmlspecialchars(zm_diconv($_GET['form']['intro']));
        $data['thumb']      = strip_tags($_GET['form']['logo']);
        $data['qrcode']      = strip_tags($_GET['form']['qr']);
        $data['status']         = 0;  
        $data['addtime']         = $_G['timestamp'];

if(!$data['name']){
$returnjson['code'] = 0;
$returnjson['msg'] = zimu_array_utf8($language_zimu['ruzhu_inc_php_0']);
echo json_encode($returnjson,true);exit();
}
if(!$data['type']){
$returnjson['code'] = 0;
$returnjson['msg'] = zimu_array_utf8($language_zimu['ruzhu_inc_php_1']);
echo json_encode($returnjson,true);exit();
}
if(!$data['quyu']){
$returnjson['code'] = 0;
$returnjson['msg'] = zimu_array_utf8($language_zimu['ruzhu_inc_php_2']);
echo json_encode($returnjson,true);exit();
}
if(!$data['address']){
$returnjson['code'] = 0;
$returnjson['msg'] = zimu_array_utf8($language_zimu['ruzhu_inc_php_3']);
echo json_encode($returnjson,true);exit();
}
if(!$data['intro']){
$returnjson['code'] = 0;
$returnjson['msg'] = zimu_array_utf8($language_zimu['ruzhu_inc_php_4']);
echo json_encode($returnjson,true);exit();
}
if(!$data['thumb'] || !$data['qrcode']){
$returnjson['code'] = 0;
$returnjson['msg'] = zimu_array_utf8('���ϴ��̼�logo��ͻ�΢�Ŷ�ά��');
echo json_encode($returnjson,true);exit();
}


if(!$isshop){
      $result = DB::insert('zimu_marry_shop', $data, 1);
}else{
        DB::update('zimu_marry_shop', $data, array(
            'id' => $isshop['id']
        ));
}


$returnjson['code'] = 1;
$returnjson['msg'] = zimu_array_utf8($language_zimu['ruzhu_inc_php_7']);
$returnjson['url'] = ZIMUCMS_URL;
echo json_encode($returnjson,true);exit();


    }else{

$parameterdata = zimu_readfromcache('table_plugin_zimu_marry_parameter');

if (!$parameterdata) {
	$parameterdata = DB::fetch_all('select * from %t order by id asc', array(
		'zimu_marry_parameter'
	));
	zimu_writetocache('table_plugin_zimu_marry_parameter', $parameterdata);
}

foreach ($parameterdata as $key => $value) {
	$parameterdata2[$parameterdata[$key]['ename']] =  explode(",",$parameterdata[$key]['value']);
	if(strpos($parameterdata[$key]['ename'],'type1_') !== false){
		$parameterdata2['type1'][$parameterdata[$key]['ename']] =  $value;
	}
}

$main_typearray = $parameterdata2['main_type'];
$quyuarray = $parameterdata2['quyu'];

    $shopdata = DB::fetch_first('select * from %t where uid=%d order by id asc', array(
        'zimu_marry_shop',
        $_G['uid']
    ));

include zimu_template('site_ruzhu');

    }