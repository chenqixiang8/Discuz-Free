<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$activity = DB::fetch_all("SHOW COLUMNS FROM %t", array('zimu_marry_activity'));
$activity_array = mysqltoarray($activity);
if (!in_array('mintitle', $activity_array)) {
    $sql1 = <<<EOF
ALTER TABLE  `pre_zimu_marry_activity` ADD COLUMN `mintitle` CHAR(30) NOT NULL;
EOF;
    runquery($sql1);
}
if (!in_array('color', $activity_array)) {
    $sql1 = <<<EOF
ALTER TABLE  `pre_zimu_marry_activity` ADD COLUMN `color` CHAR(30) NOT NULL;
EOF;
    runquery($sql1);
}

if (!in_array('status', zm_fieldexists('zimu_marry_shop'))) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimu_marry_shop` ADD `status` TINYINT(1) UNSIGNED NOT NULL DEFAULT '1';
EOF;
    runquery($sql1);
}

if (!in_array('typename', zm_fieldexists('zimu_marry_yuyue'))) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimu_marry_yuyue` ADD `typename` CHAR(20) NOT NULL;
EOF;
    runquery($sql1);
}

if (!in_array('uid', zm_fieldexists('zimu_marry_yuyue'))) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimu_marry_yuyue` ADD `uid` INT(10) UNSIGNED NOT NULL;
EOF;
    runquery($sql1);
}

    if (!in_array('recommend', zm_fieldexists('zimu_marry_shop'))) {
        $sql1 = <<<EOF
ALTER TABLE `pre_zimu_marry_shop` ADD `recommend` TINYINT(3) UNSIGNED NOT NULL;
EOF;
        runquery($sql1);
    }

    $sql1 = <<<EOF
    
CREATE TABLE IF NOT EXISTS `pre_zimu_marry_marryday` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` int(10) UNSIGNED NOT NULL,
  `username` char(30) NOT NULL,
  `tel` char(20) NOT NULL,
  `marrytime` int(10) UNSIGNED NOT NULL,
  `note` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

EOF;
    runquery($sql1);

deldirfile(DISCUZ_ROOT . "./source/plugin/zimu_marry/template/common/",true);
deldirfile(DISCUZ_ROOT . "./source/plugin/zimu_marry/template/touch/",true);
deldirfile(DISCUZ_ROOT . "./source/plugin/zimu_marry/template/admins/",true);
deldirfile(DISCUZ_ROOT . "./source/plugin/zimu_marry/template/members/",true);

$finish = TRUE;

function zm_fieldexists($table){
$field_list = DB::fetch_all("SHOW COLUMNS FROM %t", array($table));
$field_list_array = mysqltoarray($field_list);
return $field_list_array;
}
function mysqltoarray($test) {
    $temp = array();
    foreach ($test as $k => $s) {
        $temp[] = $s['Field'];
    }
    return $temp;
}
function deldirfile($directory, $empty = false) {
    if(substr($directory,-1) == "/") {
        $directory = substr($directory,0,-1);
    }

    if(!file_exists($directory) || !is_dir($directory)) {
        return false;
    } elseif(!is_readable($directory)) {
        return false;
    } else {
        @$directoryHandle = opendir($directory);

        while ($contents = @readdir($directoryHandle)) {
            if($contents != '.' && $contents != '..') {
                $path = $directory . "/" . $contents;

                if($contents != 'meta.htm' && $contents != 'footer_base.htm' && $contents != 'footer.htm' && $contents != 'header_base.htm' && $contents != 'success.htm'){

                    if(is_dir($path)) {
                        @deldirfile($path, $empty);
                    } else {
                        @unlink($path);
                    }
                }


            }
        }

        @closedir($directoryHandle);

        if($empty == false) {
            if(!@rmdir($directory)) {
                return false;
            }
        }

        return true;
    }
}