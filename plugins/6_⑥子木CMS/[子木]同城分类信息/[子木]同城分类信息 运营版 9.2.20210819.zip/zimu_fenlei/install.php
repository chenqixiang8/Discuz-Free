<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$sql = <<<SQL

CREATE TABLE IF NOT EXISTS `pre_zimu_fenlei_alltongji` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `users` int(10) UNSIGNED NOT NULL,
  `views` int(10) UNSIGNED NOT NULL,
  `pubs` int(10) UNSIGNED NOT NULL,
  `shop_nums` int(10) UNSIGNED NOT NULL,
  `shop_views` int(10) UNSIGNED NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimu_fenlei_cat` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) UNSIGNED NOT NULL,
  `name` char(30) NOT NULL,
  `icon` char(255) NOT NULL,
  `pid` int(10) UNSIGNED NOT NULL,
  `price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `endtime` int(10) UNSIGNED NOT NULL,
  `taocan_type` varchar(3000) NOT NULL,
  `tag` text NOT NULL,
  `isnav` tinyint(1) UNSIGNED NOT NULL,
  `url` char(255) NOT NULL,
  `status` tinyint(1) UNSIGNED NOT NULL DEFAULT '1',
  `list_tpl` tinyint(3) UNSIGNED NOT NULL,
  `cat_key` varchar(5000) NOT NULL,
  `cat_fid` char(100) NOT NULL,
  `sort` tinyint(3) UNSIGNED NOT NULL DEFAULT '100',
  `onlyadmin` tinyint(1) UNSIGNED NOT NULL,
  `onlysetmeal` tinyint(1) UNSIGNED NOT NULL,
  `share_refresh` int(10) UNSIGNED NOT NULL,
  `share_dig` int(10) UNSIGNED NOT NULL,
  `share_dig_days` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimu_fenlei_cat_diy` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `cid` int(10) UNSIGNED NOT NULL,
  `name` char(50) NOT NULL,
  `type` char(20) NOT NULL,
  `placeholder` char(100) NOT NULL,
  `extra` varchar(3000) NOT NULL,
  `max` smallint(3) UNSIGNED NOT NULL,
  `required` tinyint(1) UNSIGNED NOT NULL,
  `status` tinyint(1) UNSIGNED NOT NULL DEFAULT '1',
  `sort` tinyint(3) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimu_fenlei_mobilelog` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` int(10) UNSIGNED NOT NULL,
  `username` char(50) NOT NULL,
  `pid` int(10) UNSIGNED NOT NULL,
  `catname` char(50) NOT NULL,
  `see_type` tinyint(2) UNSIGNED NOT NULL DEFAULT '1',
  `addtime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimu_fenlei_mptpl` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `tpl` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;



CREATE TABLE IF NOT EXISTS `pre_zimu_fenlei_order` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `oid` varchar(200) NOT NULL,
  `uid` int(10) UNSIGNED NOT NULL,
  `openid` varchar(1000) NOT NULL,
  `pay_type` tinyint(1) UNSIGNED NOT NULL,
  `is_paid` tinyint(3) UNSIGNED NOT NULL,
  `order_sn` varchar(100) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `pay_amount` decimal(10,2) NOT NULL,
  `pay_points` int(10) UNSIGNED NOT NULL,
  `payment` varchar(20) NOT NULL,
  `payment_cn` varchar(20) NOT NULL,
  `description` varchar(150) NOT NULL,
  `service_name` varchar(30) NOT NULL,
  `params` text NOT NULL,
  `notes` varchar(150) NOT NULL,
  `addtime` int(11) UNSIGNED NOT NULL,
  `payment_time` int(10) UNSIGNED NOT NULL,
  `referer` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `payment_name` (`payment`),
  KEY `oid` (`oid`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimu_fenlei_parameter2` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` char(100) NOT NULL,
  `parameter` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;



CREATE TABLE IF NOT EXISTS `pre_zimu_fenlei_pub` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `cid1` int(10) UNSIGNED NOT NULL,
  `cid2` int(10) UNSIGNED NOT NULL,
  `catname` char(30) NOT NULL,
  `uid` int(10) UNSIGNED NOT NULL,
  `username` char(20) NOT NULL,
  `mobile` char(20) NOT NULL,
  `con` text NOT NULL,
  `diycon` varchar(10000) NOT NULL,
  `tags` varchar(200) NOT NULL,
  `imglist` text NOT NULL,
  `display` tinyint(1) UNSIGNED NOT NULL DEFAULT '1',
  `audit` tinyint(1) UNSIGNED NOT NULL DEFAULT '1',
  `confirm` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `endtime` int(10) UNSIGNED NOT NULL,
  `toptime` int(10) UNSIGNED NOT NULL,
  `refreshtime` int(10) UNSIGNED NOT NULL,
  `views` int(10) UNSIGNED NOT NULL DEFAULT '1',
  `shares` int(10) UNSIGNED NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  `url` char(200) NOT NULL,
  `source` char(30) NOT NULL,
  `tid` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;



CREATE TABLE IF NOT EXISTS `pre_zimu_fenlei_sendsmslog` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` int(10) UNSIGNED NOT NULL,
  `mobile` char(20) NOT NULL,
  `con` varchar(300) NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimu_fenlei_setmeal` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `setmeal_name` char(30) NOT NULL,
  `days` smallint(3) UNSIGNED NOT NULL,
  `expense` int(10) UNSIGNED NOT NULL,
  `access` char(255) NOT NULL,
  `tip` char(100) NOT NULL,
  `sort` tinyint(3) UNSIGNED NOT NULL DEFAULT '100',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;



CREATE TABLE IF NOT EXISTS `pre_zimu_fenlei_setmeal_fl` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `setmeal_name` char(30) NOT NULL,
  `days` smallint(3) UNSIGNED NOT NULL,
  `expense` int(10) UNSIGNED NOT NULL,
  `pubs` int(10) UNSIGNED NOT NULL,
  `refreshes` int(10) UNSIGNED NOT NULL,
  `topdays` int(10) UNSIGNED NOT NULL,
  `tip` char(100) NOT NULL,
  `sort` tinyint(3) UNSIGNED NOT NULL DEFAULT '100',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimu_fenlei_setting` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) UNSIGNED NOT NULL,
  `settings` longtext NOT NULL,
  `notifytext` text NOT NULL,
  `views` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimu_fenlei_share_data` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `pid` int(10) UNSIGNED NOT NULL,
  `uid` int(10) UNSIGNED NOT NULL,
  `useragent` varchar(1000) NOT NULL,
  `ip` char(200) NOT NULL,
  `type` char(20) NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimu_fenlei_shop` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` int(10) UNSIGNED NOT NULL,
  `username` char(50) NOT NULL,
  `name` char(50) NOT NULL,
  `cid1` int(10) UNSIGNED NOT NULL,
  `cid2` int(10) UNSIGNED NOT NULL,
  `catname` char(50) NOT NULL,
  `address` char(100) NOT NULL,
  `latitude` char(100) NOT NULL,
  `longitude` char(100) NOT NULL,
  `opentime` char(50) NOT NULL,
  `mobile` char(30) NOT NULL,
  `con` text NOT NULL,
  `gonggao` varchar(3000) NOT NULL,
  `xuanchuan` char(255) NOT NULL,
  `biaoqian` char(255) NOT NULL,
  `logo` char(255) NOT NULL,
  `qrcode` char(255) NOT NULL,
  `photo` varchar(10000) NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  `endtime` int(10) UNSIGNED NOT NULL,
  `refreshtime` int(10) UNSIGNED NOT NULL,
  `toptime` int(10) UNSIGNED NOT NULL,
  `views` int(10) UNSIGNED NOT NULL,
  `setmeal_id` int(10) UNSIGNED NOT NULL,
  `setmeal_name` char(100) NOT NULL,
  `display` tinyint(1) UNSIGNED NOT NULL,
  `source` char(20) NOT NULL,
  `vr` char(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimu_fenlei_shop_cat` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` char(30) NOT NULL,
  `icon` char(255) NOT NULL,
  `pid` int(10) UNSIGNED NOT NULL,
  `isnav` tinyint(1) UNSIGNED NOT NULL,
  `url` char(255) NOT NULL,
  `status` tinyint(1) UNSIGNED NOT NULL DEFAULT '1',
  `sort` tinyint(3) UNSIGNED NOT NULL DEFAULT '100',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimu_fenlei_smslog` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` int(10) UNSIGNED NOT NULL,
  `mobile` char(20) NOT NULL,
  `code` int(10) UNSIGNED NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimu_fenlei_token` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) UNSIGNED NOT NULL,
  `uid` int(10) UNSIGNED NOT NULL,
  `username` char(50) NOT NULL,
  `mobile` char(20) NOT NULL,
  `token` char(255) NOT NULL,
  `openid` char(255) NOT NULL,
  `unionid` char(255) NOT NULL,
  `xcx_openid` char(255) NOT NULL,
  `money` int(10) UNSIGNED NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  `refreshtime` int(10) UNSIGNED NOT NULL,
  `blacklist` tinyint(1) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimu_fenlei_tongji` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `cid` int(10) UNSIGNED NOT NULL,
  `views` int(10) UNSIGNED NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimu_fenlei_user_setmeal` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` int(10) UNSIGNED NOT NULL,
  `setmeal_id` int(10) UNSIGNED NOT NULL,
  `setmeal_name` char(50) NOT NULL,
  `pubs` int(10) UNSIGNED NOT NULL,
  `refreshes` int(10) UNSIGNED NOT NULL,
  `topdays` int(10) UNSIGNED NOT NULL,
  `starttime` int(10) UNSIGNED NOT NULL,
  `endtime` int(10) UNSIGNED NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_fenlei_searchlog` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` char(100) NOT NULL,
  `uid` int(10) UNSIGNED NOT NULL,
  `username` char(50) NOT NULL,
  `openid` char(255) NOT NULL,
  `mobile` char(20) NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_fenlei_adlist` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `con` char(255) NOT NULL,
  `adimg` char(255) NOT NULL,
  `type` tinyint(1) UNSIGNED NOT NULL,
  `catid` int(10) UNSIGNED NOT NULL,
  `url` char(255) NOT NULL,
  `views` int(10) UNSIGNED NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  `toptime` int(10) UNSIGNED NOT NULL,
  `endtime` int(10) UNSIGNED NOT NULL,
  `catname` char(100) NOT NULL,
  `position` int(10) UNSIGNED NOT NULL,
  `newtype` char(255) NOT NULL,
  `newcatid` char(255) NOT NULL,
  `noapp` tinyint(1) UNSIGNED NOT NULL,
  `diycolor` char(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_fenlei_queue_auto_refresh` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `pid` int(10) UNSIGNED NOT NULL,
  `uid` int(10) UNSIGNED NOT NULL,
  `refreshtime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_fenlei_refresh_log` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` int(10) UNSIGNED NOT NULL,
  `ids` int(10) UNSIGNED NOT NULL,
  `type` int(10) UNSIGNED NOT NULL,
  `money` int(10) UNSIGNED NOT NULL,
  `note` char(100) NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_fenlei_viewad` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` int(10) UNSIGNED NOT NULL,
  `type` char(30) NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

SQL;

runquery($sql);

$finish = TRUE;
