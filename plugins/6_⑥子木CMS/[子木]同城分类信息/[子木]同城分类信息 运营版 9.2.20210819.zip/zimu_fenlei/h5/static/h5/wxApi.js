import jWeixin from "@/static/h5/jweixin.js"

const wxApi = {
	siteurl:null,
	configData: null,
	timer: null,
	shareOptions: null,
	/**
	 * [wxRegister 微信Api初始化]
	 */
	wxRegister(callback) {
		let _this = this,
			signUrl = location.href,
			jsApiList = ["onMenuShareTimeline", "onMenuShareAppMessage", "updateAppMessageShareData", "updateTimelineShareData","openBusinessView", "scanQRCode", "getLocation", "openLocation", "chooseWXPay", "chooseImage", "previewImage","uploadImage", "getLocalImgData"];
			let pages = getCurrentPages();
			let route = pages[pages.length - 1].route;
		uni.request({
			url: _this.siteurl + '&model=wechatsign',
			method: 'POST',
			data: {
				sign_url: signUrl,
				path:route,
			},
			header: {
				'content-type': 'application/x-www-form-urlencoded',
			},
			success: (res) => {
			let data = res.data;
			jWeixin.config({
				debug: false, // 开启调试模式
				appId: data.appId, // 必填，公众号的唯一标识
				timestamp: data.timestamp, // 必填，生成签名的时间戳
				nonceStr: data.nonceStr, // 必填，生成签名的随机串
				signature: data.signature, // 必填，签名
				jsApiList: jsApiList // 必填，需要使用的JS接口列表
			});

			_this.wxShare(data.shareOptions)

			jWeixin.ready(() => {
				callback && callback();
			});
			
			uni.setNavigationBarTitle({
				title:data.shareOptions.navtitle
			})
			
			var ua = window.navigator.userAgent.toLowerCase();
			if (ua.match(/qianfan/i) == 'qianfan') {
			QFH5.setTitle(data.shareOptions.navtitle);
			QFH5.setShareInfo(data.shareOptions.title,data.shareOptions.imgUrl,data.shareOptions.desc,data.shareOptions.link,function(state,data){});
			}
			if (ua.match(/magapp/i) == 'magapp') {
			mag.setTitle(data.shareOptions.navtitle);
			mag.setData({
			  shareData: {
			      title: data.shareOptions.title,
			      des: data.shareOptions.desc,
			      picurl: data.shareOptions.imgUrl,
			      linkurl: data.shareOptions.link,
			      }
			});
			}
			
			jWeixin.error((optinos) => {
				// config信息验证失败会执行error函数，
				//如签名过期导致验证失败，具体错误信息可以打开config的debug模式查看，
				//也可以在返回的res参数中查看，对于SPA可以在这里更新签名。
				clearTimeout(_this.timer);
				_this.timer = setTimeout(() => {
					_this.wxRegister();
				}, 5000);
			});
						
			}
		});
	},
	wxShare(options) {
		jWeixin.ready(() => {
			jWeixin.updateAppMessageShareData(options);
			jWeixin.updateTimelineShareData(options);
			jWeixin.onMenuShareAppMessage(options);
			jWeixin.onMenuShareTimeline(options);
		});
	},
	wxPay(options,toreferer) {
		jWeixin.chooseWXPay({
			timestamp: options.timeStamp, // 支付签名时间戳，注意微信jssdk中的所有使用timestamp字段均为小写。但最新版的支付后台生成签名使用的timeStamp字段名需大写其中的S字符
			nonceStr: options.nonceStr, // 支付签名随机串，不长于 32 位
			package: options.package, // 统一支付接口返回的prepay_id参数值，提交格式如：prepay_id=\*\*\*）
			signType: options.signType, // 签名方式，默认为'SHA1'，使用新版支付需传入'MD5'
			paySign: options.paySign, // 支付签名
			success(res) {
				uni.showModal({
					title: '提示',
					content: '支付成功',
					showCancel:false,
					success: function (res) {
						window.location.replace(toreferer);
					}
				});
				options.success && options.success(res)
			},
			cancel(res) {
				uni.showToast({
					title:'你取消了支付',
					icon:'none',
					duration: 2000
				})
				options.cancel && options.cancel(res)
			},
			fail(res) {
				uni.showToast({
					title:'支付失败',
					icon:'none',
					duration: 2000
				})
				options.fail && options.fail(res)
			}
		});
	},
	scanQRCode(optinos) {
		jWeixin.scanQRCode(optinos);
	},
	uploadImage(optinos) {
		jWeixin.uploadImage(optinos);
	},
	chooseImage(optinos) {
		jWeixin.chooseImage(optinos);
	},
	getLocalImgData(localId, success, fail) {
		jWeixin.getLocalImgData({
			localId, // 图片的localID
			success: function(res) {
				console.log("success", res);
				success && success(res)
			},
			fail: function(res) {
				fail && fail(res)
			}
		});
	},
	openLocation(optinos) {
		jWeixin.openLocation(optinos);
	},
	getLocation(optinos) {
		jWeixin.getLocation(optinos);
	},
	/**
	 * 微信好物圈
	 */
	wxGoodsCircle(queryString, success, fail) {
		jWeixin.openBusinessView({
			businessType: 'friendGoodsRecommend',
			queryString: queryString,
			success(res) {
				success && success(res);
			},
			fail(res) {
				fail && fail(res);
			}
		})
	}
}
export default wxApi
