/*================================公司详细页================================*/
  // 关注
  $(".com_attention").on('click',function(){
	var url = qscms.root+"&model=ajaxpersonal&ac=company_focus";
	var company_id = $(this).data('cid');
	var isVisitor = (typeof($("input[name='hide_isVisitor']").val())!="undefined") ? $("input[name='hide_isVisitor']").val() : 0;
	var utype = (typeof($("input[name='hide_utype']").val())!="undefined") ? $("input[name='hide_utype']").val() : 0;		
	var thisObj = $(this);
	if ((isVisitor > 0)) {
	  if(utype != 2){
		var dialogType = new QSpopout();
		dialogType.setContent('您当前为企业帐户，无法操作！您可以切换个人帐户或重新登录个人帐户');
		dialogType.show();
		dialogType.setBtn(2, ['取消', '切换个人帐户']);
		dialogType.getPrimaryBtn().on('click', function () {
			window.location.href = qscms.root+"&model=mypersonal";
		});			  
		//qsToast({type:2,context: '请登录个人会员'});
		return false;
	  }
	  $.getJSON(url,{company_id:company_id},function(result){
		if(result.status==1){
		  qsToast({type:1,context: result.msg});
		  thisObj.html(result.data.html).toggleClass('for_cancel');
		} else {
		  qsToast({type:2,context: result.msg});
		  return false;
		}
	  });
	} else {
	  tologin();
	  //qsToast({type:2,context: '登录后才可以关注'});
	  return false;
	}
  });
  //导航栏切换  
  $("#tabboxs a").bind("click",function(){
	  var m=$(this);
	  m.parent().children().removeClass("selected");
	  $('#tabboxs-1,#tabboxs-2').css('display','none');
	  m.addClass("selected");
	  if("tabboxs-1"==m.data('id')){
		  $('#tabboxs-1').css('display','block');
	  }else if("tabboxs-2"==m.data('id')){
		  $('#tabboxs-2').css('display','block');
	  }
  });

  //点击展示头像
  function click_fun_logo(show_image) {
	var popout = new QSpopout();
	var html = '<img src="'+show_image+'" style="width:100%" class="cj-btn-close">';
	popout.setContent(html);
	popout.setBtn(1, ['确定']);
	popout.show();
  }
  $('.cj-btn-close').live('click', function(){ $('#popout').remove(); });
	
  /*点击或下载加载更多职位*/
  function load_jobs(jobs_uid){ 
	var totalpage=$("input[name='totalpage']").val();
	var scroll_has = $(".cjrolling").offset().top - $(window).scrollTop() - $(window).height() - 150;
	if (stops != false && scroll_has <= 0){
	  if(parseInt(page) <= parseInt(totalpage)){	  
		$.ajax({
			type: "get",
			url: qscms.root+"?m=Mobile&c=Jobs&a=ajax_jobs_show&uid="+jobs_uid+"&page="+page,
			async:false,
			beforeSend: function(){ stops = false;$("#ajax_loader").show(); },
			success: function (results) {
			  if (results.status==1) {
				  if(parseInt(page) == parseInt(totalpage)){
					  $("#ajax_loader").html('<font color="#999">已经加载完了..</font>');
				  }				  
				  page++;stops = true;				
				  $("#scroll_data").append(results.data);
			  }else{
				  $("#ajax_loader").html('<font color="#999">已经加载完了..</font>');
			  }			  		  
			},error: function(XMLHttpRequest) {
			  $("#scroll_data").append(XMLHttpRequest.responseText);
			}
		});			
	  }else{
		stops = false;
		$("#ajax_loader").html('<font color="#999">已经加载完了..</font>');
	  }
	}
  } 

//内容过高时显示查看更多按钮
$('.cj_more').on('click',function(){
  var prev = $(this).prev();
  var child = $(this).children('.showbtn');
  if(prev.hasClass('desc')){
	child.html('收起展示');
	prev.removeClass('desc');
	child.addClass('topbtn');
  }else{
	child.html('查看更多');
	prev.addClass('desc');
	child.removeClass('topbtn');
  }
});
if ($(".cj_txt .cj-des-wrapper").length > 0){
	var des_height = $(".cj-des-wrapper").height();
	if(des_height>260){
		$(".cj_txt").addClass('desc');
		$(".cj_more").show();
	}
} 
/*================================公司详细页-end================================*/
var use_swiper_container = $(".swiper-container").length; 
if(use_swiper_container>0){
	var mySwiper = new Swiper('#swiper-container', { lazy:{loadPrevNext:true},paginationClickable: true, calculateHeight: true,grabCursor: true,autoplay: true,autoplay: {delay: 6000},pagination: {el: '.swiper-pagination'}
	});
}