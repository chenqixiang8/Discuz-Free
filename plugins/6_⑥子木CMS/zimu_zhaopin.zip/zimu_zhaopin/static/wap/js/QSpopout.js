/**
 * 显示提示消息
 * @param options 自定义参数,使用：qsToast({type:1,context: result.msg});
 */
function qsToast(options) {
    if ($('.qs-toast').css('visibility') == 'visible') { // 防止重复点击
        return false;
    }
    var defaultOptions = {
        type: 1, // 消息类型 1:成功 2:警告 3:金币
        context: '', // 内容
        delay: 2000 // 自动消失时间(毫秒)
    };
    $.extend(defaultOptions, options);
    var typeClass = 'success';
    if (defaultOptions.type == 2) {
        typeClass = 'remind';
    }
    if (defaultOptions.type == 3) {
        typeClass = 'coins';
    }
    var toastHtml = '<div id="toast" style="display: none;">';
    toastHtml += '<div class="qs-mask-transparent"></div>';
    toastHtml += '<div class="qs-toast">';
    toastHtml += '<p class="qs-toast-content">' + defaultOptions.context + '</p>';
    toastHtml += '<div class="clear"></div>';
    toastHtml += '</div>';
    toastHtml += '</div>';

    $('body').append(toastHtml);
    $('#toast').fadeIn(200);
    $('.qs-toast').css({
        left: ($(window).width() - $('.qs-toast').width())/2
    });
	setTimeout(function() {
		$('#toast').remove();
	}, defaultOptions.delay);
}
/**
 * 弹出框类
 * @param title 标题
 * @constructor
 */
function QSpopout(title) {
    this.title = title;
    this.init();
}

QSpopout.prototype = {
    /**
     * 初始化
     */
    init: function() {
        var popoutHtml = '<div id="popout" style="display: none;">';
        popoutHtml += '<div class="qs-mask"></div>';
        popoutHtml += '<div class="qs-popout"><div class="qs-popout-body">';
        if (this.title) {
            popoutHtml += '<div class="qs-popout-hd"><div class="qs-popout-title">' + this.title + '</div></div>';
        }
        popoutHtml += '<div class="qs-popout-bd"></div>';
        popoutHtml += '<div class="qs-popout-ft">';
        popoutHtml += '<a href="javascript:;" class="qs-popout-btn qs-popout-btn-default"></a>';
        popoutHtml += '<a href="javascript:;" class="qs-popout-btn qs-popout-btn-primary"></a>';
        popoutHtml += '</div>';
        popoutHtml += '</div></div>';
        popoutHtml += '</div>';
        $('body').append(popoutHtml);

        this.popout = $('#popout');
        // 设置默认按钮
        this.defaultBtn = this.getDefaultBtn();
        this.primaryBtn = this.getPrimaryBtn();
        this.setBtn(2, ['取消', '确定']);
    },
    /**
     * 显示
     */
    show: function() {
        this.popout.fadeIn(0);
    },
    /**
     * 设置内容
     * @param value 内容
     */
    setContent: function(value) {
        $('.qs-popout-bd').html(value);
    },
    setCss: function(name,value) {
        $(name).css(value);
    },
    /**
     * 隐藏
     */
    hide: function() {
        this.popout.fadeOut(200);
        this.popout.remove();
    },
    /**
     * 设置按钮
     * @param num 按钮数量
     * @param value 按钮内容
     */
    setBtn: function(num, value) {
        var that = this;
		if (num == 101) {
			//等于101时没有去关闭弹窗
			$('.qs-popout-ft').remove();
		}else{
			if(num == 1){
				this.defaultBtn.hide();
				value = value ? value : '确定';
				this.primaryBtn.text(value);
			}else{
				this.defaultBtn.text(value[0]);
				this.primaryBtn.text(value[1]);
			}			
			// 关闭
			$('.qs-popout-btn').on('click', function() {
				that.hide();
			});
		}
		
    },
    /**
     * 获取主操作按钮
     * @returns {*|jQuery|HTMLElement}
     */
    getPrimaryBtn: function() {
        return $('.qs-popout-btn-primary');
    },
    /**
     * 获取辅助操作按钮
     * @returns {*|jQuery|HTMLElement}
     */
    getDefaultBtn: function() {
        return $('.qs-popout-btn-default');
    }
}