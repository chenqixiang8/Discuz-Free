/*================================职位详细页================================*/
$(document).ready(function(){

  //职位收藏职位点击事件绑定
  $(".job_favor").on('click',function(){
	var obj = $(this);
	var url = qscms.root+"&model=ajaxpersonal&ac=jobs_favorites";
	var jid = $(this).data('jid');
	var jidname = $(this).data('jidname');
	var comuid = $(this).data('comuid');
	var comid = $(this).data('comid');
	var comname = $(this).data('comname');
	var isVisitor = (typeof($("input[name='hide_isVisitor']").val())!="undefined") ? $("input[name='hide_isVisitor']").val() : 0;
	var utype = (typeof($("input[name='hide_utype']").val())!="undefined") ? $("input[name='hide_utype']").val() : 0;	
	if ((isVisitor > 0)) {
	  if(utype != 2){
		var dialogType = new QSpopout();
		dialogType.setContent('您当前为企业帐户，无法操作！');
		dialogType.show();
		dialogType.setBtn(2, ['取消', '切换个人帐户']);
		dialogType.getPrimaryBtn().on('click', function () {
			window.location.href = qscms.root+"&model=mypersonal";
		});
		return false;
	  }
	  $.getJSON(url,{jid:jid,jidname:jidname,comuid:comuid,comid:comid,comname:comname},function(result){
		if(result.status==1){
		  qsToast({type:1,context: result.msg});
		  if(result.data=='cancel'){
			obj.html('<img src="/source/plugin/zimu_zhaopin/static/wap/images/foot-nav-2.png"><br>收藏');
		  }else{
			obj.html('<img src="/source/plugin/zimu_zhaopin/static/wap/images/foot-nav-3.png"><br>已收藏');
		  }
		} else {
		  qsToast({type:2,context: result.msg});
		  return false;
		}
	  });
	}else{
	  tologin();
	  return false;
	  //qsToast({type:2,context: '登录后才可以收藏'});
	}
  });
  $('.J_tel').on('click',function(){
	var isVisitor = (typeof($("input[name='hide_isVisitor']").val())!="undefined") ? $("input[name='hide_isVisitor']").val() : 0;
	var utype = (typeof($("input[name='hide_utype']").val())!="undefined") ? $("input[name='hide_utype']").val() : 0;
	var hidetel = (typeof($("input[name='hidetel']").val())!="undefined") ? $("input[name='hidetel']").val() : 0;
	var hidetel_msg = (typeof($("input[name='hidetel_msg']").val())!="undefined") ? $("input[name='hidetel_msg']").val() : 0;
    console.log(hidetel_msg);
	if (isVisitor > 0) {
		if(utype != 2){
		  var dialogType = new QSpopout();
		  dialogType.setContent('您当前为企业帐户，无法操作！您可以切换个人帐户或重新登录个人帐户');
		  dialogType.show();
		  dialogType.setBtn(2, ['取消', '切换个人帐户']);
		  dialogType.getPrimaryBtn().on('click', function () {
			  window.location.href = qscms.root+"&model=mypersonal";
		  });				
		  //qsToast({type:2,context: '请登录个人会员'});
		  return false;
		}
	    if(hidetel==1 && hidetel_msg ){
		  var dialogType = new QSpopout();
		  dialogType.setContent(hidetel_msg);
		  dialogType.show();
		  dialogType.setBtn(1, ['确定']);			
		  return false;
		}
		if($(this).hasClass('hide_tel')){
			qsToast({type:2,context: '该企业设置联系方式不公开！'});
			return false;
		}
	}else{
	  tologin();
	    //qsToast({type:2,context: '登录后才可以查看联系方式'});
		return false;
	}
  });
/*================================职位详细页-end ================================*/
var use_swiper_container = $(".swiper-container").length; 
if(use_swiper_container>0){
	var mySwiper = new Swiper('#swiper-container', { lazy:{loadPrevNext:true},paginationClickable: true, calculateHeight: true,grabCursor: true,autoplay: true,autoplay: {delay: 6000},pagination: {el: '.swiper-pagination'}
	});
}
if($('.bottom-split-block').length>0){
	$(".bottom-split-block").css("display","none");
}

});