/*================================简历详细页================================*/
$(document).ready(function(){
// 加入人才库
$(".resume_favor").on('click',function(){
	var url = qscms.root+"&model=ajaxcompany&ac=resume_favor";
	var rid = $(this).data('rid');
	var isVisitor = (typeof($("input[name='hide_isVisitor']").val())!="undefined") ? $("input[name='hide_isVisitor']").val() : 0;
	var utype = (typeof($("input[name='hide_utype']").val())!="undefined") ? $("input[name='hide_utype']").val() : 0;		
	if ((isVisitor > 0)) {
		if(utype != 1){
		  var dialogType = new QSpopout();
		  dialogType.setContent('您当前为个人帐户，无法操作！请切换企业帐户或重新登录企业帐户');
		  dialogType.show();
		  dialogType.setBtn(2, ['取消', '切换企业帐户']);
		  dialogType.getPrimaryBtn().on('click', function () {
			  window.location.href = qscms.root+"&model=mycompany";
		  });			
		  //qsToast({type:2,context: '请登录企业会员'});
		  return false;
		}
		$.getJSON(url,{rid:rid},function(result){
			if(result.status==1){
				qsToast({type:1,context: result.msg});
				if(result.data=='has'){
				  $('#j_favor_bottom').html('<img src="/source/plugin/zimu_zhaopin/static/wap/images/foot-nav-2.png"><br>收藏');
				}else{
				  $('#j_favor_bottom').html('<img src="/source/plugin/zimu_zhaopin/static/wap/images/foot-nav-3.png"><br>已收藏');
				}
			} else {
				qsToast({type:2,context: result.msg});
				return false;
			}
		});
	} else {
		  tologin();
		  //qsToast({type:2,context: '请登录企业会员'});
		  return false;
	}
});
// 下载简历
$(".downbtn").on('click',function(){
	var url = qscms.root+"&model=ajaxcompany&ac=resume_down";
	var rid = $(this).data('rid');
	var isVisitor = (typeof($("input[name='hide_isVisitor']").val())!="undefined") ? $("input[name='hide_isVisitor']").val() : 0;
	var utype = (typeof($("input[name='hide_utype']").val())!="undefined") ? $("input[name='hide_utype']").val() : 0;	
	if ((isVisitor > 0)) {
		if(utype != 1){
		  var dialogType = new QSpopout();
		  dialogType.setContent('您当前为个人帐户，无法操作！请切换企业帐户或重新登录企业帐户');
		  dialogType.show();
		  dialogType.setBtn(2, ['取消', '切换企业帐户']);
		  dialogType.getPrimaryBtn().on('click', function () {
			  window.location.href = qscms.root+"&model=mycompany";
		  });
		  //qsToast({type:2,context: '请登录企业会员'});
		  return false;
		}
		$.getJSON(qscms.root+"&model=ajaxcompany&ac=resume_down_confirm",{rid:rid},function(data){
			if(data.status==1){
				var dialog = new QSpopout();
				dialog.setContent(data.msg);
				if(data.data=='no'){
					dialog.setBtn(1,'确定');
				}else if(data.data=='mix'){
					dialog.setBtn(1,'取消');
				}else if(data.data=='mix2'){
					dialog.setBtn(2,['取消', '升级套餐']);
					dialog.getPrimaryBtn().on('click', function () {
						window.location.href = qscms.root+"&model=companyservice&ac=setmeal_add";
					});
				}else{
					dialog.getPrimaryBtn().on('click', function () {
					  $.getJSON(url,{rid:rid},function(result){
						  if(result.status==1){
							  qsToast({type:1,context: result.msg});
							  setTimeout(function(){
								  window.location.reload();
							  },2000);
						  } else {
							  qsToast({type:2,context: result.msg});
							  return false;
						  }
					  });
					});
				}
				dialog.show();
			}else if(data.status==2){
				window.location.href = data.msg;
			}else{
				qsToast({type:2,context: data.msg});
			}
		});
	} else {
		tologin();
		//qsToast({type:2,context: '请登录企业会员'});
		return false;
	}
});
$('#resume_tel').on('click',function(){
	var isVisitor = (typeof($("input[name='hide_isVisitor']").val())!="undefined") ? $("input[name='hide_isVisitor']").val() : 0;
	var utype = (typeof($("input[name='hide_utype']").val())!="undefined") ? $("input[name='hide_utype']").val() : 0;
	if (isVisitor<=0) {
		tologin();
		//qsToast({type:2,context: '请登录企业会员'});
		return false;
	}
	if($(this).attr('utype') != 1){
		var dialogType = new QSpopout();
		dialogType.setContent('您当前为个人帐户，无法操作！请切换企业帐户或重新登录企业帐户');
		dialogType.show();
		dialogType.setBtn(2, ['取消', '切换企业帐户']);
		dialogType.getPrimaryBtn().on('click', function () {
			window.location.href = qscms.root+"&model=mycompany";
		});		
		//qsToast({type:2,context: '请登录企业帐号！'});
		return false;
	}
	if($(this).attr('type') == 0){
		qsToast({type:2,context: '请先下载简历！'});
		return false;
	}
});
if($('.bottom-split-block').length>0){
	$(".bottom-split-block").css("display","none");
}

});
//点击展示头像
function click_fun_logo(show_image) {
  var popout = new QSpopout();
  var html = '<img src="'+show_image+'" style="width:100%" class="cj-btn-close">';
  popout.setContent(html);
  popout.setBtn(1, ['确定']);
  popout.show();
}
$('.cj-btn-close').live('click', function(){ $('#popout').remove(); });
  
/*================================简历详细页-end================================*/