//全球通用JS代码片断
$(document).ready(function()
{ 
    //固定头部导航
	window.addEventListener('touchmove', function () {
	  if($(this).scrollTop()>0){
		$("#header_nav").addClass("navFix");
	  }else{ 
		$("#header_nav").removeClass("navFix"); 
	  }
	});
	//顶部发布职位
	$('#J_jobs_add_top').on('click',function(){
	$.getJSON(qscms.root+"?m=Mobile&c=Company&a=check_jobs_num",function(result){
	  if(result.status==1){
		var dialog = new QSpopout();
		var free = result.data;
		if(free==1){
			dialog.setContent('<div class="dialog_notice nospace">您当前是免费会员，发布中的职位数已超过最大限制，升级VIP会员后可继续发布职位，建议您立即升级VIP会员！</div>');
		}else{
			dialog.setContent('<div class="dialog_notice nospace">当前显示的职位已超过最大限制，建议您立即升级服务套餐或将暂时不招聘的职位设为关闭！</div>');
		}
		forCloseNav();
		dialog.show();
		dialog.setBtn(2, ['取消', '升级套餐']);
		dialog.getPrimaryBtn().on('click', function () {
			window.location.href = qscms.root+"?m=Mobile&c=CompanyService&a=setmeal_add";
		});
	  }else{
		window.location.href=qscms.root+"?m=Mobile&c=Company&a=jobs_add";
	  }
	});
	});
	//分站筛选
	$('.city-choose').on('click', function(){
		var selectData = 0;
		$.get(qscms.root+"&model=ajax_get_city",{selectData:selectData},function(result){
			if(result){
			  $("body").append(result);
			  $('body').css({"overflow":"hidden"});
			}
		});
	});
	//底部定位
	if($('.bottomfixed').length>0){ $(".memberlogin_fixed").css("bottom","1.2rem"); }
	if($('.bottomfixed').length>0 && $('.memberlogin_fixed').length>0){ $("#backtop").css("bottom","2.4rem"); }
});	
//滑动显示层
function ShowDivSlide(id, url) {
    if ($(".SlideDiv").length <= 0) {
        $("body").append("<div class='SlideDiv'><div class='DivContent' id='" + id + "'></div><div class='btnCloseSlideDiv' onclick='CloseDivSlide()'>关闭</div></div>");
    }
    if ($("#getDiv_bg").length <= 0) {
        $("body").append("<div id='getDiv_bg'></div>");
    }
    $("#getDiv_bg").height($(document).height()).show();	
    var height = $(".SlideDiv").height();
	$("#" + id).css({ height: (height - 40) + "px" });
	$("#" + id).load(url, function(){
	  $(".SlideDiv").animate({ bottom: '0px' }, 10, function () {
		  $(".SlideDiv").fadeIn();
	  });
	});

}
//滑动关闭层
function CloseDivSlide(){
    $("#getDiv_bg").hide();
	var height = $(".SlideDiv").height();
    $(".SlideDiv").animate({ bottom: '-' + height + 'px' }, 500, function () {
        $(".SlideDiv").fadeOut();
    });
}

/***为您推荐职位、简历***/
function ajax_show_jobsresume(){  
  var totalpage=$("input[name='totalpage']").val();
  var utype = (typeof($("input[name='hide_utype']").val())!="undefined") ? $("input[name='hide_utype']").val() : 0;
  var more_txt = (utype==1) ? '<a href="'+qscms.root+'&model=resume">您期望的简历数量较少？点击查看更多简历..</a>' : '<a href="'+qscms.root+'&model=jobs">您期望的职位数量较少？点击查看更多职位..</a>';
  if (stops != false){
	  if(parseInt(page) <= parseInt(totalpage)){	  
		$.ajax({
			type: "get",
			datType: "json", 
			url: qscms.root+"&model=ajax_show_jobsresume&utype="+utype+"&page="+page,
			beforeSend: function(){ stops = false;},
			success: function (result) {
            var result = JSON.parse(result);
            console.log(result);					  
			  if (result.status==1 && result['data'].data_list.length>0) {
				  page++;stops = true;
				  var html = '';
				  if(result.data.type=='resume'){
					  html = ajax_show_resume_html(result.data.data_list);
				  }else{
					  html = ajax_show_jobs_html(result.data.data_list);
				  }			
				  $("input[name='totalpage']").val(result.data.totalPages);
				  $("#tuijian_ajax").append(html);
				  $("#ajax_loader").show();
			  }else{
				  $("#ajax_loader").show().html(more_txt);
			  }	
			  $("#ajax_loader_text").hide();		
			},
			error: function(XMLHttpRequest) {
			  $("#ajax_loader").html(more_txt);
			},
			complete: function(){ $("#ajax_loaders").hide(); }
		});	 
	  }else{
		stops = false;
		$("#ajax_loader").html(more_txt);
	  }
  }
}

//职位相关数据显示
function ajax_show_jobs_html(data){
  var html = jobs_emergency = '';
  for(var i in data){
	  if(data[i].project==1)
	  {
		  html += data[i].html;
	  }else{	  
		  jobs_emergency = (data[i].emergency==1) ? ' <img src="/source/plugin/zimu_zhaopin/wap/static/images/231.png"/>' : '';
		  html += '<div class="job-list-item for-event">';
		  html += '<a href="'+data[i].jobs_url+'">';
		  html += '<div class="info">';
		  html += '  <div class="line-one">';
		  html += '      <div class="job-name substring font16">';
		  if(data[i].stick_cn!=''){
		  html += '      <i class="new_tuijiantext">置顶</i> ';
		  }
		  html += data[i].jobs_name+' '+jobs_emergency+'</div>';
		  html += '      <div class="refresh-time font10">'+data[i].refreshtime_cn+'</div>';
		  html += '      <div class="wage-pa font13">'+data[i].wage_cn+'</div>';
		  html += '      <div class="clear"></div>';
		  html += '  </div>';
		  html += '  <div class="line-two substring font12">'+data[i].category_cn;
		  if(data[i].education_cn){
		  html += '<span class="line"></span>'+data[i].education_cn;
		  }
		  if(data[i].experience_cn){
		  html += '<span class="line"></span>'+data[i].experience_cn;
		  }
		  html += '</div>';
		  html += '  <div class="line-tag font10">';
		  if(data[i].district_cn){
		  html += '    <div class="job-tag">'+data[i].district_cn+'</div>';
		  }
		  if(data[i].tag_cn!=''){
			  for(var i2 in data[i]['tag_cn']){
				  html += '<div class="job-tag">'+data[i]['tag_cn'][i2]+'</div>';	
			  }
		  }else{
		  	 if(data[i]['scale_cn']){ html += '<div class="job-tag">'+data[i].scale_cn+'</div>'; }
			 if(data[i]['trade_cn']){ html += '<div class="job-tag">'+data[i].trade_cn+'</div>'; }
			 if(data[i]['sex_cn']){ html += '<div class="job-tag">'+data[i].sex_cn+'</div>'; }
		  }
		  html += '    <div class="clear"></div>';
		  html += '  </div>';
		  html += '  <div class="line-company font12" style="text-indent:0;">'+data[i].companyname;
if(data[i]['company_mingqi']==1){
		  html += '  <span class="mingqi" style="background-color:#fd8000;">名企</span>';
}
if(data[i]['setmeal_id']>1){
		  html += '  <span class="mingqi">会员</span>';
}
if(data[i]['company_certificate']==1){
		  html += '  <span class="yirenzheng">已认证</span>';
}
		  html += '  </div>';
		  html += '</div>';
		  html += '</a>';
		  html += '</div><div class="list-split-block"></div>';
	  }
  }
  return html;
}
//简历相关数据显示
function ajax_show_resume_html(data){
  var html = '';
  for(var i in data){
	  if(data[i].project==1)
	  {
		  html += data[i].html;
	  }else{
		  html += '<div class="resume-list-item for-event">';
		  html += '<a href="'+data[i].resume_url+'">';
		  html += '  <div class="info">';
		  html += '  <dt class="logo-info"><div class="logo-img"><img src="'+data[i].photo_img+'" border="0"/></div><i class="sex '+data[i].sex_icon+'">'+data[i].sex_cn+'</i></dt>';
		  html += '  <dt class="right-info">';
		  html += '    <div class="line-one">';
		  html += '        <div class="real-name substring font16">'+data[i].fullname+'<span class="real-small font12">'+data[i].age_cn+'</span></div>';
		  if(data[i].strong_tag!='' && data[i].strong_tag!=0){		  
		  	html += '        <div class="gold font10">'+data[i].strong_tag+'</div>';
		  }
		  if(data[i].stick_cn!=''){
		  	html += '      <div class="refresh-time font10 tuijiantext">置顶</div>';
		  }else{
		  	html += '      <div class="refresh-time font10">'+data[i].refreshtime_cn+'</div>';
		  }
		  html += '        <div class="clear"></div>';
		  html += '    </div>';
		  html += '    <div class="line-two substring font12">'+data[i].wage_cn+'<span class="line"></span>'+data[i].experience_cn+'<span class="line"></span>'+data[i].education_cn+'</div>';
		  html += '    <div class="line-three font10 substring">';
		  html += ''+data[i].nature_cn+'<span class="line"></span>';
		  if(data[i].district_cn!=''){ html += ''+data[i].district_cn+'<span class="line"></span>'; }
		  html += '    '+data[i].intention_jobs+'</div>';
		  if(data[i].tag_cn!='')
		  {
			  html += '<div class="line-four font10">';
			  for (var i2 in data[i]['tag_cn']){
				  html += '<div class="resume-tag">'+data[i]['tag_cn'][i2]+'</div>';
			  }
			  html += '<div class="clear"></div>';
			  html += '</div>';
		  }
		  html += '  </dt>';
		  html += '  </div>';
		  html += '</a>';
		  html += '</div>';
		  html += '</div><div class="list-split-block"></div>';
	  }
  }
  return html;
}

//申请职位点击事件绑定
function apply_jobs(jid){
	var url = qscms.root+"?m=Mobile&c=ajaxPersonal&a=resume_apply";
	var isVisitor = (typeof($("input[name='hide_isVisitor']").val())!="undefined") ? $("input[name='hide_isVisitor']").val() : 0;
	var utype = (typeof($("input[name='hide_utype']").val())!="undefined") ? $("input[name='hide_utype']").val() : 0;
	if ((isVisitor > 0)) {
	  if(utype != 2){
		qsToast({type:2,context: '请登录个人会员'});
		return false;
	  }
	  $.getJSON(url,{jid:jid},function(result){
		if(result.status==1){
		  qsToast({type:1,context: result.msg});
		  return false;
		} else {
		  qsToast({type:2,context: result.msg});
		  return false;
		}
	  });
	} else {
		if (eval(qscms.smsTatus)) {
			window.location.href=qscms.root+'?m=Mobile&c=AjaxPersonal&a=resume_add_dig&jid='+jid;
		} else {
			window.location.href=qscms.root+"?m=Mobile&c=Members&a=login";
		}
	}
}
//为您推荐职位、简历
var stops=true,page=1;
$(window).scroll(function(){
  //固定头部导航
  if($(this).scrollTop()>0){
	$("#header_nav").addClass("navFix");
  }else{ 
	$("#header_nav").removeClass("navFix"); 
  }	
  if($("input[name='totalpage']").val()>=1){
	  var scroll_has = $("#tuijian_point").offset().top - $(window).scrollTop() - $(window).height() - 150; 
	  console.log(scroll_has)
	  if (scroll_has <= 100){
		  ajax_show_jobsresume(); 
	  }else{
		$("#ajax_loader").show();
	  }
  }
});
setTimeout(function(){ 
   ajax_show_jobsresume(); 
},300);
/***为您推荐职位、简历****/