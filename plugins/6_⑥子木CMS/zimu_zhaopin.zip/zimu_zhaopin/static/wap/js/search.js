// Zepto.cookie plugin
(function(a){a.extend(a.fn,{cookie:function(b,c,d){var e,f,g,h;if(arguments.length>1&&String(c)!=="[object Object]"){d=a.extend({},d);if(c===null||c===undefined)d.expires=-1;return typeof d.expires=="number"&&(e=d.expires*24*60*60*1e3,f=d.expires=new Date,f.setTime(f.getTime()+e)),c=String(c),document.cookie=[encodeURIComponent(b),"=",d.raw?c:encodeURIComponent(c),d.expires?"; expires="+d.expires.toUTCString():"",d.path?"; path="+d.path:"",d.domain?"; domain="+d.domain:"",d.secure?"; secure":""].join("")}return d=c||{},h=d.raw?function(a){return a}:decodeURIComponent,(g=(new RegExp("(?:^|; )"+encodeURIComponent(b)+"=([^;]*)")).exec(document.cookie))?h(g[1]):null}})})(Zepto);

/*职位简历、书店广告搜索*/
$('.js-so-close').on('click', function () {
	$(this).closest('.topbg').find('.soimput').val('');
	$('#J_submit').addClass('rightbtn');
	$('#J_submit').removeClass('rightbtn-so');
	$('#J_submit').addClass('cancel');
	$('#J_submit').html('取消');
})
if($('#J_soinput').val()){
	$('#J_submit').addClass('rightbtn-so');
	$('#J_submit').removeClass('rightbtn');
	$('#J_submit').removeClass('cancel');
	$('#J_submit').html('搜索');
}
function get_history(d,page_val){
	var b = "", hlength = 0;
	var searchHistoryArr = new Array();
	if ($.fn.cookie("searchHistory_"+page_val)) {
	  searchHistoryArr = $.fn.cookie("searchHistory_"+page_val).split(",");
	};
	if (searchHistoryArr.length == 0) {
	  d.hide();
	  return false
	}
	$.each(searchHistoryArr.reverse(), function(index, val) {
	  hlength += 1;
	  b += '<a href="javascript:;" data-self="'+val+'" class="hotword substring for-event history_go">'+val+'</a>';
	});
	if (hlength > 0) {
	  d.empty().html(b);
	  $("#J_history").show();
	  $(".history_go").on("click", function() {
		searchGo($(this).data("self"));
	  });
	  $(".record .close").on("click", function() {
		var searchHistoryArr = $.fn.cookie("searchHistory_"+page_val).split(","),
		  val = $(this).prev().data("self"),
		  index = $.inArray(val,searchHistoryArr);
		if (index >= 0) {
		  searchHistoryArr.splice(index,1);
		};
		$.fn.cookie("searchHistory_"+page_val,searchHistoryArr,{ path: '/' });
		$(this).parent().remove();
	  });
	} else {
	  d.empty();
	  $("#J_history").hide()
	}
}
function add_history(key,page_val){
	if (key.length > 0) {
	  var searchHistoryArr = new Array();
	  if ($.fn.cookie("searchHistory_"+page_val)) {
		searchHistoryArr = $.fn.cookie("searchHistory_"+page_val).split(",");
		var isOnly = true;
		$.each(searchHistoryArr, function(index, val) {
		  if (val == key) {
			isOnly = false;
		  };
		});
		if (isOnly) {
		  if (searchHistoryArr.length >= 10) {
			searchHistoryArr.splice(0,1);
		  }
		  searchHistoryArr.push(key);
		};
	  } else {
		searchHistoryArr.push(key);
	  };	  
	  $.fn.cookie("searchHistory_"+page_val,searchHistoryArr,{ path: '/' });
	}
}
function searchGo(key) {
	if(key==''){
		$('.cjpageso').hide();
		$('body').css({"overflow":"auto"});
	}else{
		add_history(key,$('#page_val').val());
		var seach_page = $('.f-seach-page').val();
		if(typeof(seach_page) =='undefined'){
			qsToast({type:2,context:"调用.f-seach-page出错，无法完成搜索"});
		}
		var search_type = $('#search_type').val();
		var citycategory = $('#citycategory').val();
		if(search_type=="full") seach_page += "search_type="+search_type+"&";
		if($.trim(citycategory)!="") seach_page += "citycategory="+citycategory+"&";
		var url = qscms.root+seach_page+"key="+key;
		window.location.href=url;
	}
}
$('.topbg .soselect').on('click', function () {
	$('.topbg').toggleClass('for-type');
})
$('.choose-s-type-cell .qs-center').on('click', function () {
	var stypeCode = $(this).find('.choose-s-type-list').data('code');
  var stypeTitle = $(this).find('.choose-s-type-list').data('title');
	$('.for-type-code').val(stypeCode);
  $('.for-type-txt').text('搜' + stypeTitle);
	$('.topbg').toggleClass('for-type');
});
$('#J_submit').on('click',function(){
	if($(this).hasClass('cancel')){
	  searchGo('');
	}else{
	  searchGo($('#J_soinput').val());
	}
});
$("#J_cleanhistory").on("click", function() {
	$("#J_history").hide();
	$.fn.cookie('searchHistory_'+$('#page_val').val(), null,{ path: '/' });
});
$('#J_soinput').on('keyup',function(){
	if($(this).val()!=''){
	  $('#J_submit').addClass('rightbtn-so');
	  $('#J_submit').removeClass('rightbtn');
	  $('#J_submit').removeClass('cancel');
	  $('#J_submit').html('搜索');
	}else{
	  $('#J_submit').addClass('rightbtn');
	  $('#J_submit').removeClass('rightbtn-so');
	  $('#J_submit').addClass('cancel');
	  $('#J_submit').html('取消');
	}
});
$('.hotword').on('click',function(){
	add_history($(this).text(),$('#page_val').val());
	window.location.href=$(this).attr('href');
	return false;
});
//输入框绑定回车事件
$('#J_soinput').keypress(function(event){
	if(event.keyCode==13){
		$(".rightbtn-so").trigger("click");
		return false;
	}
});

//职位搜索js片断=====================================
 // 跳转方法
 function goPage() {
	 //var toSearchPage = $('.f-seach-page').val();
	 //window.location.href = qscms.root + toSear
	var nowKeyValue = $.trim($('#searchForm').find('input[name="key"]').val());
	var post_data = $('#searchForm').serialize(); 
	$.post($('#searchForm').attr('action'),post_data,function(result){	  
		if(result.status==1){
			window.location.href=result.data;
		}else{
			qsToast({type:2,context:result.msg});
		}
	},'json');
 }
  // 更多列表左右切换
   $('.js-more-l').on('click', function () {
	   var targetId = $(this).data('id');
	   $('.f-box-more').toggleClass('qs-actionsheet-toggle-left');
	   $('#' + targetId).toggleClass('qs-actionsheet-toggle');
   })
   $('.f-more-back-btn').on('click', function () { // 更多列表切换返回
	   $('.f-box-more').toggleClass('qs-actionsheet-toggle-left');
	   $('.f-more-content').removeClass('qs-actionsheet-toggle');
   })
   $('.f-more-back-a').on('click', function () { // 更多列表项点击
	   var thisType = $(this).data('type');
	   var thisTitle = $(this).data('title');
	   var thisCode = $(this).data('code');
	   $('.f-more-l-code-' + thisType).val(thisCode);
	   $('.f-more-l-txt-' + thisType).text(thisTitle);
	   $('.f-box-more').toggleClass('qs-actionsheet-toggle-left');
	   $('.f-more-content').removeClass('qs-actionsheet-toggle');
   })
   // 除更多和读取缓存之外的下拉列表
   $('.f-item-normal').on('click', function () {
	   var thisType = $(this).data('type');
	   var thisTitle = $(this).data('title');
	   var thisCode = $(this).data('code');
	   $('.f-normal-code-' + thisType).val(thisCode);
	   $('.f-normal-txt-' + thisType).text(thisTitle);
	   $('body').removeClass('filter-fixed');
	   $('.f-box-' + thisType).addClass('qs-hidden');
	   $('.js-filter').removeClass('active');
	   $('#f-mask').hide();
	   goPage();
   })
   // 过滤已投递
   $('.js-clickedbox').on('click', function () {
	   if ($(this).hasClass('clickedchoice')) {
		   $(this).removeClass('clickedchoice');
		   $('.f-deliver').val('0');
	   } else {
		   $(this).addClass('clickedchoice');
		   $('.f-deliver').val('1');
	   }
   })
  // 清空已选分类
  $('.js-clearjob-jobcategory').on('click', function () {
	  alert(3);
	  $('.qs-recover-code-job').val('');
	  goPage();
  })
