$(function () {
var hideClass = 'qs-hidden';
var tempArr = $('.qs-temp');
//只显示城市的区域列表，三级分类
$.each(tempArr, function() {
  var that = $(this);
  var thistype = $(this).data('type');
  var datasource = eval($(this).data('source'));
  var thisBox = '.f-box-' + thistype;
  var thisLink = eval($(this).data('link')); //是否是搜索
  var parentcity = $.trim($(this).data('parentcity'));//根据城市显示区域小类
  //根据城市显示区域小类
  if(parentcity.length){
	var parentcityList = datasource[parentcity];
	if (parentcityList) {			
        var tempHtml = '<div class="f-box-inner">';
        if (thisLink) {
          tempHtml += '<div class="level1Link">';
          tempHtml += '<li><a class="f-item f-none" href="javascript:;" data-code="" data-title="地区">不限</a></li>';
          tempHtml += '</div>';
          if (that.data('range')) {
            tempHtml += '<div class="level1Group">';
            tempHtml += '<li><a class="f-item" href="javascript:;" data-code="near" data-title="附近">附近</a></li>';
            tempHtml += '</div>';
          }
        }
		var tempLevelStr = parentcityList.split('`');
		$.each(tempLevelStr, function(key, value) {
		  if (value.split(',')) {
			tempHtml += '<div class="level1Link">';
			tempHtml += '<li><a class="f-item f-none" href="javascript:;" data-code="' + value.split(',')[0] + '" data-title="' + value.split(',')[1] + '">' + value.split(',')[1] + '</a></li>';
			tempHtml += '</div>';
		  }
		})
        tempHtml += '</div>';	
		 tempHtml += '<div class="f-btn-submit qs-center"><div class="qs-btn qs-btn-inline qs-btn-small qs-btn-blue city-choose" data-type="city" data-base="QS_city_spell_parent" data-source="QS_city_spell" data-range="false" data-searchtype="QS_jobslist">切换城市</div></div>	';	
        $(thisBox).html(tempHtml);
		$(".f-box-city").css("height","8.1rem");
        // 恢复选中
        var rvalue = $('.qs-temp-code-' + thistype).val();	
		if (rvalue.length) {
            $(thisBox + ' .level1Link .f-none').each(function(){
              if ($(this).data('code') == rvalue) {
                $(this).addClass('select');
              }
            });			
		} else {
          if (thisLink) { // 判断是否是筛选
            var rangeValue = $('.qs-temp-code-range').val();
            if (rangeValue.length) {
              $(thisBox + ' .level1Group').eq(0).find('.f-item').addClass('select');
              var rclickTempHtml = '<div class="f-box-inner">';
              rclickTempHtml += '<div class="level2Group">';
              rclickTempHtml += '<li><a class="f-item f-range" href="javascript:;" data-code="" data-title="不限">不限</a></li>';
              rclickTempHtml += '<li><a class="f-item f-range" href="javascript:;" data-code="1" data-title="1公里">1公里</a></li>';
              rclickTempHtml += '<li><a class="f-item f-range" href="javascript:;" data-code="3" data-title="3公里">3公里</a></li>';
              rclickTempHtml += '<li><a class="f-item f-range" href="javascript:;" data-code="5" data-title="5公里">5公里</a></li>';
              rclickTempHtml += '<li><a class="f-item f-range" href="javascript:;" data-code="10" data-title="10公里">10公里</a></li>';
              rclickTempHtml += '</div>';
              rclickTempHtml += '</div>';
              $(thisBox).append(rclickTempHtml);
              var recoverRangeItemArr = $(thisBox + ' .level2Group').eq(0).find('.f-item');
              $.each(recoverRangeItemArr, function () {
                if ($(this).data('code') == rangeValue) {
                  $(this).addClass('select');
                }
              })
            } else {
              $(thisBox + ' .level1Link .f-item').eq(0).addClass('active');
            }
          } else {
            $(thisBox + ' .level2Group').eq(0).removeClass(hideClass); //不恢复默认二级分类的第一个显示出来
          }			
		}
        /**
         * 筛选点击一级跳转
         */
        $(thisBox + ' .level1Link a.f-none').on('click', function () {
          var qtcode = $(this).data('code');
          var qttitle = $(this).data('title');
          $('.qs-temp-code-' + thistype).val(qtcode);
          $('.qs-temp-txt-' + thistype).text(qttitle);
          if (qtcode.length == 0) {
            $('.qs-temp-code-range').val(qtcode);
          }
          clearFilter();
          goPage();
		})
        /**
         * 一级分类点击
         */
        $(thisBox + ' .level1Group a.f-item').not('.f-none').on('click', function() {
          $(thisBox + ' .level1Group a.f-item').removeClass('active');
          if (thisLink) {
            $(thisBox + ' .level1Link a.f-item').removeClass('active');
          }
          $(this).addClass('active');
          var thisIndex = getIndex($(this).closest('.level1Group'), thisBox + ' .level1Group');
          var clickTempHtml = '';
          var thisItemCode = $(this).data('code'); // 获取点击的title
          if (thisItemCode == 'near') { // 点击的为附近
            clickTempHtml += '<div class="f-box-inner">';
			clickTempHtml += '<div class="level2Group">';
            clickTempHtml += '<li><a class="f-item f-range" href="javascript:;" data-code="" data-title="不限">不限</a></li>';
            clickTempHtml += '<li><a class="f-item f-range" href="javascript:;" data-code="1" data-title="1公里">1公里</a></li>';
            clickTempHtml += '<li><a class="f-item f-range" href="javascript:;" data-code="3" data-title="3公里">3公里</a></li>';
            clickTempHtml += '<li><a class="f-item f-range" href="javascript:;" data-code="5" data-title="5公里">5公里</a></li>';
            clickTempHtml += '<li><a class="f-item f-range" href="javascript:;" data-code="10" data-title="10公里">10公里</a></li>';
            clickTempHtml += '</div>';
			clickTempHtml += '</div>';
			lcj_geolocation();
          }
          if ($(thisBox + ' .f-box-inner').length > 1) {
            $(thisBox + ' .f-box-inner').eq(1).remove();
          }
          $(thisBox).append(clickTempHtml);
		})
		/**
		 * 二级分类点击,只针对于附近的
		 */
		$(thisBox + ' .level2Group a.f-item').live('click', function() {
			if (thisLink) {
			  if ($(this).hasClass('f-range')) {// 附近
				var cookie_lat = $.fn.cookie('cookie_lat');
				var cookie_lng = $.fn.cookie('cookie_lng');
				if(cookie_lat && cookie_lng){
					$("#lat").val(cookie_lat);
					$("#lng").val(cookie_lng);
				}else{
					alert("无法获取附近定位，请重新退出访问，提示获取地理位置时请同意获取");
					return false;
				}	
				var qtcode = $(this).data('code');
				$('.qs-temp-code-range').val(qtcode);
				$('.qs-temp-code-' + thistype).val('');
			  }
			  clearFilter();
			  goPage();
			} else {
			  $('.js-actionsheet').removeClass('qs-actionsheet-toggle');
			  $('.qs-mask').fadeOut(200);
			}			
		});
	}
  }
  /**
   * 清除筛选
   */
  function clearFilter() {
	$('body').removeClass('filter-fixed');
	$(thisBox).addClass(hideClass);
	$('#f-mask').hide();
	$('.qs-temp').removeClass('active');
  }  
});
//点击选择城市分站时
$('.city-choose').on('click', function(){
	var that = $(this);
	var thistype = $(this).data('type');
	var database = eval(that.data('base'));
	var datasource = eval(that.data('source'));
	var searchtype = $.trim(that.data('searchtype'));
	var parentcity = $.trim(that.data('parentcity'));//根据城市显示区域小类
	var thisBox = '.subcityCate';
	var tempHtml = '<div class=\"m-sub-filter-page\">';
	tempHtml += '<div class=\"msp-head\">';
	tempHtml += '	<div class=\"msp-head-box\">';
	tempHtml += '		<div class="msp-cancel-btn"></div>';
	tempHtml += '		<div class=\"msp-title font16\">选择地区</div>';
	tempHtml += '		<div class=\"clear\"></div>';
	tempHtml += '	</div>';
	tempHtml += '</div>';
	tempHtml += '<div class=\"subcityCate\">';
	tempHtml += '<div class=\"subcityCate-left font13\">';
	tempHtml += '	<div class=\"levelLink\"><a class="f-item" href=\"javascript:;\" data-code=\"\" data-title=\"城市分站\">城市分站</a></div>';
	//附近的
	if (that.data('range')) {
	  tempHtml += '<div class="levelLink"><a class="f-item" href="javascript:;" data-code="near" data-title="附近">附近</a></div>';
	}
	//省份
	$.each(database, function(key, value) {
	  if (value.split(',')) {
		tempHtml += '<div class="levelLink"><a class="f-item" href="javascript:;" data-code="' + value.split(',')[0] + '" data-title="' + value.split(',')[1] + '">' + value.split(',')[1] + '</a></div>';
	  }
	})//	  
	tempHtml += '</div>';
	tempHtml += '<div class="subcityCate-box scrollbar">';
	tempHtml += '<div class="' + hideClass + ' subcityCate-inner" id="subsite_col">';
	//城市分站
	$.getJSON(qscms.root+"?m=Mobile&c=Subsite&a=ajax_get_city",{search_type:searchtype},function(result){
		if(result.status==1){
		  $("#subsite_col").append(result.data.html);
		}
	});
	tempHtml += '</div>';
	// 是否开启附近地区
	if (that.data('range')) { 
	  tempHtml += '<div class="' + hideClass + ' subcityCate-inner">';
	  tempHtml += '<div class="m-sub-city-group font12">';
	  tempHtml += '<li><a class="f-item f-range" href="javascript:;" data-code="" data-title="不限">不限</a></li>';
	  tempHtml += '<li><a class="f-item f-range" href="javascript:;" data-code="1" data-title="1公里">1公里</a></li>';
	  tempHtml += '<li><a class="f-item f-range" href="javascript:;" data-code="3" data-title="3公里">3公里</a></li>';
	  tempHtml += '<li><a class="f-item f-range" href="javascript:;" data-code="5" data-title="5公里">5公里</a></li>';
	  tempHtml += '<li><a class="f-item f-range" href="javascript:;" data-code="10" data-title="10公里">10公里</a></li>';
	  tempHtml += '<div class="clear"></div>';
	  tempHtml += '</div>';
	  tempHtml += '</div>';
	}
	for (var i = 0; i < database.length; i++) {			
	  if (database[i].split(',')) {
		var tempLevel2Str = datasource[database[i].split(',')[0]];
		if (tempLevel2Str) {
		  var tempLevel2Array = tempLevel2Str.split('`');
		  if (tempLevel2Array) {
			tempHtml += '<div class="' + hideClass + ' subcityCate-inner" data-code="' + database[i].split(',')[0] + '">';
			tempHtml += '<div class="m-sub-city-group font12">';
			tempHtml += '<li><a class="f-item" href="javascript:;" data-code="' + database[i].split(',')[0] + '" data-title="' + database[i].split(',')[1] + '">不限</a></li>';
			$.each(tempLevel2Array, function(key, value) {
			  if (value.split(',')) {
				if (value.split(',')[0]) {
				  tempHtml += '<li><a class="f-item" href="javascript:;" data-code="' + value.split(',')[0] + '" data-title="' + database[i].split(',')[1] + value.split(',')[1] + '">' + value.split(',')[1] + '</a></li>';
				}
			  }
			})
			tempHtml += '</div>';
			tempHtml += '</div>';
		  }
		}
	  }
	}	  
	tempHtml += '</div>';
	tempHtml += '</div>';
	$("body").append(tempHtml);
	// 恢复选中
	var rvalue = parentcity;
	if (rvalue.length) { // 恢复选中
		var rvalueArr = rvalue.split(',');
		var itemArr = $(thisBox + ' .subcityCate-inner a.f-item').not('.c-next');
		$.each(rvalueArr, function (key, value) {
		  $.each(itemArr, function () {
			if ($(this).data('code') == value) {				  
			  $(this).addClass('select');
			  var thisIndex = getIndex($(this).parents('.subcityCate-inner'), thisBox + ' .subcityCate-inner');
			  $(thisBox+' .subcityCate-inner').addClass(hideClass);
			  $(thisBox+' .subcityCate-inner').eq(thisIndex).removeClass(hideClass);
			}
		  })
		});
		// 一级大类
		$(thisBox + ' .levelLink').removeClass('select active');
		var subscriptValue = 0;
		$(thisBox + ' .subcityCate-inner a.f-item.select').each(function(index, el) {			 
			var thisGroup = $(this).closest(thisBox + ' .subcityCate-inner');
			subscriptValue = $(thisBox + ' .subcityCate-inner').index(thisGroup);			  
			$(thisBox + ' .levelLink a.f-item').eq(subscriptValue).addClass('select');
		});
	}else{
		var rangeValue = $('.qs-temp-code-range').val();
		if (that.data('range') && rangeValue.length) {
		  $(thisBox + ' .levelLink a.f-item').removeClass('active');
		  $(thisBox + ' .levelLink').eq(1).find('.f-item').addClass('select');
		  $(thisBox + ' .subcityCate-inner').eq(1).removeClass(hideClass);
		  var recoverRangeItemArr = $(thisBox + ' .subcityCate-inner').eq(1).find('.f-item');
		  $.each(recoverRangeItemArr, function () {
			if ($(this).data('code') == rangeValue) {
			  $(this).addClass('select');
			}
		  })
		} else {
		  $(thisBox + ' .levelLink .f-item').eq(0).addClass('active');
		  $(thisBox + ' .subcityCate-inner').eq(0).removeClass(hideClass);
		}		  
	}
	/**
	 * 一级分类点击
	 */
	$(thisBox+' .levelLink a.f-item').not('.f-none').on('click', function() {
	  $(thisBox+' .levelLink a.f-item').removeClass('active');
	  $(this).addClass('active');
	  var thisIndex = getIndex($(this).closest('.levelLink'), thisBox+' .levelLink');
	  $(thisBox+' .subcityCate-inner').addClass(hideClass);
	  $(thisBox+' .subcityCate-inner').eq(thisIndex).removeClass(hideClass);
	   var thisItemCode = $(this).data('code'); // 获取点击的title
	   if (thisItemCode == 'near') { // 点击的为附近
	  	lcj_geolocation();
	  }
	})
	/**
	 * 三级分类点击
	 */
	$(thisBox+' .m-sub-city-group a.f-item').live('click', function(){
		var qtcode = $(this).data('code');
		var qttitle = $(this).data('title');
		$('.qs-temp-txt-' + thistype).text(qttitle);				
		$('.qs-temp-code-' + thistype).val(qtcode);
		$('.qs-temp-input-' + thistype).val(qttitle);
		if ($(this).hasClass('f-range')) {// 附近
		  var cookie_lat = $.fn.cookie('cookie_lat');
		  var cookie_lng = $.fn.cookie('cookie_lng');
		  if(cookie_lat && cookie_lng){
			  $("#lat").val(cookie_lat);
			  $("#lng").val(cookie_lng);
		  }else{
			  alert("无法获取附近定位，请重新退出访问，提示获取地理位置时请同意获取");
			  return false;
		  }
		  $('.qs-temp-code-range').val(qtcode);	
		  $('.qs-temp-code-' + thistype).val('');
		}else{
		  $(".qs-temp-code-range").val("");
		  $("#lat").val("");
		  $("#lng").val("");
		}
		cityclearFilter();
		goPage();			  
	})
		  
   $("#f-mask").trigger("click");
   $('html,body').css({"overflow":"hidden"});

   $('.msp-cancel-btn').on('click', function () {
	  cityclearFilter();
   })
});
$('.msg-input-ser').live('input',function(){
	$('.m-sub-filter-page').addClass('no-head');
	var tVal = $(this).val();
	var $subCityArr = $('.district_val');
	var html = "";
	$.each($subCityArr, function(){
		var eVal = $(this).attr('title');
		var eSpell = $(this).attr('spell');
		if (tVal!="" && (eVal.indexOf(tVal) != -1 || eSpell.indexOf(tVal) != -1)){
			html += "<li>" + $(this).html() + "</li>";
		}
	});
	if (!tVal) {		
		$('.m-sub-filter-page').removeClass('no-head');
		$('.m-sub-filter-page').removeClass('no-data');
	} else {
		$('.m-sub-filter-page').removeClass('no-head');
		$('.m-sub-filter-page').removeClass('no-data');
		if (html) {
			$('.m-sub-city-search-data .m-sub-city-group').html(html);
			$('.m-sub-filter-page').addClass('no-head');
		}else{
			$('.m-sub-filter-page').addClass('no-data');
		}
	}
});
$('.msp-clear-search').live('click', function(){
	$('.msg-input-ser').val('');
	$('.msg-input-ser').trigger('input')
})

//结束所有
});  
/**
 * 清除筛选
 */
function cityclearFilter() {
  $('.m-sub-filter-page').remove();
  $('html,body').css({"overflow":"auto"});
}
/**
 * 获取当前对象的下标
 * @param obj 当前对象
 * @param container 当前容器
 * @returns {*|jQuery} 下标
 */
function getIndex(obj, container) {
  return $(container).index(obj);
}

//筛选附近时定位
function getLocation(){	
  if (navigator.geolocation)	{
	  navigator.geolocation.getCurrentPosition(showPosition, showError,{
		  // 指示浏览器获取高精度的位置，默认为false
		  enableHighAccuracy: true,
		  // 指定获取地理位置的超时时间，默认不限时，单位为毫秒
		  timeout: 5000,
		  // 最长有效期，在重复获取地理位置时，此参数指定多久再次获取位置。
		  maximumAge: 3000
	  });
  }else{
	  baiduapi_geolocation();
  }
}
function showError(error){
	switch(error.code)	{
	  case error.PERMISSION_DENIED:
	  case error.POSITION_UNAVAILABLE:
	  case error.TIMEOUT:
	  case error.UNKNOWN_ERROR:
		  baiduapi_geolocation();
		  break;
	}
}
function showPosition(position){
	set_geolocation_cookie(position.coords.latitude,position.coords.longitude,30);
}
//设置定位cookie
function set_geolocation_cookie(lat,lng,min){
	$("#lat").val(lat);
	$("#lng").val(lng);
	var expiresDate= new Date();
	expiresDate.setTime(expiresDate.getTime() + (min * 60 * 1000));
	$.fn.cookie('cookie_lat', lat,{path : '/',expires:expiresDate});
	$.fn.cookie('cookie_lng', lng,{path : '/',expires:expiresDate});
}
//百度地图定位
function baiduapi_geolocation(){
	var geolocation = new BMap.Geolocation();
	geolocation.getCurrentPosition(function(r){
		if(this.getStatus() == BMAP_STATUS_SUCCESS){
			set_geolocation_cookie(r.point.lat,r.point.lng,30);
		}else {
			set_geolocation_cookie("23.096865","113.3053",5);
		}        
	},{enableHighAccuracy: true})
}
function lcj_geolocation(){
	var cookie_lat = $.fn.cookie('cookie_lat');
	var cookie_lng = $.fn.cookie('cookie_lng');
	if(cookie_lat && cookie_lng){
		$("#lat").val(cookie_lat);
		$("#lng").val(cookie_lng);
	}else{
		getLocation();
	}
}