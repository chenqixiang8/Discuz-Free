//职位搜索js片断=====================================
 //用于判断app的点击了首页的搜索框
 var location_href = window.location.href;
 if(location_href.indexOf("#search")>-1){
	 $('.cjpageso').toggle();
	 $('body').css({"overflow":"hidden"});
 }
// 更多列表左右切换
 $('.js-more-l').on('click', function () {
	 var targetId = $(this).data('id');
	 $('.f-box-more').toggleClass('qs-actionsheet-toggle-left');
	 $('#' + targetId).toggleClass('qs-actionsheet-toggle');
 })
 $('.f-more-back-btn').on('click', function () { // 更多列表切换返回
	 $('.f-box-more').toggleClass('qs-actionsheet-toggle-left');
	 $('.f-more-content').removeClass('qs-actionsheet-toggle');
 })
 $('.f-more-back-a').on('click', function () { // 更多列表项点击
	 var thisType = $(this).data('type');
	 var thisTitle = $(this).data('title');
	 var thisCode = $(this).data('code');
	 $('.f-more-l-code-' + thisType).val(thisCode);
	 $('.f-more-l-txt-' + thisType).text(thisTitle);
	 $('.f-box-more').toggleClass('qs-actionsheet-toggle-left');
	 $('.f-more-content').removeClass('qs-actionsheet-toggle');
 })
	// 除更多和读取缓存之外的下拉列表
 $('.f-item-normal').on('click', function () {
	 var thisType = $(this).data('type');
	 var thisTitle = $(this).data('title');
	 var thisCode = $(this).data('code');
	 $('.f-normal-code-' + thisType).val(thisCode);
	 $('.f-normal-txt-' + thisType).text(thisTitle);
	 $('body').removeClass('filter-fixed');
	 $('.f-box-' + thisType).addClass('cj-hidden');
	 $('.js-filter').removeClass('active');
	 $('#f-mask').hide();
	 goPage();
 })
 // 过滤已投递
 $('.js-clickedbox').on('click', function () {
	 if ($(this).hasClass('clickedchoice')) {
		 $(this).removeClass('clickedchoice');
		 $('.f-deliver').val('0');
	 } else {
		 $(this).addClass('clickedchoice');
		 $('.f-deliver').val('1');
	 }
 })
// 清空已选分类
$('.js-clearjob-jobcategory').on('click', function () {
	$('.qs-recover-code-job').val('');
	goPage();
})
// 点击筛选
$('#f-do-filter').on('click', function () {
	goPage();
});

//qsToast({type:1,context: 3}); 
//分类js断片
//修改高度
var mod_height = $(window).height()-150;
$(".category_selector").height(mod_height);
$(".city_selector").height(mod_height);
 
//判断选择了哪一个大类并显示相应的小类	
$(".category_selector").on("click", ".category-list-I li", function(){
	var cid = $(this).attr("data-id");
	$(".category-list-I li.selected").removeClass("selected");
	$(this).addClass("selected");
	show_category_small(cid);
});
$(".city_selector").on("click", ".category2-list-I li", function(){
	var cid = $(this).attr("data-id");
	$(".category2-list-I li.selected").removeClass("selected");
	$(this).addClass("selected");
	show_category_small2(cid);
});
var selected_cid = $(".category-list-I li.selected").attr("data-id");
var selected2_cid = $(".category2-list-I li.selected").attr("data-id");
if(selected_cid) show_category_small(selected_cid);
if(selected2_cid) show_category_small2(selected_cid);
//根据作品大类显示出小类
function show_category_small(cid)
{  
	$(".category-list-II").hide();
	$("#category_second_"+cid).show(); 
}
function show_category_small2(cid)
{  
	$(".category2-list-II").hide();
	$("#category2_second2_"+cid).show(); 
}  
//内容过高时显示查看更多按钮
$('.cj_more').on('click',function(){
  var prev = $(this).prev();
  var child = $(this).children('.showbtn');
  if(prev.hasClass('desc')){
	child.html('收起展示');
	prev.removeClass('desc');
	child.addClass('topbtn');
  }else{
	child.html('查看更多');
	prev.addClass('desc');
	child.removeClass('topbtn');
  }
});
if ($(".cj_txt .cj-des-wrapper").length > 0){
	var des_height = $(".cj-des-wrapper").height();
	if(des_height>260){
		$(".cj_txt").addClass('desc');
		$(".cj_more").show();
	}
}
//职位举报显示隐藏  
$('.baoxian_close').on('click',function(){
	$('.baoxian_layer').css("display","none");
});
$('.jubao-font,.jubao-logo').on('click',function(){
	$('.baoxian_layer').css("display","block");
});
 
// 申请职位点击事件绑定
$(".apply_jobs").on('click',function(){
  var obj = $(this);
  var url = qscms.root+"&model=ajaxpersonal&ac=resume_apply";
  var jid = $(this).data('jid');
  var jidname = $(this).data('jidname');
  var comuid = $(this).data('comuid');
  var comid = $(this).data('comid');
  var comname = $(this).data('comname');
  var isVisitor = (typeof($("input[name='hide_isVisitor']").val())!="undefined") ? $("input[name='hide_isVisitor']").val() : 0;
  var utype = (typeof($("input[name='hide_utype']").val())!="undefined") ? $("input[name='hide_utype']").val() : 0;
  if ((isVisitor > 0)) {
	if(utype != 2){
	  var dialogType = new QSpopout();
	  dialogType.setContent('您当前为企业帐户，无法操作！您可以切换个人帐户或重新登录个人帐户');
	  dialogType.show();
	  dialogType.setBtn(2, ['取消', '切换个人帐户']);
	  dialogType.getPrimaryBtn().on('click', function () {
		  window.location.href = qscms.root+"&model=mypersonal";
	  });			
	  //qsToast({type:2,context: '请登录个人会员'});
	  return false;
	}
	$.getJSON(url,{jid:jid,jidname:jidname,comuid:comuid,comid:comid,comname:comname},function(result){
	  if(result.status==1){
	  	if(result.data=='no'){
	  		var dialog = new QSpopout();
	  		dialog.setContent(result.msg);
	  		dialog.setBtn(1,'确定');
	  		dialog.show();
	  		return false;
	  	}
		  window.location.reload();
		  //window.location.href = location.href+'&totel=1';
		qsToast({type:1,context: result.msg});
	  } else {
		if(result['msg'].indexOf('请您先创建简历')!=-1){
			var dialogType = new QSpopout();
			dialogType.setContent('投递失败，请您先创建简历后才能投递简历');
			dialogType.show();
			dialogType.setBtn(2, ['取消', '创建简历']);
			dialogType.getPrimaryBtn().on('click', function () {
				window.location.href=qscms.root+'&model=resume_edit_basis';
			});				
		}else{
			qsToast({type:2,context: result.msg});
		}
		return false;
	  }
	});
  }else{
  	  tologin();
	  //qsToast({type:2,context: '登录后才可以投递简历'});
	  return false;
  }
});

// 发送消息【包括对于职位、简历、企业发送消息】
$(".fasixin").on('click',function(){
	var thisObj = $(this);
	var touid = thisObj.attr("data-touid");
	var type = (typeof(thisObj.attr("data-type"))!='undefined') ? thisObj.attr("data-type") : 1;
	var pid = (typeof(thisObj.attr("data-pid"))!='undefined') ? thisObj.attr("data-pid") : 0;
	var tra_id = (typeof(thisObj.attr("data-traid"))!='undefined') ? thisObj.attr("data-traid") : 0;		
	$.getJSON(qscms.root + "?m=Mobile&c=AjaxCommon&a=msg_send",{touid:touid,type:type,pid:pid,tra_id:tra_id},function(result){
		if(result.status==10){
		    var dialogType = new QSpopout();
			dialogType.setContent(result.data.html);
			dialogType.show();
			dialogType.setBtn(1, ['关闭']);
		}else if(result.status == 1){
			if(result.data){
				window.location.href=qscms.root+"?m=Mobile&c=AjaxCommon&a=msg_send&touid="+touid+"&type="+type+"&pid="+pid+"&tra_id="+tra_id+"#applink";
			}else{
				qsToast({type:2,context: result.msg});
			}
		}else{
		  if (result.dialog==1){
			  //登录页面
			  window.location.href=qscms.root+"?m=Mobile&c=Members&a=login";
		  }else{
			  qsToast({type:2,context: result.msg});
		  }
		}			
	});
});	