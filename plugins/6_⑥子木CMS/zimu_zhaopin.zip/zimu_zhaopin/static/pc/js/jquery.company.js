$(document).ready(function(){
	
//分享内容
$("#Jshare").hover(function(){ $("#Jshare").addClass('share-show'); },function(){ $("#Jshare").removeClass('share-show'); });	
//发私信按钮事件	
$(".J_send_msg").on('click',function(){
	var backdropLayerTpl = '<div class="modal_backdrop fade in"></div>';
	$(backdropLayerTpl).appendTo($(document.body));
	$(".pop_leave_msg").css('display','block');
});	
$(".J_realyClose").on('click',function(){
	$(".modal_backdrop").remove();
	$(".pop_leave_msg").css('display','none');
});		
var isVisitor = (typeof($("input[name='hide_isVisitor']").val())!="undefined") ? $("input[name='hide_isVisitor']").val() : 0;

// 收藏职位点击事件绑定
$(".favor").die().live('click',function(){
  var url = qscms.root+"&model=ajaxpersonal&ac=jobs_favorites";
  var jid = $(this).data('jid');
  if ((isVisitor > 0)) {
      $.getJSON(url,{jid:jid},function(result){
		  if(result.status==10){
			  $(this).dialog({title:'操作失败',border:false,content:result.data.html });
		  }else if(result.status==1){		  
             disapperTooltip('success',result.msg);
			 $(".favor").toggleClass('for_cancel');
          } else {
              disapperTooltip('remind',result.msg);
          }
      });
  } else {
	  tologin();
	  return false;
  }
});

// 申请职位点击事件绑定
$(".apply_jobs").die().live('click',function(){
  var qsDialog = $(this).dialog({loading: true,footer: false,header: false,border: false,backdrop: false});
  var jid = $(this).data('jid');
  if (eval(qscms.smsTatus)) {
	  var url = qscms.root+"&model=ajaxpersonal&ac=resume_apply";
      $.getJSON(url,{jid:jid},function(result){
          if(result.status==10){
			  qsDialog.hide();
			  $(this).dialog({title:'操作失败',border:false,content:result.data.html });
		  }else if(result.status==1) {
              if(result.data.html){
                  qsDialog.hide();
                  var qsDialogSon = $(this).dialog({ title: '申请职位', content: result.data.html });
              }else{
                  qsDialog.hide();
                  disapperTooltip("remind", result.msg);
              }
          }else if(result.data==1){
              qsDialog.hide();
              disapperTooltip('remind',result.msg);
              setTimeout(function() {
                  location.href=qscms.root+"?m=Home&c=Personal&a=resume_add";
              },1000);

		}else if(result.data=='noresume'){

              qsDialog.hide();
      var qsDialog = $(this).dialog({
          title: '温馨提醒',
          loading: false,
          border: false,
          btns: ['取消', '立即填写'],
          cancel: function () {
              window.location.href = qscms.root+"&model=personal&ac=index";
          }
      });
      qsDialog.setContent(result.msg);

          }else{
              if (eval(result.dialog)) {
                  var creatsUrl = qscms.root+"?m=Home&c=AjaxPersonal&a=resume_add_dig";
                  $.getJSON(creatsUrl,{jid:jid}, function(result){
                      if(result.status==1){
                          qsDialog.hide();
                          var qsDialogSon = $(this).dialog({content: result.data.html,footer: false,header: false,border: false});
                          qsDialogSon.setInnerPadding(false);
                      } else {
                          qsDialog.hide();
                          disapperTooltip('remind',result.msg);
                      }
                  });
              } else {
                  qsDialog.hide();
                  disapperTooltip('remind',result.msg);
              }
          }
      });
  } else {
	  if ((isVisitor > 0)) {
          var url = qscms.root+"&model=ajaxpersonal&ac=resume_apply";
          $.getJSON(url,{jid:jid},function(result){
			if(result.status==10){
			   qsDialog.hide();
			   $(this).dialog({title:'操作失败',border:false,content:result.data.html });
		  	}else if(result.status==1) {
				if(result.data.html){
					qsDialog.hide();
					var qsDialogSon = $(this).dialog({title: '申请职位',content: result.data.html});
				}
				else {
					qsDialog.hide();
					disapperTooltip("remind", result.msg);
				}
			}else if(result.data==1){
				qsDialog.hide();
				disapperTooltip('remind',result.msg);
				setTimeout(function() {
					location.href=qscms.root+"?m=Home&c=Personal&a=resume_add";
				},1000);

		}else if(result.data=='noresume'){

	 qsDialog.hide();
      var qsDialogSon = $(this).dialog({
          title: '温馨提醒',
          loading: false,
          border: false,
          btns: ['取消', '立即填写'],
          cancel: function () {
              window.location.href = qscms.root+"&model=personal&ac=index";
          }
      });
      qsDialogSon.setContent(result.msg);

			}else{
				if (eval(result.dialog)) {
					var creatsUrl = qscms.root+"?m=Home&c=AjaxPersonal&a=resume_add_dig";
					$.getJSON(creatsUrl,{jid:jid}, function(result){
						if(result.status==1){
							qsDialog.hide();
							var qsDialogSon = $(this).dialog({content: result.data.html,footer: false,header: false,border: false});
							qsDialogSon.setInnerPadding(false);
						} else {
							qsDialog.hide();
							disapperTooltip('remind',result.msg);
						}
					});
				} else {
					qsDialog.hide();
					disapperTooltip('remind',result.msg);
				}
			}
		});
	  }else{
	  	tologin();
	  	return false;
	  }
  }
});

// 简历处理率提示
$('.slitxthelp').hover(function () {
  $(this).find('.tip').show();
},function () {
  $(this).find('.tip').hide();
})


//举报职位
$(".report").click(function(){
	var url = qscms.root+"?m=Home&c=AjaxPersonal&a=report_jobs";
	var qsDialog = $(this).dialog({loading: true,footer: false,header: false,border: false,backdrop: false	});
	var jid = $(this).data('jid');
	$.getJSON(url,{jobs_id:jid},function(result){
	  if(result.status==10){
		 qsDialog.hide();
		 $(this).dialog({title:'操作失败',border:false,content:result.data.html });
	  }else if(result.status==1){
		  qsDialog.hide();
		  var qsDialogSon = $(this).dialog({
			  title:'举报职位',
			  content: result.data,
			  footer: false
		  });
	  } else {
		  if (eval(result.dialog)) {
			  var loginUrl = qscms.root+"?m=Home&c=AjaxCommon&a=get_login_dig";
			  $.getJSON(loginUrl, function(result){
				  if(result.status==1){
					  qsDialog.hide();
					  var qsDialogSon = $(this).dialog({title: '会员登录',content: result.data.html,footer: false,border: false});
					  qsDialogSon.setInnerPadding(false);
				  } else {
					  qsDialog.hide();
					  disapperTooltip('remind',result.msg);
				  }
			  });
		  } else {
			  qsDialog.hide();
			  disapperTooltip('remind',result.msg);
		  }
	  }
	});
});

// 关注企业
$(".abtn").die().live('click',function(){
	var url = qscms.root+"&model=ajaxpersonal&ac=company_focus";
	var company_id = $(this).data('cid');
	if ((isVisitor > 0)) {
		$.getJSON(url,{company_id:company_id},function(result){
			if(result.status==10){
			   $(this).dialog({title:'操作失败',border:false,content:result.data.html });
			}else if(result.status==1){
				disapperTooltip('success',result.msg);
				$(".abtn").html(result.data.html).toggleClass('for_cancel');
				if(result.data.op==1){
					$(".fans_num").html(parseInt($(".fans_num").html())+1);
				}else{
					$(".fans_num").html(parseInt($(".fans_num").html())-1);
				}
			} else {
				disapperTooltip('remind',result.msg);
			}
		});
	} else {
	  	tologin();
	  	return false;
	}
});
});
//复制，使用Ctrl+V粘贴出来
function copyText(id){
	try{
		var targetText = document.getElementById(id);
		targetText.focus();
		targetText.select();
		var clipeText = targetText.createTextRange();
		clipeText.execCommand("Copy");
		alert("已复制，使用Ctrl+V粘贴出来");
	}catch(e){
		alert('您的浏览器不支持剪贴板复制\n请按Ctrl+C复制链接');
	}
}