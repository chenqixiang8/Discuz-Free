/* ============================================================
 * jquery.resumelist.js  简历搜索列表页面js集合
 * ============================================================ */
!function($) {
	//新增地区选择
	$('.J_choose_city').click(function() {
		$('.showSearchModal').click();
	});
	$("body").on("click", ".J_list_city,.J_btnyes", function() {
	  setTimeout(function(){ $(".ajax_search_location").submit(); },300);
	});
    // 关键字联想
	if($("#autoKeyInput").length){
	  var hotKey = $('#autoKeyInput').autocomplete({
		  serviceUrl:qscms.root+"?m=Home&c=ajaxCommon&a=hotword",
		  minChars:1,
		  maxHeight:280,
		  width:500,
		  zIndex: 1,
		  deferRequestBy: 0
	  });
	}

	// 收起、展开筛选条件
	foldAction('.J_showbtn', '.J_so_condition');
	function foldAction(trigger, performer) {
		$(trigger).click(function() {
			$(this).addClass('none').siblings().removeClass('none');
			var indexValue = $(trigger).index(this);
			if (indexValue) {
				$(performer).slideUp();
			} else {
				$(performer).slideDown();
			}
		})
	}

	// 周边人才和热门人才切换
	$('.J_resume_hotnear').click(function() {
		$(this).addClass('select').siblings('.J_resume_hotnear').removeClass('select');
		var indexValue = $('.J_resume_hotnear').index(this);
		$('.J_resume_hotnear_show').removeClass('show');
		$('.J_resume_hotnear_show').eq(indexValue).addClass('show');
	});

	// 全选、反选
	$('.J_allSelected').click(function() {
		var isChecked = $(this).hasClass('select');
		var listArray = $('.J_allListBox .J_allList');
		if (isChecked) {
			$(this).removeClass('select');
			$.each(listArray, function(index, val) {
				$(this).removeClass('select');
			});
			$('.J_resumeList').removeClass('select');
		} else {
			$(this).addClass('select');
			$.each(listArray, function(index, val) {
				$(this).addClass('select');
			});
			$('.J_resumeList').addClass('select');
		}
		
	});
	$('.J_allList').click(function(){
		var isChecked = $(this).hasClass('select');
		if (isChecked) {
			$(this).removeClass('select');
			$(this).closest('.J_resumeList').removeClass('select');
			$('.J_allSelected').removeClass('select');
		} else {
			$(this).addClass('select');
			$(this).closest('.J_resumeList').addClass('select');
			var listArray = $('.J_allListBox .J_allList');
			var listCheckedArray = $('.J_allListBox .J_allList.select');
			if (listArray.length == listCheckedArray.length) {
				$('.J_allSelected').addClass('select');
			}
		}
	});

	// 下载、收藏简历
	resumeSomething('.J_downResume', '下载成功！', true);
	resumeSomething_collect('.J_collectForResume', '收藏成功！', false);

	function resumeSomething_collect (trigger, successMsg, isdown) {
		$(trigger).click(function() {

var isVisitor = (typeof($("input[name='hide_isVisitor']").val())!="undefined") ? $("input[name='hide_isVisitor']").val() : 0;
if (isVisitor <= 0) {tologin();return false;}

			var obj = $(this);
			var batch = eval($(this).data('batch'));
			var url = $(this).data('url');
			var ridValue = '';
			var isType = '';
			if (batch) {
				if (listCheckEmpty()) {
					disapperTooltip('remind','您还没有选择简历！');
					return false;
				} else {
					var listCheckedObjs = $('.J_allListBox .J_allList.select');
					var ridArray = new Array();
					$.each(listCheckedObjs, function(index, val) {
						ridArray[index] = $(this).closest('.J_resumeList').data('rid');
					});
					ridValue = ridArray.join(',');
				}
			} else {
				ridValue = $(this).closest('.J_resumeList').data('rid');
			}
			isdown ? isType = 'GET' : isType = 'POST';
			$.ajax({
				url: url,
				type: isType,
				dataType: 'json',
				data: {rid: ridValue}
			})
			.done(function(data) {
				if (parseInt(data.status)) {
					if(data.status==10){
						$(this).dialog({title:'操作失败',border:false,content:data.data.html });
					}else if(data.status==1){

				if(data.data=='tocom_info'){

      var qsDialog = $(this).dialog({
          title: '温馨提醒',
          loading: false,
          border: false,
          btns: ['取消', '立即填写'],
          cancel: function () {
              window.location.href = qscms.root+"&model=company&ac=com_info";
          }
      });
      qsDialog.setContent('您还未填写企业信息，填写企业信息后享受更多优质服务');
      
				}else{

							if(trigger == '.J_collectForResume'){
								if (data.data == 'has') {
									$(obj).removeClass('favorites2');
									$(obj).text('收藏');
									disapperTooltip('success', '取消收藏成功！');
								} else {
									$(obj).addClass('favorites2');
									$(obj).text('已收藏');
									disapperTooltip('success', successMsg);
								}
							}

				}

				}
				} else {
					if (eval(data.dialog)) {
						var qsDialog = $(this).dialog({
			        		loading: true,
							footer: false,
							header: false,
							backdrop: false
						});
						var loginUrl = qscms.root + '?m=Home&c=AjaxCommon&a=get_login_dig';
						$.getJSON(loginUrl, function(result){
				            if(result.status==1){
								qsDialog.hide();
								var qsDialogSon = $(this).dialog({
									title: '会员登录',
									content: result.data.html,
									footer: false
								});
				    			qsDialogSon.setInnerPadding(false);
				            } else {
				            	qsDialog.hide();
				                disapperTooltip("remind", result.msg);
				            }
				        });
					} else {
						disapperTooltip("remind", data.msg);
					}
				}

			})
		});
	}


	function resumeSomething (trigger, successMsg, isdown) {
		$(trigger).click(function() {

var isVisitor = (typeof($("input[name='hide_isVisitor']").val())!="undefined") ? $("input[name='hide_isVisitor']").val() : 0;
if (isVisitor <= 0) {tologin();return false;}

			var obj = $(this);
			var batch = eval($(this).data('batch'));
			var url = $(this).data('url');
			var ridValue = '';
			var isType = '';
			if (batch) {
				if (listCheckEmpty()) {
					disapperTooltip('remind','您还没有选择简历！');
					return false;
				} else {
					var listCheckedObjs = $('.J_allListBox .J_allList.select');
					var ridArray = new Array();
					$.each(listCheckedObjs, function(index, val) {
						ridArray[index] = $(this).closest('.J_resumeList').data('rid');
					});
					ridValue = ridArray.join(',');
				}
			} else {
				ridValue = $(this).closest('.J_resumeList').data('rid');
			}
			isdown ? isType = 'GET' : isType = 'POST';
			$.ajax({
				url: url,
				type: isType,
				dataType: 'json',
				data: {rid: ridValue}
			})
			.done(function(data) {
				if (parseInt(data.status)) {
					if(data.status==10){
						$(this).dialog({title:'操作失败',border:false,content:data.data.html });
					}else if(data.status==1){

				if(data.data=='no' || data.data=='mix' ){

						$(this).dialog({
							title: '下载简历',
							footer: false,
							content:data.msg
						});

				}else if(data.data=='mix2'){

      var qsDialog = $(this).dialog({
          title: '下载简历',
          loading: false,
          border: false,
          btns: ['取消', '升级套餐'],
          cancel: function () {
              window.location.href = qscms.root+"&model=companyservice&ac=setmeal_add";
          }
      });
      qsDialog.setContent(data.msg);

				}else if(data.data=='tocom_info'){

      var qsDialog = $(this).dialog({
          title: '温馨提醒',
          loading: false,
          border: false,
          btns: ['取消', '立即填写'],
          cancel: function () {
              window.location.href = qscms.root+"&model=company&ac=com_info";
          }
      });
      qsDialog.setContent('您还未填写企业信息，填写企业信息后享受更多优质服务');
      
				}else{

				var url = qscms.root+"&model=ajaxcompany&ac=resume_down";

				var qsDialog = $(this).dialog({
					title: '下载简历',
					loading: false,
					border: false,
					btns: ['确定', '取消'],
					yes: function () {
						$.getJSON(url,{rid:ridValue},function(result){
							if(result.status==1){
								disapperTooltip('success', result.msg);
								setTimeout(function(){
									window.location.reload();
								},2000);
							} else {
								disapperTooltip('success', result.msg);
								return false;
							}
						});
					}
				});
				qsDialog.setContent(data.msg);


				}


					}else if (isdown) {
						$(this).dialog({
							title: '下载简历',
							footer: false,
							content:data.msg
						});
					} else {

							if(trigger == '.J_collectForResume'){
								if (data.data == 'has') {
									$(obj).removeClass('favorites2');
									$(obj).text('收藏');
									disapperTooltip('success', '取消收藏成功！');
								} else {
									$(obj).addClass('favorites2');
									$(obj).text('已收藏');
									disapperTooltip('success', successMsg);
								}
							}

							if(trigger == '.J_downResume'){
								$(obj).addClass('btn_lightgray');
								$(obj).text('已下载');
								disapperTooltip('success', successMsg);
							}

					}
				} else {
					if (eval(data.dialog)) {
						var qsDialog = $(this).dialog({
			        		loading: true,
							footer: false,
							header: false,
							backdrop: false
						});
						var loginUrl = qscms.root + '?m=Home&c=AjaxCommon&a=get_login_dig';
						$.getJSON(loginUrl, function(result){
				            if(result.status==1){
								qsDialog.hide();
								var qsDialogSon = $(this).dialog({
									title: '会员登录',
									content: result.data.html,
									footer: false
								});
				    			qsDialogSon.setInnerPadding(false);
				            } else {
				            	qsDialog.hide();
				                disapperTooltip("remind", result.msg);
				            }
				        });
					} else {
						disapperTooltip("remind", data.msg);
					}
				}

			})
		});
	}

	// 判断列表中是否有选中的项目
	function listCheckEmpty() {
		var listCheckedArray = $('.J_allListBox .J_allList.select');
		if (listCheckedArray.length) {
			return false;
		} else {
			return true;
		}
	}

	// 专业类别相关js
	var majorValue = $('input[name="major"]').val();
	if (majorValue) {
		if(!majorValue.length) {
			$('.tab_list').eq(0).addClass('select');
			$('.tab_content').eq(0).addClass('select');
		} else {
			var recoverIndex = $('.tab_list').index($('.tab_list.select'));
			$('.tab_content').eq(recoverIndex).addClass('select');
		}
	} else {
		$('.tab_list').eq(0).addClass('select');
		$('.tab_content').eq(0).addClass('select');
	}
	$('.tab_list').click(function () {
		$(this).addClass('select').siblings().removeClass('select');
		var thisIndex = $('.tab_list').index(this);
		$('.tab_content').eq(thisIndex).addClass('select').siblings('.tab_content').removeClass('select');
	});

	//列表职位名称鼠标经过离开事件
	$('.J_resumeList h3.name').hover(function(){ 
	  $(this).addClass('cur');
	},function(){ 
	$(this).removeClass('cur');
	}); 
	
	// 立即登录
	$('.J_login').die().live('click', function() {
	  var qsDialog = $(this).dialog({
		loading: true,
		footer: false,
		header: false,
		border: false,
		backdrop: false
	  });
	  var loginUrl = qscms.root+"?m=Home&c=AjaxCommon&a=get_login_dig";
	  $.getJSON(loginUrl, function(result){
		if(result.status==1){
			qsDialog.hide();
			var qsDialogSon = $(this).dialog({
				title: '会员登录',
				content: result.data.html,
				footer: false,
				border: false
			});
			qsDialogSon.setInnerPadding(false);
		} else {
			qsDialog.hide();
			disapperTooltip('remind',result.msg);
		}
	  });
	});	
}(window.jQuery);