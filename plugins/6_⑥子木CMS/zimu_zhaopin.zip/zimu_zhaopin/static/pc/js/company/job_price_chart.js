$(document).ready(function(){
  //竞争力分析
  var default_id = $.trim($("#id").val());
  if(default_id!=""){
	 setTimeout(function(){ jingzhengli(); },500); 
  }
  $("body").on("click", ".modal_body_box_jl2 .J_list_jobs", function() {
	 setTimeout(function(){ jingzhengli(); },500); 
  });
  function jingzhengli(){
      var jobcategory = $.trim($('#jobcategory').val());
	  var minwage = $.trim($("#minwage").val());
	  var maxwage = $.trim($("#maxwage").val());
	  if(jobcategory!="" && minwage!="" && maxwage!="") {
		  $.getJSON(qscms.root+"?m=Home&c=Company&a=job_price_chart",{jingzheng:1,jobcategory:jobcategory,minwage:minwage,maxwage:maxwage},function(result){
			  for (var i = 0; i <= 5; i++) {  
				$(".signalContainer").removeClass("signalContainerQ"+i);
			  } 
			  if (result.status == 1) {		
				  $(".signalContainer").addClass("signalContainerQ"+result['data']['jingzheng']);	  
			  } else {
				  $(".signalContainer").addClass("signalContainerQ0");
			  }
		  });
	  }
  }
  //自定义价格
  $(".autoJobWage").click(function(){
	  if($(this).attr("data-val")=='range'){
		  $(".autoJobWage").attr('data-val','auto').text("取消自定义");
		  $(".salary-range").hide();
		  $(".salary-auto").show();
	  }else{
		  $(".salary-contect .k-form-item__error").text("").hide();
		  $(".autoJobWage").attr('data-val','range').text("自定义");
		  $(".salary-range").show();
		  $(".salary-auto").hide();		  
	  }
	  $(".salary-contect .J_listitme_text").text("请选择");
	  $(".salary-contect .J_listitme_code").val("");
	  $("#minwage").val("");
	  $("#maxwage").val("");	  	  
  });
  
  //弹层提示价格
  $(".toSalaryBar,.signalContainer").click(function(){
      var url = $(this).attr('url');
      var qsDialog = $(this).dialog({
          title: '全行业薪资竞争力分析',
          loading: true,
          border: false,
		  footer:false
      });
      var jobcategory = $('#jobcategory').val();
	  var minwage = $("#minwage").val();
	  var maxwage = $("#maxwage").val();	  
      $.getJSON(qscms.root+"?m=Home&c=Company&a=job_price_chart",{jobcategory:jobcategory,minwage:minwage,maxwage:maxwage},function(result){
          if (result.status == 1) {
              qsDialog.setContent(result.data);
          } else {
			  qsDialog.hide();
              disapperTooltip('remind', result.msg);
          }
      });	  
  });
  $(".J_describe_tip").click(function(){
	var qsDialog = $(this).dialog({
		title: "职位发布规范",
		backdrop: false,
		loading: true,
	});
	$.getJSON(qscms.root+"?m=Home&c=Company&a=job_describe_tip",function(result){
		if(result.status==1){
			qsDialog.setContent(result.data);
		}
	});
  });
  //选择价格时自动分割价格
  $(".dropdowbox13 li").click(function(){
	  var price_col = $(this).find("a").text();
	  var priceCol = price_col.match(/\d+/g).join(',');
	  var strArr = priceCol.split(","); //字符分割
	  var minWage = parseInt(strArr[0]*1000);
	  var maxWage = parseInt(strArr[1]*1000);
	  if(isNaN(maxWage)){
		  maxWage = parseInt(minWage*2);
	  }
	  $("#minwage").val(minWage);
	  $("#maxwage").val(maxWage);
	  setTimeout(function(){ jingzhengli(); },500); 
  });
  //价格离开时发现错误提示
  $("#minwage,#maxwage").blur(function(){
	  var minwageValue = $.trim($('#minwage').val());
	  var maxwageValue = $.trim($('#maxwage').val());
	  if (!minwageValue.length || minwageValue==0) {
		  $(".salary-contect .k-form-item__error").text("请选择或填写最低月薪").show();
		  return false;
	  }
	  if (minwageValue != "" && !regularTelLast.test(minwageValue)) {
		  $(".salary-contect .k-form-item__error").text("最低月薪应为数字").show();
		  return false;
	  }
	  if (!maxwageValue.length || minwageValue==0) {
		  $(".salary-contect .k-form-item__error").text("请选择或填写最高月薪").show();
		  return false;
	  }
	  if (maxwageValue != "" && !regularTelLast.test(maxwageValue)) {
		  $(".salary-contect .k-form-item__error").text("最高月薪应为数字").show();
		  return false;
	  }
	  if (minwageValue != "" && maxwageValue != "" && parseInt(minwageValue) > parseInt(maxwageValue)) {
		  $(".salary-contect .k-form-item__error").text("最低月薪不能大于最高月薪").show();
		  return false;
	  }
	  if (parseInt(maxwageValue) > (parseInt(minwageValue) * 2)) {
		  $(".salary-contect .k-form-item__error").text("最高月薪不能超过最低月薪的2倍").show();
		  return false;
	  }
	  if (parseInt(minwageValue)<1000 || parseInt(maxwageValue)>150000) {
		  $(".salary-contect .k-form-item__error").text("月薪范围1000-150000").show();
		  return false;
	  }	 
	  $(".salary-contect .k-form-item__error").text("").hide();
	  setTimeout(function(){ jingzhengli(); },500); 
  });
});