/* ============================================================
 * jquery.index.js  首页js集合
 * ============================================================
 * ============================================================ */
!function($) {
	//移动端访问时
	// 顶部搜索类型切换
    $('.city-sel').click(function() {
    	$(this).closest('.search-form-con').toggleClass('open');
		$('.selecttype_down .down_list').off().click(function() {
			var type = $(this).data('type');
			var hiddenType = $('#top_search_type').val();
			var txt = $(this).text();
			var originalTxt = $('.label-text b').text();
			$('.label-text b').text(txt);
			$('#top_search_input').attr("placeholder",$(this).attr("data-placeholder"));
			$(this).text(originalTxt);
			$(this).data('type', hiddenType);
			$('#top_search_type').val(type);
		});
    	$(document).on('click', function(e) {
			var target  = $(e.target);
			if (target.closest(".city-sel").length == 0) {
				$('.search-form-con').removeClass('open');
			};
		});
    });	
	// 顶部回车搜索
	$('#top_search_input').bind('keypress', function(event) {
		if (event.keyCode == "13") {
			$("#top_search_btn").click();
		}
	});
    // 顶部搜索跳转
    $('#top_search_btn').click(function() {
    	var keyValue = $.trim($('#top_search_input').val());
    	var searchType = $('#top_search_type').val();
		if(qscms.keyUrlencode==1){
			keyValue = encodeURI(keyValue);
		}
		if(searchType=='QS_jobslist'){
		window.location.href = qscms.root+'&model=jobs&key='+keyValue;
		}
		if(searchType=='QS_resumelist'){
		window.location.href = qscms.root+'&model=resume&key='+keyValue;
		}
    });		

	// 首页顶部轮播广告位
	imgScroll.scroll({name:'imgscroll1',width:'580px',height:'220px',direction:"left",addcss:true,showinfo:"scroll",infodirection:'top',speed:200},4000,450);
	imgScroll.scroll({name:'imgscroll2',width:'312px',height:'220px',direction:"left",addcss:true,showinfo:"scroll",infodirection:'top',speed:200},6000,450);
	imgScroll.scroll({name:'imgscroll3',width:'580px',height:'110px',direction:"left",addcss:true,showinfo:"scroll",infodirection:'top',speed:200},6000,450);
	imgScroll.scroll({name:'imgscroll4',width:'312px',height:'110px',direction:"left",addcss:true,showinfo:"scroll",infodirection:'top',speed:200},6000,450);
	imgScroll.scroll({name:'imgscroll5',width:'580px',height:'110px',direction:"left",addcss:true,showinfo:"scroll",infodirection:'top',speed:200},6000,450);
	imgScroll.scroll({name:'imgscroll6',width:'312px',height:'110px',direction:"left",addcss:true,showinfo:"scroll",infodirection:'top',speed:200},6000,450);	
	
	//首页左侧菜单栏
	$(".catgory-menu-block").hover(function () {
		$(this).addClass("catgory-menu-block_hover");
		$(this).find("ul").show();
	}, function () {
		$(this).removeClass("catgory-menu-block_hover");
		$(this).find("ul").hide();
	});
	// 广告位图片延迟加载
	$("img.lazy").lazyload({
        effect : "fadeIn"
    });
	
	//推荐职位、急聘职位、最新职位
	var isDone = true; // 防止重复点击
	var ajaxpage = {};
	$('.J_change_batch').click(function(){
    	var $url = $(this).data('url');
    	var $thisParent = $(this).closest('.J_change_parent');
		$('.J_change_batch').removeClass('cur');
		$thisParent.find('.ajax_loading').show();
		$(this).addClass('cur');
    	if (isDone) {
    		isDone = false;
            if(!ajaxpage[$url]) ajaxpage[$url] = 1;
        	$.getJSON($url, {p: ajaxpage[$url]}, function(result) {
        		if(result.status == 1){
                    $thisParent.find('.J_change_result').html(result.data.html);
                    isDone = true;
                    if(result.data.isfull){
                        ajaxpage[$url] = 1;
                    }else{
                        ajaxpage[$url]++;
                    }
                }
				$thisParent.find('.ajax_loading').hide();
        	});
    	};		
	});
	//推荐公司
	var company_jobs_arr = new Array();
	var idsValue = '';
	$(".company_jobs_").each(function(index,element){
		company_jobs_arr.push($(this).data('jobuid'));
	});	
	idsValue = company_jobs_arr.join(',');
	
	//延时执行获取数据
	setTimeout(time_delay_data,2000);//延时2秒
	//公告
	setInterval('CjScroll(".gonggaoScroll")',3000); 
}(window.jQuery);
//延时执行获取数据
function time_delay_data(){
	//原创作品
	$.getJSON("/index.php?m=Home&c=index&a=ajax_load_words", function(result) {
		if(result.status == 1){
			$('#ajax_load_words').html(result.data.html);
		}
	});	
}
function CjScroll(obj){ 
  $(obj).find("ul:first").animate({ marginTop:"-45px" },500,function(){  $(this).css({marginTop:"0px"}).find("li:first").appendTo(this); }); 
} 