// JavaScript Document
$(document).ready(function() {
    $("#version_switch").click(function() {
        $.getJSON(qscms.root + '?m=Home&c=AjaxCommon&a=jump_new_tpl&tpl=default', function(result) {
            if (result.status == 1) {
                window.location.href = result.data
            }
        })
    });
    $(".all-nav-list").click(function() {
        $(this).toggleClass('fs');
        $(".dropdown-nav").stop(true, true).slideToggle(200)
    });
    $(".J_hoverbut").hover(function() {
        $(this).toggleClass('hover')
    });
    $('.ajax_search_location').submit(function() {
        var nowKeyValue = $.trim($(this).find('input[name="key"]').val());
        if (nowKeyValue.length && nowKeyValue.length < 2) {
            disapperTooltip("remind", '关健字长度需大于等于2个文字！');
            return !1
        }
        var post_data = $(this).serialize();
        if (qscms.keyUrlencode == 1) {
            post_data = encodeURI(post_data)
        }
        $.post($(this).attr('action'), post_data, function(result) {
            if (result.status == 1) {
                window.location.href = result.data
            } else {
                disapperTooltip("remind", result.msg)
            }
        }, 'json');
        return false
    });
    $(".J_focus input[type='text'][dir!='no_focus'],.J_focus textarea[dir!='no_focus'],.J_focus input[type='password']").focus(function() {
        $(this).addClass("input_focus")
    });
    $(".J_focus input[type='text'][dir!='no_focus'],.J_focus textarea[dir!='no_focus'],.J_focus input[type='password']").blur(function() {
        $(this).removeClass("input_focus")
    });
    $('.J_job_hotnear').click(function() {
        $(this).addClass('select').siblings('.J_job_hotnear').removeClass('select');
        var indexValue = $('.J_job_hotnear').index(this);
        $('.J_job_hotnear_show').removeClass('show');
        $('.J_job_hotnear_show').eq(indexValue).addClass('show')
    });
    $('#username').live('blur', function() {
        var username = $.trim($('#username').val());
        var account_type_default = $.trim($('#account_type_default').val());
        if (username != "" && account_type_default == "") {
            $.ajax({
                url: qscms.root + '?m=Home&c=Members&a=ajax_check',
                dataType: 'json',
                type: 'post',
                cache: false,
                async: false,
                data: {
                    type: 'username_mobile',
                    param: username
                },
                success: function(result) {
                    if (result && result.status == 1) {
                        var qsDialogSon = $(this).dialog({
                            title: '此用户名含多个帐号',
                            closeBtn: false,
                            content: result.data,
                            yes: function() {
                                qsDialogSon.setCloseDialog(false);
                                var ajax_check_username = $.trim($('input:radio[name="ajax_check_username"]:checked').val());
                                var ajax_check_login_type = $.trim($('input[name="ajax_check_login_type"]').val());
                                if (ajax_check_username == "") {
                                    disapperTooltip('remind', '请选择您的会员帐号进行登录');
                                    return false
                                } else {
                                    $('input[name="username"]').val(ajax_check_username);
                                    $('#account_type_default').val(ajax_check_login_type);
                                    qsDialogSon.hide()
                                }
                            },
                            cancel: function() {
                                qsDialogSon.setCloseDialog(false);
                                qsDialogSon.hide();
                                $('input[name="password"]').val("")
                            }
                        })
                    }
                }
            })
        }
    });
    $(".fasixin").live('click', function() {
        var thisObj = $(this);
        var touid = thisObj.attr("data-touid");
        var type = (typeof (thisObj.attr("data-type")) != 'undefined') ? thisObj.attr("data-type") : 1;
        var pid = (typeof (thisObj.attr("data-pid")) != 'undefined') ? thisObj.attr("data-pid") : 0;
        var tra_id = (typeof (thisObj.attr("data-traid")) != 'undefined') ? thisObj.attr("data-traid") : 0;
        var qsDialog = $(this).dialog({
            loading: true,
            footer: false,
            header: false,
            border: false,
            backdrop: false
        });
        $.getJSON(qscms.root + "?m=Home&c=AjaxCommon&a=msg_send", {
            touid: touid,
            type: type,
            pid: pid,
            tra_id: tra_id
        }, function(result) {
            if (result.status == 10) {
                qsDialog.hide();
                $(this).dialog({
                    title: '操作失败',
                    border: false,
                    content: result.data.html
                })
            } else if (result.status == 1) {
                qsDialog.hide();
                if (result.data) {
                    var qsDialogSon = $(this).dialog({
                        title: '立即沟通',
                        footer: false,
                        content: result.data
                    })
                } else {
                    disapperTooltip("remind", result.msg)
                }
            } else {
                qsDialog.hide();
                if (result.dialog == 1) {
                    dialog_login()
                } else {
                    disapperTooltip("remind", result.msg)
                }
            }
        })
    })
});
function dialog_login() {
    $.getJSON(qscms.root + "?m=Home&c=AjaxCommon&a=get_login_dig", function(result) {
        if (result.status == 1) {
            var qsDialogSon = $(this).dialog({
                title: '会员登录',
                content: result.data.html,
                footer: false,
                border: false
            });
            qsDialogSon.setInnerPadding(false)
        } else {
            disapperTooltip('remind', result.msg)
        }
    })
}
//jQuery.cookie
jQuery.cookie = function(name, value, options) {
    if (typeof value != 'undefined') {
        options = options || {};
        if (value === null) {
            value = '';
            options = $.extend({}, options);
            options.expires = -1
        }
        var expires = '';
        if (options.expires && (typeof options.expires == 'number' || options.expires.toUTCString)) {
            var date;
            if (typeof options.expires == 'number') {
                date = new Date();
                date.setTime(date.getTime() + (options.expires * 24 * 60 * 60 * 1000))
            } else {
                date = options.expires
            }
            expires = '; expires=' + date.toUTCString()
        }
        var path = options.path ? '; path=' + (options.path) : '';
        var domain = options.domain ? '; domain=' + (options.domain) : '';
        var secure = options.secure ? '; secure' : '';
        document.cookie = [name, '=', encodeURIComponent(value), expires, path, domain, secure].join('')
    } else {
        var cookieValue = null;
        if (document.cookie && document.cookie != '') {
            var cookies = document.cookie.split(';');
            for (var i = 0; i < cookies.length; i++) {
                var cookie = jQuery.trim(cookies[i]);
                if (cookie.substring(0, name.length + 1) == (name + '=')) {
                    cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                    break
                }
            }
        }
        return cookieValue
    }
};

function tologin(){
    window.location.href = qscms.base+qscms.root+"&model=tologin";
}