/*
 *上传附件
 *form     flie元素ID容
 *option   上传附件的参数  
 *fun      上传成功回调函数
 *before   上传附件前回调函数
 *going    执行上传附件时显示内容(默认为"请稍后...")
*/
(function($){
	$.upload = function(form,option,fun,before,going){
		var settings = {
				type:'image'
			};
		if(option) $.extend(settings,option);
		new AjaxUpload(form,{
			action:qscms.root + '&model=upload',
			name:$(form).attr('name'),
			data:settings,
			responseType:'json',
			/*onChange:function(file,ext){
				if(!$.trim($(file).val())) return !1;
			},*/
			onSubmit:function(file,ext){
				if(ext && /^(jpg|jpeg|png|gif|doc|docx|txt|rar|zip|bmp|xls|xlsx)$/.test(ext)){
					var af = this._input.files;
					var byteSize = af[0].size;
					if ((byteSize / 1024) > (10 * 1024)) {
						alert('图片最大只能上传10MB');
						return false;
					} else {
						if(before && !1 == before()) return !1;
						//ext是后缀名
						form.disabled = "disabled";
					}
					if(before && !1 == before()) return !1;
					form.disabled = "disabled";
				} else {
					alert('您上传了不支持的格式，请重新上传！');
					return false;
				}
				if(before && !1 == before()) return !1;
				form.disabled = "disabled";
			},
			onComplete:function(file,result){
				form.disabled = "";
				if(result.status==1){
					fun && fun(result);
				}else{
					if(typeof(result.msg)=="undefined"){
						alert("上传失败，可能原因：文件超过最大限制 或 文件格式有误");
					}else{
						alert(result.msg);
					}
					if(result.dialog) location.reload();
				}
			}
		});
	};
})(jQuery);