//右侧通用导航，过滤不显示页面小写
//QQ右侧客服、回到顶部
$(document).ready(function() {
    $('.J_sidebar_tip').live('hover', function() {
        $(this).toggleClass('hover')
    });
    $('#J_sidebar_back_top').live('click', function() {
        $("html,body").animate({
            "scrollTop": 0
        }, 500)
    });
    $('html').on('click', "*:not('#J_sidebar,.modal')", function(e) {
        if ($(e.target).parents('#J_sidebar').length)
            return;
        if ($(e.target).parents('.modal').length)
            return;
        clickCloseSidebar()
    });
    $("#J_sidebar_hide").live('click', function() {
        $("#J_sidebar_msg_btn").addClass("active");
        clickCloseSidebar()
    });
    $("#J_sidebar_user_btn").live('click', function() {
        if ($("#J_sidebar_user_btn").hasClass("active")) {
            clickCloseSidebar()
        } else {
            clickOpenSidebar('#J_sidebar_user');
            $.getJSON(qscms.root + "/?m=Home&c=AjaxSidebar&a=sidebar_account", function(result) {
                var SidebarPanelB = $('#J_sidebar_user .e-sidebar-panel-b');
                if (result.status == 1) {
                    SidebarPanelB.html(result.data.html)
                } else {
                    SidebarPanelB.html('<div class="nothign">' + result.msg + '</div>')
                }
            })
        }
    });
    $("#J_sidebar_msg_btn").live('click', function() {
        if ($("#J_sidebar_msg_btn").hasClass("active")) {
            clickCloseSidebar()
        } else {
            clickOpenSidebar('#J_sidebar_msg');
            $.getJSON(qscms.root + "/?m=Home&c=AjaxSidebar&a=sidebar_msg", function(result) {
                var SidebarPanelB = $('#J_sidebar_msg .e-sidebar-panel-b');
                if (result.status == 1) {
                    SidebarPanelB.html(result.data.html)
                } else {
                    SidebarPanelB.html('<div class="nothign">' + result.msg + '</div>')
                }
            })
        }
    });
    $(".J_sidebar_msg_type").live('click', function() {
        var type = $(this).attr('data-type');
        $.getJSON(qscms.root + "/?m=Home&c=AjaxSidebar&a=sidebar_msg", {
            type: type
        }, function(result) {
            var SidebarPanelB = $('#J_sidebar_msg .e-sidebar-panel-b');
            if (result.status == 1) {
                SidebarPanelB.html(result.data.html)
            } else {
                SidebarPanelB.html('<div class="nothign">' + result.msg + '</div>')
            }
        })
    });
    $('#J_sidebar_refresh_resume').live('click', function() {
        var pid = $(this).attr('pid');
        var _audit = $(this).attr('_audit');
        var is_display = eval($(this).attr('is_display'));
        if (_audit != 1) {
            disapperTooltip('remind', "审核中或未通过的简历无法刷新！")
        } else if (!is_display) {
            disapperTooltip('remind', "默认简历已关闭，无法刷新！")
        } else {
            $.post(qscms.root + "/?m=Home&c=Personal&a=refresh_resume", {
                pid: pid
            }, function(result) {
                if (result.status == 1) {
                    if (result.data > 0) {
                        disapperTooltip("goldremind", '刷新简历增加' + result.data + '积分<span class="point">+' + result.data + '</span>')
                    } else {
                        disapperTooltip('success', result.msg)
                    }
                } else {
                    disapperTooltip('remind', result.msg)
                }
            }, 'json')
        }
    });
    $("#J_sidebar_tuijian_btn").live('click', function() {
        if ($("#J_sidebar_tuijian_btn").hasClass("active")) {
            clickCloseSidebar()
        } else {
            clickOpenSidebar('#J_sidebar_tuijian');
            $.getJSON(qscms.root + "/?m=Home&c=AjaxSidebar&a=sidebar_tuijian", function(result) {
                var SidebarPanelB = $('#J_sidebar_tuijian .e-sidebar-panel-b');
                if (result.status == 1) {
                    SidebarPanelB.html(result.data.html)
                } else {
                    SidebarPanelB.html('<div class="nothign">' + result.msg + '</div>')
                }
            })
        }
    });
    $('.J_tuijian_refresh').live('click', function(event) {
        var obj = $(this);
        var ajaxpage = parseInt(obj.attr('ajaxpage'));
        $('.J_tuijian_tab_menu').find('.ajax_loading').show();
        $.getJSON(qscms.root + "/?m=Home&c=AjaxSidebar&a=sidebar_tuijian", {
            p: ajaxpage
        }, function(data) {
            $('.J_tuijian_tab_menu').find('.J_tuijian_tab_menu_html').html(data.data.html);
            $('.J_tuijian_tab_menu').find('.ajax_loading').hide()
        })
    });
    $("#J_sidebar_favor_btn").live('click', function() {
        if ($("#J_sidebar_favor_btn").hasClass("active")) {
            clickCloseSidebar()
        } else {
            clickOpenSidebar('#J_sidebar_favor');
            $.getJSON(qscms.root + "/?m=Home&c=AjaxSidebar&a=sidebar_favor", function(result) {
                var SidebarPanelB = $('#J_sidebar_favor .e-sidebar-panel-b');
                if (result.status == 1) {
                    SidebarPanelB.html(result.data.html)
                } else {
                    SidebarPanelB.html('<div class="nothign">' + result.msg + '</div>')
                }
            })
        }
    });
    $(".J_sidebar_favor_type").live('click', function() {
        var type = $(this).attr('data-type');
        $.getJSON(qscms.root + "/?m=Home&c=AjaxSidebar&a=sidebar_favor", {
            type: type
        }, function(result) {
            var SidebarPanelB = $('#J_sidebar_favor .e-sidebar-panel-b');
            if (result.status == 1) {
                SidebarPanelB.html(result.data.html)
            } else {
                SidebarPanelB.html('<div class="nothign">' + result.msg + '</div>')
            }
        })
    });
    $("#J_sidebar_history_btn").live('click', function() {
        if ($("#J_sidebar_history_btn").hasClass("active")) {
            clickCloseSidebar()
        } else {
            clickOpenSidebar('#J_sidebar_history');
            $.getJSON(qscms.root + "/?m=Home&c=AjaxSidebar&a=sidebar_history", function(result) {
                var SidebarPanelB = $('#J_sidebar_history .e-sidebar-panel-b');
                if (result.status == 1) {
                    SidebarPanelB.html(result.data.html)
                } else {
                    SidebarPanelB.html('<div class="nothign">' + result.msg + '</div>')
                }
            })
        }
    });
    $(".J_sidebar_jobs_refresh").live('click', function() {
        var url = $(this).attr('url');
        var footerShow = eval($(this).data('type'));
        var qsDialog = $(this).dialog({
            title: '职位刷新',
            loading: true,
            showFooter: false,
            yes: function() {
                $.post(url, function(result) {
                    if (result.status) {
                        disapperTooltip("success", result.msg);
                        setTimeout(function() {
                            window.location.reload()
                        }, 2000)
                    } else {
                        disapperTooltip("remind", result.msg);
                        return false
                    }
                }, 'json')
            }
        });
        $.getJSON(url, function(result) {
            if (result.data.show_footer == 0) {
                qsDialog.showFooter(false)
            } else {
                if (!footerShow) {
                    qsDialog.showFooter(true)
                }
            }
            qsDialog.setContent(result.msg)
        })
    });
    $(".J_sidebar_stick_btn").live('click', function() {
        var qsDialog = $(this).dialog({
            title: '职位置顶',
            loading: true,
            showFooter: false
        });
        var url = qscms.root + "/?m=Home&c=CompanyService&a=jobs_stick";
        var jobs_id = $(this).attr('data');
        $.getJSON(url, {
            jobs_id: jobs_id
        }, function(result) {
            qsDialog.setContent(result.msg)
        })
    });
    $(".J_sidebar_emergency_btn").live('click', function() {
        var qsDialog = $(this).dialog({
            title: '职位紧急',
            loading: true,
            showFooter: false
        });
        var url = qscms.root + "/?m=Home&c=CompanyService&a=jobs_emergency";
        var jobs_id = $(this).attr('data');
        $.getJSON(url, {
            jobs_id: jobs_id
        }, function(result) {
            qsDialog.setContent(result.msg)
        })
    });
});
//右侧窗口开始推大来
function clickOpenSidebar(domName) {
    $('#J_sidebar').stop(true);
    $('#J_sidebar').animate({
        'right': 0
    }, 250);
    $('#J_sidebar_hide').stop(true);
    $('#J_sidebar_hide').animate({
        "opacity": "1"
    }, 500);
    $('.e-sidebar-item').removeClass('active');
    $(domName + "_btn").addClass("active");
    $('.e-sidebar-ctn').css('display', 'none');
    $(domName).fadeIn("show")
}
;
function clickCloseSidebar() {
    $('#J_sidebar').stop(true);
    $('#J_sidebar').animate({
        'right': -280
    }, 250);
    $('#J_sidebar_hide').stop(true);
    $('#J_sidebar_hide').animate({
        "opacity": "0"
    }, 500);
    $('.e-sidebar-item').removeClass('active')
}
;
function get_msg_number() {
    var counter = 1;
    var runtime = 60000;
    var myFunction = function() {
        clearInterval(interval);
        $.getJSON(qscms.root + "/?m=Home&c=AjaxSidebar&a=sidebar_msg_count", function(result) {
            if (result.status == 1) {
                if (result.data > 0) {
                    $('.ajax_msg_num').show().html(result.data)
                } else {
                    $('.ajax_msg_num').hide()
                }
                counter++
            }
        });
        if (counter >= 10) {
            runtime = 300000
        }
        if (counter >= 50) {
            runtime = 600000
        }
        if (counter < 100) {
            interval = setInterval(myFunction, runtime)
        }
    };
    var interval = setInterval(myFunction, runtime)
}
;
var global = {
    h: $(window).height(),
    st: $(window).scrollTop(),
    backTop: function() {
        global.st > (global.h * 0.5) ? $("#J_sidebar_back_top").addClass('active') : $("#J_sidebar_back_top").removeClass('active')
    }
};
global.backTop();
$(window).scroll(function() {
    global.h = $(window).height();
    global.st = $(window).scrollTop();
    global.backTop()
});
$(window).resize(function() {
    global.h = $(window).height();
    global.st = $(window).scrollTop();
    global.backTop()
});