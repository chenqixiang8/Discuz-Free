function onPrint(){
  var html = $("#resume_print").html();
  var bodyHtml = document.body.innerHTML;
  document.body.innerHTML = html;
  window.print();
  document.body.innerHTML = bodyHtml;
}

$(document).ready(function(){
	
var isVisitor = (typeof($("input[name='hide_isVisitor']").val())!="undefined") ? $("input[name='hide_isVisitor']").val() : 0;

/*
	// 右侧固定侧边栏
	$('#navRight').stickySidebar({
		sidebarTopMargin: 0,
		footerThreshold: 100
	});
*/	
	// 点击显示作品大图
	$('.J_for_bigimg').die().live('click', function(event) {
		var src = $(this).data('src');
		var qsDialog = $(this).dialog({
			title: '照片作品',
			innerPadding: false,
			border: true,
			content: '<div style="max-width: 900px;max-height: 600px;"><img style="max-width: 900px;max-height: 600px;" src="'+src+'" /></div>',
			showFooter: false
		});
	});
	$('#resume_doc').click(function(){
		if(!isVisitor){
			$.getJSON(qscms.root+"?m=Home&c=AjaxCommon&a=get_login_dig", function(result){
				if(result.status==1){
					var qsDialogSon = $(this).dialog({
						title: '会员登录',
						content: result.data.html,
						footer: false,
						border: false
					});
					qsDialogSon.setInnerPadding(false);
				}else{
					qsDialog.hide();
					disapperTooltip('remind',result.msg);
				}
			});
			return !1;
		}else{
			var rid = $(this).data('rid');			
			javascript:location.href=qscms.root+"?m=Home&c=Resume&a=resume_doc&id="+rid;
		}
	});

	// 下载简历和获取联系方式点击事件绑定
	$(".J_downbtn").die().live('click',function(){

if (isVisitor <= 0) {tologin();return false;}

		var url = $(this).attr('url');
		var rid = $(this).data('rid');

		$.getJSON(url,function(data){			

				if (parseInt(data.status)) {
					if(data.status==10){
						$(this).dialog({title:'操作失败',border:false,content:data.data.html });
					}else if(data.status==1){

				if(data.data=='no' || data.data=='mix' ){

						$(this).dialog({
							title: '下载简历',
							footer: false,
							content:data.msg
						});

				}else if(data.data=='tocom_info'){


      var qsDialog = $(this).dialog({
          title: '温馨提醒',
          loading: false,
          border: false,
          btns: ['取消', '立即填写'],
          cancel: function () {
              window.location.href = qscms.root+"&model=company&ac=com_info";
          }
      });
      qsDialog.setContent('您还未填写企业信息，填写企业信息后享受更多优质服务');


				}else if(data.data=='mix2'){

      var qsDialog = $(this).dialog({
          title: '下载简历',
          loading: false,
          border: false,
          btns: ['取消', '升级套餐'],
          cancel: function () {
              window.location.href = qscms.root+"&model=companyservice&ac=setmeal_add";
          }
      });
      qsDialog.setContent(data.msg);

				}else{

				var url = qscms.root+"&model=ajaxcompany&ac=resume_down";

				var qsDialog = $(this).dialog({
					title: '下载简历',
					loading: false,
					border: false,
					btns: ['确定', '取消'],
					yes: function () {
						$.getJSON(url,{rid:rid},function(result){
							if(result.status==1){
								disapperTooltip('success', result.msg);
								setTimeout(function(){
									window.location.reload();
								},2000);
							} else {
								disapperTooltip('success', result.msg);
								return false;
							}
						});
					}
				});
				qsDialog.setContent(data.msg);


				}

					}else if(data.status==3){
						disapperTooltip("remind", data.msg);
						
					}else if (isdown) {
						$(this).dialog({
							title: '下载简历',
							footer: false,
							content:data.msg
						});
					} else {

							if(trigger == '.J_collectForResume'){
								if (data.data == 'has') {
									$(obj).removeClass('favorites2');
									$(obj).text('收藏');
									disapperTooltip('success', '取消收藏成功！');
								} else {
									$(obj).addClass('favorites2');
									$(obj).text('已收藏');
									disapperTooltip('success', successMsg);
								}
							}

							if(trigger == '.J_downResume'){
								$(obj).addClass('btn_lightgray');
								$(obj).text('已下载');
								disapperTooltip('success', successMsg);
							}

					}
				}
				

		});
	});
	
	// 发送面试邀请
	$('.J_interview').click(function(){
		var id = $(this).data('rid');			
		var qsDialog = $(this).dialog({
			title: '发送面试邀请',
			loading: true,
			footer: false,
			header: false,
			border: false,
			backdrop: false
		});
		$.getJSON(qscms.root+"?m=Home&c=Company&a=jobs_interview_add",{id:id},function(result){
			if(result.status == 1){
				qsDialog.hide();
				var qsDialogSon = $(this).dialog({
					title: '发送面试邀请',
					content: result.data,
					yes: function() {
						var notesVal = $.trim($('input[name="notes"]').val());
						if (notesVal.length > 40) {
							$('input[name="notes"]').focus();
							disapperTooltip('remind','最多输入40个字');
							return false;
						}
						$('.J_btnyes').val('发送中...');
						$.post(qscms.root+"?m=Home&c=Company&a=jobs_interview_add",$('#J_interviewWrap').serialize(),function(result){
							if(result.status == 1){
								qsDialogSon.hide();
								disapperTooltip('success',result.msg);
							} else {
								$('.J_btnyes').val('确定');
								disapperTooltip('remind',result.msg);
							}
						},'json');
					}
				});
				qsDialogSon.setCloseDialog(false);
				// 时间插件
				laydate({
					elem: '#date',
					min: laydate.now()
				})
			} else {
				if (result.dialog==1) {
					var loginUrl = qscms.root+"?m=Home&c=AjaxCommon&a=get_login_dig";
					$.getJSON(loginUrl, function(result){
						if(result.status==1){
							qsDialog.hide();
							var qsDialogSon = $(this).dialog({
								title: '会员登录',
								content: result.data.html,
								footer: false,
								border: false
							});
							qsDialogSon.setInnerPadding(false);
						} else {
							qsDialog.hide();
							disapperTooltip('remind',result.msg);
						}
					});
				} else {
					qsDialog.hide();
					disapperTooltip('remind',result.msg);
				}
			}
		});
	});
	$(".label_resume").live('click',function(){
		var thisObj = $(this);
		$(".label_resume").removeClass('select');
		thisObj.addClass('select');
		var label = thisObj.attr('data');
		var label_type = thisObj.attr('label_type');
		var url = qscms.root+"?m=Home&c=AjaxCompany&a=resume_label";
		var resume_id = $(this).data('rid');		
		$.getJSON(url,{resume_id:resume_id,label:label,label_type:label_type},function(result){
			if(result.status == 1){
				disapperTooltip('success',result.msg);
			}else{
				disapperTooltip('remind',result.msg);
			}
		});
	});

	// 加入人才库
	$(".favor").die().live('click',function(){
		var url = qscms.root+"?m=Home&c=AjaxCompany&a=resume_favor";
		var rid = $(this).data('rid');	
		if ((isVisitor > 0)) {
			$.getJSON(url,{rid:rid},function(result){
				if(result.status==10){
				   $(this).dialog({title:'操作失败',border:false,content:result.data.html });
				}else if(result.status==1){
					disapperTooltip('success',result.msg);
				} else {
					disapperTooltip('remind',result.msg);
				}
			});
		} else {
			var qsDialog = $(this).dialog({
				loading: true,
				footer: false,
				header: false,
				border: false,
				backdrop: false
			});
			var loginUrl = qscms.root+"?m=Home&c=AjaxCommon&a=get_login_dig";
			$.getJSON(loginUrl, function(result){
				if(result.status==1){
					qsDialog.hide();
					var qsDialogSon = $(this).dialog({
						title: '会员登录',
						content: result.data.html,
						footer: false,
						border: false
					});
					qsDialogSon.setInnerPadding(false);
				} else {
					qsDialog.hide();
					disapperTooltip('remind',result.msg);
				}
			});
		}
	});

	// 投诉简历
	$("#report").die().live('click', function(){
		var resume_id = $(this).data('rid');	
		var url = qscms.root+"?m=Home&c=AjaxCompany&a=report_resume";
		var qsDialog = $(this).dialog({
			loading: true,
			footer: false,
			header: false,
			border: false,
			backdrop: false
		});
		$.getJSON(url,{resume_id:resume_id},function(result){
			if(result.status==10){
				qsDialog.hide();
				$(this).dialog({title:'操作失败',border:false,content:result.data.html });
			}else if(result.status==1){
				qsDialog.hide();
				var qsDialogSon = $(this).dialog({
					title:'举报简历',
					content: result.data,
					footer: false
				});
			} else {
				if (eval(result.dialog)) {
					var loginUrl = qscms.root+"?m=Home&c=AjaxCommon&a=get_login_dig";
					$.getJSON(loginUrl, function(result){
						if(result.status==1){
							qsDialog.hide();
							var qsDialogSon = $(this).dialog({
								title: '会员登录',
								content: result.data.html,
								footer: false,
								border: false
							});
							qsDialogSon.setInnerPadding(false);
						} else {
							qsDialog.hide();
							disapperTooltip('remind',result.msg);
						}
					});
				} else {
					qsDialog.hide();
					disapperTooltip('remind',result.msg);
				}
			}
		});
	});
});