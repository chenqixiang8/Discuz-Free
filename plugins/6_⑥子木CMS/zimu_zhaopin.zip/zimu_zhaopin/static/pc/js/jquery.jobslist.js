/* ============================================================
 * jquery.jobslist.js  职位搜索列表页面js集合
 * ============================================================ */
!function($) {
	//新增地区选择
	$('.J_choose_city').click(function() {
		$('.showSearchModal').click();
	});
	$("body").on("click", ".modal_body_box3 .J_list_city", function() {
	  setTimeout(function(){ $(".ajax_search_location").submit(); },300);
	});
	if ($("#autoKeyInput").length>0){
	  // 关键字联想
	  var hotKey = $('#autoKeyInput').autocomplete({
		  serviceUrl:qscms.root+"?m=Home&c=ajaxCommon&a=hotword",minChars:1,maxHeight:280,width:500,zIndex: 1,deferRequestBy: 0});	
	}
	// 收起、展开筛选条件
	foldAction('.J_showbtn', '.J_so_condition');
	function foldAction(trigger, performer) {
		$(trigger).click(function() {
			$(this).addClass('none').siblings().removeClass('none');
			var indexValue = $(trigger).index(this);
			if (indexValue) {
				$(performer).slideUp();
			} else {
				$(performer).slideDown();
			}
		})
	}
	// 全选、反选
	$('.J_allSelected').click(function() {
		var isChecked = $(this).hasClass('select');
		var listArray = $('.J_allListBox .J_allList');
		if (isChecked) {
			$(this).removeClass('select');
			$.each(listArray, function(index, val) {
				$(this).removeClass('select');
			});
			$('.J_jobsList').removeClass('select');
		} else {
			$(this).addClass('select');
			$.each(listArray, function(index, val) {
				$(this).addClass('select');
			});
			$('.J_jobsList').addClass('select');
		}
		
	});
	$('.J_allList').click(function(){
		var isChecked = $(this).hasClass('select');
		if (isChecked) {
			$(this).removeClass('select');
			$(this).closest('.J_jobsList').removeClass('select');
			$('.J_allSelected').removeClass('select');
		} else {
			$(this).addClass('select');
			$(this).closest('.J_jobsList').addClass('select');
			var listArray = $('.J_allListBox .J_allList');
			var listCheckedArray = $('.J_allListBox .J_allList.select');
			if (listArray.length == listCheckedArray.length) {
				$('.J_allSelected').addClass('select');
			}
		}
	});

	// 申请、收藏职位
	jobSomething('.J_applyForJob', '申请成功！', true);
	jobSomething('.J_collectForJob', '收藏成功！', false);
	function jobSomething (trigger, successMsg, iscreate) {

		$(trigger).click(function() {

var isVisitor = (typeof($("input[name='hide_isVisitor']").val())!="undefined") ? $("input[name='hide_isVisitor']").val() : 0;
if (isVisitor <= 0) {tologin();return false;}

			var obj = $(this);
			var batch = eval($(this).data('batch'));
			var url = $(this).data('url');
			var jidValue = '';
			if (batch) { // 是否是批量
				if (listCheckEmpty()) {
					disapperTooltip('remind','您还没有选择职位！');
					return false;
				} else {
					var listCheckedObjs = $('.J_allListBox .J_allList.select');
					var jidArray = new Array();
					$.each(listCheckedObjs, function(index, val) {
						jidArray[index] = $(this).closest('.J_jobsList').data('jid');
					});
					jidValue = jidArray.join(',');
				}
			} else {
				jidValue = $(this).closest('.J_jobsList').data('jid');
			}
			$.ajax({
				url: url,
				type: 'POST',
				dataType: 'json',
				data: {jid: jidValue}
			})
			.done(function(data) {
				if (parseInt(data.status)) {
					if(data.status==10){
						$(this).dialog({title:'操作失败',border:false,content:data.data.html });
					}else{
						if(data.data.html){
							$(this).dialog({title:'申请职位',border:false,content:data.data.html });
						}else if(data.data=='no'){
							$(this).dialog({title:'申请职位',border:false,content:data.msg });
						}else if(data.data=='noresume'){

      var qsDialog = $(this).dialog({
          title: '温馨提醒',
          loading: false,
          border: false,
          btns: ['取消', '立即填写'],
          cancel: function () {
              window.location.href = qscms.root+"&model=personal&ac=index";
          }
      });
      qsDialog.setContent(data.msg);


						} else {

							if(trigger == '.J_collectForJob'){
								if (data.data == 'cancel') {
									$(obj).removeClass('favorites2');
									$(obj).text('收藏');
									disapperTooltip('success', '取消收藏成功！');
								} else {
									$(obj).addClass('favorites2');
									$(obj).text('已收藏');
									disapperTooltip('success', successMsg);
								}
							}
							if(trigger == '.J_applyForJob'){
								$(obj).addClass('btn_lightgray');
								$(obj).text('已投递');
								disapperTooltip('success', successMsg);
							}
						}
					}
				}else if(data.data==1){
					location.href=qscms.root+"?m=Home&c=Personal&a=resume_add";
				}else {
					if (eval(data.dialog)) {
						var qsDialog = $(this).dialog({loading: true,footer: false,header: false,border: false,backdrop: false});
						if (iscreate) { // 申请职位
                            if (eval(qscms.smsTatus)) {// 是否开启短信
                                var creatsUrl = qscms.root + '?m=Home&c=AjaxPersonal&a=resume_add_dig';
                                $.getJSON(creatsUrl,{jid:jidValue}, function(result){
                                    if(result.status==1){
                                        qsDialog.hide();
                                        var qsDialogSon = $(this).dialog({content: result.data.html,footer: false,header: false,border: false});
                                        qsDialogSon.setInnerPadding(false);
                                    } else {
                                        qsDialog.hide();
                                        disapperTooltip("remind", result.msg);
                                    }
                                });
                            } else {
                                var loginUrl = qscms.root + '?m=Home&c=AjaxCommon&a=get_login_dig';
                                $.getJSON(loginUrl, function(result){
                                    if(result.status==1){
                                        qsDialog.hide();
                                        var qsDialogSon = $(this).dialog({title: '会员登录',content: result.data.html,footer: false,border: false});
                                        qsDialogSon.setInnerPadding(false);
                                    } else {
                                        qsDialog.hide();
                                        disapperTooltip("remind", result.msg);
                                    }
                                });
                            }
						} else {
							var loginUrl = qscms.root + '?m=Home&c=AjaxCommon&a=get_login_dig';
							$.getJSON(loginUrl, function(result){
					            if(result.status==1){
									qsDialog.hide();
									var qsDialogSon = $(this).dialog({title: '会员登录',content: result.data.html,footer: false,border: false});
					    			qsDialogSon.setInnerPadding(false);
					            } else {
					            	qsDialog.hide();
					                disapperTooltip("remind", result.msg);
					            }
					        });
						}

					}else if(data.data=='noresume'){

      var qsDialog = $(this).dialog({
          title: '温馨提醒',
          loading: false,
          border: false,
          btns: ['取消', '立即填写'],
          cancel: function () {
              window.location.href = qscms.root+"&model=personal&ac=index";
          }
      });
      qsDialog.setContent(data.msg);
      
					} else {
						disapperTooltip("remind", data.msg);
					}
				}
			})
		});
	}
	//列表职位名称鼠标经过离开事件
	$('.J_jobsList h3.name').hover(function(){ 
	  $(this).addClass('cur');
	},function(){ 
	$(this).removeClass('cur');
	}); 

	// 判断列表中是否有选中的项目
	function listCheckEmpty() {
		var listCheckedArray = $('.J_allListBox .J_allList.select');
		if (listCheckedArray.length) {
			return false;
		} else {
			return true;
		}
	}
	// 立即登录
	$('.J_login').die().live('click', function() {
	  var qsDialog = $(this).dialog({loading: true,footer: false,header: false,border: false,backdrop: false});
	  var loginUrl = qscms.root+"?m=Home&c=AjaxCommon&a=get_login_dig";
	  $.getJSON(loginUrl, function(result){
		if(result.status==1){
			qsDialog.hide();
			var qsDialogSon = $(this).dialog({title: '会员登录',content: result.data.html,footer: false,border: false});
			qsDialogSon.setInnerPadding(false);
		} else {
			qsDialog.hide();
			disapperTooltip('remind',result.msg);
		}
	  });
	});	
	//配置公众号订阅器条件生成
	var subscribe = $('.subscribe-wechat-wrapper');
	if(subscribe.length>0 && $.cookie("jobs_subscribe_wechat")!="1") {
		var filterVal = $.trim($("input[name=filter]").val());
		var action_name = $.trim(subscribe.data('action'));
		if(filterVal!=""){
			$.ajax({
				url: qscms.root+"?m=Home&c=Qrcode&a=jobs_subscribe",
				type: "GET",
				data: { filter:encodeURI(filterVal), action_name:action_name },
				dataType: "json",
				success: function(result) {
					console.log(result);
					if(result.status==1){
						var subscribe_html = "";
						subscribe_html += "<a href=\'javascript:;\' class=\'close\' title=\'今天不再显示\' id=\'subscription_close\'></a>";
						subscribe_html += "<dl>";
						subscribe_html += "    <dt><img src=\'"+qscms.root+"?m=Home&c=Qrcode&a=index&url="+result.data.url+"\'></dt>";
						subscribe_html += "    <dd>微信扫一扫</dd>";
						subscribe_html += "</dl>";
						subscribe_html += "<a class=\'action\' href=\'"+window.location.href+"?action_name=1\' title=\'转成永久性二维码\'>永久</a>";
						subscribe_html += "<span class=\'title\'>开启职位订阅</span>";
						subscribe_html += "<span class=\'sub-title\'>关注东纺服务号，坐等好工作砸在您头上</span>";
						subscribe_html += "<p>定时为您推送<span>【"+result.data.scene_title+"】</span>相关职位</p>";
						subscribe_html += "<p class=\'font12\'>让您不再苦于寻找不到合适的职位而烦恼，东纺为您免费进行定制推送</p>";
						subscribe.html(subscribe_html);
						subscribe.css('display','block');
					}
				}
			})
		}
	}
	$('#subscription_close').live('click', function() {
		$.cookie("jobs_subscribe_wechat",1, { expires: 1});
		subscribe.hide();
		return false; 
	});	
	//底部广告条浮动
	$('.bottom-publish-close').click(function(){ 
		$.cookie("jobs_bottom_publish",1);
		$('.bottom-publish-wrap').hide();
		return false; 
	});
	
}(window.jQuery);