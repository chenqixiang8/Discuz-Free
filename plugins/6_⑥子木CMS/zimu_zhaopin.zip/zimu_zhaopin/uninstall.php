<?php

if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$sql = <<<EOF
DROP TABLE  IF EXISTS pre_zimu_zhaopin_area;
DROP TABLE  IF EXISTS pre_zimu_zhaopin_category;
DROP TABLE  IF EXISTS pre_zimu_zhaopin_category_district;
DROP TABLE  IF EXISTS pre_zimu_zhaopin_category_jobs;
DROP TABLE  IF EXISTS pre_zimu_zhaopin_category_major;
DROP TABLE  IF EXISTS pre_zimu_zhaopin_company_down_resume;
DROP TABLE  IF EXISTS pre_zimu_zhaopin_company_favorites;
DROP TABLE  IF EXISTS pre_zimu_zhaopin_company_profile;
DROP TABLE  IF EXISTS pre_zimu_zhaopin_jobs;
DROP TABLE  IF EXISTS pre_zimu_zhaopin_members;
DROP TABLE  IF EXISTS pre_zimu_zhaopin_members_setmeal;
DROP TABLE  IF EXISTS pre_zimu_zhaopin_order;
DROP TABLE  IF EXISTS pre_zimu_zhaopin_parameter2;
DROP TABLE  IF EXISTS pre_zimu_zhaopin_personal_favorites;
DROP TABLE  IF EXISTS pre_zimu_zhaopin_personal_focus_company;
DROP TABLE  IF EXISTS pre_zimu_zhaopin_personal_jobs_apply;
DROP TABLE  IF EXISTS pre_zimu_zhaopin_refresh_log;
DROP TABLE  IF EXISTS pre_zimu_zhaopin_resume;
DROP TABLE  IF EXISTS pre_zimu_zhaopin_resume_credent;
DROP TABLE  IF EXISTS pre_zimu_zhaopin_resume_education;
DROP TABLE  IF EXISTS pre_zimu_zhaopin_resume_img;
DROP TABLE  IF EXISTS pre_zimu_zhaopin_resume_language;
DROP TABLE  IF EXISTS pre_zimu_zhaopin_resume_training;
DROP TABLE  IF EXISTS pre_zimu_zhaopin_resume_work;
DROP TABLE  IF EXISTS pre_zimu_zhaopin_setmeal;
DROP TABLE  IF EXISTS pre_zimu_zhaopin_setmeal_increment;
DROP TABLE  IF EXISTS pre_zimu_zhaopin_setting;
DROP TABLE  IF EXISTS pre_zimu_zhaopin_view_resume;
DROP TABLE  IF EXISTS pre_zimu_zhaopin_per_viewlog;
DROP TABLE  IF EXISTS pre_zimu_zhaopin_com_viewlog;
DROP TABLE  IF EXISTS pre_zimu_zhaopin_report;
DROP TABLE  IF EXISTS pre_zimu_zhaopin_share_refresh;
DROP TABLE  IF EXISTS pre_zimu_zhaopin_kefu;
DROP TABLE  IF EXISTS pre_zimu_zhaopin_news;
DROP TABLE  IF EXISTS pre_zimu_zhaopin_news_cat;
DROP TABLE  IF EXISTS pre_zimu_zhaopin_crm_company;
DROP TABLE  IF EXISTS pre_zimu_zhaopin_crm_custom_log;
DROP TABLE  IF EXISTS pre_zimu_zhaopin_crm_custom_feedback;
DROP TABLE  IF EXISTS pre_zimu_zhaopin_crm_person;
DROP TABLE  IF EXISTS pre_zimu_zhaopin_queue_auto_refresh;
DROP TABLE  IF EXISTS pre_zimu_zhaopin_jobfair_online;
DROP TABLE  IF EXISTS pre_zimu_zhaopin_jobfair_online_com;
DROP TABLE  IF EXISTS pre_zimu_zhaopin_company_interview;
DROP TABLE  IF EXISTS pre_zimu_zhaopin_members_handsel;
DROP TABLE  IF EXISTS pre_zimu_zhaopin_mptpl;
DROP TABLE  IF EXISTS pre_zimu_zhaopin_wxscene;

EOF;

runquery($sql);

deldirfile(DISCUZ_ROOT . "./source/plugin/zimu_zhaopin/uploadzimucms");

deldirfile(DISCUZ_ROOT . "./source/plugin/zimu_zhaopin/static/kindeditor/attached/image");


$finish = TRUE;



function deldirfile($directory, $empty = false) {
    if(substr($directory,-1) == "/") {
        $directory = substr($directory,0,-1);
    }

    if(!file_exists($directory) || !is_dir($directory)) {
        return false;
    } elseif(!is_readable($directory)) {
        return false;
    } else {
        @$directoryHandle = opendir($directory);

        while ($contents = @readdir($directoryHandle)) {
            if($contents != '.' && $contents != '..') {
                $path = $directory . "/" . $contents;

                if(is_dir($path)) {
                    @deldirfile($path, $empty);
                } else {
                    @unlink($path);
                }
            }
        }

        @closedir($directoryHandle);

        if($empty == false) {
            if(!@rmdir($directory)) {
                return false;
            }
        }

        return true;
    }
}
function deletecache($cachenames) {  
    if(!empty($cachenames)) {  
  DB::delete('common_syscache', array('cname' => $cachenames));
    }  
}