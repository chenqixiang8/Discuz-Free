<?php

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

header('Access-Control-Allow-Origin:*');

require_once DISCUZ_ROOT . './source/plugin/zimu_zhaopin/config.php';

$model = addslashes($_GET['model']);
$model = !empty($model) ? $model : 'newindex';

/*if (!checkmobile() && $model !='admins' && $model !='members' && $model !='cityid' && $model !='initialization' && $model !='categorycache') {
include(template('zimu_zhaopin:index_guide'));
exit();
}*/

if (IN_WECHAT && $zmdata['base']['weixin_appid'] && $zmdata['base']['weixin_appsecret'] && $zmdata['settings']['mp_qrcode_url'] && getcookie('zimu_zhaopin_subscribe') != 1 && $zmdata['settings']['mp_qrcode_time'] > 0) {
    
    $openid = $_G['cookie']['zimu_zhaopin_openid'] ? $_G['cookie']['zimu_zhaopin_openid'] : '';
    if (!$openid) {
        $tools    = new JsApiPaySF();
        $opendata = $tools->GetFollowOpenid(get_url() . '&oauth=yes');
        if ($openid = $opendata['openid']) {
            dsetcookie('zimu_zhaopin_openid', $openid, 86400);
        }
    }
    if ($openid && $_G['uid']) {
        DB::query("update %t set openid=%s where uid=%d", array(
            'zimu_zhaopin_members',
            $openid,
            $_G['uid']
        ));
    }
    
    require_once DISCUZ_ROOT . './source/plugin/zimu_zhaopin/class/wechat.lib.class.php';
    $wechat_client = new WeChatClient($zmdata['base']['weixin_appid'], $zmdata['base']['weixin_appsecret']);
    $wechatinfo    = $wechat_client->getUserInfoById($openid);
    
    if ($wechatinfo['subscribe'] == 1) {
        dsetcookie('zimu_zhaopin_subscribe', 1, 600);
        DB::query("update %t set bind_weixin=1 where uid=%d", array(
            'zimu_zhaopin_company_profile',
            $_G['uid']
        ));
        DB::query("update %t set bind_weixin=1 where uid=%d", array(
            'zimu_zhaopin_resume',
            $_G['uid']
        ));
    } elseif (getcookie('zimu_zhaopin_subscribe') != 1) {
        $show_mp_qrcode = 1;
        dsetcookie('zimu_zhaopin_subscribe', 1, $zmdata['settings']['mp_qrcode_time']);
        DB::query("update %t set bind_weixin=0 where uid=%d", array(
            'zimu_zhaopin_company_profile',
            $_G['uid']
        ));
        DB::query("update %t set bind_weixin=0 where uid=%d", array(
            'zimu_zhaopin_resume',
            $_G['uid']
        ));
    }
    
}

if ($_G['uid']) {
    $myutype = DB::result_first('select utype from %t where uid=%d order by id desc', array(
        'zimu_zhaopin_members',
        $_G['uid']
    ));
    if ($myutype == 1) {
        $myheaderinfo = DB::fetch_first('select * from %t where uid=%d order by id desc', array(
            'zimu_zhaopin_company_profile',
            $_G['uid']
        ));
    } else {
        $myheaderinfo = DB::fetch_first('select * from %t where uid=%d order by id desc', array(
            'zimu_zhaopin_resume',
            $_G['uid']
        ));
        
        if ($myheaderinfo && $zmdata['settings']['login_replenish_resume'] && $myheaderinfo['refreshtime'] < strtotime(date('Y-m-d', $_G['timestamp']))) {
            
            DB::query("update %t set refreshtime=%d where id=%d and uid=%d", array(
                'zimu_zhaopin_resume',
                $_G['timestamp'],
                $myheaderinfo['id'],
                $_G['uid']
            ));
            
            $refresh_log_setsqlarr['uid']     = $_G['uid'];
            $refresh_log_setsqlarr['mode']    = 0;
            $refresh_log_setsqlarr['addtime'] = $_G['timestamp'];
            $refresh_log_setsqlarr['type']    = 2001;
            
            DB::insert('zimu_zhaopin_refresh_log', $refresh_log_setsqlarr, 1);
            
        }
        
    }

            DB::query("update %t set logintime=%d where uid=%d and logintime<%d", array(
                'zimu_zhaopin_company_profile',
                $_G['timestamp'],
                $_G['uid'],
                $_G['timestamp']-300
            ));

            DB::query("update %t set logintime=%d where uid=%d and logintime<%d", array(
                'zimu_zhaopin_resume',
                $_G['timestamp'],
                $_G['uid'],
                $_G['timestamp']-300
            )); 

}

if ($zmdata['settings']['show_noaudit']) {
    $noauditwheresql  = ' where audit = 1 ';
    $noauditwheresql2 = ' and audit = 1 ';
}

DB::query("update %t set views=views+1", array(
    'zimu_zhaopin_setting'
));


$auto_refresh = DB::fetch_all('select * from %t where type=1 and refreshtime<=%d order by refreshtime asc', array(
    'zimu_zhaopin_queue_auto_refresh',
    $_G['timestamp']
));
foreach ($auto_refresh as $key => $value) {

DB::query("update %t set refreshtime=%d where id=%d", array(
    'zimu_zhaopin_jobs',
    $value['refreshtime'],
    $value['pid'],
    $_G['timestamp']
));

$setsqlarr_refresh_log['uid']     = $value['uid'];
$setsqlarr_refresh_log['mode']    = 2;
$setsqlarr_refresh_log['addtime'] = $value['refreshtime'];
$setsqlarr_refresh_log['type']    = 1001;
DB::insert('zimu_zhaopin_refresh_log', $setsqlarr_refresh_log, 1);

    DB::delete('zimu_zhaopin_queue_auto_refresh', array(
        'id' => $value['id']
    ));

}



include DISCUZ_ROOT . './source/plugin/zimu_zhaopin/module/' . $model . '.inc.php';