<?php
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

if (!in_array('stick_endtime', zm_fieldexists('zimu_zhaopin_resume'))) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimu_zhaopin_resume` ADD COLUMN `stick_endtime` INT(10) UNSIGNED NOT NULL;
EOF;
    runquery($sql1);
}

    $sql1 = <<<EOF
ALTER TABLE `pre_zimu_zhaopin_resume` CHANGE `strong_tag` `strong_tag` CHAR(50) NOT NULL;
EOF;
    runquery($sql1);


if (!in_array('strong_tag_endtime', zm_fieldexists('zimu_zhaopin_resume'))) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimu_zhaopin_resume` ADD COLUMN `strong_tag_endtime` INT(10) UNSIGNED NOT NULL;
EOF;
    runquery($sql1);
}

if (!in_array('category_sort', zm_fieldexists('zimu_zhaopin_jobs'))) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimu_zhaopin_jobs` ADD COLUMN `category_sort` CHAR(100) NOT NULL;
EOF;
    runquery($sql1);
}


if (!in_array('telephone', zm_fieldexists('zimu_zhaopin_members'))) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimu_zhaopin_members` ADD COLUMN `telephone` CHAR(100) NOT NULL;
EOF;
    runquery($sql1);
}

if (!in_array('verify_code', zm_fieldexists('zimu_zhaopin_members'))) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimu_zhaopin_members` ADD COLUMN `verify_code` CHAR(100) NOT NULL;
EOF;
    runquery($sql1);
}

if (!in_array('referer', zm_fieldexists('zimu_zhaopin_order'))) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimu_zhaopin_order` ADD COLUMN `referer` VARCHAR(1000) NOT NULL;
EOF;
    runquery($sql1);
}

if (!in_array('wxtpl', zm_fieldexists('zimu_zhaopin_company_profile'))) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimu_zhaopin_company_profile` ADD `wxtpl` CHAR(200) NOT NULL;
EOF;
    runquery($sql1);
}

if (!in_array('wxtpl', zm_fieldexists('zimu_zhaopin_jobs'))) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimu_zhaopin_jobs` ADD `wxtpl` CHAR(200) NOT NULL;
EOF;
    runquery($sql1);
}

if (!in_array('wxtpl', zm_fieldexists('zimu_zhaopin_resume'))) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimu_zhaopin_resume` ADD `wxtpl` CHAR(200) NOT NULL;
EOF;
    runquery($sql1);
}

if (!in_array('certificate_img_audit', zm_fieldexists('zimu_zhaopin_company_profile'))) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimu_zhaopin_company_profile` ADD `certificate_img_audit` TINYINT(1) UNSIGNED NOT NULL;
EOF;
    runquery($sql1);
}

if (!in_array('company_certificate', zm_fieldexists('zimu_zhaopin_jobs'))) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimu_zhaopin_jobs` ADD `company_certificate` TINYINT(1) UNSIGNED NOT NULL;
EOF;
    runquery($sql1);
}

if (!in_array('ispay', zm_fieldexists('zimu_zhaopin_jobs'))) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimu_zhaopin_jobs` ADD `ispay` TINYINT UNSIGNED NOT NULL;
EOF;
    runquery($sql1);
}

if (!in_array('istop', zm_fieldexists('zimu_zhaopin_category_jobs'))) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimu_zhaopin_category_jobs` ADD `istop` TINYINT(1) UNSIGNED NOT NULL;
EOF;
    runquery($sql1);
}

if (!in_array('is_pcad', zm_fieldexists('zimu_zhaopin_company_profile'))) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimu_zhaopin_company_profile` ADD `is_pcad` TINYINT(1) UNSIGNED NOT NULL;
EOF;
    runquery($sql1);
}

if (!in_array('pcad', zm_fieldexists('zimu_zhaopin_company_profile'))) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimu_zhaopin_company_profile` ADD `pcad` CHAR(250) NOT NULL;
EOF;
    runquery($sql1);
}

if (!in_array('parentid', zm_fieldexists('zimu_zhaopin_area'))) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimu_zhaopin_area` ADD COLUMN `parentid` INT(10) UNSIGNED NOT NULL;
EOF;
    runquery($sql1);
}

if (!in_array('district2', zm_fieldexists('zimu_zhaopin_jobs'))) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimu_zhaopin_jobs` ADD `district2` VARCHAR(100) NOT NULL;
EOF;
    runquery($sql1);
}

if (!in_array('views', zm_fieldexists('zimu_zhaopin_setting'))) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimu_zhaopin_setting` ADD COLUMN `views` INT(10) UNSIGNED NOT NULL;
EOF;
    runquery($sql1);
}

if (!in_array('company_mingqi', zm_fieldexists('zimu_zhaopin_company_profile'))) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimu_zhaopin_company_profile` ADD `company_mingqi` TINYINT(1) UNSIGNED NOT NULL;
EOF;
    runquery($sql1);
}

if (!in_array('company_mingqi', zm_fieldexists('zimu_zhaopin_jobs'))) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimu_zhaopin_jobs` ADD `company_mingqi` TINYINT(1) UNSIGNED NOT NULL;
EOF;
    runquery($sql1);
}

if (!in_array('kefu_uid', zm_fieldexists('zimu_zhaopin_company_profile'))) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimu_zhaopin_company_profile` ADD `kefu_uid` SMALLINT(1) UNSIGNED NOT NULL;
EOF;
    runquery($sql1);
}

if (!in_array('kefu_name', zm_fieldexists('zimu_zhaopin_company_profile'))) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimu_zhaopin_company_profile` ADD `kefu_name` CHAR(20) NOT NULL;
EOF;
    runquery($sql1);
}

if (!in_array('kefu_uid', zm_fieldexists('zimu_zhaopin_resume'))) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimu_zhaopin_resume` ADD `kefu_uid` SMALLINT(1) UNSIGNED NOT NULL;
EOF;
    runquery($sql1);
}

if (!in_array('kefu_name', zm_fieldexists('zimu_zhaopin_resume'))) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimu_zhaopin_resume` ADD `kefu_name` CHAR(20) NOT NULL;
EOF;
    runquery($sql1);
}


if (!in_array('refreshtime', zm_fieldexists('zimu_zhaopin_company_profile'))) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimu_zhaopin_company_profile` ADD COLUMN `refreshtime` INT(10) UNSIGNED NOT NULL;
EOF;
    runquery($sql1);
}

if (!in_array('logintime', zm_fieldexists('zimu_zhaopin_company_profile'))) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimu_zhaopin_company_profile` ADD COLUMN `logintime` INT(10) UNSIGNED NOT NULL;
EOF;
    runquery($sql1);
}

if (!in_array('refreshtime', zm_fieldexists('zimu_zhaopin_resume'))) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimu_zhaopin_resume` ADD COLUMN `refreshtime` INT(10) UNSIGNED NOT NULL;
EOF;
    runquery($sql1);
}

if (!in_array('logintime', zm_fieldexists('zimu_zhaopin_resume'))) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimu_zhaopin_resume` ADD COLUMN `logintime` INT(10) UNSIGNED NOT NULL;
EOF;
    runquery($sql1);
}

if (!in_array('weixin', zm_fieldexists('zimu_zhaopin_company_profile'))) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimu_zhaopin_company_profile` ADD `weixin` CHAR(20) NOT NULL;
EOF;
    runquery($sql1);
}
if (!in_array('weixin', zm_fieldexists('zimu_zhaopin_resume'))) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimu_zhaopin_resume` ADD `weixin` CHAR(20) NOT NULL;
EOF;
    runquery($sql1);
}

if (!in_array('bind_weixin', zm_fieldexists('zimu_zhaopin_company_profile'))) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimu_zhaopin_company_profile` ADD `bind_weixin` TINYINT(1) UNSIGNED NOT NULL;
EOF;
    runquery($sql1);
}
if (!in_array('bind_weixin', zm_fieldexists('zimu_zhaopin_resume'))) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimu_zhaopin_resume` ADD `bind_weixin` TINYINT(1) UNSIGNED NOT NULL;
EOF;
    runquery($sql1);
}


if (!in_array('is_contact', zm_fieldexists('zimu_zhaopin_company_profile'))) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimu_zhaopin_company_profile` ADD `is_contact` TINYINT(1) UNSIGNED NOT NULL;
EOF;
    runquery($sql1);
}
if (!in_array('is_contact', zm_fieldexists('zimu_zhaopin_resume'))) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimu_zhaopin_resume` ADD `is_contact` TINYINT(1) UNSIGNED NOT NULL;
EOF;
    runquery($sql1);
}

if (!in_array('district3', zm_fieldexists('zimu_zhaopin_jobs'))) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimu_zhaopin_jobs` ADD `district3` CHAR(100) NOT NULL;
EOF;
    runquery($sql1);
}

if (!in_array('points', zm_fieldexists('zimu_zhaopin_members'))) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimu_zhaopin_members` ADD `points` INT(10) UNSIGNED NOT NULL;
EOF;
    runquery($sql1);
}
if (!in_array('parttime_type', zm_fieldexists('zimu_zhaopin_jobs'))) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimu_zhaopin_jobs` ADD `parttime_type` TINYINT(1) UNSIGNED NOT NULL;
EOF;
    runquery($sql1);
}

if (!in_array('parttime_money', zm_fieldexists('zimu_zhaopin_jobs'))) {
    $sql1 = <<<EOF
ALTER TABLE `pre_zimu_zhaopin_jobs` ADD `parttime_money` CHAR(30) NOT NULL;
EOF;
    runquery($sql1);
}

    $sql1 = <<<EOF
    
CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_area` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` char(100) NOT NULL,
  `sort` smallint(3) UNSIGNED NOT NULL DEFAULT '100',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_view_resume` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` int(10) UNSIGNED NOT NULL,
  `resumeid` int(10) UNSIGNED NOT NULL,
  `company_id` int(10) UNSIGNED NOT NULL,
  `companyname` char(100) NOT NULL,
  `hasdown` tinyint(1) UNSIGNED NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_per_viewlog` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` int(10) UNSIGNED NOT NULL,
  `jid` int(10) UNSIGNED NOT NULL,
  `jobname` char(100) NOT NULL,
  `cid` int(10) UNSIGNED NOT NULL,
  `comname` char(100) NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_com_viewlog` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` int(10) UNSIGNED NOT NULL,
  `rid` int(10) UNSIGNED NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_report` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` int(10) UNSIGNED NOT NULL,
  `username` varchar(30) NOT NULL,
  `jobs_id` int(10) UNSIGNED NOT NULL,
  `report_type` int(10) NOT NULL,
  `telephone` varchar(15) NOT NULL,
  `audit` int(10) NOT NULL DEFAULT '1',
  `content` varchar(250) NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_share_refresh` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` int(10) UNSIGNED NOT NULL,
  `model` char(50) NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_kefu` (
    `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
    `uid` int(10) UNSIGNED NOT NULL,
    `kefu_name` char(30) NOT NULL,
    `kefu_mobile` char(20) NOT NULL,
    `kefu_tel` char(20) NOT NULL,
    `kefu_wxid` char(20) NOT NULL,
    `kefu_qrcode_url` char(255) NOT NULL,
    PRIMARY KEY (`id`)
  ) ENGINE=MyISAM AUTO_INCREMENT=1;

  CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_news` (
    `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
    `title` char(50) NOT NULL,
    `cid` int(10) UNSIGNED NOT NULL,
    `catname` char(20) NOT NULL,
    `keyword` char(50) NOT NULL,
    `description` char(200) NOT NULL,
    `thumb` char(255) NOT NULL,
    `tag` char(20) NOT NULL,
    `author` char(30) NOT NULL,
    `views` int(10) UNSIGNED NOT NULL,
    `con` text NOT NULL,
    `toutiao` tinyint(1) UNSIGNED NOT NULL,
    `addtime` int(10) UNSIGNED NOT NULL,
    PRIMARY KEY (`id`)
  ) ENGINE=MyISAM AUTO_INCREMENT=1;
  
  CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_news_cat` (
    `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
    `name` char(30) NOT NULL,
    PRIMARY KEY (`id`)
  ) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_crm_company` (
  `rid` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `com_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `com_uid` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `crm_uid` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `level` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `funnel` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `follow_time` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `next_time` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `receive_time` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `give_up_time` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `remark` text,
  PRIMARY KEY (`rid`),
  KEY `com_id` (`com_id`),
  KEY `crm_uid` (`crm_uid`),
  KEY `level` (`level`),
  KEY `funnel` (`funnel`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_crm_custom_log` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `custom_type` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `custom_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `crm_uid` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `op_type` char(20) NOT NULL DEFAULT '',
  `note` varchar(100) NOT NULL DEFAULT '',
  `remark` varchar(255) NOT NULL DEFAULT '',
  `add_time` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `ip` varchar(15) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `custom_type` (`custom_type`),
  KEY `custom_id` (`custom_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_crm_custom_feedback` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `custom_type` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `custom_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `crm_uid` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `type_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `contact_name` char(50) NOT NULL DEFAULT '',
  `add_time` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `comment` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `custom_type` (`custom_type`),
  KEY `custom_id` (`custom_id`),
  KEY `crm_uid` (`crm_uid`),
  KEY `type_id` (`type_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_crm_person` (
  `rid` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `resume_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `resume_uid` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `crm_uid` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `funnel` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `source` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `label` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `level` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `follow_time` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `next_time` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `receive_time` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `give_up_time` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `remark` text,
  PRIMARY KEY (`rid`),
  KEY `resume_id` (`resume_id`),
  KEY `crm_uid` (`crm_uid`),
  KEY `funnel` (`funnel`),
  KEY `source` (`source`),
  KEY `label` (`label`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_queue_auto_refresh` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `pid` int(10) UNSIGNED NOT NULL,
  `type` tinyint(1) UNSIGNED NOT NULL,
  `uid` int(10) UNSIGNED NOT NULL,
  `refreshtime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_jobfair_online` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` char(255) NOT NULL,
  `summary` varchar(5000) NOT NULL,
  `starttime` int(10) UNSIGNED NOT NULL,
  `endtime` int(10) UNSIGNED NOT NULL,
  `thumb` char(255) NOT NULL,
  `poster` char(255) NOT NULL,
  `contact` char(100) NOT NULL,
  `tel` char(100) NOT NULL,
  `price` char(20) NOT NULL,
  `intro` text NOT NULL,
  `views` int(10) UNSIGNED NOT NULL,
  `bgcolor` char(20) NOT NULL,
  `kefu_tip` char(100) NOT NULL,
  `kefu_qrcode` char(255) NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_jobfair_online_com` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `fid` int(10) UNSIGNED NOT NULL,
  `uid` int(10) UNSIGNED NOT NULL,
  `com_id` int(10) UNSIGNED NOT NULL,
  `com_name` char(255) NOT NULL,
  `sort` smallint(5) UNSIGNED NOT NULL DEFAULT '100',
  `zhiding` tinyint(1) UNSIGNED NOT NULL,
  `note` varchar(5000) NOT NULL,
  `status` tinyint(1) UNSIGNED NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_company_interview` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `resume_id` int(10) UNSIGNED NOT NULL,
  `resume_name` varchar(30) NOT NULL,
  `resume_uid` int(10) UNSIGNED NOT NULL,
  `jobs_id` int(10) UNSIGNED NOT NULL,
  `jobs_name` varchar(60) NOT NULL,
  `company_id` int(10) UNSIGNED NOT NULL,
  `company_name` varchar(60) NOT NULL,
  `company_uid` int(10) UNSIGNED NOT NULL,
  `interview_addtime` int(10) UNSIGNED NOT NULL,
  `notes` varchar(255) NOT NULL DEFAULT '',
  `personal_look` tinyint(3) UNSIGNED NOT NULL DEFAULT '1',
  `interview_time` varchar(20) NOT NULL DEFAULT '',
  `address` varchar(255) NOT NULL,
  `contact` varchar(60) NOT NULL,
  `telephone` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `resume_uid_resumeid` (`resume_uid`,`resume_id`),
  KEY `company_uid_jobid` (`company_uid`,`jobs_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_members_handsel` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) UNSIGNED NOT NULL,
  `htype` varchar(60) NOT NULL,
  `htype_cn` varchar(30) NOT NULL,
  `operate` tinyint(1) UNSIGNED NOT NULL DEFAULT '1',
  `points` int(10) UNSIGNED NOT NULL,
  `addtime` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`,`htype`,`addtime`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_mptpl` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `type` char(20) NOT NULL,
  `tpl` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_zimu_zhaopin_wxscene` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `keyword` char(200) NOT NULL,
  `tip` char(200) NOT NULL,
  `con` text NOT NULL,
  `type` char(30) NOT NULL,
  `etime` int(10) NOT NULL,
  `times` int(10) UNSIGNED NOT NULL,
  `subscribe` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

EOF;
    runquery($sql1);

deldirfile(DISCUZ_ROOT . "./source/plugin/zimu_zhaopin/template/common/",true);
deldirfile(DISCUZ_ROOT . "./source/plugin/zimu_zhaopin/template/touch/",true);
deldirfile(DISCUZ_ROOT . "./source/plugin/zimu_zhaopin/template/admins/",true);
deldirfile(DISCUZ_ROOT . "./source/plugin/zimu_zhaopin/template/",true);

$finish = TRUE;

function zm_fieldexists($table){
$field_list = DB::fetch_all("SHOW COLUMNS FROM %t", array($table));
$field_list_array = mysqltoarray($field_list);
return $field_list_array;
}
function mysqltoarray($test) {
    $temp = array();
    foreach ($test as $k => $s) {
        $temp[] = $s['Field'];
    }
    return $temp;
}
function deldirfile($directory, $empty = false) {
    if(substr($directory,-1) == "/") {
        $directory = substr($directory,0,-1);
    }

    if(!file_exists($directory) || !is_dir($directory)) {
        return false;
    } elseif(!is_readable($directory)) {
        return false;
    } else {
        @$directoryHandle = opendir($directory);

        while ($contents = @readdir($directoryHandle)) {
            if($contents != '.' && $contents != '..') {
                $path = $directory . "/" . $contents;

                if($contents != 'meta.htm' && $contents != 'footer_base.htm' && $contents != 'footer.htm' && $contents != 'header_base.htm' && $contents != 'success.htm'){

                    if(is_dir($path)) {
                      chmod($save_dir.$filename,0755);
                        @deldirfile($path, $empty);
                    } else {
                      chmod($save_dir.$filename,0755);
                        @unlink($path);
                    }
                }


            }
        }

        @closedir($directoryHandle);

        if($empty == false) {
            if(!@rmdir($directory)) {
                return false;
            }
        }

        return true;
    }
}