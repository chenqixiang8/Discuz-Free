<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT . './api/trade/api_alipay.php';
$pburl= $_G['siteurl'];
$notify_url = $pburl. 'source/plugin/zimu_zhaopin/lib/notify_ali.php';
if (checkmobile()) {
    $alipay_config['partner'] = DISCUZ_PARTNER;
    $alipay_config['key'] = DISCUZ_SECURITYCODE;
    $alipay_config['sign_type'] = strtoupper('MD5');;
    $alipay_config['input_charset'] = strtolower('utf-8');
    $alipay_config['cacert'] = DISCUZ_ROOT . 'source/plugin/zimu_zhaopin/lib/alipay_m/cacert.pem';
    $alipay_config['transport'] = 'http';
    $seller_email = $_G['setting']['ec_account'];
    $format = "xml";
    $v = "2.0";
    $req_id = date('Ymdhis');
    $call_back_url = $notify_url;
    unset($_GET['formhash']);
    $merchant_url = $notify_url;

    $subject2 = zimu_array_utf8($subject);

    $req_data = '<direct_trade_create_req><notify_url>' . $notify_url . '</notify_url><call_back_url>' . $call_back_url . '</call_back_url><seller_account_name>' . $seller_email . '</seller_account_name><out_trade_no>' . $order['oid'] . '</out_trade_no><subject>' . $subject2 . '</subject><total_fee>' . ($pay_amount) . '</total_fee><merchant_url>' . $merchant_url . '</merchant_url></direct_trade_create_req>';
    $para_token = array(
        "service" => "alipay.wap.trade.create.direct",
        "partner" => trim($alipay_config['partner']),
        "sec_id" => trim($alipay_config['sign_type']),
        "format" => $format,
        "v" => $v,
        "req_id" => $req_id,
        "req_data" => $req_data,
        "_input_charset" => trim(strtolower($alipay_config['input_charset']))
    );
    include_once DISCUZ_ROOT . 'source/plugin/zimu_zhaopin/lib/alipay_m/AlipaySubmit.php';
    $alipaySubmit = new AlipaySubmit($alipay_config);
    $html_text = $alipaySubmit->buildRequestHttp($para_token);
    $html_text = urldecode($html_text);
    $para_html_text = $alipaySubmit->parseResponse($html_text);
    $request_token = $para_html_text['request_token'];
    $req_data = '<auth_and_execute_req><request_token>' . $request_token . '</request_token></auth_and_execute_req>';
    $parameter = array(
        "service" => "alipay.wap.auth.authAndExecute",
        "partner" => trim($alipay_config['partner']),
        "sec_id" => trim($alipay_config['sign_type']),
        "format" => $format,
        "v" => $v,
        "req_id" => $req_id,
        "req_data" => $req_data,
        "_input_charset" => trim(strtolower($alipay_config['input_charset']))
    );
    $alipaySubmit = new AlipaySubmit($alipay_config);
    $html_text = $alipaySubmit->buildRequestForm($parameter, 'get', '');
    echo $html_text;exit;
} else {
    $args = array(
        'subject' => $body,
        'body' => $body,
        'service' => 'trade_create_by_buyer',
        'partner' => DISCUZ_PARTNER,
        'notify_url' => $notify_url,
        'return_url' => $notify_url,
        'show_url' => $_G['siteurl'],
        '_input_charset' => 'UTF-8',
        'out_trade_no' => $order['oid'],
        'price' => $pay_amount,
        'quantity' => 1,
        'seller_email' => $_G['setting']['ec_account'],
        'extend_param' => 'isv^dz11'
    );
    if (DISCUZ_DIRECTPAY) {
        $args['service'] = 'create_direct_pay_by_user';
        $args['payment_type'] = '1';
    } else {
        $args['logistics_type'] = 'EXPRESS';
        $args['logistics_fee'] = 0;
        $args['logistics_payment'] = 'SELLER_PAY';
        $args['payment_type'] = 1;
    }
    $link = trade_returnurl($args);
    dheader('location: ' . $link);exit;
}