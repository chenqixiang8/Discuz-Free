<?php

define('IN_API', true);
define('CURSCRIPT', 'api');
define('DISABLEXSSCHECK', true);

require_once '../../../../source/class/class_core.php';
$discuz = C::app();
$discuz->init();

$_G['siteurl'] = str_replace('source/plugin/zimu_zhaopin/lib/', '', $_G['siteurl']);

include_once DISCUZ_ROOT .'source/plugin/zimu_zhaopin/config.php';

global $_G;
if (!$_G['cache']['plugin']) {
    loadcache('plugin');
}

$qf_paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
    'zimu_zhaopin_parameter2',
    'qfapp'
));
$qf_paramter = unserialize($qf_paramter['parameter']);


$nonce = notify_qf_nonce();
$secret = $qf_paramter['qf_secret'];

$qforder_id = $_REQUEST['order_id'];
$data = array(
    'order_id' => $qforder_id,
    'nonce' => $nonce,
);

$data['sign'] = notify_qf_sign($data, $secret);
$r = http_build_query($data);

$url = str_replace('{hostname}', $qf_paramter['qf_hostname'], 'http://{hostname}.qianfanapi.com/api1_2/orders/query?') . $r;
$retfrom = dfsockopen($url);
if (!$retfrom) {
    $retfrom = file_get_contents($url);
}

if ($retqf = json_decode($retfrom, true)) {
    if ($retqf['data'][$qforder_id]['result'] == 1 || $retqf['data'][$qforder_id]['result'] == 2) {

    $order = DB::fetch_first('select * from %t where order_sn=%s and payment=%s order by id desc', array(
        'zimu_zhaopin_order',
        $qfoid,
        'qfapp'
    ));
    $order['params'] = $order['params']?unserialize($order['params']):array();

        if($order['is_paid'] == 1 && $order['order_sn']){
            finish_order($order, $order['order_sn'], $order['amount'], 'WECAHT');
        }
    }
}


function notify_qf_nonce($length = 32)
{
    $chars = "abcdefghijklmnopqrstuvwxyz0123456789";
    $str = "";
    for ($i = 0; $i < $length; $i++) {
        $str .= substr($chars, mt_rand(0, strlen($chars) - 1), 1);
    }
    return $str;
}

function notify_qf_sign($params, $secret)
{
    ksort($params);
    $sparams = array();
    foreach ($params as $k => $v) {
        if ("@" != substr($v, 0, 1)) {
            $sparams[] = "$k=$v";
        }
    }
    $sparams[] = "secret=" . $secret;
    return strtoupper(md5(implode("&", $sparams)));
}