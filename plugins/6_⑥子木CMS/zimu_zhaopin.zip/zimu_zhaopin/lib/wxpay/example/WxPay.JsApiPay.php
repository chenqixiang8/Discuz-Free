<?php

class JsApiPaySF
{
	public $data = null;
	

	public function GetOpenid()
	{
		if (!isset($_GET['code'])){
			$baseUrl = get_url();
			$url = $this->__CreateOauthUrlForCode($baseUrl);
            global $_G;
            if($_G['cache']['plugin']['zimu_zhaopin']['oauth2_url']) {
                $jieurl = $_G['cache']['plugin']['zimu_zhaopin']['oauth2_url'];
                $baseUrl = urlencode($baseUrl);
                $url = "$jieurl?appid=".WxPayConfigSF::APPID."&redirect_uri={$baseUrl}&response_type=code&scope=snsapi_base&state=#wechat_redirect";
            }
			header("Location: $url");
			exit();
		} else {
		    $code = $_GET['code'];
			$openid = $this->getOpenidFromMp($code);
			return $openid;
		}
	}
	public function GetFollowOpenid($baseUrl)
	{
	    global  $_G;
        if (!isset($_GET['code'])){
            $redirect_uri = $this->getOAuthConnectUri($baseUrl);
            if($_G['cache']['plugin']['zimu_zhaopin']['oauth2_url']) {
                $jieurl = $_G['cache']['plugin']['zimu_zhaopin']['oauth2_url'];
                $baseUrl = urlencode($baseUrl);
                $redirect_uri = "$jieurl?appid=".WxPayConfigSF::APPID."&redirect_uri={$baseUrl}&response_type=code&scope=snsapi_base&state=#wechat_redirect";
            }
            dheader('location: '.$redirect_uri);
        } else {
            $tockeninfo = $this->getAccessTokenByCode($_GET['code']);
            //print_r($tockeninfo);exit();
            if(!$tockeninfo['openid']){
                //showmessage(var_export($tockeninfo, true));
                //exit;
            }
            return $tockeninfo;
        }
	}

    public function getAccessTokenByCode($code) {
        $_appid = WxPayConfigSF::APPID;
        $_secret = WxPayConfigSF::APPSECRET;
        $url = "https://api.weixin.qq.com/sns/oauth2/access_token?appid={$_appid}&secret={$_secret}&code=$code&grant_type=authorization_code";
        $res = json_decode(self::get($url), true);
        return $res;
    }
    function getOAuthConnectUri($redirect_uri, $state = '', $scope = 'snsapi_base') {
        $_appid = WxPayConfigSF::APPID;
        $_secret = WxPayConfigSF::APPSECRET;
        $redirect_uri = urlencode($redirect_uri);
        $url = "https://open.weixin.qq.com/connect/oauth2/authorize?appid={$_appid}&redirect_uri={$redirect_uri}&response_type=code&scope={$scope}&state={$state}#wechat_redirect";
        return $url;
    }
    public function getUserInfoByOpenid($uid, $lang = '') {
        if (!$lang) {
            $lang = 'en';
        }
        $access_token = $this->getAccessToken();
        $url = "https://api.weixin.qq.com/cgi-bin/user/info?access_token=$access_token&openid=$uid&lang=$lang";
        $res = json_decode(self::get($url), true);
        return $res;
    }


	public function getUserInfoById($access_token, $openid, $lang = '')
	{
		if (!$lang) {
			$lang = 'zh_CN';
		}

		$url = "https://api.weixin.qq.com/sns/userinfo?access_token=$access_token&openid=$openid&lang=$lang";
		$res = json_decode(self::get($url), true);
		return $res;
	}

	public function getAccessToken() {
		global $_G;
		$token = null;
		$appid = SF_APPID;
		$appsecret = SF_APPSECRET;
		$cachename = 'wechatat_' . $appid;
		loadcache($cachename);

		$token = $_G['cache'][$cachename];

		// check cache
		if ($token) {

			$ischeck = self::get('https://api.weixin.qq.com/cgi-bin/getcallbackip?access_token='.$token['token']);
			$ischeck = json_decode($ischeck,true);
			if($ischeck['errcode'] != 40001 && time() < $token['expiration'] ){
				return $token;
			}
			
		}

		// get new token
		$url = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=$appid&secret=$appsecret";

		$json = self::get($url);
		$res = json_decode($json, true);

		if ($res['errcode']==0) {
			// update cache
			$token = array(
				'token' => $res['access_token'],
				'expiration' => time() + (int) $res['expires_in']-1000,
			);
			savecache($cachename, $token);
		}else{
			savecache($cachename, '');
			return $res;
		}
		return $token;
	}

	/**
	 * @method get
	 * @static
	 * @param  {string}
	 * @return {string|boolen}
	 */
	public static function get($url) {
        $ret = file_get_contents($url);
        if($ret){
            return $ret;
        }
		if(!function_exists('curl_init')){
			return file_get_contents($url);
		}
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		# curl_setopt($ch, CURLOPT_HEADER, 1);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);

		if (!curl_exec($ch)) {
			error_log(curl_error($ch));
			$data = '';
		} else {
			$data = curl_multi_getcontent($ch);
		}
		curl_close($ch);
		return $data;
	}

	public function GetJsApiParameters($UnifiedOrderResult)
	{
		if(!array_key_exists("appid", $UnifiedOrderResult)
		|| !array_key_exists("prepay_id", $UnifiedOrderResult)
		|| $UnifiedOrderResult['prepay_id'] == "")
		{
		    exit(json_encode(array('error' => var_export($UnifiedOrderResult, 1))));
//			throw new WxPayExceptionSF("param error!". var_export(diconv($UnifiedOrderResult['return_msg'], 'utf-8'), true));
		}
		$jsapi = new WxPayJsApiPaySF();
		$jsapi->SetAppid($UnifiedOrderResult["appid"]);
		$timeStamp = time();
		$jsapi->SetTimeStamp("$timeStamp");
		$jsapi->SetNonceStr(WxPayApiSF::getNonceStr());
		$jsapi->SetPackage("prepay_id=" . $UnifiedOrderResult['prepay_id']);
		$jsapi->SetSignType("MD5");
		$jsapi->SetPaySign($jsapi->MakeSign());
		$parameters = json_encode($jsapi->GetValues());
		return $parameters;
	}

	public function GetOpenidFromMp($code)
	{
		$url = $this->__CreateOauthUrlForOpenid($code);

		$ch = curl_init();

		curl_setopt($ch, CURLOPT_TIMEOUT, $this->curl_timeout);
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,FALSE);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,FALSE);
		curl_setopt($ch, CURLOPT_HEADER, FALSE);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
		if(WxPayConfigSF::CURL_PROXY_HOST != "0.0.0.0"
			&& WxPayConfigSF::CURL_PROXY_PORT != 0){
			curl_setopt($ch,CURLOPT_PROXY, WxPayConfigSF::CURL_PROXY_HOST);
			curl_setopt($ch,CURLOPT_PROXYPORT, WxPayConfigSF::CURL_PROXY_PORT);
		}

		$res = curl_exec($ch);
		curl_close($ch);

		$data = json_decode($res,true);
		$this->data = $data;
		return $data;
		$openid = $data['openid'];
		return $openid;
	}

	private function ToUrlParams($urlObj)
	{
		$buff = "";
		foreach ($urlObj as $k => $v)
		{
			if($k != "sign"){
				$buff .= $k . "=" . $v . "&";
			}
		}
		
		$buff = trim($buff, "&");
		return $buff;
	}

	public function GetEditAddressParameters()
	{	
		$getData = $this->data;
		$data = array();
		$data["appid"] = WxPayConfigSF::APPID;
		$data["url"] = "http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
		$time = time();
		$data["timestamp"] = "$time";
		$data["noncestr"] = "1234568";
		$data["accesstoken"] = $getData["access_token"];
		ksort($data);
		$params = $this->ToUrlParams($data);
		$addrSign = sha1($params);
		
		$afterData = array(
			"addrSign" => $addrSign,
			"signType" => "sha1",
			"scope" => "jsapi_address",
			"appId" => WxPayConfigSF::APPID,
			"timeStamp" => $data["timestamp"],
			"nonceStr" => $data["noncestr"]
		);
		$parameters = json_encode($afterData);
		return $parameters;
	}

	private function __CreateOauthUrlForCode($redirectUrl)
	{
		$urlObj["appid"] = WxPayConfigSF::APPID;
		$urlObj["redirect_uri"] = "$redirectUrl";
		$urlObj["response_type"] = "code";
		$urlObj["scope"] = "snsapi_base";
		$urlObj["state"] = "STATE"."#wechat_redirect";
		$bizString = $this->ToUrlParams($urlObj);
		return "https://open.weixin.qq.com/connect/oauth2/authorize?".$bizString;
	}

	private function __CreateOauthUrlForOpenid($code)
	{
		$urlObj["appid"] = WxPayConfigSF::APPID;
		$urlObj["secret"] = WxPayConfigSF::APPSECRET;
		$urlObj["code"] = $code;
		$urlObj["grant_type"] = "authorization_code";
		$bizString = $this->ToUrlParams($urlObj);
		return "https://api.weixin.qq.com/sns/oauth2/access_token?".$bizString;
	}
}