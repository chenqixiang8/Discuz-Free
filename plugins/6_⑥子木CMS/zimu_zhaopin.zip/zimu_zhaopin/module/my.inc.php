<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

isuid();

require_once DISCUZ_ROOT . './source/plugin/zimu_zhaopin/module/creatmember.inc.php';

if(IN_MAGAPP && $_GET['unionordernum']){

$unionordernum = addslashes($_GET['unionordernum']);
    $order = DB::fetch_first('select * from %t where order_sn=%s and payment=%s order by id desc', array(
        'zimu_zhaopin_order',
        $unionordernum,
        'magapp'
    ));
    $order['params'] = $order['params']?unserialize($order['params']):array();

if($order['is_paid'] == 1 && $order['order_sn']){

$mag_paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
    'zimu_zhaopin_parameter2',
    'magapp'
));
$mag_paramter = unserialize($mag_paramter['parameter']);

			$mag_url = $mag_paramter['magapp_hostname'].'/core/pay/pay/orderStatusQuery?unionOrderNum='.$order['order_sn'].'&secret='.$mag_paramter['magapp_secret'];

            $mag_ret = json_decode(lizimu_post($mag_url,''),true);
			if ($mag_ret['paycode']==1) {

    if($order && $order['is_paid'] == 1) {
        finish_order($order, $order['order_sn'], $order['amount'], 'WECAHT');
    }

			}



}

}


if(IN_QFAPP && $_GET['qfoid']){

$qfoid = addslashes($_GET['qfoid']);

    $order = DB::fetch_first('select * from %t where order_sn=%s and payment=%s order by id desc', array(
        'zimu_zhaopin_order',
        $qfoid,
        'qfapp'
    ));
    $order['params'] = $order['params']?unserialize($order['params']):array();

if($order['is_paid'] == 1 && $order['order_sn']){

$qf_paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
    'zimu_zhaopin_parameter2',
    'qfapp'
));
$qf_paramter = unserialize($qf_paramter['parameter']);

$qf_nonce = qf_nonce();
$qf_secret = $qf_paramter['qf_secret'];

$data = array(
    'order_id' => $qfoid,
    'nonce' => $qf_nonce,
);

$data['sign'] = qf_sign($data, $qf_secret);
$r = http_build_query($data);

$url = str_replace('{hostname}', $qf_paramter['qf_hostname'], 'http://{hostname}.qianfanapi.com/api1_2/orders/query?') . $r;
$retfrom = dfsockopen($url);
if (!$retfrom) {
    $retfrom = file_get_contents($url);
}

if ($retqf = json_decode($retfrom, true)) {
    if ($retqf['data'][$qfoid]['result'] == 1 || $retqf['data'][$qfoid]['result'] == 2) {

    if($order && $order['is_paid'] == 1) {
        finish_order($order, $order['order_sn'], $order['amount'], 'WECAHT');
    }
    
    }
}


}

}


if($utype == 1){

dheader('Location:' . ZIMUCMS_URL.'&model=mycompany');

}else{

dheader('Location:' . ZIMUCMS_URL.'&model=mypersonal');

}