<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$refererurl = $_SERVER['HTTP_REFERER'];

isuid($refererurl);