<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

isuid();

$ac       = addslashes($_GET['ac']);
$ac       = !empty($ac) ? $ac : 'index';
$tosubmit = intval($_GET['tosubmit']);

if (IN_WECHAT) {
    $openid = $_G['cookie']['zimu_zhaopin_openid'] ? $_G['cookie']['zimu_zhaopin_openid'] : '';
    if (!$openid) {
        $tools    = new JsApiPaySF();
        $opendata = $tools->GetFollowOpenid(get_url() . '&oauth=yes');
        if ($openid = $opendata['openid']) {
            dsetcookie('zimu_zhaopin_openid', $openid, 86400);
        }
    }
    if ($openid) {
        DB::query("update %t set openid=%s where uid=%d", array(
            'zimu_zhaopin_members',
            $openid,
            $_G['uid']
        ));
    }
}


$category_jobs = DB::fetch_all('select * from %t order by c_order asc,c_id asc', array(
    'zimu_zhaopin_category'
));

foreach ($category_jobs as $key => $value) {
    
    $category_jobs2[$value['c_alias']][$value['c_id']] = $value['c_name'];
    
}

$tag_arr = $category_jobs2['ZM_jobtag'];

$company_profile = DB::fetch_first('select * from %t where uid=%d order by id desc', array(
    'zimu_zhaopin_company_profile',
    $_G['uid']
));

require_once DISCUZ_ROOT . './source/plugin/zimu_zhaopin/module/creatmembers_setmeal.inc.php';


if ($ac == 'com_info') {
    
    require_once DISCUZ_ROOT . './source/plugin/zimu_zhaopin/module/creatmember.inc.php';
    
    $myuser = DB::fetch_first('select * from %t where uid=%d order by id asc', array(
        'zimu_zhaopin_members',
        $_G['uid']
    ));
    
    $sms_paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
        'zimu_zhaopin_parameter2',
        'aliyunsms'
    ));
    $sms_paramter = unserialize($sms_paramter['parameter']);
    
    $mag_paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
        'zimu_zhaopin_parameter2',
        'magapp'
    ));
    $mag_paramter = unserialize($mag_paramter['parameter']);
    
    $com_input_paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
        'zimu_zhaopin_parameter2',
        'com_input'
    ));
    
    $com_input_paramters = unserialize($com_input_paramter['parameter']);
    
    
    if ($tosubmit == 1 && $_GET['md5hash'] == formhash()) {
        
        if (!$myuser['telephone'] && $sms_paramter['smsAppKey']) {
            $telephone    = trim($_GET['telephone']);
            $mobile_vcode = trim($_GET['mobile_vcode']);
            if ($myuser['verify_code'] != $mobile_vcode) {
                ajaxReturn(0, $language_zimu['company_inc_php_0']);
            } else {
                DB::query("update %t set telephone=%s where uid=%d", array(
                    'zimu_zhaopin_members',
                    $telephone,
                    $_G['uid']
                ));
            }
        }
        
        
        $setsqlarr['id']          = $company_profile['id'];
        $setsqlarr['uid']         = $_G['uid'];
        $setsqlarr['companyname'] = zm_diconv(I('companyname', 0, 'trim'));
        
        $info = DB::fetch_first('select * from %t where uid !=%d and companyname = %s order by id desc', array(
            'zimu_zhaopin_company_profile',
            $setsqlarr['uid'],
            $setsqlarr['companyname']
        ));
        
        if ($info)
            ajaxReturn(0, $setsqlarr['companyname'] . $language_zimu['company_inc_php_1']);
        
        $data = array(
            'nature',
            'trade',
            'scale'
        );
        foreach ($data as $val) {
            $setsqlarr[$val] = I($val, 0, 'intval');
        }
        
        $district_array            = explode(".", $_GET['district']);
        $setsqlarr['district']  = strip_tags($_GET['district']);
        $district_cn1 = DB::result_first('select name from %t where id=%d order by id desc', array(
            'zimu_zhaopin_area',
            $district_array[0]
        ));
        $district_cn2 = DB::result_first('select name from %t where id=%d order by id desc', array(
            'zimu_zhaopin_area',
            $district_array[1]
        ));
        $district_cn3 = DB::result_first('select name from %t where id=%d order by id desc', array(
            'zimu_zhaopin_area',
            $district_array[2]
        ));
        
        if($zmdata['settings']['area_three']==1){
        $setsqlarr['district_cn'] = $district_cn2.$district_cn3;
        }else{
        $setsqlarr['district_cn'] = $district_cn1.$district_cn2;
        }


        $setsqlarr['nature_cn'] = $category_jobs2['ZM_company_type'][$setsqlarr['nature']];
        $setsqlarr['trade_cn']  = $category_jobs2['ZM_trade'][$setsqlarr['trade']];
        $setsqlarr['scale_cn']  = $category_jobs2['ZM_scale'][$setsqlarr['scale']];
        
        $setsqlarr['address']   = zm_diconv(I('address', '', 'trim'));
        $setsqlarr['contact']   = zm_diconv(I('contact', '', 'trim'));
        $setsqlarr['telephone'] = I('telephone', '', 'trim');
        $setsqlarr['contents']  = zm_diconv(zm_fomat($_GET['contents']));
        $setsqlarr['map_x']     = I('map_x', 0, 'trim');
        !$setsqlarr['map_x'] && $setsqlarr['map_x'] = 0;
        $setsqlarr['map_y'] = I('map_y', 0, 'trim');
        !$setsqlarr['map_y'] && $setsqlarr['map_y'] = 0;
        
        
        if ($_GET['logovalue']) {
            $setsqlarr['logo'] = $posttag = I('logovalue', '', 'trim');
        }
        $setsqlarr['tag'] = $posttag = I('tag', '', 'trim');
        
        if ($_GET['certificate_img']) {
            $setsqlarr['certificate_img'] = $posttag = I('certificate_img', '', 'trim');
        }
        
        if ($posttag) {
            $tagArr = explode(",", $posttag);
            $r_arr  = array();
            foreach ($tagArr as $key => $value) {
                $r_arr[] = $category_jobs2['ZM_jobtag'][$value];
            }
            if (!empty($r_arr)) {
                $setsqlarr['tag_cn'] = implode(",", $r_arr);
            } else {
                $setsqlarr['tag_cn'] = '';
            }
        }
        
        $setsqlarr['audit'] = 2;
        
        $setsqlarr['telephone'] = $setsqlarr['telephone'] ? $setsqlarr['telephone'] : $myuser['telephone'];
        
        
        if ($setsqlarr['id']) {
            
            if ($company_profile['audit'] == 3) {
                $setsqlarr['audit'] = 2;
            }
            
            $result = DB::update('zimu_zhaopin_company_profile', $setsqlarr, array(
                'id' => $setsqlarr['id'],
                'uid' => $_G['uid']
            ));
            
        } elseif (!$company_profile) {
            
            $setsqlarr['addtime'] = time();

            $result = DB::insert('zimu_zhaopin_company_profile', $setsqlarr, 1);
            
            $paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
                'zimu_zhaopin_parameter2',
                'wxtpl'
            ));
            
            $paramters = unserialize($paramter['parameter']);
            
            notification_user('admin', $paramters['wxtpl_admin'], array(
                'first' => $language_zimu['company_inc_php_2'],
                'keyword1' => $language_zimu['company_inc_php_3'],
                'keyword2' => date('Y-m-d H;i', $_G['timestamp']),
                'remark' => $language_zimu['company_inc_php_4'],
                'url' => ZIMUCMS_URL . '&model=viewcom&cid=' . $result
            ));
            
            $magcon = '{"tag":"' . $language_zimu['company_inc_php_5'] . '","title":"' . $language_zimu['company_inc_php_6'] . '","title_themecolor":"#ff0000","link":"' . ZIMUCMS_URL . '&model=viewcom&cid=' . $result . '","extra_info":[{"key":"' . $language_zimu['company_inc_php_7'] . '","val":"' . $setsqlarr['companyname'] . '"}],"des":"' . $language_zimu['company_inc_php_8'] . '","des_themecolor":"#008000"}';
            
            notification_user_magapp('admin', $magcon);
            
        }
        
        ajaxReturn(1, $language_zimu['company_inc_php_9'], array(
            'url' => ZIMUCMS_URL . '&model=mycompany'
        ));
        exit();
        
        
    }
    
    
        $arealist = DB::fetch_all('select * from %t where parentid=0 order by sort asc,id asc', array(
            'zimu_zhaopin_area'
        ), 'id');
        
        foreach ($arealist as $key => $value) {
            
            $arealist[$value['id']]['list'] = DB::fetch_all('select * from %t where parentid=%d order by sort asc,id asc', array(
                'zimu_zhaopin_area',
                $value['id']
            ),'id');
            
            foreach ($arealist[$value['id']]['list'] as $key2 => $value2) {
                
                $arealist[$value['id']]['list'][$value2['id']]['list'] = DB::fetch_all('select * from %t where parentid=%d order by sort asc,id asc', array(
                    'zimu_zhaopin_area',
                    $value2['id']
                ),'id');

            }
            
            
        }
    
    
} elseif ($ac == 'jobs_add') {
    
    if (!$company_profile && !checkmobile()) {
        
        dheader('Location: ' . ZIMUCMS_URL . '&model=company&ac=com_info');
        
    }
    if (!$company_profile && !$zmdata['settings']['com_quickadd']) {
        
        dheader('Location: ' . ZIMUCMS_URL . '&model=company&ac=com_info');
        
    }
    
    if ($company_profile['audit'] == 3) {
        
        dheader('Location: ' . ZIMUCMS_URL . '&model=company&ac=com_info');
        
    }
    
    require_once DISCUZ_ROOT . './source/plugin/zimu_zhaopin/module/creatmember.inc.php';
    
    $myuser = DB::fetch_first('select * from %t where uid=%d order by id asc', array(
        'zimu_zhaopin_members',
        $_G['uid']
    ));
    
    $sms_paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
        'zimu_zhaopin_parameter2',
        'aliyunsms'
    ));
    $sms_paramter = unserialize($sms_paramter['parameter']);
    
    $setmeal = DB::fetch_first('select * from %t where uid=%d order by id desc', array(
        'zimu_zhaopin_members_setmeal',
        $_G['uid']
    ));
    
    $jobs_num = DB::result_first("SELECT count(*) FROM %t where uid=%d", array(
        "zimu_zhaopin_jobs",
        $_G['uid']
    ));
    
    $total = $setmeal['jobs_meanwhile'] - $jobs_num;
    
    $jid = intval($_GET['jid']);
    
    $job_input_paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
        'zimu_zhaopin_parameter2',
        'job_input'
    ));
    
    $job_input_paramters = unserialize($job_input_paramter['parameter']);
    
    
    if ($tosubmit == 1 && $_GET['md5hash'] == formhash()) {
        
        if ($total <= 0 && $company_profile && !$zmdata['settings']['add_jobs_price']) {
            ajaxReturn(0, $language_zimu['company_inc_php_10']);
        }
        
        
        if (!$myuser['telephone'] && $sms_paramter['smsAppKey']) {
            $telephone    = trim($_GET['telephone']);
            $mobile_vcode = trim($_GET['mobile_vcode']);
            if ($myuser['verify_code'] != $mobile_vcode) {
                ajaxReturn(0, $language_zimu['company_inc_php_11']);
            } else {
                DB::query("update %t set telephone=%s where uid=%d", array(
                    'zimu_zhaopin_members',
                    $telephone,
                    $_G['uid']
                ));
            }
        }
        
        if (!$company_profile) {
            
            $setsqlarr2['uid']         = $_G['uid'];
            $setsqlarr2['audit']       = 2;
            $setsqlarr2['companyname'] = zm_diconv(I('companyname', '', 'trim'));
            $setsqlarr2['address']     = zm_diconv(I('address', '', 'trim'));
            $setsqlarr2['contact']     = zm_diconv(I('contact', '', 'trim'));
            $setsqlarr2['telephone']   = zm_diconv(I('telephone', '', 'trim'));
            $setsqlarr2['addtime'] = time();
            $result2                   = DB::insert('zimu_zhaopin_company_profile', $setsqlarr2, 1);
            
            $paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
                'zimu_zhaopin_parameter2',
                'wxtpl'
            ));
            
            $paramters = unserialize($paramter['parameter']);
            
            notification_user('admin', $paramters['wxtpl_admin'], array(
                'first' => $language_zimu['company_inc_php_12'],
                'keyword1' => $language_zimu['company_inc_php_13'],
                'keyword2' => date('Y-m-d H:i', $_G['timestamp']),
                'remark' => $language_zimu['company_inc_php_14'],
                'url' => ZIMUCMS_URL . '&model=viewcom&cid=' . $result2
            ));
            
            $magcon = '{"tag":"' . $language_zimu['company_inc_php_15'] . '","title":"' . $language_zimu['company_inc_php_16'] . '","title_themecolor":"#ff0000","link":"' . ZIMUCMS_URL . '&model=viewcom&cid=' . $result2 . '","extra_info":[{"key":"' . $language_zimu['company_inc_php_17'] . '","val":"' . $setsqlarr['companyname'] . '"}],"des":"' . $language_zimu['company_inc_php_18'] . '","des_themecolor":"#008000"}';
            
            notification_user_magapp('admin', $magcon);
            
            $freesetmeal = DB::fetch_first('select * from %t where id=1 order by id desc', array(
                'zimu_zhaopin_setmeal'
            ));
            
            $total = $freesetmeal['jobs_meanwhile'];
            
        }
        
        $setsqlarr['uid']       = $_G['uid'];
        $setsqlarr['jobs_name'] = zm_diconv(addslashes($_GET['jobs_name']));
        $setsqlarr['nature']    = intval($_GET['nature']);
        $setsqlarr['nature_cn'] = zm_diconv(addslashes($_GET['nature_cn']));
        
        $jobcategory                = zm_diconv(addslashes($_GET['jobcategory']));
        $jobcategory_arr            = explode(".", $jobcategory);
        $setsqlarr['topclass']      = $jobcategory_arr[0];
        $setsqlarr['category']      = $jobcategory_arr[1];
        $setsqlarr['subclass']      = $jobcategory_arr[2];
        $setsqlarr['category_cn']   = zm_diconv(addslashes($_GET['category_cn']));
        $setsqlarr['category_sort'] = zm_diconv(addslashes($_GET['category_sort']));
        $setsqlarr['amount']        = intval($_GET['amount']);
        $setsqlarr['experience']    = intval($_GET['experience']);
        $setsqlarr['experience_cn'] = zm_diconv(addslashes($_GET['experience_cn']));
        $setsqlarr['education']     = intval($_GET['education']);
        $setsqlarr['education_cn']  = zm_diconv(addslashes($_GET['education_cn']));
        $setsqlarr['wage']          = intval($_GET['wage']);
        $setsqlarr['wage_cn']       = zm_diconv(addslashes($_GET['wage_cn']));
        $setsqlarr['tag']           = I('tag', '', 'trim');
        $setsqlarr['tag_cn']        = zm_diconv(addslashes($_GET['tag_cn']));
        $setsqlarr['contents']      = zm_diconv(zm_fomat($_GET['contents']));
        $setsqlarr['company_id']    = $company_profile['id'] ? $company_profile['id'] : $result2;
        $setsqlarr['companyname']   = $company_profile['companyname'] ? $company_profile['companyname'] : $setsqlarr2['companyname'];
        $setsqlarr['sex']           = intval($_GET['sex']);
        if ($setsqlarr['sex'] == 1) {
            $sex_cn = $language_zimu['company_inc_php_19'];
        } elseif ($setsqlarr['sex'] == 2) {
            $sex_cn = $language_zimu['company_inc_php_20'];
        } else {
            $sex_cn = $language_zimu['company_inc_php_21'];
        }
        $setsqlarr['sex_cn'] = $sex_cn;
        
        $districtcategory_arr            = explode(".", $_GET['districtcategory']);
        if($districtcategory_arr[1]){
        $setsqlarr['district']  = $districtcategory_arr[0];
        $setsqlarr['district2'] = $districtcategory_arr[1];
        $setsqlarr['district3'] = $districtcategory_arr[2];
        }else{
        $setsqlarr['district']  = $_GET['districtcategory'];
        $setsqlarr['district2'] = $_GET['district2category'];
        $setsqlarr['district3'] = $_GET['district3category'];
        }
        $district_cn1 = DB::result_first('select name from %t where id=%d order by id desc', array(
            'zimu_zhaopin_area',
            $setsqlarr['district']
        ));
        $district_cn2 = DB::result_first('select name from %t where id=%d order by id desc', array(
            'zimu_zhaopin_area',
            $setsqlarr['district2']
        ));
        $district_cn3 = DB::result_first('select name from %t where id=%d order by id desc', array(
            'zimu_zhaopin_area',
            $setsqlarr['district3']
        ));
        
        if($zmdata['settings']['area_three']==1){
        $setsqlarr['district_cn'] = $district_cn2.$district_cn3;
        }else{
        $setsqlarr['district_cn'] = $district_cn1.$district_cn2;
        }
        
        $array = array(
            'trade',
            'trade_cn',
            'scale',
            'scale_cn'
        );
        foreach ($array as $val) {
            $setsqlarr[$val] = $company_profile[$val];
        }
        
        $setsqlarr['parttime_type']          = intval($_GET['parttime_type']);
        $setsqlarr['parttime_money']       = addslashes($_GET['parttime_money']);

        if ($jid) {
            
            $thejobs = DB::fetch_first('select * from %t where id=%d and uid=%d order by id desc', array(
                'zimu_zhaopin_jobs',
                $jid,
                $_G['uid']
            ));
            
            $setsqlarr['audit'] = 2;
            
            $result = DB::update('zimu_zhaopin_jobs', $setsqlarr, array(
                'id' => $jid,
                'uid' => $_G['uid']
            ));
            
        } else {
            
            if ($total <= 0 && $zmdata['settings']['add_jobs_price'] > 0) {
                $setsqlarr['audit'] = 3;
                $setsqlarr['ispay'] = 1;
            } else {
                $setsqlarr['audit'] = 2;
            }
            
            $setsqlarr['addtime']     = $_G['timestamp'];
            $setsqlarr['refreshtime'] = $_G['timestamp'];
            $jid = $result = DB::insert('zimu_zhaopin_jobs', $setsqlarr, 1);
            
            $paramter  = DB::fetch_first('select * from %t where name=%s order by id desc', array(
                'zimu_zhaopin_parameter2',
                'wxtpl'
            ));
            $paramters = unserialize($paramter['parameter']);
            
            notification_user('admin', $paramters['wxtpl_admin'], array(
                'first' => $setsqlarr2['companyname'] . $language_zimu['company_inc_php_22'],
                'keyword1' => $language_zimu['company_inc_php_23'],
                'keyword2' => date('Y-m-d H:i', $_G['timestamp']),
                'remark' => $language_zimu['company_inc_php_24'],
                'url' => ZIMUCMS_URL . '&model=viewjob&jid=' . $result
            ));
            
            
            $magcon = '{"tag":"' . $language_zimu['company_inc_php_25'] . '","title":"' . $setsqlarr2['companyname'] . $language_zimu['company_inc_php_26'] . '","title_themecolor":"#ff0000","link":"' . ZIMUCMS_URL . '&model=viewjob&jid=' . $result . '","extra_info":[{"key":"' . $language_zimu['company_inc_php_27'] . '","val":"' . $setsqlarr['jobs_name'] . '"}],"des":"' . $language_zimu['company_inc_php_28'] . '","des_themecolor":"#008000"}';
            
            notification_user_magapp('admin', $magcon);
            
        }
        
        
        $service_id = intval($_GET['service_id']);
        
        if ($service_id) {
            $service_info = DB::fetch_first('select * from %t where cat=%s and id=%d order by id desc', array(
                'zimu_zhaopin_setmeal_increment',
                'stick',
                $service_id
            ));
        }
        if ($service_info) {
            $my_setmeal  = DB::fetch_first('select * from %t where uid=%d order by id desc', array(
                'zimu_zhaopin_members_setmeal',
                $_G['uid']
            ));
            $my_discount = $my_setmeal;
            $new_price   = $my_discount['discount_stick'] > 0 ? round($service_info['price'] * $my_discount['discount_stick'] / 10, 2) : $service_info['price'];
            if ($setsqlarr['ispay'] == 1) {
                $new_price = $new_price + round($zmdata['settings']['add_jobs_price'], 2);
            }
            $params['oid']        = date('YmdHis') . mt_rand(100000, 999999);
            $params['zpid']       = $jid;
            $params['uid']        = $_G['uid'];
            $params['openid']     = $openid;
            $params['utype']      = 1;
            $params['order_type'] = 8;
            $params['pay_type']   = 2;
            $params['is_paid']    = 1;
            $params['amount']     = $new_price;
            $params['pay_amount'] = $new_price;
            $params['payment']    = 'wxpay';
            $params['payment_cn'] = $language_zimu['company_inc_php_29'];
            if ($setsqlarr['ispay'] == 1) {
                $params['description']  = $service_info['name'] . '+���ѷ���ְλ';
                $params['service_name'] = 'jobs_pay_add';
            } else {
                $params['description']  = $service_info['name'];
                $params['service_name'] = 'jobs_stick';
            }
            $params_array            = array(
                'days' => $service_info['value']
            );
            $params_array['jobs_id'] = $jid;
            $params['params']        = serialize($params_array);
            $params['addtime']       = $_G['timestamp'];
            $params['setmeal']       = $service_id;
            $params['discount']      = $language_zimu['company_inc_php_31'] . $my_discount['discount_stick'] . $language_zimu['company_inc_php_32'];
            $params['referer']       = addslashes($_GET['referer']);
            
            $return_order_info = DB::insert('zimu_zhaopin_order', $params, 1);
            
            ajaxReturn(2, $language_zimu['company_inc_php_33'], ZIMUCMS_URL . '&model=companyservice&ac=order_detail&order_id=' . $return_order_info);
            
        }
        
        if ($setsqlarr['ispay'] == 1) {
            
            $params['oid']           = date('YmdHis') . mt_rand(100000, 999999);
            $params['zpid']          = $jid;
            $params['uid']           = $_G['uid'];
            $params['openid']        = $openid;
            $params['utype']         = 1;
            $params['order_type']    = 15;
            $params['pay_type']      = 2;
            $params['is_paid']       = 1;
            $params['amount']        = round($zmdata['settings']['add_jobs_price'], 2);
            $params['pay_amount']    = round($zmdata['settings']['add_jobs_price'], 2);
            $params['payment']       = 'wxpay';
            $params['payment_cn']    = $language_zimu['company_inc_php_34'];
            $params['description']   = $language_zimu['company_inc_php_30'];
            $params['service_name']  = 'jobs_pay_add';
            $params_array            = array(
                'days' => $service_info['value']
            );
            $params_array['jobs_id'] = $jid;
            $params['params']        = serialize($params_array);
            $params['addtime']       = $_G['timestamp'];
            $params['setmeal']       = $service_id;
            $params['referer']       = addslashes($_GET['referer']);
            
            $return_order_info = DB::insert('zimu_zhaopin_order', $params, 1);
            
            ajaxReturn(2, $language_zimu['company_inc_php_36'], ZIMUCMS_URL . '&model=companyservice&ac=order_detail&order_id=' . $return_order_info);
            
        }
        
        
        
        ajaxReturn(1, $jid ? $language_zimu['company_inc_php_37'] : $language_zimu['company_inc_php_38'], array(
            'url' => ZIMUCMS_URL . '&model=company&ac=jobs_list',
            'html' => '<a href="' . ZIMUCMS_URL . '&model=company&ac=jobs_list" class="qs-btn qs-btn-medium qs-btn-blue mt2">' . $language_zimu['company_inc_php_39'] . '</a></div>'
        ));
        
    } else {
        
        $jobs = DB::fetch_first('select * from %t where id=%d and uid=%d order by id desc', array(
            'zimu_zhaopin_jobs',
            $jid,
            $_G['uid']
        ));
        
        $arealist = DB::fetch_all('select * from %t where parentid=0 order by sort asc,id asc', array(
            'zimu_zhaopin_area'
        ), 'id');
        
        foreach ($arealist as $key => $value) {
            
            $arealist[$value['id']]['list'] = DB::fetch_all('select * from %t where parentid=%d order by sort asc,id asc', array(
                'zimu_zhaopin_area',
                $value['id']
            ),'id');
            
            foreach ($arealist[$value['id']]['list'] as $key2 => $value2) {
                
                $arealist[$value['id']]['list'][$value2['id']]['list'] = DB::fetch_all('select * from %t where parentid=%d order by sort asc,id asc', array(
                    'zimu_zhaopin_area',
                    $value2['id']
                ),'id');

            }
            
            
        }
        
        $category_jobs = DB::fetch_all('select * from %t where parentid=0 order by category_order asc,id asc', array(
            'zimu_zhaopin_category_jobs'
        ));
        
        foreach ($category_jobs as $key => $value) {
            
            $category_jobs[$key]['childs'] = DB::fetch_all('select * from %t where parentid=%d order by category_order asc,id asc', array(
                'zimu_zhaopin_category_jobs',
                $value['id']
            ));
            
        }
        
        $increment_arr = DB::fetch_all('select * from %t where cat=%s order by sort asc,id desc', array(
            'zimu_zhaopin_setmeal_increment',
            'stick'
        ));
        
        
    }
} elseif ($ac == 'check_jobs_num') {
    
    $upper_limit = 0;
    
    $setmeal = DB::fetch_first('select * from %t where uid=%d order by id desc', array(
        'zimu_zhaopin_members_setmeal',
        $_G['uid']
    ));
    
    $jobs_num = DB::result_first("SELECT count(*) FROM %t where uid=%d", array(
        "zimu_zhaopin_jobs",
        $_G['uid']
    ));
    
    $total = $setmeal['jobs_meanwhile'] - $jobs_num;
    if ($total <= 0) {
        $upper_limit = 1;
    }
    ajaxReturn($upper_limit, '', $setmeal['is_free']);
    exit();
    
} elseif ($ac == 'jobs_list') {
    
    $type = I('type', 0, 'intval');
    
    $wherearr   = array();
    $wherearr[] = ' uid = ' . $_G['uid'];
    if ($type == 1) {
        $wherearr[] = ' audit != 3 and display != 2';
    } elseif ($type == 2) {
        $wherearr[] = ' ( audit = 3 or display = 2 )';
    }
    $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE ' . implode(' AND ', $wherearr) : '';
    
    
    $jobs_list = DB::fetch_all('select * from %t %i order by id desc', array(
        'zimu_zhaopin_jobs',
        $wheresql
    ));
    
    $setmeal = DB::fetch_first('select * from %t where uid=%d order by id desc', array(
        'zimu_zhaopin_members_setmeal',
        $_G['uid']
    ));
    
    $total = DB::result_first("SELECT count(*) FROM %t where uid=%d", array(
        "zimu_zhaopin_jobs",
        $_G['uid']
    ));
    
    if ($total >= $setmeal['jobs_meanwhile'])
        $upper_limit = 1;
    
} elseif ($ac == 'jobs_refresh_confirm') {
    
    $yid = intval($_GET['yid']);
    if (!$yid) {
        ajaxReturn(0, $language_zimu['company_inc_php_40']);
    }
    
    $job = DB::fetch_first('select * from %t where id=%d and uid=%d order by id desc', array(
        'zimu_zhaopin_jobs',
        $yid,
        $_G['uid']
    ));
    
    if ($job['audit'] == 3) {
        ajaxReturn(0, $language_zimu['company_inc_php_41']);
    } elseif ($job['display'] == 2) {
        ajaxReturn(0, $language_zimu['company_inc_php_42']);
    }
    
    $my_setmeal = DB::fetch_first('select * from %t where uid=%d order by id desc', array(
        'zimu_zhaopin_members_setmeal',
        $_G['uid']
    ));
    
    $tip          = '';
    $refresh_time = DB::result_first("SELECT count(*) FROM %t where uid=%d and type=%d and mode=%d and addtime>%d", array(
        "zimu_zhaopin_refresh_log",
        $_G['uid'],
        1001,
        2,
        strtotime(date('Y-m-d', $_G['timestamp']))
    ));
    
    if ($refresh_time >= $my_setmeal['refresh_jobs_free']) {
        $tip  = '<p class="font_yellow">' . $language_zimu['company_inc_php_43'] . '<strong> ' . $zmdata['settings']['refresh_jobs_price'] . '<strong> ' . $zmdata['settings']['money_name'] . '</p>
<a href="' . ZIMUCMS_URL . '&model=companyservice&ac=service_refresh_jobs_one&payment=wxpay&jobs_id=' . $yid . '" class="qs-btn qs-btn-medium qs-btn-green mt2 pay-type" data-type="wxpay">' . $language_zimu['company_inc_php_44'] . '</a>';
        $mode = 'mix';
    } else {
        $tip  = '<div class="dialog_notice">' . $language_zimu['company_inc_php_45'] . ' <span>' . ($my_setmeal['refresh_jobs_free'] - $refresh_time) . '</span> ' . $language_zimu['company_inc_php_46'] . '</div>';
        $mode = 'setmeal';
    }
    ajaxReturn(1, $tip, $mode);
    
} elseif ($ac == 'jobs_refresh') {
    
    $yid = intval($_GET['yid']);
    
    if (!$yid) {
        ajaxReturn(0, $language_zimu['company_inc_php_47']);
    }
    
    $setsqlarr['refreshtime'] = $_G['timestamp'];
    DB::update('zimu_zhaopin_jobs', $setsqlarr, array(
        'id' => $yid,
        'uid' => $_G['uid']
    ));
    
    $setsqlarr_refresh_log['uid']     = $_G['uid'];
    $setsqlarr_refresh_log['mode']    = 2;
    $setsqlarr_refresh_log['addtime'] = $_G['timestamp'];
    $setsqlarr_refresh_log['type']    = 1001;
    
    DB::insert('zimu_zhaopin_refresh_log', $setsqlarr_refresh_log, 1);
    
    ajaxReturn(1, $language_zimu['company_inc_php_48']);
    
} elseif ($ac == 'jobs_refresh_all') {
    
    $user_jobs = DB::result_first("SELECT count(*) FROM %t where audit !=3 and display !=2 and uid=%d", array(
        "zimu_zhaopin_jobs",
        $_G['uid']
    ));
    
    if ($user_jobs == 0) {
        ajaxReturn(0, $language_zimu['company_inc_php_49']);
    }
    
    $my_setmeal = DB::fetch_first('select * from %t where uid=%d order by id desc', array(
        'zimu_zhaopin_members_setmeal',
        $_G['uid']
    ));
    
    $refresh_time = DB::result_first("SELECT count(*) FROM %t where uid=%d and type=%d and mode=%d and addtime>%d", array(
        "zimu_zhaopin_refresh_log",
        $_G['uid'],
        1001,
        2,
        strtotime(date('Y-m-d', $_G['timestamp']))
    ));
    
    if ($refresh_time >= $my_setmeal['refresh_jobs_free']) {
        ajaxReturn(2, $language_zimu['company_inc_php_50'] . ' <span class="font_yellow">' . $user_jobs . '</span> ' . $language_zimu['company_inc_php_51'], 1);
    } elseif ($user_jobs + $refresh_time > $my_setmeal['refresh_jobs_free']) {
        $surplus = $my_setmeal['refresh_jobs_free'] - $refresh_time;
        ajaxReturn(2, $language_zimu['company_inc_php_52'] . ' <span class="font_yellow">' . $user_jobs . '</span> ' . $language_zimu['company_inc_php_53'] . ' <span class="font_yellow">' . $surplus . '</span> ' . $language_zimu['company_inc_php_54'], 1);
    } else {
        
        $jobsid_arr = DB::fetch_all('select id from %t where uid=%d and audit !=3 and display !=2 order by id desc', array(
            'zimu_zhaopin_jobs',
            $_G['uid']
        ));
        
        $yid = array();
        foreach ($jobsid_arr as $key => $value) {
            $yid[] = $value['id'];
            
            $setsqlarr2['uid']     = $_G['uid'];
            $setsqlarr2['mode']    = 2;
            $setsqlarr2['addtime'] = $_G['timestamp'];
            $setsqlarr2['type']    = 1001;
            DB::insert('zimu_zhaopin_refresh_log', $setsqlarr2, 1);
            
        }
        
        DB::query("update %t set refreshtime=%d where id in (%n) and uid=%d", array(
            'zimu_zhaopin_jobs',
            $_G['timestamp'],
            $yid,
            $_G['uid']
        ));
        
        
        ajaxReturn(1, $language_zimu['company_inc_php_55']);
        
    }
    
} elseif ($ac == 'jobs_apply') {
    
    $settr   = I('settr', 0, 'intval');
    $jobs_id = I('jobs_id', 0, 'intval');
    $state   = I('state', 0, 'intval');
    
    $state_arr = array(
        '1' => $language_zimu['company_inc_php_56'],
        '2' => $language_zimu['company_inc_php_57'],
        '3' => $language_zimu['company_inc_php_58'],
        '4' => $language_zimu['company_inc_php_59']
    );
    
    $jobs_list = DB::fetch_all('select * from %t where uid=%d and audit !=3 and display!=2 order by id asc', array(
        'zimu_zhaopin_jobs',
        $_G['uid']
    ), 'id');
    if ($jobs_id) {
        $wheresql = $wheresql . ' and jobs_id=' . $jobs_id;
    }
    if ($state) {
        $wheresql = $wheresql . ' and is_reply=' . $state;
    }
    $apply_list = DB::fetch_all('select * from %t where company_uid=%d %i order by is_reply asc,did desc', array(
        'zimu_zhaopin_personal_jobs_apply',
        $_G['uid'],
        $wheresql
    ));

$utype = DB::result_first('select utype from %t where uid=%d order by id desc', array(
        'zimu_zhaopin_members',
        $_G['uid']
    ));

} elseif ($ac == 'jobs_resume') {
    
    $jid   = intval($_GET['jid']);
    
    $jobsdata = DB::fetch_first('select * from %t where id=%d order by id desc', array(
        'zimu_zhaopin_jobs',
        $jid
    ));

    if($jobsdata['sex']){
    $wherearr[]=' sex = '.$jobsdata['sex'];
    }
    if($jobsdata['topclass']){
    $topcat = $jobsdata['topclass'].'.';
    $wherearr[]=' intention_jobs_id LIKE \'%'.$topcat.'%\' ';
    }
    if($jobsdata['experience']){
    $wherearr[]=' experience >= '.$jobsdata['experience'];
    }
    if($jobsdata['education']){
    $wherearr[]=' education >= '.$jobsdata['education'];
    }
    if($jobsdata['wage']){
    $wherearr[]=' wage <= '.$jobsdata['wage'];
    }

    $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';


    $resumelist = DB::fetch_all('select * from %t %i order by refreshtime desc,id desc', array(
        'zimu_zhaopin_resume',
        $wheresql
    ));

    $utype = DB::result_first('select utype from %t where uid=%d order by id desc', array(
            'zimu_zhaopin_members',
            $_G['uid']
        ));


} elseif ($ac == 'jobs_interview') {
    
    $settr   = I('settr', 0, 'intval');
    $jobs_id = I('jobs_id', 0, 'intval');
    $state   = I('state', 0, 'intval');
    
    $state_arr = array(
        '1' => $language_zimu['company_inc_php_60'],
        '2' => $language_zimu['company_inc_php_61'],
        '3' => $language_zimu['company_inc_php_62'],
        '4' => $language_zimu['company_inc_php_63']
    );
    
    $jobs_list = DB::fetch_all('select * from %t where uid=%d and audit !=3 and display!=2 order by id asc', array(
        'zimu_zhaopin_jobs',
        $_G['uid']
    ), 'id');

    if ($jobs_id) {
        $wheresql = $wheresql . ' and jobs_id=' . $jobs_id;
    }
    if ($state) {
        $wheresql = $wheresql . ' and is_reply=' . $state;
    }
    $apply_list = DB::fetch_all('select * from %t where company_uid=%d %i order by id desc', array(
        'zimu_zhaopin_company_interview',
        $_G['uid'],
        $wheresql
    ));


} else if ($ac == 'jobs_interview_del' && $_GET['md5hash'] == formhash()) {
    
    $ids = intval($_GET['ids']);
    
    $result = DB::delete('zimu_zhaopin_company_interview', array(
        'id' => $ids,
        'company_uid' => $_G['uid']
    ));
    
    ajaxReturn(1, $language_zimu['company_inc_php_64']);
    

} elseif ($ac == 'company_label_resume_apply') {
    
    $did   = I('did', 0, 'intval');
    $state = I('state', 0, 'intval');
    !$did && ajaxReturn(0, $language_zimu['company_inc_php_65']);
    
    DB::query("update %t set personal_look=2,is_reply=%d,reply_time=%d where did=%d", array(
        'zimu_zhaopin_personal_jobs_apply',
        $state,
        $_G['timestamp'],
        $did
    ));
    
    if($state==2){

        $applydata = DB::fetch_first('select * from %t where did=%d order by did desc', array(
            'zimu_zhaopin_personal_jobs_apply',
            $did
        ));

        $touid   = intval($_GET['touid']);

        $paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
            'zimu_zhaopin_parameter2',
            'wxtpl'
        ));
        
        $paramters = unserialize($paramter['parameter']);
        
        $first = $language_zimu['company_inc_php_66'];
        $keyword1 = $language_zimu['company_inc_php_67'].$applydata['jobs_name'].'('.$applydata['company_name'].')'.$language_zimu['company_inc_php_68'];
        $remark = $language_zimu['company_inc_php_69'];

        $templatedata = array(
                'first' => array(
                    'value' => urlencode(diconv($first, CHARSET, 'utf-8')),
                    'color' => "#FF4040"
                ),
                'keyword1' => array(
                    'value' => urlencode(diconv(zm_diconv($keyword1), CHARSET, 'utf-8'))
                ),
                'keyword2' => array(
                    'value' => date('Y-m-d H:i',$_G['timestamp'])
                ),
                'remark' => array(
                    'value' => urlencode(diconv(zm_diconv($remark), CHARSET, 'utf-8')),
                    'color' => "#008000"
                )
        );

        notification_user2($applydata['personal_uid'], $paramters['wxtpl_admin'], $templatedata, ZIMUCMS_URL . '&model=jobs');
        
        $magcon = '{"tag":"' . $language_zimu['company_inc_php_70'] . '","title":"' . $language_zimu['company_inc_php_71'] . '","title_themecolor":"#ff0000","link":"' . ZIMUCMS_URL . '&model=jobs","extra_info":[{"key":"' . $language_zimu['company_inc_php_72'] . '","val":"' . $applydata['jobs_name'] . '"},{"key":"' . $language_zimu['company_inc_php_73'] . '","val":"' . $applydata['company_name'] . '"},{"key":"' . $language_zimu['company_inc_php_74'] . '","val":"'.$language_zimu['company_inc_php_75'].'"}],"des":"' . $remark . '","des_themecolor":"#008000"}';
        
        notification_user_magapp($applydata['personal_uid'], $magcon);
                



    }



    ajaxReturn(1, $language_zimu['company_inc_php_76']);
    
} elseif ($ac == 'company_label_resume_down') {
    
    $did   = I('did', 0, 'intval');
    $state = I('state', 0, 'intval');
    !$did && ajaxReturn(0, $language_zimu['company_inc_php_77']);
    
    DB::query("update %t set is_reply=%d where did=%d", array(
        'zimu_zhaopin_company_down_resume',
        $state,
        $did
    ));
    
    ajaxReturn(1, $language_zimu['company_inc_php_78']);
    
} elseif ($ac == 'resume_down') {
    
    $state     = I('state', 0, 'intval');
    $state_arr = array(
        '1' => $language_zimu['company_inc_php_79'],
        '2' => $language_zimu['company_inc_php_80'],
        '3' => $language_zimu['company_inc_php_81'],
        '4' => $language_zimu['company_inc_php_82']
    );
    
    if ($state) {
        $wheresql = $wheresql . ' and is_reply=' . $state;
    }
    
    $down_list = DB::fetch_all('select * from %t where company_uid=%d %i order by did desc', array(
        'zimu_zhaopin_company_down_resume',
        $_G['uid'],
        $wheresql
    ));
    
    
} elseif ($ac == 'resume_favorites') {
    
    $education_list  = $category_jobs2['ZM_education'];
    $experience_list = $category_jobs2['ZM_experience'];
    
    $education_id  = intval($_GET['education']);
    $experience_id = intval($_GET['experience']);
    
    if ($education_id) {
        $wheresql = $wheresql . ' and education=' . $education_id;
    }
    if ($experience_id) {
        $wheresql = $wheresql . ' and experience=' . $experience_id;
    }
    
    $aaa = DB::query('select a.did,a.favorites_addtime,a.resume_id,b.* from %t a left join %t b on a.resume_id=b.id where a.company_uid=%d %i order by favorites_addtime desc', array(
        'zimu_zhaopin_company_favorites',
        'zimu_zhaopin_resume',
        $_G['uid'],
        $wheresql
    ));
    
    while ($res = DB::fetch($aaa)) {
        $favorites[] = $res;
    }
    
} elseif ($ac == 'jobs_close') {
    
    $jobs_id = intval($_GET['jobs_id']);
    
    DB::query("update %t set display=2 where id=%d and uid=%d", array(
        'zimu_zhaopin_jobs',
        $jobs_id,
        $_G['uid']
    ));
    
    ajaxReturn(1, $language_zimu['company_inc_php_83'], ZIMUCMS_URL . '&model=company&ac=jobs_list');
    
} elseif ($ac == 'jobs_display') {
    
    $jobs_id = intval($_GET['jobs_id']);
    
    $upper_limit = 0;
    $my_setmeal  = DB::fetch_first('select * from %t where uid=%d order by id desc', array(
        'zimu_zhaopin_members_setmeal',
        $_G['uid']
    ));
    
    $jids = DB::result_first("SELECT count(*) FROM %t where uid=%d and audit!=3 and display!=2", array(
        "zimu_zhaopin_jobs",
        $_G['uid']
    ));
    
    if ($jids >= $my_setmeal['jobs_meanwhile'])
        $upper_limit = 1;
    if ($upper_limit) {
        ajaxReturn(2);
    }
    
    DB::query("update %t set display=1 where id=%d and uid=%d", array(
        'zimu_zhaopin_jobs',
        $jobs_id,
        $_G['uid']
    ));
    
    ajaxReturn(1, $language_zimu['company_inc_php_84'], ZIMUCMS_URL . '&model=company&ac=jobs_list');
    
} elseif ($ac == 'jobs_delete') {
    
    $jobs_id = intval($_GET['jobs_id']);
    
    $result = DB::delete('zimu_zhaopin_jobs', array(
        'id' => $jobs_id,
        'uid' => $_G['uid']
    ));
    
    ajaxReturn(1, $language_zimu['company_inc_php_85'], ZIMUCMS_URL . '&model=company&ac=jobs_list');
    
} elseif ($ac == 'viewlog') {
    
    $favorites = DB::fetch_all('select * from %t where uid=%d order by addtime desc', array(
        'zimu_zhaopin_com_viewlog',
        $_G['uid']
    ));
    
} elseif ($ac == 'jobs_viewlog') {
    
    $favorites = DB::fetch_all('select * from %t where cid=%d order by addtime desc', array(
        'zimu_zhaopin_per_viewlog',
        $company_profile['id']
    ));

} elseif ($ac == 'jobs_interview_add') {

if ($tosubmit == 1 && $_GET['md5hash'] == formhash()) {

        $resume = DB::fetch_first('select * from %t where id=%d order by id desc', array(
            'zimu_zhaopin_resume',
            intval($_GET['resume_id'])
        ));

        $jobs = DB::fetch_first('select * from %t where id=%d order by id desc', array(
            'zimu_zhaopin_jobs',
            intval($_GET['jobs_id'])
        ));

            $company_interview_data['resume_id'] = I('resume_id',0,'intval');
            $company_interview_data['resume_name'] = $resume['fullname'];
            $company_interview_data['resume_uid'] = $resume['uid'];
            $company_interview_data['jobs_id'] = I('jobs_id',0,'intval');
            $company_interview_data['jobs_name'] = $jobs['jobs_name'];
            $company_interview_data['company_id'] = $company_profile['id'];
            $company_interview_data['company_name'] = $company_profile['companyname'];
            $company_interview_data['company_uid'] = $company_profile['uid'];
            $date = I('date','','trim');
            if(!$date){
                ajaxReturn(0,$language_zimu['company_inc_php_86']);
            }
            $ap = I('ap',1,'intval')== 1? 'AM' : 'PM';
            $ap2 = I('ap',1,'intval')== 1? $language_zimu['company_inc_php_87'] : $language_zimu['company_inc_php_88'];
            $time = I('time',0,'intval');
            if(!$time){
                ajaxReturn(0,$language_zimu['company_inc_php_89']);
            }
            $interview_time = strtotime($date.' '.$time.':00:00 '.$ap);
            $company_interview_data['interview_time'] = $date.' '.$ap2.$time.$language_zimu['company_inc_php_90'];
            if($interview_time<time()){
                ajaxReturn(0,$language_zimu['company_inc_php_91']);
            }
            $company_interview_data['address'] = zm_diconv(addslashes($_GET['address']));
            $company_interview_data['contact'] = zm_diconv(addslashes($_GET['contact']));
            $company_interview_data['telephone'] = zm_diconv(addslashes($_GET['telephone']));
            $company_interview_data['notes'] = zm_diconv(addslashes($_GET['notes']));
            $company_interview_data['interview_addtime'] = $_G['timestamp'];
            $result = DB::insert('zimu_zhaopin_company_interview', $company_interview_data, 1);


        $paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
            'zimu_zhaopin_parameter2',
            'wxtpl'
        ));
        
        $paramters = unserialize($paramter['parameter']);
        
        $first = $resume['fullname'].$language_zimu['company_inc_php_92'];

        $templatedata = array(
                'first' => array(
                    'value' => urlencode(diconv($first, CHARSET, 'utf-8')),
                    'color' => "#FF4040"
                ),
                'job' => array(
                    'value' => urlencode(diconv(strip_tags(zm_diconv($jobs['jobs_name'])), CHARSET, 'utf-8'))
                ),
                'company' => array(
                    'value' => urlencode(diconv(strip_tags(zm_diconv($company_profile['companyname'])), CHARSET, 'utf-8'))
                ),
                'time' => array(
                    'value' => urlencode(diconv(strip_tags(zm_diconv($company_interview_data['interview_time'])), CHARSET, 'utf-8'))
                ),
                'address' => array(
                    'value' => urlencode(diconv(strip_tags(zm_diconv($company_interview_data['address'])), CHARSET, 'utf-8'))
                ),
                'contact' => array(
                    'value' => urlencode(diconv(strip_tags(zm_diconv($company_interview_data['contact'])), CHARSET, 'utf-8'))
                ),
                'tel' => array(
                    'value' => urlencode(diconv(strip_tags(zm_diconv($company_interview_data['telephone'])), CHARSET, 'utf-8'))
                ),
                'remark' => array(
                    'value' => urlencode(diconv(strip_tags(zm_diconv($company_interview_data['notes'].$language_zimu['company_inc_php_93'])), CHARSET, 'utf-8')),
                    'color' => "#008000"
                )
        );

        notification_user2($resume['uid'], $paramters['wxtpl_jobs_mianshi'], $templatedata, ZIMUCMS_URL . '&model=personal&ac=jobs_interview');
        
        $magcon = '{"tag":"' . $language_zimu['company_inc_php_94'] . '","title":"' . $language_zimu['company_inc_php_95'] . '","title_themecolor":"#ff0000","link":"' . ZIMUCMS_URL . '&model=personal&ac=jobs_interview","extra_info":[{"key":"' . $language_zimu['company_inc_php_96'] . '","val":"' . $jobs['jobs_name'] . '"},{"key":"' . $language_zimu['company_inc_php_97'] . '","val":"' . $company_profile['companyname'] . '"},{"key":"' . $language_zimu['company_inc_php_98'] . '","val":"' . $company_interview_data['interview_time'] . '"},{"key":"' . $language_zimu['company_inc_php_99'] . '","val":"' . $company_interview_data['address'] . '"},{"key":"' . $language_zimu['company_inc_php_100'] . '","val":"' . $company_interview_data['contact'] . '"},{"key":"' . $language_zimu['company_inc_php_101'] . '","val":"' . $company_interview_data['telephone'] . '"}],"des":"' . $company_interview_data['notes'].$language_zimu['company_inc_php_102'] . '","des_themecolor":"#008000"}';
        
        notification_user_magapp($resume['uid'], $magcon);
                




            ajaxReturn(1,$language_zimu['company_inc_php_103']);



}else{
        $rid = intval($_GET['rid']);

        $apply = DB::fetch_first('select * from %t where id=%d order by id desc', array(
            'zimu_zhaopin_resume',
            $rid
        ));

        $alljobs = DB::fetch_all('select * from %t where company_id=%d order by id desc', array(
            'zimu_zhaopin_jobs',
            $company_profile['id']
        ));
}

} else {
    
    DB::query("update %t set utype=1 where uid=%d", array(
        'zimu_zhaopin_members',
        $_G['uid']
    ));
    
    if (!$company_profile && !checkmobile()) {
        
        dheader('Location: ' . ZIMUCMS_URL . '&model=company&ac=com_info');
        
    }

    $my_setmeal = DB::fetch_first('select * from %t where uid=%d order by id desc', array(
        'zimu_zhaopin_members_setmeal',
        $_G['uid']
    ));

    if ($company_profile && $my_setmeal['setmeal_id'] > 0 && $my_setmeal['endtime'] < $_G['timestamp'] && $my_setmeal['endtime'] > 0) {
    
    
    $freesetmeal = DB::fetch_first('select * from %t where id=1 order by id desc', array(
        'zimu_zhaopin_setmeal'
    ));
    
    $timestamp                         = time();
    $setsqlarr2['expire']              = $freesetmeal['is_free'] == 1 ? 1 : 0;
    $setsqlarr2['uid']                 = $_G['uid'];
    $setsqlarr2['setmeal_id']          = $freesetmeal['id'];
    $setsqlarr2['setmeal_name']        = $freesetmeal['setmeal_name'];
    $setsqlarr2['days']                = $freesetmeal['days'];
    $setsqlarr2['expense']             = $freesetmeal['expense'];
    $setsqlarr2['jobs_meanwhile']      = $freesetmeal['jobs_meanwhile'];
    $setsqlarr2['refresh_jobs_free']   = $freesetmeal['refresh_jobs_free'];
    //$setsqlarr2['download_resume']     = $my_setmeal['download_resume'] + $freesetmeal['download_resume'];
    $setsqlarr2['download_resume']     = $freesetmeal['download_resume'];
    $setsqlarr2['download_resume_max'] = $freesetmeal['download_resume_max'];
    $setsqlarr2['added']               = $freesetmeal['added'];
    $setsqlarr2['starttime']           = $_G['timestamp'];
    if ($freesetmeal['days'] > 0) {
        $setsqlarr2['endtime'] = strtotime("" . $freesetmeal['days'] . " days");
    } else {
        $setsqlarr2['endtime'] = "0";
    }
    
    $setsqlarr2['set_sms'] = $my_setmeal['set_sms'] + $freesetmeal['set_sms'];
    
    $setsqlarr2['show_apply_contact']         = $freesetmeal['show_apply_contact'];
    $setsqlarr2['is_free']                    = $freesetmeal['is_free'];
    $setsqlarr2['discount_download_resume']   = $freesetmeal['discount_download_resume'];
    $setsqlarr2['discount_sms']               = $freesetmeal['discount_sms'];
    $setsqlarr2['discount_stick']             = $freesetmeal['discount_stick'];
    $setsqlarr2['discount_emergency']         = $freesetmeal['discount_emergency'];
    $setsqlarr2['discount_auto_refresh_jobs'] = $freesetmeal['discount_auto_refresh_jobs'];
    

    DB::update('zimu_zhaopin_members_setmeal', $setsqlarr2, array(
        'uid' => $_G['uid']
    ));
    
    DB::update('zimu_zhaopin_company_profile', array(
        'setmeal_id' => $setsqlarr2['setmeal_id'],
        'setmeal_name' => $setsqlarr2['setmeal_name']
    ), array(
        'uid' => $_G['uid']
    ));


    DB::update('zimu_zhaopin_jobs', array(
        'setmeal_deadline' => $setsqlarr2['endtime'],
        'setmeal_id' => $setsqlarr2['setmeal_id'],
        'setmeal_name' => $setsqlarr2['setmeal_name']
    ), array(
        'uid' => $_G['uid']
    ));
    
    
    }


    $my_setmeal = DB::fetch_first('select * from %t where uid=%d order by id desc', array(
        'zimu_zhaopin_members_setmeal',
        $_G['uid']
    ));
    
    $jobs_total = DB::result_first('select count(*) from %t where uid=%d and audit!=3 order by id desc', array(
        'zimu_zhaopin_jobs',
        $_G['uid']
    ));
    
    $my_setmeal['surplus_jobs'] = $my_setmeal['jobs_meanwhile'] - $jobs_total;
    
    if ($my_setmeal['endtime'] == 0) {
        $leave_days = $language_zimu['company_inc_php_104'];
    } else {
        $minus      = ($my_setmeal['endtime'] - time()) / 3600 / 24;
        $leave_days = intval($minus);
    }
    
    $tag_arr = explode(',', $company_profile['tag_cn']);
    
    
    $audit_jobs = DB::result_first("SELECT count(*) FROM %t where uid=%d and audit != 3 and display != 2", array(
        "zimu_zhaopin_jobs",
        $_G['uid']
    ));
    
    $audit_jobs2 = DB::result_first("SELECT count(*) FROM %t where uid=%d and (audit = 3 or display = 2 ) ", array(
        "zimu_zhaopin_jobs",
        $_G['uid']
    ));
    
    $nolook_resume = DB::result_first("SELECT count(*) FROM %t where company_uid=%d and is_reply=0", array(
        "zimu_zhaopin_personal_jobs_apply",
        $_G['uid']
    ));
    
    $download_resume = DB::result_first("SELECT count(*) FROM %t where company_uid=%d", array(
        "zimu_zhaopin_company_down_resume",
        $_G['uid']
    ));
    
    $collection_resume = DB::result_first("SELECT count(*) FROM %t where company_uid=%d", array(
        "zimu_zhaopin_company_favorites",
        $_G['uid']
    ));

     $total_view = DB::result_first("SELECT count(*) FROM %t where cid=%d group by uid", array(
        "zimu_zhaopin_per_viewlog",
        $company_profile['id']
    ));

}

include zimu_template('company_' . $ac);