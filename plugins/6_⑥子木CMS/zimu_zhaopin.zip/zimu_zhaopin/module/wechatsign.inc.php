<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$url = addslashes($_GET['url']);

if ($zmdata['base']['weixin_appid'] && $zmdata['base']['weixin_appsecret']) {
    require_once DISCUZ_ROOT . './source/plugin/zimu_zhaopin/class/wechat.lib.class.php';
    $wechat_client = new WeChatClient($zmdata['base']['weixin_appid'], $zmdata['base']['weixin_appsecret']);
    $jssdkvalue    = $wechat_client->getSignPackage($url);
    echo json_encode($jssdkvalue,true);
}
