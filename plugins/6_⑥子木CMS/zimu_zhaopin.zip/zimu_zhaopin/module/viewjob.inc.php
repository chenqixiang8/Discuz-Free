<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

header("Access-Control-Allow-Origin: *");

$manage_uids = str_replace(';', ',', $zmdata['manage_uids']);
$manage_uids = explode(',', $manage_uids);

if (in_array($_G['uid'], $manage_uids)) {
    $noauditwheresql2 = '';
}

$jid = intval($_GET['jid']);

$jobdata = DB::fetch_first('select * from %t where id=%d ' . $noauditwheresql2 . ' order by id asc', array(
    'zimu_zhaopin_jobs',
    $jid
));

$companydata = DB::fetch_first('select * from %t where id=%d order by id asc', array(
    'zimu_zhaopin_company_profile',
    $jobdata['company_id']
));

$setmeal = DB::fetch_first('select * from %t where uid = %d order by id desc', array(
    'zimu_zhaopin_members_setmeal',
    $jobdata['uid']
));

$companydata['setmeal_img'] = DB::result_first('select setmeal_img from %t where id=%d order by id desc', array(
    'zimu_zhaopin_setmeal',
    $setmeal['setmeal_id']
));

$companyjob = DB::fetch_all('select * from %t where audit !=3 and display != 2 and company_id=%d ' . $noauditwheresql2 . ' order by rand() limit 5', array(
    'zimu_zhaopin_jobs',
    $jobdata['company_id']
));

$randjob = DB::fetch_all('select * from %t where audit !=3 and display != 2 ' . $noauditwheresql2 . ' order by rand() limit 8', array(
    'zimu_zhaopin_jobs'
));

$utype = DB::result_first('select utype from %t where uid=%d order by id desc', array(
    'zimu_zhaopin_members',
    $_G['uid']
));

$hasfav = DB::fetch_first('select * from %t where personal_uid=%d and jobs_id=%d order by did desc', array(
    'zimu_zhaopin_personal_favorites',
    $_G['uid'],
    $jid
));

$isresume = DB::fetch_first('select * from %t where personal_uid=%d and jobs_id=%d order by did desc', array(
    'zimu_zhaopin_personal_jobs_apply',
    $_G['uid'],
    $jid
));

$resume_info = DB::fetch_first('select * from %t where uid=%d order by id asc', array(
    'zimu_zhaopin_resume',
    $_G['uid']
));

$applynums = DB::result_first("SELECT count(*) FROM %t where jobs_id=%d", array(
    "zimu_zhaopin_personal_jobs_apply",
    $jid
));

if ($isresume) {
    
    
} else {
    
    if (!$resume_info || ($zmdata['settings']['resume_tocomtel'] && $resume_info['audit'] != 1) || ($zmdata['settings']['look_com_tel'] == 1 && !$isresume)) {
        
        $companydata['telephone'] = substr_replace($companydata['telephone'], '****', 3, 4);
        
        if ($zmdata['settings']['resume_tocomtel'] && $resume_info['audit'] != 1) {
            $hidetel     = 1;
            $hidetel_msg = $language_zimu['viewjob_inc_php_0'] . '<br>' . $language_zimu['viewjob_inc_php_1'] . '<br><img style=\'width:200px;\' src=\'' . $zmdata['settings']['kefu_qrcode_url'] . '\'><p style=\'color:#ff552e;font-size:15px;\'>' . $language_zimu['viewjob_inc_php_2'] . '</p>';
        }
        
    }
    
}

$mag_paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
    'zimu_zhaopin_parameter2',
    'magapp'
));

$mag_paramter = unserialize($mag_paramter['parameter']);


$navtitle    = $jobdata['jobs_name'] . '_' . $jobdata['companyname'] . '_' . $zmdata['base']['title'];
$keywords    = $jobdata['jobs_name'] . ',' . $jobdata['companyname'] . ',' . $zmdata['base']['title'];
$description = $jobdata['contents'];

$share_title = $jobdata['jobs_name'] . '_' . $jobdata['companyname'] . '_' . $zmdata['base']['title'];
$share_desc  = $zmdata['base']['share_desc'];
$share_url   = rtrim($_G['siteurl'], '/') . $_SERVER['REQUEST_URI'];
if ($companydata['logo'] && !preg_match('/^(http|\.)/i', $companydata['logo'])) {
    $companydata['logo'] = $_G['siteurl'] . $companydata['logo'];
}
$share_thumb = $companydata['logo'] ? $companydata['logo'] : $share_thumb;

if (!checkmobile()) {
    $isfav = DB::fetch_first('select * from %t where uid=%d and company_id=%d order by id desc', array(
        'zimu_zhaopin_personal_focus_company',
        $_G['uid'],
        $cid
    ));
}

if ($_G['uid']) {
    
    $is_viewlog = DB::fetch_first('select * from %t where uid=%d and jid=%d order by id desc', array(
        'zimu_zhaopin_per_viewlog',
        $_G['uid'],
        $jid
    ));
    
    if ($is_viewlog) {
        
        DB::query("update %t set addtime=%d where id=%d", array(
            'zimu_zhaopin_per_viewlog',
            $_G['timestamp'],
            $is_viewlog['id']
        ));
        
    } else {
        
        $per_viewlog['uid']     = $_G['uid'];
        $per_viewlog['jid']     = $jid;
        $per_viewlog['jobname'] = $jobdata['jobs_name'];
        $per_viewlog['cid']     = $jobdata['company_id'];
        $per_viewlog['comname'] = $jobdata['companyname'];
        $per_viewlog['addtime'] = $_G['timestamp'];
        DB::insert('zimu_zhaopin_per_viewlog', $per_viewlog);
    }
    
}

$viewjob_seo_title = preg_replace(array(
    '/jobs_name/',
    '/wage_cn/',
    '/amount/',
    '/experience_cn/',
    '/education_cn/',
    '/sex_cn/',
    '/district_cn/',
    '/companyname/',
    '/tag_cn/',
    '/contents/'
), array(
    $jobdata['jobs_name'],
    $jobdata['wage_cn'],
    $jobdata['amount'],
    $jobdata['experience_cn'],
    $jobdata['education_cn'],
    $jobdata['sex_cn'],
    $jobdata['district_cn'],
    $jobdata['companyname'],
    $jobdata['tag_cn'],
    $jobdata['contents']
), $zmdata['settings']['viewjob_seo_title']);

$viewjob_seo_keyword = preg_replace(array(
    '/jobs_name/',
    '/wage_cn/',
    '/amount/',
    '/experience_cn/',
    '/education_cn/',
    '/sex_cn/',
    '/district_cn/',
    '/companyname/',
    '/tag_cn/',
    '/contents/'
), array(
    $jobdata['jobs_name'],
    $jobdata['wage_cn'],
    $jobdata['amount'],
    $jobdata['experience_cn'],
    $jobdata['education_cn'],
    $jobdata['sex_cn'],
    $jobdata['district_cn'],
    $jobdata['companyname'],
    $jobdata['tag_cn'],
    $jobdata['contents']
), $zmdata['settings']['viewjob_seo_keyword']);

$viewjob_seo_desc = preg_replace(array(
    '/jobs_name/',
    '/wage_cn/',
    '/amount/',
    '/experience_cn/',
    '/education_cn/',
    '/sex_cn/',
    '/district_cn/',
    '/companyname/',
    '/tag_cn/',
    '/contents/'
), array(
    $jobdata['jobs_name'],
    $jobdata['wage_cn'],
    $jobdata['amount'],
    $jobdata['experience_cn'],
    $jobdata['education_cn'],
    $jobdata['sex_cn'],
    $jobdata['district_cn'],
    $jobdata['companyname'],
    $jobdata['tag_cn'],
    $jobdata['contents']
), $zmdata['settings']['viewjob_seo_desc']);


$viewjob_seo_desc = str_replace(array(
    "\r\n",
    "\r",
    "\n"
), "", $viewjob_seo_desc);

$navtitle    = $share_title = $viewjob_seo_title ? $viewjob_seo_title : $navtitle;
$keywords    = $viewjob_seo_keyword ? $viewjob_seo_keyword : $navtitle;
$description = $share_desc = $viewjob_seo_desc ? $viewjob_seo_desc : $navtitle;


if (IN_WECHAT && checkmobile() && $zmdata['settings']['wx_create_qrcode'] == 1) {
    
    require_once DISCUZ_ROOT . './source/plugin/zimu_zhaopin/class/wechat.lib.class.php';
    $wechat_client = new WeChatClient($zmdata['base']['weixin_appid'], $zmdata['base']['weixin_appsecret']);
    
    $qrcode_url = $wechat_client->getQrcodeImgUrlByTicket($wechat_client->getQrcodeTicket(array(
        'scene_str' => $model . 'zimuyun' . $jid,
        'expire' => 2591000
    )));
    $qrcode_img = base64_encode(dfsockopen($qrcode_url));
    $qrcode_img = $qrcode_img ? $qrcode_img : base64_encode(file_get_contents($qrcode_url));
    
}

if ($zmdata['settings']['diyposter'] == 1) {
    
    $diyposter_paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
        'zimu_zhaopin_parameter2',
        'diyposter'
    ));
    
    $diyposter = unserialize($diyposter_paramter['parameter']);
    
    foreach ($diyposter['data'] as $key => $value) {
        if ($value['type'] == 'com_logo') {
            $diyposter['data'][$key]['words'] = ZIMUCMS_URL . '&model=toimg&url=' . $companydata['logo'];
        }
        if ($value['type'] == 'com_name') {
            $diyposter['data'][$key]['words'] = $companydata['companyname'];
        }
        if ($value['type'] == 'jobs_name') {
            $diyposter['data'][$key]['words'] = $jobdata['jobs_name'];
        }
        if ($value['type'] == 'jobs_wage') {
            $diyposter['data'][$key]['words'] = $jobdata['wage_cn'];
        }
        if ($value['type'] == 'jobs_address') {
            $diyposter['data'][$key]['words'] = $companydata['address'];
        }
        if ($value['type'] == 'jobs_address') {
            $diyposter['data'][$key]['words'] = $companydata['address'];
        }
        
    }
    
    if ($diyposter['bg'] && !preg_match('/^(http|\.)/i', $diyposter['bg'])) {
        $diyposter['bg'] = $_G['siteurl'] . $diyposter['bg'];
    }
    
    $bg_data   = getimagesize($diyposter['bg']);
    $bg_height = $bg_data[1] * (450 / $bg_data[0]);
    
}

$audit_tip1 = explode("\r\n", trim($zmdata['settings']['audit_tip1']));
$audit_tip2 = explode("\r\n", trim($zmdata['settings']['audit_tip2']));

include zimu_template('viewjob');
