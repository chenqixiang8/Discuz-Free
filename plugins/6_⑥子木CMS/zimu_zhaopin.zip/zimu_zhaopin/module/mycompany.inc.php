<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

isuid();

require_once DISCUZ_ROOT . './source/plugin/zimu_zhaopin/module/creatmember.inc.php';

$paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
    'zimu_zhaopin_parameter2',
    'indexad'
));

$paramters_indexad = unserialize($paramter['parameter']);

$company_profile = DB::fetch_first('select * from %t where uid = %d order by id desc', array(
    'zimu_zhaopin_company_profile',
    $_G['uid']
));


$setmeal = DB::fetch_first('select * from %t where uid = %d order by id desc', array(
    'zimu_zhaopin_members_setmeal',
    $_G['uid']
));

if ($company_profile && !$setmeal) {
    
    $freesetmeal = DB::fetch_first('select * from %t where id=1 order by id desc', array(
        'zimu_zhaopin_setmeal'
    ));
    
    $timestamp                         = time();
    $setsqlarr2['expire']              = $freesetmeal['is_free'] == 1 ? 1 : 0;
    $setsqlarr2['uid']                 = $_G['uid'];
    $setsqlarr2['setmeal_id']          = $freesetmeal['id'];
    $setsqlarr2['setmeal_name']        = $freesetmeal['setmeal_name'];
    $setsqlarr2['days']                = $freesetmeal['days'];
    $setsqlarr2['expense']             = $freesetmeal['expense'];
    $setsqlarr2['jobs_meanwhile']      = $freesetmeal['jobs_meanwhile'];
    $setsqlarr2['refresh_jobs_free']   = $freesetmeal['refresh_jobs_free'];
    $setsqlarr2['download_resume']     = $freesetmeal['download_resume'];
    $setsqlarr2['download_resume_max'] = $freesetmeal['download_resume_max'];
    $setsqlarr2['added']               = $freesetmeal['added'];
    $setsqlarr2['starttime']           = $_G['timestamp'];
    if ($freesetmeal['days'] > 0) {
        $setsqlarr2['endtime'] = strtotime("" . $freesetmeal['days'] . " days");
    } else {
        $setsqlarr2['endtime'] = "0";
    }
    
    $setsqlarr2['set_sms'] = $freesetmeal['set_sms'];
    
    $setsqlarr2['show_apply_contact']         = $freesetmeal['show_apply_contact'];
    $setsqlarr2['is_free']                    = $freesetmeal['is_free'];
    $setsqlarr2['discount_download_resume']   = $freesetmeal['discount_download_resume'];
    $setsqlarr2['discount_sms']               = $freesetmeal['discount_sms'];
    $setsqlarr2['discount_stick']             = $freesetmeal['discount_stick'];
    $setsqlarr2['discount_emergency']         = $freesetmeal['discount_emergency'];
    $setsqlarr2['discount_auto_refresh_jobs'] = $freesetmeal['discount_auto_refresh_jobs'];
    
    DB::insert('zimu_zhaopin_members_setmeal', $setsqlarr2);
    
    $setmeal = DB::fetch_first('select * from %t where uid = %d order by id desc', array(
        'zimu_zhaopin_members_setmeal',
        $_G['uid']
    ));

    DB::query("update %t set setmeal_deadline=%d,setmeal_id=%d,setmeal_name=%s where uid=%d", array(
        'zimu_zhaopin_jobs',
        $setsqlarr2['endtime'],
        $setsqlarr2['setmeal_id'],
        $setsqlarr2['setmeal_name'],
        $_G['uid']
    ));

} elseif ($company_profile && $setmeal['setmeal_id'] > 0 && $setmeal['endtime'] < $_G['timestamp'] && $setmeal['endtime'] > 0) {
    
    
    $freesetmeal = DB::fetch_first('select * from %t where id=1 order by id desc', array(
        'zimu_zhaopin_setmeal'
    ));
    
    $timestamp                         = time();
    $setsqlarr2['expire']              = $freesetmeal['is_free'] == 1 ? 1 : 0;
    $setsqlarr2['uid']                 = $_G['uid'];
    $setsqlarr2['setmeal_id']          = $freesetmeal['id'];
    $setsqlarr2['setmeal_name']        = $freesetmeal['setmeal_name'];
    $setsqlarr2['days']                = $freesetmeal['days'];
    $setsqlarr2['expense']             = $freesetmeal['expense'];
    $setsqlarr2['jobs_meanwhile']      = $freesetmeal['jobs_meanwhile'];
    $setsqlarr2['refresh_jobs_free']   = $freesetmeal['refresh_jobs_free'];
    $setsqlarr2['download_resume']     = $freesetmeal['download_resume'];
    $setsqlarr2['download_resume_max'] = $freesetmeal['download_resume_max'];
    $setsqlarr2['added']               = $freesetmeal['added'];
    $setsqlarr2['starttime']           = $_G['timestamp'];
    if ($freesetmeal['days'] > 0) {
        $setsqlarr2['endtime'] = strtotime("" . $freesetmeal['days'] . " days");
    } else {
        $setsqlarr2['endtime'] = "0";
    }
    
    $setsqlarr2['set_sms'] = $setmeal['set_sms'] + $freesetmeal['set_sms'];
    
    $setsqlarr2['show_apply_contact']         = $freesetmeal['show_apply_contact'];
    $setsqlarr2['is_free']                    = $freesetmeal['is_free'];
    $setsqlarr2['discount_download_resume']   = $freesetmeal['discount_download_resume'];
    $setsqlarr2['discount_sms']               = $freesetmeal['discount_sms'];
    $setsqlarr2['discount_stick']             = $freesetmeal['discount_stick'];
    $setsqlarr2['discount_emergency']         = $freesetmeal['discount_emergency'];
    $setsqlarr2['discount_auto_refresh_jobs'] = $freesetmeal['discount_auto_refresh_jobs'];
    

    DB::update('zimu_zhaopin_members_setmeal', $setsqlarr2, array(
        'uid' => $_G['uid']
    ));
    
    DB::update('zimu_zhaopin_company_profile', array(
        'setmeal_id' => $setsqlarr2['setmeal_id'],
        'setmeal_name' => $setsqlarr2['setmeal_name']
    ), array(
        'uid' => $_G['uid']
    ));


    DB::update('zimu_zhaopin_jobs', array(
        'setmeal_deadline' => $setsqlarr2['endtime'],
        'setmeal_id' => $setsqlarr2['setmeal_id'],
        'setmeal_name' => $setsqlarr2['setmeal_name']
    ), array(
        'uid' => $_G['uid']
    ));


    $setmeal = DB::fetch_first('select * from %t where uid = %d order by id desc', array(
        'zimu_zhaopin_members_setmeal',
        $_G['uid']
    ));
    
    
}

$total_jobs_apply = DB::result_first("SELECT count(*) FROM %t where company_uid=%d and is_reply=0", array(
    "zimu_zhaopin_personal_jobs_apply",
    $_G['uid']
));

$total_resume_down = DB::result_first("SELECT count(*) FROM %t where company_uid=%d", array(
    "zimu_zhaopin_company_down_resume",
    $_G['uid']
));

$total_resume_favorites = DB::result_first("SELECT count(*) FROM %t where company_uid=%d", array(
    "zimu_zhaopin_company_favorites",
    $_G['uid']
));

$count_viewlog = DB::result_first("SELECT count(*) FROM %t where uid=%d", array(
    "zimu_zhaopin_com_viewlog",
    $_G['uid']
));

$total_jobs_interview = DB::result_first("SELECT count(*) FROM %t where company_uid=%d", array(
    "zimu_zhaopin_company_interview",
    $_G['uid']
));

$utype = 1;
DB::query("update %t set utype=1 where uid=%d", array(
    'zimu_zhaopin_members',
    $_G['uid']
));

$is_jobs_audit = DB::result_first("SELECT id FROM %t where uid=%d and audit=3", array(
    "zimu_zhaopin_jobs",
    $_G['uid']
));

$is_hide_share_text = DB::result_first("SELECT id FROM %t where uid=%d and audit=1", array(
    "zimu_zhaopin_jobs",
    $_G['uid']
));

if($company_profile['kefu_uid']){
    $kefudata = DB::fetch_first('select * from %t where uid = %d order by id desc', array(
        'zimu_zhaopin_kefu',
        $company_profile['kefu_uid']
    ));
}

include zimu_template('mycompany');