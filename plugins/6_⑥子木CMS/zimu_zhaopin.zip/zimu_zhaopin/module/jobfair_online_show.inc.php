<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$op = addslashes($_GET['op']);
$op = $op ? $op : 'jobfairlist';

$ids = intval($_GET['ids']);

$needlogin = intval($_GET['needlogin']);
if ($needlogin == 1) {
    isuid(ZIMUCMS_URL . '&model=jobfair_online_show&ids=' . $ids);
}


if ($op == 'apply') {
    
    $note = zm_diconv(strip_tags($_GET['note']));
    
    !$_G['uid'] && ajaxReturn(0, $language_zimu['jobfair_online_show_inc_php_0']);
    
    $hasapply = DB::fetch_first('select * from %t where uid=%d and fid=%d order by id desc', array(
        'zimu_zhaopin_jobfair_online_com',
        $_G['uid'],
        $ids
    ));
    
    $hasapply && ajaxReturn(1, $language_zimu['jobfair_online_show_inc_php_1']);
    
    $hascom = DB::fetch_first('select * from %t where uid=%d order by id desc', array(
        'zimu_zhaopin_company_profile',
        $_G['uid']
    ));
    !$hascom && ajaxReturn(2, $language_zimu['jobfair_online_show_inc_php_2']);
    
    $apply_data['fid']      = $ids;
    $apply_data['uid']      = $_G['uid'];
    $apply_data['com_id']   = $hascom['id'];
    $apply_data['com_name'] = $hascom['companyname'];
    $apply_data['note']     = $note;
    $apply_data['addtime']  = $_G['timestamp'];
    DB::insert('zimu_zhaopin_jobfair_online_com', $apply_data);
    
    ajaxReturn(200, 'ok');
    
} else {
    
    $keyword = trim($_GET['keyword']);
    $keyword = dhtmlspecialchars($keyword);
    $keyword = stripsearchkey($keyword);
    $keyword = daddslashes($keyword);
    
    $jobfair = DB::fetch_first('select * from %t where id=%d order by id desc', array(
        'zimu_zhaopin_jobfair_online',
        $ids
    ));
    
    if (!$jobfair['bgcolor']) {
        $jobfair['bgcolor'] = '#0486fe';
    }
    
    
    $hasapply = DB::fetch_first('select * from %t where uid=%d and fid=%d order by id desc', array(
        'zimu_zhaopin_jobfair_online_com',
        $_G['uid'],
        $ids
    ));
    
    
    
    if (!empty($keyword)) {
        $wheresql  = " and ( `jobs_name` LIKE '%{$keyword}%' or `companyname` LIKE '%{$keyword}%' ) ";
        
        $lists2 = DB::fetch_all('select * from %t where fid=%d and status=1 order by zhiding desc,sort asc,addtime asc', array(
            'zimu_zhaopin_jobfair_online_com',
            $ids
        ));
        
        $allcoms = count($lists2);
        $alljobs = 0;
        
        foreach ($lists2 as $key => $value) {
            
            $lists2[$key]['jobs'] = DB::fetch_all('select * from %t where company_id=%d and audit != 3 and display!=2 %i order by id desc', array(
                'zimu_zhaopin_jobs',
                $value['com_id'],
                $wheresql
            ));

            $lists3[$key]['jobs']    = DB::fetch_all('select * from %t where company_id=%d and audit != 3 and display!=2 order by id desc', array(
                'zimu_zhaopin_jobs',
                $value['com_id']
            ));
            
            $alljobs = $alljobs + count($lists3[$key]['jobs']);

            if (count($lists2[$key]['jobs']) > 0) {

                $lists[$key]            = $value;
                $lists[$key]['profile'] = DB::fetch_first('select * from %t where id=%d order by id desc', array(
                    'zimu_zhaopin_company_profile',
                    $value['com_id']
                ));
                
                $lists[$key]['jobs'] = $lists3[$key]['jobs'];                
                
            }
            
        }

    } else {
        
        $lists = DB::fetch_all('select * from %t where fid=%d and status=1 order by zhiding desc,sort asc,addtime asc', array(
            'zimu_zhaopin_jobfair_online_com',
            $ids
        ));
        
        $allcoms = count($lists);
        $alljobs = 0;
        
        foreach ($lists as $key => $value) {
            
            $lists[$key]['profile'] = DB::fetch_first('select * from %t where id=%d order by id desc', array(
                'zimu_zhaopin_company_profile',
                $value['com_id']
            ));
            $lists[$key]['jobs']    = DB::fetch_all('select * from %t where company_id=%d and audit != 3 and display!=2 order by id desc', array(
                'zimu_zhaopin_jobs',
                $value['com_id']
            ));
            
            $alljobs = $alljobs + count($lists[$key]['jobs']);
            
        }
        
    }

    DB::query("update %t set views=views+1 where id=%d", array(
        'zimu_zhaopin_jobfair_online',
        $ids
    ));
    
    $navtitle    = $share_title = $jobfair['title'] ? $jobfair['title'] : $navtitle;
    $keywords    = $jobfair['summary'] ? $jobfair['summary'] : $navtitle;
    $description = $share_desc = cutstr($jobfair['summary'], 160);
    $share_url   = rtrim($_G['siteurl'], '/') . $_SERVER['REQUEST_URI'];
    
    if ($jobfair['thumb'] && !preg_match('/^(http|\.)/i', $jobfair['thumb'])) {
        $jobfair['thumb'] = $_G['siteurl'] . $jobfair['thumb'];
    }
    $share_thumb = $jobfair['thumb'] ? $jobfair['thumb'] : $share_thumb;
    
    
    include zimu_template('jobfair_online_show');
    
}