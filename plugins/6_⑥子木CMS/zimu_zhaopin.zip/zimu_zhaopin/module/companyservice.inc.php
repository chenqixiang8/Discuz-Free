<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

isuid();
$ac       = addslashes($_GET['ac']);
$tosubmit = intval($_GET['tosubmit']);

if (IN_WECHAT) {
    $openid = $_G['cookie']['zimu_zhaopin_openid'] ? $_G['cookie']['zimu_zhaopin_openid'] : '';
    if (!$openid) {
        $tools    = new JsApiPaySF();
        $opendata = $tools->GetFollowOpenid(get_url() . '&oauth=yes');
        if ($openid = $opendata['openid']) {
            dsetcookie('zimu_zhaopin_openid', $openid, 86400);
        }
    }
    if ($openid) {
        DB::query("update %t set openid=%s where uid=%d", array(
            'zimu_zhaopin_members',
            $openid,
            $_G['uid']
        ));
    }
}

$my_setmeal = DB::fetch_first('select * from %t where uid=%d order by id desc', array(
    'zimu_zhaopin_members_setmeal',
    $_G['uid']
));

$company_profile = DB::fetch_first('select * from %t where uid=%d order by id desc', array(
    'zimu_zhaopin_company_profile',
    $_G['uid']
));

if ($my_setmeal['endtime'] == 0) {
    $leave_days = $language_zimu['companyservice_inc_php_0'];
} else {
    $minus      = ($my_setmeal['endtime'] - time()) / 3600 / 24;
    $leave_days = intval($minus);
}

$rl = dreferer();

if ($ac == 'service_refresh_jobs_one') {
    
    $params['payment'] = addslashes($_GET['payment']);
    $jobs_id           = intval($_GET['jobs_id']);
    
    $params['oid']           = date('YmdHis') . mt_rand(100000, 999999);
    $params['zpid']          = $jobs_id;
    $params['uid']           = $_G['uid'];
    $params['openid']        = $openid;
    $params['utype']         = 1;
    $params['order_type']    = 13;
    $params['pay_type']      = 2;
    $params['is_paid']       = 1;
    $params['amount']        = $zmdata['settings']['refresh_jobs_price'];
    $params['pay_amount']    = $zmdata['settings']['refresh_jobs_price'];
    $params['payment']       = 'wxpay';
    $params['payment_cn']    = $language_zimu['companyservice_inc_php_1'];
    $params['description']   = $language_zimu['companyservice_inc_php_2'] . $language_zimu['companyservice_inc_php_3'] . $params['pay_amount'] . $zmdata['settings']['money_name'];
    $params['service_name']  = 'jobs_refresh';
    $params_array['jobs_id'] = $jobs_id;
    $params_array['type']    = 'jobs_refresh';
    $params['params']        = serialize($params_array);
    $params['addtime']       = $_G['timestamp'];
    $params['referer']       = $rl;
    
    $return_order_info = DB::insert('zimu_zhaopin_order', $params, 1);
    
    
    dheader('Location: ' . ZIMUCMS_URL . '&model=companyservice&ac=order_detail&order_id=' . $return_order_info);
    
} elseif ($ac == 'service_down_resume_one') {
    
    $resume_id = intval($_GET['resume_id']);
    
    $params['payment'] = addslashes($_GET['payment']);
    
    $params['oid']          = date('YmdHis') . mt_rand(100000, 999999);
    $params['zpid']         = $resume_id;
    $params['uid']          = $_G['uid'];
    $params['openid']       = $openid;
    $params['utype']        = 1;
    $params['order_type']   = 14;
    $params['pay_type']     = 2;
    $params['is_paid']      = 1;
    $params['amount']       = $zmdata['settings']['download_resume_price'];
    $params['pay_amount']   = $zmdata['settings']['download_resume_price'];
    $params['payment']      = 'wxpay';
    $params['payment_cn']   = $language_zimu['companyservice_inc_php_4'];
    $params['description']  = $language_zimu['companyservice_inc_php_5'];
    $params['service_name'] = 'resume_download';
    $params['addtime']      = $_G['timestamp'];
    $params['referer']      = $rl;
    
    $return_order_info = DB::insert('zimu_zhaopin_order', $params, 1);
    
    
    dheader('Location: ' . ZIMUCMS_URL . '&model=companyservice&ac=order_detail&order_id=' . $return_order_info);
    
    
    
} elseif ($ac == 'order_detail') {
    
    $order_id = intval($_GET['order_id']);
    
    $order           = DB::fetch_first('select * from %t where uid=%d and id=%d order by id desc', array(
        'zimu_zhaopin_order',
        $_G['uid'],
        $order_id
    ));
    $order['params'] = $order['params'] ? unserialize($order['params']) : array();
    
    $rl = $order['referer'] ? $order['referer'] : dreferer();
    
    if (IN_MAGAPP) {
        
        $mag_paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
            'zimu_zhaopin_parameter2',
            'magapp'
        ));
        $mag_paramter = unserialize($mag_paramter['parameter']);
        
    }
    
    if (IN_QFAPP) {
        
        $qf_paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
            'zimu_zhaopin_parameter2',
            'qfapp'
        ));
        $qf_paramter = unserialize($qf_paramter['parameter']);
        
    }
    
    if($company_profile['kefu_uid']){
        $kefudata = DB::fetch_first('select * from %t where uid = %d order by id desc', array(
            'zimu_zhaopin_kefu',
            $company_profile['kefu_uid']
        ));
    }

    $my_members = DB::fetch_first('select * from %t where uid=%d order by id desc', array(
        'zimu_zhaopin_members',
        $_G['uid']
    ));
        

} elseif ($ac == 'service_stick') {
    
    $jobs_id = I('jobs_id', 0, 'intval');
    
    if ($tosubmit == 1 && $_GET['md5hash'] == formhash()) {
        
        
        if (!$jobs_id) {
            ajaxReturn(0, $language_zimu['companyservice_inc_php_6']);
        }
        
        $promotion_field = DB::fetch_first('select * from %t where uid=%d and id=%d and audit!=3 order by id desc', array(
            'zimu_zhaopin_jobs',
            $_G['uid'],
            $jobs_id
        ));
        
        if ($promotion_field['stick'] == 1 && $promotion_field['stick_endtime'] > $_G['timestamp']) {
            ajaxReturn(0, $language_zimu['companyservice_inc_php_7']);
        }
        
        $service_id = I('service_id', 0, 'intval');
        if (!$service_id) {
            $service_id = I('project_id', 0, 'intval');
        }
        $service_info = DB::fetch_first('select * from %t where cat=%s and id=%d order by id desc', array(
            'zimu_zhaopin_setmeal_increment',
            'stick',
            $service_id
        ));
        
        if (!$service_info) {
            ajaxReturn(0, $language_zimu['companyservice_inc_php_8']);
        }
        
        $my_discount = $my_setmeal;
        
        $new_price = $my_discount['discount_stick'] > 0 ? round($service_info['price'] * $my_discount['discount_stick'] / 10, 2) : $service_info['price'];
        
        
        $params['oid']           = date('YmdHis') . mt_rand(100000, 999999);
        $params['zpid']          = $jobs_id;
        $params['uid']           = $_G['uid'];
        $params['openid']        = $openid;
        $params['utype']         = 1;
        $params['order_type']    = 8;
        $params['pay_type']      = 2;
        $params['is_paid']       = 1;
        $params['amount']        = $new_price;
        $params['pay_amount']    = $new_price;
        $params['payment']      = $_GET['payment_name'] == 'remittance' ? 'remittance' : 'wxpay';
        $params['payment_cn']   = $_GET['payment_name'] == 'remittance' ? $language_zimu['companyservice_inc_php_9'] : $language_zimu['companyservice_inc_php_10'];
        $params['description']   = $service_info['name'];
        $params['service_name']  = 'jobs_stick';
        $params_array            = array(
            'days' => $service_info['value']
        );
        $params_array['jobs_id'] = $jobs_id;
        $params['params']        = serialize($params_array);
        $params['addtime']       = $_G['timestamp'];
        
        $params['setmeal']  = $service_id;
        $params['discount'] = $language_zimu['companyservice_inc_php_11'] . $my_discount['discount_stick'] . $language_zimu['companyservice_inc_php_12'];
        $params['referer']  = $rl;
        
        $return_order_info = DB::insert('zimu_zhaopin_order', $params, 1);
        
        if (checkmobile()) {
            
            ajaxReturn(1, $language_zimu['companyservice_inc_php_13'], ZIMUCMS_URL . '&model=companyservice&ac=order_detail&order_id=' . $return_order_info);
            exit();
            
        } else {

            if($_GET['payment_name']=='remittance'){

                $data['qrurl']    = '333';
                $data['order_id'] = $return_order_info;
                ajaxReturn(1, $language_zimu['companyservice_inc_php_14'], $data);
                exit();

            }
                        
            $subject = $service_info['name'];
            $body    = diconv(cutstr(strip_tags($subject), 20), CHARSET, 'UTF-8');
            
            $tools  = new JsApiPaySF();
            $notify = new NativePaySF();
            $input  = new WxPayUnifiedOrderSF();
            $input->SetBody($body);
            $input->SetAttach($body);
            $input->SetOut_trade_no($params['oid']);
            $input->SetTotal_fee($new_price * 100);
            $input->SetTime_start(date('YmdHis'));
            $input->SetGoods_tag($body);
            $pburl = $_G['siteurl'];
            $input->SetNotify_url($pburl . 'source/plugin/zimu_zhaopin/lib/notify_wx.php');
            $input->SetTrade_type((IN_WECHAT ? 'JSAPI' : (checkmobile() ? 'MWEB' : 'NATIVE')));
            
            $input->SetProduct_id($params['oid']);
            $result = $notify->GetPayUrl($input);
            $url2   = $result['code_url'];
            if (!$url2) {
                $msg = diconv($result['return_msg'], 'utf-8');
                ajaxReturn(0, $msg);
                exit();
                
            } else {
                $data['qrurl']    = 'http://qr.liantu.com/api.php?&w=240&bg=ffffff&fg=333333&text=' . urlencode($url2);
                $data['order_id'] = $return_order_info;
                ajaxReturn(1, $language_zimu['companyservice_inc_php_15'], $data);
                exit();
                
            }
            
            
        }
        
        
        
        
        
        
        
        
    } else {
        
        $jobs_id             = I('jobs_id', 0, 'intval');
        $jobs_where['uid']   = $_G['uid'];
        $jobs_where['audit'] = 1;
        $jobs_arr            = DB::fetch_all('select * from %t where uid=%d and audit!=3 order by id desc', array(
            'zimu_zhaopin_jobs',
            $_G['uid']
        ));
        
        if ($jobs_id) {
            $jobs_info = DB::fetch_first('select * from %t where uid=%d and id=%d and audit!=3 order by id desc', array(
                'zimu_zhaopin_jobs',
                $_G['uid'],
                $jobs_id
            ));
            
            $jobs_buy = $jobs_info['stick'] && $jobs_info['stick_endtime'] > $_G['timestamp'] ? 1 : 0;
        } else {
            $jobs_buy = 0;
        }
        
        $increment_arr = DB::fetch_all('select * from %t where cat=%s order by sort asc,id desc', array(
            'zimu_zhaopin_setmeal_increment',
            'stick'
        ));
        
        $increment_arr[0]['my_price'] = $my_setmeal['discount_stick'] > 0 ? round($increment_arr[0]['price'] * $my_setmeal['discount_stick'] / 10, 2) : $increment_arr[0]['price'];
        
        
    }

} elseif ($ac == 'service_refresh') {
    
    $jobs_id = I('jobs_id', 0, 'intval');
    
    if ($tosubmit == 1 && $_GET['md5hash'] == formhash()) {
        
        
        if (!$jobs_id) {
            ajaxReturn(0, $language_zimu['companyservice_inc_php_16']);
        }
        
        $promotion_field = DB::fetch_first('select * from %t where uid=%d and id=%d and audit!=3 order by id desc', array(
            'zimu_zhaopin_jobs',
            $_G['uid'],
            $jobs_id
        ));

        $has_auto = DB::fetch_first('select * from %t where type=1 and pid=%d order by id desc', array(
            'zimu_zhaopin_queue_auto_refresh',
            $jobs_id
        ));

        if ($has_auto) {
            ajaxReturn(0, $language_zimu['companyservice_inc_php_17']);
        }
        
        $service_id = I('service_id', 0, 'intval');
        if (!$service_id) {
            $service_id = I('project_id', 0, 'intval');
        }
        $service_info = DB::fetch_first('select * from %t where cat=%s and id=%d order by id desc', array(
            'zimu_zhaopin_setmeal_increment',
            'auto_refresh_jobs',
            $service_id
        ));
        
        if (!$service_info) {
            ajaxReturn(0, $language_zimu['companyservice_inc_php_18']);
        }
        
        $my_discount = $my_setmeal;
        
        $new_price = $my_discount['discount_auto_refresh_jobs'] > 0 ? round($service_info['price'] * $my_discount['discount_auto_refresh_jobs'] / 10, 2) : $service_info['price'];
        
        
        $params['oid']           = date('YmdHis') . mt_rand(100000, 999999);
        $params['zpid']          = $jobs_id;
        $params['uid']           = $_G['uid'];
        $params['openid']        = $openid;
        $params['utype']         = 1;
        $params['order_type']    = 12;
        $params['pay_type']      = 2;
        $params['is_paid']       = 1;
        $params['amount']        = $new_price;
        $params['pay_amount']    = $new_price;
        $params['payment']       = 'wxpay';
        $params['payment_cn']    = $language_zimu['companyservice_inc_php_19'];
        $params['description']   = $service_info['name'];
        $params['service_name']  = 'jobs_auto_refresh';

        $params_array = array('days'=>$service_info['value']);
        $params_array['starttime'] = $_G['timestamp'];
        for ($i=0; $i < $service_info['value']*4; $i++) {
            $timespace = 3600*6*$i;
            if($i+1==$service_info['value']*4){
                $params_array['endtime'] = $params_array['starttime']+$timespace;
            }
        }
        $params_array['jobs_id'] = $jobs_id;
        
        $params['params']        = serialize($params_array);
        $params['addtime']       = $_G['timestamp'];
        
        $params['setmeal']  = $service_id;
        $params['discount'] = $language_zimu['companyservice_inc_php_20'] . $my_discount['discount_auto_refresh_jobs'] . $language_zimu['companyservice_inc_php_21'];
        $params['referer']  = $rl;
        
        $return_order_info = DB::insert('zimu_zhaopin_order', $params, 1);
        
        if (checkmobile()) {
            
            ajaxReturn(1, $language_zimu['companyservice_inc_php_22'], ZIMUCMS_URL . '&model=companyservice&ac=order_detail&order_id=' . $return_order_info);
            exit();
            
        } else {
            
            $subject = $service_info['name'];
            $body    = diconv(cutstr(strip_tags($subject), 20), CHARSET, 'UTF-8');
            
            $tools  = new JsApiPaySF();
            $notify = new NativePaySF();
            $input  = new WxPayUnifiedOrderSF();
            $input->SetBody($body);
            $input->SetAttach($body);
            $input->SetOut_trade_no($params['oid']);
            $input->SetTotal_fee($new_price * 100);
            $input->SetTime_start(date('YmdHis'));
            $input->SetGoods_tag($body);
            $pburl = $_G['siteurl'];
            $input->SetNotify_url($pburl . 'source/plugin/zimu_zhaopin/lib/notify_wx.php');
            $input->SetTrade_type((IN_WECHAT ? 'JSAPI' : (checkmobile() ? 'MWEB' : 'NATIVE')));
            
            $input->SetProduct_id($params['oid']);
            $result = $notify->GetPayUrl($input);
            $url2   = $result['code_url'];
            if (!$url2) {
                $msg = diconv($result['return_msg'], 'utf-8');
                ajaxReturn(0, $msg);
                exit();
                
            } else {
                $data['qrurl']    = 'http://qr.liantu.com/api.php?&w=240&bg=ffffff&fg=333333&text=' . urlencode($url2);
                $data['order_id'] = $return_order_info;
                ajaxReturn(1, $language_zimu['companyservice_inc_php_23'], $data);
                exit();
                
            }
            
            
        }
        
        
    } else {
        
        $jobs_id             = I('jobs_id', 0, 'intval');
        $jobs_where['uid']   = $_G['uid'];
        $jobs_where['audit'] = 1;
        $jobs_arr            = DB::fetch_all('select * from %t where uid=%d and audit!=3 order by id desc', array(
            'zimu_zhaopin_jobs',
            $_G['uid']
        ));
        foreach ($jobs_arr as $key => $value) {
            $has_auto = DB::fetch_first('select * from %t where type=1 and pid=%d order by id desc', array(
                'zimu_zhaopin_queue_auto_refresh',
                $value['id']
            ));
            $jobs_arr[$key]['auto_refresh'] = $has_auto?1:0;
        }
        if ($jobs_id) {
            $has_auto = DB::fetch_first('select * from %t where type=1 and pid=%d order by id desc', array(
                'zimu_zhaopin_queue_auto_refresh',
                $jobs_id
            ));
            $jobs_buy = $has_auto?1:0;
        } else {
            $jobs_buy = 0;
        }
        
        $increment_arr = DB::fetch_all('select * from %t where cat=%s order by sort asc,id desc', array(
            'zimu_zhaopin_setmeal_increment',
            'auto_refresh_jobs'
        ));
        
        $increment_arr[0]['my_price'] = $my_setmeal['discount_auto_refresh_jobs'] > 0 ? round($increment_arr[0]['price'] * $my_setmeal['discount_auto_refresh_jobs'] / 10, 2) : $increment_arr[0]['price'];
        
        
    }

} elseif ($ac == 'index') {
    
    $jobs_total = DB::result_first('select count(*) from %t where uid=%d and audit!=3 order by id desc', array(
        'zimu_zhaopin_jobs',
        $_G['uid']
    ));
    
    $my_setmeal['surplus_jobs'] = $my_setmeal['jobs_meanwhile'] - $jobs_total;
    
    $setmeal_list = DB::fetch_all('select * from %t where display=1 and apply=1 order by show_order desc,id desc', array(
        'zimu_zhaopin_setmeal'
    ));
    
    foreach ($setmeal_list as $key => $value) {
        $setmeal_list[$key]['discount'] = get_discount_for_setmeal_one($value);
    }
    
} elseif ($ac == 'setmeal_add_confirm') {
    
    $tip = $language_zimu['companyservice_inc_php_24'] . $my_setmeal['setmeal_name'] . $language_zimu['companyservice_inc_php_25'] . '<br /><span class="font_yellow">' . $language_zimu['companyservice_inc_php_26'] . '<br />' . $language_zimu['companyservice_inc_php_27'] . '</span><br />' . $language_zimu['companyservice_inc_php_28'];
    
    
    ajaxReturn(1, '', '<div class="dialog_notice nospace">' . $tip . '</div>');
    
} elseif ($ac == 'setmeal_add') {
    
    if (!$my_setmeal) {
        
        dheader('Location: ' . ZIMUCMS_URL . '&model=company&ac=com_info');
        
    }
    
    if ($tosubmit == 1 && $_GET['md5hash'] == formhash()) {
        
        $service_id = I('service_id', 0, 'intval');
        
        $service_info = DB::fetch_first('select * from %t where display=1 and apply=1 and id=%d order by id desc', array(
            'zimu_zhaopin_setmeal',
            $service_id
        ));
        
        if (!$service_info) {
            ajaxReturn(0, $language_zimu['companyservice_inc_php_29']);
        }
        
        $params['oid']          = date('YmdHis') . mt_rand(100000, 999999);
        $params['zpid']         = 888;
        $params['uid']          = $_G['uid'];
        $params['openid']       = $openid;
        $params['utype']        = 1;
        $params['order_type']   = 1;
        $params['pay_type']     = 2;
        $params['is_paid']      = 1;
        $params['amount']       = $service_info['expense'];
        $params['pay_amount']   = $service_info['expense'];
        $params['payment']      = $_GET['payment_name'] == 'remittance' ? 'remittance' : 'wxpay';
        $params['payment_cn']   = $_GET['payment_name'] == 'remittance' ? $language_zimu['companyservice_inc_php_30'] : $language_zimu['companyservice_inc_php_31'];
        $params['description']  = $service_info['setmeal_name'];
        $params['service_name'] = 'setmeal_add';
        $params['addtime']      = $_G['timestamp'];
        
        $params['setmeal'] = $service_id;
        $params['referer'] = $rl;
        
        $return_order_info = DB::insert('zimu_zhaopin_order', $params, 1);
        
        if (checkmobile()) {
            
            ajaxReturn(1, $language_zimu['companyservice_inc_php_32'], ZIMUCMS_URL . '&model=companyservice&ac=order_detail&order_id=' . $return_order_info);
            exit();
            
        } else {

            if($_GET['payment_name']=='remittance'){

                $data['qrurl']    = '333';
                $data['order_id'] = $return_order_info;
                ajaxReturn(1, $language_zimu['companyservice_inc_php_33'], $data);
                exit();

            }else{

            $subject = $service_info['setmeal_name'];
            $body    = diconv(cutstr(strip_tags($subject), 20), CHARSET, 'UTF-8');
            
            $tools  = new JsApiPaySF();
            $notify = new NativePaySF();
            $input  = new WxPayUnifiedOrderSF();
            $input->SetBody($body);
            $input->SetAttach($body);
            $input->SetOut_trade_no($params['oid']);
            $input->SetTotal_fee($service_info['expense'] * 100);
            $input->SetTime_start(date('YmdHis'));
            $input->SetGoods_tag($body);
            $pburl = $_G['siteurl'];
            $input->SetNotify_url($pburl . 'source/plugin/zimu_zhaopin/lib/notify_wx.php');
            $input->SetTrade_type((IN_WECHAT ? 'JSAPI' : (checkmobile() ? 'MWEB' : 'NATIVE')));
            
            $input->SetProduct_id($params['oid']);
            $result = $notify->GetPayUrl($input);
            $url2   = $result['code_url'];
            if (!$url2) {
                $msg = diconv($result['return_msg'], 'utf-8');
                ajaxReturn(0, $msg);
                exit();
                
            } else {
                $data['qrurl']    = 'http://qr.liantu.com/api.php?&w=240&bg=ffffff&fg=333333&text=' . urlencode($url2);
                $data['order_id'] = $return_order_info;
                ajaxReturn(1, $language_zimu['companyservice_inc_php_34'], $data);
                exit();
                
            }

            }
            
        }
        
        
    } else {
        
        $setmeal_list = DB::fetch_all('select * from %t where display=1 and apply=1 order by show_order desc,id desc', array(
            'zimu_zhaopin_setmeal'
        ));
        
        foreach ($setmeal_list as $key => $value) {
            $setmeal_list[$key]['discount'] = get_discount_for_setmeal_one($value);
        }
        
        $service_id = I('service_id', 1, 'intval');
        
        $setmeal_info = DB::fetch_first('select * from %t where display=1 and apply=1 and id=%d order by id desc', array(
            'zimu_zhaopin_setmeal',
            $service_id
        ));
        
        $setmeal_info['discount'] = get_discount_for_setmeal_one($setmeal_info);
        
        
    }
    
    
} elseif ($ac == 'check_weixinpay_notify') {
    
    $order_id = intval($_GET['order_id']);
    
    $order = DB::fetch_first('select * from %t where uid=%d and id=%d order by id desc', array(
        'zimu_zhaopin_order',
        $_G['uid'],
        $order_id
    ));
    
    if ($order['is_paid'] == 2) {
        
        ajaxReturn(1, $language_zimu['companyservice_inc_php_35'], ZIMUCMS_URL . '&model=companyservice&ac=order_detail&order_id=' . $order_id);
        
    } else {
        
        ajaxReturn(0, $language_zimu['companyservice_inc_php_36']);
        
    }
    
} elseif ($ac == 'order_list') {
    
    $type         = I('type', '', 'trim');
    $function_arr = array(
        'setmeal',
        'increment',
        'points'
    );
    
    switch ($type) {
        case 'setmeal':
            $wherearr[] = ' order_type = 1';
            break;
        case 'increment':
            $wherearr[] = ' (order_type = 6 or order_type = 7 or order_type = 8 or order_type = 9 or order_type = 10 or order_type = 11 or order_type = 12 or order_type = 13 or order_type = 14 )';
            break;
    }
    $is_paid = I('is_paid', 0, 'intval');
    if ($is_paid > 0) {
        $wherearr[] = ' is_paid = ' . $is_paid;
    }
    
    //$wherearr[] = " payment = 'wxpay' ";
    $wherearr[] = ' uid = ' . $_G['uid'];
    
    $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE ' . implode(' AND ', $wherearr) : '';
    
    
    $order = DB::fetch_all('select * from %t %i order by id desc', array(
        'zimu_zhaopin_order',
        $wheresql
    ));
    
} elseif ($ac == 'order_pay_repeat') {
    
    $order_id = intval($_GET['order_id']);
    
    $newoid = date('YmdHis') . mt_rand(100000, 999999);
    
    DB::query("update %t set oid=%s where id=%d", array(
        'zimu_zhaopin_order',
        $newoid,
        $order_id
    ));
    
    $order = DB::fetch_first('select * from %t where uid=%d and id=%d order by id desc', array(
        'zimu_zhaopin_order',
        $_G['uid'],
        $order_id
    ));
    
    $order['oid'] = $newoid;
    
    $subject = $order['description'];
    $body    = diconv(cutstr(strip_tags($subject), 20), CHARSET, 'UTF-8');
    
    $tools  = new JsApiPaySF();
    $notify = new NativePaySF();
    $input  = new WxPayUnifiedOrderSF();
    $input->SetBody($body);
    $input->SetAttach($body);
    $input->SetOut_trade_no($order['oid']);
    $input->SetTotal_fee($order['amount'] * 100);
    $input->SetTime_start(date('YmdHis'));
    $input->SetGoods_tag($body);
    $pburl = $_G['siteurl'];
    $input->SetNotify_url($pburl . 'source/plugin/zimu_zhaopin/lib/notify_wx.php');
    $input->SetTrade_type((IN_WECHAT ? 'JSAPI' : (checkmobile() ? 'MWEB' : 'NATIVE')));
    
    $input->SetProduct_id($order['oid']);
    $result = $notify->GetPayUrl($input);
    $url2   = $result['code_url'];
    if (!$url2) {
        $msg = diconv($result['err_code_des'], 'utf-8');
        ajaxReturn(0, $msg);
        exit();
        
    } else {
        $data['qrurl']    = 'http://qr.liantu.com/api.php?&w=240&bg=ffffff&fg=333333&text=' . urlencode($url2);
        $data['order_id'] = $order_id;
        ajaxReturn(1, $language_zimu['companyservice_inc_php_37'], $data);
        exit();
        
    }
    
} elseif ($ac == 'increment') {
    
    $download_resume_discount = DB::result_first('select discount_download_resume from %t where discount_download_resume>0 order by discount_download_resume asc', array(
        'zimu_zhaopin_setmeal'
    ));
    
    $stick_discount = DB::result_first('select discount_stick from %t where discount_stick>0 order by discount_stick asc', array(
        'zimu_zhaopin_setmeal'
    ));
    
} elseif ($ac == 'download_resume') {
    
    $vip_discount = DB::result_first('select discount_download_resume from %t where discount_download_resume>0 order by discount_download_resume asc', array(
        'zimu_zhaopin_setmeal'
    ));
    
    $increment_arr = DB::fetch_all('select * from %t where cat=%s order by sort desc,id asc', array(
        'zimu_zhaopin_setmeal_increment',
        'download_resume'
    ));
    
    $increment_arr[0]['my_price'] = $my_setmeal['discount_download_resume'] > 0 ? round($increment_arr[0]['price'] * $my_setmeal['discount_download_resume'] / 10, 2) : $increment_arr[0]['price'];
    
} elseif ($ac == 'confirm_pay_increment') {
    
    $setmeal_end_days = $language_zimu['companyservice_inc_php_38'];
    if ($my_setmeal['endtime'] == 0) {
        $tip = $language_zimu['companyservice_inc_php_39'] . $my_setmeal['setmeal_name'] . $language_zimu['companyservice_inc_php_40'] . $setmeal_end_days . $language_zimu['companyservice_inc_php_41'];
    } else {
        if ($my_setmeal['endtime'] > time()) {
            $sub_day          = sub_day($my_setmeal['endtime'], time());
            $sub_day          = preg_replace('/(\d+)/', '<span class="font_yellow">\1</span>', $sub_day);
            $setmeal_end_days = $sub_day . $language_zimu['companyservice_inc_php_42'];
        } else {
            $setmeal_end_days = $language_zimu['companyservice_inc_php_43'];
        }
        $tip = $language_zimu['companyservice_inc_php_44'] . $my_setmeal['setmeal_name'] . $language_zimu['companyservice_inc_php_45'] . date('Y-m-d', $my_setmeal['endtime']) . $language_zimu['companyservice_inc_php_46'];
    }
    
    ajaxReturn(1, $language_zimu['companyservice_inc_php_47'], $tip);

    
 } elseif ($ac == 'gold') {

    $my_members = DB::fetch_first('select * from %t where uid=%d order by id desc', array(
        'zimu_zhaopin_members',
        $_G['uid']
    ));

    $handsel = DB::fetch_all('select * from %t where uid=%d order by id desc', array(
        'zimu_zhaopin_members_handsel',
        $_G['uid']
    ));

 } elseif ($ac == 'gold_log') {

    $my_members = DB::fetch_first('select * from %t where uid=%d order by id desc', array(
        'zimu_zhaopin_members',
        $_G['uid']
    ));

    $operate = intval($_GET['operate']) ? intval($_GET['operate']) : 1;

    $handsel = DB::fetch_all('select * from %t where uid=%d and operate=%d order by id desc', array(
        'zimu_zhaopin_members_handsel',
        $_G['uid'],
        $operate
    ));

    $get_num = DB::result_first("SELECT sum(points) FROM %t where uid=%d and operate=1", array(
        "zimu_zhaopin_members_handsel",
        $_G['uid'],
        $operate
    ));
    $get_num = intval($get_num);

    $use_num = DB::result_first("SELECT sum(points) FROM %t where uid=%d and operate=2", array(
        "zimu_zhaopin_members_handsel",
        $_G['uid'],
        $operate
    ));
    $use_num = intval($use_num);


 } elseif ($ac == 'gold_add') {

      $my_members = DB::fetch_first('select * from %t where uid=%d order by id desc', array(
        'zimu_zhaopin_members',
        $_G['uid']
    ));  
    

        if ($tosubmit == 1 && $_GET['md5hash'] == formhash()) {
        
         $add_num = intval($_GET['add_num']);

        if (!$add_num) {
            ajaxReturn(0, $language_zimu['companyservice_inc_php_48']);
        }
        
        $params['oid']           = date('YmdHis') . mt_rand(100000, 999999);
        $params['zpid']          = 888;
        $params['uid']           = $_G['uid'];
        $params['openid']        = $openid;
        $params['utype']         = 1;
        $params['order_type']    = 2;
        $params['pay_type']      = 2;
        $params['is_paid']       = 1;
        $params['amount']        = $add_num/10;
        $params['pay_amount']    = $add_num/10;
        $params['payment']      = $_GET['payment_name'] == 'remittance' ? 'remittance' : 'wxpay';
        $params['payment_cn']   = $_GET['payment_name'] == 'remittance' ? $language_zimu['companyservice_inc_php_49'] : $language_zimu['companyservice_inc_php_50'];
        $params['description']   = $language_zimu['companyservice_inc_php_51'];
        $params['service_name']  = 'buy_points';
        $params_array            = array(
            'add_num' => $add_num
        );
        $params['params']        = serialize($params_array);
        $params['addtime']       = $_G['timestamp'];
        $params['referer']  = $rl;
        
        $return_order_info = DB::insert('zimu_zhaopin_order', $params, 1);
        
        if (checkmobile()) {
            
            ajaxReturn(1, $language_zimu['companyservice_inc_php_52'], ZIMUCMS_URL . '&model=companyservice&ac=order_detail&order_id=' . $return_order_info);
            exit();
            
        }
    }


} elseif ($ac == 'increment_add_save') {
    
    $service_type = addslashes($_GET['service_type']);
    $service_id   = I('project_id', 0, 'intval');
    
    if ($service_type == 'download_resume') {
        $order_type = 6;
    }
    $service_info = DB::fetch_first('select * from %t where cat=%s and id=%d order by id desc', array(
        'zimu_zhaopin_setmeal_increment',
        $service_type,
        $service_id
    ));
    
    if (!$service_info) {
        ajaxReturn(0, $language_zimu['companyservice_inc_php_53']);
    }
    
    $new_price = $my_setmeal['discount_' . $service_type] > 0 ? round($service_info['price'] * $my_setmeal['discount_' . $service_type] / 10, 2) : $service_info['price'];
    
    if (!$service_info) {
        ajaxReturn(0, $language_zimu['companyservice_inc_php_54']);
    }
    
    $params['oid']          = date('YmdHis') . mt_rand(100000, 999999);
    $params['zpid']         = 888;
    $params['uid']          = $_G['uid'];
    $params['openid']       = $openid;
    $params['utype']        = 1;
    $params['order_type']   = $order_type;
    $params['pay_type']     = 2;
    $params['is_paid']      = 1;
    $params['amount']       = $new_price;
    $params['pay_amount']   = $new_price;
    $params['payment']      = $_GET['payment_name'] == 'remittance' ? 'remittance' : 'wxpay';
    $params['payment_cn']   = $_GET['payment_name'] == 'remittance' ? $language_zimu['companyservice_inc_php_55'] : $language_zimu['companyservice_inc_php_56'];
    $params['description']  = $service_info['name'];
    $params['service_name'] = 'download_resume';
    $params['addtime']      = $_G['timestamp'];
    $params_array           = array(
        'nums' => $service_info['value']
    );
    $params['params']       = serialize($params_array);
    
    
    $params['setmeal']  = $service_id;
    $params['discount'] = $language_zimu['companyservice_inc_php_57'] . $my_setmeal['discount_' . $service_type] . $language_zimu['companyservice_inc_php_58'];
    $params['referer']  = $rl;
    
    $return_order_info = DB::insert('zimu_zhaopin_order', $params, 1);
    
    if (checkmobile()) {
        ajaxReturn(1, $language_zimu['companyservice_inc_php_59'], ZIMUCMS_URL . '&model=companyservice&ac=order_detail&order_id=' . $return_order_info);
        exit();
        
    } else {

        if($_GET['payment_name']=='remittance'){

            $data['qrurl']    = '333';
            $data['order_id'] = $return_order_info;
            ajaxReturn(1, $language_zimu['companyservice_inc_php_60'], $data);
            exit();
        }

        $subject = $service_info['name'];
        $body    = diconv(cutstr(strip_tags($subject), 20), CHARSET, 'UTF-8');
        
        $tools  = new JsApiPaySF();
        $notify = new NativePaySF();
        $input  = new WxPayUnifiedOrderSF();
        $input->SetBody($body);
        $input->SetAttach($body);
        $input->SetOut_trade_no($params['oid']);
        $input->SetTotal_fee($new_price * 100);
        $input->SetTime_start(date('YmdHis'));
        $input->SetGoods_tag($body);
        $pburl = $_G['siteurl'];
        $input->SetNotify_url($pburl . 'source/plugin/zimu_zhaopin/lib/notify_wx.php');
        $input->SetTrade_type((IN_WECHAT ? 'JSAPI' : (checkmobile() ? 'MWEB' : 'NATIVE')));
        
        $input->SetProduct_id($params['oid']);
        $result = $notify->GetPayUrl($input);
        $url2   = $result['code_url'];
        if (!$url2) {
            $msg = diconv($result['return_msg'], 'utf-8');
            ajaxReturn(0, $msg);
            exit();
            
        } else {
            $data['qrurl']    = 'http://qr.liantu.com/api.php?&w=240&bg=ffffff&fg=333333&text=' . urlencode($url2);
            $data['order_id'] = $return_order_info;
            ajaxReturn(1, $language_zimu['companyservice_inc_php_61'], $data);
            exit();
            
        }
        
        
    }
    
    
}



include zimu_template('companyservice_' . $ac);



function get_discount_for_setmeal_one($setmeal)
{
    $arr[0] = $setmeal['discount_download_resume'];
    $arr[1] = $setmeal['discount_stick'];
    //$arr[2] = $setmeal['discount_auto_refresh_jobs'];
    unset($arr[array_search(0, $arr)]);
    $pos    = array_search(min($arr), $arr);
    $return = $arr[$pos];
    return _format_discount($return);
}
function _format_discount($value)
{
    $value_arr = explode(".", $value);
    if ($value_arr[1] == 0) {
        return $value_arr[0];
    } else {
        return $value;
    }
}