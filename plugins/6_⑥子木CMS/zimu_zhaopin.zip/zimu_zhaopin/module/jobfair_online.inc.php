<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$op = addslashes($_GET['op']);
$op = $op ? $op : 'jobfairlist';



$newjobfair = DB::fetch_all('select * from %t order by id desc', array(
    'zimu_zhaopin_jobfair_online'
));


$navtitle = $zmdata['settings']['jobfair_online_seo_title'] ? $zmdata['settings']['jobfair_online_seo_title'] : $navtitle;
$keywords = $zmdata['settings']['jobfair_online_seo_keyword'] ? $zmdata['settings']['jobfair_online_seo_keyword'] : $navtitle;
$description = $zmdata['settings']['jobfair_online_seo_desc'] ? $zmdata['settings']['jobfair_online_seo_desc'] : $navtitle;

include zimu_template('jobfair_online');