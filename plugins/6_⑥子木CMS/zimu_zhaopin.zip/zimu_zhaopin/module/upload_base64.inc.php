<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$ac = addslashes($_GET['ac']);

    
    $config_params = savepic('haibao');
    $data          = array(
        'path' => $config_params['show_path'],
        'img' => $config_params['save_path']
    );

    ajaxReturn(1, $language_zimu['upload_base64_inc_php_0'], $data);
    


function savepic($type){
    global $_G;

    $config_params = array(
        'upload_ok' => false,
        'save_path' => '',
        'show_path' => ''
    );
    $filename      = uniqid() . '.jpg';
    $uid           = $_G['uid'];

if (preg_match('/^(data:\s*image\/(\w+);base64,)/',$_GET['img_base64'],$result)){


    $pic           = base64_decode(str_replace($result[1],'',$_GET['img_base64']));

    $date        = date('ym/d/');
    $save_avatar = DISCUZ_ROOT . './source/plugin/zimu_zhaopin/uploadzimucms/' . $type . '/' . $date;

    if (!is_dir($save_avatar)) {
        mkdir($save_avatar, 0777, true);
    }

    file_put_contents($save_avatar . $filename, $pic);

    $oss_paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
        'zimu_zhaopin_parameter2',
        'alioss'
    ));
    $oss_paramter = unserialize($oss_paramter['parameter']);

    if($oss_paramter['ACCESS_ID'] && $oss_paramter['ACCESS_KEY'] && $oss_paramter['ENDPOINT'] && $oss_paramter['BUCKET']){
        $saved_file = DISCUZ_ROOT.'/source/plugin/zimu_zhaopin/uploadzimucms/' . $type . '/' . $date . $filename;
        include_once DISCUZ_ROOT.'source/plugin/zimu_zhaopin/lib/OSS/Common.php';
        if ($surl = zm_oss_upload('zimu_zhaopin/'. $type . '/' . $date . $filename, $saved_file)) {
            @unlink($saved_file);
        $imgurl = $surl;
        $config_params['save_path'] = $imgurl;
        $config_params['show_path'] = $imgurl;
        $config_params['upload_ok'] = true;
        return $config_params;
        exit();
        }
    }

    $config_params['save_path'] = '/source/plugin/zimu_zhaopin/uploadzimucms/' . $type . '/' . $date . $filename;
    $config_params['show_path'] = $_G['siteurl'] . 'source/plugin/zimu_zhaopin/uploadzimucms/' . $type . '/' . $date . $filename;
    ;
    $config_params['upload_ok'] = true;
    return $config_params;
}   
}