<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}


$md5hash = addslashes($_GET['md5hash']);
$click_ids = addslashes($_GET['click_ids']);
$click_type = addslashes($_GET['click_type']);

if($click_ids && $md5hash = $formhash){


        if(strpos($click_ids, ',')!==false){
            $click_ids = dintval(array_filter(explode(',', $click_ids)), true);
            return DB::query("update %t set click=click+1 WHERE id IN (%n)", array('zimu_zhaopin_'.$click_type, $click_ids));
        }else{
            return DB::query("update %t set click=click+1 WHERE id=%d", array('zimu_zhaopin_'.$click_type, $click_ids));
        }



}