<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$cid = intval($_GET['cid']);

$companydata = DB::fetch_first('select * from %t where id=%d order by id asc', array(
        'zimu_zhaopin_company_profile',
        $cid
    ));

$companyjob = DB::fetch_all('select * from %t where company_id=%d '.$noauditwheresql2.' order by id asc', array(
        'zimu_zhaopin_jobs',
        $cid
    ));

$utype = DB::result_first('select utype from %t where uid=%d order by id desc', array(
        'zimu_zhaopin_members',
        $_G['uid']
    ));

$isfav = DB::fetch_first('select * from %t where uid=%d and company_id=%d order by id desc', array(
	'zimu_zhaopin_personal_focus_company',
	$_G['uid'],
	$cid
));

$isresume = DB::fetch_first('select * from %t where uid=%d '.$noauditwheresql2.' order by id desc', array(
    'zimu_zhaopin_resume',
    $_G['uid']
));

$isapply= DB::fetch_first('select * from %t where personal_uid=%d and company_id=%d order by did desc', array(
    'zimu_zhaopin_personal_jobs_apply',
    $_G['uid'],
    $cid
));


if(!$isresume || ($zmdata['settings']['resume_tocomtel'] && $isresume['audit']!=1) ){

$companydata['telephone'] = substr_replace($companydata['telephone'],'****',3,4);
$companydata['landline_tel'] = substr_replace($companydata['landline_tel'],'****',5,4);

}

$manage_uids = str_replace(';', ',', $zmdata['manage_uids']);
$manage_uids = explode(',', $manage_uids);

$audit_tip1 = explode("\r\n", trim($zmdata['settings']['audit_tip1']));
$audit_tip2 = explode("\r\n", trim($zmdata['settings']['audit_tip2']));


$navtitle = $companydata['companyname'].'_'.$zmdata['base']['title'];
$keywords = $companydata['companyname'].','.$zmdata['base']['title'];
$description = cutstr($companydata['contents'],100,'...');

$share_title = $companydata['companyname'].'_'.$zmdata['base']['title'];
$share_desc = $zmdata['base']['share_desc'];
$share_url = rtrim($_G['siteurl'], '/').$_SERVER['REQUEST_URI'];
if ($companydata['logo'] && !preg_match('/^(http|\.)/i', $companydata['logo'])) {
   $companydata['logo'] = $_G['siteurl'].$companydata['logo'];
}
$share_thumb = $companydata['logo'] ? $companydata['logo'] : $_G['siteurl'].$zmdata['base']['share_thumb']; 

include zimu_template('viewcom');