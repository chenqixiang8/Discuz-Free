<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

isuid();

$ac       = addslashes($_GET['ac']);
$tosubmit = intval($_GET['tosubmit']);


$order_id = intval($_GET['order_id']);
$pay_amount = round($_GET['pay_amount'],2);

$payment       = addslashes($_GET['payment']);

$deductible_val = intval($_GET['deductible_val']);

$order = DB::fetch_first('select * from %t where uid=%d and id=%d order by id desc', array(
        'zimu_zhaopin_order',
        $_G['uid'],
        $order_id
    ));
$order['params'] = $order['params']?unserialize($order['params']):array();

	$subject = $order['description'];
	$body=diconv(cutstr(strip_tags($subject),20),CHARSET,'UTF-8');


if($ac=='wap_remittance'){

    DB::query("update %t set payment=%s,payment_cn=%s,pay_points=%d,pay_amount=%s where id=%d and uid=%d", array(
        'zimu_zhaopin_order',
        'remittance',
        $language_zimu['pay_inc_php_0'],
        $deductible_val,
        $pay_amount,
        $order_id,
        $_G['uid']
    ));

$company_profile = DB::fetch_first('select * from %t where uid=%d order by id desc', array(
    'zimu_zhaopin_company_profile',
    $_G['uid']
));

if($company_profile['kefu_uid']){
    $kefudata = DB::fetch_first('select * from %t where uid = %d order by id desc', array(
        'zimu_zhaopin_kefu',
        $company_profile['kefu_uid']
    ));
}

$wap_remittance['tip_text'] = $zmdata['settings']['offline_pay'] ? $zmdata['settings']['offline_pay'] : $language_zimu['pay_inc_php_1'];
$wap_remittance['kefu_qrcode_url'] = $kefudata['kefu_qrcode_url'] ? $kefudata['kefu_qrcode_url'] : $zmdata['settings']['kefu_qrcode_url'];
ajaxReturn(200,'ok',$wap_remittance);

}else{

if(IN_MAGAPP){

$mag_paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
    'zimu_zhaopin_parameter2',
    'magapp'
));
$mag_paramter = unserialize($mag_paramter['parameter']);

			$call_back=$_G['siteurl'].'source/plugin/zimu_zhaopin/lib/notify_magapp.php?trade_no='.$order['oid'].'&userid='.$_G['uid'];

			$mag_parameter=array('trade_no'=>$order['oid'],'callback'=>$call_back,'amount'=>$pay_amount,'title'=>$body,'user_id'=>$_G['uid'],'des'=>$body,'remark'=>$body,'secret'=>$mag_paramter['magapp_secret']);

			$mag_url = $mag_paramter['magapp_hostname'].'/core/pay/pay/unifiedOrder?'.http_build_query($mag_parameter);
            
            $mag_ret = json_decode(lizimu_post($mag_url,''),true);

			if ($mag_ret) {
				if ($unionOrderNum = $mag_ret['data']['unionOrderNum']) {

    DB::query("update %t set payment=%s,payment_cn=%s,order_sn=%s,pay_points=%d,pay_amount=%s where id=%d and uid=%d", array(
        'zimu_zhaopin_order',
        'magapp',
        $language_zimu['pay_inc_php_2'].'APP'.$language_zimu['pay_inc_php_3'],
        $mag_ret['data']['unionOrderNum'],
        $deductible_val,
        $pay_amount,
        $order_id,
        $_G['uid']
    ));
				}

$order = DB::fetch_first('select * from %t where uid=%d and id=%d order by id desc', array(
        'zimu_zhaopin_order',
        $_G['uid'],
        $order_id
    ));

                ajaxReturn(1,$order);

			}else{
				ajaxReturn(0,$mag_ret["msg"]);
			}


}

if(IN_QFAPP){

$qfoid = addslashes($_GET['qfoid']);

    DB::query("update %t set payment=%s,payment_cn=%s,order_sn=%s,pay_points=%d,pay_amount=%s where id=%d and uid=%d", array(
        'zimu_zhaopin_order',
        'qfapp',
        $language_zimu['pay_inc_php_4'].'APP'.$language_zimu['pay_inc_php_5'],
        $qfoid,
        $deductible_val,
        $pay_amount,
        $order_id,
        $_G['uid']
    ));

$order = DB::fetch_first('select * from %t where uid=%d and id=%d order by id desc', array(
        'zimu_zhaopin_order',
        $_G['uid'],
        $order_id
    ));

    ajaxReturn(1,$order);


}


if(IN_WECHAT){

if($pay_amount==0){

if($deductible_val){
    DB::query("update %t set pay_points=%d,pay_amount=%s where id=%d and uid=%d", array(
        'zimu_zhaopin_order',
        $deductible_val,
        $pay_amount,
        $order_id,
        $_G['uid']
    ));
}

finish_order($order, '0', '0', 'WECAHT');

$data['nomoney_url'] = $order['referer'];
ajaxReturn(1,$language_zimu['pay_inc_php_6'],$data);

}else{


    if($deductible_val){
        DB::query("update %t set pay_points=%d,pay_amount=%s where id=%d and uid=%d", array(
            'zimu_zhaopin_order',
            $deductible_val,
            $pay_amount,
            $order_id,
            $_G['uid']
        ));
    }

			$tools=new JsApiPaySF();
			$notify=new NativePaySF();
			$input=new WxPayUnifiedOrderSF();
			$input->SetBody($body);
			$input->SetAttach($body);
			$input->SetOut_trade_no($order['oid']);
			$input->SetTotal_fee($pay_amount*100);
			$input->SetTime_start(date('YmdHis'));
			$input->SetGoods_tag($body);
			$pburl=$_G['siteurl'];
			$input->SetNotify_url($pburl.'source/plugin/zimu_zhaopin/lib/notify_wx.php');
			$input->SetTrade_type((IN_WECHAT ? 'JSAPI' : (checkmobile() ? 'MWEB' : 'NATIVE')));

				$openid=$_G['cookie']['zimu_zhaopin_openid'];
				$input->SetOpenid($openid);
				$order2=WxPayApiSF::unifiedOrder($input);
				$jsApiParameters=$tools->GetJsApiParameters($order2);
				if ($order2['prepay_id']=='') {
					$jsApiParameters=json_encode(array('error'=>$openid.' error'));
				}
				echo $jsApiParameters;
				exit();
}

}


if (checkmobile() && !IN_WECHAT && $payment=='wxpay'){

if($pay_amount==0){

if($deductible_val){
    DB::query("update %t set pay_points=%d,pay_amount=%s where id=%d and uid=%d", array(
        'zimu_zhaopin_order',
        $deductible_val,
        $pay_amount,
        $order_id,
        $_G['uid']
    ));
}

finish_order($order, '0', '0', 'WECAHT');

$data['nomoney_url'] = $order['referer'];
ajaxReturn(1,$language_zimu['pay_inc_php_7'],$data);

}else{


    if($deductible_val){
        DB::query("update %t set pay_points=%d,pay_amount=%s where id=%d and uid=%d", array(
            'zimu_zhaopin_order',
            $deductible_val,
            $pay_amount,
            $order_id,
            $_G['uid']
        ));
    }

            $tools=new JsApiPaySF();
            $notify=new NativePaySF();
            $input=new WxPayUnifiedOrderSF();
            $input->SetBody($body);
            $input->SetAttach($body);
            $input->SetOut_trade_no($order['oid']);
            $input->SetTotal_fee($pay_amount*100);
            $input->SetTime_start(date('YmdHis'));
            $input->SetGoods_tag($body);
            $pburl=$_G['siteurl'];
            $input->SetNotify_url($pburl.'source/plugin/zimu_zhaopin/lib/notify_wx.php');
            $input->SetTrade_type((IN_WECHAT ? 'JSAPI' : (checkmobile() ? 'MWEB' : 'NATIVE')));

            $input->SetProduct_id($order_id);
            $input->values['spbill_create_ip']=get_real_clientip();
            $result=WxPayApiSF::unifiedOrder($input);
            if ($result['return_code']=='SUCCESS' && $result['result_code']=='SUCCESS') {
                $data['mweb_url']=$result['mweb_url'].'&redirect_url='.urlencode($order['referer']);
            }else {
                $data['error']=$result['return_msg'].'('.$result['return_code'].')';
            }
            echo json_encode($data);
            exit();

}

}


if (checkmobile() && $payment=='alipay'){


    DB::query("update %t set payment=%s,payment_cn=%s where id=%d and uid=%d", array(
        'zimu_zhaopin_order',
        'alipay',
        $language_zimu['pay_inc_php_8'],
        $order_id,
        $_G['uid']
    ));


if($pay_amount==0){

if($deductible_val){
    DB::query("update %t set pay_points=%d,pay_amount=%s where id=%d and uid=%d", array(
        'zimu_zhaopin_order',
        $deductible_val,
        $pay_amount,
        $order_id,
        $_G['uid']
    ));
}

finish_order($order, '0', '0', 'WECAHT');

$data['nomoney_url'] = $order['referer'];
ajaxReturn(1,$language_zimu['pay_inc_php_9'],$data);

}else{


    if($deductible_val){
        DB::query("update %t set pay_points=%d,pay_amount=%s where id=%d and uid=%d", array(
            'zimu_zhaopin_order',
            $deductible_val,
            $pay_amount,
            $order_id,
            $_G['uid']
        ));
    }


include_once(DISCUZ_ROOT.'source/plugin/zimu_zhaopin/lib/alipay_m/alipay.php');

}

}


}