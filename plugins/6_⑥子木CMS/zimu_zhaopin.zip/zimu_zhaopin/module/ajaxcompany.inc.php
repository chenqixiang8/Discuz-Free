<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

isuid();

$ac       = addslashes($_GET['ac']);
$tosubmit = intval($_GET['tosubmit']);


if($ac == 'resume_favor' ){

$rid = intval($_GET['rid']);

        !$rid && ajaxReturn(0,$language_zimu['ajaxcompany_inc_php_0']);
        $has = DB::fetch_first('select * from %t where company_uid=%d and resume_id=%d order by did desc', array(
                'zimu_zhaopin_company_favorites',
                $_G['uid'],
                $rid
            ));

        if($has){

            DB::delete('zimu_zhaopin_company_favorites', array(
                'company_uid' => $_G['uid'],
                'resume_id' => $rid
            ));

        ajaxReturn(1,$language_zimu['ajaxcompany_inc_php_1'],'has');

        }else{

        $data['company_uid']       = $_G['uid'];
        $data['resume_id']        = $rid;
        $data['favorites_addtime']     = $_G['timestamp'];

        DB::insert('zimu_zhaopin_company_favorites', $data);

            ajaxReturn(1,$language_zimu['ajaxcompany_inc_php_2']);
        }

}elseif($ac == 'resume_down_confirm' ){

        $rid = I('rid',0,'intval');
        if(!$rid){
            ajaxReturn(0,$language_zimu['ajaxcompany_inc_php_3']);
        }

        $company_profile = DB::fetch_first('select * from %t where uid=%d order by id desc', array(
            'zimu_zhaopin_company_profile',
            $_G['uid']
        ));

        if(!$company_profile){
if (!checkmobile()){
            ajaxReturn(1,ZIMUCMS_URL.'&model=company&ac=com_info','tocom_info');
}else{
            ajaxReturn(2,ZIMUCMS_URL.'&model=company&ac=com_info');
}
        }


        if($zmdata['settings']['com_down_resume_audit'] && $company_profile['audit'] !=1 ){
            ajaxReturn(1,$language_zimu['ajaxcompany_inc_php_4'].'<br>'.$language_zimu['ajaxcompany_inc_php_5'].'<br><img style="width:200px;" src="'.$zmdata['settings']['kefu_qrcode_url'].'">','no');
        }

        $my_setmeal = DB::fetch_first('select * from %t where uid=%d order by id desc', array(
            'zimu_zhaopin_members_setmeal',
            $_G['uid']
        ));

        $tip = '';
        $mode = '';

        $isdown = DB::result_first("SELECT did FROM %t where company_uid=%d and resume_id=%d", array(
            "zimu_zhaopin_company_down_resume",
            $_G['uid'],
            $rid
        ));

        $downnum = DB::result_first("SELECT count(*) FROM %t where company_uid=%d and down_addtime>%d", array(
            "zimu_zhaopin_company_down_resume",
            $_G['uid'],
            strtotime(date('Y-m-d', $_G['timestamp']))
        ));

        if($isdown>=1){
            ajaxReturn(3,$language_zimu['ajaxcompany_inc_php_6']);
        }
        if($my_setmeal['download_resume_max'] > 0){
            if($downnum >= $my_setmeal['download_resume_max']){

                if($zmdata['settings']['resume_download_quick'] == 1){
                $tip = '<div class="dialog_notice">'.$language_zimu['ajaxcompany_inc_php_7'].' <span class="font_yellow">'.$downnum.'</span> '.$language_zimu['ajaxcompany_inc_php_8'].'<br><a href="'.ZIMUCMS_URL.'&model=companyservice&ac=service_down_resume_one&payment=wxpay&resume_id='.$rid.'" class="qs-btn qs-btn-medium qs-btn-green mt2 pay-type" data-type="wxpay">'.$zmdata['settings']['download_resume_price'].$zmdata['settings']['money_name'].$language_zimu['ajaxcompany_inc_php_9'].'</a></div>';
                }else{
                $tip = '<div class="dialog_notice">'.$language_zimu['ajaxcompany_inc_php_10'].' <span class="font_yellow">'.$downnum.'</span> '.$language_zimu['ajaxcompany_inc_php_11'].'</div>';
                }
                $mode = 'mix2';
                ajaxReturn(1,$tip,$mode);
            }
        }

        if ($my_setmeal['download_resume']<=0){

            if($zmdata['settings']['resume_download_quick'] == 1){

                $tip = '<p class="font_yellow">'.$language_zimu['ajaxcompany_inc_php_12'].'<strong> '.$zmdata['settings']['download_resume_price'].'<strong> '.$zmdata['settings']['money_name'].'</p>
<a href="'.ZIMUCMS_URL.'&model=companyservice&ac=service_down_resume_one&payment=wxpay&resume_id='.$rid.'" class="qs-btn qs-btn-medium qs-btn-green mt2 pay-type" data-type="wxpay">'.$language_zimu['ajaxcompany_inc_php_13'].'</a>';
                $mode = 'mix2';

            }else{

                $tip = $language_zimu['ajaxcompany_inc_php_14'];
                $mode = 'mix2';

            }
        }else{

            $tip = '<div class="dialog_notice">'.$language_zimu['ajaxcompany_inc_php_15'].' <span>'.$my_setmeal['download_resume'].'</span> '.$language_zimu['ajaxcompany_inc_php_16'].'</div>';
            $mode = 'setmeal';
        }

        ajaxReturn(1,$tip,$mode);

}elseif($ac == 'resume_down' ){

        $rid = I('rid',0,'intval');
        if(!$rid){
            ajaxReturn(0,$language_zimu['ajaxcompany_inc_php_17']);
        }

        $setsqlarr2['resume_id'] = $rid;
        $setsqlarr2['company_uid'] = $_G['uid'];
        $setsqlarr2['down_addtime'] = $_G['timestamp'];

        DB::insert('zimu_zhaopin_company_down_resume', $setsqlarr2, 1);

    DB::query("update %t set download_resume=download_resume-1 where uid=%d", array(
        'zimu_zhaopin_members_setmeal',
        $_G['uid'],
    ));

        ajaxReturn(1,$language_zimu['ajaxcompany_inc_php_18']);


}