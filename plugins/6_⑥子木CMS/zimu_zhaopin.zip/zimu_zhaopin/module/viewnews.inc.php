<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}


$nid = intval($_GET['nid']);

$catdata = DB::fetch_all('select * from %t order by id asc', array(
	'zimu_zhaopin_news_cat'
));

$newsdata = DB::fetch_first('select * from %t where id=%d order by id desc', array(
    'zimu_zhaopin_news',
    $nid
));


DB::query("update %t set views=views+1 where id=%d", array(
    'zimu_zhaopin_news',
    $nid
));

$randnews = DB::fetch_all('select * from %t order by rand(20)', array(
    'zimu_zhaopin_news'
));

$navtitle = $share_title = $newsdata['title'] ? $newsdata['title'] : $navtitle;
$keywords = $newsdata['keyword'] ? $newsdata['keyword'] : $navtitle;
$description = $share_desc = $newsdata['description'] ? $newsdata['description'] : $navtitle;

include zimu_template('news_con');