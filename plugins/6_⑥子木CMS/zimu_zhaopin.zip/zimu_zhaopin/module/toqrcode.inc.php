<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$url = addslashes($_GET['url']);

$errorCorrectionLevel = 'L';
$matrixPointSize = 5;
require_once DISCUZ_ROOT.'source/plugin/zimu_zhaopin/class/qrcode.class.php';
$QR = QRcode::png($url,false,$errorCorrectionLevel, $matrixPointSize, 2);