<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(!$_G['uid']){

include zimu_template('register');

}else{

if($utype == 1){

dheader('Location:' . ZIMUCMS_URL);

}else{

dheader('Location:' . ZIMUCMS_URL);

}

}