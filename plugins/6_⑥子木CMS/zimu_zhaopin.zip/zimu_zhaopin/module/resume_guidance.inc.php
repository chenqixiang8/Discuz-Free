<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/zimu_zhaopin/module/creatmember.inc.php';

$tosubmit = intval($_GET['tosubmit']);

        if (IN_WECHAT) {
            $openid= $_G['cookie']['zimu_zhaopin_openid'] ? $_G['cookie']['zimu_zhaopin_openid'] : '';
            if (!$openid){
                $tools=new JsApiPaySF();
                $opendata=$tools->GetFollowOpenid(get_url().'&oauth=yes');
                if ($openid=$opendata['openid']) {
                    dsetcookie('zimu_zhaopin_openid',$openid,86400);
                }
            }
            if($openid){
                DB::query("update %t set openid=%s where uid=%d", array(
                    'zimu_zhaopin_members',
                    $openid,
                    $_G['uid'],
                ));
            }
        }


$resume_info = DB::fetch_first('select * from %t where uid=%d order by id asc', array(
        'zimu_zhaopin_resume',
        $_G['uid']
    ));

$pid = $resume_info['id'];

$category_jobs = DB::fetch_all('select * from %t order by c_order asc,c_id asc', array(
        'zimu_zhaopin_category'
    ));

foreach ($category_jobs as $key => $value) {

$category_jobs2[$value['c_alias']][$value['c_id']] = $value['c_name'];

}

$educationlist = $category_jobs2['ZM_education'];

if($tosubmit == 1 && $_GET['md5hash'] == formhash() ){


}else{
    
include zimu_template('resume_guidance');

}