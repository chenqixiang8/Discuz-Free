<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$cates = array();


    $citys = DB::fetch_all('select id,parentid,name from %t order by sort asc,id asc', array(
        'zimu_zhaopin_area'
    ));

    foreach ($citys as $key => $value) {
        
        $citys2[$value['parentid']][$value['id']] = $value['name'];

    }

    $cates['ZM_city'] = $citys2;

    $category_jobs = DB::fetch_all('select * from %t order by c_order asc,c_id asc', array(
        'zimu_zhaopin_category'
    ));
    
    foreach ($category_jobs as $key => $value) {
        
        $category_jobs2[$value['c_alias']][$value['c_id']] = $value['c_name'];
        
    }

        $jobs = array();
        $jobsData = DB::fetch_all('select id,parentid,categoryname from %t order by category_order asc,id asc', array(
        'zimu_zhaopin_category_jobs'
    ));
        foreach ($jobsData as $key => $val) {
            $jobs[$val['parentid']][$val['id']] = $val['categoryname'];
        }


$cates['ZM_jobs'] = $jobs;
$cates['ZM_trade'] = $category_jobs2['ZM_trade'];

            $content = '';
            foreach ($cates as $key => $cate) {
                $content.= "var {$key}_parent=new Array(".assembly($cate[0]).");";
                $content.="var {$key}=new Array();";
                foreach ($cate[0] as $_key=>$val) {
                    $content.="{$key}[{$_key}]=".assembly($cate[$_key],'`','').";";
                    if($key == 'ZM_jobs' && $cate[$_key]){
                        foreach ($cate[$_key] as $skey=>$sval) {
                            $content.="{$key}[{$skey}]=".assembly($cate[$skey],'`','').";";
                        }
                    }

                    if($key == 'ZM_city' && $cate[$_key]){
                        foreach ($cate[$_key] as $skey=>$sval) {
                            $content.="{$key}[{$skey}]=".assembly($cate[$skey],'`','').";";
                            if($cate[$skey]){
                                foreach ($cate[$skey] as $skey4=>$sval4) {
                                    $content.="{$key}[{$skey4}]=".assembly($cate[$skey4],'`','').";";
                                    if($cate[$skey4]){
                                        foreach ($cate[$skey4] as $skey5=>$sval5) {
                                            $content.="{$key}[{$skey5}]=".assembly($cate[$skey5],'`','').";";
                                            if($cate[$skey5]){
                                                foreach ($cate[$skey5] as $skey6=>$sval6) {
                                                    $content.="{$key}[{$skey6}]=".assembly($cate[$skey6],'`','').";";
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                }
            }

            foreach ($category_jobs2 as $key => $val) {
                $arr = array();
                foreach ($val as $_key=>$_val) {
                    $arr[] = '"'.$_key.','.$_val.'"';
                }
                $arr = implode(',',$arr);
                $content.="var {$key}=new Array({$arr});";
            }

$path = DISCUZ_ROOT . './source/plugin/zimu_zhaopin/static/wap/js/categorycache.js';
$content = diconv($content,$_G['charset'],'UTF-8');
file_put_contents($path,$content);
echo 'ok';