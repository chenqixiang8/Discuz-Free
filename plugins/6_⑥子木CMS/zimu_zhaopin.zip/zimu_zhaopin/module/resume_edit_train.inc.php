<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$tosubmit = intval($_GET['tosubmit']);
$wid = intval($_GET['wid']);

if($tosubmit == 1 && $_GET['md5hash'] == formhash() ){

$pid = intval($_GET['pid']);

            $uid = $_G['uid'];

            $setsqlarr['uid'] = $uid;
            $setsqlarr['agency'] = I('agency','','trim');
            $setsqlarr['course'] = I('course','','trim');
            $setsqlarr['description'] = I('description','','trim');
            $setsqlarr['startyear'] = I('startyear',0,'intval');
            $setsqlarr['startmonth'] = I('startmonth',0,'intval');
            $setsqlarr['endyear'] = I('endyear',0,'intval');
            $setsqlarr['endmonth'] = I('endmonth',0,'intval');
            $setsqlarr['todate'] = I('todate',0,'intval');

            if ($setsqlarr['todate'] == 1) {
                if(!$setsqlarr['startyear'] || !$setsqlarr['startmonth']) ajaxReturn(0,$language_zimu['resume_edit_train_inc_php_0']);
                if($setsqlarr['startyear'] > intval(date('Y'))) ajaxReturn(0,$language_zimu['resume_edit_train_inc_php_1']);
                if($setsqlarr['startyear'] == intval(date('Y')) && $setsqlarr['startmonth'] >= intval(date('m'))) ajaxReturn(0,$language_zimu['resume_edit_train_inc_php_2']);
            } else {
                if(!$setsqlarr['startyear'] || !$setsqlarr['startmonth'] || !$setsqlarr['endyear'] || !$setsqlarr['endmonth']) ajaxReturn(0,$language_zimu['resume_edit_train_inc_php_3']);
                if($setsqlarr['startyear'] > intval(date('Y'))) ajaxReturn(0,$language_zimu['resume_edit_train_inc_php_4']);
                if($setsqlarr['startyear'] == intval(date('Y')) && $setsqlarr['startmonth'] >= intval(date('m'))) ajaxReturn(0,$language_zimu['resume_edit_train_inc_php_5']);
                if($setsqlarr['endyear'] > intval(date('Y'))) ajaxReturn(0,$language_zimu['resume_edit_train_inc_php_6']);
                if($setsqlarr['endyear'] == intval(date('Y')) && $setsqlarr['endmonth'] > intval(date('m'))) ajaxReturn(0,$language_zimu['resume_edit_train_inc_php_7']);
                if($setsqlarr['startyear'] > $setsqlarr['endyear']) ajaxReturn(0,$language_zimu['resume_edit_train_inc_php_8']);
                if($setsqlarr['startyear'] == $setsqlarr['endyear'] && $setsqlarr['startmonth'] >= $setsqlarr['endmonth']) ajaxReturn(0,$language_zimu['resume_edit_train_inc_php_9']);
            }

            if(!$pid) ajaxReturn(0,$language_zimu['resume_edit_train_inc_php_10']);
            $setsqlarr['pid'] = $pid;

            $training = DB::fetch_all('select * from %t where uid=%d and pid=%d order by id asc', array(
                'zimu_zhaopin_resume_training',
                $_G['uid'],
                $pid
            ));

            if(count($training)>=6) $this->ajaxReturn(0,$language_zimu['resume_edit_train_inc_php_11']);
            if($wid){
                $setsqlarr['id'] = $wid;

            $result = DB::update('zimu_zhaopin_resume_training', $setsqlarr, array(
                'id' => $wid,
                'uid' => $uid,
                'pid' => $pid,
            ));

            ajaxReturn(1,$language_zimu['resume_edit_train_inc_php_12'],array('url'=>ZIMUCMS_URL.'&model=resume_replenish&rid='.$pid));
            exit();

            }else{

            $result = DB::insert('zimu_zhaopin_resume_training', $setsqlarr, 1);

            ajaxReturn(1,$language_zimu['resume_edit_train_inc_php_13'],array('url'=>ZIMUCMS_URL.'&model=resume_replenish&rid='.$pid));
            exit();


            }


}else{

$pid = intval($_GET['rid']);

$info = DB::fetch_first('select * from %t where uid=%d and id=%d and pid=%d order by id asc', array(
        'zimu_zhaopin_resume_training',
        $_G['uid'],
        $wid,
        $pid
    ));

include zimu_template('resume_edit_train');

}