<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$url = addslashes($_GET['url']);

if ($url && !preg_match('/^(http|\.)/i', $url)) {
   $url = $_G['siteurl'].$url;
}

$img = file_get_contents($url,true);
header("Content-Type: image/jpeg;text/html; charset=utf-8");
echo $img;
exit();