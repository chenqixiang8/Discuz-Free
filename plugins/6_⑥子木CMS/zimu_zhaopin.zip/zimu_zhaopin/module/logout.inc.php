<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}


require_once libfile('function/misc');
require_once libfile('function/member');
loaducenter();

uc_user_synlogout();

clearcookies();

$_G['groupid'] = $_G['member']['groupid'] = 7;
$_G['uid'] = $_G['member']['uid'] = 0;
$_G['username'] = $_G['member']['username'] = $_G['member']['password'] = '';

dheader('Location:' . ZIMUCMS_URL);
