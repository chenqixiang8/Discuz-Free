<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(submitcheck('submit')) {

        $paramters = $_GET['options'];

        $isadd = DB::fetch_first('select * from %t where name=%s order by id desc', array(
            'zimu_zhaopin_parameter2',
            'alioss'
        ));

        if ($isadd['id'] > 0) {

        DB::query("update %t set parameter=%s where id=%d", array(
            'zimu_zhaopin_parameter2',
            serialize($paramters),
            $isadd['id']
        ));
            
        } else {

        $adddata = array(
                'name'=>'alioss',
                'parameter'=>serialize($paramters),
        );

            DB::insert('zimu_zhaopin_parameter2', $adddata);
            
        }
        
        
        include template('zimu_zhaopin:common/success');
        


}else{


        $paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
            'zimu_zhaopin_parameter2',
            'alioss'
        ));
        
        $paramters = unserialize($paramter['parameter']);

include zimu_template('admins/admins_'.$type,'');


}