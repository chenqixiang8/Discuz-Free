<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$op = addslashes($_GET['op']);
$op = $op ? $op : 'list';

if ($op == 'edit') {
    

    if (submitcheck('submit')) {

        $data['title']        = strip_tags($_GET['title']);
        $data['cid']         = intval($_GET['cid']);
        if ($data['cid']) {
            $data['catname'] = DB::result_first('select name from %t where id=%d', array(
                'zimu_zhaopin_news_cat',
                $data['cid'],
            ));
        }
        $data['keyword']        = strip_tags($_GET['keyword']);
        $data['description']        = strip_tags($_GET['description']);
        if ($_FILES['thumb']['tmp_name']) {
            $data['thumb'] = zm_saveimages($_FILES['thumb']);
        }
        $data['tag']        = strip_tags($_GET['tag']);
        $data['author']        = strip_tags($_GET['author']);
        $data['views']         = intval($_GET['views']);
        $data['addtime'] = strtotime($_GET['addtime']);
        $data['con']    = dhtmlspecialchars($_GET['con']);
        $data['toutiao']         = intval($_GET['toutiao']);
        $data['id']      = intval($_GET['ids']);
        
        
        
        if ($data['id'] > 0) {

        DB::update('zimu_zhaopin_news', $data, array(
            'id' => $data['id']
        ));
            
        } else {
            
            $result = DB::insert('zimu_zhaopin_news', $data, 1);
            
        }
        
        
        include template('zimu_zhaopin:common/success');
        
        
    } else {

        $catdata = DB::fetch_all('select * from %t order by id asc', array(
            'zimu_zhaopin_news_cat'
        ));
        
        $ids = intval($_GET['ids']);
        
        $listdata = DB::fetch_first('select * from %t where id=%d', array(
            'zimu_zhaopin_news',
            $ids
        ));

        include zimu_template('admins/admins_' . $type,'');
        
    }
    
    
} else if ($op == 'del' && $_GET['md5hash'] == formhash()) {
    
    $ids = intval($_GET['ids']);
    
    $result = DB::delete('zimu_zhaopin_news', array(
        'id' => $ids
    ));
    
    include template('zimu_zhaopin:common/success');

} else {
    
    $wheresql = 'where 1=1 ';

    $cid = intval($_GET['cid']);
    if (!empty($cid)) {
        $wheresql .= " and cid = ".$cid;
    }

    $catdata = DB::fetch_all('select * from %t order by id asc', array(
        'zimu_zhaopin_news_cat'
    ));

    $pindex = max(1, intval($_GET['page']));
    $psize  = 30;
    
    $total = DB::result_first("SELECT count(*) FROM %t %i", array(
        "zimu_zhaopin_news",
        $wheresql
    ));

    $listdata = DB::fetch_all('select * from %t %i order by id desc limit %d,%d', array(
        'zimu_zhaopin_news',
        $wheresql,
        ($pindex - 1) * $psize,
        $psize
    ));
    
    $pager = pagination($total, $pindex, $psize);
    
    
    include zimu_template('admins/admins_' . $type,'');
    
    
}