<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$op = addslashes($_GET['op']);
$op = $op ? $op : 'list';

if ($op == 'edit') {

    if (submitcheck('submit')) {

        $data['uid']         = intval($_GET['uid']);

        $data['kefu_name']         = strip_tags($_GET['kefu_name']);
        $data['kefu_mobile']         = strip_tags($_GET['kefu_mobile']);
        $data['kefu_tel']         = strip_tags($_GET['kefu_tel']);
        $data['kefu_wxid']         = strip_tags($_GET['kefu_wxid']);
        if ($_FILES['kefu_qrcode_url']['tmp_name']) {
            $data['kefu_qrcode_url'] = zm_saveimages($_FILES['kefu_qrcode_url']);
        }

        $data['id']      = intval($_GET['ids']);

        if ($data['id'] > 0) {

            DB::update('zimu_zhaopin_kefu', $data, array(
                'id' => $data['id']
            ));
            
        } else {
            
            $result = DB::insert('zimu_zhaopin_kefu', $data, 1);
            
        }
        
        
        include template('zimu_zhaopin:common/success');
        
        
    } else {
        
        $ids = intval($_GET['ids']);
        
        $listdata = DB::fetch_first('select * from %t where id=%d', array(
            'zimu_zhaopin_kefu',
            $ids
        ));

        include zimu_template('admins/admins_' . $type,'');
        
    }
    
    
} else if ($op == 'del' && $_GET['md5hash'] == formhash()) {
    
    $ids = intval($_GET['ids']);
    
    $result = DB::delete('zimu_zhaopin_kefu', array(
        'id' => $ids
    ));
    
    include template('zimu_zhaopin:common/success');

} else {
    
    $wheresql = 'where 1=1 ';
            
    $pindex = max(1, intval($_GET['page']));
    $psize  = 30;
    
    $total = DB::result_first("SELECT count(*) FROM %t %i", array(
        "zimu_zhaopin_kefu",
        $wheresql
    ));

    $total2 = DB::result_first("SELECT count(*) FROM %t %i", array(
        "zimu_zhaopin_kefu",
        "where 1=1"
    ));

    $listdata = DB::fetch_all('select * from %t %i order by id desc limit %d,%d', array(
        'zimu_zhaopin_kefu',
        $wheresql,
        ($pindex - 1) * $psize,
        $psize
    ));
    
    $pager = pagination($total, $pindex, $psize);
    
    include zimu_template('admins/admins_' . $type,'');
    
    
}