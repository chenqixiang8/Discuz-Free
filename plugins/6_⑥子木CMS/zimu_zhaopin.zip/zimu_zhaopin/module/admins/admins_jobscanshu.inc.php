<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$op = addslashes($_GET['op']);
$op = $op ? $op : 'list';
$name = addslashes($_GET['name']);
$name = $name ? $name : 'trade';

$parentid = intval($_GET['parentid']);

if($op == 'list'){

if(submitcheck('submit')) {


		if (!empty($_GET['ids'])) {
			foreach ($_GET['ids'] as $k => $v) {

if($v){
		$data = array('categoryname' => trim($_GET['categoryname'][$k]), 'category_order' => intval($_GET['category_order'][$k]));

            DB::update('zimu_zhaopin_category_jobs', $data, array(
                'parentid' => $parentid,
                'id' => $v
            ));

}elseif(trim($_GET['categoryname'][$k])){

        $data = array('parentid' => $parentid,'categoryname' => trim($_GET['categoryname'][$k]), 'category_order' => intval($_GET['category_order'][$k]));

        DB::insert('zimu_zhaopin_category_jobs', $data);

}

}
		}

        include template('zimu_zhaopin:common/success');

}else{

$top_lists = DB::fetch_all('select * from %t where parentid=0 order by category_order asc,id asc', array(
        'zimu_zhaopin_category_jobs'
    ));

$lists = DB::fetch_all('select * from %t where parentid=%d order by category_order asc,id asc', array(
        'zimu_zhaopin_category_jobs',
        $parentid
    ));

include zimu_template('admins/admins_'.$type,'');

}


}


if ($op == 'del' && $_GET['md5hash'] == formhash() ) {
	$ids = intval($_GET['ids']);

    $result = DB::delete('zimu_zhaopin_category_jobs', array(
        'id' => $ids
    ));

    include template('zimu_zhaopin:common/success');

}