<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
    

    include zimu_template('admins/admins_' . $type,'');