<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$op = addslashes($_GET['op']);
$op = $op ? $op : 'list';
$name = addslashes($_GET['name']);
$name = $name ? $name : 'trade';

if($op == 'list'){

if(submitcheck('submit')) {


        if (!empty($_GET['ids'])) {
            foreach ($_GET['ids'] as $k => $v) {

                if ($v) {
                    $data = array('name' => trim($_GET['c_name'][$k]));

                    DB::update('zimu_zhaopin_news_cat', $data, array(
                        'id' => $v,
                    ));

                } elseif (trim($_GET['c_name'][$k])) {

                    $data = array('name' => trim($_GET['c_name'][$k]));

                    DB::insert('zimu_zhaopin_news_cat', $data);

                }

            }
        }


        include template('zimu_zhaopin:common/success');

}else{

$lists = DB::fetch_all('select * from %t order by id asc', array(
        'zimu_zhaopin_news_cat'
    ));

include zimu_template('admins/admins_'.$type,'');

}


}


if ($op == 'post') {

if(submitcheck('submit')) {

        $data['name'] = strip_tags($_GET['name']);
        $data['sort'] = intval($_GET['sort']);

        DB::insert('zimu_zhaopin_area', $data);

        include template('zimu_zhaopin:common/success');

}else{

include zimu_template('admins/admins_'.$type,'');

}

}


if ($op == 'del' && $_GET['md5hash'] == formhash() ) {

	$ids = intval($_GET['ids']);

    $result = DB::delete('zimu_zhaopin_news_cat', array(
        'id' => $ids
    ));

    include template('zimu_zhaopin:common/success');

}