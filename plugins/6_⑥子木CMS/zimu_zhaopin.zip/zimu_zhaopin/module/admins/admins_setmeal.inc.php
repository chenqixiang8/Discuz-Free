<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$op = addslashes($_GET['op']);
$op = $op ? $op : 'list';

if ($op == 'edit') {

$category_jobs = DB::fetch_all('select * from %t order by c_order asc,c_id asc', array(
        'zimu_zhaopin_category'
    ));

foreach ($category_jobs as $key => $value) {

$category_jobs2[$value['c_alias']][$value['c_id']] = $value['c_name'];

}


    if (submitcheck('submit')) {

  
        $data['setmeal_name']        = strip_tags($_GET['setmeal_name']);
        if ($_FILES['setmeal_img']['tmp_name']) {
            $data['setmeal_img'] = zm_saveimages($_FILES['setmeal_img']);
        }
        $data['days']        = intval($_GET['days']);
        $data['expense']         = intval($_GET['expense']);
        $data['jobs_meanwhile']        = intval($_GET['jobs_meanwhile']);
        $data['refresh_jobs_free']        = intval($_GET['refresh_jobs_free']);
        $data['download_resume']        = intval($_GET['download_resume']);
        $data['download_resume_max']        = intval($_GET['download_resume_max']);
        $data['discount_download_resume']        = strip_tags($_GET['discount_download_resume']);
        $data['discount_stick']        = strip_tags($_GET['discount_stick']);
        $data['apply']        = intval($_GET['apply']);
        $data['added']        = strip_tags($_GET['added']);
        $data['show_order']        = intval($_GET['show_order']);
        $data['id']      = intval($_GET['ids']);
        
        
        
        if ($data['id'] > 0) {

            DB::update('zimu_zhaopin_setmeal', $data, array(
                'id' => $data['id']
            ));
            
        } else {
            
            $result = DB::insert('zimu_zhaopin_setmeal', $data, 1);
            
        }
        
        
        include template('zimu_zhaopin:common/success');
        
        
    } else {
        
        $ids = intval($_GET['ids']);
        
        $listdata = DB::fetch_first('select * from %t where id=%d', array(
            'zimu_zhaopin_setmeal',
            $ids
        ));

        include zimu_template('admins/admins_' . $type,'');
        
    }
    
    
} else if ($op == 'del' && $_GET['md5hash'] == formhash()) {
    
    $ids = intval($_GET['ids']);
    
    $result = DB::delete('zimu_zhaopin_setmeal', array(
        'id' => $ids
    ));
    
    include template('zimu_zhaopin:common/success');


} else {
    
    $wheresql = 'where 1=1 ';
    
    $pindex = max(1, intval($_GET['page']));
    $psize  = 100;
    
    $listdata = DB::fetch_all('select * from %t %i order by id asc limit %d,%d', array(
        'zimu_zhaopin_setmeal',
        $wheresql,
        ($pindex - 1) * $psize,
        $psize
    ));
    
    $pager = pagination($total, $pindex, $psize);
    
    
    include zimu_template('admins/admins_' . $type,'');
    
    
}