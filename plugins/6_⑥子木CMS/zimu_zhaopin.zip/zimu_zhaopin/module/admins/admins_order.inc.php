<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$op = addslashes($_GET['op']);
$op = $op ? $op : 'list';

if ($op == 'edit') {

    if (submitcheck('submit')) {

        $data['uid']        = strip_tags($_GET['uid']);
        $data['fullname']        = strip_tags($_GET['fullname']);
        $data['audit']         = intval($_GET['audit']);
        $data['addtime'] = strtotime($_GET['addtime']);
        $data['refreshtime'] = strtotime($_GET['refreshtime']);
        $data['sex']         = intval($_GET['sex']);
        $data['sex_cn']         = strip_tags($_GET['sex_cn']);
        $data['birthdate']         = intval($_GET['birthdate']);
        if($data['birthdate']){
            $data['age'] = date('Y')-$data['birthdate'];
        }
        $data['education']         = intval($_GET['education']);
        $data['education_cn']         = strip_tags($_GET['education_cn']);
        $data['experience']         = intval($_GET['experience']);
        $data['experience_cn']         = strip_tags($_GET['experience_cn']);
        $data['telephone']         = strip_tags($_GET['telephone']);
        $data['current']         = intval($_GET['current']);
        $data['current_cn']         = strip_tags($_GET['current_cn']);
        $data['nature']         = intval($_GET['nature']);
        $data['nature_cn']         = strip_tags($_GET['nature_cn']);
        $data['wage']         = intval($_GET['wage']);
        $data['wage_cn']         = strip_tags($_GET['wage_cn']);
        $data['specialty']        = strip_tags($_GET['specialty']);

        if ($_FILES['photo_img']['tmp_name']) {
            $data['photo_img'] = zm_saveimages($_FILES['photo_img']);
        }

        
        $stick_endtime = strtotime($_GET['stick_endtime']);
        if($stick_endtime > $_G['timestamp']){
        $data['stick'] = 1;
        $data['stick_endtime'] = strtotime($_GET['stick_endtime']);
        }
        $data['strong_tag'] = strip_tags($_GET['strong_tag']);
        if(strtotime($_GET['strong_tag_endtime']) > $_G['timestamp']){
        $data['strong_tag_endtime'] = strtotime($_GET['strong_tag_endtime']);
        }
        
        $data['id']      = intval($_GET['ids']);
        
        
        
        if ($data['id'] > 0) {

            DB::update('zimu_zhaopin_resume', $data, array(
                'id' => $data['id']
            ));
            
        } else {
            
            $result = DB::insert('zimu_zhaopin_resume', $data, 1);
            
        }
        
        
        include template('zimu_zhaopin:common/success');
        
        
    } else {
        
        $ids = intval($_GET['ids']);
        
        $listdata = DB::fetch_first('select * from %t where id=%d', array(
            'zimu_zhaopin_resume',
            $ids
        ));

        include zimu_template('admins/admins_' . $type,'');
        
    }
    
    
} else if ($op == 'del' && $_GET['md5hash'] == formhash()) {
    
    $ids = intval($_GET['ids']);
    
    $result = DB::delete('zimu_zhaopin_resume', array(
        'id' => $ids
    ));
    
    include template('zimu_zhaopin:common/success');

} else if ($op == 'remittance_true') {

    $ids = intval($_GET['ids']);

    $notes = addslashes($_GET['input']);

    DB::query("update %t set notes=%s where id=%d", array(
        'zimu_zhaopin_order',
        $notes,
        $ids
    ));

    $order = DB::fetch_first('select * from %t where id=%d order by id desc', array(
        'zimu_zhaopin_order',
        $ids
    ));
    $order['params'] = $order['params']?unserialize($order['params']):array();
    
    if($order && $order['is_paid'] == 1) {
        finish_order($order, $order['order_sn'], $order['amount'], 'WECAHT');
    }

    ajaxReturn(1,$order);


} else {
    
    $service_name = addslashes($_GET['service_name']);

    $wheresql = 'where 1=1 ';

    if (!empty($service_name)) {
        if($service_name=='download_resume'){
        $wheresql .= " and (service_name = '".$service_name."' or service_name = 'resume_download') ";
        }else{
        $wheresql .= " and service_name = '".$service_name."' ";
        }
    }

    $is_paid = intval($_GET['is_paid']);
    if (!empty($is_paid)) {
        $wheresql .= " and is_paid = ".$is_paid;
    }

    $time_start2 = strtotime($_GET['time_start']);
    $time_end2 = strtotime($_GET['time_end']);
    if (!empty($time_start2) && !empty($time_end2)) {
        $wheresql .= " and addtime >= ".$time_start2." and addtime <= ".$time_end2;
    }



    $keyword = intval($_GET['keyword']);
    if (!empty($keyword)) {
        $wheresql .= " and uid = ".$keyword;
    }

    $pindex = max(1, intval($_GET['page']));
    $psize  = 20;
    
    $total = DB::result_first("SELECT count(*) FROM %t %i", array(
        "zimu_zhaopin_order",
        $wheresql
    ));
    
    $allmoney = DB::result_first("SELECT sum(pay_amount) FROM %t %i", array(
        "zimu_zhaopin_order",
        $wheresql
    ));

    $listdata = DB::fetch_all('select * from %t %i order by id desc limit %d,%d', array(
        'zimu_zhaopin_order',
        $wheresql,
        ($pindex - 1) * $psize,
        $psize
    ));
    
    $pager = pagination($total, $pindex, $psize);
    
    
    include zimu_template('admins/admins_' . $type,'');
    
    
}