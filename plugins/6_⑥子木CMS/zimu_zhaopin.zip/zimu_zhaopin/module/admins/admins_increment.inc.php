<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$op = addslashes($_GET['op']);
$op = $op ? $op : 'list';

if ($op == 'edit') {

$category_jobs = DB::fetch_all('select * from %t order by c_order asc,c_id asc', array(
        'zimu_zhaopin_category'
    ));

foreach ($category_jobs as $key => $value) {

$category_jobs2[$value['c_alias']][$value['c_id']] = $value['c_name'];

}


    if (submitcheck('submit')) {

  
        $data['cat']        = strip_tags($_GET['cat']);
        $data['name']        = strip_tags($_GET['name']);
        $data['value']         = intval($_GET['value']);
        $data['price']        = strip_tags($_GET['price']);
        $data['sort']        = intval($_GET['sort']);
        $data['id']      = intval($_GET['ids']);
        
        
        
        if ($data['id'] > 0) {

            DB::update('zimu_zhaopin_setmeal_increment', $data, array(
                'id' => $data['id']
            ));
            
        } else {
            
            $result = DB::insert('zimu_zhaopin_setmeal_increment', $data, 1);
            
        }
        
        
        include template('zimu_zhaopin:common/success');
        
        
    } else {
        
        $ids = intval($_GET['ids']);
        
        $listdata = DB::fetch_first('select * from %t where id=%d', array(
            'zimu_zhaopin_setmeal_increment',
            $ids
        ));

        include zimu_template('admins/admins_' . $type,'');
        
    }
    
    
} else if ($op == 'del' && $_GET['md5hash'] == formhash()) {
    
    $ids = intval($_GET['ids']);
    
    $result = DB::delete('zimu_zhaopin_setmeal_increment', array(
        'id' => $ids
    ));
    
    include template('zimu_zhaopin:common/success');


} else {
    
    $wheresql = 'where 1=1 ';
    
    $pindex = max(1, intval($_GET['page']));
    $psize  = 100;
    
    $listdata = DB::fetch_all('select * from %t %i order by id asc limit %d,%d', array(
        'zimu_zhaopin_setmeal_increment',
        $wheresql,
        ($pindex - 1) * $psize,
        $psize
    ));
    
    $pager = pagination($total, $pindex, $psize);
    
    
    include zimu_template('admins/admins_' . $type,'');
    
    
}