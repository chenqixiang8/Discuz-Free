<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$op = addslashes($_GET['op']);
$op = $op ? $op : 'list';

$parentid = intval($_GET['parentid']);


if($op == 'list'){

if(submitcheck('submit')) {


		if (!empty($_GET['ids'])) {
			foreach ($_GET['ids'] as $k => $v) {

if($v){

		$data = array('name' => trim($_GET['name'][$k]), 'sort' => intval($_GET['sort'][$k]));

            DB::update('zimu_zhaopin_area', $data, array(
                'id' => $v
            ));

}elseif(trim($_GET['name'][$k])){

        $data = array('parentid' => $parentid,'name' => trim($_GET['name'][$k]), 'sort' => intval($_GET['sort'][$k]));

        DB::insert('zimu_zhaopin_area', $data);

}

			}
		}

        include template('zimu_zhaopin:common/success');

}else{


$top_lists = DB::fetch_all('select * from %t where parentid=0 order by sort asc,id asc', array(
        'zimu_zhaopin_area'
    ));

$lists = DB::fetch_all('select * from %t where parentid=%d order by sort asc,id asc', array(
        'zimu_zhaopin_area',
        $parentid
    ));

include zimu_template('admins/admins_'.$type,'');

}


}


if ($op == 'post') {

if(submitcheck('submit')) {

        $data['name'] = strip_tags($_GET['name']);
        $data['sort'] = intval($_GET['sort']);

        DB::insert('zimu_zhaopin_area', $data);

        include template('zimu_zhaopin:common/success');

}else{

include zimu_template('admins/admins_'.$type,'');

}

}


if ($op == 'del' && $_GET['md5hash'] == formhash() ) {
	$ids = intval($_GET['ids']);

    $result = DB::delete('zimu_zhaopin_area', array(
        'id' => $ids
    ));

    include template('zimu_zhaopin:common/success');

}