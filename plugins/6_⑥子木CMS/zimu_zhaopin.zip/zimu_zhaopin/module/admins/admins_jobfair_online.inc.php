<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$op = addslashes($_GET['op']);
$op = $op ? $op : 'jobfairlist';

if ($op == 'editjobfair') {

if(submitcheck('submit')) {

        $data['title']        = strip_tags($_GET['title']);
        $data['starttime'] = strtotime($_GET['starttime']);
        $data['endtime'] = strtotime($_GET['endtime']);
        $data['contact']        = strip_tags($_GET['contact']);
        $data['tel']        = strip_tags($_GET['tel']);
        if ($_FILES['thumb']['tmp_name']) {
            $data['thumb'] = zm_saveimages($_FILES['thumb']);
        }
        if ($_FILES['poster']['tmp_name']) {
            $data['poster'] = zm_saveimages($_FILES['poster']);
        }
        if ($_FILES['kefu_qrcode']['tmp_name']) {
            $data['kefu_qrcode'] = zm_saveimages($_FILES['kefu_qrcode']);
        }
        $data['kefu_tip']        = strip_tags($_GET['kefu_tip']);
        $data['summary']        = strip_tags($_GET['summary']);
        $data['addtime'] = strtotime($_GET['addtime']);
        $data['intro']    = dhtmlspecialchars($_GET['intro']);
        $data['price']        = strip_tags($_GET['price']);
        $data['bgcolor']        = strip_tags($_GET['bgcolor']);
        $data['id']      = intval($_GET['ids']);
        
        if ($data['id'] > 0) {

        DB::update('zimu_zhaopin_jobfair_online', $data, array(
            'id' => $data['id']
        ));
            
        } else {
            
            $result = DB::insert('zimu_zhaopin_jobfair_online', $data, 1);
            
        }
          
        include template('zimu_zhaopin:common/success');

}else{

        $ids = intval($_GET['ids']);
        
        $listdata = DB::fetch_first('select * from %t where id=%d', array(
            'zimu_zhaopin_jobfair_online',
            $ids
        ));

        include zimu_template('admins/admins_' . $type .'_jobfairlist','');

}


} else if ($op == 'jobfair_company') {

    $fid = intval($_GET['fid']);

if(submitcheck('submit')) {

        if (!empty($_GET['ids'])) {
            foreach ($_GET['ids'] as $k => $v) {

if($v){
        $data = array(
            'fid' => $fid,
            'uid' => intval($_GET['uid'][$k]),
            'com_id' => intval($_GET['com_id'][$k]),
            'sort' => intval($_GET['sort'][$k]),
            'com_name' => trim($_GET['com_name'][$k]),
            'zhiding' => intval($_GET['zhiding'][$k]),
            'note' => trim($_GET['note'][$k]),
            'status' => intval($_GET['status'][$k]),
            'addtime' => intval($_GET['addtime'][$k]),
        );

            DB::update('zimu_zhaopin_jobfair_online_com', $data, array(
                'fid' => $fid,
                'id' => $v
            ));

}elseif(trim($_GET['com_name'][$k])){

        $data = array(
            'fid' => $fid,
            'uid' => intval($_GET['uid'][$k]),
            'com_id' => intval($_GET['com_id'][$k]),
            'sort' => intval($_GET['sort'][$k]),
            'com_name' => trim($_GET['com_name'][$k]),
            'zhiding' => intval($_GET['zhiding'][$k]),
            'note' => trim($_GET['note'][$k]),
            'status' => intval($_GET['status'][$k]),
            'addtime' => $_G['timestamp'],
        );

        DB::insert('zimu_zhaopin_jobfair_online_com', $data);

}

}
        }

        include template('zimu_zhaopin:common/success');

}else{

    $ids = intval($_GET['ids']);

    $status = intval($_GET['status']);
    if (!empty($status)) {
        $wheresql = " and status = 0 ";
    }

    $lists = DB::fetch_all('select * from %t where fid=%d %i order by zhiding desc,sort asc,addtime asc', array(
        'zimu_zhaopin_jobfair_online_com',
        $ids,
        $wheresql
    ));

include zimu_template('admins/admins_' . $type .'_jobfairlist','');

}


} else if ($op == 'del_company' && $_GET['md5hash'] == formhash()) {

    $ids = intval($_GET['ids']);
    $fid = intval($_GET['fid']);
    
    $result = DB::delete('zimu_zhaopin_jobfair_online_com', array(
        'id' => $ids,
        'fid' => $fid
    ));
    
    include template('zimu_zhaopin:common/success');


} else if ($op == 'del' && $_GET['md5hash'] == formhash()) {
    
    $ids = intval($_GET['ids']);
    
    $result = DB::delete('zimu_zhaopin_jobfair_online', array(
        'id' => $ids
    ));
    
    include template('zimu_zhaopin:common/success');


} else {


        
    $wheresql = 'where 1=1 ';

    $pindex = max(1, intval($_GET['page']));
    $psize  = 30;
    
    $total = DB::result_first("SELECT count(*) FROM %t %i", array(
        "zimu_zhaopin_jobfair_online",
        $wheresql
    ));

    $listdata = DB::fetch_all('select * from %t %i order by id desc limit %d,%d', array(
        'zimu_zhaopin_jobfair_online',
        $wheresql,
        ($pindex - 1) * $psize,
        $psize
    ));
    
    $pager = pagination($total, $pindex, $psize);
    
    
    include zimu_template('admins/admins_' . $type .'_'. $op,'');
    
    
}