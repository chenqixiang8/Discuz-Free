<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(submitcheck('submit')) {

        $ids = intval($_GET['ids']);

        $data['title'] = strip_tags($_GET['title']);
        $data['keywords'] = strip_tags($_GET['keywords']);
        $data['description'] = strip_tags($_GET['description']);
        if ($_FILES['logo']['tmp_name']) {
            $data['logo'] = zm_saveimages($_FILES['logo']);
        }
        $data['share_title'] = strip_tags($_GET['share_title']);
        $data['share_desc'] = strip_tags($_GET['share_desc']);
        $data['weixin_appid'] = strip_tags($_GET['weixin_appid']);
        $data['weixin_appsecret'] = strip_tags($_GET['weixin_appsecret']);
        if ($_FILES['share_thumb']['tmp_name']) {
            $data['share_thumb'] = zm_saveimages($_FILES['share_thumb']);
        }
        if ($_FILES['kefu_qrcode']['tmp_name']) {
            $_GET['settings']['kefu_qrcode_url'] = zm_saveimages($_FILES['kefu_qrcode']);
        }
        if ($_FILES['kefu_avatar']['tmp_name']) {
            $_GET['settings']['kefu_avatar_url'] = zm_saveimages($_FILES['kefu_avatar']);
        }

        if ($_FILES['mp_qrcode']['tmp_name']) {
            $_GET['settings']['mp_qrcode_url'] = zm_saveimages($_FILES['mp_qrcode']);
        }
        if ($_FILES['pc_logo']['tmp_name']) {
            $_GET['settings']['pc_logo_url'] = zm_saveimages($_FILES['pc_logo']);
        }
        if ($_FILES['app_thumb']['tmp_name']) {
            $_GET['settings']['app_thumb_url'] = zm_saveimages($_FILES['app_thumb']);
        }
        
        $data['settings'] = serialize($_GET['settings']);
if($ids){
        $result = DB::update('zimu_zhaopin_setting', $data, array(
            'id' => $ids
        ));
}else{
        $result = DB::insert('zimu_zhaopin_setting',$data,1);
}

        
        include template('zimu_zhaopin:common/success');


}else{


$data = DB::fetch_first('select * from %t order by id desc', array(
        'zimu_zhaopin_setting'
    ));

$settings = unserialize($data['settings']);

include zimu_template('admins/admins_'.$type,'');


}