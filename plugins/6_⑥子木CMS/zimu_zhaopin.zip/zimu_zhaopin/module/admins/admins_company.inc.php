<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$op = addslashes($_GET['op']);
$op = $op ? $op : 'list';

if ($op == 'edit') {

$category_jobs = DB::fetch_all('select * from %t order by c_order asc,c_id asc', array(
        'zimu_zhaopin_category'
    ));

foreach ($category_jobs as $key => $value) {

$category_jobs2[$value['c_alias']][$value['c_id']] = $value['c_name'];

}

    $tag_arr = $category_jobs2['ZM_jobtag'];

    $arealist = DB::fetch_all('select * from %t where parentid=0 order by sort asc,id asc', array(
        'zimu_zhaopin_area'
    ),'id');

    foreach ($arealist as $key => $value) {
        
        $arealist[$value['id']]['list'] = DB::fetch_all('select * from %t where parentid=%d order by sort asc,id asc', array(
        'zimu_zhaopin_area',
        $value['id']
    ));
        
    }

    if (submitcheck('submit')) {

        $data['uid']      = intval($_GET['uid']);
        $data['audit']         = intval($_GET['audit']);
        $data['companyname']        = strip_tags($_GET['companyname']);
        $data['nature']         = intval($_GET['nature']);
        $data['nature_cn']        = strip_tags($_GET['nature_cn']);
        $data['scale']         = intval($_GET['scale']);
        $data['scale_cn']        = strip_tags($_GET['scale_cn']);
        $data['district']         = intval($_GET['district']);
        $data['district_cn']        = strip_tags($_GET['district_cn']);

        $district_array            = explode(".", $_GET['district']);
        $data['district']  = strip_tags($_GET['district']);
        $district_cn1 = DB::result_first('select name from %t where id=%d order by id desc', array(
            'zimu_zhaopin_area',
            $district_array[0]
        ));
        $district_cn2 = DB::result_first('select name from %t where id=%d order by id desc', array(
            'zimu_zhaopin_area',
            $district_array[1]
        ));
        $district_cn3 = DB::result_first('select name from %t where id=%d order by id desc', array(
            'zimu_zhaopin_area',
            $district_array[2]
        ));
        
        if($zmdata['settings']['area_three']==1){
        $data['district_cn'] = $district_cn2.$district_cn3;
        }else{
        $data['district_cn'] = $district_cn1.$district_cn2;
        }


        $data['trade']         = intval($_GET['trade']);
        $data['trade_cn']        = strip_tags($_GET['trade_cn']);
        $data['tag'] = $posttag = trim($_GET['tag']);
        if ($posttag) {
            $tagArr = explode(",", $posttag);
            $r_arr  = array();
            foreach ($tagArr as $key => $value) {
                $r_arr[] = $category_jobs2['ZM_jobtag'][$value];
            }
            if (!empty($r_arr)) {
                $data['tag_cn'] = implode(",", $r_arr);
            } else {
                $data['tag_cn'] = '';
            }
        }

        $data['contact']        = strip_tags($_GET['contact']);
        $data['telephone']        = strip_tags($_GET['telephone']);
        $data['landline_tel']        = strip_tags($_GET['landline_tel']);
        $data['address']        = strip_tags($_GET['address']);
        $data['contents']        = strip_tags($_GET['contents']);
        $data['map_x']        = strip_tags($_GET['map_x']);
        $data['map_y']        = strip_tags($_GET['map_y']);
        if ($_FILES['logo']['tmp_name']) {
            $data['logo'] = zm_saveimages($_FILES['logo']);
        }
        if($_GET['img_logo']=='nopic'){
            $data['logo'] = '';
        }
        if ($_FILES['certificate_img']['tmp_name']) {
            $data['certificate_img'] = zm_saveimages($_FILES['certificate_img']);
        }
        if($_GET['img_certificate_img']=='nopic'){
            $data['certificate_img'] = '';
        }
        if ($_FILES['pcad']['tmp_name']) {
            $data['pcad'] = zm_saveimages($_FILES['pcad']);
        }
        if($_GET['img_pcad']=='nopic'){
            $data['pcad'] = '';
        }
        $data['click']   = intval($_GET['click']);
        $data['addtime'] = strtotime($_GET['addtime']);
        $data['wxtpl']        = strip_tags($_GET['wxtpl']);
        $data['certificate_img_audit']      = intval($_GET['certificate_img_audit']);
        $data['is_pcad']   = intval($_GET['is_pcad']);
        $data['company_mingqi']      = intval($_GET['company_mingqi']);
        $data['kefu_uid']      = intval($_GET['kefu_uid']);
        $data['weixin']        = strip_tags($_GET['weixin']);
        if ($data['kefu_uid']) {
            $data['kefu_name'] = DB::result_first('select kefu_name from %t where uid=%d', array(
                'zimu_zhaopin_kefu',
                $data['kefu_uid'],
            ));
        }
        $data['id']      = intval($_GET['ids']);

    DB::query("update %t set company_certificate=%d,company_mingqi=%d,trade=%d,trade_cn=%s where uid=%d", array(
        'zimu_zhaopin_jobs',
        $data['certificate_img_audit'],
        $data['company_mingqi'],
        $data['trade'],
        $data['trade_cn'],
        $data['uid']
    ));

        if ($data['id'] > 0) {

        $listdata = DB::fetch_first('select * from %t where id=%d', array(
            'zimu_zhaopin_company_profile',
            $data['id']
        ));

if($data['wxtpl'] && $data['audit']!=2 && $data['audit'] != $listdata['audit']){

    $paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
        'zimu_zhaopin_parameter2',
        'wxtpl'
    ));

    $paramters = unserialize($paramter['parameter']);

    notification_user($data['uid'],$paramters['wxtpl_admin'],array('first'=>$data['companyname'].$language_zimu['admins_company_inc_php_0'],'keyword1'=>$data['audit']==1 ? $language_zimu['admins_company_inc_php_1'] : $language_zimu['admins_company_inc_php_2'],'keyword2'=>date('Y-m-d H:i',$_G['timestamp']),'remark'=>$data['wxtpl'].'\r\n'.$language_zimu['admins_company_inc_php_3'],'url'=>ZIMUCMS_URL.'&model=mycompany'));


$magcon = '{"tag":"'.$language_zimu['admins_company_inc_php_4'].'","title":"'.$data['companyname'].$language_zimu['admins_company_inc_php_5'].'","title_themecolor":"#ff0000","link":"'.ZIMUCMS_URL.'&model=mycompany","extra_info":[{"key":"'.$language_zimu['admins_company_inc_php_6'].'","val":"'.($data['audit']==1 ? $language_zimu['admins_company_inc_php_7'] : $language_zimu['admins_company_inc_php_8']).'"}],"des":"'.$data['wxtpl'].'<br>'.$language_zimu['admins_company_inc_php_9'].'","des_themecolor":"#008000"}';

    notification_user_magapp($data['uid'],$magcon);


}

if($data['telephone']){
    DB::query("update %t set telephone=%s where uid=%d", array(
        'zimu_zhaopin_members',
        $$data['telephone'],
        $data['uid']
    ));
}

            DB::update('zimu_zhaopin_company_profile', $data, array(
                'id' => $data['id']
            ));
            
        } else {
            
            $result = DB::insert('zimu_zhaopin_company_profile', $data, 1);
            
        }
        
        
        include template('zimu_zhaopin:common/success');
        
        
    } else {
        
        $ids = intval($_GET['ids']);
        
        $listdata = DB::fetch_first('select * from %t where id=%d', array(
            'zimu_zhaopin_company_profile',
            $ids
        ));

        $kefudata = DB::fetch_all('select * from %t order by id asc', array(
            'zimu_zhaopin_kefu'
        ));

        include zimu_template('admins/admins_' . $type,'');
        
    }
    
    
} else if ($op == 'del' && $_GET['md5hash'] == formhash()) {
    
    $ids = intval($_GET['ids']);
    
    $result = DB::delete('zimu_zhaopin_company_profile', array(
        'id' => $ids
    ));
    
    include template('zimu_zhaopin:common/success');


}elseif ($op == 'editsetmeal') {

    $ids = intval($_GET['ids']);

    $setmealist = DB::fetch_all('select * from %t order by id asc', array(
            'zimu_zhaopin_setmeal'
        ));

    $user_setmeal = DB::fetch_first('select * from %t where uid=%d order by id desc', array(
        'zimu_zhaopin_members_setmeal',
        $ids
    ));
    
    $mypoints = DB::result_first('select points from %t where uid=%d order by id desc', array(
        'zimu_zhaopin_members',
        $ids
    ));

    if (submitcheck('submit')) {

$tosetmea = intval($_GET['tosetmea']);
$setmealid = intval($_GET['setmealid']);
$touid = intval($_GET['ids']);

if($tosetmea && $touid){

    $setmeal = DB::fetch_first('select * from %t where id=%d and display=1 order by id desc', array(
        'zimu_zhaopin_setmeal',
        $setmealid
    ));

        $timestamp = time();
        $setmeal_add['expire'] = $setmeal['is_free'] == 1 ? 1 : 0;
        $setmeal_add['uid'] = $touid;
        $setmeal_add['setmeal_id'] = $setmeal['id'];
        $setmeal_add['setmeal_name'] = $setmeal['setmeal_name'];
        $setmeal_add['days'] = $setmeal['days'];
        $setmeal_add['expense']=$setmeal['expense'];
        $setmeal_add['jobs_meanwhile']=$setmeal['jobs_meanwhile'];
        $setmeal_add['refresh_jobs_free']=$setmeal['refresh_jobs_free'];
        $setmeal_add['download_resume_max'] = $setmeal['download_resume_max'];
        $setmeal_add['added']=$setmeal['added'];
        $setmeal_add['starttime'] = time();
        if ($setmeal['days']>0){
            $setmeal_add['endtime']=strtotime("".$setmeal['days']." days");
        }else{
            $setmeal_add['endtime']="0";  
        }
        $setmeal_add['show_apply_contact'] = $setmeal['show_apply_contact'];
        $setmeal_add['is_free']=$setmeal['is_free'];
        $setmeal_add['discount_download_resume']=$setmeal['discount_download_resume'];
        $setmeal_add['discount_stick']=$setmeal['discount_stick'];
        $setmeal_add['discount_emergency']=$setmeal['discount_emergency'];
        $setmeal_add['discount_auto_refresh_jobs']=$setmeal['discount_auto_refresh_jobs'];


if($tosetmea==1){

       $setmeal_add['download_resume'] = $setmeal['download_resume'];
       $setmeal_add['starttime'] = time();

}elseif($tosetmea==2){

       $setmeal_add['download_resume'] = $user_setmeal['download_resume'] + $setmeal['download_resume'];

}

if($user_setmeal){

            DB::update('zimu_zhaopin_members_setmeal', $setmeal_add, array(
                'uid' => $touid
            ));

}else{

    DB::insert('zimu_zhaopin_members_setmeal', $setmeal_add);
            
}

            DB::query("update %t set setmeal_id=%d,setmeal_name=%s where uid=%d", array(
                'zimu_zhaopin_company_profile',
                $setmeal['id'],
                $setmeal['setmeal_name'],
                $touid
            ));

            DB::query("update %t set setmeal_id=%d,setmeal_name=%s where uid=%d", array(
                'zimu_zhaopin_jobs',
                $setmeal['id'],
                $setmeal['setmeal_name'],
                $touid
            ));

}else{

$user_setmeal2 = $_GET['user_setmeal'];
$user_setmeal2['endtime'] = strtotime($user_setmeal2['endtime']);

DB::update('zimu_zhaopin_members_setmeal', $user_setmeal2, array(
    'uid' => $ids
));

            DB::query("update %t set setmeal_id=%d,setmeal_name=%s where uid=%d", array(
                'zimu_zhaopin_jobs',
                $user_setmeal['setmeal_id'],
                $user_setmeal['setmeal_name'],
                $ids
            ));

}


            DB::query("update %t set points=%d where uid=%d", array(
                'zimu_zhaopin_members',
                intval($_GET['mypoints']),
                $ids
            ));

        include template('zimu_zhaopin:common/success');
        
    }else{

    include zimu_template('admins/admins_' . $type,'');

    }

} else if ($op == 'changecontact') {

$cid = intval($_GET['cid']);
$display = intval($_GET['display']);

DB::query("update %t set is_contact=%d where id=%d", array(
    'zimu_zhaopin_company_profile',
    $display,
    $cid
));

ajaxReturn(1,1);

} else if ($op == 'changeweixin') {

$cid = intval($_GET['cid']);
$display = addslashes($_GET['display']);

DB::query("update %t set weixin=%s where id=%d", array(
    'zimu_zhaopin_company_profile',
    $display,
    $cid
));

ajaxReturn(1,1);

}elseif ($op == 'refreshalljob') {

$ids = intval($_GET['ids']);

    $total = DB::result_first("SELECT count(*) FROM %t where company_id=%d", array(
        "zimu_zhaopin_jobs",
        $ids
    ));

  DB::query("update %t set refreshtime=%d where company_id=%d", array(
      'zimu_zhaopin_jobs',
      $_G['timestamp'],
      $ids
  ));

  ajaxReturn(1,$total);

}elseif ($op == 'changeaudit') {

DB::query("update %t set audit=1 where id in (%n)", array(
    'zimu_zhaopin_company_profile',
    $_GET['ids']
));

ajaxReturn(1,1);
     
} else {

    $wheresql = 'where 1=1 ';
    $keywordtype = intval($_GET['keywordtype']);
    $keyword     = trim($_GET['keyword']);
    $keyword     = dhtmlspecialchars($keyword);
    $keyword     = stripsearchkey($keyword);
    $keyword     = daddslashes($keyword);

    if (!empty($keyword)) {
        if ($keywordtype == 1) {
            $wheresql .= " and `id` = '{$keyword}' ";
        } elseif ($keywordtype == 2) {
            $wheresql .= " and `companyname` LIKE '%{$keyword}%' ";
        } elseif ($keywordtype == 3) {
            $wheresql .= " and `uid` = '{$keyword}' ";
        } elseif ($keywordtype == 4) {
            $wheresql .= " and `telephone` LIKE '%{$keyword}%' ";
        }
    }
    
    $audit = intval($_GET['audit']);
    if (!empty($audit)) {
        $wheresql .= " and audit = ".$audit;
    }
    $setmeal_id = intval($_GET['setmeal_id']);
    if (!empty($setmeal_id)) {
        $wheresql .= " and setmeal_id > ".$setmeal_id;
    }
    $certificate_img_audit = intval($_GET['certificate_img_audit']);
    if($certificate_img_audit==1){
        $wheresql .= " and certificate_img_audit = ".$certificate_img_audit;
    }elseif($certificate_img_audit==2){
        $wheresql .= " and certificate_img_audit = 0";
    }

    $order = intval($_GET['order']);
    if($order==1){
        $whereorder = 'refreshtime';
    }else if($order==2){
        $whereorder = 'logintime';
    }else{
        $whereorder = 'id';
    }

    $pindex = max(1, intval($_GET['page']));
    $psize  = 30;
    
    $total = DB::result_first("SELECT count(*) FROM %t %i", array(
        "zimu_zhaopin_company_profile",
        $wheresql
    ));

    $total2 = DB::result_first("SELECT count(*) FROM %t %i", array(
        "zimu_zhaopin_company_profile",
        "where 1=1 and audit=2"
    ));

    $listdata = DB::fetch_all('select * from %t %i order by %i desc limit %d,%d', array(
        'zimu_zhaopin_company_profile',
        $wheresql,
        $whereorder,
        ($pindex - 1) * $psize,
        $psize
    ));
    
    $pager = pagination($total, $pindex, $psize);
    
    
    include zimu_template('admins/admins_' . $type,'');
    
    
}