<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$company_nums = DB::result_first("SELECT count(*) FROM %t", array(
    "zimu_zhaopin_company_profile"
));

$company_nums2 = DB::result_first("SELECT count(*) FROM %t where addtime>%d", array(
    "zimu_zhaopin_company_profile",
    strtotime(date('Y-m-d', $_G['timestamp']))
));

$jobs_nums = DB::result_first("SELECT count(*) FROM %t", array(
    "zimu_zhaopin_jobs"
));

$jobs_nums2 = DB::result_first("SELECT count(*) FROM %t where addtime>%d", array(
    "zimu_zhaopin_jobs",
    strtotime(date('Y-m-d', $_G['timestamp']))
));


$resume_nums = DB::result_first("SELECT count(*) FROM %t", array(
    "zimu_zhaopin_resume"
));

$resume_nums2 = DB::result_first("SELECT count(*) FROM %t where addtime>%d", array(
    "zimu_zhaopin_resume",
    strtotime(date('Y-m-d', $_G['timestamp']))
));


$order_nums = DB::result_first("SELECT sum(amount) FROM %t where is_paid=2", array(
    "zimu_zhaopin_order"
));

$order_nums2 = DB::result_first("SELECT sum(amount) FROM %t where is_paid=2 and addtime>%d", array(
    "zimu_zhaopin_order",
    strtotime(date('Y-m-d', $_G['timestamp']))
));

$order_nums2 = intval($order_nums2);

$oldcom_data = DB::fetch_all('select * from %t where setmeal_id>1 and endtime<%d order by id desc', array(
    'zimu_zhaopin_members_setmeal',
    $_G['timestamp']
));


$audit_com = DB::result_first("SELECT count(*) FROM %t where audit=2", array(
    "zimu_zhaopin_company_profile"
));

$audit_jobs = DB::result_first("SELECT count(*) FROM %t where audit=2", array(
    "zimu_zhaopin_jobs"
));

$audit_resume = DB::result_first("SELECT count(*) FROM %t where audit=2", array(
    "zimu_zhaopin_resume"
));

$audit_report = DB::result_first("SELECT count(*) FROM %t where audit=1", array(
    "zimu_zhaopin_report"
));

$bind_weixin_company = DB::result_first("SELECT count(*) FROM %t where bind_weixin=1", array(
    "zimu_zhaopin_company_profile"
));

$bind_weixin_resume = DB::result_first("SELECT count(*) FROM %t where bind_weixin=1", array(
    "zimu_zhaopin_resume"
));

$month_nums = DB::result_first("SELECT sum(amount) FROM %t where is_paid=2 and addtime>=%d and addtime<=%d", array(
    "zimu_zhaopin_order",
    mktime(0,0,0,date('m'),1,date('Y')),
    mktime(23,59,59,date('m'),date('t'),date('Y'))
));
$month_nums = intval($month_nums);

$month_nums2 = DB::result_first("SELECT sum(amount) FROM %t where is_paid=2 and addtime>=%d and addtime<=%d", array(
    "zimu_zhaopin_order",
    strtotime(date('Y-m-01 00:00:00',strtotime('-1 month'))),
    strtotime(date("Y-m-d 23:59:59", strtotime(-date('d').'day')))
));
$month_nums2 = intval($month_nums2);

include zimu_template('admins/admins_'.$type,'');

