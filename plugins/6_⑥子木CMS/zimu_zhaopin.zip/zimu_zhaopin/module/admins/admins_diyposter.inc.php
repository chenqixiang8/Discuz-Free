<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$op = addslashes($_GET['op']);
$op = $op ? $op : 'list';

if(submitcheck('submit')) {


        $paramters1 = $_GET['data'];

        $paramters2 = json_decode(zimu_array_utf8($paramters1),true);

	    $paramters['data'] = zimu_array_utf8tomy($paramters2);
        $paramters['bg'] = $_GET['bg'];

        $isadd = DB::fetch_first('select * from %t where name=%s order by id desc', array(
            'zimu_zhaopin_parameter2',
            'diyposter'
        ));

        if ($isadd['id'] > 0) {

        DB::query("update %t set parameter=%s where id=%d", array(
            'zimu_zhaopin_parameter2',
            serialize($paramters),
            $isadd['id']
        ));
            
        } else {

        $adddata = array(
                'name'=>'diyposter',
                'parameter'=>serialize($paramters),
        );

            DB::insert('zimu_zhaopin_parameter2', $adddata);
            
        }
        
        
        include template('zimu_zhaopin:common/success');



} else {

        $paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
            'zimu_zhaopin_parameter2',
            'diyposter'
        ));
        
        $paramters = unserialize($paramter['parameter']);
    
    include zimu_template('admins/admins_' . $type,'');
    
    
}