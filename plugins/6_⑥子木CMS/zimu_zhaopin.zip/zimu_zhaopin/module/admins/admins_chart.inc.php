<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$ac = addslashes($_GET['ac']);

$starttime = strtotime($_GET['starttime']);
$endtime = strtotime($_GET['endtime'])+86400;

if($ac=='chart1'){

$json_row_company = array();

$query = DB::query("SELECT FROM_UNIXTIME(addtime,'%m-%d') as time , '".$language_zimu['admins_chart_inc_php_0']."' as name, count(*) as count FROM ".DB::table('zimu_zhaopin_company_profile')." WHERE addtime >= $starttime and addtime <= $endtime GROUP BY time");
while($res = DB::fetch($query)){
       $json_row_company[] = $res;
    }

$json_row_resume = array();
$query = DB::query("SELECT FROM_UNIXTIME(addtime,'%m-%d') as time , '".$language_zimu['admins_chart_inc_php_1']."' as name, count(*) as count FROM ".DB::table('zimu_zhaopin_resume')." WHERE addtime >= $starttime and addtime <= $endtime GROUP BY  time");
while($res = DB::fetch($query)){
       $json_row_resume[] = $res;
    }
$json_row_jobs = array();
$query = DB::query("SELECT FROM_UNIXTIME(addtime,'%m-%d') as time , '".$language_zimu['admins_chart_inc_php_2']."' as name, count(*) as count FROM ".DB::table('zimu_zhaopin_jobs')." WHERE addtime >= $starttime and addtime <= $endtime GROUP BY  time");
while($res = DB::fetch($query)){
       $json_row_jobs[] = $res;
    }


$json_row3 = array_merge($json_row_company,$json_row_resume);
$json_row3 = array_merge($json_row3,$json_row_jobs);


sort_array_multi($json_row3, ['time', 'count','name'], ['asc', 'asc','desc']);


echo $json_row4 = json_encode(zimu_array_utf8($json_row3),true);

}

if($ac=='chart2'){

$json_row_resume = array();
$query = DB::query("SELECT FROM_UNIXTIME(addtime,'%m-%d') as time , '".$language_zimu['admins_chart_inc_php_3']."' as name, count(*) as count FROM ".DB::table('zimu_zhaopin_refresh_log')." WHERE addtime >= $starttime and addtime <= $endtime and mode=0 and type=2001 GROUP BY time");
while($res = DB::fetch($query)){
       $json_row_resume[] = $res;
    }

$json_row_jobs = array();
$query = DB::query("SELECT FROM_UNIXTIME(addtime,'%m-%d') as time , '".$language_zimu['admins_chart_inc_php_4']."' as name, count(*) as count FROM ".DB::table('zimu_zhaopin_refresh_log')." WHERE addtime >= $starttime and addtime <= $endtime and mode=2 and type=1001 GROUP BY time");
while($res = DB::fetch($query)){
       $json_row_jobs[] = $res;
    }

$json_row_jobs_apply = array();
$query = DB::query("SELECT FROM_UNIXTIME(apply_addtime,'%m-%d') as time , '".$language_zimu['admins_chart_inc_php_5']."' as name, count(*) as count FROM ".DB::table('zimu_zhaopin_personal_jobs_apply')." WHERE apply_addtime >= $starttime and apply_addtime <= $endtime GROUP BY time");
while($res = DB::fetch($query)){
       $json_row_jobs_apply[] = $res;
    }

$json_row_down_resume = array();
$query = DB::query("SELECT FROM_UNIXTIME(down_addtime,'%m-%d') as time , '".$language_zimu['admins_chart_inc_php_6']."' as name, count(*) as count FROM ".DB::table('zimu_zhaopin_company_down_resume')." WHERE down_addtime >= $starttime and down_addtime <= $endtime GROUP BY time");
while($res = DB::fetch($query)){
       $json_row_down_resume[] = $res;
    }


$json_row_jobs_apply2 = array();
$query = DB::query("SELECT FROM_UNIXTIME(apply_addtime,'%m-%d') as time , '".$language_zimu['admins_chart_inc_php_7']."' as name, count(distinct personal_uid) as count FROM ".DB::table('zimu_zhaopin_personal_jobs_apply')." WHERE apply_addtime >= $starttime and apply_addtime <= $endtime GROUP BY time");
while($res = DB::fetch($query)){
       $json_row_jobs_apply2[] = $res;
    }


$json_row3 = array_merge($json_row_resume,$json_row_jobs);
$json_row3 = array_merge($json_row3,$json_row_jobs_apply,$json_row_down_resume,$json_row_jobs_apply2);


sort_array_multi($json_row3, ['time', 'count','name'], ['asc', 'asc','desc']);


echo $json_row4 = json_encode(zimu_array_utf8($json_row3),true);

}



if($ac=='chart3'){

$json_row_type1 = array();
$query = DB::query("SELECT FROM_UNIXTIME(addtime,'%m-%d') as time , '".$language_zimu['admins_chart_inc_php_8']."' as name, count(*) as count FROM ".DB::table('zimu_zhaopin_order')." WHERE is_paid=2 and order_type=1 and addtime >= $starttime and addtime <= $endtime GROUP BY time");
while($res = DB::fetch($query)){
       $json_row_type1[] = $res;
    }

$json_row_type3 = array();
$query = DB::query("SELECT FROM_UNIXTIME(addtime,'%m-%d') as time , '".$language_zimu['admins_chart_inc_php_9']."' as name, count(*) as count FROM ".DB::table('zimu_zhaopin_order')." WHERE is_paid=2 and order_type=3 and addtime >= $starttime and addtime <= $endtime GROUP BY time");
while($res = DB::fetch($query)){
       $json_row_type3[] = $res;
    }

$json_row_type8 = array();
$query = DB::query("SELECT FROM_UNIXTIME(addtime,'%m-%d') as time , '".$language_zimu['admins_chart_inc_php_10']."' as name, count(*) as count FROM ".DB::table('zimu_zhaopin_order')." WHERE is_paid=2 and order_type=8 and addtime >= $starttime and addtime <= $endtime GROUP BY time");
while($res = DB::fetch($query)){
       $json_row_type8[] = $res;
    }


$json_row_type13 = array();
$query = DB::query("SELECT FROM_UNIXTIME(addtime,'%m-%d') as time , '".$language_zimu['admins_chart_inc_php_11']."' as name, count(*) as count FROM ".DB::table('zimu_zhaopin_order')." WHERE is_paid=2 and order_type=13 and addtime >= $starttime and addtime <= $endtime GROUP BY time");
while($res = DB::fetch($query)){
       $json_row_type13[] = $res;
    }

$json_row3 = array_merge($json_row_type1,$json_row_type3,$json_row_type8,$json_row_type13);


sort_array_multi($json_row3, ['time', 'count','name'], ['asc', 'asc','desc']);


echo $json_row4 = json_encode(zimu_array_utf8($json_row3),true);

}



function sort_array_multi(array &$arr, array $keys, array $order)
{
    //У�����
    if ( count($keys) == ($times = count($order)) ) {
        for ( $i = 0, $j = 0; $j < $times; $i += 2, $j++ ) {
            foreach ( $arr as $k => $v ) {
                //ԭ�����Ƿ���ڸ��ֶ�
                if ( isset($v[$keys[$j]]) ) {
                    $params[$i][] = $v[$keys[$j]];    //TODO ��������֧��
                } else {
                    return false;
                }
            }
            if ( strtoupper($order[$j]) == 'ASC' ) {
                $params[$i + 1] = SORT_ASC;
            } else {
                $params[$i + 1] = SORT_DESC;
            }
        }
        $params[] = &$arr;
        return call_user_func_array('array_multisort', $params);
    } else {
        return false;
    }
}
