<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(!$_G['uid']){


if(!$zmdata['settings']['weixin_login_url']){

isuid();

}


$referer = urldecode($_GET['referer']);

$op = addslashes($_GET['op']);


if($op=='loging'){

$username = zm_diconv($_GET['username']);
$password = addslashes($_GET['password']);

if (isMobile($username)) {

    $uid = DB::result_first('select uid from %t where telephone=%s order by id desc', array(
        'zimu_zhaopin_members',
        $username
    ));
    
    if ($uid) {
        $userinfo = getuserbyuid($uid);
        $username          = $userinfo['username'];
    }

}

    loaducenter();
    list($result) = uc_user_login($username, $password, 0, 0); 
  
    if($result >= 0) {
    
    $member = getuserbyuid($result, 1);
    require_once libfile('function/member');
    $cookietime = 1296000;
    setloginstatus($member, $cookietime);
    
    C::t('common_member_status')->update($result, array(
        'lastip' => $_G['clientip'],
        'lastvisit' => TIMESTAMP,
        'lastactivity' => TIMESTAMP
    ));

    $ucsynlogin = '';
    if ($_G['setting']['allowsynlogin']) {
        $ucsynlogin = uc_user_synlogin($result);
    }

    $url = urldecode($_GET['url']);

    $returndata['status'] = 1;
    $returndata['data'] = $url ? $url : ZIMUCMS_URL;


    }else{

    $returndata['status'] = 0;
    $returndata['msg'] = zimu_array_utf8($language_zimu['login_inc_php_0']);

    }

    echo json_encode($returndata);exit();


}else if($op == 'loging2'){

$mobile = addslashes($_GET['mobile']);
$mobile_vcode = addslashes($_GET['mobile_vcode']);


    $uid = DB::result_first('select uid from %t where telephone=%s and verify_code=%d order by id desc', array(
        'zimu_zhaopin_members',
        $mobile,
        $mobile_vcode
    ));
    
    if ($uid) {

    $member = getuserbyuid($uid, 1);
    if (!$member) {
        return false;
    }
    if (isset($member['_inarchive'])) {
        C::t('common_member_archive')->move_to_master($member['uid']);
    }
    require_once libfile('function/member');
    $cookietime = 1296000;
    setloginstatus($member, $cookietime);


    $url = urldecode($_GET['url']);

    $returndata['status'] = 1;
    $returndata['data'] = $url ? $url : ZIMUCMS_URL;


    }else{

    $returndata['status'] = 0;
    $returndata['msg'] = zimu_array_utf8($language_zimu['login_inc_php_1']);

    }

    echo json_encode($returndata);exit();


}else if($op == 'ajax_check'){

$param = addslashes($_GET['param']);

        $user = DB::fetch_first('select * from %t where telephone=%s order by id desc', array(
                    'zimu_zhaopin_members',
                    $param
                ));

        if($user['uid']){

        $rand = mt_rand(1000, 9999);

        $sms_paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
            'zimu_zhaopin_parameter2',
            'aliyunsms'
        ));
        $sms_paramter = unserialize($sms_paramter['parameter']);
    
        $app_key = $sms_paramter['smsAppKey']; 
        $app_secret = $sms_paramter['smssecretKey']; 
        $sign_name = mb_convert_encoding($sms_paramter['smsFreeSignName'],'UTF-8',CHARSET);
        $smsdata['code'] = $rand;
    
        $requestUrl = "http://dysmsapi.aliyuncs.com/";
        $params['PhoneNumbers']= $param;
        $params['SignName']= $sign_name;
        if(isMobile($param)){
        $params['TemplateCode']= $sms_paramter['smsTemplateCode'];
        }else{
        $params['TemplateCode']= $sms_paramter['smsTemplateCode2'];
        }
        $params['TemplateParam']= json_encode($smsdata);
        $params['OutId']= "3333";
        $params['RegionId']= "cn-hangzhou";
        $params['AccessKeyId']= $app_key;
        $params['Format']= "JSON";
        $params['SignatureMethod']= "HMAC-SHA1";
        $params['SignatureVersion']= "1.0";
        $params['SignatureNonce']= uniqid();
        date_default_timezone_set("GMT");
        $params['Timestamp']= date("Y-m-d\TH:i:s\Z");
        $params['Action']= "SendSms";
        $params['Version']= "2017-05-25";
        $params['Signature']= aliyun_signature($params,$app_secret);
    
        include_once DISCUZ_ROOT . './source/plugin/zimu_zhaopin/class/Aliyun_HttpHelper.class.php';
    
        $Aliyun_HttpHelper = new Aliyun_HttpHelper();
        $result = $Aliyun_HttpHelper->curl($requestUrl,'POST',$params,array('x-sdk-client' => 'php/2.0.0'));
    
        $aaa = object_array(json_decode($result));
    
            if ($aaa['alibaba_aliqin_fc_sms_num_send_response']['result']['success'] == 1 || $aaa['success'] == 1 || $aaa['Code'] == 'OK') {
    
        DB::query("update %t set verify_code=%d where uid=%d", array(
            'zimu_zhaopin_members',
            $rand,
            $user['uid'],
        ));
    
                ajaxReturn(1,'ok');
            }else{
                ajaxReturn(0,mb_convert_encoding($aaa['Message'], CHARSET, 'UTF-8'));
            }


        }else{
            ajaxReturn(0,'nouser');
        }






}else{

include zimu_template('login');

}

}else{

if($utype == 1){

dheader('Location:' . ZIMUCMS_URL);

}else{

dheader('Location:' . ZIMUCMS_URL);

}

}


function aliyun_signature($params,$AccessKeySecret){
    ksort($params);

    $canonicalizedQueryString = '';
    foreach($params as $key => $value){
        $canonicalizedQueryString .= '&' . percentEncode($key). '=' . percentEncode($value);
    }

    $stringToSign = 'POST&%2F&' . percentEncode(substr($canonicalizedQueryString, 1));

    $signature = base64_encode(hash_hmac('sha1', $stringToSign, $AccessKeySecret."&", true));
    return $signature;
}

function percentEncode($str){
    $res = urlencode($str);
    $res = preg_replace('/\+/', '%20', $res);
    $res = preg_replace('/\*/', '%2A', $res);
    $res = preg_replace('/%7E/', '~', $res);
    return $res;
}