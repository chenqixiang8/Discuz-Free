<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/zimu_zhaopin/module/creatmember.inc.php';

$tosubmit = intval($_GET['tosubmit']);

if (IN_WECHAT) {
    $openid = $_G['cookie']['zimu_zhaopin_openid'] ? $_G['cookie']['zimu_zhaopin_openid'] : '';
    if (!$openid) {
        $tools    = new JsApiPaySF();
        $opendata = $tools->GetFollowOpenid(get_url() . '&oauth=yes');
        if ($openid = $opendata['openid']) {
            dsetcookie('zimu_zhaopin_openid', $openid, 86400);
        }
    }
    if ($openid) {
        DB::query("update %t set openid=%s where uid=%d", array(
            'zimu_zhaopin_members',
            $openid,
            $_G['uid']
        ));
    }
}


$mag_paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
    'zimu_zhaopin_parameter2',
    'magapp'
));
$mag_paramter = unserialize($mag_paramter['parameter']);

$resume_info = DB::fetch_first('select * from %t where uid=%d order by id asc', array(
    'zimu_zhaopin_resume',
    $_G['uid']
));

$rid = $resume_info['id'];

$category_jobs = DB::fetch_all('select * from %t order by c_order asc,c_id asc', array(
    'zimu_zhaopin_category'
));

foreach ($category_jobs as $key => $value) {
    
    $category_jobs2[$value['c_alias']][$value['c_id']] = $value['c_name'];
    
}

$arealist = DB::fetch_all('select * from %t where parentid=0 order by sort asc,id asc', array(
    'zimu_zhaopin_area'
));


$myuser = DB::fetch_first('select * from %t where uid=%d order by id asc', array(
    'zimu_zhaopin_members',
    $_G['uid']
));

$sms_paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
    'zimu_zhaopin_parameter2',
    'aliyunsms'
));
$sms_paramter = unserialize($sms_paramter['parameter']);

$resume_input_paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
    'zimu_zhaopin_parameter2',
    'resume_input'
));

$resume_input_paramters = unserialize($resume_input_paramter['parameter']);

if ($tosubmit == 1 && $_GET['md5hash'] == formhash()) {
    
    
    if (checkmobile() && !$myuser['telephone'] && $sms_paramter['smsAppKey']) {
        $telephone    = trim($_GET['telephone']);
        $mobile_vcode = trim($_GET['mobile_vcode']);
        if ($myuser['verify_code'] != $mobile_vcode) {
            ajaxReturn(0, $language_zimu['resume_edit_basis_inc_php_0']);
        } else {
            DB::query("update %t set telephone=%s where uid=%d", array(
                'zimu_zhaopin_members',
                $telephone,
                $_G['uid']
            ));
        }
    }
    
    $uid = $_G['uid'];
    
    $ints  = array(
        'sex',
        'birthdate',
        'education',
        'experience',
        'nature',
        'current',
        'wage'
    );
    $trims = array(
        'major',
        'district',
        'district_cn',
        'tag',
        'tag_cn',
        'telephone',
        'fullname',
        'intention_jobs_id',
        'trade'
    );
    foreach ($ints as $val) {
        if ($_GET[$val]) {
            $setsqlarr[$val] = intval($_GET[$val]);
        }
    }
    foreach ($trims as $val) {
        if ($_GET[$val]) {
            $setsqlarr[$val] = zm_diconv(trim($_GET[$val]));
        }
    }
    $resume_count == 0 && $setsqlarr['def'] = 1;
    
    $setsqlarr['uid']   = $_G['uid'];
    $setsqlarr['title'] = $language_zimu['resume_edit_basis_inc_php_1'] . date('Ymd');
    $sex                = array(
        '1' => $language_zimu['resume_edit_basis_inc_php_2'],
        '2' => $language_zimu['resume_edit_basis_inc_php_3']
    );
    if ($setsqlarr['sex']) {
        $setsqlarr['sex_cn'] = $sex[$setsqlarr['sex']];
    }
    if ($setsqlarr['education']) {
        $setsqlarr['education_cn'] = $category_jobs2['ZM_education'][$setsqlarr['education']];
    }
    if ($setsqlarr['experience']) {
        $setsqlarr['experience_cn'] = $category_jobs2['ZM_experience'][$setsqlarr['experience']];
    }
    
    if ($setsqlarr['current']) {
        $setsqlarr['current_cn'] = $category_jobs2['ZM_current'][$setsqlarr['current']];
    }
    if ($setsqlarr['nature']) {
        $setsqlarr['nature_cn'] = $category_jobs2['ZM_jobs_nature'][$setsqlarr['nature']];
    }
    
    if ($setsqlarr['trade']) {
        foreach (explode(',', $setsqlarr['trade']) as $val) {
            $trade_cn[] = $category_jobs2['ZM_trade'][$val];
        }
        $setsqlarr['trade_cn'] = implode(',', $trade_cn);
    } else {
        $trade_cn = array();
    }
    
    if ($setsqlarr['intention_jobs_id'] && $setsqlarr['intention_jobs_id'] != 0) {
        $jobs     = array();
        $jobsData = DB::fetch_all('select id,parentid,categoryname,spell from %t order by category_order desc', array(
            'zimu_zhaopin_category_jobs'
        ));
        foreach ($jobsData as $key => $val) {
            $jobs[$val['parentid']][$val['id']] = $val;
        }
        
        foreach (explode(',', $setsqlarr['intention_jobs_id']) as $val) {
            $val         = explode('.', $val);
            $intention[] = $val[2] ? $jobs[$val[1]][$val[2]]['categoryname'] : ($val[1] ? $jobs[$val[0]][$val[1]]['categoryname'] : $jobs[0][$val[0]]['categoryname']);
        }
        
        $setsqlarr['intention_jobs'] = implode(',', $intention);
        
        if ($resume_input_paramters['intention_jobs'] == 2 && $_GET['intention_jobs']) {
            $setsqlarr['intention_jobs'] = trim($_GET['intention_jobs']);
        }
    } else if ($_GET['intention_jobs']) {
        $setsqlarr['intention_jobs'] = trim($_GET['intention_jobs']);
    }
    
    if ($setsqlarr['wage']) {
        $setsqlarr['wage_cn'] = $category_jobs2['ZM_wage'][$setsqlarr['wage']];
    }
    if ($setsqlarr['major']) {
        $major     = array();
        $majorData = DB::fetch_all('select id,parentid,categoryname from %t order by parentid asc,category_order desc,id desc', array(
            'zimu_zhaopin_category_major'
        ));
        
        foreach ($majorData as $key => $val) {
            $major[$val['id']] = $val['categoryname'];
        }
        
        $setsqlarr['major_cn'] = $major[$setsqlarr['major']];
    }
    
    
    if ($setsqlarr['birthdate']) {
        $setsqlarr['age'] = date('Y') - $setsqlarr['birthdate'];
    }
    
    if (!$setsqlarr['telephone']) {
        $setsqlarr['telephone'] = addslashes($myuser['telephone']);
    }
    
    
    DB::query("update %t set telephone=%s where uid=%d", array(
        'zimu_zhaopin_members',
        $setsqlarr['telephone'],
        $_G['uid']
    ));
    
    
    if ($_GET['specialty']) {
        $setsqlarr['specialty'] = zm_diconv(zm_fomat($_GET['specialty']));
    }
    
    $setsqlarr['audit'] = 2;

    if ($_GET['logovalue']) {
        $setsqlarr['photo_img'] = addslashes($_GET['logovalue']);
        $setsqlarr['photo'] = 1;
    }

    if (!$rid) {
        
        
        $setsqlarr['addtime'] = $setsqlarr['refreshtime'] = $_G['timestamp'];
        
        $rid = $result = DB::insert('zimu_zhaopin_resume', $setsqlarr, 1);
        
        $paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
            'zimu_zhaopin_parameter2',
            'wxtpl'
        ));
        
        $paramters = unserialize($paramter['parameter']);
        
        notification_user('admin', $paramters['wxtpl_admin'], array(
            'first' => $language_zimu['resume_edit_basis_inc_php_4'],
            'keyword1' => $language_zimu['resume_edit_basis_inc_php_5'],
            'keyword2' => date('Y-m-d H:i', $_G['timestamp']),
            'remark' => $language_zimu['resume_edit_basis_inc_php_6'],
            'url' => ZIMUCMS_URL . '&model=viewresume&rid=' . $result
        ));
        
        $magcon = '{"tag":"' . $language_zimu['resume_edit_basis_inc_php_7'] . '","title":"' . $language_zimu['resume_edit_basis_inc_php_8'] . '","title_themecolor":"#ff0000","link":"' . ZIMUCMS_URL . '&model=viewresume&rid=' . $result . '","extra_info":[{"key":"' . $language_zimu['resume_edit_basis_inc_php_9'] . '","val":"' . $setsqlarr['fullname'] . '"}],"des":"' . $language_zimu['resume_edit_basis_inc_php_10'] . '","des_themecolor":"#008000"}';
        
        notification_user_magapp('admin', $magcon);
        
    } else {
        
        if ($resume_info['audit'] != $setsqlarr['audit'] && $setsqlarr['audit']) {
            
            $paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
                'zimu_zhaopin_parameter2',
                'wxtpl'
            ));
            
            $paramters = unserialize($paramter['parameter']);
            
            notification_user('admin', $paramters['wxtpl_admin'], array(
                'first' => $language_zimu['resume_edit_basis_inc_php_11'],
                'keyword1' => $language_zimu['resume_edit_basis_inc_php_12'],
                'keyword2' => date('Y-m-d H:i', $_G['timestamp']),
                'remark' => $language_zimu['resume_edit_basis_inc_php_13'],
                'url' => ZIMUCMS_URL . '&model=viewresume&rid=' . $rid
            ));
            
            $magcon = '{"tag":"' . $language_zimu['resume_edit_basis_inc_php_14'] . '","title":"' . $language_zimu['resume_edit_basis_inc_php_15'] . '","title_themecolor":"#ff0000","link":"' . ZIMUCMS_URL . '&model=viewresume&rid=' . $rid . '","extra_info":[{"key":"' . $language_zimu['resume_edit_basis_inc_php_16'] . '","val":"' . $setsqlarr['fullname'] . '"}],"des":"' . $language_zimu['resume_edit_basis_inc_php_17'] . '","des_themecolor":"#008000"}';
            
            notification_user_magapp('admin', $magcon);
            
        }
        
        
        $result = DB::update('zimu_zhaopin_resume', $setsqlarr, array(
            'id' => $rid,
            'uid' => $_G['uid']
        ));
        
    }
    
    $service_id = intval($_GET['service_id']);
    if ($service_id) {
        $service_info = DB::fetch_first('select * from %t where cat=%s and id=%d order by id desc', array(
            'zimu_zhaopin_setmeal_increment',
            'resume_stick',
            $service_id
        ));
    }
    if ($service_info) {
        $params['oid']             = date('YmdHis') . mt_rand(100000, 999999);
        $params['zpid']            = $rid;
        $params['uid']             = $_G['uid'];
        $params['openid']          = $openid;
        $params['utype']           = 2;
        $params['order_type']      = 3;
        $params['pay_type']        = 2;
        $params['is_paid']         = 1;
        $params['amount']          = $service_info['price'];
        $params['pay_amount']      = $service_info['price'];
        $params['payment']         = 'wxpay';
        $params['payment_cn']      = $language_zimu['resume_edit_basis_inc_php_18'];
        $params['description']     = $service_info['name'];
        $params['service_name']    = 'resume_stick';
        $params_array              = array(
            'days' => $service_info['value']
        );
        $params_array['resume_id'] = $rid;
        $params['params']          = serialize($params_array);
        $params['addtime']         = $_G['timestamp'];
        
        $params['setmeal'] = $service_id;
        $params['referer'] = addslashes($_GET['referer']);
        $return_order_info = DB::insert('zimu_zhaopin_order', $params, 1);
        
        ajaxReturn(1, $language_zimu['resume_edit_basis_inc_php_19'], array(
            'url' => ZIMUCMS_URL . '&model=companyservice&ac=order_detail&order_id=' . $return_order_info
        ));
        
    }
    
    
    if (!$rid) {
        ajaxReturn(1, $language_zimu['resume_edit_basis_inc_php_20'], array(
            'url' => ZIMUCMS_URL . '&model=resume_guidance&rid=' . $rid
        ));
    } else {
        ajaxReturn(1, $language_zimu['resume_edit_basis_inc_php_21'], array(
            'url' => ZIMUCMS_URL . '&model=resume_replenish&rid=' . $rid
        ));
    }
    
} else {
    
    $birthdate_arr = range(date('Y') - 16, date('Y') - 65);
    
    $userprofile = DB::fetch_first('select * from %t where uid=%d and id=%d order by id asc', array(
        'zimu_zhaopin_resume',
        $_G['uid'],
        $rid
    ));
    
    $increment_arr = DB::fetch_all('select * from %t where cat=%s order by sort asc,id desc', array(
        'zimu_zhaopin_setmeal_increment',
        'resume_stick'
    ));
    
    $tag_arr = $category_jobs2['ZM_resumetag'];
    
    $resume['tag_key'] = $resume['tag'] ? explode(',', $resume['tag']) : array();
    $resume['tag_cn']  = $resume['tag_cn'] ? explode(',', $resume['tag_cn']) : array();
    //$tag_arr = array_chunk($tags,12,true);
    
    include zimu_template('resume_edit_basis');
    
}