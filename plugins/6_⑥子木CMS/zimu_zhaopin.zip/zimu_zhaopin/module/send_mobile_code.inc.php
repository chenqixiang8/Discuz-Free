<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

        isuid();

        $mobile=I('mobile','','trim');

        $user = DB::fetch_first('select * from %t where telephone=%s order by id desc', array(
                'zimu_zhaopin_members',
                $mobile
            ));

        if($user['telephone'] && $user['telephone'] == $mobile) ajaxReturn(0,$language_zimu['send_mobile_code_inc_php_0'].$mobile.$language_zimu['send_mobile_code_inc_php_1']);

        if(getcookie('verify_mobile_time') && ($_G['timestamp']-getcookie('verify_mobile_time'))<60){
             ajaxReturn(0,$language_zimu['send_mobile_code_inc_php_2'].'180'.$language_zimu['send_mobile_code_inc_php_3']);
        }

        $rand = mt_rand(1000, 9999);

    $sms_paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
        'zimu_zhaopin_parameter2',
        'aliyunsms'
    ));
    $sms_paramter = unserialize($sms_paramter['parameter']);

    $app_key = $sms_paramter['smsAppKey']; 
    $app_secret = $sms_paramter['smssecretKey']; 
    $sign_name = mb_convert_encoding($sms_paramter['smsFreeSignName'],'UTF-8',CHARSET);
    $smsdata['code'] = $rand;

    $requestUrl = "http://dysmsapi.aliyuncs.com/";
    $params['PhoneNumbers']= $mobile;
    $params['SignName']= $sign_name;
    if(isMobile($mobile)){
    $params['TemplateCode']= $sms_paramter['smsTemplateCode'];
    }else{
    $params['TemplateCode']= $sms_paramter['smsTemplateCode2'];
    }
    $params['TemplateParam']= json_encode($smsdata);
    $params['OutId']= "3333";
    $params['RegionId']= "cn-hangzhou";
    $params['AccessKeyId']= $app_key;
    $params['Format']= "JSON";
    $params['SignatureMethod']= "HMAC-SHA1";
    $params['SignatureVersion']= "1.0";
    $params['SignatureNonce']= uniqid();
    date_default_timezone_set("GMT");
    $params['Timestamp']= date("Y-m-d\TH:i:s\Z");
    $params['Action']= "SendSms";
    $params['Version']= "2017-05-25";
    $params['Signature']= aliyun_signature($params,$app_secret);

    include_once DISCUZ_ROOT . './source/plugin/zimu_zhaopin/class/Aliyun_HttpHelper.class.php';

    $Aliyun_HttpHelper = new Aliyun_HttpHelper();
    $result = $Aliyun_HttpHelper->curl($requestUrl,'POST',$params,array('x-sdk-client' => 'php/2.0.0'));

    $aaa = object_array(json_decode($result));

        if ($aaa['alibaba_aliqin_fc_sms_num_send_response']['result']['success'] == 1 || $aaa['success'] == 1 || $aaa['Code'] == 'OK') {

    DB::query("update %t set verify_code=%d where uid=%d", array(
        'zimu_zhaopin_members',
        $rand,
        $_G['uid'],
    ));

    dsetcookie('verify_mobile_time',$_G['timestamp'],7200);

            ajaxReturn(1,$language_zimu['send_mobile_code_inc_php_6']);
        }else{
            ajaxReturn(0,mb_convert_encoding($aaa['Message'], CHARSET, 'UTF-8'));
        }

function aliyun_signature($params,$AccessKeySecret){
    ksort($params);

    $canonicalizedQueryString = '';
    foreach($params as $key => $value){
        $canonicalizedQueryString .= '&' . percentEncode($key). '=' . percentEncode($value);
    }

    $stringToSign = 'POST&%2F&' . percentEncode(substr($canonicalizedQueryString, 1));

    $signature = base64_encode(hash_hmac('sha1', $stringToSign, $AccessKeySecret."&", true));
    return $signature;
}

function percentEncode($str){
    $res = urlencode($str);
    $res = preg_replace('/\+/', '%20', $res);
    $res = preg_replace('/\*/', '%2A', $res);
    $res = preg_replace('/%7E/', '~', $res);
    return $res;
}