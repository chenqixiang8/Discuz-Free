<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

isuid();

$ac       = addslashes($_GET['ac']);
$tosubmit = intval($_GET['tosubmit']);


if($ac == 'jobs_favorites' ){

$jid = intval($_GET['jid']);

        !$jid && ajaxReturn(0,$language_zimu['ajaxpersonal_inc_php_0']);
        $has = DB::fetch_first('select * from %t where personal_uid=%d and jobs_id=%d order by did desc', array(
                'zimu_zhaopin_personal_favorites',
                $_G['uid'],
                $jid
            ));

        if($has){

            DB::delete('zimu_zhaopin_personal_favorites', array(
                'personal_uid' => $_G['uid'],
                'jobs_id' => $jid
            ));

        ajaxReturn(1,$language_zimu['ajaxpersonal_inc_php_1'],'cancel');

        }else{

        $jobsinfo = DB::fetch_first('select * from %t where id=%d order by id asc', array(
            'zimu_zhaopin_jobs',
            $jid
        ));  

        $data['personal_uid']       = $_G['uid'];
        $data['jobs_id']        = $jid;
        $data['jobs_name']       = $jobsinfo['jobs_name'];
        $data['company_id']       = $jobsinfo['company_id'];
        $data['company_name']       = $jobsinfo['companyname'];
        $data['company_uid']       = $jobsinfo['uid'];
        $data['addtime']     = $_G['timestamp'];

        DB::insert('zimu_zhaopin_personal_favorites', $data);

            ajaxReturn(1,$language_zimu['ajaxpersonal_inc_php_2']);
        }

}elseif($ac == 'resume_apply' ){

        $jid = intval($_GET['jid']);
        !$jid && ajaxReturn(0,$language_zimu['ajaxpersonal_inc_php_3']);


        $resume_info = DB::fetch_first('select * from %t where uid=%d order by id asc', array(
            'zimu_zhaopin_resume',
            $_G['uid']
        ));  

        if($zmdata['settings']['resume_tocomtel'] && $resume_info && $resume_info['audit'] !=1 ){
            if($resume_info['audit']==3){
            ajaxReturn(1,$language_zimu['ajaxpersonal_inc_php_4'].'<br>'.$resume_info['wxtpl'].'<br>'.$language_zimu['ajaxpersonal_inc_php_5'].'<img style="width:200px;" src="'.$zmdata['settings']['kefu_qrcode_url'].'"><p style="color:#ff552e;font-size:15px;">'.$language_zimu['ajaxpersonal_inc_php_6'].'</p>','no');
            }else{
            ajaxReturn(1,$language_zimu['ajaxpersonal_inc_php_7'].'<br>'.$language_zimu['ajaxpersonal_inc_php_8'].'<br><img style="width:200px;" src="'.$zmdata['settings']['kefu_qrcode_url'].'"><p style="color:#ff552e;font-size:15px;">'.$language_zimu['ajaxpersonal_inc_php_9'].'</p>','no');
            }
        }


        $isapply = DB::fetch_first('select * from %t where personal_uid=%d and jobs_id=%d order by did desc', array(
                'zimu_zhaopin_personal_jobs_apply',
                $_G['uid'],
                $jid
            ));
   
        if($isapply){
            ajaxReturn(0,$language_zimu['ajaxpersonal_inc_php_10']);
        }


        $today_total = DB::result_first("SELECT count(*) FROM %t where personal_uid=%d and apply_addtime>%d", array(
            "zimu_zhaopin_personal_jobs_apply",
            $_G['uid'],
            strtotime(date('Y-m-d', $_G['timestamp']))
        ));

        if($zmdata['settings']['max_apply_jobs'] && $today_total >= $zmdata['settings']['max_apply_jobs']){
            ajaxReturn(0,$language_zimu['ajaxpersonal_inc_php_11'].$zmdata['settings']['max_apply_jobs'].$language_zimu['ajaxpersonal_inc_php_12']);
        }

        $isresume = DB::fetch_first('select * from %t where uid=%d order by id desc', array(
                'zimu_zhaopin_resume',
                $_G['uid']
            ));
 
        if(!$isresume){
            ajaxReturn(0,$language_zimu['ajaxpersonal_inc_php_13'],'noresume');
        }
        if($isresume['audit']==3){
            ajaxReturn(0,$language_zimu['ajaxpersonal_inc_php_14'],'noresume');
        }

        $data['resume_id']       = $isresume['id'];
        $data['resume_name']        = $isresume['title'];
        $data['personal_uid']     = $_G['uid'];
        $data['jobs_id']       = $jid;
        $data['jobs_name']       = addslashes(zm_diconv($_GET['jidname']));
        $data['company_id']       = intval($_GET['comid']);
        $data['company_name']       = addslashes(zm_diconv($_GET['comname']));
        $data['company_uid']       = intval($_GET['comuid']);
        $data['apply_addtime']       = $_G['timestamp'];
        $data['is_apply']       = 2;

        if(!$data['jobs_name']){
                $jobsinfo = DB::fetch_first('select * from %t where id=%d order by id asc', array(
                    'zimu_zhaopin_jobs',
                    $jid
                ));
                $data['jobs_name']       = $jobsinfo['jobs_name'];
                $data['company_id']       = $jobsinfo['company_id'];
                $data['company_name']       = $jobsinfo['companyname'];
                $data['company_uid']       = $jobsinfo['uid'];
        }


        DB::insert('zimu_zhaopin_personal_jobs_apply', $data);

        $company_profile = DB::fetch_first('select * from %t where id=%d order by id asc', array(
            'zimu_zhaopin_company_profile',
            $data['company_id']
        )); 

        $tip = $resume_info['fullname'].$language_zimu['ajaxpersonal_inc_php_15'];

        notification_user_sms($company_profile['telephone'],'chanyoo_sms_tp1',$tip);

        DB::query("update %t set refreshtime=%d where uid=%d", array(
            'zimu_zhaopin_resume',
            $_G['timestamp'],
            $_G['uid']
        ));

        $setsqlarr2['uid'] = $_G['uid'];
        $setsqlarr2['mode'] = 0;
        $setsqlarr2['addtime'] = $_G['timestamp'];
        $setsqlarr2['type'] = 2001;
        DB::insert('zimu_zhaopin_refresh_log', $setsqlarr2, 1);


    $paramter = DB::fetch_first('select * from %t where name=%s order by id desc', array(
        'zimu_zhaopin_parameter2',
        'wxtpl'
    ));

    $paramters = unserialize($paramter['parameter']);
    
    notification_user($data['company_uid'],$paramters['wxtpl_jobs_apply'],array('first'=>$language_zimu['ajaxpersonal_inc_php_16'].$data['jobs_name'].' '.$language_zimu['ajaxpersonal_inc_php_17'],'keyword1'=>$isresume['fullname'],'keyword2'=>$isresume['education_cn'],'keyword3'=>$isresume['experience_cn'],'keyword4'=>$isresume['district_cn'],'keyword5'=>$isresume['wage_cn'],'remark'=>$language_zimu['ajaxpersonal_inc_php_18'].$zmdata['base']['title'].$language_zimu['ajaxpersonal_inc_php_19'],'url'=>ZIMUCMS_URL.'&model=company&ac=jobs_apply'));


$magcon = '{"tag":"'.$language_zimu['ajaxpersonal_inc_php_20'].'","title":"'.$language_zimu['ajaxpersonal_inc_php_21'].$data['jobs_name'].$language_zimu['ajaxpersonal_inc_php_22'].'","title_themecolor":"#ff0000","link":"'.ZIMUCMS_URL.'&model=company&ac=jobs_apply","extra_info":[{"key":"'.$language_zimu['ajaxpersonal_inc_php_23'].'","val":"'.$isresume['fullname'].'"},{"key":"'.$language_zimu['ajaxpersonal_inc_php_24'].'","val":"'.$isresume['education_cn'].'"},{"key":"'.$language_zimu['ajaxpersonal_inc_php_25'].'","val":"'.$isresume['experience_cn'].'"},{"key":"'.$language_zimu['ajaxpersonal_inc_php_26'].'","val":"'.$isresume['district_cn'].'"},{"key":"'.$language_zimu['ajaxpersonal_inc_php_27'].'","val":"'.$isresume['wage_cn'].'"}],"des":"'.$language_zimu['ajaxpersonal_inc_php_28'].'","des_themecolor":"#008000"}';

    notification_user_magapp($data['company_uid'],$magcon);


        ajaxReturn(1,$language_zimu['ajaxpersonal_inc_php_29']);

}elseif($ac == 'company_focus' ){

        $company_id = intval($_GET['company_id']);

        if(!$company_id){
            ajaxReturn(0,$language_zimu['ajaxpersonal_inc_php_30']);
        }

        $has = DB::fetch_first('select * from %t where uid=%d and company_id=%d order by id desc', array(
                'zimu_zhaopin_personal_focus_company',
                $_G['uid'],
                $company_id
            ));

        if($has){

            DB::delete('zimu_zhaopin_personal_focus_company', array(
                'uid' => $_G['uid'],
                'company_id' => $company_id
            ));

        ajaxReturn(1,$language_zimu['ajaxpersonal_inc_php_31'],array('html'=>$language_zimu['ajaxpersonal_inc_php_32'],'op'=>2));

        }else{

        $data['uid']       = $_G['uid'];
        $data['company_id']        = $company_id;
        $data['addtime']     = $_G['timestamp'];

        DB::insert('zimu_zhaopin_personal_focus_company', $data);

        ajaxReturn(1,$language_zimu['ajaxpersonal_inc_php_33'],array('html'=>$language_zimu['ajaxpersonal_inc_php_34'],'op'=>1));
        
        }


}