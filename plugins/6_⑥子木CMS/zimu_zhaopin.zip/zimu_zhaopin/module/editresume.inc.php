<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

isuid();

$jid = intval($_GET['jid']);

$jobdata = DB::fetch_first('select * from %t where id=%d order by id asc', array(
        'zimu_zhaopin_jobs',
        $jid
    ));

$companydata = DB::fetch_first('select * from %t where id=%d order by id asc', array(
        'zimu_zhaopin_company_profile',
        $jobdata['company_id']
    ));

$index_job = DB::fetch_all('select * from %t order by id desc', array(
        'zimu_zhaopin_jobs'
    ));

include zimu_template('editresume');