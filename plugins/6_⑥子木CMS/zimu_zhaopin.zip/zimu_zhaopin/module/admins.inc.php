<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(!$_G['uid']){

if(!$zmdata['settings']['weixin_login_url']){

isuid();
exit();

}else{

dheader('Location:' . $_G['siteurl'] . 'plugin.php?id=zimu_zhaopin&model=login&referer=' . urlencode(ZIMUCMS_URL.'&model=admins'));
exit();

}

}

$type = addslashes($_GET['type']);
$type = !empty($type) ? $type : 'dashboard';

$ac = addslashes($_GET['ac']);
$ac = !empty($ac) ? $ac : 'index';

$manage_groups = explode(';', $zmdata['manage_uids']);

foreach ($manage_groups as $key => $value) {
  $manage_uids[$key] = explode(',', $value);
}

if(!in_array($_G['uid'],$manage_uids[0]) && !in_array($_G['uid'],$manage_uids[1])){
echo 'error';exit();
}

if(in_array($_G['uid'],$manage_uids[0])){
$manage_type = 'admins';
}else{
$manage_type = 'operator';
}

$title = $zmdata['base']['title'].$language_zimu['admins_inc_php_0'];

if($type){
    include DISCUZ_ROOT.'./source/plugin/zimu_zhaopin/module/admins/admins_'.$type.'.inc.php';
}