<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}


$resume_info = DB::fetch_first('select * from %t where uid=%d order by id asc', array(
        'zimu_zhaopin_resume',
        $_G['uid']
    ));

if(!$resume_info){

dheader('Location: '.ZIMUCMS_URL.'&model=resume_edit_basis');

}


$rid = $resume_info['id'];


$tosubmit = intval($_GET['tosubmit']);

$category_jobs = DB::fetch_all('select * from %t order by c_order asc,c_id asc', array(
        'zimu_zhaopin_category'
    ));

foreach ($category_jobs as $key => $value) {

$category_jobs2[$value['c_alias']][$value['c_id']] = $value['c_name'];

}


if($tosubmit == 1 && $_GET['md5hash'] == formhash() ){


            $uid = $_G['uid'];

            $ints = array('sex','birthdate','education','experience','nature','current','wage');
            $trims = array('district','telephone','fullname','email','intention_jobs_id','trade');
            foreach ($ints as $val) {
                $setsqlarr[$val] = intval($_GET[$val]);
            }
            foreach ($trims as $val) {
                $setsqlarr[$val] = trim($_GET[$val]);
            }
            $resume_count == 0 && $setsqlarr['def'] = 1;
            $setsqlarr['display_name'] = 1;

            $setsqlarr['title'] = $language_zimu['resume_replenish_edu_inc_php_0'].date('Ymd');
            $sex = array('1'=>$language_zimu['resume_replenish_edu_inc_php_1'],'2'=>$language_zimu['resume_replenish_edu_inc_php_2']);
            $setsqlarr['sex_cn']             = $sex[$setsqlarr['sex']];
            $setsqlarr['education_cn']       = $category_jobs2['ZM_education'][$setsqlarr['education']];
            $setsqlarr['experience_cn']       = $category_jobs2['ZM_experience'][$setsqlarr['experience']];
            $setsqlarr['current_cn']       = $category_jobs2['ZM_current'][$setsqlarr['current']];
            $setsqlarr['nature_cn']       = $category_jobs2['ZM_jobs_nature'][$setsqlarr['nature']];

            if($setsqlarr['trade']){
                foreach(explode(',',$setsqlarr['trade']) as $val) {
                    $trade_cn[] = $category_jobs2['ZM_trade'][$val];
                }
            }else{
                $trade_cn = array();
            }
            $setsqlarr['trade_cn']           = implode(',',$trade_cn);


            $jobs = array();
            $jobsData = DB::fetch_all('select id,parentid,categoryname,spell from %t order by category_order desc', array(
                'zimu_zhaopin_category_jobs'
            ));
            foreach ($jobsData as $key => $val) {
                $jobs[$val['parentid']][$val['id']] = $val;
            }

            foreach(explode(',',$setsqlarr['intention_jobs_id']) as $val) {
                $val = explode('.',$val);
                $intention[] = $val[2] ? $jobs[$val[1]][$val[2]]['categoryname'] : ($val[1] ? $jobs[$val[0]][$val[1]]['categoryname'] : $jobs[0][$val[0]]['categoryname']);
            }

            $setsqlarr['intention_jobs']     = implode(',',$intention);

            $setsqlarr['wage_cn']       = $category_jobs2['ZM_wage'][$setsqlarr['wage']];



            $district = array();
            $districtData = DB::fetch_all('select id,parentid,categoryname from %t order by category_order desc,id asc', array(
                'zimu_zhaopin_category_district'
            ));
            foreach ($districtData as $key => $val) {
                $district[$val['parentid']][$val['id']] = $val['categoryname'];
            }

            foreach(explode(',',$setsqlarr['district']) as $val) {
                $val = explode('.',$val);
                $district_cn[] = $val[2] ? $district[$val[1]][$val[2]] : ($val[1] ? $district[$val[0]][$val[1]] : $district[0][$val[0]]);
            }

            $setsqlarr['district_cn']        = implode(',',$district_cn);

            $setsqlarr['audit']        = 2;

            $setsqlarr['uid'] = $uid;

            $result = DB::insert('zimu_zhaopin_resume', $setsqlarr, 1);


            echo ajaxReturn(1,$language_zimu['resume_replenish_edu_inc_php_3'],array('url'=>ZIMUCMS_URL.'&model=resume_replenish&rid='.$result));
            exit();

}else{

$birthdate_arr = range(date('Y')-16,date('Y')-65);

$resume = DB::fetch_first('select * from %t where uid=%d and id=%d order by id asc', array(
        'zimu_zhaopin_resume',
        $_G['uid'],
        $rid
    ));

            $resume['work'] = DB::fetch_all('select * from %t where uid=%d and pid=%d order by id asc', array(
                'zimu_zhaopin_resume_work',
                $_G['uid'],
                $rid
            ));

            $resume['educationlist'] = DB::fetch_all('select * from %t where uid=%d and pid=%d order by id asc', array(
                'zimu_zhaopin_resume_education',
                $_G['uid'],
                $rid
            ));

            $info = DB::fetch_first('select * from %t where uid=%d and pid=%d order by id asc', array(
                'zimu_zhaopin_resume_training',
                $_G['uid'],
                $rid
            ));

        $info && $resume['train'] = 1;

            $info = DB::fetch_first('select * from %t where uid=%d and pid=%d order by id asc', array(
                'zimu_zhaopin_resume_credent',
                $_G['uid'],
                $rid
            ));

        $info && $resume['certificate'] = 1;


            $info = DB::fetch_first('select * from %t where uid=%d and pid=%d order by id asc', array(
                'zimu_zhaopin_resume_language',
                $_G['uid'],
                $rid
            ));

        $info && $resume['lang'] = 1;

            $resume['resume_img'] = DB::fetch_all('select * from %t where uid=%d and resume_id=%d order by id asc', array(
                'zimu_zhaopin_resume_img',
                $_G['uid'],
                $rid
            ));

include zimu_template('resume_replenish_edu');

}