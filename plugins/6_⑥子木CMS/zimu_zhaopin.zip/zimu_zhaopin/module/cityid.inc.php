<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}



$district = DB::fetch_all('select * from %t where parentid != 0 order by id asc', array(
        'zimu_zhaopin_category_district'
    ));


foreach($district as $key=>$val) {

echo $val['categoryname'].'ID:'.$val['id'].'<br>';

}