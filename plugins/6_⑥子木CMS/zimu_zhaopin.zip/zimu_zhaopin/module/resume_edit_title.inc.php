<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$tosubmit = intval($_GET['tosubmit']);
$rid = intval($_GET['rid']);
$title = addslashes($_GET['title']);

if($tosubmit == 1 && $_GET['md5hash'] == formhash() ){


            $uid = $_G['uid'];

    DB::query("update %t set title=%s where id=%d and uid=%d", array(
        'zimu_zhaopin_resume',
        $title,
        $rid,
        $uid
    ));

            echo ajaxReturn(1,$language_zimu['resume_edit_title_inc_php_0']);
            exit();

}