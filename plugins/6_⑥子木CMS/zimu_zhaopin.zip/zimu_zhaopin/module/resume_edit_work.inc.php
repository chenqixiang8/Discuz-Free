<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$tosubmit = intval($_GET['tosubmit']);
$wid = intval($_GET['wid']);

if($tosubmit == 1 && $_GET['md5hash'] == formhash() ){

$pid = intval($_GET['pid']);

            $uid = $_G['uid'];

            $setsqlarr['uid'] = $uid;
            $setsqlarr['companyname'] = zm_diconv(trim($_GET['companyname']));
            $setsqlarr['achievements'] = zm_diconv(trim($_GET['achievements']));
            $setsqlarr['jobs'] = zm_diconv(trim($_GET['jobs']));
            $setsqlarr['startyear'] = intval($_GET['startyear']);
            $setsqlarr['startmonth'] = intval($_GET['startmonth']);
            $setsqlarr['endyear'] = intval($_GET['endyear']);
            $setsqlarr['endmonth'] = intval($_GET['endmonth']);
            $setsqlarr['todate'] = intval($_GET['todate']);

            if ($setsqlarr['todate'] == 1) {
                if(!$setsqlarr['startyear'] || !$setsqlarr['startmonth']) ajaxReturn(0,$language_zimu['resume_edit_work_inc_php_0']);
                if($setsqlarr['startyear'] > intval(date('Y'))) ajaxReturn(0,$language_zimu['resume_edit_work_inc_php_1']);
                if($setsqlarr['startyear'] == intval(date('Y')) && $setsqlarr['startmonth'] >= intval(date('m'))) ajaxReturn(0,$language_zimu['resume_edit_work_inc_php_2']);
            } else {
                if(!$setsqlarr['startyear'] || !$setsqlarr['startmonth'] || !$setsqlarr['endyear'] || !$setsqlarr['endmonth']) ajaxReturn(0,$language_zimu['resume_edit_work_inc_php_3']);

                if($setsqlarr['startyear'] > intval(date('Y'))) ajaxReturn(0,$language_zimu['resume_edit_work_inc_php_4']);
                if($setsqlarr['startyear'] == intval(date('Y')) && $setsqlarr['startmonth'] >= intval(date('m'))) ajaxReturn(0,$language_zimu['resume_edit_work_inc_php_5']);
                if($setsqlarr['endyear'] > intval(date('Y'))) ajaxReturn(0,$language_zimu['resume_edit_work_inc_php_6']);
                if($setsqlarr['endyear'] == intval(date('Y')) && $setsqlarr['endmonth'] > intval(date('m'))) ajaxReturn(0,$language_zimu['resume_edit_work_inc_php_7']);
                
                if($setsqlarr['startyear'] > $setsqlarr['endyear']) ajaxReturn(0,$language_zimu['resume_edit_work_inc_php_8']);
                if($setsqlarr['startyear'] == $setsqlarr['endyear'] && $setsqlarr['startmonth'] >= $setsqlarr['endmonth']) ajaxReturn(0,$language_zimu['resume_edit_work_inc_php_9']);
            }

            if(!$pid) ajaxReturn(0,$language_zimu['resume_edit_work_inc_php_10']);
            $setsqlarr['pid'] = $pid;

            $work = DB::fetch_all('select * from %t where uid=%d and pid=%d order by id asc', array(
                'zimu_zhaopin_resume_work',
                $_G['uid'],
                $pid
            ));

            if(count($work)>=6) ajaxReturn(0,$language_zimu['resume_edit_work_inc_php_11']);
            if(!$wid){
   
            $result = DB::insert('zimu_zhaopin_resume_work', $setsqlarr, 1);

            $news = intval($_GET['news']);
            
            if($news==1){

            $html = '<div class="expmod " type="work">
        <div class="exptr1 substring">'.$setsqlarr['companyname'].'<span class="font13"></span></div>
        <div class="exptr2 substring font13 ">'.$setsqlarr['jobs'].'&nbsp;|&nbsp;'.$setsqlarr['startyear'].'-'.$setsqlarr['startmonth'].' '.$language_zimu['resume_edit_work_inc_php_12'].' '.$setsqlarr['endyear'].'-'.$setsqlarr['endmonth'].'</div>
        <div class="exptr3 font12">'.$setsqlarr['achievements'].'</div></div>';

                ajaxReturn(1,$language_zimu['resume_edit_work_inc_php_13'],array('url'=>ZIMUCMS_URL.'&model=resume_guidance&rid='.$pid,'html'=>$html));

            }else{
                ajaxReturn(1,$language_zimu['resume_edit_work_inc_php_14'],array('url'=>ZIMUCMS_URL.'&model=resume_replenish_work&rid='.$pid));
            }
            exit();

            }else{

            $setsqlarr['id'] = $wid;
            
            $result = DB::update('zimu_zhaopin_resume_work', $setsqlarr, array(
                'id' => $wid,
                'uid' => $uid,
                'pid' => $pid,
            ));

            ajaxReturn(1,$language_zimu['resume_edit_work_inc_php_15'],array('url'=>ZIMUCMS_URL.'&model=resume_replenish_work&rid='.$pid));
            exit();

            }

}else{

$pid = intval($_GET['rid']);

$info = DB::fetch_first('select * from %t where uid=%d and id=%d and pid=%d order by id asc', array(
        'zimu_zhaopin_resume_work',
        $_G['uid'],
        $wid,
        $pid
    ));

include zimu_template('resume_edit_work');

}