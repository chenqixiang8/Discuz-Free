<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$wherearr = array();
$cid = intval($_GET['cid']);
if($cid){
$wherearr[]=' cid= '.$cid.' ';
}


$wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';

$pindex = max(1, intval($_GET['page']));
$psize = 10;


$catdata = DB::fetch_all('select * from %t order by id asc', array(
	'zimu_zhaopin_news_cat'
));

$newslist = DB::fetch_all('select * from %t %i order by id desc limit %d,%d', array(
    'zimu_zhaopin_news',
    $wheresql,
	($pindex - 1) * $psize,
	$psize
));


$total = DB::result_first("SELECT count(*) FROM %t %i", array(
    "zimu_zhaopin_news",
    $wheresql,
    $_G['timestamp'],
));

$totalPages = ceil($total/$psize);

$pager = pagination($total, $pindex, $psize);

$randnews = DB::fetch_all('select * from %t order by rand() limit 30', array(
    'zimu_zhaopin_news'
));

$navtitle = $share_title = $zmdata['settings']['news_seo_title'] ? $zmdata['settings']['news_seo_title'] : $navtitle;
$keywords = $zmdata['settings']['news_seo_keyword'] ? $zmdata['settings']['news_seo_keyword'] : $navtitle;
$description = $share_desc = $zmdata['settings']['news_seo_desc'] ? $zmdata['settings']['news_seo_desc'] : $navtitle;

include zimu_template('news');