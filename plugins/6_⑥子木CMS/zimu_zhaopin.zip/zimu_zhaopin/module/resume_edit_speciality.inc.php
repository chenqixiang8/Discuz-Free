<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$tosubmit = intval($_GET['tosubmit']);
$wid = intval($_GET['wid']);


$category = array();

$categoryData = DB::fetch_all('select c_id,c_alias,c_name from %t order by c_order asc,c_id asc', array(
    'zimu_zhaopin_category'
));

foreach ($categoryData as $key=>$val){
    $category[$val['c_alias']][$val['c_id']] = $val['c_name'];
}

$tags = $category['ZM_resumetag'];

if($tosubmit == 1 && $_GET['md5hash'] == formhash() ){

$pid = intval($_GET['pid']);

            $uid = $_G['uid'];

            $tag_cn = I('tag_cn','','trim');
            $setarr['tag_cn']=$tag_cn?implode(",", $tag_cn):'';
            $tag=$_GET['tag'];
            $setarr['tag']=$tag?implode(",", $tag):'';
            foreach ($tag as $key => $val) {
                $setarr['tag_cn'].=",{$tags[$val]}";
            }
            $setarr['tag_cn'] = ltrim($setarr['tag_cn'],',');

            if($pid){

            $setarr['id'] = $pid;

            $result = DB::update('zimu_zhaopin_resume', $setarr, array(
                'id' => $pid,
                'uid' => $uid
            ));

            }

            ajaxReturn(1,$language_zimu['resume_edit_speciality_inc_php_0'],array('url'=>ZIMUCMS_URL.'&model=resume_replenish&rid='.$pid));
            exit();


}else{

$pid = intval($_GET['rid']);

$resume = DB::fetch_first('select * from %t where uid=%d and id=%d order by id asc', array(
        'zimu_zhaopin_resume',
        $_G['uid'],
        $pid
    ));

        $resume['tag_key'] = $resume['tag']?explode(',',$resume['tag']):array();
        $resume['tag_cn'] = $resume['tag_cn']?explode(',',$resume['tag_cn']):array();
        $tag_arr = array_chunk($tags,12,true);

include zimu_template('resume_edit_speciality');

}