<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

    class QF_HTTP_CLIENT
    {
        private $hostname;
        private $token;

        public function __construct($hostname=null,$token = null) {
            $this->hostname = $hostname;
            $this->token = $token;
        }

        /**
         * @param string $method ����ʽ
         * @param string $path ����·��
         * @param array $requestBody ���������
         * @return array
         * @throws Exception
         */
        private function _request($method, $path, $requestBody)
        {
            $header = array(
                "Authorization: Bearer {$this->token}",
                "Content-Type: application/x-www-form-urlencoded",
                "Cache-Control: no-cache",
                "Accept: application/json",
                "User-Agent: QianFanHttpClient/1.0.0"
            );
            $url = "https://{$this->hostname}.qianfanapi.com/openapi/{$path}";
            $curlHandle = curl_init();
            curl_setopt($curlHandle, CURLOPT_URL, $url);
            curl_setopt($curlHandle, CURLOPT_HEADER, 0);
            curl_setopt($curlHandle, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($curlHandle, CURLOPT_HTTPHEADER, $header);
            curl_setopt($curlHandle, CURLOPT_SSL_VERIFYPEER, 0);
            curl_setopt($curlHandle, CURLOPT_SSL_VERIFYHOST, 0);
            curl_setopt($curlHandle, CURLOPT_CUSTOMREQUEST, $method);
            if (count($requestBody)) {
                curl_setopt($curlHandle, CURLOPT_POST, 1);
                curl_setopt($curlHandle, CURLOPT_POSTFIELDS, http_build_query($requestBody));
            }
            curl_setopt($curlHandle, CURLOPT_CONNECTTIMEOUT, 2); // ���ӳ�ʱ
            curl_setopt($curlHandle, CURLOPT_TIMEOUT, 2); // ��Ӧ��ʱ

            $response = curl_exec($curlHandle);
            $error = curl_error($curlHandle);
            $errno = curl_errno($curlHandle);
            // $status = curl_getinfo($curlHandle, CURLINFO_HTTP_CODE);
            curl_close($curlHandle);

            if ($error) {
                throw new Exception("cURL Error #{$errno}. $error", 1);
            }

            $data = json_decode($response, true);
            if (json_last_error() != JSON_ERROR_NONE) {
                $error = json_last_error_msg();
                $errno = json_last_error();
                throw new Exception("Json Parsing Error #{$errno}. $error", 1);
            }
            return $data;
        }

        public function get($path)
        {
            return $this->_request('GET', $path, []);
        }

        public function put($path, $data)
        {
            return $this->_request('PUT', $path, $data);
        }

        public function post($path, $data)
        {
            return $this->_request('POST', $path, $data);
        }

        public function delete($path, $data)
        {
            return $this->_request('DELETE', $path, $data);
        }
    }
