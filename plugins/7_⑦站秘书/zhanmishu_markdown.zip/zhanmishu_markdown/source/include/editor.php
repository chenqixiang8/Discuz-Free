<?php


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if (!class_exists('zhanmishu_markdown_controller',false)) {
    C::import('zhanmishu_markdown_controller','plugin/zhanmishu_markdown/source/controller');
}

 $markdownHander =  new zhanmishu_markdown_controller();
 $markdownConfig = $markdownHander->config;
 $markdownConfig['uploadOutline'] = $markdownConfig['uploadOutline'] ? true : false;
 $markdownConfig['viewType'] = $markdownConfig['viewType'] ? $markdownConfig['viewType'] : 'ir';

 