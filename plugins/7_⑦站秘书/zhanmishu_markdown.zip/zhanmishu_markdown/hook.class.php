<?php


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if (!class_exists('zhanmishu_markdown_controller',false)) {
    C::import('zhanmishu_markdown_controller','plugin/zhanmishu_markdown/source/controller');
}
if (!class_exists('XssHtml',false)) {
    C::import('XssHtml','plugin/zhanmishu_markdown/source/class');
}

/**
 * 本程序功能基类
 * 
 */
class plugin_zhanmishu_markdown_base
{
    public function parseHander(){
        return new zhanmishu_markdown_controller();
    }
    public static function isIE() {
        $isIE = strpos($_SERVER['HTTP_USER_AGENT'],"Triden");
        return $isIE;  
    }

    public function cleanXss($html = '') {
        if(!$html) {
            return '';
        }
        $xss = new XssHtml(zhanmishu_app::auto_charset_change($html, CHARSET, 'utf-8'));
        $html = $xss->getHtml();

        return zhanmishu_app::auto_charset_change($html, 'utf-8', CHARSET);
    }
}

/**
 * PC版本嵌入点
 */
class plugin_zhanmishu_markdown extends plugin_zhanmishu_markdown_base {

}

/**
 * PC版本嵌入点
 */
class plugin_zhanmishu_markdown_forum extends plugin_zhanmishu_markdown {
    // function post_attribute_extra(){
    //     return '<label id="extra_filebuy_b" onclick="showExtra(\'extra_filebuy\')"><span id="extra_filebuy_chk">'.lang('plugin/zhanmishu_markdown','pay_buy').'</span></label>';
    // }
    function viewthread_postbottom_output(){
        global $postlist;
        global $_G;

        include libfile('function/editor');

        foreach($postlist as $k=>$post){
            // echo $post['message'];die;
            $pattern= "/\[md\](.*)\[\/md\]/is";
            $isMd = preg_match($pattern, $post['message'] , $MarkdownReturn);
            if ($isMd) {
                $message = C::t('forum_post')->fetch('tid:'.$post['tid'], $post['pid'], true);
                

                $mdMessage = substr($message['message'], 4, -5);
                // 移除url标签、video标签、audio标签等
                $mdMessage = $this->cleanXss($mdMessage);
                
                $mdMessage = preg_replace("/\[audio\](.*?)\[\/audio\]/", "$1", $mdMessage);
                $mdMessage = preg_replace("/\[url\](.*?)\[\/url\]/", "$1", $mdMessage);
                $mdMessage = preg_replace("/\[video\](.*?)\[\/video\]/", "$1", $mdMessage);
                $mdMessage = preg_replace("/\[flash\](.*?)\[\/flash\]/", "$1", $mdMessage);
                $mdMessage = preg_replace("/\[media\](.*?)\[\/media\]/", "$1", $mdMessage);

                if (IS_ROBOT || self::isIE() || $this->parseHander()->config['markParse'] == '1') {
                    $replace = '<div class="vditor-reset">'.zhanmishu_markdown_controller::markdownParse($mdMessage).'<div>';
                }else{
                    $replace = '<textarea style="display:none;" class="markdownContent vditor-reset" cols="30" rows="10">'.$mdMessage.'</textarea>';
                }
                $post['message'] = $replace;
                $remoteHost = $_G['setting']['ftp']['attachurl'];
                if(substr($remoteHost, -1) == '/'){
                    $remoteHost = substr($remoteHost, 0, -1);
                }
                if (!empty($post['attachments'])) {
                    foreach ($post['attachments'] as $attach) {
                        if (strpos($post['message'], $attach['attachment'])) {
                            
                            if($attach['remote'] == '1'){
                                $post['message'] = str_replace(
                                    'data/attachment/forum/'.$attach['attachment'],
                                    $remoteHost.'/forum/'.$attach['attachment'],
                                    $post['message']
                                );
                                
                                // echo $_G['setting']['attachdir'].'<br>';
                                // echo $_G['setting']['attachurl'].'<br>';
                                // echo $_G['setting']['ftp']['attachurl'].'<br>';
                                // echo $attach['attachment'].'<br>';
                            }
                            unset($post['attachments'][$attach['aid']]);
                        }
                    }
                }

                $postlist[$k] = $post;
            }
            
        }
        return;
    }
    function viewthread_bottom(){
        include template('zhanmishu_markdown:markdown');
        return $markdown;
    }
    function post_attribute_extra_body(){
        
    }
    function post_middle() {
        if ($_GET['editorTypeChecked']) {
            $isMd = preg_match($pattern, $_GET['message'] , $MarkdownReturn);
            $_GET['message'] = $this->cleanXss($_GET['message']);
            if(!$isMd) {
                $_GET['message'] = '[md]' . $_GET['message'] .'[/md]';
            }
        }
        

    }
    function post_middle_output(){
        global $_G, $postinfo, $editorid, $editor;
        if (!in_array($_G['groupid'], $this->parseHander()->config['avaiable_groups']) || !in_array($_GET['fid'], $this->parseHander()->config['avaiable_forums'])) {
            return;
        }
        $hash = md5(substr(md5($_G['config']['security']['authkey']), 8).$_G['uid']);
        


        $isMarkdown = 0;
        if ((!$postinfo['message'] && $this->parseHander()->config['defaultEditor']) || (substr($postinfo['message'], 0 , 4) == '[md]' && substr($postinfo['message'], -5) == '[/md]')) {
            $isMarkdown = 1;
            $message = C::t('forum_post')->fetch('tid:'.$postinfo['tid'], $postinfo['pid'], true);
                
            $mdMessage = substr($message['message'], 4, -5);

            $mdMessage = preg_replace("/\[audio\](.*?)\[\/audio\]/", "$1", $mdMessage);
            $mdMessage = preg_replace("/\[url\](.*?)\[\/url\]/", "$1", $mdMessage);
            $mdMessage = preg_replace("/\[video\](.*?)\[\/video\]/", "$1", $mdMessage);
            $mdMessage = preg_replace("/\[flash\](.*?)\[\/flash\]/", "$1", $mdMessage);
            $mdMessage = preg_replace("/\[media\](.*?)\[\/media\]/", "$1", $mdMessage);

            $postinfo['message'] = $mdMessage;
        }
        include template('zhanmishu_markdown:post_add');
        return $post_add;
    }
}

/**
 * 手机版本嵌入点
 */
class mobileplugin_zhanmishu_markdown extends plugin_zhanmishu_markdown_base {

}

/**
 * 手机版本嵌入点
 */
class mobileplugin_zhanmishu_markdown_forum extends mobileplugin_zhanmishu_markdown {
    function viewthread_bottom_mobile() {
        include template('zhanmishu_markdown:markdown');
        return $markdown;
    }
    function viewthread_top_mobile(){
        return '<link rel="stylesheet" href="source/plugin/zhanmishu_markdown/template/editor/index.css?20200224">';
    }

    function viewthread_bottom_mobile_output() {
        global $postlist;
        global $_G;
        include libfile('function/editor');
        foreach($postlist as $k=>$post){
            $pattern= "/\[md\](.*)\[\/md\]/is";
            $isMd = preg_match($pattern, $post['message'] , $MarkdownReturn);
            if ($isMd) {
                $message = C::t('forum_post')->fetch('tid:'.$post['tid'], $post['pid'], true);
                
                $mdMessage = substr($message['message'], 4, -5);
                $mdMessage = $this->cleanXss($mdMessage);

                $mdMessage = preg_replace("/\[audio\](.*?)\[\/audio\]/", "$1", $mdMessage);
                $mdMessage = preg_replace("/\[url\](.*?)\[\/url\]/", "$1", $mdMessage);
                $mdMessage = preg_replace("/\[video\](.*?)\[\/video\]/", "$1", $mdMessage);
                $mdMessage = preg_replace("/\[flash\](.*?)\[\/flash\]/", "$1", $mdMessage);
                $mdMessage = preg_replace("/\[media\](.*?)\[\/media\]/", "$1", $mdMessage);

                if (IS_ROBOT || self::isIE() || $this->parseHander()->config['markParse'] == '1') {
                    
                    $replace = '<div class="vditor-reset">'.zhanmishu_markdown_controller::markdownParse($mdMessage).'<div>';
                }else{
                    $replace = '<textarea style="display:none;" class="markdownContent vditor-reset" cols="30" rows="10">'.$mdMessage.'</textarea>';
                }
                $post['message'] = $replace;
                $remoteHost = $_G['setting']['ftp']['attachurl'];
                if(substr($remoteHost, -1) == '/'){
                    $remoteHost = substr($remoteHost, 0, -1);
                }
                if (!empty($post['attachments'])) {
                    foreach ($post['attachments'] as $attach) {
                        if (strpos($post['message'], $attach['attachment'])) {
                            
                            if($attach['remote'] == '1'){
                                $post['message'] = str_replace(
                                    'data/attachment/forum/'.$attach['attachment'],
                                    $remoteHost.'/forum/'.$attach['attachment'],
                                    $post['message']
                                );
                            }
                            unset($post['attachments'][$attach['aid']]);
                        }
                    }
                }
                $postlist[$k] = $post;
            }
        }
        return;
    }
}

?>