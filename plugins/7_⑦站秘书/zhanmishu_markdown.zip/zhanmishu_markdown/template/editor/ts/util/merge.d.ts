export declare const merge: (...options: any[]) => any;
