/// <reference types="./types" />
export declare const highlightToolbar: (vditor: IVditor) => void;
