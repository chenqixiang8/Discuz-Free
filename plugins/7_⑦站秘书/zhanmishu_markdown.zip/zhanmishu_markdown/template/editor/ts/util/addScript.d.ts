export declare const addScriptSync: (path: string, id: string) => boolean;
export declare const addScript: (path: string, id: string) => Promise<unknown>;
