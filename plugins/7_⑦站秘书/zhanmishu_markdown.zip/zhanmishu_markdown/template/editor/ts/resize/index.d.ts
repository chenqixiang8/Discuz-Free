/// <reference types="./types" />
export declare class Resize {
    element: HTMLElement;
    constructor(vditor: IVditor);
    private bindEvent;
}
