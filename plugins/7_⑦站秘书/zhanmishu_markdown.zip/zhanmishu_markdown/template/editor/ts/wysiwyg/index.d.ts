/// <reference types="./types" />
declare class WYSIWYG {
    element: HTMLPreElement;
    popover: HTMLDivElement;
    selectPopover: HTMLDivElement;
    afterRenderTimeoutId: number;
    hlToolbarTimeoutId: number;
    preventInput: boolean;
    composingLock: boolean;
    commentIds: [];
    constructor(vditor: IVditor);
    showComment(): void;
    hideComment(): void;
    private copy;
    private bindEvent;
}
export { WYSIWYG };
