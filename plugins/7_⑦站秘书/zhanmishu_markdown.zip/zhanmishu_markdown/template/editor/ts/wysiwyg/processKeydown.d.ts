/// <reference types="./types" />
export declare const processKeydown: (vditor: IVditor, event: KeyboardEvent) => boolean;
export declare const removeBlockElement: (vditor: IVditor, event: KeyboardEvent) => boolean;
