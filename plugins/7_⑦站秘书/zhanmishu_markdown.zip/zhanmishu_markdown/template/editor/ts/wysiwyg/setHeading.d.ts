/// <reference types="./types" />
export declare const setHeading: (vditor: IVditor, tagName: string) => void;
export declare const removeHeading: (vditor: IVditor) => void;
