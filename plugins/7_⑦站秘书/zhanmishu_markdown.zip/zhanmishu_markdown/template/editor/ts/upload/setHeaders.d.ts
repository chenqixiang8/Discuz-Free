/// <reference types="./types" />
export declare const setHeaders: (vditor: IVditor, xhr: XMLHttpRequest) => void;
