/// <reference types="./types" />
export declare const setPreviewMode: (mode: "both" | "editor", vditor: IVditor) => void;
