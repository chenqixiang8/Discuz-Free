export declare const chartRender: (element?: (HTMLElement | Document), cdn?: string) => void;
