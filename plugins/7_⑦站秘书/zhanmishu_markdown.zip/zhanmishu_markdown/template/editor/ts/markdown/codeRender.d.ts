/// <reference types="./types" />
export declare const codeRender: (element: HTMLElement, lang?: keyof II18n) => void;
