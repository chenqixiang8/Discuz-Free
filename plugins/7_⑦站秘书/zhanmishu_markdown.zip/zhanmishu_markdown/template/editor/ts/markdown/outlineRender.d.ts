/// <reference types="./types" />
export declare const outlineRender: (contentElement: HTMLElement, targetElement: Element, vditor?: IVditor) => void;
