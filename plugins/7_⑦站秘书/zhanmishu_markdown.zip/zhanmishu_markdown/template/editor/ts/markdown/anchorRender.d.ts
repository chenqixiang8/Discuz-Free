export declare const anchorRender: (type: number) => void;
