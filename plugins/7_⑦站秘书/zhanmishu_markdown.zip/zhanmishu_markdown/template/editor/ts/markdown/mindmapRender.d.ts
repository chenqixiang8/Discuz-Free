export declare const mindmapRender: (element?: (HTMLElement | Document), cdn?: string) => void;
