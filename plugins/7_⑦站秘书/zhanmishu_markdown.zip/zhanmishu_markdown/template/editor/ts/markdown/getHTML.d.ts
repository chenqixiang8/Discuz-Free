/// <reference types="./types" />
export declare const getHTML: (vditor: IVditor) => string;
