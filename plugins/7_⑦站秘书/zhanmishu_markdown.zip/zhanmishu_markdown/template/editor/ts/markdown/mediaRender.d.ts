export declare const mediaRender: (element: HTMLElement) => void;
