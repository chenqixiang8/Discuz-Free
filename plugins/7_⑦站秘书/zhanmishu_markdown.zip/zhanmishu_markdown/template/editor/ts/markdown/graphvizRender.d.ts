export declare const graphvizRender: (element: HTMLElement, cdn?: string) => void;
