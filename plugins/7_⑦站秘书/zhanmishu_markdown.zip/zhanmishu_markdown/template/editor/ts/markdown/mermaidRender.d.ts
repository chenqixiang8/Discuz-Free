export declare const mermaidRender: (element: HTMLElement, cdn?: string) => void;
