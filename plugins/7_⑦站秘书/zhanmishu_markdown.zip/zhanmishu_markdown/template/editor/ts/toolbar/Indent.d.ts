/// <reference types="./types" />
import { MenuItem } from "./MenuItem";
export declare class Indent extends MenuItem {
    constructor(vditor: IVditor, menuItem: IMenuItem);
}
