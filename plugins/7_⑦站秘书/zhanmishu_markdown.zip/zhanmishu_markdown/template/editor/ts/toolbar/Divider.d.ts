export declare class Divider {
    element: HTMLElement;
    constructor();
}
