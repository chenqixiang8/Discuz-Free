<?php
/**
 *      [HereEdu!] (C)2001-2099 hereEdu Inc
 *      This is NOT a freeware, use is subject to license terms
 *
 *      Author: zhanmishu.com $
 *      qq:87883395 $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
  exit('Access Denied');
}
 
$pluginId = 'zhanmishu_markdown';
@unlink(DISCUZ_ROOT.'source/plugin/'.$pluginId.'/discuz_plugin_'.$pluginId.'.xml');
@unlink(DISCUZ_ROOT.'source/plugin/'.$pluginId.'/discuz_plugin_'.$pluginId.'_SC_GBK.xml');
@unlink(DISCUZ_ROOT.'source/plugin/'.$pluginId.'/discuz_plugin_'.$pluginId.'_SC_UTF8.xml');
@unlink(DISCUZ_ROOT.'source/plugin/'.$pluginId.'/discuz_plugin_'.$pluginId.'_TC_BIG5.xml');
@unlink(DISCUZ_ROOT.'source/plugin/'.$pluginId.'/discuz_plugin_'.$pluginId.'_TC_UTF8.xml');

$finish = TRUE;
?>