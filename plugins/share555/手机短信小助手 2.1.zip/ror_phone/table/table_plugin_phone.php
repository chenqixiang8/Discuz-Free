<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 * Time: 2020-02-11
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_plugin_phone extends discuz_table
{
    var $phone_code_expire = 300;
    var $phone_code_error_count = 3;
    
    var $message_status = array();
    
    public function __construct()
    {
        parent::__construct();

        $this->_pk = 'phone';
        $this->_table = 'plugin_ror_phone';
        
        $this->message_status = array(
            -1=>lib_base::lang('message_status-1'),
            0=>lib_base::lang('message_status0'),
            1=>lib_base::lang('message_status1'),
        );
    }
    
    /**
     * 绑定手机列表
     *
     * @access public
     * @param string, int, int string
     * @return array
     */
    public function phone_list($fields, $offset, $limit, $where = '')
    {
        $sql = 'SELECT '.$fields.' FROM '.DB::table($this->_table).'
                '.$where.'
                ORDER BY dateline DESC LIMIT '.$offset.','.$limit;
    
        return DB::fetch_all($sql);
    }
    
    /**
     * 绑定手机统计
     *
     * @access public
     * @param string
     * @return int
     */
    public function phone_count($where = '')
    {
        $sql = 'SELECT COUNT(*) FROM '.DB::table($this->_table).'
    	       '.$where;
         
        return DB::result_first($sql);
    }
    
    /**
     * 绑定手机信息
     *
     * @access public
     * @param string
     * @return array
     */
    public function bind_detail_by_phone($phone)
    {
        $sql = 'SELECT phone,uid,code,error_count,updatetime FROM '.DB::table($this->_table)." WHERE phone='".$phone."'";
         
        return DB::fetch_first($sql);
    }
    
    /**
     * uc 用户信息
     *
     * @access public
     * @param string
     * @return array
     */
    public function uc_user_by_uid($uid)
    {
        $sql = 'SELECT * FROM '.UC_DBTABLEPRE.'members WHERE uid='.$uid;
        
        return DB::fetch_first($sql);
    }
    
    /**
     * 更换uc邮箱
     *
     * @access public
     * @param string
     * @return array
     */
    public function uc_email_update($uid, $email)
    {
        $sql = 'UPDATE '.UC_DBTABLEPRE."members SET email='".$email."' WHERE uid=".$uid;
        
        return DB::query($sql);
    }
    
    /**
     * 手机发送验证码log
     *
     * @access public
     * @param string, string, string, int
     * @return bool
     */
    public function phone_message_log($platform, $phone, $message, $status)
    {
        $add = array(
            'platform'=>$platform,
            'phone'=>$phone,
            'dateline'=>time(),
            'message'=>$message,
            'status'=>$status
        );
        
        return DB::insert('plugin_ror_phone_message', $add);
    }
    
    /**
     * 消息日志列表
     *
     * @access public
     * @param string, int, int string
     * @return array
     */
    public function message_list($fields, $offset, $limit, $where = '')
    {
        $sql = 'SELECT '.$fields.' FROM '.DB::table('plugin_ror_phone_message').'
                '.$where.'
                ORDER BY dateline DESC LIMIT '.$offset.','.$limit;
    
        return DB::fetch_all($sql);
    }
    
    /**
     * 消息日志统计
     *
     * @access public
     * @param string
     * @return int
     */
    public function message_count($where = '')
    {
        $sql = 'SELECT COUNT(*) FROM '.DB::table('plugin_ror_phone_message').'
    	       '.$where;
         
        return DB::result_first($sql);
    }
    
    /**
     * 密码检测
     *
     * @access public
     * @param string
     * @return array
     */
    public function password_check($password)
    {
        $rule = "/^[a-zA-Z\d_-]{5,20}$/";
        
        $n = preg_match_all($rule, $password, $array);
        
        if(! $n){
            return lib_base::back_array(lib_base::lang('password_check_limit'));
        }
        
        return lib_base::back_array('success', 0);
    }
    
    /**
     * 验证码
     *
     * @access public
     * @param 
     * @return int
     */
    public function code_create()
    {
        return mt_rand(100000, 999999);
    }
    
    /**
     * uc 用户信息
     *
     * @access public
     * @param string
     * @return array
     */
    public function uc_user_by_username($username)
    {
        $sql = 'SELECT * FROM '.UC_DBTABLEPRE."members WHERE username='".$username."'";
    
        return DB::fetch_first($sql);
    }
}