<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 * Time: 2020-02-11
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

/**
 * lib_func_phone Class
 * @package plugin
 * @subpackage ror
 * @category phone
 * @author ror
 * @link
 */
class lib_func_phone
{    
    var $platform = array(
        'aliyun',
        'tencent',
        'wangyi'
    );
    
    /**
     * 短信发送
     *
     * @access public
     * @param string, string
     * @return array
     */
    public static function send($phone, $code)
    {
        $platform = lib_base::settings('platform');
        
        if(! method_exists(new self(), $platform)){
            return lib_base::back_array('请选择接入的短信平台');
        }
        
        $result = self::$platform($phone, $code);
        
        $status = $result['state'] == 0?1:-1;
        
        $message = $code.' '.$result['result'];
        
        lib_base::table('plugin_phone')->phone_message_log($platform, $phone, $message, $status);
        
        return $result;
    }
    
    /**
     * 阿里云短信发送
     *
     * @access public
     * @param string, string
     * @return array
     */
    public static function aliyun($phone, $code)
    {
        require(DISCUZ_ROOT.'source/plugin/ror_phone/third_party/aliyun/SignatureHelper.php');
        
        $params = array ();
        
        // *** 需用户填写部分 ***
        // fixme 必填: 请参阅 https://ak-console.aliyun.com/ 取得您的AK信息
        $accessKeyId = lib_base::settings('app_id');
        $accessKeySecret = lib_base::settings('app_key');
        // fixme 必填: 短信签名，应严格按"签名名称"填写，请参考: https://dysms.console.aliyun.com/dysms.htm#/develop/sign
        $params["SignName"] = lib_base::settings('app_sign');
        // fixme 必填: 短信模板Code，应严格按"模板CODE"填写, 请参考: https://dysms.console.aliyun.com/dysms.htm#/develop/template
        $params["TemplateCode"] = lib_base::settings('app_template');

        // fixme 必填: 短信接收号码
        $params["PhoneNumbers"] = $phone;

        // fixme 可选: 设置模板参数, 假如模板中存在变量需要替换则为必填项
        $params['TemplateParam'] = Array (
            "code" => $code
        );
    
        // fixme 可选: 设置发送短信流水号
        //$params['OutId'] = "12345";
    
        // fixme 可选: 上行短信扩展码, 扩展码字段控制在7位或以下，无特殊需求用户请忽略此字段
        //$params['SmsUpExtendCode'] = "1234567";
    
    
        // *** 需用户填写部分结束, 以下代码若无必要无需更改 ***
        if(!empty($params["TemplateParam"]) && is_array($params["TemplateParam"])) {
            $params["TemplateParam"] = json_encode($params["TemplateParam"], JSON_UNESCAPED_UNICODE);
        }
    
        // 初始化SignatureHelper实例用于设置参数，签名以及发送请求
        $helper = new SignatureHelper();
    
        // 此处可能会抛出异常，注意catch
        $result = $helper->request(
            $accessKeyId,
            $accessKeySecret,
            "dysmsapi.aliyuncs.com",
            array_merge($params, array(
                "RegionId" => "cn-hangzhou",
                "Action" => "SendSms",
                "Version" => "2017-05-25",
            ))
            // fixme 选填: 启用https
            // ,true
        );

        if($result->Code != 'OK'){
            return lib_base::back_array($result->Message);
        }
    
        return lib_base::back_array($result->Message, 0);
    }
    
    /**
     * 腾讯短信发送
     *
     * @access public
     * @param string, string
     * @return array
     */
    public static function tencent($phone, $code)
    {
        require(DISCUZ_ROOT.'source/plugin/ror_phone/third_party/tencent/SmsSenderUtil.php');
        require(DISCUZ_ROOT.'source/plugin/ror_phone/third_party/tencent/SmsSingleSender.php');

        // 短信应用SDK AppID
        $appid = lib_base::settings('app_id'); // 1400开头
        // 短信应用SDK AppKey
        $appkey = lib_base::settings('app_key');
        // 短信模板ID，需要在短信应用中申请
        $templateId = lib_base::settings('app_template');  // NOTE: 这里的模板ID`7839`只是一个示例，真实的模板ID需要在短信控制台中申请
        $smsSign = lib_base::settings('app_sign'); // NOTE: 这里的签名只是示例，请使用真实的已申请的签名，签名参数使用的是`签名内容`，而不是`签名ID`
        
        // 需要发送短信的手机号码
        $phoneNumbers = array($phone);

        $ssender = new SmsSingleSender($appid, $appkey);

        $params = array($code);
        $result = $ssender->sendWithParam("86", $phoneNumbers[0], $templateId,$params, $smsSign, "", "");// 签名参数未提供或者为空时，会使用默认签名发送短信
        $result = json_decode($result, TRUE);

        if($result['result'] != 0){
            return lib_base::back_array($result['errmsg']);
        }
        
        return lib_base::back_array($result['errmsg'], 0);
    }
    
    /**
     * 网易短信发送
     *
     * @access public
     * @param string, string
     * @return array
     */
    public static function wangyi($phone, $code)
    {
        //使用示例
        require(DISCUZ_ROOT.'source/plugin/ror_phone/third_party/phone_wangyi.php');
        //网易云信分配的账号，请替换你在管理后台应用下申请的Appkey
        $AppKey = lib_base::settings('app_id');
        //网易云信分配的账号，请替换你在管理后台应用下申请的appSecret
        $AppSecret = lib_base::settings('app_key');
        $templateId = lib_base::settings('app_template');
        
        $p = new ServerAPI($AppKey, $AppSecret);     //fsockopen伪造请求
        
        //发送短信验证码
        $result = $p->sendSmsCode($templateId, $phone, '', 6);
        
        //发送模板短信
        //$result  = $p->sendSMSTemplate($templateId, array($phone), array($code));

        if($result['code'] != 200){
            return lib_base::back_array($result['msg']);
        }
        
        return lib_base::back_array($result['msg'], 0);
    }
    
    public static function captcha_check()
    {
        global $_G;
        
        if(! lib_base::settings('gt3_is_open')){
            return lib_base::back_array(lib_base::lang('gt_check_success'), 0);
        }
        
        define("CAPTCHA_ID", lib_base::settings('gt3_id'));
        define("PRIVATE_KEY", lib_base::settings('gt3_key'));
        
        /**
         * 输出二次验证结果,本文件示例只是简单的输出 Yes or No
         */
        // error_reporting(0);
        require_once dirname(dirname(__FILE__)) . '/third_party/gt3/lib/class.geetestlib.php';
        session_start();
        $GtSdk = new GeetestLib(CAPTCHA_ID, PRIVATE_KEY);

        $is_mobile = checkmobile();
        $data = array(
            "user_id" => $_G['uid'], # 网站用户id
            "client_type" => $is_mobile ? 'h5' : 'web', #web:电脑上的浏览器；h5:手机上的浏览器，包括移动应用内完全内置的web_view；native：通过原生SDK植入APP应用的方式
            "ip_address" => $_SERVER['REMOTE_ADDR'] # 请在此处传输用户请求验证时所携带的IP
        );

//         if ($_SESSION['gtserver'] == 1) {   //服务器正常
        if (getcookie('gtserver') == 1) {   //服务器正常

            $result = $GtSdk->success_validate($_GET['geetest_challenge'], $_GET['geetest_validate'], $_GET['geetest_seccode'], $data);
            if (! $result) {
                return lib_base::back_array(lib_base::lang('gt_check_fail'));
            }
            
            return lib_base::back_array(lib_base::lang('gt_check_success'), 0);
        }else{  //服务器宕机,走failback模式
            $result = $GtSdk->fail_validate($_GET['geetest_challenge'], $_GET['geetest_validate'], $_GET['geetest_seccode']);
            if (! $result) {
                return lib_base::back_array(lib_base::lang('gt_check_fail'));
            }
            
            return lib_base::back_array(lib_base::lang('gt_check_success'), 0);
        }
    }
}