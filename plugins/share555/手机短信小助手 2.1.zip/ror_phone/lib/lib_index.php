<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

require_once libfile('lib/base', 'plugin/'.PLUGIN_NAME);

/**
 * lib_index Class
 * @package plugin
 * @subpackage ror
 * @category phone
 * @author ror
 * @link
 */
class lib_index
{
    protected static $allow_actions = array(
        'index'=>array('class'=>'lib_index_phone','function'=>'index'),
        
        'login'=>array('class'=>'lib_index_phone','function'=>'login'),
        'bind_send_code'=>array('class'=>'lib_index_phone','function'=>'bind_send_code'),
        'bind'=>array('class'=>'lib_index_phone','function'=>'bind'),
        'unbind_send_code'=>array('class'=>'lib_index_phone','function'=>'unbind_send_code'),
        'unbind'=>array('class'=>'lib_index_phone','function'=>'unbind'),
        'forget_send_code'=>array('class'=>'lib_index_phone','function'=>'forget_send_code'),
        'forget'=>array('class'=>'lib_index_phone','function'=>'forget'),
        'register_send_code'=>array('class'=>'lib_index_phone','function'=>'register_send_code'),
        'register'=>array('class'=>'lib_index_phone','function'=>'register'),
        'captcha'=>array('class'=>'lib_index_phone','function'=>'captcha'),
    );

    public function run()
    {
//         ini_set("display_errors", "On");
//         error_reporting(E_ALL);
        
        global $_G;
        
        $action = $_GET['act'] ? $_GET['act'] : 'index';
        if (! isset(self::$allow_actions[$action])) {
            showmessage(lib_base::lang('noaction'));
        }
        
        $op = self::$allow_actions[$action];
        
        require_once libfile(str_replace('lib_', 'lib/', $op['class']), 'plugin/'.PLUGIN_NAME);
        
        $class = $op['class'];
        $class = new $class();
        $function = $op['function'];
        $class->$function();
    }
}