<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 * Time: 2020-02-11
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

/**
 * lib_admin_phone Class
 * @package plugin
 * @subpackage ror
 * @category phone
 * @author ror
 * @link
 */
class lib_admin_phone
{
    protected static $table = 'plugin_phone';
    
    protected static $limit = 10;
    protected static $limit_max = 90;
    
    public static function index()
    {
        lib_base::header(lib_base::admin_url('phone_list'));
    }
    
    public static function phone_list()
    {
        $escape['search'] = lib_base::escape($_GET['search']);
        $escape['field'] = lib_base::escape($_GET['field']);
    
        $page = $_GET['page']?intval($_GET['page']):1;
        $limit = $_GET['limit']?($_GET['limit'] > self::$limit_max ? self::$limit_max : intval($_GET['limit'])):self::$limit;
        $uid = $_GET['uid'] !== null ? intval($_GET['uid']) : '';
    
        $fields = array('phone'=>lib_base::lang('phone_phone'),'uid'=>lib_base::lang('phone_uid'),'code'=>lib_base::lang('phone_code'),'error_count'=>lib_base::lang('phone_error_count'),'dateline'=>lib_base::lang('phone_dateline'),'updatetime'=>lib_base::lang('phone_updatetime'));
        $tool = array(
            '<a class="layui-btn" href="'.lib_base::admin_url('phone_list').'">'.lib_base::lang('phone_all').'</a>',
            '<a class="layui-btn" href="'.lib_base::admin_url('phone_list&uid=1').'">'.lib_base::lang('phone_binded').'</a>',
            '<a class="layui-btn" href="'.lib_base::admin_url('phone_list&uid=0').'">'.lib_base::lang('phone_unbind').'</a>',
            '<a class="layui-btn" onclick="Func.open({url:\''.lib_base::admin_url('message_list').'\'})">'.lib_base::lang('phone_message_log').'</a>',
            //'<a class="layui-btn" onclick="Func.open({url:\''.lib_base::admin_url('grab_auth').'\'})">'.lib_base::lang('grab_auth').'</a>',
        );
        $submit = lib_base::admin_url('phone_list').'&limit='.$limit;
    
        $fields_str = lib_func::field_str($fields);
        $offset = ($page - 1) * $limit;
    
        $where = '';
        if($uid === 0 || $uid === 1){
            if($uid){
                $where .= ' AND uid!=0';
            }else{
                $where .= ' AND uid=0';
            }
            $submit .= '&uid='.$uid;
        }
        
        if($escape['search'] && $escape['field'] && array_key_exists($escape['field'], $fields)){
            $where .= " AND ".$escape['field']." = '".$escape['search']."'";
            $submit .= '&search='.$escape['search'].'&field='.$escape['field'];
        }
        $where && $where = 'WHERE '.ltrim($where, ' AND');
    
        $list = lib_base::table(self::$table)->phone_list($fields_str, $offset, $limit, $where);
        
        foreach($list as $key => $value){
            if($value['uid']){
                $list[$key]['uid'] = '<a target="_blank" href="home.php?mod=space&uid='.$value['uid'].'">'.$value['uid'].'</a>';
            }
        }
    
        $count = lib_base::table(self::$table)->phone_count($where);
        $page_count = ceil($count / $limit);
        $paging = lib_func::paging($page_count, $page, $submit.'&page=', $limit, $count);
        $search = lib_func::field_option(array('phone'=>lib_base::lang('phone_phone')), $escape['field']);
    
        $formate['time'] = array('dateline','updatetime');
        $formate['op'] = array(
            array('url'=>lib_base::admin_url('phone_unbind'),'name'=>lib_base::lang('phone_op_unbind'),type=>3)
        );
    
        $fields = lib_func::create_table($list, $fields, $formate);
    
        include lib_base::template('admin');
    }
  
    public static function phone_unbind()
    {
        $phone = lib_base::escape($_GET['ids']);
    
        $result = lib_base::table(self::$table)->update($phone, array('uid'=>0));
        
        if(! $result){
            lib_base::back_text(lib_base::lang('fail'));
        }
        
        lib_base::back_text(lib_base::lang('success'), 0);
    }
    
    public static function message_list()
    {
        $escape['search'] = lib_base::escape($_GET['search']);
        $escape['field'] = lib_base::escape($_GET['field']);
    
        $page = $_GET['page']?intval($_GET['page']):1;
        $limit = $_GET['limit']?($_GET['limit'] > self::$limit_max ? self::$limit_max : intval($_GET['limit'])):self::$limit;
        $status = $_GET['status'] ? intval($_GET['status']) : 0;

        $fields = array('platform'=>lib_base::lang('message_platform'),'phone'=>lib_base::lang('message_phone'),'dateline'=>lib_base::lang('message_dateline'),'message'=>lib_base::lang('message_message'),'status'=>lib_base::lang('message_status'));
        $tool = array(
            '<a class="layui-btn" href="'.lib_base::admin_url('message_list').'">'.lib_base::lang('message_tool_all').'</a>',
            '<a class="layui-btn" href="'.lib_base::admin_url('message_list&status=1').'">'.lib_base::lang('message_tool_success').'</a>',
            '<a class="layui-btn" href="'.lib_base::admin_url('message_list&status=-1').'">'.lib_base::lang('message_tool_fail').'</a>',
        );
        $submit = lib_base::admin_url('message_list').'&limit='.$limit;
    
        $fields_str = lib_func::field_str($fields);
        $offset = ($page - 1) * $limit;
    
        $where = '';
        if($status){
            $where .= ' AND status='.$status;
            $submit .= '&status='.$status;
        }
        
        if($escape['search'] && $escape['field'] && array_key_exists($escape['field'], $fields)){
            $where .= " AND ".$escape['field']." = '".$escape['search']."'";
            $submit .= '&search='.$escape['search'].'&field='.$escape['field'];
        }
        $where && $where = 'WHERE '.ltrim($where, ' AND');
    
        $list = lib_base::table(self::$table)->message_list($fields_str, $offset, $limit, $where);
    
        $count = lib_base::table(self::$table)->message_count($where);
        $page_count = ceil($count / $limit);
        $paging = lib_func::paging($page_count, $page, $submit.'&page=', $limit, $count);
        $search = lib_func::field_option(array('platform'=>lib_base::lang('message_platform'),'phone'=>lib_base::lang('message_phone')), $escape['field']);

    
        $formate['time'] = array('dateline');
        $formate['fi'] = array('status'=>lib_base::table(self::$table)->message_status);

        $fields = lib_func::create_table($list, $fields, $formate);
    
        include lib_base::template('admin');
    }
    
//     public static function grab_auth()
//     {
//         global $_G;
    
//         $post = array(
//             'host'=>$_SERVER['HTTP_HOST'],
//             'plugin'=>PLUGIN_NAME
//         );
    
//         $result = lib_func::curl(lib_base::$grab_host.lib_base::$grab_api_auth, $post);
    
//         $result = json_decode($result, TRUE);
    
//         //转码兼容
//         if(CHARSET == 'gbk'){
//             $result = lib_base::convert_utf8_to_gbk($result);
//         }
    
//         if(! isset($result['state']) || $result['state'] != 0){
//             lib_base::js_back_show($result['result']);
//         }
    
//         loadcache(PLUGIN_NAME);
//         $cache = $_G['cache'][PLUGIN_NAME];
//         $cache['auth'] = $result['result'];
//         savecache(PLUGIN_NAME, $cache);
    
//         lib_base::js_back_show(lib_base::lang('grab_auth_success'));
//     }
}