<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

require_once libfile('lib/base', 'plugin/'.PLUGIN_NAME);
require_once libfile('lib/func', 'plugin/'.PLUGIN_NAME);

/**
 * lib_admin Class
 * @package plugin
 * @subpackage ror
 * @category phone
 * @author ror
 * @link
 */
class lib_admin
{
    protected static $allow_actions = array(
        'index'=>array('class'=>'lib_admin_phone','function'=>'index'),
        
        'phone_list'=>array('class'=>'lib_admin_phone','function'=>'phone_list'),
        'phone_unbind'=>array('class'=>'lib_admin_phone','function'=>'phone_unbind'),
        'message_list'=>array('class'=>'lib_admin_phone','function'=>'message_list'),
        //'grab_auth'=>array('class'=>'lib_admin_phone','function'=>'grab_auth'),
    );
    
    public function run()
    {
//         ini_set("display_errors", "On");
//         error_reporting(E_ALL);
        
        global $_G;

        $action = $_GET['act'] ? $_GET['act'] : 'index';

        if(! isset(self::$allow_actions[$action])){
            lib_base::js_back_show(lib_base::lang('noaction'));
        }

        if(FORMHASH != $_GET['myformhash'] && ! in_array($action, array('index','phone_list'))){
            showmessage(lib_base::lang('noformhash'));
        }
        
        if(! $_G['adminid']){
            lib_base::js_back_window(lib_base::lang('nopermission'));
        }

        if(CHARSET == 'gbk' && isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
            $_GET = lib_base::convert_utf8_to_gbk($_GET);
        }
        
        $op = self::$allow_actions[$action];

        require_once libfile(str_replace('lib_', 'lib/', $op['class']), 'plugin/'.PLUGIN_NAME);
        
        $class = $op['class'];
        $class = new $class();
        $function = $op['function'];
        $class->$function();
    }
}