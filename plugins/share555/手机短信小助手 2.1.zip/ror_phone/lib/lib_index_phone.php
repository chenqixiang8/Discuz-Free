<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 * Time: 2020-02-11
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

/**
 * lib_index_phone Class
 * @package plugin
 * @subpackage ror
 * @category phone
 * @author ror
 * @link
 */
class lib_index_phone
{
    protected static $table = 'plugin_phone';
    
    public static function index()
    {
        global $_G;
        
        $bind_is_show = $_GET['action'] == 'bind' ? 1 : 0;
        $unbind_is_show = $_GET['action'] == 'unbind' ? 1 : 0;
        $register_is_show = $_GET['action'] == 'register' ? 1 : 0;
        $forget_is_show = $_GET['action'] == 'forget' ? 1 : 0;
        $back = $_GET['back'] ? $_GET['back'] : ($_SERVER['HTTP_REFERER'] ? $_SERVER['HTTP_REFERER'] : '/');
        
        $username = $_G['username'] ? $_G['username'] : '';
        
        $phone_send_intval = lib_base::settings('phone_send_intval');
        ! $phone_send_intval && $phone_send_intval = 60;
        
        $snow_effect = lib_base::settings('snow_effect');
        $web_bg_image = lib_base::settings('web_bg_image');
        $wap_bg_image = lib_base::settings('wap_bg_image');
        $gt3_is_open = lib_base::settings('gt3_is_open');

        $act = $_GET['action'] ? $_GET['action'] : 'login';
        
        include lib_base::template('index');
    }
    
    public static function captcha()
    {
        global $_G;

        define("CAPTCHA_ID", lib_base::settings('gt3_id'));
        define("PRIVATE_KEY", lib_base::settings('gt3_key'));

        /**
         * 使用Get的方式返回：challenge和capthca_id 此方式以实现前后端完全分离的开发模式 专门实现failback
         * @author Tanxu
         */
        //error_reporting(0);
        require_once dirname(dirname(__FILE__)) . '/third_party/gt3/lib/class.geetestlib.php';
        $GtSdk = new GeetestLib(CAPTCHA_ID, PRIVATE_KEY);
        session_start();
        
        $is_mobile = checkmobile();
        $data = array(
    		"user_id" => $_G['uid'], # 网站用户id
    		"client_type" => $is_mobile ? 'h5' : 'web', #web:电脑上的浏览器；h5:手机上的浏览器，包括移动应用内完全内置的web_view；native：通过原生SDK植入APP应用的方式
    		"ip_address" => $_SERVER['REMOTE_ADDR'] # 请在此处传输用户请求验证时所携带的IP
    	);

        $status = $GtSdk->pre_process($data, 1);

        dsetcookie('gtserver', $status, 600);
        dsetcookie('user_id', $data['user_id'], 600);
        
//         $_SESSION['gtserver'] = $status;
//         $_SESSION['user_id'] = $data['user_id'];
        
        echo $GtSdk->get_response_str();
    }
    
    public static function login()
    {
        global $_G;
    
        $phone = lib_base::escape($_GET['username']);
        $password = $_GET['password'];
        
        if(! $phone || ! $password){
            lib_base::back_text(lib_base::lang('input_phone_password'));
        }
        
        //验证码检测
        require_once libfile('lib/func_phone', 'plugin/'.PLUGIN_NAME);
        $result = lib_func_phone::captcha_check();
        if($result['state'] != 0){
            lib_base::back_text($result['result']);
        }
        
        if(preg_match('/^1\d{10}$/', $phone)){
            $bind = lib_base::table(self::$table)->bind_detail_by_phone($phone);
        }else{
            loaducenter();
            $bind = lib_base::table(self::$table)->uc_user_by_username($phone);
        }
        
        if(! $bind || ! $bind['uid']){
            lib_base::back_text(lib_base::lang('unbind_phone_header'), 2);
        }
        
        $user = getuserbyuid($bind['uid']);
        if(! $user){
            lib_base::back_text(lib_base::lang('bind_member_no_exist'));
        }

        //登陆密码验证
        require_once libfile('function/member');
        $result = userlogin($user['username'], $password, '', '', 'username', $_G['clientip']);
        if($result['status'] != 1 || $result['member']['uid'] != $user['uid']){
            $status = $result['ucresult']['uid'];
            if($status == -4){
                lib_base::back_text(lib_base::lang('password_error_limit'));
            }else if($status == -3){
                lib_base::back_text(lib_base::lang('ques_check_fail'));
            }else if($status == -2){
                lib_base::back_text(lib_base::lang('username_password_error'));
            }else if($status == -1){
                lib_base::back_text(lib_base::lang('unknow_member'));
            }else{
                lib_base::back_text(lib_base::lang('login_fail'));
            }
        }

        //写cookie
        setloginstatus($result['member'], 2592000);
        
        lib_base::back_text(lib_base::lang('login_success_header'), 0);
    }
    
    public static function bind_send_code()
    {
        $phone = lib_base::escape($_GET['phone']);
        
        if(! $phone){
            lib_base::back_text(lib_base::lang('input_phone'));
        }
        
        //验证码检测
        require_once libfile('lib/func_phone', 'plugin/'.PLUGIN_NAME);
        $result = lib_func_phone::captcha_check();
        if($result['state'] != 0){
            lib_base::back_text($result['result']);
        }
        
        $bind = lib_base::table(self::$table)->bind_detail_by_phone($phone);

        $time = time();
        
        if($bind)
        {
            if($bind['uid']){
                lib_base::back_text(lib_base::lang('phone_is_binded'));
            }
            
            $phone_send_intval = lib_base::settings('phone_send_intval');
            if($time - $bind['updatetime'] < $phone_send_intval){
                lib_base::back_text(sprintf(lib_base::lang('message_send_intval'), $phone_send_intval));
            }
        }
        
        require_once libfile('lib/func_phone', 'plugin/'.PLUGIN_NAME);
        
        $code = lib_base::table(self::$table)->code_create();

        $result = lib_func_phone::send($phone, $code);

        if($result['state'] != 0){
            lib_base::back_text($result['result']);
        }
        
        if($bind){
            lib_base::table(self::$table)->update($phone, array('code'=>$code,'updatetime'=>$time));
        }else{
            lib_base::table(self::$table)->insert(array('phone'=>$phone,'uid'=>0,'code'=>$code,'error_count'=>0,'dateline'=>$time,'updatetime'=>$time));
        }
        
        lib_base::back_text(lib_base::lang('message_send_success'), 0);
    }
    
    public static function bind()
    {
        global $_G;
        
        $username = lib_base::escape($_GET['username']);
        $phone = lib_base::escape($_GET['phone']);
        
        $password = $_GET['password'];
        $code = intval($_GET['code']);
    
        if(! $username || ! $phone || ! $password || ! $code){
            lib_base::back_text(lib_base::lang('form_check'));
        }
        
        $bind = lib_base::table(self::$table)->bind_detail_by_phone($phone);
        
        if(! $bind){
            lib_base::back_text(lib_base::lang('phone_code_get_fail'));
        }
        
        if($bind['uid']){
            lib_base::back_text(lib_base::lang('phone_is_binded'));
        }
    
        $time = time();
        
        if($time - $bind['updatetime'] > lib_base::table(self::$table)->phone_code_expire){
            lib_base::back_text(lib_base::lang('code_expire'));
        }
        
        if($bind['error_count'] && $bind['error_count'] > lib_base::table(self::$table)->phone_code_error_count){
            lib_base::back_text(sprintf(lib_base::lang('code_error_limit'), lib_base::table(self::$table)->phone_code_error_count, lib_base::table(self::$table)->phone_code_expire / 60));
        }
        
        if($code != $bind['code']){
            lib_base::table(self::$table)->update($phone, array('error_count'=>++$bind['error_count']));
            lib_base::back_text(lib_base::lang('code_error'));
        }
        
        $user = C::t('common_member')->fetch_by_username($username, 1);
        if(! $user){
            lib_base::back_text(lib_base::lang('username_no_exist'));
        }
        
        //登陆密码验证
        require_once libfile('function/member');
        $result = userlogin($user['username'], $password, '', '', 'username', $_G['clientip']);
        if($result['status'] != 1 || $result['member']['uid'] != $user['uid']){
            $status = $result['ucresult']['uid'];
            if($status == -4){
                lib_base::back_text(lib_base::lang('password_error_limit'));
            }else if($status == -3){
                lib_base::back_text(lib_base::lang('ques_check_fail'));
            }else if($status == -2){
                lib_base::back_text(lib_base::lang('username_password_error'));
            }else if($status == -1){
                lib_base::back_text(lib_base::lang('unknow_member'));
            }else{
                lib_base::back_text(lib_base::lang('login_fail'));
            }
        }

        lib_base::table(self::$table)->update($phone, array('uid'=>$user['uid'],'error_count'=>0));
    
        lib_base::back_text(lib_base::lang('bind_success_header'), 0);
    }
    
    public static function unbind_send_code()
    {
        $phone = lib_base::escape($_GET['phone']);
    
        if(! $phone){
            lib_base::back_text(lib_base::lang('input_phone'));
        }
    
        //验证码检测
        require_once libfile('lib/func_phone', 'plugin/'.PLUGIN_NAME);
        $result = lib_func_phone::captcha_check();
        if($result['state'] != 0){
            lib_base::back_text($result['result']);
        }
        
        $bind = lib_base::table(self::$table)->bind_detail_by_phone($phone);
    
        $time = time();
    
        if(! $bind || ! $bind['uid']){
            lib_base::back_text(lib_base::lang('phone_no_bind'));
        }
        
        $phone_send_intval = lib_base::settings('phone_send_intval');
        if($time - $bind['updatetime'] < $phone_send_intval){
            lib_base::back_text(sprintf(lib_base::lang('message_send_intval'), $phone_send_intval));
        }
    
        require_once libfile('lib/func_phone', 'plugin/'.PLUGIN_NAME);
    
        $code = lib_base::table(self::$table)->code_create();
    
        $result = lib_func_phone::send($phone, $code);
    
        if($result['state'] != 0){
            lib_base::back_text($result['result']);
        }
    
        lib_base::table(self::$table)->update($phone, array('code'=>$code,'updatetime'=>$time));
    
        lib_base::back_text(lib_base::lang('message_send_success'), 0);
    }
    
    public static function unbind()
    {
        global $_G;
    
        $username = lib_base::escape($_GET['username']);
        $phone = lib_base::escape($_GET['phone']);
    
        $code = intval($_GET['code']);
    
        if(! $username || ! $phone || ! $code){
            lib_base::back_text(lib_base::lang('form_check'));
        }
    
        if(! $_G['uid']){
            lib_base::back_text(lib_base::lang('unbind_is_current'));
        }

        $bind = lib_base::table(self::$table)->bind_detail_by_phone($phone);
    
        if(! $bind || ! $bind['uid']){
            lib_base::back_text(lib_base::lang('phone_no_bind'));
        }
        
        if($_G['uid'] != $bind['uid']){
            lib_base::back_text(lib_base::lang('phone_bind_no_current'));
        }
    
        $time = time();
    
        if($time - $bind['updatetime'] > lib_base::table(self::$table)->phone_code_expire){
            lib_base::back_text(lib_base::lang('code_expire'));
        }
    
        if($bind['error_count'] && $bind['error_count'] > lib_base::table(self::$table)->phone_code_error_count){
            lib_base::back_text(sprintf(lib_base::lang('code_error_limit'), lib_base::table(self::$table)->phone_code_error_count, lib_base::table(self::$table)->phone_code_expire / 60));
        }
    
        if($code != $bind['code']){
            lib_base::table(self::$table)->update($phone, array('error_count'=>++$bind['error_count']));
            lib_base::back_text(lib_base::lang('code_error'));
        }
    
        lib_base::table(self::$table)->update($phone, array('uid'=>0,'error_count'=>0));
    
        lib_base::back_text(lib_base::lang('unbind_success_header'), 0);
    }
    
    public static function forget_send_code()
    {
        $phone = lib_base::escape($_GET['phone']);
    
        if(! $phone){
            lib_base::back_text(lib_base::lang('input_phone'));
        }
    
        //验证码检测
        require_once libfile('lib/func_phone', 'plugin/'.PLUGIN_NAME);
        $result = lib_func_phone::captcha_check();
        if($result['state'] != 0){
            lib_base::back_text($result['result']);
        }
        
        $bind = lib_base::table(self::$table)->bind_detail_by_phone($phone);
    
        $time = time();
        
        if(! $bind || ! $bind['uid']){
            lib_base::back_text(lib_base::lang('phone_no_bind'));
        }
    
        $phone_send_intval = lib_base::settings('phone_send_intval');
        if($time - $bind['updatetime'] < $phone_send_intval){
            lib_base::back_text(sprintf(lib_base::lang('message_send_intval'), $phone_send_intval));
        }
    
        require_once libfile('lib/func_phone', 'plugin/'.PLUGIN_NAME);
    
        $code = lib_base::table(self::$table)->code_create();
    
        $result = lib_func_phone::send($phone, $code);
    
        if($result['state'] != 0){
            lib_base::back_text($result['result']);
        }
    
        lib_base::table(self::$table)->update($phone, array('code'=>$code,'updatetime'=>$time));
    
        lib_base::back_text(lib_base::lang('message_send_success'), 0);
    }
    
    public static function forget()
    {
        global $_G;
    
        $phone = lib_base::escape($_GET['phone']);
    
        $password = $_GET['password'];
        $code = intval($_GET['code']);
    
        if(! $phone || ! $password || ! $code){
            lib_base::back_text(lib_base::lang('form_check'));
        }
        
        //密码检测
        $result = lib_base::table(self::$table)->password_check($password);
        if($result['state'] != 0){
            lib_base::back_text($result['result']);
        }
    
        $bind = lib_base::table(self::$table)->bind_detail_by_phone($phone);
        
        if(! $bind){
            lib_base::back_text(lib_base::lang('phone_code_get_fail'));
        }
        
        if(! $bind['uid']){
            lib_base::back_text(lib_base::lang('phone_no_bind'));
        }

        $time = time();
    
        if($time - $bind['updatetime'] > lib_base::table(self::$table)->phone_code_expire){
            lib_base::back_text(lib_base::lang('code_expire'));
        }
    
        if($bind['error_count'] && $bind['error_count'] > lib_base::table(self::$table)->phone_code_error_count){
            lib_base::back_text(sprintf(lib_base::lang('code_error_limit'), lib_base::table(self::$table)->phone_code_error_count, lib_base::table(self::$table)->phone_code_expire / 60));
        }
    
        if($code != $bind['code']){
            lib_base::table(self::$table)->update($phone, array('error_count'=>++$bind['error_count']));
            lib_base::back_text(lib_base::lang('code_error'));
        }
    
        //重置验证码错误统计
        lib_base::table(self::$table)->update($phone, array('error_count'=>0));
        
        loaducenter();
        $uc_user = lib_base::table(self::$table)->uc_user_by_uid($bind['uid']);

        //更新密码
        $result = uc_user_edit($uc_user['username'], $password, $password, $uc_user['email'], 1);
        
        if($result <= 0){
            if($result == -8){
                lib_base::back_text(lib_base::lang('member_is_protected'));
            }else if($result == 0){
                lib_base::back_text(lib_base::lang('password_reset_repeat'));
            }else{
                lib_base::back_text(lib_base::lang('password_reset_fail'));
            }
        }
        
        $password = md5(md5($password).$uc_user['salt']);
        if(isset($user['_inarchive'])) {
            C::t('common_member_archive')->move_to_master($uc_user['uid']);
        }
        C::t('common_member')->update($uc_user['uid'], array('password' => $password));
        C::t('common_member_field_forum')->update($uc_user['uid'], array('authstr'=>''));
       
        lib_base::back_text(lib_base::lang('password_reset_success_header'), 0);
    }
    
    public static function register_send_code()
    {
        $phone = lib_base::escape($_GET['phone']);
    
        if(! $phone){
            lib_base::back_text(lib_base::lang('input_phone'));
        }
    
        //验证码检测
        require_once libfile('lib/func_phone', 'plugin/'.PLUGIN_NAME);
        $result = lib_func_phone::captcha_check();
        if($result['state'] != 0){
            lib_base::back_text($result['result']);
        }
        
        $bind = lib_base::table(self::$table)->bind_detail_by_phone($phone);
    
        $time = time();
    
        if($bind)
        {
            if($bind['uid']){
                lib_base::back_text(lib_base::lang('phone_is_binded'));
            }
    
            $phone_send_intval = lib_base::settings('phone_send_intval');
            if($time - $bind['updatetime'] < $phone_send_intval){
                lib_base::back_text(sprintf(lib_base::lang('message_send_intval'), $phone_send_intval));
            }
        }
    
        require_once libfile('lib/func_phone', 'plugin/'.PLUGIN_NAME);
    
        $code = lib_base::table(self::$table)->code_create();
    
        $result = lib_func_phone::send($phone, $code);
    
        if($result['state'] != 0){
            lib_base::back_text($result['result']);
        }
    
        if($bind){
            lib_base::table(self::$table)->update($phone, array('code'=>$code,'updatetime'=>$time));
        }else{
            lib_base::table(self::$table)->insert(array('phone'=>$phone,'uid'=>0,'code'=>$code,'error_count'=>0,'dateline'=>$time,'updatetime'=>$time));
        }
    
        lib_base::back_text(lib_base::lang('message_send_success'), 0);
    }
    
    public static function register()
    {
        global $_G;
    
        $username = lib_base::escape($_GET['username']);
        $phone = lib_base::escape($_GET['phone']);
    
        $password = $_GET['password'];
        $code = intval($_GET['code']);
    
        if(! $username || ! $phone || ! $password || ! $code){
            lib_base::back_text(lib_base::lang('form_check'));
        }
    
        //密码检测
        $result = lib_base::table(self::$table)->password_check($password);
        if($result['state'] != 0){
            lib_base::back_text($result['result']);
        }
        
        $bind = lib_base::table(self::$table)->bind_detail_by_phone($phone);
        
        if(! $bind){
            lib_base::back_text(lib_base::lang('phone_code_get_fail'));
        }
        
        if($bind['uid']){
            lib_base::back_text(lib_base::lang('phone_is_binded'));
        }
    
        $time = time();
    
        if($time - $bind['updatetime'] > lib_base::table(self::$table)->phone_code_expire){
            lib_base::back_text(lib_base::lang('code_expire'));
        }
    
        if($bind['error_count'] && $bind['error_count'] > lib_base::table(self::$table)->phone_code_error_count){
            lib_base::back_text(sprintf(lib_base::lang('code_error_limit'), lib_base::table(self::$table)->phone_code_error_count, lib_base::table(self::$table)->phone_code_expire / 60));
        }
    
        if($code != $bind['code']){
            lib_base::table(self::$table)->update($phone, array('error_count'=>++$bind['error_count']));
            lib_base::back_text(lib_base::lang('code_error'));
        }
    
        loaducenter();
        
        $parse_url = parse_url($_G['siteurl']);
        $param = explode('.', $parse_url['host']);
        $param_count = count($param);
        $email_host = $param[$param_count - 2].'.'.$param[$param_count - 1];
        $email_temp = $phone.'@'.$email_host;
        
        $uid = uc_user_register($username, $password, $email_temp, '', '', $_G['clientip']);
        if($uid <= 0){
            if($uid == -1){
                lib_base::back_text(lib_base::lang('username_sensitive'));
            }elseif($uid == -2){
                lib_base::back_text(lib_base::lang('username_shield'));
            }elseif($uid == -3){
                lib_base::back_text(lib_base::lang('username_is_registered'));
            }elseif($uid == -4){
                lib_base::back_text(lib_base::lang('email_is_invalid'));
            }elseif($uid == -5){
                lib_base::back_text(lib_base::lang('email_is_unused'));
            }elseif($uid == -6){
                lib_base::back_text(lib_base::lang('email_is_registered'));
            }else{
                lib_base::back_text(lib_base::lang('op_unknow'));
            }
        }
        
        $email = $uid.'@'.$email_host;
        
        //更换uc邮箱
        lib_base::table(self::$table)->uc_email_update(uid, $email);
        
        $uc_user = lib_base::table(self::$table)->uc_user_by_uid($bind['uid']);
        
        $setting = $_G['setting'];
        $groupid = $setting['regverify'] ? 8 : $setting['newusergroupid'];
        $init_arr = explode(',',  $setting['initcredits']);

        $password = md5(md5($password).$uc_user['salt']);
        
        C::t('common_member')->insert($uid, $username, $password, $email, $_G['clientip'], $groupid, $init_arr);
        C::t('common_member_status')->update($uid, array('lastip'=>$_G['clientip'],'lastvisit'=>TIMESTAMP, 'lastactivity'=>TIMESTAMP));
        
        require_once libfile('cache/userstats', 'function');
        build_cache_userstats();
        
        //绑定手机
        lib_base::table(self::$table)->update($phone, array('uid'=>$uid,'error_count'=>0));
        
        lib_base::back_text(lib_base::lang('register_success_header'), 0);
    }
}