<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 * Time: 2020-02-11
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


class mobileplugin_ror_phone
{
    //注册入口
    function global_header_mobile()
    {
        global $_G;
    
        if($_GET['mod'] == 'register' && $_G['cache']['plugin']['ror_phone']['login_user_close']){
            header('location:plugin.php?id=ror_phone&action=register');
        }
    }
}

class mobileplugin_ror_phone_forum extends mobileplugin_ror_phone
{    
    function post_ror_phone()
    {
        global $_G;
        
        $phone_verify = $_G['cache']['plugin']['ror_phone']['phone_verify'];
        
        if(! $phone_verify){
            return '';
        }
        
        $sql = 'SELECT phone FROM '.DB::table('plugin_ror_phone').' WHERE uid='.$_G['uid'];
        
        $phone = DB::result_first($sql);

        if(! $phone){
            showmessage(lang('plugin/ror_phone', 'send_limit'), 'plugin.php?id=ror_phone&action=bind');
        }
    }
}

class mobileplugin_ror_phone_member extends mobileplugin_ror_phone
{
    //登陆入口
    function logging_bottom_mobile()
    {
        global $_G;

        if($_G['cache']['plugin']['ror_phone']['login_user_close']){
            header('location:plugin.php?id=ror_phone');
        }
        
        $lang_login = lang('plugin/ror_phone', 'login');
        $lang_register = lang('plugin/ror_phone', 'register');
        $lang_bind = lang('plugin/ror_phone', 'bind');
        
        $html = <<<EOT
<style type="text/css">
.ror-phone-a{width:70%;margin:0 auto;margin-top:30px;}
.ror-phone-a td{text-align:center;}
.ror-phone-a a{color:#369;}
.ror-phone-a a img{width:20px;vertical-align:middle;}
</style>
<table class="ror-phone-a">
<tr>
<td><a href="plugin.php?id=ror_phone"><img src="source/plugin/ror_phone/public/images/1.ico"/> {$lang_login}</a></td>
<td><a href="plugin.php?id=ror_phone&action=register"><img src="source/plugin/ror_phone/public/images/2.ico"/> {$lang_register}</a></td>
<td><a href="plugin.php?id=ror_phone&action=bind"><img src="source/plugin/ror_phone/public/images/3.ico"/> {$lang_bind}</a></td>
</tr>
</table>
EOT;

        return $html;
    }
}


