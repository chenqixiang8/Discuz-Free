<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 * Time: 2020-02-11
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_ror_phone
{
    //只允许手机登陆入口
    function global_login_extra()
    {
        global $_G;
        
        if(! $_G['cache']['plugin']['ror_phone']['login_user_close']){
            return '';
        }
        
        list($color1, $color2, $color3, $color4) = explode(';', $_G['cache']['plugin']['ror_phone']['login_button_style']);
        ! $color1 && $color1 = '#505050';
        ! $color2 && $color2 = '#acacac';
        ! $color3 && $color3 = '#6BC30D';
        ! $color4 && $color4 = '#fff';
    
        $lang_login = lang('plugin/ror_phone', 'login');
        $lang_register = lang('plugin/ror_phone', 'register');

        $html = <<<EOT
<style type="text/css">
.fastlg .pns{display:none;}
.login{position:relative;height:32px;line-height:32px;margin-top:5px;display:inline;}.fr{float:right;}.login li{float:left;display:block;}.login li a{text-align:center;font-size:14px;float:left;display:block;width:70px;height:32px;line-height:32px;background:{$color1};color:{$color2};font-family:"arial","微软雅黑";}.login .reg a{background:{$color3};color:{$color4};}
</style>
<ul class="login fr">
	<li class="openlogin"><a href="plugin.php?id=ror_phone">{$lang_login}</a></li>
	<li class="reg"><a href="plugin.php?id=ror_phone&action=register">{$lang_register}</a></li>
</ul>
EOT;
        return $html;
    }
}

class plugin_ror_phone_forum extends plugin_ror_phone
{    
    //实名认证
    function post_ror_phone()
    {
        global $_G;
        
        $phone_verify = $_G['cache']['plugin']['ror_phone']['phone_verify'];
        
        if(! $phone_verify){
            return '';
        }
        
        $sql = 'SELECT phone FROM '.DB::table('plugin_ror_phone').' WHERE uid='.$_G['uid'];
        
        $phone = DB::result_first($sql);

        if(! $phone){
            showmessage(lang('plugin/ror_phone', 'send_limit'), 'plugin.php?id=ror_phone&action=bind');
        }
    }
}

class plugin_ror_phone_home extends plugin_ror_phone
{
    //个人资料 绑定信息
    function spacecp_profile_extra()
    {
        global $_G;

        if(! $_G['uid']){
            return '';
        }
        
        $sql = 'SELECT phone FROM '.DB::table('plugin_ror_phone').' WHERE uid='.$_G['uid'];
        $phone = DB::result_first($sql);
        if(! $phone){
            return '';
        }
        
        $phone = substr_replace($phone, '****', 3, 4);
        
        $lang_unbind = lang('plugin/ror_phone', 'unbind');
        $lang_bind_phone = lang('plugin/ror_phone', 'bind_phone');
        
        $html = <<<EOT
<table cellspacing="0" cellpadding="0" class="tfm">
<tbody><tr><th>{$lang_bind_phone}</th><td style="width:74%;">{$phone}</td><td><a href="plugin.php?id=ror_phone&action=unbind" target="_blank">{$lang_unbind}</a></td></tr>
</tbody></table>  
EOT;
        return $html;
    }
}

class plugin_ror_phone_member extends plugin_ror_phone
{
    //登陆入口
    function logging_input()
    {
        global $_G;
        
        $lang_login = lang('plugin/ror_phone', 'login');
        $lang_register = lang('plugin/ror_phone', 'register');
        $lang_bind = lang('plugin/ror_phone', 'bind');
        
        $html = <<<EOT
<style type="text/css">
.ror-phone-a{width:50%;margin:0 auto;margin-top:10px;}
.ror-phone-a td{text-align:center;}
.ror-phone-a a{text-decoration:none;}
.ror-phone-a a img{width:20px;vertical-align:middle;}
</style>
<table class="ror-phone-a">
<tr>
<td><a href="plugin.php?id=ror_phone"><img src="source/plugin/ror_phone/public/images/1.ico"/> {$lang_login}</a></td>
<td><a href="plugin.php?id=ror_phone&action=register"><img src="source/plugin/ror_phone/public/images/2.ico"/> {$lang_register}</a></td>
<td><a href="plugin.php?id=ror_phone&action=bind"><img src="source/plugin/ror_phone/public/images/3.ico"/> {$lang_bind}</a></td>
</tr>
</table>
EOT;
        
        if($_G['cache']['plugin']['ror_phone']['login_user_close']){
            $html = '<script type="text/javascript">location.href="plugin.php?id=ror_phone"</script>';
        }

        return $html;
    }
    
    //注册入口
    function register_input()
    {
        global $_G;
        
        if($_G['cache']['plugin']['ror_phone']['login_user_close']){
            header('location:plugin.php?id=ror_phone&action=register');
        }
        
        $lang_login = lang('plugin/ror_phone', 'login');
        $lang_register = lang('plugin/ror_phone', 'register');
        $lang_bind = lang('plugin/ror_phone', 'bind');
        
        $html = <<<EOT
<style type="text/css">
.ror-phone-a{width:50%;margin:0 auto;margin-top:10px;}
.ror-phone-a td{text-align:center;}
.ror-phone-a a{text-decoration:none;}
.ror-phone-a a img{width:20px;vertical-align:middle;}
</style>
<table class="ror-phone-a">
<tr>
<td><a href="plugin.php?id=ror_phone"><img src="source/plugin/ror_phone/public/images/1.ico"/> {$lang_login}</a></td>
<td><a href="plugin.php?id=ror_phone&action=register"><img src="source/plugin/ror_phone/public/images/2.ico"/> {$lang_register}</a></td>
<td><a href="plugin.php?id=ror_phone&action=bind"><img src="source/plugin/ror_phone/public/images/3.ico"/> {$lang_bind}</a></td>
</tr>
</table>
EOT;
        
        return $html;
    }
}