jQuery(function($){
	$(function() {	
		$('#login #login-password').focus(function() {
			$('.login-owl').addClass('password');
		}).blur(function() {
			$('.login-owl').removeClass('password');
		});
		$('#login #register-password').focus(function() {
			$('.register-owl').addClass('password');
		}).blur(function() {
			$('.register-owl').removeClass('password');
		});
		$('#login #register-repassword').focus(function() {
			$('.register-owl').addClass('password');
		}).blur(function() {
			$('.register-owl').removeClass('password');
		});
		$('#login #forget-password').focus(function() {
			$('.forget-owl').addClass('password');
		}).blur(function() {
			$('.forget-owl').removeClass('password');
		});
		$('#login #bind-password').focus(function() {
			$('.forget-owl').addClass('password');
		}).blur(function() {
			$('.forget-owl').removeClass('password');
		});
		
		$('.goto_forget').click(function(){
			goto_forget();
		});
		$('.goto_register').click(function(){
			goto_register();
		});
		$('.login_submit').click(function(){
			login();
		});
		$('.goto_login').click(function(){
			goto_login();
		});
		$('.forget-send-code').click(function(){
			forget_send_code();
		});
		$('.forget').click(function(){
			forget();
		});
		$('.register-send-code').click(function(){
			register_send_code();
		});
		$('.register').click(function(){
			register();
		});
		$('.bind-send-code').click(function(){
			bind_send_code();
		});
		$('.bind').click(function(){
			bind();
		});
		$('.unbind-send-code').click(function(){
			unbind_send_code();
		});
		$('.unbind').click(function(){
			unbind();
		});
		
		$('.show_login').click(function(){
			$('#bind_form').hide();
			$('#unbind_form').hide();
			$('#login_form').show();
			
			if($('#captcha-login').length > 0){
				captcha_init('login');
			}
		});

		if(bind_is_show == 1){
			$('#bind_form').show();
			$('#login_form').hide();
		}
		if(unbind_is_show == 1){
			$('#unbind_form').show();
			$('#login_form').hide();
		}
		if(register_is_show == 1){
			goto_register();
		}
		if(forget_is_show == 1){
			goto_forget();
		}
	});

	function notice(id, msg)
	{
		$.pt({
    		target: $(id),
    		position: 'b',
    		align: 'c',
    		width: 'auto',
    		height: 'auto',
    		content:msg
    	});
	}
	
	var InterValObj; //timer变量，控制时间 
	var count = phone_send_intval; //间隔函数，1秒执行 
	var curCount;//当前剩余秒数 
	var state = 0;
	  
	//timer处理函数 
	function SetRemainTime(id)
	{ 
		if(curCount == 0){         
			window.clearInterval(InterValObj);//停止计时器 
			$(id).removeAttr("disabled");//启用按钮 
			$(id).val("发送"); 
		}else{ 
			curCount--; 
			$(id).val(curCount + " 秒后可重新发送"); 
		} 
    }
	      
	function goto_register(){
		$("#register-username").val("");
		$("#register-password").val("");
		$("#register-repassword").val("");
		$("#register-code").val("");
		$("#tab-2").prop("checked",true);
		
		if($('#captcha-register').length > 0){
			captcha_init('register');
		}
	}

	function goto_login(){
		$("#login-username").val("");
		$("#login-password").val("");
		$("#tab-1").prop("checked",true);

		if($('#captcha-login').length > 0){
			captcha_init('login');
		}
	}

	function goto_forget(){
		$("#forget-username").val("");
		$("#forget-password").val("");
		$("#forget-code").val("");
		$("#tab-3").prop("checked",true);
		
		if($('#captcha-forget').length > 0){
			captcha_init('forget');
		}
	}

	function login(){
		var username = $("#login-username").val(),
			password = $("#login-password").val();

		if(username == ""){
			notice('#login-username', '手机号不能为空');
			return;
		}
		if(password == ""){
			notice('#login-password', '密码不能为空');
			return;
		}
		
		$.ajax({
			data    : $('#login_form').serialize(),
			dataType: 'json',
			type    : 'post',
			url     : 'plugin.php?id=ror_phone&act=login',
			success : function(data){
				if(data.state != 0){
					notice('.login-input-container', data.result);
					if(data.state == 2){
						setTimeout(function(){
							$('#bind_form').show();
							$('#login_form').hide();
							
							if($('#captcha-bind').length > 0){
								captcha_init('bind');
							}
						}, 2000);
					}
					
					return;
				}
				
				notice('.login-input-container', data.result);
				
				setTimeout(function(){
					location.href = location_back;
				}, 2000);
			}
		});
	}
	
	function bind_send_code()
	{
		var phone = $('#bind-phone').val();
		if(! phone){
			notice('#bind-phone', '请输入手机号');
			return;
		}
		if(state == 1){
			return;
		}
		state = 1;
		
		$.ajax({
			data    : $('#bind_form').serialize(),
			dataType: 'json',
			type    : 'post',
			url     : 'plugin.php?id=ror_phone&act=bind_send_code',
			success : function(data){
				state = 0;
				if(data.state != 0){
					notice('#bind-code', data.result);
					return;
				}
				
				notice('#bind-code', data.result);
				
				curCount = count; 
				//设置button效果，开始计时 
				$(".bind-send-code").attr("disabled", "true"); 
				$(".bind-send-code").val(curCount + " 秒后可重新发送"); 
				InterValObj = window.setInterval(function(){
					SetRemainTime('.bind-send-code');
				}, 1000);
			}
		});
	} 
	
	function bind()
	{
		var username = $('#bind-username').val();
		if(! username){
			notice('#bind-username', '请输入用户名');
			return;
		}
		var password = $('#bind-password').val();
		if(! password){
			notice('#bind-password', '请输入登陆密码');
			return;
		}
		var phone = $('#bind-phone').val();
		if(! phone){
			notice('#bind-phone', '请输入手机号');
			return;
		}
		var code = $('#bind-code').val();
		if(! code){
			notice('#bind-code', '请输入验证码');
			return;
		}
		if(state == 1){
			return;
		}
		state = 1;
		
		$.ajax({
			data    : {username:username,password:password,phone:phone,code:code},
			dataType: 'json',
			type    : 'post',
			url     : 'plugin.php?id=ror_phone&act=bind',
			success : function(data){
				state = 0;
				if(data.state != 0){
					notice('.bind-input-container', data.result);
					return;
				}
				
				notice('.bind-input-container', data.result);
				setTimeout(function(){
					$('#bind_form').hide();
					$('#login_form').show();
					
					if($('#captcha-login').length > 0){
						captcha_init('login');
					}
				}, 2000);
			}
		});
	}
	
	function unbind_send_code()
	{
		var phone = $('#unbind-phone').val();
		if(! phone){
			notice('#unbind-phone', '请输入手机号');
			return;
		}
		if(state == 1){
			return;
		}
		state = 1;
		
		$.ajax({
			data    : $('#unbind_form').serialize(),
			dataType: 'json',
			type    : 'post',
			url     : 'plugin.php?id=ror_phone&act=unbind_send_code',
			success : function(data){
				state = 0;
				if(data.state != 0){
					notice('#unbind-code', data.result);
					return;
				}
				
				notice('#unbind-code', data.result);
				
				curCount = count; 
				//设置button效果，开始计时 
				$(".unbind-send-code").attr("disabled", "true"); 
				$(".unbind-send-code").val(curCount + " 秒后可重新发送"); 
				InterValObj = window.setInterval(function(){
					SetRemainTime('.unbind-send-code');
				}, 1000);
			}
		});
	} 
	
	function unbind()
	{
		var username = $('#unbind-username').val();
		if(! username){
			notice('#unbind-username', '请输入用户名');
			return;
		}
		var phone = $('#unbind-phone').val();
		if(! phone){
			notice('#unbind-phone', '请输入手机号');
			return;
		}
		var code = $('#unbind-code').val();
		if(! code){
			notice('#unbind-code', '请输入验证码');
			return;
		}
		if(state == 1){
			return;
		}
		state = 1;
		
		$.ajax({
			data    : {username:username,phone:phone,code:code},
			dataType: 'json',
			type    : 'post',
			url     : 'plugin.php?id=ror_phone&act=unbind',
			success : function(data){
				state = 0;
				if(data.state != 0){
					notice('.unbind-input-container', data.result);
					return;
				}
				
				notice('.unbind-input-container', data.result);
				setTimeout(function(){
					location.href = '/';
				}, 2000);
			}
		});
	}
	
	function forget_send_code()
	{
		var phone = $('#forget-username').val();
		if(! phone){
			notice('#forget-username', '请输入手机号');
			return;
		}
		if(state == 1){
			return;
		}
		state = 1;
		
	　　  //请求后台发送验证码 
		$.ajax({
			data    : $('#forget_form').serialize(),
			dataType: 'json',
			type    : 'post',
			url     : 'plugin.php?id=ror_phone&act=forget_send_code',
			success : function(data){
				state = 0;
				if(data.state != 0){
					notice('#forget-code', data.result);
					return;
				}
				
				notice('#forget-code', data.result);
				
				curCount = count; 
				//设置button效果，开始计时 
				$(".forget-send-code").attr("disabled", "true"); 
				$(".forget-send-code").val(curCount + " 秒后可重新发送"); 
				InterValObj = window.setInterval(function(){
					SetRemainTime('.forget-send-code');
				}, 1000);
			}
		});
	}

	function forget()
	{
		var phone = $('#forget-username').val(),
			password = $('#forget-password').val(),
			code = $('#forget-code').val();
		//判断用户名密码是否为空
		if(phone == ''){
			notice('#forget-username', '手机号不能为空');
			return;
		}
		if(password == ''){
			notice('#forget-password', '密码不能为空');
			return;
		}
		//检查注册码是否正确
		if(code == ''){
			notice('#forget-code', '验证码不能为空');
			return;
		}
		
		$.ajax({
			data    : {phone:phone,password:password,code:code},
			dataType: 'json',
			type    : 'get',
			url     : 'plugin.php?id=ror_phone&act=forget',
			success : function(data){
				if(data.state != 0){
					notice('.forget-input-container', data.result);
					return;
				}
				
				notice('.forget-input-container', data.result);
				
				setTimeout(function(){
					goto_login();
				}, 2000);
			}
		});
	}
	
	function register_send_code()
	{
		var phone = $('#register-phone').val();
		if(! phone){
			notice('#register-phone', '请输入手机号');
			return;
		}
		if(state == 1){
			return;
		}
		state = 1;
		
		$.ajax({
			data    : $('#register_form').serialize(),
			dataType: 'json',
			type    : 'post',
			url     : 'plugin.php?id=ror_phone&act=register_send_code',
			success : function(data){
				state = 0;
				if(data.state != 0){
					notice('#register-code', data.result);
					return;
				}
				
				notice('#register-code', data.result);
				
				curCount = count; 
				//设置button效果，开始计时 
				$(".register-send-code").attr("disabled", "true"); 
				$(".register-send-code").val(curCount + " 秒后可重新发送"); 
				InterValObj = window.setInterval(function(){
					SetRemainTime('.register-send-code');
				}, 1000);
			}
		});
	} 
	
	//注册
	function register()
	{
		var username = $("#register-username").val(),
			password = $("#register-password").val(),
			phone = $("#register-phone").val(),
			code = $("#register-code").val();
			
		if(username == ""){
			notice('#register-username', '用户名不能为空');
			return;
		}
		if(password == ""){
			notice('#register-password', '密码不能为空');
			return;
		}
		if(phone == ""){
			notice('#register-phone', '手机号不能为空');
			return;
		}
		if(code == ""){
			notice('#register-code', '验证码不能为空');
			return;
		}
		
		$.ajax({
			data    : {username:username,password:password,phone:phone,code:code},
			dataType: 'json',
			type    : 'post',
			url     : 'plugin.php?id=ror_phone&act=register',
			success : function(data){
				state = 0;
				if(data.state != 0){
					notice('.register-input-container', data.result);
					return;
				}
				
				notice('.register-input-container', data.result);
				setTimeout(function(){
					goto_login();
				}, 2000);
			}
		});
	}
});