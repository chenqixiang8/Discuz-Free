<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: admincp_color.inc.php 2016-6-13 06:15:40Z $
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

include './source/plugin/wq_app_setting/config/config.php';

$ac = in_array($_GET['ac'], array('add', 'edit', 'set')) ? $_GET['ac'] : 'set';
$url = 'plugins&operation=config&do=' . $pluginid . '&identifier=wq_app_setting&pmod=admincp_color';
$formurl = $url . "&ac=" . $ac;
$hrefurl = ADMINSCRIPT . '?action=' . $url;
$cpurl = 'action=' . $url;

if($ac == "set") {
	if(!submitcheck('editsubmit')) {

		$lists = C::t("#wq_app_setting#wq_app_setting_style")->fetch_all_by_search();

		showformheader($formurl, ' enctype ', 'editsubmit');
		showtableheader($Plang['f827a234e098a232'], ' nobottom');
		showsubtitle(array("", $Plang['bd940fc8596f83d8'], $Plang['6ad26712f8f13b35'], $Plang['fd834a0ef5d26959'], $Plang['665295d9a3fa6b2e'], $Plang['1ff473de6cbef96f'], $Plang['22ce55aad49de0ff'], $Plang['b89503ed35ca1537'], $Plang['4e64f0e320d8b16b']));
		foreach($lists as $key => $list) {
			$defaultcolor = $list ['defaultcolor'] ? "checked" : "";
			$status = $list ['status'] ? "checked" : "";
			showtablerow('width=50px', array('width=50px', "width=70px", "width=100px", "width=100px", 'width=130px', "width=60px", 'width=60px', 'width=100px', ''), array(
				$list ['type'] ? "" : '<a name = "class_' . $list ['sid'] . '"><input class = "fs" type = "checkbox" name = "delete[' . $list ['sid'] . ']" value = "' . $list ['sid'] . '" /></a> ',
				'<input style="width:50px;" type="number" name="displayorder[' . $list ['sid'] . ']" value="' . $list ['displayorder'] . '"/>' .
				'<input style="width:50px;" type="hidden" name="sid[' . $list ['sid'] . ']" value="' . $list ['sid'] . '"/>',
				$list ['name'],
				'<div style="background:' . $list ['color'] . ';width:20px;height:20px;"></div>',
				'<img style="width:50px" src="' . $list ['banner'] . '"/>',
				'<input type="radio" name="defaultcolor" value="' . $list ['sid'] . '" ' . $defaultcolor . '/>',
				'<input type="checkbox" name="status[' . $list ['sid'] . ']" value="1"  ' . $status . '/>',
				$Plang['type_' . $list ['type']],
				$list ['type'] ? "" : '<a href = "' . $hrefurl . '&ac=edit&sid=' . $list ['sid'] . '">[' . $Plang['9a150d4af72d7358'] . ']</a>',
				'',
				)
			);
		}
		echo '<tr><td colspan = "1"></td><td colspan = "4"><div><a href = "' . $hrefurl . '&ac=add" class = "addtr">' . $Plang['4435ebab14804e56'] . '</a></div></td></tr>';
		showsubmit('editsubmit', 'submit', 'del');
		showtablefooter();/*Dism��taobao��com*/
		showformfooter();
	} else {
		foreach($_GET['sid'] as $key => $sid) {
			if($sid == $_GET['delete'][$sid]) {
				$row = C::t("#wq_app_setting#wq_app_setting_style")->fetch_by_sid($sid);
				if(!$row['type']) {
					if(is_file(DISCUZ_ROOT . $row['banner'])) {
						wq_rmdir(DISCUZ_ROOT . './' . $row['targettplname']);
					}
					C::t("#wq_app_setting#wq_app_setting_style")->delete($sid);
				}
			} else {
				$status = $_GET['status'][$sid] ? 1 : 0;
				$defaultcolor = $_GET['defaultcolor'] == $sid && $status ? 1 : 0;

				$data = array(
					'displayorder' => $_GET['displayorder'][$sid],
					'defaultcolor' => $defaultcolor,
					'status' => $status,
				);
				C::t("#wq_app_setting#wq_app_setting_style")->update($sid, $data);
			}
		}
		wq_app_setting_cache_color();
		cpmsg($Plang['setsucceed'], $cpurl, 'succeed');
	}
}

if($ac == "add" || $ac == "edit") {
	if(!submitcheck('allsubmit')) {
		$sid = $_GET['sid'] ? intval($_GET['sid']) : 0;
		$targettplname = "";

		$row = array();
		if($sid) {
			$row = C::t("#wq_app_setting#wq_app_setting_style")->fetch_by_sid($sid);
			$targettplname = $row['targettplname'];
			if($row['type']) {
				cpmsg($Plang['d716222cb674ccfd'], $cpurl, 'error');
			}
		}

		$displayorder = $_GET['displayorder'] ? intval($_GET['displayorder']) : ($row['displayorder'] ? $row['displayorder'] : 0);
		$name = $_GET['name'] ? dhtmlspecialchars($_GET['name']) : ($row['name'] ? $row['name'] : "");
		$color = $_GET['color'] ? dhtmlspecialchars($_GET['color']) : ($row['color'] ? $row['color'] : "");
		$banner = $_GET['banner'] ? dhtmlspecialchars($_GET['banner']) : ($row['banner'] ? $row['banner'] : "");
		$defaultcolor = $_GET['defaultcolor'] ? intval($_GET['defaultcolor']) : ($row['defaultcolor'] ? $row['defaultcolor'] : 0);
		$status = isset($_GET['status']) ? intval($_GET['status']) : ($row['status'] ? $row['status'] : 1);

		$title = $ac == 'add' ? $Plang['4435ebab14804e56'] : $Plang['46812575130d1773'];

		showformheader($formurl, 'enctype', 'allsubmit');
		showtableheader($title, 'nobottom');
		showsetting($Plang['bd940fc8596f83d8'], 'displayorder', $displayorder, 'number');
		showsetting($Plang['6ad26712f8f13b35'], 'name', $name, 'text');
		showsetting($Plang['fd834a0ef5d26959'], 'color', $color, 'color', '', 0, $Plang['8da0683d532cbe8a']);
		if($banner) {
			$forumbanner = $banner;
			$forumbannerhtml = '<img style="width:100px;" src="' . $forumbanner . '" />';
		}

		showhiddenfields(array('sid' => $sid, 'hiddenbanner' => $forumbanner, 'targettplname' => $targettplname));

		showsetting($Plang['665295d9a3fa6b2e'], 'banner', $banner, 'file', '', 0, $forumbannerhtml . $Plang['1b3fab8e03efb79b']);
		showsetting($Plang['1ff473de6cbef96f'], 'defaultcolor', $defaultcolor, 'radio', '', 0);
		showsetting($Plang['22ce55aad49de0ff'], 'status', $status, 'radio');

		showsubmit('allsubmit', 'submit');
		showtablefooter();/*Dism��taobao��com*/
		showformfooter();
	} else {
		$sid = $_GET['sid'] ? intval($_GET['sid']) : 0;
		$data['sid'] = $sid;
		$data['hiddenbanner'] = $_GET['hiddenbanner'] ? dhtmlspecialchars($_GET['hiddenbanner']) : '';
		$data['displayorder'] = $_GET['displayorder'] ? intval($_GET['displayorder']) : 0;
		$data['targettplname'] = $_GET['targettplname'] ? dhtmlspecialchars($_GET['targettplname']) : '';
		$data['name'] = $_GET['name'] ? dhtmlspecialchars($_GET['name']) : '';
		$data['color'] = $_GET['color'] ? dhtmlspecialchars($_GET['color']) : '';
		$data['defaultcolor'] = $_GET['defaultcolor'] ? intval($_GET['defaultcolor']) : 0;
		$data['status'] = $_GET['status'] ? intval($_GET['status']) : 0;
		$data['type'] = 0;
		$data['dateline'] = time();

		$query = http_build_query($data);
		$errorurl = $cpurl . "&ac=" . $ac . "&" . $query;

		if(empty($data['name'])) {
			cpmsg($Plang['279499c2832a5428'], $errorurl, 'error');
		}
		if(empty($data['color'])) {
			cpmsg($Plang['2b23e2a7413df531'], $errorurl, 'error');
		}

		if($ac == "add") {
			if(empty($_FILES['banner']['name'])) {
				cpmsg($Plang['f5bdee3fce15c7be'], $errorurl, 'error');
			}
			unset($data['sid'], $data['hiddenbanner']);
			$sid = C::t("#wq_app_setting#wq_app_setting_style")->insert($data, true);
			$data['targettplname'] = 'data/attachment/wq_app_setting/style/t' . $sid . '/';
		}


		if(!empty($_FILES['banner']['name'])) {
			$banner = wq_app_setting_upload_images($_FILES['banner'], $data['targettplname']);
			if(in_array($banner, array('-101', '-102', '-103', '-104', '-105'))) {

				if($ac == "add") {
					C::t("#wq_app_setting#wq_app_setting_style")->delete($sid);
				}

				cpmsg($Plang['file_upload_error_' . $banner], $errorurl, 'error');
			}
			$data['banner'] = $banner;

			if($hiddenbanner) {
				if(is_file(DISCUZ_ROOT . $hiddenbanner)) {
					@unlink(DISCUZ_ROOT . $hiddenbanner);
				}
			}
		}
		if($data['defaultcolor']) {
			$lists = C::t("#wq_app_setting#wq_app_setting_style")->fetch_all_by_defaultcolor($data['defaultcolor']);
			if($lists) {
				foreach($lists as $key => $list) {
					C::t("#wq_app_setting#wq_app_setting_style")->update($list['sid'], array('defaultcolor' => 0));
				}
			}
		}

		unset($data['sid'], $data['hiddenbanner']);
		C::t("#wq_app_setting#wq_app_setting_style")->update($sid, $data);

		$content = file_get_contents("./source/plugin/wq_app_setting/static/css/template.css");
		$content = str_replace(array('|name|', '|color|'), array($data['name'], $data['color']), $content);
		file_put_contents($data['targettplname'] . "style.css", print_r($content, 1));

		wq_app_setting_cache_color();
		$msg = $ac == 'edit' ? $Plang['8ee460c51dbd9dee'] : $Plang['22fc21e29216217a'];
		cpmsg($msg, $cpurl, 'succeed');
	}
}
//From: Dism_taobao-com
?>