<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: wq_app_setting.inc.php 2016-6-13 06:15:40Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$_GET['id'] = "wq_app_setting:wq_app_setting";

include_once DISCUZ_ROOT . './source/plugin/wq_app_setting/config/config.php';

$configdir = DISCUZ_ROOT . './source/plugin/' . $identifier . '/pluginextend/';
$pconfig = array();
wq_get_pluginextend_loadconfig($configdir, $pconfig);

$defaultmod = $pconfig['defaultmodule'] ? $pconfig['defaultmodule'] : "index";

$allowmod = array('index', 'ajax', 'qrcode', 'tpllist', 'api', 'static', 'icon');

foreach($pconfig['addmodule'] as $k => $v) {
	$allowmod = array_merge($allowmod, array($k));
	$dirlist[$k] = $v;
}

$mod = !in_array($_GET['mod'], $allowmod) ? $defaultmod : $_GET['mod'];

if(!in_array($mod, array('static', 'ajax', 'api'))) {
	empty($_G['uid']) ? showmessage('to_login', '', array(), array('showmsg' => true, 'login' => 1)) : '';
}

foreach($pconfig['rewritemodule'] as $k => $v) {
	if($k == $mod) {
		$dirlist[$k] = $v;
	}
}

$dirlist[$mod] = $dirlist[$mod] ? $dirlist[$mod] : "module";

require DISCUZ_ROOT . './source/plugin/wq_app_setting/' . $dirlist[$mod] . '/setting_' . $mod . '.php';

?>