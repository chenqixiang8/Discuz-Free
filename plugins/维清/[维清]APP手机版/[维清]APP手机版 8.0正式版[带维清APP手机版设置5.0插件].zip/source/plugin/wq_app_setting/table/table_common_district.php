<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_common_district extends discuz_table {

	public function __construct() {

		$this->_table = 'common_district';
		$this->_pk = 'id';

		parent::__construct();
	}

	public function fetch_all_by_level_upid($level = '1', $upid = '0', $displayorder = 'displayorder', $sort = 'ASC') {
		$val[] = $this->_table;
		$sql[] = '1';
		if($displayorder) {
			$order = ' ORDER BY ' . $displayorder . ' ' . $sort . ',id ASC';
		}
		if($level) {
			$sql[] = 'level=%d';
			$val[] = $level;
		}
		if($upid) {
			$sql[] = 'upid=%d';
			$val[] = $upid;
		}
		$wheresql = implode(' AND ', $sql);
		return DB::fetch_all('SELECT id,name,level,usetype,upid FROM %t WHERE ' . $wheresql . $order, $val, $this->_pk);
	}

	public function fetch_all_by_names($names) {

		if($names) {
			return DB::fetch_all('SELECT id,name,level,usetype,upid FROM %t WHERE name IN(%n)', array($this->_table, $names));
		}
	}

}
//From: Dism_taobao-com
?>