<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: table_wq_subnav.php 2015-9-21 11:02:59Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_wq_app_setting extends discuz_table {

	public function __construct() {
		$this->_table = 'wq_app_setting';
		$this->_pk = 'uid';
		parent::__construct();
	}

}
//From: Dism_taobao-com
?>