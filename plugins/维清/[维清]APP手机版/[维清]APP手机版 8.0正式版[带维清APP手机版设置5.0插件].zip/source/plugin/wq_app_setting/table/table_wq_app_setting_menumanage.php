<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: table_wq_subnav.php 2015-9-21 11:02:59Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_wq_app_setting_menumanage extends discuz_table {

	public function __construct() {
		$this->_table = 'wq_app_setting_menumanage';
		$this->_pk = 'id';
		parent::__construct();
	}

	function fetch_all_by_search($menutype = 0) {
		$val[] = $this->_table;
		$sql[] = '1';

		$order = ' ORDER BY `displayorder` ASC ';

		if($menutype) {
			$sql[] = 'menutype=%d';
			$val[] = $menutype;
		}

		$wheresql = implode(' AND ', $sql);
		return DB::fetch_all("SELECT * FROM %t WHERE " . $wheresql . $order, $val);
	}

	public function count_by_search($menutype = 0) {
		$val[] = $this->_table;
		$sql[] = '1';

		$order = ' ORDER BY `displayorder` ASC ';

		if($menutype) {
			$sql[] = 'menutype=%d';
			$val[] = $menutype;
		}

		$wheresql = implode(' AND ', $sql);
		return DB::result_first("SELECT COUNT(*) FROM %t WHERE " . $wheresql . $order, $val);
	}

	public function fetch_by_id($id) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d ", array($this->_table, $id));
	}

	public function fetch_all_by_id_type($id) {
		return DB::fetch_all("SELECT * FROM %t WHERE id>%d AND type=1", array($this->_table, $id));
	}

}
//From: Dism_taobao-com
?>