<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: table_wq_subnav.php 2015-9-21 11:02:59Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_wq_app_setting_style extends discuz_table {

	public function __construct() {
		$this->_table = 'wq_app_setting_style';
		$this->_pk = 'sid';
		parent::__construct();
	}

	function fetch_all_by_search() {
		$val[] = $this->_table;
		$sql[] = '1';

		$order = ' ORDER BY `displayorder` ASC ';

		$wheresql = implode(' AND ', $sql);
		return DB::fetch_all("SELECT * FROM %t WHERE " . $wheresql . $order, $val);
	}

	public function fetch_by_sid($sid) {
		return DB::fetch_first("SELECT * FROM %t WHERE sid=%d ", array($this->_table, $sid));
	}

	function fetch_all_by_defaultcolor($defaultcolor) {
		return DB::fetch_all("SELECT * FROM %t WHERE defaultcolor=%d ", array($this->_table, $defaultcolor));
	}

}
//From: Dism_taobao-com
?>