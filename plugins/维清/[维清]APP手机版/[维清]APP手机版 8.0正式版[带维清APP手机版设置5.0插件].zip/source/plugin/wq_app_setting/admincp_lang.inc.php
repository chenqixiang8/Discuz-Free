<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: admincp_lang.inc.php 2017-4-14 22:35:59Z $
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$identifier = $plugin['identifier'];
$template_indentifier = str_replace('_setting', '', $identifier);
include_once DISCUZ_ROOT . "./source/plugin/{$identifier}/config/config.php";

loadcache(array("lang_{$identifier}"));
$updatePlang = array();
if(!empty($_G['cache']["lang_{$identifier}"]['updateplang'])) {
	$updatePlang = $_G['cache']["lang_{$identifier}"]['updateplang'];
}

$updateTlang = array();
if(!empty($_G['cache']["lang_{$identifier}"]['updatetlang'])) {
	$updateTlang = $_G['cache']["lang_{$identifier}"]['updatetlang'];
}

$_all_lang = array();
$Plang = wq_loadlang($identifier, false);
foreach($Plang as $pkey => $pval) {
	$_all_lang[] = array(
		'type' => 'p',
		'key' => $pkey,
		'val' => $pval,
	);
}

if(strtolower(CHARSET) == 'gbk') {
	include_once DISCUZ_ROOT . "./template/{$template_indentifier}/php/lang_gbk.php";
} else {
	include_once DISCUZ_ROOT . "./template/{$template_indentifier}/php/lang_utf8.php";
}
foreach($Tlang as $tkey => $tval) {
	$_all_lang[] = array(
		'type' => 't',
		'key' => $tkey,
		'val' => $tval,
	);
}

$keyword = wq_parse_params('keyword');

$perpage = max(0, intval(wq_parse_params('perpage')));
$_perpage = $perpage ? $perpage : '';
$page = max(1, intval(wq_parse_params('page', 0)));
$start = ($page - 1 ) * $perpage;

$url = "plugins&operation=config&do={$pluginid}&identifier={$identifier}&pmod=admincp_lang";

if(!submitcheck('formsubmit')) {
	echo <<<EOF
	<style>
		.tb .noborder .rowform .txt{width:500px;}
	</style>

EOF;


	$all_lang = array();
	foreach($_all_lang as $key => $val) {
		$value = !empty($updatePlang[$val['key']]) ? $updatePlang[$val['key']] : ($updateTlang[$val['key']] ? $updateTlang[$val['key']] : '');
		if($keyword && (strpos($val['val'], $keyword) === false && strpos($value, $keyword) === false)) {
			continue;
		}
		$all_lang[$key] = $val;
	}

	$count = count($all_lang);


	if($perpage) {
		$all_lang = array_slice($all_lang, $start, $perpage, true);
	}

	$mpurl = ADMINSCRIPT . '?action=' . $url;
	$mpurl .=!empty($keyword) ? '&keyword=' . $keyword : '';
	$mpurl .=!empty($_perpage) ? '&perpage=' . $_perpage : '';

	$tips = <<<EOF
		<li style="color:#F00">&#x7279;&#x6B8A;&#x7B26;&#x53F7;&#x4E0D;&#x53EF;&#x4FEE;&#x6539;&#x5982;&#xFF1A;%d&#x3001;%s&#x6216;{time}&#x7B49;&#x7B49;</li>
		<li style="color:#F00">&#x63D0;&#x4EA4;&#x6570;&#x636E;&#x8FC7;&#x5927;&#x5BFC;&#x81F4;&#x63D0;&#x4EA4;&#x5931;&#x8D25;&#xFF0C;&#x8BF7;&#x8BBE;&#x7F6E;&#x6BCF;&#x9875;&#x6570;&#x636E;</li>
		<li>&#x6BCF;&#x9875;&#x6570;&#x636E;&#x586B;&#x5199;&#x5C0F;&#x4E8E;&#x7B49;&#x4E8E;&#x96F6;&#x65F6;&#xFF0C;&#x9ED8;&#x8BA4;&#x8BFB;&#x53D6;&#x6240;&#x6709;&#x7684;&#x6570;&#x636E;</li>
		<li>&#x53EF;&#x901A;&#x8FC7;&#x641C;&#x7D22;&#x8BED;&#x8A00;&#x5305;&#x5173;&#x952E;&#x5B57;&#x5FEB;&#x901F;&#x67E5;&#x627E;&#x8981;&#x4FEE;&#x6539;&#x7684;&#x8BED;&#x8A00;</li>
EOF;
	showtips($tips, 'tips', TRUE, '&#x6E29;&#x99A8;&#x63D0;&#x793A;');

	showformheader($url);
	showtableheader('&#x641C;&#x7D22;', 'nobottom');
	showtablerow('', array('width="260px"', 'width="320px"', 'width="100px"', ''), array(
		"&#x6BCF;&#x9875;&#x6570;&#x91CF;:&nbsp;&nbsp;<input size = \"10\" name=\"perpage\" type=\"number\" value=\"" . $_perpage . "\" />",
		"&#x8BED;&#x8A00;&#x5305;&#x5173;&#x952E;&#x5B57;&#x641C;&#x7D22;:&nbsp;&nbsp;<input size = \"25\" name=\"keyword\" type=\"text\" value=\"" . $keyword . "\" />",
		'<input class="btn" type="submit"  value="' . $lang['search'] . '" />',
		'',
	));
	showtablefooter();/*Dism��taobao��com*/
	showformfooter();

	showformheader($url);
	showtableheader("&#x8BED;&#x8A00;&#x5305;&#x5217;&#x8868;");
	showhiddenfields(array('keyword' => $keyword, 'perpage' => $perpage, 'page' => $page));
	foreach($all_lang as $key => $val) {

		if($val['type'] == 'p') {
			$upval = !empty($updatePlang[$val['key']]) ? $updatePlang[$val['key']] : '';
		} else {
			$upval = !empty($updateTlang[$val['key']]) ? $updateTlang[$val['key']] : '';
		}

		showsetting($val['key'], "{$val['type']}lang[$val[key]]", $upval, 'text', '', 0, "&#x9ED8;&#x8BA4;&#x503C;&#xFF1A;{$val['val']}");
	}

	$multi = $perpage ? multi($count, $perpage, $page, $mpurl) : '';
	showsubmit('formsubmit', 'submit', '', '', $multi);
	showtablefooter();/*Dism��taobao��com*/
	showformfooter();
} else {

	$_updatePlang = wq_parse_params('plang', array());
	$_updateTlang = wq_parse_params('tlang', array());

	$list = array(
		'updateplang' => array_filter(array_merge($updatePlang, $_updatePlang)),
		'updatetlang' => array_filter(array_merge($updateTlang, $_updateTlang)),
		'lang' => array(),
		'tlang' => array(),
	);

	foreach($Plang as $key => $val) {
		$list['lang'][$key] = $val;
		if(!empty($list['updateplang'][$key])) {
			$list['lang'][$key] = dhtmlspecialchars($list['updateplang'][$key]);
		}
	}
	foreach($Tlang as $key => $val) {
		$list['tlang'][$key] = $val;
		if(!empty($list['updatetlang'][$key])) {
			$list['tlang'][$key] = dhtmlspecialchars($list['updatetlang'][$key]);
		}
	}

	savecache("lang_{$identifier}", $list);

	$cpmsgurl = 'action=' . $url;
	$cpmsgurl .=!empty($keyword) ? '&keyword=' . $keyword : '';
	$cpmsgurl .=!empty($_perpage) ? '&perpage=' . $_perpage : '';
	$cpmsgurl .=!empty($page) ? '&page=' . $page : '';

	cpmsg("&#x8BED;&#x8A00;&#x5305;&#x4FEE;&#x6539;&#x6210;&#x529F;", $cpmsgurl, 'succeed');
}
//From: Dism_taobao-com
?>