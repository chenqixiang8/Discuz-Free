<?php

/**
 * Wikin! [ Discuz!Ӧ��ר�ң�������ά�廥���Ƽ����޹�˾��������Ʒ�� ]
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: hooks.class.php 2015-7-5 20:09:18Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_wq_app_setting_base {

	public $lang;
	public $setting;

	function init() {
		include_once DISCUZ_ROOT . './source/plugin/wq_app_setting/config/loadfunc.php';

		$this->lang = wq_loadlang('wq_app_setting');
	}

	function common_base() {
		include_once DISCUZ_ROOT . './source/plugin/wq_app_setting/config/loadfunc.php';
		global $_G;
		$this->setting = wq_loadsetting('wq_app_setting');
	}

	function _forumdisplay_updatecache($params) {
		global $_G;

		$messages = array(
			'recommend_daycount_succeed',
			'admin_succeed',
			'post_reply_succeed',
			'post_edit_succeed'
		);

		if(in_array($params['param'][0], $messages) || ($params['param'][0] == 'recommend_succeed' && $params['param'][2]['recommendv'] = "+1")) {

			$tids = array();
			if(!empty($params['param'][2]['tid'])) {
				$tids = array($params['param'][2]['tid']);
			} elseif(!empty($_GET['tid'])) {
				$tids = array(intval($_GET['tid']));
			}

			if(empty($tids)) {
				return false;
			}

			$this->_threadinfo_updatecache($tids);
		}
	}

	function _threadinfo_updatecache($tids, $flag = true) {
		include_once DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_wq_app.php';
		include_once DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_wq_app_other.php';

		wq_app_get_thread_info_from_cache($tids, true);
	}

}
//From: Dism_taobao-com
?>