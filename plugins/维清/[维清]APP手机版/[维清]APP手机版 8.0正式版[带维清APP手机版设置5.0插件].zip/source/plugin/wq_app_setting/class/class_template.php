<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: class_template.php 34486 2014-05-08 01:31:08Z nemohou $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class wq_template {

	var $csscurmodules = '';

	function loadcsstemplate() {
		global $_G;

		$scriptcss = $css = $content = $this->csscurmodules = '';

		$cssfile = DISCUZ_ROOT . './data/cache/wq_app_setting/csscache/style_wq_app_module.css';
		$timestamp = @filemtime($cssfile);
		$timecompare = @filemtime(DISCUZ_ROOT . './data/cache/wq_app_setting/csscache/style_wq_app_' . $_G['basescript'] . '_' . CURMODULE . '.css');

		$content = @implode('', file($cssfile));
		include_once DISCUZ_ROOT . './source/discuz_version.php';

		if(DISCUZ_VERSION < 'X3.3' && DISCUZ_VERSION != 'F1.0') {
			$content = preg_replace("/\[(.+?)\](.*?)\[end\]/ies", "\$this->cssvtags('\\1','\\2')", $content);
		} else {
			$content = preg_replace_callback("/\[(.+?)\](.*?)\[end\]/is", array($this, 'loadcsstemplate_callback_cssvtags_12'), $content);
		}

		if($this->csscurmodules && (empty($timecompare) || $timestamp > $timecompare)) {
			$this->csscurmodules = preg_replace(array('/\s*([,;:\{\}])\s*/', '/[\t\n\r]/', '/\/\*.+?\*\//'), array('\\1', '', ''), $this->csscurmodules);

			if(@$fp = fopen(DISCUZ_ROOT . './data/cache/wq_app_setting/csscache/style_wq_app_' . $_G['basescript'] . '_' . CURMODULE . '.css', 'w')) {
				fwrite($fp, $this->csscurmodules);
				fclose($fp);
			} else {
				exit('Can not write to cache files, please check directory ./data/ and ./data/cache/ .');
			}
			$css = 'style_wq_app_' . $_G['basescript'] . '_' . CURMODULE;
			if($css) {
				$scriptcss = '<link rel="stylesheet" type="text/css" href="./data/cache/wq_app_setting/csscache/' . $css . '.css?' . VERHASH . '" />';
			}
		} elseif(!empty($timecompare)) {
			$scriptcss = '<link rel="stylesheet" type="text/css" href="./data/cache/wq_app_setting/csscache/style_wq_app_' . $_G['basescript'] . '_' . CURMODULE . '.css?' . VERHASH . '" />';
		}

		return $scriptcss;
	}

	function loadcsstemplate_callback_cssvtags_12($matches) {
		return $this->cssvtags($matches[1], $matches[2]);
	}

	function cssvtags($param, $content) {
		global $_G;
		$modules = explode(',', $param);
		foreach($modules as $module) {
			$module .= '::'; //fix notice
			list($b, $m) = explode('::', $module);
			if($b && $b == $_G['basescript'] && (!$m || $m == CURMODULE)) {
				$this->csscurmodules .= $content;
				return;
			}
		}
		return;
	}

}
//From: Dism_taobao-com
?>