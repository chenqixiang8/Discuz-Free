<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: function_touch_setting.php 2015-10-8 19:41:34Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function wq_app_setting_save_avatar($url) {

	$dir = DISCUZ_ROOT . "/data/cache/avatarTmp/";

	dmkdir($dir);

	$filename = $dir . '/' . date('His') . strtolower(random(16)) . '.jpg';
	if(preg_match('/^(data:\s*image\/(\w+);base64,)/', $url, $result)) {
		file_put_contents($filename, base64_decode(str_replace($result[1], '', $url)));

		return $filename;
	}
}

function wq_app_setting_uploadAvatar($uid, $localFile) {

	global $_G;
	if(!$uid || !$localFile) {
		return false;
	}

	$localFile = wq_app_setting_save_avatar($localFile);

	list($width, $height, $type, $attr) = getimagesize($localFile);

	if(!$width) {
		return false;
	}

	if($width < 10 || $height < 10 || $type == 4) {
		return false;
	}

	$imageType = array(1 => '.gif', 2 => '.jpg', 3 => '.png');
	$fileType = $imgType[$type];
	if(!$fileType) {
		$fileType = '.jpg';
	}

	$avatarPath = $_G['setting']['attachdir'];
	$tmpAvatar = $avatarPath . './temp/upload' . $uid . $fileType;
	file_exists($tmpAvatar) && @unlink($tmpAvatar);
	file_put_contents($tmpAvatar, file_get_contents($localFile));

	if(!is_file($tmpAvatar)) {
		return false;
	}

	$tmpAvatarBig = './temp/upload' . $uid . 'big' . $fileType;
	$tmpAvatarMiddle = './temp/upload' . $uid . 'middle' . $fileType;
	$tmpAvatarSmall = './temp/upload' . $uid . 'small' . $fileType;

	$image = new image;
	if($image->Thumb($tmpAvatar, $tmpAvatarBig, 200, 250, 1) <= 0) {
		return false;
	}
	if($image->Thumb($tmpAvatar, $tmpAvatarMiddle, 120, 120, 1) <= 0) {
		return false;
	}
	if($image->Thumb($tmpAvatar, $tmpAvatarSmall, 48, 48, 2) <= 0) {
		return false;
	}

	$tmpAvatarBig = $avatarPath . $tmpAvatarBig;
	$tmpAvatarMiddle = $avatarPath . $tmpAvatarMiddle;
	$tmpAvatarSmall = $avatarPath . $tmpAvatarSmall;

	$avatar1 = wq_app_setting_byte2hex(file_get_contents($tmpAvatarBig));
	$avatar2 = wq_app_setting_byte2hex(file_get_contents($tmpAvatarMiddle));
	$avatar3 = wq_app_setting_byte2hex(file_get_contents($tmpAvatarSmall));

	$extra = '&avatar1=' . $avatar1 . '&avatar2=' . $avatar2 . '&avatar3=' . $avatar3;
	$result = wq_app_setting_uc_api_post_ex('user', 'rectavatar', array('uid' => $uid), $extra);
	C::t('common_member')->update($_G['uid'], array('avatarstatus' => '1'));
	updatecreditbyaction('setavatar');
	@unlink($tmpAvatar);
	@unlink($tmpAvatarBig);
	@unlink($tmpAvatarMiddle);
	@unlink($tmpAvatarSmall);
	@unlink($localFile);
	return true;
}

function wq_app_setting_byte2hex($string) {
	$buffer = '';
	$value = unpack('H*', $string);
	$value = str_split($value[1], 2);
	$b = '';
	foreach($value as $k => $v) {
		$b .= strtoupper($v);
	}

	return $b;
}

function wq_app_setting_uc_api_post_ex($module, $action, $arg = array(), $extra = '') {
	$s = $sep = '';
	loaducenter();

	foreach($arg as $k => $v) {
		$k = urlencode($k);
		if(is_array($v)) {
			$s2 = $sep2 = '';
			foreach($v as $k2 => $v2) {
				$k2 = urlencode($k2);
				$s2 .= "$sep2{$k}[$k2]=" . urlencode(uc_stripslashes($v2));
				$sep2 = '&';
			}
			$s .= $sep . $s2;
		} else {
			$s .= "$sep$k=" . urlencode(uc_stripslashes($v));
		}
		$sep = '&';
	}

	$postdata = uc_api_requestdata($module, $action, $s, $extra);
	return uc_fopen2(UC_API . '/index.php', 500000, $postdata, '', TRUE, UC_IP, 20);
}


function wq_get_city_level_upid($level, $upid) {

	$return = array();

	$district = C::t('#wq_app_setting#common_district')->fetch_all_by_level_upid($level, $upid);

	foreach($district as $key => $item) {
		$return[$key] = $item;
		$return[$key]['name'] = diconv($item['name'], CHARSET, 'UTF-8');
	}
	return $return;
}
//From: Dism_taobao-com
?>