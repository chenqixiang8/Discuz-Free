<?php

/**
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: function_wq_app.php 2015-10-8 11:47:28Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function wq_profile_setting($fieldid, $space = array(), $showstatus = false, $ignoreunchangable = false, $ignoreshowerror = false) {
	global $_G;

	if(empty($_G['cache']['profilesetting'])) {
		loadcache('profilesetting');
	}
	$field = $_G['cache']['profilesetting'][$fieldid];
	if(empty($field) || !$field['available'] || in_array($fieldid, array('uid', 'constellation', 'zodiac', 'birthmonth', 'birthyear', 'birthprovince', 'birthdist', 'birthcommunity', 'resideprovince', 'residedist', 'residecommunity'))) {
		return '';
	}
	$reqired = '';
	if($field['required']) {
		$reqired = '(' . lang('spacecp', 'required') . ')';
	}

	if($showstatus) {
		$uid = intval($space['uid']);
		if($uid && !isset($_G['profile_verifys'][$uid])) {
			$_G['profile_verifys'][$uid] = array();
			if($value = C::t('common_member_verify_info')->fetch_by_uid_verifytype($uid, 0)) {
				$fields = dunserialize($value['field']);
				foreach($fields as $key => $fvalue) {
					if($_G['cache']['profilesetting'][$key]['needverify']) {
						$_G['profile_verifys'][$uid][$key] = $fvalue;
					}
				}
			}
		}
		$verifyvalue = NULL;
		if(isset($_G['profile_verifys'][$uid][$fieldid])) {
			if($fieldid == 'gender') {
				$verifyvalue = lang('space', 'gender_' . intval($_G['profile_verifys'][$uid][$fieldid]));
			} elseif($fieldid == 'birthday') {
				$verifyvalue = $_G['profile_verifys'][$uid]['birthyear'] . '-' . $_G['profile_verifys'][$uid]['birthmonth'] . '-' . $_G['profile_verifys'][$uid]['birthday'];
			} else {
				$verifyvalue = $_G['profile_verifys'][$uid][$fieldid];
			}
		}
	}

	$html = '';
	$field['unchangeable'] = !$ignoreunchangable && $field['unchangeable'] ? 1 : 0;
	if($fieldid == 'birthday') {
		if($field['unchangeable'] && !empty($space[$fieldid])) {
			return '<span>' . $space['birthyear'] . '-' . $space['birthmonth'] . '-' . $space['birthday'] . '</span>';
		}
		$birthyeayhtml = '';
		$nowy = dgmdate($_G['timestamp'], 'Y');
		for($i = 0; $i < 100; $i++) {
			$they = $nowy - $i;
			$selectstr = $they == $space['birthyear'] ? ' selected' : '';
			$birthyeayhtml .= "<option value=\"$they\"$selectstr>$they</option>";
		}
		$birthmonthhtml = '';
		for($i = 1; $i < 13; $i++) {
			$selectstr = $i == $space['birthmonth'] ? ' selected' : '';
			$birthmonthhtml .= "<option value=\"$i\"$selectstr>$i</option>";
		}
		$birthdayhtml = '';
		if(empty($space['birthmonth']) || in_array($space['birthmonth'], array(1, 3, 5, 7, 8, 10, 12))) {
			$days = 31;
		} elseif(in_array($space['birthmonth'], array(4, 6, 9, 11))) {
			$days = 30;
		} elseif($space['birthyear'] && (($space['birthyear'] % 400 == 0) || ($space['birthyear'] % 4 == 0 && $space['birthyear'] % 400 != 0))) {
			$days = 29;
		} else {
			$days = 28;
		}
		for($i = 1; $i <= $days; $i++) {
			$selectstr = $i == $space['birthday'] ? ' selected' : '';
			$birthdayhtml .= "<option value=\"$i\"$selectstr>$i</option>";
		}

		$html = '<select name="birthyear" id="birthyear" class="ps" onchange="showbirthday();" tabindex="1">'
			. '<option value="">' . $field['title'] . $reqired . ': ' . lang('space', 'year') . '</option>'
			. $birthyeayhtml
			. '</select>'
			. '<select name="birthmonth" id="birthmonth" class="ps" onchange="showbirthday();" tabindex="1">'
			. '<option value="">' . $field['title'] . $reqired . ': ' . lang('space', 'month') . '</option>'
			. $birthmonthhtml
			. '</select>'
			. '<select name="birthday" id="birthday" class="ps" tabindex="1">'
			. '<option value="">' . $field['title'] . $reqired . ': ' . lang('space', 'day') . '</option>'
			. $birthdayhtml
			. '</select>';
	} elseif($fieldid == 'gender') {
		if($field['unchangeable'] && $space[$fieldid] > 0) {
			return '<span>' . lang('space', 'gender_' . intval($space[$fieldid])) . '</span>';
		}
		$selected = array($space[$fieldid] => ' selected="selected"');
		$html = '<select name="gender" id="gender" class="ps" tabindex="1">';
		if($field['unchangeable']) {
			$html .= '<option value="">' . lang('space', 'gender') . $reqired . '</option>';
		} else {
			$html .= '<option value="0"' . ($space[$fieldid] == '0' ? ' selected="selected"' : '') . '>' . lang('space', 'gender') . $reqired . ': ' . lang('space', 'gender_0') . '</option>';
		}
		$html .= '<option value="1"' . ($space[$fieldid] == '1' ? ' selected="selected"' : '') . '>' . lang('space', 'gender_1') . '</option>'
			. '<option value="2"' . ($space[$fieldid] == '2' ? ' selected="selected"' : '') . '>' . lang('space', 'gender_2') . '</option>'
			. '</select>';
	} elseif($fieldid == 'birthcity') {
		if($field['unchangeable'] && !empty($space[$fieldid])) {
			return '<span>' . $space['birthprovince'] . '-' . $space['birthcity'] . '</span>';
		}
		$values = array(0, 0, 0, 0);
		$elems = array('birthprovince', 'birthcity', 'birthdist', 'birthcommunity');
		if(!empty($space['birthprovince'])) {
			$html = profile_show('birthcity', $space);
			$html .= '&nbsp;(<a href="javascript:;">' . lang('spacecp', 'profile_edit') . '</a>)';
			$html .= '<p id="birthdistrictbox"></p>';
		} else {
			$title = $field['title'] . $reqired . ': ';
			$html = '<p id="birthdistrictbox">' . wq_showdistrict($values, $elems, 'birthdistrictbox', 1, 'birth', $title) . '</p>';
		}
	} elseif($fieldid == 'residecity') {
		if($field['unchangeable'] && !empty($space[$fieldid])) {
			return '<span>' . $space['resideprovince'] . '-' . $space['residecity'] . '</span>';
		}
		$values = array(0, 0, 0, 0);
		$elems = array('resideprovince', 'residecity', 'residedist', 'residecommunity');
		if(!empty($space['resideprovince'])) {
			$html = profile_show('residecity', $space);
			$html .= '&nbsp;(<a href="javascript:;" >' . lang('spacecp', 'profile_edit') . '</a>)';
			$html .= '<p id="residedistrictbox"></p>';
		} else {
			$title = $field['title'] . $reqired . ': ';
			$html = '<p id="residedistrictbox">' . wq_showdistrict($values, $elems, 'residedistrictbox', 1, 'reside', $title) . '</p>';
		}
	} elseif($fieldid == 'qq') {
		$html = "<input type=\"text\" name=\"$fieldid\" id=\"$fieldid\" class=\"px\" value=\"$space[$fieldid]\" placeholder=\"$field[title]$reqired\" tabindex=\"1\" /><p><a href=\"\" class=\"xi2\" onclick=\"this.href='http://wp.qq.com/set.html?from=discuz&uin='+$('$fieldid').value\" target=\"_blank\">" . lang('spacecp', 'qq_set_status') . "</a></p>";
	} else {
		if($field['unchangeable'] && $space[$fieldid] != '') {
			if($field['formtype'] == 'file') {
				$imgurl = getglobal('setting/attachurl') . './profile/' . $space[$fieldid];
				return '<span><a href="' . $imgurl . '" target="_blank"><img src="' . $imgurl . '"  style="max-width: 500px;" /></a></span>';
			} else {
				return '<span>' . nl2br($space[$fieldid]) . '</span>';
			}
		}
		if($field['formtype'] == 'textarea') {
			$html = "<textarea name=\"$fieldid\" id=\"$fieldid\" class=\"pt\" rows=\"3\" cols=\"40\" placeholder=\"$field[title]$reqired\" tabindex=\"1\">$space[$fieldid]</textarea>";
		} elseif($field['formtype'] == 'select') {
			$field['choices'] = explode("\n", $field['choices']);
			$html = "<select name=\"$fieldid\" id=\"$fieldid\" class=\"ps\" tabindex=\"1\">";
			$html .= "<option value=\"\">$field[title]$reqired</option>";
			foreach($field['choices'] as $op) {
				$html .= "<option value=\"$op\"" . ($op == $space[$fieldid] ? 'selected="selected"' : '') . ">$op</option>";
			}
			$html .= '</select>';
		} elseif($field['formtype'] == 'list') {
			$field['choices'] = explode("\n", $field['choices']);
			$html = '';
			if(!empty($field['choices'])) {
				$html .= "{$field['title']}{$reqired}<br />";
			}

			$html .= "<select name=\"{$fieldid}[]\" id=\"$fieldid\" class=\"ps\" multiple=\"multiplue\" tabindex=\"1\">";
			$space[$fieldid] = explode("\n", $space[$fieldid]);
			foreach($field['choices'] as $op) {
				$html .= "<option value=\"$op\"" . (in_array($op, $space[$fieldid]) ? 'selected="selected"' : '') . ">$op</option>";
			}
			$html .= '</select>';
		} elseif($field['formtype'] == 'checkbox') {
			$field['choices'] = explode("\n", $field['choices']);
			$space[$fieldid] = explode("\n", $space[$fieldid]);
			if(!empty($field['choices'])) {
				$html .= "{$field['title']}{$reqired}<br />";
			}
			foreach($field['choices'] as $k => $op) {
				$html .= ''
					. "<span class=\"lb\"><input type=\"checkbox\" name=\"{$fieldid}[]\" id=\"$fieldid{$k}\" class=\"pc\" value=\"$op\" tabindex=\"1\"" . (in_array($op, $space[$fieldid]) ? ' checked="checked"' : '') . " id=\"{$fieldid}{$k}\" /><label for=\"{$fieldid}{$k}\">$op</label></span>";
			}
		} elseif($field['formtype'] == 'radio') {
			$field['choices'] = explode("\n", $field['choices']);
			if(!empty($field['choices'])) {
				$html .= "{$field['title']}{$reqired}<br />";
			}
			foreach($field['choices'] as $k => $op) {
				$html .= ''
					. "<span class=\"lb\"><input type=\"radio\" name=\"{$fieldid}\" class=\"pr\" value=\"$op\" tabindex=\"1\"" . ($op == $space[$fieldid] ? ' checked="checked"' : '') . " id=\"{$fieldid}{$k}\" /><label for=\"{$fieldid}{$k}\">$op</label></span>";
			}
		} elseif($field['formtype'] == 'file') {
			$html = "$field[title]$reqired<input type=\"file\" value=\"\" name=\"$fieldid\" id=\"$fieldid\" tabindex=\"1\" class=\"pf\" /><input type=\"hidden\" name=\"$fieldid\" value=\"$space[$fieldid]\" />";
			if(!empty($space[$fieldid])) {
				$url = getglobal('setting/attachurl') . './profile/' . $space[$fieldid];
				$html .= "&nbsp;<label><input type=\"checkbox\" class=\"checkbox\" tabindex=\"1\" name=\"deletefile[$fieldid]\" id=\"$fieldid\" value=\"yes\" />" . lang('spacecp', 'delete') . "</label><br /><a href=\"$url\" target=\"_blank\"><img src=\"$url\" width=\"200\" class=\"mtm\" /></a>";
			}
		} else {

			$html = "<input type=\"text\" name=\"$fieldid\" id=\"$fieldid\" class=\"px\" value=\"$space[$fieldid]\" tabindex=\"1\" placeholder=\"$field[title]$reqired\"/>";
		}
	}
	$html .=!$ignoreshowerror ? "<div class=\"rq mtn\" id=\"showerror_$fieldid\"></div>" : '';
	if($showstatus) {
		$html .= "<p class=\"d\">$value[description]";
		if($space[$fieldid] == '' && $value['unchangeable']) {
			$html .= lang('spacecp', 'profile_unchangeable');
		}
		if($verifyvalue !== null) {
			if($field['formtype'] == 'file') {
				$imgurl = getglobal('setting/attachurl') . './profile/' . $verifyvalue;
				$verifyvalue = "<img src='$imgurl' alt='$imgurl' style='max-width: 500px;'/>";
			}
			$html .= "<strong>" . lang('spacecp', 'profile_is_verifying') . " (<a href=\"#\" onclick=\"display('newvalue_$fieldid');return false;\">" . lang('spacecp', 'profile_mypost') . "</a>)</strong>"
				. "<p id=\"newvalue_$fieldid\" style=\"display:none\">" . $verifyvalue . "</p>";
		} elseif($field['needverify']) {
			$html .= lang('spacecp', 'profile_need_verifying');
		}
		$html .= '</p>';
	}

	return $html;
}

function wq_showdistrict($values, $elems = array(), $container = 'districtbox', $showlevel = null, $containertype = 'birth', $title = '') {
	$html = '';
	if(!preg_match("/^[A-Za-z0-9_]+$/", $container)) {
		return $html;
	}
	$showlevel = !empty($showlevel) ? intval($showlevel) : count($values);
	$showlevel = $showlevel <= 4 ? $showlevel : 4;
	$upids = array(0);
	for($i = 0; $i < $showlevel; $i++) {
		if(!empty($values[$i])) {
			$upids[] = intval($values[$i]);
		} else {
			for($j = $i; $j < $showlevel; $j++) {
				$values[$j] = '';
			}
			break;
		}
	}
	$options = array(1 => array(), 2 => array(), 3 => array(), 4 => array());
	if($upids && is_array($upids)) {
		foreach(C::t('common_district')->fetch_all_by_upid($upids, 'displayorder', 'ASC') as $value) {
			if($value['level'] == 1 && ($value['id'] != $values[0] && ($value['usetype'] == 0 || !(($containertype == 'birth' && in_array($value['usetype'], array(1, 3))) || ($containertype != 'birth' && in_array($value['usetype'], array(2, 3))))))) {
				continue;
			}
			$options[$value['level']][] = array($value['id'], $value['name']);
		}
	}
	$names = array('province', 'city', 'district', 'community');
	for($i = 0; $i < 4; $i++) {
		if(!empty($elems[$i])) {
			$elems[$i] = dhtmlspecialchars(preg_replace("/[^\[A-Za-z0-9_\]]/", '', $elems[$i]));
		} else {
			$elems[$i] = ($containertype == 'birth' ? 'birth' : 'reside') . $names[$i];
		}
	}

	for($i = 0; $i < $showlevel; $i++) {
		$level = $i + 1;
		if(!empty($options[$level])) {
			$html .= '<select name="' . $elems[$i] . '" id="' . $elems[$i] . '" class="ps"  tabindex="1">';
			$html .= '<option value="">' . $title . lang('spacecp', 'district_level_' . $level) . '</option>';
			foreach($options[$level] as $option) {
				$selected = $option[0] == $values[$i] ? ' selected="selected"' : '';
				$html .= '<option did="' . $option[0] . '" value="' . $option[1] . '"' . $selected . '>' . $option[1] . '</option>';
			}
			$html .= '</select>';
		}
	}
	return $html;
}

function wq_app_setting_discuzcode($message, $smileyoff, $bbcodeoff, $htmlon = 0, $allowsmilies = 1, $allowbbcode = 1, $allowimgcode = 1, $allowhtml = 0, $jammer = 0, $parsetype = '0', $authorid = '0', $allowmediacode = '0', $pid = 0, $lazyload = 0, $pdateline = 0, $first = 0) {
	global $_G;

	static $authorreplyexist;

	if($pid && strpos($message, '[/password]') !== FALSE) {
		if($authorid != $_G['uid'] && !$_G['forum']['ismoderator']) {
			$message = preg_replace("/\s?\[password\](.+?)\[\/password\]\s?/ie", "parsepassword('\\1', \$pid)", $message);
			if($_G['forum_discuzcode']['passwordlock'][$pid]) {
				return '';
			}
		} else {
			$message = preg_replace("/\s?\[password\](.+?)\[\/password\]\s?/ie", "", $message);
			$_G['forum_discuzcode']['passwordauthor'][$pid] = 1;
		}
	}

	if($parsetype != 1 && !$bbcodeoff && $allowbbcode && (strpos($message, '[/code]') || strpos($message, '[/CODE]')) !== FALSE) {
		$message = preg_replace("/\s?\[code\](.+?)\[\/code\]\s?/ies", "codedisp('\\1')", $message);
	}

	$msglower = strtolower($message);

	$htmlon = $htmlon && $allowhtml ? 1 : 0;

	if(!$htmlon) {
		$message = dhtmlspecialchars($message);
	} else {
		$message = preg_replace("/<script[^\>]*?>(.*?)<\/script>/i", '', $message);
	}

	if($_GET['mod'] != 'post' && $_GET['action'] != 'edit') {
		if($_G['setting']['plugins']['func'][HOOKTYPE]['discuzcode']) {
			$_G['discuzcodemessage'] = & $message;
			$param = func_get_args();
			hookscript('discuzcode', 'global', 'funcs', array('param' => $param, 'caller' => 'discuzcode'), 'discuzcode');
		}
	}

	if(!$smileyoff && $allowsmilies) {
		$message = parsesmiles($message);
	}

	if($_G['setting']['allowattachurl'] && strpos($msglower, 'attach://') !== FALSE) {
		$message = preg_replace("/attach:\/\/(\d+)\.?(\w*)/ie", "parseattachurl('\\1', '\\2', 1)", $message);
	}

	if($allowbbcode) {
		if(strpos($msglower, 'ed2k://') !== FALSE) {
			$message = preg_replace("/ed2k:\/\/(.+?)\//e", "parseed2k('\\1')", $message);
		}
	}

	if(!$bbcodeoff && $allowbbcode) {
		if(strpos($msglower, '[/url]') !== FALSE) {
			$message = preg_replace("/\[url(=((https?|ftp|gopher|news|telnet|rtsp|mms|callto|bctp|thunder|qqdl|synacast){1}:\/\/|www\.|mailto:)?([^\r\n\[\"']+?))?\](.+?)\[\/url\]/ies", "parseurl('\\1', '\\5', '\\2')", $message);
		}
		if(strpos($msglower, '[/email]') !== FALSE) {
			$message = preg_replace("/\[email(=([a-z0-9\-_.+]+)@([a-z0-9\-_]+[.][a-z0-9\-_.]+))?\](.+?)\[\/email\]/ies", "parseemail('\\1', '\\4')", $message);
		}

		$nest = 0;
		while(strpos($msglower, '[table') !== FALSE && strpos($msglower, '[/table]') !== FALSE) {
			$message = preg_replace("/\[table(?:=(\d{1,4}%?)(?:,([\(\)%,#\w ]+))?)?\]\s*(.+?)\s*\[\/table\]/ies", "parsetable('\\1', '\\2', '\\3')", $message);
			if(++$nest > 4)
				break;
		}

		$message = str_replace(array(
			'[/color]', '[/backcolor]', '[/size]', '[/font]', '[/align]', '[b]', '[/b]', '[s]', '[/s]', '[hr]', '[/p]',
			'[i=s]', '[i]', '[/i]', '[u]', '[/u]', '[list]', '[list=1]', '[list=a]',
			'[list=A]', "\r\n[*]", '[*]', '[/list]', '[indent]', '[/indent]', '[/float]'
			), array(
			'</font>', '</font>', '</font>', '</font>', '</div>', '<strong>', '</strong>', '<strike>', '</strike>', '<hr class="l" />', '</p>', '<i class="pstatus">', '<i>',
			'</i>', '<u>', '</u>', '<ul>', '<ul type="1" class="litype_1">', '<ul type="a" class="litype_2">',
			'<ul type="A" class="litype_3">', '<li>', '<li>', '</ul>', '<blockquote>', '</blockquote>', '</span>'
			), preg_replace(array(
			"/\[color=([#\w]+?)\]/i",
			"/\[color=((rgb|rgba)\([\d\s,]+?\))\]/i",
			"/\[backcolor=([#\w]+?)\]/i",
			"/\[backcolor=((rgb|rgba)\([\d\s,]+?\))\]/i",
			"/\[size=(\d{1,2}?)\]/i",
			"/\[size=(\d{1,2}(\.\d{1,2}+)?(px|pt)+?)\]/i",
			"/\[font=([^\[\<]+?)\]/i",
			"/\[align=(left|center|right)\]/i",
			"/\[p=(\d{1,2}|null), (\d{1,2}|null), (left|center|right)\]/i",
			"/\[float=left\]/i",
			"/\[float=right\]/i"
				), array(
			"<font color=\"\\1\">",
			"<font style=\"color:\\1\">",
			"<font style=\"background-color:\\1\">",
			"<font style=\"background-color:\\1\">",
			"<font size=\"\\1\">",
			"<font style=\"font-size:\\1\">",
			"<font face=\"\\1\">",
			"<div align=\"\\1\">",
			"<p style=\"line-height:\\1px;text-indent:\\2em;text-align:\\3\">",
			"<span style=\"float:left;margin-right:5px\">",
			"<span style=\"float:right;margin-left:5px\">"
				), $message));

		if($pid && !defined('IN_MOBILE')) {
			$message = preg_replace("/\s?\[postbg\]\s*([^\[\<\r\n;'\"\?\(\)]+?)\s*\[\/postbg\]\s?/ies", "parsepostbg('\\1', '$pid')", $message);
		} else {
			$message = preg_replace("/\s?\[postbg\]\s*([^\[\<\r\n;'\"\?\(\)]+?)\s*\[\/postbg\]\s?/is", "", $message);
		}

		if($parsetype != 1) {
			if(strpos($msglower, '[/quote]') !== FALSE) {
				$message = preg_replace("/\s?\[quote\][\n\r]*(.+?)[\n\r]*\[\/quote\]\s?/is", tpl_quote(), $message);
			}
			if(strpos($msglower, '[/free]') !== FALSE) {
				$message = preg_replace("/\s*\[free\][\n\r]*(.+?)[\n\r]*\[\/free\]\s*/is", tpl_free(), $message);
			}
		}
		if($parsetype != 1 && $allowbbcode < 0 && isset($_G['cache']['bbcodes'][-$allowbbcode])) {
			$message = preg_replace($_G['cache']['bbcodes'][-$allowbbcode]['searcharray'], $_G['cache']['bbcodes'][-$allowbbcode]['replacearray'], $message);
		}
		if($parsetype != 1 && strpos($msglower, '[/hide]') !== FALSE && $pid) {
			if($_G['setting']['hideexpiration'] && $pdateline && (TIMESTAMP - $pdateline) / 86400 > $_G['setting']['hideexpiration']) {
				$message = preg_replace("/\[hide[=]?(d\d+)?[,]?(\d+)?\]\s*(.*?)\s*\[\/hide\]/is", "\\3", $message);
				$msglower = strtolower($message);
			}
			if(strpos($msglower, '[hide=d') !== FALSE) {
				$message = preg_replace("/\[hide=(d\d+)?[,]?(\d+)?\]\s*(.*?)\s*\[\/hide\]/ies", "expirehide('\\1','\\2','\\3', $pdateline)", $message);
				$msglower = strtolower($message);
			}
			if(strpos($msglower, '[hide]') !== FALSE) {
				if($authorreplyexist === null) {
					if(!$_G['forum']['ismoderator']) {
						if($_G['uid']) {
							$_post = C::t('forum_post')->fetch('tid:' . $_G['tid'], $pid);
							$authorreplyexist = $_post['tid'] == $_G['tid'] ? C::t('forum_post')->fetch_pid_by_tid_authorid($_G['tid'], $_G['uid']) : FALSE;
						}
					} else {
						$authorreplyexist = TRUE;
					}
				}
				if($authorreplyexist) {
					$message = preg_replace("/\[hide\]\s*(.*?)\s*\[\/hide\]/is", tpl_hide_reply(), $message);
				} else {
					$message = preg_replace("/\[hide\](.*?)\[\/hide\]/is", tpl_hide_reply_hidden(), $message);
					$message = '<script type="text/javascript">replyreload += \',\' + ' . $pid . ';</script>' . $message;
				}
			}
			if(strpos($msglower, '[hide=') !== FALSE) {
				$message = preg_replace("/\[hide=(\d+)\]\s*(.*?)\s*\[\/hide\]/ies", "creditshide(\\1,'\\2', $pid, $authorid)", $message);
			}
		}
	}

	if(!$bbcodeoff) {
		if($parsetype != 1 && strpos($msglower, '[swf]') !== FALSE) {
			$message = preg_replace("/\[swf\]\s*([^\[\<\r\n]+?)\s*\[\/swf\]/ies", "bbcodeurl('\\1', ' <img src=\"'.STATICURL.'image/filetype/flash.gif\" align=\"absmiddle\" alt=\"\" /> <a href=\"{url}\" target=\"_blank\">Flash: {url}</a> ')", $message);
		}

		if(defined('IN_MOBILE') && !defined('TPL_DEFAULT') && !defined('IN_MOBILE_API')) {
			$allowimgcode = false;
		}
		$attrsrc = !IS_ROBOT && $lazyload ? 'file' : 'src';
		if(strpos($msglower, '[/img]') !== FALSE) {
			$message = preg_replace(array(
				"/\[img\]\s*([^\[\<\r\n]+?)\s*\[\/img\]/ies",
				"/\[img=(\d{1,4})[x|\,](\d{1,4})\]\s*([^\[\<\r\n]+?)\s*\[\/img\]/ies"
				), $allowimgcode ? array(
					"parseimg(0, 0, '\\1', " . intval($lazyload) . ", " . intval($pid) . ", 'onmouseover=\"img_onmouseoverfunc(this)\" " . ($lazyload ? "lazyloadthumb=\"1\"" : "onload=\"thumbImg(this)\"") . "')",
					"parseimg('\\1', '\\2', '\\3', " . intval($lazyload) . ", " . intval($pid) . ")"
					) : ($allowbbcode ? array(
						(!defined('IN_MOBILE') ? "bbcodeurl('\\1', '<a href=\"{url}\" target=\"_blank\">{url}</a>')" : "bbcodeurl('\\1', '')"),
						(!defined('IN_MOBILE') ? "bbcodeurl('\\3', '<a href=\"{url}\" target=\"_blank\">{url}</a>')" : "bbcodeurl('\\3', '')"),
						) : array("bbcodeurl('\\1', '{url}')", "bbcodeurl('\\3', '{url}')")), $message);
		}
	}

	for($i = 0; $i <= $_G['forum_discuzcode']['pcodecount']; $i ++) {
		$message = str_replace("[\tDISCUZ_CODE_$i\t]", $_G['forum_discuzcode']['codehtml'][$i], $message);
	}

	unset($msglower);

	if($jammer) {
		$message = preg_replace("/\r\n|\n|\r/e", "jammer()", $message);
	}
	if($first) {
		if(helper_access::check_module('group')) {
			$message = preg_replace("/\[groupid=(\d+)\](.*)\[\/groupid\]/i", lang('forum/template', 'fromgroup') . ': <a href="forum.php?mod=forumdisplay&fid=\\1" target="_blank">\\2</a>', $message);
		} else {
			$message = preg_replace("/(\[groupid=\d+\].*\[\/groupid\])/i", '', $message);
		}
	}
	return $htmlon ? $message : nl2br(str_replace(array("\t", '   ', '  '), array('&nbsp; &nbsp; &nbsp; &nbsp; ', '&nbsp; &nbsp;', '&nbsp;&nbsp;'), $message));
}

function wq_app_writetocache($script, $array, $prefix = 'wq_') {
	global $_G;

	$setting = get_wq_app_setting();

	$datas = array(
		'expireat' => time() + $setting['memory_time'],
		'data' => $array
	);

	include_once libfile('function/cache');
	$cachedata = getcachevars(array('info' => $datas));

	if(memory('check')) {
		return memory('set', $prefix . $script, serialize($datas), $setting['memory_time']);
	}

	global $_G;

	$dir = DISCUZ_ROOT . './data/sysdata/wq_app/';
	if(!is_dir($dir)) {
		dmkdir($dir, 0777);
	}

	if($fp = @fopen($dir . $prefix . $script . ".php", 'wb')) {
		fwrite($fp, "<?php\n//Discuz! cache file, DO NOT modify me!\n//Identify: " . md5($prefix . $script . '.php' . $cachedata . $_G['config']['security']['authkey']) . "\n\n" . $cachedata . "?>");
		fclose($fp);
	} else {
		exit('Can not write to cache files, please check directory ./data/ and ./data/sysdata/ .');
	}
}

function wq_app_readfromcache($script, $prefix = 'wq_') {

	if(memory('check')) {
		$data = memory('get', $prefix . $script);
		$ret = unserialize($data);
		return $ret['data'];
	}

	global $_G;

	$dir = DISCUZ_ROOT . './data/sysdata/wq_app/';
	if(!is_dir($dir)) {
		dmkdir($dir, 0777);
	}

	$ret = array();

	if(is_file($dir . $prefix . $script . ".php")) {
		@include $dir . $prefix . $script . ".php";
		if(time() < $info['expireat']) {
			$ret = $info['data'];
		}
	}
	return $ret;
}

function wq_app_showforum(&$forum, $type = '', $last = '', $liststyles = array(), $style = '1', $toggle = false) {
	global $_G;

	if($last == '') {
		$return = '<tr class="hover">' .
			'<td class="td25"' . ($type == 'group' ? ' onclick="toggle_group(\'group_' . $forum['fid'] . '\', $(\'a_group_' . $forum['fid'] . '\'))"' : '') . '>' . ($type == 'group' ? '<a href="javascript:;" id="a_group_' . $forum['fid'] . '">' . ($toggle ? '[+]' : '[-]') . '</a>' : '') . '</td>
			<td>';
		if($type == 'group') {
			$return .= '<div class="parentboard">';
			$_G['fg'] = !empty($_G['fg']) ? intval($_G['fg']) : 0;
			$_G['fg'] ++;
		} elseif($type == '') {
			$return .= '<div class="board">';
		} elseif($type == 'sub') {
			$return .= '<div id="cb_' . $forum['fid'] . '" class="childboard">';
		}
		$return .= dhtmlspecialchars($forum['name']) . '</td><td>' . ($type == 'group' ? "" : select_html($liststyles, 'forumstyle[' . $forum['fid'] . ']', $style, false, false)) . '</td><td></td></tr>';
		if($type == 'group')
			$return .= '<tbody id="group_' . $forum['fid'] . '"' . ($toggle ? ' style="display:none;"' : '') . '>';
	} else {
		$return = '</tbody>';
	}

	echo $return = isset($return) ? $return : '';
}

function wq_app_setting_parseforumattach(&$post, $aids) {

	if(($aids = array_unique($aids))) {
		$_searchs = $_replaces = array();
		foreach(C::t('forum_attachment_n')->fetch_all_by_id('tid:' . $post['tid'], 'aid', $aids) as $attach) {
			if($attach['isimage']) {
				$_replaces[$attach['aid']] = '<img src="' . wq_app_setting_get_picurl($attach['attachment'], $attach['remote'], $attach['thumb']) . '"/>';
				$_searchs[$attach['aid']] = '[attach]' . $attach['aid'] . '[/attach]';
			}
		}
	}
	if($_searchs && $_replaces) {
		$post['message'] = str_ireplace($_searchs, $_replaces, $post['message']);
	}
}

function wq_app_get_forum_in_group() {
	global $_G;

	if(!function_exists('forum')) {
		require_once libfile('function/forumlist');
	}

	$fids = array();
	foreach($_G['cache']['forums'] as $val) {
		$fids[$val['fid']] = $val['fid'];
	}

	$forum_access = array();
	if(!empty($_G['member']['accessmasks'])) {
		$forum_access = C::t('forum_access')->fetch_all_by_fid_uid($fids, $_G['uid']);
	}
	$forum_fields = C::t('forum_forumfield')->fetch_all($fids);

	foreach($_G['cache']['forums'] as $gkey => $gval) {
		$gval = wq_app_setting_forum_info_merge($gval, $forum_fields, $forum_access);

		if($gval['type'] == 'group' && $gval['status'] == '1' && forum($gval)) {
			$catlist[$gkey] = $gval;
			foreach($_G['cache']['forums'] as $fkey => $fval) {
				$fval = wq_app_setting_forum_info_merge($fval, $forum_fields, $forum_access);

				if($fval['type'] == 'forum' && $fval['status'] == '1' && $fval['fup'] == $gval['fid'] && forum($fval)) {
					$catlist[$gkey]['forums'][] = $fval['fid'];
					foreach($_G['cache']['forums'] as $skey => $sval) {
						$sval = wq_app_setting_forum_info_merge($sval, $forum_fields, $forum_access);

						if($sval['type'] == 'sub' && $sval['status'] == '1' && $sval['fup'] == $fval['fid'] && forum($sval)) {
							$catlist[$gkey]['forums'][] = $sval['fid'];
						}
					}
				}
			}

			if(empty($catlist[$gkey]['forums'])) {
				unset($catlist[$gkey]);
			}
		}
	}
	return $catlist;
}

function wq_app_setting_forum_info_merge($forum, $forum_fields, $forum_access) {

	if($forum_fields[$forum['fid']]['fid']) {
		$forum = array_merge($forum, $forum_fields[$forum['fid']]);
	}

	if($forum_access['fid']) {
		$forum = array_merge($forum, $forum_access[$forum['fid']]);
	}
	return $forum;
}

function wq_app_reply_msg_dispose($v, $flag = false) {
	global $_G;
	$wq_app_Plang = wq_app_get_Plang();
	$rauthor = '';

	if(!function_exists('discuzcode')) {
		include_once libfile('function/discuzcode');
	}

	if(dstrpos($v['message'], '/quote') !== false && dstrpos($v['message'], $wq_app_Plang['ecdaa3f726064eb1']) !== false) {
		$rauthor = substr($v['message'], strpos($v['message'], 'color=') + 14, strpos($v['message'], $wq_app_Plang['ecdaa3f726064eb1']) - (strpos($v['message'], 'color=') + 14));
		$v['message'] = trim(substr($v['message'], strpos($v['message'], '/quote') + 7));
	}
	$v['message'] = preg_replace("/\[attach\](\d+)\[\/attach\]/i", '&#x3010;&#x56FE;&#x7247;&#x3011;', $v['message']);
	$v['message'] = preg_replace("/\[attachimg\](\d+)\[\/attachimg\]/i", '', $v['message']);
	$v['message'] = preg_replace("/\[flash\](\w+)\[\/flash\]/i", '', $v['message']);
	$v['message'] = preg_replace("/\[media\](\w+)\[\/media\]/i", '', $v['message']);
	$v['message'] = preg_replace("/\[url\](\w+)\[\/url\]/i", '', $v['message']);
	$v['message'] = preg_replace("/\[img\](\w+)\[\/img\]/i", '', $v['message']);
	$v['message'] = preg_replace("/\[audio\](\w+)\[\/audio\]/i", '', $v['message']);
	$v['message'] = cutstr(preg_replace("/(\<[^\<]*\>|\r|\n|\s|\[.+?\])/is", '', $v['message']), 80, '');
	$v['message'] = discuzcode($v['message']);
	$re['author'] = $v['author'];
	$re['authorid'] = $v['authorid'];
	$re['rauthor'] = $rauthor;
	$re['rauthorid'] = $rauthor ? C::t('common_member')->fetch_uid_by_username($rauthor) : 0;
	$re['message'] = $v['message'];

	return $re;
}

function get_wq_app_summary_pids_by_tids($tids) {
	global $_G;
	require_once libfile('function/discuzcode');
	loadcache('usergroups');

	$setting = get_wq_app_setting();

	$forum_post = DB::fetch_all('SELECT p.*,f.* FROM ' . DB::table('forum_post') . ' p '
			. "LEFT JOIN " . DB::table('forum_forum') . " f ON f.fid=p.fid "
			. 'WHERE p.tid IN(%n) AND p.first=1', array($tids));

	foreach($forum_post as $post) {
		$tid = $post['tid'];
		$userinfo = getuserbyuid($post['authorid']);
		$forum_allowbbcode = $post['allowbbcode'] ? -$userinfo['groupid'] : 0;
		$post['message'] = preg_replace("/\[attach\](\d+)\[\/attach\]/i", '', $post['message']);
		$post['message'] = preg_replace("/\[attachimg\](\d+)\[\/attachimg\]/i", '', $post['message']);
		$post['message'] = preg_replace("/\[flash\](\w+)\[\/flash\]/i", '', $post['message']);
		$post['message'] = preg_replace("/\[media\](\w+)\[\/media\]/i", '', $post['message']);
		$post['message'] = preg_replace("/\[url\](\w+)\[\/url\]/i", '', $post['message']);
		$post['message'] = preg_replace("/\[img\](\w+)\[\/img\]/i", '', $post['message']);
		$post['message'] = preg_replace("/\[audio\](\w+)\[\/audio\]/i", '', $post['message']);
		$post['message'] = wq_app_messagecutstr($post['message'], $setting['message_length']);

		$post['message'] = discuzcode($post['message'], $post['smileyoff'], $post['bbcodeoff'], $post['htmlon'] & 1, $post['allowsmilies'], -1, ($post['allowimgcode'] && $_G['setting']['showimages'] ? 1 : 0), $post['allowhtml'], ($post['jammer'] && $post['authorid'] != $_G['uid'] ? 1 : 0), 0, $post['authorid'], $_G['cache']['usergroups'][$userinfo['groupid']]['allowmediacode'] && $post['allowmediacode'], $post['pid'], $_G['setting']['lazyload'], $post['dateline'], $post['first']);
		$summarys[$tid] = $post['message'];
		$pids[$tid] = $post['pid'];
		$fids[$tid] = $post['name'];
	}

	return array('summarys' => $summarys, 'pids' => $pids, 'fids' => $fids);
}

function wq_app_messagecutstr($str, $length = 0, $dot = ' ...') {
	global $_G;
	$str = wq_app_messagesafeclear($str);
	$sppos = strpos($str, chr(0) . chr(0) . chr(0));
	if($sppos !== false) {
		$str = substr($str, 0, $sppos);
	}
	$language = lang('forum/misc');
	loadcache(array('bbcodes_display', 'bbcodes', 'smileycodes', 'smilies', 'smileytypes', 'domainwhitelist'));
	$bbcodes = 'b|i|u|p|color|size|font|align|list|indent|float';
	$bbcodesclear = 'email|code|free|table|tr|td|img|swf|flash|attach|media|audio|groupid|payto' . ($_G['cache']['bbcodes_display'][$_G['groupid']] ? '|' . implode('|', array_keys($_G['cache']['bbcodes_display'][$_G['groupid']])) : '');
	$str = strip_tags(preg_replace(array(
		"/\[hide=?\d*\](.*?)\[\/hide\]/is",
		"/\[quote](.*?)\[\/quote]/si",
		$language['post_edit_regexp'],
		"/\[url=?.*?\](.+?)\[\/url\]/si",
		"/\[($bbcodesclear)=?.*?\].+?\[\/\\1\]/si",
		"/\[($bbcodes)=?.*?\]/i",
		"/\[\/($bbcodes)\]/i",
		"/\\\\u/i"
			), array(
		"[b]$language[post_hidden][/b]",
		'',
		'',
		'\\1',
		'',
		'',
		'',
		'%u'
			), $str));
	if($length) {
		$str = cutstr($str, $length, $dot);
	}
	return trim($str);
}

function wq_app_messagesafeclear($message) {
	if(strpos($message, '[/password]') !== FALSE) {
		$message = '';
	}
	if(strpos($message, '[/postbg]') !== FALSE) {
		$message = preg_replace("/\s?\[postbg\]\s*([^\[\<\r\n;'\"\?\(\)]+?)\s*\[\/postbg\]\s?/is", '', $message);
	}
	if(strpos($message, '[/begin]') !== FALSE) {
		$message = preg_replace("/\[begin(=\s*([^\[\<\r\n]*?)\s*,(\d*),(\d*),(\d*),(\d*))?\]\s*([^\[\<\r\n]+?)\s*\[\/begin\]/is", '', $message);
	}
	if(strpos($message, '[page]') !== FALSE) {
		$message = preg_replace("/\s?\[page\]\s?/is", '', $message);
	}
	if(strpos($message, '[/index]') !== FALSE) {
		$message = preg_replace("/\s?\[index\](.+?)\[\/index\]\s?/is", '', $message);
	}
	if(strpos($message, '[/begin]') !== FALSE) {
		$message = preg_replace("/\[begin(=\s*([^\[\<\r\n]*?)\s*,(\d*),(\d*),(\d*),(\d*))?\]\s*([^\[\<\r\n]+?)\s*\[\/begin\]/is", '', $message);
	}
	if(strpos($message, '[/groupid]') !== FALSE) {
		$message = preg_replace("/\[groupid=\d+\].*\[\/groupid\]/i", '', $message);
	}
	$language = lang('forum/misc');
	$message = preg_replace(array($language['post_edithtml_regexp'], $language['post_editnobbcode_regexp'], $language['post_edit_regexp']), '', $message);
	return $message;
}

function wq_app_edit_message($message, $pid = 0, $flag = false) {
	global $_G;

	if(!function_exists('discuzcode')) {
		require_once libfile('function/discuzcode');
	}

	if($flag) {
		$message = discuzcode($message, 0, 0);
		$message = htmlspecialchars_decode($message, ENT_QUOTES);
		$message = str_replace('smilieid="', 'class="wq_smilieimg" smilieid="', $message);
		return $message;
	}

	$message = wq_app_setting_discuzcode($message, 0, 0);

	$aids = $_search = $_replace = array();
	preg_match_all('/\[attachimg\](\d+)\[\/attachimg\]/is', $message, $attachs, PREG_SET_ORDER);
	if(is_array($attachs) && !empty($attachs)) {
		foreach($attachs as $key => $attach) {
			$aids[] = $attach['1'];
			$_search[] = $attach['0'];
		}
	}
	if(!empty($aids) && $pid) {
		$rows = DB::fetch_all('SELECT * FROM %t WHERE pid=%d  AND %i AND isimage IN (1, -1)', array(get_tableid('pid:' . $pid), $pid, DB::field('aid', $aids)), 'aid');
		foreach($aids as $key => $aid) {
			$imgurl = wq_app_setting_get_picurl($rows[$aid]['attachment'], $rows[$aid]['remote']);
			$_replace[$aid] = '<img src="' . $imgurl . '" aid="aimg_' . $aid . '">';
		}
		$message = str_replace($_search, $_replace, $message);
	}

	preg_match_all("/\[img(.*)](.*)\[\/img\]/ismUe", $message, $imglist, PREG_SET_ORDER);

	if(is_array($imglist) && !empty($imglist)) {
		$_replace = $_search = array();
		foreach($imglist as $key => $value) {
			$_search[] = $value[0];
			list($width, $height) = explode(',', trim($value[1], '='));
			$_replace[] = '<img  src="' . $value[2] . '" width="' . $width . 'px" height="' . $height . 'px" border="0">';
		}
		$message = str_replace($_search, $_replace, $message);
	}
	return $message;
}

function get_wq_app_userinfo_and_age($space, $flag = false, $do = '') {
	$data = intval(date("Y"));

	if($flag) {
		foreach($space as $key => $val) {
			if($val['authorid']) {
				$uids[] = $val['authorid'];
			} else {
				if($do == 'following') {
					$uids[] = $val['followuid'];
				}
				if($do == 'follower') {
					$uids[] = $val['uid'];
				}
			}
		}

		$uids = array_values(array_unique($uids));

		$user = DB::fetch_all("SELECT * FROM " . DB::table('common_member_profile') . " mp "
				. "LEFT JOIN " . DB::table('common_member') . " m ON mp.uid=m.uid "
				. " WHERE mp.uid IN(%n)", array($uids));
		foreach($user as $k => $v) {
			$v['age'] = '';
			if($v['birthyear'] != 0) {
				$v['age'] = $data - intval($v['birthyear']) + 1;
			}
			$userinfo[$v['uid']] = $v;
		}
	} else {
		$userinfo = C::t('common_member_profile')->fetch($space['uid']);
		$userinfo['age'] = '';
		if($userinfo['birthyear'] != 0) {
			$userinfo['age'] = $data - intval($userinfo['birthyear']) + 1;
		}
	}

	return $userinfo;
}

function get_specialtpl($Tlang) {

	global $_G, $showthreadsorts, $adveditor, $special, $specialextra, $threadplughtml, $activitytypelist, $forum_optionlist, $isfirstpost, $sortid;

	if($_GET[action] != 'newthread' && $_GET[action] != 'edit') {
		return;
	}

	if($showthreadsorts) {
		include_once template("forum/post_sortoption");
	} elseif($adveditor) {
		switch($special) {
			case 1:
				include_once template("forum/post_poll");
				break;
			case 2:
				include_once template("forum/post_trade");
				break;
			case 3:
				include_once template("forum/post_reward");
				break;
			case 4:
				include_once template("forum/post_activity");
				break;
			case 5:
				include_once template("forum/post_debate");
				break;
		}
		if($specialextra) {
			echo '<div class="specialpost s_clear">' . $threadplughtml . '</div>';
		}
	}
}

function wq_app_get_domain() {
	global $_G;

	$defaultcurhost = empty($_G['setting']['domain']['app']['mobile']) ? '' : $_G['setting']['domain']['app']['mobile'];
	$output = array('str' => array(), 'preg' => array()); //strΪ���������Ĳ��Һ��滻��pregΪrewrite��Ĭ�������Ĳ��Һ��滻
	$_G['domain'] = array();
	if(is_array($_G['setting']['domain']['app'])) {
		$apps = $_G['setting']['domain']['app'];

		$repflag = $apps['portal'] || $apps['forum'] || $apps['group'] || $apps['home'] || $apps['default'];

		foreach($apps as $app => $domain) {
			if(in_array($app, array('default', 'mobile'))) {
				continue;
			}
			$appphp = "{$app}.php";
			if(!$domain) {
				$domain = $defaultcurhost;
			}

			if($domain != '') {
				$domain = 'http://' . $domain . $_G['siteport'] . '/';
			}
			if($repflag) {
				$output['str']['search'][$app] = "<a href=\"{$app}.php";
				$output['str']['replace'][$app] = '<a href="' . $domain . $appphp;
				$_G['domain']['pregxprw'][$app] = '<a href\="(' . preg_quote($domain, '/') . ')' . $appphp;
			} else {
				$_G['domain']['pregxprw'][$app] = '<a href\="()' . $appphp;
			}
		}
	}
	if($_G['setting']['rewritestatus'] || $output['str']['search']) {
		if($_G['setting']['rewritestatus']) {
			require_once libfile('function/admincp');
			$output['preg'] = rewritedata(0);
		}
	}

	$_G['setting']['output'] = $output;
}
//From: Dism_taobao-com
?>