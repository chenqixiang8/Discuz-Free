<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
function wq_app_get_Plang()
{
	include_once DISCUZ_ROOT . "./source/plugin/wq_app_setting/config/loadfunc.php";
	$_var_0 = DISCUZ_ROOT . "./source/plugin/wq_app_setting/language/language." . currentlang() . ".php";
	if (is_file($_var_0)) {
		$_var_1 = $_var_0;
	} else {
		$_var_1 = libfile("language", "plugin/wq_app_setting/language");
	}
	include $_var_1;
	global $wq_app_plang;
	return $wq_app_plang;
}
function get_clienturl()
{
	global $_G;
	$_var_1 = strtolower($_SERVER["HTTP_USER_AGENT"]);
	$_var_2 = '';
	if (strpos($_var_1, "iphone") !== false || strpos($_var_1, "ios") !== false) {
		$_var_2 = $_G["cache"]["mobileoem_data"]["iframeUrl"] ? $_G["cache"]["mobileoem_data"]["iframeUrl"] . "&platform=ios" : "http://www.discuz.net/mobile.php?platform=ios";
	} else {
		if (strpos($_var_1, "android") !== false) {
			$_var_2 = $_G["cache"]["mobileoem_data"]["iframeUrl"] ? $_G["cache"]["mobileoem_data"]["iframeUrl"] . "&platform=android" : "http://www.discuz.net/mobile.php?platform=android";
		} else {
			if (strpos($_var_1, "windows phone") !== false) {
				$_var_2 = $_G["cache"]["mobileoem_data"]["iframeUrl"] ? $_G["cache"]["mobileoem_data"]["iframeUrl"] . "&platform=windowsphone" : "http://www.discuz.net/mobile.php?platform=windowsphone";
			}
		}
	}
	return $_var_2;
}
function get_postspecialcheck($_arg_0)
{
	foreach ($_arg_0 as $_var_1 => $_var_2) {
		$_arg_0[$_var_1] = " class=\"wqcolor wqborder_bottom\"";
	}
	return $_arg_0;
}
function get_tid_by_favid($_arg_0)
{
	foreach ($_arg_0 as $_var_1) {
		$_var_1["tid"] = $_var_1["id"];
		$_var_2[] = $_var_1;
	}
	return $_var_2;
}
function wq_app_get_guide_options($_arg_0)
{
	$_var_1 = $_arg_0["guide_view"] == "fav" ? "newthread&ac=myfav" : $_arg_0["guide_view"];
	dheader("Location:forum.php?mod=guide&view=" . $_var_1);
	return 0;
}
function get_my_favfids_by_uid($_arg_0 = '', $_arg_1 = true)
{
	global $_G;
	if ($_arg_0 == '') {
		$_arg_0 = $_G["uid"];
	}
	$_var_3 = C::t("home_favorite")->fetch_all_by_uid_idtype($_arg_0, "fid");
	if ($_arg_1) {
		foreach ($_var_3 as $_var_4) {
			$_var_5[] = $_var_4["id"];
		}
	} else {
		$_var_5 = $_var_3;
	}
	return $_var_5 ? $_var_5 : array();
}
function get_my_favfids_by_fid($_arg_0 = false)
{
	global $_G;
	global $wq_app_setting;
	$_var_3 = array();
	$_var_4 = get_my_favfids_by_uid();
	if (!$_arg_0) {
		$_var_5 = $_var_4;
	} else {
		$_var_6 = $wq_app_setting["recommend"];
		$_var_5 = $_var_6;
		if ($_G["uid"] && $_var_4) {
			$_var_5 = array_values(array_diff($_var_6, $_var_4));
		}
		if (count($_var_5) > 3) {
			$_var_7 = array_rand($_var_5, 3);
			foreach ($_var_7 as $_var_8) {
				$_var_9[] = $_var_5[$_var_8];
			}
			$_var_5 = $_var_9;
		}
	}
	$_var_3 = C::t("forum_forum")->fetch_all_info_by_fids($_var_5);
	return $_var_3;
}
function get_guide_data_by_type()
{
	global $wq_app_setting;
	$_var_1 = max(1, intval($_GET["page"]));
	$_var_2 = ($_var_1 - 1) * $wq_app_setting["guide_perpage"];
	if ($_GET["ac"] == "myfav") {
		$_var_3 = wq_get_guide_list_for_myfav($_var_2, $wq_app_setting["guide_perpage"]);
	} else {
		$_var_3 = in_array($_GET["view"], array("hot", "digest", "new", "newthread", "sofa")) ? get_guide_list($_GET["view"], $_var_2, $wq_app_setting["guide_perpage"]) : array();
	}
	return $_var_3;
}
function get_guide_view()
{
	if ($_GET["view"] == "newthread" && !$_GET["ac"]) {
		$_var_0 = 0;
		$_var_1[0] = "class=\"on\"";
	} else {
		if ($_GET["view"] == "sofa") {
			$_var_0 = 1;
			$_var_1[1] = "class=\"on\"";
		} else {
			if ($_GET["view"] == "hot") {
				$_var_0 = 2;
				$_var_1[2] = "class=\"on\"";
			} else {
				if ($_GET["view"] == "digest") {
					$_var_0 = 3;
					$_var_1[3] = "class=\"on\"";
				} else {
					if ($_GET["ac"] == "myfav") {
						$_var_0 = 4;
						$_var_1[4] = "class=\"on\"";
					}
				}
			}
		}
	}
	return $_var_0;
}
function wq_get_guide_list_for_myfav($_arg_0 = 0, $_arg_1 = 10, $_arg_2 = 0)
{
	global $_G;
	$_var_4 = "newthread";
	$_var_5 = get_my_favfids_by_uid();
	loadcache(array("forums", "myfavthread_" . $_G["uid"]));
	$_var_6 = 900;
	$_var_7 = $_G["cache"]["myfavthread_" . $_G["uid"]];
	if (empty($_var_5)) {
		savecache("myfavthread_" . $_G["uid"], '');
		return array("forumnames" => array(), "threadcount" => 0, "threadlist" => array());
	}
	if ($_var_7 && TIMESTAMP - $_var_7["cachetime"] < $_var_6) {
		$_var_8 = $_var_7["data"];
		$_var_9 = count($_var_8);
		$_var_8 = array_slice($_var_8, $_arg_0, $_arg_1, true);
		$_var_10 = false;
		if (empty($_var_8)) {
			return array();
		}
	} else {
		$_var_11 = 0;
		$_var_12 = 50000;
		$_var_13 = C::t("forum_thread")->fetch_max_tid();
		$_var_14 = max(0, $_var_13 - $_var_12);
		if ($_arg_2) {
			$_var_14 = max(0, $_var_14 - $_var_12);
		}
		$_var_8 = array();
		foreach ($_G["cache"]["forums"] as $_var_15 => $_var_16) {
			if (in_array($_var_15, $_var_5)) {
				if ($_var_16["type"] != "group" && $_var_16["status"] > 0 && !$_var_16["viewperm"] && !$_var_16["havepassword"]) {
					$_var_17[] = $_var_15;
				}
			}
		}
		if (empty($_var_17)) {
			return array();
		}
		$_var_10 = true;
	}
	$_var_18 = C::t("forum_thread")->fetch_all_for_guide($_var_4, $_var_14, $_var_8, 0, $_var_11, 0, 600, $_var_17);
	$_var_19 = 0;
	foreach ($_var_18 as $_var_20) {
		if (!empty($_var_8) || !$_var_20["isgroup"] && in_array($_var_20["fid"], $_var_17)) {
			if ($_var_20["displayorder"] >= 0) {
				$_var_20 = wq_guide_procthread($_var_20);
				$_var_21[] = $_var_20["tid"];
				if ($_var_8 || $_var_19 >= $_arg_0 && $_var_19 < $_arg_0 + $_arg_1) {
					$_var_22[$_var_20[tid]] = $_var_20;
					$_var_17[$_var_20[fid]] = $_var_20["fid"];
				}
				$_var_19 = $_var_19 + 1;
			}
		}
	}
	if ($_var_14 > $_var_12 && !$_arg_2 && count($_var_22) < 50) {
		return wq_get_guide_list_for_myfav($_arg_0, $_arg_1, 1);
	}
	$_var_23 = array();
	if ($_var_17) {
		$_var_23 = C::t("forum_forum")->fetch_all_name_by_fid($_var_17);
	}
	$_var_24 = array();
	if ($_var_8) {
		$_var_21 = array();
		foreach ($_var_8 as $_var_25 => $_var_26) {
			if ($_var_22[$_var_26]) {
				$_var_24[$_var_25] = $_var_22[$_var_26];
				$_var_21[] = $_var_26;
			}
		}
	} else {
		$_var_24 = $_var_22;
	}
	$_var_22 = NULL;
	if ($_var_10) {
		$_var_9 = count($_var_21);
		$_var_27 = array("cachetime" => TIMESTAMP, "data" => $_var_21);
		savecache("myfavthread_" . $_G["uid"], $_var_27);
	}
	return array("forumnames" => $_var_23, "threadcount" => $_var_9, "threadlist" => $_var_24);
}
function wq_guide_procthread($_arg_0)
{
	global $_G;
	$_G["forum_colorarray"] = array('', "#EE1B2E", "#EE5023", "#996600", "#3C9D40", "#2897C5", "#2B65B7", "#8F2A90", "#EC1282");
	$_var_2 = strtotime(dgmdate(TIMESTAMP, "Ymd"));
	$_arg_0["lastposterenc"] = rawurlencode($_arg_0["lastposter"]);
	$_arg_0["multipage"] = '';
	if ($_arg_0["special"]) {
		$_var_3 = $_arg_0["replies"];
	} else {
		$_var_3 = $_arg_0["replies"] + 1;
	}
	if ($_var_3 > $_G["ppp"]) {
		$_var_4 = '';
		$_arg_0["pages"] = ceil($_var_3 / $_G["ppp"]);
		$_var_5 = 2;
		while ($_var_5 <= 6 && $_var_5 <= $_arg_0["pages"]) {
			$_var_4 = $_var_4 . ("<a href=\"forum.php?mod=viewthread&tid=" . $_arg_0["tid"] . "&amp;extra=" . $_var_6 . "&amp;page=" . $_var_5 . "\">" . $_var_5 . "</a>");
			$_var_5 = $_var_5 + 1;
		}
		if ($_arg_0["pages"] > 6) {
			$_var_4 = $_var_4 . ("..<a href=\"forum.php?mod=viewthread&tid=" . $_arg_0["tid"] . "&amp;extra=" . $_var_6 . "&amp;page=" . $_arg_0["pages"] . "\">" . $_arg_0["pages"] . "</a>");
		}
		$_arg_0["multipage"] = "&nbsp;..." . $_var_4;
	}
	if ($_arg_0["highlight"]) {
		$_var_7 = sprintf("%02d", $_arg_0["highlight"]);
		$_var_8 = sprintf("%03b", $_var_7[0]);
		$_arg_0["highlight"] = " style=\"";
		if ($_var_8[0]) {
			$_arg_0["highlight"] = $_arg_0["highlight"] . "font-weight: bold;";
		}
		if ($_var_8[1]) {
			$_arg_0["highlight"] = $_arg_0["highlight"] . "font-style: italic;";
		}
		if ($_var_8[2]) {
			$_arg_0["highlight"] = $_arg_0["highlight"] . "text-decoration: underline;";
		}
		if ($_var_7[1]) {
			$_arg_0["highlight"] = $_arg_0["highlight"] . ("color: " . $_G["forum_colorarray"][$_var_7[1]]);
		}
		$_arg_0["highlight"] = $_arg_0["highlight"] . "\"";
	} else {
		$_arg_0["highlight"] = '';
	}
	$_arg_0["recommendicon"] = '';
	if (!empty($_G["setting"]["recommendthread"]["status"]) && $_arg_0["recommends"]) {
		foreach ($_G["setting"]["recommendthread"]["iconlevels"] as $_var_9 => $_var_5) {
			if ($_arg_0["recommends"] > $_var_5) {
				$_arg_0["recommendicon"] = $_var_9 + 1;
				break;
			}
		}
	}
	$_arg_0["moved"] = $_arg_0["heatlevel"] = $_arg_0["new"] = 0;
	if ($_arg_0["forumstick"] || !$_arg_0["moved"] && $_arg_0["isgroup"] != 1) {
		$_arg_0["icontid"] = $_arg_0["tid"];
	} else {
		$_arg_0["icontid"] = $_arg_0["closed"];
	}
	$_arg_0["folder"] = "common";
	$_arg_0["weeknew"] = !(TIMESTAMP - 604800 > $_arg_0["dbdateline"]);
	if ($_arg_0["replies"] > $_arg_0["views"]) {
		$_arg_0["views"] = $_arg_0["replies"];
	}
	if ($_G["setting"]["heatthread"]["iconlevels"]) {
		foreach ($_G["setting"]["heatthread"]["iconlevels"] as $_var_9 => $_var_5) {
			if ($_arg_0["heats"] > $_var_5) {
				$_arg_0["heatlevel"] = $_var_9 + 1;
				break;
			}
		}
	}
	if ($_arg_0["dateline"] > $_var_2) {
		$_arg_0["istoday"] = 1;
	} else {
		$_arg_0["istoday"] = 0;
	}
	$_arg_0["dbdateline"] = $_arg_0["dateline"];
	$_arg_0["dateline"] = dgmdate($_arg_0["dateline"], "u", "9999", getglobal("setting/dateformat"));
	$_arg_0["dblastpost"] = $_arg_0["lastpost"];
	$_arg_0["lastpost"] = dgmdate($_arg_0["lastpost"], "u");
	if (in_array($_arg_0["displayorder"], array(1, 2, 3, 4))) {
		$_arg_0["id"] = "stickthread_" . $_arg_0["tid"];
	} else {
		$_arg_0["id"] = "normalthread_" . $_arg_0["tid"];
	}
	$_arg_0["rushreply"] = getstatus($_arg_0["status"], 3);
	return $_arg_0;
}
function get_guide_showmodel()
{
	global $wq_app_setting;
	global $mysetting;
	if ($mysetting["forumindex_showmodel"] == "-1") {
		$_var_2 = $wq_app_setting["forumindex_showmodel"];
	} else {
		$_var_2 = $mysetting["forumindex_showmodel"];
	}
	return $_var_2;
}
function get_tid_isclose_for_guide()
{
	global $thread;
	global $_G;
	if (!$thread["forumstick"] && $thread["closed"] > 1 && ($thread["isgroup"] == 1 || $thread["fid"] != $_G["fid"])) {
		$thread["tid"] = $thread["closed"];
	} else {
		$thread["tid"] = $thread["tid"];
	}
	return $thread["tid"];
}
function get_forum_forumcolumns($_arg_0)
{
	global $wq_app_setting;
	global $_G;
	if ($wq_app_setting["hengpai_pc"] == "0") {
		$_var_3 = 1;
	} else {
		$_var_3 = $_arg_0["forumcolumns"];
		if ($_var_3 >= 4) {
			$_var_3 = 4;
		}
		if ($_var_3 <= 1) {
			$_var_3 = 1;
		}
	}
	return $_var_3;
}
function get_forum_showmodel()
{
	global $wq_app_setting;
	global $mysetting;
	global $_G;
	$_var_3 = $_G["setting"]["wq_app_forumlist_style"] ? unserialize($_G["setting"]["wq_app_forumlist_style"]) : array();
	if ($mysetting["list_showmodel"] != "-1") {
		return $mysetting["list_showmodel"];
	}
	$_var_4 = 1;
	if ($_var_3) {
		$_var_4 = isset($_var_3[$_G["forum"]["fid"]]) ? $_var_3[$_G["forum"]["fid"]] : $_var_4;
	}
	return $_var_4;
}
function wq_app_get_forum_class($_arg_0)
{
	if ($_arg_0 == "w") {
		$_var_1 = "wqfriend_circle";
	} elseif ($_arg_0 == "b") {
		$_var_1 = "wqindex_list wqpadding0";
	} elseif ($_arg_0 == "s") {
		$_var_1 = "wqindex_list wqpadding0";
	} elseif ($_arg_0 == "6") {
		$_var_1 = "wqindex_list wqindex_list_no";
	} elseif ($_arg_0 == "j") {
		$_var_1 = "wqpic_essence";
	} else {
		$_var_1 = "wqindex_list";
	}
	return $_var_1;
}
function wq_app_select_fav_by_fid($_arg_0)
{
	$_var_1 = C::t("forum_forum")->fetch_info_by_fid($_arg_0);
	$_var_2 = array("favtimes" => $_var_1["favtimes"]);
	return json_encode($_var_2);
}
function get_post_all_check($_arg_0)
{
	switch ($_arg_0) {
		case "heat":
			return 1;
		case "hot":
			return 2;
		case "lastpost":
			return 3;
		case "digest":
			return 4;
		case "specialtype":
		case "sortid":
		case "typeid":
			return 5;
	}
	return 0;
}
function fetch_by_id_idtype_uid($_arg_0, $_arg_1, $_arg_2 = 0)
{
	return DB::fetch_first("SELECT * FROM %t WHERE id=%d AND idtype=%s AND uid=%d", array("home_favorite", $_arg_0, $_arg_1, $_arg_2));
}
function get_wq_app_setting()
{
	global $_G;
	loadcache("plugin");
	$_var_1 = $_G["cache"]["plugin"]["wq_app_setting"];
	$_var_1["logoname"] = trim($_var_1["logoname"]);
	$_var_1["desktop_name"] = trim($_var_1["desktop_name"]);
	$_var_1["home_navmenu"] = intval($_var_1["home_navmenu"]);
	$_var_1["portal_list_showmodel"] = intval($_var_1["portal_list_showmodel"]);
	$_var_1["portal_view_showmodel"] = intval($_var_1["portal_view_showmodel"]);
	$_var_1["portal_view_reply"] = intval($_var_1["portal_view_reply"]);
	$_var_1["discuz_style"] = intval($_var_1["discuz_style"]);
	$_var_1["hengpai_pc"] = intval($_var_1["hengpai_pc"]);
	$_var_1["view_line"] = intval($_var_1["view_line"]);
	$_var_1["tpost"] = intval($_var_1["tpost"]);
	$_var_1["is_discuz_myfav"] = intval($_var_1["is_discuz_myfav"]);
	$_var_1["forumlist_left_width"] = intval($_var_1["forumlist_left_width"]);
	$_var_1["post_style"] = intval($_var_1["post_style"]);
	$_var_1["use_original_image"] = intval($_var_1["use_original_image"]);
	$_var_1["memory_time"] = intval($_var_1["memory_time"]);
	$_var_1["is_drop_down_loading"] = intval($_var_1["is_drop_down_loading"]);
	$_var_1["isopen_modrecommend"] = intval($_var_1["isopen_modrecommend"]);
	$_var_1["viwe_top"] = intval($_var_1["viwe_top"]);
	$_var_1["top_num"] = intval($_var_1["top_num"]);
	$_var_1["message_length"] = intval($_var_1["message_length"]);
	$_var_1["img_left"] = intval($_var_1["img_left"]);
	$_var_1["view_imgnum"] = intval($_var_1["view_imgnum"]);
	$_var_1["wechat_recommend_num"] = intval($_var_1["wechat_recommend_num"]);
	$_var_1["wechat_replies_num"] = intval($_var_1["wechat_replies_num"]);
	$_var_1["view_screen_mode"] = intval($_var_1["view_screen_mode"]);
	$_var_1["post_but_singleshow"] = intval($_var_1["post_but_singleshow"]);
	$_var_1["view_screen_openstop"] = intval($_var_1["view_screen_openstop"]);
	$_var_1["view_style"] = intval($_var_1["view_style"]);
	$_var_1["view_view_style"] = intval($_var_1["view_view_style"]);
	$_var_1["view_reply_style"] = intval($_var_1["view_reply_style"]);
	$_var_1["is_reply_reload"] = intval($_var_1["is_reply_reload"]);
	$_var_1["view_click"] = intval($_var_1["view_click"]);
	$_var_1["view_open_promote"] = intval($_var_1["view_open_promote"]);
	$_var_1["view_use_original_image"] = intval($_var_1["view_use_original_image"]);
	$_var_1["forumindex_showmodel"] = trim($_var_1["forumindex_showmodel"]);
	$_var_1["guide_view"] = trim($_var_1["guide_view"]);
	$_var_1["guide_perpage"] = intval($_var_1["guide_perpage"]);
	$_var_1["recommend"] = unserialize($_var_1["recommend"]);
	$_var_1["thread_carousel"] = intval($_var_1["thread_carousel"]);
	$_var_1["weiqing_thread_block_id"] = intval($_var_1["weiqing_thread_block_id"]);
	$_var_1["maxwidth"] = intval($_var_1["maxwidth"]);
	$_var_1["maxheight"] = intval($_var_1["maxheight"]);
	$_var_1["login_seccheck"] = intval($_var_1["login_seccheck"]);
	$_var_1["register_seccheck"] = intval($_var_1["register_seccheck"]);
	$_var_1["password_seccheck"] = intval($_var_1["password_seccheck"]);
	$_var_1["open_advertisement"] = intval($_var_1["open_advertisement"]);
	$_var_1["advertisement_logo"] = trim($_var_1["advertisement_logo"]);
	$_var_1["advertisement_title"] = trim($_var_1["advertisement_title"]);
	$_var_1["advertisement_overview"] = trim($_var_1["advertisement_overview"]);
	$_var_1["advertisement_link"] = trim($_var_1["advertisement_link"]);
	$_var_1["advertisement_button"] = trim($_var_1["advertisement_button"]);
	$_var_1["advertisement_time"] = intval($_var_1["advertisement_time"]);
	$_var_1["icon_url"] = trim($_var_1["icon_url"]);
	$_var_1["is_close_showtips"] = intval($_var_1["is_close_showtips"]);
	$_var_1["qrcode_type"] = intval($_var_1["qrcode_type"]);
	$_var_1["wechat_recommend_num"] = $_var_1["wechat_recommend_num"] > 20 ? 20 : $_var_1["wechat_recommend_num"];
	$_var_1["wechat_recommend_num"] = $_var_1["wechat_recommend_num"] < 0 ? 10 : $_var_1["wechat_recommend_num"];
	$_var_1["wechat_replies_num"] = $_var_1["wechat_replies_num"] > 20 ? 20 : $_var_1["wechat_replies_num"];
	$_var_1["wechat_replies_num"] = $_var_1["wechat_replies_num"] < 0 ? 10 : $_var_1["wechat_replies_num"];
	return $_var_1;
}
function get_wq_app_style()
{
	global $_G;
	$_var_1 = $_G["setting"]["styleid2"];
	loadcache("style_" . $_var_1);
	return $_G["cache"]["style_" . $_var_1];
}
function get_wq_login()
{
	global $_G;
	loadcache("plugin");
	$_var_1 = $_G["cache"]["plugin"]["wq_login"];
	$_var_1["formhash"] = formhash();
	return $_var_1;
}
function get_default_stylesetting()
{
	return array("myextstyle" => "0", "forumindex_showmodel" => "-1", "list_showmodel" => "-1", "nav_showmodel" => "0");
}
function get_stylesetting_by_uid()
{
	global $_G;
	if ($_G["uid"]) {
		dsetcookie("wq_app_my_stylesetting", '');
		if (!$_G["cookie"]["wq_app_my_stylesetting"]) {
			$_var_1 = C::t("#wq_app_setting#wq_app_setting")->fetch($_G["uid"]);
			if ($_var_1) {
				$_var_2 = unserialize($_var_1["show"]);
			} else {
				$_var_2 = get_default_stylesetting();
			}
			dsetcookie("wq_app_my_stylesetting", serialize($_var_2), TIMESTAMP + 2592000);
		} else {
			$_var_2 = unserialize($_G["cookie"]["wq_app_my_stylesetting"]);
		}
	} else {
		$_var_2 = get_default_stylesetting();
	}
	return $_var_2;
}
function get_system_smilies_from_js()
{
	$_var_0 = C::t("forum_imagetype")->fetch_all_by_type("smiley", 1);
	foreach ($_var_0 as $_var_1 => $_var_2) {
		$_var_3 = C::t("common_smiley")->fetch_all_by_type_code_typeid("smiley", $_var_2["typeid"]);
		$_var_4[$_var_1] = array();
		foreach ($_var_3 as $_var_5) {
			if ($_var_6 = @getimagesize(DISCUZ_ROOT . "./static/image/smiley/" . $_var_2["directory"] . "/" . $_var_5["url"])) {
				$_var_4[$_var_1][] = array("code" => $_var_5["code"], "image" => $_var_2["directory"] . "/" . $_var_5["url"]);
			}
		}
	}
	return $_var_4;
}
function get_system_smilies()
{
	global $_G;
	loadcache(array("smilies", "smileytypes"));
	$_var_1 = array();
	ksort($_G["cache"]["smilies"]["replacearray"]);
	ksort($_G["cache"]["smilies"]["searcharray"]);
	foreach ($_G["cache"]["smilies"]["replacearray"] as $_var_2 => $_var_3) {
		$_var_4 = preg_match("/smiley\\/" . $_G["cache"]["smileytypes"][$_G["cache"]["smilies"]["typearray"][$_var_2]]["directory"] . "\\/(.*)\" smilieid/iUs", $_var_3, $_var_5);
		if ($_var_4) {
			$_var_3 = $_var_5[1];
		}
		$_var_1[$_G["cache"]["smilies"]["typearray"][$_var_2]][] = array("code" => $_G["cache"]["smilies"]["searcharray"][$_var_2], "image" => $_G["cache"]["smileytypes"][$_G["cache"]["smilies"]["typearray"][$_var_2]]["directory"] . "/" . $_var_3, "id" => $_var_2);
		$_var_6 = $_var_6 + 1;
	}
	foreach ($_G["cache"]["smileytypes"] as $_var_7 => $_var_8) {
		$_var_9[] = $_var_1[$_var_7];
	}
	return array_values($_var_9);
}
function wq_app_delete_fav_by_fid($_arg_0)
{
	global $_G;
	if ($_GET["formhash"] != formhash()) {
		return '';
	}
	if ($_arg_0) {
		C::t("forum_forum")->update_forum_counter($_arg_0, 0, 0, 0, 0, -1);
	}
	C::t("home_favorite")->delete_by_id_idtype($_arg_0, "fid");
	if ($_G["setting"]["cloud_status"]) {
		$_var_2 = Cloud::loadClass("Service_Client_Favorite");
		$_var_2->remove($_G["uid"], $_arg_0, TIMESTAMP);
	}
	return "1";
}
function get_wq_app_toplist($_arg_0)
{
	global $_G;
	$_var_2 = 1;
	$_var_3 = get_wq_app_setting();
	$_var_4 = wq_app_get_Plang();
	foreach ($_arg_0 as $_var_5) {
		if ($_var_3["viwe_top"] && $_var_5["displayorder"] > 0) {
			if ($_var_5["displayorder"] == 1) {
				$_var_5["topicon"] = $_var_4["4673e046394d207a"];
			} elseif ($_var_5["displayorder"] == 2) {
				$_var_5["topicon"] = $_var_4["9d24721c1907a20d"];
			} elseif ($_var_5["displayorder"] == 3) {
				$_var_5["topicon"] = $_var_4["ecae8556da730566"];
			} else {
				$_var_5["topicon"] = $_var_4["99e266c1de5e6fe2"];
			}
			$_var_6[] = $_var_5;
			$_var_2 = $_var_2 + 1;
			if ($_var_3["top_num"] > 0 && $_var_2 > $_var_3["top_num"]) {
				break;
			}
		}
	}
	return $_var_6;
}
function wq_app_get_wechat_reply_success_msg($_arg_0, $_arg_1, $_arg_2)
{
	$_var_3 = wq_app_get_Plang();
	$_var_4 = DB::fetch_first("SELECT pid,author, authorid, message FROM %t WHERE tid = %d AND fid = %d AND pid = %d AND first = 0 ", array("forum_post", $_arg_0, $_arg_2, $_arg_1));
	$_var_5 = wq_app_reply_msg_dispose($_var_4);
	if (empty($_var_5["rauthor"])) {
		$_var_6 = $_var_6 . ("<p>\r\n                    <a href=\"home.php?mod=space&do=profile&uid=" . $_var_5["authorid"] . "\" class=\"wq_name\">" . $_var_5["author"] . ":</a>\r\n                    <a href=\"forum.php?mod=post&action=reply&&fid=" . $_arg_2 . "&tid=" . $_arg_0 . "&repquote=" . $_var_5["pid"] . "&route=w\"  class=\"dialog wqdis_block notlogged\">&nbsp;&nbsp;" . $_var_5["message"] . "</a>\r\n                </p>");
	} else {
		$_var_6 = $_var_6 . ("<p>\r\n                    <a href = \"home.php?mod=space&do=profile&uid=" . $_var_5["authorid"] . "\" class=\"wq_name\">" . $_var_5["author"] . "</a> <span style=\"float: left;\">" . $_var_3["d48e05b9e79bb751"] . "</span>\r\n                    <a href = \"home.php?mod=space&do=profile&uid=" . $_var_5["rauthorid"] . "\" class=\"wq_name\">" . $_var_5["rauthor"] . ":</a>\r\n                    <a href = \"forum.php?mod=post&action=reply&&fid=" . $_arg_2 . "&tid=" . $_arg_0 . "&repquote=" . $_var_5["pid"] . "&route=w\" class = \"dialog notlogged\">&nbsp;&nbsp;" . $_var_5["message"] . "</a>\r\n                </p>");
	}
	return $_var_6;
}
function wq_app_get_thread_info_from_cache($_arg_0, $_arg_1 = false)
{
	global $_G;
	$_var_3 = array();
	if (!is_array($_arg_0)) {
		$_arg_0 = array($_arg_0);
	}
	if (!empty($_arg_0)) {
		if (!$_arg_1) {
			foreach ($_arg_0 as $_var_4) {
				$_var_5 = wq_app_readfromcache("forumdisplay_tid" . $_var_4, "wq_");
				if (!empty($_var_5)) {
					$_var_3[$_var_4] = $_var_5;
				}
			}
		}
		if (empty($_var_3) || count($_var_3) != count($_arg_0)) {
			if (is_array($_var_3) && !empty($_var_3)) {
				$_arg_0 = array_diff($_arg_0, array_keys($_var_3));
			}
			if (empty($_var_3)) {
				$_var_3 = array();
			}
			$_var_6 = get_wq_app_data($_arg_0);
			$_var_7 = wq_app_get_recommend_by_tids($_arg_0);
			$_var_8 = wq_app_get_replies_by_tids($_arg_0);
			foreach ($_var_6["summarys"] as $_var_4 => $_var_9) {
				$_var_3[$_var_4]["fid"] = $_var_6["fids"][$_var_4] ? $_var_6["fids"][$_var_4] : '';
				$_var_3[$_var_4]["summary"] = $_var_9;
				$_var_3[$_var_4]["imagenum"] = $_var_6["images"][$_var_4]["count"] ? intval($_var_6["images"][$_var_4]["count"]) : 0;
				$_var_3[$_var_4]["maximgs"] = $_var_6["images"][$_var_4]["maximgs"] ? $_var_6["images"][$_var_4]["maximgs"] : array();
				$_var_3[$_var_4]["images"] = $_var_6["images"][$_var_4]["image"] ? $_var_6["images"][$_var_4]["image"] : array();
				$_var_3[$_var_4]["recommendnum"] = $_var_7[$_var_4]["recommendnum"] ? $_var_7[$_var_4]["recommendnum"] : 0;
				$_var_3[$_var_4]["recommend"] = $_var_7[$_var_4]["user"] ? $_var_7[$_var_4]["user"] : array();
				$_var_3[$_var_4]["repliesnum"] = $_var_8[$_var_4]["repliesnum"] ? $_var_8[$_var_4]["repliesnum"] : 0;
				$_var_3[$_var_4]["replies"] = $_var_8[$_var_4]["msg"] ? $_var_8[$_var_4]["msg"] : array();
				$_var_3[$_var_4]["replies"] = $_var_8[$_var_4]["msg"] ? $_var_8[$_var_4]["msg"] : array();
			}
			foreach ($_var_3 as $_var_10 => $_var_11) {
				wq_app_writetocache("forumdisplay_tid" . $_var_10, $_var_11);
			}
		}
	}
	return $_var_3;
}
function wq_app_get_replies_by_tids($_arg_0)
{
	global $_G;
	$_var_2 = $_var_3 = array();
	foreach ($_arg_0 as $_var_4) {
		$_var_5 = DB::result_first("SELECT count(*) FROM %t WHERE tid = %d AND first = 0 AND invisible = 0", array("forum_post", $_var_4));
		if ($_var_5 > 0) {
			$_var_6[$_var_4] = $_var_5;
			$_var_2[$_var_4] = DB::fetch_all("SELECT pid,author, authorid, message FROM %t WHERE tid = %d AND first = 0 AND invisible = 0 ORDER BY `dateline` DESC limit 20", array("forum_post", $_var_4));
		}
	}
	foreach ($_var_2 as $_var_7 => $_var_8) {
		$_var_9 = array();
		foreach ($_var_8 as $_var_10 => $_var_11) {
			$_var_9["msg"][$_var_11["pid"]] = wq_app_reply_msg_dispose($_var_11);
		}
		$_var_3[$_var_7] = $_var_9;
		$_var_3[$_var_7]["repliesnum"] = $_var_6[$_var_7];
	}
	return $_var_3;
}
function wq_app_get_recommend_by_tids($_arg_0)
{
	global $_G;
	$_var_2 = $_var_3 = array();
	foreach ($_arg_0 as $_var_4) {
		$_var_5 = DB::result_first("SELECT count(*) FROM %t  WHERE tid=%d", array("forum_memberrecommend", $_var_4));
		if ($_var_5 > 0) {
			$_var_6[$_var_4] = $_var_5;
			$_var_7 = $_var_5 > 20 ? $_var_5 - 20 : 0;
			$_var_2[$_var_4] = DB::fetch_all("SELECT * FROM %t  WHERE tid=%d  ORDER BY `dateline` ASC " . DB::limit($_var_7, 20), array("forum_memberrecommend", $_var_4));
		}
	}
	foreach ($_var_2 as $_var_8 => $_var_9) {
		$_var_10 = array();
		foreach ($_var_9 as $_var_11 => $_var_12) {
			$_var_13 = getuserbyuid($_var_12["recommenduid"]);
			$_var_10["user"][$_var_12["recommenduid"]] = $_var_13["username"];
		}
		$_var_3[$_var_8] = $_var_10;
		$_var_3[$_var_8]["recommendnum"] = $_var_6[$_var_8];
	}
	return $_var_3;
}
function get_wq_app_data($_arg_0)
{
	global $_G;
	$_var_2 = array();
	if (!empty($_arg_0)) {
		$_var_3 = get_wq_app_summary_pids_by_tids($_arg_0);
		$_var_2["summarys"] = $_var_3["summarys"];
		$_var_2["fids"] = $_var_3["fids"];
		$_var_4 = $_var_3["pids"];
		$_var_2["images"] = get_wq_app_images_by_tid_pids($_var_4);
	}
	return $_var_2;
}
function get_wq_app_tids($_arg_0)
{
	foreach ($_arg_0 as $_var_1) {
		$_var_2[] = $_var_1["tid"];
	}
	return $_var_2;
}
function get_wq_app_images_by_tid_pids($_arg_0)
{
	global $_G;
	$_var_2 = get_wq_app_setting();
	$_var_3 = array();
	foreach ($_arg_0 as $_var_4 => $_var_5) {
		$_var_3[$_var_4] = array("maximgs" => array(), "image" => array(), "count" => 0);
		$_var_6 = DB::fetch_first("SELECT message FROM " . DB::table("forum_post") . " WHERE tid=%d AND first=1", array($_var_4));
		preg_match_all("/\\[img(.*)](.*)\\[\\/img\\]/ismUe", $_var_6["message"], $_var_7, PREG_SET_ORDER);
		$_var_8 = 0;
		if (is_array($_var_7) && !empty($_var_7)) {
			$_var_8 = count($_var_7);
		}
		$_var_9 = C::t("forum_attachment_n")->count_image_by_id("pid:" . $_var_5, "pid", $_var_5);
		$_var_10 = intval($_var_8 + $_var_9);
		if ($_var_9 > 0) {
			$_var_11 = fetch_max_image_three("pid:" . $_var_5, "pid", $_var_5);
			$_var_12 = array();
			foreach ($_var_11 as $_var_13 => $_var_14) {
				$_var_3[$_var_4]["maximgs"][$_var_14["aid"]]["attachment"] = $_var_14["attachment"];
				$_var_3[$_var_4]["maximgs"][$_var_14["aid"]]["thumb"] = $_var_14["thumb"];
				$_var_3[$_var_4]["maximgs"][$_var_14["aid"]]["remote"] = $_var_14["remote"];
			}
		}
		$_var_3[$_var_4]["count"] = $_var_10;
		if ($_var_8 > 0) {
			foreach ($_var_7 as $_var_13 => $_var_15) {
				$_var_3[$_var_4]["image"][] = $_var_15[2];
			}
		}
	}
	return $_var_3;
}
function wq_app_setting_get_pic($_arg_0, $_arg_1, $_arg_2 = 0, $_arg_3 = 1)
{
	global $_G;
	$_var_5 = get_wq_app_setting();
	$_var_6 = array();
	if (!empty($_arg_0)) {
		if ($_var_5["use_original_image"] == 2) {
			if (in_array($_arg_2, array("m", "0", "1", "4", "6", "j"))) {
				$_var_7 = 220;
			}
			if (in_array($_arg_2, array("b", "s"))) {
				$_var_7 = 640;
			}
			if (in_array($_arg_2, array("3", "5"))) {
				if ($_var_8 > 2) {
					$_var_7 = 220;
				} else {
					if ($_var_8 > 1) {
						$_var_7 = 320;
					} else {
						$_var_7 = 640;
					}
				}
			}
			if (in_array($_arg_2, array("w"))) {
				if ($_var_8 == 1) {
					$_var_7 = 640;
				} else {
					$_var_7 = 220;
				}
			}
			$_var_9 = 99999;
			foreach ($_arg_0 as $_var_10 => $_var_11) {
				$_var_6[] = sprintf("forum.php?mod=image&aid=%s&size=%sx%s&key=%s", $_var_10, $_var_7, $_var_9, dsign($_var_10 . "|" . $_var_7 . "|" . $_var_9));
			}
		}
		if ($_var_5["use_original_image"] == 1) {
			foreach ($_arg_0 as $_var_12 => $_var_11) {
				$_var_6[] = wq_app_setting_get_picurl($_var_11["attachment"], $_var_11["remote"], $_var_11["thumb"]);
			}
		}
	}
	if (!empty($_arg_1)) {
		foreach ($_arg_1 as $_var_12 => $_var_13) {
			$_var_6[] = $_var_13;
		}
	}
	$_var_14 = array_slice($_var_6, 0, $_arg_3);
	return $_var_14;
}
function wq_app_setting_get_picurl($_arg_0, $_arg_1, $_arg_2)
{
	global $_G;
	if (wq_app_setting_is_picurl($_arg_0)) {
		return $_arg_0;
	}
	if ($_arg_2) {
		$_arg_0 = getimgthumbname($_arg_0);
	}
	if ($_arg_1 == 1) {
		$_var_4 = $_G["setting"]["ftp"]["attachurl"] . "forum/" . $_arg_0;
	} else {
		$_arg_0 = $_G["setting"]["attachurl"] . "forum/" . $_arg_0;
		if (wq_app_setting_is_picurl($_arg_0)) {
			return $_arg_0;
		}
		$_var_4 = $_arg_0;
	}
	return $_var_4;
}
function wq_app_setting_is_picurl($_arg_0)
{
	return in_array(strtolower(substr($_arg_0, 0, 6)), array("http:/", "https:", "ftp://"));
}
function fetch_max_image_three($_arg_0, $_arg_1, $_arg_2)
{
	return DB::fetch_all("SELECT * FROM %t WHERE %i AND isimage IN (1, -1) ORDER BY width DESC", array(get_tableid($_arg_0), DB::field($_arg_1, $_arg_2)));
}
function get_tableid($_arg_0)
{
	if (!is_numeric($_arg_0)) {
		list($_var_1, $_var_2) = explode(":", $_arg_0);
		$_var_3 = dintval($_var_2);
		$_arg_0 = DB::result_first("SELECT tableid FROM %t WHERE pid=%d LIMIT 1", array("forum_attachment", $_var_3));
		if ($_arg_0 >= 0 && $_arg_0 < 10) {
			$_arg_0 = intval($_arg_0);
		} else {
			$_arg_0 = "127";
		}
	}
	if ($_arg_0 >= 0 && $_arg_0 < 10) {
		return "forum_attachment_" . intval($_arg_0);
	}
	if ($_arg_0 == 127) {
		return "forum_attachment_unused";
	}
}
function wq_app_get_subforum()
{
	global $_G;
	loadcache(array("forums"));
	foreach ($_G["cache"]["forums"] as $_var_1) {
		if ($_var_1["type"] == "sub") {
			$_var_2[] = $_var_1["fid"];
		}
	}
	$_var_3 = C::t("forum_forum")->fetch_all_info_by_fids($_var_2);
	foreach ($_var_3 as $_var_1) {
		if (is_array(unserialize($_var_1["extra"]))) {
			$_var_1["extra"] = unserialize($_var_1["extra"]);
		} else {
			$_var_1["extra"] = array();
		}
		if ($_var_1["icon"]) {
			$_var_1["icon"] = $_G["setting"]["attachurl"] . "common/" . $_var_1["icon"];
		} else {
			$_var_1["icon"] = '';
		}
		if ($_var_1["lastpost"]) {
			$_var_1["lastpost"] = explode("\t", $_var_1["lastpost"]);
		} else {
			$_var_1["lastpost"] = '';
		}
		if ($_var_1["lastpost"][2]) {
			$_var_1["lastpost"][2] = dgmdate($_var_1["lastpost"][2], "u", "9999", getglobal("setting/dateformat") . " H:i:s");
		} else {
			$_var_1["lastpost"][2] = '';
		}
		$_var_4[$_var_1["fup"]][$_var_1["fid"]] = $_var_1;
	}
	return $_var_4;
}
function get_wq_app_blog_and_ablum_replay_number($_arg_0, $_arg_1, $_arg_2)
{
	global $_G;
	loadcache("custominfo");
	$_var_4 = $_G["cache"]["custominfo"]["postno"];
	if ($_arg_0 > 1) {
		$_var_5 = (intval($_arg_0) - 1) * $_arg_1 + intval($_arg_2) + 2;
	} else {
		$_var_5 = intval($_arg_0) + intval($_arg_2) + 1;
	}
	if (!empty($_var_4[$_var_5])) {
		return $_var_4[$_var_5];
	}
	return $_var_5 . $_var_4[0];
}
function get_poll_has_image($_arg_0)
{
	foreach ($_arg_0 as $_var_1) {
		if (is_array($_var_1["imginfo"]) && !empty($_var_1["imginfo"])) {
			return true;
		}
	}
	return false;
}
function get_block_data_by_bid($_arg_0)
{
	include_once libfile("function/block");
	loadcache("blockclass");
	$_arg_0 = intval($_arg_0);
	block_get_batch($_arg_0);
	$_var_1 = block_fetch_content($_arg_0, true);
	return $_var_1;
}
function get_block_data_by_ul($_arg_0)
{
	$_var_1 = substr_count($_arg_0, "<img");
	$_var_2 = "<li class=\"on\"></li>";
	if ($_var_1 >= 2) {
		$_var_3 = 2;
		while ($_var_3 <= $_var_1) {
			$_var_2 = $_var_2 . "<li></li>";
			$_var_3 = $_var_3 + 1;
		}
	}
	return $_var_2;
}
function wq_app_get_op_value()
{
	if ($_GET["forumlist"] && $_GET["forumlist"] == 1) {
		$_var_0 = "forumlist";
	}
	if ($_GET["mod"] == "misc" && $_GET["action"] == "nav" && $_GET["ac"] == "myfav") {
		$_var_0 = "fav";
	}
	if ($_GET["mod"] == "misc" && $_GET["action"] == "nav" && !$_GET["ac"]) {
		$_var_0 = "post";
	}
	return $_var_0;
}
function get_wq_app_forum_post($_arg_0, $_arg_1)
{
	global $_G;
	if ($_arg_0) {
		$_var_3 = C::t("forum_thread")->fetch($_arg_0);
		if ($_var_3 && !getstatus($_var_3["status"], 2)) {
			$_var_4 = C::t("forum_post")->fetch_all_by_tid("tid:" . $_arg_0, $_arg_0, true, "ASC", 0, 10, NULL, 0);
			loadcache("smilies");
			foreach ($_var_4 as $_var_5 => $_var_6) {
				if ($_var_6["first"]) {
					unset($_var_4[$_var_5]);
				} else {
					$_var_6["message"] = preg_replace($_G["cache"]["smilies"]["searcharray"], '', $_var_6["message"]);
					$_var_6["message"] = preg_replace("/\\{\\:soso_((e\\d+)|(_\\d+_\\d))\\:\\}/e", '', $_var_6["message"]);
					$_var_4[$_var_5]["message"] = cutstr(preg_replace("/\\[.+?\\]/ies", '', dhtmlspecialchars($_var_6["message"])), 300);
				}
			}
		}
	}
	return $_var_4;
}
function get_feed_content()
{
	global $list;
	global $feed;
	global $_G;
	$_var_3 = wq_app_get_Plang();
	$_var_4 = array();
	$_var_5 = $list["content"][$feed["tid"]];
	$_var_4["content"] = $list["content"][$feed["tid"]];
	$_var_4["thread"] = $list["threads"][$_var_5["tid"]];
	if (!$feed["note"]) {
		$_var_6 = strpos($_var_5["content"], "</div>");
		$_var_4["text"] = "<div class=\"flw_con\">" . substr($_var_5["content"], 0, $_var_6 + 6) . "</div>";
		$_var_4["count"] = 0;
		$_var_4["imglist"] = '';
		$_var_4["overcount"] = 0;
		$_var_7 = strpos($_var_5["content"], "<img");
		if ($_var_6) {
			$_var_4["contenta"] = substr($_var_5["content"], $_var_6 + 6);
		} else {
			$_var_4["contenta"] = $_var_5["content"];
			$_var_7 = 0;
		}
		$_var_8 = trim(strip_tags($_var_4["contenta"]));
		if (!empty($_var_8) && strlen($_var_8) > 80) {
			$_var_4["contenta"] = str_replace(array("<br>", "<br >", "<br />", "<br/>"), '', cutstr($_var_8, 80)) . $_var_3["0966aa06d289d8bb"];
		}
		while ($_var_7) {
			$_var_9 = strpos($_var_5["content"], ">", $_var_7) - $_var_7 + 1;
			$_var_4["count"] = $_var_4["count"] + 1;
			if ($_var_4["count"] <= 3) {
				$_var_10 = substr($_var_5["content"], $_var_7, $_var_9);
				$_var_10 = str_replace(array("<img", "src="), array("<img class=\"lazyload-home\"", "data-src="), $_var_10);
				$_var_10 = str_replace(array("alt"), array("data-alt"), $_var_10);
				$_var_4["imglist"] = $_var_4["imglist"] . "<div class=\"wqimglist\">" . $_var_10 . "</div>";
			}
			$_var_7 = strpos($_var_5["content"], "<img", $_var_7 + 1);
			if ($_var_7 > $_var_6) {
				break;
			}
		}
	} else {
		$_var_4["text"] = $feed["note"];
		$_var_6 = strpos($_var_5["content"], "</div>");
		if ($_var_6) {
			$_var_11 = substr($_var_5["content"], $_var_6 + 6);
		} else {
			$_var_11 = substr($_var_5["content"], $_var_6);
		}
		$_var_4["texta"] = $_var_11;
		$_var_4["textb"] = substr($_var_11, 0);
		$_var_12 = trim(strip_tags($_var_4["textb"]));
		if (!empty($_var_12) && strlen($_var_12) > 80) {
			$_var_4["textb"] = cutstr($_var_12, 80);
		}
		$_var_13 = strpos($_var_5["content"], "smilieid");
		$_var_14 = preg_match("/<img/iUs", $_var_5["content"]);
		if ($_var_14) {
			$_var_7 = strpos($_var_5["content"], "<img");
			$_var_15 = strpos($_var_5["content"], ">", $_var_7);
			if ($_var_13 > $_var_15) {
				$_var_9 = strpos($_var_5["content"], ">", $_var_7) - $_var_7 + 1;
				$_var_10 = substr($_var_5["content"], $_var_7, $_var_9);
				$_var_10 = str_replace(array("<img", "src="), array("<img class=\"lazyload-home\"", "data-src="), $_var_10);
				$_var_10 = str_replace(array("alt"), array("data-alt"), $_var_10);
				$_var_4["imglist"] = $_var_10;
			} else {
				$_var_4["imglist"] = "<img src=" . $_G["style"]["styleimgdir"] . "images/link.png>";
				$_var_4["imglist"] = str_replace(array("<img", "src="), array("<img class=\"lazyload-home\"", "data-src="), $_var_4["imglist"]);
			}
		} else {
			$_var_4["imglist"] = "<img src=" . $_G["style"]["styleimgdir"] . "images/link.png>";
			$_var_4["imglist"] = str_replace(array("<img", "src="), array("<img class=\"lazyload-home\"", "data-src="), $_var_4["imglist"]);
		}
	}
	return $_var_4;
}
function wq_app_setting_feed_title($_arg_0, $_arg_1)
{
	$_var_2 = wq_app_get_Plang();
	$_var_3 = $_var_2["3503679c8dba2a8f"];
	if ($_arg_0 == "feed") {
		if ($_arg_1 == "follow") {
			$_var_3 = $_var_2["937001e9a0611a38"];
		} elseif ($_arg_1 == "special") {
			$_var_3 = $_var_2["a8ca29a353d9151e"];
		} elseif ($_arg_1 == "other") {
			$_var_3 = $_var_2["ecec1f33d9d9b443"];
		}
	}
	return $_var_3;
}
function wq_app_setting_get_feeds($_arg_0, $_arg_1, $_arg_2)
{
	$_var_3 = 0;
	$_var_4 = array();
	if ($_arg_0 == "view") {
		$_var_3 = wq_app_setting_get_feeds_num($_arg_2);
		if ($_var_3 <= 0) {
			$_var_3 = wq_app_setting_get_feeds_num($_arg_2, "home_follow_feed_archiver");
		}
	}
	if ($_arg_0 == "feed") {
		if ($_arg_1 == "follow") {
			$_var_4 = C::t("home_follow")->fetch_all_following_by_uid($_arg_2);
			$_var_4[$_arg_2] = array("uid" => $_arg_2);
			$_arg_2 = array_keys($_var_4);
		}
		if ($_arg_1 == "special") {
			$_var_4 = C::t("home_follow")->fetch_all_following_by_uid($_arg_2, 1);
			$_arg_2 = array_keys($_var_4);
		}
		$_var_3 = wq_app_setting_get_feeds_num($_arg_2) + wq_app_setting_get_feeds_num($_arg_2, "home_follow_feed_archiver");
	}
	return $_var_3;
}
function wq_app_setting_get_feeds_num($_arg_0, $_arg_1 = "home_follow_feed")
{
	$_var_2[] = $_arg_1;
	if (!empty($_arg_0)) {
		$_arg_0 = dintval($_arg_0, true);
		$_var_3[] = is_array($_arg_0) && $_arg_0 ? "uid IN(%n)" : "uid=%d";
		$_var_2[] = $_arg_0;
	}
	$_var_4 = !empty($_var_3) ? " WHERE " . implode(" AND ", $_var_3) : '';
	$_var_5 = DB::result_first("SELECT COUNT(*) FROM %t " . $_var_4 . '', $_var_2);
	return $_var_5;
}
function wq_qq_register($_arg_0, $_arg_1 = 0)
{
	global $_G;
	if (!$_arg_0) {
		return NULL;
	}
	loaducenter();
	$_var_3 = $_G["setting"]["newusergroupid"];
	$_var_4 = md5(random(10));
	$_var_5 = "qq_" . strtolower(random(10)) . "@qq.com";
	$_var_6 = "/^(" . str_replace(array("\\*", "\r\n", " "), array(".*", "|", ''), preg_quote($_G["setting"]["censoruser"] = trim($_G["setting"]["censoruser"]), "/")) . ")\$/i";
	if ($_G["setting"]["censoruser"] && @preg_match($_var_6, $_arg_0)) {
		if (!$_arg_1) {
			showmessage("profile_username_protect");
		} else {
			return NULL;
		}
	}
	$_var_7 = wq_qq_system_register($_arg_0, $_var_4, $_var_5);
	$_var_8 = array("credits" => explode(",", $_G["setting"]["initcredits"]));
	C::t("common_member")->insert($_var_7, $_arg_0, $_var_4, $_var_5, $_G["clientip"], $_var_3, $_var_8);
	if ($_G["setting"]["regctrl"] || $_G["setting"]["regfloodctrl"]) {
		C::t("common_regip")->delete_by_dateline($_G["timestamp"] - ($_G["setting"]["regctrl"] > 72 ? $_G["setting"]["regctrl"] : 72) * 3600);
		if ($_G["setting"]["regctrl"]) {
			C::t("common_regip")->insert(array("ip" => $_G["clientip"], "count" => -1, "dateline" => $_G["timestamp"]));
		}
	}
	if ($_G["setting"]["regverify"] == 2) {
		C::t("common_member_validate")->insert(array("uid" => $_var_7, "submitdate" => $_G["timestamp"], "moddate" => 0, "admin" => '', "submittimes" => 1, "status" => 0, "message" => '', "remark" => ''), false, true);
		manage_addnotify("verifyuser");
	}
	require_once libfile("function/member");
	$_var_9 = 1296000;
	setloginstatus(array("uid" => $_var_7, "username" => $_arg_0, "password" => $_var_4, "groupid" => $_var_3), $_var_9);
	dsetcookie("isqquser", 1, $_var_9);
	include_once libfile("function/stat");
	updatestat("register");
	include_once libfile("cache/userstats", "function");
	build_cache_userstats();
	return $_var_7;
}
function process_username($_arg_0)
{
	global $_G;
	$_arg_0 = trim($_arg_0);
	$_var_2 = dstrlen($_arg_0);
	if ($_var_2 < 3) {
		$_arg_0 = $_arg_0 . chr(rand(65, 90)) . chr(rand(65, 90)) . chr(rand(65, 90) . chr(rand(65, 90)));
	} else {
		if ($_var_2 > 15) {
			$_arg_0 = cutstr($_arg_0, 15, '');
		}
	}
	loaducenter();
	$_var_3 = uc_user_checkname($_arg_0);
	if ($_var_3 == -1) {
		$_arg_0 = str_replace(array(",", " ", "%", "<", ">", "*", "\""), '', $_arg_0);
		$_arg_0 = process_username($_arg_0);
	} else {
		if ($_var_3 == -2) {
			$_var_4 = 0;
			while ($_var_4 < 5) {
				$_var_5 = $_var_5 . chr(rand(65, 90));
				$_var_4;
			}
			$_arg_0 = process_username($_var_5);
		} else {
			if ($_var_3 == -3) {
				$_arg_0 = cutstr($_arg_0, 10, '') . "_" . chr(rand(65, 90)) . chr(rand(65, 90)) . chr(rand(65, 90)) . chr(rand(65, 90));
				$_arg_0 = process_username($_arg_0);
			}
		}
	}
	$_var_6 = "/^(" . str_replace(array("\\*", "\r\n", " "), array(".*", "|", ''), preg_quote($_G["setting"]["censoruser"] = trim($_G["setting"]["censoruser"]), "/")) . ")\$/i";
	if ($_G["setting"]["censoruser"] && @preg_match($_var_6, $_arg_0)) {
		$_var_7 = explode("\n", $_G["setting"]["censoruser"]);
		foreach ($_var_7 as $_var_8 => $_var_9) {
			$_var_5[] = trim($_var_9);
		}
		$_arg_0 = str_replace($_var_5, '', $_arg_0);
		$_arg_0 = process_username($_arg_0);
	}
	return $_arg_0;
}
function wq_qq_system_register($_arg_0, $_arg_1, $_arg_2)
{
	global $_G;
	$_var_4 = uc_user_register(addslashes($_arg_0), $_arg_1, $_arg_2, '', '', $_G["clientip"]);
	if ($_var_4 <= 0) {
		if (!$_var_5) {
			if ($_var_4 == -1) {
				showmessage("profile_username_illegal");
			} else {
				if ($_var_4 == -2) {
					showmessage("profile_username_protect");
				} else {
					if ($_var_4 == -3) {
						return $_var_4 = wq_qq_system_register(cutstr($_arg_0, 11, '') . chr(rand(65, 90)) . chr(rand(65, 90)) . chr(rand(65, 90)) . chr(rand(65, 90)), $_arg_1, $_arg_2);
					}
					if ($_var_4 == -4) {
						showmessage("profile_email_illegal");
					} else {
						if ($_var_4 == -5) {
							showmessage("profile_email_domain_illegal");
						} else {
							if ($_var_4 == -6) {
								showmessage("profile_email_duplicate");
							} else {
								showmessage("undefined_action");
							}
						}
					}
				}
			}
		} else {
			return NULL;
		}
	} else {
		return $_var_4;
	}
}
function save_avatar($_arg_0)
{
	$_var_1 = DISCUZ_ROOT . "/data/cache/avatarTmp/";
	dmkdir($_var_1);
	$_var_2 = $_var_1 . "/" . date("His") . strtolower(random(16)) . ".jpg";
	$_var_3 = dfsockopen($_arg_0, 0, array(), '', false);
	file_put_contents($_var_2, $_var_3);
	return $_var_2;
}
function wq_qq_uploadAvatar($_arg_0, $_arg_1)
{
	global $_G;
	if (!$_arg_0 || !$_arg_1) {
		return false;
	}
	$_arg_1 = save_avatar($_arg_1);
	list($_var_3, $_var_4, $_var_5, $_var_6) = getimagesize($_arg_1);
	if (!$_var_3) {
		return false;
	}
	if ($_var_3 < 10 || $_var_4 < 10 || $_var_5 == 4) {
		return false;
	}
	$_var_7 = array(1 => ".gif", 2 => ".jpg", 3 => ".png");
	$_var_8 = $_var_9[$_var_5];
	if (!$_var_8) {
		$_var_8 = ".jpg";
	}
	$_var_10 = $_G["setting"]["attachdir"];
	$_var_11 = $_var_10 . "./temp/upload" . $_arg_0 . $_var_8;
	file_exists($_var_11) && @unlink($_var_11);
	file_put_contents($_var_11, file_get_contents($_arg_1));
	if (!is_file($_var_11)) {
		return false;
	}
	$_var_12 = "./temp/upload" . $_arg_0 . "big" . $_var_8;
	$_var_13 = "./temp/upload" . $_arg_0 . "middle" . $_var_8;
	$_var_14 = "./temp/upload" . $_arg_0 . "small" . $_var_8;
	$_var_15 = new image();
	if ($_var_15->Thumb($_var_11, $_var_12, 200, 250, 1) <= 0) {
		return false;
	}
	if ($_var_15->Thumb($_var_11, $_var_13, 120, 120, 1) <= 0) {
		return false;
	}
	if ($_var_15->Thumb($_var_11, $_var_14, 48, 48, 2) <= 0) {
		return false;
	}
	$_var_12 = $_var_10 . $_var_12;
	$_var_13 = $_var_10 . $_var_13;
	$_var_14 = $_var_10 . $_var_14;
	$_var_16 = wq_qq_byte2hex(file_get_contents($_var_12));
	$_var_17 = wq_qq_byte2hex(file_get_contents($_var_13));
	$_var_18 = wq_qq_byte2hex(file_get_contents($_var_14));
	$_var_19 = "&avatar1=" . $_var_16 . "&avatar2=" . $_var_17 . "&avatar3=" . $_var_18;
	$_var_20 = wq_qq_uc_api_post_ex("user", "rectavatar", array("uid" => $_arg_0), $_var_19);
	@unlink($_var_11);
	@unlink($_var_12);
	@unlink($_var_13);
	@unlink($_var_14);
	@unlink($_arg_1);
	return true;
}
function wq_qq_byte2hex($_arg_0)
{
	$_var_1 = '';
	$_var_2 = unpack("H*", $_arg_0);
	$_var_2 = str_split($_var_2[1], 2);
	$_var_3 = '';
	foreach ($_var_2 as $_var_4 => $_var_5) {
		$_var_3 = $_var_3 . strtoupper($_var_5);
	}
	return $_var_3;
}
function wq_qq_uc_api_post_ex($_arg_0, $_arg_1, $_arg_2 = array(), $_arg_3 = '')
{
	$_var_4 = $_var_5 = '';
	foreach ($_arg_2 as $_var_6 => $_var_7) {
		$_var_6 = urlencode($_var_6);
		if (is_array($_var_7)) {
			$_var_8 = $_var_9 = '';
			foreach ($_var_7 as $_var_10 => $_var_11) {
				$_var_10 = urlencode($_var_10);
				$_var_8 = $_var_8 . ('' . $_var_9 . '' . $_var_6 . "[" . $_var_10 . "]=" . urlencode(uc_stripslashes($_var_11)));
				$_var_9 = "&";
			}
			$_var_4 = $_var_4 . ($_var_5 . $_var_8);
		} else {
			$_var_4 = $_var_4 . ('' . $_var_5 . '' . $_var_6 . "=" . urlencode(uc_stripslashes($_var_7)));
		}
		$_var_5 = "&";
	}
	$_var_12 = uc_api_requestdata($_arg_0, $_arg_1, $_var_4, $_arg_3);
	return uc_fopen2(UC_API . "/index.php", 500000, $_var_12, '', true, UC_IP, 20);
}
function wq_usergroup($_arg_0)
{
	global $_G;
	if (!$_G["cache"]["usergroups"]) {
		loadcache("usergroups");
	}
	$_var_2["prefix"] = "LV.";
	foreach ($_G["cache"]["usergroups"] as $_var_3 => $_var_4) {
		$_var_2["group"][$_var_3] = array("title" => $_var_4["stars"], "background" => 1, "style" => 1);
	}
	$_var_2["class"] = array("0" => "1", "1" => "1", "2" => "2", "3" => "2", "4" => "3", "5" => "3", "6" => "3", "7" => "4", "8" => "4", "9" => "5");
	savecache("wq_usergroup", $_var_2);
	return $_var_2;
}
function wq_usergroup_show($_arg_0)
{
	global $_G;
	global $wq_app_usergroup;
	if ($_arg_0 > 0 && $wq_app_usergroup["group"][$_arg_0]) {
		$_var_3 = $wq_app_usergroup["group"][$_arg_0];
		$_var_4 = $wq_app_usergroup["prefix"] . $_var_3["title"];
		$_var_5 = $wq_app_usergroup["class"][$_var_3["title"]];
		$_var_6 = '';
		if (!$_var_3["style"]) {
			if ($_var_3["bgcolor"] && $_var_3["background"]) {
				$_var_6 = $_var_6 . ("background-color:" . $_var_3["bgcolor"] . ";");
			}
			if ($_var_3["color"]) {
				$_var_6 = $_var_6 . ("color:" . $_var_3["color"] . ";");
			}
			$_var_6 = "style=\"" . $_var_6 . "\"";
		}
		if ($_var_3["background"]) {
			$_var_7 = "<i class=\"dislv" . $_var_5 . " dislv\" " . $_var_6 . ">" . $_var_4 . "</i>";
		} else {
			$_var_7 = "<i class=\"nodislv" . $_var_5 . "\" " . $_var_6 . ">" . $_var_4 . "</i>";
		}
		return $_var_7;
	}
}
function wq_usergroup_showMenu()
{
	global $_G;
	global $do;
	$_var_2 = $_G["member"]["extgroupids"] ? explode("\t", $_G["member"]["extgroupids"]) : array();
	$_var_3["current"] = "upgrade";
	foreach ($_G["cache"]["usergroups"] as $_var_4 => $_var_5) {
		$_var_5["grouptitle"] = strip_tags($_var_5["grouptitle"]);
		if ($_var_5["type"] == "special") {
			$_var_6 = $_G["cache"]["usergroup_" . $_var_4]["radminid"] ? "admin" : "user";
		} else {
			if ($_var_5["type"] == "system") {
				$_var_6 = $_G["cache"]["usergroup_" . $_var_4]["radminid"] ? "admin" : "user";
			} else {
				if ($_var_5["type"] == "member") {
					$_var_6 = "upgrade";
				}
			}
		}
		$_var_7 = '';
		if (!empty($_G["wq_gid"]) && $_G["wq_gid"] == $_var_4) {
			$_var_7 = " class=\"xi1\"";
		}
		$_var_8 = "<li class=\"wqnew_bottom\"><a style=\"display: block;\" href=\"home.php?mod=spacecp&ac=usergroup&gid=" . $_var_4 . "\"" . $_var_7 . ">" . wq_usergroup_show($_var_4) . "<i class=\"wqm_right5\"></i>" . $_var_5["grouptitle"] . "</a></li>";
		if (in_array($_var_4, $_var_2)) {
			$_var_3["my"] = $_var_3["my"] . $_var_8;
		}
		$_var_3[$_var_6] = $_var_3[$_var_6] . $_var_8;
		if (!empty($_G["wq_gid"]) && $_G["wq_gid"] == $_var_4) {
			$_var_3["current"] = $_var_6;
		}
	}
	$_var_7 = '';
	if (!$_G["wq_gid"] && $do == "usergroup") {
		$_var_7 = " class=\"xi1\"";
	}
	$_var_3["my"] = "<li><a style=\"display: block;\" href=\"home.php?mod=spacecp&ac=usergroup\"" . $_var_7 . ">" . wq_usergroup_show($_G["groupid"]) . "<i class=\"wqm_right5\"></i>" . $_G["group"]["grouptitle"] . "</a></li>" . $_var_3["my"];
	if (!$_G["wq_gid"] && $do == "usergroup") {
		$_var_3["current"] = "my";
	}
	return $_var_3;
}
function wq_app_load_icon()
{
	global $_G;
	global $mysetting;
	$_var_2 = $_G["style"]["styleimgdir"] . "images/icon_load.gif";
	return "<div class=\"wqmore\" style=\"display: none\">\r\n                    <img src=\"" . $_var_2 . "\"/>\r\n                    &#x8F7D;&#x5165;&#x4E2D;&#xFF0C;&#x8BF7;&#x7A0D;&#x7B49;...\r\n                </div>";
}
function wq_app_multipage($_arg_0)
{
	global $_G;
	parse_str($_SERVER["QUERY_STRING"], $_var_2);
	unset($_var_2["page"]);
	unset($_var_2["mobile"]);
	unset($_var_2["inajax"]);
	unset($_var_2["api"]);
	$_var_3 = "forum.php?" . http_build_query($_var_2);
	return str_replace("forum.php?mod=forumdisplay&fid=" . $_G[fid], $_var_3, $_arg_0);
}
function check_is_favorite($_arg_0, $_arg_1)
{
	global $_G;
	$_arg_0 = intval($_arg_0);
	$_arg_1 = trim($_arg_1);
	if (!$_arg_0 || !$_arg_1) {
		return false;
	}
	if ($_arg_1 == "thread") {
		$_var_3 = "tid";
	} elseif ($_arg_1 == "forum") {
		$_var_3 = "fid";
	} elseif ($_arg_1 == "blog") {
		$_var_3 = "blogid";
	} elseif ($_arg_1 == "group") {
		$_var_3 = "gid";
	} elseif ($_arg_1 == "album") {
		$_var_3 = "albumid";
	} elseif ($_arg_1 == "space") {
		$_var_3 = "uid";
	} elseif ($_arg_1 == "article") {
		$_var_3 = "aid";
	}
	$_var_4 = C::t("home_favorite")->fetch_by_id_idtype($_arg_0, $_var_3, $_G["uid"]);
	if ($_var_4 && count($_var_4) > 0) {
		return true;
	}
	return false;
}
function wq_app_get_album_pic_replynum_by_albumid($_arg_0)
{
	$_var_1 = DB::fetch_all("SELECT c.id,count(c.id) as replynum FROM " . DB::table("home_comment") . " c  LEFT JOIN " . DB::table("home_pic") . " p ON c.id=p.picid WHERE p.albumid=%d  GROUP BY c.id;", array($_arg_0));
	foreach ($_var_1 as $_var_2 => $_var_3) {
		$_var_4[$_var_3["id"]] = $_var_3["replynum"];
	}
	return $_var_4;
}
function wq_app_qrcode_generate($_arg_0, $_arg_1, $_arg_2)
{
	$_var_3 = DISCUZ_ROOT . "./data/cache/wq_app_setting/" . $_arg_1 . "/";
	$_var_4 = $_var_3 . $_arg_2 . ".png";
	if (!file_exists($_var_4) || !filesize($_var_4)) {
		require_once DISCUZ_ROOT . "source/plugin/wq_app_setting/class/qrcode.class.php";
		dmkdir($_var_3);
		QRcode::png($_arg_0, $_var_4, QR_ECLEVEL_Q, 4);
	}
	return "data/cache/wq_app_setting/" . $_arg_1 . "/" . $_arg_2 . ".png";
}
function wq_app_get_personal_background($_arg_0, $_arg_1, $_arg_2)
{
	global $_G;
	$_var_4 = '';
	if (!$_arg_0) {
		$_var_4 = $_G["style"]["styleimgdir"] . "images/wqhead_bg" . rand(1, 4) . ".jpg";
	}
	if ($_arg_0 && $_G["cache"]["plugin"]["wq_space"]) {
		$_var_5 = DB::fetch_first("SELECT b.*  FROM " . DB::table("wq_space_log") . " l  LEFT JOIN " . DB::table("wq_space_background") . " b ON l.bid=b.bid WHERE l.uid=%d ORDER BY l.lid DESC;", array($_arg_0));
		if ($_var_5) {
			$_var_4 = $_var_5["remote"] == 1 ? $_var_5["background"] : "data/attachment/portal/" . $_var_5["background"];
		}
	}
	return $_var_4;
}
function wq_app_setting_set_menulist($_arg_0 = 0)
{
	$_var_1 = C::t("#wq_app_setting#wq_app_setting_menumanage")->fetch_all_by_search($_arg_0);
	foreach ($_var_1 as $_var_2 => $_var_3) {
		$_var_4[$_var_3["id"]] = $_var_3;
	}
	return $_var_4;
}
function wq_app_setting_cache_menulist()
{
	if (!function_exists("savecache")) {
		require_once libfile("function/cache");
	}
	$_var_0 = wq_app_setting_set_menulist();
	savecache("wq_app_menulist", $_var_0);
}
function wq_app_setting_cache_color()
{
	if (!function_exists("savecache")) {
		require_once libfile("function/cache");
	}
	$_var_0 = wq_app_setting_get_all_color();
	savecache("wq_app_color", $_var_0);
}
function wq_app_setting_get_all_color()
{
	$_var_0 = $_var_0 = C::t("#wq_app_setting#wq_app_setting_style")->fetch_all_by_search();
	foreach ($_var_0 as $_var_1 => $_var_2) {
		$_var_3[$_var_2["sid"]] = $_var_2;
	}
	return $_var_3;
}
function wq_app_setting_insert_menu()
{
	$_var_0 = wq_app_get_Plang();
	$_var_1 = array(array("menuname" => $_var_0["284f927b236721f7"], "menuurl" => "forum.php", "menutype" => "1", "notmenuicon" => "wqiconfont2 wqicon2-shouye", "menuicon" => "wqiconfont2 wqicon2-shouye2", "displayorder" => 1), array("menuname" => $_var_0["1f2bc3ad6c3c78b3"], "menuurl" => "forum.php?forumlist=1", "menutype" => "1", "notmenuicon" => "wqiconfont2 wqicon2-bankuai", "menuicon" => "wqiconfont2 wqicon2-bankuai2", "displayorder" => 2), array("menuname" => $_var_0["b93c5f8f3d2ec943"], "menuurl" => "forum.php?mod=misc&action=nav", "menutype" => "1", "notmenuicon" => "wqiconfont2 wqicon2-fatie", "menuicon" => "wqiconfont2 wqicon2-fatie2", "displayorder" => 3), array("menuname" => $_var_0["197c70954d1e6c19"], "menuurl" => "portal.php", "menutype" => "1", "notmenuicon" => "wqiconfont2 wqicon2-menhu", "menuicon" => "wqiconfont2 wqicon2-menhu2", "displayorder" => 4), array("menuname" => $_var_0["4280e1909724fc0d"], "menuurl" => "home.php?mod=space&do=profile&mycenter=1", "menutype" => "1", "notmenuicon" => "wqiconfont2 wqicon2-wode", "menuicon" => "wqiconfont2 wqicon2-wode2", "displayorder" => 5), array("menuname" => "&#x9996;&#x9875;", "menuurl" => "plugin.php?id=wq_channel&mod=index&pageid=1", "menutype" => "1", "notmenuicon" => "wqiconfont2 wqicon2-shouye", "menuicon" => "wqiconfont2 wqicon2-shouye2", "displayorder" => 6), array("menuname" => "&#x793E;&#x533A;", "menuurl" => "plugin.php?id=wq_channel&mod=index&pageid=2", "menutype" => "1", "notmenuicon" => "wqiconfont2 wqicon2-bankuai", "menuicon" => "wqiconfont2 wqicon2-bankuai2", "displayorder" => 7), array("menuname" => "&#x53D1;&#x73B0;", "menuurl" => "plugin.php?id=wq_channel&mod=index&pageid=5", "menutype" => "1", "notmenuicon" => "wqiconfont2 wqicon2-faxian", "menuicon" => "wqiconfont2 wqicon2-faxian2", "displayorder" => 8), array("menuname" => $_var_0["284f927b236721f7"], "menuurl" => "forum.php", "menutype" => "2", "notmenuicon" => "wqiconfont2 wqicon2-shouye", "displayorder" => 1), array("menuname" => $_var_0["1f2bc3ad6c3c78b3"], "menuurl" => "forum.php?forumlist=1", "menutype" => "2", "notmenuicon" => "wqiconfont2 wqicon2-bankuai", "displayorder" => 2), array("menuname" => $_var_0["b93c5f8f3d2ec943"], "menuurl" => "forum.php?mod=misc&action=nav", "menutype" => "2", "notmenuicon" => "wqiconfont2 wqicon2-fatie", "displayorder" => 3), array("menuname" => $_var_0["197c70954d1e6c19"], "menuurl" => "portal.php", "menutype" => "2", "notmenuicon" => "wqiconfont2 wqicon2-menhu", "displayorder" => 4), array("menuname" => $_var_0["1e7246dd6ccc5539"], "menuurl" => "search.php", "menutype" => "2", "notmenuicon" => "wqiconfont2 wqicon2-sousuo", "displayorder" => 5), array("menuname" => $_var_0["20de32b2fa5e9d06"], "menuurl" => "plugin.php?id=wq_sign", "menutype" => "2", "notmenuicon" => "wqiconfont2 wqicon2-qiandao", "displayorder" => 7), array("menuname" => $_var_0["8bafd5202547e50d"], "menuurl" => "home.php?mod=space&do=blog&view=all", "menutype" => "2", "notmenuicon" => "wqiconfont2 wqicon2-rizhi1", "displayorder" => 8), array("menuname" => $_var_0["167687d3478142ba"], "menuurl" => "home.php?mod=space&do=album&view=all", "menutype" => "2", "notmenuicon" => "wqiconfont2 wqicon2-xiangce1", "displayorder" => 9), array("menuname" => $_var_0["55a13021a8604d26"], "menuurl" => "home.php?mod=space&do=wall&from=space", "menutype" => "2", "notmenuicon" => "wqiconfont2 wqicon2-liuyan", "displayorder" => 10), array("menuname" => $_var_0["2f66aa86e2aa1c1e"], "menuurl" => "misc.php?mod=tag", "menutype" => "2", "notmenuicon" => "wqiconfont2 wqicon2-tag", "displayorder" => 11), array("menuname" => $_var_0["891c3349e42ca283"], "menuurl" => "home.php?mod=space&do=pm", "menutype" => "2", "notmenuicon" => "wqiconfont2 wqicon2-pinglun", "displayorder" => 12), array("menuname" => $_var_0["0cdc284874d77017"], "menuurl" => "home.php?mod=space&do=notice", "menutype" => "2", "notmenuicon" => "wqiconfont2 wqicon2-tixing2", "displayorder" => 13), array("menuname" => $_var_0["e1c38a4dd824fb35"], "menuurl" => "home.php?mod=space&do=favorite&type=all", "menutype" => "2", "notmenuicon" => "wqiconfont2 wqicon2-shoucang1", "displayorder" => 14));
	foreach ($_var_1 as $_var_2 => $_var_3) {
		$_var_4 = $_var_3;
		$_var_4["type"] = 1;
		$_var_4["dateline"] = time();
		C::t("#wq_app_setting#wq_app_setting_menumanage")->insert($_var_4);
	}
	wq_app_setting_cache_menulist();
	$_var_5 = wq_app_setting_set_menulist(2);
	foreach ($_var_5 as $_var_2 => $_var_3) {
		$_var_6[] = $_var_3["id"];
	}
	C::t("common_setting")->update("wq_app_setting_side_menu", $_var_6);
	$_var_4 = array("foot" => array("menuone" => 1, "menutwo" => 2, "menuthree" => 3, "menufour" => 4, "menufive" => 5), "num" => 5);
	C::t("common_setting")->update("wq_app_setting_footer_menu", $_var_4);
	if (!function_exists("updatecache")) {
		include_once libfile("function/cache");
	}
	updatecache("setting");
}
function wq_app_setting_insert_color()
{
	$_var_0 = wq_app_get_Plang();
	$_var_1 = array(array("sid" => "1", "name" => $_var_0["ae2c59a675bf6827"], "color" => "#18191c", "banner" => "./source/plugin/wq_app_setting/static/style/t1/user_bule.jpg", "targettplname" => "./source/plugin/wq_app_setting/static/style/t1/", "displayorder" => 1), array("sid" => "2", "name" => $_var_0["db9bfd5e071c8c0d"], "color" => "#64b8ff", "banner" => "./source/plugin/wq_app_setting/static/style/t2/user_bule.jpg", "targettplname" => "./source/plugin/wq_app_setting/static/style/t2/", "displayorder" => 2), array("sid" => "3", "name" => $_var_0["3f7627ff4bb224b2"], "color" => "#56a0f9", "banner" => "./source/plugin/wq_app_setting/static/style/t3/user_bule.jpg", "targettplname" => "./source/plugin/wq_app_setting/static/style/t3/", "displayorder" => 3), array("sid" => "4", "name" => $_var_0["c4e58cdb31a79751"], "color" => "#1e81d2", "banner" => "./source/plugin/wq_app_setting/static/style/t4/user_bule.jpg", "targettplname" => "./source/plugin/wq_app_setting/static/style/t4/", "displayorder" => 4), array("sid" => "5", "name" => $_var_0["4ea544aa7a5ead18"], "color" => "#ff4040", "banner" => "./source/plugin/wq_app_setting/static/style/t5/user_bule.jpg", "targettplname" => "./source/plugin/wq_app_setting/static/style/t5/", "displayorder" => 5), array("sid" => "6", "name" => $_var_0["861a0e08cbe6a0eb"], "color" => "#fc716c", "banner" => "./source/plugin/wq_app_setting/static/style/t6/user_bule.jpg", "targettplname" => "./source/plugin/wq_app_setting/static/style/t6/", "displayorder" => 6), array("sid" => "7", "name" => $_var_0["3c0e369d969e24db"], "color" => "#ff5c8b", "banner" => "./source/plugin/wq_app_setting/static/style/t7/user_bule.jpg", "targettplname" => "./source/plugin/wq_app_setting/static/style/t7/", "displayorder" => 7), array("sid" => "8", "name" => $_var_0["47a93230577c65ba"], "color" => "#fe552e", "banner" => "./source/plugin/wq_app_setting/static/style/t8/user_bule.jpg", "targettplname" => "./source/plugin/wq_app_setting/static/style/t8/", "displayorder" => 8), array("sid" => "9", "name" => $_var_0["27a7e803450fbaf2"], "color" => "#ff8500", "banner" => "./source/plugin/wq_app_setting/static/style/t9/user_bule.jpg", "targettplname" => "./source/plugin/wq_app_setting/static/style/t9/", "displayorder" => 9), array("sid" => "10", "name" => $_var_0["1ce7580fe0c51651"], "color" => "#ffb700", "banner" => "./source/plugin/wq_app_setting/static/style/t10/user_bule.jpg", "targettplname" => "./source/plugin/wq_app_setting/static/style/t10/", "displayorder" => 10), array("sid" => "11", "name" => $_var_0["b8fa4e5f5f4d84ac"], "color" => "#9570fe", "banner" => "./source/plugin/wq_app_setting/static/style/t11/user_bule.jpg", "targettplname" => "./source/plugin/wq_app_setting/static/style/t11/", "displayorder" => 11), array("sid" => "12", "name" => $_var_0["79c0f8e7481fc387"], "color" => "#c5c56b", "banner" => "./source/plugin/wq_app_setting/static/style/t12/user_bule.jpg", "targettplname" => "./source/plugin/wq_app_setting/static/style/t12/", "displayorder" => 12), array("sid" => "13", "name" => $_var_0["9ee619ec1307d1c6"], "color" => "#06c1ae", "banner" => "./source/plugin/wq_app_setting/static/style/t13/user_bule.jpg", "targettplname" => "./source/plugin/wq_app_setting/static/style/t13/", "displayorder" => 13), array("sid" => "14", "name" => $_var_0["eba97f85c067380e"], "color" => "#31c27d", "banner" => "./source/plugin/wq_app_setting/static/style/t14/user_bule.jpg", "targettplname" => "./source/plugin/wq_app_setting/static/style/t14/", "displayorder" => 14), array("sid" => "15", "name" => $_var_0["88d3a143206eee22"], "color" => "#8fc31c", "banner" => "./source/plugin/wq_app_setting/static/style/t15/user_bule.jpg", "targettplname" => "./source/plugin/wq_app_setting/static/style/t15/", "displayorder" => 15));
	foreach ($_var_1 as $_var_2 => $_var_3) {
		$_var_4 = $_var_3;
		$_var_4["type"] = 1;
		$_var_4["dateline"] = time();
		$_var_4["defaultcolor"] = 0;
		$_var_4["status"] = 1;
		C::t("#wq_app_setting#wq_app_setting_style")->insert($_var_4);
	}
	wq_app_setting_cache_color();
}
function wq_app_get_forumlist($_arg_0, $_arg_1)
{
	global $_G;
	loadcache("forums");
	$_var_3 = $_var_4 = $_var_5 = array();
	$_var_6 = count($_G["cache"]["forums"]);
	foreach ($_G["cache"]["forums"] as $_var_7 => $_var_8) {
		if ($_var_8["type"] == "group" && $_var_8["status"] == "1") {
			$_var_3[$_var_7] = $_var_8;
			$_var_9[] = $_var_8["fid"];
		}
	}
	foreach ($_var_3 as $_var_10 => $_var_11) {
		foreach ($_G["cache"]["forums"] as $_var_7 => $_var_8) {
			if ($_var_8["type"] == "forum" && $_var_8["status"] == "1" && $_var_8["fup"] == $_var_11["fid"]) {
				$_var_4[$_var_8["fup"]][] = $_var_8;
				$_var_9[] = $_var_8["fid"];
			}
		}
	}
	foreach ($_var_4 as $_var_12 => $_var_13) {
		foreach ($_var_13 as $_var_10 => $_var_11) {
			foreach ($_G["cache"]["forums"] as $_var_7 => $_var_8) {
				if ($_var_8["type"] == "sub" && $_var_8["status"] == "1" && $_var_8["fup"] == $_var_11["fid"]) {
					$_var_5[$_var_8["fup"]][] = $_var_8;
					$_var_9[] = $_var_8["fid"];
				}
			}
		}
	}
	foreach ($_var_3 as $_var_14 => $_var_15) {
		$_var_16 = $_var_6 > 30 && count($_var_4[$_var_14]) > 2;
		$_var_17[] = wq_app_showforum($_var_15, "group", '', array(), '', $_var_16);
		if (!empty($_var_4[$_var_14])) {
			foreach ($_var_4[$_var_14] as $_var_8) {
				$_var_18 = $_arg_0[$_var_8["fid"]] || $_arg_0[$_var_8["fid"]] === "0" ? $_arg_0[$_var_8["fid"]] : "1";
				$_var_17[] = wq_app_showforum($_var_8, '', '', $_arg_1, $_var_18);
				if (!empty($_var_5[$_var_8["fid"]])) {
					foreach ($_var_5[$_var_8["fid"]] as $_var_19) {
						$_var_18 = $_arg_0[$_var_19["fid"]] || $_arg_0[$_var_19["fid"]] === "0" ? $_arg_0[$_var_19["fid"]] : "1";
						$_var_17[] = wq_app_showforum($_var_19, "sub", '', $_arg_1, $_var_18);
					}
				}
			}
		}
		wq_app_showforum($_var_15, '', "lastboard");
	}
}
function wq_app_cache_recommend_or_favorite_info($_arg_0)
{
	global $_G;
	require_once libfile("function/cache");
	if ($_arg_0 == "recommendadd") {
		$_var_2 = wq_app_get_user_all_recommend($_G["uid"]);
	} else {
		if ($_arg_0 == "favorite") {
			$_var_2 = wq_app_get_user_all_favorite($_G["uid"], "tid");
		}
	}
	savecache("wq_app_" . $_arg_0 . "_" . $_G["uid"], $_var_2);
}
function wq_app_get_user_all_favorite($_arg_0, $_arg_1)
{
	$_var_2 = C::t("home_favorite")->fetch_all_by_uid_idtype($_arg_0, $_arg_1);
	foreach ($_var_2 as $_var_3 => $_var_4) {
		$_var_5[$_var_4["id"]] = $_var_4;
	}
	return $_var_5;
}
function wq_app_get_user_all_recommend($_arg_0)
{
	$_var_1 = DB::fetch_all("SELECT * FROM %t WHERE recommenduid=%d", array("forum_memberrecommend", $_arg_0));
	foreach ($_var_1 as $_var_2 => $_var_3) {
		$_var_4[$_var_3["tid"]] = $_var_3;
	}
	return $_var_4;
}
function wq_app_get_last_thread_and_next_thread($_arg_0 = "nextoldset")
{
	global $_G;
	$_var_2 = $_G["thread"]["lastpost"];
	$_var_3 = $_G["fid"];
	$_var_4 = "<";
	$_var_5 = "DESC";
	if ($_arg_0 == "nextnewset") {
		$_var_4 = ">";
		$_var_5 = "ASC";
	}
	$_var_6 = DB::result_first("SELECT subject FROM %t WHERE fid=%d AND displayorder>=0 AND closed=0 AND lastpost" . $_var_4 . "%d  ORDER BY " . DB::order("lastpost", $_var_5) . DB::limit(1), array("forum_thread", $_var_3, $_var_2));
	return $_var_6;
}
function wq_app_setting_upload_images($_arg_0, $_arg_1 = '', $_arg_2 = 2)
{
	global $_G;
	include_once DISCUZ_ROOT . "./source/plugin/wq_app_setting/class/upload.class.php";
	$_var_4 = new wq_app_setting_discuz_upload();
	$_var_4->init($_arg_0, $_arg_1);
	$_var_5 = $_var_4->attach;
	if ($_var_5["size"] > $_arg_2 * 1024 * 1024) {
		return "-105";
	}
	if (!$_var_5["isimage"]) {
		return "-102";
	}
	$_var_4->save();
	$_var_6 = intval($_var_4->errorcode);
	if ($_var_6 < 0) {
		return $_var_6;
	}
	return $_var_5["attachment"];
}
function wq_app_loadcsstemplate()
{
	global $_G;
	require_once DISCUZ_ROOT . "/source/plugin/wq_app_setting/class/class_template.php";
	$_var_1 = new wq_template();
	$_var_2 = $_var_1->loadcsstemplate();
	return $_var_2;
}
function wq_app_template_set_csscache()
{
	global $_G;
	$_var_1 = DISCUZ_ROOT . "./template/wq_app/static/style/module.css";
	$_var_2 = @filemtime($_var_1);
	$_var_3 = @filemtime(DISCUZ_ROOT . "./data/cache/wq_app_setting/csscache/style_wq_app_module.css");
	if (file_exists($_var_1) && ($_var_2 > $_var_3 || empty($_var_3))) {
		$_var_4 = @implode('', file($_var_1));
		$_var_4 = preg_replace("/\\/\\*\\*\\s*(.+?)\\s*\\*\\*\\//", "[\\1]", $_var_4);
		$_var_4 = preg_replace("/url\\(([\"'])?/i", "url(\\1" . $_G["siteurl"] . '', $_var_4);
		$_var_4 = preg_replace(array("/\\s*([,;:\\{\\}])\\s*/", "/[\\t\\n\\r]/", "/\\/\\*.+?\\*\\//"), array("\\1", '', ''), $_var_4);
		$_var_5 = DISCUZ_ROOT . "./data/cache/wq_app_setting/csscache";
		dmkdir($_var_5);
		if (@($_var_6 = fopen($_var_5 . "/style_wq_app_module.css", "w"))) {
			fwrite($_var_6, $_var_4);
			fclose($_var_6);
		} else {
			echo "Can not write to cache files, please check directory ./data/ and ./data/cache/ .";
			return 0;
		}
	}
}
function set_search_cookie($_arg_0)
{
	global $_G;
	$_var_2 = array();
	if (getcookie("search_" . $_G["uid"])) {
		$_var_2 = unserialize(getcookie("search_" . $_G["uid"]));
	}
	if (empty($_var_2)) {
		$_var_2[] = $_arg_0;
	} else {
		$_var_3 = count($_var_2);
		if (!in_array($_arg_0, $_var_2)) {
			array_unshift($_var_2, $_arg_0);
		}
		array_filter($_var_2);
		$_var_2 = array_values(array_slice($_var_2, 0, 20));
	}
	$_var_2 = serialize($_var_2);
	dsetcookie("search_" . $_G["uid"], $_var_2, 0, 1, true);
}
function wq_app_dgmdate($_arg_0)
{
	$_var_1 = intval(strtotime($_arg_0));
	if ($_var_1) {
		$_arg_0 = date("Y-m-d", $_var_1);
	}
	return $_arg_0;
}
function wq_app_setting_get_aid($_arg_0)
{
	$_var_1 = array();
	foreach ($_arg_0 as $_var_2 => $_var_3) {
		$_var_1[] = $_var_3["aid"];
	}
	return $_var_1;
}
function wq_app_settingget_content_by_aids($_arg_0)
{
	$_var_1 = DB::fetch_all("SELECT * FROM %t WHERE aid IN(%n)", array("portal_article_content", $_arg_0), "aid");
	foreach ($_arg_0 as $_var_2) {
		$_var_3[$_var_2] = $_var_1[$_var_2];
	}
	$_var_4 = array();
	require_once libfile("function/forum");
	foreach ($_var_3 as $_var_2 => $_var_5) {
		$_var_4[$_var_2]["content"] = $_var_5["content"];
		if ($_var_5["idtype"] == "tid" || $_var_5["idtype"] == "pid") {
			$_var_6 = get_thread_by_tid($_var_5["id"]);
			if (!empty($_var_6)) {
				if ($_var_5["idtype"] == "pid") {
					$_var_7 = C::t("forum_post")->fetch($_var_6["posttableid"], $_var_5["id"]);
				} else {
					$_var_7 = C::t("forum_post")->fetch_threadpost_by_tid_invisible($_var_5["id"]);
				}
			}
			$_var_8["tid"] = $_var_5["id"];
			$_arg_0 = array();
			$_var_7["message"] = $_var_5["content"];
			if ($_var_6["attachment"]) {
				$_var_8["group"]["allowgetimage"] = 1;
				if (preg_match_all("/\\[attach\\](\\d+)\\[\\/attach\\]/i", $_var_7["message"], $_var_9)) {
					$_arg_0 = $_var_9[1];
				}
			}
			if ($_arg_0) {
				wq_app_setting_parseforumattach($_var_7, $_arg_0);
			}
			$_var_4[$_var_2]["content"] = $_var_7["message"];
		}
	}
	return $_var_4;
}
function wq_app_setting_get_imgurl_and_num($_arg_0, $_arg_1 = false)
{
	$_var_2 = array();
	$_var_3 = wq_app_setting_get_aid($_arg_0);
	if (!empty($_var_3)) {
		if (!$_arg_1) {
			foreach ($_var_3 as $_var_4) {
				$_var_5 = wq_app_readfromcache("list_aid" . $_var_4, "wq_");
				if (!empty($_var_5)) {
					$_var_2[$_var_4] = $_var_5;
				}
			}
		}
		if (empty($_var_2) || count($_var_2) != count($_var_3)) {
			if (is_array($_var_2) && !empty($_var_2)) {
				$_var_3 = array_diff($_var_3, array_keys($_var_2));
			}
			if (empty($_var_2)) {
				$_var_2 = array();
			}
			$_var_6 = wq_app_settingget_content_by_aids($_var_3);
			foreach ($_var_6 as $_var_4 => $_var_7) {
				preg_match_all("/<img.*?src=\"(.*?)\".*?>/is", $_var_7["content"], $_var_8, PREG_SET_ORDER);
				foreach ($_var_8 as $_var_9 => $_var_10) {
					if (!empty($_var_10[1]) && dstrpos($_var_10[1], "static/image/smiley") === false) {
						$_var_2[$_var_4]["image"][] = $_var_10[1];
					}
				}
				$_var_2[$_var_4]["num"] = count($_var_2[$_var_4]["image"]);
			}
			foreach ($_var_2 as $_var_9 => $_var_11) {
				wq_app_writetocache("list_aid" . $_var_9, $_var_11);
			}
		}
	}
	return $_var_2;
}
function wq_app_setting_set_search_and_label_bgcolor()
{
	global $_G;
	$_var_1 = array("#feeed5", "#d9f6f6", "#fee3e6", "#f6f4c9", "#e8e6ff", "#d0e8fb", "#b7ebff");
	$_var_2 = array_rand($_var_1, 1);
	$_var_3 = $_var_1[$_var_2];
	return $_var_3;
}
function wq_app_setting_get_footer_url()
{
	global $_G;
	$_var_1 = !(strrpos($_G["siteurl"], "https://") === 0) ? "http://" : "https://";
	$_var_2 = $_var_1 . $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"];
	$_var_2 = rtrim(str_replace(array("&mobile=2", "?mobile=2"), '', $_var_2), "/");
	$_var_3 = $_var_1 . $_SERVER["HTTP_HOST"] . $_SERVER["PHP_SELF"] . "?" . $_SERVER["QUERY_STRING"];
	$_var_3 = trim(str_replace(array("&mobile=2", "?mobile=2"), '', $_var_3));
	$_var_4 = $_G["siteurl"] . "forum.php?mod=guide&view=" . $_GET["view"];
	if (in_array($_var_3, array($_var_4, $_var_4 . "&ac=myfav")) && $_G["setting"]["mobile"]["mobilehotthread"]) {
		$_var_5[] = $_G["siteurl"] . "forum.php";
	}
	$_var_5[] = $_var_2;
	$_var_5[] = $_var_3;
	$_var_5 = array_unique($_var_5);
	return $_var_5;
}
function wq_app_get_new_verify($_arg_0, $_arg_1 = false, $_arg_2 = 0)
{
	global $_G;
	$_var_4 = is_array($_arg_0) ? $_arg_0 : array($_arg_0);
	$_var_5 = C::t("common_member_verify")->fetch_all($_var_4);
	if (!$_arg_1) {
		foreach ($_var_5 as $_arg_0 => $_var_6) {
			foreach ($_G["setting"]["verify"] as $_var_7 => $_var_8) {
				if ($_var_8["available"] && $_var_8["showicon"]) {
					if ($_var_6["verify" . $_var_7] == 1) {
						$_var_5["verifyicon"][] = $_var_7;
					}
				}
			}
		}
		if (count($_var_5["verifyicon"]) > $_arg_2) {
			$_var_5["verifyicon"] = array_slice($_var_5["verifyicon"], 0, $_arg_2);
		}
	}
	return $_var_5;
}
	if (!defined("IN_DISCUZ")) {
		echo "Access Denied";
		return 0;
	}
	$_var_0 = "success"; /*dis'.'m.tao'.'bao.com*/
	if ($_var_0 != "success") {
		echo "Access Denied Weiqing";
		return 0;
	}