<?php

/**
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: function_admincp.php 2015-12-28 21:11:17Z $
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

function wq_app_setting_icon_select($setname, $id, $name, $value = "") {
	global $_G;

	$icon = "";
	if(!empty($value)) {
		$icon = '<i style="font-size:20px;" class="' . $value . '"></i>';
	}
	$html = "<input style=\"width:160px\" type = \"text\" id=\"{$id}_v\" class=\"left txt\"  name=\"{$name}\"  value=\"$value\" onchange=\"updatecolorpreview('{$id}')\"><span  class=\"left\" style=\"width:40px;\" id = \"{$id}_i\">{$icon}</span><input type=\"button\" value=\"&#x56FE;&#x6807;\"  id=\"{$id}\"  class=\"colorwd\" onclick=\"{$id}_frame.location='plugin.php?id=wq_app_setting&mod=icon&ac={$id}|{$id}_v';showMenu({'ctrlid':'{$id}'})\" /><span id=\"{$id}_menu\" style=\"display: none\"><iframe name=\"{$id}_frame\" src=\"\" frameborder=\"0\" width=\"458\" height=\"260\" style=\" border: 1px solid #dedede;\" ></iframe></span>";

	showtablerow('', array('colspan="2" class="td27" s="1"'), array($setname . ":"));
	showtablerow('class="noborder"', array('colspan="2" class="vtop rowform"'), array($html));
}

function wq_app_setting_set_select_menu($list, $title, $name, $value = "", $type = "select") {
	global $Plang;
	$varname[0] = $name;
	if($type == "select") {
		$varname[1][] = array('0', "&#x4E0D;&#x542F;&#x7528;");
	}
	foreach($list as $key => $val) {
		$varname[1][] = array($val['id'], $val['menuname']);
	}

	echo showsetting($title, $varname, $value, $type);
}
//From: Dism_taobao-com
?>