<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if($_GET['formhash'] == FORMHASH) {
	if($_G['uid']) {
		if($_GET['ac'] == 'uploading') {
			echo wq_app_setting_uploadAvatar($_G['uid'], $_GET['image']);
		} elseif($_GET['ac'] == 'head') {
			echo avatar($_G['uid'], middle, true) . "&t=" . rand(0, 9999999);
		} elseif($_GET['ac'] == 'city') {
			$city = wq_city();
			echo json_encode($city);
		}
	}
}

if($_GET['ac'] == 'favorite' || $_GET['ac'] == 'recommendadd') {
	$wqtype = dhtmlspecialchars($_GET['ac']);
	wq_app_cache_recommend_or_favorite_info($wqtype);
} elseif($_GET['ac'] == 'get_reply' && formhash() == $_GET['formhash']) {
	include_once DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_wq_app.php';
	$tid = $_GET['tid'] ? intval($_GET['tid']) : 0;
	$fid = $_GET['fid'] ? intval($_GET['fid']) : 0;
	$pid = $_GET['pid'] ? intval($_GET['pid']) : 0;
	$html = "";
	if($pid && $fid && $tid) {
		$html .= wq_app_get_wechat_reply_success_msg($tid, $pid, $fid);
	}
	echo $html;
} elseif($_GET['ac'] == 'wqhistory_delete' && formhash() == $_GET['formhash']) {
	dsetcookie("search_" . $_G['uid'], '');
	showmessage($Plang['a85fef487c71a24b']);
} elseif($_GET['ac'] == 'tags') {

	$subject = $_GET['subjectenc'];
	$message = $_GET['messageenc'];
	if(CHARSET == 'gbk') {
		$subject = diconv($subject, 'utf-8');
		$message = diconv($message, 'utf-8');
	}

	if(empty($subject) || empty($message)) {
		echo '';
		exit;
	}
	$data = $subject . $subject . $subject . $message;
	require_once DISCUZ_ROOT . './source/plugin/wq_app_setting/thirdparty/phpanalysis/phpanalysis.class.php';

	PhpAnalysis::$loadInit = false;
	$pa = new PhpAnalysis(CHARSET, CHARSET, true);

	$pa->LoadDict();
	$pa->SetSource($data, CHARSET, CHARSET);
	$pa->StartAnalysis(true);
	$tags = $pa->GetFinallyKeywords(5);
	echo $tags;
	exit;
} elseif($_GET['ac'] == 'promotionqrcodetid') {

	$tid = intval($_GET['tid']);
	$uid = $_GET['uid'] ? intval($_GET['uid']) : $_G['uid'];
	$loginurl = $_G['siteurl'] . 'forum.php?mod=viewthread&tid=' . $tid . '&fromuid=' . $uid;
	require_once DISCUZ_ROOT . 'source/plugin/wq_app_setting/class/qrcode.class.php';
	$size = $_GET['size'] ? intval($_GET['size']) : '5';
	if($setting['qrcode_type'] == 1) {
		ob_clean();
	}
	echo(QRcode::png($loginurl, false, QR_ECLEVEL_Q, 4));
	exit("");
}
//From: Dism_taobao-com
?>