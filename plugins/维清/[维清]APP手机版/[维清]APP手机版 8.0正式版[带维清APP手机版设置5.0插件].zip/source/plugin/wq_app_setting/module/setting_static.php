<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


$path = DISCUZ_ROOT . 'template/wq_app/static/js/';

header("Content-type: application/json");

$files = explode(',', $_GET['file']);
$version = $_GET['version'];
$cachename = 'static_' . md5($_GET['file']) . $version;

if(!$files) {
	$array = array('code' => 1);
	echo json_encode($array);
	exit;
}
$contents = array();
foreach($files as $file) {
	if(strpos($file, '..') !== false) {
		continue;
	}
	$filename = $path . $file;
	$contents[$file] = diconv(file_get_contents($filename), "GBK", "UTF-8");
}
$array = array('code' => 0, 'file' => $contents);
$result = json_encode($array);
echo $result;
exit;

?>