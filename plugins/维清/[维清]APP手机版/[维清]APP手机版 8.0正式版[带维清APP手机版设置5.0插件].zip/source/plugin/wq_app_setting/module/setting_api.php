<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: setting_api.inc.php 2016-10-17 18:20:02Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$allowfun = array('district', 'userinfo_district', 'realtime_news', 'images_attachment', 'attachlist');
$fun = !in_array($_GET['fun'], $allowfun) ? 'district' : $_GET['fun'];

if($fun == 'district') {

	$level = intval($_GET['level']) > 1 ? intval($_GET['level']) : 1;
	$upid = intval($_GET['upid']) > 0 ? intval($_GET['upid']) : 0;

	$district = wq_get_city_level_upid($level, $upid);
	echo json_encode(array("errcode" => '0', 'data' => $district));
	exit();
} elseif($fun == 'userinfo_district') {

	if($_GET['type'] == 'birth') {

		$resutl = DB::fetch_first("SELECT birthprovince,birthcity FROM %t WHERE uid = '%d'", array('common_member_profile', $_G['uid']));
		foreach($resutl as $key => $value) {
			$names[] = $value;
		}

		$district = C::t('#wq_app_setting#common_district')->fetch_all_by_names($names);
		foreach($district as $key => $value) {
			$return["idforlevel" . $value['level']] = $value['id'];
		}
	} elseif($_GET['type'] == 'reside') {
		$resutl = DB::fetch_first("SELECT resideprovince,residecity FROM %t WHERE uid = '%d'", array('common_member_profile', $_G['uid']));
		foreach($resutl as $key => $value) {
			$names[] = $value;
		}

		$district = C::t('#wq_app_setting#common_district')->fetch_all_by_names($names);
		foreach($district as $key => $value) {
			$return["idforlevel" . $value['level']] = $value['id'];
		}
	}

	echo json_encode(array("errcode" => '0', 'data' => $return));
	exit();
} elseif($fun == 'realtime_news') {
	loaducenter();

	$uid = !empty($_GET['uid']) ? intval($_GET['uid']) : "";
	$plid = !empty($_GET['plid']) ? intval($_GET['plid']) : "";
	if($plid == '') {
		$touid = !empty($_GET['touid']) ? intval($_GET['touid']) : "";

		if($uid < $touid) {
			$min_max = $uid . '_' . $touid;
		} elseif($uid > $touid) {
			$min_max = $touid . '_' . $uid;
		} else {
			$min_max = '';
		}
		$plid = DB::result_first("SELECT plid FROM " . UC_DBTABLEPRE . "pm_lists WHERE min_max=%s", array($min_max));
	}
	$id = substr((string) $plid, -1, 1);
	$time = $_GET['time'] ? dhtmlspecialchars(trim($_GET['time'])) : "";

	$re = DB::fetch_first("SELECT * FROM " . UC_DBTABLEPRE . "pm_members WHERE plid=%d AND uid=%d", array($plid, $uid));

	if($re['isnew'] > 0) {
		$res = DB::fetch_all("SELECT * FROM " . UC_DBTABLEPRE . "pm_messages_" . $id . " WHERE plid=%d AND authorid<>%d AND dateline>%s ORDER BY dateline ASC", array($plid, $uid, $time));

		foreach($res as $key => $val) {
			$val['message'] = diconv($val['message'], CHARSET, 'utf-8');
			$val['touidurl'] = avatar($val['authorid'], small, true);
			$results[] = $val;
		}
		DB::query("UPDATE " . UC_DBTABLEPRE . "pm_members SET isnew=0 WHERE plid=" . $plid);
		echo json_encode(array("errcode" => '1', 'data' => $results));
		exit();
	}
	echo json_encode(array("errcode" => '-1', 'data' => $re));
	exit();
} elseif($fun == 'images_attachment') {
	$tid = !empty($_GET['tid']) ? intval($_GET['tid']) : '';
	$pid = !empty($_GET['pid']) ? intval($_GET['pid']) : '';

	if($tid && $pid) {
		$tableid = DB::result_first("SELECT tableid FROM %t WHERE tid=%d AND pid=%d", array('forum_attachment', $tid, $pid));
		if($tableid >= 0 && $tableid < 10) {
			$tablename = 'forum_attachment_' . intval($tableid);
		} else {
			return '-1';
			echo json_encode(array("errcode" => '-1', 'msg' => $Plang['f3011b2a813a64de']));
			exit();
		}

		$results = DB::fetch_all("SELECT aid,attachment,isimage,remote,thumb FROM %t WHERE tid=%d AND pid=%d", array($tablename, $tid, $pid));

		if(!$results && empty($results)) {
			return '-2';
			echo json_encode(array("errcode" => '-2', 'msg' => $Plang['7b6cfd23ddbd63b3']));
			exit();
		}

		foreach($results as $re) {
			$re['attachment'] = wq_app_setting_get_picurl($re['attachment'], $re['remote'], $re['thumb']);
			if($re['isimage'] == 1) {
				$res[$re['aid']] = $re['attachment'];
			} else {
				$attach[$re['aid']] = $re['attachment'];
			}
		}

		echo json_encode(array("errcode" => '1', 'msg' => $res, 'attach' => $attach));
		exit();
	}
} elseif($fun == 'attachlist') {
	$aid = !empty($_GET['aid']) ? intval($_GET['aid']) : '';

	$html = '';
	if(!$aid) {
		echo json_encode(array("errcode" => '-1', 'msg' => $html));
		exit();
	}
	$attach = C::t('forum_attachment_n')->fetch('aid:' . $aid, $aid);
	$isimage = in_array($attach['isimage'], array(1, -1)) ? 1 : 0;
	$imgurl = wq_app_setting_get_picurl($attach['attachment'], $attach['remote'], $attach['thumb']);

	if($_GET['ac'] == "image") {
		$html = '<li><span aid="' . $aid . '" class="del wqdelete" wqtype="img"><a href="javascript:;"><i class="wqiconfont2 wqicon2-jianhao f22"></i></a></span><span class="wqimg"><a href="javascript:;"><img id="aimg_' . $aid . '" title="' . $attach['filename'] . '" src="' . $imgurl . '" /></a></span><input type="hidden" name="attachnew[' . $aid . '][description]" /></li>';
	} else {

		$attach['ext'] = fileext($attach['filename']);
		if(!function_exists('attachtype')) {
			require_once libfile('function/attachment');
		}
		$attach['filetype'] = attachtype($attach['ext'] . "\t");
		if(empty($attach['filetype'])) {
			$attach['filetype'] = '<img src="static/image/filetype/image.gif" border="0" class="vm" alt="">';
		}

		$html = '<li>' . $attach['filetype'] . '<span class="wqtext">' . $attach['filename'] . '</span><span class="y"><a href="javascript:;" class="wq_insert wqbg_color" data-aid="' . $aid . '" data-isimage="' . $isimage . '" data-url="' . $imgurl . '">&#x63D2;&#x5165;</a><a href="javascript:;" class="wq_delete del" aid="' . $aid . '" wqtype="attach"><i class="wqiconfont2 wqicon2-gbdelete"></i></a></span><input type="hidden" name="attachnew[' . $aid . '][description]"></li>';
	}

	echo json_encode(array("errcode" => '1', 'msg' => diconv($html, CHARSET, 'utf-8')));
	exit();
}
//From: Dism_taobao-com
?>