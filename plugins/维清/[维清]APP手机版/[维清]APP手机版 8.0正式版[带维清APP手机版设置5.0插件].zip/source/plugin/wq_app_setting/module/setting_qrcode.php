<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$qrcode_url = wq_app_qrcode_generate($_G['siteurl'] . 'home.php?mod=space&do=profile&uid=' . $_G['uid'], 'ueserqrcode', $_G['uid']);
include template('wq_app_setting:tpl_setting_qrcode');

?>