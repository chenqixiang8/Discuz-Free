<?php

/**
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: index.php 2016-7-23 10:35:46Z $
 */
chdir("../../../../");

$script = isset($_GET['script']) ? trim($_GET['script']) : 'forum';

$allowscript = array('forum', 'portal', 'home');

if(!in_array($script, $allowscript)) {
	exit('Access Denied');
}

define("IN_API", TRUE);
require './' . $script . '.php';

ob_end_clean();
$_G['gzipcompress'] ? ob_start('ob_gzhandler') : ob_start();

if(!$_G['mobile']) {
	exit('Access Denied');
}

require './template/wq_app/php/config.php';

if(CURSCRIPT == 'forum' && CURMODULE == 'guide') {
	unset($data);
	$showmodel = get_guide_showmodel();
	$list = get_guide_data_by_type();
	include template('forum/guide_list_row_' . $showmodel);
}

if(CURSCRIPT == 'forum' && CURMODULE == 'forumdisplay') {

	$showmodel = get_forum_showmodel();

	if(empty($_G['forum']['picstyle']) || $_G['cookie']['forumdefstyle']) {
		include template('forum/forumdisplay_' . $showmodel);
	} else {
		include template('forum/forumdisplay_p');
	}
}

if(CURSCRIPT == 'home' && CURMODULE == 'follow') {
	include template('home/follow_feed_li');
}

if(CURSCRIPT == 'home' && CURMODULE == 'space' && $do == "blog") {
	include template('home/space_blog_list_1');
}

$havedomain = implode('', $_G['setting']['domain']['app']);
wq_app_get_domain();

if($_G['setting']['rewritestatus'] || !empty($havedomain)) {
	$content = ob_get_contents();
	$content = output_replace($content);
	ob_end_clean();
	$_G['gzipcompress'] ? ob_start('ob_gzhandler') : ob_start();
	echo $content;
}
//From: Dism_taobao-com
?>