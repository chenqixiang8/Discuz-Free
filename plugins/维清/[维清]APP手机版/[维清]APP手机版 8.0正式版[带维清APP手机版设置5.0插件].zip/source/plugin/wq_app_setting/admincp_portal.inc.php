<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: admincp_portal.inc.php 2015-3-24 06:25:34Z $
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

include './source/plugin/wq_app_setting/config/config.php';
if(!submitcheck('form')) {
	loadcache(array('portalcategory', 'wq_app_setting_set'));

	function wq_getcategory($upid) {
		global $_G;
		foreach($_G['cache']['portalcategory'] as $category) {
			if($category['upid'] == $upid && !$category['closed']) {
				$_G['wq_categoryvalue'][] = array($category['catid'], str_repeat('&nbsp;', $category['level'] * 4) . $category['catname']);
				wq_getcategory($category['catid']);
			}
		}
	}

	showformheader('plugins&operation=config&do=' . $pluginid . '&identifier=wq_app_setting&pmod=admincp_portal', '', 'form');
	showtableheader($Plang['8d7b2ab59f15f5d1s'], 'nobottom');

	$varname = array('category[]');
	wq_getcategory(0);
	$varname[1] = $_G['wq_categoryvalue'];
	showsetting($Plang['category_set'], $varname, $_G['cache']['wq_app_setting_set'], 'mselect', '', 0, $Plang['gotosetclass'] . '<a href="' . ADMINSCRIPT . '?action=portalcategory">' . $Plang['1f3b44f2d47843ed'] . '</a>');
	showsubmit('form', 'submit');
	showtablefooter();/*Dism��taobao��com*/
	showformfooter();
} else {

	savecache('wq_app_setting_set', $_GET['category']);
	cpmsg($Plang['setsucceed'], 'action=plugins&operation=config&do=' . $pluginid . '&identifier=wq_app_setting&pmod=admincp_portal', 'succeed');
}
//From: Dism_taobao-com
?>