<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: admincp_menumanage.inc.php 2015-3-24 06:25:34Z $
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

include DISCUZ_ROOT . './source/plugin/wq_app_setting/config/config.php';
include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_admincp_ext.php';

$ac = in_array($_GET['ac'], array('set', 'add', 'edit', 'manage', 'del', 'sideset', 'sidemanage', 'allmanage', 'meset', 'memanage')) ? dhtmlspecialchars($_GET['ac']) : 'allmanage';
$wq_a = array($ac => ' class="wq_a"');

if($setting['icon_url']) {
	echo '<link rel="stylesheet" id="css_extstyle" type="text/css" href="http:' . $setting['icon_url'] . '?{VERHASH}" />';
}
echo <<<EOF
   <link rel="stylesheet" id="css_extstyle" type="text/css" href="template/wq_app/static/font/iconfont.css?{VERHASH}" />
   <link rel="stylesheet" id="css_extstyle" type="text/css" href="http:{$setting['icon_url']}?{VERHASH}" />
EOF;

if($ac == 'del') {
	$menuid = intval($_GET['id']);
	$menu = C::t("#wq_app_setting#wq_app_setting_menumanage")->fetch_by_id($menuid);
	if($menu['type'] == '1') {
		cpmsg($Plang['fb2f65ff76c031c1'], '', 'error');
	}
	C::t("#wq_app_setting#wq_app_setting_menumanage")->delete($menuid);
	if($menu['menutype'] == 1) {
		$data = array();
		$foot_menu = unserialize($_G['setting']['wq_app_setting_footer_menu']);
		foreach($foot_menu['foot'] as $key => $val) {
			$data['foot'][$key] = $val;
			if($menuid == $val) {
				$data['foot'][$key] = 0;
			}
		}
		$data['num'] = count(array_filter($data['foot']));
		C::t('common_setting')->update('wq_app_setting_footer_menu', $data);
		updatecache('setting');
	}

	if($menu['menutype'] == 2) {
		$data = array();
		$side_menu = unserialize($_G['setting']['wq_app_setting_side_menu']);
		foreach($side_menu as $key => $val) {
			if($menuid != $val) {
				$data[] = $val;
			}
		}
		C::t('common_setting')->update('wq_app_setting_side_menu', $data);
		updatecache('setting');
	}

	wq_app_setting_cache_menulist();
	cpmsg($Plang['8987fdbb54a9953a'], "action=plugins&operation=config&do=" . $pluginid . "&identifier=wq_app_setting&pmod=admincp_menumanage&ac=allmanage", "succeed");
}

$tips = "";
if($ac == 'add') {
	$tips = '<li style="text-align:left"><span style="color:red;">' . $Plang['adf3152647af8fc0'] . '</span></li>'
		. '<li style="text-align:left">' . $Plang['e41b41fed4305595'] . '</li>'
		. '<li style="text-align:left">' . $Plang['39e11c7e399ccaa6'] . '</li>';
}
if($ac == 'set') {
	$tips = '<li style="text-align:left">' . $Plang['69451a54941a9ee7'] . '</li>';
}
if(in_array($ac, array('manage', 'sidemanage', 'allmanage'))) {
	$tips = '<li style="text-align:left">' . $Plang['700d428d42588bc4'] . '</li>';
}



if(!submitcheck('form')) {
	$url = 'plugins&operation=config&do=' . $pluginid . '&identifier=wq_app_setting&pmod=admincp_menumanage';
	$formurl = $url . '&ac=' . $ac;
	$hrefurl = ADMINSCRIPT . '?action=' . $url;

	$type = array(
		'allmanage' => $Plang['06e69ff4b866c43a'],
		'manage' => $Plang['bc0b3dd140ddf1a6'],
		'set' => $Plang['4a3e60096e73bec2'],
		'sidemanage' => $Plang['222ff06d945e203f'],
		'sideset' => $Plang['d462986ff4fdff25'],
		'memanage' => $Plang['bc892216aafd4c02'],
		'meset' => $Plang['8e4e1bec56bb3f49'],
		'add' => $Plang['98efab7b9ce7393f'],
		'edit' => $Plang['dbbaba1357999615'],
	);
	$title = $Plang['39b79c1288a82305'] . $type[$ac];
	$li = '';
	foreach($type as $key => $val) {
		if($key == 'edit') {
			continue;
		}
		$li .= '<li' . $wq_a[$key] . '><a href="' . $hrefurl . '&ac=' . $key . '">' . $val . '</a></li>';
	}

	echo <<<EOF
    <style>
        .wq_mn {display: inline; margin-right: 10px; padding-top: 10px; overflow: hidden;}
        .wq_tb{line-height: 30px; border-bottom: 1px solid #CDCDCD;  margin-top: 5px; height: 31px; }
        .wq_bm{margin-bottom: 10px; }
        .wq_.bw0{background: transparent; border: none !important;}
        .wq_tb li{float: left; margin: 0 3px 0 0; list-style: none; display: list-item; text-align: -webkit-match-parent;}
        .wq_tb a{display: block; padding: 0 10px; border: 1px solid #CDCDCD; color: #333; text-decoration: none; background: #E5EDF2;}
        .wq_tb .wq_a a{border-bottom-color: #FFF; background: #FFF; font-weight: 700;}
    </style>
    <div class="wq_mn">
        <div class="wq_bm wq_bw0">
            <ul class="wq_tb wq_cl">
                    {$li}
                    <li><a href="http://www.wikin.cn/plugin.php?id=wq_help&cid=30&pid=179#pid179" target="_blank">{$Plang['548681ee6ef6f3e9']}</a></li>
            </ul>
        </div>
    </div>
EOF;
	if(!empty($tips)) {
		showtips($tips, 'tips', TRUE, $Plang['c6fa3e37f1c095c2']);
	}
	if($ac == 'set') {
		$menusum = unserialize($_G['setting']['wq_app_setting_footer_menu']);
		$menuone = $menusum['foot']['menuone'] ? $menusum['foot']['menuone'] : '';
		$menutwo = $menusum['foot']['menutwo'] ? $menusum['foot']['menutwo'] : '';
		$menuthree = $menusum['foot']['menuthree'] ? $menusum['foot']['menuthree'] : '';
		$menufour = $menusum['foot']['menufour'] ? $menusum['foot']['menufour'] : '';
		$menufive = $menusum['foot']['menufive'] ? $menusum['foot']['menufive'] : '';

		$list = wq_app_setting_set_menulist(1);
		showformheader($formurl, '', 'form');
		showtableheader("", 'nobottom');
		showtitle($title);
		wq_app_setting_set_select_menu($list, $Plang['838cf201117c0547'], "menuone", $menuone);
		wq_app_setting_set_select_menu($list, $Plang['181ca58440893fb8'], "menutwo", $menutwo);
		wq_app_setting_set_select_menu($list, $Plang['f4c3e4c87feeb70e'], "menuthree", $menuthree);
		wq_app_setting_set_select_menu($list, $Plang['ba8aa9da6cd4c8c6'], "menufour", $menufour);
		wq_app_setting_set_select_menu($list, $Plang['ed1b4eb15418b758'], "menufive", $menufive);
		showsubmit('form', 'submit');
		showtablefooter();/*Dism��taobao��com*/
		showformfooter();
	}
	if($ac == 'sideset') {
		$menusum = unserialize($_G['setting']['wq_app_setting_side_menu']);
		$sidelists = $menusum ? $menusum : "";

		$list = wq_app_setting_set_menulist(2);
		showformheader($formurl, '', 'form');
		showtableheader("", 'nobottom');
		showtitle($title);
		wq_app_setting_set_select_menu($list, $Plang['ccb9bc22723002c5'], "sidelist[]", $sidelists, 'mselect');
		showsubmit('form', 'submit');
		showtablefooter();/*Dism��taobao��com*/
		showformfooter();
	}
	if($ac == 'meset') {
		$menusum = unserialize($_G['setting']['wq_app_setting_me_menu']);
		$melists = $menusum ? $menusum : "";

		$list = wq_app_setting_set_menulist(3);
		showformheader($formurl, '', 'form');
		showtableheader("", 'nobottom');
		showtitle($title);
		wq_app_setting_set_select_menu($list, $Plang['422a6ed55ed6bbe2'], "melist[]", $melists, 'mselect');
		showsubmit('form', 'submit');
		showtablefooter();/*Dism��taobao��com*/
		showformfooter();
	}

	if(in_array($ac, array('manage', 'sidemanage', 'allmanage', 'memanage'))) {
		$manage_arr = array(
			'allmanage' => 0,
			'manage' => 1,
			'sidemanage' => 2,
			'memanage' => 3
		);
		$page = max(1, $_GET['page']);
		$perpage = $setting['admin_page'] ? $setting['admin_page'] : 2;
		$start = ($page - 1 ) * $perpage;
		$menutype = $manage_arr[$ac] ? $manage_arr[$ac] : 0;
		$menutypes = array('1' => $Plang['bc0b3dd140ddf1a6'], '2' => $Plang['222ff06d945e203f'], '3' => $Plang['bc892216aafd4c02']);
		$list = wq_app_setting_set_menulist($menutype);
		$count = C::t("#wq_app_setting#wq_app_setting_menumanage")->count_by_search();

		echo <<<EOF
    <style>
        .hover td{text-align:center;}
    </style>
EOF;

		$comprehensive = $Plang['12075b143472200a'];
		if($ac == 'manage') {
			$comprehensive = $Plang['defdf7831f3bc0fb'];
		} elseif(in_array($ac, array('sidemanage', 'memanage'))) {
			$comprehensive = $Plang['a44acd00edee8947'];
		}

		showformheader($formurl, '', 'form');
		showtableheader("", 'nobottom');
		showtitle($title);
		showsubtitle(array($Plang['1670da9c2989259f'], $Plang['f91a74e38d74eb1b'], $Plang['e1ee509fa2405cbe'], $Plang['f76981187933142c'], $Plang['cfea7e68784df67e'], $comprehensive, $Plang['b89503ed35ca1537'], $Plang['4e64f0e320d8b16b']));
		foreach($list as $key => $val) {
			$menuicon_list = $val ['menutype'] == 1 ? '<i class="' . $val ['menuicon'] . '"></i>' : ($val ['menuicon'] ? '<input type="button" style=" width:35px;background: ' . $val ['menuicon'] . '">' : '');

			showtablerow('', array("width=60px", "width=100px", "width=350px", 'width=100px', "width=100px", "width=100px", 'width=100px', 'width=100px', ''), array(
				'<input style="width:50px;" type="number" name="displayorder[' . $val ['id'] . ']" value="' . $val ['displayorder'] . '"/>' .
				'<input style="width:50px;" type="hidden" name="id[' . $val ['id'] . ']" value="' . $val ['id'] . '"/>',
				$val ['menuname'],
				$val ['menuurl'],
				$menutypes[$val ['menutype']],
				'<i class="' . $val ['notmenuicon'] . '"></i>',
				$menuicon_list,
				$val ['type'] == 1 ? $Plang['e6de3489f4cb71ab'] : $Plang['a8785c3dbc5f1798'],
				'<a href="' . $hrefurl . '&ac=edit&id=' . $val ['id'] . '">[' . $Plang['9a150d4af72d7358'] . ']</a>'
				. ($val ['type'] != 1 ? '<a onclick="app_del_confirm()" href="' . $hrefurl . '&ac=del&id=' . $val ['id'] . '">[' . $Plang['0d9efacf5089d88c'] . ']</a>' : ''),
				'',
				)
			);
		}
		echo '<tr><td colspan = "1"></td><td colspan = "4"><div><a href = "' . $hrefurl . '&ac=add" class = "addtr">' . $Plang['98efab7b9ce7393f'] . '</a></div></td></tr>';
		showsubmit('form', 'submit');
		showtablefooter();/*Dism��taobao��com*/
		showformfooter();
		echo <<<EOF
    <script type='text/JavaScript'>
        function app_del_confirm() {
            if (!confirm("{$Plang['f0bd9df48c222a04']}")) {
                window.event.returnValue = false;
            }
        }
    </script>
EOF;
	}
	if($ac == 'edit' || $ac == 'add') {
		echo <<<EOF
    <style>
        .noborder .rowform .nofloat li{ width:8% !important;}
        .noborder .rowform .nofloat li i{  font-size: 22px !important;}
    </style>
EOF;

		$id = $_GET['id'] ? intval($_GET['id']) : 0;
		if($id) {
			$menu = C::t("#wq_app_setting#wq_app_setting_menumanage")->fetch_by_id($id);
		}

		$menuname = $_GET['menuname'] ? dhtmlspecialchars($_GET['menuname']) : ($menu['menuname'] ? $menu['menuname'] : "");
		$menuurl = $_GET['menuurl'] ? dhtmlspecialchars($_GET['menuurl']) : ($menu['menuurl'] ? $menu['menuurl'] : "");
		$menuicon = $_GET['menuicon'] ? dhtmlspecialchars($_GET['menuicon']) : ($menu['menuicon'] ? $menu['menuicon'] : "");
		$notmenuicon = $_GET['notmenuicon'] ? dhtmlspecialchars($_GET['notmenuicon']) : ($menu['notmenuicon'] ? $menu['notmenuicon'] : "");
		$type = $_GET['type'] ? intval($_GET['type']) : ($menu['type'] ? $menu['type'] : 0);
		$displayorder = $_GET['displayorder'] ? intval($_GET['displayorder']) : ($menu['displayorder'] ? $menu['displayorder'] : 0);
		$menutype = $_GET['menutype'] ? intval($_GET['menutype']) : ($menu['menutype'] ? $menu['menutype'] : 1);
		$menutype_status = $ac == "edit" ? 1 : 0;
		$menutypes = array(
			array('1', $Plang['bc0b3dd140ddf1a6'], array('icon' => '', 'color' => 'none')),
			array('2', $Plang['222ff06d945e203f'], array('color' => '', 'icon' => 'none')),
			array('3', $Plang['bc892216aafd4c02'], array('color' => '', 'icon' => 'none')),
		);

		showformheader($formurl, '', 'form');
		showtableheader("", 'nobottom');
		showtitle($title);
		showhiddenfields(array('id' => $id, 'type' => $type));
		if($ac == 'edit') {
			showhiddenfields(array('editmenutype' => $menutype,));
		}
		showsetting($Plang['f91a74e38d74eb1b'], 'menuname', $menuname, 'text');
		showsetting($Plang['e1ee509fa2405cbe'], 'menuurl', $menuurl, 'text', $type, '', $Plang['a3584c5822c84180']);
		showsetting($Plang['f76981187933142c'], array('menutype', $menutypes), $menutype, 'mradio', $menutype_status, '', $Plang['4ea31faf7bb5f2e9']);
		showsetting($Plang['1670da9c2989259f'], 'displayorder', $displayorder, 'number');
		wq_app_setting_icon_select($Plang['cfea7e68784df67e'], 'not_icon', 'notmenuicon', $notmenuicon);

		showtagheader('tbody', 'icon', $menutype == 1);
		wq_app_setting_icon_select($Plang['defdf7831f3bc0fb'], 'on_icon', 'menuicon', $menuicon);
		showtagfooter('tbody');

		showtagheader('tbody', 'color', in_array($menutype, array(2, 3)));
		showsetting($Plang['fd834a0ef5d26959'], 'menucolor', $menuicon, 'color', '', 0, $Plang['8da0683d532cbe8a']);
		showtagfooter('tbody');

		showsubmit('form', 'submit');
		showtablefooter();/*Dism��taobao��com*/
		showformfooter();
	}
} else {
	$mpurl = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=wq_app_setting&pmod=admincp_menumanage';

	if($ac == 'set') {
		$data['foot'] = array(
			'menuone' => intval($_GET['menuone']),
			'menutwo' => intval($_GET['menutwo']),
			'menuthree' => intval($_GET['menuthree']),
			'menufour' => intval($_GET['menufour']),
			'menufive' => intval($_GET['menufive']),
		);
		$data['num'] = count(array_filter($data['foot']));
		C::t('common_setting')->update('wq_app_setting_footer_menu', $data);
		updatecache('setting');
		cpmsg($Plang['9a52f4d6ef956904'], $mpurl . "&ac=set", 'succeed');
	} elseif($ac == 'sideset') {
		$data = $_GET['sidelist'] ? $_GET['sidelist'] : "";

		if(!$data) {
			cpmsg($Plang['9b32ef230e04145a'], $mpurl . "&ac=sideset", 'error');
		}

		C::t('common_setting')->update('wq_app_setting_side_menu', $data);
		updatecache('setting');
		cpmsg($Plang['9a52f4d6ef956904'], $mpurl . "&ac=sideset", 'succeed');
	} elseif($ac == 'meset') {
		$data = $_GET['melist'] ? $_GET['melist'] : "";

		if(!$data) {
			cpmsg($Plang['9b32ef230e04145a'], $mpurl . "&ac=meset", 'error');
		}

		C::t('common_setting')->update('wq_app_setting_me_menu', $data);
		updatecache('setting');
		cpmsg($Plang['9a52f4d6ef956904'], $mpurl . "&ac=meset", 'succeed');
	} elseif($ac == 'manage' || $ac == 'sidemanage' || $ac == 'allmanage') {
		loadcache(array('wq_app_menulist'));
		$menulist = $_G['cache']['wq_app_menulist'];

		$ids = $_GET['id'];
		foreach($ids as $key => $id) {
			if($_GET['displayorder'][$id] != $menulist[$id]['displayorder']) {
				$data = array('displayorder' => $_GET['displayorder'][$id]);
				C::t("#wq_app_setting#wq_app_setting_menumanage")->update($id, $data);
			}
		}
		wq_app_setting_cache_menulist();
		cpmsg($Plang['8ee460c51dbd9dee'], $mpurl . "&ac=" . $ac, 'succeed');
	} else {
		$menuid = intval($_GET['id']);
		$menuname = dhtmlspecialchars($_GET['menuname']);
		$menuurl = str_replace(array('&amp;'), array('&'), dhtmlspecialchars($_GET['menuurl']));
		$notmenuicon = dhtmlspecialchars($_GET['notmenuicon']);
		$menutype = $_GET['editmenutype'] ? intval($_GET['editmenutype']) : intval($_GET['menutype']);
		$menuicon = $menutype == 1 ? dhtmlspecialchars($_GET['menuicon']) : dhtmlspecialchars($_GET['menucolor']);
		$displayorder = $_GET['displayorder'] ? intval($_GET['displayorder']) : 0;
		$type = $_GET['type'] ? intval($_GET['type']) : 0;

		$url = $mpurl . "&ac=" . $ac;
		$url .= $menuname ? '&menuname=' . $menuname : '';
		$url .= $menuurl ? '&menuurl=' . $menuurl : '';
		$url .= $notmenuicon ? '&notmenuicon=' . $notmenuicon : '';
		$url .= $menuicon ? '&menuicon=' . $menuicon : '';
		$url .= $displayorder ? '&displayorder=' . $displayorder : '';
		$url .= $menutype ? '&menutype=' . $menutype : '';
		$url .= $type ? '&type=' . $type : '';
		$url .= $menuid ? '&id=' . $menuid : '';

		if(empty($menuname)) {
			cpmsg($Plang['ff7fe338ffe4d13a'], $url, 'error');
		}
		if(empty($menuurl) && !$type) {
			cpmsg($Plang['c07a99e3fb173f8d'], $url, 'error');
		}
		if(empty($notmenuicon)) {
			cpmsg($Plang['bb2332fec166f20e'], $url, 'error');
		}

		if($menutype == 1 && empty($menuicon)) {
			cpmsg($Plang['43c1bfb01105079c'], $url, 'error');
		}

		$data = array(
			'menuname' => $menuname,
			'notmenuicon' => $notmenuicon,
			'menuicon' => $menuicon,
			'type' => $type,
			'displayorder' => $displayorder,
			'dateline' => TIMESTAMP,
		);

		if(!$type) {
			$data['menuurl'] = $menuurl;
		}

		if($menuid) {
			$re = C::t("#wq_app_setting#wq_app_setting_menumanage")->update($menuid, $data);
		} else {
			$data['menutype'] = $menutype;
			$re = C::t("#wq_app_setting#wq_app_setting_menumanage")->insert($data);
		}

		$msg = $menuid ? array($Plang['8ee460c51dbd9dee'], $Plang['759d5664099b2589']) : array($Plang['22fc21e29216217a'], $Plang['c9a7ef7f47484dc4']);
		if($re) {
			wq_app_setting_cache_menulist();
			cpmsg($msg[0], $mpurl . "&ac=allmanage", 'succeed');
		}
		cpmsg($msg[1], $mpurl . "&ac=allmanage", 'error');
	}
}
//From: Dism_taobao-com
?>