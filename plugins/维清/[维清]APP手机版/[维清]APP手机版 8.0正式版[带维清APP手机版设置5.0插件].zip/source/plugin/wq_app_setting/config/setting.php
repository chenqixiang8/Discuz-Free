<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: setting.php 2016-7-27 14:33:32Z $
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
include DISCUZ_ROOT . './source/plugin/wq_app_setting/config/setting_base.php';
$setting['wechat_recommend_num'] = $setting['wechat_recommend_num'] > 20 ? 20 : $setting['wechat_recommend_num'];
$setting['wechat_recommend_num'] = $setting['wechat_recommend_num'] < 0 ? 10 : $setting['wechat_recommend_num'];
$setting['wechat_replies_num'] = $setting['wechat_replies_num'] > 20 ? 20 : $setting['wechat_replies_num'];
$setting['wechat_replies_num'] = $setting['wechat_replies_num'] < 0 ? 10 : $setting['wechat_replies_num'];
?>