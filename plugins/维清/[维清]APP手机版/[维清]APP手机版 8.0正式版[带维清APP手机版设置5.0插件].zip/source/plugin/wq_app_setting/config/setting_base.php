<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: setting_base Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

loadcache('plugin');
$setting = $_G['cache']['plugin']['wq_app_setting'];
$setting['logoname'] = trim($setting['logoname']);
$setting['desktop_name'] = trim($setting['desktop_name']);
$setting['home_navmenu'] = intval($setting['home_navmenu']);
$setting['portal_list_showmodel'] = intval($setting['portal_list_showmodel']);
$setting['portal_view_showmodel'] = intval($setting['portal_view_showmodel']);
$setting['portal_view_reply'] = intval($setting['portal_view_reply']);
$setting['discuz_style'] = intval($setting['discuz_style']);
$setting['hengpai_pc'] = intval($setting['hengpai_pc']);
$setting['view_line'] = intval($setting['view_line']);
$setting['tpost'] = intval($setting['tpost']);
$setting['is_discuz_myfav'] = intval($setting['is_discuz_myfav']);
$setting['forumlist_left_width'] = intval($setting['forumlist_left_width']);
$setting['post_style'] = intval($setting['post_style']);
$setting['use_original_image'] = intval($setting['use_original_image']);
$setting['memory_time'] = intval($setting['memory_time']);
$setting['is_drop_down_loading'] = intval($setting['is_drop_down_loading']);
$setting['isopen_modrecommend'] = intval($setting['isopen_modrecommend']);
$setting['viwe_top'] = intval($setting['viwe_top']);
$setting['top_num'] = intval($setting['top_num']);
$setting['message_length'] = intval($setting['message_length']);
$setting['img_left'] = intval($setting['img_left']);
$setting['view_imgnum'] = intval($setting['view_imgnum']);
$setting['wechat_recommend_num'] = intval($setting['wechat_recommend_num']);
$setting['wechat_replies_num'] = intval($setting['wechat_replies_num']);
$setting['view_screen_mode'] = intval($setting['view_screen_mode']);
$setting['post_but_singleshow'] = intval($setting['post_but_singleshow']);
$setting['view_screen_openstop'] = intval($setting['view_screen_openstop']);
$setting['view_style'] = intval($setting['view_style']);
$setting['view_view_style'] = intval($setting['view_view_style']);
$setting['view_reply_style'] = intval($setting['view_reply_style']);
$setting['is_reply_reload'] = intval($setting['is_reply_reload']);
$setting['view_click'] = intval($setting['view_click']);
$setting['view_open_promote'] = intval($setting['view_open_promote']);
$setting['view_use_original_image'] = intval($setting['view_use_original_image']);
$setting['forumindex_showmodel'] = trim($setting['forumindex_showmodel']);
$setting['guide_view'] = trim($setting['guide_view']);
$setting['guide_perpage'] = intval($setting['guide_perpage']);
$setting['recommend'] = unserialize($setting['recommend']);
$setting['thread_carousel'] = intval($setting['thread_carousel']);
$setting['weiqing_thread_block_id'] = intval($setting['weiqing_thread_block_id']);
$setting['maxwidth'] = intval($setting['maxwidth']);
$setting['maxheight'] = intval($setting['maxheight']);
$setting['login_seccheck'] = intval($setting['login_seccheck']);
$setting['register_seccheck'] = intval($setting['register_seccheck']);
$setting['password_seccheck'] = intval($setting['password_seccheck']);
$setting['open_advertisement'] = intval($setting['open_advertisement']);
$setting['advertisement_logo'] = trim($setting['advertisement_logo']);
$setting['advertisement_title'] = trim($setting['advertisement_title']);
$setting['advertisement_overview'] = trim($setting['advertisement_overview']);
$setting['advertisement_link'] = trim($setting['advertisement_link']);
$setting['advertisement_button'] = trim($setting['advertisement_button']);
$setting['advertisement_time'] = intval($setting['advertisement_time']);
$setting['icon_url'] = trim($setting['icon_url']);
$setting['is_close_showtips'] = intval($setting['is_close_showtips']);
$setting['qrcode_type'] = intval($setting['qrcode_type']);

?>