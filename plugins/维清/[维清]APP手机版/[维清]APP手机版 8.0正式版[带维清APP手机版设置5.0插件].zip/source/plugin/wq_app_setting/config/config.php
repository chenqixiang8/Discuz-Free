<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: config.php 2015-10-8 19:41:34Z $
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

loadcache('wq_usergroup');
include_once DISCUZ_ROOT . './source/plugin/wq_app_setting/config/loadfunc.php';
include_once DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_app_setting.php';
include_once DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_wq_app.php';
include_once DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_wq_app_other.php';

$wq_app_usergroup = $_G['cache']['wq_usergroup'] ? $_G['cache']['wq_usergroup'] : wq_usergroup();

$Plang = wq_loadlang('wq_app_setting');

$setting = wq_loadsetting('wq_app_setting');
?>