<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: admincp_liststyle.inc.php 2015-3-24 06:25:34Z $
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

include './source/plugin/wq_app_setting/config/config.php';

if(!submitcheck('form')) {
	$liststyles = array(
		'm' => $Plang['1daaeadb0fc91b71'],
		'0' => $Plang['e8e33f5d43ee1515'],
		'1' => $Plang['667b87b0288c36fc'],
		'3' => $Plang['83983f56383ac6de'],
		'4' => $Plang['784bba3b9ea51f19'],
		'5' => $Plang['4a34b6739c523a31'],
		'6' => $Plang['9ddad9b01e09a985'],
		'b' => $Plang['99bf14273e1b7dc5'],
		's' => $Plang['62e2dce85bd085a8'],
		'j' => $Plang['a82174bf9e5092b9'],
		'w' => $Plang['046ddc4435e9d428'],
	);
	$formurl = 'plugins&operation=config&do=' . $pluginid . '&identifier=wq_app_setting&pmod=admincp_liststyle';
	$forumstyles = $_G['setting']['wq_app_forumlist_style'] ? unserialize($_G['setting']['wq_app_forumlist_style']) : array();

	showformheader($formurl);
	showtableheader('', 'nobottom');
	showsubtitle(array('', $Plang['7f10a119f7d58793'], $Plang['62aa7186259cf774'], ""), 'header', array('', 'width="300px"', 'width="300px"', ''));
	wq_app_get_forumlist($forumstyles, $liststyles);
	showsubmit('form', 'submit');
	showtablefooter();/*Dism��taobao��com*/
	showformfooter();
	select_html($liststyles, 'forumstyle[]', $liststyle, false, false);
} else {
	$forumstyle = $_GET['forumstyle'];

	C::t('common_setting')->update('wq_app_forumlist_style', $forumstyle);
	updatecache('setting');
	cpmsg($Plang['9a52f4d6ef956904'], 'action=plugins&operation=config&do=' . $pluginid . '&identifier=wq_app_setting&pmod=admincp_liststyle', 'succeed');
}
//From: Dism_taobao-com
?>