<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: admincp_usergroup.inc.php 2015-3-24 06:25:34Z $
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

include './source/plugin/wq_app_setting/config/config.php';

$url = 'plugins&operation=config&do=' . $pluginid . '&identifier=wq_app_setting&pmod=admincp_usergroup';
$status = in_array($_GET['status'], array('0', '1', '2')) ? intval($_GET['status']) : 0;
$href = ADMINSCRIPT . '?action=' . $url;
$url .= '&status=' . $status;
$msg_url = 'action=' . $url;
if(!submitcheck('form')) {
	echo <<<EOT
<style>
 .hover div:hover,.status{background-color: #666666 !important;}
    .hover div{width:100px;height;text-align:center;line-height:18px;border-radius:4px;}
    .hover div:hover a,.status a{color:#FFF !important;}
    input:hover, input:focus{border-color:#09C;background:#F5F9FD none repeat scroll 0% 0%;}
</style>
EOT;
	showtips($Plang['cname_tips']);
	$usergroup = C::t('common_usergroup')->range_orderby_creditshigher();
	foreach($usergroup as $key => $value) {
		$k = $value['type'] == 'member' ? 0 : ($value['radminid'] ? 1 : 2);
		$status_array[$k][$key] = $value;
	}
	showtableheader();
	showtablerow('', array('width="60"', 'width="60"', 'width="60"'), array(
		"<div " . ($status === 0 ? 'class="status"' : "") . "><a style='color:#FF9300;' href=\"" . $href . "\">" . $Plang['Member_group'] . "</a></div>",
		"<div " . ($status === 1 ? 'class="status"' : "") . "><a style='color:blur' href=\"" . $href . "&status=1\">" . $Plang['management_group'] . "</a></div>",
		"<div " . ($status === 2 ? 'class="status"' : "") . "><a style='color:red' href=\"" . $href . "&status=2\">" . $Plang['Special_group'] . "</a></div>",
	));
	showtablefooter();/*Dism��taobao��com*/
	showformheader($url, '', 'form');
	showtableheader();
	showtablerow('', '', array(
		' ' . $Plang['Title_prefix'] . ': <input type="text"  name="prefix"  value="' . $wq_app_usergroup['prefix'] . '" />',
	));
	showtablefooter();/*Dism��taobao��com*/
	showtableheader($Plang['Group_title'], 'nobottom');
	showsubtitle(array($Plang['Group_name'], $Plang['level_num'], $Plang['is_use_background'], $Plang['is_style_system'], $Plang['Custom_background'], $Plang['Custom_background-color']));
	foreach($status_array[$status] as $key => $val) {
		$title = intval($wq_app_usergroup['group'][$key]['title']) >= 0 ? intval($wq_app_usergroup['group'][$key]['title']) : 0;
		showtablerow('', '', array(
			$val['grouptitle'],
			$prefix . '<input type="number" style="width:50px;" name="title[' . $key . ']"  value="' . $title . '" />',
			'<input class="checkbox" type="checkbox" name="background[' . $key . ']" value="1" ' . ($wq_app_usergroup['group'][$key]['background'] > 0 ? 'checked' : '') . '>',
			'<input class="checkbox" type="checkbox" name="style[' . $key . ']" value="1" ' . ($wq_app_usergroup['group'][$key]['style'] > 0 ? 'checked' : '') . '>',
			'<input type="hidden" name="gid[]" value="' . $key . '">' .
			"<input type=\"text\" id=\"group_bgcolor_" . $key . "_v\" class=\"left txt\" size=\"6\" name=\"bgcolor[" . $key . "]\" value=\"" . $wq_app_usergroup['group'][$key]['bgcolor'] . "\" onchange=\"updatecolorpreview('group_bgcolor_" . $key . "')\">"
			. "<input type=\"button\"  style=\"background-color: " . $wq_app_usergroup['group'][$key]['bgcolor'] . ";\" id=\"group_bgcolor_" . $key . "\"  class=\"colorwd\" onclick=\"group_bgcolor_" . $key . "_frame.location='static/image/admincp/getcolor.htm?group_bgcolor_" . $key . "|group_bgcolor_" . $key . "_v';showMenu({'ctrlid':'group_bgcolor_" . $key . "'})\" />"
			. "<span id=\"group_bgcolor_" . $key . "_menu\" style=\"display: none\">"
			. "<iframe name=\"group_bgcolor_" . $key . "_frame\" src=\"\" frameborder=\"0\" width=\"210\" height=\"148\" scrolling=\"no\"></iframe>"
			. "</span>",
			"<input type=\"text\" id=\"group_color_" . $key . "_v\" class=\"left txt\" size=\"6\" name=\"color[" . $key . "]\" value=\"" . $wq_app_usergroup['group'][$key]['color'] . "\" onchange=\"updatecolorpreview('group_color_" . $key . "')\">"
			. "<input style=\"background-color: " . $wq_app_usergroup['group'][$key]['color'] . ";\" type=\"button\" id=\"group_color_" . $key . "\"  class=\"colorwd\" onclick=\"group_color_" . $key . "_frame.location='static/image/admincp/getcolor.htm?group_color_" . $key . "|group_color_" . $key . "_v';showMenu({'ctrlid':'group_color_" . $key . "'})\" />"
			. "<span id=\"group_color_" . $key . "_menu\" style=\"display: none\">"
			. "<iframe name=\"group_color_" . $key . "_frame\" src=\"\" frameborder=\"0\" width=\"210\" height=\"148\" scrolling=\"no\"></iframe>"
			. "</span>",
			)
		);
	}
	showsubmit('form', 'submit');
	showtablefooter();/*Dism��taobao��com*/
	showformfooter();
} else {
	if(trim($_GET['prefix'])) {
		$wq_app_usergroup['prefix'] = trim($_GET['prefix']);
		foreach($_GET['gid'] as $key => $value) {
			$wq_app_usergroup['group'][$value] = array(
				'title' => intval($_GET['title'][$value]) >= 0 ? intval($_GET['title'][$value]) : 0,
				'background' => $_GET['background'][$value] ? 1 : 0,
				'style' => $_GET['style'][$value] ? 1 : 0,
				'bgcolor' => $_GET['bgcolor'][$value],
				'color' => $_GET['color'][$value],
			);
		}
		foreach($wq_app_usergroup['group'] as $key => $value) {
			$level[$value['title']][] = $key;
		};
		ksort($level);
		$count = count($level);
		$num = $count % 5;
		if($num > 0) {
			$remainder = ($count - $num) / 5;
		} else {
			$remainder = $count / 5;
		}
		$i = 1;
		$j = 0;
		$k = 0;
		foreach($level as $key => $value) {
			$j++;
			$k++;
			$level[$key] = $i;
			if($num > 0 && $i <= $num) {
				if($j == $remainder + 1) {
					$j = 0;
					$i++;
				}
			} else {
				if($j == $remainder) {
					$j = 0;
					$i++;
				}
			}
		}
		$wq_app_usergroup['class'] = $level;
		savecache('wq_usergroup', $wq_app_usergroup);
		cpmsg($Plang['setsucceed'], $msg_url, 'succeed');
	} else {
		cpmsg($Plang['prefix_no-empty'], $msg_url, 'error');
	}
}
//From: Dism_taobao-com
?>