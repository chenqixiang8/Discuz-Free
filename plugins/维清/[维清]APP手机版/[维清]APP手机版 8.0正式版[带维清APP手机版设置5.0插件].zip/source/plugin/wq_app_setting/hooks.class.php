<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: hooks.class.php 2015-12-2 20:00:01Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include_once DISCUZ_ROOT . './source/plugin/wq_app_setting/class/base.class.php';

class plugin_wq_app_setting extends plugin_wq_app_setting_base {

	function common() {
		global $_G;
		$this->common_base();

		if(CURSCRIPT == 'home' && $_GET['mod'] == 'space') {
			$spaceuid = empty($_GET['uid']) ? $_G['uid'] : intval($_GET['uid']);

			if(isset($_GET['username']) && !empty($_GET['username'])) {
				$member = C::t('common_member')->fetch_by_username($_GET['username']);
				if(empty($member) && !($member = C::t('common_member_archive')->fetch_by_username($_GET['username']))) {
					showmessage('space_does_not_exist');
				}
				$spaceuid = $member['uid'];
			}

			if(empty($_GET['do']) && !isset($_GET['diy'])) {
				if($_G['adminid'] == 1) {
					if($_G['setting']['allowquickviewprofile']) {
						if(!$_G['inajax']) {
							dheader("Location:{$_G['siteurl']}home.php?mod=space&uid=$spaceuid&do=profile");
						}
					}
				}
			}
		}
	}

}

class plugin_wq_app_setting_forum extends plugin_wq_app_setting {

	function topicadmin_topicadmin_delpost_message($params) {
		global $_G;
		$this->_forumdisplay_updatecache($params);
	}

	function post_wq_app_setting_message($params) {
		global $_G;
		$this->_forumdisplay_updatecache($params);
	}

	function misc_wq_app_setting_message($params) {
		global $_G;
		$this->_forumdisplay_updatecache($params);
	}

}

class mobileplugin_wq_app_setting extends plugin_wq_app_setting_base {

	function common() {
		$_GET['referer'] = urldecode($_GET['referer']);
		global $_G;

		if(CURSCRIPT == 'home' && CURMODULE == 'spacecp' && $_GET['ac'] == 'usergroup') {
			$_G['wq_gid'] = $_GET['gid'];
		}
		$this->common_base();

		$_G['setting']['seccodedata']['rule']['post']['allow'] = false;

		if($this->setting['password_seccheck']) {
			$_G['setting']['seccodedata']['rule']['password']['allow'] = false;
		}
		if($this->setting['login_seccheck']) {
			$_G['setting']['seccodedata']['rule']['login']['allow'] = false;
		}
		if($this->setting['register_seccheck']) {
			$_G['setting']['seccodedata']['rule']['register']['allow'] = false;
		}
		if(CURSCRIPT == 'home' && $_GET['mod'] == 'space') {
			$spaceuid = empty($_GET['uid']) ? $_G['uid'] : intval($_GET['uid']);

			if(isset($_GET['username']) && !empty($_GET['username'])) {
				$member = C::t('common_member')->fetch_by_username($_GET['username']);
				if(empty($member) && !($member = C::t('common_member_archive')->fetch_by_username($_GET['username']))) {
					showmessage('space_does_not_exist');
				}
				$spaceuid = $member['uid'];
			}

			if(empty($_GET['do']) && !isset($_GET['diy'])) {
				if($_G['adminid'] == 1) {
					if($_G['setting']['allowquickviewprofile']) {
						if(!$_G['inajax']) {
							dheader("Location:{$_G['siteurl']}home.php?mod=space&uid=$spaceuid&do=profile");
						}
					}
				}
			}
		}

		if(CURSCRIPT == 'home' && $_GET['mod'] == 'spacecp' && $_GET['ac'] == 'avatar') {
			dheader("Location:{$_G['siteurl']}home.php?mod=spacecp&op=index&mobile=2");
		}
	}

}

class mobileplugin_wq_app_setting_forum extends mobileplugin_wq_app_setting {

	function post_wq_app_setting() {
		global $sortid, $_G;
		loadcache(array('threadsort_option_' . $_GET['sortid']));
		if((submitcheck('topicsubmit') || submitcheck('editsubmit')) && $_G['cache']['threadsort_option_' . $_GET['sortid']]) {
			require_once libfile('function/threadsort');
			threadsort_checkoption($_GET['sortid']);
			$_G['forum_optiondata'] = threadsort_validator($_GET['typeoption'], 0);
		}
	}

	function topicadmin_topicadmin_delpost_message($params) {
		global $_G;
		$this->_forumdisplay_updatecache($params);
	}

	function post_wq_app_setting_message($params) {
		$this->_forumdisplay_updatecache($params);
	}

	function misc_wq_app_setting_message($params) {
		global $_G;
		$this->_forumdisplay_updatecache($params);
	}

	function tag_forum() {
		global $_G;
		if($_GET['mod'] == 'tag' && $_GET['op'] == 'set') {
			$_GET['tags'] = diconv($_GET['tags'], "utf-8");
		}
	}

}

class mobileplugin_wq_app_setting_search extends mobileplugin_wq_app_setting {

	function portal_search() {
		global $_G;

		if($_GET['searchsubmit'] && !empty($_GET['kw'])) {
			$kw = dhtmlspecialchars($_GET['kw']);
			$this->set_search_cookie($kw);
		}
	}

	function forum_search() {
		global $_G;

		if($_GET['searchsubmit'] && !empty($_GET['kw'])) {
			$kw = dhtmlspecialchars($_GET['kw']);
			$this->set_search_cookie($kw);
		}
	}

	function set_search_cookie($kw) {
		global $_G;

		$searchs = array();
		if(getcookie("search_" . $_G['uid'])) {
			$searchs = unserialize(getcookie("search_" . $_G['uid']));
		}

		if(empty($searchs)) {
			$searchs[] = $kw;
		} else {
			$num = count($searchs);
			if(!in_array($kw, $searchs)) {
				array_unshift($searchs, $kw);
			}
			array_filter($searchs);
			$searchs = array_values(array_slice($searchs, 0, 20));
		}

		$searchs = serialize($searchs);
		dsetcookie("search_" . $_G['uid'], $searchs, 0, 1, true);
	}

}
//From: Dism_taobao-com
?>