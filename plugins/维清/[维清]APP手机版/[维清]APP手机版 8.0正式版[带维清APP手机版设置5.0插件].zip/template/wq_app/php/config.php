<?php

/**
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: config.php 2015-8-26 22:08:14Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(CHARSET == 'gbk') {
	include 'lang_gbk.php';
} else {
	include 'lang_utf8.php';
}

loadcache(array('lang_wq_app_setting'));
if(!empty($_G['cache']['lang_wq_app_setting']['tlang'])) {
	$Tlang = $_G['cache']['lang_wq_app_setting']['tlang'];
}
if($_G['cache']['plugin']['wq_buluo']) {
	$newTlang = $Tlang;
	unset($Tlang);

	foreach($newTlang as $key => $val) {
		$Tlang[$key] = str_replace($newTlang['20d01d716f550469'], $_G['setting']['navs'][3]['navname'], $val);
	}
	include_once DISCUZ_ROOT . './source/plugin/wq_buluo/function/function_buluo_touch.php';

	$templatename = _buluo_wq_get_templatename();

	$wq_buluo_touch = _buluo_get_wq_buluo_touch();
}
include_once DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_wq_app.php';
include_once DISCUZ_ROOT . './source/plugin/wq_app_setting/config/loadfunc.php';
include_once DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_wq_app_other.php';

if(strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false) {
	define("WQ_IN_WECHAT", true);
} elseif(strpos($_SERVER['HTTP_USER_AGENT'], 'QQ') !== false) {
	define("WQ_IN_QQ", true);
}

$wq_app_setting = get_wq_app_setting();
$wq_app_style = get_wq_app_style();
$wq_login = get_wq_login();
$backurl = wq_get_backurl();
if($_G['uid']) {
	$qrcode_url = wq_app_qrcode_generate($_G['siteurl'] . 'home.php?mod=space&do=profile&uid=' . $_G['uid'], 'ueserqrcode', $_G['uid']);
}

$userid = $_G['uid'];
if(!$_GET['mycenter'] && CURSCRIPT == 'home' && (CURMODULE == 'space' || CURMODULE == 'follow' ) && $space['uid']) {
	$data = C::t('#wq_app_setting#wq_app_setting')->fetch($space['uid']);
	$mysetting = $data ? unserialize($data['show']) : get_default_stylesetting();
	$userid = $space['uid'];
} else {
	$mysetting = get_stylesetting_by_uid($styleid);
}

$logofilename = $wq_app_setting['logoname'] ? $wq_app_setting['logoname'] : "wqlogo.png";

$wq_smilies = get_system_smilies();

$wq_default_avatar = avatar(0, small, true);
$wq_my_avatar = $_G['uid'] ? avatar($_G['uid'], small, true) : $wq_default_avatar;

if(CURSCRIPT == 'member' && CURMODULE == 'connect' && $_G['qc']) {
	include_once DISCUZ_ROOT . './template/wq_app/php/qq_register.php';
}

wq_app_template_set_csscache();

loadcache(array('wq_app_menulist', 'wq_app_color', 'userreasons'));
$wq_app_menulist = !empty($_G['cache']['wq_app_menulist']) ? $_G['cache']['wq_app_menulist'] : wq_app_setting_set_menulist();
$wq_app_color = !empty($_G['cache']['wq_app_color']) ? $_G['cache']['wq_app_color'] : wq_app_setting_get_all_color();
$wq_app_defaultextstyle = "";
foreach($wq_app_color as $key => $val) {
	if($val['defaultcolor'] == 1) {
		$wq_app_defaultextstyle = $val['targettplname'];
	}
	$myextstyle == false;
	if($val['targettplname'] == $mysetting['myextstyle']) {
		$myextstyle = true;
	}
}

$_G['style']['styleimgdir'] = "template/wq_app/static/";
$myimg = wq_app_get_personal_background($userid, $mysetting, $wq_app_defaultextstyle);
if((CURSCRIPT == 'group' || (CURSCRIPT == 'forum' && (CURMODULE == 'group' || ( CURMODULE == 'forumdisplay' && $action == 'list')))) && $showmessage != 1 || CURSCRIPT == 'search' && CURMODULE == 'group') {

	if(!$_G['cache']['plugin']['wq_buluo']) {
		showmessage($Tlang['open_group']);
	} else {
		include_once DISCUZ_ROOT . './source/plugin/wq_buluo/function/function_buluo_ext.php';
		include_once DISCUZ_ROOT . './source/plugin/wq_buluo/function/function_buluo.php';
		$wq_buluo = get_wq_buluo();
	}
}

$foot_menu = unserialize($_G['setting']['wq_app_setting_footer_menu']);
$side_menu = unserialize($_G['setting']['wq_app_setting_side_menu']);
$me_menu = unserialize($_G['setting']['wq_app_setting_me_menu']);

$data = $_SERVER['HTTP_USER_AGENT'] . '&nbsp;&nbsp;' . date('H:i:s') . '<br/>';
$data .= file_get_contents('./data/cache/ua.html');
file_put_contents('./data/cache/ua.html', print_r($data, 1));

$wqreferer = str_replace('&amp;', '&', dreferer());
if(strpos($wqreferer, 'member.php?mod=register')) {
	$wqreferer = "./";
} else {
	$wqreferer = urlencode($wqreferer);
}

$sourcehttp = strrpos($_G['siteurl'], 'https://') !== 0 ? 'http://' : 'https://';
$sourceurl = $sourcehttp . $_SERVER ['HTTP_HOST'] . $_SERVER['PHP_SELF'] . "?" . $_SERVER['QUERY_STRING'];

if(CURSCRIPT == 'member' && CURMODULE == 'register' && !$sendurl) {

	$htmls = $settings = array();
	foreach($_G['cache']['fields_register'] as $field) {
		$fieldid = $field['fieldid'];
		$html = wq_profile_setting($fieldid, array(), false, false, true);
		if($html) {
			$settings[$fieldid] = $_G['cache']['profilesetting'][$fieldid];
			$htmls[$fieldid] = $html;
		}
	}
}
//From: Dism_taobao-com
?>