<?php

/**
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: function_header.php 2015-8-26 22:08:14Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function wq_app_get_header($params = array(), $nodiv = true, $right = false, $connect = '', $left = true, $center = true) {
	global $_G;

	$wclass = $params['wclass'] ? ' ' . $params['wclass'] : '';
	$wid = $params['wid'] ? ' id="' . $params['wid'] . '"' : '';
	$wextra = $params['wextra'] ? ' ' . $params['wextra'] : '';
	$wtype = $params['wtype'] ? ' ' . $params['wtype'] : 0;

	$dclass = $params['dclass'] ? ' ' . $params['dclass'] : '';
	$did = $params['did'] ? ' id="' . $params['did'] . '"' : '';
	$ltype = $params['ltype'] ? $params['ltype'] : 'fhi';
	$lname = $params['lname'] ? $params['lname'] : '';
	$lurl = $params['lurl'] ? $params['lurl'] : 'javascript:;';
	$lid = $params['lid'] ? ' id="' . $params['lid'] . '"' : '';
	$lclass = $params['lclass'] ? ' ' . $params['lclass'] : '';
	$lextra = $params['lextra'] ? ' ' . $params['lextra'] : '';
	$ctype = $params['ctype'] ? $params['ctype'] : '';
	$cname = $ctype == 'img' ? $params['cimg'] : $params['cname'];
	$rtype = $params['rtype'] ? $params['rtype'] : '';
	$rname = $params['rname'] ? $params['rname'] : '';
	$rurl = $params['rurl'] ? $params['rurl'] : 'javascript:;';
	if($rtype == 'but' && empty($params['rurl'])) {
		$rurl = '';
	}
	$rid = $params['rid'] ? ' id="' . $params['rid'] . '"' : '';
	$rclass = $params['rclass'] ? ' ' . $params['rclass'] : '';
	$rextra = $params['rextra'] ? ' ' . $params['rextra'] : '';
	$hstyle = $params['hstyle'] ? ' ' . $params['hstyle'] : '';

	$lvalue = '';
	if($left) {
		switch($ltype) {
			case 'dh':
				$lvalue = '<a href="javascript:;" class="wqiconfont2 wqicon2-daohang2 wqapp_f28 wqmenu showslidemenu"></a>';
				break;
			case 'fh':
				$lvalue = '<a href="' . $lurl . '" class="wqiconfont2 wqicon2-fanhui-copy-copy wqapp_f22' . $lclass . '"' . $lid . $lextra . '></a>';
				break;
			case 'a':
				$lname = $lname ? $lname : '<i class="wqiconfont2 wqicon2-fanhui-copy-copy wqapp_f22"></i>';
				$lvalue = '<a href="' . $lurl . '" class="wqheader_left' . $lclass . '"' . $lid . $lextra . '>' . $lname . '</a>';
				break;
			case 'cancel':
				$lurl = $lurl ? 'javascript:history.back(-1);' : $lurl;
				$lvalue = '<a href="' . $lurl . '" class="wqcancel' . $lclass . '"' . $lid . $lextra . '>' . $lname . '</a>';
				break;
		}
	}
	$cvlaue = $center && !empty($cname) ? wq_app_header_center_html($ctype, $cname) : '';

	$rvalue = '';
	if($right) {
		switch($rtype) {
			case 'share':
				$rvalue = '<a href="javascript:;" class="wqiconfont2 wqicon2-albumfenxiang y wqapp_f26 wqheader_right wqshare"></a>';
				break;
			case 'a':
				$aclss = $nodiv ? 'y wqheader_right' : 'wqpublish';
				$rvalue = '<a href="' . $rurl . '" class="' . $aclss . $rclass . '"' . $rid . $rextra . '">' . $rname . '</a>';
				break;
			case 'icon':
				$rvalue = '<a href="' . $rurl . '" class="wqapp_f24 wqmyfollow wqiconfont2' . $rclass . '"' . $rid . $rextra . '>' . $rname . '</a>';
				break;
			case 'but':
				$butname = $params['butname'] ? ' name="' . $params['butname'] . '"' : '';
				$butval = $butname ? ' value="true"' : '';
				$buttype = $params['buttype'] ? ' type="' . $params['buttype'] . '"' : ' type="submit"';
				$buturl = $rurl ? ' href="' . $rurl . '"' : '';
				$rvalue = '<button' . $butname . $butval . $buttype . ' class="wqpublish wqbg_color' . $rclass . '"' . $rid . $rextra . $buturl . '>' . $rname . '</button>';
				break;
		}
	}

	$html = $lvalue . $cvlaue . $rvalue;
	$html = $nodiv ? '<div class="wqheader_div new_div' . $dclass . '" ' . $did . '>' . $html . '</div>' : $html;

	$wclass_m = '';
	switch($wtype) {
		case 1:
			$wclass_m = ' wqheader_lump wqbg_color wqheader wqheader-position wqheader-relative';
			break;
		case 2:
			$wclass_m = ' wqheader wqbg_color wqheader-position wqheader-relative';
			break;
		case 3:
			$wclass_m = ' wqheader_lump wqbg_color wqheader-position wqheader-relative';
			break;
	}

	$header = '<div class="' . $wclass_m . $wclass . '"' . $wid . $wextra . '>';
	$header .= $html;
	$header .= $connect;
	$header .= '</div><div class="wqheight44" style="display: none;' . $hstyle . '"></div>';

	return $header;
}

function wq_app_header_center_html($ctype, $name) {
	global $_G;
	switch($ctype) {
		case 'span':
			$cvlaue = '<span class="wqpost_title">' . $name . '</span>';
			break;
		case 'img':
			$cvlaue = '<img class="wqlogo" src="' . $_G['style']['styleimgdir'] . 'images/' . $name . '">';
			break;
		case 'div':
			$cvlaue = '<div class="wqintroduction">' . $name . '</div>';
			break;
		default:
			$cvlaue = $name;
	}

	return $cvlaue;
}
//From: Dism_taobao-com
?>