<?php

/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 *
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * $Id: check.php 2015-4-9 21:49:52Z $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
define('STATURL', '{siteurl}index.php?mod=stat');

global $params;
$params = array();

$params['i_SN'] = '{ADDONVAR:SN}';
$params['i_RevisionID'] = '{ADDONVAR:RevisionID}';
$params['i_RevisionDateline'] = '{ADDONVAR:RevisionDateline}';
$params['i_SiteUrl'] = '{ADDONVAR:SiteUrl}';
$params['i_ClientUrl'] = '{ADDONVAR:ClientUrl}';
$params['i_SiteID'] = '{ADDONVAR:SiteID}';
$params['i_QQID'] = '{ADDONVAR:QQID}';
$params['i_AppKey'] = '{ADDONVAR:AppKey}';

include_once DISCUZ_ROOT . './source/discuz_version.php';
$params['s_identifier'] = 'wq_app';
$params['s_pluginversion'] = '8.0';
$params['s_siteversion'] = DISCUZ_VERSION;
$params['s_siterelease'] = DISCUZ_RELEASE;
$params['s_timestamp'] = TIMESTAMP;
$params['s_nowurl'] = $_G['siteurl'];
$bbname = CHARSET == 'gbk' ? $_G['setting']['bbname'] : diconv($_G['setting']['bbname'], CHARSET, 'GBK');
$params['s_bbname'] = base64_encode($bbname);
$params['s_site_qq'] = $_G['setting']['site_qq'];
$params['s_adminemail'] = $_G['setting']['adminemail'];
$params['i_md5'] = '{ADDONVAR:MD5}'; /*Dism_taobao-com*/

ksort($params);
$paramsbase = base64_encode(serialize($params));
$md5hash = md5($paramsbase);

?>