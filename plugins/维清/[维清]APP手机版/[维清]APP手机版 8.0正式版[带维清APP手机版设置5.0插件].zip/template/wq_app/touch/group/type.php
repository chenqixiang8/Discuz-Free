<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['type'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{template common/wq_buluo_tpl_header}-->

<!--{if $_GET[inajax]!=1}-->
<div class="my_place b_bottom"><a href="forum.php">{lang homepage}</a>
    <em class="wqiconfont wqicon-youyou"></em>
    <a href="group.php">$_G[setting][navs][3][navname]</a> <em class="wqiconfont wqicon-youyou"></em><!--{echo str_replace('<em>&rsaquo;</em>', '', $groupnav);}-->
</div>
<div id="ct" class="ct2 wp group_type_lump">
    <div class="mn group_type" style="padding-bottom: 10px;">
        <div class="bm fl">
            <!--{if $list}-->
            <div class="tbmu bw0">
                <span class="y">
                    <select title="{lang orderby}" onchange="location.href = this.value" class="ps">
                        <option value="$url" $selectorder[default]>{lang orderby_default}</option>
                        <option value="$url&orderby=thread" $selectorder[thread]>{lang stats_main_threads_count}</option>
                        <option value="$url&orderby=membernum" $selectorder[membernum]>{lang group_member_count}</option>
                        <option value="$url&orderby=dateline" $selectorder[dateline]>{lang group_create_time}</option>
                        <option value="$url&orderby=activity" $selectorder[activity]>{lang group_activities}</option>
                    </select>
                </span>
                {lang group_total_numbers}
            </div>
            <div class="bm_c">
                <table cellspacing="0" cellpadding="0" class="fl_tb">
                    <!--{loop $list $fid $val}-->
                    <tr class="fl_row">
                        <td class="fl_icn"><a href="forum.php?mod=group&fid=$fid" title="$val[name]"><img src="$val[icon]" alt="$val[name]" /></a></td>
                        <td class="fl_txt">
                            <!--{hook/index_grouplist $fid}-->
                            <strong><a href="forum.php?mod=group&fid=$fid" title="$val[name]">$val[name]</a></strong>
                            <p class="xg1">$val[description]</p>
                        </td>
                        <td class="fl_i">
                            <span class="i_z z m_r10"><i class="wqiconfont wqicon-qun f22"></i>$val[membernum]</span>
                            <span class="i_y" style="float: right; line-height: 36px;"><i class="wqiconfont wqicon-massage f18"></i>$val[threads]</span>
                        </td>
                    </tr>
                    <!--{/loop}-->
                </table>
            </div>
            <!--{if $multipage}-->
                <!--{eval
                    $multipage=str_replace('group.php','buluo.php',$multipage);
                }-->
                <style>.page a{ padding:2px 15px;}</style>
                $multipage
            <!--{/if}-->
            <!--{else}-->
            <div class="bm emp">
                <h2>{lang group_category_no_groups}</h2>
            </div>
            <!--{/if}-->
        </div>
    </div>
    <div class="group_h30"></div>
    <div class="application_ipgroup"><a href="forum.php?mod=group&action=create&fupid=$fup&groupid=$sgid" id="create_group_btn">{$Tlang[0e85dffc8ac8f983]}</a></div>
</div>
<!--{else}-->
<!--{if $page==1}-->
<div class="scrol_wrapper" id="group_{$_GET[gid]}" count='$getcount' perpage='$perpage' page='$page' data='$_GET[gid]'>
    <div>
        <ul class="bar_list">
            <!--{/if}-->
            <!--{if $list}-->
            <!--{if $_G[uid]}-->
            <!--{eval $wq_user= wq_group_usered($_G['uid']);}-->
            <!--{/if}-->
            <!--{loop $list $val}-->
            <!--{if $val[jointype]!=-1}-->
            <li class="section_p">
                <a href="buluo.php?mod=group&fid=$val[fid]">
                               <div class="bar_icon_wrap">
                        <img class="bar_icon"  src="$val[icon]">
                    </div>
                    <div class="title"><span class="name">$val[name]</span></div>
                    <div class="desc"><span>{$Tlang[8ea9c932f8444151]}{$val[threads]} {$Tlang[2c8a07313e7706bc]}{$val[membernum]}</span></div>
                </a>
                <!--{if $wq_user[$val[fid]]}-->
                <div><span class="btn_focus2"><!--{if $wq_user[$val[fid]][level]==0}-->{$Tlang[4feb290c5e86a4b8]}<!--{else}-->{$Tlang[b4b0d4ba96890702]}<!--{/if}--></span></div>
                <!--{elseif $val[jointype]!=1}-->
                <div><a href="forum.php?mod=group&action=join&fid=$val[fid]"  data='$val[fid]' jointype='$val[jointype]' class="btn_focus2 btn_focus blue join_{$val[fid]} notlogged" onclick="wq_join_data(this);
                        return wq_touch_showwindow('wq_join', this.href, 'GET');">{$Tlang[876bb8031df32628]}</a></div>
                <!--{/if}-->
                <p class="group_line b_bottom"></p>
            </li>
            <!--{/if}-->
            <!--{/loop}-->
            <!--{/if}-->
            <!--{if $page==1}-->
        </ul>
        <div class="support_idea">
            <a href="buluo.php?mod=group&action=create&fupid=$fup&groupid=$sgid" >
                <!--class="dialog"-->
                <div class="apply_group_icon"><i class="wqiconfont wqicon-yuanjiahao apply_group"></i></div>
                <div class="apply_group_txt">{$Tlang[7101528219bc68e8]}</div>
            </a>
        </div>
        <!--{if $page <= $getcount / $perpage}-->
            <div class="p_load_more">
                <!--{if $_G[uid] && isset($mysetting[myextstyle]) && $mysetting[myextstyle] != '0'}-->
                <img src="{$mysetting[myextstyle]}/icon_load.gif"/>
                <!--{else}-->
                <img src="{$_G['style'][styleimgdir]}mobile/images/icon_load.gif"/>
                <!--{/if}-->
                {$Tlang['d0a97567aed382e8']}
            </div>
        <!--{/if}-->
    </div>
</div>
<!--{/if}-->
<!--{/if}-->
<script>
	$(function () {
		$(".bar_list").on('click','a',function(){
			var gid = $("#department-list .active a").attr("data");
			group_storage('group_gid',gid);
		});
	})
</script>
<!--{template common/wq_buluo_tpl_footer}-->
<!--{/if}-->