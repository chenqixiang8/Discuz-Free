<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['group_list_3'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<li class="b_bottom">
    <!--{hook/forumdisplay_thread_mobile $key}-->
    <div>
        <div class="user_pane">
            <!--{if $thread['authorid'] && $thread['author']}-->
            <a href="{if $_G['forum']['status']==3}plugin.php?id=wq_buluo&mod=card{else}home.php?mod=space&do=profile{/if}&uid={$thread[authorid]}">
                <img class="wq_js_delayload" data="{avatar($thread[authorid], small, true)}"/>
                <font {if $groupcolor[$thread[authorid]]} style="color: $groupcolor[$thread[authorid]];"{/if} class="width100">{$thread[author]}</font>
            </a>
            <a href="home.php?mod=spacecp&ac=usergroup{if $_G[uid]!=$thread[authorid]}&gid=$fav_member[$thread[authorid]][groupid]{/if}" class="f12">
                <!--{echo  _buluo_wq_usergroup_show($fav_member[$thread[authorid]][groupid]);}-->
            </a>
            <!--{else}-->
            <a href="javascript:;">
                <img src="$_G['style'][styleimgdir]/mobile/images/hidden.jpg"/>
                {$_G[setting][anonymoustext]}
            </a>
            <!--{/if}-->
            <!--{if CURMODULE=='guide'||CURSCRIPT=='plugin'}-->
            <span class="y">
                <a href="buluo.php?mod=forumdisplay&fid={$thread['fid']}">
                    #<!--{echo strip_tags($_G['forum']['name']) ? strip_tags($_G['forum']['name']) :($_G['cache']['forums'][$thread[fid]]['name']?$_G['cache']['forums'][$thread[fid]]['name']:$wq_data['fids'][$thread['tid']]) ;}-->#
                </a>
            </span>
            <!--{/if}-->
        </div>
        <a href="buluo.php?mod=viewthread&tid=$thread[tid]&extra=$extra">
            <div class="h_over_nav">
                <h3 class="title">
                    <!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
                    <span class="icon_top">{$Tlang['4d3aee3cefdbf4b8']}</span>
                    <!--{/if}-->
                    <!--{if $thread['digest'] > 0}-->
                    <span class="icon_digest">{$Tlang['4431e4914edfce71']}</span>
                    <!--{/if}-->
                    <!--{if $thread['weeknew']}-->
                    <span class="icon_xin">{$Tlang['de8128f785039560']}</span>
                    <!--{/if}-->
                    <!--{if $thread[heatlevel]}-->
                    <span class="icon_hot">{$Tlang['03a43059cdc3dcad']}</span>
                    <!--{/if}-->
                    <!--{if $thread[folder] == 'lock'}-->
                    <span class="icon_gb">{$Tlang['beb08d096719774b']}</span>
                    <!--{elseif $thread['special'] == 1}-->
                    <span class="icon_vote">{$Tlang['a1e86aeac9394d67']}</span>
                    <!--{elseif $thread['special'] == 2}-->
                    <span class="icon_sell">{$Tlang['0907c7cfc9d2cf2b']}</span>
                    <!--{elseif $thread['special'] == 3}-->
                    <span class="icon_reward">{$Tlang['655aa530ba4d16cf']}</span>
                    <!--{elseif $thread['special'] == 4}-->
                    <span class="icon_activity">{$Tlang['2e5409eeacda8839']}</span>
                    <!--{elseif $thread['special'] == 5}-->
                    <span class="icon_debate">{$Tlang['5cbc8ce0fb1e25e0']}</span>
                    <!--{/if}-->
                    <!--{if strpos($thread[typehtml],']')}-->
                    <!--{echo str_replace(array('[', ']','<a','</a>'), array('','','<span class="wq_typehtml" ', '</span>'),$thread[typehtml]);}-->
                    <!--{elseif strpos($thread[typehtml],'img')}-->
                    <!--{echo str_replace(array('<a','</a>'), array('<span class="wq_typeimg" ', '</span>'),$thread[typehtml]);}-->
                    <!--{/if}-->
                    <!--{if strpos($thread[sorthtml],']')}-->
                    <!--{echo str_replace(array('[', ']','<a','</a>'), array('','','<span class="wq_typehtml" ', '</span>'),$thread[sorthtml]);}-->
                    <!--{/if}-->
                    <font $thread[highlight]>{$thread[subject]}</font>
                </h3>
                <div class="title_con">{$wq_data['summarys'][$thread['tid']]}</div>
            </div>
            <!--{if $wq_img_data}-->
                <div class="{if $wq_data_num > '2'}interest_img3{elseif $wq_data_num > '1'}interest_img2{else}interest_img1{/if}">
                    <!--{loop $wq_img_data $k $v}-->
                        <div class="img-box wqc_img_box" datah="{$v[height]}"  dataw="{$v[width]}" num="{$wq_data_num}" datatid="{$thread[tid]}" data="{$k}">
                           <img data="{$v[image]}" class="wq_js_delayload" id="wqc_css_{$thread[tid]}_{$k}" dataurl="{$v['image']}">
                        </div>
                    <!--{/loop}-->
                </div>
            <!--{/if}-->
        </a>
    </div>
    <p class="by disuser_nick" style="clear: both">
        <a href="buluo.php?mod=viewthread&tid=$thread[tid]&extra=$extra">
            <b>{$thread[dateline]}</b>
            <span class="num y"><i class="wqiconfont wqicon-massage f14 c_grey m_r2 m_tf2"></i>{$thread[replies]}</span>
            <span class="y browse_record"><i class="wqiconfont wqicon-liulan c_grey m_r2 f14"></i>$thread[views]</span>
        </a>
    </p>
</li>
<!--{/if}-->