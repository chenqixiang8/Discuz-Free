<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['group_manage'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{if $_GET[inajax]!=1}-->
<div class="my_group_tag" id="my_group_tag">
    <div class="tag_list">
        <ul>
            <li{if $_GET['op'] == 'group' && empty($_GET['suboperation'])} class="a"{/if}><a href="buluo.php?mod=group&action=manage&op=group&fid=$_G[fid]">{$Tlang[c1ae0e287c9cf97d]}</a></li>
            <!--{if !empty($groupmanagers[$_G[uid]]) || $_G['adminid'] == 1}-->
            <li{if $_GET['op'] == 'checkuser'} class="a"{/if}><a href="buluo.php?mod=group&action=manage&op=checkuser&fid=$_G[fid]">{$Tlang[084aae972c1d20ab]}</a>  </li>
            <li{if $_GET['op'] == 'manageuser'} class="a"{/if}><a href="buluo.php?mod=group&action=manage&op=manageuser&fid=$_G[fid]">{$Tlang[cb652d7e9654f645]}</a>  </li>
            <!--{/if}-->
            <!--{if $_G['forum']['founderuid'] == $_G['uid'] || $_G['adminid'] == 1}-->
            <li{if $_GET['op'] == 'threadtype'} class="a"{/if}><a href="buluo.php?mod=group&action=manage&op=threadtype&fid=$_G[fid]">{$Tlang[968265252bbb1364]}</a>  </li>
            <li{if $_GET['op'] == 'group' && $_GET['suboperation'] == 'levelstyle'} class="a"{/if}><a href="buluo.php?mod=group&action=manage&fid=$_G[fid]&suboperation=levelstyle">{$Tlang[d8c79993411048d5]}</a></li>
            <li{if $_GET['op'] == 'demise'} class="a"{/if}><a href="buluo.php?mod=group&action=manage&op=demise&fid=$_G[fid]">{$Tlang[cffd1e62c29df058]}</a></li>
            <!--{/if}-->
        </ul>
    </div>
</div>

<!--{eval $wq_slide=1;$my_group_tag='my_group_tag';}-->
<!--{template common/wq_buluoslide}-->
<!--{/if}-->
<!--{if $_GET['op'] == 'group'}-->
<!--{eval $wq_buluo_url=wq_buluo_pc_load_manage();}-->
<!--{if $wq_buluo_url}-->
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_buluo/config/config.php';}-->
<!--{eval require_once $wq_buluo_url;exit;}-->
<!--{/if}-->
<!--{template common/wq_buluocalendar}-->
<div class="bw0 group_add">
    <form id="set_form" enctype="multipart/form-data" action="forum.php?mod=group&action=manage&op=group&fid=$_G[fid]" name="manage" method="post" autocomplete="off">
        <input type="hidden" value="{FORMHASH}" name="formhash" />
        <input type="hidden" value="1" name="groupmanage" />
        <table cellspacing="0" cellpadding="0" class="tfm vt" summary="{lang group_admin_panel}">
            <tbody>
                <!--{if !empty($specialswitch['allowchangename']) && ($_G['uid'] == $_G['forum']['founderuid'] || $_G['adminid'] == 1)}-->
                <tr class="b_bottom">
                    <th>{lang group_name}<span class="rq">*</span></th>
                    <td><input type="text" id="name" name="name" class="px" size="36" tabindex="1" value="$_G[forum][name]" autocomplete="off" tabindex="1" /></td>
                </tr>
                <!--{/if}-->
                <!--{if !empty($specialswitch['allowchangetype']) && ($_G['uid'] == $_G['forum']['founderuid'] || $_G['adminid'] == 1)}-->
                <tr class="b_bottom">
                    <th>{lang group_category}<span class="rq">*</span></th>
                    <td>
                        <!--{eval $firstgroup = $_G['cache']['grouptype']['first'];
                               $secondgroup = $_G['cache']['grouptype']['second'];}-->
                        <!--{if $firstgroup[$firstgid]}-->
                        <!--{eval $parentid_val=$firstgid; $fup_val=$_G['forum']['fup'];$treelist_dummy=$firstgroup[$firstgid][name].($secondgroup[$_G['forum']['fup']]?' '.$secondgroup[$_G['forum']['fup']][name]:'');}-->
                        <!--{else}-->
                        <!--{eval $parentid_val=reset($firstgroup);$parentid_val=$parentid_val[fid]; $fup_val=$firstgroup[$parentid_val][secondlist][0];$treelist_dummy=$firstgroup[$parentid_val][name].($fup_val?' '.$secondgroup[$fup_val][name]:'');}-->
                        <!--{/if}-->
                        <input type="text" id="treelist_dummy" class="px city_text" autocomplete="off" placeholder="&#x8BF7;&#x9009;&#x62E9;" value="$treelist_dummy"/>
                        <input type="hidden"  id="parentid" name="parentid"  autocomplete="off" value="$parentid_val"/>
                        <input type="hidden"  id="fup" name="fup"  autocomplete="off" value="$fup_val"/>
                        <ul id="treelist" style="display: none">
                            <!--{echo wq_group_class($firstgid,$_G['forum']['fup']);}-->
                        </ul>
                    </td>
                </tr>
                <!--{/if}-->
                <tr class="b_bottom">
                    <th>{lang group_description}</th>
                    <td>
                        <div id="descriptionpreview"></div>
                        <div class="tedt">
                            <div class="area">
                                <textarea id="descriptionmessage" name="descriptionnew" class="pt" rows="8">$_G[forum][descriptionnew]</textarea>
                            </div>
                        </div>
                </tr>
                <tr class="b_bottom">
                    <th>{$Tlang[ab09b45571bf1b82]}</th>
                    <td>
                        <div class="width_half y width_spacing">
                            <input class="weui_switch" type="checkbox" id="gviewpermnew_1" name="gviewpermnew"  value="1" $gviewpermselect[1]/>
                        </div>
                    </td>
                </tr>
                <tr class="b_bottom">
                    <th>{lang group_join_type}</th>
                    <td class="p_b40">
                        <div class="width_cell_hd">
                            <input type="radio" name="jointypenew" class="weui_check" id="jointypenew_0" value="0" $jointypeselect[0]/>
                            <label class="weui_check_label" for="jointypenew_0"><i class="weui_icon_checked"></i>{$Tlang[b3500f7e797828a3]}</label>
                        </div>
                        <div class="width_cell_hd"><input type="radio" name="jointypenew" class="weui_check"id="jointypenew_2" value="2" $jointypeselect[2]/>
                            <label class="weui_check_label" for="jointypenew_2"><i class="weui_icon_checked"></i>{$Tlang[084aae972c1d20ab]}</label>
                        </div>
                        <div class="width_cell_hd"><input type="radio" name="jointypenew" class="weui_check" id="jointypenew_1" value="1" $jointypeselect[1]/>
                            <label class="weui_check_label" for="jointypenew_1"><i class="weui_icon_checked"></i>{$Tlang[96cbaaa50da04a11]}</label>
                        </div>
                        <!--{if !empty($specialswitch['allowclosegroup'])}-->
                        <div class="width_cell_hd">
                            <input type="radio" name="jointypenew" class="weui_check" id="jointypenew_-1" value="-1" $jointypeselect[-1]/>
                            <label class="weui_check_label" for="jointypenew_-1"><i class="weui_icon_checked"></i>{lang close}</label></div>
                        <div class="po_prompt po_ab">{lang group_close_notice}</div>
                        <!--{/if}-->
                    </td>
                </tr>
                <!--{if $_G['setting']['allowgroupdomain'] && !empty($_G['setting']['domain']['root']['group']) && $domainlength}-->
                <tr class="b_bottom">
                    <th>{lang subdomain}</th>
                    <td class="p_b40">
                        http://<input type="text" name="domain" class="px" value="$_G[forum][domain]" style="width: 100px;"/>.{$_G['setting']['domain']['root']['group']}
                        <div class="po_prompt po_ab">
                            {$Tlang[ebe4239eddc8c0c4]}<br/>
                            <!--{if $_G[forum][domain] && $consume}-->{lang group_edit_domain_message}<!--{/if}-->
                        </div>
                    </td>
                </tr>
                <!--{/if}-->
            </tbody>
        </table>
        <!--{if !empty($_G['group']['allowupbanner']) || $_G['adminid'] == 1}-->
        <div class="group_manage_img">
            <div class="group_po">{$Tlang[bd651309bf1b252a]}<input accept="image/*" type="file" name="bannernew" id="bannernew" class="pf poto"/></div>
            <!--{if $_G['forum']['banner']}-->
            <input  type="checkbox" name="deletebanner" class="weui_check" value="1" id="deletebanner"/>
            <label class="weui_check_label"  for="deletebanner"><i class="weui_icon_checked"></i>{lang group_no_image}</label>
            <img id="bannernew_img" src="$_G[forum][banner]?{TIMESTAMP}" />
            <!--{else}-->
            <img id="bannernew_img"  style="display: none"/>
            <!--{/if}-->
            <p class="d">
                <!--{if $_G[setting][group_imgsizelimit]}-->
                {lang group_image_filesize_limit}
                <!--{/if}-->
            </p>
        </div>
        <!--{/if}-->
        <div class="group_manage_img">
            <div class="group_po">{$Tlang[0b7e577591ddc129]}<input type="file" accept="image/*" id="iconnew" class="pf vm poto"  name="iconnew" /></div>
            <!--{if $_G['forum']['icon']}-->
            <img id="iconnew_img" width="48" height="48"  class="vm z" style="margin-right: 1em;" src="$_G[forum][icon]?{TIMESTAMP}" />
            <!--{/if}-->
            <span style="width: 230px; float: left;line-height: 24px;">{$Tlang[wq_group_icon_resize]}
                <!--{if $_G[setting][group_imgsizelimit]}-->
                {lang group_image_filesize_limit}
                <!--{/if}--></span>

        </div>
        <div class="found_group"><button id="set_button" type="button"  class="pn pnc" ><strong>{lang submit}</strong></button></div>
    </form>
</div>
<script type="text/javascript" src="{$_G['style'][styleimgdir]}mobile/thirdparty/jquery.form.min.js?{VERHASH}"></script>
<script>
    $(function () {
        var parentid, fup;
        $("#treelist").mobiscroll().treelist({
            theme: "android-ics light",
            lang: "zh",
            placeholder: '&#x8BF7;&#x9009;&#x62E9;',
            inputClass: "px city_text",
            mode: 'mixed',
            value: $("#treelist_dummy").val(),
            display: 'bottom',
            cancelText: '&#x53D6;&#x6D88;',
            setText: '&#x786E;&#x5B9A;',
            headerText: function (valueText) {
                return '{lang group_category}';
            },
            formatResult: function (array) {
                var one = $('#treelist li[data-val="' + array[0] + '"]').children('span').text();
                parentid = array[0].replace('s', '');
                fup = array[1] ? array[1].replace('s', '') : '';
                var two = array[1] ? ' ' + $('#treelist li[data-val="' + array[1] + '"]').text() : '';
                return one + two;
            },
            onSelect: function (valueText, inst) {
                $('#parentid').val(parentid);
                $('#fup').val(fup);
            },
        });
        $('#set_button').click(function () {
            var obj = $('#set_form');
            obj.ajaxSubmit({
                url: obj.attr('action') + '&inajax=1',
                dataType: 'html',
                success: function (s) {
                    popup.open(wqXml(s));
                },
            });
            return false;
        });
        function getObjectURL(file) {
            var url = null;
            if (window.createObjectURL != undefined) { // basic
                url = window.createObjectURL(file);
            } else if (window.URL != undefined) { // mozilla(firefox)
                url = window.URL.createObjectURL(file);
            } else if (window.webkitURL != undefined) { // webkit or chrome
                url = window.webkitURL.createObjectURL(file);
            }
            return url;
        }
        $('#iconnew').change(function () {
            var img = $(this).val();
            if (img != '') {
                var objUrl = getObjectURL(this.files[0]);
                if (objUrl) {
                    $("#iconnew_img").attr("src", objUrl);
                }
            }
        });
        $('#bannernew').change(function () {
            var img = $(this).val();
            if (img != '') {
                var objUrl = getObjectURL(this.files[0]);
                if (objUrl) {
                    $("#bannernew_img").attr("src", objUrl).show();
                }
            }
        });
    });</script>
<!--{elseif $_GET['op'] == 'checkuser'}-->
<!--{if $_GET[api]!=1}-->
<!--{if $checkusers}-->
<div id="group_check_list">
    <div class="xld xlda audit_list">
        <!--{loop $checkusers $uid $user}-->
        <dl class="bbda b_bottom" id="group_check_{$uid}">
            <dd class="m avt"><a href="plugin.php?id=wq_buluo&mod=card&uid=$user[uid]"><!--{echo avatar($user[uid], 'small')}--></a></dd>
            <dt><a href="plugin.php?id=wq_buluo&mod=card&uid=$user[uid]">$user[username]</a><span class="xw0">$user['joindateline']</span></dt>
            <dd class="pns group_checks">
                <a href="forum.php?mod=group&action=manage&op=checkuser&fid=$_G[fid]&uid=$user[uid]&checktype=1" data="$uid"><button type="button" class="pn pnc b_bule_all"><em>{lang pass}</em></button></a>&nbsp;
                <a href="forum.php?mod=group&action=manage&op=checkuser&fid=$_G[fid]&uid=$user[uid]&checktype=2" data="$uid"><button type="button" class="pn ignore b_all"><em>{lang ignore}</em></button></a>
            </dd>
        </dl>
        <!--{/loop}-->
    </div>
    <div class="p_load_more" style="display: none">
        <!--{if $_G[uid] && isset($mysetting[myextstyle]) && $mysetting[myextstyle] != '0'}-->
        <img src="{$mysetting[myextstyle]}/icon_load.gif"/>
        <!--{else}-->
        <img src="{$_G['style'][styleimgdir]}mobile/images/icon_load.gif"/>
        <!--{/if}-->
        {$Tlang['d0a97567aed382e8']}
    </div>
    <div class="group_h50"></div>
    <div class="tbmu audit_member b_drak group_checks b_top">
        <ul>
            <li><a href="forum.php?mod=group&action=manage&op=checkuser&fid=$_G[fid]&checkall=2" class="a b_all" data='{lang ignore_all}'>{lang ignore_all}</a></li>
            <li><a href="forum.php?mod=group&action=manage&op=checkuser&fid=$_G[fid]&checkall=1" data='{lang pass_all}' class="b_bule_all">{lang pass_all}</a></li>
        </ul>
    </div>
</div>
<script type="text/javascript">
    var data_id
    $(function () {
        var scroll_locked = true, page = '$page', count = "$checknum", perpage = "$perpage";
        $('.group_checks a').click(function () {
            var obj = $(this);
            data_id = obj.attr('data');
            $.ajax({
                type: 'POST',
                url: obj.attr('href') + '&inajax=1',
                data: {},
                dataType: 'html',
            }).success(function (s) {
                popup.open(wqXml(s));
                clearInterval(setTimeout_location);
                setTimeout(function () {
                    popup.close();
                }, '1000');
            }).error(function () {
                window.location.href = obj.attr('href');
                popup.close();
            });
            return false;
        });
        $(window).bind('scroll', function () {
            if (scroll_locked && count / perpage > page && $(document).scrollTop() + wq_window_height > $(document).height() - 500) {
                scroll_locked = false;
                loadthread();
            }
        });
        function loadthread() {
            $(".p_load_more").show();
            page++;
            $.ajax({
                type: 'POST',
                url: "forum.php?",
                data: {fid: "$_G['fid']", mod: 'group', action: 'manage', op: 'checkuser', inajax: '1', api: '1', page: page},
                dataType: 'html',
            }).success(function (s) {
                $('.audit_list').append(wqXml(s));
                $(".p_load_more").hide();
                scroll_locked = true;
            })
        }
    });
    function succeedhandle_(url, msg, param) {
        if ($.trim(msg) == '{$Tlang[243d3303ca736e98]}') {
            if (data_id == '{lang pass_all}') {
                $('#group_check_list').replaceWith('<p class="emp"><span class="no_content"><img src="$_G[style][styleimgdir]mobile/images/no_content.png"></span>{lang group_no_member_moderated}</p>');
            } else {
                $('#group_check_' + data_id + " .group_checks").replaceWith('<dd class="pns group_checks">{$Tlang[0803216264bcaad2]}</dd>');
            }
        } else if ($.trim(msg) == '{$Tlang[3726e406761de0c9]}') {
            if (data_id == '{lang ignore_all}') {
                $('#group_check_list').replaceWith('<p class="emp"><span class="no_content"><img src="$_G[style][styleimgdir]mobile/images/no_content.png"></span>{lang group_no_member_moderated}</p>');
            } else {
                $('#group_check_' + data_id).remove();
                $('.bbda').length == 0 ? $('#group_check_list').replaceWith('<p class="emp"><span class="no_content"><img src="$_G[style][styleimgdir]mobile/images/no_content.png"></span>{lang group_no_member_moderated}</p>') : '';
            }
        }
    }
</script>
<!--{else}-->
<p class="emp"><!--{if $_GET[inajax]!='1'}--><span class="no_content"><img src="$_G['style'][styleimgdir]mobile/images/no_content.png"></span><!--{/if}-->{lang group_no_member_moderated}
</p>
<!--{/if}-->
<!--{else}-->
<!--{loop $checkusers $uid $user}-->
<dl class="bbda" id="group_check_{$uid}">
    <dd class="m avt"><a href="plugin.php?id=wq_buluo&mod=card&uid=$user[uid]"><!--{echo avatar($user[uid], 'small')}--></a></dd>
    <dt><a href="plugin.php?id=wq_buluo&mod=card&uid=$user[uid]">$user[username]</a><span class="xw0">$user['joindateline']</span></dt>
    <dd class="pns group_checks">
        <a href="forum.php?mod=group&action=manage&op=checkuser&fid=$_G[fid]&uid=$user[uid]&checktype=1" data="$uid"><button type="button" class="pn pnc"><em>{lang pass}</em></button></a>&nbsp;
        <a href="forum.php?mod=group&action=manage&op=checkuser&fid=$_G[fid]&uid=$user[uid]&checktype=2" data="$uid"><button type="button" class="pn ignore"><em>{lang ignore}</em></button></a>
    </dd>
</dl>
<!--{/loop}-->
<!--{/if}-->
<!--{elseif $_GET['op'] == 'manageuser'}-->
<script type="text/javascript">
    function groupManageUser(targetlevel_val) {
        $('#targetlevel').val(targetlevel_val);
        $('#wq_g_cancel').click();
        $('#manageuser').submit();
    }
</script>
<!--{if $_G['forum']['membernum'] > 2}-->
<div class="bm_c pns wqbuluo_search_member">
    <form action="buluo.php?mod=group&action=manage&op=manageuser&fid=$_G[fid]" method="post">
        <input type="text"  name="srchuser" {if empty($_GET['srchuser'])}onclick="$('groupsearch').value=''"{/if} placeholder="{lang enter_member_user}" value="{if $_GET['srchuser']}$_GET[srchuser]{/if}" size="15" class="px p_fre vm"  id="groupsearch" >
               <button class="pn vm" type="submit"><span>{lang search}</span></button>
    </form>
</div>
<!--{/if}-->
<form action="forum.php?mod=group&action=manage&op=manageuser&fid=$_G[fid]&manageuser=true"  id="manageuser" method="post" autocomplete="off" onsubmit="return wq_touch_ajaxpost(this);">
    <input type="hidden" value="{FORMHASH}" name="formhash" />
    <input type="hidden" value="0" name="targetlevel" id="targetlevel"/>
    <input type="hidden" value="true" name="manageuser" />
    <!--{if $adminuserlist}-->
    <div class="bm gtoup_title">
        <h2 class="b_bottom">{$Tlang[de762c42e41a7b16]}</h2>
        <div class="name_member">
            <ul class="ml mls">
                <!--{loop $adminuserlist $user_key $user}-->
                <li class="b_bottom">
                    <!--{if $_G['adminid'] == 1 || ($_G['uid'] != $user['uid'] && ($_G['uid'] == $_G['forum']['founderuid'] || $user['level'] > $groupuser['level']))}-->
                     <a href="plugin.php?id=wq_buluo&mod=card&uid=$user[uid]" title="{if $user['level'] == 1}{lang group_moderator_title}{elseif $user['level'] == 2}{lang group_moderator_vice_title}{/if}{if $user['online']} {lang login_normal_mode}{/if}" class="avt"><p class="group_sign">
                        <input type="checkbox" id='wq_admin_{$user_key}' class="weui_check" name="muid[{$user[uid]}]" value="$user[level]"  {if $_G['forum']['founderuid']==$user[uid]}disabled='disabled' {/if}/>
                        <label class="weui_check_label" for="wq_admin_{$user_key}"><i class="weui_icon_checked"></i></label>
                    </p>
                    <!--{/if}-->
                    <div class="gtoup_title_div">

                        <!--{if $user['online']}-->
                        <em class="gol"></em>
                        <!--{/if}-->
                        <!--{echo avatar($user[uid], 'small')}-->
                    <p class="gtoup_title_ov "><span class="width150">$user[username]</span>
                            <!--{if $user[uid]==$_G['forum'][founderuid]}-->
                             <em class="f12 big_admin chief_admin">{$Tlang[091ee70332c0c298]}</em>
                            <!--{elseif $user['level'] == 1}-->
                            <em class="f12 big_admin">{$Tlang[15e00942fd322f8b]}</em>
                            <!--{elseif $user['level'] == 2}-->
                            <em class="f12 big_admin">{$Tlang[8234ab99d3b11df1]}</em>
                        <!--{/if}-->
                    </p>
                    </div>
                </a></li>
                <!--{/loop}-->
            </ul>
        </div>
    </div>
    <!--{/if}-->
    <!--{if $staruserlist}-->
    <div class="bm gtoup_title">
        <h2 class="b_bottom">{$Tlang[f187e961fb15208e]}</h2>
        <div class="name_member">
            <div class="ml mls">
                <!--{loop wq_alphabetical_order($staruserlist) $key $value}-->
                <div>
                    <h3>$key</h3>
                    <ul>
                        <!--{loop $value $k $user}-->
                        <li>
                         <a href="plugin.php?id=wq_buluo&mod=card&uid=$user[uid]" title="{lang group_star_member_title}{if $user['online']} {lang login_normal_mode}{/if}" class="avt group_menber">
                            <p class="group_sign">
                                <!--{if $_G['adminid'] == 1 || $user['level'] > $groupuser['level']}-->
                                <input type="checkbox" id='wq_member_{$key}_{$k}' class="weui_check" name="muid[{$user[uid]}]" value="$user[level]" />
                                <label class="weui_check_label" for="wq_member_{$key}_{$k}"><i class="weui_icon_checked"></i></label>
                                <!--{/if}-->
                            </p>
                            <div class="gtoup_title_div">

                                <!--{if $user['online']}-->
                                <em class="gol"{if $user['level'] <= 3} style="margin-top: 15px;"{/if}></em>
                                <!--{/if}-->
                                <!--{echo avatar($user[uid], 'small')}-->

                            <p class="gtoup_title_ov"> <span class="width150">$user[username] </span>
                                <!--{if $user[uid]==$_G['forum'][founderuid]}--> {$Tlang[091ee70332c0c298]}<!--{/if}--></p>
                                </div>
                       </a> </li>

                        <!--{/loop}-->
                    </ul>
                </div>
                <!--{/loop}-->
            </div>
        </div>
    </div>
    <!--{/if}-->
    <!--{if $userlist}-->
    <div class="bm gtoup_title">
        <h2 class="b_bottom">{lang member}</h2>
        <div class="name_member">
            <!--{if $userlist}-->
            <div class="ml mls">
                <!--{loop wq_alphabetical_order($userlist) $key $value}-->
                <h3>$key</h3>
                <ul>
                    <!--{loop $value $k $user}-->
                    <li>
                     <a href="plugin.php?id=wq_buluo&mod=card&uid=$user[uid]" class="avt">
                        <p class="group_sign">
                            <!--{if $_G['adminid'] == 1 || $user['level'] > $groupuser['level']}-->
                            <input type="checkbox" id='wq_user_{$key}_{$k}' class="weui_check" name="muid[{$user[uid]}]" value="$user[level]"/>
                            <label class="weui_check_label" for="wq_user_{$key}_{$k}"><i class="weui_icon_checked"></i></label>
                            <!--{/if}-->
                        </p>
                        <div class="gtoup_title_div">
                       <!--{echo avatar($user[uid], 'small')}-->
                        <p class="gtoup_title_ov"><span class="width150">$user[username]</span><!--{if $user[uid]==$_G['forum'][founderuid]}--> {$Tlang[fddbe73d3614fdd4]}<!--{/if}--></p>
                  </div>  </a></li>
                    <!--{/loop}-->
                </ul>
                <!--{/loop}-->
            </div>
            <!--{/if}-->
        </div>
    </div>
    <!--{/if}-->
    <!--{if $multipage}--><div class="pgs mbm">$multipage</div><!--{/if}-->
    <div class="group_h44"></div>
    <div class="member_manage"><a href="javascript:;" onclick=" $('#masking').fadeIn();
            $('#wq_mtype').slideDown();">{$Tlang[4fb732ea043a312d]}</a></div>
    <div class="cl post_ass name_btn" id="wq_mtype" style="display:none;">
        <ul>
            <!--{loop $mtype $key $name}-->
            <!--{if $_G['forum']['founderuid'] == $_G['uid'] || $key > $groupuser['level'] || $_G['adminid'] == 1}-->
            <li><button type="button" class="pn" onclick="groupManageUser('{$key}')">$name</button></li>
            <!--{/if}-->
            <!--{/loop}-->
            <li class="g_cancel"><a href="javascript:;" id="wq_g_cancel">{$Tlang[9c825be7149e5b97]}</a></li>
        </ul>
    </div>
</form>
<script type="text/javascript">
    $(function () {
        $('#masking,#wq_g_cancel').click(function () {
            $('#wq_mtype').slideUp();
            $('#masking').fadeOut()
        });
    })
</script>
<!--{elseif $_GET['op'] == 'threadtype'}-->
<div class="bm bw0">
    <!--{if empty($specialswitch['allowthreadtype'])}-->
    {lang group_level_cannot_do}
    <!--{else}-->
    <script>
        var rowtypedata_id = 0;
        var addrowdirect = 0;
        var typenumlimit = '$typenumlimit';
        function addrow(obj, type) {
            var obj = document.getElementById(obj);
            var table = obj.parentNode.parentNode.parentNode.parentNode;
            if (typenumlimit <= obj.parentNode.parentNode.rowIndex - 1) {
                alert('{lang group_threadtype_limit_1}' + typenumlimit + '{lang group_threadtype_limit_2}');
                return false;
            }
            if (!addrowdirect) {
                var row = table.insertRow(obj.parentNode.parentNode.rowIndex);
            } else {
                var row = table.insertRow(obj.parentNode.parentNode.rowIndex + 1);
            }
            var rowtypedata = [[
                    [1, '', ''],
                    [1, '<input type="checkbox" id="rowtypedata_id' + rowtypedata_id + '" class="weui_check" name="newenable[]" checked="checked" value="1"/>\n\
        <label class="weui_check_label" for="rowtypedata_id' + rowtypedata_id + '">\n\
                                <i class="weui_icon_checked"></i></label>', ''],
                    [1, '<input class="px" type="number" size="1" name="newdisplayorder[]" value="0"/>'],
                    [1, '<input class="px" type="text" name="newname[]"/>']
                ]];
            rowtypedata_id++;
            var typedata = rowtypedata[type];
            for (var i = 0; i <= typedata.length - 1; i++) {
                var cell = row.insertCell(i);
                cell.colSpan = typedata[i][0];
                var tmp = typedata[i][1];
                if (typedata[i][2]) {
                    cell.className = typedata[i][2];
                }
                tmp = tmp.replace(/\{(\d+)\}/g, function ($1, $2) {
                    return addrow.arguments[parseInt($2) + 1];
                });
                cell.innerHTML = tmp;
            }
            addrowdirect = 0;
        }
    </script>
    <div id="threadtypes">
        <form  action="forum.php?mod=group&action=manage&op=threadtype&fid=$_G[fid]" autocomplete="off" method="post" onsubmit="return wq_touch_ajaxpost(this);">
            <input type="hidden" value="{FORMHASH}"  name="formhash"/>
            <input type="hidden" value="true"  name="groupthreadtype"/>
            <div class="manage_add">
                <table cellspacing="0" cellpadding="0" class="tfm vt">
                    <tr class="b_bottom">
                        <th>{lang threadtype_turn_on}</th>
                        <td>
                            <div class="width_half y">
                                <input class="weui_switch" type="checkbox" name="threadtypesnew[status]" $checkeds[status][1]  value="1">
                            </div>
                        </td>
                    </tr>
                    <tbody>
                        <tr class="b_bottom">
                            <th>{lang threadtype_required}</th>
                            <td>
                                <div class="width_half y">
                                    <input class="weui_switch" type="checkbox" name="threadtypesnew[required]" $checkeds[required][1]  value="1">
                                </div>
                            </td>
                        </tr>
                        <tr class="b_bottom">
                            <th>{$Tlang[db32e5829cf9f699]}</th>
                            <td>
                                <div class="width_half y">
                                    <input class="weui_switch" type="checkbox" name="threadtypesnew[prefix]" $checkeds[prefix][1]  value="1">
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div  class="theme_ass" >
                <h2 class="ptm">{lang threadtype}</h2>
                <table  cellspacing="0" cellpadding="0" class="dt">
                    <tbody>
                        <tr>
                            <th width="15%">{lang delete}</th>
                            <th width="15%">{lang enable}</th>
                            <th width="20%">{lang displayorder}</th>
                            <th width="50%">{lang threadtype_name}</th>
                        </tr>
                        <!--{if $threadtypes}-->
                        <!--{loop $threadtypes $key $val}-->
                        <tr>
                            <td>
                                <input type="checkbox" class="weui_check" id="{$key}_del" name="threadtypesnew[options][delete][]" value="{$val[typeid]}" />
                                <label class="weui_check_label" for="{$key}_del">
                                    <i class="weui_icon_checked"></i></label>
                            </td>
                            <td>

                                <input type="checkbox" class="weui_check" id="{$key}_enable" name="threadtypesnew[options][enable][{$val[typeid]}]" value="1" $val[enablechecked]/>
                                <label class="weui_check_label" for="{$key}_enable">
                                    <i class="weui_icon_checked"></i></label>
                            </td>
                            <td>
                                <input type="number"  name="threadtypesnew[options][displayorder][{$val[typeid]}]" class="px" size="1" value="$val[displayorder]" />
                            </td>
                            <td><input type="text" name="threadtypesnew[options][name][{$val[typeid]}]" class="px" value="$val[name]"/></td>
                        </tr>
                        <!--{/loop}-->
                        <!--{/if}-->
                        <tr>
                            <td colspan="4" style="display:none">
                                <img class="vm" src="{IMGDIR}/addicn.gif"/><a href="javascript:;" id="wq_add_class">{lang threadtype_add}</a>
                            </td>
                        </tr>
                    </tbody>
                </table>
                <p class="found_group"><a href="javascript:;" onclick="addrow('wq_add_class', 0)">{lang threadtype_add}</a></p>
            </div>

            <p class="found_group"><button type="submit" class="pn pnc">{lang submit}</button></p>
        </form>
    </div>
    <!--{/if}-->
</div>
<!--{elseif $_GET['op'] == 'demise'}-->
<div class="bw0 group_attorn">
    <!--{if $groupmanagers}-->
    <div class="tbmu">
        <div class="mtm">
            <h2 class="b_bottom">{$Tlang[c6fa3e37f1c095c2]}</h2>
            <p>{$Tlang[d5d5d324ebb2383e]}</p>
            <p>{$Tlang[6b92377b82ad5f27]}</p>
        </div>
    </div>
    <form action="forum.php?mod=group&action=manage&op=demise&fid=$_G[fid]" method="post" onsubmit="return wq_touch_ajaxpost(this);">
        <input type="hidden" value="{FORMHASH}" name="formhash"/>
        <input type="hidden" value="ture" name="groupdemise" />
        <h3 class="b_bottom">{lang transfer_group_to}</h3>
        <div class="transfer_group">
            <ul class="ml mls">
                <!--{loop $groupmanagers $admin_key $user}-->
                <!--{if $user['uid'] != $_G['uid']}-->
                <li>
                    <a href="plugin.php?id=wq_buluo&mod=card&uid=$user[uid]" title="{if $user['level'] == 1}{lang group_moderator}{elseif $user['level'] == 2}{lang group_moderator_vice}{/if}{if $user['online']} {lang login_normal_mode}{/if}" class="avt">
                        <!--{echo avatar($user[uid], 'small')}-->
                    </a>
                    <p class="">$user[username]</p>
                    <p class="group_sign2">
                        <input type="radio" id="wq_admin_$admin_key" class="weui_check" name="suid" value="$user[uid]"/>
                        <label class="weui_check_label" for="wq_admin_$admin_key"> <i class="weui_icon_checked"></i></label>
                    </p>
                </li>
                <!--{/if}-->
                <!--{/loop}-->
            </ul>

        </div>
        <div class="mtm input_login_password"><input type="password" name="grouppwd" placeholder="{lang group_input_password}" class="px p_fre b_all"/></div>
        <p class="found_group"><button type="submit" class="pn pnc">{lang submit}</button></p>
    </form>
    <!--{else}-->
    <p class="emp">{lang group_no_admin_member}</p>
    <!--{/if}-->
</div>
<!--{/if}-->
<!--{/if}-->