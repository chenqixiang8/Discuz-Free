<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['index'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{eval $plugin_wq_buluo = !empty($_G['cache']['plugin']['wq_buluo']) ? 1 : 0;}-->
<!--{if $plugin_wq_buluo}-->
    <!--{eval
        $wq_buluo=$_G['cache']['plugin']['wq_buluo'];
        $wq_buluo[mobile_header]=intval($wq_buluo[mobile_header]);
    }-->
    <!--{if $wq_buluo[mobile_header]!=1}--> <!--{eval $header_nav='null';}--> <!--{/if}-->
<!--{/if}-->

<!--{template common/wq_buluo_tpl_header}-->
<style>body{ overflow: hidden;}</style>
<div class="page_group">
    <div id="main-window" class="group_left" >
        <div class="group_right abs" id="right-pane">
        <div class="group_right abs" id="group_right_list">
            <div class="group_content">&nbsp;</div>
            <div class="scrol_wrapper" id="group_index">
                <div>
                <!--{if $wq_buluo[ad_images]&&$wq_buluo[ad_url]}-->
				<ul class="bar_list">
                    <li class="group_banner ">
                        <a href="$wq_buluo[ad_url]">
                        <img src="$wq_buluo[ad_images]">
                        </a>
                    </li>
                </ul>
                <!--{/if}-->
                <ul class="bar_list">
                    <!--{if $_G[uid]}-->
                    <!--{eval $wq_user= wq_group_usered($_G['uid']);}-->
                    <!--{/if}-->
                    <!--{eval
                        $group_recommend=wq_group_recommend(dunserialize($_G['setting']['group_recommend']));
                    }-->
                    <!--{loop $group_recommend $val}-->
                    <!--{if $val[jointype]!=-1}-->
                    <li class="section_p">
                        <a href="forum.php?mod=group&fid=$val[fid]">
                            <div class="bar_icon_wrap">
                                <img class="bar_icon"  src="$val[icon]">
                            </div>
                            <div class="title"><span class="name">$val[name]</span></div>
                            <div class="desc"><span>{$Tlang[8ea9c932f8444151]}{$val[threads]} {$Tlang[2c8a07313e7706bc]}{$val[membernum]}</span></div>
                        </a>
                        <!--{if $wq_user[$val[fid]]}-->
                        <div>
                            <span class="btn_focus2">
                                <!--{if $wq_user[$val[fid]][level]==0}-->
                                {$Tlang[4feb290c5e86a4b8]}
                                <!--{else}-->
                                {$Tlang[b4b0d4ba96890702]}
                                <!--{/if}-->
                            </span>
                        </div>
                        <!--{elseif $val[jointype]!=1}-->
                        <div><a href="forum.php?mod=group&action=join&fid=$val[fid]&handlekey=wq_join"  data='$val[fid]' jointype='$val[jointype]' class="btn_focus2  btn_focus blue join_{$val[fid]} dialog notlogged" successfun="wq_join_data(obj);">{$Tlang[876bb8031df32628]}</a></div>
                        <!--{/if}-->
                        <p class="group_line b_bottom"></p>
                    </li>
                    <!--{/if}-->
                    <!--{/loop}-->
                </ul>
                </div>
            </div>
        </div>
    </div>

        <div id="left-pane" class="group_list">
            <ul id="department-list">
                <li class="active b_bottom"><a href="javascript:;" data='index'><div class="section_p">{lang recommend_group}</div></a></li>
                <!--{loop $first $groupid $group}-->
                <li class="b_bottom">
					<a href="group.php?mod=index&gid=$groupid&orderby=activity" data='$groupid' id="gid_{$groupid}">
						<div class="section_p">$group[name]</div>
					</a>
				</li>
                <!--{/loop}-->
            </ul>
        </div>
    </div>
</div>
<!--{template group/index_nav}-->
<!--{eval $adminid = $_G['adminid'];
$_G['ismoderator'] = $adminid == 1 || $adminid == 2 ? 1 : '';}-->
<script type="text/javascript" src="{$_G['style'][styleimgdir]}mobile/thirdparty/fastclick.js?{VERHASH}"></script>
<script type="text/javascript" src="{$_G['style'][styleimgdir]}mobile/thirdparty/isScroll.min.js?{VERHASH}"></script>
<script>
    var join_data, jointype;
    function  wq_join_data(obj) {
        join_data = $(obj).attr('data');
        jointype = $(obj).attr('jointype');
    }
    function succeedhandle_wq_join(url, msg, param) {
        if ($.trim(msg) == "{$Tlang[3f043f93b49a94fc]}{$_G['setting']['navs'][3]['navname']}") {
            clearInterval(setTimeout_location);
            var join_msg = jointype == 2&&!'$_G[ismoderator]' ? '{$Tlang[4feb290c5e86a4b8]}' : '{$Tlang[b4b0d4ba96890702]}';
            $('.join_' + join_data).replaceWith("<span class=\"btn_focus2\">" + join_msg + "</span>")
            setTimeout(function() {
                popup.close();
            }, '1000');
        }
    }
    $(function() {
        var windowHeight = document.doctype ? $(window).height() : document.body.clientHeight;
        var headHeight = $('.group_content').offset().top, group_menu = $('.group_menu').height();
        var isClick = false;
        FastClick.attach(document.body);
        $('#main-window').css('height', wq_window_height - group_menu - headHeight);
        var myscroll = new iScroll("left-pane", {
            hScrollbar: false,
            hScroll: false,
            bounce: true,
            vScrollbar: false
        });
        $('#group_index').height($('#main-window').height());
        new iScroll('group_index', {
            hScrollbar: false,
            hScroll: false,
            bounce: false,
            vScrollbar: false
        });

        var ss = {};

        $('#left-pane a').off().on('click', function(e) {
            e.preventDefault();
            var obj = $(this);
            var data = obj.attr('data');
            var url = obj.attr('href');

            if (isClick) return;
            isClick = true;
            if ($('#group_' + data).length) {
                switchover(obj);
                $('#group_' + data).show();
                isClick = false;
            } else {
                $.ajax({
                    type: 'POST',
                    url: url + '&inajax=1',
                    data: {},
                    dataType: 'html'
                }).success(function(s) {
                    switchover(obj);
                    $('#group_right_list').append(wqXml(s));
                    $('#group_' + data).height($('#main-window').height());

                    ss[data] = new iScroll('group_' + data, {
                        hScrollbar: false,
                        hScroll: false,
                        bounce: false,
                        vScrollbar: false,
                        onScrollEnd: function() {
                            var obj = $('.scrol_wrapper:visible');
                            var count = obj.attr('count');
                            var perpage = obj.attr('perpage');
                            var page = obj.attr('page');
                            if(scroll_locked && count && count / perpage > page && this.maxScrollY + 45 >= this.y ){
                                console.log(this);
                                var data_gid = obj.attr('data');
                                scroll_locked = false;

                                load_scroll({
                                    page: page,
                                    gid: data_gid,
                                    data: data,
                                    url: url,
                                    pageinfo: {
                                        count: count,
                                        perpage: perpage,
                                        page: page
                                    }
                                });
                            }
                        }
                    });
                    isClick = false;
                }).error(function() {
                    window.location.href = obj.attr('href');
                    popup.close();
                    isClick = false;
                });
            }
            return false;
        });

        var fid = localStorage.getItem('group_gid');
        if(fid){
            $('#left-pane a#gid_'+fid).click();
            group_storage('group_gid','','remove');
        }

        $(".bar_list").on('click','a',function(){
            var gid = $("#department-list .active a").attr("data");
            group_storage('group_gid',gid);
        });

        function switchover(obj) {
            $('.scrol_wrapper').hide();
            $('#left-pane li').attr('class', 'b_bottom');
            obj.parent().attr('class', 'active b_bottom');
            if ($('#department-list').height() >= $('#main-window').height()) {
                myscroll.scrollToElement('#left-pane .active', 2000);
            }
        }

        var scroll_locked = true;

        function load_scroll(opt) {
            $(".p_load_more").show();
            $('#group_' + opt.gid + " .support_idea").hide();
            opt.pageinfo.page++;
            $.ajax({
                type: 'POST',
                url: opt.url + '&inajax=1&page=' + opt.pageinfo.page,
                data: {},
                dataType: 'html'
            }).success(function(s) {
                $('#group_' + opt.gid + " ul").append(wqXml(s));
                $('#group_' + opt.gid).attr('page', opt.pageinfo.page);

                if (opt.pageinfo.page >= opt.pageinfo.count / opt.pageinfo.perpage) {
                    $('#group_' + opt.gid + ' .p_load_more').hide();
                }

                $('#group_' + opt.gid + " .support_idea").show();
                scroll_locked = true;

                ss[opt.data].refresh();
            });
        }
    });
</script>
<!--{eval $wq_footer_hide='1';}-->
<!--{template common/wq_buluo_tpl_footer}-->

<!--{/if}-->