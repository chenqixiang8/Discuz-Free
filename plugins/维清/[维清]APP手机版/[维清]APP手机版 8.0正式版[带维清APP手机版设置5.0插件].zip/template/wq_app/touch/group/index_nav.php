<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['index_nav'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<div class="group_menu b_top <!--{if $wq_buluo['nav_index']==0}--> group_menu_4<!--{/if}-->">
    <ul>
        <!--{if $wq_buluo['nav_index']==1}--><li class="wqgroup_index"><a href="$wq_buluo['nav_indexurl']"><i class="wqiconfont wqicon-index_2"></i><br/>{$Tlang[83f1e7a6a15f1d8a]}</a></li><!--{/if}-->
        <li <!--{if CURSCRIPT=='plugin'&&$mod=='index'}-->class="on"<!--{/if}-->><a href="plugin.php?id=wq_buluo"><i class="wqiconfont wqicon-icon14"></i><br/>{$Tlang[b8b54b467f160e57_a]}</a></li>
        <li <!--{if CURSCRIPT=='plugin'&&$mod=='user'}-->class="on"<!--{/if}-->><a href="plugin.php?id=wq_buluo&mod=user"><i class="wqiconfont wqicon-zuijinsousuo"></i><br/>{$Tlang[f988674ee5adc844]}</a></li>
        <li <!--{if CURSCRIPT=='group'&&CURMODULE=='index'}-->class="on"<!--{/if}-->><a href="buluo.php?mod=index" ><i class="wqiconfont wqicon-paixing"></i><br/>{$Tlang[1d8d4281bef59b43]}</a></li>
        <li <!--{if CURSCRIPT=='search'&&CURMODULE=='group'}--> class="on"<!--{/if}-->><a href="search.php?&mod=group" ><i class="wqiconfont wqicon-ss"></i><br/>{$Tlang[38224a4a6fc78c7c]}</a></li>
    </ul>
</div>


<!--{/if}-->