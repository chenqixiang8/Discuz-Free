<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['group_create'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{template common/wq_buluocalendar}-->
<form method="post" id="wq_creategroup" autocomplete="off" name="groupform"   action="forum.php?mod=group&action=create" >

	<div class="wq_lump_div wq-relative">
		<div class="wq_lump_pro">
                    <a href="javascript:history.go(-1);" class="wq_return">{$Tlang[9c825be7149e5b97]}</a>{$Tlang[913bd87e0b3ec651]} <span class="return_in"><button type="button" class="pn pnc formdialog">{$Tlang[984c5e7090423fd1]}</button></span>
		</div>
	</div>
	<div class="h44"></div>
	<div class="bml group_add" id="main_messaqge">
        <input type="hidden" name="formhash" value="{FORMHASH}" />
        <input type="hidden" name="referer" value="{echo dreferer()}"/>
        <input type="hidden" name="handlekey" value="creategroup"/>
        <input type="hidden" name="createsubmit" value="true">
        <table cellspacing="0" cellpadding="0" class="tfm">
            <tbody>
                <tr class="b_bottom">
                    <th>{lang group_category}<strong class="rq">*</strong></th>
                    <td>
                        <input type="text" id="treelist_dummy" class="px city_text"  placeholder="&#x8BF7;&#x9009;&#x62E9;" value="{$_G['cache']['grouptype']['first'][$_GET['fupid']][name]} {$_G['cache']['grouptype']['second'][$_G['cache']['grouptype']['first'][$_GET['fupid']][secondlist][0]][name]}"/>
                        <input type="hidden"  id="parentid" name="parentid"   value="$_GET['fupid']"/>
                        <input type="hidden"  id="fup" name="fup"  value="$_G['cache']['grouptype']['first'][$_GET['fupid']][secondlist][0]"/>
                        <ul id="treelist" style="display: none">
                            <!--{echo wq_group_class($_GET[fupid]);}-->
                        </ul>
                    </td>
                </tr>
                <tr class="b_bottom">
                    <td colspan="2">
                        <!--{if $_GET[name]}-->
                        <!--{eval $encoding = mb_detect_encoding($_GET[name],array("ASCII","UTF-8","GB2312","GBK","BIG5"));
                        $wq_name= diconv($_GET[name],$encoding);}-->
                        <!--{/if}-->
			<input type="text" name="name" class="px" size="36" placeholder="{lang group_name}" value="$wq_name"/>
                    </td>
                </tr>
                <tr class="b_bottom">
                    <td colspan="2">
                        <div id="descriptionpreview"></div>
                        <div class="tedt">
                            <div class="area">
                                <textarea name="descriptionnew"  class="pt" placeholder="{lang group_description}"rows="8"></textarea>
                            </div>
                        </div>
                </tr>
                <tr class="b_bottom">
                    <th>{$Tlang[ab09b45571bf1b82]}<strong class="rq">*</strong></th>
                    <td>
                        <div class="width_spacing width_half y"><input class="weui_switch" type="checkbox" id="gviewperm_1" name="gviewperm"  value="1" checked="checked"/></div>
                    </td>
                </tr>
                <tr class="b_bottom">
                    <th>{lang group_join_type}<strong class="rq">*</strong></th>
                    <td>
                        <div class="width_half width50">
                            <input id="jointype_0" type="radio" name="jointype" class="weui_check"  value="0" checked="checked"/>
                            <label class="weui_check_label" for="jointype_0">
                                <i class="weui_icon_checked"></i>{$Tlang[b3500f7e797828a3]}</label>
                        </div>
                        <div class="width_half width50">
                            <input id="jointype_2" type="radio" name="jointype" class="weui_check" value="2"/>
                            <label class="weui_check_label" for="jointype_2">
                                <i class="weui_icon_checked"></i>{$Tlang[084aae972c1d20ab]}</label>
                        </div>
                        <div class="width_half width50">
                            <input id="jointype_1" type="radio" name="jointype" class="weui_check" value="1"/>
                            <label class="weui_check_label" for="jointype_1"> <i class="weui_icon_checked"></i>{$Tlang[96cbaaa50da04a11]}</label>
                        </div>
                    </td>
                </tr>
            </tbody>
        </table>
        <!--{if !$_G['group']['buildgroupcredits']}-->
        <p class="p_l10 p_t10"><strong class="rq">{lang group_create_buildcredits} $_G['group']['buildgroupcredits'] $_G['setting']['extcredits'][$creditstransextra]['unit']{$_G['setting']['extcredits'][$creditstransextra]['title']}</strong></p>
        <!--{/if}-->
	</div>
</form>
<script>
	$(function() {
		var parentid, fup;
		$("#treelist").mobiscroll().treelist({
			theme: "android-ics light",
			lang: "zh",
			placeholder: '&#x8BF7;&#x9009;&#x62E9;',
			inputClass: "px city_text",
			mode: 'mixed',
			value: $("#treelist_dummy").val(),
			display: 'bottom',
			cancelText: '&#x53D6;&#x6D88;',
			setText: '&#x786E;&#x5B9A;',
			headerText: function(valueText) {
				return '{lang group_category}';
			},
			formatResult: function(array) {
				var one = $('#treelist li[data-val="' + array[0] + '"]').children('span').text();
				parentid = array[0].replace('s', '');
				fup = array[1] ? array[1].replace('s', '') : '';
				var two = array[1] ? ' ' + $('#treelist li[data-val="' + array[1] + '"]').text() : '';
				return one + two;
			},
			onSelect: function(valueText, inst) {
				$('#parentid').val(parentid)
				$('#fup').val(fup)
			},
		});
	});
</script>

<!--{/if}-->