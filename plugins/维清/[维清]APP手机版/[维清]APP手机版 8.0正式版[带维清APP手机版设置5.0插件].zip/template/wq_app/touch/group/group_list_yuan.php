<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['group_list_yuan'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{if $_GET[inajax]!=1}-->
<!--{if $_G['forum']['threadtypes']}-->
<!--{eval $r=0;}-->
<!--{block thread_group_class}-->
<div class="my_group_ass f14" id="thread_group_class">
    <div class="tag_list">
        <ul>
            <li {if !$_GET['typeid']} class="a on"{/if}><a href="forum.php?mod=forumdisplay&action=list&fid=$_G[fid]">{lang forum_viewall}</a></li>
            <!--{loop $_G['forum']['threadtypes']['types'] $id $name}-->
            <!--{eval $r++;}-->
            <li{if $_GET['typeid'] == $id} class="a on"{/if}><a href="forum.php?mod=forumdisplay&action=list&fid=$_G[fid]{if $_GET['typeid'] != $id}&filter=typeid&typeid=$id$forumdisplayadd[typeid]{/if}">$name</a>
            <!--{/loop}-->
        </ul>
    </div>
</div>
<!--{/block}-->
<!--{if $r}-->
$thread_group_class
<!--{/if}-->
<!--{eval $wq_slide=1;$my_group_tag='thread_group_class';}-->
<!--{template common/slide}-->
<!--{/if}-->
<!--{if $wq_buluo['group_top']==1&& $_G['forum_threadcount']}-->
<!--{eval $t=0;}-->
<!--{block topthread_html}-->
 <!--{loop $_G['forum_threadlist'] $k $topthread}-->
        <!--{if in_array($topthread['displayorder'], array(1, 2, 3, 4))}-->
        <!--{eval $t++;}-->
        <a href="forum.php?mod=viewthread&tid=$topthread[tid]&extra=$extra">
            <li>
                <span class="icon_top">{$Tlang['4d3aee3cefdbf4b8']}</span>
                    <!--{if strpos($topthread[typehtml],']')}-->
                    <!--{eval $wq_typehtml= str_replace(array('[', ']','<a','</a>'), array('','','<span class="wq_typehtml" ', '</span>'),$topthread[typehtml]);}-->
                    <!--{elseif strpos($topthread[typehtml],'img')}-->
                    <!--{eval $wq_typehtml= str_replace(array('<a','</a>'), array('<span class="wq_typeimg" ', '</span>'),$topthread[typehtml]);}-->
                    <!--{/if}-->
                    $wq_typehtml
                    <!--{if strpos($topthread[sorthtml],']')}-->
                    <!--{eval $wq_sorthtml=str_replace(array('[', ']','<a','</a>'), array('','','<span class="wq_typehtml" ', '</span>'),$topthread[sorthtml]);}-->
                    $wq_typehtml
                    <!--{/if}-->
	         <font $topthread[highlight]>{$topthread[subject]}</font>
            </li>
        </a>
        <!--{/if}-->
        <!--{/loop}-->
<!--{/block}-->
<!--{if $t}-->
<div class="forum_dis_t m_b5">
    <ul>
       $topthread_html
    </ul>
</div>
<!--{/if}-->

<!--{/if}-->

<div id="threadlist" class="tl theme_card" style="position: relative;">
    <div class="forum_dis">
        <form method="post" autocomplete="off" name="moderate" id="moderate" action="forum.php?mod=topicadmin&action=moderate&fid=$_G[fid]&infloat=yes&nopost=yes">
            <input type="hidden" name="formhash" value="{FORMHASH}" />
            <input type="hidden" name="listextra" value="$extra" />
            <!--{if $_G['forum_threadcount']}-->
            <ul id="mainlist">
                <!--{eval $showmodel = $mysetting['forumindex_showmodel'] == "-1" ? $wq_buluo['group_list_show'] : $mysetting['forumindex_showmodel'];
                $wq_data = get_data($_G['forum_threadlist'],$showmodel);}-->
                <!--{loop $_G['forum_threadlist'] $key $thread}-->
                <!--{if !in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
               <!--{eval include template('forum/list_style_'.$showmodel);}-->
                <!--{/if}-->
                <!--{/loop}-->
            </ul>
            <div class="p_load_more" style="display: none">
                <!--{if $_G[uid] && isset($mysetting[myextstyle]) && $mysetting[myextstyle] != '0'}-->
                <img src="{$mysetting[myextstyle]}/icon_load.gif"/>
                <!--{else}-->
                <img src="{$_G['style'][styleimgdir]}mobile/images/icon_load.gif"/>
                <!--{/if}-->
                {$Tlang['d0a97567aed382e8']}
            </div>
            <script>
				$(function() {
					var scroll_locked = true, page = '$page', count = "$_G['forum_threadcount']", perpage = "$_G['setting']['mobile']['mobiletopicperpage']";
					$(window).bind('scroll', function() {
						if (scroll_locked && count / perpage > page && $(document).scrollTop() + wq_window_height > wq_document_height - 500) {
							scroll_locked = false;
							loadthread();
						}
					});
					function loadthread() {
						$(".p_load_more").show();
						page++;
						$.ajax({
							type: 'POST',
							url: "forum.php?",
							data: {fid: "$_G['forum']['fid']", mod: 'forumdisplay', inajax: '1', page: page},
                                                        dataType: 'html'
						}).success(function(s) {
							$('#mainlist').append(wqXml(s));
							$(".p_load_more").hide();
							scroll_locked = true;
						})
					}
				});
            </script>
            <!--{else}-->
            <p class="emp">
                <span class="no_content"><img src="$_G['style'][styleimgdir]mobile/images/no_content.png"></span>
                {$Tlang[6e6c14a625a3791a]}
            </p>
            <!--{/if}-->
        </form>
    </div>
</div>
<!--{else}-->
<!--{eval $showmodel = $mysetting['forumindex_showmodel'] == "-1" ? $wq_buluo['group_list_show'] : $mysetting['forumindex_showmodel'];
$wq_data = get_data($_G['forum_threadlist'],$showmodel);}-->
<!--{loop $_G['forum_threadlist'] $key $thread}-->
<!--{if !in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
<!--{eval include template('forum/list_style_'.$showmodel);}-->
<!--{/if}-->
<!--{/loop}-->
<!--{/if}-->
<!--{/if}-->