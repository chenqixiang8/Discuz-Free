<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['group_recommend'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{template common/wq_buluo_tpl_header}-->
<h3 class="flb">
	<em>{lang group_push_to_forum}</em>
	<span><a href="javascript:;" onclick="hideWindow('$_GET[handlekey]');" class="flbc" title="{lang close}">{lang close}</a></span>
</h3>
<form method="post" autocomplete="off" id="form_$_GET[handlekey]" name="form_$_GET[handlekey]" action="forum.php?mod=group&action=recommend&fid=$_G[fid]" {if $_G[inajax]}onsubmit="ajaxpost(this.id, 'form_$_GET[handlekey]');"{/if}>
	  <input type="hidden" name="referer" value="{echo dreferer()}" />
	<input type="hidden" name="grouprecommend" value="true" />
	<input type="hidden" name="inajax" value="$_G[inajax]" />
	<!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
	<input type="hidden" name="formhash" value="{FORMHASH}" />
	<div class="c" id="return_$_GET[handlekey]">
		<select id="recommend" name="recommend" class="ps mtw mbw">
			<option value="0">{lang group_do_not_push}</option>
			$forumselect
		</select>
	</div>
	<p class="o pns">
		<button type="submit" value="true" class="pn pnc"><strong>{lang confirms}</strong></button>
	</p>
</form>

<!--{/if}-->