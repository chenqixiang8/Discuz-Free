<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['group_memberlist'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{if $op == 'alluser'}-->
<!--{eval $groupuser_extinfos= C::t('#wq_buluo#wq_buluo_groupuser_extinfo')->fetch_all_by_fid($_G['fid']);}-->
{eval
function wq_userlist($userlist,$level,$name) {
global $_G,$groupuser_extinfos,$wq_buluo_level;
$i=0;
}
<!--{if $userlist}-->


<!--{block return}-->
<div class="bml indexpage gtoup_title">
    <div class="list_title"><span class="big_admin">$name</span><em class="avatar_line b_bottom"></em></div>
    <ul class="group_list_hof">
        <!--{loop $userlist $user}-->
        <!--{if $user[uid]!=$_G['forum'][founderuid] && $user['level'] == $level}-->
        <!--{eval   $experience=$groupuser_extinfos[$user[uid]][experience]?$groupuser_extinfos[$user[uid]][experience]:0;
                    eval($wq_buluo_level[php]);
                    $wq_levelclass= $wq_buluo_level['level'][$wq_level]['class']?$wq_buluo_level['level'][$wq_level]['class']:1;
                    $i++;}-->
        <li>
            <a href="plugin.php?id=wq_buluo&mod=card&uid=$user[uid]">
                <!--{eval $user_avatar= avatar($user[uid], 'small');}-->
                <div class="group_avatar">$user_avatar</div>
            </a>
            <div class="name_list_hof">
                <a href="plugin.php?id=wq_buluo&mod=card&uid=$user[uid]" class="name_hof">
                    <div class="content">
                        <div class="nick width150">$user[username]</div>
                    </div>
                </a>
                <!--{if !empty($wq_buluo_level[prefix]) && !empty($wq_level)}-->
                <a href="plugin.php?id=wq_buluo&mod=level&fid=$_G[fid]">
                    <span class="prevent_default buluo-dislv{$wq_levelclass}">$wq_buluo_level[prefix]{$wq_level}</span>
                </a>
                <!--{/if}-->
            </div>
        </li>
        <!--{/if}-->
        <!--{/loop}-->
    </ul>
</div>
<!--{/block}-->
<!--{eval return $i>0?$return:'';}-->
<!--{/if}-->
{eval
}

}
<div class="bml indexpage gtoup_title">
    <!--{eval  $experience=$groupuser_extinfos[$_G['forum'][founderuid]][experience]>0?$groupuser_extinfos[$_G['forum'][founderuid]][experience]:0;
               eval($wq_buluo_level[php]);
               $wq_levelclass=$wq_buluo_level['level'][$wq_level]['class']?$wq_buluo_level['level'][$wq_level]['class']:1;}-->
    <div class="list_title"><span class="big_admin chief_admin">{$Tlang[091ee70332c0c298]}</span><em class="avatar_line b_bottom avatar_line60"></em></div>
    <ul class="group_list_hof">
        <li>
            <a href="plugin.php?id=wq_buluo&mod=card&uid=$_G['forum'][founderuid]" >
                <div class="group_avatar">{avatar($_G['forum'][founderuid], 'small')}</div>
            </a>
            <div class="name_list_hof">
                <a href="plugin.php?id=wq_buluo&mod=card&uid=$_G['forum'][founderuid]" class="name_hof"> <div class="content">
                        <div class="nick width150"> $_G['forum'][foundername]</div> </div>
                </a>
                 <!--{if !empty($wq_buluo_level[prefix]) && !empty($wq_level)}-->
                <a href="plugin.php?id=wq_buluo&mod=level&fid=$_G[fid]">
                    <span class="prevent_default buluo-dislv{$wq_levelclass}">$wq_buluo_level[prefix]{$wq_level}</span>
                </a>
                 <!--{/if}-->
            </div>
        </li>
    </ul>
</div>
<!--{echo wq_userlist($adminuserlist,1,$Tlang[20d01d716f550469]);}-->
<!--{echo wq_userlist($adminuserlist,2,$Tlang[8234ab99d3b11df1]);}-->
<!--{echo wq_userlist($staruserlist,3,$Tlang[f187e961fb15208e]);}-->
<!--{echo wq_userlist($alluserlist,4,$Tlang[cb652d7e9654f645]);}-->
<!--{if $multipage}--><div class="pgs">$multipage</div><!--{/if}-->
<!--{/if}-->
<!--{eval $wq_footer_hide='1';}-->
<!--{template common/wq_buluo_tpl_footer}-->
<!--{/if}-->