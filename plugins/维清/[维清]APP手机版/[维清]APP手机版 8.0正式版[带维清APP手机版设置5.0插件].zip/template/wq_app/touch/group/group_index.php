<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['group_index'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{if $status != 2}-->
<!--{if $_GET[doing]!='dynamic'}-->
<div class="tl bml gtoup_title">
    <div class="forum_dis">
        <!--{if $newthreadlist['dateline']['data']}-->
        <ul id="$thread[id]">
            <!--{eval $showmodel = $mysetting['forumindex_showmodel'] == "-1" ? $wq_buluo['group_index_show'] : $mysetting['forumindex_showmodel']; $wq_data = _buluo_get_data($newthreadlist['dateline']['data'],$showmodel);}-->
            <!--{loop $newthreadlist['dateline']['data'] $thread}-->
            <!--{eval include template('forum/list_style_'.$showmodel);}-->
            <!--{/loop}-->
        </ul>
    </div>
    <!--{if $_G['forum']['threads'] > 10}-->
    <div class="p_load_more"><a href="forum.php?mod=forumdisplay&action=list&fid=$_G[fid]#groupnav">{lang click_to_readmore}<i class="wqiconfont wqicon-down_1 f22 m_l5"></i></a></div>
    <!--{/if}-->
    <!--{else}-->
    <p class="emp">
        <span class="no_content"><img src="$_G['style'][styleimgdir]mobile/images/no_content.png"></span>
        {$Tlang[6e6c14a625a3791a]}
    </p>
    <!--{/if}-->
</div>
<!--{else}-->
<div class="bm bml gtoup_title">
    <div class="bm_c member_dynamics">
        <!--{if $groupfeedlist}-->
        <ul class="el">
            <!--{loop $groupfeedlist $feed}-->
            <li>
                <img src="$feed[icon_image]" class="t"/>
                <!--{if !empty($feed[title_template])}-->
                $feed[title_template]
                <!--{/if}-->
                <!--{if !empty($feed[body_data][subject])}-->$feed[body_data][subject]<!--{/if}-->
            </li>
            <!--{/loop}-->
        </ul>
        <!--{else}-->
        <p class="emp">
            <span class="no_content"><img src="$_G['style'][styleimgdir]mobile/images/no_content.png"></span>
            {lang group_no_latest_feeds}
        </p>
        <!--{/if}-->
    </div>
</div>
<!--{/if}-->
<!--{/if}-->
<!--{/if}-->