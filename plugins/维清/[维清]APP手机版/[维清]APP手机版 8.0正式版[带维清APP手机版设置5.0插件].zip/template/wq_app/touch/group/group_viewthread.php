<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['group_viewthread'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{eval $threadsorts = null;}-->
<!--{eval $header_nav='null';}-->
<!--{template common/wq_buluo_tpl_header}-->
<!--{hook/viewthread_top_mobile}-->
<!-- main postlist start -->
<!--{if !empty($_G['cache']['plugin']['wq_reward'])}-->
<!--{eval include_once DISCUZ_ROOT . './source/plugin/wq_reward/function/function_reward.php';}-->
<!--{eval $tem_html = common_forum_viewthread_postbottom('gtid',$_G['tid']);$button_html = $tem_html[0];}-->
<!--{/if}-->

<style>
.dislv1, .dislv2, .dislv3 { background-color:#f8c255; color:#fff;}
.dislv4, .dislv5, .dislv6, .dislv7 { background-color: #fcad30; color:#fff;}
.dislv8, .dislv9, .dislv10, .dislv11, .dislv12 { background-color: #fd963b; color:#fff;}
.dislv13, .dislv14, .dislv15, .dislv16, .dislv17 {background-color: #fd7b3b; color:#fff;}
.dislv18 {background-color: #fe5a34; color:#fff;}
</style>
<div id="view_big">
<div class="postlist">
    <!--{eval $postcount = 0;
    $wq_buluo_group_extinfo = C::t('#wq_buluo#wq_buluo_group_extinfo')->fetch($_G['fid']);
    loadcache('wq_buluo_level');
    $wq_buluo_level = $_G['cache']['wq_buluo_level'] ? $_G['cache']['wq_buluo_level'] : wq_buluo_levels();
    $wq_reset = reset($wq_buluo_level['style']);
    $lid = $wq_buluo_group_extinfo['lid'] && $wq_buluo_level['style'][$wq_buluo_group_extinfo['lid']] ? $wq_buluo_group_extinfo['lid'] : ($wq_reset ? $wq_reset['lid'] : 0);
    $wq_forumuser_url='plugin.php?id=wq_buluo&mod=card&uid=';}-->
    <!--{if $page > 1}-->
        <div class="wraper groupviewlump">
            <div class="group_title">
                <!--{if $_G[forum][threadsorts][types][$_G[forum_thread][sortid]]}-->
                <span class="wq_typehtml ts_txt">{$_G[forum][threadsorts][types][$_G[forum_thread][sortid]]}</span>
                <!--{/if}-->
                <!--{if $_G['forum_thread']['typeid'] && $_G['forum']['threadtypes']['types'][$_G['forum_thread']['typeid']]}-->
                <span class="wq_typehtml ts_txt">{$_G['forum']['threadtypes']['types'][$_G['forum_thread']['typeid']]}</span>
                <!--{/if}-->
                <!--{if $threadsorts && $_G['forum_thread']['sortid']}-->
                <span class="wq_typehtml ts_txt">{$_G['forum']['threadsorts']['types'][$_G['forum_thread']['sortid']]}</span>
                <!--{/if}-->
                <!--{if $wq_touch_setting['view_click']}-->
                <a href="forum.php?mod=viewthread&tid={$_G[forum_thread][tid]}">$_G[forum_thread][subject]</a>
                <!--{else}-->
                $_G[forum_thread][subject]
                <!--{/if}-->
                <!--{if $_G['forum_thread'][displayorder] == -2}--> <span>({$Tlang['moderating']})</span>
                <!--{elseif $_G['forum_thread'][displayorder] == -3}--><span>({$Tlang['have_ignored']})</span>
                <!--{elseif $_G['forum_thread'][displayorder] == -4}--><span>({$Tlang['draft']})</span>
                <!--{/if}-->
            </div>
        </div>
        <div class="all_comments b_bottom">
            <a id="order" name="order"></a>
            <span class="b_bule_5">{$Tlang['4bc7b967c326c87e']}</span>
        </div>
    <!--{/if}-->
    <!--{loop $postlist $post}-->
    <!--{eval $needhiddenreply = ($hiddenreplies && $_G['uid'] != $post['authorid'] && $_G['uid'] != $_G['forum_thread']['authorid'] && !$post['first'] && !$_G['forum']['ismoderator']);
    $wq_userurl=$wq_forumuser_url.$post[authorid];}-->
    <!--{hook/viewthread_posttop_mobile $postcount}-->
    <!--{if !$post[first]}-->
    <!--{if !empty($_G['cache']['plugin']['wq_reward'])}-->
    <!--{eval $replay_reward = forum_portal_group('gtid',$post['tid'],$post['pid']);}-->
     <!--{/if}-->
    <!--{template forum/wq_buluoviewthread_reply}-->
    <!--{eval continue;}-->
    <!--{/if}-->

    <div class="wraper groupviewlump">
        <div class="plc cl b_bottom user_info" id="pid$post[pid]">
            <a  class="a"href="{if $post['authorid'] && $post['username'] &&($_G['forum']['ismoderator']||!$post['anonymous'])}$wq_userurl{else}javascript:;{/if}">
                <span class="avatar head_avatar">
                    <img src="{if  $post['anonymous']}{STATICURL}image/magic/hidden.gif{else}{avatar(!$post['authorid']?0:$post[authorid], small, true)}{/if}" style="width:32px;height:32px;"/>
                </span>
                <div class="name_wrap display" href="#replybtn_$post[pid]">
                    <ul class="authi">
                        <li class="grey cl disuser_nick"></li>
                        <!--{eval $replies =  $thread[replies] < 0 ? 0 : $thread[replies]}-->
                        <!--{if $postusers[$post[authorid]][signature]}-->
                        <div class="user_sign">{$postusers[$post[authorid]][signature]}</div>
                        <!--{/if}-->
                        <span class="wqiconfont wqicon-youyou group_arrow"></span>
                    </ul>

                </div>
            </a>
            <div class="author author_div <!--{if !$postusers[$post[authorid]][signature]}-->author_div_t26<!--{/if}--> ">
                <a href="{if $post['authorid'] && $post['username'] &&($_G['forum']['ismoderator']||!$post['anonymous'])}$wq_userurl{else}javascript:;{/if}"><div class="width60 user_nick">
                        <!--{eval $wq_delete=$wq_hiddens=0;}-->
                        <!--{if $post['authorid'] && $post['username'] &&($_G['forum']['ismoderator']||!$post['anonymous'])}-->
                        <!--{eval $wq_hiddens=1;}-->
                        <font{if $post[groupcolor]} style="color: $post[groupcolor]"{/if}>$post[author]</font>
                        <!--{else}-->
                        <!--{if !$post['authorid']}-->
                        {lang guest} <em>$post[useip]{if $post[port]}:$post[port]{/if}</em>
                        <!--{elseif $post['authorid'] && $post['username'] && $post['anonymous']}-->
                        {lang anonymous}
                        <!--{else}-->
                        <!--{eval $wq_delete='1';}-->
                        $post[author]
                        <!--{/if}-->
                        <!--{/if}-->
                    </div>
                </a>
                <!--{if $wq_delete}-->
                <i class="f12">{$Tlang['917d9624d942699d']}</i>
                <!--{elseif $wq_hiddens}-->
                <!--{eval $groupuser_extinfo=C::t('#wq_buluo#wq_buluo_groupuser_extinfo')->fetch_first_by_uid_fid($post[authorid], $_G[fid]);
                $experience=$groupuser_extinfo[experience]?$groupuser_extinfo[experience]:0;
                eval($wq_buluo_level[php]);
                $wq_levelclass= $wq_buluo_level['level'][$wq_level]['class']?$wq_buluo_level['level'][$wq_level]['class']:1;}-->
                <!--{if !empty($wq_buluo_level[prefix]) && !empty($wq_buluo_level[style][$lid][content][$wq_level]) && !empty($wq_level)}-->
                <a href="plugin.php?id=wq_buluo&mod=level&fid=$_G[fid]" class="f12">
                    <span class="prevent_default buluo-dislv{$wq_levelclass}">$wq_buluo_level[prefix]{$wq_level} {$wq_buluo_level[style][$lid][content][$wq_level]}</span>
                </a>
                <!--{/if}-->
                <!--&nbsp;<span class="honour g_fans">{$Tlang[a2dafe87a6099970]}</span>-->
                <!--{/if}-->
            </div>
        </div>

        <div class="group_title">
            <!--{if $_G[forum][threadsorts][types][$_G[forum_thread][sortid]]}-->
            <span class="wq_typehtml ts_txt">{$_G[forum][threadsorts][types][$_G[forum_thread][sortid]]}</span>
            <!--{/if}-->
            <!--{if $_G['forum_thread']['typeid'] && $_G['forum']['threadtypes']['types'][$_G['forum_thread']['typeid']]}-->
            <span class="wq_typehtml ts_txt">{$_G['forum']['threadtypes']['types'][$_G['forum_thread']['typeid']]}</span>
            <!--{/if}-->
            <!--{if $threadsorts && $_G['forum_thread']['sortid']}-->
            <span class="wq_typehtml ts_txt">{$_G['forum']['threadsorts']['types'][$_G['forum_thread']['sortid']]}</span>
            <!--{/if}-->
            <!--{if $wq_touch_setting['view_click']}-->
            <a href="forum.php?mod=viewthread&tid={$_G[forum_thread][tid]}">$_G[forum_thread][subject]</a>
            <!--{else}-->
            $_G[forum_thread][subject]
            <!--{/if}-->
            <!--{if $_G['forum_thread'][displayorder] == -2}--> <span>({$Tlang['moderating']})</span>
            <!--{elseif $_G['forum_thread'][displayorder] == -3}--><span>({$Tlang['have_ignored']})</span>
            <!--{elseif $_G['forum_thread'][displayorder] == -4}--><span>({$Tlang['draft']})</span>
            <!--{/if}-->
        </div>
        <div class="group_title_info"><span class="time">$post[dateline]</span>
            <span class="detail_from"><a href="forum.php?mod=forumdisplay&action=list&fid=$_G['forum']['fid']#groupnav"><!--{echo strip_tags($_G['forum']['name']) ? strip_tags($_G['forum']['name']) : $_G['forum']['name'];}--></a></span>
        </div>
        <div class="message_img">
            <!--{template forum/wq_buluoviewthread_message}-->
            <!--{if ($post[tags] || $relatedkeywords) && $_GET['from'] != 'preview'}-->
            <div class="label_txt">
                <i class="wqiconfont wqicon-biaoqian m_r2 f20"></i>
                <!--{if $post[tags]}-->
                <!--{eval $tagi = 0;}-->
                <!--{loop $post[tags] $var}-->
                <!--{if $tagi}-->, <!--{/if}--><a title="$var[1]" href="misc.php?mod=tag&id=$var[0]">$var[1]</a>
                <!--{eval $tagi++;}-->
                <!--{/loop}-->
                <!--{/if}-->
                <!--{if $relatedkeywords}--><span>$relatedkeywords</span><!--{/if}-->
            </div>
            <!--{/if}-->

            <!--{if $_GET['from'] != 'preview' && !empty($post['ratelog'])}-->
            <dl id="ratelog_$post[pid]" class="rate{if !empty($_G['cookie']['ratecollapse'])} rate_collapse{/if}">
                <dd style="margin:0">
                    <div class="rate_num">
                        <p><span class="xi1"><!--{echo count($postlist[$post[pid]][totalrate]);}--></span>{$Tlang['a355ecd8d5fdf8df']}</p>
                        <p class="rate_l"><!--{loop $post['ratelog'] $uid $ratelog}--><a href="home.php?mod=space&uid=$uid"><!--{echo avatar($uid, 'small');}--></a><!--{/loop}--></p>
                    </div>
                </dd>
            </dl>
            <!--{else}-->
            <div id="post_rate_div_$post[pid]"></div>
            <!--{/if}-->

            <!--{if $_G['group']['raterange'] && $post['authorid']}-->
            <!--{eval $mobiscroll_select=1;}-->
            <!--{template common/wq_buluocalendar}-->
            <div class="my_rate grades" href="" style="display: none" ><a href="javascript:;">{$Tlang['f26bdb744e87d798']}</a></div>
            <!--{/if}-->
            {$button_html}
                    <!--{if ($_G['group']['raterange'] && $post['authorid'])||($_GET['from'] != 'preview' && !empty($post['ratelog']))}-->
                    <!--{if $_GET['from'] != 'preview' && !empty($post['ratelog'])}-->
                    <!--{eval $ajax_action="viewratings";$rate_class="rate_viewratings"}-->
                    <!--{else}-->
                    <!--{eval $ajax_action="rate";$rate_class="grades";}-->
                    <!--{/if}-->
                    <!--{if $_G['group']['raterange'] && $post['authorid']}--> <!--{/if}-->

                    <!--{/if}-->

            <div class="message_img">
                <!--                <div class="appreciate">
                                    <div class="appreciate_wrap">
                                        <div class="appreciate"> <a href="#" class="btn_appreciation">����</a> <span class="head_count show"><a href="#"><i>3</i><b>������</b></span></a></div>
                                        <div class="appreciate_list_wrapper">
                                            <div class="appreciate_list vcenter">
                                                <a href="home.php?mod=space&uid=$uid">{echo avatar($uid, 'small');}{echo avatar($uid, 'small');}{echo avatar($uid, 'small');}{echo avatar($uid, 'small');}{echo avatar($uid, 'small');}{echo avatar($uid, 'small');}{echo avatar($uid, 'small');}{echo avatar($uid, 'small');}</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>-->
                <div class="manage_wz">
                    <!--{if $_G['forum']['ismoderator']}-->
                    <a href="#moptions_$post[pid]" onclick="return false" class="popup blue">{lang manage}</a>
                    <div id="moptions_$post[pid]" name="moptions_$post[pid]" popup="true" class="manage" style="display:none;">
                        <div class="ass_fl">
                            <!--{if !$_G['forum_thread']['special']}-->
                            <button type="button" class="redirect button" href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]<!--{if $_G[forum_thread][sortid]}-->&sortid={$_G[forum_thread][sortid]}<!--{/if}-->{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page">{lang edit}</button>
                            <!--{/if}-->
                            <button type="button" class="dialog button notlogged" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&operation=delete&optgroup=3&from={$_G[tid]}">{lang delete}</button>
                            <button type="button" class="dialog button notlogged" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&from={$_G[tid]}&optgroup=4">{lang close}</button>
                            <button type="button" class="dialog button notlogged" href="forum.php?mod=topicadmin&action=banpost&fid={$_G[fid]}&tid={$_G[tid]}&topiclist[]={$_G[forum_firstpid]}">{$Tlang[5b1cbfcad581bfea]}</button>
                            <button type="button" class="dialog button notlogged" href="forum.php?mod=topicadmin&action=warn&fid={$_G[fid]}&tid={$_G[tid]}&topiclist[]={$_G[forum_firstpid]}">{$Tlang[a8d4b15dd720dbfc]}</button>
                        </div>
                    </div>
                    <!--{else}-->
                        <!--{if (!$_G['forum_thread']['special'] && $_G['forum']['alloweditpost'] && $_G['uid'] && ($post['authorid'] == $_G['uid'] && $_G['forum_thread']['closed'] == 0) && !(!$alloweditpost_status && $edittimelimit && TIMESTAMP - $post['dbdateline'] > $edittimelimit))}-->
                            <a class="m_l10  blue" href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]<!--{if $_G[forum_thread][sortid]}--><!--{if $post[first]}-->&sortid={$_G[forum_thread][sortid]}<!--{/if}--><!--{/if}-->{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page">
                                {lang edit}
                            </a>
                        <!--{/if}-->
                    <!--{/if}-->
                    <!--{if !IS_ROBOT && !$_GET['authorid'] && !$_G['forum_thread']['archiveid']}-->
                    <em class="admin_gl"><a href="forum.php?mod=viewthread&tid=$_G[tid]&page=$page&authorid=$_G[forum_thread][authorid]" rel="nofollow" class="blue" style="font-size:12px;font-weight:normal;">{lang viewonlyauthorid}</a></em>
                    <!--{elseif !$_G['forum_thread']['archiveid']}-->
                    <em class="admin_gl"><a href="forum.php?mod=viewthread&tid=$_G[tid]&page=$page" rel="nofollow" class="blue" style="font-size:12px;font-weight:normal;">{lang thread_show_all}</a></em>
                    <!--{/if}-->
                    <span class="y m_l10"><i class="wqiconfont wqicon-liulan c_grey m_r2 f14"></i>$thread[views]</span>
                    <!--{eval $fovorite = C::t('home_favorite')->fetch_by_id_idtype($_G[tid],'tid',$_G[uid]);}-->
                    <span class="y">
                        <a href="home.php?mod=spacecp&ac=favorite&type=thread&id=$_G[tid]" class="favbtn notlogged">
                            <!--{if $fovorite && $fovorite['uid']==$_G[uid]}-->
                                <i class="wqiconfont wqicon-shoucang m_r2 f14" style=" color: #f2de00"></i>
                            <!--{else}-->
                                <i class="wqiconfont wqicon-favorite c_grey m_r2 f14"></i>
                            <!--{/if}-->
                                <span>{$_G['thread']['favtimes']}</span>
                        </a>
                    </span>
                    <!--{if ($_G['group']['raterange'] && $post['authorid'])||($_GET['from'] != 'preview' && !empty($post['ratelog']))}-->
                        <!--{if $_GET['from'] != 'preview' && !empty($post['ratelog'])}-->
                            <!--{eval $ajax_action="viewratings";$rate_class="rate_viewratings"}-->
                        <!--{else}-->
                            <!--{eval  $ajax_action="rate";$rate_class="grades";}-->
                        <!--{/if}-->
                        <!--{if $_G['group']['raterange'] && $post['authorid']}--> <!--{/if}-->
                        <span class="y wqbuluo_rate">
                            <a href="forum.php?mod=misc&action=$ajax_action&tid=$_G[tid]&pid=$post[pid]&type=wq_buluo"  class="support {$rate_class}" {if $_G['group']['raterange'] && $post['authorid']}pid="$post[pid]"{/if}>
                               <i class="wqiconfont wqicon-icon02 c_grey"></i>
                            </a>
                            <!--{if count($postlist[$post[pid]][totalrate])>0}-->
                            <i class="m_l-4"><!--{echo count($postlist[$post[pid]][totalrate]);}--></i>
                            <!--{/if}-->
                        </span>
                    <!--{/if}-->
                </div>
            </div>

        </div>
        <div class="client_bg"><!--{hook/viewthread_postbottom_mobile $postcount}--></div>
    </div>
    <!--{if $post['relateitem']}-->
    <div class="recommend_list">
        <div class="recommend_title"><i class="left_side"></i> <span>{$Tlang[33a32dbdb037a534]}</span> </div>
        <ul class="recommend_post_list">
            <!--{loop $post['relateitem'] $var}-->
            <li class="b_bottom"><a href="forum.php?mod=viewthread&tid=$var[tid]"><div class="group_title text_overflow_ellipsis"><i></i>$var[subject]</div></a></li>
            <!--{/loop}-->
        </ul>
    </div>
    <!--{/if}-->
    <div class="all_comments b_bottom">
        <a id="order" name="order"></a>
        <span class="b_bule_5">{$Tlang['4bc7b967c326c87e']}</span>
        <em class="y">
            <!--{if $_GET['ordertype']== "1"}-->
            <a href="forum.php?mod=viewthread&tid={$_G['tid']}&extra={$_GET['extra']}#order"><i class="reverse"></i>{$Tlang['ff816907b89d1612']}</a>
            <!--{else}-->
            <a href="forum.php?mod=viewthread&tid={$_G['tid']}&extra={$_GET['extra']}&ordertype=1#order"><i></i>{$Tlang['fe87c0c04d9f5a58']}</a>
            <!--{/if}-->
        </em>
    </div>
    <!--{if count($postlist) == '1'}-->
    <div class="empty_sofa"><img src="{$_G['style'][styleimgdir]}mobile/images/sofa.png"/><br/>{$Tlang['d72d60ca7091a3bd']}</div>
    <!--{/if}-->
    <!--{eval $postcount++;}-->
    <!--{/loop}-->

</div>
<!-- main postlist end -->

$multipage
<div class="h50"></div>
<!--{if $_G['isgroupuser'] <= 0 && empty($_G['forum']['ismoderator'])}-->
    <!--{eval
        $forwardurl=$recommendurl="plugin.php?id=wq_buluo&mod=join&fid=$_G[fid]";
    }-->
<!--{else}-->
    <!--{eval
        $forwardurl="plugin.php?id=wq_buluo&mod=forward&tid=$_G[tid]";
        $recommendurl="forum.php?mod=misc&action=recommend&do=add&tid=$_G[tid]&handlekey=recommendadd";
    }-->
<!--{/if}-->
<div class="plc cl group_view_foot">
    <ul>
        <!--{eval $groupthread_extinfo = C::t('#wq_buluo#wq_buluo_groupthread_extinfo')->fetch($_G['tid']);
        $forwardnum = intval($groupthread_extinfo['forwardnum']) >= 1 ? intval($groupthread_extinfo['forwardnum'])  : 0;}-->
        <li class="group_bordright"><a href="{$forwardurl}"  class="dialog notlogged"><i class="wqiconfont wqicon-sczhuanfa f22"></i>$forwardnum</a></li>
        <!--{if !$_G['uid']}-->
        <li class="group_bordright"> <a href="member.php?mod=logging&action=login&infloat=1" id='reply_login'  class="dialog notlogged"><i class="wqiconfont wqicon-huifu f18"></i><!--{echo $thread[replies] < 0 ? 0 : $thread[replies];}--></a></li>
        <!--{else}-->
            <!--{if $_G['isgroupuser'] <= 0 && empty($_G['forum']['ismoderator'])}-->
                <li class="group_bordright"><a href="plugin.php?id=wq_buluo&mod=join&fid=$_G[fid]" class="dialog notlogged"><i class="wqiconfont wqicon-huifu f18"></i><!--{echo $thread[replies] < 0 ? 0 : $thread[replies];}--></a></li>
            <!--{else}-->
                <li class="group_bordright group_reply"><a href="javascript:;" ><i class="wqiconfont wqicon-huifu f18"></i><!--{echo $thread[replies] < 0 ? 0 : $thread[replies];}--></a></li>
            <!--{/if}-->
        <!--{/if}-->
        <li>
            <a href="{$recommendurl}&hash={FORMHASH}" class="dialog notlogged">
                <i class="wqiconfont wqicon-zan-copy f18"></i>
                <span id="recommend_add">{$_G['thread']['recommend_add']}</span>
            </a>
        </li>
    </ul>
</div>

<!--{hook/viewthread_bottom_mobile}-->
</div>

<!--{if $fastpost}-->
    <!--{subtemplate forum/wq_buluoforumdisplay_fastpost}-->
<!--{/if}-->
<!--{if defined('WQ_IN_WECHAT')}-->
<script type="text/javascript">
    $(function () {
        var i = 0, authi = new Array(), obj_img = new Array();
        $('.message_img img').each(function (i) {
            obj_img[i] = $(this).attr('src');
            if (obj_img[i].indexOf('http://') == "-1") {
                obj_img[i] = "{$_G['siteurl']}" + obj_img[i];
            }
            i++;
        });
        $('.message_img img').click(function () {
            var img = $(this).attr('src');
            if (img.indexOf('http://') == "-1") {
                img = "{$_G['siteurl']}" + img;
            }
            wx.previewImage({
                current: img,
                urls: obj_img
            });
            return false;
        });
        $('.authi img').click(function () {
            var j = 0, authi = new Array();
            var img = $(this).attr('src');
            if (img.indexOf('http://') == "-1") {
                img = "{$_G['siteurl']}" + img;
            }
            var parent_img = $(this).closest(".authi").find("img");
            parent_img.each(function (j) {
                authi[j] = $(this).attr('src');
                if (authi[j].indexOf('http://') == "-1") {
                    authi[j] = "{$_G['siteurl']}" + authi[j];
                }
                j++;
            });
            wx.previewImage({
                current: img,
                urls: authi
            });
            return false;
        });
    });
</script>
<!--{/if}-->
<script type="text/javascript">
    var scroll_Top; uid="$_G['uid']";
    var crad_reply=getcookie("wq_buluo_crad_replay_tid");
    $(function () {
        if(crad_reply){
            if(uid && uid != 0 && uid != ''){
                if( $('#wq_reply_click').length){
                    $('#wq_reply_click').click();
                    scroll_reply = $(document).scrollTop();
                    $('#wq_reply_post , .wqreplyheader').show();
                    $('#needmessage').focus().val('').attr('placeholder', '{lang send_reply_fast_tip}');
                    $('#wq_reply').hide();
                    setcookie("wq_buluo_crad_replay_tid",'',-1);
                }
            }else{
            }
        }

        $('.group_reply').on('click', function () {
            $('#wq_reply_click').click();
            scroll_reply = $(document).scrollTop();
            $('#wq_reply_post , .wqreplyheader').show();
            $('#needmessage').focus().val('').attr('placeholder', '{lang send_reply_fast_tip}');
            $('#wq_reply').hide();
        });

        $('.favbtn').on('click', function () {
            var obj = $(this);
            $.ajax({
                type: 'POST',
                url: obj.attr('href') + '&handlekey=favbtn&inajax=1',
                data: {favoritesubmit: 'true', formhash: '{FORMHASH}'},
                dataType: 'html',
            }).success(function (s) {
                popup.open(wqXml(s));
            }).error(function () {
                window.location.href = obj.attr('href');
                popup.close();
            });
            return false;
        });

        var pcontent_height = $(window).height() - 50;
        $('.grades').on('click', function () {
            var obj = $(this);
            $.ajax({
                type: 'GET',
                url: obj.attr('href') + '&inajax=1',
                data: {},
                dataType: 'html',
            }).success(function (s) {
                $('#popup_grade').html(wqXml(s));
                if ($('#rateform').length) {
                    $('#popup_content').attr("style", 'height:' + pcontent_height + 'px').html(wqXml(s));
                    if ($('#popup_fullscreen').is(':hidden')) {
                        $('#popup_title').text("{$Tlang['0487fbf42b51d238']}");
                        $('#popup_fullscreen').slideDown();
                        scroll_Top = $(window).scrollTop();
                        $('html,body').addClass("wq_ovhidden");
                    }
                    $('.my_rate').hide();
                } else {
                    popup.open(wqXml(s));
                }
            }).error(function () {
                window.location.href = obj.attr('href');
                popup.close();
            });
            return false;
        });
        $('.rate_viewratings').on('click', function () {
            var obj = $(this);
            $.ajax({
                type: 'GET',
                url: obj.attr('href') + '&inajax=1',
                data: {},
                dataType: 'html',
            }).success(function (s) {
                $('#popup_content').attr("style", 'height:' + pcontent_height + 'px').html(wqXml(s));
                $('#popup_title').text("{$Tlang['0b895e776c79def4']}");
                $('#popup_fullscreen').slideDown();
                var pid = obj.attr('pid');
                if (pid) {
                    $('.my_rate').attr('href', 'forum.php?mod=misc&action=rate&tid=$_G[tid]&pid=' + pid).slideDown();
                    $('#rate_h50').show();
                }
                scroll_Top = $(window).scrollTop();
                $('html,body').addClass("wq_ovhidden");
            }).error(function (s) {
                window.location.href = obj.attr('href');
                popup.close();
            });
            return false;
        });

        $('.support_forum').on('click', function () {
            var obj = $(this);
            var data = obj.attr('data');
            $.ajax({
                type: 'GET',
                url: obj.attr('href') + '&inajax=1',
                data: {'hash': '{FORMHASH}'},
                dataType: 'html',
            }).success(function (s) {
                $('#popup_grade').html(wqXml(s));
                if ($.trim($('#popup_grade p:eq(0)').text()) == '{$Tlang[289f61f54d327553]}') {
                    var text = $('#review_support_' + data).text() > 0 ? $('#review_support_' + data).text() + 1 : 1;
                    $('#review_support_' + data).html(text);
                }
                popup.open(wqXml(s));
            }).error(function () {
                window.location.href = obj.attr('href');
                popup.close();
            });
            return false;
        });
        $('.oppose').on('click', function () {
            var obj = $(this);
            var data = obj.attr('data');
            $.ajax({
                type: 'GET',
                url: obj.attr('href') + '&inajax=1',
                data: {'hash': '{FORMHASH}'},
                dataType: 'html',
            }).success(function (s) {
                $('#popup_grade').html(wqXml(s));
                if ($.trim($('#popup_grade p:eq(0)').text()) == '{$Tlang[289f61f54d327553 ]}') {
                    var text = $('#review_supportss_' + data).text() > 0 ? $('#review_supportss_' + data).text() + 1 : 1;
                    $('#review_supportss_' + data).html(text);
                }
                popup.open(wqXml(s));
            }).error(function () {
                window.location.href = obj.attr('href');
                popup.close();
            });
            return false;
        });

        $('.bestanswer').on('click', function () {
            var obj = $(this);
            $.ajax({
                type: 'POST',
                url: obj.attr('href') + '&inajax=1',
                data: {
                    'formhash': '{FORMHASH}',
                    'listextra': '{$_GET[extra]}',
                    'page': '{$_GET[page]}',
                    'bestanswersubmit': 'yes',
                    'from': '{$_GET[from]}'
                },
                dataType: 'html',
            }).success(function (s) {
                popup.open(wqXml(s));
            }).error(function () {
                window.location.href = obj.attr('href');
                popup.close();
            });
            return false;
        });
    });

    function errorhandle_recommendadd(msg, param) {
        if (param['recommendv'] == '+1') {
            var objv = $('#recommend_add');
            objv.css("display", "");
            objv.html(parseInt(objv.html()) + 1);
        }
    }

    function succeedhandle_favbtn(url, msg, param) {
        if ($.trim(msg) == '{$Tlang[fffeda57b2002266]}') {
            clearInterval(setTimeout_location);
            $('.favbtn i').attr('class','wqiconfont wqicon-shoucang m_r2 f14');
            $('.favbtn i').css('color','#f2de00');
            $('.favbtn span').text(parseInt($('.favbtn span').text()) + 1);
            setTimeout(function () {
                popup.close();
            }, '1000');
        }
    }

</script>
<a href="javascript:;" title="{lang scrolltop}" class="scrolltop bottom"></a>
<!--{eval $wq_footer_hide='1';}-->
<!--{template common/wq_buluo_tpl_footer}-->

<!--{/if}-->