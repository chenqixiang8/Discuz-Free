<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['group'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{eval $header_nav='null';}-->
<!--{template common/wq_buluo_tpl_header}-->
<!--{if $_GET[inajax]!=1}-->
<div id="ct" class="ct2 wp ">
    <div class="mn">
        <!--{if $action != 'manage'&& $action != 'create'}-->
        <!--{if helper_access::check_module('group')}-->
        <!--{if !$_G[uid]}-->
        <a  href="member.php?mod=logging&action=login&infloat=yes" class="dialog notlogged"><div class="publish_btn"><i class="wqiconfont wqicon-post group_post"></i></div></a>
        <!--{else}-->
        <a id="newspecial" href="buluo.php?mod=post&action=newthread&fid=$_G[fid]&type=wq_buluo" {if !$_G['isgroupuser']}style="display:none"{/if}><div class="publish_btn"><i class="wqiconfont wqicon-post group_post"></i></div></a>
        <!--{if $_G['group']['allowpost'] && ($_G['group']['allowposttrade'] || $_G['group']['allowpostpoll'] || $_G['group']['allowpostreward'] || $_G['group']['allowpostactivity'] || $_G['group']['allowpostdebate'] || $_G['setting']['threadplugins'] || $_G['forum']['threadsorts'])}-->
        <div id="newspecial_menu" class="post_ass" style="display: none">
            <ul class="p_pop" >
                <!--{if !$_G['forum']['allowspecialonly']}-->
                <li><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&type=wq_buluo"><i class="wqiconfont wqicon-post_1 f22"></i>{lang post_newthread}<em class="wqiconfont wqicon-youyou"></em></a></li>
                <!--{/if}-->
                <!--{if $_G['group']['allowpostpoll']}-->
                <li class="poll"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=1&type=wq_buluo"><i class="wqiconfont wqicon-toupiao f22"></i>{lang post_newthreadpoll}<em class="wqiconfont wqicon-youyou"></em></a></li>
                <!--{/if}-->
                <!--{if $_G['group']['allowpostreward']}-->
                <li class="reward"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=3&type=wq_buluo"><i class="wqiconfont wqicon-jinqian f22"></i>{lang post_newthreadreward}<em class="wqiconfont wqicon-youyou"></em></a></li>
                <!--{/if}-->
                <!--{if $_G['group']['allowpostdebate']}-->
                <li class="debate"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=5&type=wq_buluo"><i class="wqiconfont wqicon-vsbianlun f22"></i>{lang post_newthreaddebate}<em class="wqiconfont wqicon-youyou"></em></a></li>
                <!--{/if}-->
                <!--{if $_G['group']['allowpostactivity']}-->
                <li class="activity"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=4&type=wq_buluo"><i class="wqiconfont wqicon-qunliao f22"></i>{lang post_newthreadactivity}<em class="wqiconfont wqicon-youyou"></em></a></li>
                <!--{/if}-->
                <!--{if $_G['group']['allowposttrade']}-->
                <li class="g_trade"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=2&type=wq_buluo"><i class="wqiconfont wqicon-wodeshangpin f22"></i>{lang post_newthreadtrade}<em class="wqiconfont wqicon-youyou"></em></a></li>
                <!--{/if}-->
                <!--{loop $_G['forum']['threadsorts']['types'] $id $threadsorts}-->
                <!--{if $_G['forum']['threadsorts']['show'][$id]}-->
                <li class="popupmenu_option"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&extra=$extra&sortid=$id&type=wq_buluo"><i class="wqiconfont wqicon-post_1 f22"></i>$threadsorts<em class="wqiconfont wqicon-youyou"></em></a></li>
                <!--{/if}-->
                <!--{/loop}-->
                <!--{if $_G['forum']['threadsorts'] && !$_G['forum']['allowspecialonly']}-->
                <!--{/if}-->
                <li class="g_cancel"><a href="javascript:;" id="wq_g_cancel" >{$Tlang[9c825be7149e5b97]}</a></li>
            </ul>
        </div>
        <script type="text/javascript">
            $(function () {
                $('#newspecial').click(function () {
                    if ($('#newspecial_menu').length) {
                        $('#masking').fadeIn();
                        $('#newspecial_menu').slideDown();
                        return false;
                    }
                });
                $('#masking,#wq_g_cancel').click(function () {
                    $('#newspecial_menu').slideUp();
                    $('#masking').fadeOut()
                });
            })
        </script>
        <!--{/if}-->
        <!--{/if}-->
        <!--{/if}-->
        <!--{if $action=='list'}-->
        <!--{eval  $groupuser = C::t('forum_groupuser')->fetch_userinfo($_G['uid'], $_G['fid']);}-->
        <!--{/if}-->
        <div class="qz_bg">
            <div class="group_home"  <!--{if $_G['forum']['banner']}-->style="background-image: url({$_G['forum']['banner']});" <!--{/if}-->>
                 <div class="group_home_bg" onclick="location.href = 'plugin.php?id=wq_buluo&mod=rank&fid=$_G[fid]';" >
                    <div class="group_head"><img src="$_G[forum][icon]"/>
                        <div class="logo_rank"><span>{$nav['first']['name']} No.<!--{echo wq_buluo_order($nav);}--></span></div>
                    </div>
                    <div class="group_info">
                        <h3>$_G[forum][name]<span></span></h3>
                        <p><span class="m_r5">{$Tlang[8ea9c932f8444151]}{$_G[forum][posts]}</span><span class="m_r5">{lang member}{$_G[forum][membernum]}</span></p>
                        <div id="wq_sign_level">
                            <!--{eval $wq_signlevel_show=0;}-->
                            <!--{if $_G['uid']||$action=='memberlist'}-->
                                <!--{eval
                                    $groupuser_extinfo=C::t('#wq_buluo#wq_buluo_groupuser_extinfo')->fetch_first_by_uid_fid($_G[uid], $_G[fid]);
                                    $wq_buluo_group_extinfo = C::t('#wq_buluo#wq_buluo_group_extinfo')->fetch($_G['fid']);
                                    loadcache('wq_buluo_level');
                                    $wq_buluo_level = $_G['cache']['wq_buluo_level'] ? $_G['cache']['wq_buluo_level'] : wq_buluo_levels();
                                    $wq_reset = reset($wq_buluo_level['style']);
                                    $lid = $wq_buluo_group_extinfo['lid'] && $wq_buluo_level['style'][$wq_buluo_group_extinfo['lid']] ? $wq_buluo_group_extinfo['lid'] : ($wq_reset ? $wq_reset['lid'] : 0);
                                    $experience=$groupuser_extinfo[experience]?$groupuser_extinfo[experience]:0;
                                    eval($wq_buluo_level[php]);
                                    $wq_levelclass= $wq_buluo_level['level'][$wq_level]['class']?$wq_buluo_level['level'][$wq_level]['class']:1;
                                }-->
                                <!--{if !empty($wq_buluo_level[prefix]) && !empty($wq_buluo_level[style][$lid][content][$wq_level]) && !empty($wq_level)}-->
                                   <div class="group_info_wrap" <!--{if $_G['forum'][founderuid]!=$_G[uid] && (!$groupuser||$groupuser[level]==0)}--><!--{eval $wq_signlevel_show=1;}-->style="display: none" <!--{/if}-->>
                                        <span class="group_level buluo-dislv{$wq_levelclass}">
                                            <a href="plugin.php?id=wq_buluo&mod=level&fid=$_G[fid]">
                                                $wq_buluo_level[prefix]{$wq_level} {$wq_buluo_level[style][$lid][content][$wq_level]}
                                            </a>
                                        </span>
                                        <!--{if $wq_buluo_level[level][$wq_level+1][val]}-->
                                            <!--{eval $width=intval($experience)/intval($wq_buluo_level[level][$wq_level+1][val])*100;}-->
                                            <div class="group_infobar m_t5"><span style="width:{$width}%;"></span></div>
                                        <!--{/if}-->
                                    </div>
                                <!--{/if}-->
                            <!--{/if}-->
                            <!--{if $_G[forum][description]&&($wq_signlevel_show||!$_G['uid'])}-->
                                <p class="group_sum">$_G[forum][description]</p>
                            <!--{/if}-->
                        </div>
                    </div>
                </div>

                <div class="group_pay">
                    <!--{if $_G['forum'][founderuid]!=$_G[uid]}-->

                    <!--{if $groupuser}-->
                    <!--{if $groupuser[level]==0}-->
                    <a href="forum.php?mod=group&action=out&fid=$_G[fid]&handlekey=wq_out" class="dialog btn_focus notlogged">{$Tlang[fcce7c30276aa190]}</a>
                    <!--{elseif $groupuser[level]>0}-->
                    <!--{if $groupuser_extinfo[lastsign]!=strtotime(date('Y-m-d'))}-->
                    <a href="plugin.php?id=wq_buluo&mod=sign&fid=$_G[fid]" class="dialog btn_focus notlogged">{$Tlang[f64c30e837e3267a]}</a>
                    <!--{else}-->
                    <a href="plugin.php?id=wq_buluo&mod=sign&fid=$_G[fid]" class="dialog btn_focus group_signed notlogged"><i class="wqiconfont wqicon-yes"></i>{$Tlang[a08b091b9ce4c933]}</a>
                    <!--{/if}-->
                    <!--{/if}-->
                    <!--{elseif helper_access::check_module('group') && $_G['forum'][jointype]!=1}-->
                    <a href="buluo.php?mod=group&action=join&fid=$_G[fid]&handlekey=wq_join" class="dialog btn_focus notlogged">{$Tlang[876bb8031df32628]}</a>
                    <!--{/if}-->
                    <!--{else}-->
                    <!--{if $groupuser_extinfo[lastsign]!=strtotime(date('Y-m-d'))}-->
                    <a href="plugin.php?id=wq_buluo&mod=sign&fid=$_G[fid]" class="dialog btn_focus notlogged">{$Tlang[f64c30e837e3267a]}</a>
                    <!--{else}-->
                    <a href="plugin.php?id=wq_buluo&mod=sign&fid=$_G[fid]" class="dialog btn_focus group_signed notlogged"><i class="wqiconfont wqicon-yes"></i>{$Tlang[a08b091b9ce4c933]}</a>
                    <!--{/if}-->

                    <!--{/if}-->
                </div>
            </div>
        </div>
        <!--{if $status != 2 && $status != 3}-->
        <!--{eval $k=3;}-->
        <!--{block wq_tag_list}-->
        <div class="tag_list">
            <ul>
                <li {if $action == 'list'}class="a"{/if}><a href="buluo.php?mod=forumdisplay&action=list&fid=$_G[fid]#groupnav" ><p class="wqiconfont wqicon-huati f18"></p>{$Tlang[8ea9c932f8444151]}</a></li>
                <li {if $action == 'memberlist' || $action == 'invite'}class="a"{/if}><a href="buluo.php?mod=group&action=memberlist&fid=$_G[fid]#groupnav" title=""><p class="wqiconfont wqicon-qun f22 l_h28"></p>{$Tlang[cb652d7e9654f645]}</a></li>
                <li {if $action == 'index' && $_GET[doing]=='dynamic'}class="a"{/if}><a href="buluo.php?mod=group&action=index&doing=dynamic&fid=$_G[fid]#groupnav" ><p class="wqiconfont wqicon-liuyan f18"></p>{$Tlang[b8b54b467f160e57]}</a></li>
                <!--{if $_G['forum']['ismoderator']}-->
                <!--{eval $k++;}-->
                <li {if $action == 'manage'}class="a"{/if}><a href="buluo.php?mod=group&action=manage&fid=$_G[fid]#groupnav"><p class="wqiconfont wqicon-guanli f24 l_h28"></p>{$Tlang[4fb732ea043a312d]}</a></li><!--{/if}-->
            </ul>
        </div>
        <!--{/block}-->
        <div class="tb group_wrap b_bottom group_wrap_{$k}" id="wq_group_index">
            $wq_tag_list
        </div>
        <!--{else}-->
        <p class="emp">
            <span class="no_content"><img src="$_G['style'][styleimgdir]mobile/images/no_content.png"></span>
            {$Tlang[5ed76286893d421b]}
        </p>
        <!--{/if}-->
        <!--{/if}-->
        <!--{if $action == 'index' && $status != 2 && $status != 3}-->
        <!--{template group/group_index}-->
        <!--{elseif in_array($action,array('list','memberlist','create','invite','manage'))}-->
        <!--{eval include template('group/group_'.$action);}-->
        <!--{/if}-->
    </div>
</div>
<!--{else}-->
<!--{if $action == 'index' && $status != 2 && $status != 3}-->
<!--{template group/group_index}-->
<!--{elseif in_array($action,array('list','memberlist','create','invite','manage'))}-->
<!--{eval include template('group/group_'.$action);}-->
<!--{/if}-->
<!--{/if}-->
<!--{eval $wq_footer_hide='1';}-->
<!--{template common/wq_buluo_tpl_footer}-->
<!--{/if}-->