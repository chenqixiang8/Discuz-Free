<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['tag'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{template common/header}-->
<!--{if $type != 'countitem'}-->
<style>body{ background: #f9f9f9;}</style>
<!--{eval
    $headparams['wtype'] = '1';
    $headparams['lurl'] = $backurl;
    $headparams['ltype'] = 'a';
    $headparams['cname'] = $Tlang['6586eca1f3a782c3'];
    echo wq_app_get_header($headparams);
}-->

<form method="post" action="misc.php?mod=tag">
    <div class="wqapp_search_warp">
        <div class="wqapp_search">
            <div class="wqsearch_input wqtag_input"><input type="" name="name"size="30" placeholder="{$Tlang['84b323e823c2664d']}"></div>
              <div class="wqsearch_list_btn y"><button type="submit">{lang search}</button></div>
        </div>
    </div>
</form>
<!-- <div class="wqsearch_warp wqnew_bottom">
            <div class="wqsearch_warp_div">
                 <form method="post" action="misc.php?mod=tag">
                    <div class="wqsearch_warp_input z">
                        <span class="wqsearch_return"><a href="{$backurl}"><i class="wqiconfont2 wqicon2-fanhui-copy-copy wqapp_f22"></i></a></span>
                        <span class="wqsearch_switch"><span><a href="misc.php?mod=tag">{lang tag}</a><em class="wqlabel_line">|</em></span></span>
                        <span class="wqsearch_input2">
                            <input type="" name="name"size="30" placeholder="{$Tlang['84b323e823c2664d']}">
                        </span>
                    </div>
                <div class="wqsearch_list_btn y"><button type="submit" class="wqbg_color wqborder">{lang search}</button></div>
                 </form>
            </div>
        </div>-->
        <div class="wqsearch_keyword wqtag_warp">
        <!--{if $tagarray}-->
              <ul>
                <!--{loop $tagarray $tag}-->
                    <!--{eval $bgcolor=wq_app_setting_set_search_and_label_bgcolor();}-->
                    <li style="background-color: {$bgcolor}"><a href="misc.php?mod=tag&id=$tag[tagid]" title="$tag[tagname]" class="xi2">$tag[tagname]</a></li>
                <!--{/loop}-->
              </ul>
             <!--{else}-->
                <p class="wqemp"><span class="wqno_con"><img src="{$_G['style'][styleimgdir]}images/wqno_con.png"></span>{lang no_tag}</p>
           <!--{/if}-->
        </div>
        <!--{else}-->
        $num
        <!--{/if}-->

<!--{template common/footer}-->

<!--{/if}-->