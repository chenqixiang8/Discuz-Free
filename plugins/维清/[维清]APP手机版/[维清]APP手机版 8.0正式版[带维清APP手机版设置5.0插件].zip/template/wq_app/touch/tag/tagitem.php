<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['tagitem'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{template common/header}-->

<!--{eval
    $headparams['wtype'] = '1';
    $headparams['lurl'] = $backurl;
    $headparams['ltype'] = 'a';
    $headparams['cname'] = $Tlang['6586eca1f3a782c3'] .' - ' .$tagname;
    echo wq_app_get_header($headparams);
}-->

<form method="post" action="misc.php?mod=tag" class="">
<div class="wqapp_search_warp">
    <div class="wqapp_search">
        <div class="wqsearch_input"><input type="" name="name"size="30" placeholder="{$Tlang['84b323e823c2664d']}" value="$tagname"></div>
          <div class="wqsearch_list_btn y"><button type="submit">{lang search}</button></div>
    </div>
</div>
</form>
<!--{if $tagname}-->
    <!--{eval $countthreadlist = count($threadlist);$countbloglist = count($bloglist);}-->
     <!--{if $countbloglist > 0 || $countthreadlist>0}-->
        <div id="ct" class="wqsearch_keyword_warp">
            <!--{if (empty($showtype) || $showtype == 'thread')}-->
             <!--{if $threadlist}-->
            <div class="wqsearch_keyword wqm_top0">
                <h3 class="wqapp_f18 wqbgf9">{lang related_thread}</h3>
            </div>
            <div class="wqindex_list">
                    <ul class="wqindex_list_ul">
                        <!--{loop $threadlist $thread}-->
                        <li class="wqnew_bottom">
                            <a href="forum.php?mod=viewthread&tid=$thread[tid]"class="wqblock">
                                <!--{if $thread[pic]}-->
                                <div class="wqlist1">
                                    <img src="$thread[pic]" alt="$thread[subject]" class="tn" />
                                    <span class="wqlisttu1"><i class="wqiconfont2 wqicon2-tupian-copy wqapp_f14 wqm_right2"></i>2222</span>
                                </div>
                                <!--{/if}-->
                                <div class="<!--{if $thread[pic]}--> wqlisthidden<!--{else}--> wqlist_maxhidden<!--{/if}-->">
                                    <h3 class="wqtitle_list"><font $thread[highlight]>$thread['subject']</font></h3>
                                </div>
                                <p class="list_info">
                                    <span class="wqwidth80">
                                        <!--{if $thread['authorid'] && $thread['author']}-->
                                        $thread[author]
                                        <!--{else}-->
                                        {lang anonymous}
                                        <!--{/if}--></span>
                                    <span class="y"><i class="wqiconfont2 wqicon2-pinglun2 wqapp_f12"></i>$thread[replies]</span>
                                    <span class="y wqm_right10 width80">$thread[dateline]</span>
                                </p>
                            </a>
                        </li>
                        <!--{/loop}-->
                    </ul>
                    <!--{if empty($showtype)}-->
                        <p class="wqmore wqbg_none">
                            <a class="wqblock" href="misc.php?mod=tag&id=$id&type=thread">{$Tlang['b7c43e76ea16b8ed']}</a>
                        </p>
                    <!--{else}-->
                        <!--{if $multipage}--><div class="pgs mtm cl">$multipage</div><!--{/if}-->
                    <!--{/if}-->
                <!--{/if}-->
            </div>
        </div>
    <!--{/if}-->
            <!--{if helper_access::check_module('blog') && (empty($showtype) || $showtype == 'blog')}-->
             <!--{if $bloglist}-->
                <div class="wqsearch_keyword_warp">
                    <div class="wqsearch_keyword wqm_top0">
                        <h3 class="wqapp_f18 wqbgf9">{lang related_blog}</h3>
                    </div>
                    <div class="wqindex_list">
                        <div class="xld xlda">
                            <ul class="wqindex_list_ul">
                                <!--{loop $bloglist $blog}-->
                                <li class="wqnew_bottom">
                                    <a href="home.php?mod=space&uid=$blog[uid]&do=blog&id=$blog[blogid]"class="wqblock" >
                                        <!--{if $blog[pic]}-->
                                        <div class="wqlist1">
                                            <img src="$blog[pic]" alt="$blog[subject]" class="tn" />
                                            <span class="wqlisttu1"><i class="wqiconfont2 wqicon2-tupian-copy wqapp_f14 wqm_right2"></i>22</span>
                                        </div>
                                        <!--{/if}-->
                                        <div class="<!--{if $blog[pic]}--> wqlisthidden<!--{else}--> wqlist_maxhidden<!--{/if}-->">
                                            <h3 class="wqtitle_list">$blog['subject']</h3>
                                        </div>
                                        <p class="list_info"><span class="width70">$blog[username]</span>
                                            <span class="y"><i class="wqiconfont2 wqicon2-pinglun2 wqapp_f12"></i>$blog[replynum]</span>
                                            <span class="y wqm_right10 width80"><!--{eval echo wq_app_dgmdate($blog[dateline])}--></span>
                                        </p>
                                    </a>
                                </li>
                                <!--{/loop}-->
                            </ul>
                        </div>
                            <!--{if empty($showtype)}-->
                                <p class="wqmore wqbg_none">
                                    <a class="wqblock" href="misc.php?mod=tag&id=$id&type=blog">{$Tlang['b7c43e76ea16b8ed']}</a>
                                </p>
                            <!--{else}-->
                                <!--{if $multipage}--><div class="pgs mtm cl">$multipage</div><!--{/if}-->
                            <!--{/if}-->
                        <!--{/if}-->
                </div>
            </div>
             <!--{/if}-->
        <!--{else}-->
            <p class="wqemp"><span class="wqno_con"><img src="{$_G['style'][styleimgdir]}images/wqno_con.png"></span>{lang no_content}</p>
        <!--{/if}-->
    <!--{else}-->
        <div class="wqheight44"></div>
        <p class="wqemp taglist"><span class="wqno_con"><img src="{$_G['style'][styleimgdir]}images/wqno_con.png"></span>{lang empty_tags}</p>
    <!--{/if}-->
<!--{template common/footer}-->
<!--{/if}-->