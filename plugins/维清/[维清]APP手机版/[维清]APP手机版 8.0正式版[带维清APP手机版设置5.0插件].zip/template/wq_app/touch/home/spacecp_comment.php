<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['spacecp_comment'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{if $_G[inajax] && $_GET['op'] == 'edit'}-->
$comment[message]
<!--{eval exit;}-->
<!--{/if}-->
<!--{template common/header}-->
<!--{if !$_G[inajax]}-->
<div id="ct" class="ct2_a wp cl">
    <div class="mn">
        <div class="bm bw0">
            <!--{/if}-->
            <!--{if $_GET['op'] == 'edit'}-->
            <form id="editcommentform_{$cid}" name="editcommentform_{$cid}" method="post" autocomplete="off" action="home.php?mod=spacecp&ac=comment&op=edit&cid=$cid{if $_GET[modcommentkey]}&modcommentkey=$_GET[modcommentkey]{/if}" {if $_G[inajax]} onsubmit="ajaxpost(this.id, 'return_$_GET[handlekey]');"{/if}>
                <input type="hidden" name="referer" value="{echo dreferer()}"/>
                <input type="hidden" name="editsubmit" value="true" />
                <input type="hidden" name="editsubmit_btn" value="true" />
                <!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
                <input type="hidden" name="formhash" value="{FORMHASH}" />

                <!--{eval
                    $headparams['wtype'] = '2';

                    $headparams['ltype'] = 'cancel';
                    $headparams['lname'] = $Tlang['9c825be7149e5b97'];
                    $headparams['lurl'] = 'javascript:void(0);';

                    $headparams['ctype'] = 'span';
                    $headparams['cname'] =$Tlang['9a150d4af72d7358'];

                    $headparams['rtype'] = 'but';
                    $headparams['rname'] = lang('home/template','submit');
                    $headparams['rclass'] = 'formdialog';
                    $headparams['rid'] = 'postsubmit';

                    echo wq_app_get_header($headparams, false, true) ;
                }-->
                <div class="wqpost_list">
                    <ul class="wqpost_list_ul">
                        <li class="post_con wqnew_bottom">
                            <textarea id="needmessage"  cols="70"   rows="8" class="wqpost_textarea" style=" height: 120px;">$comment[message]</textarea>
                            <input type="hidden" id="wq_needmessage"  name="message">
                            <div class="wqpost_upload"><span class="wqiconfont2 wqicon2-biaoqing wqapp_f26 wqbiaoqing"></span>
                            </div>
                             <!--{template common/upload_image}-->
                        </li>
                    </ul>
                       <!--{template common/smilies}-->
                </div>
            </form>
            <script>
                var message = $('#needmessage').val();
                message = message.replace(/\n?\[img\]\s*([^\[\<\r\n]+?)\s*\[\/img\]\n?/gi, function (match, capture) {
                    wq_capture = $.trim(capture.replace('$_G[siteurl]', ''));
                    var img = $('img[data="' + wq_capture + '"]').attr('dataid');
                    if (img) {
                        return  '[em:' + img + ':]';
                    } else {
                        return match.replace('amp;', '');
                    }
                });

                $('#needmessage').val(message);
                function expression_insertunit(obj) {
                    var id_val = $('#needmessage').val();
                    $('#needmessage').val(id_val + '[em:' + obj.attr('sid') + ':]');
                    postsubmit_button();
                }
                function postsubmit_button() {
                    $('#postsubmit').attr('disabled', ($.trim($('#needmessage').val()) ? null : 'disabled'));
                }

                $('#needmessage').on('keyup input', function () {
                    postsubmit_button();
                });
                $('.wqexpression').on('click', function () {
                    $(this).toggleClass('c_jianpan');
                    if ($('.cellphone_expression').is(':hidden')) {
                        $('.cellphone_expression').show();
                        expression_viwepager();
                    } else {
                        $('.cellphone_expression').hide();
                    }
                });
                $('#postsubmit').on('click', function () {
                    var needmessage = $('#needmessage').val();
                    needmessage = needmessage.replace(/\[em:([0-9]+):\]/gi, function (match, capture) {
                        var img = $('img[dataid="' + capture + '"]').attr('data');
                        if (img) {
                            return wq_capture = '[img]' + img + '[/img]';
                        } else {
                            return match;
                        }
                    });
                    $('#wq_needmessage').val(needmessage);
                    $('#wq_postsubmit').click();
                });
                        function succeedhandle_editcommentform_{$cid} (url, message, values) {
                            clearTimeout(setTimeout_location);
                            setTimeout_location = setTimeout(function() {
                                location.replace(url);
                            }, '1000');
                        }
                $('.wqbiaoqing').on('click', function () {
                    $(this).toggleClass('wqicon2-jianpan');
                    if ($('.cellphone_expression').is(':hidden')) {
                        $('#imglist').hide();
                        $('.cellphone_expression').show();
                        $('#upload_icon').removeClass('blue');
                        $('.wqbiaoqing').removeClass('wqicon2-biaoqing');
                        expression_viwepager();
                    } else {
                        $('.cellphone_expression').hide();
                        $('.wqbiaoqing').addClass('wqicon2-biaoqing');
                    }
                });
                function expression_insertunit(obj) {
                    var id_val = $('.wqpost_textarea').val();
                    $('.wqpost_textarea').val(id_val + obj.attr('code'));
                }
                deleteSmilies('{:', ':}');

            </script>
            <!--{eval $nofooter=1;}-->
            <!--{elseif $_GET['op'] == 'delete'}-->
            <div class="wqshield_notice">
                <form id="deletecommentform_{$cid}" name="deletecommentform_{$cid}" method="post" autocomplete="off" action="home.php?mod=spacecp&ac=comment&op=delete&cid=$cid" {if $_G[inajax]}onsubmit="ajaxpost(this.id, 'return_$_GET[handlekey]');"{/if}>
                      <input type="hidden" name="referer" value="{echo dreferer()}" />
                    <input type="hidden" name="deletesubmit" value="true" />
                    <input type="hidden" name="formhash" value="{FORMHASH}" />
                    <!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->

                    <div class="wqshield_con"><p>{lang delete_reply_message}</p></div>
                    <p class="wqbtn_can wqnew_top">
                        <a href="javascript:;" onclick="popup.close();" class="wqeject_cancel wqnew_right">{lang cancel}</a>
                        <button type="submit" name="deletesubmitbtn" value="true" class="formdialog wqdetermine">{lang determine}</button>

                    </p>
                </form>
            </div>
            <!--{elseif $_GET['op'] == 'reply'}-->
            <div class="shield_notice">
                <form id="replycommentform_{$comment[cid]}" name="replycommentform_{$comment[cid]}" method="post" autocomplete="off" action="home.php?mod=spacecp&ac=comment" {if $_G[inajax]} onsubmit="ajaxpost('replycommentform_{$comment[cid]}', 'return_$_GET[handlekey]');"{/if}>
                      <input type="hidden" name="referer" value="{echo dreferer()}" />
                    <input type="hidden" name="id" value="$comment[id]" />
                    <input type="hidden" name="idtype" value="$comment[idtype]" />
                    <input type="hidden" name="cid" value="$comment[cid]" />
                    <input type="hidden" name="commentsubmit" value="true" />
                    <!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
                    <input type="hidden" name="formhash" value="{FORMHASH}" />
                    <div id="reply_msg_{$comment[cid]}">
                        <div class="c">
                            <p>
                                <label for="message">{lang content}:</label>
                                <span id="replyface_{$comment[cid]}" onclick="showFace(this.id, 'message_pop_{$comment[cid]}');
                                        return false;" class="cur1"><img src="{IMGDIR}/facelist.gif" alt="facelist" class="vm" /></span>
                                <!--{if $_G['setting']['magicstatus'] && !empty($_G['setting']['magics']['doodle'])}-->
                                <span id="editdoodle_{$cid}" onclick="showWindow(this.id, 'home.php?mod=magic&mid=doodle&showid=comment_doodle&target=message_pop_{$comment[cid]}', 'get', 0)" class="cur1"><img src="{STATICURL}image/magic/doodle.small.gif" alt="doodle" class="vm" />{$_G[setting][magics][doodle]}</span>
                                <!--{/if}-->
                            </p>
                            <textarea id="message_pop_{$comment[cid]}" name="message" onkeydown="ctrlEnter(event, 'commentsubmit_btn');" rows="8" cols="70" class="pt mtn"></textarea>
                            <!--{if $secqaacheck || $seccodecheck}-->
                            <!--{block sectpl}--><sec> <span id="sec<hash>" onclick="showMenu({'ctrlid': this.id, 'win': '{$_GET[handlekey]}'});"><sec></span><div id="sec<hash>_menu" class="p_pop p_opt" style="display:none"><sec></div><!--{/block}-->
                            <div class="mtm mbm"><!--{subtemplate common/seccheck}--></div>
                            <!--{/if}-->
                        </div>
                        <p class="o pns">
                            <button type="submit" name="commentsubmit_btn" id="commentsubmit_btn" value="true" class="pn pnc">{lang reply}</button>
                            <a href="javascript:;" onclick="popup.close();" class="eject_cancel">{lang cancel}</a>
                        </p>
                    </div>
                </form>
            </div>
            <script type="text/javascript">
                function succeedhandle_$_GET['handlekey'] (url, message, values) {
<!--{if $comment['idtype']!='uid'}-->
<!--{if $_GET['feedid']}-->
                    feedcomment_add(values['cid'], $_GET['feedid']);
<!--{else}-->
                    comment_add(values['cid']);
<!--{/if}-->
<!--{/if}-->
                }
            </script>
            <!--{/if}-->
            <!--{if !$_G[inajax]}-->
        </div>
    </div>
</div>
<!--{/if}-->

<!--{template common/footer}-->

<!--{/if}-->