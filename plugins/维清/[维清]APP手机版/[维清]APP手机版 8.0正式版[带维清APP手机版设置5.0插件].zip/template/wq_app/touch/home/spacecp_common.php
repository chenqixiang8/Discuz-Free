<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['spacecp_common'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{template common/header}-->
<!--{if !$_G[inajax]}-->
<div id="ct" class="ct2_a wp cl">
	<div class="mn">
		<div class="bm bw0">
			<!--{/if}-->
			<!--{if $_GET['op'] == 'ignore'}-->
			<div class="wqshield_notice">
				<form method="post" autocomplete="off" id="wq_ignoreform" name="ignoreform_{$formid}" action="home.php?mod=spacecp&ac=common&op=ignore&type=$type" >
					  <!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
					<input type="hidden" name="ignoresubmit" value="true" />
					<input type="hidden" name="formhash" value="{FORMHASH}" />
					<input type="hidden" name="referer" value="{echo dreferer()}">
					<div class="wqshield_con">
						<p>{lang no_view_notice_next}</p>
						<p class="ptn">
                                                    <input class="weui_check" type="radio" name="authorid" id="authorid1"  value="$_GET[authorid]" checked="checked"/>
							<label class="weui_check_label" for="authorid1"><i class="weui_icon_checked"></i>{lang shield_this_friend}</label>
						</p>
						<p class="ptn">
                                                    <input class="weui_check" type="radio" name="authorid" id="authorid0" value="0"/>
							<label class="weui_check_label" for="authorid0"><i class="weui_icon_checked"></i>{lang shield_all_friend}</label>
						</p>
					</div>
					<p class="wqbtn_can wqnew_top">
                                            <a href="javascript:;" onclick="popup.close();"  class="wqeject_cancel wqnew_right">{lang cancel}</a>
                                            <input type="submit" name="feedignoresubmit" value="{lang determine}" class="formdialog wqdetermine">
					</p>
				</form>
			</div>
			<!--{elseif $_GET['op'] == 'getuserapp'}-->

			<!--{loop $my_userapp $value}-->
			<!--{if $value['allowsidenav']}-->
			<li><!--{if $value[appstatus]}--><span class="{if $value[appstatus]==1}appnew{else}apphot{/if}"></span><!--{/if}--><a href="userapp.php?mod=app&id=$value[appid]"><img {if $value[icon]}src="$value[icon]" onerror="this.onerror=null;this.src='http://appicon.manyou.com/icons/$value[appid]'"{else} src="http://appicon.manyou.com/icons/$value[appid]"{/if}>$value[appname]</a></li>
			<!--{/if}-->
			<!--{/loop}-->
			<!--{elseif $_GET['op']=='modifyunitprice'}-->


			<form method="post" autocomplete="off" id="ignoreform_{$formid}" name="ignoreform_{$formid}" action="home.php?mod=spacecp&ac=common&op=modifyunitprice" {if $_G[inajax]}onsubmit="ajaxpost(this.id, 'return_$_GET[handlekey]');"{/if}>
				  <!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
				<input type="hidden" name="modifysubmit" value="true" />
				<input type="hidden" name="formhash" value="{FORMHASH}" />
				<input type="hidden" name="referer" value="{echo dreferer()}">
				<div class="wqshield_notice">
					<p>{lang modify_unitprice_note}</p>
					<p class="ptn"><label>{lang bid_single_price}: <input type="text" name="unitprice" class="px" value="$showinfo[unitprice]" /></label></p>
				</div>
				<p class="wqbtn_can wqnew_top">
                                    <a href="javascript:;" onclick="popup.close();" class="wqeject_cancel wqnew_right">{lang cancel}</a>
					<button type="submit" name="unitpriceysubmit" value="true" class="wqdetermine">{lang determine}</button>
				</p>
			</form>
			<script type="text/javascript">
				function succeedhandle_$_GET['handlekey'] (url, message, values) {
					var priceObj = $('show_unitprice');
					if (priceObj) {
						priceObj.innerHTML = values['unitprice'];
					}

				}
			</script>
			<!--{/if}-->
			<!--{if !$_G[inajax]}-->
		</div>
	</div>
</div>
<!--{/if}-->
<!--{template common/footer}-->
<!--{/if}-->