<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['space_thread'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{template common/header}-->

    <!--{block headname}-->
        <ul>
            <li<!--{if $_GET['type'] != 'reply'}--> class="wqon"<!--{/if}-->><a href="home.php?mod=space&uid={$space[uid]}&do=thread&view=me&type=thread" >{$Tlang['ef4d4e21186f4b9c']}</a></li>
            <li<!--{if $_GET['type'] == 'reply'}--> class="wqon2"<!--{/if}-->><a href="home.php?mod=space&uid={$space[uid]}&do=thread&view=me&type=reply">{$Tlang['0a40f81498299a4b']}</a></li>
        </ul>
    <!--{/block}-->
    <!--{eval
        $headparams['wtype'] = '2';
        $headparams['ltype'] = 'fh';
        $headparams['lclass'] = 'wqmenu';
        $headparams['lurl'] = $backurl;
	$headparams['ctype'] = 'div';
        $headparams['cname'] =$headname;

        echo wq_app_get_header($headparams, false) ;
    }-->

<!--{if $list}-->
<!--{eval
    $new_tids = get_wq_app_tids($list);
    $new_threadlists= wq_app_get_thread_info_from_cache($new_tids);
}-->
<div class="wqindex_list">
    <ul class="wqindex_list_ul">
        <!--{loop $list $stid $thread}-->
        <!--{eval
            $imagenum = $new_threadlists[$thread['tid']]['imagenum'];
            $images= $imagenum > 0 ? wq_app_setting_get_pic($new_threadlists[$thread['tid']]['maximgs'],$new_threadlists[$thread['tid']]['images'],4,1) : array();
        }-->
            <!--{if $viewtype == 'reply' || $viewtype == 'postcomment'}-->
            <li class="wqnew_bottom">
            <a href="forum.php?mod=redirect&goto=findpost&ptid=$thread[tid]&pid=$thread[pid]" class="wqblock">
                <div class="wqlist_maxhidden">
                    <h3 class="wqtitle_list">
                        <!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
                           <span class="wqicon_all_14 wqicon_top">$Tlang['4d3aee3cefdbf4b8']</span>
                        <!--{/if}-->
                        <!--{if $thread['digest'] > 0}-->
                            <span class="wqicon_all_14 wqicon_digest">$Tlang['4431e4914edfce71']</span>
                        <!--{/if}-->
                        <!--{if $thread['attachment'] == 2 && $_G['setting']['mobile']['mobilesimpletype'] == 0 && in_array($showmodel, array("m", "0"))}-->
                            <span class="wqicon_all_14 wqicon2-tupian wqicon_tucolor">$Tlang['d09806a34575d52c']</span>
                        <!--{/if}-->
                        <!--{if $thread['weeknew']}-->
                            <span class="wqicon_all_14 wqicon_xin">$Tlang['de8128f785039560']</span>
                        <!--{/if}-->
                        <!--{if $thread['heatlevel']}-->
                            <span class="wqicon_all_14 wqicon_hot">$Tlang['03a43059cdc3dcad']</span>
                        <!--{/if}-->

                        <!--{if $thread['folder'] == 'lock'}-->
                            <span class="wqicon_all_14 wqicon_gb">$Tlang['beb08d096719774b']</span>
                        <!--{elseif $thread['special'] == 1}-->
                            <span class="wqicon_all_14 wqicon_vote">$Tlang['a1e86aeac9394d67']</span>
                        <!--{elseif $thread['special'] == 2}-->
                            <span class="wqicon_all_14 wqicon_sell">$Tlang['0907c7cfc9d2cf2b']</span>
                        <!--{elseif $thread['special'] == 3}-->
                            <span class="wqicon_all_14 wqicon_reward">$Tlang['655aa530ba4d16cf']</span>
                        <!--{elseif $thread['special'] == 4}-->
                            <span class="wqicon_all_14 wqicon_activity">$Tlang['2e5409eeacda8839']</span>
                        <!--{elseif $thread['special'] == 5}-->
                            <span class="wqicon_all_14 wqicon_debate"> $Tlang['5cbc8ce0fb1e25e0']</span>
                        <!--{/if}-->
                        $thread[subject]
                    </h3>
                </div>
                 </a>
                 <!--{loop $tids[$stid] $pid}-->
                    <p class="wqthread_findpost">
                        <a href="forum.php?mod=redirect&goto=findpost&ptid=$thread[tid]&pid=$pid" class="wqblock">
                            <!--{eval $post = $posts[$pid];}--><!--{if $post[message]}-->"{$post['message']}"<!--{else}-->......<!--{/if}-->
                        </a>
                    </p>
                <!--{/loop}-->
                <p class="list_info"><span>{$thread[lastpost]}</span>
                    <span class="y"><i class="wqiconfont2 wqicon2-pinglun2 wqapp_f12"></i>{$thread[replies]}</span>
                    <span class="y wqm_right10"><i class="wqiconfont2 wqicon2-p-see wqapp_f12"></i><!--{if $thread['isgroup'] != 1}-->$thread[views]<!--{else}-->{$groupnames[$thread[tid]][views]}<!--{/if}--></span>
                </p>


            </li>
            <!--{else}-->
            <li class="wqnew_bottom">
            <a href="forum.php?mod=viewthread&tid=$thread[tid]"class="wqblock">
                 <!--{if $imagenum}-->
                 <div class="wq-lazyload-container wqintelligent1">
                     <img  src="$_G['style'][styleimgdir]images/wq_dian.jpg" data-src="$images[0]" alt="$thread[subject]" class="tn wq_js_delayload" />
                </div>
                 <!--{/if}-->
                <div class="<!--{if $imagenum}-->wqlisthiddenp<!--{else}-->wqlist_maxhidden<!--{/if}-->">
                    <h3 class="wqtitle_list">

                        <!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
                            <span class="wqicon_all_14 wqicon_top">$Tlang['4d3aee3cefdbf4b8']</span>
                        <!--{/if}-->
                        <!--{if $thread['digest'] > 0}-->
                            <span class="wqicon_all_14 wqicon_digest">$Tlang['4431e4914edfce71']</span>
                        <!--{/if}-->
                        <!--{if $thread['attachment'] == 2 && $_G['setting']['mobile']['mobilesimpletype'] == 0 && in_array($showmodel, array("m", "0"))}-->
                            <span class="wqicon_all_14 wqicon2-tupian wqicon_tucolor">$Tlang['d09806a34575d52c']</span>
                        <!--{/if}-->
                        <!--{if $thread['weeknew']}-->
                            <span class="wqicon_all_14 wqicon_xin">$Tlang['de8128f785039560']</span>
                        <!--{/if}-->
                        <!--{if $thread['heatlevel']}-->
                            <span class="wqicon_all_14 wqicon_hot">$Tlang['03a43059cdc3dcad']</span>
                        <!--{/if}-->

                        <!--{if $thread['folder'] == 'lock'}-->
                            <span class="wqicon_all_14 wqicon_gb">$Tlang['beb08d096719774b']</span>
                        <!--{elseif $thread['special'] == 1}-->
                            <span class="wqicon_all_14 wqicon_vote">$Tlang['a1e86aeac9394d67']</span>
                        <!--{elseif $thread['special'] == 2}-->
                            <span class="wqicon_all_14 wqicon_sell">$Tlang['0907c7cfc9d2cf2b']</span>
                        <!--{elseif $thread['special'] == 3}-->
                            <span class="wqicon_all_14 wqicon_reward">$Tlang['655aa530ba4d16cf']</span>
                        <!--{elseif $thread['special'] == 4}-->
                            <span class="wqicon_all_14 wqicon_activity">$Tlang['2e5409eeacda8839']</span>
                        <!--{elseif $thread['special'] == 5}-->
                            <span class="wqicon_all_14 wqicon_debate"> $Tlang['5cbc8ce0fb1e25e0']</span>
                        <!--{/if}-->

                        $thread[subject]
                    </h3>
                </div>
                <p class="list_info"><span>{$thread[lastpost]}</span>
                    <span class="y"><i class="wqiconfont2 wqicon2-pinglun2 wqapp_f12"></i>{$thread[replies]}</span>
                    <span class="y wqm_right10"><i class="wqiconfont2 wqicon2-p-see wqapp_f12"></i><!--{if $thread['isgroup'] != 1}-->$thread[views]<!--{else}-->{$groupnames[$thread[tid]][views]}<!--{/if}--></span>
                </p>
            </a>
            </li>
            <!--{/if}-->
        <!--{/loop}-->
    </ul>
    {$multi}
</div>
<!--{else}-->
<p class="wqemp">{lang no_related_posts}</p>
<!--{/if}-->

<!--{template common/footer}-->

<!--{/if}-->