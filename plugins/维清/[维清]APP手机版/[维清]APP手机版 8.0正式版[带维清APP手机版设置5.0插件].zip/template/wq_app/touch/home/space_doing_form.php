<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['space_doing_form'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<div id="moodfm" class="wq_doing_warp">
    <form method="post" autocomplete="off" id="mood_addform" action="home.php?mod=spacecp&ac=doing&view=$_GET[view]" onsubmit="if(!$('#message').val()){return false;}">
        <div id="mood_statusinput" class="wq_moodfm_input">
            <textarea name="message" id="message" class="xg1" rows="4" placeholder="{$defaultstr}"></textarea>
        </div>
        <div class="wq_doing_biaoqing">
            <div class="wqpost_upload">
                <span class="wqiconfont2 wqapp_f26 wqbiaoqing wqicon2-biaoqing"></span>
            </div>
            <!--{if $_GET[action] != 'edit' && ($secqaacheck || $seccodecheck)}-->
                <!--{subtemplate common/seccheck}-->
            <!--{/if}-->
            <!--{template common/smilies}-->
        </div>
        <div class="wq_doing_btn"><button type="submit" name="add" class="button2" id="add">{lang publish}</button></div>
        <div class="wq_moodfm_f">
                <!--{if $_G['group']['maxsigsize']}-->
                        <input type="checkbox" name="to_signhtml" id="to_sign" class="weui_check" value="1">
                        <label class="weui_check_label wqblock" for="to_sign"><i class="weui_icon_checked"></i>{lang doing_update_personal_signature}</label>
                <!--{/if}-->
        </div>
        <input type="hidden" name="addsubmit" value="true" />
        <input type="hidden" name="refer" value="$theurl" />
        <input type="hidden" name="topicid" value="$topicid" />
        <input type="hidden" name="formhash" value="{FORMHASH}" />
    </form>
</div>
<script>
    $('.wqbiaoqing').on('click', function () {
        $(this).toggleClass('wqicon2-jianpan');
        if ($('.cellphone_expression').is(':hidden')) {
            $('.cellphone_expression').show();
            $('.wqbiaoqing').removeClass('wqicon2-biaoqing');
            expression_viwepager();
        } else {
            $('.cellphone_expression').hide();
            $('.wqbiaoqing').addClass('wqicon2-biaoqing');
        }
    });
    function expression_insertunit(obj) {
        var id_val = $('#message').val();
        $('#message').val(id_val + obj.attr('code'));
    }
    deleteSmilies('{:', ':}');
</script>
<!--{/if}-->