<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['space_album_list'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{eval $friendsname = array(1 => '{lang friendname_1}',2 => '{lang friendname_2}',3 => '{lang friendname_3}',4 => '{lang friendname_4}');}-->
<!--{eval $header_nav = $header_nav_app = 'null';}-->
<!--{template common/header}-->

    <!--{if $_G[uid]}-->
        <!--{eval  $headparams['lurl'] = 'javascript: history.go(-1)';}-->
    <!--{else}-->
        <!--{eval  $headparams['lurl'] = 'member.php?mod=logging&action=login';}-->
    <!--{/if}-->
    <!--{eval $headright = false;}-->
    <!--{if helper_access::check_module('album') && $space[self]}-->
        <!--{eval $headright = true;}-->
        <!--{if $space[self] && $_GET['view']=='me'}-->
            <!--{if $count}-->
                <!--{eval
                    $headparams['rname'] = $Tlang['79d7cd1dfdbdd11e'];
                    $headparams['rurl'] = 'home.php?mod=spacecp&ac=upload&albumid='.$album['albumid'];
                }-->
            <!--{else}-->
                <!--{eval
                    $headparams['rname'] = $Tlang['bab286385e559395'];
                    $headparams['rurl'] = 'home.php?mod=spacecp&ac=upload&do=create';
                }-->
            <!--{/if}-->
        <!--{/if}-->
    <!--{/if}-->
    <!--{eval
        $headparams['wtype'] = '1';
        $headparams['ltype'] = 'a';
        $headparams['cname'] = $Tlang['6be0b791b8a8138f'];
        $headparams['rtype'] = 'a';
        $headparams['rclass'] = 'wqapp_f16';

        echo wq_app_get_header($headparams,true,$headright);
    }-->

    <!--{if $space[uid]==$_G[uid]}-->
    <div class="appl my_album_list">
        <div class="tbn tag_list">
            <ul>
                <li$actives[we]><a href="home.php?mod=space&do=album&view=we">{lang friend_album}</a></li>
                <li$actives[me]><a href="home.php?mod=space&do=album&view=me">{lang my_album}</a></li>
                <li$actives[all]><a href="home.php?mod=space&do=album&view=all">{lang view_all}</a></li>
            </ul>
        </div>
    </div>
    <!--{/if}-->
    <!--{if ($_GET['view'] == 'we') && $userlist}-->
    <div class="appl my_album_list casual_see">
        <select name="fuidsel" onchange="fuidgoto(this.value);" class="ps">
            <option value="">{lang all_friends}</option>
            <!--{loop $userlist $value}-->
            <!--{eval $k++;}-->
            <option value="$value[fuid]"{$fuid_actives[$value[fuid]]}>$value[fusername]</option>
            <!--{/loop}-->
        </select>
    </div>
    <!--{/if}-->
    <!--{if $count}-->
    <div class="mn">
        <!--{eval $k=0;}-->
        <!--{block navHtml}-->
        <!--{/block}-->
        <!--{if $k}-->
        <div class="tbmu cl casual_see my_blog_tag p_l10" id="my_album_tag">
            $navHtml
        </div>
        <!--{if $k>2}-->
        <!--{eval $wq_slide=1;$my_group_tag='my_album_tag';}-->
        <!--{template common/slide}-->
        <!--{/if}-->
        <!--{/if}-->
        <div class="ptw album_list clearfixed">
            <!--{if $space[self] && $_GET['view']=='me'}-->
            <!--{block default_album}-->
            <li class="wqnew_all">
                <a href="home.php?mod=space&uid=$value[uid]&do=album&id=-1">
                    <div class="c">
                        <img src="template/wq_app/static/images/default_album.png" alt="{lang default_album}" />
                    </div>
                    <div class="ptn" style=" text-align: center"><em class="xi2">{lang default_album}</em></div>
                </a>
            </li>
            <!--{/block}-->
            <!--{/if}-->
            <ul class="ml mla cl">
                <!--{if $count}-->
                <!--{loop $list  $key $value}-->
                <!--{eval $wq_lists[$value['uid']][]=$value;
                     $wq_username[$value['uid']]=$value['username'];}-->
                <!--{/loop}-->
                <!--{loop $wq_lists $uid $list}-->
                <div class="{if $_GET[view]!='me'}album_list_div  album_list_bottom b_bottom{/if}">
                    <!--{loop $list $key $value}-->
                    <li class="wqnew_all">
                        <a href="home.php?mod=space&uid=$value[uid]&do=album&id=$value[albumid]" >
                            <div class="c">
                                <!--{if $value[pic]}-->
                                <img src="$value[pic]" alt="$value[albumname]" />
                                <!--{/if}-->
                            </div>
                            <div class="ptn">
                                <em class="width100">
                                    <!--{if $value[albumname]}-->
                                    $value[albumname]
                                    <!--{else}-->
                                    {lang default_album}
                                    <!--{/if}--></em>
                                <span>
                                    <!--{if $value[picnum]}-->
                                    $value[picnum]
                                    <!--{/if}-->
                                </span>
                            </div>
                            <!--{if $friendsname[$value[friend]]}-->
<!--{eval $friendsClass = array(1 => 'wqicon2-haoyou',2 => 'wqicon-haoyou2 wqapp_f13 zhidinghy',3 => 'wqicon2-mimas wqapp_f14',4 => 'wqicon2-changjianwenti wqapp_f12');}-->
                            <div class="album_visual"><i class="wqiconfont2 $friendsClass[$value[friend]]"></i>$friendsname[$value[friend]]</div>
                            <!--{/if}-->
                        </a>
                    </li>
                    <!--{/loop}-->
                </div>
                <!--{/loop}-->
                $default_album
                <!--{if $multi}--><div class="pgs cl mtm">$multi</div><!--{/if}-->
                <!--{else}-->
                <!--{if $space[self] && $_GET['view']=='me'}-->
                $default_album
                <!--{else}-->
                <!--{echo wq_touch_no_content('home/template','no_album');}-->
                <!--{/if}-->
            </ul>
            <!--{/if}-->
        </div>
    </div>

 <!--{else}-->
<p class="wqemp"><span class="wqno_con"><img src="{$_G['style'][styleimgdir]}images/wqno_con.png"></span>{lang no_album}</p>
 <!--{/if}-->
<script>
    function fuidgoto(fuid) {
        location.href = 'home.php?mod=space&do=album&view=we' + (fuid != '' ? '&fuid=' + fuid : '');
    }
</script>

<!--{template common/footer}-->
<!--{/if}-->