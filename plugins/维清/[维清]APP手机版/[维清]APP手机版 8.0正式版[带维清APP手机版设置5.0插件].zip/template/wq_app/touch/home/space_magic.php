<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['space_magic'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{template common/header}-->
    <!--{eval
        $headparams['wtype'] = '1';
        $headparams['lurl'] = $backurl;
        $headparams['ltype'] = 'a';
        $headparams['cname'] = $Tlang['9750e35d7e3c69f0'];
        echo wq_app_get_header($headparams);
    }-->
    <div class="appl my_shop_list">
        <div class="tbn tag_list">
            <ul>
               <!--{if $_G['group']['allowmagics']}--><li$actives[shop]><a href="home.php?mod=magic&action=shop">{lang magics_shop}</a></li><!--{/if}-->
                <li$actives[mybox]><a href="home.php?mod=magic&action=mybox">{lang magics_user}</a></li>
                <li$actives[log]><a href="home.php?mod=magic&action=log&operation=uselog">{lang magics_log}</a></li>
                <!--{hook/magic_nav_extra}-->
            </ul>
        </div>
    </div>
    <div class="mn">
		<div class="bm bw0">
			<!--{if !$_G['setting']['magicstatus'] && $_G['adminid'] == 1}-->
				<div class="emp">{lang magics_tips}</div>
			<!--{/if}-->
			<!--{if $action == 'shop'}-->
				<!--{subtemplate home/space_magic_shop}-->
			<!--{elseif $action == 'mybox'}-->
				<!--{subtemplate home/space_magic_mybox}-->
			<!--{elseif $action == 'log'}-->
				<!--{subtemplate home/space_magic_log}-->
			<!--{/if}-->
		</div>
	</div>

<!--{template common/footer}-->
<!--{/if}-->