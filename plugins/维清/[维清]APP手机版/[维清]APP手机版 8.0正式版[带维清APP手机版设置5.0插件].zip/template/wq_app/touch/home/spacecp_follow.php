<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['spacecp_follow'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{if $_GET['op'] == 'delete'}-->
<div class="wqshield_notice">
    <form method="post" autocomplete="off" id="deletefeed_{$_GET['feedid']}" name="deletefeed_{$_GET['feedid']}" action="home.php?mod=spacecp&ac=follow&op=delete&feedid=$_GET['feedid']" {if $_G[inajax]}onsubmit="ajaxpost(this.id, 'return_$_GET[handlekey]');"{/if}>
	<input type="hidden" name="referer" value="{echo dreferer()}" />
	<input type="hidden" name="deletesubmit" value="true" />
	<input type="hidden" name="formhash" value="{FORMHASH}" />
	<!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
        <div class="c altw mtm mbm">{lang follow_del_feed_confirm}</div>
        <p class="wqbtn_can wqnew_top">
            <a href="javascript:;" onclick="popup.close();" class="wqeject_cancel wqnew_right">{lang cancel}</a>
            <button type="submit" name="btnsubmit" value="true" class="wqdetermine formdialog">{lang determine}</button>
        </p>
    </form>
</div>
<!--{eval exit();}-->
<!--{/if}-->
<!--{if $_GET['op'] == 'relay'}-->
<div class="wqshield_notice">
    <form method="post" autocomplete="off" id="postform_{$tid}" action="home.php?mod=spacecp&ac=follow&op=relay&tid=$tid" {if $_G[inajax]}onsubmit="ajaxpost(this.id, 'return_$_GET[handlekey]');"{/if}>
	<input type="hidden" name="relaysubmit" value="true" />
        <input type="hidden" name="referer" value="{echo dreferer()}" />
        <input type="hidden" name="formhash" value="{FORMHASH}" />
        <input type="hidden" name="tid" value="$tid" />
        <!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
        <div class="wqshield_con" style="padding:0px 10px;">
            <div class='wqbo_textarea wqnew_all'><textarea id="note_{$tid}" name="note" class="wqtextarea" cols="50" rows="4" onkeyup="strLenCalc(this, 'checklen{$tid}', 140);"></textarea></div>
        </div>
        <p class="wqword_count">
            {lang follow_can_enter}<span id="checklen{$tid}" class="xg1 wqword_count">140</span>{lang follow_word}
        </p>
        <p style="text-align: left;margin-top: 10px; padding-left:10px;">
            <input class="weui_check" id="iscomment" type="checkbox" name="addnewreply" value="1" style="display:none;"/>
            <label class="weui_check_label" for="iscomment"><i class="weui_icon_checked i_middle"></i>
                {lang post_add_inonetime}
            </label>
        </p>
        <p class="wqbtn_can wqnew_top">
            <a href="javascript:;" onclick="popup.close();" class="wqeject_cancel wqnew_right">{lang cancel}</a>
            <button type="submit" name="relaysubmit_btn" id="relaysubmit_btn" class="wqdetermine formdialog" value="true" tabindex="23"><span>{lang follow_reply}</span></button>
        </p>
        <!--{if $secqaacheck || $seccodecheck}-->
        <!--{block sectpl}--><sec> <span id="sec<hash>"><sec></span><div id="sec<hash>_menu" class="p_pop p_opt" style="display:none"><sec></div><!--{/block}-->
        <div class="mtm sec"><!--{subtemplate common/seccheck}--></div>
        <!--{/if}-->
        <div id="return_$_GET[handlekey]"></div>
    </form>
</div>
<!--{eval exit();}-->
<!--{/if}-->
<!--{/if}-->