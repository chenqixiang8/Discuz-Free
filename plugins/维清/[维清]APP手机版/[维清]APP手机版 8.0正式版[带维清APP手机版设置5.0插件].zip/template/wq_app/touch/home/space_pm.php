<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['space_pm'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{eval $_G['home_tpl_titles'] = array('{lang pm}');}-->
<!--{template common/header}-->
<!--{if in_array($filter, array('privatepm','announcepm')) || in_array($_GET[subop], array('view','viewg'))}-->
<!--{if in_array($filter, array('privatepm','announcepm'))}-->
    <!--{block headname}-->
        <ul>
            <li <!--{if $filter=='privatepm'}--> class="wqon"<!--{/if}-->>
                <a href="home.php?mod=space&do=pm&filter=privatepm">
                    {lang private_pm}
                </a>
            </li>
            <li <!--{if $filter=='announcepm'}--> class="wqon2"<!--{/if}-->>
                <a href="home.php?mod=space&do=pm&filter=announcepm">
                    {lang announce_pm}
                </a>
            </li>
        </ul>
    <!--{/block}-->
    <!--{eval
        $headparams['wtype'] = '2';
        $headparams['ltype'] = 'fh';
        $headparams['lclass'] = 'wqmenu';
        $headparams['lurl'] = $backurl;
	$headparams['ctype'] = 'div';
        $headparams['cname'] =$headname;

        echo wq_app_get_header($headparams, false) ;
    }-->


<!-- main pmlist start -->
<!--{if $list}-->
<div class="wqprivate_news">
    <ul>
        <!--{loop $list $key $value}-->
        <li class="wqnew_bottom">
            <a href="{if $value[touid]}home.php?mod=space&do=pm&subop=view&touid=$value[touid]{else}home.php?mod=space&do=pm&subop=view&plid={$value['plid']}&type=1{/if}" class="wqblock">
            <!--{if $value[isnew]}--><span class="wqnum"style="padding: 1px 6px;top: 10px;">$value[isnew]</span><!--{/if}-->
                <img class="wqimg" src="<!--{if $value[pmtype] == 2}-->{STATICURL}image/common/grouppm.png<!--{else}--><!--{avatar($value[touid] ? $value[touid] : ($value[lastauthorid] ? $value[lastauthorid] : $value[authorid]), small, true)}--><!--{/if}-->" />
                <h2 class="wqname wqellipsis"> <!--{if $value[touid]}-->{$value[tousername]}<!--{elseif $value['pmtype'] == 2}-->$value['firstauthor']
                    <!--{/if}--></h2>
                </a>
                <p class="wqhead_info wqellipsis">
                  <span class="y wqapp_f14 wqlh_28 wq_grey wqm_left10">
                      <a class="dialog wq_grey" href="home.php?mod=spacecp&ac=pm&op=delete&deletesubmit=1&deletepm_deluid[]=$value[touid]&handlekey=deletemsg&formhash={FORMHASH}" ><i class="wqiconfont2 wqicon2-gbdelete wqapp_f18"></i></a></span>
                    <span class="wqapp_f14">
                        <a href="{if $value[touid]}home.php?mod=space&do=pm&subop=view&touid=$value[touid]{else}home.php?mod=space&do=pm&subop=view&plid={$value['plid']}&type=1{/if}" class="wq_grey">
                    <!--{if $value['pmtype'] == 2}-->[{lang chatpm}]
                        <!--{if $value[subject]}-->$value[subject]<br><!--{/if}-->
                    <!--{/if}-->
                    <!--{if $value['pmtype'] == 2 && $value['lastauthor']}--><!--{else}-->$value[message]<!--{/if}--></a></span>
                </p>

              <span class="wqtime_news wq_grey"><!--{eval echo date("Y-m-d",$value[dateline]);}--></span>

        </li>
        <!--{/loop}-->

    </ul>
</div>
<!--{elseif $grouppms}-->
<div class="wqprivate_news">
    <ul>
        <!--{loop $grouppms  $grouppm}-->
        <li class="wqnew_bottom">
            <a href="home.php?mod=space&do=pm&subop=viewg&pmid=$grouppm[id]" class="wqblock">
                <!--{if !$gpmstatus[$grouppm[id]]}--><span class="wqnum" style="padding: 1px 6px;top: 10px;">$grouppm[isnew]</span><!--{/if}-->
                <img class="wqimg" src="static/image/common/{if $grouppm[author]}annpm{else}systempm{/if}.png" />
                <h2 class="wqname wqellipsis">
                    <!--{if $grouppm[author]}-->
                    $grouppm[author]
                    <!--{else}-->
                    {lang system}
                    <!--{/if}-->
                    <span class="wqtime_news wq_grey"><!--{eval echo date("Y-m-d",$grouppm[dateline]);}--></span>
                </h2>
                  </a>
                 <p class="wqhead_info wqellipsis">
                  <span class="wqapp_f14 wq_grey"> $grouppm[message]</span>
                  <span class="y wqapp_f14 wqlh_28 wq_grey wqm_left10">
                  <!--{if $grouppm['authorid'] == $_G['uid']}-->
                <a class="wq_grey dialog" href="home.php?mod=spacecp&ac=pm&op=delete&deletesubmit=1&deletepm_delplid[]=$grouppm[plid]&handlekey=deletemsg&formhash={FORMHASH}">
                    <i class="wqiconfont2 wqicon2-gbdelete wqapp_f18"></i>
                </a>
            <!--{else}-->
                <a class="wq_grey dialog" href="home.php?mod=spacecp&ac=pm&op=delete&deletesubmit=1&deletepm_quitplid[]=$grouppm[plid]&handlekey=deletemsg&formhash={FORMHASH}">
                    <i class="wqiconfont2 wqicon2-gbdelete wqapp_f18"></i>
                </a>
            <!--{/if}-->
            </span>
                 </p>



        </li>
        <!--{/loop}-->
    </ul>
</div>
<!--{else}-->
<p class="wqemp"><span class="wqno_con"><img src="{$_G['style'][styleimgdir]}images/wqno_con.png"></span>{lang no_corresponding_pm}</p>
<!--{/if}-->
<script>
    function succeedhandle_deletemsg() {
        clearTimeout(setTimeout_location);
        setTimeout(function () {
            location.reload();
        }, 1000);
    }
</script>
<!-- main pmlist end -->

<!--{elseif in_array($_GET[subop], array('view','viewg'))}-->
    <!--{if $_GET[subop]=='view'}-->
        <!--{if $touid}-->
            <!--{eval $headparams['cname'] =$Tlang['f04db6d711e702d8'].$tousername.$Tlang['liaotian'];}-->
        <!--{else}-->
            <!--{if $list}-->
                <!--{eval $headparams['cname'] =$list[0]['subject'];}-->
            <!--{else}-->
                <!--{eval $headparams['cname'] ="{lang chatpm}";}-->
            <!--{/if}-->
        <!--{/if}-->
    <!--{elseif $_GET[subop]=='viewg'}-->
        <!--{if $grouppm[author]}-->
            <!--{eval $headparams['cname'] =$grouppm[author];}-->
        <!--{else}-->
            <!--{eval $headparams['cname'] ="{lang system}";}-->
        <!--{/if}-->
    <!--{/if}-->
    <!--{eval
        $headparams['wtype'] = '1';
        $headparams['lurl'] = $backurl;
        $headparams['ltype'] = 'a';
        echo wq_app_get_header($headparams);
    }-->
<!-- main viewmsg_box start -->
<div class="wp">
    <!--{if !$grouppm}-->
        <!--{if !$list}-->
            <div class="msgbox_no b_m">{lang no_corresponding_pm}</div>
        <!--{/if}-->
        <div class="msgbox b_m wqxiaoxi_ovhd" page="$page" count="$count" perpage="$perpage" touid="$_GET['touid']">
            <!--{loop $list $key $value}-->
            <!--{subtemplate home/space_pm_node}-->
            <!--{/loop}-->
            <!--{eval //print_r($multi);}-->
        </div>
        <form id="pmform" class="pmform" name="pmform" method="post" action="home.php?mod=spacecp&ac=pm&op=send&daterange=$daterange&pmsubmit=yes" >
            <input type="hidden" name="formhash" value="{FORMHASH}" />
            <!--{if !$touid}-->
            <input type="hidden" name="plid" value="$plid" />
            <!--{else}-->
            <input type="hidden" name="touid" value="$touid" />
            <!--{/if}-->
            <!--<div class="wqheight49"></div>-->
            <div class="wqinput_reply wqnew_top">
              <span class="wqinput z wqnew_all"><input type="text" value="" autocomplete="off" id="replymessage" name="message"></span>
               <button name="pmsubmit" id="pmsubmit" class="y wqbg_color wqborder formdialog" value="" />{lang reply}</button>
            </div>
        </form>

    <!--{elseif $grouppm}-->
        <div class="wqnews_details b_m">
            <div class="avat z avatar_news"><img class="self_view" src="static/image/common/{if $grouppm[author]}annpm{else}systempm{/if}.png" /></div>
            $grouppm[message]
            <span class="date wqapp_f14 y"><!--{eval echo date("Y-m-d",$grouppm[dateline]);}--></span>
        </div>
    <!--{/if}-->
</div>
<!--{eval $avatarurl = avatar($_G['uid'], small, true);}-->
<!-- main viewmsg_box end -->
<script>
    var avatarurl = '{$avatarurl}';
    $(function () {
        $('html, body').css('min-height', '100.1%');
        var scrollHeight = $('body').prop('scrollHeight');
        $('body').scrollTop(scrollHeight);
        var maxPage = $('.msgbox.b_m').attr('page');
        $(document).on('scroll', function () {
            var page = $('.msgbox.b_m').attr('page'), touid = $('.msgbox.b_m').attr('touid');
            if (!$(document).scrollTop() && page > 1) {
                var scrollBottom = $(document).height();
                page--;
                $.ajax({
                    url: 'home.php?mod=space&do=pm&subop=view&mobwqimgile=2',
                    data: {touid: touid, page: page},
                    type: 'POST',
                    dataType: 'html'
                }).success(function (res) {
                    var start = res.indexOf('<div class="wqmynews_remind cl">', res.indexOf('msgbox b_m')), end = res.lastIndexOf('</div>', res.indexOf('<form id="pmform"'));
                    var html = res.slice(start, end);
                    $('.msgbox.b_m').prepend(html).attr('page', page);
                    $(document).scrollTop($(document).height() - scrollBottom);
                });
            }
        });
    });

    function succeedhandle_pmform(locationhref, message, param){
        $('.new_dialogbox2 ,#mask').hide();
        clearTimeout(setTimeout_location);
        var msg = $('#replymessage').val();
        var time = new Date();
        var formTime = replyTime(time);
        var html = '<div class="wqmynews_remind cl"><div class="avat y avatar_news"><a href="home.php?mod=space&amp;uid=1&amp;do=profile&amp;mycenter=1&amp;mobile=2"><img style="height:32px;width:32px;" src="' + avatarurl + '"></a></div><div class="wqnews_white y"><div class="dialog_c"><div class="dialog_t">' + msg + '</div></div><div class="dialog_b"></div><div class="date wqapp_f14">' + formTime + '</div></div></div>';
        if ($('.msgbox_no').length) $('.msgbox_no').remove();
        $('.msgbox.b_m').append(html);
        $('#replymessage').val('');
        var scrollHeight = $('body').prop('scrollHeight');
        $('body').scrollTop(scrollHeight);
    }

    var timeline;
    if ($('.msgbox_no').length) {
        timeline = 0;
    } else {
        timeline = Math.max(($('.wqnews_details').eq($('.wqnews_details').length - 1).find('.date').attr('data-time') || 0), ($('.wqmynews_remind').eq($('.wqmynews_remind').length - 1).find('.date').attr('data-time') || 0));
    }

    setInterval_location = setInterval(function getpm() {
        $.ajax({
            url: 'plugin.php?id=wq_app_setting&mod=api&fun=realtime_news&uid={$_G[uid]}&plid={$plid}&touid={$touid}&time='+timeline,
            type: 'POST',
            dataType: 'json'
        }).success(function (res) {
            if (res.errcode === '1') {
                var time = new Date(res.data[0].dateline * 1000);
                var formTime = replyTime(time);
                var html = '<div class="wqnews_details"><div class="avat z avatar_news"><a href="home.php?mod=space&uid=' + res.data[0].authorid + '&do=profile">'
                    +'<img style="height:32px;width:32px;" src="<!--{avatar(' + res.data[0].touidurl + ', small, true)}-->" /></a></div><div class="wqnews_green z">'
                    +'<div class="dialog_c"><div class="dialog_t">' + res.data[0].message + '</div></div><div class="dialog_b"></div>'
                    +'<div class="date wqapp_f14" data-time="' + res.data[0].dateline + '">' + formTime + '</div></div></div>';
                if ($('.msgbox_no').length) $('.msgbox_no').remove();
                $('.msgbox.b_m').append(html);
                timeline = Math.max(($('.wqnews_details').eq($('.wqnews_details').length - 1).find('.date').attr('data-time') || 0), ($('.wqmynews_remind').eq($('.wqmynews_remind').length - 1).find('.date').attr('data-time') || 0));
                var scrollHeight = $('body').prop('scrollHeight');
                $('body').scrollTop(scrollHeight);
            }
        })
    }, 5000)

    function replyTime(obj) {
        var hour = obj.getHours();
        var minute = obj.getMinutes();
        var second = obj.getSeconds();
        if (second < 10) second = '0' + second;
        if (minute < 10) minute = '0' + minute;
        if (hour < 10) hour = '0' + hour;
        time = hour + ':' + minute + ':' + second;
        return time;
    }
</script>
<!--{/if}-->

<!--{else}-->
    <div class="bm_c">
        {lang user_mobile_pm_error}
    </div>
<!--{/if}-->
    <div class="wqheight47" style="height: 0.95rem;"></div>
    <div class="wqnews_remind wqnew_top">
        <ul>
            <li>
                <a href="home.php?mod=space&do=notice&view" class="wqblock<!--{if $_GET['do'] == 'notice'}--> wqcolor<!--{/if}-->"><i class="wqiconfont2 wqicon2-tixing wqapp_f18"></i>{$Tlang['4cfa49d2e80059bc']}</a>
            </li>
            <li>
                <a href="home.php?mod=space&do=pm" class="wqblock<!--{if $_GET['do'] == 'pm'}--> wqcolor<!--{/if}-->"><i class="wqiconfont2 wqicon2-xiaoxi wqapp_f18"></i>{$Tlang['2ba413127f2431b2']}</a>
            </li>
        </ul>
    </div>
<!--{eval $nofooter=1;}-->
<!--{template common/footer}-->

<!--{/if}-->