<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['spacecp_favorite'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{template common/header}-->
<div class="wqshield_notice">

<!--{if $_GET['op'] == 'delete'}-->
	<form id="favoriteform_{$favid}" name="favoriteform_{$favid}" method="post" autocomplete="off" action="home.php?mod=spacecp&ac=favorite&op=delete&favid=$favid&type=$_GET[type]">
		<input type="hidden" name="referer" value="{eval echo dreferer();}" />
		<input type="hidden" name="deletesubmit" value="true" />
		<input type="hidden" name="handlekey" value="{$_GET['handlekey']}" />
		<input type="hidden" name="formhash" value="{FORMHASH}" />

	<div class="wqshield_con"><p>{lang delete_favorite_message}<p></div>
	<p class="wqbtn_can wqnew_top">
            <a href="javascript:;" onclick="popup.close();"class="wqeject_cancel wqnew_right">{lang cancel}</a>
            <input type="submit" name="deletesubmitbtn" value="{lang determine}" class="formdialog wqdetermine"></p>

	</form>
<!--{else}-->
	<form method="post" autocomplete="off" id="favoriteform_{$id}" name="favoriteform_{$id}" action="home.php?mod=spacecp&ac=favorite&type=$type&id=$id&spaceuid=$spaceuid" >
		<input type="hidden" name="favoritesubmit" value="true" />
		<input type="hidden" name="referer" value="{eval echo dreferer();}" />
                <input type="hidden" name="handlekey" value="{$_GET['handlekey']}" />
		<input type="hidden" name="formhash" value="{FORMHASH}" />

       <div class="wqshield_con">
           <div style='line-height: 26px; padding:5px 0px;'> <!--{if $_GET[type] == 'forum'}-->{lang favorite_forum_confirm}<!--{elseif $_GET[type] == 'thread'}--> {lang favorite_thread_confirm}<!--{/if}-->{$title}</div>
             <div class="wqbo_textarea wqnew_all">
                 <textarea id="general_{$id}" name="description" rows="1" class="wqtextarea wqm_top3" ><!--{if $description}-->$description<!--{else}-->{lang favorite_description_default}<!--{/if}--></textarea>
            </div>
       </div>
	<p class="wqbtn_can wqnew_top">
             <a href="javascript:;" onclick="popup.close();" class="wqeject_cancel wqnew_right">{lang cancel}</a>
            <input type="submit" name="favoritesubmit_btn" id="favoritesubmit_btn"  value="{lang determine}" class="formdialog wqdetermine">

        </p>
	</form>
<!--{/if}-->





</div>

<!--{template common/footer}-->

<!--{/if}-->