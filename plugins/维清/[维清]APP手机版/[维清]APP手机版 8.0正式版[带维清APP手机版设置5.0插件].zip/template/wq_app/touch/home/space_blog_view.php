<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['space_blog_view'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{eval $header_nav='null';}-->
<!--{template common/header}-->
<div id="view_big">
    <!--{block headconnect}-->
        <div class="wqadmin_eject new_menu" id="wqbolg_js" style="display: none;">
            <span class="wqadmin_eject_arrow"></span>
            <ul>
                <li><a href="home.php?mod=spacecp&ac=blog&blogid=$blog[blogid]&op=edit"><i class="wqiconfont2 wqicon2-xindenew85 wqapp_f18"></i>{lang edit}</a></li>
                <li><a href="home.php?mod=spacecp&ac=blog&blogid=$blog[blogid]&op=delete&handlekey=delbloghk_{$blog[blogid]}" class="dialog"id="blog_delete_$blog[blogid]" onclick="showWindow(this.id, this.href, 'get', 0);" datatype="0"><i class="wqiconfont2 wqicon2-gbdelete wqapp_f20"></i>{lang delete}</a></li>
                <!--{if checkperm('manageblog')}-->
                <li><a href="home.php?mod=spacecp&ac=blog&blogid=$blog[blogid]&op=edithot&handlekey=bloghothk_{$blog[blogid]}" id="blog_hot_$blog[blogid]" class="dialog"><i class="wqiconfont2 wqicon2-remen wqapp_f20"></i>{$Tlang['f24403d0514c8670']}</a>
                </li>
                <!--{/if}-->
            </ul>
        </div>
        <div class="new_hide" style="display: none;"></div>
    <!--{/block}-->
    <!--{eval $headright=false;}-->
    <!--{if $_G[uid] == $blog[uid] || checkperm('manageblog')}-->
        <!--{eval
            $headright=true;
            $headparams['rtype'] = 'icon';
            $headparams['rclass'] = 'wqicon2-gengduo1 y wqapp_f30 wqheader_right new_button';
        }-->
    <!--{/if}-->
    <!--{eval
        $headparams['wtype'] = '3';
        $headparams['ltype'] = 'a';
        $headparams['lurl'] = $backurl;
        $headparams['cname'] = $Tlang['00d894c323f4abd1'];

        echo wq_app_get_header($headparams, true, $headright, $headconnect) ;
    }-->

<!--{eval
    loadcache('wq_usergroup');
    $wq_app_usergroup=$_G['cache']['wq_usergroup']?$_G['cache']['wq_usergroup']:wq_usergroup();
    $listuserinfo=get_wq_app_userinfo_and_age($list,true);
    $spaceuserinfo = get_wq_app_userinfo_and_age($blog);
}-->
<div class="wqheight44" style="display: none;"></div>
<div class="wqhome_view">
    <ul>
        <li>
            <div class="wqhome_view_info_warp wqnew_bottom">
                <a href="home.php?mod=space&do=profile&uid=$blog[uid]" style="display: initial">
                    <img src="{avatar($blog[uid], small, true)}" class="wqhead">
                </a>
                <div class="wqhome_view_info">
                    <h2 class="wqapp_f16"><a href="home.php?mod=space&do=profile&uid=$blog[uid]" style="color:{$_G['cache']['usergroups'][$space['groupid']]['color']}" class="width120 wqapp_f16">$space[username]</a>

                        <!--{if $spaceuserinfo['gender']==1}-->
                            <span class="wqgender wqman"><i class="wqiconfont2 wqicon2-nan wqapp_f12"></i>{$spaceuserinfo[age]}</span>
                        <!--{elseif $spaceuserinfo['gender']==2}-->
                            <span class="wqgender wqgirl"><i class="wqiconfont2 wqicon2-nv wqapp_f12"></i>{$spaceuserinfo[age]}</span>
                        <!--{/if}-->
                        <span>
                            <a href="javascript:;" class="f12"><!--{eval echo wq_usergroup_show($space[groupid]);}--></a>
                        </span>
                    </h2>
                    <p class="wq_grey wqellipsis wqapp_f12"> <!--{date($blog[dateline])}-->
                        <!--{if $blog['friend']}-->
                        <span>{$friendsname[$blog[friend]]}</span>
                        <!--{/if}--></p>
                </div>
                <div class="wqhome_view_btn">
                    <i class="wqiconfont2 wqicon2-p-see wqapp_f14 wqm_right3"></i>$blog[viewnum]
                </div>
            </div>
        </li>
    </ul>
</div>
<!--{eval //echo "<pre>";print_r($listuserinfo);exit;}-->
<div class="wqpost_view_warp">
    <h3 class="wqapp_f22 wqblog_title">
        <!--{if $blog[status] == 1}-->
        <span class="wqicon_all wqicon_recy">{lang pending}</span>
        <!--{/if}-->
        <!--{if $blog[hot]}--><span class="wqicon_all wqicon_hot">{lang hot} $blog[hot]</span><!--{/if}-->
        $blog[subject]</h3>
        <!--{eval $blog[message] = wq_app_edit_message($blog[message],0,true);}-->
    <div id="blog_article"  class="wqpost_view_img" style='margin-bottom: 0.2rem;'>$blog[message]</div>
</div>
<!--{if $blog[tag]}-->
<div class="my_post_view" id="my_blog_roll">
    <div class="tag_list">
        <ul>
            <!--{eval $tagi = 0;}-->
            <!--{loop $blog[tag] $var}-->
            <li>
                <!--{if $tagi}--><!--{/if}--><a href="misc.php?mod=tag&id=$var[0]">$var[1]</a>
                <!--{eval $tagi++;}-->
            </li>
            <!--{/loop}-->
        </ul>
    </div>
</div>
<!--{/if}-->
<!--{eval $my_roll_tag='my_blog_roll';}-->
<!--{template common/slide}-->
  <!--{if $otherlist}-->
  <div class="wqseparate2"></div>
<div class="wqrelated_posts">
    <h3 class="wqnew_bottom"><a href="javascript:;" class="wqborder_bottom wqcolor">{$Tlang['38692b71279bf1af']}</a></h3>
    <ul>
        <!--{loop $otherlist $value}-->
        <li class="wqnew_bottom">
            <a href="home.php?mod=space&uid=$value[uid]&do=blog&id=$value[blogid]" class="wqellipsis">
                $value[subject]
            </a>
        </li>
        <!--{/loop}-->
        <li class="wqnew_bottom"><a href="home.php?mod=space&uid=$space['uid']&do=blog&view=me&from=space" class="wqellipsis" >{$Tlang['696a978f7ce5cb04']}<span class="wqkey">{$Tlang['7775f0d6c8db1ad9']}</span>{$Tlang['c70356cafde614c1']}<i class="wqiconfont2 wqicon-jiantou"></i></a></li>
    </ul>
</div>
 <!--{/if}-->
<!--{if $newlist}-->
<div class="wqrelated_posts">
    <h3 class="wqnew_bottom"><a href="javascript:;" class="wqborder_bottom wqcolor">{lang popular_blog_review}</a></h3>
    <ul>
         <!--{loop $newlist $value}-->
        <li class="wqnew_bottom">
            <a href="home.php?mod=space&uid=$value[uid]&do=blog&id=$value[blogid]" class="wqellipsis">
                $value[subject]
            </a>
        </li>
         <!--{/loop}-->
    </ul>
</div>
 <!--{/if}-->
<div class="wqseparate2" id='wqall_comment'></div>
<div class="wqposts_atom">
    <h3 class="wqnew_bottom"><a href="javascript:;" class="wqborder_bottom wqcolor">{$Tlang['4bc7b967c326c87e']}</a></h3>
    <!--{if $list}-->
    <div class="wqhome_view">
        <ul>
            <!--{loop $list $k $value}-->
            <li class="wqhome_view_info_warp">
                <!--{if $value[author]}-->
                <a href="home.php?mod=space&do=profile&uid=$value[authorid]" class="head_all" style="display: initial"><!--{avatar($value[authorid],small)}--></a>
                <!--{else}-->
                <img src="{STATICURL}image/magic/hidden.gif" class="wqhead"/>
                <!--{/if}-->
                <div class="wqhome_view_info">
                    <h2 class="wqapp_f16 new_div">
                        <!--{if $value[author]}-->
                        <a href="home.php?mod=space&do=profile&uid=$value[authorid]" id="author_$value[cid]" class="wqwidth80 wqapp_f16 wq_grey">{$value[author]}</a>
                        <!--{else}-->
                        $_G[setting][anonymoustext]
                        <!--{/if}-->
                        <!--{if $value[status] == 1}--><b>({lang moderate_need})</b><!--{/if}-->
                        <!--{if $listuserinfo[$value['authorid']]['gender']==1}-->
                            <span class="wqgender wqman"><i class="wqiconfont2 wqicon2-nan wqapp_f12"></i>{$listuserinfo[$value['authorid']][age]}</span>
                        <!--{elseif $listuserinfo[$value['authorid']]['gender']==2}-->
                            <span class="wqgender wqgirl"><i class="wqiconfont2 wqicon2-nv wqapp_f12"></i>{$listuserinfo[$value['authorid']][age]}</span>
                        <!--{/if}-->
                        <span>
                            <a href="javascript:;" class="f12"><!--{eval echo wq_usergroup_show($listuserinfo[$value['authorid']][groupid]);}--></i></a>
                        </span>
                         <!--{if $_G[uid] == $blog[uid] || checkperm('manageblog')}--><span class="y wqm_left10" style="line-height: 24px;"><a href="javascript:;" class="wq_grey new_button"><i class="wqiconfont2 wqicon2-gengduo1 wqapp_f20"></i></a></span> <!--{/if}-->
                        <span class="y wqapp_f14 wq_grey">
                          <!--{eval echo get_wq_app_blog_and_ablum_replay_number($page, $perpage, $k); }-->
                        </span>
                    </h2>
                    <!--{if $_G[uid]}-->
                    <div class="wqadmin_eject wqbolg_js2 new_menu" style="display: none;">
                        <span class="wqadmin_eject_arrow"></span>
                        <ul><!--{if $value[authorid]==$_G[uid]}-->
                            <li id="reply_edit"><a href="home.php?mod=spacecp&ac=comment&op=edit&cid=$value[cid]&handlekey=editcommenthk_{$value[cid]}"  cid="{$value[cid]}"><i class="wqiconfont2 wqicon2-xindenew85 wqapp_f18"></i>{lang edit}</a></li><!--{/if}-->
                            <!--{if $value[authorid]==$_G[uid] || $value[uid]==$_G[uid] || checkperm('managecomment')}-->          <li> <a href="home.php?mod=spacecp&ac=comment&op=delete&cid=$value[cid]&handlekey=delcommenthk" class="dialog"id="blog_delete_$blog[blogid]" onclick="showWindow(this.id, this.href, 'get', 0);" datatype="0"><i class="wqiconfont2 wqicon2-gbdelete wqapp_f20"></i>{lang delete}</a></li><!--{/if}-->

                            <!--{if $value[authorid]!=$_G[uid] && ($value['idtype'] != 'uid' || $space[self]) && $value[author]}--><li>  <a cid="{$value[cid]}" class="wq_reply_comment" style="padding:0px;" href="javascript:;"  author="$value[author]"><i class="wqiconfont2 wqicon2-pinglun2 wqapp_f18"></i>{lang reply}</a></li>
                            <!--{/if}-->
                        </ul>
                    </div>
                    <!--{/if}-->
                    <div> <!--{if $value[status] == 0 || $value[authorid] == $_G[uid] || $_G[adminid] == 1}-->
                        <!--{eval $value[message] = wq_app_edit_message($value[message],0,true);}-->
                        $value[message]
                        <!--{else}-->
                        {lang moderate_not_validate}
                        <!--{/if}--></div>
                    <p class="list_info wqapp_f13">
                        <span class="width80"><!--{date($value[dateline])}--></span>
                    </p>
                </div>
            </li>
            <!--{/loop}-->
        </ul>
        <!--{if $multi}--><div class="pgs cl mbm">$multi</div><!--{/if}-->
    </div>
    <!--{else}-->
    <div class="wqempty_sofa"><img src="{$_G['style'][styleimgdir]}images/sofa.png"/><br/>{$Tlang['d72d60ca7091a3bd']}</div>
    <!--{/if}-->
</div>
<div class="wqheight49"></div>
<div class="wqcomment_input">
    <!--{if !$blog[noreply] && helper_access::check_module('blog')}-->
    <div class="wqcomment_input_div z">
         <div class="wq_reply_eject notlogged" id="fastpostmessage">
                  <i class="wqiconfont2 wqicon2-xiepinglun"></i>{$Tlang['9e598cfd08858c5a']}
           </div>
        <!--<input id="fastpostmessage" type="text" placeholder="{$Tlang['06e8cffa61d86ac8']}" readonly>-->
    </div>
    <!--{else}-->
    <div class="wqcomment_input_divno z">
         <div class="wq_reply_eject notlogged">
                 {$Tlang['20822d03ce75b5fc']}
           </div>
        <!--<input type="text" placeholder="{$Tlang['20822d03ce75b5fc']}" readonly>-->
    </div>
     <!--{/if}-->
    <div class="wqcomment_input_icon">
        <ul>
            <li><a class="scrollIntoView" href="javascript:;"><i class="wqiconfont2 wqicon2-pinglun2 wqapp_f22 wqicon_position"><span class="wqcomment_num">$blog[replynum]</span></i></a></li>
            <li class="wqcollection">
                <a href="home.php?mod=spacecp&ac=favorite&type=blog&id=$blog[blogid]&spaceuid=$blog[uid]" class="dialog">
                    <!--{eval $flag = check_is_favorite($blog[blogid],'blog');}-->
                    <!--{if $flag && $_G['uid']}-->
                    <i class="wqiconfont2 wqicon2-shoucang1 wqapp_f26 wqcolor_yellow wqicon_position"></i>
                    <!--{else}-->
                    <i class="wqiconfont2 wqicon2-shoucang1 wqapp_f26 wqicon_position"></i>
                    <!--{/if}-->
                </a>
            </li>
            <li><a href="javascript:;"><i class="wqiconfont2 wqicon2-fenxiang01 wqapp_f24 wqshare wqview_share"></i></a></li>
        </ul>
    </div>
</div>
</div>
<!--{template common/share}-->
<form method="post" autocomplete="off" id="quickcommentform_{$id}" action="home.php?mod=spacecp&ac=comment">
    <input type="hidden" name="formhash" value="{FORMHASH}"/>
    <input type="hidden" name="referer" value="home.php?mod=space&uid={$blog['uid']}&do=blog&id={$id}">
    <input type="hidden" name="id" value="{$id}">
    <input type="hidden" name="idtype" value="blogid">
    <input type="hidden" name="handlekey" value="qcblog_{$id}">
    <input type="hidden" name="commentsubmit" value="true">
    <input type="hidden" name="quickcomment" value="true">
    <input type="hidden" id="wq_cid" name="cid" value="" />
    <!--{eval
        $headparams['wclass'] = 'wqheader wqbg_color new_lump';
        $headparams['wtype'] = '';
        $headparams['wextra'] = 'style="display:none; z-index: 12;"';

        $headparams['ltype'] = 'cancel';
        $headparams['lname'] = $Tlang['9c825be7149e5b97'];
        $headparams['lurl'] = 'javascript:void(0);';

	$headparams['ctype'] = 'span';
        $headparams['cname'] =$Tlang['dbedca5ca18ae5c8'];

        $headparams['rtype'] = 'but';
        $headparams['rname'] = $Tlang['c0e5b55d87a9643f'];
        $headparams['rclass'] = 'formdialog';
        $headparams['rid'] = 'postsubmit';
        $headparams['butname'] = 'ratesubmit';

        echo wq_app_get_header($headparams, false, true) ;
    }-->
    <div class="wqpost_list new_list" style="display:none;">
        <ul class="wqpost_list_ul">
            <li class="post_con wqnew_bottom">
                <textarea class="wqpost_textarea" id="needmessage" tabindex="3" autocomplete="off" name="message" rows="2" placeholder="{$Tlang['91efda220ced091e']}" fwin="reply" style="height: 120px;"></textarea>
                <div class="wqpost_upload"><span class="wqiconfont2 wqicon2-biaoqing wqapp_f26 wqbiaoqing"></span>
                    <a href="javascript:;" class="wqiconfont2 wqicon2-tupian3 wqapp_f26">
                        <input id='filedata' type="file" name="Filedata"  multiple="multiple"  class="wqfiledata" accept="image/*">
                        <i class="wqtoday" style="display: none;">0</i>
                    </a>
                </div>
                <!--{template common/upload_image}-->
            </li>
        </ul>
        <!--{template common/smilies}-->
    </div>
    </form>
<script>
    var scroll_Top;
    $("#fastpostmessage").on("click",function(e){
        scroll_Top = $(window).scrollTop();
        $('#view_big').hide();
        $('.new_lump').show();
        $('.new_list').show();
    });
    var intoView = scrollIntoView();
    $('.scrollIntoView').on('click', function () {
        intoView();
    }) ;
    setTimeout(function(){
        $('.new_cancel:eq(1)').addClass('new_wqcancel').removeClass('new_cancel');
        $('.new_wqcancel').on('click',function(){
            $('#view_big').show();
            $(".new_list").hide();
            $(".new_lump").hide();
            $(".new_dialogbox").hide();
            $(".cancel-mask").hide();
            setTimeout(function () {
                $(window).scrollTop(scroll_Top)
            }, 100);
        });
    },100);
    function uploadsuccess_forum(data) {
        if(data == '') {
            popup.open('{lang uploadpicfailed}', 'alert');
        }
        var dataarr = data.split('|');
        if(dataarr[0] == 'DISCUZUPLOAD' && dataarr[2] == 0) {
            popup.close();
            if ($('#imglist').is(':hidden')) {
                $('.cellphone_expression').hide();
                $('.wqbiaoqing').removeClass('wqicon2-jianpan').addClass('wqicon2-biaoqing');
                $('#imglist').show();
            }
           $('#imglist').prepend('<li><span aid="'+dataarr[3]+'" class="del wqdelete"><a href="javascript:;"> <i class="wqiconfont2 wqicon2-jianhao f22"></i></a></span><span class="wqimg"><a href="javascript:;"><img id="aimg_'+dataarr[3]+'" title="'+dataarr[6]+'" src="{$_G[setting][attachurl]}forum/'+dataarr[5]+'" /></a></span><input type="hidden" name="attachnew['+dataarr[3]+'][description]" /></li>');
           $('.wqtoday').show().text($('#imglist li').length-1);
           $('#filedata').val('');
        } else {
                var sizelimit = '';
                if(dataarr[7] == 'ban') {
                        sizelimit = '{lang uploadpicatttypeban}';
                } else if(dataarr[7] == 'perday') {
                        sizelimit = '{lang donotcross}'+Math.ceil(dataarr[8]/1024)+'K)';
                } else if(dataarr[7] > 0) {
                        sizelimit = '{lang donotcross}'+Math.ceil(dataarr[7]/1024)+'K)';
                }
                popup.open(STATUSMSG[dataarr[2]] + sizelimit, 'alert');
        }
    };
    $('.wqbiaoqing').on('click', function () {
        $(this).toggleClass('wqicon2-jianpan');
        if ($('.cellphone_expression').is(':hidden')) {
            $('#imglist').hide();
            $('.cellphone_expression').show();
            $('#upload_icon').removeClass('blue');
            $('.wqbiaoqing').removeClass('wqicon2-biaoqing');
            expression_viwepager();
        } else {
            $('.cellphone_expression').hide();
            $('.wqbiaoqing').addClass('wqicon2-biaoqing');
        }
    });
    function expression_insertunit(obj) {
        var id_val = $('.wqpost_textarea').val();
        $('.wqpost_textarea').val(id_val + obj.attr('code'));
    }
    deleteSmilies('{:', ':}');
    $('.wq_reply_comment').on('click', function () {
        $('#mask').hide();
        var cid = $(this).attr('cid');
        var author = $(this).attr('author');
        $('#wq_cid').val(cid);
        $('#wq_quickcomment').val('');
        $('.new_lump').show();
        $(".new_list").show();
        $('#view_big').hide();
        $('#needmessage').attr('placeholder', "{$Tlang['209e3f19421ead4d']} " + author).val('').focus();
    });
</script>
<!--{eval $nofooter=1;}-->
<!--{template common/footer}-->

<!--{/if}-->