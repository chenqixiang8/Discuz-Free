<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['wq_buluospace_prompt_nav'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<div class="tbn remind_list b_bottom">
	<ul>
		<!--{loop $_G['notice_structure'] $key $type}-->
                <!--{if in_array($key, array('mypost','interactive','system'))}-->
                <li $opactives[$key]><em class="notice_$key"></em><a href="home.php?mod=space&do=notice&view=$key"><!--{eval echo lang('template', 'notice_'.$key)}--><!--{if $_G['member']['category_num'][$key]}--><span class="today_foot top5 right14">$_G['member']['category_num'][$key]</span><!--{/if}--></a></li>
		<!--{/if}-->
                <!--{/loop}-->
	</ul>
</div>
<!--{/if}-->