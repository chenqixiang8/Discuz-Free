<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['spacecp_doing'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{template common/header}-->

<!--{if $_GET['op'] == 'delete'}-->
        <div id="ct" class="wqshield_notice">
            <form method="post" autocomplete="off" id="doingform_{$doid}_{$id}" name="doingform" action="home.php?mod=spacecp&ac=doing&op=delete&doid=$doid&id=$id">
                    <!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
                    <input type="hidden" name="referer" value="{echo dreferer()}" />
                    <input type="hidden" name="formhash" value="{FORMHASH}" />
                    <div class="wqshield_con">
                        <p>{lang determine_delete_doing}</p>
                    </div>

                    <p class="wqbtn_can wqnew_top">
                        <a href="javascript:;" class="wqeject_cancel new_cancel wqnew_right" onclick='popup.close();'>{$Tlang['9c825be7149e5b97']}</a>
                        <button name="deletesubmit" type="submit" class="wqdetermine new_cancel" value="true">{lang determine}</button>
                    </p>
            </form>
	</div>
<!--{elseif $_GET['op'] == 'spacenote'}-->
	<!--{if $space[spacenote]}-->$space[spacenote]<!--{/if}-->
<!--{elseif $_GET['op'] == 'docomment' || $_GET['op'] == 'getcomment'}-->
	<!--{if helper_access::check_module('doing')}-->

            <div id="moodfm" class="wq_doing_warp">
                <form  id="{$_GET[key]}_docommform_{$doid}_{$id}" method="post" autocomplete="off" action="home.php?mod=spacecp&ac=doing&op=comment&doid=$doid&id=$id">
                    <!--{eval
                        $headparams['wtype'] = '1';

                        $headparams['ltype'] = 'cancel';
                        $headparams['lname'] = $Tlang['9c825be7149e5b97'];
                        $headparams['lurl'] = 'javascript:void(0);';

                        $headparams['ctype'] = 'span';
                        $headparams['cname'] = {lang reply};

                        $headparams['rtype'] = 'but';
                        $headparams['rname'] = $Tlang['c0e5b55d87a9643f'];
                        $headparams['rclass'] = 'button2 formdialog';
                        $headparams['rid'] = 'add';
                        $headparams['buttype'] = 'submit';
                        $headparams['butname'] = 'ratesubmit';


                        echo wq_app_get_header($headparams, false, true) ;
                    }-->
                    <div id="mood_statusinput" class="wq_moodfm_input" style="padding-bottom:0;">
                        <textarea  name="message" id="{$_GET[key]}_form_{$doid}_{$id}_t" class="reply_message wqeditarea"></textarea>
                    </div>
                    <div class="wq_doing_biaoqing">
                        <div class="wqpost_upload">
                            <span class="wqiconfont2 wqapp_f26 wqreplaybiaoqing wqicon2-biaoqing"></span>
                        </div>
                        <!--{template common/smilies}-->
                    </div>
                    <input type="hidden" name="commentsubmit" value="true" />
                    <input type="hidden" name="handlekey" value="$_GET[handlekey]" />
                    <input type="hidden" name="formhash" value="{FORMHASH}"/>
                </form>
            </div>
            <script reload="1">
                $('.wqreplaybiaoqing').on('click', function () {
                    $(this).toggleClass('wqicon2-jianpan');
                    if ($('.cellphone_expression').is(':hidden')) {
                        $('.cellphone_expression').show();
                        $('.wqreplaybiaoqing').removeClass('wqicon2-biaoqing');
                        expression_viwepager();
                    } else {
                        $('.cellphone_expression').hide();
                        $('.wqreplaybiaoqing').addClass('wqicon2-biaoqing');
                    }
                });
                function expression_insertunit(obj) {
                    var id_val = $('.reply_message').val();
                    $('.reply_message').val(id_val + obj.attr('code'));
                }
                deleteSmilies('{:', ':}');
                function succeedhandle_{$_GET[handlekey]}(url, msg, values) {
                    clearTimeout(setTimeout_location);
                    setTimeout(function() {
                        location.href='home.php?mod=space&do=doing&view=we';
                    }, '1000');
                }
            </script>
	<!--{/if}-->
	<!--{if $_GET['op'] == 'getcomment'}-->
		<!--{template home/space_doing_li}-->
	<!--{/if}-->
<!--{else}-->
    <div id="content">
        <!--{if helper_access::check_module('doing')}-->
        <!--{template home/space_doing_form}-->
        <!--{/if}-->
    </div>
<!--{/if}-->
<!--{template common/footer}-->
<!--{/if}-->