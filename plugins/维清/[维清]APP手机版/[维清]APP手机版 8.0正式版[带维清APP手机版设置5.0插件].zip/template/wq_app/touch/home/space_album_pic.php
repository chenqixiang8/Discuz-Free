<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['space_album_pic'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{template common/header}-->
    <!--{block headconnect}-->
        <div class="wqadmin_eject new_menu" id="wqalbum_js" style="display: none;">
            <span class="wqadmin_eject_arrow wqadmin_position"></span>
            <ul>
                <!--{if checkperm('managealbum')}-->
                    <li><a class="hot" href="home.php?mod=spacecp&ac=album&picid=$pic[picid]&op=edithot&handlekey=picedithothk_{$pic[picid]}" id="a_hot_$pic[picid]"  class="dialog wqpadding_leftright5"><i class="wqiconfont2 wqicon2-remen wqapp_f18"></i>{$Tlang['f24403d0514c8670']}</a></li>
                <!--{/if}-->
                <li><a href="home.php?mod=spacecp&ac=album&op=editpic&albumid=$album[albumid]&picid=$pic['picid']"><i class="wqiconfont2 wqicon2-gbdelete wqapp_f20"></i>{lang delete}</a></li>
            </ul>
        </div>
        <div class="new_hide" style="display: none;"></div>
    <!--{/block}-->
     <!--{eval $headright=false;}-->
    <!--{if ($_G[uid] == $album[uid] || checkperm('managealbum')) && $album[albumid] > 0}-->
        <!--{eval
            $headright=true;
            $headparams['rtype'] = 'icon';
            $headparams['rclass'] = 'wqicon2-gengduo1 y wqapp_f30 wqheader_right new_pic_detail new_button';
        }-->
    <!--{/if}-->
    <!--{eval
        $headparams['wtype'] = '3';
        $headparams['ltype'] = 'a';
        $headparams['lurl'] = $backurl;
        $headparams['cname'] = $Tlang['82dfab76186f2828'];

        echo wq_app_get_header($headparams, true, $headright, $headconnect) ;
    }-->

<!--{eval
    loadcache('wq_usergroup');
    $wq_app_usergroup=$_G['cache']['wq_usergroup']?$_G['cache']['wq_usergroup']:wq_usergroup();
    $listuserinfo=get_wq_app_userinfo_and_age($list,true);
    $spaceuserinfo = get_wq_app_userinfo_and_age($space);
}-->
<div class="wqhome_view">
    <ul>
        <li>
            <div class="wqhome_view_info_warp wqnew_bottom">
                <a href="home.php?mod=space&do=profile&uid=$space[uid]" style="display: initial">
                    <img src="{avatar($space[uid], small, true)}" class="wqhead">
                </a>
                <div class="wqhome_view_info">
                    <h2 class="wqapp_f16"><a href="home.php?mod=space&do=profile&uid=$space[uid]" class="width120 wqapp_f16">$space[username]</a>
                        <!--{if $spaceuserinfo['gender']==1}-->
                        <span class="wqgender wqman"><i class="wqiconfont2 wqicon2-nan wqapp_f12"></i>{$spaceuserinfo[age]}</span>
                        <!--{elseif $spaceuserinfo['gender']==2}-->
                        <span class="wqgender wqgirl"><i class="wqiconfont2 wqicon2-nv wqapp_f12"></i>{$spaceuserinfo[age]}</span>
                        <!--{/if}-->
                        <span>
                            <a href="home.php?mod=spacecp&ac=usergroup{if $_G[uid]!=$space[uid]}&gid=$space[groupid]{/if}" class="f12">
                                <!--{echo wq_usergroup_show($space[groupid]);}-->
                            </a>
                        </span>
                    </h2>
                    <p class="wq_grey wqellipsis wqapp_f14"><!--{date($pic[dateline])}--></p>
                    <!--{if $friendsname[$value[friend]]}--><!--{eval $friendsClass = array(1 => 'wqicon2-haoyou',2 => 'wqicon2-haoyou2 wqapp_f13 zhidinghy',3 => 'wqicon2-mima wqapp_f14',4 => 'wqicon2-changjianwenti wqapp_f12');}-->
                    <span class="album_visual"><i class="wqiconfont2 $friendsClass[$value[friend]] wqm_right5"></i>$friendsname[$value[friend]]</span>
                    <!--{/if}-->
                </div>
            </div>
        </li>
    </ul>
</div>
<div class="wqpost_view_img wqpadding_12">
    <img src="$pic[pic]" id="pic" />
</div>
<div class="wqpost_view_warp">
    <div id="a_set_title" >
        <!--{if $pic[status] == 1}-->
        {lang moderate_need}
        <!--{/if}-->
        <!--{if $pic[title]}-->
        $pic[title]
        <!--{else}-->
        <!--{eval echo substr($pic['filename'], 0, strrpos($pic['filename'], '.'));}-->
        <!--{/if}-->
    </div>
</div>
<div class="wqscore_zambia">
      {if checkperm('managealbum')}
    <a href="javascript:void(0);" id="a_hot_$pic[picid]" class="wqred">{$Tlang['f24403d0514c8670']}$pic[hot]</a>
     {/if}
</div>

<!--{if $album[friend] != 3}-->
<div id="click_div">
    <!--{template home/space_click}-->
</div>
<!--{/if}-->
<!--{if $list}-->
<div class="wqseparate2" id='wqall_comment'></div>
<div class="wqposts_atom">
    <h3><a href="javascript:;" class="wqborder_bottom wqcolor">{$Tlang['4bc7b967c326c87e']}</a></h3>
    <div class="wqhome_view">
        <ul>
            <!--{loop $list $k $value}-->
            <li class="wqhome_view_info_warp">
                <!--{if $value[author]}-->
                <a href="home.php?mod=space&do=profile&uid=$value[authorid]" class="head_all" style="display: initial"><!--{avatar($value[authorid],small)}--></a>
                <!--{else}-->
                <img src="{STATICURL}image/magic/hidden.gif" class="wqhead"/>
                <!--{/if}-->
                <div class="wqhome_view_info">
                    <h2 class="wqapp_f16 new_div">
                        <!--{if $value[author]}-->
                        <a href="home.php?mod=space&do=profile&uid=$value[authorid]" id="author_$value[cid]" class="wqwidth80 wqapp_f16 wq_grey">{$value[author]}</a>
                        <!--{else}-->
                        $_G[setting][anonymoustext]
                        <!--{/if}-->
                        <!--{if $value[status] == 1}--><b>({lang moderate_need})</b><!--{/if}-->
                        <!--{if $listuserinfo[$value['authorid']]['gender']==1}-->
                        <span class="wqgender wqman"><i class="wqiconfont2 wqicon2-nan wqapp_f12"></i>&nbsp;{$listuserinfo[$value['authorid']][age]}</span>
                        <!--{elseif $listuserinfo[$value['authorid']]['gender']==2}-->
                        <span class="wqgender wqgirl"><i class="wqiconfont2 wqicon2-nv wqapp_f12"></i>&nbsp;{$listuserinfo[$value['authorid']][age]}</span>
                        <!--{/if}-->
                        <span><a href="javascript:;" class="f12">
                                <!--{eval echo wq_usergroup_show($listuserinfo[$value['authorid']][groupid]);}--></a></span>
                       <!--{if ($_G[uid] == $album[uid] || checkperm('managealbum')) && $album[albumid] > 0}--> <span class="y wqm_left10" style="line-height: 24px;"><a href="javascript:;" class="wq_grey new_button"><i class="wqiconfont2 wqicon2-gengduo1 wqapp_f20"></i></a></span><!--{/if}-->
                        <span class="y wqapp_f14 wq_grey">
                             <!--{eval  echo get_wq_app_blog_and_ablum_replay_number($page, $perpage, $k); }-->
                        </span>
                    </h2>
                    <!--{if $_G[uid]}-->
                    <div class="wqadmin_eject wqbolg_js2 new_menu" style="display: none;">
                        <span class="wqadmin_eject_arrow"></span>
                        <ul><!--{if $value[authorid]==$_G[uid]}-->
                            <li><a href="home.php?mod=spacecp&ac=comment&op=edit&cid=$value[cid]&handlekey=editcommenthk_{$value[cid]}" cid="{$value[cid]}"class="wqpadding_leftright5" ><i class="wqiconfont2 wqicon2-xindenew85 wqapp_f18"></i>{lang edit}</a></li><!--{/if}-->
                            <!--{if $value[authorid]==$_G[uid] || $value[uid]==$_G[uid] || checkperm('managecomment')}-->
                            <li><a href="home.php?mod=spacecp&ac=comment&op=delete&cid=$value[cid]&handlekey=delcommenthk" class="wqpadding_leftright5 dialog"id="blog_delete_$blog[blogid]" onclick="showWindow(this.id, this.href, 'get', 0);" datatype="0"><i class="wqiconfont2 wqicon2-gbdelete wqapp_f20"></i>{lang delete}</a></li><!--{/if}-->
                            <!--{if $value[authorid]!=$_G[uid] && ($value['idtype'] != 'uid' || $space[self]) && $value[author]}-->
                            <li><a cid="{$value[cid]}" href="javascript:;" class="wq_reply_comment" author="$value[author]"><i class="wqiconfont2 wqicon2-pinglun2 wqapp_f20"></i>{lang reply}</a></li>
                            <!--{/if}-->
                        </ul>
                    </div>
                    <!--{/if}-->
                    <div> <!--{if $value[status] == 0 || $value[authorid] == $_G[uid] || $_G[adminid] == 1}-->
                        <!--{eval $value[message] = wq_app_edit_message($value[message],0,true);}-->
                        $value[message]
                        <!--{else}-->
                        {lang moderate_not_validate}
                        <!--{/if}--></div>
                    <p class="list_info wqapp_f13">
                        <span class="width80"><!--{date($value[dateline])}--></span>
                    </p>
                </div>
            </li>
            <!--{/loop}-->
        </ul>
    </div>
       <!--{/if}-->
</div>
<!--{if $multi}-->$multi<!--{/if}-->
<div class="wqheight47"></div>
<div class="wqcomment_input wqnew_top">
    <span class="wqcomment_input_div z">
         <div class="wq_reply_eject notlogged" id="fastpostmessage">
                  <i class="wqiconfont2 wqicon2-xiepinglun"></i>{$Tlang['9e598cfd08858c5a']}
           </div>
    </span>
    <div class="wqcomment_input_icon">
        <ul>
            <li><a class="scrollIntoView" href="javascript:;"><i class="wqiconfont2 wqicon2-pinglun2 wqapp_f22 wqicon_position"><span class="wqcomment_num">$count</span></i></a></li>
            <li><a class="dialog" href="home.php?mod=spacecp&ac=favorite&type=album&id=$album[albumid]&spaceuid=$space[uid]&handlekey=sharealbumhk_{$album[albumid]}">
                    <!--{eval $flag = check_is_favorite($album[albumid],'album');}-->
                    <!--{if $flag && $_G['uid']}-->
                   <i class="wqiconfont2 wqicon2-shoucang1 wqapp_f26 wqcolor_yellow wqicon_position"></i>
                    <!--{else}-->
                    <i class="wqiconfont2 wqicon2-shoucang1 wqapp_f26 wqicon_position"></i>
                    <!--{/if}-->
                </a>
            </li>
            <li><a href="javascript:;" id="a_share_$pic[picid]"><i class="wqiconfont2 wqicon2-fenxiang01 wqapp_f24 wqshare wqview_share"></i></a></li>
        </ul>
    </div>
</div>
<!--{template common/share}-->
<form method="post" autocomplete="off" id="fastpostform" action="home.php?mod=spacecp&ac=comment&handlekey=qcpic_{$picid}">
    <input type="hidden" name="formhash" value="{FORMHASH}"/>
    <input type="hidden" name="refer" value="$theurl" />
    <input type="hidden" name="id" value="$picid" />
    <input type="hidden" name="idtype" value="picid" />
    <input type="hidden"  id="wq_commentsubmit"  name="commentsubmit" value="true" />
    <input type="hidden" id="wq_cid" name="cid" value=""/>
    <input type="hidden" id="wq_op" name="op" value=""/>
    <input type="hidden" id="wq_editsubmit" name="editsubmit" value=""/>

    <!--{eval
        $headparams['wclass'] = 'wqheader wqbg_color new_lump';
        $headparams['wtype'] = '';
        $headparams['wextra'] = 'style="display:none; z-index: 12;"';

        $headparams['ltype'] = 'cancel';
        $headparams['lname'] = $Tlang['9c825be7149e5b97'];
        $headparams['lurl'] = 'javascript:void(0);';

	$headparams['ctype'] = 'span';
        $headparams['cname'] =$Tlang['dbedca5ca18ae5c8'];

        $headparams['rtype'] = 'but';
        $headparams['rname'] = $Tlang['c0e5b55d87a9643f'];
        $headparams['rclass'] = 'formdialog';
        $headparams['rid'] = 'postsubmit';
        $headparams['butname'] = 'ratesubmit';

        echo wq_app_get_header($headparams, false, true) ;
    }-->

    <div class="wqpost_list new_list" style="display:none;">
        <ul class="wqpost_list_ul">
            <li class="post_con wqnew_bottom">
                <textarea class="wqpost_textarea" id="needmessage" tabindex="3" autocomplete="off" name="message" rows="2" placeholder="{$Tlang['91efda220ced091e']}" fwin="reply" style="height: 120px;"></textarea>
                <div class="wqpost_upload"><span class="wqiconfont2 wqicon2-biaoqing wqapp_f26 wqbiaoqing"></span>
                </div>
            </li>
        </ul>
        <!--{template common/smilies}-->
    </div>
</form>

<script>
    var scroll_Top;
    var model = {
        init:function(){
            model.comment();
            model.comment_edit();
            model.hot();
            var intoView = scrollIntoView();
            $('.scrollIntoView').on('click', function () {
                intoView();
            }) ;
        },
        comment:function(){
            $("#fastpostmessage").on("click",function(e){
                scroll_Top = $(window).scrollTop();
                $('.wqposts_atom,.wqpost_view_img').hide();
                $('.new_lump').show();
                $('.new_list').show();
            });

            $('.wqbiaoqing').on('click', function () {
                $(this).toggleClass('wqicon2-jianpan');
                if ($('.cellphone_expression').is(':hidden')) {
                    $('#imglist').hide();
                    $('.cellphone_expression').show();
                    $('#upload_icon').removeClass('blue');
                    $('.wqbiaoqing').removeClass('wqicon2-biaoqing');
                    expression_viwepager();
                } else {
                    $('.cellphone_expression').hide();
                    $('.wqbiaoqing').addClass('wqicon2-biaoqing');
                }
            });
            deleteSmilies('{:', ':}');
        },
        comment_edit:function(){
            $('.wq_reply_comment').on('click', function () {
                $('#mask').hide();
                var cid = $(this).attr('cid');
                var author = $(this).attr('author');
                $('#wq_cid').val(cid);
                $('#wq_quickcomment').val('');
                $('.new_lump').show();
                $(".new_list").show();
                $('#view_big').hide();
                $('#needmessage').attr('placeholder', "{$Tlang['209e3f19421ead4d']} " + author).val('').focus();
            });
        },
        hot:function(){
            $('.hot').click(function(e){
                $('#wqalbum_js').hide();
                var obj = $(this);
                popup.open(toast);
                $.ajax({
                    type: 'GET',
                    url: obj.attr('href') + '&inajax=1',
                    dataType: 'html'
                }).success(function (s) {
                    var wq = s;
                    popup.open(wq);
                }).error(function () {
                    window.location.href = obj.attr('href');
                    popup.close();
                });
                e.preventDefault();
            });
        }
    };
    model.init();

    function expression_insertunit(obj) {
        var id_val = $('.wqpost_textarea').val();
        $('.wqpost_textarea').val(id_val + obj.attr('code'));
    }
</script>
<!--{eval $nofooter=1;}-->
<!--{template common/footer}-->
<!--{/if}-->