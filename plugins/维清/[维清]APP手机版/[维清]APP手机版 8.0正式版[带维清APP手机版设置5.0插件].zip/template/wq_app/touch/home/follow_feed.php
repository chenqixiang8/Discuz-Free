<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['follow_feed'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{if !in_array($do, array('following', 'follower')) && $_GET['action']=='publish'}-->
<!--{eval $header_nav='null';}-->
<!--{/if}-->
<!--{template common/header}-->
<!--{if in_array($do, array('following', 'follower'))}-->
    <!--{block headname}-->
        <ul>
            <li<!--{if $do == 'following'}--> class="wqon"<!--{/if}-->><a href="home.php?mod=follow&do=following&uid={$space[uid]}">{$Tlang['8fe539a549ff6e77']}</a></li>
            <li<!--{if $do == 'follower'}--> class="wqon2" <!--{/if}-->><a href="home.php?mod=follow&do=follower&uid={$space[uid]}">{$Tlang['2598e4efb6f60cb1']}</a></li>
        </ul>
    <!--{/block}-->
    <!--{eval
        $headparams['wtype'] = '2';
        $headparams['ltype'] = 'fh';
        $headparams['lclass'] = 'wqmenu';
        $headparams['lurl'] = $backurl;
	$headparams['ctype'] = 'div';
        $headparams['cname'] =$headname;

        echo wq_app_get_header($headparams, false) ;
    }-->


<!--{if $list}-->
<!--{eval
    loadcache('wq_usergroup');
    $wq_app_usergroup=$_G['cache']['wq_usergroup']?$_G['cache']['wq_usergroup']:wq_usergroup();
    $spaceuserinfo = get_wq_app_userinfo_and_age($list,true,$do);
}-->

<div class="wqapp_listen_audience">
    <ul>
        <!--{loop $list $fuid $fuser}-->
            <!--{if empty($fuser['fusername']) || empty($fuser['username'])}-->
            <!--{eval continue;}-->
            <!--{/if}-->
        <li class="wqnew_bottom">
            <a href="home.php?mod=space&do=profile&uid=$fuid" >
                <!--{avatar($fuid,middle)}-->
                <h2 class="wqname wqellipsis">
                    <!--{if $do=='following'}-->$fuser['fusername'] <!--{/if}-->
                    <!--{if $do=='follower'}-->$fuser['username'] <!--{/if}-->
                </h2>
            </a>
            <!--{if $do=='following'}-->
                <!--{if $viewself}-->
                <a id="a_followmod_{$fuser['followuid']}" href="home.php?mod=spacecp&ac=follow&op=del&hash={FORMHASH}&fuid=$fuser['followuid']" class="wqbtn_follow wqbtn_already dialog"><i class="wqiconfont2 wqicon2-iconfontfollowok wqapp_f24"></i></a>
                <!--{elseif $fuser[followuid] != $_G[uid]}-->
                    <!--{if $fuser['mutual']}-->
                    <a id="a_followmod_{$fuser['followuid']}" href="home.php?mod=spacecp&ac=follow&op=del&hash={FORMHASH}&fuid=$fuser['followuid']" class="wqbtn_follow wqbtn_already dialog"><i class="wqiconfont2 wqicon2-iconfontfollowok wqapp_f24"></i></a>
                    <!--{elseif helper_access::check_module('follow')}-->
                    <a id="a_followmod_{$fuser['followuid']}" href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$fuser['followuid']" class="wqbtn_follow wqbtn_grey dialog"><i class="wqiconfont2 wqicon2-guanzhu wqapp_f20"></i></a>
                    <!--{/if}-->
                <!--{/if}-->
            <!--{else}-->
                <!--{if $fuser[uid] != $_G[uid]}-->
                    <!--{if $fuser['mutual']}-->
                    <a id="a_followmod_{$fuser['uid']}" href="home.php?mod=spacecp&ac=follow&op=del&hash={FORMHASH}&fuid=$fuser['uid']"  class="wqbtn_follow wqbtn_already dialog"><i class="wqiconfont2 wqicon2-huxianghaoyou wqapp_f20"></i></a>
                    <!--{elseif helper_access::check_module('follow')}-->
                    <a id="a_followmod_{$fuser['uid']}" href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$fuser['uid']"  class="wqbtn_follow wqbtn_grey dialog"><i class="wqiconfont2 wqicon2-guanzhu wqapp_f20"></i></a>
                    <!--{/if}-->
                <!--{/if}-->
            <!--{/if}-->
            <!--{eval
                $memberinfo[$fuid]['follower'] = empty($memberinfo[$fuid]['follower']) || !$memberinfo[$fuid]['follower'] ? 0 : $memberinfo[$fuid]['follower'];
                $memberinfo[$fuid]['following'] = empty($memberinfo[$fuid]['following']) || !$memberinfo[$fuid]['following'] ? 0 : $memberinfo[$fuid]['following'];
            }-->
            <p class="wqlisten_audience_num"><span class="wqm_right5">{$Tlang['bbd702ca1f76841a']}$memberinfo[$fuid]['follower']</span><span class=" wqm_right5">{$Tlang['2c8a07313e7706bc']}$memberinfo[$fuid]['following']</span>
            </p>
        </li>
        <!--{/loop}-->
    </ul>
</div>
    <!--{if !empty($multi)}-->
    <div>$multi</div>
    <!--{/if}-->
<!--{else}-->
<div id="nofollowmsg">
    <div class="flw_thread">
        <ul>
            <li class="flw_article">
                <div class="wqemp">
                    <span class="xg1 xs2 hm">
                        <!--{if $viewself}-->
                            <!--{if $do=='following'}-->
                            {lang follow_you_following_none}<a href="home.php?mod=follow&view=other" class="xi2">{lang follow_hall}</a>{lang follow_fetch_interested_user}
                            <!--{else}-->
                            {lang follow_you_follower_none1}<a href="home.php?mod=follow" class="xi2">{lang follow_add_feed}</a>{lang follow_you_follower_none2}
                            <!--{/if}-->
                        <!--{else}-->
                            <!--{if $do=='following'}-->
                            {lang follow_user_following_none}
                            <!--{else}-->
                            {lang follow_user_follower_none}
                            <!--{/if}-->
                        <!--{/if}-->
                    </span>
                </div>
            </li>
        </ul>
    </div>
</div>
<!--{/if}-->
<!--{else}-->
<!--{if $_GET['action']!='publish'}-->
    <!--{eval $headright=false;}-->
    <!--{if helper_access::check_module('follow') && ( $do == 'feed' || ( $do == 'view' && $viewself))}-->
        <!--{eval
            $headright=true;
            $headparams['rtype'] = 'a';
            $headparams['rname'] = $Tlang['b5937c141ee29253'];
            $headparams['rclass'] = 'wqapp_f16';
            $headparams['rurl'] = 'home.php?mod=follow&action=publish';
        }-->
    <!--{/if}-->
    <!--{eval
        $headparams['wtype'] = '1';
        $headparams['lurl'] = $backurl;
        $headparams['ltype'] = 'a';
        $headparams['cname'] =wq_app_setting_feed_title($do,$view);
        echo wq_app_get_header($headparams,true,$headright);
    }-->

<!--{if $do == 'view'}-->
<!--{eval $fuid =$uid}-->
<!--{else}-->
<!--{eval $fuid =$vuid}-->
<!--{/if}-->
<!--{eval $count=wq_app_setting_get_feeds($do, $view,$fuid);}-->

<div class="wqheight44" style="display: none;"></div>
    <!--{if !empty($list['feed'])}-->
        <div contentid="follow_feed_ul" class="wqrelay_warp pulldown_load_js"  query_string="{$_SERVER['QUERY_STRING']}"  count="{$count}" perpage="20" page="$page">
            <ul id="follow_feed_ul" class="wqindex_list_ul">
                <!--{template home/follow_feed_li}-->
            </ul>
            <p class="wqloading_all wqloaded_all" <!--{if {$space['feeds']} / 20 > $page}-->style="display:none;"<!--{/if}-->>{$Tlang['b3f7b411f8a25701']}</p>
            <div class="wqmore" style="display: none;">
                <img src="{$_G['style'][styleimgdir]}images/icon_load.gif" />
                {$Tlang['d0a97567aed382e8']}
            </div>
            <script type="text/javascript">
                function succeedhandle_attachpay(url, msg, values) {
                    hideWindow('attachpay');
                    window.location.href = url;
                }
            </script>
        </div>
    <!--{eval $footerSlide = 1;}-->
    <!--{else}-->
    <div class="wqemp">
        <!--{if $viewself}-->
        {lang follow_following_null}
        <!--{else}-->
       <div class="wqemp_guanzhu" style='border-bottom: none;'>{lang follow_no_content}</div>
        <!--{/if}-->
        <!--{if $do == 'feed' && $view == 'special'}-->
        <div class="mtw hm xg1">
            {lang follow_add_special_tip}<a href="home.php?mod=follow&do=following&uid=$uid" class="xi2">{lang follow_add_special_following}</a>
        </div>
        <!--{/if}-->

        <!--{if !empty($recommend) && $showrecommend && $view != 'special'}-->
        <!--{eval $showrecommend = false;}-->
        <div class="flw_user_list mbm">
            <h3 class="xw1"><span class="wqline wqbg_color"></span>{lang  follow_recommend}</h3>
            <ul class="ml mls cl">
                <!--{loop $recommend $ruid $rusername}-->
                <li>
                    <a href="home.php?mod=space&do=profile&uid=$ruid" class="avt" c="1" shref="home.php?mod=space&do=profile&uid=$ruid"><!--{avatar($ruid,small)}--></a>
                    <p><a href="home.php?mod=space&do=profile&uid=$ruid">$rusername</a></p>
                    <!--{if helper_access::check_module('follow')}-->
                    <span><a id="a_followmod_{$ruid}" href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$ruid&from=block" class="wqcolor dialog" onclick="ajaxget(this.href);
                            doane(event);" style="text-decoration: none !important;">{lang follow_add}</a></span>
                    <!--{/if}-->
                </li>
                <!--{/loop}-->
            </ul>
        </div>
        <!--{/if}-->
        <!--{eval $footerSlide = 1;}-->
        </div>
<!--{/if}-->
<!--{else}-->
<!--{eval $wqfollow_post=true;}-->
<!--{template forum/post}-->
<!--{/if}-->
<!--{/if}-->
<script>
    var model = {
        init:function(){
            $('html,body').css('min-height', '101%');
            model.ajax();
            model.cursorOn();
        },
        ajax:function(){
            $('body').on('click', '.hot',function(){
                $('#wqalbum_js').hide();
                var obj = $(this);
                popup.open(toast);
                $.ajax({
                    type: 'GET',
                    url: obj.attr('href') + '&inajax=1',
                    dataType: 'html'
                }).success(function (s) {
                    var wq = s;
                    popup.open(wq);
                }).error(function () {
                    window.location.href = obj.attr('href');
                    popup.close();
                });
                return false;
            });
        },
        cursorOn:function(){
            var top;
            var length;
            $('body').on('focus','.wqshield_notice:eq(1) textarea',function(){
                top = parseFloat($(this).parents('.new_dialogbox2').css('top'));
                length = top - 44 - 20 * $(window).height() / 568;
                $(this).parents('.new_dialogbox2').css({'transition':'0.3s','transform':'translate(0,' + length * (-1) + 'px)'});
            });
            $('body').on('blur','.wqshield_notice:eq(1) textarea',function(){
                var that = $(this);
                setTimeout(function(){
                    that.parents('.new_dialogbox2').css('transform','translate(0,0)');
                },300);
            });
            $('body').on('click','.new_dialogbox2 a,.new_dialogbox2 button',function(){
                $(this).parents('.new_dialogbox2').css('transition',"");
            });
        }
    };
    model.init();
    function strLenCalc(obj, checklen, maxlen) {
	var v = obj.value, charlen = 0, maxlen = !maxlen ? 200 : maxlen, curlen = maxlen, len = v.length;
	for(var i = 0; i < v.length; i++) {
            if(v.charCodeAt(i) < 0 || v.charCodeAt(i) > 255) {
		curlen -= charset == 'utf-8' ? 2 : 1;
            }
	}
	if(curlen >= len) {
		$('#' + checklen).html(curlen - len);
	} else {
		obj.value = mb_cutstr(v, maxlen, 0);
	}
    }
    function mb_cutstr(str, maxlen, dot) {
        var len = 0;
        var ret = '';
        var dot = !dot ? '...' : dot;
        maxlen = maxlen - dot.length;
        for(var i = 0; i < str.length; i++) {
            len += str.charCodeAt(i) < 0 || str.charCodeAt(i) > 255 ? (charset == 'utf-8' ? 3 : 2) : 1;
            if(len > maxlen) {
                ret += dot;
                 break;
            }
        ret += str.substr(i, 1);
        }
        return ret;
    }

    function delayload() {
        var document_top = $(document).scrollTop();
        $(".lazyload-home").each(function() {
            var img_top = $(this).offset().top;
            if (img_top >= document_top && img_top <= document_top + wq_window_height) {
                $(this).attr('src', $(this).attr('data-src') ).removeClass("lazyload-home");
                feed_img($(this).parent())
            }
        });
    }
</script>
<!--{template common/footer}-->

<!--{/if}-->