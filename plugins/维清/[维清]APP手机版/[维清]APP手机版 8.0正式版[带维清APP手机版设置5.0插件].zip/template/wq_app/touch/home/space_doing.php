<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['space_doing'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{template common/header}-->
    <!--{eval $headright=false;}-->
    <!--{if helper_access::check_module('collection')}-->
        <!--{eval $headright=true;}-->
    <!--{/if}-->

    <!--{eval
        $headparams['wtype'] = '1';
        $headparams['ltype'] = 'a';
        $headparams['lurl'] = $backurl;
        $headparams['cname'] = $Tlang['643d94f69debff50'];
        $headparams['rtype'] = 'a';
        $headparams['rclass'] = 'wqapp_f16';

        $headparams['rtype'] = 'a';
        $headparams['rclass'] = '';

        echo wq_app_get_header($headparams,true,$headright);
    }-->
    <div id="ct" class="ct2_a wp cl">
        <div class="appl">
            <div class="wq_record_paste">
                <div class="tag_list">
                    <ul>
                        <li$actives[we]><a href="home.php?mod=space&do=$do&view=we">{lang me_friend_doing}</a></li>
                        <li$actives[me]><a href="home.php?mod=space&do=$do&view=me">{lang doing_view_me}</a></li>
                        <li$actives[all]><a href="home.php?mod=space&do=$do&view=all">{lang view_all}</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="mn pbm">
            <!--{if $space[self] && helper_access::check_module('doing')}--><!--{template home/space_doing_form}--><!--{/if}-->

            <!--{if $searchkey}-->
               <!-- <p class="tbmu">{lang doing_search_record} <span style="color: red; font-weight: 700;">$searchkey</span> {lang doing_record_list}</p>-->
            <!--{/if}-->

            <!--{if $dolist}-->
                <div class="wqseparate2"></div>
                <div class="wq_record_list {if empty($diymode)}xlda{/if}">
                    <ul>
                        <!--{loop $dolist $dv}-->
                        <!--{eval $doid = $dv[doid];}-->
                        <!--{eval $_GET[key] = $key = random(8);}-->
                            <li class="wqnew_bottom" id="{$key}dl{$doid}">
                                <div class="wq_head">
                                    <a href="home.php?mod=space&uid=$dv[uid]" c="1"><!--{avatar($dv[uid],small)}--></a>
                                </div>
                                <div class="{if empty($diymode)}ptm{else}ptw{/if} xs2">
                                    <a href="home.php?mod=space&uid=$dv[uid]">$dv[username]</a>
                                    <span class="y wqapp_f12 wq_grey"><!--{date($dv['dateline'], 'u')}--></span>
                                    <!--{if $dv[status] == 1}--><span style="font-weight: bold;">({lang moderate_need})</span><!--{/if}-->
                                    <!--{eval $dv[message]= wq_app_edit_message($dv[message],0,true);;}-->
                                    <p class="wq_con">$dv[message]</p>
                                </div>
                                <div class="wq_grey wqapp_f12 wq_reply_delete">
                                    <!--{if $dv[uid]==$_G[uid]}-->
                                        <span class="y"><a href="home.php?mod=spacecp&ac=doing&op=delete&doid=$doid&id=0&handlekey=doinghk_{$doid}_0" class="dialog" id="{$key}_doing_delete_{$doid}_0">{lang delete}</a></span>
                                    <!--{/if}-->
                                    <!--{if helper_access::check_module('doing')}-->
                                        <span class="y"><a href="home.php?mod=spacecp&ac=doing&op=docomment&handlekey=msg_0&doid={$doid}&id=0&key={$key}" class="">{lang reply}</a></span>
                                    <!--{/if}-->
                                </div>
                                <!--{eval $list = $clist[$doid];}-->
                                <div class="cmt brm" id="{$key}_$doid"{if empty($list) || !$showdoinglist[$doid]} style="display:none;"{/if}>
                                    <span id="{$key}_form_{$doid}_0"></span>
                                    <!--{template home/space_doing_li}-->
                                </div>
                            </li>
                        <!--{/loop}-->
                    </ul>
                    <!--{if $pricount}-->
                        <p class="mtm">{lang hide_doing}</p>
                    <!--{/if}-->
                </div>

                <!--{if $multi}-->
                    <div class="pgs cl mtm">$multi</div>
                <!--{/if}-->
            <!--{else}-->
                <p class="wqemp">{lang doing_no_replay}<!--{if $space[self]}-->{lang doing_now}<!--{/if}--></p>
            <!--{/if}-->
        </div>
    </div>
<!--{template common/footer}-->

<!--{/if}-->