<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['spacecp_share'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{template common/header}-->
<!--{if !$_G[inajax]}-->
<div id="pt" class="bm cl">
	<div class="z">
		<a href="./" class="nvhm" title="{lang homepage}">$_G[setting][bbname]</a>
                <em>&rsaquo;</em>
                <a href="home.php">$_G[setting][navs][4][navname]</a>
	</div>
</div>
	<div id="ct" class="ct2_a wp cl">
		<div class="mn">
	          <div class="bm bw0">
<!--{/if}-->
<!--{if $_GET['op'] == 'delete'}-->
<div class="wqshield_notice">
	<form id="shareform_{$sid}" name="shareform_{$sid}" method="post" autocomplete="off" action="home.php?mod=spacecp&ac=share&op=delete&sid=$sid&type=$_GET[type]" {if $_G[inajax] && $_GET[type]!='view'} onsubmit="ajaxpost(this.id, 'return_$_GET[handlekey]');"{/if}>
		<input type="hidden" name="referer" value="{echo dreferer()}" />
		<input type="hidden" name="deletesubmit" value="true" />
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
		<div class="c">{lang delete_share_message}</div>
		<p class="o pns">
			<button type="submit" name="deletesubmitbtn" value="true" class="pn pnc"><strong>{lang determine}</strong></button>
                        <a href="javascript:;" onclick="popup.close();" class="eject_cancel">{lang cancel}</a>
		</p>
	</form>
    </div>
	<!--{if $_G[inajax] && $_GET[type]!='view'}-->
	<script type="text/javascript">
		function succeedhandle_$_GET[handlekey](url, msg, values) {
			share_delete(values['sid']);
		}
	</script>
	<!--{/if}-->
<!--{elseif $_GET['op'] == 'edithot'}-->
<div class="wqshield_notice">
	<form method="post" autocomplete="off" action="home.php?mod=spacecp&ac=share&op=edithot&sid=$sid">
		<input type="hidden" name="referer" value="{echo dreferer()}" />
		<input type="hidden" name="hotsubmit" value="true" />
		<input type="hidden" name="formhash" value="{FORMHASH}" />
                <div class="wqshield_con"><p>{lang new_hot}<input type="text" name="hot" value="$share[hot]" size="10" class="txt sc_textarea"style="width: 80%;" /></p></div>
		<p class="wqbtn_can wqnew_top">
                   <a href="javascript:;" onclick="popup.close();" class="wqeject_cancel wqnew_right">{lang cancel}</a>
		   <button type="submit" name="btnsubmit" value="true" class="wqdetermine">{lang determine}</button>
		</p>
	</form>
</div>
<!--{elseif $_GET['op']=='link'}-->
	<!--{if !$_G[inajax]}-->
		<h1 class="mt"><img src="static/image/feed/share.gif" class="vm" alt="share"> {lang share}</h1>
	<!--{else}-->
		<h3 class="flb">
		     <em id="return_$_GET[handlekey]">{lang share}</em>
	             <!--{if $_G[inajax]}--><span><a href="javascript:;" onclick="hideWindow('$_GET[handlekey]');" class="flbc" title="{lang close}">{lang close}</a></span><!--{/if}-->
		</h3>
	<!--{/if}-->
	<form id="shareform" name="shareform" action="home.php?mod=spacecp&ac=share&type=link" method="post" autocomplete="off" >
		<input type="hidden" name="refer" value="home.php?mod=space&uid=$space[uid]&do=share&view=me" />
		<input type="hidden" name="topicid" value="$_GET[topicid]" />
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<input type="hidden" name="sharesubmit" value="true" />
		<!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
		<div class="c tfm">
			<p>{lang share_web_music_flash}:</p>
			<p class="mtn mbm"><input type="text" size="30" class="px" name="link" onfocus="javascript:if('http://'==this.value)this.value='';" onblur="javascript:if(''==this.value)this.value='http://'" id="share_link" value="$linkdefault" /></p>
			<p>{lang description}:</p>
			<p class="mtn mbm"><textarea id="share_general" name="general" cols="30" rows="3" class="pt" onkeydown="ctrlEnter(event, 'sharesubmit_btn')">$generaldefault</textarea></p>
			<!--{if $type == 'thread'}-->
				<p><a href="javascript:;" onclick="setCopy($('share_general').value + '\n ' + $('share_link').value, '{lang share_copylink}')" />{lang share_im}</a></p>
			<!--{/if}-->
			<!--{if $secqaacheck || $seccodecheck}-->
				<!--{block sectpl}--><sec> <span id="sec<hash>" class="secq" onclick="showMenu({'ctrlid':this.id,'win':'{$_GET[handlekey]}'})"><sec></span><div id="sec<hash>_menu" class="p_pop p_opt" style="display:none"><sec></div><!--{/block}-->
				<div class="sec"><!--{subtemplate common/seccheck}--></div>
			<!--{/if}-->
		</div>
		<p class="o pns">
			<button type="submit"  name="sharesubmit_btn" id="sharesubmit_btn" value="true" class="formdialog pn pnc">{lang share}</button>
		</p>
	</form>
	<!--{if $_G[inajax]}-->
	<script type="text/javascript">
		function succeedhandle_$_GET['handlekey'](url, message, values) {
			showCreditPrompt();
		}
	</script>
	<!--{/if}-->
<!--{else}-->
<div class="wqshield_notice">
	<form method="post" autocomplete="off" id="shareform_{$id}" name="shareform_{$id}" action="home.php?mod=spacecp&ac=share&type=$type&id=$id">
		<input type="hidden" name="sharesubmit" value="true">
		<input type="hidden" name="referer" value="{echo dreferer()}">
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
		<div class="wqshield_con" style="padding:10px 20px 0px 20px;">
                    <p><textarea id="general_{$id}" class="wqtextarea wqnew_all" name="general" cols="50" rows="4"  placeholder="{lang share_description}" ></textarea></p>
			<!--{if $secqaacheck || $seccodecheck}-->
			<!--{block sectpl}--><sec> <span id="sec<hash>" onclick="showMenu({'ctrlid':this.id,'win':'{$_GET[handlekey]}'})"><sec></span><div id="sec<hash>_menu" class="p_pop p_opt" style="display:none"><sec></div><!--{/block}-->
			<div class="mtm sec"><!--{subtemplate common/seccheck}--></div>
			<!--{/if}-->
		</div>
                <!--{if $commentcable[$type]}-->
                <p style="text-align: left;height: 40px; line-height: 40px; padding-left:10px;">
                     <input type="checkbox"name="iscomment"class="weui_check"value="1" id="iscomment">
                            <label class="weui_check_label" for="iscomment"><i class="weui_icon_checked"></i>  <!--{if $type == 'thread'}-->{lang post_add_inonetime}<!--{else}-->{lang comment_add_inonetime}<!--{/if}--></label>
                <p><!--{/if}-->
		<p class="wqbtn_can wqnew_top">
                     <a href="javascript:;" onclick="popup.close();" class="wqeject_cancel wqnew_right">{lang cancel}</a>
                    <button type="submit" name="sharesubmit_btn" id="sharesubmit_btn" class="formdialog wqdetermine" value="true">{lang determine}</button>
		</p>
	</form>
</div>
<!--{/if}-->

<!--{if !$_G[inajax]}-->
		</div>
	</div>
</div>
<!--{/if}-->
<!--{template common/footer}-->
<!--{/if}-->