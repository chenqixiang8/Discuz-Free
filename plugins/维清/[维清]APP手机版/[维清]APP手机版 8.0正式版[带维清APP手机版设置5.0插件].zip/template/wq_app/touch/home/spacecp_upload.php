<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['spacecp_upload'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{eval $header_nav='null';}-->
<!--{template common/header}-->
    <div class="wqheader wqbg_color uploadtitle wqheader-position wqheader-relative">
        <a href="javascript:;" class="wqcancel">{$Tlang['9c825be7149e5b97']}</a>
         <!--{if $albums && $_GET[do] !='create'}-->
            <span class="wqpost_title">{$Tlang['9af5a64c904a836f']}</span>
            <button  class="wqpublish wqbg_color" onclick="$('#post_submit').click();">{$Tlang['ea3949d3bf95b1a2']}</button>
        <!--{else}-->
            <span class="wqpost_title">{$Tlang['a38454698d434472']}</span>
            <button class="wqpublish wqbg_color" onclick="$('#post_submit').click();">{$Tlang['b531d032f4f29f92']}</button>
        <!--{/if}-->
    </div>
    <div class="wqheight44" style="display: none;"></div>
    <form method="post" autocomplete="off" id="albumform" action="home.php?mod=spacecp&ac=upload">
        <input type="hidden" name="albumsubmit" id="albumsubmit" value="true" />
        <input type="hidden" name="formhash" value="{FORMHASH}" />
        <input id='post_submit' type="submit" class='formdialog' style="display: none"/>
        <input id="uploadalbumid" type="hidden" name="albumid" />
<!--{if $albums && $_GET[do] !='create'}-->
        <input id="albumop" type="hidden" name="albumop" value="selectalbum"/>
        <!--{if $albumid}-->
        <div id="selectalbum">
            <!--{loop $albums $value}-->
                <!--{if $value[albumid] == $albumid}-->
                <div class="wqchoice_upload_photos" data-id="$albumid">
                    <a href="javascript:;">
                    <div class="wqchoice_div">
                        <div class="z wqchoice_prompt">{$Tlang['9cf73e44a65d3919']}</div>
                        <div class="y wqchoice_divarrow"><i class="wqiconfont2 wqicon2-jiantou"></i></div>
                        <div class="wqchoice_div2 y">
                            <span class="wqchoice_divimg"><img src="data/attachment/album/$value[pic]"></span>
                            <h3 class="wqchoice_divname wqellipsis">$value[albumname]</h3>
                            <p class="wqapp_f12 wqchoice_divcondition"><i class="wqiconfont2 wqicon2-haoyou"></i><span><!--{if $value[friend] == 0}-->{$Tlang['58dd85be48101356']}<!--{elseif $value[friend] == 1}-->{$Tlang['658b435c5ae5090b']}<!--{elseif $value[friend] == 2}-->{$Tlang['ece2969614153680']}<!--{elseif $value[friend] == 3}-->{$Tlang['dc79e6dbef19e27f']}<!--{elseif $value[friend] == 4}-->{$Tlang['e1d15e8b226050de']}<!--{/if}--></span></p>
                        </div>
                    </div>
                    </a>
                </div>
                <!--{/if}-->
            <!--{/loop}-->
        </div>
        <!--{else}-->
        <div id="selectalbum">
            <!--{loop $albums $value}-->
                <!--{if $value == reset($albums)}-->
                <div class="wqchoice_upload_photos" data-id="$value[albumid]">
                    <a href="javascript:;">
                    <div class="wqchoice_div">
                        <div class="z wqchoice_prompt">{$Tlang['9cf73e44a65d3919']}</div>
                        <div class="y wqchoice_divarrow"><i class="wqiconfont2 wqicon2-jiantou"></i></div>
                        <div class="wqchoice_div2 y">
                            <span class="wqchoice_divimg"><img src="data/attachment/album/$value[pic]"></span>
                            <h3 class="wqchoice_divname wqellipsis">$value[albumname]</h3>
                            <p class="wqapp_f12 wqchoice_divcondition"><i class="wqiconfont2 wqicon2-haoyou"></i><span><!--{if $value[friend] == 0}-->{$Tlang['58dd85be48101356']}<!--{elseif $value[friend] == 1}-->{$Tlang['658b435c5ae5090b']}<!--{elseif $value[friend] == 2}-->{$Tlang['ece2969614153680']}<!--{elseif $value[friend] == 3}-->{$Tlang['dc79e6dbef19e27f']}<!--{elseif $value[friend] == 4}-->{$Tlang['e1d15e8b226050de']}<!--{/if}--></span></p>
                        </div>
                    </div>
                    </a>
                </div>
                <!--{/if}-->
            <!--{/loop}-->
        </div>
        <!--{/if}-->
<!--{else}-->
        <input id="albumop" type="hidden" name="albumop" value="creatalbum"/>
        <div id="creatalbum" class="wqcreate">
            <div class="wqpost_list">
                <ul class="wqpost_list_ul">
                    <li class="wqnew_bottom"><input type="text" name="albumname" class="wqpost_input" placeholder="{$Tlang['951d1c2b4c9f7926']}"></li>
                    <li class="wqnew_bottom">
                        <textarea name="depict" id="affirmpoint" class="wqpost_textarea" placeholder="{$Tlang['8757cd19752ab239']}" ></textarea>
                    </li>
                    <li class="wqnew_bottom">
                        <select name="friend" class="wqpost_select"  onchange="passwordShow(this.value);">
                            <option value="0" selected="selected">{lang friendname_0}</option>
                            <option value="1">{lang friendname_1}</option>
                            <option value="2">{lang friendname_2}</option>
                            <option value="3">{lang friendname_3}</option>
                            <option value="4">{lang friendname_4}</option>
                        </select>
                    </li>
                    <li class="wqnew_bottom" id="span_password" style="display:none;">
                        <input type="text" name="password" id="uploadpassword" class="wqpost_input" value="" size="10" placeholder="{lang password}" />
                    </li>
                    <li class="tb_selectgroup wqnew_bottom" style="display:none;">
                         <select name="selectgroup" class="wqpost_select">
                            <option value="">{lang from_friends_group}</option>
                            <!--{loop $groups $key $value}-->
                            <option value="$key">$value</option>
                            <!--{/loop}-->
                        </select>
                    </li>
                    <li class="tb_selectgroup wqnew_bottom" style="display:none;">
                        <textarea name="target_names" class="wqpost_textarea" id="target_names" placeholder="{lang friend_name_space}"></textarea>
                        <p id="names_hidden" style="display: none"></p>
                    </li>
                </ul>
            </div>
        </div>
<!--{/if}-->
        <div class="wqseparate"></div>
        <div class="wqlist_upload_photos" >
            <input id='filedata' type="file" name="Filedata" multiple="multiple"  class="wqfiledata" accept="image/*" style="display:none;">
            <!--{template common/upload_image}-->
        </div>

        <div class="wqdrop_upload_operation slide-stop" style="display: none;">
            <p class="wqdrop_upload"><a href="javascript:history.back();" class="wqblock">{$Tlang['2933bba823b9ad39']}</a></p>
            <p><a href="javascript:;" class="wqcancel wqblock">{$Tlang['9c825be7149e5b97']}</a></p>
        </div>
        <div class="wq_updateto" style="display:none;">
            <!--{eval
                $headparams['wtype'] = '2';
                $headparams['ltype'] = 'cancel';
                $headparams['lname'] = $Tlang['9c825be7149e5b97'];
                $headparams['lurl'] = 'javascript:void(0);';
                $headparams['ctype'] = 'span';
                $headparams['cname'] =$Tlang['9cf73e44a65d3919'];

                $headparams['rtype'] = 'a';
                $headparams['rurl'] = 'home.php?mod=spacecp&ac=upload&do=create';
                $headparams['rname'] = $Tlang['bab286385e559395'];

                echo wq_app_get_header($headparams, false, true) ;
            }-->


            <div class="wqupload_to_list">
                <ul>
                    <!--{loop $albums $value}-->
                        <li class="wqnew_bottom" data-id="$value[albumid]">
                            <a href="javascript:;" class="wqblock">
                                <div class="wqupload_to_list_img"><img src="data/attachment/album/$value[pic]"></div>
                                <div class="wqupload_to_list_info">
                                    <h3 class="wqellipsis wqapp_f18">$value[albumname]</h3>
                                </div>
                                <p class="wqcondition wq_grey wqapp_f14"><span class="wqm_right10">$value[picnum]{$Tlang['ac71b5f442db4d5f']}</span><i class="wqiconfont2 wqicon2-haoyou"></i><span class="wqupload_to_friend"><!--{if $value[friend] == 0}-->{$Tlang['58dd85be48101356']}<!--{elseif $value[friend] == 1}-->{$Tlang['658b435c5ae5090b']}<!--{elseif $value[friend] == 2}-->{$Tlang['ece2969614153680']}<!--{elseif $value[friend] == 3}-->{$Tlang['dc79e6dbef19e27f']}<!--{elseif $value[friend] == 4}-->{$Tlang['e1d15e8b226050de']}<!--{/if}--></span></p>
                            </a>
                        </li>
                    <!--{/loop}-->
                </ul>
            </div>
        </div>
    </form>
        <script>
            var model = {
                init:function(){
                    $('#imglist').show();
                    $('.wqlist_upload_photos').width($('body').width() - 16);
                    $('.wqlist_upload_photos ul li:last-child').css({'margin-right':'0','line-height':($('.wqlist_upload_photos li').width() - 2) + 'px'});
                    $('.wqlist_upload_photos li').height($('.wqlist_upload_photos li').width());
                    if($('.wqchoice_upload_photos').data('id')){
                        $('#uploadalbumid').val($('.wqchoice_upload_photos').data('id'));
                    }
                    model.cancel_load();
                    model.uploadTo();
                },
                cancel_load:function(){
                    $('body').on('click','.cancel-mask,.wqcancel.wqblock', function(){
                       $('.cancel-mask, .wqdrop_upload_operation').hide();
                    });
                },
                uploadTo:function(){
                    $('.wqchoice_upload_photos').click(function(){
                        $('.wq_updateto').show();
                        $('.wqchoice_upload_photos,.wqlist_upload_photos,.wqseparate,.uploadtitle').hide();
                    });
                    $('.wqupload_to_list li').click(function(){
                        $('.wqchoice_divname').text($(this).find('.wqellipsis').text());
                        $('.wqchoice_divcondition span').text($(this).find('.wqupload_to_friend').text());
                        $('.wqchoice_divimg img').prop('src',$(this).find('.wqupload_to_list_img img').prop('src'));
                        $('.wqchoice_upload_photos').attr('data-id',$(this).data('id'));
                        $('#uploadalbumid').val($(this).data('id'));
                        $('.wq_updateto').hide();
                        $('.wqchoice_upload_photos,.wqlist_upload_photos,.wqseparate,.uploadtitle').show();
                    });
                    $('.wqpost_select').change(function(){
                        if($('.wqpost_select').val() == '2'){
                            $('#span_password').hide();
                            $('.tb_selectgroup').show();
                        } else if($('.wqpost_select').val() == '4') {
                            $('.tb_selectgroup').hide();
                            $('#span_password').show();
                        } else {
                            $('.tb_selectgroup,#span_password').hide();
                        }
                    });
                    $('.wqpost_select').change(function(){
                        var gid = $(this).val();
                        if (gid) {
                            $.get('home.php?mod=spacecp&ac=privacy&inajax=1&op=getgroup&gid=' + gid, {},
                                function(s) {
                                    s = wqXml(s);
                                    var s = wq_replace_js(s);
                                    s = $.trim($('#names_hidden').html(s).text());
                                    s = s + ' ';
                                    document.getElementById('target_names').innerHTML += s;
                                }, 'html');
                        }
                    });
                }
            };
            model.init();
            upload_image = function(data) {
            if(data == '') {
                popup.open('{lang uploadpicfailed}', 'alert');
            }
            var dataarr = eval('(' + data + ')');
                popup.close();
                $('#imglist').prepend('<li><span aid="'+dataarr['picid']+'" class="del wqdelete"><a href="javascript:;"> <i class="wqiconfont2 wqicon2-jianhao f22"></i></a></span><span class="wqimg"><a href="javascript:;"><img style="height:'+ $('.wqlist_upload_photos li').width() +'px;width:100%;" id="aimg_'+dataarr['picid']+'" title="'+dataarr['picid']+'" src="'+dataarr['bigimg']+'" /></a></span><input type="hidden" name="title['+dataarr['picid']+']" /></li>');
            };
            function passwordShow(value) {
                var span_password, tb_selectgroup;
                    switch (value) {
                        case '4':
                            span_password = 'show';
                            tb_selectgroup = 'hide';
                            break;
                        case '2':
                            span_password = 'hide';
                            tb_selectgroup = 'show';
                            break;
                        default:
                            span_password = 'hide';
                            tb_selectgroup = 'hide';
                    }
                        $('#span_password')[span_password]();
                        $('#tb_selectgroup')[tb_selectgroup]();
                    }
            url = 'misc.php?mod=swfupload&action=swfupload&operation=album&type=image&inajax=yes&infloat=yes';
        </script>

<!--{template common/footer}-->
<!--{/if}-->