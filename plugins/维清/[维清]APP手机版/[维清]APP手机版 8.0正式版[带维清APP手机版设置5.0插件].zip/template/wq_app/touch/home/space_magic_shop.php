<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['space_magic_shop'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<div class="wqmagic_menu wqnew_bottom">
    <ul class="tb cl">
            <li $subactives[index]><a href="home.php?mod=magic&action=shop">{lang default}</a></li>
            <li $subactives[hot]><a href="home.php?mod=magic&action=shop&operation=hot">{lang top}</a></li>
    </ul>
 </div>

	<!--{if $_G['group']['maxmagicsweight']}-->
		<div class="tbmu wqmagic_tbmu wqnew_bottom">{lang magics_capacity}: <span class="xi1">$totalweight</span>/{$_G['group']['maxmagicsweight']}</div>
	<!--{/if}-->
	<!--{if $magiccredits}-->
			<div class="tbmu wqmagic_tbmu wqnew_bottom"><!--{if $_G['group']['magicsdiscount']}-->{lang magics_discount}<span class="pipe">|</span><!--{/if}-->
			{lang you_have_now}
			<!--{eval $i = 0;}-->
			<!--{loop $magiccredits $id}-->
				<!--{if $i != 0}-->, <!--{/if}-->{$_G['setting']['extcredits'][$id][img]} {$_G['setting']['extcredits'][$id][title]} <span class="xi1"><!--{echo getuserprofile('extcredits'.$id);}--></span> {$_G['setting']['extcredits'][$id][unit]}
				<!--{eval $i++;}-->
			<!--{/loop}-->
			<!--{if ($_G['setting']['ec_ratio'] && ($_G['setting']['ec_tenpay_opentrans_chnid'] || $_G['setting'][ec_tenpay_bargainor] || $_G['setting']['ec_account'])) || $_G['setting']['card']['open']}-->
				<a href="home.php?mod=spacecp&ac=credit&op=buy" class="y wq_button">{lang buy_credits}</a>
			<!--{/if}-->
			<!--{if $_G[setting][exchangestatus]}-->
				<a href="home.php?mod=spacecp&ac=credit&op=exchange" class="y wq_button">{lang credit_exchange}</a>
			<!--{/if}-->
                        </div>
	<!--{/if}-->
<!--{if $magiclist}-->
	<ul class="mgcl wq_magiv_list">
	<!--{loop $magiclist $key $magic}-->
		<li class="wqnew_bottom">
			<div id="magic_$magic[identifier]" class="mg_img wq_img" onmouseover="showMenu({'ctrlid':this.id, 'menuid':'magic_$magic[identifier]_menu', 'pos':'12!'});">
				<img src="$magic[pic]" alt="$magic[name]" />
			</div>
			<h3><strong>$magic[name]</strong></h3>
                        <div id="magic_$magic[identifier]_menu" class="wqmagic_effect" >
				<div class="tip_horn"></div>
				<div class="tip_c" style="text-align:left">$magic[description]</div>
			</div>
			<p>
				<!--{if {$_G['setting']['extcredits'][$magic[credit]][unit]}}-->
					{$_G['setting']['extcredits'][$magic[credit]][title]} <strong class="xi1 xw1 xs2">$magic[price]</strong> {$_G['setting']['extcredits'][$magic[credit]][unit]}/{lang magics_unit}
				<!--{else}-->
					<strong class="wq_orange">$magic[price]</strong> {$_G['setting']['extcredits'][$magic[credit]][title]}/{lang magics_unit}
				<!--{/if}-->
				<!--{if $operation == 'hot'}--><em class="xg1">({lang sold} $magic[salevolume] {lang magics_unit})</em><!--{/if}-->

                                <span class="y wqmagic_operate">
                                <!--{if $magic['num'] > 0}-->
					<a href="home.php?mod=magic&action=shop&operation=buy&mid=$magic[identifier]">{lang magics_operation_buy}</a>
					<!--{if $_G['group']['allowmagics'] > 1}-->
					<em class="pipe">|</em> <a href="home.php?mod=magic&action=shop&operation=give&mid=$magic[identifier]">{lang magics_operation_present}</a>
					<!--{/if}-->
				<!--{else}-->
					<span class="xg1 wq_grey">{lang magic_empty}</span>
				<!--{/if}-->
                                </span>
			</p>
		</li>
	<!--{/loop}-->
	</ul>
	<!--{if $multipage}--><div class="pgs cl mtm">$multipage</div><!--{/if}-->
<!--{else}-->
        <p class="wqemp"><span class="wqno_con"><img src="{$_G['style'][styleimgdir]}images/wqno_con.png"></span>{lang data_nonexistence}</p>
<!--{/if}-->
<!--{/if}-->