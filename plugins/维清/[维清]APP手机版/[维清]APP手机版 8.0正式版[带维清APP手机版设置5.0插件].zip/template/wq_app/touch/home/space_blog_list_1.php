<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['space_blog_list_1'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{loop $list $k $value}-->
    <!--{eval $stickflag = isset($value['stickflag']) ? 0 : 1;}-->
    <!--{if is_array($value)}-->
        <li class="wqnew_bottom">
            <div class="wqmessage_info_div wqblock wqpadding0 new_div">
                <a href="home.php?mod=space&do=profile&uid=$value[uid]">
                    <img src="<!--{avatar($value[uid], small, true)}-->" class="wqhead"/>
                    <div class="wqmessage_info">
                        <h2 class="wqname wqellipsis">$value[username]</h2>
                        <p class="wq_grey wqellipsis wqapp_f14">$value[dateline]<!--{if $friendsname[$value[friend]]}--><span class="f12">$friendsname[$value[friend]]</span><!--{/if}--></p>
                    </div>
                </a>
               <!--{if $_GET['view']=='me' && $space['self']}-->
                <div class="wqmessage_info_btn wqmessage_info_bolg">
                    <a href="javascript:;" class="new_button"><i class="wqiconfont2 wqicon2-youjiantou-copy"></i></a>
                </div>
                 <!--{/if}-->
            </div>
            <div name="moptions_$post[pid]" popup="true" class="wqadmin_eject wqright0 new_menu" style="display:none;">
                <span class="wqadmin_eject_arrow wqright6"></span>
                <ul>
                    <li class="blog_edit"><a class="wqpadding_leftright5" href="home.php?mod=spacecp&ac=blog&blogid={$value[blogid]}&op=edit"><i class="wqiconfont2 wqicon2-fabiao wqapp_f20"></i>{$Tlang['9a150d4af72d7358']}</a></li>
                    <li><a class="dialog wqpadding_leftright5" href="home.php?mod=spacecp&ac=blog&blogid={$value[blogid]}&op=delete&handlekey=delbloghk_{$value[blogid]}" id="blog_delete_{$value[blogid]}" onclick="showWindow(this.id, this.href, 'get', 0);"><i class="wqiconfont2 wqicon2-gbdelete wqapp_f20"></i>{lang delete}</a></li>
                    <li><a class="dialog wqpadding_leftright5" href="home.php?mod=spacecp&ac=blog&blogid={$value[blogid]}&op=stick&stickflag={$stickflag}&handlekey=stickbloghk_{$value[blogid]}" id="blog_stick_{$value[blogid]}" onclick="showWindow(this.id, this.href, 'get', 0);"><!--{if $stickflag}--><i class="wqiconfont2 wqicon2-zhiding wqapp_f20"></i>{lang stick}<!--{else}--><i class="wqiconfont2 wqicon2-quxiaozhiding wqapp_f20"></i>{lang cancel_stick}<!--{/if}--></a></li>
                </ul>
            </div>
            <a href="home.php?mod=space&uid=$value[uid]&do=blog&id=$value[blogid]" class="wqblock">
                <div class="wqlist_maxhidden">
                    <h3 class="wqtitle_list"{if $value[magiccolor]} style="color: {$_G[colorarray][$value[magiccolor]]}"{/if}>
                        <!--{if !$stickflag}--><span class="wqicon_all wqicon_top">{lang stick}</span><!--{/if}-->
                    $value[subject]</h3>
                </div>
                <p class="list_info"><span>{$Tlang['aea8dc57dfa06b73']}$value[viewnum]{$Tlang['6092e15fd6f787ca']}</span>
                    <span class="y"><i class="wqiconfont2 wqicon2-pinglun2 wqapp_f12"></i>$value[replynum]</span>
                    <!--<span class="y wqm_right10"><i class="wqiconfont2 wqicon2-albumfenxiang wqyulan"></i></span>-->
                </p>
            </a>
        </li>
    <!--{/if}-->
<!--{/loop}-->

<!--{/if}-->