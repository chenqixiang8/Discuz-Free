<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['spacecp_credit_base'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{template common/header}-->
            <!--{eval
                $headparams['wtype'] = '1';
                $headparams['lurl'] = $backurl;
                $headparams['ltype'] = 'a';
                $headparams['cname'] = $Tlang['a86acd545cc0a2fd'];
                echo wq_app_get_header($headparams);
            }-->

		<!--{hook/spacecp_credit_top}-->
		<!--{subtemplate home/spacecp_credit_header}-->

		<!--{if  $_GET['op'] == 'buy'}-->
			<!--{eval $_GET['op']='base';}-->
		<!--{/if}-->

		<!--{if in_array($_GET['op'], array('base', 'buy', 'transfer', 'exchange'))}-->
                <div class="wqapp_creditl">
                    <!--{if  $_GET['op'] == 'base'}-->
                        <!--<div class="wqseparate"></div>-->
				<div class="wqapp_total wqbg_color">
                                    <em><i class="wqiconfont2 wqicon2-jifen wqapp_f32"></i>{lang credits}: </em>
                                    <span>$_G['member']['credits']</span>
                                    <p class="xg1">( $creditsformulaexp )</p>
                                </div>
			<!--{/if}-->
			<ul class="creditl">

			<!--{eval $creditid=0;}-->

			<!--{if $_GET['op'] == 'base' && $_G['setting']['creditstrans']}-->
				<!--{eval $creditid=$_G['setting']['creditstrans'];}-->
				<!--{if $_G['setting']['extcredits'][$creditid]}-->
				<!--{eval $credit=$_G['setting']['extcredits'][$creditid]; }-->
				<li class="wqnew_bottom"><em><!--{if $credit[img]}--> {$credit[img]}<!--{/if}--> {$credit[title]}: </em><!--{echo getuserprofile('extcredits'.$creditid);}--> {$credit[unit]} &nbsp;
					<!--{if ($_G['setting']['ec_ratio'] && ($_G['setting']['ec_tenpay_opentrans_chnid'] || $_G['setting'][ec_tenpay_bargainor] || $_G['setting']['ec_account'])) || $_G['setting']['card']['open']}-->
					<!--<a href="home.php?mod=spacecp&ac=credit&op=buy" class="xi2">{lang card_use}&raquo;</a>-->
					<!--{/if}-->
				</li>
				<!--{/if}-->
			<!--{/if}-->
			<!--{loop $_G['setting']['extcredits'] $id $credit}-->
				<!--{if $id!=$creditid}-->
				<li class="wqnew_bottom"><em><!--{if $credit[img]}--> {$credit[img]}<!--{/if}--> {$credit[title]}: </em><!--{echo getuserprofile('extcredits'.$id);}--> {$credit[unit]}</li>
				<!--{/if}-->
			<!--{/loop}-->
			<!--{hook/spacecp_credit_extra}-->
			</ul>
                    </div>
		<!--{/if}-->
		<!--{if $_GET['op'] == 'base'}-->
		<!--{elseif $_GET['op'] == 'buy'}-->
			<!--{if ($_G[setting][ec_ratio] && ($_G[setting][ec_account] || $_G[setting][ec_tenpay_opentrans_chnid] || $_G[setting][ec_tenpay_bargainor])) || $_G[setting][card][open]}-->
			<form id="addfundsform" name="addfundsform" method="post" autocomplete="off" action="home.php?mod=spacecp&ac=credit&op=buy" onsubmit="ajaxpost(this.id, 'return_addfundsform');">
				<input type="hidden" name="formhash" value="{FORMHASH}" />
				<input type="hidden" name="addfundssubmit" value="true" />
				<input type="hidden" name="handlekey" value="buycredit" />
				<table cellspacing="0" cellpadding="0" class="tfm mtn">
					<tr>
						<th>{lang mode_of_payment}</th>
						<td colspan="2">
							<!--{if $_G[setting][ec_ratio] && ($_G[setting][ec_tenpay_bargainor] || $_G[setting][ec_tenpay_opentrans_chnid])}-->
								<div class="mbm pbn bbda cl">
									<div id="div#tenpayBankList"></div><span id="#bank_type_value"></span>
									<link rel="stylesheet" type="text/css" href="http://union.tenpay.com/bankList/css_col3.css" />
									<script type="text/javascript">
										$('div#tenpayBankList').html = function(){$('div#tenpayBankList').innerHTML = htmlString.replace(/<span.+?\/span>/g, ''); };
										$("#bank_type_value").val = function(){{if $_G[setting][card][open]}$('cardbox').style.display='none';if($('card_box_sec')){$('card_box_sec').style.display='none';}$('paybox').style.display='';{/if}};
										appendscript('http://union.tenpay.com/bankList/bank.js', '');
									</script>
								</div>
							<!--{/if}-->
							<div class="long-logo mbw">
								<ul>
								<!--{if $_G[setting][ec_ratio] && $_G[setting][ec_account]}-->
									<li class="z">
										<input name="bank_type" type="radio" value="alipay" class="vm" id="apitype_alipay" $ecchecked onclick="checkValue(this)" /><label class="vm" style="margin-right:18px;width:135px;height:32px;background:#FFF url({STATICURL}image/common/alipay_logo.gif) no-repeat;border:1px solid #DDD;display:inline-block;" onclick="{if $_G[setting][card][open]}$('cardbox').style.display='none';if($('card_box_sec')){$('card_box_sec').style.display='none';}$('paybox').style.display='';{/if}" for="apitype_alipay"></label>
									</li>
								<!--{/if}-->
								<!--{if $_G[setting][card][open]}-->
									<li>
										<input name="bank_type" type="radio" value="card" id="apitype_card" class="vm" $ecchecked  onclick="activatecardbox();" /><label class="vm" style="padding-left:10px;width:125px;height:32px;line-height:32px;background:#FFF;border:1px solid #DDD;display:inline-block;" onclick="activatecardbox();"><span class="xs2">{lang card_credit}</span></label>
									</li>
								<!--{/if}-->
								</ul>
							</div>
						</td>
					</tr>
					<tr id="paybox" style="{if ($_G[setting][ec_tenpay_bargainor] || $_G[setting][ec_tenpay_opentrans_chnid] || $_G[setting][ec_account]) && empty($ecchecked) }display:;{else}display:none;{/if}">
						<th>{lang memcp_credits_addfunds}</th>
						<td class="pns">
							<input type="text" size="5" class="px" style="width: auto;" id="addfundamount" name="addfundamount" value="0" onkeyup="addcalcredit()" />
							&nbsp;{$_G[setting][extcredits][$_G[setting][creditstrans]][title]}&nbsp;
							{lang credits_need}&nbsp;{lang memcp_credits_addfunds_caculate_radio}
						</td>
						<td width="300" class="d">
							{lang memcp_credits_addfunds_rules_ratio} =  <strong>$_G[setting][ec_ratio]</strong> {$_G[setting][extcredits][$_G[setting][creditstrans]][unit]}{$_G[setting][extcredits][$_G[setting][creditstrans]][title]}
							<!--{if $_G[setting][ec_mincredits]}--><br />{lang memcp_credits_addfunds_rules_min}  <strong>$_G[setting][ec_mincredits]</strong> {$_G[setting][extcredits][$_G[setting][creditstrans]][unit]}{$_G[setting][extcredits][$_G[setting][creditstrans]][title]}<!--{/if}-->
							<!--{if $_G[setting][ec_maxcredits]}--><br />{lang memcp_credits_addfunds_rules_max}  <strong>$_G[setting][ec_maxcredits]</strong> {$_G[setting][extcredits][$_G[setting][creditstrans]][unit]}{$_G[setting][extcredits][$_G[setting][creditstrans]][title]}<!--{/if}-->
							<!--{if $_G[setting][ec_maxcreditspermonth]}--><br />{lang memcp_credits_addfunds_rules_month}  <strong>$_G[setting][ec_maxcreditspermonth]</strong> {$_G[setting][extcredits][$_G[setting][creditstrans]][unit]}{$_G[setting][extcredits][$_G[setting][creditstrans]][title]}<!--{/if}-->
						</td>
					</tr>
					<!--{if $_G[setting][card][open]}-->
						<tr id="cardbox" style="{if $_G[setting][card][open] && $ecchecked}display:;{else}display:none;{/if}">
							<th>{lang card}</th>
							<td colspan="2">
								<input type="text" class="px" id="cardid" name="cardid" />
							</td>
						</tr>
						<!--{if $seccodecheck}-->
							</table>
							<!--{block sectpl}--><table id="card_box_sec" style="{if $_G[setting][card][open] && $ecchecked}display:;{else}display:none;{/if}" cellspacing="0" cellpadding="0" class="tfm mtn"><tr><th><sec></th><td colspan="2"><span id="sec<hash>" onclick="showMenu({'ctrlid':this.id,'win':'{$_GET[handlekey]}'})"><sec></span><div id="sec<hash>_menu" class="p_pop p_opt" style="display:none"><sec></div></td></tr></table><!--{/block}-->
							<!--{subtemplate common/seccheck}-->
							<table cellspacing="0" cellpadding="0" class="tfm mtn">
						<!--{/if}-->
					<!--{/if}-->
					<tr>
						<th>&nbsp;</th>
						<td colspan="2">
							<button type="submit" name="addfundssubmit_btn" class="pn" id="addfundssubmit_btn" value="true"><em>{lang memcp_credits_addfunds}</em></button>
						</td>
					</tr>

				</table>
			</form>
			<span style="display: none" id="return_addfundsform"></span>
			<script type="text/javascript">
				function addcalcredit() {
					var addfundamount = $('addfundamount').value.replace(/^0/, '');
					var addfundamount = parseInt(addfundamount);
					$('desamount').innerHTML = !isNaN(addfundamount) ? Math.ceil(((addfundamount / $_G[setting][ec_ratio]) * 100)) / 100 : 0;
				}
				<!--{if $_G[setting][card][open]}-->
				function activatecardbox() {
					$('apitype_card').checked=true;
					$('cardbox').style.display='';
					if($('card_box_sec')){
						$('card_box_sec').style.display='';
					}
					$('paybox').style.display='none';
				}
				<!--{/if}-->
			</script>
			<!--{/if}-->
		<!--{elseif $_GET['op'] == 'transfer'}-->

			<!--{if $_G[setting][transferstatus] && $_G['group']['allowtransfer']}-->
				<form id="transferform" name="transferform" method="post" autocomplete="off" action="home.php?mod=spacecp&ac=credit&op=transfer" onsubmit="ajaxpost(this.id, 'return_transfercredit');return false;">
					<input type="hidden" name="formhash" value="{FORMHASH}" />
					<input type="hidden" name="transfersubmit" value="true" />
					<input type="hidden" name="handlekey" value="transfercredit" />

					<div class="wqpersonal_data">
						<ul>
							<li class="wqnew_bottom">
								<em>{lang memcp_credits_transfer}</em>
								<span class="text_left wqtransfer_limit">
									<input type="text" name="transferamount" id="transferamount" class="px" size="5" style="width: auto;" value="0"  />
									&nbsp;{$_G[setting][extcredits][$_G[setting][creditstransextra][9]][title]}&nbsp;
									{lang credits_give}&nbsp;
									<input type="text" name="to" id="to" class="px" size="15" placeholder="{$Tlang['2aef1a750edcec42']}"/>
									<p class="wq_limit">
										{lang memcp_credits_transfer_min_balance} $_G[setting][transfermincredits] {$_G[setting][extcredits][$_G[setting][creditstransextra][9]][unit]}
										<!--{if intval($taxpercent) > 0}-->{lang credits_tax} $taxpercent<!--{/if}-->
									</p>
								</span>
							</li>

							<li class="wqnew_bottom">
								<em>{lang transfer_login_password}<span class="rq">*</span></em>
								<span class="text_left"><input type="password" name="password" class="px" value="" placeholder="{$Tlang['97c706512a882490']}"  /></span>
							</li>
							<li class="wqnew_bottom">
								<em>{lang credits_transfer_message}</em>
								<span class="text_left"><input type="text" name="transfermessage" class="px" size="40" placeholder="{$Tlang['c163be2247eeee07']}" /></span>
							</li>
						</ul>
					</div>

					<div class="wqapp_creditl_button">
						<button type="submit" name="transfersubmit_btn" id="transfersubmit_btn" class="button2 formdialog" value="true">{lang memcp_credits_transfer}</button>
						<span style="display: none" id="return_transfercredit"></span>
					</div>
				</form>
			<!--{/if}-->

		<!--{elseif $_GET['op'] == 'exchange'}-->

			<!--{if $_G[setting][exchangestatus] && ($_G[setting][extcredits] || $_CACHE['creditsettings'])}-->
			<form id="exchangeform" name="exchangeform" method="post" autocomplete="off" action="home.php?mod=spacecp&ac=credit&op=exchange&handlekey=credit" onsubmit="ajaxpost(this.id, 'return_exchangeform'); return false;">
				<input type="hidden" name="formhash" value="{FORMHASH}" />
				<input type="hidden" name="operation" value="exchange" />
				<input type="hidden" name="exchangesubmit" value="true" />
				<input type="hidden" name="outi" id='outi' value="" />

				<div class="wqpersonal_data">
					<ul>
						<li class="wqnew_bottom">
							<em>{lang memcp_credits_exchange}</em>
							<span class="text_left wqtransfer_limit">
								<input type="text" id="exchangeamount" name="exchangeamount" class="px" size="5" style="width: auto;" value="0" onkeyup="exchangecalcredit()"/>
								<select name="tocredits" id="tocredits" class="ps" onChange="exchangecalcredit()">
								<!--{loop $_G[setting][extcredits] $id $ecredits}-->
									<!--{if $ecredits[allowexchangein] && $ecredits[ratio]}-->
										<option value="$id" unit="$ecredits[unit]" title="$ecredits[title]" ratio="$ecredits[ratio]">$ecredits[title]</option>
									<!--{/if}-->
								<!--{/loop}-->
								<!--{eval $i=0;}-->

								<!--{loop $_CACHE['creditsettings'] $id $data}--><!--{eval $i++;}-->
									<!--{if $data[title]}-->
									<option value="$id" outi="$i">$data[title]</option>
									<!--{/if}-->
								<!--{/loop}-->
								</select>
								&nbsp;{lang credits_need}&nbsp;
								<input type="text" id="exchangedesamount" class="px" size="5" style="width: auto;" value="0" disabled="disabled" />
								<select name="fromcredits" id="fromcredits_0" class="ps" style="display: block" onChange="exchangecalcredit();">
								<!--{loop $_G[setting][extcredits] $id $credit}-->
									<!--{if $credit[allowexchangeout] && $credit[ratio]}-->
										<option value="$id" unit="$credit[unit]" title="$credit[title]" ratio="$credit[ratio]">$credit[title]</option>
									<!--{/if}-->
								<!--{/loop}-->
								</select>
								<!--{eval $i=0;}-->
								<!--{loop $_CACHE['creditsettings'] $id $data}--><!--{eval $i++;}-->
									<select name="fromcredits_$i" id="fromcredits_$i" class="ps" style="display: block" onChange="exchangecalcredit()">
										<!--{loop $data[creditsrc] $id $ratio}-->
											<option value="$id" unit="$_G['setting']['extcredits'][$id][unit]" title="$_G['setting']['extcredits'][$id][title]" ratiosrc="$data[ratiosrc][$id]" ratiodesc="$data[ratiodesc][$id]">$_G['setting']['extcredits'][$id][title]</option>
										<!--{/loop}-->
									</select>
								<!--{/loop}-->
								<script type="text/javascript">
									var tocredits = document.getElementById('tocredits');
									var fromcredits = document.getElementById('fromcredits_0');
									var outi = document.getElementById('outi');
									if(fromcredits.length > 1 && tocredits.value == fromcredits.value) {
										fromcredits.selectedIndex = tocredits.selectedIndex + 1;
									}
								</script>

								<p class="wq_limit">
									<!--{if $_G[setting][exchangemincredits]}-->
										{lang memcp_credits_exchange_min_balance} $_G[setting][exchangemincredits]
									<!--{/if}-->
									<span id="taxpercent">
										<!--{if intval($taxpercent) > 0}-->
											{lang credits_tax} $taxpercent
										<!--{/if}-->
									</span>
								</p>
							</span>
						</li>

						<li class="wqnew_bottom">
							<em>{lang transfer_login_password}<span class="rq">*</span></em>
							<span class="text_left"><input type="password" name="password" class="px" value="" placeholder="{$Tlang['97c706512a882490']}"  /></span>
						</li>
					</ul>
				</div>

				<div class="wqapp_creditl_button">
					<button type="submit" name="exchangesubmit_btn" id="exchangesubmit_btn" class="button2 formdialog" value="true">{lang memcp_credits_exchange}</button>
				</div>
			</form>
			<script type="text/javascript">
				function exchangecalcredit() {
					with($('#exchangeform')) {
						tocredit = tocredits[tocredits.selectedIndex];
						if(!tocredit) {
							return;
						}

						<!--{eval $i=0;}-->
						<!--{loop $_CACHE['creditsettings'] $id $data}--><!--{eval $i++;}-->
							document.getElementById('fromcredits_$i').style.display = 'none';
						<!--{/loop}-->

						if(tocredit.getAttribute('outi')) {
							outi.value = tocredit.getAttribute('outi');
							fromcredit = document.getElementById('fromcredits_' + tocredit.getAttribute('outi'));
							document.getElementById('taxpercent').style.display = document.getElementById('fromcredits_0').style.display = 'none';
							fromcredit.style.display = '';
							fromcredit = fromcredit[fromcredit.selectedIndex];
							document.getElementById('exchangeamount').value = document.getElementById('exchangeamount').value.toInt();
							if(document.getElementById('exchangeamount').value != 0) {
								document.getElementById('exchangedesamount').value = Math.floor( fromcredit.getAttribute('ratiosrc') / fromcredit.getAttribute('ratiodesc') * document.getElementById('exchangeamount').value);
							} else {
								document.getElementById('exchangedesamount').value = '';
							}
						} else {
							outi.value = 0;
							document.getElementById('taxpercent').style.display = document.getElementById('fromcredits_0').style.display = '';
							fromcredit = fromcredits[fromcredits.selectedIndex];
							document.getElementById('exchangeamount').value = document.getElementById('exchangeamount').value.toInt();
							if(fromcredit.getAttribute('title') != tocredit.getAttribute('title') && $('exchangeamount').value != 0) {
								if(tocredit.getAttribute('ratio') < fromcredit.getAttribute('ratio')) {
									document.getElementById('exchangedesamount').value = Math.ceil( tocredit.getAttribute('ratio') / fromcredit.getAttribute('ratio') * document.getElementById('exchangeamount').value * (1 + $_G[setting][creditstax]));
								} else {
									document.getElementById('exchangedesamount').value = Math.floor( tocredit.getAttribute('ratio') / fromcredit.getAttribute('ratio') * document.getElementById('exchangeamount').value * (1 + $_G[setting][creditstax]));
								}
							} else {
								document.getElementById('exchangedesamount').value = '';
							}
						}
					}
				}
				String.prototype.toInt = function() {
					var s = parseInt(this);
					return isNaN(s) ? 0 : s;
				}
				exchangecalcredit();
			</script>
			<!--{/if}-->

		<!--{else}-->
			{eval
				$_TPL['cycletype'] = array(
					'0' => '{lang one_time}',
					'1' => '{lang everyday}',
					'2' => '{lang the_time}',
					'3' => '{lang interval_minutes}',
					'4' => '{lang open_cycle}'
				);
			}
                        <!--{if $op == 'rule'}-->
                            <div class="wqcredit_rule">
                                    <select onchange="location.href='home.php?mod=spacecp&ac=credit&op=rule&fid='+this.value"><option value="">{lang credit_rule_global}</option>$select</select>
                            </div>
                    <!--{/if}-->
			<div class="tbmu bw0 wqcredit_message">
				<p>{lang activity_award_message}</p>
			</div>
                        <div class="wqforum_privilege_tit">
                            <table cellspacing="0" cellpadding="0">
                                <tr class="wqfont_bold"><td class="xw1">{lang action_name}</td></tr>
                                <!--{loop $list $key $value}-->
                                <tr>
                                    <td>$value[rulename]</td>
                                </tr>
                                <!--{/loop}-->
                        </table>
                            </div>
                        <div class="wqforum_privilege_con slide-stop">
			<table cellspacing="0" cellpadding="0" >
				<tr class="wqfont_bold">

					<td class="xw1">{lang cycle_range}</td>
					<td class="xw1">{lang max_award_per_week}</td>
					<!--{loop $_G['setting']['extcredits'] $key $value}-->
					<td class="xw1">$value[title]</td>
					<!--{/loop}-->
				</tr>
				<!--{eval $i = 0;}-->
				<!--{loop $list $key $value}-->
				<!--{eval $i++;}-->
				<tr{if $i % 2 == 0} class="alt"{/if}>
					<td>$_TPL[cycletype][$value[cycletype]]</td>
					<td><!--{if $value[rewardnum]}-->$value[rewardnum]<!--{else}-->{lang unlimited_time}<!--{/if}--></td>
					<!--{loop $_G['setting']['extcredits'] $key $credit}-->
					<!--{eval $creditkey = 'extcredits'.$key;}-->
					<td><!--{if $value[$creditkey] > 0}-->+$value[$creditkey]<!--{elseif $value[$creditkey] < 0}-->$value[$creditkey]<!--{else}-->0<!--{/if}--></td>
					<!--{/loop}-->
				</tr>
				<!--{/loop}-->
			</table>
                        </div>
		<!--{/if}-->
		<!--{hook/spacecp_credit_bottom}-->
		</div>
	</div>
</div>
<!--{template common/footer}-->
<!--{/if}-->