<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['spacecp_credit_log'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{template common/header}-->
	<!--{eval
		$headparams['wtype'] = '1';
		$headparams['lurl'] = $backurl;
		$headparams['ltype'] = 'a';
		$headparams['cname'] = $Tlang['a86acd545cc0a2fd'];
		echo wq_app_get_header($headparams);
	}-->

	<!--{hook/spacecp_credit_top}-->
	<!--{subtemplate home/spacecp_credit_header}-->
	<div class="wqcredit_menu wqnew_bottom">
		<ul class="tb cl">
			<li{if $_GET[suboperation] != 'creditrulelog'} class="a"{/if}><a href="home.php?mod=spacecp&ac=credit&op=log" hidefocus="true">{lang credit_log}</a></li>
			<li{if $_GET[suboperation] == 'creditrulelog'} class="a"{/if}><a{if $_GET[suboperation] == 'creditrulelog'} class="a"{/if} href="home.php?mod=spacecp&ac=credit&op=log&suboperation=creditrulelog" hidefocus="true">{lang credit_log_sys}</a></li>
		</ul>
	</div>
	<!--{if $_GET[suboperation] != 'creditrulelog'}-->
		<div class="wqforum_privilege_con slide-stop" >
			<table summary="{lang memcp_credits_log_payment}" cellspacing="0" cellpadding="0" >
				<tr class="wqfont_bold">
					<td class="xw1">{lang operation}</td>
					<td class="xw1">{lang credit_change}</td>
					<td class="xw1">{lang detail}</td>
					<td class="xw1">{lang changedateline}</td>
				</tr>
				<!--{eval $i = 0;}-->
				<!--{loop $loglist $value}-->
					<!--{eval $i++;}-->
					<!--{eval $value = makecreditlog($value, $otherinfo);}-->
					<tr{if $i % 2 == 0} class="alt"{/if}>
						<td><!--{if $value['operation']}--><a href="home.php?mod=spacecp&ac=credit&op=log&optype=$value['operation']">$value['optype']</a><!--{else}-->$value['title']<!--{/if}--></td>
						<td>$value['credit']</td>
						<td><!--{if $value['operation']}-->$value['opinfo']<!--{else}-->$value['text']<!--{/if}--></td>
						<td>$value['dateline']</td>
					</tr>
				<!--{/loop}-->
			</table>
		</div>
	<!--{elseif $_GET[suboperation] == 'creditrulelog'}-->

		<div class="wqforum_privilege_tit">
			<table cellspacing="0" cellpadding="0">
				<tr class="wqfont_bold"><td class="xw1">{lang action_name}</td></tr>
				<!--{eval $i = 0;}-->
				<!--{loop $list $key $log}-->
					<!--{eval $i++;}-->
					<tr>
						<td><a href="home.php?mod=spacecp&ac=credit&op=rule&rid=$log[rid]">$log[rulename]</a></td>
					</tr>
				<!--{/loop}-->
			</table>
		</div>
		<div class="wqforum_privilege_con slide-stop" >
			<table summary="{lang get_credit_histroy}" cellspacing="0" cellpadding="0" >
				<tr class="wqfont_bold">
					<td class="xw1">{lang total_time}</td>
					<td class="xw1">{lang cycles_num}</td>
					<!--{loop $_G['setting']['extcredits'] $key $value}-->
						<td class="xw1">$value[title]</th>
					<!--{/loop}-->
					<td class="xw1">{lang last_award_time}</td>
				</tr>
				<!--{eval $i = 0;}-->
				<!--{loop $list $key $log}-->
					<!--{eval $i++;}-->
					<tr{if $i % 2 == 0} class="alt"{/if}>
						<td>$log[total]</td>
						<td>$log[cyclenum]</td>
						<!--{loop $_G['setting']['extcredits'] $key $value}-->
						<!--{eval $creditkey = 'extcredits'.$key;}-->
						<td>$log[$creditkey]</td>
						<!--{/loop}-->
						<td><!--{date($log[dateline], 'Y-m-d H:i')}--></td>
					</tr>
				<!--{/loop}-->
			</table>
		</div>
	<!--{/if}-->
	<!--{if $multi}--><div class="pgs cl mtm">$multi</div><!--{/if}-->
	<!--{hook/spacecp_credit_bottom}-->
<!--{template common/footer}-->
<!--{/if}-->