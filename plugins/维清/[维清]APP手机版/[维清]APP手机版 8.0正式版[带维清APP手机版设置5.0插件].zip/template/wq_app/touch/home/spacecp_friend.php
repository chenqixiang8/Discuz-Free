<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['spacecp_friend'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{template common/header}-->


<!--{if !$_G[inajax]}-->
    <!--{eval $headright=false;}-->
    <!--{if helper_access::check_module('collection')}-->
        <!--{eval $headright=true;}-->
    <!--{/if}-->

    <!--{eval
        $headparams['wtype'] = '1';
        $headparams['ltype'] = 'a';
        $headparams['lurl'] = $backurl;
        $headparams['cname'] = $Tlang['9241e6cc9dd2bfc1'];
        $headparams['rtype'] = 'a';
        $headparams['rclass'] = 'wqapp_f16';

        $headparams['rtype'] = 'a';
        $headparams['rclass'] = '';

        echo wq_app_get_header($headparams,true,$headright);
    }-->

    <div id="ct" class="ct2_a wp cl">
	<div class="mn">
            <div class="wq_friend_paste wqnew_bottom slide-stop" id="wq_friend_paste">
                <div class="tag_list">
                    <ul>
                        <li{$a_actives[me]}><a href="home.php?mod=space&do=friend">{$Tlang['492d7428cf380a08']}</a></li>
                        <!--{if empty($_G['setting']['sessionclose'])}-->
                            <li{$a_actives[onlinefriend]}><a href="home.php?mod=space&do=friend&view=online&type=friend">{$Tlang['6b544f7ca0dafd71']}</a></li>
                            <li{$a_actives[onlinemember]}><a href="home.php?mod=space&do=friend&view=online&type=member">{lang online_member}</a></li>
                        <!--{/if}-->
                        <li{$a_actives[onlinenear]}><a href="home.php?mod=space&do=friend&view=online&type=near">{$Tlang['b5c1fa83a20109c8']}</a></li>
                        <li{$a_actives[visitor]}><a href="home.php?mod=space&do=friend&view=visitor">{$Tlang['e6770cc65c1bebb1']}</a></li>
                        <li{$a_actives[trace]}><a href="home.php?mod=space&do=friend&view=trace">{$Tlang['fbf0ea853e6edcc0']}</a></li>
                        <li$actives[request]><a href="home.php?mod=spacecp&ac=friend&op=request">{lang friend_request}</a></li>
                        <li{$a_actives[blacklist]}><a href="home.php?mod=space&do=friend&view=blacklist">{$Tlang['3fd457794e518744']}</a></li>
                    </ul>
                </div>
            </div>
            <!--{eval $my_roll_tag='wq_friend_paste';}-->
            <!--{template common/slide}-->
            <div class="bm bw0">
<!--{/if}-->
		<!--{if $op =='ignore'}-->
                <div class="wqshield_notice">
                        <form method="post" autocomplete="off"  name="friendform_{$uid}" action="home.php?mod=spacecp&inajax=yes&ac=friend&op=ignore&uid=$uid&confirm=1">
				<input type="hidden" name="referer" value="{echo dreferer()}">
				<input type="hidden" name="friendsubmit" value="true"/>
				<input type="hidden" name="formhash" value="{FORMHASH}"/>
				<input type="hidden" name="from" value="$_GET[from]"/>
				<!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
                                <div class="wqshield_con"><p>{lang determine_lgnore_friend}</p></div>
				<p class="wqbtn_can wqnew_top">
                                    <a href="javascript:;" onclick="popup.close();" class="wqeject_cancel wqnew_right">{lang cancel}</a>
                                    <button type="submit" name="friendsubmit_btn" class="formdialog wqdetermine" value="true">{lang determine}</button>

				</p>
			</form>
                </div>
                <script type="text/javascript" reload="1">
                    function succeedhandle_{$_GET[handlekey]}(url, msg, values) {
                        var obj = $('#friend_'+ values['uid'] +'_li');
                        if(obj.length > 0){
                            obj.remove();
                            if($('.xw1').length > 0){
                                var friendnum = parseInt($('.xw1').html());
                                    friendnum = friendnum > 0 ? friendnum-1 : 0;
                                $('.xw1').html(friendnum);
                                if(friendnum == 0){
                                    $('#friend_ul').before('<div class="wqemp"><span class="wqno_con"><img src="{$_G[style][styleimgdir]}images/wqno_con.png"></span>{lang no_friend_list}</div>');
                                }
                            }
                        }

                        var obj1 = $('#friend_relation');
                        if(obj1.length > 0){
                            obj1.html('<a href="home.php?mod=spacecp&ac=friend&op=add&uid='+values['uid']+'&handlekey=add_friend" class="dialog"><i class="wqiconfont2 wqicon2-haoyou-copy wqapp_f20"></i>{$Tlang[80f4502bde9c9130]}</a>');
                        }

                        var obj2 = $('#friend_tbody_'+values['uid']);
                        if(obj2.length > 0){
                            obj2.remove();
                            if($('#friend_ul li.wqnew_bottom').length == 0){
                                $('.wq_friend_operation').remove();
                                $('.wq_friend_request').before('<div class="wqemp"><span class="wqno_con"><img src="{$_G[style][styleimgdir]}images/wqno_con.png"></span>{lang no_new_friend_application}</div>');
                            }
                        }
                        wq_setTimeout();
                    }
                </script>
		<!--{elseif $op == 'find'}-->
			<!--{if !empty($recommenduser) || $nearlist || $friendlist || $onlinelist}-->
				<!--{if !empty($recommenduser)}-->
				<h2 class="mtw">{lang recommend_user}</h2>
				<ul class="buddy cl">
					<!--{loop $recommenduser $key $value}-->
					<li>
						<div class="avt"><a href="home.php?mod=space&do=profile&uid=$value[uid]" title="$value[username]" c="1"><!--{avatar($value[uid],small)}--></a></div>
						<h4><a href="home.php?mod=space&do=profile&uid=$value[uid]" title="$value[username]">$value[username]</a></h4>
						<p title="$value[reason]" class="maxh">$value[reason]</p>
						<p><a href="home.php?mod=spacecp&ac=friend&op=add&uid=$value[uid]" id="a_near_friend_$key" class="addbuddy dialog">{lang add_friend}</a></p>
					</li>
					<!--{/loop}-->
				</ul>
				<!--{/if}-->

				<!--{if $nearlist}-->
				<h2 class="mtw">{lang surprise_they_near}</h2>
				<ul class="buddy cl">
					<!--{loop $nearlist $key $value}-->
					<li>
						<div class="avt"><a href="home.php?mod=space&do=profile&uid=$value[uid]" title="$value[username]" c="1"><!--{avatar($value[uid],small)}--></a></div>
						<h4><a href="home.php?mod=space&do=profile&uid=$value[uid]" title="$value[username]">$value[username]</a></h4>
						<p><a href="home.php?mod=spacecp&ac=friend&op=add&uid=$value[uid]" id="a_near_friend_$key"  class="addbuddy dialog">{lang add_friend}</a></p>
					</li>
					<!--{/loop}-->
				</ul>
				<!--{/if}-->

				<!--{if $friendlist}-->
				<h2 class="mtw">{lang friend_friend_might_know}</h2>
				<ul class="buddy cl">
					<!--{loop $friendlist $key $value}-->
					<li>
						<div class="avt"><a href="home.php?mod=space&do=profile&uid=$value[uid]" title="$value[username]" c="1"><!--{avatar($value[uid],small)}--></a></div>
						<h4><a href="home.php?mod=space&do=profile&uid=$value[uid]" title="$value[username]">$value[username]</a></h4>
						<p><a href="home.php?mod=spacecp&ac=friend&op=add&uid=$value[uid]&handlekey=friendhk_{$value[uid]}" id="a_friend_friend_$key" class="addbuddy dialog">{lang add_friend}</a></p>
					</li>
					<!--{/loop}-->
				</ul>
				<!--{/if}-->

				<!--{if $onlinelist}-->
				<h2 class="mtw">{lang they_online_add_friend}</h2>
				<ul class="buddy cl">
					<!--{loop $onlinelist $key $value}-->
					<li>
						<div class="avt"><a href="home.php?mod=space&do=profile&uid=$value[uid]" title="$value[username]" c="1"><!--{avatar($value[uid],small)}--></a></div>
						<h4><a href="home.php?mod=space&do=profile&uid=$value[uid]" title="$value[username]">$value[username]</a></h4>
						<p><a href="home.php?mod=spacecp&ac=friend&op=add&uid=$value[uid]&handlekey=onlinehk_{$value[uid]}" id="a_online_friend_$key" class="addbuddy dialog">{lang add_friend}</a></p>
					</li>
					<!--{/loop}-->
				</ul>
				<!--{/if}-->
			<!--{else}-->
				<div class="wqemp mtw ptw hm xs2">
				{lang find_know_nofound}
				</div>
			<!--{/if}-->

		<!--{elseif $op == 'search'}-->

			<h3 class="tbmu">{lang search_member_result}:</h3>
			<!--{template home/space_list}-->

		<!--{elseif $op=='changenum'}-->
			<h3 class="flb">
				<em id="return_$_GET[handlekey]">{lang friend_hot}</em>
				<!--{if $_G[inajax]}--><span><a href="javascript:;" onclick="hideWindow('$_GET[handlekey]');" class="flbc" title="{lang close}">{lang close}</a></span><!--{/if}-->
			</h3>
			<form method="post" autocomplete="off" id="changenumform_{$uid}" name="changenumform_{$uid}" action="home.php?mod=spacecp&ac=friend&op=changenum&uid=$uid">
				<input type="hidden" name="referer" value="{echo dreferer()}">
				<!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
				<input type="hidden" name="formhash" value="{FORMHASH}" />
				<div class="c">
					<p>{lang adjust_friend_hot}</p>
					<p>{lang new_hot}:<input type="text" name="num" value="$friend[num]" size="5" class="px" /> ({lang num_0_999})</p>
				</div>
				<p class="o pns">
					<button type="submit" name="changenumsubmit" class="pn pnc" value="true"><strong>{lang determine}</strong></button>
				</p>
			</form>
			<script type="text/javascript" reload="1">
				function succeedhandle_$_GET[handlekey](url, msg, values) {
					friend_delete(values['uid']);
					$('spannum_'+values['fid']).innerHTML = values['num'];
					hideWindow('$_GET[handlekey]');
				}
			</script>
		<!--{elseif $op=='changegroup'}-->
                    <div class="wqshield_notice">
                        <form method="post" autocomplete="off" id="changegroupform_{$uid}" name="changegroupform_{$uid}" action="home.php?mod=spacecp&ac=friend&op=changegroup&uid=$uid">
                            <input type="hidden" name="referer" value="{echo dreferer()}">
                            <input type="hidden" name="changegroupsubmit" value="true" />
                            <!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
                            <input type="hidden" name="formhash" value="{FORMHASH}" />
                            <div class="wqshield_title">{lang set_friend_group}</div>
                            <div class="wqshield_height"></div>
                            <div class="wqshield_con">
                                <table  class="wqshield_table">
                                    <tr>
                                        <!--{eval $i=0;}-->
                                        <!--{loop $groups $key $value}-->
                                            <td style="padding:8px 8px 0 0; text-align:left !important;" >
                                                <input type="radio" name="group" class="weui_check"id="group$key" value="$key"$groupselect[$key]/>
                                                <label class="weui_check_label" for="group$key"><i class="weui_icon_checked"></i>$value</label>
                                            </td>
                                        <!--{if $i%2==1}--></tr><tr><!--{/if}-->
                                        <!--{eval $i++;}-->
                                        <!--{/loop}-->
                                    </tr>
                                </table>
                            </div>
                            <p class="wqbtn_can wqnew_top">
                                <a href="javascript:;" onclick="popup.close();" class="wqeject_cancel wqnew_right">{lang cancel}</a>
                                <button type="submit" name="changegroupsubmit_btn" class="pn pnc formdialog" value="true">{lang determine}</button>
                            </p>
                        </form>
                    </div>
                    <script type="text/javascript">
                        function succeedhandle_$_GET[handlekey](url, msg, values) {
                             wq_setTimeout();
                        }
                    </script>
		<!--{elseif $op=='editnote'}-->
                    <div class="wqshield_notice">
                        <form method="post" autocomplete="off" id="editnoteform_{$uid}" name="editnoteform_{$uid}" action="home.php?mod=spacecp&ac=friend&op=editnote&uid=$uid">
				<input type="hidden" name="referer" value="{echo dreferer()}">
				<input type="hidden" name="editnotesubmit" value="true" />
				<!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
				<input type="hidden" name="formhash" value="{FORMHASH}" />
                                <div class="wqshield_title">{$Tlang['83c3dfd91fbf02ce']}</div>
                                <div class="wqshield_height"></div>
                                <div class="wqshield_con">
                                    <p class="wqinput"><input type="text" name="note" value="$friend[note]" size="35" placeholder="{$Tlang['13ed287ce4208093']}"/></p>
                                </div>
				<p class="wqbtn_can wqnew_top">
                                    <a href="javascript:;" onclick="popup.close();" class="wqeject_cancel wqnew_right">{lang cancel}</a>
                                    <button type="submit" name="editnotesubmit_btn" class="pn pnc formdialog" value="true">{lang determine}</button>
				</p>
			</form>
                    </div>
                    <script type="text/javascript">
                            function succeedhandle_$_GET[handlekey](url, msg, values) {
                                var uid=values['uid'];
                                var elem = $('#friend_note_'+uid);
                                if(elem) {
                                    elem.html(values['note']);
                                }else{
                                    $('#friend_'+uid+'_li <h4>').append('<span id="friend_note_'+uid+'" class="note xw0">'+values['note']+'</span>');
                                }
                                wq_setTimeout()
                            }
                    </script>
		<!--{elseif $op=='group'}-->

			<p class="tbmu">
				<a href="home.php?mod=spacecp&ac=friend&op=group"{if !isset($_GET[group])} class="a"{/if}>{lang all_friends}</a>
				<!--{loop $groups $key $value}-->
				<span class="pipe">|</span><a href="home.php?mod=spacecp&ac=friend&op=group&group=$key"{if isset($_GET[group]) && $_GET[group]==$key} class="a"{/if}>$value</a>
				<!--{/loop}-->
			</p>
			<p class="tbmu">{lang friend_group_hot_message}</p>

			<!--{if $list}-->
			<form method="post" autocomplete="off" action="home.php?mod=spacecp&ac=friend&op=group&ref">
				<div id="friend_ul">
					<ul class="buddy cl">
					<!--{loop $list $key $value}-->
						<li>
							<div class="avt"><a href="home.php?mod=space&do=profile&uid=$value[uid]"><!--{avatar($value[uid],small)}--></a></div>
							<h4><input type="checkbox" name="fuids[]" value="$value[uid]" class="pc" /> <a href="home.php?mod=space&do=profile&uid=$value[uid]">$value[username]</a></h4>
							<p class="xg1">{lang hot}:$value[num]</p>
							<p class="xg1">$value[group]</p>
						</li>
					<!--{/loop}-->
					</ul>
				</div>
				<div class="mtn">
					<label for="chkall" onclick="checkAll(this.form, 'fuids')"><input type="checkbox" name="chkall" id="chkall" class="pc" />{lang select_all}</label>
					{lang set_member_group}:
					<select name="group" class="ps vm">
					<!--{loop $groups $key $value}-->
						<option value="$key">$value</option>
					<!--{/loop}-->
					</select>&nbsp;
					<button type="submit" name="btnsubmit" value="true" class="pn pnc vm"><strong>{lang determine}</strong></button>

				</div>
				<!--{if $multi}--><div class="pgs cl mtm">$multi</div><!--{/if}-->
				<input type="hidden" name="formhash" value="{FORMHASH}" />
				<input type="hidden" name="groupsubmin" value="true" />
			</form>
			<!--{else}-->
			<div class="wqemp"><span class="wqno_con"><img src="{$_G['style'][styleimgdir]}images/wqno_con.png"></span>{lang no_friend_list}</div>
			<!--{/if}-->

		<!--{elseif $op=='groupname'}-->
			<h3 class="flb">
				<em id="return_$_GET[handlekey]">{lang friends_group}</em>
				<!--{if $_G[inajax]}--><span><a href="javascript:;" onclick="hideWindow('$_GET[handlekey]');" class="flbc" title="{lang close}">{lang close}</a></span><!--{/if}-->
			</h3>
			<div id="__groupnameform_{$group}">
				<form method="post" autocomplete="off" id="groupnameform_{$group}" name="groupnameform_{$group}" action="home.php?mod=spacecp&ac=friend&op=groupname&group=$group" {if $_G[inajax]}onsubmit="ajaxpost(this.id, 'return_$_GET[handlekey]');"{/if}>
					<input type="hidden" name="referer" value="{echo dreferer()}">
					<input type="hidden" name="groupnamesubmit" value="true" />
					<!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
					<input type="hidden" name="formhash" value="{FORMHASH}" />
					<div class="c">
						<p>{lang set_friend_group_name}</p>
						<p class="mtm">{lang new_name}:<input type="text" name="groupname" value="$groups[$group]" size="15" class="px" /></p>
					</div>
					<p class="o pns">
						<button type="submit" name="groupnamesubmit_btn" value="true" class="pn pnc"><strong>{lang determine}</strong></button>
					</p>
				</form>
				<script type="text/javascript">
					function succeedhandle_$_GET[handlekey](url, msg, values) {
						friend_changegroupname(values['gid']);
					}
				</script>
			</div>

		<!--{elseif $op=='groupignore'}-->
			<h3 class="flb">
				<em id="return_$_GET[handlekey]">{lang set_member_feed}</em>
				<!--{if $_G[inajax]}--><span><a href="javascript:;" onclick="hideWindow('$_GET[handlekey]');" class="flbc" title="{lang close}">{lang close}</a></span><!--{/if}-->
			</h3>
			<div id="$group">
				<form method="post" autocomplete="off" id="groupignoreform" name="groupignoreform" action="home.php?mod=spacecp&ac=friend&op=groupignore&group=$group" {if $_G[inajax]}onsubmit="ajaxpost(this.id, 'return_$_GET[handlekey]');"{/if}>
					<input type="hidden" name="referer" value="{echo dreferer()}">
					<input type="hidden" name="groupignoresubmit" value="true" />
					<!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
					<input type="hidden" name="formhash" value="{FORMHASH}" />
					<div class="c">
						<!--{if !isset($space['privacy']['filter_gid'][$group])}-->
						<p>{lang not_show_feed_homepage}</p>
						<!--{else}-->
						<p>{lang show_feed_homepage}</p>
						<!--{/if}-->
					</div>
					<p class="o pns">
						<button type="submit" name="groupignoresubmit_btn" class="pn pnc" value="true"><strong>{lang determine}</strong></button>
					</p>
				</form>
			</div>
		<!--{elseif $op=='request'}-->

			<div class="tbmu">
				<!--{if $list}-->
				<div class="wq_friend_operation wqnew_bottom">
                                    <a href="home.php?mod=spacecp&ac=friend&op=ignore&confirm=1&key=$space[key]&handlekey=all_cfrfriendhk_ignore" class="wq_ignore dialog">{$Tlang['4667315d3e1afd8d']}</a>
                                    <a href="home.php?mod=spacecp&ac=friend&op=addconfirm&key=$space[key]&handlekey=all_cfrfriendhk_post"  class="dialog">{$Tlang['a5d63bbf8989f6a6']}</a>
                                </div>
				<!--{/if}-->
				<!--{if $maxfriendnum}-->
                                    <div class="wq_friend_tbmu wqnew_bottom">
                                        ({lang max_friend_num})
                                            <!--{if $_G[setting][magics][friendnum]}-->
                                                <span class="y">
                                                    {$Tlang['e6bc045ab2e93181']}<a id="a_magic_friendnum" href="home.php?mod=magic&mid=friendnum">{$_G[setting][magics][friendnum]}</a>
                                                    <img src="{STATICURL}image/magic/friendnum.small.gif" alt="friendnum" class="vm" />
                                                </span>
                                                <p>({lang expansion_friend_message})</p>
                                            <!--{/if}-->
                                    </div>
				<!--{/if}-->
			</div>
			<!--{if $list}-->
                        <div class="wq_friend_request">
                            <ul id="friend_ul">
                                    <!--{loop $list $key $value}-->
                                    <li class="wqnew_bottom" id="friend_tbody_$value[fuid]">
                                        <div class="wq_head"><a href="home.php?mod=space&do=profile&uid=$value[fuid]" c="1"><!--{avatar($value[fuid],middle)}--></a></div>
                                        <div class="wq_con">
                                            <h3>
                                                    <a href="home.php?mod=space&do=profile&uid=$value[fuid]">$value[fusername]</a>
                                                    <!--{if $ols[$value[fuid]]}--><img src="{IMGDIR}/ol.gif" alt="online" title="{lang online}" class="vm" /> <!--{/if}-->
                                                    <!--{if $value['videostatus']}-->
                                                    <img src="{IMGDIR}/videophoto.gif" alt="videophoto" class="vm" /> <span class="xg1">{lang certified_by_video}</span>
                                                    <!--{/if}-->
                                            </h3>
                                            <div id="friend_$value[fuid]">
                                                    <!--{if $value[note]}--><div class="quote"><blockquote id="quote">$value[note]</blockquote></div><!--{/if}-->
                                                    <p><!--{date($value[dateline], 'n-j H:i')}--></p>
                                                    <p><a href="home.php?mod=spacecp&ac=friend&op=getcfriend&fuid=$value[fuid]&handlekey=cfrfriendhk_{$value[uid]}" id="a_cfriend_$key" class="wq_common dialog">{lang your_common_friends}</a></p>
                                                    <p>
                                                            <a href="home.php?mod=spacecp&ac=friend&op=add&uid=$value[fuid]&handlekey=afrfriendhk_{$value[uid]}" id="afr_$value[fuid]" class="wq_confirm dialog">{lang confirm_applications}</a>
                                                            <a href="home.php?mod=spacecp&ac=friend&op=ignore&uid=$value[fuid]&confirm=1&handlekey=afifriendhk_{$value[uid]}" id="afi_$value[fuid]" class="dialog">{lang ignore}</a>
                                                    </p>
                                            </div>
                                        </div>
                                    </li>
                                    <!--{/loop}-->
                            </ul>
                         </div>
                        <script type="text/javascript">
                            function succeedhandle_all_cfrfriendhk_ignore() {
                                wqall_cfrfriendhk();
                            }
                            function succeedhandle_all_cfrfriendhk_post(url, msg, values) {
                                clearInterval(setTimeout_location);
                                $.ajax({
                                    type: 'POST',
                                    url: url + '&inajax=1&handlekey=all_cfrfriendhk_post',
                                    dataType: 'html'
                                }).success(function(s) {
                                    var wq = wqXml(s);
                                    popup.open(wq);
                                    if($.trim(msg) == '{$Tlang[357c80f9fe7dbb3f]}'){
                                        wqall_cfrfriendhk();
                                    }else{
                                       evalscript(wq);
                                    }
                                }).error(function() {
                                    popup.open('{lang networkerror}', 'alert');
                                });
                            }
                            function wqall_cfrfriendhk(){
                                $('.wq_friend_operation').remove();
                                $('.wq_friend_request').hide();
                                $('.wq_friend_request').before('<div class="wqemp"><span class="wqno_con"><img src="{$_G[style][styleimgdir]}images/wqno_con.png"></span>{lang no_new_friend_application}</div>');
                                $('.wq_friend_request').remove();
                                wq_setTimeout();
                            }

                        </script>
			<!--{if $multi}--><div class="pgs cl mtm">$multi</div><!--{/if}-->
			<!--{else}-->
                            <div class="wqemp"><span class="wqno_con"><img src="{$_G['style'][styleimgdir]}images/wqno_con.png"></span>{lang no_new_friend_application}</div>
			<!--{/if}-->
		<!--{elseif $op=='getcfriend'}-->
                    <div class="wqshield_notice">
			<h3 class="wq_request_title">
				<!--{if count($list)>14}-->
				<em>{lang max_view_15_friends}</em>
				<!--{else}-->
                                <em> {eval echo count($list)} {$Tlang['45066d8d384cbab1']}</em>
				<!--{/if}-->
                                <!--{if $_G[inajax]}--><span class="y wq_friend_close"><a href="javascript:;" onclick="popup.close();" class="wqeject_cancel wqnew_right" title="{lang close}"><i class="wqiconfont2 wqicon2-iconuser wqapp_f20"></i></a></span><!--{/if}-->
			</h3>
                            <div class="wqshield_con">
				<!--{if $list}-->
				<ul class="wq_friend_list">
                                    <!--{loop $list $key $value}-->
					<li>
                                            <div class="avt"><a href="home.php?mod=space&do=profile&uid=$value[uid]"><!--{avatar($value[uid],small)}--><br/>$value[username]</a></div>
					</li>
                                    <!--{/loop}-->
				</ul>
				<!--{else}-->
				<p>{lang you_have_no_common_friends}</p>
				<!--{/if}-->
			</div>

                    </div>

		<!--{elseif $op=='add'}-->
                    <div class="wqshield_notice">
                        <form method="post" autocomplete="off"  name="addform_{$tospace[uid]}" action="home.php?mod=spacecp&ac=friend&op=add&uid=$tospace[uid]&inajax=yes">
                            <input type="hidden" name="referer" value="{echo dreferer()}" />
                            <input type="hidden" name="addsubmit" value="true" />
                            <!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
                            <input type="hidden" name="formhash" value="{FORMHASH}" />
                            <div class="wqshield_title">{$Tlang['70bfe1bd82881d57']}</div>
                            <div class="wqshield_height"></div>
                            <div class="wqshield_con">
                                <p class="wqinput"><input type="text" name="note" placeholder="{lang add}{$tospace[username]}{lang add_friend_note}" size="35" /></p>
                                <p>
                                    <select name="gid" class="wqselect">
                                        <!--{loop $groups $key $value}-->
                                             <option value="$key" {if empty($space['privacy']['groupname']) && $key==1} selected="selected"{/if}>$value</option>
                                        <!--{/loop}-->
                                    </select>
                                </p>
                            </div>
                            <p class="wqbtn_can wqnew_top">
                                <a href="javascript:;" onclick="popup.close();" class="wqeject_cancel wqnew_right">{lang cancel}</a>
                                <button type="submit" name="addsubmit_btn" id="addsubmit_btn" value="true" class="formdialog wqdetermine">{lang determine}</button>
                            </p>
			</form>
                    </div>
                    <script type="text/javascript">
                        function succeedhandle_$_GET[handlekey](url, msg, values) {
                            wq_setTimeout();
                        }
                    </script>
		<!--{elseif $op=='add2'}-->
                <div class="wqshield_notice">
			<form method="post" autocomplete="off" id="addratifyform_{$tospace[uid]}" name="addratifyform_{$tospace[uid]}" action="home.php?mod=spacecp&ac=friend&op=add&uid=$tospace[uid]">
                            <input type="hidden" name="referer" value="{echo dreferer()}" />
                            <input type="hidden" name="add2submit" value="true" />
                            <input type="hidden" name="from" value="$_GET[from]" />
                            <!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
                            <input type="hidden" name="formhash" value="{FORMHASH}" />
                            <div class="wqshield_title">{$Tlang['70bfe1bd82881d57']}</div>
                            <div class="wqshield_height"></div>
                            <div class="wqshield_con">
                                <table cellspacing="0" cellpadding="0" style="width: 100%;">
                                    <tr>
                                        <td valign="top">
                                            <div class="wqm_bottom10" style='text-align: left;'>{lang approval_the_request_group}:</div>
                                            <table>
                                                <tr>
                                                    <!--{eval $i=0;}-->
                                                        <div class="wqshield_con_border">
                                                            <select name="gid" class="wqselect">
                                                                <!--{loop $groups $key $value}-->
                                                                    <option value="$key" {if empty($space['privacy']['groupname']) && $key==1} selected="selected"{/if}>$value</option>
                                                                <!--{/loop}-->
                                                            </select>
                                                        </div>
                                                    <!--{if $i%2==1}--></tr><tr><!--{/if}-->
                                                    <!--{eval $i++;}-->
                                                </tr>
                                            </table>
                                        </td>
                                    </tr>
                                </table>
                            </div>
                            <p class="wqbtn_can">
                                <a href="javascript:;" onclick="popup.close();" class="wqeject_cancel wqnew_right">{lang close}</a>
                                <button type="submit" name="add2submit_btn" value="true" class="formdialog wqdetermine">{lang approval}</button>
                            </p>
			</form>
                    </div>
                    <script type="text/javascript">
                        function succeedhandle_$_GET[handlekey](url, msg, values) {
                            var obj1 = $('#friend_relation');
                            if(obj1.length > 0){
                                obj1.html('<a href="home.php?mod=spacecp&ac=friend&op=ignore&uid='+values['uid']+'&handlekey=ignore_friend"  class="dialog"><i class="wqiconfont2 wqicon2-shanchuhaoyou wqapp_f20"></i>{$Tlang[9b5fc1808acd0509]}</a>');
                                wq_setTimeout();
                            }

                            var obj2 = $('#friend_tbody_'+values['uid']);
                            if(obj2.length > 0){
                                obj2.remove();
                                if($('#friend_ul li.wqnew_bottom').length == 0){
                                    $('.wq_friend_request').before('<div class="wqemp"><span class="wqno_con"><img src="{$_G[style][styleimgdir]}images/wqno_con.png"></span>{lang no_new_friend_application}</div>');
                                }
                                wq_setTimeout();
                            }
                        }
                    </script>
		<!--{elseif $op=='getinviteuser'}-->
			$jsstr
		<!--{/if}-->

<!--{if !$_G[inajax]}-->
		</div>
	</div>

</div>
<!--{/if}-->

<!--{template common/footer}-->

<!--{/if}-->