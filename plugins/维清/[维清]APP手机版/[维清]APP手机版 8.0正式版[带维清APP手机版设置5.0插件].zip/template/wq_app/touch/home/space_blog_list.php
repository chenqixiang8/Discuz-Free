<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['space_blog_list'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{eval $header_nav='null';}-->
<!--{template common/header}-->
<div class="wqheader_lump wqbg_color  wqheader-position wqheader-relative">
    <div class="wqheader_div">
        <a href="{$backurl}" class="wqheader_left"><i class="wqiconfont2 wqicon2-fanhui-copy-copy wqapp_f22"></i></a>{$Tlang['c70356cafde614c1']}
        <!--{if helper_access::check_module('blog') && $space[self]}--><a href="home.php?mod=spacecp&ac=blog" class="y wqapp_f16 wqheader_right">{$Tlang['f02293b738fd9f49']}</a><!--{/if}-->
    </div>
</div>
<div class="wqheight44" style="display: none;"></div>
    <!--{if $space['uid']==$_G[uid]}-->
        <div class="appl my_album_list" style="overflow: hidden;">
            <div class="tbn tag_list">
                <ul>
                    <li$actives[we]><a href="home.php?mod=space&do=blog&view=we">{$Tlang[c50ac18ced40b59c]}</a></li>
                    <li$actives[me]><a href="home.php?mod=space&do=blog&view=me">{lang my_blog}</a></li>
                    <li$actives[all]><a href="home.php?mod=space&do=blog&view=all">{lang view_all}</a></li>
                </ul>
            </div>
        </div>
    <!--{/if}-->
    <!--{if $userlist}-->
        <div class="appl my_album_list casual_see">
            <select name="fuidsel" onchange="fuidgoto(this.value);" class="ps">
                <option value="">{lang all_friends}</option>
                <!--{loop $userlist $value}-->
                <option value="$value[fuid]"{$fuid_actives[$value[fuid]]}>$value[fusername]</option>
                <!--{/loop}-->
            </select>
        </div>
    <!--{/if}-->
    <!--{if $_GET[view] == 'me' && $classarr}-->
    <div class="my_private_roll wqnew_bottom" id="my_blog_roll">
        <div class="tag_list">
            <ul>
                <li {if !$_GET[classid]} class="a"{/if}><a href="home.php?mod=space&uid=$space[uid]&do=blog&view=me" >{$Tlang['8dfe4b30674494c1']}</a></li>
                <!--{loop $classarr $classid $classname}-->
                    <li {if $_GET[classid]==$classid} class="a"{/if}><a href="home.php?mod=space&uid=$space[uid]&do=blog&classid=$classid&view=me" id="classid$classid" >$classname</a></li>
                <!--{/loop}-->
            </ul>
        </div>
    </div>
<!--{eval $my_roll_tag='my_blog_roll';}-->
    <!--{template common/slide}-->
    <!--{/if}-->

<!--{if $list}-->
    <!--{eval $view=dhtmlspecialchars($_GET['view']);}-->
    <div class="wqindex_list wqmessage pulldown_load_js" contentid="blog_list_{$view}" count="{$count}" query_string="{$_SERVER['QUERY_STRING']}" page="$page" perpage="$perpage">
        <ul class="wqindex_list_ul" id="blog_list_{$view}">
            <!--{subtemplate home/space_blog_list_1}-->
        </ul>
        <!--{eval echo wq_app_load_icon();}-->
    </div>
    <p class="wqloaded_all" style="display:none;" >{$Tlang['b3f7b411f8a25701']}</p>
    <div class="new_hide" style="display: none;"></div>
<!--{else}-->
    <p class="wqemp">
        <span class="wqno_con"><img src="{$_G['style']['styleimgdir']}images/wqno_con.png"></span>{lang no_related_blog}
    </p>
<!--{/if}-->
<script>
    function fuidgoto(fuid) {
        location.href = 'home.php?mod=space&do=blog&view=we' + (fuid != '' ? '&fuid=' + fuid : '');
    }
</script>
<!--{template common/footer}-->
<!--{/if}-->