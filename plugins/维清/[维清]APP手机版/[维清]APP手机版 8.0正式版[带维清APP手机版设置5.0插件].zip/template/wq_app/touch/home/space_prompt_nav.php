<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['space_prompt_nav'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->

  <div class="wqpersonal_secrecy">
             <ul>
                 <!--{eval $wqnotice = array('mypost'=>'wqicon2-tiezisousuo wqimg_1','interactive'=>'wqicon2-hudong wqimg_2','system'=>'wqicon2-tixing1 wqimg_3');}-->
                 <!--{loop $_G['notice_structure'] $key $type}-->
                <!--{if in_array($key, array('mypost','interactive','system'))}-->
                <li $opactives[$key]>
                    <a href="home.php?mod=space&do=notice&view=$key">
                     <div class="wqicon"><em class="notice_$key"><i class="wqiconfont2 {$wqnotice[$key]} wqapp_f20 wqimg"></i></em></div>
                     <div class="wqpersonal_secrecy_right wqm_left44"><!--{eval echo lang('template', 'notice_'.$key)}--><!--{if $_G['member']['category_num'][$key]}--><span class="wqprompt"></span><!--{/if}--><span class="y wq_arrow"><!--{if $_G['member']['category_num'][$key]}-->$_G['member']['category_num'][$key]{$Tlang['edb32dc5618bc9e9']}<!--{/if}--><i class="wqiconfont2 wqicon2-jiantou wqm_left6"></i></span></div>
                    </a>
                </li>
                <!--{/if}-->
                <!--{/loop}-->
            </ul>
        </div>



<!--{/if}-->