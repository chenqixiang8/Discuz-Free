<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['space_profile'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{template common/header}-->
<style>body{ background-color: #f2f4f7;} </style>
<!--{if !empty($myimg)}-->
    <style>.wqpersonal_bg{background-image: url({$myimg});}</style>
<!--{/if}-->
<!--{eval $userposts = $space['posts'];}-->
 <div class="wqpersonal_warp">
    <div class="wqpersonal_bg" ><!--{if !empty($_G['cache']['plugin']['wq_space'])}--> <a href="plugin.php?id=wq_space"></a><!--{/if}--></div>
   <div class="wqpersonal_head">
        <a href="javascript: void(0);">
            <img id="head_image" src="{avatar($space[uid], middle, true)}" class="wqsethead" />
        </a>
    </div>
    <h3 class="wqpersonal_user wqapp_f20"><a href="home.php?mod=space&do=profile&uid=$space[uid]" class="wqwhite wqellipsis" style="color:{$space[group][color]}">$space[username]</a></h3>
    <div class="wqpersonal_head_fansfollow">
       <div class="wqfollow"><span><a href="home.php?mod=follow&do=following&uid={$space['uid']}" class="wqwhite">{$Tlang['2c8a07313e7706bc']} {$space['following']}</a></span></div>
        <div class="wqline"></div>
        <div class="wqfans"><span><a href="home.php?mod=follow&do=follower&uid={$space[uid]}" class="wqwhite">{$Tlang['bbd702ca1f76841a']} $space['follower']</a></span></div>
    </div>
    <div class="wqpersonal_autograph wqellipsis">
         <!--{if $space['sightml']}-->
        $space['sightml']
        <!--{else}-->
        {$Tlang['4f615502be264330']}
     <!--{/if}-->

    </div>
     <!--{if $space['uid'] != $_G['uid']}-->
    <div class="wqothers_more wqnew_top">
        <ul>
            <!--{eval $follow = 0;}-->
            <!--{eval $follow = C::t('home_follow')->fetch_all_by_uid_followuid($_G['uid'], $space['uid']);}-->
            <!--{if !$follow}-->
            <li><a href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid={$space[uid]}&handlekey=add_attention" class="dialog notlogged wqnew_right"><i class="wqiconfont2 wqicon2-guanzhu wqapp_f18"></i>{$Tlang['2c8a07313e7706bc']}</a></li>
            <!--{else}-->
            <li><a href="home.php?mod=spacecp&ac=follow&op=del&hash={FORMHASH}&fuid={$space[uid]}&handlekey=cancel_attention" class="dialog notlogged wqnew_right"><i class="wqiconfont2 wqicon2-iconfontfollowok wqapp_f20"></i>{$Tlang['914d2c5341afe66f']}</a></li>
            <!--{/if}-->
            <li><a href="home.php?mod=space&do=pm&subop=view&touid=$space[uid]#last" class="wqnew_right"><i class="wqiconfont2 wqicon2-xiaoxi wqapp_f16 wqsend_message notlogged"></i>{$Tlang['29c5cc0e5fe68d2e']}</a></li>
            <li><a href="home.php?mod=spacecp&ac=poke&op=send&uid=$space[uid]&handlekey=propokehk" class="wqnew_right"><i class="wqiconfont2 wqicon2-cgdazhaohu wqapp_f18 notlogged"></i>{$Tlang['6f9fef320a80fb33']}</a></li>
            <li id="friend_relation">
                <!--{if !$isfriend}-->
                <a href="home.php?mod=spacecp&ac=friend&op=add&uid=$space[uid]&handlekey=add_friend" class="dialog wqnew_right"><i class="wqiconfont2 wqicon2-haoyou-copy wqapp_f20 notlogged"></i>{$Tlang['80f4502bde9c9130']}</a>
                <!--{else}-->
                <a href="home.php?mod=spacecp&ac=friend&op=ignore&uid=$space[uid]&handlekey=ignore_friend" class="dialog wqnew_right"><i class="wqiconfont2 wqicon2-shanchuhaoyou wqapp_f20"></i>{$Tlang['9b5fc1808acd0509']}</a>
                <!--{/if}-->
            </li>
        </ul>
    </div>
    <!--{/if}-->
</div>

 <!--{if $wq_app_setting['home_navmenu'] == 1}-->
<div class="wqpersonal_list my_personal_roll">
    <div class="tag_list">
        <ul>
            <!--{if helper_access::check_module('follow')}-->
            <li class="wqnew_right"><a href="home.php?mod=follow&uid={$space['uid']}&do=view&from=space">{$Tlang['7290c0040c783494']}<br><span>{$space['feeds']}</span></a></li>
            <!--{/if}-->
            <li class="wqnew_right"><a href="home.php?mod=space&uid={$space['uid']}&do=thread&view=me&type=thread&from=space">{$Tlang['57f5cb4a5a928cae']}<br><span>{$space['threads']}</span></a></li>
            <!--{if helper_access::check_module('blog')}-->
            <li class="wqnew_right"><a href="home.php?mod=space&uid=$space['uid']&do=blog&view=me&from=space">{$Tlang['c70356cafde614c1']}<br><span>$space['blogs']</span></a></li>
            <!--{/if}-->
            <!--{if helper_access::check_module('album')}-->
            <li class="wqnew_right"><a href="home.php?mod=space&uid=$space['uid']&do=album&view=me&from=space">{$Tlang['6be0b791b8a8138f']}<br><span>$space['albums']</span></a></li>
            <!--{/if}-->
            <!--<li><a href="javascript:;">{$Tlang['dae251a4f8687b1c']}<br><span>1</span></a></li>-->
            <!--{if helper_access::check_module('wall')}-->
            <!--{eval $count_wall = C::t('home_comment')->count_by_id_idtype($space['uid'], 'uid', 0);;}-->
            <li class="wqno_border"><a href="home.php?mod=space&do=wall&from=space&uid={$space['uid']}">{$Tlang['4cc652d2a2685c2d']}<br><span>$count_wall</span></a></li>
            <!--{/if}-->
        </ul>
    </div>
</div>
<!--{elseif $wq_app_setting['home_navmenu'] == 2}-->
<div class="wqpersonal_list my_personal_roll my_personal_roll2">
    <div class="tag_list">
        <ul>
            <!--{if helper_access::check_module('follow')}-->
            <li class="wqnew_right"><a href="home.php?mod=follow&uid={$space['uid']}&do=view&from=space">{$Tlang['7290c0040c783494']}</a></li>
            <!--{/if}-->
            <li class="wqnew_right"><a href="home.php?mod=space&uid={$space['uid']}&do=thread&view=me&type=thread&from=space">{$Tlang['57f5cb4a5a928cae']}</a></li>
            <!--{if helper_access::check_module('blog')}-->
            <li class="wqnew_right"><a href="home.php?mod=space&uid=$space['uid']&do=blog&view=me&from=space">{$Tlang['c70356cafde614c1']}</a></li>
            <!--{/if}-->
            <!--{if helper_access::check_module('album')}-->
            <li class="wqnew_right"><a href="home.php?mod=space&uid=$space['uid']&do=album&view=me&from=space">{$Tlang['6be0b791b8a8138f']}</a></li>
            <!--{/if}-->
            <!--{if helper_access::check_module('wall')}-->
            <!--{eval $count_wall = C::t('home_comment')->count_by_id_idtype($space['uid'], 'uid', 0);;}-->
            <li class="wqno_border"><a href="home.php?mod=space&do=wall&from=space&uid={$space['uid']}">{$Tlang['4cc652d2a2685c2d']}</a></li>
            <!--{/if}-->
        </ul>
    </div>
</div>
<!--{elseif $wq_app_setting['home_navmenu'] == 3}-->
<div class="wqpersonal_list my_personal_roll my_personal_roll3">
    <div class="tag_list">
        <ul>
            <!--{if helper_access::check_module('follow')}-->
            <li class="wqnew_right"><a href="home.php?mod=follow&uid={$space['uid']}&do=view&from=space"><i class="wqiconfont2 wqicon2-guangbo wqapp_f22"></i><br><span>{$space['feeds']}</span></a></li>
            <!--{/if}-->
            <li class="wqnew_right"><a href="home.php?mod=space&uid={$space['uid']}&do=thread&view=me&type=thread&from=space"><i class="wqiconfont2 wqicon2-fabu1 wqapp_f20"></i><br><span>{$space['threads']}</span></a></li>
            <!--{if helper_access::check_module('blog')}-->
            <li class="wqnew_right"><a href="home.php?mod=space&uid=$space['uid']&do=blog&view=me&from=space"><i class="wqiconfont2 wqicon2-rizhi2 wqapp_f20"></i><br><span>$space['blogs']</span></a></li>
            <!--{/if}-->
            <!--{if helper_access::check_module('album')}-->
            <li class="wqnew_right"><a href="home.php?mod=space&uid=$space['uid']&do=album&view=me&from=space"><i class="wqiconfont2 wqicon2-tupian2 wqapp_f20"></i><br><span>$space['albums']</span></a></li>
            <!--{/if}-->
            <!--{if helper_access::check_module('wall')}-->
            <!--{eval $count_wall = C::t('home_comment')->count_by_id_idtype($space['uid'], 'uid', 0);;}-->
            <li class="wqno_border"><a href="home.php?mod=space&do=wall&from=space&uid={$space['uid']}"><i class="wqiconfont2 wqicon2-liuyan wqapp_f20"></i><br><span>$count_wall</span></a></li>
            <!--{/if}-->
        </ul>
    </div>
</div>
 <!--{/if}-->

<!--{eval $my_roll_tag='my_personal_roll';}-->
<!--{subtemplate common/slide}-->

<!--{if $_GET['mycenter'] == '1'}-->
<div class="wqseparate"></div>
<div class="wqpersonal_secrecy">
    <ul>
        <li>
           <a href="home.php?mod=spacecp&op=index">
               <div class="wqicon wqshezhi"><i class="wqiconfont2 wqicon2-shezhi wqapp_f24"></i></div>
               <div class="wqpersonal_secrecy_right wqno_border">{$Tlang['94159469baeee72d']}<i class="wqiconfont2 wqicon2-jiantou y wq_arrow wqapp_f16"></i></div>
           </a>
       </li>
   </ul>
</div>
<div class="wqseparate"></div>
<div class="wqpersonal_secrecy">
    <ul>
        <li>
            <a href="home.php?mod=space&do=friend">
                <div class="wqicon wqcollection"><i class="wqiconfont2 wqicon2-haoyou-copy wqapp_f22" style=" line-height: normal;"></i></div>
                <div class="wqpersonal_secrecy_right">{$Tlang['492d7428cf380a08']}<i class="wqiconfont2 wqicon2-jiantou y wq_arrow wqapp_f16"></i><span class="y wq_arrow wqm_right10"></span></div>
            </a>
        </li>
		<li>
            <a href="home.php?mod=space&do=pm">
                <div class="wqicon wqnews"><i class="wqiconfont2 wqicon2-xiaoxi wqapp_f22"></i></div>
                <div class="wqpersonal_secrecy_right wqnew_bottom">{$Tlang['1c36a143f82ce389']}<!--{if $_G[member][newpm]}--><span class="wqprompt"></span><!--{/if}--><i class="wqiconfont2 wqicon2-jiantou y wq_arrow wqapp_f16"></i><!--{if $_G[member][newpm]}--><span class="y wq_arrow wqm_right10">{$_G[member][newpm]}{$Tlang['0d2d986e225715fd']}</span><!--{/if}--></div>
            </a>
        </li>
        <li>
            <a href="home.php?mod=space&do=notice&view">
                <div class="wqicon wqremind"><i class="wqiconfont2 wqicon2-tixing wqapp_f22"></i></div>
                <div class="wqpersonal_secrecy_right wqnew_bottom">{$Tlang['35ebc17f15aba47a']}<!--{if $_G[member][newprompt]}--><span class="wqprompt"></span><!--{/if}--><i class="wqiconfont2 wqicon2-jiantou y wq_arrow wqapp_f16"></i><span class="y wq_arrow wqm_right10"><!--{if $_G[member][newprompt]}-->{$_G[member][newprompt]}{$Tlang['edb32dc5618bc9e9']}<!--{/if}--></span></div>
            </a>
        </li>
        <!--{if $_G['setting']['verify']['enabled'] && allowverify() || $_G['setting']['my_app_status'] && $_G['setting']['videophoto']}-->
        <!--{eval $verify = wq_app_get_new_verify($_G['uid'],false,4);}-->
        <!--{eval //echo"<pre>"; print_r($verify);exit;}-->
        <li>
            <a href="{if $_G['setting']['verify']['enabled']}home.php?mod=spacecp&ac=profile&op=verify{else}home.php?mod=spacecp&ac=videophoto{/if}">
                <div class="wqicon wqauthentication"><i class="wqiconfont2 wqicon2-renzheng wqapp_f22"></i></div>
                <div class="wqpersonal_secrecy_right wqnew_bottom">&#x6211;&#x7684;&#x8BA4;&#x8BC1;
                    <i class="wqiconfont2 wqicon2-jiantou y wq_arrow wqapp_f16"></i>
                    <span class="y wqimg_a wqm_right10">
                        <!--{loop $verify['verifyicon'] $vid}-->
                           <!--{if $_G['setting']['verify'][$vid]['icon']}-->
                                <img src="$_G['setting']['verify'][$vid]['icon']" alt="$_G['setting']['verify'][$vid][title]" title="$_G['setting']['verify'][$vid][title]">
                            <!--{else}-->
                                {$_G['setting']['verify'][$vid][title]}
                            <!--{/if}-->
                        <!--{/loop}-->
                    </span>
                </div>
            </a>
        </li>
        <!--{/if}-->
        <li>
            <a href="home.php?mod=space&uid={$_G[uid]}&do=favorite&view=me&type=thread">
                <div class="wqicon wqcollection"><i class="wqiconfont2 wqicon2-favorite wqapp_f22" style=" line-height: normal;"></i></div>
                <div class="wqpersonal_secrecy_right">{$Tlang['e17c06793e315f8a']}<i class="wqiconfont2 wqicon2-jiantou y wq_arrow wqapp_f16"></i><span class="y wq_arrow wqm_right10"></span></div>
            </a>
        </li>
        <li>
            <a href="home.php?mod=magic">
                <div class="wqicon wqprop"><i class="wqiconfont2 wqicon2-jingxuan wqapp_f24" style=" line-height: normal;"></i></div>
                <div class="wqpersonal_secrecy_right wqno_border">{$Tlang['9750e35d7e3c69f0']}<i class="wqiconfont2 wqicon2-jiantou y wq_arrow wqapp_f16"></i><span class="y wq_arrow wqm_right10"></span></div>
            </a>
        </li>
    </ul>
</div>
<!--{if $_G['cache']['plugin']['wq_usergroup'] || $_G['cache']['plugin']['wq_reward'] || $_G['cache']['plugin']['wq_buycredit']}-->
<div class="wqseparate"></div>
<div class="wqpersonal_secrecy">
     <ul>
          <!--{if !empty($_G['cache']['plugin']['wq_usergroup'])}-->
        <li>
            <a href="plugin.php?id=wq_usergroup">
                <div class="wqicon wqusergroup"><i class="wqiconfont2 wqicon2-yonghuzuguanli wqapp_f22"></i></div>
                <div class="wqpersonal_secrecy_right wqnew_bottom">&#x8D2D;&#x4E70;&#x7528;&#x6237;&#x7EC4;<i class="wqiconfont2 wqicon2-jiantou y wq_arrow wqapp_f16"></i><span class="y wq_arrow wqm_right10"></span></div>
            </a>
        </li>
        <!--{/if}-->
        <!--{if !empty($_G['cache']['plugin']['wq_reward'])}-->
        <li>
            <a href="home.php?mod=spacecp&ac=plugin&id=wq_reward:spacecp_reward">
                <div class="wqicon wqreward"><i class="wqiconfont2 wqicon2-dashang wqapp_f24"></i></div>
                <div class="wqpersonal_secrecy_right wqnew_bottom">&#x73B0;&#x91D1;&#x6253;&#x8D4F;<i class="wqiconfont2 wqicon2-jiantou y wq_arrow wqapp_f16"></i><span class="y wq_arrow wqm_right10"></span></div>
            </a>
        </li>
        <!--{/if}-->
        <!--{if !empty($_G['cache']['plugin']['wq_buycredit'])}-->
        <li>
            <a href="plugin.php?id=wq_buycredit">
                <div class="wqicon wqbuycredit"><i class="wqiconfont2 wqicon2-jifen wqapp_f24"></i></div>
                <div class="wqpersonal_secrecy_right wqnew_bottom">&#x79EF;&#x5206;&#x5145;&#x503C;<i class="wqiconfont2 wqicon2-jiantou y wq_arrow wqapp_f16"></i><span class="y wq_arrow wqm_right10"></span></div>
           </a>
        </li>
        <!--{/if}-->
    </ul>
</div>
<!--{/if}-->

<!--{if $_G['cache']['plugin']['wq_login'] || $_G['cache']['plugin']['wq_smslogin']}-->
<div class="wqseparate"></div>
<div class="wqpersonal_secrecy">
    <ul>
        <!--{if $_G['cache']['plugin']['wq_login']}-->
            <li>

                <div class="wqicon wqweixin"><i class="wqiconfont2 wqicon2-perweixin wqapp_f24"></i></div>
                <div class="wqpersonal_secrecy_right wqno_phonebord">
                    <!--{eval include_once template('wq_login:tpl_login_profile');}-->
                    <!--{echo tpl_login_profile($_G);}-->
                </div>

            </li>
        <!--{/if}-->
        <!--{if $_G['cache']['plugin']['wq_qqlogin']}-->
            <li>
                <div class="wqicon wqqq_bind"><i class="wqiconfont2 wqicon2-perqq wqapp_f22"></i></div>
                <div class="wqpersonal_secrecy_right wqno_phonebord">
                    <!--{eval  include_once template('wq_qqlogin:module');}-->
                    <!--{echo _tpl_qqlogin_profile();}-->
                </div>

            </li>
        <!--{/if}-->
        <!--{if $_G['cache']['plugin']['wq_smslogin']}-->

            <!--{eval
                $sms_bind = C::t("#wq_smslogin#wq_smslogin_bindlogs")->fetch_by_uid_is_bind($_G['uid']);
                $allow_mobile_verify = $_G['cache']['plugin']['wq_smslogin']['allow_mobile_verify'];
                $bind_is_not_password = $_G['cache']['plugin']['wq_smslogin']['bind_is_write_password'];
            }-->
            <!--{if $sms_bind || $allow_mobile_verify}-->
            <li>
                <div class="wqicon wqphone"><i class="wqiconfont2 wqicon2-shouji1 wqapp_f24"></i></div>
                <div class="wqpersonal_secrecy_right wqno_border wqno_phonebord">
                    <!--{eval include_once template('wq_smslogin:module');}-->
                    <!--{echo module($sms_bind,$allow_mobile_verify,$bind_is_not_password);}-->
                </div>
            </li>
            <!--{/if}-->
        <!--{/if}-->
    </ul>
</div>
<!--{/if}-->
<!--{if !empty($_G['cache']['plugin']['wq_wechatreader'])}-->
<div class="wqseparate"></div>
<div class="wqpersonal_secrecy">
    <ul>
       <li>
           <a href="plugin.php?id=wq_wechatreader&mod=index">
            <div class="wqicon wqkey"><i class="wqiconfont2 wqicon2-guanjianci wqapp_f22"></i></div>
            <div class="wqpersonal_secrecy_right wqnew_bottom">{$Tlang['89233c735152ce77']}<i class="wqiconfont2 wqicon2-jiantou y wq_arrow wqapp_f16"></i><span class="y wq_arrow wqm_right10"></span></div>
           </a>
       </li>
        <li>
            <a href="plugin.php?id=wq_wechatreader&mod=index&step=1">
            <div class="wqicon wqtext"><i class="wqiconfont2 wqicon2-weiwen wqapp_f22"></i></div>
            <div class="wqpersonal_secrecy_right wqnew_bottom">{$Tlang['0ff529101fb9cfa3']}<i class="wqiconfont2 wqicon2-jiantou y wq_arrow wqapp_f16"></i><span class="y wq_arrow wqm_right10"></span></div>
           </a>
       </li>
       <li>
            <a href="plugin.php?id=wq_wechatreader&mod=index&step=2">
            <div class="wqicon wqnumber"><i class="wqiconfont2 wqicon2-woguanzhude wqapp_f22"></i></div>
            <div class="wqpersonal_secrecy_right wqno_border">{$Tlang['63b16ceb118e80f7']}<i class="wqiconfont2 wqicon2-jiantou y wq_arrow wqapp_f16"></i><span class="y wq_arrow wqm_right10"></span></div>
           </a>
       </li>
   </ul>
</div>
<!--{/if}-->

<!--{if $me_menu}-->
    <div class="wqseparate"></div>
    <div class="wqpersonal_secrecy">
        <ul>
            <!--{loop $me_menu $mkey $mval}-->
                <li>
                   <a href="{$wq_app_menulist[$mval][menuurl]}">
                       <div class="wqicon"{if $wq_app_menulist[$mval][menuicon]} style="color:{$wq_app_menulist[$mval][menuicon]}"{/if}><i class="{$wq_app_menulist[$mval][notmenuicon]} wqapp_f24"></i></div>
                       <div class="wqpersonal_secrecy_right wqno_border">{$wq_app_menulist[$mval][menuname]}<i class="wqiconfont2 wqicon2-jiantou y wq_arrow wqapp_f16"></i><span class="y wq_arrow wqm_right10"></span></div>
                   </a>
               </li>
           <!--{/if}-->
       </ul>
    </div>
<!--{/if}-->

<!--{elseif $_GET['uid']!= $_G['uid'] && $_GET['mycenter'] == '2'}-->
<div class="wqpersonal_warp">
    <div class="wqpersonal_bg"></div>
    <div class="wqpersonal_return">
        <a href="javascript:;" class="wqiconfont2 wqicon2-fanhui-copy-copy wqapp_f22 wqreturn"></a>
        <a href="javascript:;" class="wqset wqset6 wqapp_f17" onclick="document.getElementById('wqmycenter_js').style.display = 'block';">{$Tlang['db9c470ab0853172']}</a>
        <div class="wqadmin_eject"  id="wqmycenter_js" style="display: none;">
            <span class="wqadmin_eject_arrow"></span>
            <ul>
                <li><a href="javascript:;" ><i class="wqiconfont2 wqicon2-myguanzhu wqapp_f20"></i>{$Tlang['2c8a07313e7706bc']}</a></li>
                <li><a href="javascript:;" ><i class="wqiconfont2 wqicon2-quxiao wqapp_f20"></i>{$Tlang['08b5128ae675d0d9']}</a></li>
                <li><a href="home.php?mod=space&do=pm&subop=view&touid=$space[uid]#last" ><i class="wqiconfont2 wqicon2-xiaoxi wqapp_f18 wqsend_message"></i>{$Tlang['29c5cc0e5fe68d2e']}</a></li>
                <li><a href="home.php?mod=spacecp&ac=poke&op=send&uid=$space[uid]&handlekey=propokehk" ><i class="wqiconfont2 wqicon2-cgdazhaohu wqapp_f20"></i>{$Tlang['6f9fef320a80fb33']}</a></li>
                <li id="friend_relation">
                    <!--{if !$isfriend}-->
                    <a href="home.php?mod=spacecp&ac=friend&op=add&uid=$space[uid]&handlekey=add_friend" class="dialog"><i class="wqiconfont2 wqicon2-haoyou-copy wqapp_f20"></i>{$Tlang['80f4502bde9c9130']}</a>
                    <!--{else}-->
                    <a href="home.php?mod=spacecp&ac=friend&op=ignore&uid=$space[uid]&handlekey=ignore_friend"  class="dialog"><i class="wqiconfont2 wqicon2-shanchuhaoyou wqapp_f20"></i>{$Tlang['9b5fc1808acd0509']}</a>
                    <!--{/if}-->
                </li>
            </ul>
        </div>
    </div>
    <div class="wqpersonal_head">
        <a href="javascript:;">
            <img src="{avatar($space[uid], middle, true)}">
        </a>
    </div>
    <h3 class="wqpersonal_user wqapp_f22"><a href="javascript:;" class="wqwhite wqellipsis ">$space[username]</a></h3>
    <div class="wqpersonal_head_fansfollow">
        <div class="wqfollow"><span><a href="home.php?mod=follow&do=follower&uid={$space[uid]}" class="wqwhite">{$Tlang['2c8a07313e7706bc']} {$space['following']}</a></span></div>
        <div class="wqline"></div>
        <div class="wqfans"><span><a href="home.php?mod=follow&do=following&uid={$space['uid']}" class="wqwhite">{$Tlang['bbd702ca1f76841a']} $space['follower']</a></span></div>
    </div>
    <div class="wqpersonal_autograph wqellipsis">
         <!--{if $space['sightml']}-->
            $space['sightml']
            <!--{else}-->
        {$Tlang['4f615502be264330']}
         <!--{/if}-->
    </div>
</div>
<div class="wqpersonal_list my_personal_roll" id="my_personal_roll">
    <div class="tag_list">
        <ul>
             <!--{if helper_access::check_module('follow')}-->
            <li><a href="home.php?mod=follow&uid={$space['uid']}&do=view&from=space">{$Tlang['7290c0040c783494']}<br><span>{$space['feeds']}</span></a></li>
             <!--{/if}-->
            <li><a href="home.php?mod=space&uid={$space['uid']}&do=thread&view=me&type=thread&from=space">{$Tlang['57f5cb4a5a928cae']}<br><span>{$space['threads']}</span></a></li>
            <!--{if helper_access::check_module('blog')}-->
            <li><a href="home.php?mod=space&uid=$space['uid']&do=blog&view=me&from=space">{$Tlang['c70356cafde614c1']}<br><span>$space['blogs']</span></a></li>
            <!--{/if}-->
            <!--{if helper_access::check_module('album')}-->
            <li><a href="home.php?mod=space&uid=$space['uid']&do=album&view=me&from=space">{$Tlang['6be0b791b8a8138f']}<br><span>$space['albums']</span></a></li>
            <!--{/if}-->
            <!--<li><a href="javascript:;">{$Tlang['dae251a4f8687b1c']}<br><span>1</span></a></li>-->
            <!--{if helper_access::check_module('wall')}-->
            <!--{eval $count_wall = C::t('home_comment')->count_by_id_idtype($space['uid'], 'uid', 0);;}-->
            <li class="wqno_border"><a href="home.php?mod=space&do=wall&from=space&uid={$space['uid']}">{$Tlang['4cc652d2a2685c2d']}<br><span>$count_wall</span></a></li>
            <!--{/if}-->
        </ul>
    </div>
</div>
<!--{eval $my_roll_tag='my_personal_roll';}-->
<!--{subtemplate common/slide}-->
<div class="wqseparate"></div>
<div class="wqrelay_warp">
    <ul>
        <!--{loop $list['feed'] $feed}-->
	<li id="feed_li_$feed['feedid']" onmouseover="this.className='flw_feed_hover cl'" onmouseout="this.className='cl'">
            <div class="wqmessage_info_div wqblock">
                <a href="home.php?mod=space&do=profile&uid=$feed[uid]">
                    <img src="<!--{if !$feed['uid'] || $post['anonymous']}--><!--{avatar(0, small, true)}--><!--{else}--><!--{avatar($feed[uid], small, true)}--><!--{/if}-->" class="wqhead" />
                    <div class="wqmessage_info">
                        <h2 class="wqname wqellipsis">$feed['username']</h2>
                        <p class="wq_grey wqellipsis wqapp_f14"><!--{eval echo dgmdate($feed['dateline'], 'u');}--></p>
                    </div>
                </a>
                <div class="wqmessage_info_btn">
                    <!--{if $feed[uid] == $_G[uid] || $_G['adminid'] == 1}--><a href="home.php?mod=spacecp&ac=follow&feedid=$feed[feedid]&op=delete" id="c_delete_$feed['feedid']" onclick="showWindow(this.id, this.href, 'get', 0);">{$Tlang['0d9efacf5089d88c']}</a>
                    <!--{/if}-->
                </div>
            </div>
            <!--{if !empty($thread) && $thread['displayorder'] >= 0}-->
<!--            <div class="wqbroadcast_text">
                <a href="javascript:;">
                    <h3>
                        {if isset($carray[$feed['cid']])}
                        {lang follow_open_feed}
                        {/if}
                        {if $thread[fid] != $_G[setting][followforumid]}
                        $thread['subject']
                        {/if}
                    </h3>
                    <div class="list_pane3">
                        <img src="template/wq_app/static/images/img_2.jpg">
                        <img src="template/wq_app/static/images/img_1.jpg">
                        <img src="template/wq_app/static/images/img_3.jpg">
                        <span class="wqlisttu2"><i class="wqiconfont2 wqicon2-tupian-copy wqapp_f14 wqm_right2"></i>4</span>
                    </div>
                </a>
            </div>
            <p class="wqbroadcast_reply"><span class="wqplate_name"><a href="javascript:;">{$Tlang['4b794d23475313ad']}</a></span>{$Tlang['cb81657d597f5ac3']}</p>
            <p class="wqbroadcast_reply"><span class="wqplate_name"><a href="javascript:;">{$Tlang['010853d7f2ec5dbc']}</a></span>{$Tlang['209e3f19421ead4d']}<span class="wqplate_name">
                    <a href="javascript:;">{$Tlang['4b794d23475313ad']}</a></span>{$Tlang['cb81657d597f5ac3']}</p>
            <p class="list_info wqm_top10 wqm_bottom10">
             {$Tlang['4c831b7d5d9fa55f']}
                <span class="y"><i class="wqiconfont2 wqicon2-pinglun2 wqapp_f12"></i>1</span>
                <span class="y wqm_right10"><i class="wqiconfont2 wqicon2-p-see"></i>25</span>
            </p>
            <div class="wqseparate"></div>
              {else}
            <h3 class="wqbroadcast_reason">{$Tlang['3b5a0575a80afe99']}</h3>
            <div class="wqbroadcast_con">
                <a href="javascript:;">
                    <div class="wqlist1"> <img src="template/wq_app/static/images/img_1.jpg"></div>
                    <div class="wqlisthidden">
                        <h3 class="wqtitle_list">{$Tlang['9347244142910939']}</h3>
                    </div>
                    <p class="list_info"><span class="wqplate_name">{$Tlang['56c03e6bc953d548']}</span>
                        <span class="y">{$Tlang['a1a26940441d6577']}</span>
                    </p>
                </a>
            </div>
            <p class="wqbroadcast_reply"><span class="wqplate_name"><a href="javascript:;">{$Tlang['4b794d23475313ad']}</a></span>{$Tlang['cb81657d597f5ac3']}</p>
            <p class="wqbroadcast_reply"><span class="wqplate_name"><a href="javascript:;">{$Tlang['010853d7f2ec5dbc']}</a></span>{$Tlang['209e3f19421ead4d']}<span class="wqplate_name"><a href="javascript:;">{$Tlang['4b794d23475313ad']}</a></span>{$Tlang['cb81657d597f5ac3']}</p>
            <p class="list_info wqm_top10 wqm_bottom10">

                2016-3-20
                <span class="y" style="width: 24px; text-align: right;"><a href="javascript:;" class="wqblock"><i class="wqiconfont2 wqicon-gbdelete wqapp_f12"></i></a></span>
                <span class="y"><a href="javascript:;"><i class="wqiconfont2 wqicon-tubiao05 wqapp_f12"></i>1</a></span>
                <span class="y wqp_right10"><a href="javascript:;"><i class="wqiconfont2 wqicon-textfenxiang"></i>25</a></span>
            </p>
            <div class="wqseparate"></div>-->
            <!--{/if}-->
	</li>
        <!--{/loop}-->
    </ul>
</div>
<script>
    var myArray = new Array();
    $('body').on('click', '#wq_login_bind', function () {
        var wq_id = $(this).attr('id');
        if (myArray[wq_id]) {
        popup.open(myArray[wq_id]);
        } else {
            $.post($(this).attr('href'), {inajax: 1}, function(s) {
                var wq = wqXml(s);
                popup.open(wq);
                myArray[wq_id] = wq;
            }, 'html');
        }
    post_submit = false;
    return false;
    });
</script>
<!--{else}-->
    <div class="wqseparate"></div>
    <div class="wqpersonal_data">
        <ul>
            <li><em>{$Tlang['bdcb7133967c3548']}</em><span class="text_left">$space['uid']</span></li>
            <li><em>{$Tlang['714c1acb4dafef05']}</em><span class="text_left"><!--{if $space['sightml']}-->$space['sightml']<!--{else}-->{$Tlang['4f615502be264330']}<!--{/if}--></span></li>
            <!--{eval $myverify = wq_app_get_new_verify($_GET['uid'],true);}-->
            <!--{if $_G[setting][verify]}-->
                <!--{eval $showverify = true;}-->
                <!--{eval $userifno=getuserbyuid($_GET['uid']); }-->
                    <!--{loop $_G['setting']['verify'] $vid $verify}-->
                       <!--{if $verify['available'] &&(empty($verify['groupid']) ||( !empty($verify['groupid']) && in_array($userifno['groupid'], $verify['groupid'])))}-->
                            <!--{if $showverify}-->
                                <li>
                                <em>&#x7528;&#x6237;&#x8BA4;&#x8BC1;</em>
                                <span class="text_left wqhome_authentication">
                                <!--{eval $showverify = false;}-->
                            <!--{/if}-->
                            <a  href="home.php?mod=spacecp&ac=profile&op=verify&vid=$vid">
                                <!--{if $myverify[$_GET["uid"]]["verify".$vid]==1}-->
                                    <!--{if $verify['icon']}--><img src="$_G['setting']['verify'][$vid]['icon']"/><!--{else}-->$verify[title]<!--{/if}-->&nbsp;
                                <!--{elseif !empty($verify['unverifyicon'])}-->
                                    <!--{if $verify['unverifyicon']}--><img src="$_G['setting']['verify'][$vid]['unverifyicon']"><!--{/if}-->&nbsp;
                                <!--{/if}-->
                            </a>
                        <!--{/if}-->
                    <!--{/loop}-->
                <!--{if !$showverify}-->
                        </span>
                    </li>
                <!--{/if}-->
            <!--{/if}-->

            <!--{if $y}-->
            <li><em>{lang usergroup}</em><span class="text_left" style="color:{$space[group][color]}">{$space[group][grouptitle]}</span></li>
            <!--{/if}-->
            <!--{loop $profiles $value}-->
            <!--{if in_array($value['title'],array($Tlang['9f1a68900c690d4a'],$Tlang['tdddwwa5ssse586a'],$Tlang['tsedsssee588d84f']))||($value['title']==$Tlang['7ebaba342c75778d']&&$value[value]=='-')}-->
            <!--{eval continue;}-->
            <!--{/if}-->
            <li><em>$value[title]</em><span class="text_left">$value[value]</span></li>
            <!--{/loop}-->
            <li class="wqnew_bottom"><em>{lang credits}</em><span class="text_left">$space[credits]</span></li>
            <!--{loop $_G[setting][extcredits] $key $value}-->
            <!--{if $value[title]}-->
            <li class="wqnew_bottom"><em>$value[title]</em><span class="text_left">{$space["extcredits$key"]} $value[unit]</span></li>
            <!--{/if}-->
            <!--{/loop}-->
        </ul>
    </div>
    <!--{if $space['uid'] == $_G['uid']}-->
    <div class="wqseparate"></div>
    <div class="wqpersonal_data">
        <ul>
            <li class="wqnew_bottom"><em>{$Tlang['734e5ea9b979860a']}</em><span class="text_left"><!--{if $space[mobile]}-->$space[mobile]<!--{else}-->{$Tlang['7e20fe5ea598f025']}<!--{/if}--></span></li>
            <li class="wqnew_bottom"><em>{$Tlang['736d269ad670f312']}</em><span class="text_left"><!--{if $space[qq]}-->$space[qq]<!--{else}-->{$Tlang['7e20fe5ea598f025']}<!--{/if}--></span></li>
            <li class="wqnew_bottom"><em>{$Tlang['c7f5bbf620d645ad']}</em><span class="text_left"><!--{if $space[email]}-->$space[email]<!--{else}-->{$Tlang['7e20fe5ea598f025']}<!--{/if}--></span></li>
            <li class="wqnew_bottom">
                <em>{$Tlang['a283d676e4e24860']}</em>
                <span class="text_left">
                    <!--{if $space[resideprovince] || $space[residecity]}-->
                    <!--{eval echo $space['resideprovince'] = $space['resideprovince'] ? $space['resideprovince'] : ""}-->
                    <!--{eval echo $space['residecity'] = $space['residecity'] ? $space['residecity'] : ""}-->
                    <!--{else}-->
                    {$Tlang['7e20fe5ea598f025']}
                    <!--{/if}-->
                </span>
            </li>
        </ul>
    </div>
    <!--{/if}-->
    <div class="wqseparate"></div>
<!--{/if}-->
<div id="uploading_fullscreen" class="ipagen slide-stop" style="display: none;position:absolute;bottom:0px;left:0px;z-index:12;">
    <div class="wq_lump_div">
        <div class="wq_lump_pro">
            <a href="javascript:;" onclick="$('#uploading_fullscreen').hide(); $('html,body').removeClass('wq_ovhidden');" class="wq_return">&#x53D6;&#x6D88;</a>&#x88C1;&#x526A;
            <span class="return_in"><button type="button" id="clipBtn" class="pn pnc">&#x5B8C;&#x6210;</button></span>
        </div>
    </div>
    <div class="pcontent" id="uploading_content">
        <div class="resource_lazy hide"></div>
        <div class="pic_edit">
            <div id="clipArea"></div>
            <div class="qd_bg">
                <button class="operate" id="positive_rotate"><i class="wqiconfont2 wqicon2-xiangyouxuanzhuanline"></i></button>
                <button class="operate" id="inverse_rotate"><i class="wqiconfont2 wqicon2-xiangzuoxuanzhuanline"></i></button>
                <button class="operate" id="reduction"><i class="wqiconfont2 wqicon2-zoomout"></i></button>
                <button class="operate" id="magnification"><i class="wqiconfont2 wqicon2-zoomin"></i></button>
            </div>
            <input type="file" id="file" style="opacity: 0;position: fixed;bottom: -100px" accept="image/*">
        </div>
        <img src="" fileName="" id="hit" style="display:none;">
    </div>
</div>
<div id="edit_profile" class="ipagen" style="position:fixed; display: none;bottom: 0px; left: 0px;"></div>
<script>
    JC.file('thirdparty/hammer.js');
    JC.file('thirdparty/iscroll-zoom.js');
    JC.file('thirdparty/jquery.photoClip.js');
    JC.run();
    var myArray = new Array();
    $('body').on('click', '#wq_login_bind', function () {
        var wq_id = $(this).attr('id');
        if (myArray[wq_id]) {
        popup.open(myArray[wq_id]);
        } else {
            $.post($(this).attr('href'), {inajax: 1}, function(s) {
                var wq = wqXml(s);
                popup.open(wq);
                myArray[wq_id] = wq;
            }, 'html');
        }
    post_submit = false;
    return false;
    });
    <!--{if $space['uid'] == $_G['uid']}-->
    $('#head_image').on('click',function(){
        $('#file').click();
    });
    var photoClip_height = photoClip_width = 150;
    var uploading_url = 'plugin.php?id=wq_app_setting';
    var photoClip = $("#clipArea").photoClip({
        width: photoClip_width,
        height: photoClip_height,
        file: "#file",
        view: "#hit",
        ok: "#clipBtn",
        loadStart: function () {
            $('.lazy_tip span').text('');
        },
        loadComplete: function () {
            $('#uploading_fullscreen').show();
            $('html,body').addClass("wq_ovhidden");
        },
        clipFinish: function (dataURL) {
            saveImageInfo(dataURL);
        }
    });
    function saveImageInfo(img_data) {
        $.post(uploading_url, {mod: 'ajax', ac: 'uploading', image: img_data, formhash: '{FORMHASH}'}, function (data) {
            if (data != '') {
                uploading_return(img_data);
            }
        });
    }
    function uploading_return(img_data) {
        $('.wqsethead').attr('src', img_data);
        $('#uploading_fullscreen').hide();
        $('html,body').removeClass('wq_ovhidden');
    }
    <!--{/if}-->
    $('.wqadmin_eject a').click(function () {
        $('.wqadmin_eject').hide();
    });
</script>
<!--{if !$_GET['mycenter'] == '1'}--><!--{eval $nofooter=1;}--><!--{/if}-->
<!--{template common/footer}-->

<!--{/if}-->