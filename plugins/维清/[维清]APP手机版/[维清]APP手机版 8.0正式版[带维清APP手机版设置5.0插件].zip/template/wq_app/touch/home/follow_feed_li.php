<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['follow_feed_li'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{eval $carray = array();}-->
<!--{eval $beforeuser = 0;}-->
<!--{eval $hiddennum = 0;}-->
<!--{loop $list['feed'] $feed}-->
<!--{eval $author = $list['threads'][$feed['tid']]['author'];$fname = $_G['cache']['forums'][$fid]['name'];}-->

    <!--{eval $return = get_feed_content();}-->
    <!--{eval $return['contenta'] = str_replace('smilieid="','class="wq_smilieimg" smilieid="',$return['contenta']);}-->
    <!--{eval $return['textb'] = str_replace('smilieid="','class="wq_smilieimg" smilieid="',$return['textb']);}-->
    <li id="feed_li_$feed['feedid']" onmouseover="this.className='flw_feed_hover cl'" onmouseout="this.className='cl'" >
    <!--{if !empty($return['thread']) && $return['thread']['displayorder'] >= 0}-->
        <!--{if !$feed['note']}-->
            <div class="wqbroadcast_text" onclick="location.href = 'forum.php?mod=viewthread&tid={$return['thread']['tid']}'">
                    <p>$return['contenta']</p>
                    <!--{if $return['imglist']}-->
                    <div class="list_pane">
                        $return['imglist']
                    </div>
                    <!--{/if}-->
            </div>
            <!--{eval $reply=get_wq_app_forum_post($feed[tid],$feed[feedid]);}-->
            <!--{loop $reply $key $val}-->
                <p class="wqbroadcast_reply"><span class="wqplate_name"><a href="home.php?mod=space&do=profile&uid=$val[authorid]" c="1">$val['author']:</a></span> $val['message']</p>
            <!--{/loop}-->
                <p class="list_info wqm_top5 wqm_bottom10">
            <!--{eval echo date('Y-m-d',$feed['dateline']);}-->
            <!--{if $feed[uid] == $_G[uid] || $_G['adminid'] == 1}-->
                <span class="y wqm_left15"><a href="home.php?mod=spacecp&ac=follow&feedid=$feed[feedid]&op=delete" class="wqblock hot"><i class="wqiconfont2 wqicon2-gbdelete wqapp_f13"></i></a></span>
            <!--{/if}-->
                <span class="y wqm_left15"><a href="forum.php?mod=post&action=reply&fid=$return['thread']['fid']&tid=$return['thread']['tid']&do=broadcast"><i class="wqiconfont2 wqicon2-pinglun2 wqapp_f12"></i></a>$return['thread']['replies']</span>
                <span class="y wqm_left15"><a href="home.php?mod=spacecp&ac=follow&op=relay&feedid=$feed['feedid']&tid=$return['thread']['tid']" class="hot"><i class="wqiconfont2 wqicon2-textfenxiang"></i></a>$return['content']['relay']</span>
            </p>
            <div class="wqseparate"></div>
            <script>
                feed_imgList($("#feed_li_$feed['feedid'] .list_pane .wqimglist"));
            </script>
        <!--{else}-->
            <h3 class="wqbroadcast_reason">$return['text']</h3>
            <div class="wqbroadcast_con">
                <a href="forum.php?mod=viewthread&tid={$return['thread']['tid']}">
                    <!--{eval $num=preg_match('/<img/iUs', $return['content']['content']);}-->
                    <div class="wqfeedlist">$return['imglist']</div>
                    <div class="wqlisthidden2">
                        <h3 class="wqtitle_list">$return['textb']</h3>
                    </div>
                    <p class="list_info"><span class="wqplate_name">#$author#</span>
                        <span class="y wqplate_time">{$Tlang['f5b8c645563c9608']} <!--{eval echo date('Y-m-d',$return['thread']['dateline']);}--></span>
                    </p>
                </a>
            </div>
            <!--{eval $reply=get_wq_app_forum_post($feed[tid],$feed[feedid]);}-->
            <!--{loop $reply $key $val}-->
                <p class="wqbroadcast_reply"><span class="wqplate_name"><a href="home.php?mod=space&do=profile&uid=$val[authorid]" c="1" shref="home.php?mod=space&do=profile&uid=$val[authorid]">$val['author']:</a></span> $val['message']</p>
            <!--{/loop}-->
                <p class="list_info wqm_top5 wqm_bottom10">
                    <!--{eval echo date('Y-m-d',$feed['dateline']);}-->
                    <!--<span class="y" style="width: 30px; text-align: right;"><a href="javascript:;" class="wqblock"><i class="wqiconfont2 wqicon2-gbdelete wqapp_f12"></i></a></span>-->
                    <span class="y wqm_left15"><a href="home.php?mod=spacecp&ac=follow&feedid=$feed[feedid]&op=delete" class="wqblock hot"><i class="wqiconfont2 wqicon2-gbdelete wqapp_f13"></i></a></span>
                    <span class="y wqm_left15"><a href="forum.php?mod=post&action=reply&fid=$return['thread']['fid']&tid=$return['thread']['tid']&do=broadcast"><i class="wqiconfont2 wqicon2-pinglun2 wqapp_f12"></i>$return['thread']['replies']</a></span>
                    <span class="y wqm_left15"><a href="home.php?mod=spacecp&ac=follow&op=relay&feedid=$feed['feedid']&tid=$return['thread']['tid']" class="hot"><i class="wqiconfont2 wqicon2-textfenxiang"></i>$return['content']['relay']</a></span>
                </p>
                <div class="wqseparate"></div>
                <script>
                    feed_img($("#feed_li_$feed['feedid'] .wqfeedlist img"));
                </script>
                </li>
        <!--{/if}-->
    <!--{else}-->
<!--    <div class="pbm c cl" id="original_content_$feed[feedid]" {if isset($carray[$feed['cid']])} style="display: none"{/if}>
        {lang follow_thread_deleted}
    </div>-->
    <!--{/if}-->
<!--{/loop}-->


<!--{/if}-->