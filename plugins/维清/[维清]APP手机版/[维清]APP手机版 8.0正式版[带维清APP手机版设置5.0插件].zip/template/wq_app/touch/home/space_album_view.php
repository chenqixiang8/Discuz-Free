<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['space_album_view'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{template common/header}-->
<div class="wqalbum_seewarp">
    <div class="wqlbum_seewarp_bg"><a href="javascript:;" {if $_G['adminid'] != 1 && $value[uid]!=$_G[uid] && $value[friend]=='4' && $value[password] && empty($_G[cookie][$pwdkey])} onclick="showWindow('list_album_$value[albumid]', this.href, 'get', 0);"{/if}><!--{if $value[pic]}--><!--{if $album[albumid] > 0}--><img src="data/attachment/album/$album[pic]" alt="{lang default_album}" /><!--{else}--><img src="{$value[pic]}" alt="{lang default_album}" /><!--{/if}--><!--{/if}--></a></div>
    <div class="wqlbum_seewarp_bggrey"></div>
    <div class="wqalbum_see_return">
        <a href="javascript:history.go(-1);" class="wqiconfont2 wqicon2-fanhui-copy-copy wqapp_f22 wqreturn" data-href="home.php?mod=space&uid=$space['uid']&do=album&view=me"></a>
        <div class="new_div">
            <a href="javascript:;" class="wqiconfont2 wqicon2-gengduo1 wqapp_f30 wqset new_button"></a>
        </div>
        <div id="wqalbum_js" class="wqadmin_eject new_menu" style="display:none;">
            <span class="wqadmin_eject_arrow wqadmin_position"></span>
            <ul>
                <li><a class="dialog" href="home.php?mod=spacecp&ac=favorite&type=album&id=$album[albumid]&spaceuid=$space[uid]&handlekey=sharealbumhk_{$album[albumid]}"><i class="wqiconfont2 wqicon2-favorite wqapp_f20"></i>{lang favorite}</a></li>
                <li>
        <!--{if $space[self]}-->
            <!--{if $album[albumid] > 0}-->
            <a href="home.php?mod=spacecp&ac=album&op=edit&albumid=$album[albumid]"><i class="wqiconfont2 wqicon2-xindenew85 wqapp_f18"></i>{$Tlang['7db60da508f19f3c']}</a>
            <!--{else}-->
            <a href="home.php?mod=spacecp&ac=album&op=editpic&albumid=0"><i class="wqiconfont2 wqicon2-guanli wqapp_f20"></i>{$Tlang['00b681267dfe520e']}</a>
            <!--{/if}-->
        <!--{/if}-->
                </li>
               <!--{if ($_G[uid] == $album[uid] || checkperm('managealbum')) && $album[albumid] > 0}--> <li><a href="home.php?mod=spacecp&ac=album&op=editpic&albumid=$album[albumid]"><i class="wqiconfont2 wqicon2-guanli wqapp_f20"></i>{$Tlang['1db7a5ee23404fdc']}</a></li> <!--{/if}-->
            </ul>
        </div>
        <div class="new_hide" style="display: none;"></div>
    </div>
    <h3 class="wqalbum_seename wqapp_f22"><a href="javascript:;" class="wqwhite wqellipsis ">$album['albumname']</a></h3>
    <!--{if $album[depict]}-->
    <div class="wqalbum_seedescribe wqellipsis2">$album[depict]</div>
    <!--{/if}-->
</div>
<div class="wqupload_photos">
    <!--{if helper_access::check_module('album') && $space[self] && (($diymode && !$_G[setting][homepagestyle]) || (!$diymode && !$_G[setting][homestyle]))}-->
    <a class="wqupload_photos_btn wqapp_f16" href="home.php?mod=spacecp&ac=upload&albumid=$album['albumid']">{$Tlang['9af5a64c904a836f']}</a>
    <!--{/if}-->
</div>
<div class="wqalbum_list">
    <!--{if $list}-->
        <ul id="wq_slides" class="clearfixed">
            <!--{loop $list $key $value}-->
            <li>
                <a href="javascript:;" data="$key" data-pic="$value[picid]">
                    <!--{if $value[pic]}--><img src="$value[pic]"/><!--{/if}-->
                </a>
                <!--{if $value[status] == 1}--><b class="pending_audit">{lang moderate_need}</b>
                <!--{/if}-->
            </li>
            <!--{/loop}-->
        </ul>
        <!--{if $multi}--><div class="pgs cl mtm">$multi</div><!--{/if}-->
    <!--{else}-->
    <!--{eval include_once template('common/common_module');}-->
        <!--{if !$pricount}-->
            <!--{echo wq_app_no_content('home/template','no_pics');}-->
        <!--{else}-->
            <!--{echo wq_app_no_content($pricount.$Tlang['5298d4f8b1285f4f']);}-->
        <!--{/if}-->
    <!--{/if}-->
</div>

<!--{block listHtml}-->
<!--{loop $list $key $image}-->
<!--{eval
    $url=$_G['setting']['attachurl'].'album/'.$image['filepath'];
    $replynums = wq_app_get_album_pic_replynum_by_albumid($image['albumid']);
}-->
<!--{eval $imglist[$key]=$url;}-->
<li class="postalbum_u" id="u_$key">
    <div class="postalbum_b" >
        <img class="postalbum_i" src='$url' load="0" id="img_$key"  zsrc="$url" orig="$url" noerror="true"/>
    </div>
    <div class="postalbum_f wqalbum_view_info">
        <p class="wqdescribe">
            <!--{if $_G[uid] == $pic[uid] || checkperm('managealbum')}-->
            <a href="home.php?mod=spacecp&ac=album&op=edittitle&albumid=$album[albumid]&picid=$image[picid]&handlekey=edittitlehk_$image['picid']" class="edittitle"><i class="wqiconfont2 wqicon2-bianji wqm_right5"></i> <!--{if $image[title]}-->$image[title]<!--{else}-->{$Tlang['2a7c4f3231b8b5d5']}<!--{/if}--></a>
            <!--{/if}-->
        </p>
        <p>
            <a href="javascript:" class="wqm_right15"><i class="wqiconfont2 wqicon2-groupcopy5 wqapp_f15 wqm_right5"></i>$replynums['picid']</a>
            <span class="y"><a href="home.php?mod=space&uid=$value[uid]&do=$do&picid=$image['picid']"><i class="wqm_right5">$Tlang['c946d075a693e29d']</i><i class="wqiconfont2 wqicon2-jiantou"></i></a></span>
        </p>
    </div>
</li>

<!--{/loop}-->
<!--{/block}-->
<!--{eval $count = count($imglist);}-->
<div class="postalbum" style="display:none;z-index: 100;">
    <div class="wqalbum_view">
        <div class="wqalbum_view_div postalbum_f new_div" style="width:auto;">
            <a href="javascript:$('.postalbum').hide(),wq_is_scroll();" class="wqalbum_view_left"><i class="wqiconfont2 wqicon2-fanhui-copy-copy wqapp_f22 wqreturn"></i></a>
            <span id="curpic"></span>/$count
            <!--{if helper_access::check_module('album') && $space[self]}--><a href="javascript:" class="wqalbum_view_right new_button"><i class="wqiconfont2 wqicon2-gengduo1 wqapp_f30 wqset"></i></a><!--{/if}-->
        </div>
        <div class="new_hide" style="display: none;"></div>
        <div class="wqadmin_eject new_menu" style=" display: none;">
            <span class="wqadmin_eject_arrow wqadmin_position"></span>
            <ul class="wqadmin_eject_ul">
                <li><a href="home.php?mod=spacecp&ac=album&op=editpic&albumid=$value[albumid]&picid=$value['picid']"><i class="wqiconfont2 wqicon2-guanli wqapp_f20"></i>{$Tlang['1db7a5ee23404fdc']}</a></li>
            </ul>
        </div>

    </div>
    <ul class="postalbum_c">
        <!--        $listHtml-->
        <!--{loop $list $key $value}-->
        <!--{eval
            $url=$_G['setting']['attachurl'].'album/'.$value['filepath'];
            $replynum = C::t('home_comment')->count_by_id_idtype($value['picid'], 'picid');
        }-->
        <li class="postalbum_u" id="u_{$key}">
            <div class="postalbum_b">
                <img class="postalbum_i" data-pic="$value['picid']" data-album="$value[albumid]" load="0" id="img_{$key}" zsrc="$url" orig="$url" noerror="true" style="max-height: 100%; visibility: visible;">
            </div>
            <div class="postalbum_f wqalbum_view_info" style="display: block;">
                <p class="wqdescribe">
                    <a href="home.php?mod=spacecp&ac=album&op=edittitle&albumid=$value[albumid]&picid=$value['picid']&handlekey=edittitlehk_$value['picid']" class="edittitle"><i class="wqiconfont2 wqicon2-bianji wqm_right5"></i>$value['title']</a>
                </p>
                <p>
                    <a href="javascript:" class="wqm_right15"><i class="wqiconfont2 wqicon2-groupcopy5 wqapp_f15 wqm_right5"></i>$replynum</a>
                    <span class="y"><a href="home.php?mod=space&uid=$value[uid]&do=album&picid=$value['picid']"><i class="wqm_right5">{$Tlang['c946d075a693e29d']}</i><i class="wqiconfont2 wqicon2-jiantou"></i></a></span>
                </p>
            </div>
        </li>
        <!--{/loop}-->
    </ul>
</div>
<!--{eval $imglist = dimplode($imglist)}-->
<script src="{$_G['style'][styleimgdir]}js/public/previewimage.js?{VERHASH}" charset="gbk"></script>
<script>
    $(function () {
        var counts = $count, imglists=[$imglist];
        var model = {
            bindEvent:function(){
                model.album_detail();
            },

            album_detail: function(){
                $('#wq_slides a').preview();

                $('.hot').click(function(e){
                    $('.wqadmin_eject').hide();
                    var obj = $(this);
                    popup.open(toast);
                    $.ajax({
                        type: 'GET',
                        url: obj.attr('href') + '&inajax=1',
                        dataType: 'html'
                    }).success(function (s) {
                        var wq = s;
                        popup.open(wq);
                    }).error(function () {
                        window.location.href = obj.attr('href');
                        popup.close();
                    });
                    e.preventDefault();
                });

                $('.edittitle').click(function(){
                    $('.wqadmin_eject').hide();
                    var obj = $(this);
                    popup.open(toast);
                    $.ajax({
                        type: 'GET',
                        url: obj.attr('href') + '&inajax=1',
                        dataType: 'html'
                    }).success(function (s) {
                        var wq = s;
                        popup.open(wq);
                    }).error(function () {
                        window.location.href = obj.attr('href');
                        popup.close();
                    });
                    return false;
                });
                $('body').on('input', '#edittitle', function () {
                    if ($(this).val().length > 79) {
                        $(this).val($(this).val().slice(0, 76) + '...');
                    }
                });
                $('.postalbum').on('touchmove', function (e) {
                    e.stopPropagation();
                });
            }
        };
        model.bindEvent();
    });


    function succeedhandle_titleform() {
        clearTimeout(setTimeout_location);
        setTimeout_location = setTimeout(function() {
            history.go(0);
        }, 1000);
    }
</script>
 <!--{eval $nofooter=1;}-->
<!--{template common/footer}-->

<!--{/if}-->