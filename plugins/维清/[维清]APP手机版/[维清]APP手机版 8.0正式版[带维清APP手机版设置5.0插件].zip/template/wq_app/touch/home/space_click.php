<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['space_click'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<table cellpadding="0" cellspacing="0" class="atd">
    <tr>
        <!--{eval $clicknum = 0;}-->
        <!--{loop $clicks $key $value}-->
        <!--{eval $clicknum = $clicknum + $value['clicknum'];}-->
        <!--{eval $value['height'] = $maxclicknum?intval($value['clicknum']*50/$maxclicknum):0;}-->
        <td>
            <a href="home.php?mod=spacecp&ac=click&op=add&clickid=$key&idtype=$idtype&id=$id&hash=$hash&handlekey=clickhandle" class="dialog notlogged">
                <img src="{STATICURL}image/click/$value[icon]"/><br/>$value[name]<!--{if $value[clicknum]}-->{$value[clicknum]}<!--{/if}-->
            </a>
        </td>
        <!--{/loop}-->
    </tr>
</table>
<script>
    function errorhandle_clickhandle() {
        var str = '{$Tlang['08515bfeb0d8596f']}';
        if ($.trim(arguments[0]) == str) {
            clearTimeout(setTimeout_location);
            setTimeout(function () {
                location.reload();
            }, 1000);
        }
    }
</script>
<!--{if $clickuserlist}-->
<div class="wqseparate2"></div>
<div class="wqscore_num">
<div class="wqscore_num_specific">
    {lang position_friend}<span class="wq_grey y">{$clicknum}{lang person}</span>
    <!--{if $_G[magic][anonymous]}-->
    <img src="{STATICURL}image/magic/anonymous.small.gif" alt="anonymous" class="vm" />
    <a id="a_magic_anonymous" href="home.php?mod=magic&mid=anonymous&idtype=$idtype&id=$id" onclick="ajaxmenu(event, this.id, 1)" class="xg1">{$_G[magic][anonymous]}</a>
    <!--{/if}-->
</div>

<div class="wqscore_num_head" id="my_portal_roll">
    <div class="tag_list">

        <ul>
            <!--{loop $clickuserlist $value}-->
            <!--{if $value[username]}-->
            <li>
              <a href="home.php?mod=space&do=profile&uid=$value[uid]" title="$value[clickname]"><!--{avatar($value[uid], 'small')}--></a></li>
            <!--{else}-->
            <li><img src="{STATICURL}image/magic/hidden.gif" alt="$value[clickname]" /></li>
            <!--{/if}-->
             <!--{/loop}-->
        </ul>

    </div>
</div>
</div>
<!--<div class="wqseparate2"></div>-->
    <!--{eval $my_roll_tag='my_portal_roll';}-->
	<!--{template common/slide}-->
	<div class="wqpost_list">
</div>
<!--{/if}-->

<!--{if $click_multi}--><div class="pgs cl mtm">$click_multi</div><!--{/if}-->

<!--{/if}-->