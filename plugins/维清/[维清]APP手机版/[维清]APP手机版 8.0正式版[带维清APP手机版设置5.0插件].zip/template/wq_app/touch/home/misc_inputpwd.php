<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['misc_inputpwd'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{template common/header}-->
<!--{if !$_G[inajax]}-->

<!--{eval
    $headparams['wtype'] = '1';
    $headparams['lurl'] = $backurl;
    $headparams['ltype'] = 'a';
    $headparams['cname'] = $Tlang['5da57ebee24c9ebb'];
    echo wq_app_get_header($headparams);
}-->
<div id="ct" class="ct2_a wp cl form_passwd">
    <div class="mn">
        <div class="bw0">
            <!--{else}-->
            <h3 class="flb">
                <em id="return_$_GET[handlekey]">{lang password_authentication}</em>
                <span><a href="javascript:;" onclick="hideWindow('$_GET[handlekey]');" class="flbc" title="{lang close}">{lang close}</a></span>
            </h3>
            <!--{/if}-->
            <form method="post" autocomplete="off"  id="invalueform" name="invalueform" action="home.php?mod=misc&ac=inputpwd" {if $_G[inajax]}onsubmit="ajaxpost(this.id, 'return_$_GET[handlekey]');"{/if}>
                  <!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
                <input type="hidden" name="refer" value="$_SERVER[REQUEST_URI]" />
                <input type="hidden" name="blogid" value="$invalue[blogid]" />
                <input type="hidden" name="albumid" value="$invalue[albumid]" />
                <input type="hidden" name="pwdsubmit" value="true" />
                <input type="hidden" name="formhash" value="{FORMHASH}" />
                <div class="wqmima_icon"><i class="wqiconfont2 wqicon2-mimas"></i></div>
                <div class="c mbn">
                    <h3>{lang enter_password}</h3>
                    <p class="wqpasswd_input wqnew_all">
                     <input id="verify_password" type="password" name="viewpwd" value="" class="px mtn" />
                    </p>
                </div>
                <p class="o pns button_passwd m_t10">
                    <button id="postsubmit" type="submit" name="submit" value="true" disabled='disabled' class="pn pnc formdialog wq_disabled wqbg_color wqborder">{lang submit}</button>
                </p>
            </form>
            <script type="text/javascript">
                $('#verify_password').on('keyup input', function () {
                    $('#postsubmit').attr('disabled', ($.trim($('#verify_password').val()) ? null : 'disabled'));
                });
            </script>
            <!--{if !$_G[inajax]}-->
        </div>
    </div>
</div>
<!--{/if}-->

<!--{template common/footer}-->
<!--{/if}-->