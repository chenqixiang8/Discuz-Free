<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['spacecp_promotion'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{template common/header}-->
<!--{eval $headright=false;}-->
    <!--{if helper_access::check_module('collection')}-->
        <!--{eval $headright=true;}-->
    <!--{/if}-->

    <!--{eval
        $headparams['wtype'] = '1';
        $headparams['ltype'] = 'a';
        $headparams['lurl'] = $backurl;
        $headparams['cname'] = $Tlang['60011bcee34ebbde'];
        $headparams['rtype'] = 'a';
        $headparams['rclass'] = 'wqapp_f16';

        $headparams['rtype'] = 'a';
        $headparams['rclass'] = '';

        echo wq_app_get_header($headparams,true,$headright);
    }-->

    <!--{hook/spacecp_promotion_top}-->
    <!--{if $_G['setting']['creditspolicy']['promotion_visit'] || $_G['setting']['creditspolicy']['promotion_register']}-->
            <div class="wq_promotion_warp">
                    <!--{if $_G['setting']['creditspolicy']['promotion_visit']}--><p>
                        {$Tlang['b9caa66c44a3aac7']}<span class="xi1">$visitstr</span>
                    </p><!--{/if}-->

                    <!--{if $_G['setting']['creditspolicy']['promotion_register']}-->
                    <p>
                    <!--{if $_G['setting']['creditspolicy']['promotion_visit']}-->
                            {$Tlang['5a16824dd3f6b506']}<span class="xi1">$regstr</span>
                    <!--{/if}-->
                    </p>
                    <!--{/if}-->
            </div>
            <div class="qz_bg">
                <div class="qrcode_wrap width_max100">
                    <div class="qrcode_container">
                        <!--{eval $qrcode_url = wq_app_qrcode_generate($_G[siteurl].'?fromuid='.$_G[uid], 'promotionqrcode', $_G['uid']);}-->
                        <img class="qrcode_img" src="{$qrcode_url}">
                        <span>
                            <img src="<!--{eval echo avatar($_G['uid'], middle, true);}-->" />
                        </span>
                    </div>
                    <div class="qrcode_code">
                        <span><img src="<!--{eval echo avatar($_G['uid'], middle, true);}-->"></span>
                        <div class="qrcode_head">
                            <h3>{$_G['username']}</h3>
                            <p>{$Tlang['9b47950a06398de6']}</p>
                        </div>
                    </div>
                </div>
            </div>
    <div class="wqseparate"></div>
    <div class="wq_promotion_mode">{$Tlang['47f12378800cd4d4']}</div>
    <!--{/if}-->
    <!--{hook/spacecp_promotion_bottom}-->
    <!--{eval $nofooter=true;}-->
<!--{template common/footer}-->
<!--{/if}-->