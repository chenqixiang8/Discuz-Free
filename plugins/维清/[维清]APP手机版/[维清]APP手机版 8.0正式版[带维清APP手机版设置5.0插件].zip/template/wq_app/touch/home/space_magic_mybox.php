<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['space_magic_mybox'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{if $_G['group']['magicsdiscount'] || $_G['group']['maxmagicsweight']}-->
	<!--{if $_G['group']['maxmagicsweight']}-->
		<p class="tbmu wqmagic_tbmu wqnew_bottom">{lang magics_capacity}: <span class="xi1">$totalweight</span>/{$_G['group']['maxmagicsweight']}</p>
	<!--{/if}-->
<!--{/if}-->
<!--{if $mymagiclist}-->
	<ul class="mgcl wq_magiv_list">
	<!--{loop $mymagiclist $key $mymagic}-->
		<li class="wqnew_bottom">

			<div id="magic_$mymagic[identifier]" class="mg_img wq_img" onmouseover="showMenu({'ctrlid':this.id, 'menuid':'magic_$mymagic[identifier]_menu', 'pos':'12!'});">

				<img src="$mymagic[pic]" alt="$mymagic[name]" />

			</div>
			<h3><strong>$mymagic[name]</strong></h3>
                        <div id="magic_$mymagic[identifier]_menu" class="wqmagic_effect">
				<div class="tip_horn"></div>
				<div class="tip_c" style="text-align:left">$mymagic[description]</div>
			</div>
			<p>{lang magics_num}: <font class="wq_orange">$mymagic[num]</font>, {lang magics_user_totalnum}: <font class="wq_orange">$mymagic[weight]</font>
                         <span class="y wqmagic_operate">
				<!--{if $mymagic['useevent']}-->
                                <a href="home.php?mod=magic&action=mybox&operation=use&magicid=$mymagic[magicid]"><strong>{lang magics_operation_use}</strong></a>&nbsp;<em class="pipe">|</em>
				<!--{/if}-->
				<!--{if $_G['group']['allowmagics'] > 1}-->
					<a href="home.php?mod=magic&action=mybox&operation=give&magicid=$mymagic[magicid]">{lang magics_operation_present}</a>&nbsp;<em class="pipe">|</em>
				<!--{/if}-->
				<!--{if $_G['setting']['magicdiscount']}-->
					<a href="home.php?mod=magic&action=mybox&operation=sell&magicid=$mymagic[magicid]">{lang magics_operation_sell}</a>
				<!--{else}-->
					<a href="home.php?mod=magic&action=mybox&operation=drop&magicid=$mymagic[magicid]">{lang magics_operation_drop}</a>
				<!--{/if}-->
                                 </span>
                        </p>

		</li>
	<!--{/loop}-->
	</ul>
	<!--{if $multipage}--><div class="pgs cl mtm page">$multipage</div><!--{/if}-->
<!--{else}-->
        <p class="wqemp"><span class="wqno_con"><img src="{$_G['style'][styleimgdir]}images/wqno_con.png"></span>{lang data_nonexistence}</p>
<!--{/if}-->

<!--{/if}-->