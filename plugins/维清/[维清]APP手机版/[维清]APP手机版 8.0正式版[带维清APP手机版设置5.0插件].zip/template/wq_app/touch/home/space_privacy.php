<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['space_privacy'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{eval $_G['home_tpl_titles'] = array('{lang remind}');}-->
<!--{template common/header}-->
<!--{eval
	$space['isfriend'] = $space['self'];
	if(in_array($_G['uid'], (array)$space['friends'])) $space['isfriend'] = 1;
	space_merge($space, 'count');
	space_merge($space, 'field_home');
}-->

<!--{eval
    $headparams['wtype'] = '1';
    $headparams['lurl'] = $backurl;
    $headparams['ltype'] = 'a';
    $headparams['cname'] = $Tlang['5f49cyinsidfsdfa'];
    echo wq_app_get_header($headparams);
}-->
<div id="ct" class="wp cl">
	<div class="nfl">
		<div class="f_c mbw form_passwd">
			<div class="wqyinsi_icon"><i class="wqiconfont2 wqicon2-quanxian"></i></div>
						<h3 class="xs2">
							{lang set_privacy}
						</h3>

						<!--{if $space['medals']}-->
							<div class="pbm mbm bbda cl">
								<h2 class="mbn">{lang medals}</h2>
								<!--{loop $space['medals'] $medal}-->
								<img src="{STATICURL}/image/common/$medal[image]" border="0" alt="$medal[name]" title="$medal[name]" /> &nbsp;
								<!--{/loop}-->
							</div>
						<!--{/if}-->
						<!--{if $_G['setting']['verify']['enabled']}-->
							<!--{eval $showverify = true;}-->
							<!--{loop $_G['setting']['verify'] $vid $verify}-->
								<!--{if $verify['available'] && $space['verify'.$vid] == 1}-->
									<!--{if $showverify}-->
									<div class="pbm mbm bbda cl">
										<h2 class="mbn">{lang profile_verify}</h2>
										<!--{eval $showverify = false;}-->
									<!--{/if}-->
									<a href="home.php?mod=spacecp&ac=profile&op=verify&vid=$vid"><!--{if $verify[icon]}--><img src="$verify[icon]" class="vm" alt="$verify[title]" title="$verify[title]" /><!--{else}-->$verify[title]<!--{/if}--></a>&nbsp;
								<!--{/if}-->
							<!--{/loop}-->
							<!--{if !$showverify}--></div><!--{/if}-->
						<!--{/if}-->
						<!--{if $manage_forum}-->
							<div class="pbm mbm bbda cl">
								<h2 class="mbn">{lang manage_forums}</h2>
								<!--{loop $manage_forum $key $value}-->
								<a href="forum.php?mod=forumdisplay&fid=$key">$value</a> &nbsp;
								<!--{/loop}-->
							</div>
						<!--{/if}-->

						<!--{if !$isfriend}-->
						<p class="mtm cl button_passwd privacy_a"><a href="home.php?mod=spacecp&ac=friend&op=add&uid=$space[uid]" id="add_friend" onclick="showWindow(this.id, this.href, 'get', 0);" class="pn pnc dialog wqbg_color" style="text-decoration: none;">{lang add_friend}</a></p>
						<!--{/if}-->
		</div>
	</div>
</div>

<!--{template common/footer}-->

<!--{/if}-->