<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['spacecp_blog'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{eval $header_nav='null';}-->
<!--{template common/header}-->
<!--{if $_GET[op] == 'delete'}-->
<div class="wqshield_notice">
    <form method="post" autocomplete="off" action="home.php?mod=spacecp&ac=blog&op=delete&blogid=$blogid">
        <input type="hidden" name="referer" value="{echo dreferer()}" />
        <input type="hidden" name="deletesubmit" value="true" />
        <input type="hidden" name="formhash" value="{FORMHASH}" />
        <div class="wqshield_con"><p>{lang sure_delete_blog}</p></div>
        <p class="wqbtn_can wqnew_top">
             <a href="javascript:;" onclick="popup.close();" class="wqeject_cancel wqnew_right">{lang cancel}</a>
            <button type="submit" name="btnsubmit" value="true" class="wqdetermine">{lang determine}</button>
        </p>
    </form>
</div>
<!--{elseif $_GET[op] == 'stick'}-->
<div class="wqshield_notice">
<form method="post" autocomplete="off" action="home.php?mod=spacecp&ac=blog&op=stick&blogid=$blogid">
    <input type="hidden" name="referer" value="{echo dreferer()}" />
    <input type="hidden" name="sticksubmit" value="true" />
    <input type="hidden" name="stickflag" value="$stickflag" />
    <input type="hidden" name="formhash" value="{FORMHASH}" />
    <div class="wqshield_con"> <p><!--{if $stickflag}-->{lang sure_stick_blog}<!--{else}-->{lang sure_cancel_stick_blog}<!--{/if}-->?</p></div>
    <p class="wqbtn_can wqnew_top">
          <!--{if $_G[inajax]}--><a href="javascript:;" title="{lang close}" onclick="popup.close();" class="wqeject_cancel wqnew_right">{lang cancel}</a><!--{/if}-->
        <button type="submit" name="btnsubmit" value="true" class="wqdetermine">{lang determine}</button>
    </p>
</form>
    </div>
<!--{elseif $_GET[op] == 'addoption'}-->
<div class="wqshield_notice">
<div class="wqshield_con">
    <p><label for="newsort">{lang name}: <input type="text" name="newsort" id="newsort" class="px" size="30" /></label></p>
</div>
<p class="wqbtn_can wqnew_top">
    <button type="button" name="btnsubmit" value="true" class="wqdetermine" onclick="if (blogAddOption('newsort', '$_GET[oid]'))hideWindow('$_GET[handlekey]');">{lang create}</button>
</p>
<script type="text/javascript">
    $('newsort').focus();
</script>
</div>
<!--{elseif $_GET[op] == 'edithot'}-->
<div class="wqshield_notice">
    <form method="post" autocomplete="off" action="home.php?mod=spacecp&ac=blog&op=edithot&blogid=$blogid">
        <input type="hidden" name="referer" value="{echo dreferer()}" />
        <input type="hidden" name="hotsubmit" value="true" />
        <input type="hidden" name="formhash" value="{FORMHASH}" />
        <div class="wqshield_con">{lang new_hot}</div>
        <div class="c m_t5 wqshield_con"><span class="wqinput"><input type="text" name="hot" value="$blog[hot]" size="10" /></span></div>
        <p class="wqbtn_can wqnew_top">
            <a href="javascript:;" onclick="popup.close();" class="wqeject_cancel wqnew_right">{lang cancel}</a>
            <button type="submit" name="btnsubmit" value="true" class="wqdetermine">{lang determine}</button>
        </p>
    </form>
</div>
<!--{else}-->
<form id="ttHtmlEditor" method="post" autocomplete="off" action="home.php?mod=spacecp&ac=blog&blogid=$blog[blogid]{if $_GET[modblogkey]}&modblogkey=$_GET[modblogkey]{/if}" onsubmit="validate(this);" enctype="multipart/form-data">

    <!--{eval
        $headparams['wtype'] = '2';

        $headparams['ltype'] = 'cancel';
        $headparams['lname'] = '<i class="wqiconfont2 wqicon2-fanhui-copy-copy wqapp_f22"></i>';
        $headparams['lurl'] = 'javascript:void(0);';

	$headparams['ctype'] = 'span';
        $headparams['cname'] =$Tlang['f02293b738fd9f49'];

        echo wq_app_get_header($headparams, false) ;
    }-->

    <div class="wqpost_list">
        <ul class="wqpost_list_ul">
            <li class="wqnew_bottom">
                <input type="text" name="subject" class="wqpost_input" size="60" id="subject" autocomplete="off" value="$blog[subject]" placeholder="{$Tlang['0b3d6ba0ad26e11e']}">
            </li>
              <li class="wqnew_bottom">
                <select name="classid" id="classid" class="wqpost_select">
                    <option >{$Tlang[2a0d5b20d77f255e]}</option>
                    <option value="0">------</option>
                    <!--{loop $classarr $value}-->
                    <!--{if $value['classid'] == $blog['classid']}-->
                    <option value="$value[classid]" selected>$value[classname]</option>
                    <!--{else}-->
                    <option value="$value[classid]">$value[classname]</option>
                    <!--{/if}-->
                    <!--{/loop}-->
                    <!--{if !$blog['uid'] || $blog['uid']==$_G['uid']}-->
                    <option value="addoption" class="dialog" style="color:red;">+{lang create_new_categories}</option>
                    <!--{/if}-->
                </select>
            </li>
            <li class="wqnew_bottom" style="display: none;"><input type="text" name="" class="wqpost_input" placeholder="{$Tlang['32d53a1effca5f9f']}"></li>
             <li class="wqnew_bottom">
                <select name="friend" onchange="passwordShow(this.value);" class="wqpost_select">
                    <option value="0"$friendarr[0]>{lang friendname_0}</option>
                    <option value="1"$friendarr[1]>{lang friendname_1}</option>
                    <option value="2"$friendarr[2]>{lang friendname_2}</option>
                    <option value="3"$friendarr[3]>{lang friendname_3}</option>
                    <option value="4"$friendarr[4]>{lang friendname_4}</option>
                </select>
            </li>
            <li id="span_password" style="$passwordstyle"><input type="text" class="wqpost_input" name="password" value="$blog[password]" size="5" placeholder="{lang password}" onkeyup="value = value.replace(/[^\w\.\/]/ig, '')"/></li>
            <div id="tb_selectgroup" style="$selectgroupstyle">
                <li>
                    <select name="selectgroup" onchange="getgroup(this.value);" class="wqpost_select">
                        <option value="">{lang from_friends_group}</option>
                        <!--{loop $groups $key $value}-->
                        <option value="$key">$value</option>
                        <!--{/loop}-->
                    </select>
                </li>
                <li>
                    <textarea name="target_names" id="target_names" placeholder="{lang friend_name_space}"  rows="3" class="wqpost_textarea">$album[target_names]</textarea>
                    <p id="names_hidden" style="display: none"></p>
                </li>
            </div>
            <li class="wqpost_see wqnew_bottom">
                <input type="checkbox"name="noreply"id="noreply" value="1" class="weui_check" {if $blog[noreply]} checked="checked"{/if}/>
                <label class="weui_check_label wqblock" for="noreply"><i class="weui_icon_checked"></i>{lang comments_not_allowed}</label>
            </li>
            <li class="wqpost_see wqnew_bottom">
                <input  id="makefeed"  type="checkbox" class="weui_check"  value="1"  placeholder="{lang feed_option}" />
                <label class="weui_check_label wqblock" for="makefeed"><i class="weui_icon_checked"></i>{$Tlang['e1159fd9925dd469']}</label>
            </li>
            <li class="post_con wqnew_bottom">
                <textarea class="wqpost_textarea" name="message" id="needmessage"  autocomplete="off" cols="80" rows="2" placeholder="{$Tlang[70ad0bcbf2229f1d]}" fwin="reply"><!--{if $_GET[op]=='edit'}-->$blog[message]<!--{/if}--></textarea>
                <div class="wqpost_upload"><span class="wqiconfont2 wqicon2-biaoqing wqapp_f26 wqbiaoqing"></span>
                    <a href="javascript:;" class="wqiconfont2 wqicon2-tupian3 wqapp_f26">
                        <input type="button" id="file_button"  class="wqfiledata">
                        <input type="file" name="Filedata"  multiple="multiple" accept="image/*" id="filedata" style="display: none;">
                        <i class="wqtoday" style="display: none">0</i>
                    </a>
                </div>
            </li>
        </ul>
        <!--{template common/upload_image}-->
        <!--{if $_GET[action] != 'edit' && ($secqaacheck || $seccodecheck)}-->
        <!--{subtemplate common/seccheck}-->
        <!--{/if}-->
        <!--{template common/smilies}-->
        <!--{hook/post_bottom_mobile}-->
        <input type="hidden" name="blogsubmit" value="true">
        <input type="hidden" name="formhash" value="{FORMHASH}">
    </div>
     <div class="wqpost_publish"><button id="postsubmit"class="wqpublish wqbg_color formdialog"disable="true">{$Tlang['c0e5b55d87a9643f']}</button></div>
</form>
<div class="dialogbox class-create" style="width: 280px;display: block;position: fixed;left: 47.5px;top: 270px;z-index: 120;opacity: 1;display:none;">
    <div class="wqshield_notice" style="padding-top:10px">
    <form id="moderateform" method="post" autocomplete="off" action="forum.php?mod=topicadmin&amp;action=moderate&amp;optgroup=3&amp;modsubmit=yes&amp;mobile=2">
        <div class="wqshield_con">
            <p class="wqinput">
                <input type="text" class="new_className" placeholder="{$Tlang['32d53a1effca5f9f']}" style="height:35px;">
            </p>
        </div>
        <p class="wqbtn_can wqnew_top">
            <a href="javascript:;" onclick="popup.close();" class="wqeject_cancel wqnew_right">{lang cancel}</a>
            <input type="button" class="wqdetermine" value="{$Tlang['984c5e7090423fd1']}">
        </p>
    </form>
    </div>
</div>
<script>
    function succeedhandle_ttHtmlEditor(url) {
        clearTimeout(setTimeout_location);
        setTimeout(function () {
            location.replace(url);
        }, 1000);
    }
    function passwordShow(value) {
        var span_password, tb_selectgroup;
        switch (value){
        case '4':
            span_password = 'show';
            tb_selectgroup = 'hide';
            break;
        case '2':
            span_password = 'hide';
            tb_selectgroup = 'show';
            break;
        default:
            span_password = 'hide';
            tb_selectgroup = 'hide';
    }
    $('#span_password')[span_password]();
        $('#tb_selectgroup')[tb_selectgroup]();
    }
    function getgroup(gid) {
        if (gid) {
            $.get('home.php?mod=spacecp&ac=privacy&inajax=1&op=getgroup&gid=' + gid, {},
                function(s) {
                    s = wqXml(s);
                    var s = wq_replace_js(s);
                    s = $.trim($('#names_hidden').html(s).text());
                    s = s + ' ';
                    document.getElementById('target_names').innerHTML += s;
                }, 'html');
        }
    }
    var newVal = $("#classid").val();
    var isSelected = '0';
    $("#classid").on("change",function(){
        if($(this).val() == "addoption"){
            $(".class-create").show();
            $("#mask").show().css('z-index', '13');
        } else {
            isSelected = $(this).val();
        }
    });
    $(".wqdetermine").on("click",function(){
        var newClass = $(".new_className").val();
        if(newClass){
            $("#classid").prepend('<option selected="selected" value="new:' + newClass + '">' + newClass + '</option>');
            $(".class-create").hide();
            $("#mask").hide();
            isSelected = $('#classid option').eq(0).val();
        }
    });
    var width = ($(document).width() - $(".class-create").width()) / 2;
    var height = ($(window).height() - $(".class-create").height()) / 2;
    $(".class-create").css({"left": width,"top": height * 5 / 9});
    $(".wqeject_cancel").on("click", function(){
        $(".class-create, #mask").hide();
        $('#classid option[value="' + isSelected + '"]').prop('selected', 'selected');
    });
    function upload_image(data) {
        if(data == '') {
            popup.open('{lang uploadpicfailed}', 'alert');
        }
        var dataarr = data.split('|');
        if(dataarr[0] == 'DISCUZUPLOAD' && dataarr[2] == 0) {
            popup.close();
            if ($('#imglist').is(':hidden')) {
                $('.cellphone_expression').hide();
                $('.wqbiaoqing').removeClass('wqicon2-jianpan').addClass('wqicon2-biaoqing');
                $('#imglist').show();
            }
            $('#imglist').prepend('<li><span aid="'+dataarr[3]+'" class="del wqdelete"><a href="javascript:;"> <i class="wqiconfont2 wqicon2-jianhao f22"></i></a></span><span class="wqimg"><a href="javascript:;"><img id="aimg_'+dataarr[3]+'" title="'+dataarr[6]+'" src="{$_G[setting][attachurl]}forum/'+dataarr[5]+'" /></a></span><input type="hidden" name="attachnew['+dataarr[3]+'][description]" /></li>');
            $('.wqtoday').show().text($('#imglist li').length-1);
            $('#filedata').val('');
            } else {
                var sizelimit = '';
                if(dataarr[7] == 'ban') {
                    sizelimit = '{lang uploadpicatttypeban}';
                } else if(dataarr[7] == 'perday') {
                    sizelimit = '{lang donotcross}'+Math.ceil(dataarr[8]/1024)+'K)';
                } else if(dataarr[7] > 0) {
                    sizelimit = '{lang donotcross}'+Math.ceil(dataarr[7]/1024)+'K)';
                }
                popup.open(STATUSMSG[dataarr[2]] + sizelimit, 'alert');
            }
        };

	<!--{if 0 && $_G['setting']['mobile']['geoposition']}-->
	geo.getcurrentposition();
	<!--{/if}-->
    $('#postsubmit').on('click', function() {
        var obj = $(this);
        var form = $('#ttHtmlEditor');
        popup.open(toast);
        var postlocation = '';
        if(geo.errmsg === '' && geo.loc) {
            postlocation = geo.longitude + '|' + geo.latitude + '|' + geo.loc;
        }
        $.ajax({
            type:'POST',
            url:form.attr('action') + '&geoloc=' + postlocation + '&handlekey='+form.attr('id')+'&inajax=1',
            data:form.serialize(),
            dataType: 'html'
        })
        .success(function(s) {
            $('.wqadmin_eject').hide();
            $('.wqindex_list.wqmessage').show();
            popup.open(wqXml(s));
        })
        .error(function() {
            popup.open('{lang networkerror}', 'alert');
        });
        return false;
    });
    function expression_insertunit(obj) {
        var id_val = $('#needmessage').val();
        $('#needmessage').val(id_val + obj.attr('code'));
    }
    deleteSmilies('{:', ':}');
    $('.wqbiaoqing').on('click', function () {
        if ($(this).is('.c_jianpan')) {
            $('#needmessage').focus();
        }
        $(this).toggleClass('wqicon2-jianpan');
        if ($('.cellphone_expression').is(':hidden')) {
            $('#imglist').hide();
            $('.cellphone_expression').show();
            $('#upload_icon').removeClass('blue');
            $('.wqbiaoqing').removeClass('wqicon2-biaoqing');
            expression_viwepager();
        } else {
            $('.cellphone_expression').hide();
            $('.wqbiaoqing').addClass('wqicon2-biaoqing');
        }
    });
</script>
<!--{eval $nofooter=1;}-->
<!--{/if}-->
<!--{template common/footer}-->
<!--{/if}-->