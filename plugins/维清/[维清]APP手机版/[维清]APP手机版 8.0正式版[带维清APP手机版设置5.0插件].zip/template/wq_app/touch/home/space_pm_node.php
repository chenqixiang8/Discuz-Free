<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['space_pm_node'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{if $value[msgfromid] != $_G['uid']}-->
<div class="wqnews_details">
    <div class="avat z avatar_news">
        <a href="home.php?mod=space&uid=$value[msgfromid]&do=profile">
          <img style="height:32px;width:32px;" src="<!--{avatar($value[msgfromid], small, true)}-->" />
        </a>
    </div>
    <div class="wqnews_green z">
        <div class="dialog_c">
            <div class="dialog_t">$value[message]</div>
        </div>
        <div class="dialog_b"></div>
        <div class="date wqapp_f14" data-time="{$value[dateline]}"><!--{eval echo date("Y-m-d",$value[dateline]);}--></div>
    </div>
</div>
<!--{else}-->
<div class="wqmynews_remind cl">
    <div class="avat y avatar_news"><a href="home.php?mod=space&uid=$value[msgfromid]&do=profile&mycenter=1"><img style="height:32px;width:32px;" src="<!--{avatar($value[msgfromid], small, true)}-->" /></a></div>
    <div class="wqnews_white y">
        <div class="dialog_c">
            <div class="dialog_t">$value[message]</div>
        </div>
        <div class="dialog_b"></div>
        <div class="date wqapp_f14" data-time="{$value[dateline]}"><!--{eval echo date("Y-m-d",$value[dateline]);}--></div>
    </div>
</div>
<!--{/if}-->


<!--{/if}-->