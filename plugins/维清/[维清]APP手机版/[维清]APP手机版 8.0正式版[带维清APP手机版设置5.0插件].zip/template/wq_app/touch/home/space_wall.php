<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['space_wall'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->

<!--{template common/header}-->
    <!--{eval
        $headparams['wtype'] = '3';
        $headparams['ltype'] = 'a';
        $headparams['lurl'] = $backurl;
        $headparams['cname'] = $Tlang['4cc652d2a2685c2d'];
        $headparams['rtype'] = 'a';
        $headparams['rname'] = $Tlang['8442ceb58921a995'];
        $headparams['rid'] = 'wq_reply_click';
        $headparams['rclass'] = 'wqapp_f16';

        echo wq_app_get_header($headparams, true, true) ;
    }-->

<!--{if $list}-->
<div class="wqmessage">
    <ul>
        <!--{loop $list $k $value}-->
        <li id="comment_{$value[cid]}_li">
            <div class="wqmessage_info_div wqblock">
                <a href="home.php?mod=space&do=profile&uid=$value[authorid]">
                    <div class="wqhead">  <!--{avatar($value[authorid],small)}--></div>
                    <div class="wqmessage_info">
                        <h2 class="wqname wqellipsis">  <!--{if $value[author]}-->
                            <em id="author_$value[cid]">{$value[author]}</em>
                            <!--{else}-->
                            $_G[setting][anonymoustext]
                            <!--{/if}-->
                            <!--{if $value[status] == 1}--><b>({lang moderate_need})</b><!--{/if}--></h2>
                        <p class="wq_grey wqellipsis wqapp_f14"><!--{date($value[dateline])}--></p>
                    </div>
                </a>
                <div class="wqmessage_info_btn">
                    <!--{if $_G[uid]}-->
                    <!--{if $value[authorid]==$_G[uid]}-->
                    <a href="home.php?mod=spacecp&ac=comment&op=edit&cid=$value[cid]&handlekey=editcommenthk_{$value[cid]}" cid="{$value[cid]}">{lang edit}</a>
                    <!--{/if}-->
                    <!--{/if}-->

                    <!--{if $value[authorid]!=$_G[uid] && ($value['idtype'] != 'uid' || $space[self]) && $value[author]}-->
                    <a cid="{$value[cid]}" class="wq_reply_comment" href="javascript:;" author="$value[author]">{lang reply}</a>
                    <!--{/if}-->

                     <!--{if $_G[uid]}-->
                    <!--{if $value[authorid]==$_G[uid] || $value[uid]==$_G[uid] || checkperm('managecomment')}-->
                    <a  class="dialog" href="home.php?mod=spacecp&ac=comment&op=delete&cid=$value[cid]&handlekey=delcommenthk">{lang delete}</a>
                    <!--{/if}-->
                     <!--{/if}-->

                </div>
            </div>
            <div class="wqmessage_con">
                <!--{if $value[status] == 0 || $value[authorid] == $_G[uid] || $_G[adminid] == 1}-->
                 <!--{eval $value[message] = wq_app_edit_message($value[message],0,true);}-->
                $value[message]
                <!--{else}-->
                {lang moderate_not_validate}
                <!--{/if}-->
            </div>
            <div class="wqseparate"></div>
        </li>
        <!--{/loop}-->
    </ul>
</div>
<!--{else}-->
<p class="wqemp"><span class="wqno_con"><img src="{$_G['style'][styleimgdir]}images/wqno_con.png"></span>{$Tlang['be7a557fd1bbd82f']}</p>
<!--{/if}-->

<!--{if $_G['uid'] || $_G['group']['allowcomment']}-->

    <form  action="home.php?mod=spacecp&ac=comment" method="post">
        <input type="hidden" name="formhash" value="{FORMHASH}"/>
        <input type="hidden" name="referer" value="home.php?mod=space&uid=$space[uid]&do=wall"/>
        <input type="hidden" name="id" value="$space[uid]" />
        <input type="hidden" name="idtype" value="uid" />
        <input type="hidden" name="handlekey" value="wq_wall"/>
        <input type="hidden"  id="wq_commentsubmit" name="commentsubmit" value="true"/>
        <input type="hidden" id="wq_cid" name="cid" value=""/>
        <input type="hidden" id="wq_op" name="op" value=""/>
        <input type="hidden" id="wq_editsubmit" name="editsubmit" value=""/>

        <!--{eval
            $headparams['wclass'] = 'wqheader wqbg_color new_lump';
            $headparams['wtype'] = '';
            $headparams['wextra'] = 'style="display:none; z-index: 12;"';

            $headparams['ltype'] = 'cancel';
            $headparams['lname'] = $Tlang['9c825be7149e5b97'];
            $headparams['lurl'] = 'javascript:void(0);';

            $headparams['ctype'] = 'span';
            $headparams['cname'] =$Tlang['dbedca5ca18ae5c8'];

            $headparams['rtype'] = 'but';
            $headparams['rname'] = $Tlang['c0e5b55d87a9643f'];
            $headparams['rclass'] = 'formdialog';
            $headparams['rid'] = 'postsubmit';
            $headparams['butname'] = 'ratesubmit';

            echo wq_app_get_header($headparams, false, true) ;
        }-->
        <div class="wqpost_list new_list" style="display:none;">
            <ul class="wqpost_list_ul">
                <li class="post_con wqnew_bottom">
                    <textarea class="wqpost_textarea" id="needmessage" tabindex="3" autocomplete="off" name="message" rows="2" placeholder="{$Tlang['5e56dd8f3b5bc8e4']}" fwin="reply" style="height: 120px;"></textarea>
                    <div class="wqpost_upload"><span class="wqiconfont2 wqicon2-biaoqing wqapp_f26 wqbiaoqing"></span>
                    </div>
                </li>
            </ul>
            <!--{template common/smilies}-->
        </div>
        <script>
            function succeedhandle_wq_wall(url, msg, param) {
                if ($.trim(msg) == "{$Tlang['89a32ae645876649']}" + param.username + "{$Tlang['e1bc41868facb6f7']}") {
                    clearInterval(setTimeout_location);
                    setTimeout(function () {
                        location.reload();
                    }, '1000');
                } else if ($.trim(msg) == "{$Tlang['357c80f9fe7dbb3f']}") {
                    clearInterval(setTimeout_location);
                    setTimeout(function () {
                        location.reload();
                    }, '1000');
                }
            }
            function succeedhandle_delcommenthk(url, msg, param) {
                if ($.trim(msg) == "{$Tlang['357c80f9fe7dbb3f']}") {
                    $('#comment_' + param.cid + '_li').remove();
                    clearInterval(setTimeout_location);
                    setTimeout(function () {
                        popup.close();
                    }, '1000');
                }
            }
            var scroll_Top;
            $("#wq_reply_click").on("click",function(e){
                scroll_Top = $(window).scrollTop();
                $('.wqmessage').hide()
                $('.new_lump').show()
                $('.new_list').show()
                $('#wq_cid,#wq_op,#wq_editsubmit').val('');
                $('#needmessage').attr('placeholder', "{$Tlang['5e56dd8f3b5bc8e4']}").val('').focus();

            });

            $('.wq_reply_comment').on('click', function () {
                scroll_Top = $(window).scrollTop();
                $('.wqmessage').hide()
                $('.new_lump').show()
                $('.new_list').show()

                var cid = $(this).attr('cid');
                var author = $(this).attr('author');
                $('#wq_cid').val(cid);
                $('#wq_op,#wq_editsubmit').val('');
                $('#wq_commentsubmit').val('1');
                $('#needmessage').attr('placeholder', "{$Tlang['209e3f19421ead4d']} " + author).val('').focus();
            });

            $('.wqbiaoqing').on('click', function () {
                $(this).toggleClass('wqicon2-jianpan')
                if ($('.cellphone_expression').is(':hidden')) {
                    $('#imglist').hide()
                    $('.cellphone_expression').show()
                    $('#upload_icon').removeClass('blue')
                    $('.wqbiaoqing').removeClass('wqicon2-biaoqing')
                    expression_viwepager()
                } else {
                    $('.cellphone_expression').hide()
                    $('.wqbiaoqing').addClass('wqicon2-biaoqing')
                }
            });
            function expression_insertunit(obj) {
                var id_val = $('.wqpost_textarea').val()
                $('.wqpost_textarea').val(id_val + obj.attr('code'))
            }
            deleteSmilies('{:', ':}')
            function postsubmit_button() {
                $('#postsubmit').attr('disabled', ($.trim($('#needmessage').val()) ? null : 'disabled'))
            }
            wq_app_ajax_scroll('$page', '$count', '$perpage', 'home.php?mod=space&uid={$space[uid]}&do=wall&from=space', 'wq_wall_list')
        </script>
    </form>
<!--{/if}-->

<!--{template common/footer}-->
<!--{/if}-->