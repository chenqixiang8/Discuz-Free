<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['spacecp_poke'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{template common/header}-->
<!--{template home/spacecp_poke_type}-->

<!--<form method="post" autocomplete="off" id="pokeform_{$tospace[uid]}" name="pokeform_{$tospace[uid]}" action="home.php?mod=spacecp&ac=poke&inajax=yes&op=$op&uid=$tospace[uid]" onsubmit="$.post($(this).attr('action'), $(this).serialize(), function (s) {
    popup.open(s.lastChild.firstChild.nodeValue);
    }, 'xml');
return false;">-->

<!--{if $op == 'send' || $op == 'reply'}-->
    <!--{eval $tospace[uid]=$tospace[uid];}-->
<!--{elseif $op == 'ignore'}-->
    <!--{eval $tospace[uid]=$uid;}-->
<!--{/if}-->

<form method="post" autocomplete="off" id="pokeform_{$tospace[uid]}" name="pokeform_{$tospace[uid]}" action="home.php?mod=spacecp&ac=poke&inajax=yes&op=$op&uid=$tospace[uid]" onsubmit="$.post($(this).attr('action'), $(this).serialize(), function (s) {popup.open(wqXml(s));}, 'html');return false;">
    <input type="hidden" name="referer" value="{echo dreferer()}"/>
    <input type="hidden" name="formhash" value="{FORMHASH}" />
    <input type="hidden" name="formhash" value="{FORMHASH}" />
    <input type="hidden" name="from" value="$_GET[from]" />
    <!--{if $_G[inajax]}-->
        <input type="hidden" name="handlekey" value="$_GET[handlekey]" />
    <!--{/if}-->
    <!--{if $op == 'send' || $op == 'reply'}-->
        <input type="hidden" name="pokesubmit" value="true" />

        <!--{eval
            $headparams['wtype'] = '2';

            $headparams['ltype'] = 'cancel';
            $headparams['lname'] = "{lang cancel}";
            $headparams['lurl'] = 'javascript:void(0);';

            $headparams['ctype'] = 'span';
            $headparams['cname'] =$Tlang['6f9fef320a80fb33'];

            $headparams['rtype'] = 'but';
            $headparams['rname'] = "{lang send}";
            $headparams['rclass'] = $_G[inajax] ? 'pns' : "";
            $headparams['rid'] = 'pokesubmit_btn';
            $headparams['butname'] = 'pokesubmit_btn';

            echo wq_app_get_header($headparams, false, true) ;
        }-->

    <!--{/if}-->
    <!--{if !$_G[inajax]}-->
        <div id="ct" class="ct2_a wp cl">
            <div class="mn">
                <div class="bm bw0">
    <!--{/if}-->
                    <div class="wqsay_hello_warp">
                        <!--{if $op == 'send' || $op == 'reply'}-->
                            <div class="wqsay_hello c {if $_G[inajax]}altw{else}mtm{/if}">
                                <div class="mbm xs2">
                                    <!--{if $tospace[uid]}-->
                                        {lang to} <a href="home.php?mod=space&do=profile&uid=$tospace[uid]" class="avt avts"><!--{avatar($tospace[uid],small)}--></a>
                                        <strong>{$tospace[username]}</strong> {lang say_hi}:
                                    <!--{else}-->
                                        {lang username}: <input type="text" name="username" value="" class="px" />
                                    <!--{/if}-->
                                </div>
                                <ul class="poke cl">
                                    <!--{loop $icons $k $v}-->
                                        <li>
                                            <input class="weui_check" type="radio" name="iconid" id="poke_$k" value="{$k}" {if $k==3}checked="checked"{/if} />
                                            <label class="weui_check_label" for="poke_$k"><i class="weui_icon_checked" style='vertical-align: sub;'></i>{$v}</label>
                                        </li>
                                    <!--{/loop}-->
                                </ul>
                            </div>

            <!--                    <p class="o{if $_G[inajax]} pns{/if}">
                                    <button type="submit" name="pokesubmit_btn" id="pokesubmit_btn" value="true" class="wqdetermine">{lang send}</button>
                                    <a href="javascript:;" onclick="popup.close();"  class="wqeject_cancel">{lang cancel}</a>
                                </p>-->

                        <!--{elseif $op == 'view'}-->
                            <!--{loop $list $key $subvalue}-->
                                <p class="pbm mbm bbda">
                                    <!--{if $subvalue[fromuid]==$space[uid]}-->
                                        {lang me}
                                    <!--{else}-->
                                        <a href="home.php?mod=space&do=profile&uid=$subvalue[fromuid]" class="xi2">{$value[fromusername]}</a>
                                    <!--{/if}-->:
                                    <span class="xw0">
                                        <!--{if $subvalue[iconid]}-->{$icons[$subvalue[iconid]]}<!--{else}-->{lang say_hi}<!--{/if}-->
                                        <!--{if $subvalue[note]}-->, {lang say}: $subvalue[note]<!--{/if}-->
                                        &nbsp; <span class="xg1"><!--{date($subvalue[dateline],'n-j H:i')}--></span>
                                    </span>
                                </p>
                            <!--{/loop}-->

                            <div class="pbn ptm xg1 xw0">
                                <a href="home.php?mod=spacecp&ac=poke&op=reply&uid=$value[uid]&handlekey=pokehk_{$value[uid]}" id="a_p_r_$value[uid]" onclick="showWindow(this.id, this.href, 'get', 0);">
                                    {lang back_to_say_hello}
                                </a>
                                <span class="pipe">|</span>
                                <a href="home.php?mod=spacecp&ac=poke&op=ignore&uid=$value[uid]" id="a_p_i_$value[uid]" onclick="showWindow('pokeignore', this.href, 'get', 0);">
                                    {lang ignore}
                                </a>
                                <!--{if !$value['isfriend']}-->
                                    <span class="pipe">|</span>
                                    <a href="home.php?mod=spacecp&ac=friend&op=add&uid=$value[uid]&handlekey=addfriendhk_{$value[uid]}" id="a_friend_$value[uid]" onclick="showWindow(this.id, this.href, 'get', 0);">
                                        {lang add_friend}
                                    </a>
                                <!--{/if}-->
                            </div>
                        <!--{elseif $op == 'ignore'}-->
                            <input type="hidden" name="ignoresubmit" value="true" />
                            <div class="wqshield_notice">
                                 <div class="wqshield_con">
                                     <p>{lang determine_lgnore_poke}</p>
                                 </div>
                                 <p class="wqbtn_can wqnew_top">
                                     <a href="javascript:;" onclick="popup.close();" class="wqeject_cancel wqnew_right">{lang cancel}</a>
                                     <button type="submit" name="ignoresubmit_btn" class="wqdetermine" value="true">{lang determine}</button>
                                 </p>

                             </div>
                        <!--{else}-->
                            <p class="tbmu">{lang you_can_reply_ignore}
                                <span class="pipe">|</span>
                                <a href="home.php?mod=spacecp&ac=poke&op=ignore" id="a_poke" onclick="showWindow('allignore', this.href, 'get', 0);">{lang ignore_all}</a>
                            </p>
                            <!--{if $list}-->
                                <div id="poke_ul" class="xld xlda">
                                    <!--{loop $list $key $value}-->
                                        <dl id="poke_$value[uid]" class="bbda cl">
                                            <dd class="m avt"><a href="home.php?mod=space&do=profile&uid=$value[uid]"><!--{avatar($value[uid],small)}--></a></dd>
                                            <dt id="poke_td_$value[uid]">
                                            <p class="mbm">
                                                <a href="home.php?mod=space&do=profile&uid=$value[fromuid]" class="xi2">{$value[fromusername]}</a>:
                                                <span class="xw0">
                                                    <!--{if $value[iconid]}-->{$icons[$value[iconid]]}<!--{else}-->{lang say_hi}<!--{/if}-->
                                                    <!--{if $value[note]}-->, {lang say}: $value[note]<!--{/if}-->
                                                    &nbsp; <span class="xg1"><!--{date($value[dateline], 'n-j H:i')}--></span>
                                                </span>
                                            </p>
                                            <div class="pbn ptm xg1 xw0 cl">
                                                <div class="y"><a href="javascript:;" onclick="view_poke($value[uid]);">{lang see_all_poke}</a></div>
                                                <a href="home.php?mod=spacecp&ac=poke&op=reply&uid=$value[uid]&handlekey=pokereply" id="a_p_r_$value[uid]" onclick="showWindow('pokereply', this.href, 'get', 0);">{lang back_to_say_hello}</a><span class="pipe">|</span>
                                                <a href="home.php?mod=spacecp&ac=poke&op=ignore&uid=$value[uid]&handlekey=pokeignore" id="a_p_i_$value[uid]" onclick="showWindow('pokeignore', this.href, 'get', 0);">{lang ignore}</a>
                                                <!--{if !$value['isfriend']}--><span class="pipe">|</span><a href="home.php?mod=spacecp&ac=friend&op=add&uid=$value[uid]&handlekey=addfriendhk_{$value[uid]}" id="a_friend_$value[uid]" onclick="showWindow(this.id, this.href, 'get', 0);">{lang add_friend}</a> <!--{/if}-->
                                            </div>
                                            </dt>
                                        </dl>
                                    <!--{/loop}-->
                                </div>
                                <!--{if $multi}-->
                                    <div class="pgs cl mtm">$multi</div>
                                <!--{/if}-->
                            <!--{else}-->
                                <div class="emp">{lang no_new_poke}</div>
                            <!--{/if}-->
                        <!--{/if}-->
                    </div>
    <!--{if !$_G[inajax]}-->
                </div>
                <div class="appl"></div>
            </div>
        </div>
    <!--{/if}-->
 </form>
<!--{eval $nofooter=1;}-->
<!--{template common/footer}-->
<!--{/if}-->