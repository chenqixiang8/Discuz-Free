<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['space_magic_shop_opreation'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{eval
	$_G['home_tpl_titles'] = array('{lang magic}');
}-->
<!--{template common/header}-->

    <!--{if $operation == 'buy'}-->
        <!--{eval $headparams['cname'] =lang('home/template','magics_operation_buy').lang('home/template','magic');}-->
    <!--{elseif $operation == 'give'}-->
        <!--{eval $headparams['cname'] =lang('home/template','magics_operation_present').'"'.$magic[name].'"';}-->
    <!--{/if}-->

    <!--{eval
        $headparams['wtype'] = '2';
        $headparams['ltype'] = 'a';
        $headparams['lclass'] = 'wqcancel';
        $headparams['lurl'] = 'javascript:void(0);';

	$headparams['ctype'] = 'span';
        echo wq_app_get_header($headparams, false) ;
    }-->

<form id="magicform" method="post" action="home.php?mod=magic&action=shop&infloat=yes"{if $_G[inajax]} onsubmit="ajaxpost('magicform', 'return_$_GET[handlekey]', 'return_$_GET[handlekey]', 'onerror');return false;"{/if}>
<div class="f_c">
	<div class="c">
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<!--{if !empty($_GET['infloat'])}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
		<input type="hidden" name="operation" value="$operation" />
		<input type="hidden" name="mid" value="$_GET['mid']" />
		<!--{if !empty($_GET['idtype']) && !empty($_GET['id'])}-->
			<input type="hidden" name="idtype" value="$_GET[idtype]" />
			<input type="hidden" name="id" value="$_GET[id]" />
		<!--{/if}-->
		<!--{if $operation == 'buy'}-->
                <div class="wqmagic_shop_list">
			<div class="mg_img wq_img"><img src="$magic[pic]" alt="" /></div>
			<div class="mbm pbm bbda">
                            <h3><strong>$magic[name]</strong></h3>
                            <p class="wq_grey">$magic[description]</p>
                            <p class="mtm xw0 mbn">{lang magics_price}: <span{if $magic[discountprice] && $magic[price] != $magic[discountprice]} style="text-decoration:line-through;"{/if}>{$_G['setting']['extcredits'][$magic[credit]][title]} <span class="wq_orange" id="magicprice">$magic[price]</span> {$_G['setting']['extcredits'][$magic[credit]][unit]}</span></p>
                            <!--{if $magic[discountprice] && $magic[price] != $magic[discountprice]}-->
                                    <p class="xw0 mbn">{lang magics_discountprice}: {$_G['setting']['extcredits'][$magic[credit]][title]} <span class="wq_orange" id="discountprice">$magic[discountprice]</span> $_G['setting']['extcredits'][$magic[credit]][unit]</p>
                            <!--{/if}-->
                            <p class="wq_grey">{lang magics_yourcredit} <!--{echo getuserprofile('extcredits'.$magic[credit])}--> {$_G['setting']['extcredits'][$magic[credit]][unit]}</p>
                            <p class="mtm xw0 mbn">{lang magics_weight}: <span class="wq_orange" id="magicweight">$magic[weight]</span></p>
                            <p class="wq_grey">{lang my_magic_volume} $allowweight</p>
                        </div>
                        <div class="xw0">
                                <p class="mtn xw0">{lang stock}: <span class="wq_orange">$magic[num]</span>{lang magics_unit}</p>
                                <!--{if $useperoid !== true}-->
                                        <p class="wq_grey"><!--{if $magic['useperoid'] == 1}-->{lang magics_outofperoid_1}<!--{elseif $magic['useperoid'] == 2}-->{lang magics_outofperoid_2}<!--{elseif $magic['useperoid'] == 3}-->{lang magics_outofperoid_3}<!--{elseif $magic['useperoid'] == 4}-->{lang magics_outofperoid_4}<!--{/if}--><!--{if $useperoid > 0}-->{lang magics_outofperoid_value}<!--{else}-->{lang magics_outofperoid_noperm}<!--{/if}--></p>
                                <!--{/if}-->
                                <!--{if !$useperm}--><p class="wq_grey">{lang magics_permission_no}</p><!--{/if}-->
                                <p class="mtn">{lang memcp_usergroups_buy}
                                    <span class="wq_input"><input id="magicnum" name="magicnum" type="text" size="2" autocomplete="off" value="1" onkeyup="compute();" /></span>
                                    {lang magics_unit}
                                </p>
                        </div>
                </div>
			<input type="hidden" name="operatesubmit" value="yes" />
		<!--{elseif $operation == 'give'}-->
			<div class="wqmagic_give">
                            <ul>
				<li>
                                    <span class="wq_title">{lang magics_target_present}</span>
                                    <div class="wq_input" style="width: 80%; display: inline-block;"><input type="text" id="selectedusername" name="tousername" size="12" autocomplete="off" value="" class="px p_fre" style="margin-right: 0;" /></div>
                                    <!--{if $buddyarray}-->
                                    <!--<div class="wq_selectedusername"><a href="javascript:;" onclick="showselect(this, 'selectedusername', 'selectusername')" class="dpbtn"><i class="wqiconfont2 wqicon2-youjiantou-copy"></i></a></div>-->
                                    <span class="wqmagic_kuang">
                                        <i class="wqiconfont2 wqicon2-youjiantou-copy"></i>
                                    <select id="selectusername" class="wqmagic_ratecon">
                                            <!--{loop $buddyarray $buddy}-->
                                            <option>$buddy[fusername]</option>
                                            <!--{/loop}-->
                                    </select>
                                        </span>
                                    <!--{/if}-->
				</li>
				<li>
                                    <span class="wq_title">{lang magics_num}</span>
                                    <div class="wq_input"><input name="magicnum" type="text" size="12" autocomplete="off" value="1" class="px p_fre" /></div>
				</li>
				<li>
                                    <span class="wq_title">{lang magics_present_message}</span>
                                    <div class="wq_textarea"><textarea name="givemessage" rows="3" class="pt">{lang magics_present_message_text}</textarea></div>
				</li>
                            </ul>
			</div>
			<input type="hidden" name="operatesubmit" value="yes" />
		<!--{/if}-->
	</div>
</div>
<!--{if empty($_GET['infloat'])}--><div class="m_c"><!--{/if}-->
<div class="wqmagic_button">
	<!--{if $operation == 'buy'}-->
		<button class="button2 formdialog" type="submit" name="operatesubmit" id="operatesubmit" value="true">{lang magics_operation_buy}</button>
	<!--{elseif $operation == 'give'}-->
		<button class="button2 formdialog" type="submit" name="operatesubmit" id="operatesubmit" value="true" onclick="return confirmMagicOp(e)">{lang magics_operation_present}</button>
	<!--{/if}-->
</div>
<!--{if empty($_GET['infloat'])}--></div><!--{/if}-->
</form>

<script type="text/javascript" reload="1">
	function succeedhandle_$_GET[handlekey](url, msg) {
		hideWindow('$_GET[handlekey]');
		<!--{if !$location}-->
			showDialog(msg, 'notice', null, function () { location.href=url; }, 0);
		<!--{else}-->
			showWindow('$_GET[handlekey]', 'home.php?$querystring');
		<!--{/if}-->
		showCreditPrompt();
	}
	function confirmMagicOp(e) {
		e = e ? e : window.event;
		showDialog('{lang magics_confirm}', 'confirm', '', 'ajaxpost(\'magicform\', \'return_magics\', \'return_magics\', \'onerror\');');
		doane(e);
		return false;
	}
	function compute() {
		var totalcredit = <!--{echo getuserprofile('extcredits'.$magic[credit])}-->;
		var totalweight = $allowweight;
		var magicprice = $('magicprice').innerHTML;
		if($('discountprice')) {
			magicprice = $('discountprice').innerHTML;
		}
		if(isNaN(parseInt($('magicnum').value))) {
			$('magicnum').value = 0;
			return;
		}
		if(!$('magicnum').value || totalcredit < 1 || totalweight < 1) {
			$('magicnum').value = 0;
			return;
		}
		var curprice = $('magicnum').value * magicprice;
		var curweight = $('magicnum').value * $('magicweight').innerHTML;
		if(curprice > totalcredit) {
			$('magicnum').value = parseInt(totalcredit / magicprice);
		} else if(curweight > totalweight) {
			$('magicnum').value = parseInt(totalweight / $('magicweight').innerHTML);
		}
		$('magicnum').value = parseInt($('magicnum').value);
	}
         $(function () {
                $('.wqmagic_ratecon').on('change', function () {
                    $('#selectedusername').val($('.wqmagic_ratecon').val())
                });
            });
</script>
<!--{eval $nofooter=1;}-->
<!--{template common/footer}-->
<!--{/if}-->