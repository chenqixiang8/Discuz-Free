<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['space_friend'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{template common/header}-->
    <!--{eval $headright=false;}-->
    <!--{if helper_access::check_module('collection')}-->
        <!--{eval $headright=true;}-->
    <!--{/if}-->

    <!--{eval
        $headparams['wtype'] = '1';
        $headparams['ltype'] = 'a';
        $headparams['lurl'] = $backurl;
        $headparams['cname'] = $Tlang['492d7428cf380a08'];
        $headparams['rtype'] = 'a';
        $headparams['rclass'] = 'wqapp_f16';

        $headparams['rtype'] = 'a';
        $headparams['rclass'] = '';

        echo wq_app_get_header($headparams,true,$headright);
    }-->

    <div id="ct">
	<div class="mn">
            <div class="wq_friend_paste wqnew_bottom slide-stop" id="wq_friend_paste">
                <div class="tag_list">
                        <ul>
                            <li{$a_actives[me]}><a href="home.php?mod=space&do=friend">{$Tlang['492d7428cf380a08']}</a></li>
                            <!--{if empty($_G['setting']['sessionclose'])}-->
                                <li{$a_actives[onlinefriend]}><a href="home.php?mod=space&do=friend&view=online&type=friend">{$Tlang['6b544f7ca0dafd71']}</a></li>
                                <li{$a_actives[onlinemember]}><a href="home.php?mod=space&do=friend&view=online&type=member">{lang online_member}</a></li>
                            <!--{/if}-->
                            <li{$a_actives[onlinenear]}><a href="home.php?mod=space&do=friend&view=online&type=near">{$Tlang['b5c1fa83a20109c8']}</a></li>
                            <li{$a_actives[visitor]}><a href="home.php?mod=space&do=friend&view=visitor">{$Tlang['e6770cc65c1bebb1']}</a></li>
                            <li{$a_actives[trace]}><a href="home.php?mod=space&do=friend&view=trace">{$Tlang['fbf0ea853e6edcc0']}</a></li>
                            <li{$actives[request]}><a href="home.php?mod=spacecp&ac=friend&op=request">{lang friend_request}</a></li>
                            <li{$a_actives[blacklist]}><a href="home.php?mod=space&do=friend&view=blacklist">{$Tlang['3fd457794e518744']}</a></li>
                        </ul>
                </div>
            </div>
            <!--{eval $my_roll_tag='wq_friend_paste';}-->
            <!--{template common/slide}-->

            <!--{if $_GET['view']=='me'}-->
                <div class="wq_friend_tbmu wqnew_bottom">
                    <span class="y">
                        <!--{if $maxfriendnum}-->
                        {$Tlang['8e59542e8f18c269']}(<span class="xw1">$count</span>/$maxfriendnum)
                            <!--{if $_G['setting']['magicstatus'] && $_G[setting][magics][friendnum]}-->
                                &nbsp;&nbsp;{$Tlang['e6bc045ab2e93181']}<a id="a_magic_friendnum" href="home.php?mod=magic&mid=friendnum">{$_G[setting][magics][friendnum]}</a>
                            <!--{/if}-->
                        <!--{else}-->
                            {lang count_member}
                        <!--{/if}-->
                    </span>
                    <a href="home.php?mod=space&do=friend&order=num">{$Tlang['407c48c054720edc']}</a>
                </div>
            <!--{/if}-->
            <!--{if $_GET['view']=='blacklist'}-->
               <div class="wq_blacklist_warp">
                    <h2 class="wq_title">{lang add_blacklist}</h2>
                    <form method="post" autocomplete="off" name="blackform" action="home.php?mod=spacecp&ac=friend&op=blacklist&start=$_GET[start]">
                        <p class="wq_input">
                             <input type="text" name="username" value="" size="15" class="px vm" placeholder="{lang username}"/>
                         </p>
                         <p class="wq_button"><button type="submit" name="blacklistsubmit_btn" id="moodsubmit_btn" value="true" class="button2 formdialog"><em>{lang add}</em></button></p>
                        <input type="hidden" name="blacklistsubmit" value="true" />
                        <input type="hidden" name="handlekey" value="blacklist" />
                        <input type="hidden" name="formhash" value="{FORMHASH}" />
                    </form>
                </div>
            <!--{/if}-->

            <!--{if $list}-->
                <div id="friend_ul" class="wq_friend_warp">
                    <ul class="buddy">
                    <!--{loop $list $key $value}-->
                        <div class="wq_con" id="friend_{$value[uid]}_li">
                            <li class="wqnew_bottom">
                                <!--{if $value[username] == ''}-->
                                    <div class="wq_head"><img src="{STATICURL}image/magic/hidden.gif" alt="{lang anonymity}" /></div>
                                    <h4>{lang anonymity}</h4>
                                <!--{else}-->
                                    <div class="wq_head">
                                        <a href="home.php?mod=space&uid=$value[uid]" c="1">
                                            <!--{if $ols[$value[uid]]}--><em class="gol" title="{lang online} {date($ols[$value[uid]], 'H:i')}"></em><!--{/if}-->
                                            <!--{avatar($value[uid],small)}-->
                                        </a>
                                    </div>
                                    <h4>
                                        <span class="y">
                                            <!--{if $_GET['view'] == 'blacklist'}-->
                                                <a href="home.php?mod=spacecp&ac=friend&op=blacklist&subop=delete&uid=$value[uid]&start=$_GET[start]&handlekey=black_del" class="dialog" onclick="setcookie('blackuid','{$value[uid]}', 500)">
                                                    {lang delete_blacklist}
                                                </a>
                                            <!--{elseif $_GET['view'] == 'visitor' || $_GET['view'] == 'trace'}-->
                                                <!--{date($value[dateline], 'n{lang month}j{lang day}')}-->
                                            <!--{elseif $_GET['view'] == 'online'}-->
                                                <!--{date($ols[$value[uid]], 'H:i')}-->
                                            <!--{else}-->
                                                {lang hot}(<span id="spannum_$value[uid]">$value[num]</span>)
                                            <!--{/if}-->
                                        </span>
                                        <a href="home.php?mod=space&uid=$value[uid]"{eval g_color($value[groupid]);}>$value[username]</a>
                                        <!--{eval g_icon($value[groupid]);}-->
                                        <!--{if $value['videostatus']}-->
                                            <img src="{IMGDIR}/videophoto.gif" alt="videophoto" class="vm" />
                                        <!--{/if}-->
                                        <!--{if $space[self]}-->
                                            <span id="friend_note_$value[uid]" class="note xw0">$value[note]</span>
                                        <!--{/if}-->
                                    </h4>
                                    <p class="maxh">
                                        <!--{eval $value['recentnote'] = wq_app_edit_message($value['recentnote'],0,true);}-->
                                        $value[recentnote]
                                    </p>
                                <!--{/if}-->
                                <div class="wqxg1">
                                    <!--{if isset($value['follow']) && $key != $_G['uid'] && $value[username] != ''}-->
                                        <a href="home.php?mod=spacecp&ac=follow&op={if $value['follow']}del{else}add{/if}&fuid=$value[uid]&hash={FORMHASH}&from=a_followmod_" id="a_followmod_$key" class="dialog">
                                            <!--{if $value['follow']}-->{$Tlang['914d2c5341afe66f']}<!--{else}-->{$Tlang['3d30950d553664c2']}<!--{/if}-->
                                        </a>
                                    <!--{/if}-->

                                    <!--{if $value[uid] != $_G['uid'] && $value[username] != ''}-->
                                        <span class="pipe">|</span>
                                        <span class="interactiv_new_div">
                                            <a href="#interaction_$value[uid]" onclick="expand_the_menu(this,'interactiv_new_div');return false" class="interactiv_new_button">
                                                {lang interactive}
                                            </a>
                                        </span>
                                        <div id="interaction_$value[uid]" name="interaction_$value[uid]" popup="true" class="wqfriend_interactive_eject wqbolg_js2 new_menu" style="display:none;">
                                            <span class="wqfriend_interactive_eject_arrow"></span>
                                            <ul>
                                                <li><a href="home.php?mod=space&uid=$value[uid]&do=profile">{lang view_profile}</a></li>
                                                <li><a href="home.php?mod=space&uid=$value[uid]">{lang visit_friend}</a></li>
                                                <li><a href="home.php?mod=spacecp&ac=poke&op=send&uid=$value[uid]" id="a_poke_$key">{lang say_hi}</a></li>
                                                <li><a href="home.php?mod=space&do=pm&subop=view&touid=$value[uid]" id="a_sendpm_$key">{lang send_pm}</a></li>
                                                <!--{hook/space_interaction_extra}-->
                                            </ul>
                                        </div>
                                    <!--{/if}-->
                                    <!--{if !$value[isfriend] && $value[username] != ''}-->
                                        <span class="pipe">|</span>
                                            <a href="home.php?mod=spacecp&ac=friend&op=add&uid=$value[uid]&handlekey=adduserhk_{$value[uid]}" id="a_friend_$key" class="dialog">
                                            {lang add_friend}
                                            </a>
                                    <!--{elseif !in_array($_GET['view'], array('blacklist', 'visitor', 'trace', 'online'))}-->
                                        <span class="pipe">|</span>
                                        <span class="manage_new_div">
                                            <a href="#opfrd_$value[uid]" onclick="expand_the_menu(this,'manage_new_div','new_menu1');return false" class="manage_new_button">{lang manage}</a>
                                        </span>
                                        <div id="opfrd_$value[uid]" name="opfrd_$value[uid]" popup="true" class="wqfriend_manage_eject wqbolg_js2 new_menu1" style="display:none;">
                                            <span class="wqfriend_manage_eject_arrow"></span>
                                            <ul>
                                                <li><a href="home.php?mod=spacecp&ac=friend&op=changegroup&uid=$value[uid]&handlekey=editgrouphk_{$value[uid]}" id="friend_group_$value[uid]" class="dialog">{lang set_friend_group}</a></li>
                                                <li><a href="home.php?mod=spacecp&ac=friend&op=editnote&uid=$value[uid]&handlekey=editnote_{$value[uid]}" id="friend_editnote_$value[uid]" class="dialog">{lang friend_editnote}</a></li>
                                                <li><a href="home.php?mod=spacecp&ac=friend&op=ignore&uid=$value[uid]&handlekey=delfriendhk_{$value[uid]}" id="a_ignore_$key" class="dialog">{lang delete}</a></li>
                                            </ul>
                                        </div>
                                    <!--{/if}-->
                                </div>
                            </li>
                        </div>
                    <!--{/loop}-->
                    </ul>
                </div>
                <!--{if $multi}--><div class="pgs cl mtm">$multi</div><!--{/if}-->
            <!--{else}-->
                <!--{if $_GET['view'] == 'me' && !$friendnum && ($online_list || $specialuser_list)}-->
                    <!--{if $specialuser_list}-->
                        <h2 class="wq_friend_h2">{lang recommend_friend}</h2>
                        <div id="friend_ul"  class="wq_friend_warp">
                            <ul class="buddy">
                                <!--{loop $specialuser_list $key $value}-->
                                    <div class="wq_con">
                                        <li class="wqnew_bottom">
                                            <div class="wq_head">
                                                <a href="home.php?mod=space&uid=$value[uid]" c="1">
                                                    <!--{if $ols[$value[uid]]}--><em class="gol" title="{lang online} {date($ols[$value[uid]], 'H:i')}"></em><!--{/if}-->
                                                    <!--{avatar($value[uid],small)}-->
                                                </a>
                                            </div>
                                            <h4>
                                                <a href="home.php?mod=space&uid=$value[uid]">$value[username]</a>
                                            </h4>
                                            <p class="maxh">
                                                <!--{eval $value['reason'] = wq_app_edit_message($value['reason'],0,true);}-->
                                                $value[reason]
                                            </p>
                                            <div class="xg1">
                                            <!--{if isset($value['follow']) && $key != $_G['uid'] && $value[username] != ''}-->
                                                <a href="home.php?mod=spacecp&ac=follow&op={if $value['follow']}del{else}add{/if}&fuid=$value[uid]&hash={FORMHASH}&from=a_specialuser_" id="a_specialuser_$key" class="dialog"><!--{if $value['follow']}-->{$Tlang['914d2c5341afe66f']}<!--{else}-->{$Tlang['3d30950d553664c2']}<!--{/if}--></a>
                                                <span class="pipe">|</span>
                                            <!--{/if}-->
                                            <a href="home.php?mod=spacecp&ac=friend&op=add&uid=$value[uid]&handlekey=adduserhk_{$value[uid]}" id="a_friend_$key" class="dialog">{lang add_friend}</a>
                                            </div>
                                        </li>
                                    </div>
                                <!--{/loop}-->
                            </ul>
                        </div>
                    <!--{/if}-->

                    <!--{if $online_list}-->
                        <h2 class="wq_friend_h2">{lang online_member}</h2>
                        <div id="friend_ul"  class="wq_friend_warp">
                            <ul class="buddy">
                                <!--{loop $online_list $key $value}-->
                                    <div class="wq_con">
                                        <li  class="wqnew_bottom">
                                            <div class="wq_head">
                                                <a href="home.php?mod=space&uid=$value[uid]" c="1">
                                                    <!--{if $ols[$value[uid]]}--><em class="gol" title="{lang online} {date($ols[$value[uid]], 'H:i')}"></em><!--{/if}-->
                                                    <!--{avatar($value[uid],small)}-->
                                                </a>
                                            </div>
                                            <h4>
                                                <a href="home.php?mod=space&uid=$value[uid]">$value[username]</a>
                                            </h4>
                                            <p class="maxh">
                                                <!--{eval $value['recentnote'] = wq_app_edit_message($value['recentnote'],0,true);}-->
                                                $value[recentnote]
                                            </p>
                                            <div class="xg1">
                                                <!--{if isset($value['follow']) && $key != $_G['uid'] && $value[username] != '' && helper_access::check_module('follow')}-->
                                                    <a href="home.php?mod=spacecp&ac=follow&op={if $value['follow']}del{else}add{/if}&fuid=$value[uid]&hash={FORMHASH}&from=a_online_" id="a_online_$key" class="dialog"><!--{if $value['follow']}-->{$Tlang['914d2c5341afe66f']}<!--{else}-->{$Tlang['3d30950d553664c2']}<!--{/if}--></a>
                                                    <span class="pipe">|</span>
                                                <!--{/if}-->
                                                <a href="home.php?mod=spacecp&ac=friend&op=add&uid=$value[uid]&handlekey=adduserhk_{$value[uid]}" id="a_friend_$key" class="dialog">{lang add_friend}</a>
                                            </div>
                                        </li>
                                    </div>
                                <!--{/loop}-->
                            </ul>
                        </div>
                    <!--{/if}-->
                <!--{else}-->
                    <div class="wqemp"><span class="wqno_con"><img src="{$_G['style'][styleimgdir]}images/wqno_con.png"></span>{lang no_friend_list}</div>
                <!--{/if}-->
            <!--{/if}-->
            <script type="text/javascript">
                function succeedhandle_followmod(url, msg, values) {
                    var fObj = $('#'+values['from']+values['fuid']);
                    if(values['type'] == 'add') {
                        fObj.html('{$Tlang['914d2c5341afe66f']}');
                        fObj.attr('href','home.php?mod=spacecp&ac=follow&op=del&fuid='+values['fuid']+'&from='+values['from']);
                    } else if(values['type'] == 'del') {
                        fObj.html('{$Tlang['3d30950d553664c2']}');
                        fObj.attr('href','home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid='+values['fuid']+'&from='+values['from']);
                    }
                    wq_setTimeout();
                }

                function succeedhandle_black_del(url, msg){
                    var blackuid = getcookie('blackuid');
                    if($('#friend_'+blackuid+'_li').length > 0){
                        $('#friend_'+blackuid+'_li').remove();
                        if($('.buddy li.wqnew_bottom').length == 0){
                            $('#friend_ul').before('<div class="wqemp"><span class="wqno_con"><img src="{$_G[style][styleimgdir]}images/wqno_con.png"></span>{lang no_friend_list}</div>');
                        }
                        setcookie('blackuid','');
                        wq_setTimeout();
                    }
                }
            </script>
        </div>
    </div>
    <div class="new_hide" style="display: none;"></div>
<!--{template common/footer}-->

<!--{/if}-->