<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['spacecp_usergroup'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{eval $header_nav='null';}-->
<!--{eval
function permtbody($maingroup) {
global $_G,$Tlang, $bperms, $pperms, $sperms, $aperms,$permlang;
}-->
<tr class="wqnew_bottom">
    <th class="wqnew_right">{$Tlang['f83d5120d181de41']}</th>
    <td>
        <span class="wqm_right5" style="vertical-align: text-bottom;"><!--{echo  wq_usergroup_show($maingroup[groupid]);}--></span>
        <!--{echo showstars($_G['cache']['usergroups'][$maingroup['groupid']]['stars']);}--></td></tr>
<!--{loop $bperms $key $groupbperm}-->
<tr class="wqnew_bottom">
<th class="wqnew_right">$permlang['perms_'.$groupbperm]</th>
<td>
    <!--{if $groupbperm == 'creditshigher' || $groupbperm == 'readaccess' || $groupbperm == 'maxpmnum'}-->
    $maingroup[$groupbperm]
    <!--{elseif $groupbperm == 'allowsearch'}-->
    <!--{if $maingroup['allowsearch'] == '0'}-->{lang permission_basic_disable_sarch}<!--{elseif $maingroup['allowsearch'] == '1'}-->{lang permission_basic_search_title}<!--{else}-->{lang permission_basic_search_content}<!--{/if}-->
    <!--{else}-->
    <!--{if $maingroup[$groupbperm] >= 1}-->
    <i class="wqiconfont2 wqicon2-yes c_green i_middle wqapp_f24"></i>
    <!--{else}-->
    <i class="wqiconfont2 wqicon2-guanbi rq wqapp_f18"></i><!--{/if}-->
    <!--{/if}-->
</td>
</tr>
<!--{/loop}-->
<!--{loop $pperms $key $grouppperm}-->
<tr class="wqnew_bottom">
    <th class="wqnew_right">$permlang['perms_'.$grouppperm]</th>
    <td>
        <!--{if in_array($grouppperm, array('maxsigsize', 'maxbiosize'))}-->
        $maingroup[$grouppperm] {lang bytes}
        <!--{elseif $grouppperm == 'allowrecommend'}-->
        <!--{if $maingroup[allowrecommend] > 0}-->+$maingroup[allowrecommend]<!--{else}--><i class="wqiconfont2 wqicon2-guanbi rq i_middle wqapp_f20"></i><!--{/if}-->
        <!--{elseif in_array($grouppperm, array('allowat', 'allowcreatecollection'))}-->
        <!--{echo intval($maingroup[$grouppperm])}-->
        <!--{else}-->
        <!--{if $maingroup[$grouppperm] == 1 || (in_array($grouppperm, array('raterange', 'allowcommentpost')) && !empty($maingroup[$grouppperm]))}--><i class="wqiconfont2 wqicon2-yes c_green i_middle wqapp_f24"></i><!--{else}--><i class="wqiconfont2 wqicon2-guanbi rq i_middle wqapp_f20"></i><!--{/if}-->
        <!--{/if}-->
    </td>
</tr>
<!--{/loop}-->
<!--{loop $sperms $key $perm}-->
<tr class="wqnew_bottom">
    <th class="wqnew_right">$permlang['perms_'.$perm]</th>

    <td>
        <!--{if in_array($perm, array('maxspacesize', 'maximagesize'))}-->
        <!--{if $maingroup[$perm]}-->$maingroup[$perm]<!--{else}-->{lang permission_attachment_nopermission}<!--{/if}-->
        <!--{else}-->
        <!--{if $maingroup[$perm] == 1}--><i class="wqiconfont2 wqicon2-yes c_green i_middle wqapp_f24"></i><!--{else}--><i class="wqiconfont2 wqicon2-guanbi rq i_middle wqapp_f20"></i><!--{/if}-->
        <!--{/if}-->
    </td>
</tr>
<!--{/loop}-->
<!--{loop $aperms $key $groupaperm}-->
<tr class="wqnew_bottom">
    <th class="wqnew_right">$permlang['perms_'.$groupaperm]</th>
    <td>
        <!--{if in_array($groupaperm, array('maxattachsize', 'maxsizeperday', 'maxattachnum'))}-->
        <!--{if $maingroup[$groupaperm]}-->$maingroup[$groupaperm]<!--{else}-->{lang permission_attachment_nopermission}<!--{/if}-->
        <!--{elseif $groupaperm == 'attachextensions'}-->
        <!--{if $maingroup[allowpostattach] == 1}--><!--{if $maingroup[attachextensions]}--><p class="nwp" title="$maingroup[attachextensions]">$maingroup[attachextensions]</p><!--{else}-->{lang permission_attachment_nopermission}<!--{/if}--><!--{else}--><i class="wqiconfont2 wqicon2-guanbi rq i_middle wqapp_f20"></i><!--{/if}-->
        <!--{else}-->
        <!--{if $maingroup[$groupaperm] == 1}--><i class="wqiconfont2 wqicon2-yes c_green i_middle wqapp_f24"></i><!--{else}--><i class="wqiconfont2 wqicon2-guanbi rq i_middle wqapp_f20"></i><!--{/if}-->
        <!--{/if}-->
    </td>
</tr>
<!--{/loop}-->
<!--{eval
}
}-->
<!--{template common/header}-->
<!--{eval loadcache('wq_usergroup');$wq_app_usergroup=$_G['cache']['wq_usergroup']?$_G['cache']['wq_usergroup']:wq_usergroup();}-->
<!--{if !in_array($do, array('buy','switch','forum', 'exit'))}-->
    <!--{eval $wq_usergroup_showMenu=wq_usergroup_showMenu();;}-->
    <!--{eval $groupid = intval($_GET['groupid']);}-->

    <!--{block headconnect}-->
        <!--{if !$_GET['groupid']}-->
            <div class="wqgroupfans_list wquser_listmenu wqnew_bottom">
                <ul>
                    <li>
                        <a href="javascript:;" id="wq_level_showmens" <!--{if $do=='usergroup'&& $_G[wq_gid]}--> class="on"<!--{/if}-->>{$Tlang['d8c79993411048d5']}
                           <i class="wqiconfont2 wqicon2-down_1"></i>
                        </a>
                    </li>
                    <li>
                        <a href="home.php?mod=spacecp&ac=usergroup" {if $do=='usergroup'&& !$_G[wq_gid]}class="on"{/if}>{$Tlang['ca286fd27b769665']}</a>
                    </li>
                    <li>
                        <a href="home.php?mod=spacecp&ac=usergroup&do=list" {if $do == 'expiry' || $do == 'list'}class="on"{/if}>{$Tlang['e6bc045ab2e93181']}</a>
                    </li>
                </ul>
            </div>
        <!--{/if}-->
        <div id="wq_userlevel_list" style="position: absolute; top: 88px; width:100%;bottom:0px;left: 0; background-color:rgba(0,0,0,0.6); z-index: 10;display: none;" >
            <div class="wqpage_user">
                <div class="user_left">
                    <div class="group_scroll">
                        <ul class="user_list">
                            <li {if $wq_usergroup_showMenu[current]=='upgrade'}class="active"{/if} data='wq_gupgrade'>{lang usergroup_group2}<i class="y wqiconfont2 wqicon2-jiantou wqapp_f12"></i></li>
                            <li {if $wq_usergroup_showMenu[current]=='user'}class="active"{/if} data='wq_guser'>{lang usergroup_group1}<i class="y wqiconfont2 wqicon2-jiantou wqapp_f12"></i></li>
                            <li {if $wq_usergroup_showMenu[current]=='admin'}class="active"{/if} data='wq_gadmin'>{lang usergroup_group3}<i class="y wqiconfont2 wqicon2-jiantou wqapp_f12"></i></li>
                            <li {if $wq_usergroup_showMenu[current]=='my'}class="active"{/if} data='wq_gmy'>{lang my_usergroups}<i class="y wqiconfont2 wqicon2-jiantou wqapp_f12"></i></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div id="user_group_levels" class="user_right" style="background: #fff; position: absolute; display: block;top: 0px;left: 139px;right: 0; height:291px; box-sizing: border-box; overflow: hidden;">
                <div id="wq_user_group_ul">
                    <!--<div class="group_content">&nbsp;</div>-->
                    <ul class="user_rightlist" id="wq_gmy" style="display: none">
                        $wq_usergroup_showMenu[my]
                    </ul>
                    <ul class="user_rightlist" id="wq_gupgrade" style="display: none">
                        $wq_usergroup_showMenu[upgrade]
                    </ul>
                    <ul class="user_rightlist" id="wq_guser" style="display: none">
                        $wq_usergroup_showMenu[user]
                    </ul>
                    <ul class="user_rightlist" id="wq_gadmin" style="display: none">
                        $wq_usergroup_showMenu[admin]
                    </ul>
                </div>
            </div>
        </div>
        <div class="levelMask" onclick="$('#wq_level_showmens').click()" style="display: none;"></div>
    <!--{/block}-->

    <!--{if !$_GET['groupid']}-->
        <!--{eval $headparams['cname']=$Tlang['c082ba66d466d3e5'];$headparams['nstyle']='height: 88px';}-->
    <!--{else}-->
        <!--{eval $headparams['cname']=$expirylist[$groupid]['grouptitle'];$headparams['nstyle']='';}-->
    <!--{/if}-->

    <!--{eval
        $headparams['wtype'] = '3';
        $headparams['ltype'] = 'a';
        $headparams['lurl'] = $backurl;

        echo wq_app_get_header($headparams, true, false, $headconnect) ;
    }-->

    <div class="mask-hide" onclick="$('#wq_level_showmens').click()" style="display: none;"></div>

    <script>
        $(function () {
            var myscroll = false;
            $('#wq_level_showmens').click(function () {
                $(this).children().toggleClass('wqicon2-appup_1');
                $('.levelMask').css({height: ($(document).height() - $('.wqheader_lump').position().top - 88) + 'px'});
                $('.mask-hide').toggle();
                $('#wq_userlevel_list, .levelMask').toggle('800');

                var id = $('#wq_userlevel_list .user_list .active').attr('data');
                $('#' + id).show().siblings().hide();
                if (!myscroll) {
                    myscroll = new IScroll("#user_group_levels", {
                        click: true,
                        bounce: true
                    });
                }
            });

            $('.levelMask, .wqheader_lump, .wqpage_user, .mask-hide').on('touchmove', function (event) {
                event.preventDefault();
            });
            $('#wq_userlevel_list .user_list li').click(function () {
                var id = $(this).attr('data');
                $(this).addClass('active').siblings().removeClass('active');
                $('.user_rightlist').hide();
                $('#' + id).show();

                myscroll.refresh();
            });
        });
    </script>
<!--{/if}-->

<!--{if in_array($do, array('buy'))}-->
    <form id="buygroupform_{$groupid}" name="buygroupform_{$groupid}" method="post" autocomplete="off" action="home.php?mod=spacecp&ac=usergroup&do=$do&groupid=$groupid">
           <input type="hidden" name="referer" value="{echo dreferer()}" />
           <input type="hidden" name="buysubmit" value="true" />
           <input type="hidden" name="gid" value="$_GET[gid]" />
           <input type="hidden" name="handlekey" value="group_buys"/>
           <input type="hidden" name="formhash" value="{FORMHASH}"/>

            <!--{eval
                $headparams['wtype'] = '2';

                $headparams['ltype'] = 'cancel';
                $headparams['lname'] = $Tlang['9c825be7149e5b97'];
                $headparams['lurl'] = 'javascript:void(0);';

                $headparams['ctype'] = 'span';
                $headparams['cname'] =$group[grouptitle];

                $headparams['rtype'] = 'but';
                $headparams['rname'] = "{lang submit}";
                $headparams['rclass'] = 'formdialog';
                $headparams['rid'] = 'editsubmit_btn';
                $headparams['butname'] = 'editsubmit_btn';

                echo wq_app_get_header($headparams, false, true) ;
            }-->




           <div class="wquser_group">
               <ul>
                   <!--{if $join}-->
                   <!--{if $group['dailyprice']}-->
                   <li class="wqnew_bottom">
                      {$Tlang['dab5ed4de94a4732']}
                       <span class="rq wquser_info"> $group[dailyprice] {$_G[setting][extcredits][$_G[setting][creditstrans]][unit]}{$_G[setting][extcredits][$_G[setting][creditstrans]][title]}</span>
                   </li>
                   <li class="wqnew_bottom">
                     {$Tlang['7786238a7f659a74']}<span class="wquser_info">$usermaxdays {lang days}</span>
                   </li>
                   <li class="wqnew_bottom">
                      {lang memcp_usergroups_span}
                      <span class="wquser_info">
                          <span class="wqinput"><input type="text" size="2" name="days" value="$group[minspan]"onkeyup="change_credits_need(this.value)"  style=" width:50px; text-indent: 0.4em; line-height: 26px;"/> </span>{lang days}
                      </span>
                   </li>
                   <li class="wqnew_bottom">
                     {lang credits_need}{$_G[setting][extcredits][$_G[setting][creditstrans]][title]}
                       <span class="wquser_info">
                           <font class="rq"><span id="credits_need"></span> {$_G[setting][extcredits][$_G[setting][creditstrans]][unit]} </font>
                       </span>
                   </li>
                   <script>
                       var dailyprice = $group[dailyprice];
                       function change_credits_need(daynum) {
                           if (!isNaN(parseInt(daynum))) {
                               $('#credits_need').text(parseInt(daynum) * dailyprice);
                           } else {
                               $('#credits_need').text();
                           }
                       }
                       change_credits_need($group[minspan]);
                   </script>
                   <p class="wqexplain">
                      {lang memcp_usergroups_explain}:
                           <!--{if $join}-->
                           {lang memcp_usergroups_join_comment}
                           <!--{else}-->
                           {lang memcp_usergroups_exit_comment}
                           <!--{/if}-->
                   </p>
                   <!--{else}-->
                   <p class="wqexplain">
                       {lang memcp_usergroups_explain}: {lang memcp_usergroups_free_comment}
                   </p>
                   <!--{/if}-->
                   <!--{/if}-->
               </ul>
           </div>
           <div class="wqoperation">
             <button type="submit" name="editsubmit_btn" id="editsubmit_btn" value="true" class="formdialog">{lang submit}</button>
       </div>
    </form>
<!--{elseif $do == 'exit'}-->
    <div class="wqshield_notice">
        <form id="buygroupform_{$groupid}" name="buygroupform_{$groupid}" method="post" autocomplete="off" action="home.php?mod=spacecp&ac=usergroup&do=$do&groupid=$groupid">
            <input type="hidden" name="referer" value="{echo dreferer()}" />
            <input type="hidden" name="buysubmit" value="true" />
            <input type="hidden" name="gid" value="$_GET[gid]" />
            <input type="hidden" name="handlekey" value="group_buys"/>
            <input type="hidden" name="formhash" value="{FORMHASH}"/>
            <div class="wqshield_con">
                          <p>{lang memcp_usergroups_explain}:
                            <!--{if $group[type] != 'special' || $group[system]=='private'}-->
                            {lang memcp_usergroups_admin_exit_comment}
                            <!--{elseif $group['dailyprice']}-->
                            {lang memcp_usergroups_exit_comment}
                            <!--{else}-->
                            {lang memcp_usergroups_open_exit_comment}
                            <!--{/if}-->
                            </p>
                    </div>
            <p class="wqbtn_can wqnew_top">
                <a href="javascript:;" onclick="popup.close();" class="wqeject_cancel wqnew_right">{$Tlang['9c825be7149e5b97']}</a>
                <button type="submit" name="editsubmit_btn" id="editsubmit_btn" value="true" class="formdialog wqdetermine">{lang submit}</button>
            </p>
        </form>
    </div>
<!--{elseif $do == 'switch'}-->
    <div class="wqshield_notice">
        <form id="switchgroupform_{$groupid}" name="switchgroupform_{$groupid}" method="post" autocomplete="off" action="home.php?mod=spacecp&ac=usergroup&do=switch&groupid=$groupid">
            <input type="hidden" name="referer" value="{echo dreferer()}" />
            <input type="hidden" name="groupsubmit" value="true" />
            <input type="hidden" name="gid" value="$_GET[gid]" />
            <!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
            <input type="hidden" name="formhash" value="{FORMHASH}" />
            <div class="wqshield_con">
                <table class="wquser_tc" cellspacing="0" cellpadding="0" style="width:220px">
                    <tr>
                        <td>{lang memcp_usergroups_main_old}</td>
                        <td>  <span class="wqm_right5"><!--{echo  wq_usergroup_show($_G[groupid]);}--></span>$_G[group][grouptitle]</td>
                    </tr>
                    <tr>
                        <td>{lang memcp_usergroups_main_new}</td>
                        <td> <span class="wqm_right5"><!--{echo  wq_usergroup_show($group[groupid]);}--></span>$group[grouptitle]</td>
                    </tr>
                </table>
            </div>
            <p class="wqbtn_can wqnew_top">
                 <a href="javascript:;" onclick="popup.close();" class="wqeject_cancel wqnew_right">{$Tlang['9c825be7149e5b97']}</a>
                <button type="submit" name="editsubmit_btn" id="editsubmit_btn" value="true" class="formdialog wqdetermine">{lang submit}</button>
            </p>
        </form>
    </div>
<!--{elseif $do == 'forum'}-->
    <!--{eval
        $headparams['wtype'] = '1';
        $headparams['lurl'] = $backurl;
        $headparams['ltype'] = 'a';
        $headparams['cname'] = $Tlang['eb4903fb3307cc70'];
        echo wq_app_get_header($headparams);
    }-->
    <div class="wqforum_privilege_tit">
        <table cellpadding="0" cellspacing="0">
            <tbody>
                <tr>
                    <td>{lang forum_name}</td>
                </tr>
                <!--{eval $key = 1;}-->
                <!--{loop $_G['cache']['forums'] $fid $forum}-->
                    <!--{if $forum['status']}-->
                        <tr>

                            <td{if $forum['type'] == 'forum'} style="padding-left:20px"{elseif $forum['type'] == 'sub'} style="padding-left:30px"{/if}><a href="forum.php?mod=forumdisplay&fid=$forum[fid]">$forum[name]</a></td>
                        </tr>
                    <!--{/if}-->
                <!--{/loop}-->
            </tbody>
        </table>
    </div>
    <div class="wqforum_privilege_con slide-stop">
         <table cellpadding="0" cellspacing="0">
            <tbody>
                <tr>
                    <!--{loop $perms $perm}-->
                       <td>$permlang['perms_'.$perm]</td>
                     <!--{/loop}-->
                </tr>
               <!--{eval $key = 1;}-->
                <!--{loop $_G['cache']['forums'] $fid $forum}-->
                <!--{if $forum['status']}-->
                <tr>
                    <!--{loop $perms $perm}-->
                        <!--{if !empty($verifyperm[$fid][$perm])}-->
                            <!--{if $myverifyperm[$fid][$perm] || $forumperm[$fid][$perm]}-->
                                <td><i class="wqiconfont2 wqicon2-o3 wquser_green"></i></td>
                            <!--{else}-->
                                <td><i class="wqiconfont2 wqicon2-iconuser wquser_red"></i></td>
                            <!--{/if}-->
                                <td>&nbsp;$verifyperm[$fid][$perm]</td>
                        <!--{else}-->
                            <!--{if $forumperm[$fid][$perm]}-->
                                <td><i class="wqiconfont2 wqicon2-o3 wquser_green"></i></td>
                            <!--{else}-->
                                <td><i class="wqiconfont2 wqicon2-iconuser wquser_red"></i></td>
                            <!--{/if}-->
                        <!--{/if}-->
                    <!--{/loop}-->
                </tr>
                <!--{/if}-->
                <!--{/loop}-->
            </tbody>
        </table>
    </div>
    <div class="wqexpresso_peration">
        <i class="wqiconfont2 wqicon2-o3 wquser_green"></i> {lang usergroup_right_message1}&nbsp;
        <i class="wqiconfont2 wqicon2-iconuser wquser_red"></i> {lang usergroup_right_message2}&nbsp;
    </div>
    <div class="wqexpresso_authentication">
    <!--{if $_G['setting']['verify']['enabled']}-->
    <!--{echo implode('', $verifyicon)}--> {lang usergroup_right_message3}
    <!--{/if}-->
    </div>

<!--{elseif $do == 'expiry' || $do == 'list'}-->

    <!--{if $expirylist}-->
        <!--{if !$_GET['groupid']}-->
            <p class="tbmu wqcurrent_user wqnew_bottom">
                {lang yourusergroup}:  <!--{echo  wq_usergroup_show($_G[groupid]);}--> {$_G['cache']['usergroups'][$_G[groupid]]['grouptitle']}
            </p>
            <p class="wqcurrent_user wqnew_bottom">{lang youhave}
                <span class="xi1">
                    <strong class="rq">$usermoney {$_G[setting][extcredits][$_G[setting][creditstrans]][unit]}</strong>{$_G[setting][extcredits][$_G[setting][creditstrans]][title]}
                </span>
            </p>
            <!--{if $do == 'expiry'}-->
            <div class="notice wqcurrent_user wqnew_bottom">{$Tlang['f989fe19a606224c']}</div>
            <!--{/if}-->
            <div cellspacing="0" cellpadding="0" class="dt mbm wqcurrent_table ">
                <ul>
                    <!--{loop $expirylist $groupid $group}-->
                        <!--{if $group['maingroup'] == '1'}-->
                            <li class="wq_lh40 wquser_bottom wqnew_bottom"><a href="home.php?mod=spacecp&ac=usergroup&do=switch&groupid=$groupid&handlekey=switchgrouphk" class="wqblock dialog">{$Tlang['de762c42e41a7b16']}<span class="wquser_switch">{$Tlang['61a625c4426cfa00']}</span></a></li>
                        <!--{else}-->
                            <li class="wqnew_bottom {echo swapclass('alt')}">
                                <a href="home.php?mod=spacecp&ac=usergroup&do=list&groupid=$groupid" class="wqblock">
                                      <p>$group[grouptitle]</p>
                                      <p class="wqprice_day wqapp_f14">
                                          <span class="wqm_right10"><!--{if $_G['cache']['usergroups'][$groupid]['pubtype'] == 'buy' && $group[dailyprice]}-->
                                       $group[dailyprice]{$_G[setting][extcredits][$_G[setting][creditstrans]][title]}/{$Tlang['007bd5bdbc31a995']}<!--{elseif $_G['cache']['usergroups'][$groupid]['pubtype'] == 'free'}-->{lang free} <!--{else}--><!--{/if}-->
                                          </span>
                                          <!--{if $group[time]}--><!--{echo $group[time]=substr($group[time],2);}--><!--{else}--><!--{/if}-->
                                      </p>
                                      <span class="wquser_see y"><i class="wqiconfont2 wqicon2-jiantou wqapp_f18"></i></span>
                               </a>
                            </li>
                        <!--{/if}-->
                    <!--{/loop}-->
                </ul>
            </div>
        <!--{else}-->
            <div class="wqmould_user_group">
                <ul>
                    <li class="wquser_group wquser_bottom wqnew_bottom"><a href="home.php?mod=spacecp&ac=usergroup&gid=$groupid">{$Tlang['b8893118f05ccf60']}<span class="wquser_info"><i class="wqiconfont2 wqicon2-jiantou"></i></span></a></li>
                    <li class="wquser_group wquser_bottom wqnew_bottom"><a href="home.php?mod=spacecp&ac=usergroup&do=forum">{$Tlang['eb4903fb3307cc70']}<span class="wquser_info"><i class="wqiconfont2 wqicon2-jiantou"></i></span></a></li>
                    <li class="wquser_group wquser_bottom wqnew_bottom">{lang memcp_usergroups_dailyprice}<span class="wquser_info">
                            <!--{if $_G['cache']['usergroups'][$groupid]['pubtype'] == 'buy' && $group[dailyprice]}-->
                       $group[dailyprice]{$_G[setting][extcredits][$_G[setting][creditstrans]][title]}<!--{elseif $_G['cache']['usergroups'][$groupid]['pubtype'] == 'free'}-->{lang free} <!--{else}--><!--{/if}--></span></li>
                    <li class="wquser_group wquser_bottom wqnew_bottom">{lang memcp_usergroups_credit}<span class="wquser_info"><!--{if $group[usermaxdays]}-->$group[usermaxdays] {lang days}<!--{/if}--></span></li>
                    <!--{if $group[time]}--><li class="wquser_group wquser_bottom wqnew_bottom">{lang group_expiry_time}<span class="wquser_info"><!--{echo $group[time]=substr($group[time],2);}--><!--{else}--></span></li><!--{/if}-->
                </ul>
            </div>
            <!--{block wq_usergroup_s}-->
                <ul>
                    <!--{eval $p=0;}-->
                    <!--{if in_array($groupid, $extgroupids) || $groupid == $_G['groupid']}-->
                    <!--{if $groupid != $_G['groupid']}-->
                    <!--{if !$group[noswitch]}-->
                    <!--{eval $p++;}--><li><a href="home.php?mod=spacecp&ac=usergroup&do=switch&groupid=$groupid&handlekey=switchgrouphk" class="dialog xi2 wqbg_red">{lang memcp_usergroups_set_main}</a></li>
                    <!--{/if}-->
                    <!--{if !$group['maingroup']}-->
                    <!--{if $_G['cache']['usergroups'][$groupid]['pubtype'] == 'buy'}-->
                    <!--{eval $p++;}--><li><a href="home.php?mod=spacecp&ac=usergroup&do=buy&groupid=$groupid&handlekey=buygrouphk" class="xi2 wq_renew" >{lang renew}</a></li>
                    <!--{/if}-->
                    <!--{eval $p++;}--><li><a href="home.php?mod=spacecp&ac=usergroup&do=exit&groupid=$groupid&handlekey=exitgrouphk" class="dialog xi2 wq_out" >{lang memcp_usergroups_exit}</a></li>
                    <!--{/if}-->
                    <!--{else}-->
                    <!--{if $_G['cache']['usergroups'][$groupid]['pubtype'] == 'buy'}-->
                    <!--{eval $p++;}--><li><a href="home.php?mod=spacecp&ac=usergroup&do=buy&groupid=$groupid&handlekey=buygrouphk" class="xi2 wq_renew" >{lang renew}</a></li>
                    <!--{/if}-->
                    <!--{/if}-->
                    <!--{elseif $_G['cache']['usergroups'][$groupid]['pubtype'] == 'free'}-->
                    <!--{eval $p++;}--><li><a href="home.php?mod=spacecp&ac=usergroup&do=buy&groupid=$groupid&handlekey=buygrouphk" class="xi2 wqbg_red" >{lang free_buy}</a></li>
                    <!--{elseif $_G['cache']['usergroups'][$groupid]['pubtype'] == 'buy'}-->
                    <!--{eval $p++;}--><li><a href="home.php?mod=spacecp&ac=usergroup&do=buy&groupid=$groupid&handlekey=buygrouphk" class="xi2 wqbg_red">{lang memcp_usergroups_buy}</a></li>
                    <!--{/if}-->
                </ul>
            <!--{/block}-->
            <!--{if $p>0}-->
                <div class="wqoperation_tz usergroup_$p">
                         $wq_usergroup_s
                </div>
            <!--{/if}-->
        <!--{/if}-->
    <!--{else}-->
        <p class="wqemp" style="margin-top:85px;">{lang memcp_usergroup_unallow}</p>
    <!--{/if}-->

<!--{else}-->
    <div class="wqtdats">
        <div class="tscr">
            <!--{if !$_G[wq_gid] ||!$group}-->
            <table cellpadding="0" cellspacing="0" class="tda">
                <tr class="wqnew_bottom">
                    <th class="wqnew_right">{$Tlang['7630047f7af0d1c4']}</th>
                    <td> $maingroup[grouptitle] </td>
                </tr>
                <tr class="wqnew_bottom">
                    <th class="wqnew_right">{lang credits}</th>
                    <td> $space[credits]</td>
                </tr>
                <!--{echo permtbody($maingroup)}-->
            </table>
            <!--{else}-->
            <!--{if $switchtype == 'user'}--><!--{eval $cid = 1;$tlang = '{lang usergroup_group1}';}--><!--{/if}-->
            <!--{if $switchtype == 'upgrade'}--><!--{eval $cid = 2;$tlang = '{lang usergroup_group2}';}--><!--{/if}-->
            <!--{if $switchtype == 'admin'}--><!--{eval $cid = 3;$tlang = '{lang usergroup_group3}';}--><!--{/if}-->
            <table cellpadding="0" cellspacing="0" class="tdat">
                <tr id="tba" class="wqnew_bottom tb c$cid">
                    <th class="wqnew_right">$tlang</th>
                    <td id="c$cid"> $currentgrouptitle </td>
                </tr>
                <!--{if $group['grouptype'] == 'member'}--><tr>
                    <!--{eval $v = $group[groupcreditshigher] - $_G['member']['credits'];}-->
                    <!--{if $_G['group']['grouptype'] == 'member' && $v > 0}-->
                    <th class="wqnew_right">{$Tlang['dd6bd30b1c3c046d']} $currentgrouptitle </th>
                    <td class="alt h">{$Tlang['6f288f578270a7a6']}{$v}{$Tlang['a86acd545cc0a2fd']}</td>
                    <!--{else}-->
                    <th  class="wqnew_right">{lang spacecp_usergroup_message2}</th>
                    <td class="alt h">$group[groupcreditshigher]</td>
                    <!--{/if}--></tr>
                <!--{/if}-->
                <!--{if array_key_exists($group['groupid'], $groupterms['ext'])}-->
                <tr class="wqnew_bottom">   <th class="wqnew_right">{lang memcp_usergroups_timelimit}</th>
                    <td><!--{date($groupterms[ext][$group['groupid']])}--></td>	 </tr>
                <!--{/if}-->
                <!--{echo permtbody($group)}-->
            </table>
            <!--{block wq_usergroup_a}-->
            <!--{eval $p=0;}-->
            <ul>
                <!--{if isset($publicgroup[$group['groupid']]) && $group['groupid'] != $_G['groupid'] && $publicgroup[$group['groupid']]['allowsetmain']}-->
                <!--{eval $p++;}--><li><a href="home.php?mod=spacecp&ac=usergroup&do=switch&groupid=$group['groupid']&gid=$_GET[gid]&handlekey=switchgrouphk" class="dialog">{lang memcp_usergroups_set_main}</a></li>
                <!--{/if}-->
                <!--{if in_array($group['groupid'], $extgroupids) && $switchmaingroup && $group['grouptype'] == 'special' && $group['groupid'] != $_G['groupid']}-->
                <!--{if $_G['cache']['usergroups'][$group['groupid']]['pubtype'] == 'buy'}-->
                <!--{eval $p++;}--><li><a href="home.php?mod=spacecp&ac=usergroup&do=buy&groupid=$group['groupid']&gid=$_GET[gid]&handlekey=buygrouphk" class="dialog" >{lang renew}</a></li>
                <!--{/if}-->
                <!--{eval $p++;}--><li><a href="home.php?mod=spacecp&ac=usergroup&do=exit&groupid=$group['groupid']&gid=$_GET[gid]&handlekey=exitgrouphk" class="dialog" >{lang memcp_usergroups_exit}</a></li>
                <!--{/if}-->
                <!--{if $group['grouptype']=='special' && $group['groupid'] != $_G['groupid'] && array_key_exists($group['groupid'], $publicgroup) && !$publicgroup[$group['groupid']]['allowsetmain']}-->
                <!--{eval $p++;}--><li><a href="home.php?mod=spacecp&ac=usergroup&do=buy&groupid=$group['groupid']&gid=$_GET[gid]&handlekey=buygrouphk" class="dialog" >{lang memcp_usergroups_buy}</a></li>
                <!--{/if}-->
            </ul>
            <!--{/block}-->
            <!--{if $p>0}-->
            <div class="bg_button usergroup_$p">$wq_usergroup_a</div>
            <!--{/if}-->
            <!--{/if}-->
        </div>
    </div>
<!--{/if}-->
<!--{eval $nofooter=1;}-->
<!--{template common/footer}-->




<!--{/if}-->