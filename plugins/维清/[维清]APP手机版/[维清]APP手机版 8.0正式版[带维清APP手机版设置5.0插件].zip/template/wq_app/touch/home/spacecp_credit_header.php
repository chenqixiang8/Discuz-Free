<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['spacecp_credit_header'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<div class="my_post_roll wqnew_bottom slide-stop" id="my_credit_roll">
      <div class="tag_list">
            <ul class="tb cl">
                    <li {$opactives[base]}{$opactives[buy]} ><a href="home.php?mod=spacecp&ac=credit&op=base">{lang my_credits}</a></li>
                    <!--{if $_G[setting][ec_ratio] && ($_G[setting][ec_account] || $_G[setting][ec_tenpay_opentrans_chnid] || $_G[setting][ec_tenpay_bargainor]) || $_G['setting']['card']['open']}-->
                    <!--<li $opactives[buy]><a href="home.php?mod=spacecp&ac=credit&op=buy">{lang buy_credits}</a></li>-->
                    <!--{/if}-->
                    <!--{if $_G[setting][transferstatus] && $_G['group']['allowtransfer']}-->
                    <li $opactives[transfer]><a href="home.php?mod=spacecp&ac=credit&op=transfer">{lang transfer_credits}</a></li>
                    <!--{/if}-->
                    <!--{if $_G[setting][exchangestatus]}-->
                    <li $opactives[exchange]><a href="home.php?mod=spacecp&ac=credit&op=exchange">{lang exchange_credits}</a></li>
                    <!--{/if}-->
                    <li $opactives[log]><a href="home.php?mod=spacecp&ac=credit&op=log">{lang memcp_credits_log}</a></li>
                    <li $opactives[rule]><a href="home.php?mod=spacecp&ac=credit&op=rule">{lang credit_rule}</a></li>
                    <!--{if !empty($_G['setting']['plugins']['spacecp_credit'])}-->
                            <!--{loop $_G['setting']['plugins']['spacecp_credit'] $id $module}-->
                                    <!--{if !$module['adminid'] || ($module['adminid'] && $_G['adminid'] > 0 && $module['adminid'] >= $_G['adminid'])}--><li{if $_GET[id] == $id} class="a"{/if}><a href="home.php?mod=spacecp&ac=plugin&op=credit&id=$id">$module[name]</a></li><!--{/if}-->
                            <!--{/loop}-->
                    <!--{/if}-->
            </ul>
          </div>
    </div>
 <!--{eval $my_roll_tag='my_credit_roll';}-->
    <!--{template common/slide}-->
<!--{/if}-->