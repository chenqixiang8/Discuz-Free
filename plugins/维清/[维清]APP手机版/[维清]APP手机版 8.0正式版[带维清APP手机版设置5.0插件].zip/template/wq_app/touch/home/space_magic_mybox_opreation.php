<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['space_magic_mybox_opreation'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{template common/header}-->
    <!--{if $operation == 'give'}-->
        <!--{eval $headparams['cname'] =lang('home/template','magics_operation_present').'"'.$magic[name].'"';}-->
    <!--{elseif $operation == 'drop'}-->
        <!--{eval $headparams['cname'] =lang('home/template','magics_operation_present').lang('home/template','magic');}-->
    <!--{elseif $operation == 'sell'}-->
        <!--{eval $headparams['cname'] =lang('home/template','magics_operation_sell').lang('home/template','magic');}-->
    <!--{elseif $operation == 'use'}-->
        <!--{eval $headparams['cname'] =lang('home/template','magics_operation_use').lang('home/template','magic');}-->
    <!--{/if}-->

    <!--{eval
        $headparams['wtype'] = '2';
        $headparams['ltype'] = 'a';
        $headparams['lclass'] = 'wqcancel';
        $headparams['lurl'] = 'javascript:void(0);';

	$headparams['ctype'] = 'span';
        echo wq_app_get_header($headparams, false) ;
    }-->


<form id="magicform" method="post" action="home.php?mod=magic&action=mybox&infloat=yes" onsubmit="ajaxpost('magicform', 'return_$_GET[handlekey]', 'return_$_GET[handlekey]', 'onerror');return false;">
<div class="f_c">
	<div class="c" id="hkey_$_GET[handlekey]">
		<div id="return_$_GET[handlekey]"></div>
			<input type="hidden" name="formhash" value="{FORMHASH}" />
			<input type="hidden" name="handlekey" value="$_GET[handlekey]" />
			<input type="hidden" name="operation" value="$operation" />
			<input type="hidden" name="magicid" value="$magicid" />
			<!--{if $operation == 'give'}-->
                        <div class="wqmagic_give">
                            <ul>
					<!--{if $_G['group']['allowmagics'] > 1 }-->
					<li>
						<span class="wq_title">{lang magics_target_present}</span>
                                                <div class="wq_input" style="width: 80%; display: inline-block;">
							<input type="text" id="selectedusername" name="tousername" size="12" autocomplete="off" value="" class="px p_fre" style="margin-right: 0;" />
                                                        </div>
							<!--{if $buddyarray}-->
							<!--<a href="javascript:;" class="dpbtn" onclick="showselect(this, 'selectedusername', 'selectusername')">&nabla;</a>-->
							 <span class="wqmagic_kuang">
                                        <i class="wqiconfont2 wqicon2-youjiantou-copy"></i>
                                                        <select id="selectusername" class="wqmagic_ratecon">
								<!--{loop $buddyarray $buddy}-->
								<option>$buddy[fusername]</option>
								<!--{/loop}-->
							</select>
                                                         </span>
						<!--{/if}-->
					</li>
					<!--{/if}-->
					<li>
						<span class="wq_title">{lang magics_num}</span>
						 <div class="wq_input"><input name="magicnum" type="text" size="12" autocomplete="off" value="1" class="px p_fre" /></div>
					</li>
					<li>
						<span class="wq_title">{lang magics_present_message}</span>
						 <div class="wq_textarea"><textarea name="givemessage" rows="3" class="pt">{lang magics_present_message_text}</textarea></div>
					</li>
                                        </ul>
				</div>

				<input type="hidden" name="operatesubmit" value="yes" />
			<!--{elseif $operation == 'use'}-->
				<!--{if $magiclist}-->
				<p class="mtw mbw">
					<select name="magicid" onchange="showWindow('magics', 'home.php?mod=magic&action=mybox&operation=use&&infloat=yes&type=$typeid&pid=$pid&typeid=$typeid&magicid='+this.options[this.selectedIndex].value)" class="chosemagic">
						<option value="0">{lang magics_select}</option>
						<!--{loop $magiclist $magics}-->
							<option value="$magics[magicid]" $magicselect[$magics[magicid]]>$magics[name] - $magics[description]</option>
						<!--{/loop}-->
					</select>
				</p>
				<!--{/if}-->
				<dl class="xld cl">
					<dd class="m"><img src="$magic[pic]" alt="$magic[name]"></dd>
					<dt class="z">
						$magic[name]
						<div class="pns xw0 cl">
							<!--{if method_exists($magicclass, 'show')}-->
								<!--{eval $magicclass->show();}-->
							<!--{/if}-->
							<!--{if $useperoid !== true}-->
								<p class="xi1"><!--{if $magic['useperoid'] == 1}-->{lang magics_outofperoid_1}<!--{elseif $magic['useperoid'] == 2}-->{lang magics_outofperoid_2}<!--{elseif $magic['useperoid'] == 3}-->{lang magics_outofperoid_3}<!--{elseif $magic['useperoid'] == 4}-->{lang magics_outofperoid_4}<!--{/if}--><!--{if $useperoid > 0}-->{lang magics_outofperoid_value}<!--{else}-->{lang magics_outofperoid_noperm}<!--{/if}--></p>
							<!--{/if}-->
						</div>
					</dt>
				</dl>
				<input type="hidden" name="usesubmit" value="yes" />
				<input type="hidden" name="operation" value="use" />
				<input type="hidden" name="magicid" value="$magicid" />
				<!--{if !empty($_GET['idtype']) && !empty($_GET['id'])}-->
					<input type="hidden" name="idtype" value="$_GET[idtype]" />
					<input type="hidden" name="id" value="$_GET[id]" />
				<!--{/if}-->
			<!--{elseif $operation == 'sell'}-->
				<ul class="wq_magiv_list">
                                    <li class="wqnew_bottom">
					<div class="m wq_img"><img src="$magic[pic]" alt="$magic[name]"></div>
                                        <h3>{lang magics_operation_sell} <span class="wq_input"><input name="magicnum" type="text" size="2" value="1" /></span> {lang magics_unit}"$magic[name]"</h3>
					<p class="wqmagic_effect">
                                                {lang recycling_prices}:
                                                <!--{if {$_G['setting']['extcredits'][$magic[credit]][unit]}}-->
                                                        {$_G['setting']['extcredits'][$magic[credit]][title]} $discountprice {$_G['setting']['extcredits'][$magic[credit]][unit]}/{lang magics_unit}
                                                <!--{else}-->
                                                        $discountprice {$_G['setting']['extcredits'][$magic[credit]][title]}/{lang magics_unit}
                                                <!--{/if}-->
                                        </p>
                                    </li>
				</ul>
				<input type="hidden" name="operatesubmit" value="yes" />
			<!--{elseif $operation == 'drop'}-->
				<dl class="xld cl">
					<dd class="m"><img src="$magic[pic]" alt="$magic[name]"></dd>
					<dt class="z">
						<p class="mtm mbm">{lang magics_operation_drop} <input name="magicnum" type="text" size="2" autocomplete="off" value="1" class="px pxs" /> {lang magics_unit}"$magic[name]"</p>
						<p class="xw0">{lang magics_weight}: $magic[weight]</p>
					</dt>
				</dl>
				<input type="hidden" name="operatesubmit" value="yes" />
			<!--{/if}-->
			</div>
</div>

<!--{if empty($_GET['infloat'])}--><div class="m_c"><!--{/if}-->
<div class="wqmagic_button" id="hbtn_$_GET[handlekey]">
	<!--{if $operation == 'give'}-->
		<button class="button2 formdialog" type="submit" name="operatesubmit" id="operatesubmit" value="true" onclick="return confirmMagicOp(e)"><span>{lang magics_operation_present}</span></button>
	<!--{elseif $operation == 'use'}-->
		<button class="button2 formdialog" type="submit" name="usesubmit" id="usesubmit" value="true"><span>{lang magics_operation_use}</span></button>
	<!--{elseif $operation == 'sell'}-->
		<button class="button2 formdialog" type="submit" name="operatesubmit" id="operatesubmit" value="true" onclick="return confirmMagicOp(e)"><span>{lang magics_operation_sell}</span></button>
	<!--{elseif $operation == 'drop'}-->
		<button class="button2 formdialog" type="submit" name="operatesubmit" id="operatesubmit" value="true" onclick="return confirmMagicOp(e)"><span>{lang magics_operation_drop}</span></button>
	<!--{/if}-->
</div>
<!--{if empty($_GET['infloat'])}--></div><!--{/if}-->
</form>

<script type="text/javascript" reload="1">
	function confirmMagicOp(e) {
		e = e ? e : window.event;
		showDialog('{lang magics_confirm}', 'confirm', '', 'ajaxpost(\'magicform\', \'return_magics\', \'return_magics\', \'onerror\');');
		doane(e);
		return false;
	}
	function succeedhandle_$_GET[handlekey](url, msg) {
		hideWindow('$_GET[handlekey]');
		if(arguments[2] && arguments[2]['avatar']) {
			msg += ' <ul class="ml mls cl"><li><a class="avt" target="_blank" href="home.php?mod=space&amp;uid='+arguments[2]['uid']+'"><em class=""></em><img src="{$_G[setting][ucenterurl]}/avatar.php?uid='+arguments[2]['uid']+'&size=small" /></a><p><a title="admin" href="home.php?mod=space&amp;uid='+arguments[2]['uid']+'" target="_blank"><b>'+arguments[2]['username']+'</b></a></p></li></ul>';
		}
		<!--{if !$location}-->
			showDialog(msg, 'notice', null, function () { location.href=url; }, 0);
		<!--{else}-->
			showWindow('$_GET[handlekey]', 'home.php?$querystring');
		<!--{/if}-->
		showCreditPrompt();
	}
         $(function () {
                $('.wqmagic_ratecon').on('change', function () {
                    $('#selectedusername').val($('.wqmagic_ratecon').val())
                });
            });
</script>
<!--{eval $nofooter=1;}-->
<!--{template common/footer}-->
<!--{/if}-->