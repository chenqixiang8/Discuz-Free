<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['space_favorite'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{if empty($diymode)}-->
<!--{template common/header}-->
<!--{eval
    $headparams['wtype'] = '1';
    $headparams['lurl'] = $backurl;
    $headparams['ltype'] = 'a';
    $headparams['cname'] = $Tlang['e17c06793e315f8a'];
    echo wq_app_get_header($headparams);
}-->
<div class="my_post_roll wqnew_bottom slide-stop" id="my_favorite_roll">
    <div class="tag_list">
        <ul>
            <li$actives[all]><a href="home.php?mod=space&do=favorite&type=all">{lang favorite_all}</a></li>
            <li$actives[thread]><a href="home.php?mod=space&do=favorite&type=thread">{lang favorite_thread}</a></li>
            <li$actives[forum]><a href="home.php?mod=space&do=favorite&type=forum">{lang favorite_forum}</a></li>
            <!--{if helper_access::check_module('group')}--><li$actives[group]><a href="home.php?mod=space&do=favorite&type=group">{lang favorite_group}</a></li><!--{/if}-->
            <!--{if helper_access::check_module('blog')}--><li$actives[blog]><a href="home.php?mod=space&do=favorite&type=blog">{lang favorite_blog}</a></li><!--{/if}-->
            <!--{if helper_access::check_module('album')}--><li$actives[album]><a href="home.php?mod=space&do=favorite&type=album">{lang favorite_album}</a></li><!--{/if}-->
            <!--{if helper_access::check_module('portal')}--><li$actives[article]><a href="home.php?mod=space&do=favorite&type=article">{lang favorite_article}</a></li><!--{/if}-->
            <!--{hook/space_favorite_nav_extra}-->
        </ul>
    </div>
</div>
<!--{eval $my_roll_tag='my_favorite_roll';}-->
<!--{template common/slide}-->
<!--{else}-->
<!--{/if}-->
    <div class="wqindex_list">
        <!--{if $list}-->
        <form method="post" autocomplete="off" name="delform" id="delform" action="home.php?mod=spacecp&ac=favorite&op=delete&type=$_GET[type]&checkall=1" onsubmit="showDialog('{lang del_select_favorite_confirm}', 'confirm', '', '$(\'delform\').submit();'); return false;">
            <input type="hidden" name="formhash" value="{FORMHASH}" />
            <input type="hidden" name="delfavorite" value="true" />
              <!--{if $_GET['type'] == 'forum'|| $_GET['type'] == 'group'}-->
            <ul class="coll_list">
                <!--{loop $list $k $value}-->
		<li>
                    <a href="$value[url]" class="a">$value[title]</a>
                    <div class="wqcollection_delete wqtwo wqtop5"><a href="home.php?mod=spacecp&ac=favorite&op=delete&favid=$k&type=$_GET[type]" onclick="showWindow(this.id, this.href, 'get', 0);" class="wqblock wq_grey dialog"><i class="wqiconfont2 wqicon2-gbdelete wqapp_f20"></i></a></div>
                </li>
                <!--{/loop}-->
            </ul>
            <!--{else}-->
            <ul id="favorite_ul" class="wqindex_list_ul">
                <!--{loop $list $k $value}-->
                <li class="wqnew_bottom" id="fav_$k">
                    <a href="$value[url]" class="wqblock">
                        <div class="wqlist_maxhidden" style="margin-right: 30px;">
                            <h3 class="wqtitle_list">$value[title]</h3>
                        </div>
                    <!--{if $value[description]}-->
                    <div class="wq_grey wqcollection_reason"><blockquote id="quote_preview">$value[description]</blockquote></div>
                    <!--{/if}-->
                    <p class="list_info">
                        <span><!--{date($value[dateline], 'u')}--></span>
                    </p>
                      </a>
                    <div class="wqcollection_delete"><a href="home.php?mod=spacecp&ac=favorite&op=delete&favid=$k&type=$_GET[type]" onclick="showWindow(this.id, this.href, 'get', 0);" class="wqblock wq_grey dialog"><i class="wqiconfont2 wqicon2-gbdelete wqapp_f20"></i></a></div>
                </li>
                <!--{/loop}-->
            </ul>
        <!--{/if}-->
        </form>
        <!--{if $multi}--><div class="pgs cl mtm">$multi</div><!--{/if}-->
        <!--{else}-->
        <p class="wqemp"><span class="wqno_con"><img src="{$_G['style'][styleimgdir]}images/wqno_con.png"></span>{lang no_favorite_yet}</p>
        <!--{/if}-->
        <!--{if empty($diymode)}-->
    </div>
<!--{/if}-->
<script type="text/javascript">
    function favorite_delete(favid) {
        var el = $('fav_' + favid);
        if (el) {
            el.style.display = "none";
        }
    }
<!--{if $_GET[type] == "thread"}-->
    function collection_favorite() {
        var form = $('delform');
        var prefix = '^favorite';
        var tids = '';
        for (var i = 0; i < form.elements.length; i++) {
            var e = form.elements[i];
            if (e.name.match(prefix) && e.checked) {
                tids += 'tids[]=' + e.getAttribute('vid') + '&';
            }
        }
        if (tids) {
            showWindow(null, 'forum.php?mod=collection&action=edit&op=addthread&' + tids);
        }
    }
<!--{/if}-->
</script>

<!--{template common/footer}-->

<!--{/if}-->