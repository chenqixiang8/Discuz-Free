<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['spacecp_profile'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{template common/header}-->
    <!--{if $_GET['op'] == 'index'}-->

    <!--{eval
        $headparams['wtype'] = '1';
        $headparams['lurl'] = $backurl;
        $headparams['ltype'] = 'a';
        $headparams['cname'] = $Tlang['c1ae0e287c9cf97d'];
        echo wq_app_get_header($headparams);
    }-->
    <div class="wqpersonal_secrecy">
        <ul>
            <!--{if !empty($_G['cache']['plugin']['wq_space'])}-->
            <li>
                <a href="plugin.php?id=wq_space:wq_space">
                    <div class="wqpersonal_secrecy_right wqm_left0 wqnew_bottom">
                        <!--{if $_G['cache']['plugin']['wq_space'][pluginname]}-->$_G['cache']['plugin']['wq_space'][pluginname]<!--{else}-->{$Tlang['4b7544545b52fbb2']}<!--{/if}-->
                        <i class="wqiconfont2 wqicon2-jiantou y wq_arrow wqapp_f16"></i><span class="y wq_arrow wqm_right10"></span>
                    </div>
                </a>
            </li>
            <!--{/if}-->
            <!--{if !empty($_G['cache']['plugin']['wq_app_setting'])}-->
            <li>
                <a id="hobby_set" href="plugin.php?id=wq_app_setting">
                    <div class="wqpersonal_secrecy_right wqno_border wqm_left0">{$Tlang['0a919fcbaeb82da5']}<i class="wqiconfont2 wqicon2-jiantou y wq_arrow wqapp_f16"></i><span class="y wq_arrow wqm_right10"></span></div>
                </a>
            </li>
            <script>
                var scroll_Top
                $('body').on('click', '#hobby_set', function() {
                    var obj = $(this);
                    $.ajax({
                        type: 'POST',
                        url: obj.attr('href') + '&inajax=1',
                        data: {},
                        dataType: 'html'
                    }).success(function(s) {
                        $('#popup_content').attr("style", 'height:' + wq_window_height + 'px').html(wqXml(s));
                        $('#popup_title').text("{$Tlang['0a919fcbaeb82da5']}");
                        $('#popup_fullscreen').slideDown();
                        scroll_Top = $(window).scrollTop();
                        $('html,body').addClass("wq_ovhidden");
                    }).error(function() {
                        window.location.href = obj.attr('href');
                        popup.close();
                    });
                    return false;
                });

                $('body').on('click', '#popup_hidden', function() {
                    $('#popup_fullscreen').slideUp();
                    $('html,body').removeClass("wq_ovhidden");
                    $(window).scrollTop(scroll_Top);
                    return false;
                });
            </script>
            <!--{/if}-->
        </ul>
    </div>
    <div class="wqseparate"></div>
    <div class="wqpersonal_secrecy">
        <ul>
            <li id="head_button">
                <a href="javascript:;">
                    <div class="wqpersonal_secrecy_right wqm_left0 wqnew_bottom">{$Tlang['639bca6a6958faac']}<i class="wqiconfont2 wqicon2-jiantou y wq_arrow wqapp_f16"></i><span class="y wq_arrow wqm_right10"></span><img src="{avatar($space[uid], middle, true)}" class="wqsethead"/></div>
                </a>
           </li>
           <li>
                <a href="home.php?mod=spacecp&ac=profile">
                    <div class="wqpersonal_secrecy_right wqm_left0 wqnew_bottom">{$Tlang['82b2d92af03eb298']}<i class="wqiconfont2 wqicon2-jiantou y wq_arrow wqapp_f16"></i><span class="y wq_arrow wqm_right10"></span></div>
                </a>
           </li>
           <li>
                <a href="home.php?mod=spacecp&ac=credit">
                    <div class="wqpersonal_secrecy_right wqm_left0 wqnew_bottom">{$Tlang['a86acd545cc0a2fd']}<i class="wqiconfont2 wqicon2-jiantou y wq_arrow wqapp_f16"></i><span class="y wq_arrow wqm_right10"></span></div>
                </a>
           </li>
           <li>
                <a href="home.php?mod=spacecp&ac=usergroup">
                    <div class="wqpersonal_secrecy_right wqm_left0 wqnew_bottom">{$Tlang['c082ba66d466d3e5']}<i class="wqiconfont2 wqicon2-jiantou y wq_arrow wqapp_f16"></i><span class="y wq_arrow wqm_right10"></span></div>
                </a>
           </li>
           <li$actives[password]>
                <a data='password' href="home.php?mod=spacecp&ac=profile&op=password">
                    <div class="wqpersonal_secrecy_right wqm_left0">{lang password_security}<i class="wqiconfont2 wqicon2-jiantou y wq_arrow wqapp_f16"></i><span class="y wq_arrow wqm_right10"></span></div>
                </a>
           </li>
           <!--{if $_G['setting']['creditspolicy']['promotion_visit'] || $_G['setting']['creditspolicy']['promotion_register']}-->
           <li$actives[promotion]>
                <a href="home.php?mod=spacecp&ac=promotion">
                    <div class="wqpersonal_secrecy_right wqno_border wqm_left0">{lang memcp_promotion}<i class="wqiconfont2 wqicon2-jiantou y wq_arrow wqapp_f16"></i><span class="y wq_arrow wqm_right10"></span></span></div>
                </a>
           </li>
           <!--{/if}-->
        </ul>
    </div>
    <div class="wqseparate"></div>
    <div class="wqout_login">
        <a class="dialog" href="member.php?mod=logging&action=logout&referer=forum.php&formhash={FORMHASH}&handlekey=logout">{$Tlang['85a9775b96baa3b4']} </a>
    </div>
    <!--{else}-->

    <!--{if $operation == 'password'}-->
    <form class="newForm" action="home.php?mod=spacecp&ac=profile" method="post" autocomplete="off">
        <input type="hidden" value="{FORMHASH}" name="formhash" />

            <!--{eval
            $headparams['wtype'] = '2';

            $headparams['ltype'] = 'cancel';
            $headparams['lname'] = $Tlang['9c825be7149e5b97'];
            $headparams['lurl'] = 'javascript:void(0);';

            $headparams['ctype'] = 'span';
            $headparams['cname'] =$Tlang['6367fcf5abe5dd3b'];

            $headparams['rtype'] = 'but';
            $headparams['rname'] = $Tlang['b531d032f4f29f92'];
            $headparams['rclass'] = 'formdialog';
            $headparams['rid'] = 'favoritesubmit_btn';

            echo wq_app_get_header($headparams, false, true) ;
        }-->
    
        <div class="wqpersonal_data">
            <ul>
                <!--{if !$_G['setting']['connect']['allow'] || !$conisregister}-->
                <li class="wqnew_bottom">
                    <em><i class="rq" title="{lang required}">*</i>{lang old_password}</em>
                    <span class="text_left"><input type="password" name="oldpassword" id="oldpassword" /></span>
                </li>
                <!--{/if}-->
                <li class="wqnew_bottom">
                    <em>{lang new_password}</em>
                    <span class="text_left"><input type="password" name="newpassword" id="newpassword" /></span>
                </li>
                <li class="wqnew_bottom">
                    <em>{lang new_password_confirm}</em>
                    <span class="text_left">
                        <input type="password" name="newpassword2" id="newpassword2"/>
                    </span>
                </li>
                <li class="wqnew_bottom" id="contact"{if $_GET[from] == 'contact'} style="background-color: {$_G['style']['specialbg']};"{/if}>
                    <em>{lang email}</em>
                    <span class="text_left">
                        <input type="text" name="emailnew" id="emailnew" value="$space[email]" />
                        <p class="wqapp_f14" id="email_tishi">
                            <!--{if empty($space['newemail'])}-->
                                <img src="{IMGDIR}/mail_active.png" class="vm"/> <span class="xi1">{$Tlang['b6e9fcc7d0d01ea1']}</span>
                            <!--{else}-->
                                <img src="{$_G['style']['imgdir']}/mail_inactive.png" class="vm"/>
                                <font style="color:#F26C4F">({$space['newemail']}){$Tlang['9624fc07fdc21060']}</font>
                                <a href="home.php?mod=spacecp&ac=profile&op=password&resend=1&handlekey=resendemail" class="xi2 dialog" id="resendemail">
                                    {$Tlang['80ad2e5229e5b0a4']}
                                </a>
                            <!--{/if}-->
                        </p>
                    </span>
                </li>
                <!--{if $_G['member']['freeze'] == 2}-->
                    <li class="wqnew_bottom">
                        <em>{lang freeze_reason}</em>
                        <span class="text_left">
                            <textarea rows="3" cols="80" name="freezereson" >$space[freezereson]</textarea>
                            <p class="wqapp_f14" id="chk_newpassword2">{lang freeze_reason_comment}</p>
                        </span>
                    </li>
                <!--{/if}-->
                <li class="wqnew_bottom">
                    <em>{lang security_question}</em>
                    <span class="text_left">
                        <select name="questionidnew" id="questionidnew">
                            <option value="" selected>{lang memcp_profile_security_keep}</option>
                            <option value="0">{lang security_question_0}</option>
                            <option value="1">{lang security_question_1}</option>
                            <option value="2">{lang security_question_2}</option>
                            <option value="3">{lang security_question_3}</option>
                            <option value="4">{lang security_question_4}</option>
                            <option value="5">{lang security_question_5}</option>
                            <option value="6">{lang security_question_6}</option>
                            <option value="7">{lang security_question_7}</option>
                        </select>
                    </span>
                </li>
                <li class="wqnew_bottom" >
                    <em>{lang security_answer}</em>
                    <span class="text_left">
                        <input type="text" name="answernew" id="answernew" />
                    </span>
                </li>
                <!--{if $secqaacheck || $seccodecheck}-->
                    <style type="text/css">
                        .sec_code{ border-top: 0px !important;}
                    </style>
                     <li class="wqnew_bottom wq_grey">
                        <div class="wqcade_pass b_bottom">
                            <!--{subtemplate common/seccheck}-->
                        </div>
                    </li>
                <!--{/if}-->
            </ul>
            <input type="hidden" name="passwordsubmit" value="true">
        </div>
    </form>
    <!--{else}-->
        <!--{if $validate}-->
            <!--{eval
                $headparams['wtype'] = '1';
                $headparams['lurl'] = $backurl;
                $headparams['ltype'] = 'a';
                $headparams['cname'] = $Tlang['82b2d92af03eb298'];
                echo wq_app_get_header($headparams);
            }-->
            <form class="newForm" action="member.php?mod=regverify" method="post" autocomplete="off">
                <input type="hidden" value="{FORMHASH}" name="formhash" />
                <div class="wqpersonal_data">
                    <ul>
                        <li class="wqnew_bottom">
                            <span>{lang validator_comment}</span>
                        </li>
                        <li class="wqnew_bottom">
                            <em>{lang validator_remark}</em>
                            <span class="text_left">$validate[remark]</span>
                        </li>
                        <li class="wqnew_bottom">
                            <em>{lang validator_message}</em>
                            <span class="text_left">
                                <input type="text" name="regmessagenew">
                            </span>
                        </li>
                    </ul>
                </div>
                <div class="wqseparate"></div>
                <div class="wqout_login">
                    <button type="submit" name="verifysubmit" value="true" class="wqbg_color" style="color: #fff; height: 42px; width: 100%; color: #fff !important; border-radius: 5px; border: none;"/><strong>{lang validator_submit}</strong></button>
                </div>
            </form>
	<!--{else}-->
            <iframe id="frame_profile" name="frame_profile" style="display: none"></iframe>
            <form id="editform" action="{if $operation != 'plugin'}home.php?mod=spacecp&ac=profile&op=$operation{else}home.php?mod=spacecp&ac=plugin&op=profile&id=$_GET[id]{/if}" method="post" enctype="multipart/form-data" autocomplete="off"{if $operation != 'plugin'} target="frame_profile"{/if} ">
                <input type="hidden" value="{FORMHASH}" name="formhash" />
                <!--{if $_GET[vid]}-->
                <input type="hidden" value="$_GET[vid]" name="vid" />
                <!--{/if}-->

                            <!--{if $operation == 'verify'}-->
                    <!--{eval $headparams['cname']="&#x6211;&#x7684;&#x8BA4;&#x8BC1";}-->
                <!--{else}-->
                    <!--{eval $headparams['cname']=$Tlang['da5fe59d8951f9b2'];}-->
                <!--{/if}-->

                <!--{if $showbtn == 'verify'}-->
                    <!--{eval $headparams['rname']=$Tlang['b531d032f4f29f92']; $headright=true;$headparams['rextra']='onclick="popup.open(toast);"'}-->
                <!--{else}-->
                    <!--{eval $headright=false;}-->
                <!--{/if}-->
                <!--{eval
                    $headparams['wtype'] = '2';

                    $headparams['ltype'] = 'cancel';
                    $headparams['lname'] = "{lang cancel}";
                    $headparams['lurl'] = 'javascript:void(0);';

                    $headparams['ctype'] = 'span';

                    $headparams['rtype'] = 'but';
                    $headparams['rclass'] =  'profileformdialog';
                    $headparams['rid'] = 'favoritesubmit_btn';

                    echo wq_app_get_header($headparams, false, $headright) ;
                }-->
            

                <div class="my_post_roll wqnew_bottom slide-stop" id="my_data_roll">
                    <div class="tag_list">
                        <ul>
                            <!--{if $operation != 'verify'}-->
                                <!--{loop $profilegroup $key $value}-->
                                <!--{if $value[available]}-->
                                <li $opactives[$key]><a data='$key' href="home.php?mod=spacecp&ac=profile&op=$key&operation=1">$value[title]</a></li>
                                <!--{/if}-->
                                <!--{/loop}-->
                            <!--{else}-->
                                <!--{if $_G[setting][verify]}-->
                                    <!--{loop $_G['setting']['verify'] $vid $verify}-->
                                        <!--{if $verify['available'] && (empty($verify['groupid']) || in_array($_G['groupid'], $verify['groupid']))}-->
                                            <!--{if $vid != 7}-->
                                                <li <!--{if $vid == $_GET['vid']}-->class="a"<!--{/if}-->><a data='verify_{$vid}' href="home.php?mod=spacecp&ac=profile&op=verify&vid=$vid">$verify['title']</a></li>
                                            <!--{elseif $_G['setting']['my_app_status'] && $vid == 7}-->
                                                <li <!--{if $vid == $_GET['vid']}-->class="a"<!--{/if}-->><a data='verify_{$vid}' href="home.php?mod=spacecp&ac=videophoto">{lang video_certification}</a></li>
                                            <!--{/if}-->
                                        <!--{/if}-->
                                    <!--{/loop}-->
                                <!--{/if}-->
                            <!--{/if}-->
                        </ul>
                    </div>
                </div>
                <!--{eval $my_roll_tag='my_data_roll';}-->
                <!--{template common/slide}-->
                <!--{if $vid}-->
                    <style>
                    .wqshenhai{font-size: 14px;padding: 5px;border: 1px dashed #f60;margin: 10px 10px 0px 10px;}
                    </style>
                    <p class="wqshenhai profile_form" data="{$operation}" id="shenhai_{$operation}_{$_GET[vid]}">
                        <!--{if !$showbtn}-->
                            {lang spacecp_profile_message2}
                        <!--{else}-->
                            {lang spacecp_profile_message1}
                        <!--{/if}-->
                    </p>
                <!--{/if}-->
                <div class="wqpersonal_data">
                    <ul>
                        <!--{loop $settings $key $value}-->
                        <!--{if $value[available]}-->
                            <li class="wqnew_bottom" id="tr_$key">
                                <em id="th_$key"><!--{if $value[required]}--><i class="rq" title="{lang required}">*</i><!--{/if}-->$value[title]</em>
                                <span class="text_left" id="td_$key">
                                    {$htmls[$key]}
                                </span>
                            </li>
                        <!--{/if}-->
                        <!--{/loop}-->
                        <!--{if $_G['group']['maxsigsize'] && in_array('sightml', $allowitems)}-->
                            <li class="wqnew_bottom">
                                <em id="th_sightml">{lang personal_signature}</em>
                                <span class="text_left"><textarea rows="3" cols="80" name="sightml" id="sightmlmessage" class="pt">$space[sightml]</textarea></span>
                            </li>
                        <!--{/if}-->
                    </ul>
                </div>
                <!--{if $showbtn}-->
                <input type="hidden" name="profilesubmit" value="true"/>
                <!--{/if}-->
            </form>
            <script>
                if (document.getElementById('birthprovince')){
                    document.getElementById('birthprovince').onchange = null;
                }
                if (document.getElementById('resideprovince')){
                    document.getElementById('resideprovince').onchange = null;
                }
                $('body').on('change', '#birthprovince, #resideprovince', function () {
                    if (!$(this).val()) {
                        $(this).next('select').remove();
                    } else {
                        var upid = $(this).find('option:selected').attr('did');
                        var that = $(this);
                        var cityName = that.parent().parent().prop('id') == 'td_birthcity' ? 'birthcity' : 'residecity';
                        $.ajax({
                            url: 'plugin.php?id=wq_app_setting&mod=api&fun=district&level=2',
                            data: {upid: upid},
                            type: 'GET',
                            dataType: 'JSON',
                            success: function (res) {
                                var option = '';
                                for (var i in res.data) {
                                    option += '<option value="' + res.data[i].name + '">' + res.data[i].name + '</option>';
                                }
                                that.next('select').remove();
                                that.parent().append('<select name="' + cityName + '" class="ps"  tabindex="1"><option value="">-'+'{$Tlang[29405aa0c5f4c1b9]}'+'-</option>' + option + '</select>');
                            }
                        });
                    }
                });

                if (document.querySelector('#td_birthcity a')) {
                    document.querySelector('#td_birthcity a').onclick = null;
                }
                if (document.querySelector('#td_residecity a')) {
                    document.querySelector('#td_residecity a').onclick = null;
                }
                $('#td_birthcity a, #td_residecity a').on('click', function () {
                    var that = $(this);
                    var type = that.parent().prop('id') == 'td_birthcity' ? 'birth' : 'reside';
                    var id = that.parent().prop('id') == 'td_birthcity' ? 'birthprovince' : 'resideprovince';
                    var provinceName = that.parent().prop('id') == 'td_birthcity' ? 'birthprovince' : 'resideprovince';
                    var cityName = that.parent().prop('id') == 'td_birthcity' ? 'birthcity' : 'residecity';
                    $.ajax({
                        url: 'plugin.php?id=wq_app_setting&mod=api&fun=userinfo_district&type=' + type,
                        type: 'GET',
                        dataType: 'JSON',
                        success: function (res) {
                            $.ajax({
                                url: 'plugin.php?id=wq_app_setting&mod=api&fun=district&level=1',
                                type: 'GET',
                                dataType: 'JSON',
                                success: function (data1) {
                                    var html = '<select id="' + id + '" name="' + provinceName + '" class="ps" tabindex="1"><option value="">-'+'{$Tlang[0345e805f3daf1b3]}'+'-</option>';
                                    var upid = '';
                                    for (var i in data1.data) {
                                        if (res.data.idforlevel1 && res.data.idforlevel1 == data1.data[i].id) {
                                            html += '<option did="' + data1.data[i].id + '" value="' + data1.data[i].name + '" selected=true>' + data1.data[i].name + '</option>';
                                            upid = data1.data[i].id;
                                        } else {
                                            html += '<option did="' + data1.data[i].id + '" value="' + data1.data[i].name + '">' + data1.data[i].name + '</option>';
                                        }
                                    }
                                    html += '</select>&nbsp;&nbsp;<select name="' + cityName + '" class="ps" tabindex="1"><option value="">-'+'{$Tlang[9405aa0c5f4c1b9]}'+'-</option>';
                                    $.ajax({
                                        url: 'plugin.php?id=wq_app_setting&mod=api&fun=district&level=2',
                                        data: {upid: upid},
                                        type: 'GET',
                                        dataType: 'JSON',
                                        success: function (data2) {
                                            for (var j in data2.data) {
                                                if (res.data.idforlevel2 && res.data.idforlevel2 == data2.data[j].id) {
                                                    html += '<option value="' + data2.data[j].name + '" selected=true>' + data2.data[j].name + '</option>';
                                                } else {
                                                    html += '<option value="' + data2.data[j].name + '">' + data2.data[j].name + '</option>';
                                                }
                                            }
                                            html += '</select>';
                                            that.next().html(html);
                                        }
                                    });
                                }
                            });
                        }
                    });
                });
            </script>
            <!--{/if}-->
        <!--{/if}-->
    <!--{/if}-->

    <div id="uploading_fullscreen" class="ipagen slide-stop" style="display: none;position:absolute;bottom:0px;left:0px;z-index:12;">
        <div class="wq_lump_div">
            <div class="wq_lump_pro">
                <a href="javascript:;" onclick="$('#uploading_fullscreen').hide();$('html,body').removeClass('wq_ovhidden');" class="wq_return">&#x53D6;&#x6D88;</a>&#x88C1;&#x526A;
                <span class="return_in"><button type="button" id="clipBtn" class="pn pnc">&#x5B8C;&#x6210;</button></span>
            </div>
        </div>
        <div class="pcontent" id="uploading_content">
            <div class="resource_lazy hide"></div>
            <div class="pic_edit">
                <div id="clipArea"></div>
                <div class="qd_bg">
                    <button class="operate" id="positive_rotate"><i class="wqiconfont2 wqicon2-xiangyouxuanzhuanline"></i></button>
                    <button class="operate" id="inverse_rotate"><i class="wqiconfont2 wqicon2-xiangzuoxuanzhuanline"></i></button>
                    <button class="operate" id="reduction"><i class="wqiconfont2 wqicon2-zoomout"></i></button>
                    <button class="operate" id="magnification"><i class="wqiconfont2 wqicon2-zoomin"></i></button>
                </div>
                <input type="file" id="file" style="opacity: 0;position: fixed;bottom: -100px" accept="image/*">
            </div>
            <img src="" fileName="" id="hit" style="display:none;">
        </div>
    </div>
    <div id="edit_profile" class="ipagen" style="position:fixed; display: none;bottom: 0px; left: 0px;"></div>
    <script>
        JC.file('thirdparty/hammer.js');
        JC.file('thirdparty/iscroll-zoom.js');
        JC.file('thirdparty/jquery.photoClip.js');
        JC.run();

        $('#head_button').on('click',function(){
            $('#file').click();
        });
        var photoClip_height = photoClip_width = 150;
        var uploading_url = 'plugin.php?id=wq_app_setting';
        var photoClip = $("#clipArea").photoClip({
            width: photoClip_width,
            height: photoClip_height,
            file: "#file",
            view: "#hit",
            ok: "#clipBtn",
            loadStart: function () {
                $('.lazy_tip span').text('');
            },
            loadComplete: function () {
                $('#uploading_fullscreen').show();
                $('html,body').addClass("wq_ovhidden");
            },
            clipFinish: function (dataURL) {
                saveImageInfo(dataURL);
            }
        });
        function saveImageInfo(img_data) {
            $.post(uploading_url, {mod: 'ajax', ac: 'uploading', image: img_data, formhash: '{FORMHASH}'}, function (data) {
                if (data != '') {
                    uploading_return(img_data);
                }
            });
        }
        function uploading_return(img_data) {
            $('.wqsethead').attr('src', img_data);
            $('#uploading_fullscreen').hide();
            $('html,body').removeClass('wq_ovhidden');
        }
        function show_success(message) {
            message = message == '' ? '{lang update_date_success}' : message;
            popup.open(message, 'alert');
            setTimeout(function() {
                window.location.href = window.location.href;
            }, '1000');
        }

        function show_error(fieldid, extrainfo) {
            var fieldname = $('#th_' + fieldid).html();
            extrainfo = (typeof extrainfo == "string") ? extrainfo : "";
            message = fieldname + "{$Tlang['68610ed787ad3a9d']}" + extrainfo;
            popup.open(message, 'alert');
        }

        function showbirthday(){
            var el = $('#birthday');
            var birthday = el.val();
            var options = "<option values=\"\">&#x65E5;</option>";
            for(var i = 1; i < 29; i++){
                options +=  "<option values=\""+i+"\">"+i+"</option>";
            }
            el.html(options);
            if($('#birthmonth').val() != "2"){
                el.append("<option value='29'>29</option>")
                el.append("<option value='30'>30</option>")
                switch($('#birthmonth').val()){
                        case "1":
                        case "3":
                        case "5":
                        case "7":
                        case "8":
                        case "10":
                        case "12":{
                                el.append("<option value='31'>31</option>")
                        }
                }
            } else if($('#birthyear').val() != "") {
                var nbirthyear=$('#birthyear').val();
                if(nbirthyear%400==0 || (nbirthyear%4==0 && nbirthyear%100!=0)){
                    el.append("<option value='29'>29</option>")
                }
            }
            el.value = birthday;
        }

    </script>
    <!--{template common/footer}-->

<!--{/if}-->