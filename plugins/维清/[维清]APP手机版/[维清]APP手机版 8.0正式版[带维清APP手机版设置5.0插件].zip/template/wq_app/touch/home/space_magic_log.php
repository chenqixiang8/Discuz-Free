<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['space_magic_log'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<div class="wqmagic_menu wqnew_bottom">
    <ul class="mbm tb cl">
        <li $subactives[uselog]><a href="home.php?mod=magic&action=log&operation=uselog">{$Tlang['331395026a267212']}</a></li>
        <li $subactives[buylog]><a href="home.php?mod=magic&action=log&operation=buylog">{$Tlang['40320e870abf6f5a']}</a></li>
        <li $subactives[givelog]><a href="home.php?mod=magic&action=log&operation=givelog">{$Tlang['eeffd44d9c5cccd1']}</a></li>
        <li $subactives[receivelog]><a href="home.php?mod=magic&action=log&operation=receivelog">{$Tlang['c5187d24cbea92c5']}</a></li>
    </ul>
</div>
<!--{if $operation == 'uselog'}-->
	<!--{if $loglist}-->
		<table summary="{lang magics_log_use}" cellspacing="0" cellpadding="0" class="dt wqmagic_log">
			<tr>
				<th class="wqt_l">{lang magics_name}</th>
				<th width="20%">{lang magics_dateline_use}</th>
				<th width="20%">{lang magics_target_use}</th>
			</tr>
			<!--{loop $loglist $log}-->
			<tr>
				<td  class="wqt_l">$log[name]</td>
				<td>$log[dateline]</td>
				<td>
					<!--{if $log[idtype] == 'uid'}-->
						<a href="home.php?mod=space&uid=$log[targetid]" target="_blank">{lang magics_target}</a>
					<!--{elseif $log[idtype] == 'tid'}-->
						<a href="forum.php?mod=viewthread&tid=$log[targetid]" target="_blank">{lang magics_target}</a>
					<!--{elseif $log[idtype] == 'pid'}-->
						<a href="forum.php?mod=redirect&pid=$log[targetid]&goto=findpost" target="_blank">{lang magics_target}</a>
					<!--{elseif $log[idtype] == 'sell'}-->
						{lang magics_operation_sell}
					<!--{elseif $log[idtype] == 'drop'}-->
						{lang magics_operation_drop}
					<!--{/if}-->
				</td>
			</tr>
			<!--{/loop}-->
		</table>
		<!--{if $multipage}--><div class="pgs cl mtm">$multipage</div><!--{/if}-->
	<!--{else}-->
             <p class="wqemp"><span class="wqno_con"><img src="{$_G['style'][styleimgdir]}images/wqno_con.png"></span>{lang data_nonexistence}</p>
	<!--{/if}-->
<!--{elseif $operation == 'buylog'}-->
	<!--{if $loglist}-->
		<table summary="{lang magics_log_buy}" cellspacing="0" cellpadding="0" class="dt wqmagic_log">
			<tr>
				<th class="wqt_l">{lang magics_name}</th>
				<th width="30%">{lang magics_dateline_buy}</th>
				<th width="20%">{lang magics_amount_buy}</th>
				<th width="20%">{lang magics_price_buy}</th>
			</tr>
			<!--{loop $loglist $log}-->
				<tr>
					<td  class="wqt_l">$log[name]</td>
					<td>$log[dateline]</td>
					<td>$log[amount]</td>
					<td>$log[price] {$_G['setting']['extcredits'][$log[credit]][unit]}{$_G['setting']['extcredits'][$log[credit]][title]}</td>
				</tr>
			<!--{/loop}-->
		</table>
		<!--{if $multipage}--><div class="pgs cl mtm">$multipage</div><!--{/if}-->
	<!--{else}-->
         <p class="wqemp"><span class="wqno_con"><img src="{$_G['style'][styleimgdir]}images/wqno_con.png"></span>{lang data_nonexistence}</p>
	<!--{/if}-->
<!--{elseif $operation == 'givelog'}-->
	<!--{if $loglist}-->
		<table summary="{lang magics_log_present}" cellspacing="0" cellpadding="0" class="dt wqmagic_log">
			<tr>
				<th class="wqt_l">{lang magics_name}</td>
				<th width="30%">{lang magics_dateline_present}</th>
				<th width="20%">{lang magics_amount_present}</th>
				<th width="20%">{lang magics_target_present}</th>
			</tr>
			<!--{loop $loglist $log}-->
				<tr>
					<td class="wqt_l">$log[name]</td>
					<td>$log[dateline]</td>
					<td>$log[amount]</td>
					<td><a href="home.php?mod=space&uid=$log[targetuid]">$log[username]</a></td>
				</tr>
			<!--{/loop}-->
		</table>
		<!--{if $multipage}--><div class="pgs cl mtm">$multipage</div><!--{/if}-->
	<!--{else}-->
            <p class="wqemp"><span class="wqno_con"><img src="{$_G['style'][styleimgdir]}images/wqno_con.png"></span>{lang data_nonexistence}</p>
	<!--{/if}-->
<!--{elseif $operation == 'receivelog'}-->
	<!--{if $loglist}-->
		<table summary="{lang magics_log_receive}" cellspacing="0" cellpadding="0" class="dt wqmagic_log">
			<tr>
				<th class="wqt_l">{lang magics_name}</th>
				<th width="20%">{lang magics_dateline_receive}</th>
				<th width="20%">{lang magics_amount_receive}</th>
				<th width="20%">{lang magics_target_receive}</th>
			</tr>
			<!--{loop $loglist $log}-->
				<tr>
					<td class="wqt_l"><a href="home.php?mod=magic&action=index&operation=buy&magicid=$log[magicid]" target="_blank">$log[name]</a></td>
					<td>$log[dateline]</td>
					<td>$log[amount]</td>
					<td><a href="home.php?mod=space&uid=$log[uid]">$log[username]</a></td>
				</tr>
			<!--{/loop}-->
		</table>
		<!--{if $multipage}--><div class="pgs cl mtm">$multipage</div><!--{/if}-->
	<!--{else}-->
         <p class="wqemp"><span class="wqno_con"><img src="{$_G['style'][styleimgdir]}images/wqno_con.png"></span>{lang data_nonexistence}</p>
	<!--{/if}-->
<!--{/if}-->
<!--{/if}-->