<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['space_notice'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{template common/header}-->
<!--{eval //echo"<pre>"; print_r($page);exit;}-->
    <!--{if empty($_GET['view'])}-->
        <!--{eval
            $headparams['wtype'] = '1';
            $headparams['lurl'] = $backurl;
            $headparams['ltype'] = 'a';
            $headparams['cname'] = $Tlang['35ebc17f15aba47a'];
            echo wq_app_get_header($headparams);
        }-->
        <!--{template home/space_prompt_nav}-->
    <!--{else}-->
                <!--{eval
                $headparams['wtype'] = '1';
                $headparams['lurl'] = $backurl;
                $headparams['ltype'] = 'a';
                $headparams['cname'] = lang('template', 'notice_'.$view);
                echo wq_app_get_header($headparams);
            }-->
             <!--{if $_G['notice_structure'][$view] && ($view == 'mypost' || $view == 'interactive')}-->
            <div class="my_private_roll wqnew_bottom slide-stop" id="my_private_roll">
                <div class="tag_list">
                    <ul>
                        <!--{loop $_G['notice_structure'][$view] $subtype}-->
                        <li $readtag[$subtype]><a href="home.php?mod=space&do=notice&view=$view&type=$subtype" class="wqblock"><!--{eval echo lang('template', 'notice_'.$view.'_'.$subtype)}--><!--{if $_G['member']['newprompt_num'][$subtype]}--><span class="today_foot right0_top-5">$_G['member']['newprompt_num'][$subtype]</span><!--{/if}--></a></li>
                        <!--{/loop}-->
                    </ul>
                </div>
            </div>
            <!--{eval $my_roll_tag='my_private_roll';}-->
            <!--{template common/slide}-->
            <!--{/if}-->
            <!--{eval //echo"<pre>";print_r($list);exit;}-->
             <div class="wqprivate_news">
                <ul>
                <!--{loop $list $key $value}-->
                <li class="wqnew_bottom {if $key==1}bw0{/if}" id="pokeQuery_{$value[id]}">
                        <!--{if $value[authorid]}-->
                        <a href="home.php?mod=space&do=profile&uid=$value[authorid]"><!--{avatar($value[authorid],small)}--></a>
                        <!--{else}-->
                            <img src="{IMGDIR}/systempm.png" alt="systempm" />
                        <!--{/if}-->
                        <span class="width120 wqhead_info wq_grey wqapp_f14" style="padding-left:60px;"><!--{date($value[dateline], 'u')}--></span>

                        <div class="wqhead_info wqm_bottom5" style="$value[style]">
                            <!--{if $_GET[view]=='interactive'}-->
                                <!--{if $_GET['type']=='poke'||$_GET['type']==''}-->
                                    <!--{eval $value[note]=str_replace(array('>' . $Tlang['350d7aeb67815571'] . '</a>','>' . $Tlang['ee56a4364bacc863'] . '</a>',"onclick=\"showWindow(this.id, this.href, 'get', 0);\"","onclick=\"showWindow('pokeignore', this.href, 'get', 0);\"",), array('><span class="wq_call_back">' . $Tlang['350d7aeb67815571'] . '<span></a>',' data="' . $value[id] . '"><span class="wq_ignore">' . $Tlang['ee56a4364bacc863'] . '<span></a>',"",'class="dialog"',), $value[note]);}-->
                                    <script>
                                        function errorhandle_() {
                                            if ($.trim(arguments[0]) == "{$Tlang['9fcce9099f793485']}") {
                                                clearInterval(setTimeout_location);
                                                setTimeout(function () {
                                                    location.reload();
                                                }, '1000');
                                            }
                                        }
                                    </script>
                                <!--{elseif $_GET['type']=='friend'}-->
                                    <!--{eval $value[note] = str_replace('xw1','xw1 dialog',$value[note])}-->
                                    <!--{eval $value[note]=str_replace(array('>'.$Tlang['a15348d1b9f97c68'].'</a>',"showWindow(this.id, this.href, 'get', 0);"), array('><span class="wq_approval">'.$Tlang['a15348d1b9f97c68'].'<span></a>',"showWindow('approval', this.href);return false;"), $value[note]);;}-->
                                <!--{/if}-->
                            <!--{/if}-->
                            <!--{eval $value[note]=str_replace('target="_blank"',"",$value[note]);}-->
                            $value[note]
                        </div>
                        <!--{if $value[from_num]}-->
                        <div class="xg1 xw0" style=" margin-left:70px;">{lang ignore_same_notice_message}</div>
                        <!--{/if}-->
                     <a class="dialog wqbtn_news wq_grey" href="home.php?mod=spacecp&ac=common&op=ignore&authorid=$value[authorid]&type=$value[type]&handlekey=addfriendhk"><i class="wqiconfont2 wqicon2-comiispingbi1 wqapp_f18"></i></a>
                    </li>
                <!--{/loop}-->
                    </ul>
            </div>
            <!--{if empty($list)}-->
            <p class="wqemp"><span class="wqno_con"><img src="{$_G['style'][styleimgdir]}images/wqno_con.png"></span>{$Tlang['3ee14901b1946751']}</p>
           <!--{/if}-->
             <!--{if $view!='userapp' && $space[notifications]}-->
            <div class="mtm mbm" style="padding:0px 12px;"><a href="home.php?mod=space&do=notice&ignore=all" class="wqblock">{lang ignore_same_notice_message}</a></div>
            <!--{/if}-->

            <!--{if $multi}-->
            <div class="pgs cl">
                <!--{eval
                    $request_url=str_replace(array("&mobile=2","&page=".$page),"",$_SERVER['REQUEST_URI']);
                    $multi=str_replace('home.php?mod=space&do=notice&isread=1',$request_url,$multi);
                }-->
                $multi
            </div>
            <!--{/if}-->
        <!--{/if}-->
        <div class="wqheight44" style=" height: 0.95rem;"></div>
        <div class="wqnews_remind wqnew_top">
            <ul>
                <li>
                    <a href="home.php?mod=space&do=notice&view" class="wqblock<!--{if $_GET['do'] == 'notice'}--> wqcolor<!--{/if}-->"><i class="wqiconfont2 wqicon2-tixing wqapp_f18"></i>{$Tlang['4cfa49d2e80059bc']}</a>
                </li>
                <li>
                    <a href="home.php?mod=space&do=pm" class="wqblock<!--{if $_GET['do'] == 'pm'}--> wqcolor<!--{/if}-->"><i class="wqiconfont2 wqicon2-xiaoxi wqapp_f18"></i>{$Tlang['2ba413127f2431b2']}</a>
                </li>
            </ul>
        </div>
<!--{eval $nofooter=1;}-->
<!--{template common/footer}-->
<!--{/if}-->