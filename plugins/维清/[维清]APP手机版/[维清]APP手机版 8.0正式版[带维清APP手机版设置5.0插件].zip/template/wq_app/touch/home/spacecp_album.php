<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['spacecp_album'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{if $_GET['op'] == 'edithot'}-->
<div class="wqshield_notice">
    <form method="post" autocomplete="off" action="home.php?mod=spacecp&ac=album&op=edithot&picid=$picid">
        <input type="hidden" name="referer" value="{echo dreferer()}" />
        <input type="hidden" name="hotsubmit" value="true" />
        <input type="hidden" name="formhash" value="{FORMHASH}" />
        <p class="c m_t5 wqshield_con"><span class="wqinput"><input type="text" name="hot" value="$pic[hot]" size="10"/></span></p>
        <p class="wqbtn_can wqnew_top">
        <a href="javascript:;" onclick="popup.close();" class="wqeject_cancel wqnew_right">{lang cancel}</a>
        <button type="submit" name="btnsubmit" value="true" class="wqdetermine formdialog">{lang determine}</button>
        </p>
    </form>
</div>
<!--{eval exit();}-->
<!--{elseif $_GET['op'] == 'edittitle'}-->
<div class="wqshield_notice">
    <form id="titleform" name="titleform" method="post" autocomplete="off" action="home.php?mod=spacecp&ac=album&op=editpic&subop=update&albumid=$pic[albumid]">
        <input type="hidden" name="referer" value="{echo dreferer()}" />
        <input type="hidden" name="editpicsubmit" value="true">
        <input type="hidden" name="formhash" value="{FORMHASH}" />
<!--        <input type="hidden" name="handlekey" value="edittitlehk_$pic[picid]">-->
        <div class="c m_t5 wqshield_con">
            <textarea id="edittitle" class="wqtextarea wqnew_all pt" name="title[{$pic[picid]}]" cols="50" rows="4" placeholder="{$Tlang['7adb966212455d78']}">$pic[title]</textarea>
        </div>
        <p class="wqbtn_can wqnew_top">
         <a href="javascript:;" onclick="popup.close();" class="wqeject_cancel wqnew_right">{lang cancel}</a>
        <button type="submit" name="btnsubmit" value="true" class="wqdetermine formdialog">{lang determine}</button>
        </p>
    </form>
</div>
<!--{eval exit();}-->
<!--{/if}-->
<!--{if $_GET['op'] == 'editpic' && $_GET['forajax']}-->
<ul id="wq_slides" class="clearfixed">
    <!--{loop $list $value}-->
    <li>
        <a href="home.php?mod=spacecp&ac=album&op=setpic&albumid=$album[albumid]&picid={$value[picid]}&handlekey=setpichk&infloat=yes">
            <!--{if $value[pic]}--><img src="$value[pic]"/><!--{/if}-->
        </a>
        <!--{if $value[status] == 1}--><b class="pending_audit">{lang moderate_need}</b>
        <!--{/if}-->
    </li>
    <!--{/loop}-->
</ul>
  <!--{eval exit();}-->
<!--{/if}-->
<!--{template common/header}-->
<!--{if $_GET['op'] == 'edit'}-->
<form method="post" autocomplete="off" id="theeditform" name="theform" action="home.php?mod=spacecp&ac=album&op=edit&albumid={$album[albumid]}">
    <input type="hidden" name="referer" value="{echo dreferer()}" />
    <input type="hidden" name="editsubmit" value="true" />
    <input type="hidden" name="formhash" value="{FORMHASH}" />

    <!--{eval
        $headparams['wtype'] = '2';

        $headparams['ltype'] = 'cancel';
        $headparams['lname'] = $Tlang['9c825be7149e5b97'];
        $headparams['lurl'] = 'javascript:void(0);';

	$headparams['ctype'] = 'span';
        $headparams['cname'] =$Tlang['7db60da508f19f3c'];

        $headparams['rtype'] = 'but';
        $headparams['rname'] = $Tlang['b531d032f4f29f92'];
        $headparams['rclass'] = 'formdialog';
        $headparams['rid'] = 'postsubmit';
        $headparams['butname'] = 'submit';

        echo wq_app_get_header($headparams, false, true) ;
    }-->


    <div class="wqpost_list new_wqpost_list">
        <ul class="wqpost_list_ul">
            <li>
               <input type="text" id="albumname" name="albumname" value="$album[albumname]"  placeholder="{lang album_name}" size="20" class="wqpost_input" />
            </li>
            <li>
                <textarea name="depict" id="depict" class="wqpost_textarea" cols="40" placeholder="{lang album_depict}" rows="3">$album[depict]</textarea>
            </li>
            <!--{if $categoryselect}-->
            <li>
                $categoryselect
            </li>
            <!--{/if}-->
            <li>
                <select name="friend" onchange="passwordShow(this.value);" class="wqpost_select">
                    <option value="0"$friendarr[0]>{lang friendname_0}</option>
                    <option value="1"$friendarr[1]>{lang friendname_1}</option>
                    <option value="2"$friendarr[2]>{lang friendname_2}</option>
                    <option value="3"$friendarr[3]>{lang friendname_3}</option>
                    <option value="4"$friendarr[4]>{lang friendname_4}</option>
                </select>
            </li>
            <li id="span_password" style="$passwordstyle">
                <input type="text" name="password" value="$album[password]" placeholder="{lang password}" size="20" class="wqpost_input" />
            </li>
            <div id="tb_selectgroup" style="$selectgroupstyle">
            <li>
                <select name="selectgroup" onchange="getgroup(this.value);" class="wqpost_select">
                    <option value="">{lang from_friends_group}</option>
                    <!--{loop $groups $key $value}-->
                    <option value="$key">$value</option>
                    <!--{/loop}-->
                </select>
            </li>
            <li>
                <textarea name="target_names" id="target_names" placeholder="{lang friend_name_space}"  rows="3" class="wqpost_textarea">$album[target_names]</textarea>
                <p id="names_hidden" style="display: none"></p>
            </li>
            </div>
        </ul>
    </div>
    <div class="wqpersonal_secrecy">
        <ul>
            <li class="wqbl_line">
                <a href="javascript:;">
                    <div class="wqpersonal_secrecy_right wqm_left0 wqno_border">{$Tlang['69c62f47af705aea']}
                        <span class="y wq_arrow">
                            <img src="data/attachment/album/$album[pic]" class="wqsethead">
                            <i class="wqiconfont2 wqicon2-jiantou wqm_left6"></i>
                        </span>
                    </div>
                </a>
            </li>
        </ul>
    </div>
    <div class="wqdelete_album">
        <a class="dialog" href="home.php?mod=spacecp&ac=album&op=delete&albumid=$album[albumid]&handlekey=delalbumhk_{$album[albumid]}" id="album_delete_$album[albumid]" >{$Tlang['08b716f05c4c28aa']}</a>
    </div>
</form>

<div id="piclist" class="wqalbum_list">
    <div class="wqpiclist wqbg_color">
        <span class="wqpost_title">{$Tlang['07c11c52326a1892']}</span>
        <a href="javascript:;" class="piccancel">{$Tlang['697de294260844df']}</a>
    </div>
</div>
<style>
    #piclist{position:fixed;top:0px;background:#fff;z-index:4;}
    .wqpiclist{line-height: 44px;height: 44px;text-align: center;width: 100%;overflow: hidden;}
    .wqpiclist .piccancel{position: absolute;top: 2px;left: 0px;padding: 0px 12px;color: #fff;text-align: center;}
</style>
<script>
    var model = {
        init: function(){
            $.ajax({
                url:'home.php?mod=spacecp&ac=album&op=editpic&albumid=$album[albumid]&forajax=1',
                data:{},
                type:'post',
                dataType:'html'
            }).success(function (data) {
                $('#piclist').append(data);
            }).error(function(){
                console.log('err')
            });
            model.render();
            model.pic_list();
        },
        render:function(){
            $('#piclist').css({'left':$(window).width(),'width':$(window).width(),'height':'100%','transition':'0.3s'});
        },
        pic_list:function(){
            $('.wqbl_line').click(function(){
                $('#piclist').css({'transform':'translate(' + ($(window).width() * (-1)) + 'px)'});
            });
            $('.piccancel').click(function(){
                $('#piclist').css({'transform':'translate(' + $(window).width() + 'px)'});
            });
            model.pic_choose();
        },
        pic_choose:function(){
            $('#piclist').on('click','#wq_slides a',function(e){
                e.preventDefault();
                var that = $(this);
                $.ajax({
                    url:$(this).prop('href'),
                    data:{inajax:1},
                    type:'GET',
                    dataType: 'html'
                }).success(function (data) {
                    $('#piclist').css({'transform':'translate(' + $(window).width() + 'px)'});
                    $('.wqbl_line').find('img').prop('src',that.find('img').prop('src'));
                }).error(function () {
                    console.log('err')
                })
            });
        }
    };
    model.init();
</script>
<!--{/if}-->
<!--{if $_GET['op'] == 'editpic'}-->
<!--{eval $firstAlbum = reset($albumlist);}-->
<form method="post" autocomplete="off" id="theform" name="theform" action="home.php?mod=spacecp&ac=album&op=editpic&albumid=$albumid">
    <input type="hidden" name="page" value="$page"/>
    <input type="hidden" name="editpicsubmit" value="true"/>
    <input type="hidden" name="formhash" value="{FORMHASH}"/>
    <input type="hidden" id="subop" name="subop" value=""/>
    <input type="hidden" id="newalbumid" name="newalbumid" value="$firstAlbum[albumid]"/>
    <!--{eval
        $headparams['wtype'] = '1';
        $headparams['lurl'] = $backurl;
        $headparams['ltype'] = 'a';
        $headparams['cname'] = $Tlang['6309c14ccc327668'];
        echo wq_app_get_header($headparams);
    }-->
    <div class="wqadmin_photo">
        <h3>
            <input type="checkbox" name="checkbox"  id="chkall" id="photo_select" class="weui_check" onchange="checkAll(this.form, 'ids')">
            <label class="weui_check_label" for="chkall"><i class="weui_icon_checked i_sub"></i> {lang select_all}</label>
        </h3>
        <div class="wqalbum_list">
            <ul>
                <input type="submit" id="editpicsubmit" class="formdialog" style='display: none;'/>
                <!--{loop $list $value}-->
                <li>
                    <div class="wqa">
                       <span class="wqphoto_radio" >
                            <input onchange="ischeck('theform', 'ids');" type="checkbox" name="ids[{$value[picid]}]" class="weui_check" id="ids[{$value[picid]}]" value="{$value[picid]}">
                            <label class="weui_check_label wqblock" for="ids[{$value[picid]}]"><i class="weui_icon_checked"></i><img src="$value[pic]" alt="" /></label>
                        </span>
                    </div>
                 </li>
                  <!--{/if}-->
            </ul>
        </div>
    </div>
    <!--{block move_html}-->
    <div class="wqshield_notice">
        <div class="wqshield_con">
            <p>{$Tlang[4d58c24ec1f4cee4]}</p>
            <p class="wqshield_con_border wqnew_all">
                <select name="newsalbumid" class="wqselect" onchange="wqc_get_albumid(this.value)">
                    <!--{eval $s=0;}-->
                    <!--{loop $albumlist $key $value}-->
                        <!--{if $albumid != $value[albumid]}-->
                        <!--{eval $s++;}-->
                        <option value="$value[albumid]">$value[albumname]</option>
                        <!--{/if}-->
                    <!--{/loop}-->
                    <!--{if $albumid>0}-->
                    <!--{eval $s++;}-->
                    <option value="0" selected="selected">{lang default_album}</option>
                    <!--{/if}-->
                </select>
            </p>
        </div>
        <p class="wqbtn_can">
            <a href="javascript:;" onclick="popup.close();" class="wqeject_cancel wqnew_right">{$Tlang[9c825be7149e5b97]}</a>
            <button type="button" onclick="$(\'#editpicsubmit\').click();" class="wqdetermine">{$Tlang[387e9a577ee04ca3]}</button>
        </p>
    </div>
    <!--{/block}-->
    <!--{eval $move_html=str_replace(array("\r","\n","\r\n"),"",$move_html);}-->
    <div class="wqtransfer_delete wqbg_color">
        <ul>
            <li><button type="button" class="wqbg_color wqborder wq_disabled" onclick="wq_editpic('move')" disabled="disabled">{$Tlang['0259d2e557959f0d']}</button><span class="wq_line"></span></li>
            <li><button type="button" class="wqbg_color wqborder wq_disabled" onclick="wq_editpic('delete')" disabled="disabled">{lang delete}</button></li>
        </ul>
    </div>
</form>
<!--{if $multi}-->$multi<!--{/if}-->
<!--{/if}-->
<!--{if $_GET['op'] == 'delete'}-->
<div class="wqshield_notice">
    <form method="post" autocomplete="off" id="thedeleteform" name="theform" action="home.php?mod=spacecp&ac=album&op=delete&albumid=$albumid&uid=$_GET[uid]">
        <input type="hidden" name="referer" value="{echo dreferer()}" />
        <input type="hidden" name="deletesubmit" value="true" />
        <input type="hidden" name="formhash" value="{FORMHASH}" />
        <div class="wqshield_con">
            <p>{lang delete_album_message}</p>
            <p class="wqborder_grey_s">
                <select name="moveto" class="wqselect">
                    <option value="-1">{lang completely_remove}</option>
                    <option value="0">{lang move_to_default_album}</option>
                    <!--{loop $albums $value}-->
                    <option value="$value[albumid]">{lang move_to} $value[albumname]</option>
                    <!--{/loop}-->
                </select>
            </p>
        </div>
        <p class="wqbtn_can wqnew_top">
            <a href="javascript:;" onclick="popup.close();" class="wqeject_cancel wqnew_right">{lang cancel}</a>
            <button type="submit" name="submit" class="formdialog wqdetermine" value="true">{lang determine}</button>
        </p>
    </form>
</div>
<!--{/if}-->
<script>
    function passwordShow(value) {
        var span_password, tb_selectgroup;
                switch (value){
        case '4':
                span_password = 'show';
                tb_selectgroup = 'hide';
                break;
                case '2':
                span_password = 'hide';
                tb_selectgroup = 'show';
                break;
                default:
                span_password = 'hide';
                tb_selectgroup = 'hide';
        }
        $('#span_password')[span_password]();
                $('#tb_selectgroup')[tb_selectgroup]();
    }

    function getgroup(gid) {
        if (gid) {
            $.get('home.php?mod=spacecp&ac=privacy&inajax=1&op=getgroup&gid=' + gid, {},
                function(s) {
                    s = wqXml(s);
                    var s = wq_replace_js(s);
                    s = $.trim($('#names_hidden').html(s).text());
                    s = s + ' ';
                    document.getElementById('target_names').innerHTML += s;
                }, 'html');
        }
    }

    $('#albumname').on('keyup input', function () {
         $('#postsubmit').attr('disabled', ($.trim($('#albumname').val()) ? null : 'disabled'));
    });

    var picObj = {{$ids}};
    function succeedhandle_setpichk(url, msg, values) {
        wq_setTimeout();
        for (var id in picObj) {
            $('#a_picid_' + picObj[id]).text("{lang set_to_conver}");
        }
        if (values['picid']) {
            $('#a_picid_' + values['picid']).text("{lang cover_pic}");
        }
    }

    var editAction;
    function succeedhandle_theform(url, msg, values) {
        if ($.trim(msg) == '{$Tlang[357c80f9fe7dbb3f]}') {
            clearInterval(setTimeout_location);
            setTimeout(function() {
                popup.close();
                location.href = document.referrer;
            }, '1000');
            if (editAction == 'delete' || editAction == 'move') {
                $('input:checked').parent().parent().remove();
                $('.wq_disabled').attr('disabled', 'disabled')
            }
        }
    }
    function checkAll(form, name) {
        for (var i = 0; i < form.elements.length; i++) {
            var e = form.elements[i];
            if (e.name.match(name)) {
                 e.checked = form.elements['chkall'].checked;
            }
        }
        ischeck('theform', 'ids');
    }
    function ischeck(id, prefix) {
        form = document.getElementById(id);
        for (var i = 0; i < form.elements.length; i++) {
            var e = form.elements[i];
            if (e.name.match(prefix) && e.checked) {
                $('.wq_disabled').attr('disabled', null)
                return true;
            }
        }
        $('.wq_disabled').attr('disabled', 'disabled');
        return true;
    }
    function wq_editpic(action) {
    $('#subop').val(action)
    if (action == 'delete') {
        if (confirm('{$Tlang[ef60f7f7fb1ab7e4]}'))$('#editpicsubmit').click();
    } else if (action == 'move'){
        popup.open('{$move_html}')
        $('form').append($('.new_dialogbox2'));
    } else{
        $('#editpicsubmit').click();
    }
    editAction = action;
    }

    function wqc_get_albumid(albumid){
        $("#newalbumid").val(albumid);
    }
    function succeedhandle_theeditform() {
        clearTimeout(setTimeout_location)
        setTimeout_location = setTimeout(function() {
            location.href = document.referrer;
        }, 1000);
    }
 </script>
<!--{eval $nofooter=1;}-->
<!--{template common/footer}-->
<!--{/if}-->