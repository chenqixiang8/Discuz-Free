<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['login'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{template common/header}-->
<style>body{ background-color: #f9f9f9}</style>
<!--{if isset($_GET['viewlostpw'])}-->
    <!--{eval
        $headparams['wtype'] = '1';
        $headparams['lurl'] = $backurl;
        $headparams['ltype'] = 'a';
        $headparams['cname'] = $Tlang['8891d1684ab9453f'];
        echo wq_app_get_header($headparams);
    }-->
    <div class="wqlogin_register">
        <form method="post" autocomplete="off" id="lostpwform_$loginhash" class="cl" onsubmit="ajaxpost('lostpwform_$loginhash', 'returnmessage3_$loginhash', 'returnmessage3_$loginhash', 'onerror');return false;" action="member.php?mod=lostpasswd&lostpwsubmit=yes&infloat=yes">
            <input type="hidden" name="formhash" value="{FORMHASH}" />
            <input type="hidden" name="handlekey" value="lostpwform" />
            <div class="wqlogin">
                <ul>
                    <li><input type="text" name="email" id="lostpw_email" size="30" tabindex="1" placeholder="{$Tlang['c7f5bbf620d645ad']}"></li>
                    <li><input type="text" name="username" id="lostpw_username" size="30" value="" tabindex="1"placeholder="{lang username}"></li>
                </ul>
            </div>
            <div class="wqlogin_btn wqm_top15"><button  tabindex="100" value="true" name="lostpwsubmit" type="submit">{lang submit}</button></div>
        </form>
    </div>
<!--{else}-->
{eval $loginhash = 'L'.random(4);}
<!-- userinfo start -->

<!--{eval
    $headparams['wtype'] = '1';
    $headparams['lurl'] = $backurl;
    $headparams['ltype'] = 'a';
    $headparams['lurl'] = !$_GET['inajax'] ? $backurl : 'javascript:;';
    $headparams['lextra'] = $_GET['inajax'] ? 'onclick="wq_is_scroll(),popup.close();"' : '';
    $headparams['cname'] = $Tlang['e0ebc819d8ccd251'];

    echo wq_app_get_header($headparams);
}-->
<div class="wqlogin_register<!--{if !empty($_GET['inajax'])}--> wqlogin_inajax<!--{/if}-->">
    <form id="loginform" method="post" action="member.php?mod=logging&action=login&loginsubmit=yes&loginhash=$loginhash" onsubmit="{if $_G['setting']['pwdsafety']}pwmd5('password3_$loginhash');{/if}" >
        <input type="hidden" name="formhash" id="formhash" value='{FORMHASH}' />
        <input type="hidden" name="referer" id="referer" value="<!--{if $wqreferer}-->{$wqreferer}<!--{else}-->forum.php?mobile=2<!--{/if}-->" />
        <input type="hidden" name="fastloginfield" value="username">
        <input type="hidden" name="cookietime" value="2592000">
        <!--{if $auth}-->
            <input type="hidden" name="auth" value="$auth" />
        <!--{/if}-->
        <div class="wqlogin">
            <ul>
                <li class="wqnew_bottom"><input type="text" value="" tabindex="1" class="" size="30" autocomplete="off" name="username" placeholder="{$Tlang['2aef1a750edcec42']}" fwin="login"></li>
                <li class="wqnew_bottom">
                    <input type="password" tabindex="2" class="wqpasswoed" size="30" value="" name="password" placeholder="{$Tlang['bda5051be3094609']}" fwin="login">
                    <a  href="javascript:;" class="wqlogin_eye y">
                        <i class="wqiconfont2 wqicon2-yincang wqapp_f20"></i>
                    </a>
                </li>
                <li class="wqnew_bottom">
                    <div class="wqlogin_select">
                        <span class="login-btn-inner">
                            <span class="login-btn-text">
                                <span class="span_question">{lang security_question}</span>
                            </span>
                            <span class="icon-arrow">&nbsp;</span>
                        </span>
                        <select id="questionid_{$loginhash}" name="questionid" class="sel_list">
                            <option value="0" selected="selected">{lang security_question}</option>
                            <option value="1">{lang security_question_1}</option>
                            <option value="2">{lang security_question_2}</option>
                            <option value="3">{lang security_question_3}</option>
                            <option value="4">{lang security_question_4}</option>
                            <option value="5">{lang security_question_5}</option>
                            <option value="6">{lang security_question_6}</option>
                            <option value="7">{lang security_question_7}</option>
                        </select>
                    </div>
                </li>
                <li class="answerli wqnew_bottom" style="display:none;"><input type="text" name="answer" id="answer_{$loginhash}" class="wqp_left0" size="30" placeholder="{lang security_a}"></li>
            <!--{if $seccodecheck}-->
            <!--{subtemplate common/seccheck}-->
            <!--{/if}-->
            </ul>
        </div>
        <div class="wqlogin_btn wqm_top15 btn_login"><button tabindex="3" value="true" name="submit" type="submit" class="formdialog"> {$Tlang['e0ebc819d8ccd251']}</button></div>
    </form>
    <p class="wqregister_account">
        <!--{if $_G['setting']['regstatus']}-->
            <a href="member.php?mod={$_G['setting']['regname']}&referer=$wqreferer">{$Tlang['3f822f539457e417']}</a>
        <!--{/if}-->
        <span class="wqretrieve_password y"><a href="member.php?mod=logging&action=login&viewlostpw=1">{$Tlang['8891d1684ab9453f']}</a></span>
    </p>
    <!--{hook/logging_bottom_mobile}-->
    <!--{if $_G['cache']['plugin']['wq_login'] || $_G['cache']['plugin']['wq_qqlogin'] || $_G['setting']['connect']['allow']||($_G['cache']['plugin']['wq_smslogin'] && $_G['cache']['plugin']['wq_smslogin']['isopen_smslogin'])}-->
        <div class="wqother_login2">
            <h3><span>{$Tlang['35f3bc67035d898c']}</span></h3>
            <div class="wqother_login2_icon">
            <!--{if $_G['cache']['plugin']['wq_login']}-->
            <!--{eval $referer = !$_G['inajax'] && CURSCRIPT != 'member' ? $_G['basefilename'] . ($_SERVER['QUERY_STRING'] ? '?' . $_SERVER['QUERY_STRING'] : '') : dreferer();$referer = urlencode($referer);}-->
               <a href="plugin.php?id=wq_login&mod=access&referer=$referer" class="wechat wqweixin wqiconfont2 wqicon2-weixin wqapp_f32"></a>
            <!--{/if}-->
            <!--{if $_G['cache']['plugin']['wq_qqlogin'] && !$_G['setting']['bbclosed']}-->
            <a href="plugin.php?id=wq_qqlogin&mod=access&op=init&referer=$referer" class="wqqq qq"><i class="wqiconfont2 wqicon2-qq wqapp_f32"></i></a>
            <!--{/if}-->
            <!--{if $_G['setting']['connect']['allow'] && !$_G['setting']['bbclosed']}-->
                <a href="{$_G[connect][login_url]}&statfrom=login_simple&referer=$referer" class="wqqq qq"><i class="wqiconfont2 wqicon2-qq wqapp_f32"></i></a>
            <!--{/if}-->
            <!--{if $_G['cache']['plugin']['wq_smslogin'] && $_G['cache']['plugin']['wq_smslogin']['isopen_smslogin']}-->
                <!--{eval $dreferer = str_replace('&amp;', '&', dreferer());$backurl = urlencode($dreferer);}-->
                <a href="plugin.php?id=wq_smslogin&mod=login&referer=$referer" class="wphone wqiconfont2 wqicon2-shouji01 wqapp_f32"></a>
            <!--{/if}-->
            </div>
        </div>
    <!--{/if}-->
</div>
<!-- userinfo end -->
<!--{if $_G['setting']['pwdsafety']}-->
	<script type="text/javascript" src="{$_G['setting']['jspath']}md5.js?{VERHASH}" reload="1"></script>
<!--{/if}-->
<!--{eval updatesession();}-->
<script type="text/javascript">
    $(function() {
        $(document).on('change', '.sel_list', function() {
            var obj = $(this);
            $('.span_question').text(obj.find('option:selected').text());
            if(obj.val() == 0) {
                $('.answerli').css('display', 'none');
            } else {
                $('.answerli').css('display', 'block');
            }
        });
    });

    $('.wqlogin_eye').on('click', function () {
        var icon = $(this).find('i');
        if (icon.hasClass('wqicon2-yincang')) {
            $('.wqpasswoed').prop('type', 'text');
            icon.addClass('wqicon2-xianshimima').removeClass('wqicon2-yincang');
        } else {
            $('.wqpasswoed').prop('type', 'password');
            icon.addClass('wqicon2-yincang').removeClass('wqicon2-xianshimima');
        }

    });
</script>
<!--{/if}-->

<!--{eval $nofooter=1;}-->
<!--{template common/footer}-->
<!--{/if}-->