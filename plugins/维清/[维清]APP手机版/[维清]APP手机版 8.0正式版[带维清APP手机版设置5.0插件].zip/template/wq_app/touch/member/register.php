<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['register'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{eval $header_nav='null';}-->
<!--{template common/header}-->
 <!--{if $bbrules && $bbrulesforce && $_GET['agree'] != 'yes'}-->
    <!--{eval $_GET['agreement']='yes';}-->
<!--{/if}-->
<!--{if $_GET['agreement'] != 'yes'}-->
<style>body{ background-color: #f9f9f9}</style>

<!--{eval
    $headparams['wtype'] = '1';
    $headparams['lurl'] = $backurl;
    $headparams['ltype'] = 'a';
    $headparams['cname'] = $Tlang['07f81880af8c9cc4'];
    echo wq_app_get_header($headparams);
}-->
<!-- registerbox start -->
<div class="wqlogin_register">
	<form method="post" autocomplete="off" name="register" id="registerform" action="member.php?mod={$_G[setting][regname]}">
                    <div class="wqlogin">
		<input type="hidden" name="regsubmit" value="yes" />
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<!--{eval $dreferer = str_replace('&amp;', '&', dreferer());}-->
		<input type="hidden" name="referer" value="$dreferer" />
		<input type="hidden" name="activationauth" value="{if $_GET[action] == 'activation'}$activationauth{/if}" />
		<ul>
			<li><input type="text" tabindex="1" class="px p_fre" size="30" autocomplete="off" value="" name="{$_G['setting']['reginput']['username']}" placeholder="{lang registerinputtip}" fwin="login"></li>
			<li><input type="password" tabindex="2" class="px p_fre" size="30" value="" name="{$_G['setting']['reginput']['password']}" placeholder="{lang login_password}" fwin="login"></li>
			<li><input type="password" tabindex="3" class="px p_fre" size="30" value="" name="{$_G['setting']['reginput']['password2']}" placeholder="{lang registerpassword2}" fwin="login"></li>
			<li><input type="email" tabindex="4" class="px p_fre" size="30" autocomplete="off" value="" name="{$_G['setting']['reginput']['email']}" placeholder="{lang registeremail}" fwin="login"></li>
			<!--{if empty($invite) && ($_G['setting']['regstatus'] == 2 || $_G['setting']['regstatus'] == 3)}-->
		       <li>
				   <input type="text" name="invitecode" autocomplete="off" tabindex="5" class="px p_fre" size="30" value="" placeholder="{lang invite_code}" fwin="login">
			   </li>
			<!--{/if}-->
			<!--{if $_G['setting']['regverify'] == 2}-->
				<li>
					<input type="text" name="regmessage" autocomplete="off" tabindex="6" class="px p_fre" size="30" value="" placeholder="{lang register_message}" fwin="login">
				</li>
			<!--{/if}-->
			<!--{if $_G['cache']['fields_register']}-->
				<!--{loop $_G['cache']['fields_register'] $field}-->
					<!--{if $htmls[$field['fieldid']]}-->
						<li class="wqnew_bottom" id="tr_{$field['fieldid']}">{$htmls[$field['fieldid']]}</li>
					<!--{/if}-->
				<!--{/loop}-->

				<script>
					if (document.getElementById('birthprovince')){
						document.getElementById('birthprovince').onchange = null;
					}
					if (document.getElementById('resideprovince')){
						document.getElementById('resideprovince').onchange = null;
					}
					$('body').on('change', '#birthprovince, #resideprovince', function () {
						if (!$(this).val()) {
							$(this).next('select').remove();
						} else {
							var upid = $(this).find('option:selected').attr('did');
							var that = $(this);
							var cityName = that.parent().parent().prop('id') == 'td_birthcity' ? 'birthcity' : 'residecity';
							$.ajax({
								url: 'plugin.php?id=wq_app_setting&mod=api&fun=district&level=2',
								data: {upid: upid},
								type: 'GET',
								dataType: 'JSON',
								success: function (res) {
									var option = '';
									for (var i in res.data) {
										option += '<option value="' + res.data[i].name + '">' + res.data[i].name + '</option>';
									}
									that.next('select').remove();
									that.parent().append('<select name="' + cityName + '" class="ps"  tabindex="1"><option value="">-'+'{$Tlang[29405aa0c5f4c1b9]}'+'-</option>' + option + '</select>');
								}
							});
						}
					});

					function showbirthday(){
						var el = $('#birthday');
						var birthday = el.val();
						var options = "<option values=\"\">&#x65E5;</option>";
						for(var i = 1; i < 29; i++){
							options +=  "<option values=\""+i+"\">"+i+"</option>";
						}
						el.html(options);
						if($('#birthmonth').val() != "2"){
							el.append("<option value='29'>29</option>")
							el.append("<option value='30'>30</option>")
							switch($('#birthmonth').val()){
									case "1":
									case "3":
									case "5":
									case "7":
									case "8":
									case "10":
									case "12":{
											el.append("<option value='31'>31</option>")
									}
							}
						} else if($('#birthyear').val() != "") {
							var nbirthyear=$('#birthyear').val();
							if(nbirthyear%400==0 || (nbirthyear%4==0 && nbirthyear%100!=0)){
								el.append("<option value='29'>29</option>")
							}
						}
						el.value = birthday;
					}
				</script>
			<!--{/if}-->
			<!--{if $secqaacheck || $seccodecheck}-->
				<li class="wq_answer">
				<!--{subtemplate common/seccheck}-->
				</li>
			<!--{/if}-->
		</ul>
	</div>
        <div class="wqlogin_btn wqm_top15 btn_register"><button tabindex="7" value="true"  name="regsubmit"  type="submit" class="formdialog">{$Tlang['a6b898a1b07cb9ff']}</button></div>
        <!--{if $_G['cache']['plugin']['wq_smslogin'] && $_G['cache']['plugin']['wq_smslogin']['isopen_register_verify']}-->
            <div class="wqlogin_iphone wqm_top15"><a href="plugin.php?id=wq_smslogin&mod=register&referer=$wqreferer">{$Tlang['0c688c5486516f6f']}</a></div>
        <!--{/if}-->
        <!--{if $bbrules}-->
            <div class="wqagreebbrule">
                <input type="checkbox" class="pc weui_check" name="agreebbrule" value="$bbrulehash" id="agreebbrule" checked="checked" />
                <label for="agreebbrule" class="weui_check_label"><i class="iconfont weui_icon_checked"></i>{lang agree}</label>
                <a href="member.php?mod=register&agreement=yes">
                        {lang rulemessage}
                </a>
            </div>
        <!--{/if}-->
    </form>

    <div class="wqregister_account"><a href="member.php?mod=logging&action=login&referer=$wqreferer">{$Tlang['4642305397c488aa']}</a></div>
    <!--{hook/register_bottom_mobile}-->
<!--{else}-->
<!--{eval
    $headparams['wtype'] = '1';
    $headparams['lurl'] = $backurl;
    $headparams['ltype'] = 'a';
    $headparams['cname'] = $Tlang['53ac212661d80a16'];
    echo wq_app_get_header($headparams);
}-->

<div id="layer_bbrule" class="wq_service_terms">
<div class="wq_con">$bbrulestxt</div>
<p class="wqchoice">
	<a href="member.php?mod={$_G['setting']['regname']}&agree=yes" class="wqagree"><span>{lang agree}</span></a>
	<a href="./" class="wqdisagree"><span>{lang disagree}</span></a>
</p>
</div>
<!--{/if}-->

</div>
<!-- registerbox end -->
<!--{eval updatesession();}-->
<!--{eval $nofooter=1;}-->
<!--{template common/footer}-->

<!--{/if}-->