<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['judge'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{template common/header}-->
<div class="wqshield_notice">
    <div class="wqshield_con">
        <input name="operations[]" type="hidden" value="delete"/>
        <p>{$Tlang['c0926623ade2bf2d']}</p>
    </div>
    <p class="wqbtn_can wqnew_top">
        <a href="javascript:;" onclick="popup.close();"class="wqeject_cancel wqnew_right">{lang cancel}</a>
        <a href="javascript:history.back(-1);" class="wqeject_cancel">{lang confirms}</a>
    </p>
</div>
<!--{template common/footer}-->
<!--{/if}-->