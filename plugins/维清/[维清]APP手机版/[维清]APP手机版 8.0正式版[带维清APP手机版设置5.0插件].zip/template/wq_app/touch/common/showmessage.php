<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['showmessage'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{if $param['login']}-->
<!--{if $_G['inajax']}-->
<!--{eval dheader('Location:member.php?mod=logging&action=login&inajax=1&infloat=1');exit;}-->
<!--{else}-->
<!--{eval dheader('Location:member.php?mod=logging&action=login');exit;}-->
<!--{/if}-->
<!--{/if}-->
<!--{eval $showmessage='1';}-->
<!--{template common/header}-->
<!--{if $_G['inajax']}-->
<div class="wqtip">
    <dt id="messagetext">
    <!--{if $url_forward && !$_GET['loc']}-->
    <!--<p><a class="grey" href="$url_forward">{lang message_forward_mobile}</a></p>-->
    <script type="text/javascript">
        setTimeout_location = setTimeout(function() {
            window.location.href = '$url_forward';
        }, '1500');
    </script>
    <!--{elseif $allowreturn}-->
    <!--<p><input type="button" class="button" onclick="popup.close();" value="{lang close}"></p>-->
    <!--{/if}-->
    $show_message
    <!--{if $_G['forcemobilemessage']}-->
    <p>
        <a href="{$_G['setting']['mobile']['pageurl']}" class="mtn">{lang continue}</a><br />
        <a href="javascript:history.back();">{lang goback}</a>
    </p>
    <!--{/if}-->
    <!--{if $url_forward && !$_GET['loc']}-->
    <!--<p><a class="grey" href="$url_forward">{lang message_forward_mobile}</a></p>-->
    <!--{elseif $allowreturn}-->
    <script type="text/javascript"  reload="1">
        setTimeout_location =setTimeout(function () {
            popup.close();
        }, '1500');
    </script>
    <!--{/if}-->
    </dt>
</div>
<!--{else}-->

<!--{eval
    $headparams['wtype'] = '2';
    $headparams['wclass'] = 'group_menu';
    $headparams['ltype'] = 'dh';
    $headparams['ctype'] = 'img';
    $headparams['cimg'] = $logofilename;
    echo wq_app_get_header($headparams,false);
}-->


<!-- header end -->
<!-- main jump start -->
<div class="jump_c">
    <p>$show_message</p>
    <!--{if $_G['forcemobilemessage']}-->
    <p>
        <a href="{$_G['setting']['mobile']['pageurl']}" class="mtn">{lang continue}</a><br />
        <a href="javascript:history.back();">{lang goback}</a>
    </p>
    <!--{/if}-->
    <!--{if $url_forward}-->
	<!--{if $url_forward && !$_GET['loc']}-->
    <script type="text/javascript"  reload="1">
        setTimeout_location = setTimeout(function () {
            window.location.href = '$url_forward';
        }, '1000');
    </script>
    <!--{/if}-->
    <p><a class="grey" href="$url_forward">{lang message_forward_mobile}</a></p>
    <!--{elseif $allowreturn}-->
    <p><a class="grey" href="javascript:history.back();">{lang message_go_back}</a></p>
    <!--{/if}-->
</div>
<!-- main jump end -->

<!--{/if}-->
<!--{template common/footer}-->



<!--{/if}-->