<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['report'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{template common/header}-->
<div class="wqshield_notice">
<form method="post" autocomplete="off" id="form_$_GET[handlekey]" name="form_$_GET[handlekey]" action="misc.php?mod=report" {if $_G[inajax]}onsubmit="if(!$('report_message').value) return false;ajaxpost(this.id, 'form_$_GET[handlekey]');"{/if}>
      <div class="wqshield_con" style="text-align: left;">
      <div class="reason_slct c" id="return_$_GET[handlekey]">
		<p>{lang report_reason}</p>
               <div class="mbn" id="report_reasons">
                    <div style="padding:.1rem 0"><input type="radio" name="report_select" class="pr weui_check" onclick="$('#report_other').hide();" value="{$Tlang['e5e641c21d514be6']}"> <label class="weui_check_label"><i class="weui_icon_checked"></i>{$Tlang['e5e641c21d514be6']}</label></div>
                    <div style="padding:.1rem 0"><input type="radio" name="report_select" class="pr weui_check" onclick="$('#report_other').hide();" value="{$Tlang['23463bf93fcde32f']}"> <label class="weui_check_label"><i class="weui_icon_checked"></i>{$Tlang['23463bf93fcde32f']}</label></div>
                    <div style="padding:.1rem 0"><input type="radio" name="report_select" class="pr weui_check" onclick="$('#report_other').hide();" value="{$Tlang['4c4028dad54359f1']}"> <label class="weui_check_label"><i class="weui_icon_checked"></i>{$Tlang['4c4028dad54359f1']}</label></div>
                    <div style="padding:.1rem 0"><input type="radio" name="report_select" class="pr weui_check" onclick="$('#report_other').hide();" value="{$Tlang['7cd6fbeafc182445']}"><label class="weui_check_label"><i class="weui_icon_checked"></i>{$Tlang['7cd6fbeafc182445']}</label></div>
                    <div style="padding:.1rem 0"><input type="radio" name="report_select" class="pr weui_check" onclick="$('#report_other').show();" value="{$Tlang['727bfaa9ea102267']}"> <label class="weui_check_label"><i class="weui_icon_checked"></i>{$Tlang['727bfaa9ea102267']}</label></div>
               </div>
		<div id="report_other" class="wqtextarea_st" style="display:none">
                    <textarea id="report_message" name="message" class="reasonarea pt xg1 wqtextarea wqapp_f16" placeholder="{lang report_reason_other}"></textarea>
		</div>
	</div>
      </div>
	<p class="wqbtn_can wqnew_top">
            <a href="javascript:;" onclick="popup.close();" class="wqeject_cancel wqnew_right">{lang cancel}</a>
            <button id="report_submit" type="submit" value="true" class="wqeject_cancel">{lang confirms}</button>
	</p>
	<input type="hidden" name="referer" value="{echo dreferer()}" />
	<input type="hidden" name="reportsubmit" value="true" />
	<input type="hidden" name="rtype" value="$_GET[rtype]" />
	<input type="hidden" name="rid" value="$_GET[rid]" />
	<!--{if $_GET['fid']}-->
	<input type="hidden" name="fid" value="$_GET[fid]" />
	<!--{/if}-->
	<!--{if $_GET['uid']}-->
	<input type="hidden" name="uid" value="$_GET[uid]" />
	<!--{/if}-->
	<input type="hidden" name="url" value="$_GET[url]" />
	<input type="hidden" name="inajax" value="$_G[inajax]" />
	<!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
	<input type="hidden" name="formhash" value="{FORMHASH}" />

</form>
    </div>
<!--<script type="text/javascript" reload="1">
var reasons = {lang report_reason_message};
var reasonstring = '';
for (i=0; i<reasons.length; i++) {
	reasonstring += '<label><input type="radio" name="report_select" class="pr" onclick="$(\'report_other\').style.display=\'' + (i < reasons.length -1 ? 'none' : '') + '\';$(\'report_msg\').style.display=\'' + (i < reasons.length -1 ? 'none' : '') + '\'" value="' + reasons[i] + '"> ' + reasons[i] + '</label><br />';
}
$('report_reasons').innerHTML = reasonstring;
</script>-->
<!--{template common/footer}-->
<!--{/if}-->