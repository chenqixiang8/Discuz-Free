<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['smilies'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{if ($_GET['mod'] == 'portalcp' && $_GET['ac'] == 'article') || ($_GET['mod'] == 'post') ||  ($_GET['mod'] == 'viewthread') }-->
<div class="cellphone_expression showHide_biaoqing" style="display:none;">
    <ul class="look_smile expression">
        <!--{eval $wq_smilies = get_system_smilies();}-->
        <!--{loop $wq_smilies  $key $val}-->
        <li id="li_$key" data="$key" <!--{if $key==0}--> class="on" <!--{/if}--> ><a href="javascript:;" class="b_right"><img src="./static/image/smiley/$val[0][image]" /></a></li>
        <!--{if $key==5}-->
        <!--{eval break;}-->
        <!--{/if}-->
        <!--{/loop}-->
    </ul>
    <div class="look_smile_div slide-stop" style="position: relative">
        <!--{eval $delete_emoji='<a class="delete_emoji"><img src="template/wq_app/static/images/delete_emoji.png" /></a>';}-->
        <!--{loop $wq_smilies $key $val}-->
        <!--{eval $count=count($val);$data_html='';}-->
        <div id="wqscrolls_$key" data="$key" class='wqscrolls'<!--{if $key!=0}-->style="display:none;"<!--{/if}--> >
             <div id="wqscroll_$key" class="scroll_lb">
                <div class="scroll_lump">
                    <!--{loop $val $k $v}-->
                    <!--{if ($k+1)%21==1}-->
                    <!--{eval $data_html.=$k==0?'<span class="small_dots on"></span>':'<span class="small_dots"></span>';}-->
                    <div class="image_b">
                        <!--{/if}-->
                        <!--{eval $v[code]=str_replace(array("/",'\\','"'),array("","",'\"'), $v['code']);}-->
                        <a href="javascript:;" sid='$v[id]' code="$v[code]">
                            <img class="delayload" dataid="$v[id]" data="static/image/smiley/$v[image]"/></a>
                    <!--{if ($k+1)%21==0 ||($k+1)==$count}-->
                        </div>
                    <!--{/if}-->
                    <!--{/loop}-->
                </div>
                <!--{if $k>=21}-->
                <p class="small_dots_t" id="small_dots_t_$key">$data_html</p>
                <!--{/if}-->
            </div>
        </div>
        <!--{if $key==5}-->
        <!--{eval break;}-->
        <!--{/if}-->
        <!--{/loop}-->
    </div>
</div>
<!--{else}-->
<div class="cellphone_expression showHide_biaoqing" style="display:none;">
    <ul class="look_smile expression">
        <!--{eval $wq_smilies = get_system_smilies();}-->
        <!--{loop $wq_smilies  $key $val}-->
        <li id="li_$key" data="$key" <!--{if $key==0}--> class="on" <!--{/if}--> ><a href="javascript:;" class="b_right"><img src="./static/image/smiley/$val[0][image]" /></a></li>
        <!--{if $key==5}-->
        <!--{eval break;}-->
        <!--{/if}-->
        <!--{/loop}-->
    </ul>
    <div class="look_smile_div slide-stop" style="position: relative">
        <!--{eval $delete_emoji='<a class="delete_emoji"><img src="template/wq_app/static/images/delete_emoji.png" /></a>';}-->
        <!--{loop $wq_smilies $key $val}-->
        <!--{eval $count=count($val);$data_html='';}-->
        <div id="wqscrolls_$key" data="$key" class='wqscrolls'<!--{if $key!=0}-->style="display:none;"<!--{/if}--> >
             <div id="wqscroll_$key" class="scroll_lb">
                <div class="scroll_lump">
                    <!--{loop $val $k $v}-->
                        <!--{if ($k+1)%20==1}-->
                            <!--{eval $data_html.=$k==0?'<span class="small_dots on"></span>':'<span class="small_dots"></span>';}-->
                            <div class="image_b">
                        <!--{/if}-->
                            <!--{eval $v[code]=str_replace(array("/",'\\','"'),array("","",'\"'), $v['code']);}-->
                            <a href="javascript:;" sid='$v[id]' code="$v[code]">
                                <img class="delayload" dataid="$v[id]" data="static/image/smiley/$v[image]"/>
                            </a>
                        <!--{if ($k+1)%20==0 ||($k+1)==$count}-->
                            {$delete_emoji}
                            </div>
                        <!--{/if}-->
                    <!--{/loop}-->
                </div>
                <!--{if $k>=20}-->
                <p class="small_dots_t" id="small_dots_t_$key">$data_html</p>
                <!--{/if}-->
            </div>
        </div>
        <!--{if $key==5}-->
        <!--{eval break;}-->
        <!--{/if}-->
        <!--{/loop}-->
    </div>
</div>
<!--{/if}-->
<script src="{$_G['style'][styleimgdir]}js/public/smilies.js?{VERHASH}"></script>
<!--{/if}-->