<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['wechat_share'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{if $wq_login['appid'] && defined('WQ_IN_WECHAT') }-->
    <!--{if (CURSCRIPT=='forum'&& CURMODULE=='viewthread')}-->
        <!--{eval
            $sharetitle = $_G[forum_thread][subject];
        }-->
    <!--{elseif (CURSCRIPT=='portal'&& CURMODULE=='view')}-->
        <!--{eval
            $sharetitle = $article[title];
        }-->
    <!--{else}-->
        <!--{eval
            $sharetitle = !empty($navtitle) ? $navtitle : "";
            $sharetitle = empty($nobbname) ? $sharetitle."-".$_G['setting']['bbname'] : $sharetitle;
        }-->
    <!--{/if}-->
    <!--{eval
        $description = !empty($metadescription) ? dhtmlspecialchars($metadescription)."-".$_G['setting']['bbname'] : $_G['setting']['bbname'];
        $imgbase=null;
    }-->

  <!--{template wq_login:WX_SharePreview}-->
<!--{/if}-->
<!--{/if}-->