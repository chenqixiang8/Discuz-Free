<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['wq_buluocalendar'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<link href="{$_G['style']['styleimgdir']}mobile/mobiscroll.custom-2.5.0.min.css?{VERHASH}" rel="stylesheet" type="text/css"/>
<script src="{$_G['style']['styleimgdir']}mobile/thirdparty/mobiscroll.custom-2.5.0.min.js?{VERHASH}"  type="text/javascript"></script>
<!--{if $datetype||$mobiscroll_select}-->
<script type="text/javascript">
    if ('$datetype') {
        var currYear = (new Date()).getFullYear();
        var year = 8;
        var opt = {
            preset: '$datetype',
            theme: 'android-ics light',
            display: 'modal',
            mode: 'mixed',
            lang: 'zh',
            dateFormat: 'yyyy-mm-dd',
            setText: '&#x786E;&#x5B9A;',
            cancelText: '&#x53D6;&#x6D88;',
            dateOrder: 'yyyymmdd',
            dayText: '&#x65E5;', monthText: '&#x6708;', yearText: '&#x5E74;', hourText: '&#x65F6;', minuteText: '&#x5206;',
            showNow: false,
            nowText: "&#x4ECA;",
            timeWheels: 'HHii', timeFormat: 'HH:ii',
            startYear: currYear,
            endYear: currYear + year
        };
    }
    if ('$mobiscroll_select') {
        var theme_select = 'scroller';
    }
    $(document).on('click', '.dwo', function () {
        $(".dwb:contains('$Tlang['9c825be7149e5b97']')").click();
    });
</script>
<!--{/if}-->

<!--{/if}-->