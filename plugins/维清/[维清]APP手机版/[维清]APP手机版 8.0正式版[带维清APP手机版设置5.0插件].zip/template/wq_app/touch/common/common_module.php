<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['common_module'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
{eval
function get_images_for_list() {
    global $showmodel, $threadlists, $thread, $wq_app_setting,$_G;
    $imagenum = $threadlists[$thread['tid']]['imagenum'];
    $images= $imagenum > 0 ? wq_app_setting_get_pic($threadlists[$thread['tid']]['maximgs'],$threadlists[$thread['tid']]['images'],$showmodel,$showmodel) : array();
}

<!--{if !$imagenum}-->
<!--{eval return '';}-->
<!--{/if}-->

<!--{if $showmodel == '1'}-->
<!--{eval $classname = $wq_app_setting['img_left'] ? "wqlist1" : "wqlist2";}-->
	<!--{block return}-->
            <!--{if $imagenum > 0}-->
		<div class="wq-lazyload-container {$classname}">
                    <!--{loop $images $k $v}-->
                        <img class="wq_js_delayload" src="{$_G['style'][styleimgdir]}images/wq_dian.jpg" data-src="{$v}">
                    <!--{/loop}-->
                    <!--{if $imagenum > 1 && $wq_app_setting['view_imgnum'] == '1'}-->
                    <span class="wqlisttu1"><i class="wqiconfont2 wqicon2-tupian-copy wqapp_f14 wqm_right2"></i>{$imagenum}</span>
                    <!--{/if}-->
		</div>
            <!--{/if}-->
	<!--{/block}-->
<!--{/if}-->

<!--{if $showmodel == '3'}-->
	<!--{eval $classname = $imagenum == 1 ? "list_pane1" : ($imagenum == 2 ? "list_pane2" : "list_pane3");}-->
	<!--{block return}-->
            <!--{if $imagenum>0}-->
                <div class="{$classname}">
                    <!--{loop $images $k $v}-->
                        <div class="wq-lazyload-container" >
                            <img class="wq_js_delayload" src="{$_G['style'][styleimgdir]}images/wq_dian.jpg" data-src="{$v}">
                        </div>
                    <!--{/loop}-->
                    <!--{if $imagenum > 3 && $wq_app_setting['view_imgnum'] == '1'}-->
                    <span class="wqlisttu2"><i class="wqiconfont2 wqicon2-tupian-copy wqapp_f14 wqm_right2"></i>{$imagenum}</span>
                    <!--{/if}-->
                </div>
            <!--{/if}-->
	<!--{/block}-->
<!--{/if}-->

<!--{eval return $return;}-->
{eval
}

function get_icon_for_list() {
    global $_G, $Tlang, $thread, $showmodel,$wq_app_setting;

}
    <!--{block return}-->
        <!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
           <span class="wqicon_all_14 wqicon_top">$Tlang['4d3aee3cefdbf4b8']</span>
        <!--{/if}-->
        <!--{if $thread['digest'] > 0}-->
            <span class="wqicon_all_14 wqicon_digest">$Tlang['4431e4914edfce71']</span>
        <!--{/if}-->
        <!--{if $thread['attachment'] == 2 && $_G['setting']['mobile']['mobilesimpletype'] == 0 && in_array($showmodel, array("m", "0"))}-->
            <span class="wqicon_all_14 wqicon_tu">$Tlang['d09806a34575d52c']</span>
        <!--{/if}-->
        <!--{if $thread['weeknew']}-->
            <span class="wqicon_all_14 wqicon_xin">$Tlang['de8128f785039560']</span>
        <!--{/if}-->
        <!--{if $thread['heatlevel']}-->
            <span class="wqicon_all_14 wqicon_hot">$Tlang['03a43059cdc3dcad']</span>
        <!--{/if}-->

        <!--{if $thread['folder'] == 'lock'}-->
            <span class="wqicon_all_14 wqicon_gb">$Tlang['beb08d096719774b']</span>
        <!--{elseif $thread['special'] == 1}-->
            <span class="wqicon_all_14 wqicon_vote">$Tlang['a1e86aeac9394d67']</span>
        <!--{elseif $thread['special'] == 2}-->
            <span class="wqicon_all_14 wqicon_sell">$Tlang['0907c7cfc9d2cf2b']</span>
        <!--{elseif $thread['special'] == 3}-->
            <span class="wqicon_all_14 wqicon_reward">$Tlang['655aa530ba4d16cf']</span>
        <!--{elseif $thread['special'] == 4}-->
            <span class="wqicon_all_14 wqicon_activity">$Tlang['2e5409eeacda8839']</span>
        <!--{elseif $thread['special'] == 5}-->
            <span class="wqicon_all_14 wqicon_debate"> $Tlang['5cbc8ce0fb1e25e0']</span>
        <!--{/if}-->
        <!--{if $thread[icon] >= 0}-->
        <span class="wqicon_all_14 wqtop_post_span <!--{if $wq_app_setting['view_style'] == 2}-->wqview_icon_color<!--{/if}-->">{$_G[cache][stamps][$thread[icon]][text]}</span>
            <!--<img src="{STATICURL}image/stamp/{$_G[cache][stamps][$thread[icon]][url]}" alt="{$_G[cache][stamps][$thread[icon]][text]}" align="absmiddle" />-->
        <!--{/if}-->
    <!--{/block}-->

    <!--{eval return $return;}-->
{eval
}

function wq_app_no_content($lang, $msg) {
    global $_G;
}
     <!--{if $msg}-->
     <!--{eval $lang = lang($lang);}-->
     <!--{eval $lang = $lang[$msg];}-->
     <!--{/if}-->
    <!--{block return}-->
        <p class="wqemp" is_content="null"><span class="wqno_con"><img src="{$_G['style']['styleimgdir']}images/wqno_con.png"></span>$lang</p>
    <!--{/block}-->
    <!--{eval return $return;}-->

{eval
}

}
<!--{/if}-->