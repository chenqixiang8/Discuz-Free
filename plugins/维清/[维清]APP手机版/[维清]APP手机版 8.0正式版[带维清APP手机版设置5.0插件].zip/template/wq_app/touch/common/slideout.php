<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['slideout'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{if !empty($myimg)}-->
    <style>.wq-slide-head{background-image: url({$myimg});}</style>
<!--{/if}-->
<div class="wq-slide-warp">
    <div class="wq-slide-head">
        <ul>
            <li>
                <!--{if !$_G['uid']}-->
                    <!--{if $_G['connectguest']}-->
                        <div class="wqhead">
                            <a href="plugin.php?id=wq_qqlogin&mod=login">
                                <img class="wqhead_img" id="head_image" src="{$wq_default_avatar}">
                            </a>
                            <span class="wqhead_login" style="color:{$space[group][color]}">
                            <!--{if $_G['cache']['plugin']['wq_qqlogin']}-->
                               <a href="plugin.php?id=wq_qqlogin&mod=login">&#x5B8C;&#x5584;&#x8D26;&#x53F7;&#x4FE1;&#x606F;</a>
                            <!--{else}-->
                                <a href="javascript:void(0)" class="wq_qqconnect">&#x5B8C;&#x5584;&#x8D26;&#x53F7;&#x4FE1;&#x606F;</a>
                            <!--{/if}-->
                                <a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">&#x9000;&#x51FA;</a>
                            </span>
                        </div>
                    <!--{else}-->
                        <div class="wqhead">
                            <a href="member.php?mod=logging&action=login">
                                <img class="wqhead_img" id="head_image" src="{$wq_default_avatar}">
                            </a>
                            <span class="wqhead_login" style="color:{$space[group][color]}">
                                <a href="member.php?mod=logging&action=login">&#x767B;&#x5F55;</a>
                                <a href="member.php?mod={$_G['setting']['regname']}">&#x6CE8;&#x518C;</a>
                            </span>
                        </div>
                    <!--{/if}-->
                <!--{else}-->
                    <!--{eval
                        $wquserinfo=get_wq_app_userinfo_and_age(array('uid'=>$_G['uid']));
                        $sightml=getuserprofile('sightml');
                    }-->
                    <a href="<!--{if $_G[uid]}-->home.php?mod=space&uid=$_G[uid]&do=profile&mycenter=1<!--{else}-->member.php?mod=logging&action=login<!--{/if}-->" class="wqblock">
                        <img class="wq_img" id="head_image" src="{$wq_my_avatar}" />
                        <h2 class="wqname wqellipsis" >{$_G[username]}</h2>
                        <p class="wqhead_info">
                            <!--{if $wquserinfo['gender']==1}-->
                                <span class="wqgender2 wqman wqm_right5"><i class="wqiconfont2 wqicon2-nan wqapp_f12"></i>{$wquserinfo['age']}</span>
                            <!--{elseif $wquserinfo['gender']==2}-->
                                <span class="wqgender2 wqman wqm_right5"><i class="wqiconfont2 wqicon2-nan wqapp_f12"></i>{$wquserinfo['age']}</span>
                            <!--{else}-->
                                <span class="wqgender2 wqprovince">{$Tlang['a948ddf6cbae92e7']}</span>
                            <!--{/if}-->
                            <!--{if $wquserinfo['resideprovince']}-->
                                <span class="wqprovince">{$wquserinfo['resideprovince']}</span>
                            <!--{/if}-->
                        </p>
                        <p class="wqmenu_autograph wqellipsis"><i class="wqiconfont2 wqicon2-icon wqapp_f12 wqquotes"></i>
                        <!--{if $sightml}-->
                            {$sightml}
                        <!--{else}-->
                            {$Tlang['dad04db205a52b38']}
                        <!--{/if}-->
                        </p>
                    </a>
                    <a href="javascript:;" class="wqbtn_follow"><i class="wqiconfont2 wqicon2-erweima wqapp_f28"></i></a>
                <!--{/if}-->
            </li>
        </ul>
    </div>
    <!--{if $side_menu}-->
        <div class="wq-slide-space" style="height: 0.2rem;"></div>
        <div class="wq-slide-list">
            <ul>
                <!--{loop $side_menu $key $val}-->
                <li><a href="{$wq_app_menulist[$val][menuurl]}"><i class="{$wq_app_menulist[$val][notmenuicon]}"{if $wq_app_menulist[$val][menuicon]} style="color:{$wq_app_menulist[$val][menuicon]}"{/if}></i>{$wq_app_menulist[$val][menuname]}</a></li>
                <!--{/loop}-->
            </ul>
        </div>
    <!--{/if}-->
    <div class="wq-slide-bottom">
        <ul>
            <li><a href="home.php?mod=spacecp&op=index"><i class="wqiconfont2 wqicon2-shezhi1 wqapp_f18"></i>{$Tlang['c1ae0e287c9cf97d']}</a></li>
            <!--{if $_G['cache']['plugin']['wq_space']}-->
                <li><a href="plugin.php?id=wq_space:wq_space"><i class="wqiconfont2 wqicon2-gexing wqapp_f18"></i>{$Tlang['4b7544545b52fbb2']}</a></li>
                <!--{else}-->
                <li><a href="home.php?mod=space&do=notice"><i class="wqiconfont2 wqicon2-tixing2 wqapp_f18"></i>{$Tlang['4cfa49d2e80059bc']}</a></li>
            <!--{/if}-->
            <li class="night-mode"><a href="javascript:;"><i class="wqiconfont2 wqicon2-moon wqapp_f18"></i><span>{$Tlang['401f10a5ae6d2ccd']}</span></a></li>
        </ul>
    </div>
</div>
<div class="wq-slide-mask" style="display:none;"></div>
<div class="nightmask"></div>
<div class="dialogbox" id="slideoutCode" style="height: 390px; width: 240px; display: none; position: fixed; left: 0px; top: 89px; z-index: 120; opacity: 1;">
    <div class="qz_bg">
        <div class="qrcode_wrap width_max100">
            <div class="qrcode_container">

                <img class="qrcode_img" src="{$qrcode_url}">
                <span>
                    <img src="<!--{eval echo avatar($_G['uid'], middle, true);}-->" />
                </span>
            </div>
            <div class="qrcode_code">
                <span><img src="<!--{eval echo avatar($_G['uid'], middle, true);}-->"></span>
                <div class="qrcode_head">
                    <h3>{$_G['username']}</h3>
                    <p>{$Tlang['694af05237e4c3eb']}</p>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript" src="{$_G['style'][styleimgdir]}js/public/wqslideout.js?{VERHASH}" charset="gbk"></script>
<script>
    $(function () {
        $(".wq_qqconnect").click(function(e) {
            window.location = 'member.php?mod=connect';
            $(this).html('&#x4FE1;&#x606F;&#x5B8C;&#x5584;&#x4E2D;&#x8BF7;&#x7B49;&#x5F85;');
            $(this).unbind(e);
        });

        $("#slideoutCode").css({"top": ($(window).height() - $("#slideoutCode").height()) / 2,"left": ($(window).width() - $("#slideoutCode").width()) / 2});

        $('#slideoutCode, .wq-slide-mask').on('touchmove', function (e) {
            if ($('#slideoutCode').is(':visible')) {
                return false;
            } else {
                e.preventDefault();
            }
        });
        $.wqslideout({
            type: 'slide',
            stop: '.slide-stop, #mask, .new_hide, .dialogbox, #oculus',
            click: '.wqicon2-daohang2'
        });

        <!--{if !$nohead_color}-->
            var night = localStorage.getItem('night');
            if (night === 'true') {
                 $('.night-mode span').text('{$Tlang['52166b92d5ac1f79']}');
                 $('.night-mode i').toggleClass('wqicon2-moon wqicon2-taiyang');
            }
        <!--{/if}-->

        $('.night-mode').on('click', function () {
            var night = localStorage.getItem('night') || 'false';
            $('.nightmask').addClass('night');
            setTimeout(function () {
                if (night === 'false') {
                    $('head').append('<link id="nightMode" rel="stylesheet" href="./source/plugin/wq_app_setting/static/style/t1/style.css?{VERHASH}" type="text/css">')
                    localStorage.setItem('night', 'true');
                    $('.night-mode span').text('{$Tlang['52166b92d5ac1f79']}');
                } else {
                    $('#nightMode').remove();
                    localStorage.setItem('night', 'false');
                    $('.night-mode span').text('{$Tlang['401f10a5ae6d2ccd']}');
                }
                $('.night-mode i').toggleClass('wqicon2-moon wqicon2-taiyang');
                setTimeout(function () {
                    $('.nightmask').removeClass('night');
                }, 300);
            }, 970);
        });
    });
</script>
<!--{/if}-->