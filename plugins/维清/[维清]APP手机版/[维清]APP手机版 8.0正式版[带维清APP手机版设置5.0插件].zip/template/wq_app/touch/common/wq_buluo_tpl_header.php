<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['wq_buluo_tpl_header'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{if !empty($_G['inajax'])}-->
<!--{template common/wq_buluoheader_ajax}-->
<!--{else}-->
    <!--{eval $plugin_wq_buluo = !empty($_G['cache']['plugin']['wq_buluo']) ? 1 : 0;}-->
    <!--{if $plugin_wq_buluo}-->
        <!--{eval
            $wq_buluo=$_G['cache']['plugin']['wq_buluo'];
            $wq_buluo[mobile_header]=intval($wq_buluo[mobile_header]);
        }-->
    <!--{/if}-->

     <!--{if $wq_buluo[mobile_header]==1 && (  (CURSCRIPT=='search' && CURMODULE=='group') || ( CURSCRIPT=='plugin' && $mod=='index') || (CURSCRIPT=='plugin' && $mod=='user') || (CURSCRIPT=='group' && CURMODULE=='index'))}-->
        <!--{eval
            $touch_tplid = $_G['setting']['styleid2'];
            loadcache('style_' . $touch_tplid);
            $touch_tpl = $_G['cache']['style_' . $touch_tplid];
            include DISCUZ_ROOT.$touch_tpl['tpldir'].'/php/config.php';
            $set_color=$wq_buluo['mobile_color']?$wq_buluo['mobile_color']:$setting['mobile_color'];

        }-->

        <!--{template common/header}-->
        <link rel="stylesheet" href="template/{$templatename}/wq_buluo_src/font/iconfont.css?{VERHASH}" type="text/css" media="all">
        <link rel="stylesheet" href="{$_G['style'][styleimgdir]}mobile/style.css?{VERHASH}" type="text/css" media="all">
        <link rel="stylesheet" href="{$_G['style'][styleimgdir]}mobile/group.css?{VERHASH}" type="text/css" media="all">
        <script type="text/javascript" src=" ./source/plugin/wq_buluo/static/js/mobile/jquery-1.8.3.min.js?{VERHASH}"></script>
        <script src="{$_G['style'][styleimgdir]}mobile/js/common.js?{VERHASH}" type="text/javascript" charset="gbk"></script>
        <script type="text/javascript" charset="gbk" src="{$_G['style'][styleimgdir]}mobile/js/wq_touch.js"></script>
     <!--{else}-->
         <!--{eval $header_nav='null';}-->
        <!--{template common/wq_buluoheader}-->
    <!--{/if}-->

<!--{/if}-->
<!--{/if}-->