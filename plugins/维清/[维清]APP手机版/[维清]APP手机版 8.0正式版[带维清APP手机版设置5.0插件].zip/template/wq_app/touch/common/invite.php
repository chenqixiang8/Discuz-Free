<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['invite'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{eval $header_nav='null';}-->
<!--{template common/wq_buluo_tpl_header}-->
    <div id="main_messaqge" class="invitation">
        <form id="friendForm" method="post" autocomplete="off" name="invite" id="inviteform" action="misc.php?mod=invite&action=$_GET[action]&id=$id{if $_GET['activity']}&activity=1{/if}">
                    <input type="hidden" name="formhash" value="{FORMHASH}"/>
                    <input type="hidden" name="invitesubmit" value="yes"/>
                    <input type="hidden" name="referer" value="{echo dreferer()}"/>
        <div class="wq_lump_pro">
            <a href="javascript:;" onclick="wq_is_scroll(),popup.close();" class="wq_return">{$Tlang[9c825be7149e5b97]}</a>{$Tlang[adccfbdd21311bbe]}<span class="return_in return_in2 right10">
                <button type="submit" disabled='disabled' id="check_button" class="pn pnc formdialog" style="width:auto;">{$Tlang[3280829519230622]}<font style="display: none;"></font> </button></span>
        </div>
        <div class="usd invitation_member">
            <table border="0" cellspacing="0" cellpadding="0"margin=0 padding=0  id="search_friend"class="clse" >
                <tr>
                    <td id="search_icon"class="wqiconfont wqicon-search f14 group_se"></td>
                    <td class="group_se_img" style="display: none;">
                        <div class="u_c_items" id="select_avatar"></div>
                    </td>
                    <td class="group_se_input"><input type="text" name="username" id="wq_username" class="group_search" value="" placeholder="{$Tlang[38224a4a6fc78c7c]}" autocomplete="off" oninput="initialize(this);"/></td>
                </tr>
            </table>
            <ul class="member_list_li" id="member_list_-1" page='0' style="display: none;overflow-y: auto;">

            </ul>
            <div id="wq_friend_list">

                    <ul id="wq_member_ul" class="cl" style="overflow-y: auto;">
                        <!--{if $at == 1 && $_G['group']['allowat']}-->
                        <li class="member_list">
                            <span class='wq_member_list'><i class="wqiconfont wqicon-down f12 group_arrow wqicon-jiantou"></i>{lang invite_my_follow}</span>
                        </li>
                        <!--{/if}-->
                        <!--{loop $friendgrouplist $groupid $group}-->
                        <li class="member_list ">
                            <p class='wq_member_list' data='$groupid'><i class="wqiconfont f12 group_arrow wqicon-jiantou"></i>$group</p>
                            <ul class="member_list_li" id="member_list_$groupid" page='0' style="display: none">
                            </ul>
                        </li>
                        <!--{/loop}-->
                    </ul>

            </div>
        </div>
      </form>
    </div>
<script type="text/javascript" reload="1">
        $(function(){
            var wq_member_ul = $(window).height() - 94;
            $('#wq_member_ul,#member_list_-1').height(wq_member_ul);
             wq_is_scroll();
        });
        var filterUser={},wq_gids={},selects={};
        function change_show(){
            var checked_num = $('#main_messaqge input:checked').length;
            var hidden_num = $('.hidden_uids').length;
            var total =checked_num+hidden_num;
            var scrollbar=$('#select_avatar').parent();
            if (total > 0) {
                scrollbar.show();
                if (total>4) {
                    scrollbar.css('width',null);
                }else{
                    scrollbar.width(40*total);
                }
                $('#search_icon').hide();
                $('#check_button').attr('disabled', null);
                if (total>1) {
                   scrollbar.scrollLeft(40+scrollbar.scrollLeft());
                   $('#check_button font').show().text('(' + total + ')');
                }else{
                   $('#check_button font').hide();
                }
            } else {
                scrollbar.hide();
                $('#search_icon').show();
                $('#check_button').attr('disabled', 'disabled');
                $('#check_button font').hide();
            }
        }
        $('#member_list_-1').on('click','li',function(){
            var uid = $(this).attr('data');
            if (uid) {
                var avatar=$(this).find('img').attr('src');
                if ($('#wq_user_'+uid).length) {
                   $('#wq_user_'+uid).attr('checked','checked');
                }else{
                   $('#friendForm').append('<input type="hidden" class="hidden_uids" id="wq_user_'+uid+'" name="uids[]" value="'+uid+'"/>');
                }
                change_show();
                $('#select_avatar').append('<span class="item_cell" id="select_avatar_'+uid+'" data="'+uid+'"><img src="'+avatar+'"></span>')
                selects[uid]=true;
                $('#wq_username').val('');
                $('#member_list_-1').hide();
                $('#wq_friend_list').show();
            }
        });
        $('#wq_member_ul').on('change', '.weui_check', function () {
            var uid=$(this).val();
            if ($(this).attr('checked')) {
               selects[uid]=true;
               var avatar= $(this).parent().find('img').attr('src');
               $('#select_avatar').append('<span class="item_cell" id="select_avatar_'+uid+'" data="'+uid+'"><img src="'+avatar+'"></span>')
            }else{
               selects[uid]=false;
               $('#select_avatar_'+uid).remove();
            }
            change_show();
        });


        $('#select_avatar').on('click', '.item_cell', function (){
           var uid=$(this).attr('data');
           var obj=$('#wq_user_'+uid);
           if (obj.length) {
                var type= obj.attr('type')
                if (type=='hidden') {
                    obj.remove()
                }else{
                    obj.attr('checked',null)
                }
           }
           selects[uid]=false;
           $(this).remove();
           change_show();
        });

        function addFilterUser(data) {
            for (var id in data) {
                filterUser[data[id]] = data[id];
            }
            return true;
        }
        <!--{if $inviteduids}-->
         addFilterUser([$inviteduids]);
        <!--{/if}-->

        $('.wq_member_list').click(function () {
            var gid = $(this).attr('data');
            $('#member_list_'+gid).toggle();
            $(this).children('i').toggleClass('wqicon-jiantou wqicon-down');
            if (!$('#member_list_'+gid).attr('status') && !wq_gids[gid]) {
                wq_gids[gid]=true;
                getUser(gid);
            }
        });
        var x=0;
        function getUser(gid,username) {
            gid = isUndefined(gid) ? -1 : parseInt(gid);
            var memberObj=$('#member_list_' + gid);
            var page=parseInt(memberObj.attr('page'));
            page++;
            var username =isUndefined(username) ? '' :username;
            x++;
            var y=x
            $.ajax({
                type: 'POST',
                url: 'home.php?mod=spacecp&ac=friend&op=getinviteuser&inajax=1&page=' + page + '&gid='+ gid +'&at={$at}&' + Math.random(),
                data: {'username':username},
                dataType: 'html'
            }).success(function (s) {
                var data = eval('(' + wqXml(s) + ')');
                var singlenum = parseInt(data['singlenum']);
                var maxfriendnum = parseInt(data['maxfriendnum']);
                var clearlist= addDataSource(data, gid,memberObj,username);
                memberObj.attr('page',page);
                if (singlenum && clearlist < maxfriendnum) {
                    getUser(gid,username);
                }else if(gid!=-1){
                    memberObj.attr('status','1');
                }else if(page==1&&!singlenum&&y==x){
                     memberObj.html('<p class="invitation_empty">{$Tlang[8a2ca1bb517d021c]}��<span>'+username+'</span>��{$Tlang[3a218bde96265cf0]}<p>');
                }
            });
        }
        function initialize(obj){
            var username = $.trim($(obj).val());
            if (username) {
                $('#member_list_-1').attr('page','0').attr('clearlist','0').attr('page','0').show().empty();
                $('#wq_friend_list').hide();
                getUser(-1,username);
            }else{
                $('#member_list_-1').hide();
                $('#wq_friend_list').show();
            }
        }
        function addDataSource(data, gid,listObj,username) {
                var html = '',j=0;
                if (gid!=-1) {
                    $.each(data.userdata, function (i, n) {
                        j++;
                        var checkedHtml=''
                        if (selects[n.uid]) {
                           $('#wq_user_'+n.uid).remove();
                           checkedHtml=' checked="checked" ';
                        }
                        html+= '<li>\n\
                        <a href="javascript:;" class="avt group_menber">\n\
                        <input name="uids[]" '+(filterUser[n.uid]?'disabled="disabled"':'')+' id="wq_user_' + n.uid + '" type="checkbox" value="' + n.uid + '"  class="weui_check" '+checkedHtml+'>\n\
                                        <label class="weui_check_label" for="wq_user_' + n.uid + '">\n\
                                            <p class="group_sign"><i class="weui_icon_checked"></i></p>\n\
                                            <img src="' + n.avatar + '">\n\
                                            <span class="gtoup_title_ov">' + n.username + '</span>\n\
                                        </label> \n\
                            </a>\n\
                        </li>';
                    });
                }else{
                    $.each(data.userdata, function (i, n) {
                        j++;
                        n.username= n.username.replace(username,'<font class="blue">'+username+'</font>')
                        if (filterUser[n.uid]) {
                            html+= '<li>\n\
                                 <a href="javascript:;" class="avt group_menber p_l0">\n\
                                  <img src="' + n.avatar + '">\n\
                                      <span class="gtoup_title_ov">' + n.username + '</span>\n\
                                    </a><em class="y group_menber_grey">{$Tlang[7dd3a6e02eb38935]}</em>\n\
                               </li>';
                        }else if(selects[n.uid]){
                            html+= '<li>\n\
                            <a href="javascript:;" class="avt group_menber p_l0">\n\
                                    <img src="' + n.avatar + '">\n\
                                    <span class="gtoup_title_ov">' + n.username + '</span>\n\
                                </a><em class="y group_menber_grey">{$Tlang[15ceb390db51b148]}</em>\n\
                            </li>';
                        }else{
                            html+= '<li data="' + n.uid + '">\n\
                            <a href="javascript:;" class="avt group_menber p_l0">\n\
                                    <img src="' + n.avatar + '">\n\
                                    <span class="gtoup_title_ov">' + n.username + '</span>\n\
                                </a>\n\
                            </li>';
                        }
                    });
                }
                var clearlist= listObj.attr('clearlist');
                clearlist=clearlist?parseInt(clearlist):0;
                listObj.append(html).attr('clearlist',clearlist+j);
                return clearlist+j;
        }
</script>
<!--{template common/wq_buluo_tpl_footer}-->
<!--{/if}-->