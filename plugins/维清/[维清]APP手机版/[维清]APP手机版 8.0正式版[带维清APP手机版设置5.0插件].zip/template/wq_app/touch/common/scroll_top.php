<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['scroll_top'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<script>
        var {$wq_scroll_top}_top =  $('#{$wq_scroll_top}').offset().top;
        var {$wq_scroll_top}_width = $('#{$wq_scroll_top}').width();
        var {$wq_scroll_top}_height = $('#{$wq_scroll_top}').outerHeight(true);
       $(window).scroll(function () {
            var  m_st = $(document).scrollTop();
            if (m_st >= {$wq_scroll_top}_top) {
                if ($('#{$wq_scroll_top}_height_div').length) {
                    $('#{$wq_scroll_top}_height_div').show();
                } else {
                   $('#{$wq_scroll_top}').after('<div id="{$wq_scroll_top}_height_div" style="height:' + {$wq_scroll_top}_height + 'px"></div>');
                }
                $('#{$wq_scroll_top}').attr('style', 'position: fixed;top: 0px;z-index:8;margin-top:0px; width:' + {$wq_scroll_top}_width + 'px;');
            } else {
                $('#{$wq_scroll_top}_height_div').hide();
                $('#{$wq_scroll_top}').attr('style', '');
            }
        });
</script>
<!--{/if}-->