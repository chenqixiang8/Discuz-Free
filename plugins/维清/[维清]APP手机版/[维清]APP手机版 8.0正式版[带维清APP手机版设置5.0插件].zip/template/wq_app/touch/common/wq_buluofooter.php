<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['wq_buluofooter'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{hook/global_footer_mobile}-->
<span id="hidden_utf8" style="display: none">&#x9644;&#x4EF6;&#x8D2D;&#x4E70;&#x6210;&#x529F;&#xFF0C;&#x5F00;&#x59CB;&#x4E0B;&#x8F7D;</span>
<div id="mask" style="display:none;"></div>
<div id="popup_fullscreen" class="ipagen" style="display: none;position: fixed; bottom: 0px; left: 0px">
    <div class="ptitle">
        <span id="popup_title"></span><i id="popup_hidden" class="wqiconfont wqicon-icon32 tj_close"></i>
    </div>
    <div class="pcontent" id="popup_content"></div>
</div>
<div id="popup_grade" style="display:none;"></div>
<div id="masking" style="display: none; width: 100%; height: 100%; position: fixed; top: 0px; left: 0px; opacity: 0.6; z-index: 100; background: black;"></div>
<script language="javascript">
<!--{if !$_G[uid]}-->
    function wq_setcookie(name, value, time) {
        var exp = new Date();
        exp.setTime(exp.getTime() + time * 1000);
        document.cookie = name + "=" + escape(value) + ";expires=" + exp.toGMTString();
    }
    function succeedhandle_loginform(url, msg, param) {
        if (param.username) {
            wq_setcookie('wq_touch_login', param.username, 15768000);
        }
    }
<!--{/if}-->
    $(function () {
        $('#popup_hidden').on('click', function () {
            $('.my_rate,#popup_fullscreen').hide();
            $("#view_big,header,.page,.footer,.h50,#wq_sign_img,a[class='scrolltop']").show();
            setTimeout(function () {
                $('body,html').removeClass('wq_ovhidden');
                $(window).scrollTop(scroll_Top)
            }, 800);
        });
    });
</script>
<!--{if $wq_footer_hide!='1'}-->
<!--{eval $useragent = strtolower($_SERVER['HTTP_USER_AGENT']);$clienturl = ''}-->

<!--{if !$nofooter}-->
<div class="footer">
    <div>
        <!--{if !$_G[uid] && !$_G['connectguest']}-->
        <a href="forum.php">{lang mobilehome}</a> | <a href="member.php?mod=logging&action=login" title="{lang login}">{lang login}</a> | <a href="<!--{if $_G['setting']['regstatus']}-->member.php?mod={$_G[setting][regname]}<!--{else}-->javascript:;" style="color:#D7D7D7;<!--{/if}-->" title="{$_G['setting']['reglinkname']}">{lang register}</a>
        <!--{else}-->
        <a href="home.php?mod=space&uid={$_G[uid]}&do=profile&mycenter=1">{$_G['member']['username']}</a> , <a href="member.php?mod=logging&action=logout&formhash={FORMHASH}&handlekey=logout" title="{lang logout}" class="dialog">{lang logout}</a>
        <!--{/if}-->
    </div>
    <div>
        <a href="javascript:;">{lang mobile2version}</a> |
        <a href="{$_G['setting']['mobile']['nomobileurl']}">{lang nomobiletype}</a>
        <!--{if $wq_touch_setting['view_app_download'] && $clienturl}--> |<a href="$clienturl">{lang clientversion}</a><!--{/if}-->
		<!--{if $_G['setting']['statcode']}--> |{$_G['setting']['statcode']}<!--{/if}-->
    </div>
    <p>&copy; {$_G['setting']['sitename']}</p>
</div>
<!--{/if}-->
<!--{if defined('IN_WQ_TOUCH')}-->
<div class="h50"></div>
<!--{if $wq_footbar!=1}-->
<div id="wq_footer_nav" class="footbar b_dark">
    <ul>
        <li class="foot_forum">
            <a id="wq_ceshi" href="forum.php?forumlist=1" ><i class="wqiconfont wqicon-forum f20"></i>{$Tlang['3ab06b120349331c']}</a>
        </li>
        <!--{eval $wq_userinfo = _buluo_get_tips();}-->
        <span class="avatar footbar_user b_dark_right">
            <a href="{$wq_userinfo['url']}">
                <img src="$wq_my_avatar" style="width:32px;height:32px;"/>
            </a>
            <!--{if $wq_userinfo['newpm'] > 0}-->
            <span class="today_foot right0">{$wq_userinfo['newpm']}</span>
            <!--{/if}-->
        </span>
        <li class="foot_post">
            <!--{if $_GET['mod'] == 'forumdisplay' && $_G['fid'] > 0}-->
            <a href="forum.php?mod=post&action=newthread&fid={$_G['fid']}&mobile=2" id="newspecial"><i class="wqiconfont wqicon-post f20"></i>{lang send_threads}</a>
            <!--{else}-->
            <a href="forum.php?mod=misc&action=nav" ><i class="wqiconfont wqicon-post f20"></i>{lang send_threads}</a>
            <!--{/if}-->
        </li>
        <span class="footbar_menu b_dark_left">
            <a href="javascript:sharenv('share_qt')"><i class="wqiconfont wqicon-share f28 m_tf2"></i></a>
        </span>
    </ul>
    <!--<span class="back_home"><a href="forum.php"><i class="wqiconfont wqicon-index_1 f26"></i></a></span>-->
</div>
<!--{/if}-->
<div id="sharenv" class="menu_pop share_in" style="display:none" onclick="sharenv('hide')">
    <div class="menu_pop">
        <img src="{$_G['style']['styleimgdir']}mobile/images/share_bg.png">
    </div>
</div>
<div id="share_other" class="sharepop share_qt" style="display:none" >
    <div onclick="sharenv('hide')" style="width: 100%;height: 100%"></div>
    <div class="share_fx">
        <p onclick="sharenv('share_qt')">{$Tlang['4d3ba91835492030']}</p>
        <ul onclick="sharenv('share_qt')">
            <li><a href="javascript:;" onclick="menu_pop_show()"><span></span>{$Tlang['fd32f2cf594cdeb8']}</a></li>
            <li><a href="javascript:;" onclick="jiathis_mh5.sendTo('qzone');"><span class="fx_qq"></span>{$Tlang['ed362969fb869003']}</a></li>
            <li><a href="javascript:;" onclick="jiathis_mh5.sendTo('tsina');"><span class="fx_qqkj"></span>{$Tlang['5b9f34f4cca87c47']}</a></li>
            <li><a href="javascript:;" onclick="jiathis_mh5.sendTo('tqq');"><span class="fx_sina"></span>{$Tlang['8bd4cabbda61b3f9']}</a></li>
        </ul>
        <!-- JiaThis Button BEGIN -->
        <script type="text/javascript" src="http://v3.jiathis.com/code/jiathis_m.js?{VERHASH}" charset="utf-8"></script>
        <!-- JiaThis Button END -->
                <p onclick="sharenv('hide')">{$Tlang['9c825be7149e5b97']}</p>
                </div>
</div>
<script>
               function sharenv(action) {
                <!--{if defined('WQ_IN_WECHAT')|| defined('WQ_IN_QQ')}-->
                    if(action == 'share_qt') {
                        $('#sharenv').fadeIn(350);
                    } else {
                        $('#sharenv').fadeOut(350);
                    }
                <!--{else}-->
                    if (action == 'share_qt') {
                        $('#share_other').fadeIn(350);
                        $(".share_fx").slideDown();
                    } else {
                        $(".share_fx").slideUp();
                        $('#share_other').fadeOut(350);
                    }
                <!--{/if}-->
                }

     function menu_pop_show() {
         popup.open('<div class=\"ass_fl\"><p>&#x8BF7;&#x7528;&#x5FAE;&#x4FE1;&#x6253;&#x5F00;&#x672C;&#x9875;&#x9762;&#x5E76;&#x70B9;&#x53F3;&#x4E0A;&#x89D2;&#x83DC;&#x5355;&#x5206;&#x4EAB;</p><p><button type=\"button\" class=\"button\" onclick=\"popup.close();\">&#x786E;&#x5B9A;</button></p></div>');
     }
</script>
<!--{/if}-->
<!--{if $_G[uid] && !isset($_G['cookie']['checkpm'])}-->
<script type="text/javascript" src="home.php?mod=spacecp&ac=pm&op=checknewpm&rand=$_G[timestamp]"></script>
<!--{/if}-->
<!--{/if}-->
</body>
</html>
<!--{eval updatesession();}-->
<!--{if defined('IN_MOBILE')}-->
<!--{eval output();}-->
<!--{else}-->
<!--{eval output_preview();}-->
<!--{/if}-->

<!--{/if}-->