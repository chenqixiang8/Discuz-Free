<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['wq_buluoupload_image'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{eval  $wq_buluo = _buluo_get_wq_buluo_touch();}-->
<ul id="imglist" class="post_imglist cl bl_line" style="display:none">
    <li id="increase" onclick="$('#filedata').click();" ><i class="wqiconfont wqicon-increase"></i></li>
</ul>
<script type="text/javascript" src="$_G['style'][styleimgdir]mobile/thirdparty/buildfileupload.js?{VERHASH}"></script>
<script>
        var url;
        var upload_image;
        var uploadsuccess_forum;
        var imgexts = typeof imgexts == 'undefined' ? 'jpg, jpeg, gif, png' : imgexts;
        var STATUSMSG = {
            '-1': '{lang uploadstatusmsgnag1}',
            '0': '{lang uploadstatusmsg0}',
            '1': '{lang uploadstatusmsg1}',
            '2': '{lang uploadstatusmsg2}',
            '3': '{lang uploadstatusmsg3}',
            '4': '{lang uploadstatusmsg4}',
            '5': '{lang uploadstatusmsg5}',
            '6': '{lang uploadstatusmsg6}',
            '7': '{lang uploadstatusmsg7}(' + imgexts + ')',
            '8': '{lang uploadstatusmsg8}',
            '9': '{lang uploadstatusmsg9}',
            '10': '{lang uploadstatusmsg10}',
            '11': '{lang uploadstatusmsg11}'
        };
        var maxheight = parseInt('$wq_buluo[maxheight]') < 1 ? 0 : parseInt('$wq_buluo[maxheight]');
        var maxwidth = parseInt('$wq_buluo[maxwidth]') < 1 ? 0 : parseInt('$wq_buluo[maxwidth]');
        function picture(uploadsuccess, id, name, url) {
            var uploadurl = url ? url : 'misc.php?mod=swfupload&operation=upload&type=image&inajax=yes&infloat=yes&simple=2';
            popup.open('<img src="' + IMGDIR + '/imageloading.gif">');
            var wq_file = new Array();
            $.each(document.getElementById(id).files, function (i, n) {
                wq_file[0] = n;
                $.buildfileupload({
                    uploadurl: uploadurl,
                    files: wq_file,
                    uploadformdata: {uid: "$_G[uid]", hash: "{echo  md5(substr(md5($_G[config][security][authkey]), 8).$_G[uid])}"},
                    uploadinputname: name,
                    maxfilesize: "$swfconfig[max]",
                    maxheight: maxheight,
                    maxwidth: maxwidth,
                    success: uploadsuccess,
                    error: function () {
                        popup.open('{lang uploadpicfailed}', 'alert');
                    }
                });
            });
        }

        $(document).on('change', '#filedata', function () {
            if ($(this).val()) {
                picture(uploadsuccess_forum, 'filedata', 'Filedata', typeof (url) == 'undefined' ? '' : url);
            }
        });
        $(document).on('click', '#file_button', function () {

            if ($('#imglist li').length == 1 || $('#imglist').is(':visible')) {
                uploadsuccess_forum = upload_image;
                $('#filedata').click();
            } else {
                if ($('.cellphone_expression').is(':visible')) {
                    $('.wqexpression').click();
                }
                $('#imglist').show();
                $('#upload_icon').addClass('blue');
            }
        });
        $(document).on('click', '.del', function () {
            var obj = $(this);
            if (obj.attr('aid')) {
                var url = 'forum.php?mod=ajax&action=deleteattach&inajax=yes&aids[]=' + obj.attr('aid');
                var dada = {}
                var type = 'GET';
            } else {
                var url = 'home.php?mod=spacecp&ac=album&op=editpic&albumid=0&subop=delete';
                var type = 'POST';
                var data = {'editpicsubmit': true, 'inajax': '1', 'formhash': '{FORMHASH}'};
                data['ids[' + obj.attr('picid') + ']'] = obj.attr('picid');
            }
            $.ajax({
                type: type,
                url: url,
                data: data,
            }).success(function (s) {
                obj.parent().remove();
                if ($('#imglist li').length - 1 == 0) {
                    $('.today_p').hide();
                }
                if (obj.attr('success_call')) {
                    eval(obj.attr('success_call'));
                }
                $('.today_p').text($('#imglist li').length - 1);
            }).error(function () {
                popup.open('{lang networkerror}', 'alert');
            });
            return false;
        });
</script>
<!--{/if}-->