<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['footer'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{hook/global_footer_mobile}-->
<!--{if (CURSCRIPT=="forum" && CURMODULE=="viewthread" && ($wq_app_setting['view_style'] == 1 || $wq_app_setting['view_style'] == 2 &&  $_G[forum_thread][special] == 4)) || (CURSCRIPT=="portal" && CURMODULE=="view")}-->
    <div class="wqheight88rem"></div>
<!--{elseif $space['uid'] && $space['uid'] != $_G['uid']}-->
    <div class="wqheight47"></div>
<!--{/if}-->
<!--{if !$nonav}-->
    <!--{template common/slideout}-->
<!--{/if}-->
<div id="mask" style="display:none; cursor:pointer; -webkit-tap-highlight-color:transparent;"></div>
<div class="dialogbox new_dialogbox" style="height: 107px; width: 280px; display: block; position: fixed; left: 47.5px; top: 280px; z-index: 120; opacity: 1;display:none">
    <div class="wqshield_notice">
        <div class="wqshield_con">
            <input name="operations[]" type="hidden" value="delete"/>
            <p>{$Tlang['c0926623ade2bf2d']}</p>
        </div>
        <p class="wqbtn_can wqnew_top">
            <a href="javascript:;" class="wqeject_cancel new_cancel wqnew_right">{lang cancel}</a>
            <a href="javascript:;" class="wqdetermine new_cancel">{lang confirms}</a>
        </p>
    </div>
</div>
<div class="cancel-mask" style="display:none;"></div>
<!--{if $_GET['mod'] == 'viewthread' || $_GET['do'] == 'album' && $_GET['picid']}-->
    <!--{eval $canceltype='1';}-->
<!--{elseif $_GET['do'] == 'blog' && $_GET['picid']}-->
    <!--{eval $canceltype='2';}-->
<!--{elseif $_GET['mod'] == 'view' && $_GET['op'] != 'edit' || ($_GET['do'] == 'wall')}-->
    <!--{eval $canceltype='3';}-->
<!--{else}-->
    <!--{eval $canceltype='4';}-->
<!--{/if}-->
<div id="popup_fullscreen" class="wqipagen" style="display: none; position:fixed; bottom:0px; left:0px;">
    <div class="wqrate_pcontent" id="popup_content"></div>
</div>
<div id="popup_grade" style="display:none;"></div>
<div class="wqapp_back_top" style="display: none;">
    <span class="wqapp_iocn_back"><i class="wqiconfont2 wqicon2-zhiding1"></i></span>
</div>
<div style="display: none;"><!--{if $_G['setting']['statcode']}-->{$_G['setting']['statcode']}<!--{/if}--></div>
<!--{if !$nofooter && $foot_menu[num]>0}-->
    <div class="wqfooter {if $foot_menu[num]==4}wqfooter_4{elseif $foot_menu[num]==3}wqfooter_3{elseif $foot_menu[num]==2 || $foot_menu[num]==1}wqfooter_2{/if} wqapp_f14 wqnew_top">
        <ul>
            <!--{eval $urls=wq_app_setting_get_footer_url();}-->

            <!--{loop $foot_menu[foot] $key $val}-->
                <!--{if !$val}-->
                    <!--{eval continue;}-->
                <!--{/if}-->

                <!--{eval
                    $footurl= in_array(strtolower(substr($wq_app_menulist[$val][menuurl], 0, 6)), array('http:/', 'https:', 'ftp://'))?$wq_app_menulist[$val][menuurl]:$_G['siteurl'].$wq_app_menulist[$val][menuurl];
                    $footurl=trim(str_replace(array("&mobile=2","?mobile=2"),"",$footurl));
                }-->
                <li><a href="{$wq_app_menulist[$val][menuurl]}" <!--{if in_array($footurl,$urls)}-->class="wqapp_color"<!--{/if}-->><i class="{if in_array($footurl,$urls)}{$wq_app_menulist[$val][menuicon]}{else}{$wq_app_menulist[$val][notmenuicon]}{/if} wqapp_f22"></i><br/>{$wq_app_menulist[$val][menuname]}</a></li>
            <!--{/loop}-->
            <!--{if $foot_menu[num]==1}-->
                <li>
                    <!--{eval $footurl=trim($_G['siteurl'].'home.php?mod=space&do=profile&mycenter=1');}-->
                    <a <!--{if in_array($footurl,$urls)}-->class="wqapp_color"<!--{/if}-->  href="<!--{if $_G[uid]}-->home.php?mod=space&do=profile&mycenter=1<!--{else}-->member.php?mod=logging&action=login<!--{/if}-->"><i class="wqiconfont2 wqicon2-wode<!--{if in_array($footurl,$urls)}-->2<!--{/if}-->  wqapp_f22"></i><br/>&#x6211;&#x7684;</a>
                </li>
            <!--{/if}-->
        </ul>
    </div>
    <!--{if $footerSlide}-->
        <script>
            $(function () {
                var windowTop = {
                    start: $(document).scrollTop(),
                    scrolls: $(document).scrollTop(),
                    isScrolling: false
                };

                var set, reset;

                $(document).on('scroll', throttle(function() {
                    var toggle = function () {
                        clearTimeout(set);
                        clearTimeout(reset);
                        if (windowTop.scrolls == $(document).scrollTop()) {
                            if (windowTop.isScrolling) {
                                windowTop.isScrolling = false;
                                if (windowTop.scrolls > windowTop.start) {
                                    windowTop.start = windowTop.scrolls;
                                    reset = setTimeout(function () {
                                        $('.wqfooter').css({'transition':'0.2s','transform':'translate(0,0px)'});
                                    }, 2000);
                                } else {
                                    windowTop.start = windowTop.scrolls;
                                    $('.wqfooter').css({'transition':'0.2s','transform':'translate(0,0px)'});

                                }
                            }
                        } else {
                            windowTop.isScrolling = true;
                            if (windowTop.scrolls < $(document).scrollTop()) {
                                $('.wqfooter').css({'transition':'0.2s','transform':'translate(0,49px)'});
                            }
                            windowTop.scrolls = $(document).scrollTop();
                            set = setTimeout(toggle, 500);
                        }
                    };
                    toggle();
                }, 500));
            });
        </script>
    <!--{else}-->
        <div class="wqheight47"></div>
    <!--{/if}-->
<!--{/if}-->
<!--{if $_G[uid] && !isset($_G['cookie']['checkpm'])}-->
<script type="text/javascript" src="home.php?mod=spacecp&ac=pm&op=checknewpm&rand=$_G[timestamp]"></script>
<!--{/if}-->
<script type="text/javascript" reload="1">
    $(function () {
        $("body").on('click','.new_button', function () {
            $(this).parents('.new_div').openmenu();
        });

        $('img').each(function(){
            if($(this).attr('smilieid')){
                $(this).addClass('wq_smilieimg');
            }
        });

        $(document).on("click", ".wqheader .wqcancel", function () {
            if (!$(this).hasClass("new_hidden2")) {
                if(location.href.indexOf('ac=upload&albumid') != -1){
                    if($('.wq_updateto').is(':hidden')){
                        $('.wqdrop_upload_operation').show();
                        $(".cancel-mask").show();

                    } else {
                        $('.wq_updateto').hide();
                        $('.wqchoice_upload_photos,.wqlist_upload_photos,.wqseparate,.uploadtitle').show();
                    }

                }else{
                    $(".new_dialogbox").show();
                    $(".cancel-mask").show();
                    $('.new_dialogbox').css('z-index','121');
                }
            } else {
                $('#view_big').show();
                $('#popup_fullscreen, .my_rate').hide();
                    $(window).scrollTop(scroll_Top)
            }
        });

        var canceltype = '$canceltype';
        $("body").on("click", ".new_cancel:eq(1)", function (e) {
            e.preventDefault();
            var h = location.href;

            if (canceltype == '1') {
                $("#popup_fullscreen, .new_list, .new_lump, .new_dialogbox, .cancel-mask").hide();
                $('.wqposts_atom, .wqpost_view_img, #view_big').show();
                $(window).scrollTop(scroll_Top);

            } else if (canceltype == '2') {
                $('.wqindex_list.wqmessage').show();
                $(".new_dialogbox2,.wqadmin_eject,.new_dialogbox, .cancel-mask").hide();
            } else if (canceltype == '3') {
                $('.postlist, .wqposts_atom, .wqmessage').show();
                $(".new_list, .new_lump, .new_dialogbox2, .new_dialogbox, .cancel-mask").hide();
                $(window).scrollTop(scroll_Top);
            } else {
                history.back();
            }
        });

        $("body").on("click", ".new_cancel:eq(0)", function (e) {
            $(".new_dialogbox").hide();
            $(".cancel-mask").hide();
        });

        var width = ($(document).width() - $(".new_dialogbox").width()) / 2;
        var height = ($(window).height() - $(".new_dialogbox").height()) / 2;
        $(".new_dialogbox").css({"left": width, "top": height * 5 / 9});

        $('.my_post_roll a').on('click',function(e){
           e.preventDefault();
           var href= $(this).prop('href');
           location.replace(href);
        });


        $('body').on('touchmove', '#mask, .new_hide, .cancel-mask, .wqsum_mask', function (e) {
            e.preventDefault();
        });

        if (!parseInt("$_G[uid]")) {
            $('.notlogged').removeClass('dialog');
            $('.notlogged').removeClass('formdialog');
            $('.notlogged').removeClass('wqfav-button');
            var status = 0;
            $('body').on('touchstart', '.notlogged', function (e) {
                status = 1;
            });
            $('body').on('touchmove', function (e) {
                status = 0;
            });
            $('body').on('touchend', '.notlogged', function (e) {
                if (status == 1) {
                    if ($(this).hasClass('dialog')) $(this).removeClass('dialog');
                    if ($(this).hasClass('formdialog')) $(this).removeClass('formdialog');
                    if ($(this).hasClass('wqfav-button')) $(this).removeClass('wqfav-button');
                    popup.open('<div class="wqshield_notice"><div class="wqshield_con wqlogin_prompt">{$Tlang['d66405b4f8b4698b']}</div><div class="wqbtn_can wqnew_top"><a href="javascript:;" onclick="popup.close();"  class="wqeject_cancel">{$Tlang['9c825be7149e5b97']}</a><button class="wqdetermine" onclick="location.href = \'member.php?mod=logging&action=login\';">{$Tlang['387e9a577ee04ca3']}</button></div></div>');
                    status = 0;
                }
                return false;
            });
        }
    });
</script>
</body>
</html>

<!--{eval
	$havedomain = implode('', $_G['setting']['domain']['app']);
	wq_app_get_domain();
}-->

<!--{if $_G['setting']['rewritestatus'] || !empty($havedomain)}-->
    <!--{eval
        $content = ob_get_contents();
        $content = output_replace($content);
        ob_end_clean();
        $_G['gzipcompress'] ? ob_start('ob_gzhandler') : ob_start();
        echo $content;
     }-->
<!--{/if}-->


<!--{eval updatesession();}-->
<!--{if !defined('IN_API')}-->
<!--{eval output();}-->
<!--{else}-->
<!--{eval "111";}-->
<!--{/if}-->

<!--{/if}-->