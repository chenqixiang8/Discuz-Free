<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['header'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{eval include DISCUZ_ROOT.'./template/wq_app/php/config.php';}-->
<!--{eval include_once DISCUZ_ROOT.'./template/wq_app/php/function_header.php';}-->
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<meta http-equiv="Cache-control" content="{if $_G['setting']['mobile'][mobilecachetime] > 0}{$_G['setting']['mobile'][mobilecachetime]}{else}no-cache{/if}" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0">
<!--<meta name="apple-mobile-web-app-capable" content="yes"/>
<meta name="apple-touch-fullscreen" content="yes"/>-->
<link rel="apple-touch-icon-precomposed" sizes="57x57" href="{$_G['style'][styleimgdir]}$wq_app_setting[desktop_name]/applogo57.png">
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="{$_G['style'][styleimgdir]}$wq_app_setting[desktop_name]/applogo114.png">
<link rel="apple-touch-icon-precomposed" sizes="152x152" href="{$_G['style'][styleimgdir]}$wq_app_setting[desktop_name]/applogo152.png">
<meta name="format-detection" content="telephone=no" />
<meta name="full-screen" content="yes">
<meta name="x5-fullscreen" content="true">
<meta name="browsermode" content="application">
<meta name="x5-page-mode" content="app">
<meta name="keywords" content="{if !empty($metakeywords)}{echo dhtmlspecialchars($metakeywords)}{/if}" />
<meta name="description" content="{if !empty($metadescription)}{echo dhtmlspecialchars($metadescription)} {/if}" />
<base href="{$_G['siteurl']}" />
<title><!--{if !empty($navtitle)}-->$navtitle<!--{/if}--></title>
<script type="text/javascript" src="{$_G['style'][styleimgdir]}js/thirdparty/flexible.js?{VERHASH}" charset="gbk"></script>
<script type="text/javascript" src="{$_G['style'][styleimgdir]}js/thirdparty/flexible_css.js?{VERHASH}" charset="gbk"></script>
<!--<link rel="stylesheet" href="{STATICURL}image/mobile/style.css" type="text/css">-->
<link rel="stylesheet" href="{$_G['style'][styleimgdir]}style/mui.min.css?{VERHASH}" type="text/css">
<link rel="stylesheet" href="{$_G['style'][styleimgdir]}style/mui.picker.min.css?{VERHASH}" type="text/css">
<!--<link rel="stylesheet" href="{$_G['style'][styleimgdir]}style/app.css?{VERHASH}" type="text/css">-->
<link rel="stylesheet" href="{$_G['style'][styleimgdir]}style/common.css?{VERHASH}" type="text/css">
<!--{eval echo wq_app_loadcsstemplate();}-->
<link rel="stylesheet" href="{$_G['style'][styleimgdir]}font/iconfont.css?{VERHASH}" type="text/css">
<!--{if !$nohead_color}-->
    <!--{if $_G[uid] && isset($mysetting[myextstyle]) && $mysetting[myextstyle] != '0' && $myextstyle}-->
    <link rel="stylesheet" id="css_extstyle" type="text/css" href="{$mysetting[myextstyle]}style.css?{VERHASH}" />
    <!--{elseif $wq_app_defaultextstyle}-->
    <link rel="stylesheet" id="css_extstyle" type="text/css" href="{$wq_app_defaultextstyle}style.css?{VERHASH}" />
    <!--{/if}-->
<!--{/if}-->
<!--{if $wq_app_setting['icon_url']}-->
    <link rel="stylesheet" type="text/css" href="{$wq_app_setting['icon_url']}?{VERHASH}" />
<!--{/if}-->
<script src="{$_G['style'][styleimgdir]}js/public/jquery-1.8.3.min.js?{VERHASH}" charset="gbk"></script>
<script type="text/javascript">var STYLEID = '{STYLEID}', STATICURL = '{STATICURL}', IMGDIR = '{IMGDIR}', VERHASH = '{VERHASH}', charset = '{CHARSET}', discuz_uid = '$_G[uid]', cookiepre = '{$_G[config][cookie][cookiepre]}', cookiedomain = '{$_G[config][cookie][cookiedomain]}', cookiepath = '{$_G[config][cookie][cookiepath]}', showusercard = '{$_G[setting][showusercard]}', attackevasive = '{$_G[config][security][attackevasive]}', disallowfloat = '{$_G[setting][disallowfloat]}', creditnotice = '<!--{if $_G['setting']['creditnotice']}-->$_G['setting']['creditnames']<!--{/if}-->', defaultstyle = '$_G[style][defaultextstyle]', REPORTURL = '$_G[currenturl_encode]', SITEURL = '$_G[siteurl]', JSPATH = '$_G[setting][jspath]',CURMODULE='{CURMODULE}',CURSCRIPT='{CURSCRIPT}',formhash = "{FORMHASH}",sourceurl="{$sourceurl}"; </script>
<script type="text/javascript" src="{$_G['style'][styleimgdir]}js/thirdparty/jscache.js?{VERHASH}" charset="{CHARSET}"></script>
<script type="text/javascript" src="{$_G['style'][styleimgdir]}js/public/common.js?{VERHASH}" charset="gbk"></script>
<script type="text/javascript" src="{$_G['style'][styleimgdir]}js/public/wq_app.js?{VERHASH}" charset="gbk"></script>
<script type="text/javascript" src="{$_G['style'][styleimgdir]}js/public/wq_utils.js?{VERHASH}" charset="gbk"></script>
<script>
    <!--{if !$nohead_color}-->
    (function () {
        var night = localStorage.getItem('night')
        if (night === 'true') {
            $('head').append('<link id="nightMode" rel="stylesheet" href="./source/plugin/wq_app_setting/static/style/t1/style.css?{VERHASH}" type="text/css">')
        }

        if (window.devicePixelRatio && devicePixelRatio >= 2 && navigator.userAgent.toLowerCase().match(/iphone/i) == "iphone") {
            document.getElementsByTagName('html')[0].className = 'retina';
	}
    })()
    <!--{/if}-->

    JC.VERSION = '{VERHASH}';
    JC.file('thirdparty/mui.min.js');
    JC.file('thirdparty/mui.picker.min.js');
    JC.file('thirdparty/muidata.js');
    JC.file('thirdparty/swipe.js');
    JC.file('thirdparty/iscroll.js');
    JC.run();
</script>
<!--{template common/wechat_share}-->
<!--<link rel="stylesheet" href="template/wq_app/style/t1/style.css?{VERHASH}" type="text/css">-->
</head>

<body class="bg">
    <div class="wq_load_con" style="position: relative; z-index: 999">
        <div class="wq_load_bg"></div>
        <div class="weui_toast wq_load_box"><div class="weui_loading"><div class="weui_loading_leaf weui_loading_leaf_0"></div><div class="weui_loading_leaf weui_loading_leaf_1"></div><div class="weui_loading_leaf weui_loading_leaf_2"></div><div class="weui_loading_leaf weui_loading_leaf_3"></div><div class="weui_loading_leaf weui_loading_leaf_4"></div><div class="weui_loading_leaf weui_loading_leaf_5"></div><div class="weui_loading_leaf weui_loading_leaf_6"></div><div class="weui_loading_leaf weui_loading_leaf_7"></div><div class="weui_loading_leaf weui_loading_leaf_8"></div><div class="weui_loading_leaf weui_loading_leaf_9"></div><div class="weui_loading_leaf weui_loading_leaf_10"></div><div class="weui_loading_leaf weui_loading_leaf_11"></div></div></div>
    </div>
<!--{hook/global_header_mobile}-->
<!--{if $wq_app_setting && $wq_app_setting['open_advertisement'] == '1'}-->
    <div class="pay_gz" id="wechatguide" style="display:none;">
        <span class="close_gz"><a href="javascript:;" id="hidewechatguide"><i class="wqiconfont2 wqicon2-guanbi1 wqapp_f22"></i></a></span>
        <a href="$wq_app_setting[advertisement_link]">
            <span class="gz_logo"><img src="$wq_app_setting[advertisement_logo]"></span>
            <span class="text">
                $wq_app_setting[advertisement_title]
                <br/><span class="des">$wq_app_setting[advertisement_overview]</span>
            </span>
            <span class="promptly_gz">$wq_app_setting[advertisement_button]</span>
        </a>
    </div>
<!--{/if}-->

<div class="wqadd_desktop_warp" style="display: none;">
    <div class="wqadd_desktop">
        <div class="wq_appminlogo"><img src="{$_G['style'][styleimgdir]}$wq_app_setting[desktop_name]/applogo114.png"></div>
        <div class="wq_appmincon">
            <span style="font-size:14px; color: #f7a00a;">{$Tlang['8011898639f3a306']}</span>
            <br/>{$Tlang['f7d1f92691761fd4']}"<i class="wqiconfont2 wqicon2-upload"></i>"<br/>{$Tlang['b08bdf4880e94971']}
        </div>
    </div>
    <span class="wqdesktop_arrow"></span>
    <span class="wqdesktop_close"><i class="wqiconfont2 wqicon2-guanbi1 wqapp_f18"></i></span>
</div>

<div class="wqsum_mask slide-stop" style="display: none;">
    <div class="wqright_slide">
        <img src="{$_G['style'][styleimgdir]}images/wqright_slide.png">
    </div>
</div>
<script>
    var is_close_showtips = parseInt('{$wq_app_setting[is_close_showtips]}');

    function wq_load_comp() {
        $('.wq_load_bg').css('opacity', '0');
        setTimeout(function () {
            $('.wq_load_box').css('opacity', '0');
            setTimeout(function () {
                $('.wq_load_con').hide();
            }, 300)
        }, 500);
    }

    window.addEventListener('error', function () {
        wq_load_comp()
    }, false)


    var wq_document_height = $(document).height();
    var wechatguidebox = $("#wechatguide");
    $(window).bind('scroll orientationchange', function (e) {
        var NameOfCookie = "hidewechatguide";
        var c = document.cookie.indexOf(NameOfCookie + "=");
        if (c == -1) {
            if ($(this).scrollTop() > 52) {
                if (wechatguidebox.is(':hidden')) {
                    wechatguidebox.slideDown(350);
                }
            } else {
                wechatguidebox.hide();
            }
        }
    });

    $("#hidewechatguide").click(function () {
        wechatguidebox.fadeOut(350);
        setcookie('hidewechatguide', 1, '$wq_app_setting[advertisement_time]');
    });

    if (window.devicePixelRatio && devicePixelRatio >= 2 && navigator.userAgent.toLowerCase().match(/iphone/i) == "iphone") {
        document.getElementsByTagName('html')[0].className = 'retina';
    }

    $(function () {
        wq_load_comp()

        var u = navigator.userAgent;
        if ($('.wqheader-position').length) {
            if (isSupportSticky()) {
                $('.wqheader-position').addClass('wqheader-sticky').removeClass('wqheader-relative');
            } else {
                var top = $('.wqheader-position').offset().top;
                if (top == 0 && !$('.pullrefresh').length) {
                    $('.wqheader-position').removeClass('wqheader-relative');
                    $('.wqheader-position').next('.wqheight44').show()
                } else {
                    $(document).on('scroll', function () {
                        if ($(window).scrollTop() > top && $('.wqheader-position').hasClass('wqheader-relative')) {
                            $('.wqheader-position').removeClass('wqheader-relative');
                            $('.wqheader-position').next('.wqheight44').show()
                        } else if ($(window).scrollTop() <= top && !$('.wqheader-position').hasClass('wqheader-relative')) {
                            $('.wqheader-position').addClass('wqheader-relative');
                            $('.wqheader-position').next('.wqheight44').hide();
                        }
                    });
                }
            }
        }

        function isSafari() {
            var t = /applewebkit\/\d+(\.\d+)*\d*\s*\(KHTML,\s*like\s*Gecko\)\s*version\/\d+(\.\d+)*\.\d+\s*mobile\/\d+\w\d+\s*safari\/\d+(\.\d+)*\.\d+$/i
            return t.test(u)
        }

        if(!is_close_showtips){
            if (!!isSafari()) {
                if (!getcookie('safarimark')) {
                    $('.wqadd_desktop_warp').show();
                    $('.wqadd_desktop_warp').on('click', function () {
                        $(this).hide();
                        setcookie('safarimark', '1', 604800);
                    })
                }
            }

            if (!getcookie('slidePrompt')) {
                $('.wqsum_mask').show();
                $('.wqsum_mask').on('click', function () {
                    $(this).hide();
                    setcookie('slidePrompt', '1', 2592000);
                });
            }
        }
    });
</script>
<!--{/if}-->