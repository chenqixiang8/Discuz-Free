<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['wq_buluo_tpl_footer'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<script type="text/javascript" reload="1">
    $(function () {
        if (!parseInt("$_G[uid]")) {
            $('.notlogged').removeClass('dialog');
            $('.notlogged').removeClass('formdialog');
            $('.notlogged').removeClass('wqfav-button');
            var status = 0;
            $('body').on('touchstart', '.notlogged', function (e) {
                status = 1;
            });
            $('body').on('touchmove', function (e) {
                status = 0;
            });
            $('body').on('touchend', '.notlogged', function (e) {
                if (status == 1) {
                    if ($(this).hasClass('dialog')) $(this).removeClass('dialog');
                    if ($(this).hasClass('formdialog')) $(this).removeClass('formdialog');
                    if ($(this).hasClass('wqfav-button')) $(this).removeClass('wqfav-button');
                    popup.open('<div class="wqshield_notice"><div class="wqshield_con wqlogin_prompt">{$Tlang['d66405b4f8b4698b']}</div><div class="wqbtn_can wqnew_top"><a href="javascript:;" onclick="popup.close();"  class="wqeject_cancel">{$Tlang['9c825be7149e5b97']}</a><button class="wqdetermine" onclick="location.href = \'member.php?mod=logging&action=login\';">{$Tlang['387e9a577ee04ca3']}</button></div></div>');
                    status = 0;
                }
                return false;
            });
        }
    });
</script>

<!--{eval $wq_footer_hide='1';}-->
<!--{if !empty($_G['inajax'])}-->
<!--{template common/wq_buluofooter_ajax}-->
<!--{else}-->
<!--{template common/wq_buluofooter}-->
<!--{/if}-->
<!--{/if}-->