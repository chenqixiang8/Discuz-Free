<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['wq_buluoslide'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{if $wq_slide==1}-->
   <script type="text/javascript" src="{$_G['style']['styleimgdir']}mobile/thirdparty/isScroll.min.js?{VERHASH}"></script>
<!--{/if}-->
<script>
    var {$my_group_tag}_width=$('#{$my_group_tag} ul').width();
    $('#{$my_group_tag} ul').parent().css('width', {$my_group_tag}_width);
    if ({$my_group_tag}_width>wq_window_width) {
        var myscroll_{$my_group_tag} = new iScroll("{$my_group_tag}", {
            hScrollbar: false,
            vScroll: false,
            bounce: true,
        });
        if ($('#{$my_group_tag} .a').length) {
            var wq_{$my_group_tag} = $('#{$my_group_tag} .a').offset().left;
            if (wq_{$my_group_tag} > wq_window_width / 2) {
                var scrollTo_left=wq_{$my_group_tag} - (wq_window_width / 2);
                var wq_left={$my_group_tag}_width - wq_window_width;
                var scrollleft=wq_left<scrollTo_left?wq_left:scrollTo_left;
                myscroll_{$my_group_tag}.scrollTo(-scrollleft, 0, 1500);
            }
        }
    }
</script>
<!--{/if}-->