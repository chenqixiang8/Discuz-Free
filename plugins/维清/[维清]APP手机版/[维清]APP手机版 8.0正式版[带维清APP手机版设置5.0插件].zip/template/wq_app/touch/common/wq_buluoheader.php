<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['wq_buluoheader'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{eval
    $touch_tplid = $_G['setting']['styleid2'];
    loadcache('style_' . $touch_tplid);
    $touch_tpl = $_G['cache']['style_' . $touch_tplid];
    include DISCUZ_ROOT.$touch_tpl['tpldir'].'/php/config.php';
    $set_color=$wq_buluo['mobile_color']?$wq_buluo['mobile_color']:$setting['mobile_color'];
}-->
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=gb2312">
            <meta http-equiv="Cache-control" content="{if $_G['setting']['mobile'][mobilecachetime] > 0}{$_G['setting']['mobile'][mobilecachetime]}{else}no-cache{/if}" />
            <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0">
                <meta name="format-detection" content="telephone=no" />
                <meta name="keywords" content="{if !empty($metakeywords)}{echo dhtmlspecialchars($metakeywords)}{/if}" />
                <meta name="description" content="{if !empty($metadescription)}{echo dhtmlspecialchars($metadescription)} {/if},$_G['setting']['bbname']" />
                <base id="wq_siteurl" href="{$_G['siteurl']}"  />
                <!--<base target="_blank"/>-->
                <title><!--{if !empty($navtitle)}-->$navtitle - <!--{/if}--><!--{if empty($nobbname)}--> $_G['setting']['bbname'] - <!--{/if}--> {lang waptitle}</title>
                <link rel="stylesheet" href="template/{$templatename}/wq_buluo_src/font/iconfont.css?{VERHASH}" type="text/css" media="all">
                    <link rel="stylesheet" href="{$_G['style'][styleimgdir]}mobile/style.css?{VERHASH}" type="text/css" media="all">
                        <link rel="stylesheet" href="{$_G['style'][styleimgdir]}mobile/group.css?{VERHASH}" type="text/css" media="all">
                             <!--{template common/wq_buluo_setcolor}-->
                            <script type="text/javascript" src=" ./source/plugin/wq_buluo/static/js/mobile/jquery-1.8.3.min.js?{VERHASH}"></script>
                            <script type="text/javascript">var STYLEID = '{STYLEID}', STATICURL = '{STATICURL}', IMGDIR = '{IMGDIR}', VERHASH = '{VERHASH}', charset = '{CHARSET}', discuz_uid = '$_G[uid]', cookiepre = '{$_G[config][cookie][cookiepre]}', cookiedomain = '{$_G[config][cookie][cookiedomain]}', cookiepath = '{$_G[config][cookie][cookiepath]}', showusercard = '{$_G[setting][showusercard]}', attackevasive = '{$_G[config][security][attackevasive]}', disallowfloat = '{$_G[setting][disallowfloat]}', creditnotice = '<!--{if $_G[setting][creditnotice]}-->$_G[setting][creditnames]<!--{/if}-->', defaultstyle = '$_G[style][defaultextstyle]', REPORTURL = '$_G[currenturl_encode]', SITEURL = '$_G[siteurl]', JSPATH = '$_G[setting][jspath]';</script>
                            <script src="{$_G['style'][styleimgdir]}mobile/js/common.js?{VERHASH}" type="text/javascript" charset="gbk"></script>
                            <script type="text/javascript" charset="gbk" src="{$_G['style'][styleimgdir]}mobile/js/wq_touch.js?{VERHASH}"></script>
                            <!--{if $wq_login['appid'] && defined('WQ_IN_WECHAT') }-->
                            <!--{if (CURSCRIPT=='forum'&& CURMODULE=='viewthread')}-->
                            <!--{eval $title = $_G[forum_thread][subject]}-->
                            <!--{elseif (CURSCRIPT=='portal'&& CURMODULE=='view')}-->
                            <!--{eval $title = $article[title]}-->
                            <!--{else}-->
                            <!--{eval $title = !empty($navtitle) ? $navtitle : ""}-->
                            <!--{eval $title = empty($nobbname) ? $title."-".$_G['setting']['bbname'] : $title}-->
                            <!--{/if}-->
                            <!--{eval $desc = !empty($metadescription) ? dhtmlspecialchars($metadescription)."-".$_G['setting']['bbname'] : $_G['setting']['bbname']}-->
                            <!--{/if}-->
                            <!--{if CURSCRIPT == 'forum' || (CURSCRIPT == 'home' && $_GET['mod'] == 'follow')}-->
                            <!--{eval $wq_smilies = _buluo_get_system_smilies();}-->
                            <!--{/if}-->
                            </head>
                            <body class="bg">
                                <!--{hook/global_header_mobile}-->
                                <!-- header start -->
                                <!--{if $header_nav!='null'}-->
                                <header>
                                    <div class="header b_bule hdc cl">
                                        <!--{if $_G['setting']['domain']['app']['mobile']}-->
                                        {eval $nav = 'http://'.$_G['setting']['domain']['app']['mobile'];}
                                        <!--{else}-->
                                        {eval $nav = "./";}
                                        <!--{/if}-->
                                        <h2>
                                            <a title="$_G[setting][bbname]" href="$nav">
                                                <img src="{$_G['style'][styleimgdir]}mobile/images/{$logofilename}" />
                                            </a>
                                        </h2>
                                        <ul class="user_fun">
                                            <li class="icon_search">
                                                <a href="search.php?mod=forum" id="forsearch"<!--{if CURSCRIPT == 'search'}--> class="current"<!--{/if}-->><i class="wqiconfont wqicon-search f22"></i></a>
                                            </li>
                                            <li id="usermsg" onclick="$('#wq_menutop_nav').toggle();">
                                                <a href="javascript:;" ><i class="wqiconfont wqicon-menu f26 m_tf2"></i></a>
                                                <!--{if $_G[member][newpm]}--><span class="icon_msg"></span><!--{/if}-->
                                            </li>
                                        </ul>
                                    </div>
                                    <!--{if !empty($mainnavlist)}-->
                                    <div id="wq_menutop_nav" style=" position: relative;">
                                        <div class="top_menu_bar">
                                            <div class="top_menu_more">
                                                <a href="javascript:;" class="more_btn" id="wq_navs_toggle"><i class="wqiconfont wqicon-menujiantou"></i></a>
                                            </div>
                                            <div class="top_menu top_menu_list" id="wq_navs_scrolls">
                                                <div class="tag_list">
                                                    <ul>
                                                        <!--{loop $mainnavlist $nav}-->
                                                        <!--{if $nav[0]}-->
                                                        <!--{eval $n++;}-->
                                                        <li <!--{if $nav[ison]}-->class="a"<!--{/if}-->><a href="$nav[1]">{$nav[0]}</a></li>
                                                        <!--{/if}-->
                                                        <!--{/loop}-->
                                                        <li style="width: 38px;"></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <div id="wq_menu_top" class="menu_top menu_toptwo" style="position: absolute; top: 0px; z-index: 12;display: none">
                                            <p class="qh_menu">{$Tlang['122afc9691142e7b']}<span id="wq_navs_toggle_all" class="y menumore"><i class="wqiconfont wqicon-jiantou-copy f18"></i></span></p>
                                            <div class="top_menu">
                                                <div class="switch_menu_list">
                                                    <ul class="ul_01">
                                                        <!--{loop $mainnavlist $nav}-->
                                                        <!--{if $nav[0]}-->
                                                        <!--{eval $n++;}-->
                                                        <li <!--{if $nav[ison]}-->class="a"<!--{/if}-->> <a href="$nav[1]" >{$nav[0]}</a></li>
                                                        <!--{/if}-->
                                                        <!--{/loop}-->
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <!--{eval $wq_slide=1;$my_group_tag='wq_navs_scrolls';}-->
                                        <!--{template common/wq_buluoslide}-->
                                        <script>
                                            $('#wq_navs_toggle,#wq_navs_toggle_all').click(function () {
                                                $('#wq_menu_top').slideToggle('800');
                                            });
                                        </script>
                                    </div>
                                    <!--{/if}-->
                                </header>
                                <!-- header end -->
                                <!--{/if}-->

                                <script>
                                    var wq_document_height = $(document).height();
                                </script>
                                <!--{eval define("IN_WQ_TOUCH",1)}-->

<!--{/if}-->