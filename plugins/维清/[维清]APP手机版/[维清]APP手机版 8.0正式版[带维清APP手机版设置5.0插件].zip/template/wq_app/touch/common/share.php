<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['share'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<link rel="stylesheet" href="{$_G['style'][styleimgdir]}style/nativeShare.css?{VERHASH}" type="text/css">

<div class="wq-share-contain">
    <div class="wq-ucshare" style="display: none;">
        <div id="nativeShare"></div>
        <div class="wqsharecancel">{$Tlang['9c825be7149e5b97']}</div>
    </div>
    <div class="wq-share wq-qqshare"><img src="{$_G['style']['styleimgdir']}images/share_bg.png" /><div class="wq_know">{$Tlang['e298957fc231dfbc']}</div></div>
    <div class="wq-share wq-2345share"><img src="{$_G['style']['styleimgdir']}images/share_browser_z.png" /></div>
    <div class="wq-share wq-baidushare"><img src="{$_G['style']['styleimgdir']}images/share_browser_y.png" /></div>
    <div class="wq-share wq-baiduBoxshare"><img src="{$_G['style']['styleimgdir']}images/share_browser_zy.png" /></div>
    <div class="wq-share wqshare_iphone"><img src="{$_G['style'][styleimgdir]}images/share_browser_pg.png"></div>
    <div class="wq-share-mask" style="display: none;"></div>
</div>

<script>
    var wqshareTo = "{$Tlang['4d3ba91835492030']}",
        wqshareSina = "{$Tlang['5b9f34f4cca87c47']}",
        wqshareWe = "{$Tlang['5db5637fce0c067d']}",
        wqshareLine = "{$Tlang['63f74042f0459ebb']}",
        wqshareQQ = "{$Tlang['424e96d32fd4df9c']}",
        wqshareQz = "{$Tlang['ed362969fb869003']}",
        wqshareMore = "{$Tlang['db9c470ab0853172']}";

    JC.file('thirdparty/nativeShare.js');
    JC.run();
</script>

<!--{/if}-->