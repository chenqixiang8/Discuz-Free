<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['upload_image'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<ul id="imglist" class="wqpost_imglist" style="display:none">
    <li class="wqadd_photo" onclick="uploadsuccess_forum = upload_image;$('#filedata').click();"><i class="wqiconfont2 wqicon2-increase"></i></li>
</ul>
<script type="text/javascript" src="{STATICURL}js/mobile/ajaxfileupload.js?{VERHASH}"></script>
<script>
    JC.file('thirdparty/buildfileupload.js');
    JC.run();
    var prcpath = "$_G[setting][attachurl]";
    var url;
    var upload_image;
    var uploadsuccess_forum;
    var imgexts = typeof imgexts == 'undefined' ? 'jpg, jpeg, gif, png' : imgexts;
    var STATUSMSG = {
            '-1' : '{lang uploadstatusmsgnag1}',
            '0' : '{lang uploadstatusmsg0}',
            '1' : '{lang uploadstatusmsg1}',
            '2' : '{lang uploadstatusmsg2}',
            '3' : '{lang uploadstatusmsg3}',
            '4' : '{lang uploadstatusmsg4}',
            '5' : '{lang uploadstatusmsg5}',
            '6' : '{lang uploadstatusmsg6}',
            '7' : '{lang uploadstatusmsg7}(' + imgexts + ')',
            '8' : '{lang uploadstatusmsg8}',
            '9' : '{lang uploadstatusmsg9}',
            '10' : '{lang uploadstatusmsg10}',
            '11' : '{lang uploadstatusmsg11}'
    };


	var maxheight = parseInt('$wq_app_setting[maxheight]') < 1 ? 0 : parseInt('$wq_app_setting[maxheight]');
	var maxwidth = parseInt('$wq_app_setting[maxwidth]') < 1 ? 0 : parseInt('$wq_app_setting[maxwidth]');
    function picture(uploadsuccess, id, name, url) {
        var uploadurl = url ? url : 'misc.php?mod=swfupload&operation=upload&type=image&inajax=yes&infloat=yes&simple=2';
        popup.open(toast);
        if(typeof FileReader != 'undefined') {
            var wq_file = new Array();
            $.each(document.getElementById(id).files, function (i, n) {

                wq_file[0] = n;
                $.buildfileupload({
                    uploadurl: uploadurl,
                    files: wq_file,
                    uploadformdata:{uid:"$_G[uid]", hash:"<!--{eval echo md5(substr(md5($_G[config][security][authkey]), 8).$_G[uid])}-->"},
                    uploadinputname: name,
                    maxfilesize: "$swfconfig[max]",
					maxheight: maxheight,
                    maxwidth: maxwidth,
                    success: uploadsuccess,
                    error: function () {
                        popup.open('{lang uploadpicfailed}', 'alert');
                    }
                });
            });
        } else {
            $.ajaxfileupload({
                url:uploadurl,
                data:{uid:"$_G[uid]", hash:"<!--{eval echo md5(substr(md5($_G[config][security][authkey]), 8).$_G[uid])}-->"},
                dataType:'text',
                fileElementId:id,
                success:uploadsuccess,
                error: function() {
                    popup.open('{lang uploadpicfailed}', 'alert');
                }
            });

        }
    }

    $(document).on('change', '#filedatas', function () {
        if ($(this).val()) {
            popup.open(toast);
            $.ajaxfileupload({
                url:'misc.php?mod=swfupload&action=swfupload&operation=upload&fid={$_G[fid]}&inajax=1',
                data:{uid:"$_G[uid]", hash:"$swfconfig[hash]"},
                dataType:'text',
                fileElementId: 'filedatas',
                success:wqupload_attach,
                error: function() {
                    popup.open('{lang uploadpicfailed}', 'alert');
                }
            });
        }
    });

    $(document).on('change', '#filedata', function () {
        if ($(this).val()) {
            picture(uploadsuccess_forum, 'filedata', 'Filedata', typeof (url) == 'undefined' ? '' : url);
        }
    });
    $(document).on('click', '#file_button', function () {
        if ($('#imglist li').length == 1 || $('#imglist').is(':visible')) {
            uploadsuccess_forum = upload_image;
            $('#filedata').click();
        } else {
            $(this).parent().parent().siblings().each(function(){
                var icon = $(this).data('type');
                if ($('.showHide_'+icon).is(':visible')) {
                    if(icon=='biaoqing'){
                        $('.wqbiaoqing').click();
                    }else{
                        $('.wqicon2-'+icon).click();
                    }
                }
            })
            $('.wqicon2-tupian1').addClass('wqcolor');
            $('#imglist').show();
            $('#upload_icon').addClass('blue');
        }
    });
    var tid = "{$_GET['tid']}" || 0, pid = "{$_GET['pid']}" || 0;
    $(document).on('click', '.del', function () {
        var obj = $(this);
        if (obj.attr('aid')) {
            var url = 'forum.php?mod=ajax&action=deleteattach&inajax=yes&aids[]=' + obj.attr('aid');
            var data = {tid: tid, pid: pid};
            var type = 'GET';
        } else {
            var url = 'home.php?mod=spacecp&ac=album&op=editpic&albumid=0&subop=delete';
            var type = 'POST';
            var data = {'editpicsubmit': true, 'inajax': '1', 'formhash': '{FORMHASH}'};
            data['ids[' + obj.attr('picid') + ']'] = obj.attr('picid');
        }
        $.ajax({
            type: type,
            url: url,
            data: data,
            dataType: 'html'
        }).success(function (s) {
            if(obj.attr('wqtype')=='img'){
                obj.parent().remove();
                if($('#imglist li').length -1 == 0){
                    $('.wqtoday').hide();
                }else{
                    $('.wqtoday').show().text($('#imglist li').length-1);
                }
            }else if(obj.attr('wqtype')=='attach'){
                obj.parent().parent().remove();
                if($('#imglist li').length -1 == 0){
                    $('.wqfujian2').addClass('none');
                }
            }
        }).error(function () {
            popup.open('{lang networkerror}', 'alert');
        });
        return false;
    });
</script>
<!--{/if}-->