<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['slide'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<script>
    var wq_window_width = $(window).width();
    if (!$('#{$my_roll_tag}').hasClass('slide-stop')) $('#{$my_roll_tag}').addClass('slide-stop')
    $('#{$my_roll_tag} ul').parent().width(3000);
    var {$my_roll_tag}_width = $('#{$my_roll_tag} ul').width() + 1;
    $('#{$my_roll_tag}').css('overflow', 'hidden');
    $('#{$my_roll_tag} ul').parent().css('width', {$my_roll_tag}_width);
    if ({$my_roll_tag}_width > wq_window_width) {
        var myscroll_{$my_roll_tag} = new IScroll('#{$my_roll_tag}', {click: true, bounce: true, scrollX: true, scrollY: false});
        if ($('#{$my_roll_tag} .a').length || $('#{$my_roll_tag} .wqcolor').length) {
            try{
                var wq_{$my_roll_tag} = $('#{$my_roll_tag} .a').offset().left;
            } catch(e) {
                var wq_{$my_roll_tag} = $('#{$my_roll_tag} .wqcolor').offset().left;
            }
            if (wq_{$my_roll_tag} > wq_window_width / 2) {
                var scrollTo_left = wq_{$my_roll_tag} - (wq_window_width / 2);
                var wq_left = {$my_roll_tag}_width - wq_window_width;
                var scrollleft = wq_left<scrollTo_left ? wq_left : scrollTo_left;
                myscroll_{$my_roll_tag}.scrollTo(-scrollleft, 0, 1500);
            }
        }
    }
</script>
<!--{/if}-->