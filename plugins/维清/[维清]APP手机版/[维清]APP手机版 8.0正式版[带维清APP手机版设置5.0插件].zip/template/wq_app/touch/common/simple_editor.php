<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['simple_editor'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<script>
    var obj = {};
    var tid = "{$_GET['tid']}" || 0, pid = "{$_GET['pid']}" || 0;
    var wqbbcodeJs = "{$_G['style'][styleimgdir]}js/public/wqbbcode.js?{VERHASH}";  //wqbbcode.js��·��
    $.fn.extend({
        opt: {
            selector: '',
            bbcodeMode: false,
            placeholder: "{$Tlang['70ad0bcbf2229f1d']}",
            imglist: '',
            subButton: ''
        },
        wqEditor: function (obj1) {
            var that = this;
            this.opt = $.extend(that.opt, obj1);
            $(that.opt.selector).attr('placeholder', that.opt.placeholder);
            $(that.opt.imglist).on('click', 'img', function () {
                var img = '<img src="' + $(this).prop('src') + '" aid="' + $(this).prop('id') + '"/>';
                that.insertImg(img, that.opt.editor);
                that.opt.bbcodeMode ? $(that.opt.selector).val(html2bbcode(that.html())) : $(that.opt.selector).val(that.html());
            });
            $('.image_b a').on('click', function () {
                var img = '<img src="' + $(this).find('img').prop('src') + '" smilieid="' + $(this).attr('sid') + '" alt="' + $(this).attr('code') + '" class="wq_smilieimg" />';
                that.insertImg(img, that.opt.editor, true);
                that.opt.bbcodeMode ? $(that.opt.selector).val(html2bbcode(that.html())) : $(that.opt.selector).val(that.html());
            });

            $('#post_attach').on('click','.wq_insert', function () {
                var wqisimage = parseInt($(this).data('isimage'));
                var wqaid = $(this).data('aid');

                if(wqisimage){
                    var img = $(this).data('url');
                    var txt = '<img src="' + img + '" aid="' + wqaid + '"/>';
                }else{
                    var txt = '[attach]' + wqaid + '[/attach]';
                }
                that.insertImg(txt, that.opt.editor);
                that.opt.bbcodeMode ? $(that.opt.selector).val(html2bbcode(that.html())) : $(that.opt.selector).val(that.html());
            });

            $('.wqapp_insert_data').on('click', function () {
                var get_c = $(this).data('class');
                var insertdata = $('.'+ get_c).val();
                if(isNull(insertdata)){
                    if(get_c == 'wqadd_url'){
                        popup.open('&#x8BF7;&#x8F93;&#x5165;&#x94FE;&#x63A5;&#x7F51;&#x5740;', 'alert');
                    }else{
                        popup.open('&#x8BF7;&#x8F93;&#x5165;&#x9700;&#x8981;&#x63D2;&#x5165;&#x7684;&#x5185;&#x5BB9;', 'alert');
                    }
                }else{
                    if(get_c == 'wqadd_music'){
                        insertdata='[audio]' + insertdata + '[/audio]';
                    }else if(get_c == 'wqadd_video'){
                        insertdata='[media=swf,500,375]' + insertdata + '[/media]';
                    }else if(get_c == 'wqadd_at'){
                        insertdata='@' + insertdata;
                    }else if(get_c == 'wqadd_url'){
                        var linktitle= $('.'+ get_c+'_1').val();
                        if(isNull(linktitle)){
                            linktitle = insertdata;
                        }
                        insertdata='[url='+insertdata+']'+linktitle+'[/url]';
                        $('.'+get_c+'_1').val('');
                    }else if(get_c == 'wqadd_image'){
                        insertdata='[img]'+insertdata+'[/img]';
                    }else if(get_c == 'wqadd_flash'){
                        insertdata='[flash=500,375]' + insertdata + '[/flash]';
                    }else if(get_c == 'wqadd_quote'){
                        insertdata='[quote]' + insertdata + '[/quote]';
                    }else if(get_c == 'wqadd_code'){
                        insertdata='[code]' + insertdata + '[/code]';
                    }else if(get_c == 'wqadd_free'){
                        insertdata='[free]' + insertdata + '[/free]';
                    }

                    $('.'+get_c).val('');
                    that.insertImg(insertdata, that.opt.editor);
                    that.opt.bbcodeMode ? $(that.opt.selector).val(html2bbcode(that.html())) : $(that.opt.selector).val(that.html());
                }
            });



            if (that.opt.bbcodeMode) {
                var e = document.createElement('script');
                e.src = wqbbcodeJs;
                document.head.appendChild(e);
                e.onload = function () {
                    that.toBb();
                };
            }
            that.on('input', function () {
                    if (that.opt.bbcodeMode) {
                        $(that.opt.selector).val(html2bbcode(that.html()));
                    } else {
                        $(that.opt.selector).val(that.html());
                    }
                    var selection = getSelection();
                    that.lastEditRange = selection.getRangeAt(0);
            });
            that.on('keyup', function () {
                var selection = getSelection();
                that.lastEditRange = selection.getRangeAt(0);
                that.lastTop = that.scrollTop();
            });
            that.on('click', function () {
                var selection = getSelection();
                that.lastEditRange = selection.getRangeAt(0);
                that.lastTop = that.scrollTop();
            });
            $(that.opt.subButton).on('touchend', function () {
                if (that.opt.bbcodeMode) {
                    $(that.opt.selector).val(html2bbcode(that.html()));
                } else {
                    $(that.opt.selector).val(that.html());
                }
            });
            $(that).addClass('slide-stop');
        },
        toBb: function () {
            var that = this;
            $.ajax({
                url: 'plugin.php?id=wq_app_setting&mod=api',
                data: {fun: 'images_attachment', tid: tid, pid: pid},
                dataType: 'JSON',
                type: 'POST',
                success: function (res) {
                    if (res && res.errcode == '1') {
                        obj = res.msg;
                        if ($(that.opt.imglist).is(':hidden')) {
                            $('.cellphone_expression').hide();
                            $('.wqexpression').removeClass('c_jianpan').removeClass('wqicon-jianpan');
                            $(that.opt.imglist).show();
                            $('#upload_icon').addClass('blue');
                        }
                        for (var i in obj) {
                            $(that.opt.imglist).prepend('<li' + (/\.(gif|jpg|jpeg|png|GIF|JPG|PNG|JPEG)$/.test(obj[i]) ? '' : ' style="display: none;"') + '><span aid="' + i + '" class="del wqdelete" wqtype="img"><a href="javascript:;">'
                                +'<i class="wqiconfont2 wqicon2-jianhao f22"></i></a></span><span class="wqimg"><a href="javascript:;"><img id="aimg_'
                                + i + '" src="'
                                + obj[i] + '" /></a></span><input type="hidden" name="attachnew[' + i + '][description]" /></li>');
                            $('.wqtoday').show().text($(that.opt.imglist + ' li:visible').length - 1);
                        }
                    }
                }
            });
        },
        insertImg: function (src, selector, isSmile) {
            if (!isSmile) src = '<div>' + src + '</div> ';
            var scrollTop = this[0].scrollHeight - this.height()
            $(selector)[0].focus();
            var selection = window.getSelection();
            if (this.lastEditRange) {
                selection.removeAllRanges();
                selection.addRange(this.lastEditRange);
            }
            var range = selection.getRangeAt(0);
            range.collapse(false);
            var hasR = range.createContextualFragment(src);
            var hasLastChild = hasR.lastChild;
            range.insertNode(hasR);
            if (hasLastChild) {
                range.setEndAfter(hasLastChild);
                range.setStartAfter(hasLastChild);
            }
            selection.removeAllRanges();
            selection.addRange(range);
            this.lastEditRange = range;
            $(selector)[0].blur();
            if (this.lastTop == scrollTop) {
                this.scrollTop(this[0].scrollHeight - this.height());
            } else {
                this.scrollTop(this.lastTop);
            }
            this.lastTop = this.scrollTop();
        }
    });
</script>
<!--{/if}-->