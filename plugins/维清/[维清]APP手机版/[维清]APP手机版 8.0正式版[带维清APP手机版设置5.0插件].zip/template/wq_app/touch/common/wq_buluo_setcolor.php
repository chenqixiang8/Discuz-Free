<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['wq_buluo_setcolor'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<style>
 .weui_switch:checked,.search_card .btn, .feeds_guide_mod_avatar_flag_on i{ background-color: $set_color;}
.weui_switch:checked{ border-color: $set_color;}
.weui_check:checked +label .weui_icon_checked:before,.groupfans_list li a.on,.fans_boy,.groupviewlump .group_title_info .detail_from a,.group_found .wq_return,.group_found .return_in,.my_group_tag .tag_list li.a a,.my_group_ass .tag_list li.a a,.audit_member ul li a.a,.audit_list .pns .ignore,.qz_bg .gz_bule,.group_menu ul li.on a,.group_left .group_list li.active a,.support_idea a,.group_wrap li.a a,.gz_group a,.card_more a,.card_in_gz span a,.card_in_f span,.card_footer_gz,.card_footer_gz,.recent_visit h3 em a,.sign_grade ul li.a,.interest_head_name a,.my_notice i,.card_footer_gz_bl{ color: $set_color;}
.groupfans_list li a.on,.my_group_tag .tag_list li.a { border-bottom: 1px solid $set_color;}
.fans_boy,.groupviewlump .group_title_info .detail_from,.my_group_ass .tag_list li.a a,.audit_member ul li a,.audit_list .pns button,.group_ass .a,.sign_grade ul li.a{border: 1px solid $set_color; }
.found_group button,.application_ipgroup,.publish_btn,.member_manage,.audit_member ul li a,.audit_list .pns button,.group_ass .a,.btn_container .share_qrcode_btn,.sign_grade_btn button,.group_pay .btn_focus,.wqbuluo_search_member button{ background: $set_color;}
.group_menu ul li.on{  border-bottom: 2px solid $set_color; }
.group_left .group_list li.active{ border-left: 2px solid $set_color;}
.section_p a{color: $set_color !important;}

</style>
<!--{/if}-->