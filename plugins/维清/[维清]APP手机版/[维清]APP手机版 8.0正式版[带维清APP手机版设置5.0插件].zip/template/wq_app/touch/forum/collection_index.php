<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['collection_index'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{template common/header}-->

    <!--{eval $headright=false;}-->
    <!--{if helper_access::check_module('collection')}-->
        <!--{eval $headright=true;}-->
    <!--{/if}-->

    <!--{eval
        $headparams['wtype'] = '1';
        $headparams['ltype'] = 'a';
        $headparams['lurl'] = $backurl;
        $headparams['cname'] = $Tlang['5d6bc314174ee1c8'];
        $headparams['rtype'] = 'a';
        $headparams['rclass'] = 'wqapp_f16';

        $headparams['rtype'] = 'a';
        $headparams['rname'] = $Tlang['984c5e7090423fd1'];
        $headparams['rurl'] = 'forum.php?mod=collection&action=edit';
        $headparams['rclass'] = '';

        echo wq_app_get_header($headparams,true,$headright);
    }-->

<div id="ct" class=" wp cl">
	<div class="bm">
		<div class="wq_amoy_paste">
                    <div class="tag_list">
			<!--{subtemplate forum/collection_nav}-->
                    </div>
		</div>
		<div class="bm_c">
			<!--{hook/collection_index_top}-->
			<!--{subtemplate forum/collection_list}-->
			<!--{hook/collection_index_bottom}-->
		</div>
	</div>
	$multipage
	<br /><br />
</div>
<!--{template common/footer}-->
<!--{/if}-->