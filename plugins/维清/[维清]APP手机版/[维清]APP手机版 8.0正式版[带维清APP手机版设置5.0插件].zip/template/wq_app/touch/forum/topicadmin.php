<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['topicadmin'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{if $_GET['type'] == 'wq_buluo'}-->
    <!--{template forum/wq_buluotopicadmin}-->
    <!--{eval exit;}-->
<!--{/if}-->

<!--{template common/header}-->
<div class="wqshield_notice">
    <form id="moderateform" method="post" autocomplete="off" action="forum.php?mod=topicadmin&action=moderate&optgroup=$optgroup&modsubmit=yes&infloat=yes" onsubmit="ajaxpost('moderateform', 'return_mods', 'return_mods', 'onerror');return false;">
        <input type="hidden" name="frommodcp" value="$frommodcp" />
        <input type="hidden" name="formhash" value="{FORMHASH}" />
        <input type="hidden" name="fid" value="$_G[fid]" />
        <input type="hidden" name="redirect" value="{echo dreferer()}" />
        <!--{if !empty($_GET['listextra'])}--><input type="hidden" name="listextra" value="$_GET['listextra']" /><!--{/if}-->
        <!--{if !empty($_GET['infloat'])}--><input type="hidden" name="handlekey" value="$_GET['handlekey']" /><!--{/if}-->
        <!--{loop $threadlist $thread}-->
        <input type="hidden" name="moderate[]" value="$thread[tid]" />
        <!--{/loop}-->
        <div class="wqshield_con">
            <!--{if $_GET['optgroup'] == 1}-->
            <ul class="wqzhiding">
                <!--{if count($threadlist) > 1 || empty($defaultcheck[recommend])}-->
                <!--{if $_G['group']['allowstickthread']}-->
                <li id="itemcp_stick" class="notchecked">
                    <p onclick="switchitemcp('itemcp_stick')">
                        <input type="checkbox" name="operations[]" id="operations1" class="weui_check" onclick="if (this.checked)switchitemcp('itemcp_stick')" value="stick" $defaultcheck[stick] />
                        <label onclick="switchitemcp('itemcp_stick')" for="operations1" class="labeltxt weui_check_label"><i class="weui_icon_checked"></i></label>{lang thread_stick}
                        <span class="dopt dsn">
                            <select class="ps wq_choice" name="sticklevel">
                                <!--{if $_G['forum']['status'] != 3}-->
                                <option value="0">{lang none}</option>
                                <option value="1" $stickcheck[1]>$_G['setting']['threadsticky'][2]</option>
                                <!--{if $_G['group']['allowstickthread'] >= 2}-->
                                <option value="2" $stickcheck[2]>$_G['setting']['threadsticky'][1]</option>
                                <!--{if $_G['group']['allowstickthread'] == 3}-->
                                <option value="3" $stickcheck[3]>$_G['setting']['threadsticky'][0]</option>
                                <!--{/if}-->
                                <!--{/if}-->
                                <!--{else}-->
                                <option value="0">{lang no}&nbsp;</option>
                                <option value="1" $stickcheck[1]>{lang yes}&nbsp;</option>
                                <!--{/if}-->
                            </select>
                        </span>
                    </p>
                    <p class="hasd wqinput wqnew_all dsn">
                        <input type="text" name="expirationstick" id="expirationstick" readonly onfocus="this.blur();" class="px muidate wqpost_input" placeholder="{lang expire}" value="$expirationstick" tabindex="1">
                        <a href="javascript:;" class="dpbtn" onclick="showselect(this, 'expirationstick')"></a>
                    </p>
                </li>
                <!--{/if}-->
                <!--{if $_G['group']['allowdigestthread']}-->
                <li id="itemcp_digest" class="notchecked">
                    <p class="hasd" onclick="switchitemcp('itemcp_digest')">
                        <input type="checkbox" name="operations[]" class="pc weui_check" onclick="if (this.checked) switchitemcp('itemcp_digest')" id="operations2" value="digest" $defaultcheck[digest] />
                        <label onclick="switchitemcp('itemcp_digest')" for="operations2" class="labeltxt weui_check_label"><i class="weui_icon_checked"></i></label>{lang admin_digest_add}
                        <span class="dopt dsn">
                            <select class="wq_choice" name="digestlevel">
                                <option value="0">{lang admin_digest_remove}</option>
                                <option value="1" $digestcheck[1]>{lang thread_digest} 1</option>
                                <!--{if $_G['group']['allowdigestthread'] >= 2}-->
                                <option value="2" $digestcheck[2]>{lang thread_digest} 2</option>
                                <!--{if $_G['group']['allowdigestthread'] == 3}-->
                                <option value="3" $digestcheck[3]>{lang thread_digest} 3</option>
                                <!--{/if}-->
                                <!--{/if}-->
                            </select>
                        </span>
                    </p>
                    <p class="hasd wqinput wqnew_all dsn">
                        <input type="text" name="expirationdigest" id="expirationdigest" readonly onfocus="this.blur();" class="px muidate wqpost_input" placeholder="{lang expire}" value="$expirationdigest" tabindex="1">
                        <a href="javascript:;" class="dpbtn" onclick="showselect(this, 'expirationdigest')"></a>
                    </p>
                </li>
                <!--{/if}-->
                <!--{if $_G['group']['allowbumpthread']}-->
                <li id="itemcp_bump" class="notchecked">
                    <p onclick="switchitemcp('itemcp_bump')"><input type="checkbox" name="operations[]" class="pc weui_check" id="operations3" onclick="if (this.checked) switchitemcp('itemcp_bump')" value="bump" $defaultcheck[bump] />
                        <label onclick="switchitemcp('itemcp_bump')" for="operations3" class="labeltxt weui_check_label"><i class="weui_icon_checked"></i></label>{lang bump}</p>
                    <p class="hasd wqinput wqnew_all dsn">
                        <input type="text" name="expirationbump" id="expirationbump" readonly onfocus="this.blur();" class="px muidate wqpost_input" placeholder="{lang expire}" tabindex="1">
                        <a href="javascript:;" class="dpbtn" onclick="showselect(this, 'expirationbump')"></a>
                    </p>
                </li>
                <!--{/if}-->
                <!--{if $_G['group']['allowhighlightthread']}-->
                <li id="itemcp_highlight" class="notchecked">
                    <p onclick="switchitemcp('itemcp_highlight')">
                        <input type="checkbox" name="operations[]" class="pc weui_check" id="operations4" onclick="if (this.checked) switchitemcp('itemcp_highlight')" value="highlight" $defaultcheck[highlight] />
                        <!--{eval $_G['forum_colorarray'] = array(1=>'#EE1B2E', 2=>'#EE5023', 3=>'#996600', 4=>'#3C9D40', 5=>'#2897C5', 6=>'#2B65B7', 7=>'#8F2A90', 8=>'#EC1282');}-->
                        <label onclick="switchitemcp('itemcp_highlight')" for="operations4" class="labeltxt weui_check_label"><i class="weui_icon_checked"></i></label>{lang thread_highlight}
                        <span class="dopt dsn">
                            <span class="hasd">
                                <input type="hidden" id="highlight_color" name="highlight_color" value="$colorcheck" />
                                <input type="hidden" id="highlight_style_1" name="highlight_style[1]" value="$stylecheck[1]" />
                                <input type="hidden" id="highlight_style_2" name="highlight_style[2]" value="$stylecheck[2]" />
                                <input type="hidden" id="highlight_style_3" name="highlight_style[3]" value="$stylecheck[3]" />

                            </span>
                            <a href="javascript:;" id="highlight_op_1" onclick="switchhl(this, 1)" class="dopt_b{if $stylecheck[1]} cnt{/if}" style="text-indent:0;text-decoration:none;font-weight:700;" title="{lang e_bold}">B</a>
                            <a href="javascript:;" id="highlight_op_2" onclick="switchhl(this, 2)" class="dopt_i{if $stylecheck[2]} cnt{/if}" style="text-indent:0;text-decoration:none;font-style:italic;" title="{lang e_italic}">I</a>
                            <a href="javascript:;" id="highlight_op_3" onclick="switchhl(this, 3)" class="dopt_l{if $stylecheck[3]} cnt{/if}" style="text-indent:0;text-decoration:underline;" title="{lang e_underline}">U</a>
                            <a href="javascript:;" id="highlight_color_ctrl" onclick="showHighLightColor('highlight_color')" class="pn colorwd"{if $colorcheck} style="background: $_G[forum_colorarray][$colorcheck]"{/if} >c</a>
                        </span>

                    </p>
                    <div class="color-setting"></div>
                    <div class="dopt dsn">
                        <p class="hasd wqinput wqnew_all">
                            <input type="text" name="expirationhighlight" id="expirationhighlight" readonly onfocus="this.blur();" class="px muidate wqpost_input" placeholder="{lang expire}" value="$expirationhighlight" tabindex="1">
                        </p>
                    </div>
                    <div class="dopt dsn">
                        <p class="hasd">
                            <label class="labeltxt">{lang backgroundcolor}:</label>
<!--                                <input type="hidden" id="highlight_bgcolor" name="highlight_bgcolor" value="$highlight_bgcolor" />-->
                            <span class="wqspan"><input name="highlight_bgcolor" value="#FFFFFF" class="pn colorbd" id="chighlight_bgcolor_ctrl" readonly></span>
                        </p>
                    </div>
                </li>
                <!--{/if}-->
                <script reload="1">
                    for (var i = 0; i < $('.wqzhiding li').length; i++) {
                        if ($('.wqzhiding li .weui_check').eq(i).is(':checked')) {
                            $('.wqzhiding li').eq(i).addClass('copt').removeClass('notchecked');
                        }
                    }

                    var myColorPicker = $('.pn.colorbd').colorPicker();

                    mui('.muidate').each(function (i, btn) {
                        btn.addEventListener('tap', function () {
                            var optionsJson = this.getAttribute('data-options') || '{}';
                            var options = JSON.parse(optionsJson);
                            var id = this.getAttribute('id');
                            var picker = new mui.DtPicker(options);
                            picker.show(function (rs) {
                                 $('#'+id).attr('value',rs.text);
                                picker.dispose();
                            });
                        }, false);
                    });
                </script>
                <!--{/if}-->
                <!--{if $_G['group']['allowrecommendthread'] && !empty($_G['forum']['modrecommend']['open']) && $_G['forum']['modrecommend']['sort'] != 1}-->
                <li id="itemcp_recommend">
                    <p>
                        <input type="checkbox" name="operations[]" class="pc weui_check_z" onclick="if (this.checked)switchitemcp('itemcp_recommend')" value="recommend" $defaultcheck[recommend] />
                        <label onclick="switchitemcp('itemcp_recommend')" class="labeltxt weui_check_label_z"><i class="weui_icon_checked_z"></i>{lang recommend}</label>
                    </p>
                        <p class="dopt">
                            <span><input type="radio" name="isrecommend" class="pr weui_check" id="isrecommend1" value="1" checked="checked" /><label class="lb weui_check_label" for="isrecommend1"><i class="weui_icon_checked"></i>{lang recommend}</label></span>
                            <span><input type="radio" name="isrecommend" class="pr weui_check" id="isrecommend2" value="0" /><label class="weui_check_label" for="isrecommend2"><i class="weui_icon_checked"></i>{lang admin_unrecommend}</label></span>
                        </p>
                         <p class="hasd wqinput wqnew_all">
                            <input type="text" name="expirationrecommend" id="expirationrecommend" class="px" placeholder="{lang expire}" onclick="showcalendar(event, this, true)" autocomplete="off" value="$expirationrecommend" tabindex="1" />
                            <a href="javascript:;" class="dpbtn" onclick="showselect(this, 'expirationrecommend')"></a>
                         </p>

                        <!--{if $defaultcheck[recommend] && count($threadlist) == 1}-->
                        <input type="hidden" name="position" value="1" />
                        <p class="dopt">
                            <label for="reducetitle" class="labeltxt">{lang forum_recommend_reducetitle}</label>
                            <input type="text" name="reducetitle" id="reducetitle" class="px wqinput_subject" value="$thread[subject]" tabindex="2" />
                        </p>
                        <!--{if $imgattach}-->
                        <p class="dopt">
                            <label class="labeltxt">{lang forum_recommend_image}</label>
                            <select name="selectattach" onchange="updateimginfo(this.value)" class="ps wqinput_subject">
                                <option value="">{lang forum_recommend_noimage}</option>
                                <!--{loop $imgattach $imginfo}-->
                                <option value="$imginfo[aid]"{if $selectattach == $imginfo[aid]} selected="selected"{/if}>$imginfo[filename]</option>
                                <!--{/loop}-->
                            </select>
                        </p>
                        <tr class="dopt">
                            <td>&nbsp;</td>
                            <td>
                                <label class="labeltxt">&nbsp;</label>
                                <img id="selectimg" src="{STATICURL}image/common/none.gif"  width="120" height="80" />
                                <script type="text/javascript" reload="1">
                                    var imgk = new Array();
                                    <!--{loop $imgattach $imginfo}-->
                                        <!--{eval $a = '\"\'\t\\""\\\''."\\\\";$k = getforumimg($imginfo['aid'], 1, 120, 80);}-->
                                        imgk[{$imginfo[aid]}] = '$k';
                                    <!--{/loop}-->
                                    function updateimginfo(aid) {
                                        if(aid) {
                                            $('selectimg').src=imgk[aid];
                                        } else {
                                            $('selectimg').src='{STATICURL}image/common/none.gif';
                                        }
                                    }
                                    <!--{if $selectattach}-->updateimginfo('$selectattach');<!--{/if}-->
                                </script>
                            </td>
                        </tr>
                        <!--{/if}-->
                        <!--{/if}-->
                    </table>
                </li>
                <!--{/if}-->
            </ul>
            <!--{elseif $_GET['optgroup'] == 2}-->
            <div class="tplw wqyidong_warp">
                <!--{if $operation != 'type'}-->
                <input type="hidden" name="operations[]" value="move" />
                <p class="mbn tahfx">
                    {lang admin_target}: <select name="moveto" id="moveto" class="ps vm" onchange="wq_app_ajaxget('forum.php?mod=ajax&action=getthreadtypes&fid=' + this.value, 'threadtypes');if (this.value) {
                                $('#moveext').show();
                            } else {
                                $('#moveext').hide();}">
                        $forumselect
                    </select>
                </p>
                <p class="mbn tahfx">
                    {lang admin_targettype}: <span><select id="threadtypes" name="threadtypeid" class="ps vm"><option value="0" /></option></select></span>
                </p>
                <div class="llst" id="moveext" style="display: none;">
                    <p class="wide">
                        <input type="radio" name="type" class="pr weui_check" id="move_in" value="normal" checked="checked" />
                        <label class="weui_check_label" for="move_in"><i class="weui_icon_checked"></i>{lang admin_move}</label>
                    </p>
                    <p class="wide">
                        <input type="radio" name="type" class="pr weui_check" id="move_in2" value="redirect" />
                        <label class="weui_check_label" for="move_in2"><i class="weui_icon_checked"></i>{lang admin_move_hold}</label>
                    </p>
                </div>
                <!--{else}-->
                <!--{if $typeselect}-->
                <input type="hidden" name="operations[]" value="type" />
                <p class="mbn tahfx">{lang types}: $typeselect</p>
                <!--{else}-->
                <div style="padding-bottom: 10px; line-height: 26px">{lang admin_type_msg}</div><!--{eval $hiddensubmit = true;}-->
                <script type="text/javascript">
                    setTimeout_location = setTimeout(function() {
                        popup.close();
                    }, '1500');
                </script>
                <!--{/if}-->
                <!--{/if}-->
            </div>
            <!--{elseif $_GET['optgroup'] == 3}-->
            <div class="wqshengjiang">
                <ul class="llst">
                    <!--{if $operation == 'delete'}-->
                    <li>
                        <!--{if $_G['group']['allowdelpost']}-->
                        <input name="operations[]" type="hidden" value="delete"/>
                        <p style="text-align: center;">{lang admin_delthread_confirm}</p>
                        <!--{else}-->
                        <p>{lang admin_delthread_nopermission}</p>
                        <!--{/if}-->
                    </li>
                    <!--{elseif $operation == 'down' || $operation='bump'}-->
                    <li class="wide" id="itemcp_bump" style="padding:0px 0 6px 0;">
                        <p><input type="radio" name="operations[]" id="itemcp_bump" class="weui_check" onclick="if (this.checked)
                                    switchitemcp('itemcp_bump');" value="bump" checked="checked"/>
                            <label onclick="switchitemcp('itemcp_bump');" for="itemcp_bump" class="labeltxt weui_check_label" style="margin:5px 0 10px 0px;"><i class="weui_icon_checked"></i>{lang admin_bump}</label>
                        </p>
                        <p class="hasd wqinput wqnew_all">
                            <input type="text" name="expirationbump" id="expirationbump" readonly onfocus="this.blur();" class="px muidate wqpost_input" placeholder="{lang expire}" tabindex="1">
                        </p>
                    </li>
                    <li class="wide" id="itemcp_down" style="padding:0px 0 0px 0;height:28px;">
                        <input type="radio" name="operations[]" id="itemcp_down"  class="weui_check" onclick="if (this.checked)
                                    switchitemcp('itemcp_down');" value="down"/>
                        <label onclick="switchitemcp('itemcp_down');"  for="itemcp_down" class="labeltxt weui_check_label" style="margin:5px 0 10px 0px;"><i class="weui_icon_checked"></i>{lang admin_down}</label>
                        <a href="javascript:;" class="dpbtn" onclick="showselect(this, 'expirationbump')"></a>
                        <!--
                        <tr class="dopt">
                                <td>&nbsp;</td>
                                <td>
                                        <p class="hasd">
                                                <label for="expirationdown" class="labeltxt">{lang expire}</label>
                                                <input onclick="showcalendar(event, this, true)" type="text" name="expirationdown" id="expirationdown" class="px" autocomplete="off" value="" tabindex="1" />
                                                <a href="javascript:;" class="dpbtn" onclick="showselect(this, 'expirationdown')">^</a>
                                        </p>
                                </td>
                        </tr>
                        -->
                    </li>
                    <script reload="1">
                        $(function () {
                            mui('.muidate').each(function (i, btn) {
                                btn.addEventListener('tap', function () {
                                    var optionsJson = this.getAttribute('data-options') || '{}';
                                    var options = JSON.parse(optionsJson);
                                    var id = this.getAttribute('id');
                                    var picker = new mui.DtPicker(options);
                                    picker.show(function (rs) {
                                         $('#'+id).attr('value',rs.text);
                                        picker.dispose();
                                    });
                                }, false);
                            });
                        })
                    </script>
                    <!--{/if}-->
                </ul>
                <!--{if $operation == 'delete'}-->
                <!--{if ($modpostsnum == 1 || $authorcount == 1) && $crimenum > 0}-->
                <br /><div style="clear: both; text-align: right;">{lang topicadmin_crime_delpost_nums}</div>
                <!--{/if}-->
                <!--{/if}-->
            </div>
            <!--{elseif $_GET['optgroup'] == 4}-->
                <p class="hasd wqinput wqnew_all">
                    <input type="text" name="expirationclose" id="expirationclose" readonly onfocus="this.blur();" class="px muidate wqpost_input" placeholder="{lang expire}" value="$expirationclose" tabindex="1">
<!--                    <input type="text" name="expirationclose" id="expirationclose" placeholder="{lang expire}" class="px" onclick="showcalendar(event, this, true)" autocomplete="off" value="$expirationclose" tabindex="1" />-->
                    <a href="javascript:;" class="dpbtn" onclick="showselect(this, 'expirationclose')"></a>
                </p>
                <p class="wide">
                    <input type="radio" name="operations[]"id="operations_gb" class="pr weui_check" value="open" $closecheck[0]  onclick="$('expirationclose').value = '';" />
                    <label class="weui_check_label"delete><i class="weui_icon_checked"></i>{lang admin_open}</label>
                </p>
                <p class="wide">
                    <input type="radio" name="operations[]"id="operations_gb2" class="pr weui_check" value="close" $closecheck[1] />
                    <label class="weui_check_label" for="operations_gb2"><i class="weui_icon_checked"></i>{lang admin_close}</label>
                </p>
                <script reload="1">
                    $(function () {
                        mui('.muidate').each(function (i, btn) {
                            btn.addEventListener('tap', function () {
                                var optionsJson = this.getAttribute('data-options') || '{}';
                                var options = JSON.parse(optionsJson);
                                var id = this.getAttribute('id');
                                var picker = new mui.DtPicker(options);
                                picker.show(function (rs) {
                                     $('#'+id).attr('value',rs.text);
                                    picker.dispose();
                                });
                            }, false);
                        });
                    })
                </script>
            <!--{elseif $_GET['optgroup'] == 5}-->
                <div class="tplw">
                    <!--{if $operation == 'recommend_group'}-->
                    <input type="hidden" name="operations[]" value="recommend_group" />
                    <p class="mbn tahfx">
                        {lang admin_target}: <select id="moveto" name="moveto" class="ps vm">
                            $forumselect
                        </select>
                    </p>
                    <!--{/if}-->
                </div>
            <!--{/if}-->
            <!--{if empty($hiddensubmit)}-->
            <ul class="wqzhiding">
                <li>
                    <div class="dopt dsn">
                        <p class="hasd">
                            <label class="labeltxt" for="reason">{lang admin_operation_explain}:</label>
                            <!--{eval $reason_select = modreasonselect(1);}-->
                            <!--{if !empty($reason_select)}-->
                            <span class="dopt dsn">
                                <select class="wq_choice" style="width:65%;" onchange="$('#reason').val(this.value)">
                                    {$reason_select}
                                </select>
                            </span>
                            <!--{/if}-->
                            <span class="wqspan">
                                 <textarea id="reason" name="reason" style="width:100%;border: none;text-indent: 0.2em;" class="pt"></textarea>
                            </span>
                        </p>
                        <p>
                            <input type="checkbox" name="sendreasonpm" id="sendreasonpm" class="weui_check"{if $_G['group']['reasonpm'] == 2 || $_G['group']['reasonpm'] == 3} checked="checked" disabled="disabled"{/if} />
                            <label for="sendreasonpm" class="labeltxt weui_check_label"><i class="weui_icon_checked"></i>{lang admin_pm}</label>
                        </p>
                    </div>
                </li>
            </ul>
            <!--{/if}-->
        </div>
        <!--{if empty($hiddensubmit)}-->
        <p class="wqbtn_can wqnew_top">
            <a href="javascript:;" onclick="popup.close();" class="wqeject_cancel wqnew_right">{lang cancel}</a>
            <button type="submit" name="modsubmit" id="modsubmit" class="pn pnc formdialog wqdetermine" value="{lang confirms}"><span>{lang confirms}</span></button>
            <!--<input type="submit" name="modsubmit" id="modsubmit" value="{lang confirms}" class="formdialog wqdetermine">-->
        </p>
        <!--{/if}-->
    </form>
</div>
<!--{template common/footer}-->

<!--{/if}-->