<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['wq_buluopost'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{if $_GET[inajax]}-->
<input type="hidden" name="noticeauthor" value="$noticeauthor" />
<input type="hidden" name="noticetrimstr" value="$noticetrimstr" />
<input type="hidden" name="noticeauthormsg" value="$noticeauthormsg" />
<input type="hidden" name="reppid" value="$reppid" />
<!--{if $_GET[reppost]}-->
<input type="hidden" name="reppost" value="$_GET[reppost]" />
<!--{elseif $_GET[repquote]}-->
<input type="hidden" name="reppost" value="$_GET[repquote]" />
<!--{/if}-->
<!--{eval exit;}-->
<!--{/if}-->

<!--{template common/wq_buluo_tpl_header}-->

<!--{eval $wq_smilies = _buluo_get_system_smilies_from_js();}-->


<!--{eval $adveditor = $isfirstpost && $special && ($_GET['action'] == 'newthread' || $_GET['action'] == 'reply' && !empty($_GET['addtrade']) || $_GET['action'] == 'edit' );}-->
<form method="post" id="postform"
      {if $_GET[action] == 'newthread'}action="forum.php?mod=post&action={if $special != 2}newthread{else}newtrade{/if}&fid=$_G[fid]&extra=$extra&topicsubmit=yes&mobile=2"
      {elseif $_GET[action] == 'reply'}action="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&extra=$extra&replysubmit=yes&mobile=2"
      {elseif $_GET[action] == 'edit'}action="forum.php?mod=post&action=edit&extra=$extra&editsubmit=yes&mobile=2" $enctype
      {/if}>
      <input type="hidden" name="formhash" id="formhash" value="{FORMHASH}" />
    <input type="hidden" name="posttime" id="posttime" value="{TIMESTAMP}"/>
    <!--{if !empty($_GET['modthreadkey'])}--><input type="hidden" name="modthreadkey" id="modthreadkey" value="$_GET['modthreadkey']" /><!--{/if}-->
    <!--{if $_GET[action] == 'reply'}-->
    <input type="hidden" name="noticeauthor" value="$noticeauthor" />
    <input type="hidden" name="noticetrimstr" value="$noticetrimstr" />
    <input type="hidden" name="noticeauthormsg" value="$noticeauthormsg" />
    <!--{if $reppid}-->
    <input type="hidden" name="reppid" value="$reppid" />
    <!--{/if}-->
    <!--{if $_GET[reppost]}-->
    <input type="hidden" name="reppost" value="$_GET[reppost]" />
    <!--{elseif $_GET[repquote]}-->
    <input type="hidden" name="reppost" value="$_GET[repquote]" />
    <!--{/if}-->
    <!--{/if}-->
    <!--{if $_GET[action] == 'edit'}-->
    <input type="hidden" name="fid" id="fid" value="$_G[fid]" />
    <input type="hidden" name="tid" value="$_G[tid]" />
    <input type="hidden" name="pid" value="$pid" />
    <input type="hidden" name="page" value="$_GET[page]" />
    <!--{/if}-->

    <!--{if $special}-->
    <input type="hidden" name="special" value="$special" />
    <!--{/if}-->
    <!--{if $specialextra}-->
    <input type="hidden" name="specialextra" value="$specialextra" />
    <!--{/if}-->
    <!--{block actiontitle}-->
    <!--{if $_GET['action'] == 'newthread'}-->
    <!--{if $special == 0}-->{lang post_newthread}
    <!--{elseif $special == 1}-->{lang post_newthreadpoll}
    <!--{elseif $special == 2}-->{lang post_newthreadtrade}
    <!--{elseif $special == 3}-->{lang post_newthreadreward}
    <!--{elseif $special == 4}-->{lang post_newthreadactivity}
    <!--{elseif $special == 5}-->{lang post_newthreaddebate}
    <!--{elseif $specialextra}-->{$_G['setting']['threadplugins'][$specialextra][name]}
    <!--{/if}-->
    <!--{elseif $_GET['action'] == 'reply' && !empty($_GET['addtrade'])}-->
    {lang trade_add_post}
    <!--{elseif $_GET['action'] == 'reply'}-->
    {lang join_thread}
    <!--{elseif $_GET['action'] == 'edit'}-->
    <!--{if $special == 2}-->{lang edit_trade}<!--{else}-->{lang edit_thread}<!--{/if}-->
    <!--{/if}-->
    <!--{/block}-->
    <!-- main postbox start -->
    <div class="wp post_title wq-relative">{$actiontitle}-<!--{eval echo strip_tags($_G['forum']['name']) ? strip_tags($_G['forum']['name']) : $_G['forum']['name'];}--></div>
<!--    <div class="height47"></div>-->
    <div class="wp">

        <!--{if $_GET[action] == 'newthread'}-->
        <!--{eval $post_nav_num=0;$postform_nav_li='';}-->

        <!--{loop $_G['forum']['threadsorts'][types] $tsortid $name}-->
        <!--{eval $postform_nav_li.=' <li'.($sortid == $tsortid?' class="a"':'').'><a href="forum.php?mod=post&action=newthread&type=wq_buluo&sortid='.$tsortid.'&fid='.$_G['fid'].'">'. strip_tags($name).'</a></li>';$post_nav_num++;}-->
        <!--{/loop}-->

        <!--{if $_G['group']['allowpostpoll']}-->
        <!--{eval $postform_nav_li.=' <li '.$postspecialcheck[1].'><a href="forum.php?mod=post&action=newthread&type=wq_buluo&special=1&fid='.$_G['fid'].'">&#x6295;&#x7968;</a></li>';$post_nav_num++;}-->
        <!--{/if}-->

        <!--{if $_G['group']['allowpostreward']}-->
        <!--{eval $postform_nav_li.=' <li '.$postspecialcheck[3].'><a href="forum.php?mod=post&action=newthread&type=wq_buluo&special=3&fid='.$_G['fid'].'">&#x60AC;&#x8D4F;</a></li>';$post_nav_num++;}-->
        <!--{/if}-->

        <!--{if $_G['group']['allowpostdebate']}-->
        <!--{eval $postform_nav_li.=' <li '.$postspecialcheck[5].'><a href="forum.php?mod=post&action=newthread&type=wq_buluo&special=5&fid='.$_G['fid'].'">&#x8FA9;&#x8BBA;</a></li>';$post_nav_num++;}-->
        <!--{/if}-->

        <!--{if $_G['group']['allowpostactivity']}-->
        <!--{eval $postform_nav_li.=' <li '.$postspecialcheck[4].'><a href="forum.php?mod=post&action=newthread&type=wq_buluo&special=4&fid='.$_G['fid'].'">&#x6D3B;&#x52A8;</a></li>';$post_nav_num++;}-->
        <!--{/if}-->

        <!--{if $_G['group']['allowposttrade']}-->
        <!--{eval $postform_nav_li.=' <li '.$postspecialcheck[2].'><a href="forum.php?mod=post&action=newthread&type=wq_buluo&special=2&fid='.$_G['fid'].'">&#x51FA;&#x552E;</a></li>';$post_nav_num++;}-->
        <!--{/if}-->

        <!--{if !$_G['forum']['threadsorts']['required'] && !$_G['forum']['allowspecialonly']}-->
        <!--{eval $postform_nav_li.='<li '.$postspecialcheck[0].'><a href="forum.php?mod=post&action=newthread&type=wq_buluo&fid='.$_G['fid'].'">&#x5E16;&#x5B50;</a></li>';$post_nav_num++;}-->
        <!--{/if}-->
        <!--{if $post_nav_num>1}-->
        <!--{if $post_nav_num<4}-->
        <!--{eval $post_nav_width=100/$post_nav_num;}-->
        <style> .post_over_li li{width:{$post_nav_width}% }</style>
        <!--{else}-->
        <style>.my_wechat_tag .tag_list{width:2000px;}</style>
        <!--{/if}-->
        <div class="{if $post_nav_num>=4}my_wechat_tag{else}post_over_li{/if}" id="my_wechat_tag" style="overflow: hidden;">
            <div class="tag_list">
                <ul>$postform_nav_li</ul>
            </div>
        </div>
        <!--{/if}-->
        <!--{if $post_nav_num>=4}-->
        <!--{eval $wq_slide=1;$my_group_tag='my_wechat_tag';}-->
        <!--{template common/wq_buluoslide}-->
        <!--{/if}-->
        <!--{/if}-->
        <div class="post_from">
            <ul class="cl">
                <!--{if $isfirstpost && !empty($_G['forum'][threadtypes][types])}-->
                <li class="bl_line">
                    <select id="typeid" name="typeid" class="sort_sel b_all">
                        <option value="0" selected="selected">{lang select_thread_catgory}</option>
                        <!--{loop $_G['forum'][threadtypes][types] $typeid $name}-->
                        <!--{if empty($_G['forum']['threadtypes']['moderators'][$typeid]) || $_G['forum']['ismoderator']}-->
                        <option value="$typeid"{if $thread['typeid'] == $typeid || $_GET['typeid'] == $typeid} selected="selected"{/if}><!--{echo strip_tags($name);}--></option>
                        <!--{/if}-->
                        <!--{/loop}-->
                    </select>
                </li>
                <!--{/if}-->
                <!--{hook/post_bottom_mobile}-->
                <li class="bl_line">
                    <!--{if $sortid}-->
                    <input type="hidden" name="sortid" value="$sortid" />
                    <!--{/if}-->
                    <!--{if $_GET['action'] != 'reply'}-->
                    <input type="text" tabindex="1" class="title_p b_bottom" id="needsubject" size="30" autocomplete="off" value="$postinfo[subject]" name="subject" placeholder="{lang thread_subject}" fwin="login">
                    <!--{if $_GET[action] == 'newthread'||$_GET[action] == 'edit'}-->

                    <!--{if $showthreadsorts}-->
                    <div class="exfm cl bl_none">
                        <!--{template forum/wq_buluopost_sortoption}-->
                    </div>
                    <!--{elseif $adveditor}-->
                    <!--{if $special == 1}-->
                    <!--{template forum/wq_buluopost_poll}-->
                    <!--{elseif $special == 2 && ($_GET[action] != 'edit' || ($_GET[action] == 'edit' && ($thread['authorid'] == $_G['uid'] && $_G['group']['allowposttrade'] || $_G['group']['allowedittrade'])))}-->
                    <!--{template forum/wq_buluopost_trade}-->
                    <!--{elseif $special == 3}-->
                    <!--{template forum/wq_buluopost_reward}-->
                    <!--{elseif $special == 4}-->
                    <!--{template forum/wq_buluopost_activity}-->
                    <!--{elseif $special == 5}-->
                    <!--{template forum/wq_buluopost_debate}-->
                    <!--{elseif $specialextra}-->
                    <div class="specialpost s_clear">$threadplughtml</div>
                    <!--{/if}-->
                    <!--{/if}-->
                    <!--{/if}-->
                    <!--{else}-->
                    <span class="post_reply">RE: $thread['subject']</span>
                    <!--{if $quotemessage}-->$quotemessage<!--{/if}-->
                    <!--{/if}-->
                </li>

                <!--{if $_G[forum_thread][special] == 5 && empty($firststand)}-->
                <li class="point_view b_top_bottom">
                    <select id="stand" name="stand">
                        <option value="">{lang debate_viewpoint}</option>
                        <option value="0"<!--{if $_GET[stand] == '0'}--> selected="selected"<!--{/if}-->>{lang debate_neutral}</option>
                        <option value="1"<!--{if $_GET[stand] == '1'}--> selected="selected"<!--{/if}-->>{lang debate_square}</option>
                        <option value="2"<!--{if $_GET[stand] == '2'}--> selected="selected"<!--{/if}-->>{lang debate_opponent}</option>
                    </select>
                </li>
                <!--{/if}-->
                <div class="bl_none area">
                    <div class="x_line"><textarea class="pt" id="needmessage" tabindex="3" autocomplete="off" id="{$editorid}_textarea" name="$editor[textarea]" cols="80" rows="2"  placeholder="{lang thread_content}" fwin="reply">$postinfo[message]</textarea></div>
                </div>
                <!--{if $_GET[action] != 'edit' && ($secqaacheck || $seccodecheck)}-->
                <!--{template common/seccheck}-->
                <!--{/if}-->
                <li style="position:relative; margin-bottom:10px;">
                    <span class="wqiconfont wqicon-emoji f30 m_l10 c_smile m_r30 wqexpression"></span>
                    <a href="javascript:;" id="upload_icon" class="wqiconfont wqicon-camara f30">
                        <input type="button" id="file_button" style="width:65px;height:40px;font-size:30px;opacity:0; position:absolute; top:0px; left:60px;"/>
                        <input type="file" name="Filedata"  id="filedata"  multiple="multiple" style="display:none" accept="image/*" />
                        <i class="today_p" style="display: none">0</i>
                    </a>

                    <span class="y m_r10">
                        <button id="postsubmit" class="btn_pn <!--{if $_GET[action] == 'edit'}-->btn_pn_blue" disable="false"<!--{else}-->btn_pn_grey" disable="true"<!--{/if}-->><span>

                                <!--{if $_GET[action] == 'newthread'}-->{lang send_thread}<!--{elseif $_GET[action] == 'reply'}-->{lang join_thread}<!--{elseif $_GET[action] == 'edit'}-->
                                {lang edit_save}<!--{/if}--></span></button></span>
                    <!--{if $_GET[action] == 'edit' && $isorigauthor && ($isfirstpost && $thread['replies'] < 1 || !$isfirstpost) && !$rushreply && $_G['setting']['editperdel']}-->
                    <span class="y" style=" line-height: 46px; margin-right:10px;">
                        <input type="checkbox" name="delete" id="weiqing_delete" class="weui_check" value="1">
                        <label class="weui_check_label" for="weiqing_delete"><i class="weui_icon_checked"></i>{lang delete_check}</label>
                    </span>
                    <!--{/if}-->
                </li>
            </ul>
            <!--{template common/wq_buluoupload_image}-->
            <script> upload_image = function (data) {
                    if (data == '') {
                        popup.open('{lang uploadpicfailed}', 'alert');
                    }
                    var dataarr = data.split('|');
                    if (dataarr[0] == 'DISCUZUPLOAD' && dataarr[2] == 0) {
                        popup.close();
                        if ($('#imglist').is(':hidden')) {
                            $('.cellphone_expression').hide();
                            $('.wqexpression').removeClass('c_jianpan').removeClass('wqicon-jianpan').addClass('wqicon-emoji');
                            $('#imglist').show();
                            $('#upload_icon').addClass('blue');
                        }
                        $('#imglist').prepend('<li><span aid="' + dataarr[3] + '" class="del"><a href="javascript:;">\n\
                                 <i class="wqiconfont wqicon-delete f22 wq_del"></i></a></span><span class="p_img"><a href="javascript:;"><img style="height:54px;width:54px;" id="aimg_' + dataarr[3] + '" title="' + dataarr[6] + '" src="{$_G[setting][attachurl]}forum/' + dataarr[5] + '" /></a></span><input type="hidden" name="attachnew[' + dataarr[3] + '][description]" /></li>');
                        $('.today_p').show().text($('#imglist li').length - 1);
                        $('#filedata').val('');
                    } else {
                        var sizelimit = '';
                        if (dataarr[7] == 'ban') {
                            sizelimit = '{lang uploadpicatttypeban}';
                        } else if (dataarr[7] == 'perday') {
                            sizelimit = '{lang donotcross}' + Math.ceil(dataarr[8] / 1024) + 'K)';
                        } else if (dataarr[7] > 0) {
                            sizelimit = '{lang donotcross}' + Math.ceil(dataarr[7] / 1024) + 'K)';
                        }
                        popup.open(STATUSMSG[dataarr[2]] + sizelimit, 'alert');
                    }
                };
            </script>
            <!--{template common/wq_buluosmilies}-->

        </div>
        <!--main postbox start-->
</form>
<script>
    function expression_insertunit(obj) {
        var id_val = $('#needmessage').val();
        $('#needmessage').val(id_val + obj.attr('code'));
    }
    deleteSmilies('{:', ':}');
    $(function () {
        $('.wqexpression').on('click', function () {
            if ($(this).is('.c_jianpan')) {
                $('#needmessage').focus();
            }
            $(this).toggleClass('wqicon-emoji wqicon-jianpan c_jianpan');
            if ($('.cellphone_expression').is(':hidden')) {
                $('#imglist').hide();
                $('.cellphone_expression').show();
                $('#upload_icon').removeClass('blue');
                expression_viwepager();
            } else {
                $('.cellphone_expression').hide();
            }
        });

        var needsubject = needmessage = false;
        if ('{$_GET[action]}' == 'reply') {
            needsubject = true;
        } else if ('{$_GET[action]}' == 'edit') {
            needsubject = needmessage = true;
        }
        if ('{$_GET[action]}' == 'newthread' || ('$_GET[action]' == 'edit' && '$isfirstpost')) {
            $('#needsubject').on('keyup input', function () {
                var obj = $(this);
                if (obj.val()) {
                    needsubject = true;
                    if (needmessage == true) {
                        $('.btn_pn').removeClass('btn_pn_grey').addClass('btn_pn_blue');
                        $('.btn_pn').attr('disable', 'false');
                    }
                } else {
                    needsubject = false;
                    $('.btn_pn').removeClass('btn_pn_blue').addClass('btn_pn_grey');
                    $('.btn_pn').attr('disable', 'true');
                }
            });
        }
        $('#needmessage').on('keyup input', function () {
            var obj = $(this);
            if (obj.val()) {
                needmessage = true;
                if (needsubject == true) {
                    $('.btn_pn').removeClass('btn_pn_grey').addClass('btn_pn_blue');
                    $('.btn_pn').attr('disable', 'false');
                }
            } else {
                needmessage = false;
                $('.btn_pn').removeClass('btn_pn_blue').addClass('btn_pn_grey');
                $('.btn_pn').attr('disable', 'true');
            }
        });
    })
    $(document).on('click', '#postsubmit', function () {
        var form = $('#postform');
        var obj = $('#postsubmit');
        if (obj.attr('disable') == 'true') {
            return false;
        }
        popup.open('<img src="' + IMGDIR + '/imageloading.gif">');
        var postlocation = '';
        if (geo.errmsg === '' && geo.loc) {
            postlocation = geo.longitude + '|' + geo.latitude + '|' + geo.loc;
        }
        $.ajax({
            type: 'POST',
            url: form.attr('action') + '&geoloc=' + postlocation + '&handlekey=' + form.attr('id') + '&inajax=1',
            data: form.serialize(),
            dataType: 'html'
        }).success(function (s) {
            popup.open(wqXml(s));
            if ('$_GET[do]' == 'broadcast') {
                location.href = 'home.php?mod=follow';
            }
        }).error(function () {
            popup.open('{lang networkerror}', 'alert');
        });
        return false;
    });
</script>

<!--{template common/wq_buluo_tpl_footer}-->

<!--{/if}-->