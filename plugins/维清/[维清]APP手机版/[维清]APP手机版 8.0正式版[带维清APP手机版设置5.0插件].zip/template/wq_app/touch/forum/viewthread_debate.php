<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['viewthread_debate'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{if $debate[umpire]}-->
<!--{if $debate['umpirepoint']}-->
<div>
    <p>
        <!--{if $debate[winner]}-->
        <!--{if $debate[winner] == 1}-->
        <label><strong>{lang debate_square}</strong>{lang debate_winner}</label>
        <!--{elseif $debate[winner] == 2}-->
        <label><strong>{lang debate_opponent}</strong>{lang debate_winner}</label>
        <!--{else}-->
        <label><strong>{lang debate_draw}</strong></label>
        <!--{/if}-->
        <!--{/if}-->
        <em>{lang debate_comment_dateline}: $debate[endtime]</em>
    </p>
    <!--{if $debate[umpirepoint]}--><p><strong>{lang debate_umpirepoint}</strong>: $debate[umpirepoint]</p><!--{/if}-->
    <!--{if $debate[bestdebater]}--><p><strong>{lang debate_bestdebater}</strong>: $debate[bestdebater]</p><!--{/if}-->
</div>
<!--{/if}-->
<!--{/if}-->

<!--{eval
$debaters=intval($debate[affirmvotes]+$debate[negavotes]);
$affirm_width=round(($debate[affirmvotes]/$debaters)*100);
$nega_width=round(($debate[negavotes]/$debaters)*100);
$debate['affirmvoterids']=array_filter(explode("\t",$debate['affirmvoterids']));
$debate['negavoterids']=array_filter(explode("\t",$debate['negavoterids']));

}-->
<div class="wqview_debate">
            <div class="wqdebate_landing_item">
                <div class="wqitem"> <span class="wqlanding_pct pro">{$affirm_width}</span><i>%</i><em>{$Tlang['20efd88434a8d35a']}</em><a href="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&stand=1{if $_GET[from]}&from=$_GET[from]{/if}" onclick="showWindow('reply', this.href)"> ( {lang debate_join} )</a></div>
                <div class="wqitem wqjojn_a"> <em>{$Tlang['41036741ecdd9669']}</em><span class="wqlanding_pct op">{$nega_width}</span><i>%</i><a href="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&stand=2{if $_GET[from]}&from=$_GET[from]{/if}" onclick="showWindow('reply', this.href)">( {lang debate_join} )</a></div>
            </div>
            <div class="wqdebate_landing_bar wqdebate_flex">
                <div class="wqdebate_left"><span></span><div></div></div>
                <div class="wqvote_main wqdebate_flex">
                    <div class="wqapp_l" data-style="width: {$affirm_width}%;"> <span class="wqapp_ll"></span> <span class="wqapp_lr"></span> </div>
                    <div class="wqapp_r" data-style="width: {$nega_width}%;"> <span class="wqapp_rl"></span> <span class="wqapp_rr"></span> </div>
                </div>
                <div class="wqdebate_right"> <span></span> <div></div> </div>
            </div>
            <div class="wqdebate_think wqdebate_landing">
                <div class="wqitem{if in_array($_G[uid],$debate[affirmvoterids])} wqapp_opacity{/if}">
                    <a href="forum.php?mod=misc&action=debatevote&tid=$_G[tid]&stand=1" class="wqdig_ok notlogged dialog">
                        <span class="wqicon_zan"><i class="wqiconfont2 wqicon2-gzan wqapp_f20"></i></span>
                        <span class="wqit_title">{lang debate_support}{$Tlang['20efd88434a8d35a']}</span>
                        <span class="wqappok">$debate[affirmvotes]{$Tlang['fda240a40b43c5bf']}</span>
                    </a>
                </div>
                <div class="vs"></div>
                <div class="wqitem{if in_array($_G[uid],$debate[negavoterids])} wqapp_opacity{/if}">
                    <a href="forum.php?mod=misc&action=debatevote&tid=$_G[tid]&stand=2" class="wqdig_ok notlogged dialog">
                        <span class="wqicon_zan"><i class="wqiconfont2 wqicon2-gzan wqapp_f20"></i></span>
                       <span class="wqit_title">{lang debate_support}{$Tlang['41036741ecdd9669']}</span>
                        <span class="wqappok">$debate[negavotes]{$Tlang['fda240a40b43c5bf']}</span>
                    </a>
                </div>
            </div>
</div>
<div class="wqdebate_point">
    <p><span>[{$Tlang['20efd88434a8d35a']}]</span>$debate[affirmpoint]</p>
    <p><span>[{$Tlang['41036741ecdd9669']}]</span>$debate[negapoint]</p>
</div>
<div class="debate_time">
    <!--{if $debate[endtime]}-->
    <p class="end_time">{lang endtime}: $debate[endtime] <br/><!--{if $debate[umpire]}-->{lang debate_umpire}: $debate[umpire]<!--{/if}--></p>
    <!--{/if}-->

    <!--{if $debate[umpire] && $_G['username'] && $debate[umpire] == $_G['member']['username']}-->
    <p class="wqwant_join wqbg_color">
        <!--{if $debate[remaintime] && !$debate[umpirepoint]}-->
        <!--<a href="forum.php?mod=misc&action=debateumpire&tid=$_G[tid]&pid=$post[pid]{if $_GET[from]}&from=$_GET[from]{/if}" >{lang debate_umpire_end}</a>-->
        <a href="forum.php?mod=misc&action=debateumpire&tid=$_G[tid]&pid=$post[pid]&over=1{if $_GET[from]}&from=$_GET[from]{/if}" >{lang debate_umpire_end}</a>
        <!--{elseif TIMESTAMP - $debate['dbendtime'] < 3600}-->
        <a href="forum.php?mod=misc&action=debateumpire&tid=$_G[tid]&pid=$post[pid]{if $_GET[from]}&from=$_GET[from]{/if}" >{lang debate_umpirepoint_edit}</a>
        <!--{/if}-->
    </p>
    <!--{/if}-->
</div>

<script type="text/javascript">
$(function() {
    $('.wq_debatevote').on('click', function() {
        var obj = $(this);
        $.ajax({
            type: 'GET',
            url: obj.attr('href') + '&inajax=1',
            data: {'hash': '{FORMHASH}'},
            dataType: 'html'
        }).success(function(s) {
            var wq = wqXml(s);
            popup.open(wq);
            evalscript(wq);
        }).error(function() {
            window.location.href = obj.attr('href');
            popup.close();
        });
        return false;
    });

    function init(time) {
        var x = time / 20,
            left = $('.wqdebate_flex .wqapp_l'),
            right = $('.wqdebate_flex .wqapp_r'),
            pro = $('.wqlanding_pct.pro'),
            op = $('.wqlanding_pct.op'),
            count = 0,
            prot = pro.text(),
            opt = op.text(),
            spdl = parseInt(pro.text()) / x,
            spd2 = parseInt(op.text()) / x,
            lw = 0,
            rw = 0
        if (pro.text() == 0 && op.text() == 0) return
        var interval = setInterval(function () {
            count++;
            lw += spdl;
            rw += spd2;
            if (lw >100) lw = 100;
            if (rw >100) rw = 100;
            left.width(lw + '%');
            right.width(rw + '%');
            pro.text(parseInt(lw));
            op.text(parseInt(rw));
            if (count > x) {
                clearInterval(interval);
                pro.text(prot);
                op.text(opt);
            }
        }, 20);
    }
    init(800);
});

</script>
<!--{/if}-->