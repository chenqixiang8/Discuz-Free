<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['forumdisplay_pay'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{template common/header}-->

<!--{eval
    $headparams['wtype'] = '1';
    $headparams['lurl'] = $backurl;
    $headparams['ltype'] = 'a';
    $headparams['cname'] = $Tlang['dad186f50093270b'];
    echo wq_app_get_header($headparams);
}-->

<div id="ct" class="wp cl form_pay">
    <div class="mn">
        <div class="nfl">
            <div class="f_c">
                <div class="wqquanxian_icon"><i class="wqiconfont2 wqicon2-quanxian"></i></div>
                <h3 class="xs2 xi2 mbm">{lang youneedpay} <span>$paycredits {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]]['unit']}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]]['title']} </span>{lang onlyintoforum}</h3>
                <div class="wqform_paybtn">
                    <form method="post" autocomplete="off" action="forum.php?mod=forumdisplay&fid=$_G[fid]&action=paysubmit">
                        <input type="hidden" name="formhash" value="{FORMHASH}" />
                        <button class="pn pnc wqbg_color wqwhite" type="submit" name="loginsubmit" value="true">{lang confirmyourpay}</button>
                        <button class="pn vm pnqx" type="button" onclick="history.go(-1)">{lang cancel}</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!--{template common/footer}-->

<!--{/if}-->