<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['viewthread_reward'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{if $_G['forum_thread']['price'] > 0}-->
            <div class="wqreward_view wqred wqapp_f18">
                <i class="wqiconfont2 wqicon2-shang wqapp_f24"></i>
                {$rewardprice}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][title]}<span class="y wqapp_f16"><a href="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]{if $_GET[from]}&from=$_GET[from]{/if}">{$Tlang['1742ce82c560a5a8']}</a></span>
            </div>
<!--{else}-->
            <div class="wqreward_view wqreward_viewgreen wqapp_f18">
                <i class="wqiconfont2 wqicon2-shang wqapp_f24"></i>
               {$rewardprice}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][title]}
            </div>
            <div class="wqreward_answer">
                <h3 class="wqtitle">{lang reward_bestanswer}</h3>
                <div class="wqreward_answer_con">
                    <a href="home.php?mod=space&do=profile&uid=$bestpost[authorid]" class="wqblock wqa_img">$bestpost[avatar]</a>
                    <div class="wqreward_answer_right">
                        <p> <a href="home.php?mod=space&do=profile&uid=$bestpost[authorid]" class="wq_grey">$bestpost[author]</a></p>
                        <p class="wqanswer_content wqellipsis2">$bestpost[message]</p>
                        <p class="wqcomplete_answer"><a href="forum.php?mod=redirect&goto=findpost&ptid=$bestpost[tid]&pid=$bestpost[pid]" >{lang view_full_content}</a></p>
                    </div>
                </div>
            </div>
 <!--{/if}-->
<!--{/if}-->