<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['wq_buluoviewthread_reward'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->

<div class="<!--{if $_G['forum_thread']['price'] > 0}-->reward_lump<!--{else}-->reward_lump_settld<!--{/if}-->">{lang thread_reward}
    <strong>
        <span class="xi1 xs3">$rewardprice</span>
    </strong>
    {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][title]} {if $_G['forum_thread']['price'] > 0}
    <span class="xi1 y">{lang unresolved}</span>{elseif $_G['forum_thread']['price'] < 0}<span class="xg1 y r_settled">{lang resolved}</span>{/if}</div>
<div id="postmessage_$post[pid]" class="postmessage">$post[message]</div>


<!--{if $post['attachment']}-->
<div class="warning">{lang attachment}: <em><!--{if $_G['uid']}-->{lang attach_nopermission}<!--{else}-->{lang attach_nopermission_login}<!--{/if}--></em></div>
<!--{elseif $post['imagelist'] || $post['attachlist']}-->
<!--{if $post['imagelist']}-->
{echo showattach($post, 1)}
<!--{/if}-->
<!--{if $post['attachlist']}-->
{echo showattach($post)}
<!--{/if}-->
<!--{/if}-->
<!--{eval $post['attachment'] = $post['imagelist'] = $post['attachlist'] = '';}-->

<!--{if $bestpost}-->
<div class="rwdbst">
    <h3 class="psth">{lang reward_bestanswer}</h3>
    <div class="pstl">
        <div class="psta"><a href="home.php?mod=space&do=profile&uid=$bestpost[authorid]">$bestpost[avatar]</a></div>
        <div class="psti">
            <p class="xi2">
                <a href="home.php?mod=space&do=profile&uid=$bestpost[authorid]">$bestpost[author]</a>
            </p>
            <div class="mtn">$bestpost[message]<a href="forum.php?mod=redirect&goto=findpost&ptid=$bestpost[tid]&pid=$bestpost[pid]" class="viewmore">{lang view_full_content}</a></div>
        </div>
    </div>
</div>
<!--{/if}-->


<!--{/if}-->