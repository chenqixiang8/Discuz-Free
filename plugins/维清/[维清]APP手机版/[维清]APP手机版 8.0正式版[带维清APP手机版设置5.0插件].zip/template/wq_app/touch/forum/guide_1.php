<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['guide_1'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{if $_GET['update']='update' &&  $_GET['inajax']}-->
<ul class="wqfollow_list_ul" id="update">
<!--{/if}-->
<!--{loop $push $key $val}-->
    <li class="wqnew_bottom">
        <a href="forum.php?mod=forumdisplay&fid={$val['fid']}">
            <div class="wqfollow_list_img">
                <!--{if $val[icon]}-->
                    <img src="$_G['setting']['attachurl']common/$val[icon]" alt="$val[name]" />
                <!--{else}-->
                    <img src="{$_G['style'][styleimgdir]}images/forum{if $val[folder]}_new{/if}.gif" alt="$val[name]" />
                <!--{/if}-->
            </div>
            <div class="wqtitle"><span class="wqname wqellipsis">$val['name']</span></div>
            <div class="wqdesc wqellipsis"><span class="wqm_right10">$val['threads']{$Tlang['7d938b8372235f6b']}</span><span>$val['favtimes']{$Tlang['afa0307eee1d3577']}</span></div>
        </a>
        <div  class="wqcancel_follow wqbg_color">
            <a href="javascript:;" data-href="home.php?mod=spacecp&ac=favorite&type=forum&id=$val[fid]"  class="wqwhite notlogged wqfav-button" data="$val[fid]">{$Tlang['2c8a07313e7706bc']}</a>
        </div>
    </li>
<!--{/loop}-->
<!--{if $_GET['update']='update' &&  $_GET['inajax']}-->
</ul>
<!--{/if}-->


<!--{/if}-->