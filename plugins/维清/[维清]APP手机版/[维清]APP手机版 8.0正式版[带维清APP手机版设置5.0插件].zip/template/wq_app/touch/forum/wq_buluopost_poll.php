<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['wq_buluopost_poll'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<input type="hidden" name="polls" value="yes" />
<div class="exfm cl b_bottom">
	<div class="sinf sppoll z poll_ft">
		<input type="hidden" name="fid" value="$_G[fid]" />
		<!--{if $_GET[action] == 'newthread'}-->
			<input type="hidden" name="tpolloption" value="1" />
			<div class="cl">
				<h4 class="z">
					{lang post_poll_comment} &nbsp;
					<span class="xw0">
                                            <input id="pollchecked" type="checkbox" class="weui_check" onclick="switchpollm(1)" />
                                            <label class="weui_check_label" for="pollchecked"><i class="weui_icon_checked"></i>{lang post_single_frame_mode}</label>
                                        </span>
				</h4>
			</div>
			<div id="pollm_c_1" class="mbm xz_poll">
                            <span id="polloption_new"></span>
                            <p id="polloption_hidden" style="display: none">
                                <a href="javascript:;" id="" class="po">
                                    <input type="file" class="file_button" id="pollUploadProgress"  name="Filedata"  index="file_index" style="width:40px;height:38px;font-size:30px;opacity:0; position:absolute; top:0px;right:0px;">
                                    <i class="wqiconfont wqicon-21 f22" id="newpoll"></i>
                                </a>
				<a href="javascript:;" class="d icon wqiconfont wqicon-poll f20 orange" onclick="delpolloption(this)"></a>
				<input type="text" name="polloption[]" class="px vm " autocomplete="off"tabindex="1" />
                            </p>
                            <p class="zj_add b_top"><a href="javascript:;" onclick="addpolloption()">+{lang post_poll_add}</a></p>
			</div>
			<div id="pollm_c_2" class="mbm single_frame b_top" style="display:none">
                            <div class="frame_p b_bottom">
                            <div class="x_line"><textarea name="polloptions" class="pt" tabindex="1" rows="6" onchange="switchpollm(0)" /></textarea></div></div>
				<p class="cl t_xian_t">{lang post_poll_comment_s}</p>
			</div>
		<!--{else}-->
			<!--{loop $poll['polloption'] $key $option}-->
				<!--{eval $ppid = $poll['polloptionid'][$key];}-->
				<p>
					<input type="hidden" name="polloptionid[{$poll[polloptionid][$key]}]" value="$poll[polloptionid][$key]" />
					<input type="text" name="displayorder[{$poll[polloptionid][$key]}]" class="px pxs vm" autocomplete="off" tabindex="1" value="$poll[displayorder][$key]" />
					<input type="text" name="polloption[{$poll[polloptionid][$key]}]" class="px vm" autocomplete="off" tabindex="1" value="$option"{if !$_G['group']['alloweditpoll']} readonly="readonly"{/if} />
					<!--img src="$poll[imginfo][$ppid][small]" class="cur1" /-->

					<span id="newpoll_{$key}" class="vm"></span>
					<span id="pollUploadProgress_{$key}" class="vm">
						<!--{if $poll[isimage]}-->
						<img src="{IMGDIR}/attachimg_2.png" class="cur1" onmouseover="showMenu({'menuid':'poll_img_preview_{$poll[imginfo][$ppid][aid]}_menu','ctrlclass':'a','duration':2,'timeout':0,'pos':'34'});" onmouseout="hideMenu('poll_img_preview_{$poll[imginfo][$ppid][aid]}_menu');" />
						<!--{/if}-->
						<input type="hidden" name="pollimage[{$poll[polloptionid][$key]}]" id="pollUploadProgress_{$key}_aid" value="$poll[imginfo][$ppid][aid]" />
						<span id="poll_img_preview_{$poll[imginfo][$ppid][aid]}_menu" style="display: none">
							<img src="$poll[imginfo][$ppid][small]" />
						</span>
					</span>
				</p>
			<!--{/loop}-->
			<span id="polloption_new"></span>
			<p id="polloption_hidden" style="display: none">
				<a href="javascript:;" class="d" onclick="delpolloption(this)">del</a>
				<input type="text" name="displayorder[]" class="px pxs vm" autocomplete="off" tabindex="1" />
				<input type="text" name="polloption[]" class="px vm" autocomplete="off"tabindex="1" />
				<span id="newpoll" class="vm"></span>
				<span id="pollUploadProgress" class="vm" style="display: none;"></span>
			</p>
			<p class="zj_add"><a href="javascript:;" onclick="addpolloption()">+{lang post_poll_add}</a></p>
		<!--{/if}-->
	</div>
	<div class="sadd z">
		<p class="mbn b_top">
			<label for="maxchoices">{lang post_poll_allowmultiple}
			<input type="tel" name="maxchoices" id="maxchoices" class="poll_px pxs" value="{if $_GET[action] == 'edit' && $poll[maxchoices]}$poll[maxchoices]{else}1{/if}" tabindex="1" />
                        <em>{lang post_option}</em></label>
		</p>
		<p class="mbn b_top">
			<label for="polldatas">{lang post_poll_expiration}
                         <input type="tel" name="expiration" id="polldatas" class="poll_px pxs" value="{if $_GET[action] == 'edit'}{if !$poll[expiration]}0{elseif $poll[expiration] < 0}{lang poll_close}{elseif $poll[expiration] < TIMESTAMP}{lang poll_finish}{else}{echo (round(($poll[expiration] - TIMESTAMP) / 86400))}{/if}{/if}" tabindex="1" /> <em>{lang days}</em>
		</label>
                </p>
		<p class="mbn b_top">
                    <input type="checkbox" name="visibilitypoll" id="visibilitypoll" class="weui_check" value="1"{if $_GET[action] == 'edit' && !$poll[visible]} checked{/if} tabindex="1" />
                           <label class="weui_check_label" for="visibilitypoll"><i class="weui_icon_checked"></i>{lang poll_after_result}
                        </label>
		</p>
		<p class="mbn b_top">
                    <input type="checkbox" name="overt" id="overt" class="weui_check" value="1"{if $_GET[action] == 'edit' && $poll[overt]} checked{/if} tabindex="1" />
                           <label class="weui_check_label" for="overt"><i class="weui_icon_checked"></i>{lang post_poll_overt} </label>
		</p>
		<!--{hook/post_poll_extra}-->
	</div>
</div>
<script>
        var index_data
        var uploadsuccess_poll= function(data) {
            if(data == '') {
                popup.open('{lang uploadpicfailed}', 'alert');
            }
            var result = jQuery.parseJSON(data);
            if(result.aid=='0'){
               popup.open(STATUSMSG[result.errorcode], 'alert');
            }
            if(result.smallimg) {
                popup.close();
                $('#newpoll_'+index_data).html('<img src="'+result.smallimg+'" /><input type="hidden" name="pollimage[]" value="'+result.aid+'">').attr('class',null);
            }
       };
       $(document).on('change', '.file_button', function() {
              index_data=$(this).attr('index');
              picture(uploadsuccess_poll,$(this).attr('id'),'Filedata','misc.php?mod=swfupload&action=swfupload&operation=poll&fid=$_G[fid]');
       })

function trim(str) {
	return str.replace(/^\s*(.*?)[\s\n]*$/g, '$1');
}
function display(id) {
	var obj = document.getElementById(id);
	if(obj.style.visibility) {
		obj.style.visibility = obj.style.visibility == 'visible' ? 'hidden' : 'visible';
	} else {
		obj.style.display = obj.style.display == '' ? 'none' : '';
	}
}
function switchpollm(swt) {
	t = document.getElementById('pollchecked').checked && swt ? 2 : 1;
	var v = '';
	for(var i = 0; i < document.getElementById('postform').elements.length; i++) {
		var e = document.getElementById('postform').elements[i];
		if(!isUndefined(e.name)) {
			if(e.name.match('^polloption')) {
				if(t == 2 && e.tagName == 'INPUT') {
					v += e.value + '\n';
				} else if(t == 1 && e.tagName == 'TEXTAREA') {
					v += e.value;
				}
			}
		}
	}
	if(t == 1) {
		var a = v.split('\n');
		var pcount = 0;
		for(var i = 0; i < document.getElementById('postform').elements.length; i++) {
			var e = document.getElementById('postform').elements[i];
			if(!isUndefined(e.name)) {
				if(e.name.match('^polloption')) {
					pcount++;
					if(e.tagName == 'INPUT') e.value = '';
				}
			}
		}
		for(var i = 0; i < a.length - pcount + 2; i++) {
			addpolloption();
		}
		var ii = 0;
		for(var i = 0; i < document.getElementById('postform').elements.length; i++) {
			var e = document.getElementById('postform').elements[i];
			if(!isUndefined(e.name)) {
				if(e.name.match('^polloption') && e.tagName == 'INPUT' && a[ii]) {
					e.value = a[ii++];
				}
			}
		}
	} else if(t == 2) {
		document.getElementById('postform').polloptions.value = trim(v);

	}
	document.getElementById('postform').tpolloption.value = t;
	if(swt) {
		display('pollm_c_1');
		display('pollm_c_2');
	}
}

var maxoptions = parseInt('$_G[setting][maxpolloptions]');
function addpolloption() {
	if(curoptions < maxoptions) {
		var imgid = 'newpoll_'+curnumber;
		var proid = 'pollUploadProgress_'+curnumber;
		var pollstr = document.getElementById('polloption_hidden').innerHTML.replace('newpoll', imgid).replace('file_index', curnumber);
		pollstr = pollstr.replace('pollUploadProgress', proid);
		document.getElementById('polloption_new').outerHTML = '<p class=b_top>' + pollstr + '</p>' + document.getElementById('polloption_new').outerHTML;
		curoptions++;
		curnumber++;
	} else {
		document.getElementById('polloption_new').outerHTML = '<span>??????��??��???��??'+maxoptions+'</span>';
	}
}
<!--{if $_GET[action] == 'newthread'}-->
	var curoptions = 0;
	var curnumber = 1;
	addpolloption();
	addpolloption();
	addpolloption();
<!--{else}-->
	var curnumber = curoptions = <!--{echo count($poll['polloption'])}-->;
	for(var i=0; i < curnumber; i++) {
		addUploadEvent('newpoll_'+i, 'pollUploadProgress_'+i);
	}
<!--{/if}-->
function delpolloption(obj) {
	obj.parentNode.parentNode.removeChild(obj.parentNode);
	curoptions--;
}
function addUploadEvent(imgid, pollstr) {
	<!--{if empty($_G['setting']['pluginhooks']['post_upload_extend']) && empty($_G['setting']['pluginhooks']['post_poll_upload_extend'])}-->
		new SWFUpload({
			upload_url: SITEURL + 'misc.php?mod=swfupload&action=swfupload&operation=poll&fid=$_G[fid]',
			post_params: {"uid":"$_G[uid]", "hash":"$swfconfig[hash]"},

			file_size_limit : "2048",
			file_types : "*.jpg;*.jpeg;*.gif;*.png;*.bmp",
			file_types_description : "{lang pictypefile}",
			file_upload_limit : 0,
			file_queue_limit : 1,

			swfupload_preload_handler : preLoad,
			swfupload_load_failed_handler : loadFailed,
			file_dialog_start_handler : fileDialogStart,
			file_queued_handler : fileQueued,
			file_queue_error_handler : fileQueueError,
			file_dialog_complete_handler : fileDialogComplete,
			upload_start_handler : uploadStart,
			upload_progress_handler : uploadProgress,
			upload_error_handler : uploadError,
			upload_success_handler : uploadSuccess,
			upload_complete_handler : uploadComplete,

			button_image_url : IMGDIR+"/uploadbutton_small_pic.png",
			button_placeholder_id : imgid,
			button_width: 26,
			button_height: 26,
			button_cursor:SWFUpload.CURSOR.HAND,
			button_window_mode: "transparent",

			custom_settings : {
				progressTarget : pollstr,
				uploadSource: 'forum',
				uploadType: 'poll'
			},

			debug: false
		});
	<!--{else}-->
		<!--{hook/post_poll_upload_extend}-->
	<!--{/if}-->
}

</script>
<!--{/if}-->