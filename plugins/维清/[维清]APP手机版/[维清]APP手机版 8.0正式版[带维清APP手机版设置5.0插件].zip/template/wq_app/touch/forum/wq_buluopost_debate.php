<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['wq_buluopost_debate'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<div class="exfm cl b_bottom">
    <div class="sinf sppoll z">
        <dl>
            <dt><label for="affirmpoint">{lang debate_square_point}:</label><span class="rq">*</span></dt>
            <dd class="b_bottom x_line"><textarea name="affirmpoint" id="affirmpoint" class="pt" tabindex="1">$debate[affirmpoint]</textarea></dd>
            <dt><label for="negapoint">{lang debate_opponent_point}:</label><span class="rq">*</span></dt>
            <dd class="b_bottom x_line"><textarea name="negapoint" id="negapoint" class="pt" tabindex="1">$debate[negapoint]</textarea></dd>
        </dl>
    </div>
    <div class="sadd z">
        <dl class="b_bottom">
            <dt><label for="endtime">{lang endtime}:</label></dt>
            <dd class="hasd cl">
                <input type="text" name="endtime" id="endtime" class="px" onclick="showcalendar(event, this, true)" autocomplete="off" value="$debate[endtime]" tabindex="1" />
                <a href="javascript:;" class="dpbtn" onclick="showselect(this, 'endtime')"></a>
            </dd>
        </dl>
        <dl class="bl_none">
            <dt><label for="umpire">{lang debate_umpire}:</label></dt>
            <dd>
                <p><input type="text" name="umpire" id="umpire" class="px bl_none" onblur="checkuserexists(this.value, 'checkuserinfo')" value="$debate[umpire]" tabindex="1" />
<span id="checkuserinfo"></span></p>
            </dd>
            <!--{hook/post_debate_extra}-->
        </dl>
    </div>
</div>
<!--{eval $datetype="datetime";}-->
<!--{template common/wq_buluocalendar}-->
<script type="text/javascript">
$(function() {
     $("#endtime").mobiscroll(opt);
});
var  timer;
function getclose(){
     popup.close();
      clearInterval(timer)
 }
function checkuserexists(username, objname) {
        var username=$.trim(username)
        if(username) {
            $.get('forum.php?mod=ajax&inajax=1&action=checkuserexists&username=' + username,'', function(s){
                popup.open(s.lastChild.firstChild.nodeValue)
                timer = setInterval(getclose, 1500)
            }, "xml");
        }
}
</script>

<!--{/if}-->