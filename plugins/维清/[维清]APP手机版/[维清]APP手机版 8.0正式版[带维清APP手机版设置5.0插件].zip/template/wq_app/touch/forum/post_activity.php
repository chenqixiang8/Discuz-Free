<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['post_activity'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<li class="wqnew_bottom">
    <select name="activitytime"  class="wqpost_select" id="activitytime">
        <option value="0">{$Tlang['15c6234b9ddc714e']}</option>
        <option value="1">{$Tlang['84b406ce5924c679']}</option>
    </select>
</li>
<li class="wqnew_bottom"><span class="rq wqrequired">*</span>
    <input type="text" name="starttimefrom[0]" readonly onfocus="this.blur();" id="activity_data1" data-options="" class="muidate wqpost_input" placeholder="{lang post_event_time}">
    <input type="text" name="starttimefrom[1]" readonly onfocus="this.blur();" id="activity_data2" data-options="" class="muidate wqpost_input" placeholder="{lang post_event_time}" style="display:none;">
    <span style="display:none;"> ~ </span>
    <input type="text" name="starttimeto" readonly onfocus="this.blur();" id="activity_data3" data-options="" class="muidate wqpost_input" placeholder="" style="display:none;">
</li>
<li class="wqnew_bottom"><span class="rq wqrequired">*</span><input type="text" name="activityplace" id="activityplace" class="wqpost_input" placeholder="{lang activity_space}"></li>
<!--{if $_GET[action] == 'newthread'}-->
    <li class="wqnew_bottom"><input type="text" id="activitycity" name="activitycity" class="wqpost_input" placeholder="{lang activity_city}" type="text" tabindex="1"></li>
<!--{/if}-->
<li class="wqnew_bottom">
<span class="rq wqrequired">*</span>
    <select name="activityclass" class="wqpost_select" id="classid">
        <option value="0">{lang activiy_sort}</option>
        <!--{if $activitytypelist}-->
            <!--{loop $activitytypelist $type}-->
                <option value="{$type}">{$type}</option>
            <!--{/loop}-->
        <!--{/if}-->
        <option value="1">{$Tlang['3a65f84458489c5a']}</option>
    </select>
</li>
<li class="wqnew_bottom"><input type="text" name="activitynumber" id="activitynumber" onkeyup="checkvalue(this.value, 'activitynumbermessage')" value="$activity[number]" tabindex="1"class="wqpost_input" placeholder="{lang activity_need_member}"><span id="activitynumbermessage"></span></li>
<li class="wqnew_bottom">
    <select name="gender" id="gender" width="38" class="wqpost_select">
        <option value="0" {if !$activity['gender']}selected="selected"{/if}>{lang unlimited}</option>
        <option value="1" {if $activity['gender'] == 1}selected="selected"{/if}>{lang male}</option>
        <option value="2" {if $activity['gender'] == 2}selected="selected"{/if}>{lang female}</option>
    </select>
</li>
<!--{if $_G['setting']['activityfield']}-->
    <li class="wqnew_bottom">
        <p class="wq_grey2">{lang optional_data}</p>
        <p class="wq_grey2">
            <!--{loop $_G['setting']['activityfield'] $key $val}-->
            <span class="wqm_right10">
                <input type="checkbox" name="userfield[]" id="userfield_$key" class="weui_check" value="$key"{if $activity['ufield']['userfield'] && in_array($key, $activity['ufield']['userfield'])} checked="checked"{/if} />
                <label class="weui_check_label" for="userfield_$key"><i class="weui_icon_checked"></i>$val</label>
            </span>
            <!--{/loop}-->
        </p>
    </li>
<!--{/if}-->
<!--{if $_G['setting']['activityextnum']}-->
    <li class="wqnew_bottom">
        <textarea name="extfield" id="extfield" class="wqpost_textarea" cols="50" placeholder="{lang other_data}" ><!--{if $activity['ufield']['extfield']}-->$activity[ufield][extfield]<!--{/if}--></textarea>
        {lang post_activity_message} $_G['setting']['activityextnum'] {lang post_option}
    </li>
<!--{/if}-->
<!--{if $_G['setting']['activitycredit']}-->
    <li class="wqnew_bottom">
        <input type="tel" name="activitycredit" id="activitycredit" class=" wqpost_input" placeholder="{lang consumption_credit}" value="$activity[credit]"><i class="wqpost_li_small wqapp_f14">{$_G['setting']['extcredits'][$_G['setting']['activitycredit']][title]}</i>
    </li>
<!--{/if}-->
<li class="wqnew_bottom"><input type="tel" name="cost" id="cost" class="wqpost_input" placeholder="{lang activity_payment}" onkeyup="checkvalue(this.value, 'costmessage')" value="$activity[cost]" tabindex="1" ><i class="wqpost_li_small wqapp_f14">{lang payment_unit}</i></li>
<li class="wqnew_bottom"><input type="text" name="activityexpiration" readonly onfocus="this.blur();" id="activityexpiration" class="muidate wqpost_input" placeholder="{lang post_closing}" autocomplete="off" value="$activity[expiration]" tabindex="1"></li>
<!--{if !$allowpostimg}-->
<li class="wqnew_bottom">
    <div class="ac_pic">
        <p>
           <input type="button" class="pn" id="activity_image">
           <span>{$Tlang['b0a34313efca5a88']}</span>
        </p>
        <div id="activityattach_image" class="wqupload_pic_img">
            <!--{if $activityattach[attachment]}-->
            <div class="wqm_top10">
                <img src="$activityattach[url]/{if $activityattach['thumb']}{eval echo getimgthumbname($activityattach['attachment']);}{else}$activityattach[attachment]{/if}"/>
                <input type="hidden" name="activityaid" id="activityaid" value="$activityattach[aid]" />
            </div>
            <!--{/if}-->
        </div>
    </div>
</li>
<!--{/if}-->
<div class="dialogbox class-create" style="width: 280px;position: fixed;left: 47.5px;top: 270px;z-index: 122;opacity: 1;display:none;">
    <div class="wqshield_notice" style="padding-top:10px">
        <form id="moderateform" method="post" autocomplete="off" action="forum.php?mod=topicadmin&amp;action=moderate&amp;optgroup=3&amp;modsubmit=yes&amp;mobile=2">
            <div class="wqshield_con">
                <p><input type="text" class="new_className" placeholder="{$Tlang['32d53a1effca5f9f']}" style="height:35px;width:100%;border:none;"></p>
            </div>
            <p class="wqbtn_can wqnew_top">
                <a href="javascript:;" class="wqeject_cancel wqnew_right">{$Tlang['9c825be7149e5b97']}</a>
                <input type="button" class="wqdetermine" value="{$Tlang['984c5e7090423fd1']}">
            </p>
        </form>
    </div>
</div>
<script type="text/javascript" src="{$_G['style']['styleimgdir']}js/forum/post_activity.js?{VERHASH}"></script>





<!--{/if}-->