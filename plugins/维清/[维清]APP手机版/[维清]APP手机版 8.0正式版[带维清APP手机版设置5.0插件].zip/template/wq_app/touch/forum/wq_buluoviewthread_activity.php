<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['wq_buluoviewthread_activity'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<div class="mbn activity tx_theme">
    <div class="activity_in">
        <!--{if $activity['thumb']}-->
        <div class="theme_img">
            <img src="$activity['thumb']"/>
        </div>
        <!--{/if}-->
        <dl>
            <dd class="orange">{lang activity_type}:</dd>
            <dt><strong>$activity[class]</strong></dt>
        </dl>
        <dl>
            <dd><i>{lang activity_starttime}:</i></dd>
            <dt>
            <!--{if $activity['starttimeto']}-->
            {lang activity_start_between}
            <!--{else}-->
            $activity[starttimefrom]
            <!--{/if}-->
            </dt>
        </dl>
        <dl>
            <dd><i>{lang activity_space}:</i></dd>
            <dt> $activity[place]</dt>
        </dl>
        <dl>
            <dd><i>{lang gender}:</i></dd>
            <dt>
            <!--{if $activity['gender'] == 1}-->
            {lang male}
            <!--{elseif $activity['gender'] == 2}-->
            {lang female}
            <!--{else}-->
            {lang unlimited}
            <!--{/if}-->
            </dt>
        </dl>
        <!--{if $activity['cost']}-->
        <dl>
            <dd><i>{lang activity_payment}:</i></dd>
            <dt> $activity[cost] {lang payment_unit}</dt>
        </dl>
        <!--{/if}-->
    </div>
    <!--{if !$_G['forum_thread']['is_archived']}-->
    <dl class="mtn">
        <dd><i>&#x5DF2;&#x62A5;&#x540D;:</i></dd>
        <dt><em>$allapplynum</em> {lang activity_member_unit}
        <!--{if $post['invisible'] == 0 && ($_G['forum_thread']['authorid'] == $_G['uid'] || (in_array($_G['group']['radminid'], array(1, 2)) && $_G['group']['alloweditactivity']) || ( $_G['group']['radminid'] == 3 && $_G['forum']['ismoderator'] && $_G['group']['alloweditactivity']))}-->
        <!--<span class="xi1">{lang activity_mod}</span>-->
        <!--{/if}-->
        </dt>
    </dl>
    <!--{if $activity['number']}-->
    <dl>
        <dd><i>{lang activity_about_member}:</i></dd>
        <dt> $aboutmembers {lang activity_member_unit}</dt>
    </dl>
    <!--{/if}-->
    <!--{if $activity['expiration']}-->
    <dl>
        <dd><i>{lang post_closing}:</i></dd>
        <dt>$activity[expiration]</dt>
    </dl>
    <!--{/if}-->
    <!--{if $post['invisible'] == 0}-->
    <!--{if ($applied && $isverified < 2)||(!$activityclose &&$isverified == 2)}-->
    <dl>
        <dt>
        <!--{if $applied && $isverified < 2}-->
        <p class="xg1 xs1 through_activity">
            <!--{if !$isverified}-->
            {lang activity_wait}
            <!--{else}-->
            {lang activity_join_audit}
            <!--{/if}-->
        </p>
        <!--{elseif !$activityclose &&$isverified == 2}-->
        <p class="pns mtn"><input value="{lang complete_data}" name="ijoin" id="ijoin" /></p>
        <!--{/if}-->
        </dt>
    </dl>
    <!--{/if}-->
    <!--{/if}-->
    <!--{/if}-->
</div>

<!--{if $_G['uid'] && !$activityclose && (!$applied || $isverified == 2)}-->
<div id="activityjoin" class="bm m_t20">
    <div class="join pd5">
        <div class="xw1 b_bule_5" id="activity_joins">{lang activity_join}<i class="y wqiconfont wqicon-down_1 cancel_arrow f20"></i></div>
        <!--{if $_G['forum']['status'] == 3 && helper_access::check_module('group') && $isgroupuser != 'isgroupuser'}-->
        <p>{lang activity_no_member}</p>
        <p><strong></strong><a href="forum.php?mod=group&action=join&fid=$_G[fid]" class="xi2">{lang activity_join_group}</a></p>
        <!--{else}-->
        <form name="activity" id="activity" style="display: none" method="post" autocomplete="off" action="forum.php?mod=misc&action=activityapplies&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]{if $_GET['from']}&from=$_GET['from']{/if}&mobile=2" >
            <input type="hidden" name="formhash" value="{FORMHASH}" />
            <!--{if $_G['setting']['activitycredit'] && $activity['credit'] && !$applied}-->
            <p class="xi1">{lang activity_need_credit} $activity[credit] {$_G['setting']['extcredits'][$_G['setting']['activitycredit']][title]}</p><!--{/if}-->
            <!--{if $activity['cost']}-->
            <div class="mode_pay"><p><strong>{lang activity_paytype}</strong>
                    <input class="weui_check" type="radio" value="0" name="payment" id="payment_0" checked="checked">
                    <label class="weui_check_label"  for="payment_0"><i class="weui_icon_checked"></i>{lang activity_pay_myself}</label></p>
                <p><strong class="m_l5"></strong>
                    <input class="weui_check" type="radio" value="1" name="payment" id="payment_1" />
                    <label class="weui_check_label" for="payment_1"><i class="weui_icon_checked"></i>{lang activity_would_payment} </label>
                <input name="payvalue" size="3" class="txt_s b_all" id="money" onfocus="$('#payment_1').click()"/> {lang payment_unit}<p></div>
            <!--{/if}-->
            <!--{if !empty($activity['ufield']['userfield'])}-->
            <div id='userfield'>
                <!--{loop $activity['ufield']['userfield'] $fieldid}-->
                <!--{if $settings[$fieldid][available]}-->
                <strong>$settings[$fieldid][title]<span class="xi1">*</span></strong>
                $htmls[$fieldid]
                <!--{/if}-->
                <!--{/loop}-->
            </div>
            <!--{/if}-->
            <!--{if !empty($activity['ufield']['extfield'])}-->
            <!--{loop $activity['ufield']['extfield'] $extname}-->
            <strong>$extname</strong><input type="text" name="$extname" maxlength="200" class="px m_l10 m_t10" value="{if !empty($ufielddata)}$ufielddata[extfield][$extname]{/if}" /><br/>
            <!--{/loop}-->
            <!--{/if}-->
            <strong class="mess_ly">{lang leaveword}</strong>
            <div class="mess_txt b_all">
                <textarea name="message" maxlength="200" cols="28" rows="1" class="txt">$applyinfo[message]</textarea></div>
            <div class="o pns hd_submit">
                <!--{if $_G['setting']['activitycredit'] && $activity['credit'] && checklowerlimit(array('extcredits'.$_G['setting']['activitycredit'] => '-'.$activity['credit']), $_G['uid'], 1, 0, 1) !== true}-->
                <p class="xi1">{$_G['setting']['extcredits'][$_G['setting']['activitycredit']][title]} {lang not_enough}$activity['credit']</p>
                <!--{else}-->
                <input type="hidden" name="activitysubmit" value="true">
                <em class="xi1" id="return_activityapplies"></em>
                <button id="activity_joins_submit" type="button" class="v_submit"><span>{lang submit}</span></button>
                <!--{/if}-->
            </div>
        </form>
        <script type="text/javascript">
            $('#activity_joins').click(function () {
                $('#activity').toggle();
                $(this).children().toggleClass('wqicon-down_1 wqicon-up_1');
            });
            $('#activity_joins_submit').click(function () {
                var obj = $('#activity');
                $.ajax({
                    type: 'POST',
                    url: obj.attr('action') + '&inajax=yes',
                    data: obj.serialize(),
                    dataType: 'html'
                }).success(function (s) {
                    popup.open(wqXml(s));
                }).error(function () {
                    popup.open('{lang networkerror}', 'alert');
                });
                return false;
            });
            function succeedhandle_activityapplies(locationhref, message) {
                setTimeout(function () {
                    location.href = locationhref;
                }, 1500);
            }
        </script>
        <!--{/if}-->
    </div>
</div>
<!--{elseif $_G['uid'] && !$activityclose && $applied}-->
<div id="activityjoincancel" class="bm mtn">
    <div class="join pd5">
        <div class="xw1" id="activity_cancel">{lang activity_join_cancel}<i class="y wqiconfont wqicon-down_1 cancel_arrow f20"></i></div>
        <form name="activity" id="activity_form" style="display: none" method="post" autocomplete="off" action="forum.php?mod=misc&action=activityapplies&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]{if $_GET['from']}&from=$_GET['from']{/if}">
            <input type="hidden" name="formhash" value="{FORMHASH}" />
            <p>
                <strong class="qx_mess">{lang leaveword}</strong><span class="mess_txt b_all"><textarea type="text" name="message" maxlength="200" class="txt" value="" /></textarea></span>
            </p>
            <p class="mtn">
                <input type="hidden" name="activitycancel" value="true">
                <button type="button" id="activity_cancel_submit" class="v_submit"><span>{lang submit}</span></button>
            </p>
        </form>
    </div>
</div>
<script type="text/javascript">
    $('#activity_cancel').click(function () {
        $('#activity_form').toggle();
        $(this).children().toggleClass('wqicon-down_1 wqicon-up_1');
    });
    $('#activity_cancel_submit').click(function () {
        var obj = $('#activity_form');
        $.ajax({
            type: 'POST',
            url: obj.attr('action') + '&inajax=yes',
            data: obj.serialize(),
            dataType: 'html'
        }).success(function (s) {
            popup.open(wqXml(s));
        }).error(function () {
            popup.open('{lang networkerror}', 'alert');
        });
        return false;
    });
    function succeedhandle_activityapplies(locationhref, message) {
        setTimeout(function () {
            location.href = locationhref;
        }, 1500);
    }
</script>
<!--{elseif !$_G['uid']}-->
<div class="xw1 b_bule_5 m_t20"><a href="member.php?mod=logging&action=login" class="dialog notlogged">{$Tlang['4218475e1ba09401']}<i class="wqiconfont wqicon-youyou f18 y"></i></a></div>
<!--{/if}-->
<!--{if $applylist}-->
<div class="ptn pbn xs1">
    <div class="through_per">
        <p class="pd5 xw1 b_bule_5">{lang activity_new_join} <i class="y p_r10">$applynumbers {lang activity_member_unit}</i></p>
        <div class="dt apply_in">
            <ul>
                <!--{loop $applylist $apply}-->
                <li>
                    <a  href="home.php?mod=space&do=profile&uid=$apply[uid]"><img src="<!--{avatar($apply[uid], small, true)}-->" /></a>
                </li>
                <!--{/loop}-->
            </ul>
        </div>
    </div>
</div>
<!--{/if}-->

<!--{if trim($post[message])!='<br />'}-->
<div id="postmessage_$post[pid]" class="postmessage">$post[message]</div>
<!--{/if}-->



<!--{/if}-->