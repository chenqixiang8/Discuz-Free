<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['wq_buluoviewthread_reply'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<div class="plc cl b_bottom user_info" id="pid$post[pid]">
    <span class="avatar head_avatar">
        <a href="{if $post['authorid'] && $post['username'] &&($_G['forum']['ismoderator']||!$post['anonymous'])}$wq_userurl{else}javascript:;{/if}">
            <!--{if $post['anonymous']}-->
            <img src="{$_G['style']['styleimgdir']}mobile/images/hidden.jpg"  style="width:32px;height:32px;"/>
            <!--{elseif !$post['authorid']}-->
            <img src='$wq_default_avatar'  style="width:32px;height:32px;"/>
            <!--{else}-->
            <!--{if $_G[uid]&&$_G[uid]==$post['authorid']}-->
            <img src='$wq_my_avatar'  style="width:32px;height:32px;"/>
            <!--{else}-->
            <img class="wq_js_delayload"  src="{avatar($post[authorid], small, true)}" data="{avatar($post[authorid], small, true)}" style="width:32px;height:32px;"/>
            <!--{/if}-->
            <!--{/if}-->
        </a>
    </span>
    <div class="name_wrap display bpi m_b10 wq_post_list" href="#replybtn_$post[pid]">
        <ul class="authi">
            <li class="grey cl disuser_nick">
                <div class="author user_nick width60">
                    <!--{eval $wq_delete=$wq_hiddens='0';}-->
                    <!--{if $post['authorid'] && $post['username'] &&($_G['forum']['ismoderator']||!$post['anonymous'])}-->
                    <!--{eval $wq_hiddens=1;}-->
                    <a href="$wq_userurl"{if $post[groupcolor]} style="color: $post[groupcolor]"{/if}>$post[author]</a>
                    <!--{else}-->
                    <!--{if !$post['authorid']}-->
                    <a href="javascript:;">{lang guest} <em>$post[useip]{if $post[port]}:$post[port]{/if}</em></a>
                    <!--{elseif $post['authorid'] && $post['username'] && $post['anonymous']}-->
                    {lang anonymous}
                    <!--{else}-->
                    <!--{eval $wq_delete=1;}-->
                    $post[author]
                    <!--{/if}-->
                    <!--{/if}-->
                </div>
                <!--{if $wq_delete}-->
                <i class="f12">{$Tlang['917d9624d942699d']}</i>
                <!--{elseif $wq_hiddens}-->
                <!--{if $post[gender]}-->
                <!--{if $post[gender]==1}-->
                <span class="male_age"><i class="wqiconfont wqicon-nan  f12"></i></span>
                <!--{else}-->
                <span class="male_age bg_nv"><i class="wqiconfont  wqicon-nv f12"></i></span>
                <!--{/if}-->
                <!--{/if}-->
                <!--{if $_G['forum']['status'] == 3}-->
                <!--{eval $groupuser_extinfo=C::t('#wq_buluo#wq_buluo_groupuser_extinfo')->fetch_first_by_uid_fid($post[authorid], $_G[fid]);
                          $experience=$groupuser_extinfo[experience]?$groupuser_extinfo[experience]:0;
                          eval($wq_buluo_level[php]);
                          $wq_levelclass= $wq_buluo_level['level'][$wq_level]['class']?$wq_buluo_level['level'][$wq_level]['class']:1;}-->
                <a href="plugin.php?id=wq_buluo&mod=level&fid=$_G[fid]" class="f12"><span class="prevent_default dislv{$wq_levelclass}">$wq_buluo_level[prefix]{$wq_level}</span> </a>
                <!--{else}-->
                <a href="home.php?mod=spacecp&ac=usergroup{if $_G[uid]!=$post[authorid]}&gid=$post[groupid]{/if}" class="f12">
                    <!--{echo _buluo_wq_usergroup_show($post[groupid]);}-->
                </a>
                <!--{/if}-->
                <!--{/if}-->
                <!--{if $_G['forum']['ismoderator']}-->
                <em class="y"><a href="#moptions_$post[pid]" onclick="return false" class="popup blue">{lang manage}</a></em>
                <div id="moptions_{$post[pid]}" name="moptions_$post[pid]" popup="true" class="manage" style="display:none;">
                    <div class="ass_fl">
                        <button type="button" class="redirect button" href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page&type=wq_buluo">{lang edit}</button>
                        <!--{if $_G['group']['allowdelpost']}--><button type="button" class="dialog button notlogged" href="forum.php?mod=topicadmin&action=delpost&fid={$_G[fid]}&tid={$_G[tid]}&operation=&optgroup=&page=&topiclist[]={$post[pid]}&type=wq_buluo">{$Tlang['0d9efacf5089d88c']}</button><!--{/if}-->
                        <!--{if $_G['group']['allowbanpost']}--><button type="button" class="dialog button notlogged" href="forum.php?mod=topicadmin&action=banpost&fid={$_G[fid]}&tid={$_G[tid]}&operation=&optgroup=&page=&topiclist[]={$post[pid]}&type=wq_buluo">{$Tlang['5b1cbfcad581bfea']}</button><!--{/if}-->
                        <!--{if $_G['group']['allowwarnpost']}--><button type="button" class="dialog button notlogged" href="forum.php?mod=topicadmin&action=warn&fid={$_G[fid]}&tid={$_G[tid]}&operation=&optgroup=&page=&topiclist[]={$post[pid]}&type=wq_buluo">{$Tlang['a8d4b15dd720dbfc']}</button><!--{/if}-->
                        <!--{if $_G['group']['allowstickreply']}--><button type="button" class="dialog button notlogged" href="forum.php?mod=topicadmin&action=stickreply&fid={$_G[fid]}&tid={$_G[tid]}&operation=&optgroup=&page=&topiclist[]={$post[pid]}&type=wq_buluo">{$Tlang['01ff72df2ca84800']}</button><!--{/if}-->
                    </div>
                </div>
                <!--{/if}-->
                <!--{eval $_self = $thread['author'] && $post['author'] == $thread['author'] && $post['position'] !== '1';}-->
                <!--{if $_self}-->
                <span class="the_landlord_t">$postno[1]</span>
                <!--{/if}-->
                <span class="grey y f12 m_l10 m_t3">
                    <!--{if isset($post[isstick])}-->&#x7F6E;&#x9876;
                    <!--{elseif $post[number] == -1}-->
                    {lang recommend_post}
                    <!--{else}-->
                    <!--{if !empty($postno[$post[number]])}-->
                    $postno[$post[number]]
                    <!--{else}-->
                    {$post[number]}{$postno[0]}
                    <!--{/if}-->
                    <!--{/if}-->
                </span>
                <!--{if $_G['forum']['ismoderator']}-->
                <!--{if $_G['forum_thread']['special'] == 3 && ($_G['forum']['ismoderator'] && (!$_G['setting']['rewardexpiration'] || $_G['setting']['rewardexpiration'] > 0 && ($_G[timestamp] - $_G['forum_thread']['dateline']) / 86400 > $_G['setting']['rewardexpiration']) || $_G['forum_thread']['authorid'] == $_G['uid']) && $post['authorid'] != $_G['forum_thread']['authorid'] && $_G['uid'] != $post['authorid'] && $_G['forum_thread']['price'] > 0}-->
                <em class="y">
                    <a href="forum.php?mod=misc&action=bestanswer&tid={$post['tid']}&pid={$post['pid']}" class="bestanswer">{$Tlang['0d1b1e2e37a34574']}</a>
                </em>
                <!--{/if}-->
                <!--{/if}-->
            </li>

            <li> <a class="reply_posts" href="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&repquote=$post[pid]&extra=$_GET[extra]&page=$page&type=wq_buluo" data='$post[username]'> <!--{subtemplate forum/wq_buluoviewthread_message}--></a></li>
            <div class="client_bg wq_reward_warp"><!--{if $replay_reward}-->{$replay_reward}<!--{/if}--><!--{hook/viewthread_postbottom_mobile $postcount}--></div>
            <li class="grey rela hudong">
                <em>
					<span class="y">
                        <a class="reply_posts" href="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&repquote=$post[pid]&extra=$_GET[extra]&page=$page&type=wq_buluo" data='$post[username]'>
                            <i class="wqiconfont wqicon-massage f16 c_grey m_tf2"></i>
                        </a>
                    </span>
                    <!--{if !$_G['forum_thread']['special'] && !$rushreply && !$hiddenreplies && $_G['setting']['repliesrank'] && !($post['isWater'] && $_G['setting']['filterednovote'])}-->
                    <span class="y">
                        <a href="forum.php?mod=misc&action=postreview&do=against&tid=$_G[tid]&pid=$post[pid]&hash={FORMHASH}" data="$post[pid]" class="oppose">
                            <i class="wqiconfont wqicon-bad f14 c_grey"></i>
                        </a>
                        <i id="review_supportss_$post[pid]">$post[postreview][against]</i>
                    </span>
                    <span class="y">
                        <a href="forum.php?mod=misc&action=postreview&do=support&tid=$_G[tid]&pid=$post[pid]&hash={FORMHASH}"  data="$post[pid]" class="support support_forum">
                            <i class="wqiconfont wqicon-zan f14 c_grey"></i>
                        </a>
                        <i id="review_support_$post[pid]">$post[postreview][support]</i>
                    </span>
                    <!--{/if}-->
                    <!--{if ($_G['group']['raterange'] && $post['authorid'])||($_GET['from'] != 'preview' && !empty($post['ratelog']))}-->
                    <!--{if $_GET['from'] != 'preview' && !empty($post['ratelog'])}-->
                    <!--{eval $ajax_action="viewratings";$rate_class="rate_viewratings"}-->
                    <!--{else}-->
                    <!--{eval $ajax_action="rate";$rate_class="grades";}-->
                    <!--{/if}-->
                    <span class="y wqbuluo_rate">
                        <a href="forum.php?mod=misc&action=$ajax_action&tid=$_G[tid]&pid=$post[pid]&type=wq_buluo"  class="support {$rate_class}" {if $_G['group']['raterange'] && $post['authorid']}pid="$post[pid]"{/if}>
                           <i class="wqiconfont wqicon-icon02 c_grey"></i>
                        </a>
                        <!--{if count($postlist[$post[pid]][totalrate])>0}-->
                        <i class="m_l-4"><!--{echo count($postlist[$post[pid]][totalrate]);}--></i>
                        <!--{/if}-->
                    </span>
                    <!--{/if}-->
                </em>
                <em class="width70">$post[dateline]</em>
            </li>
        </ul>
    </div>
</div>
<!--{eval $postcount++;}-->






<!--{/if}-->