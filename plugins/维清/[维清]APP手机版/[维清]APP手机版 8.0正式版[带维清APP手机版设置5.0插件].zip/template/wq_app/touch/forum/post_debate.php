<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['post_debate'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<li class="wqnew_bottom">
    <span class="rq wqrequired">*</span>
        <textarea name="affirmpoint" id="affirmpoint" class="wqpost_textarea" tabindex="1" placeholder="{lang debate_square_point}" >$debate[affirmpoint]</textarea>
</li>
<li class="wqnew_bottom">
    <span class="rq wqrequired">*</span>
    <textarea name="negapoint" id="negapoint" class="wqpost_textarea" tabindex="1" placeholder="{lang debate_opponent_point}"></textarea>
</li>
<li class="wqnew_bottom">
    <input  name="endtime" id="endtime"data-options="{&quot;beginYear&quot;:2016,&quot;endYear&quot;:2030}"onclick="showcalendar(event, this, true)" class="muidate wqpost_input" placeholder="{$Tlang['1b2ae1ed4b219851']}" value="$debate[endtime]">
    <a href="javascript:;" class="dpbtn" onclick="showselect(this, 'endtime')"></a>
</li>
<li class="wqnew_bottom">
    <input type="text" name="umpire" id="umpire" class="wqpost_input" placeholder="{$Tlang['c01819ad865a4e6e']}"  onblur="checkuserexists(this.value, 'checkuserinfo')"value="$debate[umpire]" tabindex="1">
    <span id="checkuserinfo"></span>
</li>
<!--{hook/post_debate_extra}-->




<!--{/if}-->