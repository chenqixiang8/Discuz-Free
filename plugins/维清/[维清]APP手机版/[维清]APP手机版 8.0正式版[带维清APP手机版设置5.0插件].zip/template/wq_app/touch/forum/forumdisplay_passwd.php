<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['forumdisplay_passwd'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{template common/header}-->
<!--{eval
    $headparams['wtype'] = '1';
    $headparams['lurl'] = $backurl;
    $headparams['ltype'] = 'a';
    $headparams['cname'] = $Tlang['5da57ebee24c9ebb'];
    echo wq_app_get_header($headparams);
}-->

<div id="ct" class="wp cl form_passwd">
    <div class="mn">
        <div class="nfl">
            <div class="f_c">
                <div class="wqmima_icon"><i class="wqiconfont2 wqicon2-mimas"></i></div>
                    <h3 class="xs2 xi2 mbm">{lang forum_password_require}</h3>
                    <div class="o">
                        <form method="post" autocomplete="off" action="forum.php?mod=forumdisplay&fid=$_G[fid]&action=pwverify">
                            <input type="hidden" name="formhash" value="{FORMHASH}" />
                            <p class="wqpasswd_input wqnew_all">
                                <input id="verify_password" type="password" name="pw" class="px" size="25" />
                            </p>
                            <input type="hidden" name="loginsubmit" value="true" />
                            <p class="button_passwd m_t10"><button id="postsubmit" disabled='disabled'  class="wq_disabled  pn pnc vm formdialog button2" type="submit">{lang submit}</button><p>
                        </form>
                    </div>
                    <script type="text/javascript">
                        $('#verify_password').on('keyup input', function () {
                            $('#postsubmit').attr('disabled', ($.trim($('#verify_password').val()) ? null : 'disabled'));
                        });
                    </script>
            </div>
        </div>
    </div>
</div>
<!--{template common/footer}-->
<!--{/if}-->