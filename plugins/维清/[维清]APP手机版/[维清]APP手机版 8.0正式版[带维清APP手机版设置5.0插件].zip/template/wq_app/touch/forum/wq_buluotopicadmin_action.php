<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['wq_buluotopicadmin_action'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{template common/wq_buluo_tpl_header}-->
<div class="tip">
    <!--{if in_array($_GET[action], array('delpost', 'banpost', 'warn','stickreply'))}-->
    <form id="topicadminform" method="post" autocomplete="off" action="forum.php?mod=topicadmin&action=$_GET[action]&modsubmit=yes&modclick=yes&mobile=2&type=wq_buluo" >
        <input type="hidden" name="formhash" value="{FORMHASH}" />
        <input type="hidden" name="fid" value="$_G[fid]" />
        <input type="hidden" name="tid" value="$_G[tid]" />
        <input type="hidden" name="page" value="$_G[page]" />
        <input type="hidden" name="reason" value="{lang topicadmin_mobile_mod}" />
        <!--{if $_GET[action] == 'delpost'}-->
        <dt>{lang admin_delpost_confirm}</dt>
        $deleteid
        <dd><input type="submit" name="modsubmit" id="modsubmit" value="{lang confirms}" class="formdialog button2"><a href="javascript:;" onclick="popup.close();"  class="eject_cancel">{lang cancel}</a></dd>
        <!--{elseif $_GET[action] == 'banpost'}-->
        <dt>
            <p>{lang admin_banpost_confirm}</p>
            $banid
            <p>
                <input type="radio" name="banned" id="admin_banpost_1" class="weui_check" value="1" $checkban />
                <label class="weui_check_label" for="admin_banpost_1"><i class="weui_icon_checked"></i>{lang admin_banpost}</label>
            </p>
            <p>
                <input type="radio" id="admin_banpost_0" name="banned" class="weui_check" value="0" $checkunban />
                <label class="weui_check_label" for="admin_banpost_0"><i class="weui_icon_checked"></i>{lang admin_unbanpost}</label>
            </p>
            </dt>
        <dd><input type="submit" name="modsubmit" id="modsubmit" value="{lang confirms}" class="formdialog button2"><a href="javascript:;" onclick="popup.close();"  class="eject_cancel">{lang cancel}</a></dd>
        <!--{elseif $_GET[action] == 'warn'}-->
        <dt>
            <p>{lang admin_warn_confirm}</p>
            $warnpid
            <p>
               <input type="radio" name="warned" id="admin_warned_1" class="weui_check" value="1" $checkwarn />
              <label class="weui_check_label" for="admin_warned_1"><i class="weui_icon_checked"></i>{lang topicadmin_warn_add}</label>
            </p>
            <p>
                <input type="radio" name="warned" id="admin_warned_0" class="weui_check" value="0" $checkunwarn />
                <label class="weui_check_label" for="admin_warned_0"><i class="weui_icon_checked"></i>{lang topicadmin_warn_delete}</label>
            </p>
        </dt>
        <dd><input type="submit" name="modsubmit" id="modsubmit" value="{lang confirms}" class="formdialog button2"><a href="javascript:;" onclick="popup.close();" class="eject_cancel" >{lang cancel}</a></dd>
        <!--{elseif $_GET[action] == 'stickreply'}-->
        <dt>
        <p>{$Tlang['39cd8e0c53943cc7']}</p>
            $stickpid
            <p>
               <input type="radio" name="stickreply" id="admin_warned_1" class="weui_check" value="1" {if empty($_GET['undo'])} checked="checked"{/if} />
                      <label class="weui_check_label" for="admin_warned_1"><i class="weui_icon_checked"></i>{$Tlang['2c9e5a6d504745be']}</label>
            </p>
            <p>
                <input type="radio" name="stickreply" id="admin_warned_0" class="weui_check" value="0" {if !empty($_GET['undo'])} checked="checked"{/if} />
                <label class="weui_check_label" for="admin_warned_0"><i class="weui_icon_checked"></i>{lang admin_unstickreply}</label>
            </p>
        </dt>
        <dd><input type="submit" name="modsubmit" id="modsubmit" value="{lang confirms}" class="formdialog button2"><a href="javascript:;" onclick="popup.close();" class="eject_cancel" >{lang cancel}</a></dd>
        <!--{/if}-->
    </form>
    <!--{else}-->
    <dt>{lang admin_threadtopicadmin_error}</dt>
    <dd><input type="button" onclick="popup.close();" value="{lang confirms}" /></dd>
    <!--{/if}-->
</div>
<!--{template common/wq_buluo_tpl_footer}-->
<!--{/if}-->