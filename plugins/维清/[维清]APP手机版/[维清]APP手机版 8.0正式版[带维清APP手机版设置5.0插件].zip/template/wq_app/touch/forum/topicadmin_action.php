<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['topicadmin_action'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{if $_GET['type'] == 'wq_buluo'}-->
    <!--{template forum/wq_buluotopicadmin_action}-->
    <!--{eval exit;}-->
<!--{/if}-->
<!--{template common/header}-->
<div class="tm_c wqshield_notice" id="floatlayout_topicadmin">
	<form id="topicadminform" method="post" autocomplete="off" action="forum.php?mod=topicadmin&action=$_GET[action]&modsubmit=yes&infloat=yes&modclick=yes">
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<input type="hidden" name="fid" value="$_G[fid]">
		<input type="hidden" name="tid" value="$_G[tid]">
		<!--{if !empty($_GET['page'])}--><input type="hidden" name="page" value="$_GET['page']" /><!--{/if}-->
		<!--{if !empty($_GET['infloat'])}--><input type="hidden" name="handlekey" value="$_GET['handlekey']" /><!--{/if}-->
		<div class="wqshield_con">
			<div class="{if $_GET[action] != 'split'}tplw{else}tpmh{/if}">
                            <!--{if $_GET[action] == 'removereward'}-->
                            {$Tlang['18f8dbb99b931507']}
                            <!--{/if}-->
			<!--{if $_GET[action] == 'delpost'}-->
				$deleteid
				{lang admin_delposts}

				<!--{if ($modpostsnum == 1 || $authorcount == 1) && $crimenum > 0}-->
					<br /><div style="clear: both; text-align: right;">{lang topicadmin_crime_delpost_nums}</div>
				<!--{/if}-->
			<!--{elseif $_GET[action] == 'delcomment'}-->
				$deleteid
				{lang topicadmin_delet_comment}
			<!--{elseif $_GET[action] == 'restore'}-->
				<input type="hidden" name="archiveid" value="$archiveid" />
				{lang admin_threadsplit_restore}
			<!--{elseif $_GET[action] == 'copy'}-->
				<p class="mbn tahfx wqmove_tiezi">
					{lang admin_target}:
                                        <select name="copyto" id="copyto" class="ps vm" onchange="wq_app_ajaxget('forum.php?mod=ajax&action=getthreadtypes&fid=' + this.value, 'threadtypes')">
						$forumselect
					</select>
				</p>
				<p class="mbn tahfx wqmove_tiezi">
					{lang admin_targettype}: <span>
                                            <select id="threadtypes" name="threadtypeid" class="ps vm">
                                                <option value="0" /></option>
                                            </select>
                                        </span>
				</p>
			<!--{elseif $_GET[action] == 'banpost'}-->
				$banid
				<p>{lang admin_banpost_confirm}</p>
					<p>
                                           <input type="radio" name="banned" class="pr weui_check" id="banned1" value="1" $checkban />
                                                <label class="weui_check_label" for="banned1"><i class="weui_icon_checked"></i>{lang admin_banpost}</label>
                                        </p>
					<p>
                                            <input type="radio" name="banned" class="pr weui_check" id="banned2"  value="0" $checkunban />
                                            <label class="weui_check_label" for="banned2"><i class="weui_icon_checked"></i>{lang admin_unbanpost}</label>
                                        </p>

			<!--{elseif $_GET[action] == 'warn'}-->
				$warnpid
                                <p>{lang admin_warn_confirm}</p>

					<p>
                                            <input type="radio" name="warned" class="pr weui_check"id="warned1" value="1" $checkwarn />
                                            <label class="weui_check_label" for="warned1"><i class="weui_icon_checked"></i>{lang topicadmin_warn_add}</label>
                                        </p>
					<p>
                                            <input type="radio" name="warned" class="pr weui_check" id="warned2" value="0" $checkunwarn />
                                            <label class="weui_check_label" for="warned2"><i class="weui_icon_checked"></i>{lang topicadmin_warn_delete}</label>
                                        </p>

				<!--{if ($modpostsnum == 1 || $authorcount == 1) && $authorwarnings > 0}-->
					<br /><div style="clear: both; text-align: right;" title="{lang topicadmin_warn_prompt}">{lang topicadmin_warn_nums}</div>
				<!--{/if}-->
			<!--{elseif $_GET[action] == 'merge'}-->

						<p class="wqapp_f15">
						{lang admin_merge_tid}</p>
                                            <p class="wqinput wqnew_all"><input type="text" name="othertid" id="othertid" class="px" size="10" /></p>

			<!--{elseif $_GET[action] == 'refund'}-->
				<table cellspacing="0" cellpadding="0" width="100%">
					<tr>
						<th>{lang pay_buyers}</th>
						<td>$payment[payers]</td>
					</tr>
					<tr>
						<th>{lang pay_author_income}</th>
						<td>$payment[netincome] {$_G[setting][extcredits][$_G['setting']['creditstransextra'][1]][unit]}{$_G[setting][extcredits][$_G['setting']['creditstransextra'][1]][title]}</td>
					</tr>
				</table>
			<!--{elseif $_GET[action] == 'split'}-->
                        <p class="wqinput wqnew_all">
				 <input type="text" name="subject" placeholder="{lang admin_split_newsubject}" id="subject" class="px" size="20" />
                            </p>
                            <p class="wqapp_f14">		<label for="split">{lang admin_split_comment}</label>

                                <span class="wqtextarea_st"><textarea name="split" id="split" class="pt wqtextarea"/></textarea></span>
				</p>
			<!--{elseif $_GET[action] == 'live'}-->
				<table cellspacing="0" cellpadding="0" width="100%">
					<tr>
						<td>
							<ul class="llst">
								<li><label><input type="radio" name="live" class="pr" value="1" <!--{if $_G[forum][livetid] != $_G[tid]}-->checked<!--{/if}-->/>{lang admin_live}</label></li>
								<li><label><input type="radio" name="live" class="pr" value="0" <!--{if $_G[forum][livetid] == $_G[tid]}-->checked<!--{/if}-->/>{lang admin_live_cancle}</label></li>
							</ul>
						</td>
					</tr>
					<tr>
						<td><br>{lang admin_live_tips}</td>
					</tr>
				</table>
			<!--{elseif $_GET[action] == 'stamp'}-->
				<p>{lang admin_stamp_select}:</p>
				<p class="tah_body mbm wqshield_con_border">
					<select name="stamp" id="stamp" class="ps wqselect" onchange="updatestampimg()">
						<option value="">{lang admin_stamp_none}</option>
					<!--{loop $_G['cache']['stamps'] $stampid $stamp}-->
						<!--{if $stamp['type'] == 'stamp'}-->
							<option value="$stampid"{if $thread[stamp] == $stampid} selected="selected"{/if}>$stamp[text]</option>
						<!--{/if}-->
					<!--{/loop}-->
					</select>
				</p>
				<script type="text/javascript" reload="1">
				if($('threadstamp')) {
					var oldthreadstamp = $('threadstamp').innerHTML;
				}
				var stampurls = new Array();
				<!--{loop $_G['cache']['stamps'] $stampid $stamp}-->
				stampurls[$stampid] = '$stamp[url]';
				<!--{/loop}-->
				function updatestampimg() {
					if($('threadstamp')) {
						$('threadstamp').innerHTML = $('stamp').value ? '<img src="{STATICURL}image/stamp/' + stampurls[$('stamp').value] + '">' : '<img src="{STATICURL}image/common/none.gif">';
					}
				}
				</script>
			<!--{elseif $_GET[action] == 'stamplist'}-->
				<p>{lang admin_stamplist_select}:</p>
				<p class="tah_body mbm wqshield_con_border">
					<select name="stamplist" id="stamplist" class="ps wqselect" onchange="updatestamplistimg()">
					<!--{if $thread[icon] >= 0}--><option value="$thread[icon]">{lang admin_stamplist_current}</option><!--{/if}-->
					<option value="">{lang admin_stamplist_none}</option>
					<!--{loop $_G['cache']['stamps'] $stampid $stamp}-->
						<!--{if $stamp['type'] == 'stamplist' && $stamp['icon']}-->
							<option value="$stampid"{if $thread[icon] == $stampid} selected="selected"{/if}>$stamp[text]</option>
						<!--{/if}-->
					<!--{/loop}-->
					</select>
				</p>
				<p class="tah_body" id="stamplistprev"></p>
				<script type="text/javascript" reload="1">
				var stampurls = new Array();
				<!--{loop $_G['cache']['stamps'] $stampid $stamp}-->
				stampurls[$stampid] = '$stamp[url]';
				<!--{/loop}-->
				function updatestamplistimg(icon) {
					icon = !icon ? $('stamplist').value : icon;

					if($('stamplistprev')) {
						$('stamplistprev').innerHTML = icon && icon >= 0 ? '<img src="{STATICURL}image/stamp/' + stampurls[icon] + '">' : '<img src="{STATICURL}image/common/none.gif">';
					}
				}
				<!--{if $thread[icon]}-->
					updatestamplistimg($thread[icon]);
				<!--{/if}-->
				</script>
			<!--{elseif $_GET[action] == 'stickreply'}-->
				$stickpid
				<ul class="llst">
					<li><label><input type="radio" name="stickreply" class="pr" value="1"{if empty($_GET['undo'])} checked="checked"{/if}/>{lang admin_stickreply} </label></li>
					<li><label><input type="radio" name="stickreply" class="pr" value="0"{if !empty($_GET['undo'])} checked="checked"{/if}/>{lang admin_unstickreply} </label></li>
				</ul>
			<!--{/if}-->
			</div>
                    <ul class="wqzhiding">
                        <li>
                            <div class="dopt dsn">
                                <p class="hasd">
                                    <label class="labeltxt">{lang admin_operation_explain}:</label>
                                    <!--{eval $reason_select = modreasonselect(1);}-->
                                    <!--{if !empty($reason_select)}-->
                                    <span class="dopt dsn">
                                        <select class="wq_choice" style="width:65%;" onchange="$('#reason').val(this.value)">
                                            {$reason_select}
                                        </select>
                                    </span>
                                    <!--{/if}-->
                                    <span class="wqspan">
                                         <textarea id="reason" name="reason" style="width:100%;border: none;text-indent: 0.2em;" class="pt"></textarea>
                                    </span>
                                </p>
                                <p>
                                    <input type="checkbox" name="sendreasonpm" id="sendreasonpm" class="weui_check"{if $_G['group']['reasonpm'] == 2 || $_G['group']['reasonpm'] == 3} checked="checked" disabled="disabled"{/if} />
                                    <label for="sendreasonpm" class="labeltxt weui_check_label"><i class="weui_icon_checked"></i>{lang admin_pm}</label>
                                </p>
                            </div>
                        </li>
                    </ul>
		</div>
         <p class="wqbtn_can wqnew_top">
           <a href="javascript:;" onclick="popup.close();" class="wqeject_cancel wqnew_right">{lang cancel}</a>
           <button type="submit" name="modsubmit" id="modsubmit" value="ture" class="pn pnc formdialog wqdetermine">{lang confirms}</button>
        </p>
	</form>
</div>
<!--{if empty($_GET['infloat'])}-->
		</div>
	</div>
</div>
<!--{/if}-->
<!--{template common/footer}-->

<!--{/if}-->