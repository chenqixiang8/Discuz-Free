<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['collection_nav'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<ul>
	<li{if !$op && !$tid} class="a"{/if}><a href="forum.php?mod=collection">{lang collection_recommended}</a></li>
	<li{if $op == 'all'} class="a"{/if}><a href="forum.php?mod=collection&amp;op=all">{lang collection_all}</a></li>
	<li{if $op == 'my'} class="a"{/if}><a href="forum.php?mod=collection&amp;op=my">{lang collection_my}</a></li>
	<!--{if !$op && $tid}--><li class="a"><a href="forum.php?mod=collection&amp;tid=$tid">{lang collection_nav_related}</a></li><!--{/if}-->
	<!--{hook/collection_nav_extra}-->
</ul>
<!--{/if}-->