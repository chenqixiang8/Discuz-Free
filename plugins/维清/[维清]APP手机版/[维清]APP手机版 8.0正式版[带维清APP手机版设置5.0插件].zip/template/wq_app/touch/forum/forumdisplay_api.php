<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['forumdisplay_api'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{template common/header}-->
<!--{eval $showmodel = get_wq_app_forum_style($_G['forum']['fid']);}-->
<!--{eval $wq_data = get_wq_app_data($_G['forum_threadlist'],$showmodel);}-->
<!--{eval //print_r($wq_data);}-->
<!--{eval $guide_nav = get_post_all_check($_GET['filter']);}-->
<!--{eval $nav_array[$guide_nav] = 'class="wqcolor wqborder_bottom"';}-->
<!--{block wq_navtitle}-->
<!--{if !empty($navtitle)}-->$navtitle - <!--{/if}--><!--{if empty($nobbname)}--> $_G['setting']['bbname'] - <!--{/if}--> {lang waptitle} - Powered by Discuz!
<!--{/block}-->

<!--{if $_GET['api'] == '1'}-->

<!--{if $_G['forum_threadcount']}-->
<!--{loop $_G['forum_threadlist'] $key $thread}-->
<li class="wqnew_bottom">
    <a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" class="wqblock guidelink">
        <!--{if $wq_data['images'][$thread['tid']]}-->
        <!--{eval $image = $wq_data['images'][$thread['tid']];}-->
        <div class="wqlist1">
            <!--{loop $image[image] $k $v}-->
            <img class="wq_js_delayload delayload" src="$_G['style'][styleimgdir]/images/gbar_pic.jpg" data-src="{$v}"/>
            <!--{if $image['count'] > 1 && $k == '2' && $wq_app_setting['view_imgnum'] == '1'}-->
            <span class="wqlisttu1"><i class="wqiconfont2 wqicon-tupian-copy wqapp_f14 wqm_right2"></i>{$image['count']}</span>
            <!--{/if}-->
            <!--{/loop}-->
        </div>
        <!--{/if}-->
        <div class="wqlist_maxhidden">
            <h3 class="wqtitle_list">
                <!--{if $thread['attachment'] == 2 && $_G['setting']['mobile']['mobilesimpletype'] == 0}-->
                <span class="wqicon_all wqicon_tu">{$Tlang['d09806a34575d52c']}</span>
                <!--{/if}-->
                <!--{if $thread['digest'] > 0}-->
                <span class="wqicon_all wqicon_digest">{$Tlang['4431e4914edfce71']}</span>
                <!--{/if}-->
                <!--{if $thread['weeknew']}-->
                <span class="wqicon_all wqicon_xin">{$Tlang['de8128f785039560']}</span>
                <!--{/if}-->
                <!--{if $thread[heatlevel]}-->
                <span class="wqicon_all wqicon_hot">{$Tlang['03a43059cdc3dcad']}</span>
                <!--{/if}-->

                <!--{if $thread[folder] == 'lock'}-->
                <span class="wqicon_all wqicon_gb">{$Tlang['beb08d096719774b']}</span>
                <!--{elseif $thread['special'] == 1}-->
                <span class="wqicon_all wqicon_vote">{$Tlang['a1e86aeac9394d67']}</span>
                <!--{elseif $thread['special'] == 2}-->
                <span class="wqicon_all wqicon_sell">{$Tlang['0907c7cfc9d2cf2b']}</span>
                <!--{elseif $thread['special'] == 3}-->
                <span class="wqicon_all wqicon_reward">{$Tlang['655aa530ba4d16cf']}</span>
                <!--{elseif $thread['special'] == 4}-->
                <span class="wqicon_all wqicon_activity">{$Tlang['2e5409eeacda8839']}</span>
                <!--{elseif $thread['special'] == 5}-->
                <span class="wqicon_all wqicon_debate">{$Tlang['5cbc8ce0fb1e25e0']}</span>
                <!--{/if}-->
                {if $thread[typename]}<span class="wqicon_all_14 wqicon_vote">{$thread[typename]}</span>{/if}<font $thread[highlight]>{$thread[subject]}</font></h3>
        </div>
        <p class="list_info">
            <!--{if $thread['authorid'] && $thread['author']}-->
            <span class="wqwidth120">{$thread[author]}</span>
            <!--{else}-->
            {$_G[setting][anonymoustext]}
            <!--{/if}-->
            <span class="y"><i class="wqiconfont2 wqicon2-pinglun2 wqapp_f12"></i>{$thread[replies]}</span>
            <span class="y wqm_right10"><i class="wqiconfont2 wqicon2-p-see wqyulan"></i>{$thread[views]}</span>
        </p>
    </a>
</li>
<!--{/loop}-->
<!--{elseif $page==1}-->
<!--{eval echo wq_app_no_content('forum/template','guide_nothreads');}-->
<!--{/if}-->
<!--{else}-->

<!--{eval
    $headparams['wtype'] = '1';
    $headparams['lurl'] = $backurl;
    $headparams['ltype'] = 'a';
    $headparams['rtype'] = 'share';
    $headparams['cname'] =strip_tags($_G['forum']['name']) ? strip_tags($_G['forum']['name']) : $_G['forum']['name'];

    echo wq_app_get_header($headparams,true,true);
}-->

<!--{template common/share}-->

<div class="wqforum_list_warp">
    <div class="wqforum_list_pic">
        <!--{if $_G['forum']['icon']}-->
        <!--{eval $valueparse = parse_url($_G['forum']['icon']);
                  $_G['forum']['icon']=!isset($valueparse['host'])?$_G['setting']['attachurl']."common/".$_G['forum']['icon']:$_G['forum']['icon'];}-->
        <img src="$_G['forum']['icon']" />
        <!--{else}-->
        <img src="{$_G['style'][styleimgdir]}forum{if $forum[folder]}_new{/if}.gif" />
        <!--{/if}-->
    </div>
    <div class="wqforum_list_info">
        <p><span class="wqm_right20">{$Tlang['3ef97ec0c0048b4b']}<em class="wqred wqm_right3">{$_G[forum]['todayposts']}</em></span><span>{$Tlang['57f5cb4a5a928cae']}<em class="wqred wqm_right3">{$_G[forum]['threads']}</em></span></p>
        <p><span class="wqm_right20">{$Tlang['2c8a07313e7706bc']}<em class="wqred wqm_right3" id="fav_num">{$_G[forum][favtimes]}</em></span>
            <!--{eval $fav = fetch_by_id_idtype_uid($_G[forum][fid], "fid", $_G['uid']);}-->
            <!--{if empty($fav)}-->
            <span class="wqforum_list_follow y wqbg_color"><a href="home.php?mod=spacecp&ac=favorite&type=forum&id={$_G[forum][fid]}" class="wqwhite notlogged" id="a_favorite">{$Tlang['36f840103635eeb2']}</a></span>
            <!--{else}-->
            <span class="wqforum_list_follow y wqbg_color"><a href="javascript:;" class="wqwhite" id="cancel_favorite" ><i class="wqiconfont2 wqicon2-o3 wqapp_f14 wqm_right3"></i>{$Tlang['2c8a07313e7706bc']}</a></span>
            <!--{/if}-->
        </p>
    </div>
</div>
<!--{if $sublist}-->
<div class="wqseparate"></div>
<div class="wqson_plate">
    <ul>
        <!--{loop $sublist $key $value}-->
        <li {if $key > 2}class="dsn"{/if}>
            <!--{if $value[icon]}-->
            <span class="wqname_img">{echo trim($value[icon])}</span>
            <!--{else}-->
            <span class="wqname_img">
                <a href="forum.php?mod=forumdisplay&fid={$value['fid']}">
                    <img src="{$_G['style'][styleimgdir]}images/forum{if $value[folder]}_new{/if}.gif" alt="$value[name]" />
                </a>
            </span>
            <!--{/if}-->
            <span class="wqname"><a href="forum.php?mod=forumdisplay&fid={$value['fid']}">{echo trim($value[name])}</a></span>
        </li>
        <!--{if $key == 2 && count($sublist) > 3}-->
        <li class="wqchild-show">
            <a href="javascript:;" class="wqblock wqellipsis" style="text-align: center;"><span>{$Tlang['db9c470ab0853172']}</span><i class="wqiconfont2 wqicon2-jiantou"></i></a>
        </li>
        <!--{/if}-->
        <!--{/loop}-->
        <!--{if count($sublist) > 3}-->
        <li class="wqchild-hide dsn">
            <a href="javascript:;" class="wqblock wqellipsis" style="text-align: center;"><span>{$Tlang['c699f8e04db8c066']}</span></a>
        </li>
        <!--{/if}-->
    </ul>
</div>
<!--{/if}-->
<div class="wqseparate"></div>
<!--{eval $screen_url='forum.php?mod=forumdisplay&fid='.$_G['forum']['fid'];}-->
<div class="my_post_roll wqpadding6 wqnew_bottom" id="my_list_roll">
    <div class="tag_list">
        <ul>
            <li><a href="$screen_url&sortall=1" {$nav_array[0]}>{$Tlang['8dfe4b30674494c1']}</a></li>
            <li><a addclass="wqindex_list" href="{$screen_url}&filter=heat&orderby=heats&sortall=1"  {$nav_array[1]}>{$Tlang['8f0491c8e569b3df']}</a></li>
            <li><a addclass="wqindex_list" href="{$screen_url}&filter=hot&sortall=1" {$nav_array[2]} >{$Tlang['53fda8b6e44196b1']}</a></li>
            <li><a addclass="wqindex_list" href="{$screen_url}&filter=lastpost&orderby=lastpost&sortall=1" {$nav_array[3]}>{$Tlang['13097feed87cf6ee']}</a></li>
            <li><a addclass="wqindex_list" href="{$screen_url}&filter=digest&digest=1&sortall=1"  {$nav_array[4]}>{$Tlang['46d1ecf7cc55b12f']}</a></li>
            <li><a addclass="wqindex_list" href="{$screen_url}&sortall=1&filter=specialtype{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}&specialtype=poll"  {$nav_array[5]}>{$Tlang['cc1025f7bbbc225d']}</a></li>
            <li><a inajax="1" addclass="wqindex_list" href="{$screen_url}&filter=sortid&sortid={$_GET['sortid']}{if $_GET[sortall]}&sortall=1{/if}" {$nav_array[6]} >{$Tlang['5c628d6fb054066c']}</a></li>
    </div>
</div>

<!--{eval $my_roll_tag='my_list_roll';}-->
<!--{template common/slide}-->

<!--{block toplist_html}-->
<!--{if $_G['forum_threadcount']}-->
<!--{eval $toplist = get_wq_app_toplist($_G['forum_threadlist']);}-->
<!--{if $toplist}-->
<div class="wqtop_post">
    <ul>
        <!--{loop $toplist $key $topthread}-->
        <!--{hook/forumdisplay_thread_mobile $key}-->
        <li><a href="forum.php?mod=viewthread&tid=$topthread[tid]&extra=$extra" class="wqellipsis guidelink"><span class="wqtop_post_span">{$Tlang['01ff72df2ca84800']}</span>
                <!--{eval $wq_top_typehtml = str_replace(array('[', ']','<a','</a>'), array('<span class="wq_typehtml" ', '</span>'), array($topthread[typehtml],$topthread[sorthtml]));;}-->
                {$wq_top_typehtml[0]}{$wq_top_typehtml[1]}
                <font $topthread[highlight]>{$topthread[subject]}</font></a>
        </li>
        <!--{/loop}-->
    </ul>
</div>
<!--{/if}-->
<!--{/if}-->
<!--{/block}-->
<!--{if empty($_G['forum']['picstyle']) || $_G['cookie']['forumdefstyle']}-->
<div class="wqindex_list {if $wq_app_setting[is_drop_down_loading]}pulldown_load_js{/if}"  id="hotlist_{$guide_nav}" botton='330' contentid='thread_lists{$guide_nav}'  count="$_G['forum_threadcount']"  query_string="{$_SERVER['QUERY_STRING']}" page="$page" perpage="$_G['setting']['mobile']['mobiletopicperpage']" data="$guide_nav" title="$wq_navtitle" pattern="ordinary">
    <!--{eval echo $toplist_html;}-->
    <!--{if $_G['forum_threadlist']}-->
    <ul class="wqindex_list_ul" id='thread_lists{$guide_nav}'>
        <!--{loop $_G['forum_threadlist'] $key $thread}-->
        <!--{subtemplate forum/style_list_1}-->
        <!--{/loop}-->
    </ul>
    <!--{else}-->
    <!--{eval echo wq_app_no_content('forum/template','guide_nothreads');}-->
    <!--{/if}-->
    <!--{if $wq_app_setting[is_drop_down_loading]}-->
    <p class="wqmore" style="display:none;">
        <a href="javascript:;" class="wqblock" ><img src="{$_G['style'][styleimgdir]}images/icon_load.gif">{$Tlang['ccfb539ba66bbe7d']}</a>
    </p>
    <!--{else}-->
    <!--{if $multipage}--><div class="pgs cl mtm"><!--{eval echo wq_app_multipage($multipage);}--></div><!--{/if}-->
    <!--{/if}-->
</div>
<!--{else}-->
<div class="wqwaterfall_warp" id="wq_forumdisplay_list">
    <div class="wqwaterfall_con {if $wq_app_setting[is_drop_down_loading]}pulldown_load_js{/if}" id="hotlist_{$guide_nav}" delid="delid" contentid='thread_lists{$guide_nav}' count="$_G['forum_threadcount']" query_string="{$_SERVER['QUERY_STRING']}" page="$page" perpage="$_G['setting']['mobile']['mobiletopicperpage']" data="$guide_nav" title="$wq_navtitle"
         botton='330'>
        <ul class="waterfall wqwaterfall" id='thread_lists{$guide_nav}' wq_flag="waterfall">
            <!--{if $_G['forum_threadlist']}-->
            <!--{loop $_G['forum_threadlist'] $key $thread}-->
            <!--{if $_G['hiddenexists'] && $thread['hidden']}-->
            <!--{eval continue;}-->
            <!--{/if}-->
            <!--{if !$thread['forumstick'] && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])}-->
            <!--{if $thread['related_group'] == 0 && $thread['closed'] > 1}-->
            <!--{eval $thread[tid]=$thread[closed];}-->
            <!--{/if}-->
            <!--{/if}-->
            <!--{eval $waterfallwidth = $_G[setting][forumpicstyle][thumbwidth] + 24; }-->
            <!--{subtemplate forum/forumdisplay_p}-->
            <!--{/loop}-->
            <!--{else}-->
            <!--{echo wq_app_no_content('forum/template','forum_nothreads');}-->
            <!--{/if}-->
        </ul>
        <!--{if $wq_app_setting[is_drop_down_loading]}-->
        <!--{echo wq_app_load_icon();}-->
        <!--{else}-->
        <!--{if $multipage}-->
        <div class="pgs cl mtm"><!--{eval echo wq_app_multipage($multipage);}--></div>
        <!--{/if}-->
        <!--{/if}-->
    </div>
</div>
<!--{/if}-->
<script type="text/javascript">
    var wqforum_list_follow = ".wqforum_list_follow", a_favorite = "#a_favorite", cancel_favorite = "#cancel_favorite", formhash = "{FORMHASH}", forum_fid = $_G['forum']['fid'], Cancel_success = "{$Tlang['bef022f6310db3b9']}", _favtimes = "{$Tlang['36f840103635eeb2']}", favtimes = "{$Tlang['2c8a07313e7706bc']}", info_success = "{$Tlang['fffeda57b2002266']}", fav_num = "#fav_num";
    function set_li_height(data, handover) {
        data.imagesLoaded(function() {
            var flag = $("ul[wq_flag='waterfall']");
            if (flag && flag.length == 1) {
                var con = $("p[is_content='null']");
                if (con.length == 1) {
                    $('.pgs').hide();
                    return;
                }

                $("ul[wq_flag='waterfall'] li").each(function() {
                    var li_height = $(this).children().height();
                    $(this).css('height', li_height);
                });
            }
        });
    }
</script>
<script type="text/javascript" src="{$_G['style']['styleimgdir']}js/forumdisplay.js?{VERHASH}"></script>
<!--{/if}-->
<!--{template common/footer}-->

<!--{/if}-->