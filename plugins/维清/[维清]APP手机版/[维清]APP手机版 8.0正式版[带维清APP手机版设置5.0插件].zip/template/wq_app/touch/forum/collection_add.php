<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['collection_add'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{template common/header}-->

<!--{eval $headright=false;}-->
    <!--{if helper_access::check_module('collection')}-->
        <!--{eval $headright=true;}-->
    <!--{/if}-->
    <!--{if $op == 'edit'}-->
    <!--{eval $headparams['cname'] = "{lang collection_edit}";}-->
    <!--{else}-->
    <!--{eval $headparams['cname'] = "{lang collection_create}";}-->
    <!--{/if}-->
    <!--{eval
        $headparams['wtype'] = '1';
        $headparams['ltype'] = 'a';
        $headparams['rtype'] = 'a';
        $headparams['lurl'] = $backurl;
        $headparams['rclass'] = 'wqapp_f16';

        $headparams['rtype'] = 'a';
        $headparams['rname'] = '';
        $headparams['rurl'] = 'forum.php?mod=collection&action=edit';
        $headparams['rclass'] = '';

        echo wq_app_get_header($headparams,true,$headright);
    }-->

 <div id="ct" class="wq_collection_addwarp">
	<div class="bm">
		<div class="bm_c">
			<form action="forum.php?mod=collection&action=edit" method="POST" id="collection">
				<table cellspacing="0" cellpadding="0" class="tfm">
					<tr>
						<th>{lang collection_title}</th>
                                                <td><input type="text" value="{$_G['collection']['name']}" name="title" id="formtitle" class="px"  placeholder="{$Tlang['86ce756d539fbb9c']}"/></td>
					</tr>
					<tr>
						<th>{lang collection_desc}</th>
                                                <td><textarea name="desc" id="formdesc" rows="4" class="pt" placeholder="{$Tlang['4bcd81a49a38feb1']}" >{$_G['collection']['desc']}</textarea></td>
					</tr>
					<tr>
						<th>{lang collection_keywords}</th>
						<td>
                                                    <input type="text" value="{$_G['collection']['keyword']}" name="keyword" id="formkeyword" placeholder="{$Tlang['a6d1586b56f1ccea']}" class="px" />
                                                    <p class="xg1 wqm_top5">{$Tlang['ef3b02de0e7d86bf']}</p>
						</td>
					</tr>
				</table>
                            <div class="wq_collection_button">
                                <input type="hidden" value="1" name="submitcollection" />
                                <input type="hidden" value="yes" name="collectionsubmit" />
                                <input type="hidden" value="{$op}" name="op" />
                                <input type="hidden" value="{$ctid}" name="ctid" />
                                <input type="hidden" name="formhash" id="formhash" value="{FORMHASH}" />
                                <button type="button"  id="collectionsubmit" class="button2"><span><!--{if $op == 'edit'}-->{$Tlang['b531d032f4f29f92']}<!--{else}-->{$Tlang['9a8a6c6aae162cb8']}<!--{/if}--></span></button>
                                <!--{if $op != 'edit'}-->
                                        <p class="xg1 wqm_top10">{lang collection_remain_tips}</p>
                                <!--{/if}-->
                            </div>
			</form>
		</div>
	</div>
</div>

<script>
    var titlelimit = '$titlelimit';
    var desclimit = '$desclimit';
    function checklen() {
        if(mb_strlen($("#formtitle").val()) > titlelimit) {
            popup.open('<div class="wqtip"><p class=class="wqp">' + {lang collection_title_exceed} + '</p></div>');
            return false;
        }
        if(mb_strlen($("#formdesc").val()) > desclimit) {
            popup.open('<div class="wqtip"><p class=class="wqp">' + {lang collection_desc_exceed} + '</p></div>');
            return false;
        }
        return true;
    }
    function coll_showerror(str){
        popup.open('<div class="wqtip"><p class=class="wqp">' + str + '</p></div>');
        setTimeout(function() {
            popup.close();
        }, '2000');
        return false;
    }
    $(function(){
        $('#collectionsubmit').on('click', function() {
            if(!checklen()){
                return false;
            };
            popup.open(toast);
            var obj = $(this);
            var formobj = $(this.form);
            $.ajax({
                type: 'POST',
                url: formobj.attr('action') + '&handlekey=' + formobj.attr('id') + '&inajax=1',
                data: formobj.serialize(),
                dataType: 'html'
            }).success(function (s) {
                var wq = wqXml(s);
                popup.open(wq_replace_js(wq));
                evalscript(wq);
            }).error(function (s) {
                popup.close();
            });
            return false;
        });
    })
</script>

<!--{template common/footer}-->
<!--{/if}-->