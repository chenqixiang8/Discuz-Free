<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['wq_buluoforumdisplay_fastpost'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<form method="post" autocomplete="off" id="fastpostform" action="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&extra=$_GET[extra]&replysubmit=yes">
    <input type="hidden" name="formhash" value="{FORMHASH}"/>
    <div class="plc cl viewpi b_dark" id="wq_reply">
        <span class="avatar t5">
            <a href="{if $_G[uid]}home.php?mod=space&uid=$_G[uid]&do=profile&mycenter=1{else}member.php?mod=logging&action=login{/if}">
                <img src="{avatar($_G[uid], small, true)}"  style="height:32px;width:32px;"/>
            </a>
        </span>
        <div class="pi m_r60">
            <ul class="fastpost">
                <li>
                    <!--{if $allowfastpost}-->
                    <div class="b_dark_all input_pl">
                        <input type="text" id="wq_reply_click" onclick=" $('#wq_reply_post,#wq_reply_hide').show();
                                $('#needmessage').focus().val('').attr('placeholder', '{lang send_reply_fast_tip}');" class="input finp"  placeholder="{$Tlang['9aae3d8d65ed9f2d']}"></div>
                    <!--{else}-->
                    <div class="pt">
                        <!--{if $_G['forum_thread']['closed'] == 1}-->
                        <a href="javascript:;" class="y b_dark_all" style="height:34px; line-height: 34px; font-size: 14px;"><span>{$Tlang['b1e3304599deacad']}</span>
                        </a>
                        <!--{else}-->
                        <!--{if !$_G['uid']}-->
                        <a href="member.php?mod=logging&action=login" id="wq_replyids_click" class="y b_dark_all dialog notlogged" style="height:34px; line-height: 34px; font-size: 14px;"><span>{lang send_reply_fast_tip}</span>
                        </a>
                        <!--{else}-->
                        <input type="submit" id="fastpostform_submit"  style='display: none' class="formdialog"/>
                        <a href="javascript:;" id="wq_replyids_click" onclick="$('#fastpostform_submit').click()" class="xi2">{$Tlang['770dd69e9fb036e6']}{$Tlang['460edde45689c320']}</a>
                        <!--{/if}-->
                        <!--{/if}-->
                    </div>
                    <!--{/if}-->
                </li>
            </ul>
        </div>
        <span class="share_view">
            <a href="javascript:sharenv('share_qt')"><i class="wqiconfont wqicon-share f28 m_tf2"></i></a>
        </span>
    </div>
    <!--{if $allowfastpost}-->
    <div id="wq_reply_hide" style="position: fixed;width: 100%;height: 100%;left: 0px;top: 0px;opacity: 0.5;background: #000; z-index:80;display: none" onclick="$('#wq_reply_post,#wq_reply_hide').hide();
            $(this).empty().hide();"></div>
    <div class="plc cl viewpi_t b_dark" id="wq_reply_post" style="display: none">
        <div style="position: relative">
            <span class="smilies" style="position: absolute;bottom: 0px;top: auto;">
                <a href="javascript:;"><i id="expression_button" class="wqiconfont wqicon-emoji f30"></i></a>
                <a href="javascript:;" ><i id="file_button" class="wqiconfont wqicon-camara f30"></i></a>
                <i class="today_p" style="display: none">0</i>
                <input type="file" name="Filedata" multiple="multiple" id="filedata"  style="display:none" accept="image/*"/>
            </span>
            <div class="pi_sm m_r80">
                <ul class="fastpost" id="replyid">
                    <li>
                        <div class="b_dark_all input_pl">
                            <textarea class="input finp" id="needmessage"  autocomplete="off"   name="message"  rows="1"  placeholder="{lang send_reply_fast_tip}" style="overflow-y:hidden;"></textarea>
                        </div>
                    </li>
                </ul>
            </div>
            <span class="share_view" style="position: absolute;bottom: 0;top:auto">
                <button name="commentsubmit_btn" id="postsubmit" disabled="disabled" type="submit" class="formdialog wq_disabled button2">{$Tlang['wq_post']}</button>
            </span>
        </div>
        <!--{template common/wq_buluoupload_image}-->
        <!--{template common/wq_buluosmilies}-->
    </div>
    <script>
        upload_image = function (data) {
            if (data == '') {
                popup.open('{lang uploadpicfailed}', 'alert');
            }
            var dataarr = data.split('|');
            if (dataarr[0] == 'DISCUZUPLOAD' && dataarr[2] == 0) {
                popup.close();
                if ($('#imglist').is(':hidden')) {
                    $('.cellphone_expression').hide();
                    $('#expression_button ').removeClass('c_jianpan').removeClass('wqicon-jianpan').addClass('wqicon-emoji');
                    $('#imglist').show();
                    $('#file_button').addClass('blue');
                }
                $('#imglist').prepend('<li><span aid="' + dataarr[3] + '" class="del"><a href="javascript:;">\n\
                              <i class="wqiconfont wqicon-delete f22 wq_del"></i></a></span><span class="p_img"><a href="javascript:;"><img style="height:54px;width:54px;" id="aimg_' + dataarr[3] + '" title="' + dataarr[6] + '" src="{$_G[setting][attachurl]}forum/' + dataarr[5] + '" /></a></span><input type="hidden" name="attachnew[' + dataarr[3] + '][description]" /></li>');
                $('.today_p').show().text($('#imglist li').length - 1);
                $('#filedata').val('');
            } else {
                var sizelimit = '';
                if (dataarr[7] == 'ban') {
                    sizelimit = '{lang uploadpicatttypeban}';
                } else if (dataarr[7] == 'perday') {
                    sizelimit = '{lang donotcross}' + Math.ceil(dataarr[8] / 1024) + 'K)';
                } else if (dataarr[7] > 0) {
                    sizelimit = '{lang donotcross}' + Math.ceil(dataarr[7] / 1024) + 'K)';
                }
                popup.open(STATUSMSG[dataarr[2]] + sizelimit, 'alert');
            }
        };
        function expression_insertunit(obj) {
            var id_val = $('#needmessage').val();
            $('#needmessage').val(id_val + obj.attr('code'));
            _adjustHs('needmessage');
            postsubmit_button();
        }
        deleteSmilies('{:', ':}');
        function postsubmit_button() {
            $('#postsubmit').attr('disabled', ($.trim($('#needmessage').val()) ? null : 'disabled'));
        }
        $(function () {
            $('#expression_button').on('click', function () {
                $(this).toggleClass('c_jianpan');
                if ($('.cellphone_expression').is(':hidden')) {
                    $('#imglist').hide();
                    $('.cellphone_expression').show();
                    $('#file_button').removeClass('blue');
                    expression_viwepager();
                } else {
                    $('.cellphone_expression').hide();
                }
            });


            $('#needmessage').on('keyup input', function () {
                postsubmit_button();
            }).on('focus', function () {
                $('.cellphone_expression,#imglist').hide();
                $('#file_button').removeClass('blue');
                $('#expression_button').removeClass('c_jianpan');
            }).autoHeight(5);

            $('.reply_posts').on('click', function () {
                var user = $(this).attr('data');
                $.post($(this).attr('href') + '&inajax=yes', {}, function (s) {
                    if (s) {
                        $('#wq_reply_hide').append(s);
                        $('#wq_reply_click').click();
                        $('#needmessage').val('').attr('placeholder', "{$Tlang['209e3f19421ead4d']} " + user);
                    }
                });
                return false;
            });
        });
    </script>
    <!--{/if}-->
</form>

<!--{/if}-->