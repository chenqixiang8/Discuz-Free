<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['debate_umpire'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{template common/header}-->
<!--<form method="post" autocomplete="off" id="postform" action="forum.php?mod=misc&action=debateumpire&tid=$_G[tid]&umpiresubmit=yes&infloat=yes{if !empty($_GET['from'])}&from=$_GET['from']{/if}"{if !empty($_GET['infloat'])} onsubmit="ajaxpost('postform', 'return_$_GET['handlekey']', 'return_$_GET['handlekey']', 'onerror'); return false;"{/if}>-->
<form method="post" autocomplete="off" id="postform" action="forum.php?mod=misc&action=debateumpire&tid=$_G[tid]&umpiresubmit=yes&infloat=yes&{if !empty($_GET['from'])}&from=$_GET['from']{/if}">
    <!--{eval
        $headparams['wtype'] = '2';

        $headparams['ltype'] = 'a';
        $headparams['lname'] = $Tlang['9c825be7149e5b97'];
        $headparams['lclass'] = 'wqcancel wqapp_f16';
	$headparams['ctype'] = 'span';
        $headparams['cname'] = $_GET['over'] == 1 ? $Tlang['ae303133252d3f6e'] : $Tlang['72aee8861fad6348'];

        $headparams['rtype'] = 'but';
        $headparams['rname'] = lang('forum/template','submit');
        $headparams['rid'] = 'umpiresubmit';
        $headparams['buttype'] = 'submit';
        $headparams['butname'] = 'umpiresubmit';

        echo wq_app_get_header($headparams, false, true) ;
    }-->

    <div class="wqdebate_list wqend_debate">
        <input type="hidden" name="formhash" id="formhash" value="{FORMHASH}" />
        <ul class="wqdebate_list_ul">
            <li>
                <span class="wqm_right10">{lang debate_winner}</span>
                <span class="wqm_right10"><input type="radio" name="winner" value="1" class="weui_check" $winnerchecked[1] id="winner1" /><label class="weui_check_label"for="winner1"><i class="weui_icon_checked"></i>{lang debate_square}</label></span>
                <span class="wqm_right10"><input type="radio" name="winner" value="2" class="weui_check" $winnerchecked[2] id="winner2" /><label class="weui_check_label"for="winner2"><i class="weui_icon_checked"></i>{lang debate_opponent}</label></span>
                <span><input type="radio" name="winner" value="3" class="weui_check" $winnerchecked[3] id="winner3" /><label class="weui_check_label" for="winner3"><i class="weui_icon_checked"></i>{lang debate_draw}</label></span>
            </li>
            <li>
                <p>
                    <select onchange="$('#bestdebater').val($(this).val())" class="wqdebate_select">
                        <option value="">{lang debate_bestdebater}</option>
                        <!--{loop $candidates $candidate}-->
                        <option value="$candidate[username]"{if $candidate[username] == $debate[bestdebater]} selected="selected"{/if}>$candidate[username] ( $candidate[voters] {lang debate_poll}, <!--{if $candidate[stand] == 1}-->{lang debate_square}<!--{elseif $candidate[stand] == 2}-->{lang debate_opponent}<!--{/if}-->)</option>
                        <!--{/loop}-->
                    </select>
                </p>
                <p><input type="text" name="bestdebater" id="bestdebater" class="wqdebate_input" placeholder="{$Tlang['8ad705ca0e63bbec']}" value="$debate[bestdebater]" size="20" /></p>
            </li>
            <li><textarea id="umpirepoint" name="umpirepoint" placeholder="{lang debate_umpirepoint}" class="wqdebate_textarea">$debate[umpirepoint]</textarea></li>
        </ul>
    </div>
</form>
<script type="text/javascript" reload="1">
    $('#umpiresubmit').on('click', function() {
       popup.open(toast);
       var form = $("#postform");
        $.ajax({
            type:'POST',
            url:form.attr('action') + '&handlekey='+form.attr('id')+'&inajax=1',
            data:form.serialize(),
            dataType: 'html'
        })
        .success(function(s) {
            popup.open(wqXml(s));
        })
        .error(function() {
            popup.open('{lang networkerror}', 'alert');
        });
        return false;
    });

</script>
<!--{template common/footer}-->
<!--{/if}-->