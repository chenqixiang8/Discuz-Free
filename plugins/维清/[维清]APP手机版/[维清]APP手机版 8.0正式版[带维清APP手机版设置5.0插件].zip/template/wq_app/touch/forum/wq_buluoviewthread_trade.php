<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['wq_buluoviewthread_trade'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{if !$post['message'] && (($_G['forum']['ismoderator'] && $_G['group']['alloweditpost'] && (!in_array($post['adminid'], array(1, 2, 3)) || $_G['adminid'] <= $post['adminid'])) || ($_G['forum']['alloweditpost'] && $_G['uid'] && $post['authorid'] == $_G['uid']))}-->
<div class="trade">
    <a href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]&page=$page">
        <span>{lang post_add_aboutcounter}</span>
    </a>
</div>
<!--{else}-->
<div class="postmessage">$post[message]</div>
<!--{/if}-->
<!--{if count($trades) > 1 || ($_G['uid'] == $_G['forum_thread']['authorid'] || $_G['group']['allowedittrade'])}-->
<div class="trade">
    <em>{lang post_trade_totalnumber}: $tradenum</em>
</div>
<!--{/if}-->
<!--{if $tradenum}-->
<!--{if $trades}-->
<!--{loop $trades $key $trade}-->
<div id="trade$trade[pid]" class="trade txt_img">
    <h4>$trade[subject]</h4>
    <div class="trade_img">
        <!--{if $trade['displayorder'] > 0}--><em class="hot">{lang post_trade_sticklist}</em><!--{/if}-->
        <!--{if $trade['thumb']}-->
        <img src="$trade[thumb]" alt="$trade[subject]" />
        <!--{else}-->
        <img src="{$_G[style][styleimgdir]}mobile/images/nophoto.gif"  alt="$trade[subject]" />
        <!--{/if}-->
    </div>
    <div class="trade_txt">
        <dl>
            <dt><span>{lang trade_type_viewthread}:</span>
            <!--{if $trade['quality'] == 1}-->{lang trade_new}<!--{/if}-->
            <!--{if $trade['quality'] == 2}-->{lang trade_old}<!--{/if}-->
            {lang trade_type_buy}
            </dt>
            <dt><span>{lang trade_remaindays}:</span>
            <!--{if $trade[closed]}-->
            <em>{lang trade_timeout}</em>
            <!--{elseif $trade[expiration] > 0}-->
            {$trade[expiration]}{lang days}{$trade[expirationhour]}{lang trade_hour}
            <!--{elseif $trade[expiration] == -1}-->
            <em>{lang trade_timeout}</em>
            <!--{else}-->
            &nbsp;
            <!--{/if}-->
            </dt>
        </dl>
        <div>
            <!--{if $trade[price] > 0}-->
            <strong>&yen;$trade[price]</strong>
            <!--{/if}-->
            <!--{if $_G['setting']['creditstransextra'][5] != -1 && $trade[credit]}-->
            <!--{if $trade['price'] > 0}-->+<!--{/if}-->{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][5]][title]}<strong>$trade[credit]</strong>
            <!--{/if}-->
            <p class="xg1 c_yj">
                <!--{if $trade['costprice'] > 0}-->
                <del>&yen;$trade[costprice]</del>
                <!--{/if}-->
                <!--{if $_G['setting']['creditstransextra'][5] != -1 && $trade['costcredit'] > 0}-->
                <del><!--{if $trade['costprice'] > 0}-->+ <!--{/if}-->{$_G[setting][extcredits][$_G['setting']['creditstransextra'][5]][title]}{$trade[costcredit]}</del>
                <!--{/if}-->
            </p>
        </div>
    </div>
</div>
<!--{if $post['authorid'] != $_G['uid'] && empty($thread['closed']) && $trade[expiration] > -1}-->
<p class="trade_contact">
    <!--{if $trade[amount]}-->
    <a href="{if $_G['uid']}forum.php?mod=trade&tid=$post[tid]&pid=$trade[pid]{else}member.php?mod=logging&action=login{/if}" class="pn"><span>{lang attachment_buy}</span></a>
    <!--{else}-->
    <a href="javascript:;" class="pn"><span>{lang sold_out}</span></a>
    <!--{/if}-->
</p>
<p class="trade_contact">
    <a href="{if $_G['uid']}home.php?mod=space&do=pm&subop=view&touid={$trade['sellerid']}#last{else}member.php?mod=logging&action=login{/if}">&#x5728;&#x7EBF;&#x780D;&#x4EF7</a>
</p>
<!--{/if}-->
<!--{/loop}-->
<!--{/if}-->
<div id="postmessage_$post[pid]">$post[counterdesc]</div>
<!--{else}-->
<div class="locked">{lang trade_nogoods}</div>
<!--{/if}-->


<!--{/if}-->