<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['pay_view'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{template common/header}-->
<!--{if empty($_GET['infloat'])}-->
<div id="ct" class="wp cl pay_view">
	<div class="mn">
		<div class="bm bw0">
<!--{/if}-->
<div class="f_c pay_title">
	<h3 class="flb b_bottom">
		<em id="return_$_GET['handlekey']">{lang pay_view}</em>
                <span class="y" onclick="popup.close();">
                    <i class="wqiconfont2 wqicon2-iconuser tj_close"></i>
		</span>
	</h3>
	<div class="c pay_view_table">
		<table class="list" cellspacing="0" cellpadding="0">
			<!--{if $loglist}-->
				<!--{loop $loglist $log}-->
					<tr>
						<td><a href="home.php?mod=space&do=profile&uid=$log[uid]">
                                                       <em class="avatar"><img src="<!--{avatar($log[uid], small, true)}-->"></em>
                                                        <div class="pay_name"> $log[username]</div></a></td>
						<td>$log[dateline]</td>
<!--						<td>{$log[$extcreditname]} {$_G[setting][extcredits][$_G[setting][creditstransextra][1]][unit]}</td>-->
					</tr>
				<!--{/loop}-->
			<!--{else}-->
				<tr><td colspan="3">{lang pay_nobuyers}</td></tr>
			<!--{/if}-->
		</table>
	</div>
</div>
<!--{if empty($_GET['infloat'])}-->
		</div>
	</div>
</div>
<!--{/if}-->
<!--{template common/footer}-->
<!--{/if}-->