<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['forumdisplay_p'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{loop $_G['forum_threadlist'] $key $thread}-->
            <!--{if $_G['hiddenexists'] && $thread['hidden']}-->
            <!--{eval continue;}-->
            <!--{/if}-->

            <!--{if !$thread['forumstick'] && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])}-->
            <!--{if $thread['related_group'] == 0 && $thread['closed'] > 1}-->
            <!--{eval $thread[tid]=$thread[closed];}-->
            <!--{/if}-->
            <!--{/if}-->

            <!--{eval $waterfallwidth = $_G[setting][forumpicstyle][thumbwidth] + 24; }-->
    <li>
        <div class="two_box">
            <a class="guidelink" href="forum.php?mod=viewthread&tid=$thread[tid]&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" {if $thread['isgroup'] == 1 || $thread['forumstick'] || CURMODULE == 'guide'} target="_blank"{else} onclick="atarget(this)"{/if} title="$thread[subject]" ">
                <!--{if $thread['cover']}-->
                    <img  src="$thread[coverpath]" alt="$thread[subject]" width="{$_G[setting][forumpicstyle][thumbwidth]}" />
                <!--{else}-->
                    <img src="{$_G['style'][styleimgdir]}images/nophoto2.gif" />
                <!--{/if}-->
                <h3 class="xw0 wqwaterfall_title">
                    <!--{hook/forumdisplay_thread $key}-->
                    $thread[subject]
                </h3>
                <div class="wqwaterfall_info wqapp_f14">
                    <span class="wqwidth80">
                        <!--{hook/forumdisplay_author $key}-->
                       <!--{if $thread['authorid'] && $thread['author']}-->
                            $thread[author]
                        <!--{else}-->
                            $_G[setting][anonymoustext]
                        <!--{/if}-->
                    </span>
                    <span class="xg1 y" ><em class="wqiconfont2 wqicon2-pinglun2 wqapp_f12 wqapp_f13 wqm_right3"></em>$thread[replies]</span>
                </div>
            </a>
        </div>
    </li>
<!--{/loop}-->
<script>
    JC.file('thirdparty/jquery.masonry.min.js');
    JC.run();
</script>
<script type="text/javascript" src="{$_G['style']['styleimgdir']}js/forum/forumdisplay_p.js?{VERHASH}"></script>

<!--{/if}-->