<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['trade'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{eval $header_nav='null';}-->
<!--{template common/header}-->
<!--{eval
    $headparams['wtype'] = '1';
    $headparams['lurl'] = $backurl;
    $headparams['ltype'] = 'a';
    $headparams['cname'] = $Tlang['071ecc9304102f62'];
    echo wq_app_get_header($headparams);
}-->
<script>
     var feevalue = 0;
</script>
<div id="ct" class="ct2 wp">
    <div class="mn buy_info">
        <form method="post" autocomplete="off" id="tradepost" name="tradepost" action="forum.php?mod=trade&action=trade&tid=$_G[tid]&pid=$pid">
            <input type="hidden" name="formhash" value="{FORMHASH}"/>
             <input type="hidden" name="tradesubmit" value="true"/>
                <div class="torder">
                    <div class="spvimg">
                        <a href="javascript:history.go(-1);"><img src="{if $trade['aid']}{echo getforumimg($trade[aid])}{else}{IMGDIR}/nophotosmall.gif{/if}"/>
                        </a>
                    </div>
                    <div class="spi">
                        <dl>
                            <dt>$trade[subject]</dt>
                            <!--{if $trade[locus]}-->
                            <dt><span>{$Tlang['2d79d3a27c3045b7']}</span> $trade[locus]</dt>
                            <!--{/if}-->
                            <dt><span>{lang trade_seller}:</span><a href="home.php?mod=space&do=profile&uid=$trade[sellerid]">$trade[seller]</a></dt>
                            <dt>
                            <!--{if $trade[price] > 0}-->
                            <strong>&yen;<!--{echo (float)$trade[price];}--></strong>
                            <!--{/if}-->
                            <!--{if $_G['setting']['creditstransextra'][5] != -1 && $trade[credit]}-->
                            &nbsp;&nbsp;{$_G[setting][extcredits][$_G['setting']['creditstransextra'][5]][title]}<strong> $trade[credit]</strong>
                            <!--{/if}-->
                            </dt>
                        </dl>
                    </div>
                    <table  cellspacing="0" cellpadding="0" class="tfm">
                        <tr>
                            <th>{$Tlang['902ddee5499ce31c']}</th>
                            <td>
                                <!--{if $trade[price] > 0}-->
                                <strong>&yen;</strong><strong id="caculate"></strong>&nbsp;
                                <!--{/if}-->
                                <!--{if $_G['setting']['creditstransextra'][5] != -1 && $trade[credit]}-->
                                {$_G[setting][extcredits][$_G['setting']['creditstransextra'][5]][title]}
                                <strong id="caculatecredit"></strong>&nbsp;<font id="crediterror" color="red"></font>
                                <!--{/if}-->
                            </td>
                        </tr>
                        <tr>
                            <!--{eval $inventory=$trade[amount]-$trade[totalitems];}-->
                            <th><label for="wq_number">{$Tlang['e4ed182bebceaba9']}</label></th>
                            <td class="rate_table rate_buy">
                                <a href="javascript:;" class="wqiconfont2 wqicon2-jian jianhao subtract_rate nolight wqapp_f24" id="minus_number"></a>
                                <em class="rate_sz buy_sz">
                                    <input type="tel" id="wq_number" name="number" class="graded" value="1"></em>
                                 <input type="hidden" id="wq_number_hidden" value="1"/>
                                <a href="javascript:;" class="wqiconfont2 wqicon2-jia jiahao add_rate wqapp_f24 {if $inventory<=1}no{/if}light" id="add_number"></a>
                                <em class="wq_stock">({$Tlang['eb3cb9138a794033']} {$inventory})</em>
                            </td>
                        </tr>
                        <tr>
                            <th>{lang post_trade_transport}</th>
                            <td>
                                <p>
                                    <!--{if $trade['transport'] == 1}-->{lang post_trade_transport_seller}<!--{/if}-->
                                    <!--{if $trade['transport'] == 2}-->{lang post_trade_transport_buyer}<!--{/if}-->
                                    <!--{if $trade['transport'] == 3}-->{lang post_trade_transport_virtual}<!--{/if}-->
                                    <!--{if $trade['transport'] == 4}-->{lang post_trade_transport_physical}<!--{/if}-->
                                    <input type="hidden" name="transport" value="$trade['transport']">
                                </p>
                            </td>
                        </tr>
                        <!--{if (in_array($trade['transport'],array(1,2,4))) && (!empty($trade['ordinaryfee']) || !empty($trade['expressfee']) || !empty($trade['emsfee']))}-->
                            <tr>
                                <td colspan="2">
                                    <!--{if !empty($trade['ordinaryfee'])}-->
                                        <span class="wqweui_icon_p">
                                        <input class="weui_check" id="fee_1" type="radio" name="fee" value="1" checked="checked" {if $trade['transport'] == 2}onclick="feevalue = $trade[ordinaryfee];calcsum()"{/if}/>
                                        <label class="weui_check_label" for="fee_1"><i class="weui_icon_checked"></i>{lang post_trade_transport_mail} &yen; $trade[ordinaryfee]</label>
                                        <!--{if $trade['transport'] == 2}--><script type="text/javascript">feevalue = '$trade[ordinaryfee]'</script><!--{/if}-->
                                        </span>
                                    <!--{/if}-->
                                    <!--{if !empty($trade['expressfee'])}-->
                                    <span class="wqweui_icon_p">
                                    <input class="weui_check" id="fee_3" type="radio" name="fee" value="3" checked="checked" {if $trade['transport'] == 2}onclick="feevalue = $trade[expressfee];calcsum()"{/if}/>
                                      <label class="weui_check_label" for="fee_3"><i class="weui_icon_checked"></i>{lang post_trade_transport_express} &yen; $trade[expressfee] </label>
                                    <!--{if $trade['transport'] == 2}--><script type="text/javascript">feevalue = '$trade[expressfee]'</script><!--{/if}-->
                                   </span>
                                    <!--{/if}-->
                                    <!--{if !empty($trade['emsfee'])}-->
                                    <span class="wqweui_icon_p">
                                    <input class="weui_check" id="fee_2" type="radio" name="fee" value="2" checked="checked" {if $trade['transport'] == 2}onclick="feevalue = $trade[emsfee];calcsum()"{/if}/>
                                    <label class="weui_check_label" for="fee_2"><i class="weui_icon_checked"></i>EMS &yen; $trade[emsfee] </label>
                                    <!--{if $trade['transport'] == 2}--><script type="text/javascript">feevalue = '$trade[emsfee]'</script><!--{/if}-->
                                    </span>
                                    <!--{/if}-->
                                </td>
                            </tr>
                        <!--{/if}-->
                        <tr>
                            <th>{lang trade_paymethod}</th>
                            <td>
                                <!--{if !$_G['uid']}-->
                                <label><input type="hidden" name="offline" value="0" checked="checked" />{lang trade_pay_alipay}</label>
                                <!--{elseif !$trade['account'] && !$trade['tenpayaccount']}-->
                                <input type="hidden" name="offline" value="1" checked="checked" />{lang trade_pay_offline}
                                <!--{else}-->
                               <input type="radio" id="offline_0" class="weui_check" name="offline" value="0" checked="checked"/>
                                <label for="offline_0" class="weui_check_label bltype"><i class="weui_icon_checked"></i>{lang trade_pay_alipay}</label>
                                <input type="radio" id="offline_1" class="weui_check" name="offline" value="1" />
                                 <label for="offline_1" class="weui_check_label bltype"><i class="weui_icon_checked"></i>{lang trade_pay_offline}</label>
                                <!--{/if}-->
                            </td>
                        </tr>
                        <!--{if $trade['transport'] != 3}-->
                        <tr>
                            <td colspan="2"><input type="text" id="buyername" name="buyername" maxlength="50" value="$lastbuyerinfo[buyername]" class="pt wqnew_all" placeholder="{$Tlang['fa16d5a8e5864f85']}"/></td>
                        </tr>
                        <tr>
                            <td colspan="2"><input type="text" id="buyercontact" name="buyercontact" maxlength="100"  value="$lastbuyerinfo[buyercontact]" class="pt wqnew_all" placeholder='{lang trade_buyercontact}'/></td>
                        </tr>
                        <tr>
                            <td colspan="2"><input type="text" id="buyerzip" name="buyerzip" maxlength="10" value="$lastbuyerinfo[buyerzip]" class="pt wqnew_all" placeholder="{$Tlang['e514023a6801f917']}"/></td>
                        </tr>
                        <tr>
                            <td colspan="2"><input type="text" id="buyerphone" name="buyerphone" maxlength="20" value="$lastbuyerinfo[buyerphone]" class="pt wqnew_all" placeholder="{$Tlang['a4a7de757d32148c']}"/></td>
                        </tr>
                        <tr>
                            <td colspan="2"><input type="text" id="buyermobile" name="buyermobile" maxlength="20" value="$lastbuyerinfo[buyermobile]" class="pt wqnew_all" placeholder="{$Tlang['734e5ea9b979860a']}"/></td>
                        </tr>
                        <!--{else}-->
                        <input type="hidden" name="buyername" value=""/>
                        <input type="hidden" name="buyercontact" value=""/>
                        <input type="hidden" name="buyerzip" value="" />
                        <input type="hidden" name="buyerphone" value=""/>
                        <input type="hidden" name="buyermobile" value=""/>
                        <!--{/if}-->
                        <tr>
                            <td colspan="2">
                               <p class="border1 wqnew_all"> <textarea id="buyermsg" name="buyermsg" rows="2" class="pt" placeholder="{$Tlang['5d1249a0d4098eaf']}"></textarea></p>
                            </td>
                        </tr>
                        <tr>

                            <td class="pns"  colspan="2">
                                <button class="pn pnc formdialog wqbg_color wqm_top10 wqtrade_confirm" type="submit" id="tradesubmit" ><span>{lang trade_buy_confirm}</span></button>
                                <!--{if !$_G['uid']}--><em class="xg2">{lang trade_guest_alarm}</em><!--{/if}-->
                            </td>
                        </tr>
                    </table>
            </div>
        </form>
        <script type="text/javascript">
            feevalue=parseFloat(feevalue);

            function calcsum() {
                var wq_number=parseInt($('#wq_number').val());
                if ('$trade[price]' > 0) {
                    $('#caculate').text(parseFloat('$trade[price]') * wq_number + feevalue);
                }
                if ("$_G['setting']['creditstransextra'][5]" != -1 && '$trade[credit]') {
                    v = parseInt('$trade[credit]') * wq_number;
                    if (v > "{echo getuserprofile('extcredits'.$_G['setting']['creditstransextra'][5])}") {
                        $('#crediterror').text("{$Tlang['8bd7510c6055308d']}");
                        $('#tradesubmit').attr('disabled', 'disabled');
                    } else {
                        $('#tradesubmit').attr('disabled', null);
                        $('#crediterror').text('');
                    }
                    $('#caculatecredit').text(v);
                }
            }

            calcsum();

            $('#minus_number').click(function(){
               var wq_number=parseInt($('#wq_number').val())-1;
               if (wq_number>=1) {
                    $('#wq_number').val(wq_number);
                    wq_numbers(wq_number);
               }
            });

            $('#add_number').click(function(){
                var wq_number=parseInt($('#wq_number').val())+1;
               if (wq_number<='$inventory') {
                    $('#wq_number').val(wq_number);
                    wq_numbers(wq_number);
               }
            });

            $('#wq_number').blur(function(){
               var wq_number=parseInt($(this).val());
               if (wq_number<='$inventory'&&wq_number>=1) {
                    $('#wq_number').val(wq_number);
                    wq_numbers(wq_number);
               }else{
                    $('#wq_number').val($('#wq_number_hidden').val());
               }
            });

            function wq_numbers(wq_number) {
                  $('#wq_number_hidden').val(wq_number);
                  calcsum();
                  $('#add_number').attr('class','wqiconfont2 wqicon2-jia jianhao add_rate wqapp_f24 '+(wq_number+1>'$inventory'?'no':'')+'light');
                  $('#minus_number').attr('class','wqiconfont2 wqicon2-jian jianhao subtract_rate wqapp_f24 '+(wq_number-1<1?'no':'')+'light');
            }
        </script>
    </div>
</div>
<!--{eval $nofooter=1;}-->
<!--{template common/footer}-->
<!--{/if}-->