<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['discuz_4'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<div id="sub_forum_$cat[fid]" class="sub_forum bm_c wqplate_ul">
    <ul>
        <!--{loop $cat[forums] $forumid}-->
        <!--{eval $forum=$forumlist[$forumid];}-->
            <li>

                <div class="wqimg">
                <!--{if $forum[icon]}-->
                    $forum[icon]
                <!--{else}-->
                    <a href="forum.php?mod=forumdisplay&fid={$forum['fid']}">
                        <img src="{$_G['style'][styleimgdir]}images/forum{if $forum[folder]}_new{/if}.gif" alt="$forum[name]" />
                    </a>
                <!--{/if}-->
                <!--{if $forum[todayposts] > 0 && $wq_app_setting[tpost]==1}--><span class="wqnum">$forum[todayposts]</span><!--{/if}-->
                </div>
                    <a href="forum.php?mod=forumdisplay&fid={$forum['fid']}"><p>{$forum[name]}</p></a>
                      <!--{if $wq_app_setting['view_line'] == '1'}-->
                        <span class="plan_line wqnew_right"></span>
                    <!--{/if}-->
            </li>
        <!--{/loop}-->
    </ul>
</div>
<!--{/if}-->