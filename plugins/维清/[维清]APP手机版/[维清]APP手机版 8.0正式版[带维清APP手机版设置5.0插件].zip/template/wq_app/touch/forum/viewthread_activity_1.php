<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['viewthread_activity_1'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{if $_G['uid'] && !$activityclose && (!$applied || $isverified == 2)}-->

    <!--{eval
        $headparams['wtype'] = '1';
        $headparams['lurl'] = $backurl;
        $headparams['ltype'] = 'a';
        $headparams['cname'] = $Tlang['e39b07482cb0532c'];
        echo wq_app_get_header($headparams);
    }-->
    <div id="activityjoin" class="bm wqjoin_warp">
    <div class="join pd5">
        <!--{if $_G['forum']['status'] == 3 && helper_access::check_module('group') && $isgroupuser != 'isgroupuser'}-->
        <p>{lang activity_no_member}</p>
        <p><strong></strong><a href="forum.php?mod=group&action=join&fid=$_G[fid]" class="xi2">{lang activity_join_group}</a></p>
        <!--{else}-->
        <form name="activity" id="activity"  method="post" autocomplete="off" action="forum.php?mod=misc&action=activityapplies&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]{if $_GET['from']}&from=$_GET['from']{/if}" >
            <input type="hidden" name="formhash" value="{FORMHASH}" />
            <input type="hidden" name="handlekey" value="activityapplies">
            <!--{if $_G['setting']['activitycredit'] && $activity['credit'] && !$applied}-->
            <p class="xi1 wqred" style="margin-bottom: 10px;">{lang activity_need_credit} $activity[credit] {$_G['setting']['extcredits'][$_G['setting']['activitycredit']][title]}</p><!--{/if}-->
            <!--{if $activity['cost']}-->
            <div class="mode_pay wqactivity_data">
                <ul>
                    <li class="wqnew_bottom">
                        <em>{lang activity_paytype}</em>
                        <span class="text_left"><input class="weui_check" type="radio" value="0" name="payment" id="payment_0" checked="checked">
                <label class="weui_check_label"  for="payment_0"><i class="weui_icon_checked"></i>{lang activity_pay_myself}</label></span>
                        <span class="text_left wqheight"><input class="weui_check" type="radio" value="1" name="payment" id="payment_1" />
                    <label class="weui_check_label" for="payment_1"><i class="weui_icon_checked"></i>{lang activity_would_payment}</label><input name="payvalue" size="3" class="txt_s wqnew_all" id="money" onfocus="$('#payment_1').click()"/> {lang payment_unit}</span>
                    </li>
                </ul>
            </div>
            <!--{/if}-->
            <!--{if !empty($activity['ufield']['userfield'])}-->
            <div id='userfield' class="wqactivity_data wqwarp">
                <ul>
                <!--{loop $activity['ufield']['userfield'] $fieldid}-->
                <!--{if $settings[$fieldid][available]}-->
                 <li class="wqnew_bottom">
                        <em>$settings[$fieldid][title]<span class="xi1 wqred">*</span></em>
                        <span class="text_left">$htmls[$fieldid]</span>
                    </li>
                <!--{/if}-->
                <!--{/loop}-->
                 </ul>
            </div>
            <!--{/if}-->
            <!--{if !empty($activity['ufield']['extfield'])}-->
            <!--{loop $activity['ufield']['extfield'] $extname}-->
            <strong>$extname</strong><input type="text" name="$extname" maxlength="200" class="px m_l10 m_t10" value="{if !empty($ufielddata)}$ufielddata[extfield][$extname]{/if}" /><br/>
            <!--{/loop}-->
            <!--{/if}-->
            <div id='userfield' class="wqactivity_data wqwarp">
                <ul>
                  <li class="wqnew_bottom">
                        <em>{lang leaveword}</em>
                        <span class="text_left"><textarea name="message" maxlength="200" cols="28" rows="1" class="txt">$applyinfo[message]</textarea></span>
                    </li>
             </ul>
            </div>
            <div class="o pns hd_submit">
                <!--{if $_G['setting']['activitycredit'] && $activity['credit'] && checklowerlimit(array('extcredits'.$_G['setting']['activitycredit'] => '-'.$activity['credit']), $_G['uid'], 1, 0, 1) !== true}-->
                <p class="xi1 wqred wqnot_enough">{$_G['setting']['extcredits'][$_G['setting']['activitycredit']][title]} {lang not_enough}$activity['credit']</p>
                <!--{else}-->
                <input type="hidden" name="activitysubmit" value="true">
                <em class="xi1" id="return_activityapplies"></em>
                <button id="activity_joins_submit" type="button" class="v_submit wqbutton wqbg_color wqborder"><span>{lang submit}</span></button>
                <!--{/if}-->
            </div>
        </form>
        <script type="text/javascript">
            $('.wqwant_join').click(function () {
                $('#activity').toggle();
            });

            $('#activity_joins_submit').click(function () {
                var obj = $('#activity');
                $.ajax({
                    type: 'POST',
                    url: obj.attr('action') + '&inajax=yes',
                    data: obj.serialize(),
                    dataType: 'html'
                }).success(function (s) {
                    popup.open(wqXml(s));
                }).error(function () {
                    popup.open('{lang networkerror}', 'alert');
                });
                return false;
            });
            function succeedhandle_activityapplies(locationhref, message) {
                setTimeout(function () {
                    location.href = locationhref;
                }, 1500);
            }
            if (document.getElementById('birthprovince')){
                document.getElementById('birthprovince').onchange = null
            }
            if (document.getElementById('resideprovince')){
                document.getElementById('resideprovince').onchange = null
            }
            $('body').on('change', '#birthprovince, #resideprovince', function () {
                if (!$(this).val()) {
                    $(this).next('select').remove()
                } else {
                    var upid = $(this).find('option:selected').attr('did')
                    var that = $(this)
                    var cityName = that.parent().prop('id') == 'birthdistrictbox' ? 'birthcity' : 'residecity'
                    var distName = that.parent().prop('id') == 'birthdistrictbox' ? 'birthdist' : 'residedist'
                    $.ajax({
                        url: 'plugin.php?id=wq_app_setting&mod=api&fun=district&level=2',
                        data: {upid: upid},
                        type: 'GET',
                        dataType: 'JSON',
                        success: function (res) {
                            var option = ''
                            for (var i in res.data) {
                                option += '<option value="' + res.data[i].name + '">' + res.data[i].name + '</option>'
                            }
                            that.next('select').remove()
                            that.parent().append('<select name="' + cityName + '" class="ps"  tabindex="1"><option value="">-{$Tlang['29405aa0c5f4c1b9']}-</option>' + option + '</select><input type="hidden" name="' + distName + '" value />')
                        }
                    })
                }
            })
        </script>
        <!--{/if}-->
    </div>
</div>
<!--{elseif $_G['uid'] && !$activityclose && $applied}-->

<div id="activityjoincancel" class="bm">
    <div class="join pd5 wqactivity_data wqwarp">
        <form name="activity" id="activity_form"  method="post" autocomplete="off" action="forum.php?mod=misc&action=activityapplies&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]{if $_GET['from']}&from=$_GET['from']{/if}">
            <input type="hidden" name="formhash" value="{FORMHASH}" />
            <input type="hidden" name="activitycancel" value="true">

                    <!--{eval
                $headparams['wtype'] = '2';
                $headparams['ltype'] = 'cancel';
                $headparams['lname'] = $Tlang['9c825be7149e5b97'];
                $headparams['lurl'] = 'javascript:void(0);';

                $headparams['ctype'] = 'span';
                $headparams['cname'] = $Tlang['79868eec5cb44779'];

                $headparams['rtype'] = 'but';
                $headparams['rname'] = "{lang submit}";
                $headparams['rclass'] = 'wqheader_right formdialog';
                $headparams['rid'] = 'activity_cancel_submit';
                $headparams['buttype'] = 'submit';

                echo wq_app_get_header($headparams, false, true) ;
            }-->
        
            <ul class='wqjoin_warp'style='padding-top: 0px;'>
                <li class="wqnew_bottom">
                    <em>{lang leaveword}</em>
                    <span class="text_left"><textarea name="message" maxlength="200" class="txt" cols="28" rows="1"  /></textarea></span>
                </li>
            </ul>
<!--            <div class="mtn pns hd_submit">
                <input type="hidden" name="activitycancel" value="true">
                <button type="button" id="activity_cancel_submit" class="v_submit wqbutton wqbg_color wqborder"><span>{lang submit}</span></button>
            </div>-->
        </form>
    </div>
</div>
<script type="text/javascript">
    $('.wqwant_join').click(function () {
        $('#activity_form').toggle();
    });

    $('#activity_cancel_submit').click(function () {
        var obj = $('#activity_form');
        $.ajax({
            type: 'POST',
            url: obj.attr('action') + '&inajax=yes',
            data: obj.serialize(),
            dataType: 'html'
        }).success(function (s) {
            popup.open(wqXml(s));
        }).error(function () {
            popup.open('{lang networkerror}', 'alert');
        });
        return false;
    });
    function succeedhandle_activityapplies(locationhref, message) {
        setTimeout(function () {
            location.href = locationhref;
        }, 1500);
    }
</script>
<!--{/if}-->



<!--{/if}-->