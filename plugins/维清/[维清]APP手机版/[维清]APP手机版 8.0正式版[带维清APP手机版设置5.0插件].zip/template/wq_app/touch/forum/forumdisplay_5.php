<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['forumdisplay_5'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{eval
    $tids = get_wq_app_tids($_G['forum_threadlist']);
    $threadlists= wq_app_get_thread_info_from_cache($tids);
    loadcache('wq_app_favorite_'  . $_G['uid']);
    $favorites=$_G['cache']['wq_app_favorite_'  . $_G['uid']];
}-->

<!--{loop $_G['forum_threadlist'] $key $thread}-->
    <!--{eval
        $threadicon = get_icon_for_list();
        $summarys = $threadlists[$thread['tid']]['summary'];
        $imagenum = $threadlists[$thread['tid']]['imagenum'];
        $images= $imagenum > 0 ? wq_app_setting_get_pic($threadlists[$thread['tid']]['maximgs'],$threadlists[$thread['tid']]['images'],$showmodel,3) : array();
    }-->
    <!--{if $thread['displayorder'] > 0}-->
        <!--{eval continue;}-->
    <!--{/if}-->


<!--{hook/forumdisplay_thread_mobile $key}-->
<li class="b_bottom">
    <div class="interest_head">
        <div class="in_img">
            <a href="home.php?mod=space&do=profile&uid={$thread[authorid]}">
                <img class="wq_js_delayload" src="{$_G['style'][styleimgdir]}images/wq_dian.jpg" data-src="{avatar($thread[authorid], small, true)}"/>
            </a>
        </div>
        <span class="interest_head_text">
            <span class="interest_head_name">
                <a href="home.php?mod=space&do=profile&uid={$thread[authorid]}">
                    <font class="wqg_width100">{$thread[author]}</font>
                </a>
            </span>
        </span>
        <span class="interest_head_time0">{$thread[dateline]}</span>
        <div class="wqgroup_browse"><span class="wqiconfont2 wqicon2-p-see f14"></span>{$thread[views]}</div>
    </div>
    <div class="wqdynamic_info_sss">
        <a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra">
            <div class="h_over_nav">
                <h3 class="title">
                    {$threadicon}{if $thread[typename]}<span class="wqicon_all_14 wqicon_vote">{$thread[typename]}</span>{/if}<font $thread[highlight]>{$thread[subject]}</font>
                </h3>
                <div class="title_con">{$summarys}</div>
            </div>
            <!--{if $images && $imagenum > 0}-->
                <div class="{if $imagenum==1}interest_img1{elseif $imagenum==2}interest_img2{else}interest_img3{/if}">
                    <!--{loop $images $k $v}-->
                        <div class="img-box wqc_img_box wq-lazyload-container" >
                            <img class="wq_js_delayload" src="{$_G['style'][styleimgdir]}images/wq_dian.jpg" data-src="{$v}">
                        </div>
                    <!--{/loop}-->
                </div>
            <!--{/if}-->
        </a>
        <div class="wqdynamic_info">
            <div class="wqdynamic_info_div">
                <a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra">
                    <i class="wqiconfont2 wqicon2-groupcopy5 f13"></i>
                    <!--{if $thread['isgroup'] != 1}-->$thread[replies]<!--{else}-->{$groupnames[$thread[tid]][replies]}<!--{/if}-->
                </a>
            </div>
            <div class="wqdynamic_info_div">
                <a href="forum.php?mod=misc&action=recommend&do=add&tid={$thread[tid]}&hash={FORMHASH}&handlekey=recommendadd" class="dialog recommendadd_zan notlogged" data="$thread[tid]">
                    <i class="wqiconfont2 wqicon2-gzan wqapp_f14"></i>
                    <span id="recommendadd_{$thread[tid]}">{$thread[recommend_add]}</span>
                    <span class="wqgroup_line " ></span>
                </a>
            </div>
            <div class="wqdynamic_info_div">
                <a href="home.php?mod=spacecp&ac=favorite&type=thread&id={$thread[tid]}&handlekey=newfav" class="newfav dialog notlogged" data="$thread[tid]">
                    <!--{if $favorites[$thread[tid]]}-->
                        <i class="wqiconfont2 wqicon2-shoucang3 wqapp_f16 wqline_h wqcolor_yellow "></i>
                    <!--{else}-->
                        <i class="wqiconfont2 wqicon2-shoucang2 wqapp_f16 wqline_h" id="i_crad_{$thread[tid]}"></i>
                    <!--{/if}-->
                    <span id="crad_{$thread[tid]}" >{$thread['favtimes']}</span>
                    <span class="wqgroup_line"></span>
                </a>
            </div>
        </div>
    </div>
</li>
<!--{/loop}-->


<!--{/if}-->