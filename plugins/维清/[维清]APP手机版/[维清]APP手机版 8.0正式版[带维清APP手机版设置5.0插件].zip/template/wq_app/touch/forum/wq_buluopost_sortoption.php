<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['wq_buluopost_sortoption'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<input type="hidden" name="selectsortid" size="45" value="$_G['forum_selectsortid']" />

<div class="sortop">
	<table cellspacing="0" cellpadding="0" class="tfm">
	<!--{if $_G['forum']['threadsorts']['description'][$_G['forum_selectsortid']]}-->
        <tr class="b_bottom">
               <th class="ptm pbm bbda">{$Tlang['36603816bcb173c9']}</th>
			<td class="ptm pbm bbda" colspan="2">$_G[forum][threadsorts][description][$_G[forum_selectsortid]]</td>
		</tr>
	<!--{/if}-->
	<!--{if $_G['forum']['threadsorts']['expiration'][$_G['forum_selectsortid']]}-->
		<tr class="b_bottom">
                    <th class="ptm pbm bbda">{$Tlang['78ff3b8f201c51d3']}</th>
			<td class="ptm pbm bbda" colspan="2">
				<div class="ftid">
					<select name="typeexpiration" tabindex="1" id="typeexpiration">
						<option value="259200">{lang three_days}</option>
						<option value="432000">{lang five_days}</option>
						<option value="604800">{lang seven_days}</option>
						<option value="2592000">{lang one_month}</option>
						<option value="7776000">{lang three_months}</option>
						<option value="15552000">{lang half_year}</option>
						<option value="31536000">{lang one_year}</option>
					</select>
				</div>
				<!--{if $_G['forum_optiondata']['expiration']}-->{lang valid_before}: $_G[forum_optiondata][expiration]<!--{/if}-->
			</td>
		</tr>
	<!--{/if}-->
        <!--{eval $datetype="date";}-->
        <!--{template common/wq_buluocalendar}-->
	<!--{loop $_G['forum_optionlist'] $optionid $option}-->
		<tr class="b_bottom">
			<th class="ptm pbm bbda">$option[title]<!--{if $option['required']}--><span class="rq">*</span><!--{/if}--></th>
			<td class="ptm pbm bbda">
                                    <!--{block reminder}-->
                                    <!--{if $option['maxnum'] || $option['minnum'] || $option['maxlength'] || $option['unchangeable'] || $option[description]}-->
                                           <!--{if $option['maxnum']}-->{lang maxnum} $option[maxnum]&nbsp; <!--{/if}-->
                                           <!--{if $option['minnum']}-->{lang minnum} $option[minnum]&nbsp;<!--{/if}-->
                                           <!--{if $option['maxlength']}-->{lang maxlength} $option[maxlength]&nbsp;<!--{/if}-->
                                           <!--{if $option['unchangeable']}-->{lang unchangeable}&nbsp;<!--{/if}-->
                                           <!--{if $option[description]}-->$option[description]<!--{/if}-->
                                    <!--{else}-->
                                    <!--{/if}-->
                                    <!--{/block}-->
                                    <!--{eval $reminder=str_replace(' ', '', $reminder);}-->
				<div id="select_$option[identifier]">
				<!--{if in_array($option['type'], array('number', 'text', 'email', 'calendar', 'image', 'url', 'range', 'upload', 'range'))}-->
					<!--{if $option['type'] == 'calendar'}-->
				        <input type="text" name="typeoption[{$option[identifier]}]" id="typeoption_$option[identifier]" tabindex="1" size="$option[inputsize]" placeholder="$reminder"  value="$option[value]"  $option[unchangeable] class="px"/>
                                        <script type="text/javascript" reload="1">
                                        $(function(){
                                               $("#typeoption_$option[identifier]").mobiscroll(opt);
                                         });
                                        </script>
					<!--{elseif $option['type'] == 'image'}-->
						<!--{if !($option[unchangeable] && $option['value'])}-->
                                                <div class="sc_bg"> <a href="javascript:;">{$Tlang['1d0d90107b8abd7d']}
                                                    <input type="button" id="sortaid_{$option[identifier]}_button" class="poto">
                                                    </a>
                                                    </div>
                                                    <div id="sortattach_image_{$option[identifier]}" class="sc_img">
                                                        <!--{if $option['value']['url']}-->
                                                        <img class="spimg" src="$option[value][url]"/>
                                                        <input type="hidden" name="typeoption[{$option[identifier]}][aid]" value="$option[value][aid]" id="sortaid_{$option[identifier]}" />
                                                        <input type="hidden" name="typeoption[{$option[identifier]}][url]" id="sortattachurl_{$option[identifier]}" value="$option[value][url]" tabindex="1"/>
                                                        <!--{/if}-->
                                                    </div>
                                                    <!--{if $option[value]}-->
                                                        <input type="hidden" name="oldsortaid[{$option[identifier]}]" value="$option[value][aid]" tabindex="1" />
                                                    <!--{/if}-->
						<!--{/if}-->
                                                <script type="text/javascript" reload="1">
                                                $(function(){
                                                    var sortaid_{$option[identifier]}_upload= function(data) {
                                                                                       if(data == '') {
                                                                                               popup.open('{lang uploadpicfailed}', 'alert');
                                                                                       }
                                                                                       var dataarr = data.split('|');
                                                                                       if(dataarr[0] == 'DISCUZUPLOAD' && dataarr[2] == 0) {
                                                                                               popup.close();
                                                                                               if ($('#tradeaid').length) {
                                                                                                       $.ajax({
                                                                                                                type:'GET',
                                                                                                                url:'forum.php?mod=ajax&action=deleteattach&inajax=yes&aids[]=' + $('#tradeaid').val(),
                                                                                                       })
                                                                                               }
                                                                                               $('#sortattach_image_{$option[identifier]}').html('<a href="javascript:;"><img src="{$_G[setting][attachurl]}forum/'+dataarr[5]+'" />\n\
                                                <input type="hidden" name="typeoption[{$option[identifier]}][aid]" id="sortaid_{$option[identifier]}" value="'+dataarr[3]+'">\n\
                                                <input type="hidden" name="sortaid_{$option[identifier]}_url" id="sortaid_{$option[identifier]}_url" value="'+dataarr[5]+'">\n\
                                                <input type="hidden" name="typeoption[{$option[identifier]}][url]" id="sortattachurl_{$option[identifier]}" value="{$_G[setting][attachurl]}forum/'+dataarr[5]+'"></a>');
                                                                                    $('#filedata').val('').attr('multiple','multiple');
                                                                                        } else {
                                                                                               var sizelimit = '';
                                                                                               if(dataarr[7] == 'ban') {
                                                                                                       sizelimit = '{lang uploadpicatttypeban}';
                                                                                               } else if(dataarr[7] == 'perday') {
                                                                                                       sizelimit = '{lang donotcross}'+Math.ceil(dataarr[8]/1024)+'K)';
                                                                                               } else if(dataarr[7] > 0) {
                                                                                                       sizelimit = '{lang donotcross}'+Math.ceil(dataarr[7]/1024)+'K)';
                                                                                               }
                                                                                               popup.open(STATUSMSG[dataarr[2]] + sizelimit, 'alert');
                                                                                       }
                                                             };
                                                        $('#sortaid_{$option[identifier]}_button').click(function() {
                                                              uploadsuccess_forum= sortaid_{$option[identifier]}_upload
                                                           $('#filedata').attr('multiple',null).click();
                                                        });
                                                });
                                                </script>
					<!--{else}-->
					<input type="{if $option['type'] == 'number'}tel{else}text{/if}" name="typeoption[{$option[identifier]}]" id="typeoption_$option[identifier]" class="sortop_px" tabindex="1" placeholder="$reminder" size="$option[inputsize]"  value="{if $_G['tid']}$option[value]{else}{if $member_profile[$option['profile']]}$member_profile[$option['profile']]{else}$option['defaultvalue']{/if}{/if}" $option[unchangeable] />
					<!--{/if}-->
				<!--{elseif in_array($option['type'], array('radio', 'checkbox', 'select'))}-->
					<!--{if $option[type] == 'select'}-->
						<!--{loop $option['value'] $selectedkey $selectedvalue}-->
							<!--{if $selectedkey}-->
								<script type="text/javascript">
									changeselectthreadsort('$selectedkey', $optionid, 'update');
								</script>
							<!--{else}-->
								<select tabindex="1" onchange="changeselectthreadsort(this.value, '$optionid');" $option[unchangeable] class="ps">
									<option value="0">{lang please_select}</option>
									<!--{loop $option['choices'] $id $value}-->
										<!--{if !$value[foptionid]}-->
										<option value="$id">$value[content] <!--{if $value['level'] != 1}-->&raquo;<!--{/if}--></option>
										<!--{/if}-->
									<!--{/loop}-->
								</select>
							<!--{/if}-->
						<!--{/loop}-->
						<!--{if !is_array($option['value'])}-->
							<select tabindex="1" onchange="changeselectthreadsort(this.value, '$optionid');" $option[unchangeable] class="ps">
								<option value="0">{lang please_select}</option>
								<!--{loop $option['choices'] $id $value}-->
									<!--{if !$value[foptionid]}-->
									<option value="$id">$value[content] <!--{if $value['level'] != 1}-->&raquo;<!--{/if}--></option>
									<!--{/if}-->
								<!--{/loop}-->
							</select>
						<!--{/if}-->
					<!--{elseif $option['type'] == 'radio'}-->
						<ul class="xl2">
						<!--{loop $option['choices'] $id $value}-->
							<li>
                                                            <input type="radio" name="typeoption[{$option[identifier]}]" id="typeoption_$option[identifier]_$id" class="weui_check" tabindex="1"  value="$id" $option['value'][$id] $option[unchangeable] class="pr">
                                                            <label class="weui_check_label" for="typeoption_$option[identifier]_$id"><i class="weui_icon_checked"></i>$value</label></li>
						<!--{/loop}-->
						</ul>
					<!--{elseif $option['type'] == 'checkbox'}-->
						<ul class="xl2">
						<!--{loop $option['choices'] $id $value}-->
							<li>
                                                            <input type="checkbox" name="typeoption[{$option[identifier]}][]" id="typeoption_$option[identifier]_$id" class="weui_check" tabindex="1"  value="$id" $option['value'][$id][$id] $option[unchangeable] class="pc">
                                                            <label class="weui_check_label" for="typeoption_$option[identifier]_$id"><i class="weui_icon_checked"></i>$value</label>
                                                        </li>
						<!--{/loop}-->
						</ul>
					<!--{/if}-->
				<!--{elseif in_array($option['type'], array('textarea'))}-->
					<textarea name="typeoption[{$option[identifier]}]" tabindex="1" id="typeoption_$option[identifier]" rows="$option[rowsize]" cols="$option[colsize]"  $option[unchangeable] class="pt">$option[value]</textarea>
				<!--{/if}-->
                                   <!--{if $option['type']!='select'}-->
                                    <span class="sortop_ts">$option[unit]</span>
                                   <!--{/if}-->
				</div>
			</td>
		</tr>
	<!--{/loop}-->
	</table>
    </div>

<!--{if $isfirstpost && $sortid}-->
	<script type="text/javascript">
		var forum_optionlist = <!--{if $forum_optionlist}-->'$forum_optionlist'<!--{else}-->''<!--{/if}-->;
                 function succeedhandle_postform(msg, param) {
                        if (msg=='forum.php?mod=post&action=newthread&fid=$_G[fid]&sortid=$sortid&mobile=2') {
                             clearInterval(setTimeout_location)
                             setTimeout(function() {
                               popup.close();
                            }, '1750');
                       }
                }
	</script>
	<script  type="text/javascript" src="{$_G['style']['styleimgdir']}mobile/thirdparty/threadsort.js?{VERHASH}"></script>
<!--{/if}-->
<!--{/if}-->