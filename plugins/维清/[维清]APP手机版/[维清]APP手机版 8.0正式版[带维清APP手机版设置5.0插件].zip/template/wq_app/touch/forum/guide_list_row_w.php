<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['guide_list_row_w'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{eval
    $tids = get_wq_app_tids($list['threadlist']);
    $threadlists= wq_app_get_thread_info_from_cache($tids);
}-->
<!--{eval include_once template('common/common_module');}-->
<!--{loop $list['threadlist'] $key $thread}-->
    <!--{eval
        $threadicon = get_icon_for_list();
        $summarys = $threadlists[$thread['tid']]['summary'];
        $imagenum = $threadlists[$thread['tid']]['imagenum'];
        $images= $imagenum > 0 ? wq_app_setting_get_pic($threadlists[$thread['tid']]['maximgs'],$threadlists[$thread['tid']]['images'],$showmodel,9) : array();
        $recommendnum = $threadlists[$thread['tid']]['recommendnum'];
        $recommend =  array_slice($threadlists[$thread['tid']]['recommend'],0,$wq_app_setting['wechat_recommend_num'],true);
        $repliesnum = $threadlists[$thread['tid']]['repliesnum'];
        $replies =  array_slice($threadlists[$thread['tid']]['replies'],0,$wq_app_setting['wechat_replies_num'],true);
        $thread['tid'] = get_tid_isclose_for_guide();
    }-->
    <li class="wqnew_bottom">
        <div class="wqhead">
            <a href="home.php?mod=space&do=profile&uid={$thread[authorid]}">
                <img src="{avatar($thread[authorid], small, true)}"/>
            </a>
        </div>
        <div class="wqcon">
            <h3>{$thread[author]}</h3>
            <a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" class="wqimga guidelink">
            <p>{$threadicon}{$thread[typehtml]}{$thread[sorthtml]}<font $thread[highlight]>{$thread[subject]}</font></p>
            <!--{if $images && $imagenum > 0}-->
                <div class="{if $imagenum==1}wqimg_1{elseif $imagenum==4}wqimg_4{else}wqimg{/if}">
                    <!--{loop $images $k $v}-->
                        <div class="wq_img wq-lazyload-container" >
                            <img class="wq_js_delayload" src="{$_G['style'][styleimgdir]}images/wq_dian.jpg"  data-src="{$v}">
                        </div>
                    <!--{/loop}-->
                    <!--{if $imagenum > 9 }-->
                        <span class="wqpic_num"><i class="wqiconfont2 wqicon2-tupian-copy"></i>{$imagenum}</span>
                    <!--{/if}-->
                </div>
            <!--{/if}-->
            </a>
            <div class="wqtime">$thread[dateline]
                <span class="wqcomment new_div">
                    <i class="wqiconfont2 wqicon2-comiisdanchupinglun new_button2"></i>
                </span>
                <div class="wqcomment_pop new_menu" style="display:none">
                    <a href="forum.php?mod=misc&action=recommend&do=add&tid={$thread[tid]}&hash={FORMHASH}&handlekey=wrecommendadd" class="wqzan dialog recommendadd_zan notlogged" data="$thread[tid]">
                        <i class="wqiconfont2 wqicon2-aixin"></i>{$Tlang['dcd4705a63ab26c1']}
                    </a>
                    <em></em>
                    <a href="forum.php?mod=post&action=reply&fid={$_G['fid']}&tid={$thread[tid]}&route=w" class="dialog notlogged">
                        <i class="wqiconfont2 wqicon2-groupcopy5"></i>{$Tlang['dbedca5ca18ae5c8']}
                    </a>
                </div>
            </div>
            <div class="wqcommet_warp" id="wqcommet_warp_{$thread[tid]}" {if $recommendnum <= 0 && $repliesnum <= 0}style="display:none"{/if} data-username="{$_G[username]}" data-uid="{$_G[uid]}">
                <span class="wqcommet_arrow wqiconfont2 wqicon2-jiantou-copy"></span>
                <div class="wqcommet_con">
                    <div class="wqzan" id="wqzan_{$thread[tid]}" {if $recommendnum <= 0}style="display:none"{/if}>
                        <i class="wqiconfont2 wqicon2-aixin"></i>
                        <!--{eval $num = end(array_keys($recommend));}-->
                        <!--{loop $recommend $rkey $rval}-->
                            <a href="home.php?mod=space&do=profile&uid={$rkey}" class="wq_name">{$rval}{if $rkey != $num},{/if}</a>
                        <!--{/loop}-->
                    </div>
                    <div class="wqcommet {if $recommendnum > 0} wq_border_top{/if}" id="wqcommet_{$thread[tid]}" {if $repliesnum <= 0}style="display:none"{/if}>
                        <!--{loop $replies $rkey $replie}-->
                            <!--{if empty($replie['rauthor'])}-->
                            <p>
                                <a href="home.php?mod=space&do=profile&uid={$replie[authorid]}" class="wq_name">{$replie['author']}:</a>
                                <a href="forum.php?mod=post&action=reply&&fid={$_G['fid']}&tid={$thread[tid]}&repquote={$rkey}&route=w"  class="dialog wqdis_block notlogged">&nbsp;&nbsp;{$replie['message']}</a>
                            </p>
                            <!--{else}-->
                            <p>
                                <a href="home.php?mod=space&do=profile&uid={$replie[authorid]}" class="wq_name">{$replie['author']}</a>
                                <span style='float: left;'>{$Tlang['209e3f19421ead4d']}</span>
                                <a href="home.php?mod=space&do=profile&uid={$replie[rauthorid]}" class="wq_name">{$replie['rauthor']}:</a>
                                <a href="forum.php?mod=post&action=reply&&fid={$_G['fid']}&tid={$thread[tid]}&repquote={$rkey}&route=w" class="dialog notlogged">&nbsp;&nbsp;{$replie['message']}</a>
                            </p>
                            <!--{/if}-->
                        <!--{/loop}-->
                    </div>
                </div>
            </div>
        </div>
    </li>
<!--{/loop}-->
<!--{/if}-->