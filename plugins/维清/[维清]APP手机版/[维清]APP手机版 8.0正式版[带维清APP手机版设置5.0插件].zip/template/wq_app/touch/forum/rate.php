<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['rate'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{template common/header}-->
<!--{if empty($_GET['showratetip'])}-->

<div id="ct" class="wqipagen">
    <!--{if $_GET[action] == 'rate'}-->
    <form id="rateform" method="post"  action="forum.php?mod=misc&action=rate&ratesubmit=yes&infloat=yes">
        <input type="hidden" name="formhash" value="{FORMHASH}"/>
        <input type="hidden" name="tid" value="$_G[tid]"/>
        <input type="hidden" name="pid" value="$_GET[pid]"/>
        <input type="hidden" name="referer" value="$referer"/>
        <!--{if !empty($_GET['infloat'])}--><input type="hidden" name="handlekey" value="rate"><!--{/if}-->
        <div class="wqheader wqbg_color" style="position: absolute; top:0px;">
            <a href="javascript:;" id="popup_hidden" class="wqcancel new_hidden1">{$Tlang['9c825be7149e5b97']}</a>
            <span class="wqpost_title">{$Tlang['0487fbf42b51d238']}</span>
            <button name="ratesubmit" id="rate_submit" type="submit" value="true" class="wqpublish wqbg_color">{lang confirms}</button>
        </div>
        <div class="mn">
            <div class="bm bw0">
                <div class="wqrate_table">
                    <table cellspacing="0" cellpadding="0" class="dt mbm">
                        <tr>
                            <th width="12%">&nbsp;</th>
                            <th width="41%">&nbsp;</th>
                            <th width="25%" >{lang rate_raterange}</th>
                            <th width="22%">{lang rate_todayleft}</th>
                        </tr>
                        <!--{eval $rateselfflag = 0;}-->
                        <!--{loop $ratelist $id $options}-->
                        <tr>
                            <td class="t_a_l">{$_G['setting']['extcredits'][$id][img]} {$_G['setting']['extcredits'][$id][title]}</td>
                            <td class="t_a_l">
                                <a href="javascript:;" id="score_s$id" class="wqiconfont2 wqicon2-jian jianhao subtract_rate {if $maxratetoday[$id]>0&&$_G['group']['raterange'][$id]['min']<0}light{else}nolight{/if}" index="$id"></a>
                                <em class="wqrate_sz"><input type="number" name="score$id" id="score$id" class="px graded" value="0" data_min="{$_G['group']['raterange'][$id]['min']}" data_max="{$_G['group']['raterange'][$id]['max']}" surplus="$maxratetoday[$id]" index="$id"/></em>
                                <input type="hidden" id="oid$id" value="0"/>
                                <a href="javascript:;" id="score_a$id" class="wqiconfont2 wqicon2-jia jianhao wqm_left5 wqm_right0 add_rate {if $maxratetoday[$id]>0&&$_G['group']['raterange'][$id]['max']>0}light{else}nolight{/if} y" index="$id"></a>
                            </td>
                            <td>{$_G['group']['raterange'][$id]['min']} ~ {$_G['group']['raterange'][$id]['max']}</td>
                            <!--{eval $rateselfflag = $_G['group']['raterange'][$id][isself] ? 1 : $rateselfflag;}-->
                            <td>$maxratetoday[$id]</td>
                        </tr>
                        <!--{/loop}-->
                    </table>
                    <div class="tpclg">
                        <table cellspacing="0" cellpadding="0" class="wqreason_slct">
                            <tr>
                                <td>
                                    <div class="wqrate_sr">
                                         <input type="text" name="reason" id="reasonselect_dummy" class="px" placeholder="{$Tlang['d34623a6783f812b']}"/>

                                        <!--{if !empty($_G['cache']['userreasons'])}-->
                                            <span class="wqrate_kuang"><i class="wqiconfont2 wqicon2-youjiantou-copy"></i>
                                                <select class="wqapp_ratecon">
                                                    <!--{loop $_G['cache']['userreasons'] $key $val}-->
                                                    <option value="{$val}">{$val}</option>
                                                    <!--{/loop}-->
                                                </select>
                                            </span>
                                        <script type="text/javascript" reload="1">
                                            $(function () {
                                                $('.wqapp_ratecon').on('change', function () {
                                                    $('#reasonselect_dummy').val($('.wqapp_ratecon').val())
                                                });
                                            });
                                        </script>
                                        <!--<button type="button" id="reasonselect_buttons" onclick="reasonselect()" class="xl_kuang"><i class="wqiconfont2 wqicon2-youjiantou-copy"></i></button>-->
                                        <!--{/if}-->

                                    </div>
                                </td>
                            </tr>
                        </table>
                    </div>
                    <!--{if $rateselfflag}-->
                    <div class="xg1">{lang admin_rate}</div>
                    <!--{/if}-->
                </div>
                <p class="wqrate_inp">
                    <span class="p_inp">
                        <input type="checkbox" name="sendreasonpm" id="sendreasonpm" class="weui_check"{if $_G['group']['reasonpm'] == 2 || $_G['group']['reasonpm'] == 3} checked="checked" disabled="disabled"{/if} />
                        <label class="weui_check_label" for="sendreasonpm"><i class="weui_icon_checked"></i>{lang admin_pm}</label>
                    </span>
                </p>
            </form>
            <script type="text/javascript" reload="1">
                $('.add_rate').click(function() {
                    var index = $(this).attr('index');
                    var score = $('#score' + index);
                    var value_num = parseInt(score.val());
                    var data_max = parseInt(score.attr('data_max'));
                    var data_min = parseInt(score.attr('data_min'));
                    var surplus = parseInt(score.attr('surplus'));
                    var surplus_num = value_num + 1 < 0 ? -(value_num + 1) : value_num + 1;
                    if (surplus > 0) {
                        if (value_num == 0 && data_min > 0 && surplus >= data_min) {
                            score.val(data_min);
                            $('#oid' + index).val(data_min);
                            setcss(data_min, data_min, data_max, index, surplus);
                        } else if (value_num < data_max && surplus_num <= surplus) {
                            score.val(value_num + 1);
                            $('#oid' + index).val(value_num + 1);
                            setcss(value_num + 1, data_min, data_max, index, surplus);
                        } else if (value_num == data_max && data_max < 0) {
                            score.val(0);
                            $('#oid' + index).val(0);
                            setcss(0, data_min, data_max, index, surplus);
                        }
                    }
                });

                $('.subtract_rate').click(function() {
                    var index = $(this).attr('index');
                    var score = $('#score' + index);
                    var value_num = parseInt(score.val());
                    var data_max = parseInt(score.attr('data_max'));
                    var data_min = parseInt(score.attr('data_min'));
                    var surplus = parseInt(score.attr('surplus'));
                    var surplus_num = value_num - 1 < 0 ? -(value_num - 1) : value_num - 1;
                    if (surplus > 0) {
                        if (value_num == 0 && data_max < 0 && surplus >= (-data_max)) {
                            score.val(data_max);
                            $('#oid' + index).val(data_max);
                            setcss(data_max, data_min, data_max, index, surplus);
                        } else if (value_num > data_min && surplus_num <= surplus) {
                            score.val(value_num - 1);
                            $('#oid' + index).val(value_num - 1);
                            setcss(value_num - 1, data_min, data_max, index, surplus);
                        } else if (value_num == data_min && data_min > 0) {
                            score.val(0);
                            $('#oid' + index).val(0);
                            setcss(0, data_min, data_max, index, surplus);
                        }
                    }
                });

                $('.graded').bind('blur', function() {
                    var index = $(this).attr('index');
                    var text = $(this).val();
                    var value_num = parseInt(text);
                    var data_max = parseInt($(this).attr('data_max'));
                    var data_min = parseInt($(this).attr('data_min'));
                    var surplus = parseInt($(this).attr('surplus'));
                    var surplus_num = value_num > 0 ? -value_num : value_num;
                    if ((!text.match(/^(-)?[0-9]+$/) || value_num < data_min || value_num > data_max || surplus_num > surplus) && (value_num != 0)) {
                        $(this).val($('#oid' + index).val());
                    } else {
                        $('#oid' + index).val(value_num);
                        setcss(value_num, data_min, data_max, index, surplus);
                    }
                });

                function setcss(value_num, data_min, data_max, index, surplus) {
                    if ((value_num > data_min && value_num > -surplus) || value_num > 0) {
                        $('#score_s' + index).removeClass('nolight').addClass("light");
                    } else {
                        $('#score_s' + index).removeClass('light').addClass("nolight");
                    }
                    if ((value_num >= data_max || value_num >= surplus) && value_num >= 0) {
                        $('#score_a' + index).removeClass('light').addClass("nolight");
                    } else {
                        $('#score_a' + index).removeClass('nolight').addClass("light");
                    }
                }

                $('body').on('click','#rate_submit',function() {
                    var obj = $(this);
                    if(obj.attr('disable') == 'true') {
                        return false;
                    }
                    obj.attr('disable', 'true');
                    popup.open(toast);
                    $.ajax({
                        type: 'POST',
                        url: $('#rateform').attr('action') + '&inajax=1',
                        data: $('#rateform').serialize(),
                        dataType: 'html'
                    }).success(function(s) {
                        popup.open(wqXml(s));
                    }).error(function() {
                        popup.open('{lang networkerror}', 'alert');
                    });

                    return false;
                });
                function succeedhandle_(url, msg, param) {
                    if ($.trim(msg) == "{$Tlang['563376474026357f']}") {
                        clearInterval(setTimeout_location);
                        setTimeout(function() {
                            location.reload();
                        }, '1000');
                    }
                }
                function errorhandle_(){
                    $('#rate_submit').attr('disable', 'false');
                }

            </script>
            <!--{/if}-->
        </div>
    </div>
</div>
<!--{/if}-->
<!--{template common/footer}-->
<!--{/if}-->