<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['guide_list_row_m'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{eval include_once template('common/common_module');}-->
<!--{loop $list['threadlist'] $key $thread}-->
<!--{eval $threadicon = get_icon_for_list();}-->
<!--{eval $thread['tid'] = get_tid_isclose_for_guide();}-->
<li class="wqnew_bottom">
    <a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" class="wqblock guidelink">
        <div class="wqlist_maxhidden">
            <h3 class="wqtitle_list">{$threadicon}{$thread[typehtml]}{$thread[sorthtml]}<font $thread[highlight]>{$thread[subject]}</font></h3>
        </div>
        <p class="list_info wqm_top3"><span class="wqwidth80">$thread[author]</span>
            <span class="y"><i class="wqiconfont2 wqicon2-pinglun2 wqapp_f12 wqapp_f13"></i><!--{if $thread['isgroup'] != 1}-->$thread[replies]<!--{else}-->{$groupnames[$thread[tid]][replies]}<!--{/if}--></span>
            <span class="y wqm_right10 width80"><i class="wqiconfont2 wqicon2-p-see wqyulan"></i>$thread[views]</span>
        </p>
    </a>
</li>
<!--{/loop}-->
<!--{/if}-->