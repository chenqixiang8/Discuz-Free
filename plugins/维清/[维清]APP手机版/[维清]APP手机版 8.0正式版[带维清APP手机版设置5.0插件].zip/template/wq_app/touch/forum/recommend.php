<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['recommend'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->

<div class="cl">
	<!--{eval unset($_G['forum']['recommendlist']['images']);}-->
	<ul class="xl{if !$_G['forum']['allowside']} xl2{/if} cl">
	<!--{loop $_G['forum']['recommendlist'] $rtid $recommend}-->
		<li>
			<a class="wqellipsis" href="forum.php?mod=viewthread&tid=$rtid" $recommend[subjectstyles]><span class="wqtop_post_span">{$Tlang['db11cdebc2eb37bd']}</span>$recommend[subject]</a>
		</li>
	<!--{/loop}-->
	</ul>
</div>
<!--{/if}-->