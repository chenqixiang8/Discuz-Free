<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['tag'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{template common/header}-->
<!--{if ($op == 'search')}-->
    <!--{if $taglist}-->
        <!--{loop $taglist $var}-->
            <a href="javascript:;" onclick="if(this.className == 'xi2') { window.onbeforeunload = null; parent.document.getElementById('tags').value += parent.document.getElementById('tags').value == '' ? '$var[tagname]' : ',$var[tagname]'; doane(); this.className += ' marked'; }" class="xi2">$var[tagname]</a>
        <!--{/loop}-->
    <!--{else}-->
        <p class="emp">{lang none_tag}<p>
    <!--{/if}-->
<!--{elseif ($op == 'set')}-->
<!--{elseif ($op == 'manage')}-->
    <div class="c bart wqshield_notice">
        <div class="wqshield_con">
            <p class="wqinput wqnew_all">
                <input type="text" name="tags" id="tags" class="px" value="$tags" size="60" />
                <input type="hidden" name="tid" id="tid" value="$_GET[tid]" />
            </p>

            <!--{if $recent_use_tag}-->
            <div class="mtn wqapp_f14 wqtext_left">{lang recent_use_tag}
                <!--{eval $tagi = 0;}-->
                <!--{loop $recent_use_tag $var}-->
                    <!--{if $tagi}-->, <!--{/if}--><a href="javascript:;" class="xi2" onclick="$('#tags')[0].value == '' ? $('#tags')[0].value += '$var' : $('#tags')[0].value += ',$var';">$var</a>
                    <!--{eval $tagi++;}-->
                <!--{/loop}-->
            </div>
            <!--{/if}-->
        </div>
        <p class="wqbtn_can wqnew_top">
            <a href="javascript:;" onclick="popup.close();" class="wqeject_cancel wqnew_right">{lang cancel}</a>
            <button type="button" name="search_button" class="pn wqdetermine" value="false" onclick="tagset();">{lang submit}</button>
        </p>
    </div>
<!--	<p class="o pns">
            <button type="button" name="search_button" class="pn" value="false" onclick="tagset();"><strong>{lang submit}</strong></button>
            <button type="button" id="closebtn" class="pn" onclick="hideWindow('$_GET[handlekey]');"><strong>{lang close}</strong></button>
	</p>-->
<!--{else}-->
	<h3 class="flb">
            <em>{lang choosetag}</em>
            <!--{if $_G[inajax]}--><span><a href="javascript:;" onclick="hideWindow('$_GET[handlekey]');" class="flbc" title="{lang close}">{lang close}</a></span><!--{/if}-->
	</h3>
	<div class="c bart">
            <div class="pns mbn cl">
                <input type="text" name="searchkey" id="searchkey" class="px vm" value="$searchkey" size="30" />&nbsp;
                <button type="button" name="search_button" class="pn vm" value="false" onclick="tagsearch();"><em>{lang search}</em></button>
            </div>
            <div id="taglistarea" style="width: 400px;"></div>
	</div>
	<p class="o pns">
            <button type="button" class="pn pnc" id="closebtn" onclick="hideWindow('$_GET[handlekey]');"><strong>{lang close}</strong></button>
	</p>
<!--{/if}-->
<script type="text/javascript">
        function tagsearch() {
            $('#taglistarea').innerHTML = '';

            var searchkey = $('#searchkey').val();
            var url = 'forum.php?mod=tag&op=search&inajax=1&searchkey='+searchkey;
            var x = new Ajax();

            x.get(url, function(s){
                if(s) {
                    $('#taglistarea').innerHTML = s;
                }
            });
        }

        function tagset() {
            var tags = $('#tags').val();
            var tid = $('#tid').val();
            var url = 'forum.php?mod=tag&op=set&inajax=1&tags='+tags+'&tid='+tid+'&formhash={FORMHASH}';

            $.ajax({
                type: 'GET',
                url: url + '&inajax=1',
                dataType: 'html'
            }).success(function(s) {
                popup.open('<div class="wqtip"><dt id="messagetext"><p>{$Tlang['5016307776f933e6']}</p></dt></div>');

                setTimeout(function () {
                    window.location.reload();
                },1500);
            }).error(function() {
                window.location.href = obj.attr('href');
                popup.close();
            });
        }
    </script>
<!--{template common/footer}-->
<!--{/if}-->