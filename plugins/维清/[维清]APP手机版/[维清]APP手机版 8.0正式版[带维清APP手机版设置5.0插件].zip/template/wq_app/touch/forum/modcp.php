<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['modcp'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{template common/header}-->
<!--{if $script == 'noperm'}-->
    <div class="bm bw0">
        <h1 class="mt">{lang mod_option_error}</h1>
        <p>{lang mod_error_invalid}</p>
        <p class="notice">{lang mod_notice}</p>
    </div>
<!--{elseif !empty($modtpl)}-->
	<!--{if in_array($script, array('member', 'login'))}-->
    	<!--{eval include(template($modtpl));}-->
    <!--{else}-->
    	<div class="box ban pbn">
    		{lang admin_threadtopicadmin_error}
        </div>
    <!--{/if}-->
<!--{/if}-->

<!--{template common/footer}-->

<!--{/if}-->