<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['collection_followers'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{template common/header}-->
<!--{eval $headright=false;}-->
    <!--{if helper_access::check_module('collection')}-->
        <!--{eval $headright=true;}-->
    <!--{/if}-->

    <!--{eval
        $headparams['wtype'] = '1';
        $headparams['ltype'] = 'a';
        $headparams['lurl'] = $backurl;
        $headparams['cname'] = $Tlang['5d6bc314174ee1c8'];
        $headparams['rtype'] = 'a';
        $headparams['rclass'] = 'wqapp_f16';

        $headparams['rtype'] = 'a';
        $headparams['rname'] = $Tlang['984c5e7090423fd1'];
        $headparams['rurl'] = 'forum.php?mod=collection&action=edit';
        $headparams['rclass'] = '';

        echo wq_app_get_header($headparams,true,$headright);
    }-->

<script type="text/javascript" src="{$_G[setting][jspath]}home_friendselector.js?{VERHASH}"></script>
<script type="text/javascript">
	var fs;
	var clearlist = 0;
</script>

<div id="ct" class="wq_collection_comment">
	<div class="wq_comment_warp">

		<div class="wq_view_info">
                    <ul>
                        <li class="wq_title">
				<a href="forum.php?mod=collection&action=view&ctid={$_G['collection']['ctid']}">{$_G['collection']['name']}</a>
			</li>
                        <li>
                            <div title="$avgrate" class="wq_stars">
			<!--{if $_G['collection']['ratenum'] > 0}-->
				<span class="clct_ratestar z"><span class="star star$star">&nbsp;</span></span>
                                <em class="wq_grey" style=" margin-left: 10px; line-height: 7px;vertical-align: text-top;">{lang collection_totalrates}</em>
			<!--{else}-->
				{lang collection_norate}
			<!--{/if}-->
			</div>
                        </li>
                        <li><div class="wq_grey">{$_G['collection']['desc']}</div></li>
                    </ul>
		</div>
	</div>
	<div class="wqseparate2"></div>
	<div class="bm">
		<div class="wq_amoy_paste">
                    <div class="tag_list">
			<ul>
				<li><a href="forum.php?mod=collection&action=view&op=comment&ctid={$_G['collection']['ctid']}">{lang collection_commentlist}</a></li>
				<li class="a"><a href="forum.php?mod=collection&action=view&op=followers&ctid={$_G['collection']['ctid']}">{lang collection_followlist}</a></li>
			</ul>
                        </div>
		</div>
		<!--{if $followers}-->
			<div class="bm_c">
				<ul class="ml mls cl">
				<!--{loop $followers $follower}-->
					<li>
						<a href="home.php?mod=space&uid=$follower[uid]" class="avt"><!--{avatar($follower[uid],small)}--></a>
						<p><a href="home.php?mod=space&uid=$follower[uid]">$follower[username]</a></p>
					</li>
				<!--{/loop}-->
				</ul>
			</div>
		<!--{else}-->
			<p class="wqemp"><span class="wqno_con"><img src="{$_G['style']['styleimgdir']}images/wqno_con.png"></span>{lang no_content}</p>
		<!--{/if}-->
		<!--{if $multipage}--><div class="bm_c cl">$multipage</div><!--{/if}-->
	</div>
</div>
<!--{template common/footer}-->
<!--{/if}-->