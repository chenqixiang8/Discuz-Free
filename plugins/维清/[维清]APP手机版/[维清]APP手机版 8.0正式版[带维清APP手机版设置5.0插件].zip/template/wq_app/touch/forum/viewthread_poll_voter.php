<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['viewthread_poll_voter'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{template common/header}-->
    <!--{eval
        $headparams['wtype'] = '1';
        $headparams['lurl'] = $backurl;
        $headparams['ltype'] = 'a';
        $headparams['cname'] = "{lang poll_voters}";
        echo wq_app_get_header($headparams);
    }-->
    <div class="c voterlist wqview_poll_voterlist">
            <p>
                    <select class="ps" onchange="{if !empty($_GET['inajax'])}showWindow('viewvote', 'forum.php?mod=misc&action=viewvote&tid=$_G[tid]&polloptionid=' + this.value){else}location.href = 'forum.php?mod=misc&action=viewvote&tid=$_G[tid]&polloptionid=' + this.value;{/if}">
                    <!--{loop $polloptions $options}-->
                            <option value="$options[polloptionid]"{if $options[polloptionid] == $polloptionid} selected="selected"{/if}>$options[polloption]</option>
                    <!--{/loop}-->
                    </select>
            </p>
            <ul class="ml voterl wqview_poll_per">
            <!--{if !$voterlist}-->
                    <li>{lang none}</li>
            <!--{else}-->
                    <!--{loop $voterlist $voter}-->
                    <li><a href="home.php?mod=space&do=profile&uid=$voter[uid]"><img src="{avatar($voter[uid], small, true)}"/><br/><span>$voter[username]</span></a></li>
                    <!--{/loop}-->
            <!--{/if}-->
            </ul>
    </div>
    <div class="c cl mbn">$multipage</div>
<!--{eval $nofooter=1;}-->
<!--{template common/footer}-->
<!--{/if}-->