<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['forumlist_1'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{eval $catlist = wq_app_get_forum_in_group();}-->
<!--{eval $myfav = get_my_favfids_by_uid();}-->
<!--{eval $_forums_info = C::t('forum_forum')->fetch_all_info_by_fids($catlist[$val['fid']][forums]);}-->

<div class="list_right abs forum_{$val['fid']} forum_list_fight" id="list_right_list" style="display: none;">
    <ul class="wqfollow_list_ul wqp_left10 wqp_right10">
        <!--{loop $catlist[$val['fid']][forums] $key $val}-->
            <li class="wqnew_bottom">
                <!--{if $op && $op == "post"}-->
                    <a href="forum.php?mod=post&action=newthread&fid={$_forums_info[$val]['fid']}">
                <!--{else}-->
                    <a href="forum.php?mod=forumdisplay&fid={$_forums_info[$val]['fid']}">
                <!--{/if}-->
                    <div class="wqfollow_list_img">
                        <!--{if $_forums_info[$val][icon]}-->
                            <!--{eval $iconurl= wq_app_setting_is_picurl($_forums_info[$val][icon])?$_forums_info[$val][icon]:$_G['setting']['attachurl'].'common/'.$_forums_info[$val][icon];}-->
                            <img src="{$iconurl}" alt="{$_forums_info[$val][name]}" />
                        <!--{else}-->
                             <img src="{$_G['style'][styleimgdir]}images/forum{if $_forums_info[$val][folder]}_new{/if}.gif" alt="{$_forums_info[$val][name]}" />
                        <!--{/if}-->
                    </div>
                    <div class="wqtitle"><span class="wqname wqellipsis<!--{if $op == "fav"}--> wqwidth100<!--{/if}-->">{$_forums_info[$val][name]}</span></div>
                    <div class="wqdesc wqellipsis<!--{if $op == "fav"}--> wqwidth50<!--{/if}-->">
                        <span class="wqm_right10">{$_forums_info[$val]['threads']}{$Tlang['3dc487520005b6c7']}</span><span id="fav_wqm_right_{$_forums_info[$val][fid]}">{$_forums_info[$val]['favtimes']}{$Tlang['914d2c5341afe66f']}</span>
                    </div>
                </a>
                <!--{if ($op && $op == "fav") || ($_GET['forumlist']==1 && $wq_app_setting['is_discuz_myfav'])}-->
                <!--{if !in_array($_forums_info[$val][fid],$myfav)}-->
                    <div  class="wqcancel_follow wqbg_color">
                        <a href="javascript:;" data-href="home.php?mod=spacecp&ac=favorite&type=forum&id=$_forums_info[$val][fid]" id="fav_wqwhite_{$_forums_info[$val][fid]}" class="wqwhite <!--{if $_G[uid]}-->wqfav-button<!--{/if}--> notlogged
" data="{$_forums_info[$val][fid]}">{$Tlang['2c8a07313e7706bc']}</a>
                    </div>
                <!--{else}-->
                    <div  class="wqcancel_follow wqborder ">
                        <a href="javascript:;" class="wqcolor wqfav-button" id="fav_wqcolor_{$_forums_info[$val][fid]}" data="{$_forums_info[$val][fid]}">{$Tlang['914d2c5341afe66f']}</a>
                    </div>
                <!--{/if}-->
                <!--{/if}-->
            </li>
        <!--{/loop}-->
    </ul>
</div>
<!--{/if}-->