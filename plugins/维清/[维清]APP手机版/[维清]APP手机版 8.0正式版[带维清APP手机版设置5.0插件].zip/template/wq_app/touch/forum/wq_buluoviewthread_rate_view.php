<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['wq_buluoviewthread_rate_view'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{template common/header}-->
<div id="ct" class="wp cl p_b32">
	<div class="o pns rate_total">
		<ul>
			<!--{eval $count = count($logcount); $add = $count % 2 != 0 ? 1 : 0}-->
			<!--{loop $logcount $id $count}-->
			<li class="b_bottom">{$_G['setting']['extcredits'][$id][title]} {$count}</li>
			<!--{/loop}-->
			<!--{if $add}-->
			<li class="b_bottom">&nbsp;</li>
			<!--{/if}-->
		</ul>
	</div>

	<div class="floatwrap">

		<!--{loop $loglist $k $log}-->
		<!--{eval $log[score]=str_replace('+', '', $log[score]);}-->
		<div class="b_bottom rate_tit <!--{if ($k)%2!=0}-->bg_tit<!--{/if}-->">
			<ul>
				<li><a href="home.php?mod=space&uid=$log[uid]">$log[username]</a></li>
				<li>{$_G['setting']['extcredits'][$log[extcredits]][title]}{$log[score]}</li>
				<li>$log[dateline]</li>
			</ul>
			<!--{if $log[reason]}-->
			<p class="rate_reason">$log[reason]</p>
			<!--{/if}-->
		</div>
		<!--{/loop}-->
	</div>
	<!--{template common/footer}-->
<!--{/if}-->