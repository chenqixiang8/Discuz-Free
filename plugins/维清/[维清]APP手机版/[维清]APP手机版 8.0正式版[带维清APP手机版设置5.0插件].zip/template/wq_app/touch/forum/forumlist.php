<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['forumlist'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{eval loadcache('forums');}-->
<!--{eval $forumlist = $_G['cache']['forums'];}-->
<!--{eval $catlist = wq_app_get_forum_in_group();}-->
<!--{eval $op = wq_app_get_op_value();}-->
<div class="scrollBorder" style="height: 0;"></div>
<div class="wqlist_warp">
    <div class="list_right abs" id="wqlist_right">
        <div id="new_right">
            <!--{loop $catlist $key $val}-->
                <!--{if $_GET['gid'] && $_GET['gid'] != $val['fid']}-->
                <!--{eval continue;}-->
                <!--{/if}-->
                <!--{template forum/forumlist_1}-->
            <!--{/loop}-->
        </div>
    </div>
    <div id="main-window" class="list_left" >
        <div id="wqlist_left" class="list_li">
            <ul id="department-list">
                <!--{loop $catlist $key $val}-->
                    <!--{if $_GET['gid'] && $_GET['gid'] != $val['fid']}-->
                        <!--{eval continue;}-->
                    <!--{/if}-->
                    <li class=""><a href="javascript:;" data="$val[fid]" {if $_GET['gid']}data-gid="{$_GET['gid']}"{/if}>$val['name']</a></li>
                <!--{/loop}-->
            </ul>
        </div>
    </div>
</div>
<script type="text/javascript">
    var formhash="{FORMHASH}",showstyle="$wq_app_setting[discuz_style]", fontlength="$wq_app_setting[forumlist_left_width]";
</script>
<script type="text/javascript" src="{$_G['style']['styleimgdir']}js/forum/forumlist.js?{VERHASH}"></script>
<!--{if ($_GET['ac'] && $_GET['ac'] == "myfav")|| ($_GET['forumlist']==1 && $wq_app_setting['is_discuz_myfav'])}-->
<script type="text/javascript">
    var Cancel_success="{$Tlang['bef022f6310db3b9']}",formhash = "{FORMHASH}",info_success = "{$Tlang['fffeda57b2002266']}", _favtimes = "{$Tlang['2c8a07313e7706bc']}", favtimes = "{$Tlang['914d2c5341afe66f']}";
    function succeedhandle_favbtn(url, msg, param) {
        if ($.trim(msg) == info_success) {
            $("#fav_wqwhite_" + param.id).html(favtimes);
            $("#fav_wqwhite_" + param.id).parent().toggleClass('wqbg_color wqborder');
            $("#fav_wqwhite_" + param.id).attr('data-href', '').prop('id', 'fav_wqcolor_' + param.id).addClass('wqcolor').removeClass('wqwhite');
            $.ajax({
                type: 'GET',
                url: 'forum.php?mod=misc',
                data: {action: 'nav', ac: 'selfav', fid: param.id, formhash: formhash},
                dataType: 'json',
                success: function (s) {
                    $("#fav_wqm_right_" + param.id).html(s.favtimes + favtimes);
                }
            });
            wq_setTimeout();
        }
    }
    function cancel_callback(fid) {
        popup.open('<div class=\"wqtip\"><p>' + Cancel_success + '</p></div>');
        $("#fav_wqcolor_" + fid).html(_favtimes);
        $("#fav_wqcolor_" + fid).parent().toggleClass('wqbg_color wqborder');
        $("#fav_wqcolor_" + fid).attr('data-href', 'home.php?mod=spacecp&ac=favorite&type=forum&id=' + fid).prop('id', 'fav_wqwhite_' + fid).addClass('wqwhite').removeClass('wqcolor');
        typeof get_favtimes != 'undefined' && get_favtimes(fid);
        wq_setTimeout();
    }
    $("body").on("click", "#new_right li > a, .wqfooter a", function (event) {
        var href = $(this).attr("href");
        if ($(this).children().hasClass("wqicon2-fabu", "wqapp_f18")) {
            sessionStorage.setItem("key", location.href);
        }
        if ($(this).parent().parent().attr("id") != "department-list") {
            location.href = href;
        }
    });
</script>
<script type="text/javascript" src="{$_G['style']['styleimgdir']}js/public/favtimes.js?{VERHASH}"></script>
<!--{/if}-->



<!--{/if}-->