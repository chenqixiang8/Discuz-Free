<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['comment'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{template common/header}-->
<!--{if empty($_GET['infloat'])}-->
<div id="ct" class="wp cl">
	<div class="mn">
		<div class="bm bw0">
<!--{/if}-->
<div class="wqshield_notice">
<form method="post" autocomplete="off" id="commentform" action="forum.php?mod=post&action=reply&comment=yes&tid=$post[tid]&pid=$_GET[pid]&extra=$extra{if !empty($_GET[page])}&page=$_GET[page]{/if}&commentsubmit=yes&infloat=yes" onsubmit="{if !empty($_GET['infloat'])}ajaxpost('commentform', 'return_$_GET['handlekey']', 'return_$_GET['handlekey']', 'onerror');return false;{/if}">
	<div class="wqshield_con">
		<input type="hidden" name="formhash" id="formhash" value="{FORMHASH}" />
		<input type="hidden" name="handlekey" value="$_GET['handlekey']" />
			<div class="tedt">
				<div class="wq_textarea">
                                    <textarea rows="2" cols="50" name="message" class="wqtextarea" id="commentmessage" style="overflow: auto" placeholder="{$Tlang['c147badb3615b986']}"></textarea>
				</div>
				<script type="text/javascript" reload="1">
				<!--{if $commentitem}-->
					var items = itemrow = itemcmm = '';
					<!--{eval $items = range(0, 5);$itemlang = array('{lang comment_1}', '{lang comment_2}', '{lang comment_3}', '{lang comment_4}', '{lang comment_5}', '{lang comment_6}');$i = $cmm = 0;}-->
					<!--{loop $commentitem $item}-->
						<!--{eval $item = trim($item);}-->
						<!--{if $item}-->
							items += '<input type="hidden" id="itemc_$i" name="commentitem[$item]" value="" />';
							itemrow = '<span id="itemt_$i" class="z xg1 cur1" title="{lang comment_give_ip}" onclick="itemdisable($i)">&nbsp;$item</span>';
							itemstar = '';
							<!--{loop $items $j}-->
							itemstar += '<em onclick="itemclk($i, $j)" onmouseover="itemop($i, $j)" onmouseout="itemset($i)" title="$itemlang[$j]($j)"{if !$j} style="width: 10px;"{/if}>$itemlang[$j]</em>';
							<!--{/loop}-->
							itemrow += '<span id="item_$i" class="z cmstar">' + itemstar + '</span>';
							<!--{eval $i++;}-->
							<!--{if !$cmm}-->items += itemrow;<!--{else}-->itemcmm += '<div class="cl cmm" style="margin:5px">' + itemrow + '</div>';<!--{/if}-->
						<!--{elseif !$cmm}-->
							items += '<span class="z" id="itemmore" onmouseover="showMenu({\'ctrlid\':this.id,\'pos\':\'13\'})">&nbsp;&raquo; {lang more}</span>';
							<!--{eval $cmm = 1;}-->
						<!--{/if}-->
					<!--{/loop}-->
					$('itemdiv').innerHTML = items;
					if(itemcmm) {
						cmmdiv = document.createElement('div');
						cmmdiv.id = 'itemmore_menu';
						cmmdiv.style.display = 'none';
						cmmdiv.className = 'p_pop';
						cmmdiv.innerHTML = itemcmm;
						$('append_parent').appendChild(cmmdiv);
					}
				<!--{/if}-->
				$('commentmessage').focus();
				</script>
			</div>
	</div>
        <p class="wqbtn_can wqnew_top">
            <a href="javascript:;" onclick="popup.close();" class="wqeject_cancel wqnew_right">{$Tlang['9c825be7149e5b97']}</a>
            <button type="submit" id="commentsubmit" class="pn pnc formdialog wqdetermine" value="true" name="commentsubmit" tabindex="3"><span>{lang publish}</span></button>
        </p>


</form>
</div>
<!--{if empty($_GET['infloat'])}-->
		</div>
	</div>
</div>
<!--{/if}-->
<!--{template common/footer}-->
<!--{/if}-->