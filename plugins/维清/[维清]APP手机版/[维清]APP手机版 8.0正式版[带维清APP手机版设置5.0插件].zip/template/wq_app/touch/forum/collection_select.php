<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['collection_select'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{template common/header}-->
<div class="wqshield_notice">

    <script>
        var remaincreateable = $reamincreatenum;
        var titlelimit = '{$titlelimit}';
        var requirecreate = false;
        var createnow = false;
        var reasonlimit = '{$reasonlimit}';
        function succeedhandle_createcollection(url, msg, collectiondata) {
            clearInterval(setTimeout_location);
            $("#createbutton").attr('disabled',false);
                if(collectiondata['ctid']) {
                    $("#selectCollection").append($("<option>").text($("#newcollection").val()).val(collectiondata['ctid']).attr('selected', true));
                    $("#collectionlist").show();
                    remaincreateable--;
                    if(remaincreateable <= 0) {
                        $("#allowcreate").hide();
                    } else {
                        $("#reamincreatenum").html(remaincreateable);
                    }
                    _wq_display('#createcollection');
                    $("#submitnewtitle").val(''); $("#newcollection").val('');
                }
                $("#nocreate").html('');
                if(requirecreate == true) {
                    $("#createRemainTips").show();
                    $("#createbutton").show;
                    $("#wqnewcollection").css('width','60%');
                    requirecreate = false;
                    if(createnow == true) {
                        $('#btn_submitaddthread').click();
                    }
                    createnow = false;
                }
        }
        function ajaxcreatecollection() {
            if(!$("#newcollection").val()) {
                popup.open('<div class=\"wqtip\"><p>' + {lang collection_fill_entire} + '</p></div>');
                return false;
            }

            if(mb_strlen($("#newcollection").val()) > titlelimit) {
                popup.open('<div class=\"wqtip\"><p>' + {lang collection_title_exceed} + '</p></div>');
                return false;
            }
            $("#createbutton").attr('disabled',true);
            $("#submitnewtitle").val($("#newcollection").val());
            $('#btn_submitcollection').click();
        }
        function checkreasonlen() {
            if(mb_strlen($("#formreason").val()) > reasonlimit) {
                popup.open('<div class=\"wqtip\"><p>' + {lang collection_reason_exceed} + '</p></div>');
                return false;
            }
            if(requirecreate == true) {
                createnow = true;
                ajaxcreatecollection();
                return false;
            } else {
                $("#createRemainTips").show();
                $("#createbutton").show();
                $("#wqnewcollection").css('width','60%');
                $('#form_addcollectionthread').click();
                return false;
            }

        }

        function _wq_display(id) {
            var obj = $(id);
            obj.is(':visible') ? obj.hide() : obj.show();
        }

        function succeedhandle_k_collect(){
            clearInterval(setTimeout_location);
            update_collection();
            setTimeout(function() {
		popup.close();
            }, '2000');
        }

        function update_collection(){
            var obj = $('#collectionnumber');
            if(obj.length > 0){
                sum = 1;
                obj.html(parseInt(obj.html())+sum);
                obj.show();
            }
        }
    </script>

    <form action="forum.php?mod=collection&action=edit&op=addthread" method="post" name="form_addcollectionthread">
        <div class="wqshield_con">
            <div id="collectionlist" {if $reamincreatenum > 0 && count($allowcollections) <= 0}style="display:none;"{/if}>
                <p>{lang collection_select}</p>
                <p class="wqshield_con_border">
                    <select name="ctid" id="selectCollection" class="wqselect">
                    <!--{loop $collections $collection}-->
                        <!--{if !in_array($collection['ctid'], $tidcollections)}-->
                            <option value="$collection['ctid']">$collection['name']</option>
                        <!--{/if}-->
                    <!--{/loop}-->
                    </select>
                </p>
            </div>
            <div id="allowcreate" {if $reamincreatenum <= 0}style="display:none;"{/if}>
                    <span id="nocreate"><!--{if !$collections}-->{lang collection_select_nocollection}<!--{/if}--></span>
                    <div class="wqm_top10 wq_found_tie">{lang collection_select_remain} <a href="javascript:;" onclick="_wq_display('#createcollection');;if($('#createcollection').is(':visible')) {$('#newcollection').focus();}" class="xi2" id="createRemainTips">{lang collection_create}</a></div>
            </div>
            <div id="createcollection" class="wqapp_createcollection ptm vm wqm_top10" style="display:none">
                <span class="wqinput" id="wqnewcollection" style="width:60%;">
                    <input type="text" value="" id="newcollection" placeholder="{lang collection_title}" style="width:100%; padding:0; text-indent: 4px;"/>
                </span>
                <button type="button" id="createbutton" name="createbutton" onclick="javascript:ajaxcreatecollection();" class="button2" style="width:80px; font-size: 14px;">
                    <span>{lang collection_create}</span>
                </button>
            </div>
            <p class="wqshield_con_border wqm_top10">
                <textarea name="reason" id="formreason" cols="50" rows="2" class="wqselect" placeholder="{lang collection_addreason}"></textarea>
            </p>
        </div>
        <p class="wqbtn_can wqnew_top">
            <!--{if $tid}-->
                <input type="hidden" name="tids[]" value="$tid">
            <!--{elseif is_array($_GET['tids'])}-->
                <!--{loop $_GET['tids'] $tid}-->
                    <input type="hidden" name="tids[]" value="$tid">
                <!--{/if}-->
            <!--{/if}-->
            <input type="hidden" name="inajax" value="1">
            <input type="hidden" name="handlekey" value="k_collect">
            <input type="hidden" name="formhash" id="formhash" value="{FORMHASH}" />
            <input type="hidden" name="addthread" id="addthread" value="1" />
            <button type="submit" name="submitaddthread" id="form_addcollectionthread" class="none formdialog" value="{$Tlang['387e9a577ee04ca3']}"><span>{$Tlang['387e9a577ee04ca3']}</span></button>
            <a href="javascript:;" onclick="popup.close();" class="wqeject_cancel wqnew_right">{$Tlang['9c825be7149e5b97']}</a>
            <button type="submit" name="submitaddthread" id="btn_submitaddthread" class="pn pnc wqdetermine" onclick="return checkreasonlen();" value="{$Tlang['387e9a577ee04ca3']}">
                <span>{$Tlang['387e9a577ee04ca3']}</span>
            </button>
        </p>
    </form>

    <div style="display:none;">
        <form action="forum.php?mod=collection&action=edit&op=add" method="post" id="fastcreateform">
            <input type="hidden" name="formhash" id="formhash" value="{FORMHASH}" />
            <input type="hidden" name="collectionsubmit" value="1" />
            <input type="hidden" name="submitcollection" value="1" />
            <input type="hidden" name="title" id="submitnewtitle" value="" />
            <button type="submit" id="btn_submitcollection" class="pn pnc wqdetermine">{$Tlang['387e9a577ee04ca3']}</button>
        </form>
    </div>
    <span id="fastcreatereturn"></span>
    <!--{if $reamincreatenum > 0 && count($allowcollections) <= 0}-->
        <script>
            var random = <!--{echo TIMESTAMP}-->;
            requirecreate = true;
            $("#createRemainTips").css('display','none');
            $("#createbutton").css('display','none');
            $("#newcollection").css('width','100%');
            $("#wqnewcollection").css('width','100%');
            _wq_display('#createcollection');
        </script>
    <!--{/if}-->
    <script>
        $(function(){
            $(document).on('click', '#btn_submitcollection', function () {
            var obj = $(this);
            var formobj = $(this.form);
            $.ajax({
                type: 'POST',
                url: formobj.attr('action') + '&handlekey=' + formobj.attr('id') + '&inajax=1',
                data: formobj.serialize(),
                dataType: 'html'
            }).success(function (s) {
                var wq = wqXml(s);
                localStorage.removeItem("temreplymessage");
                evalscript(wq);
            }).error(function () {
                window.location.href = 'forum.php';
                popup.close();
            });
            return false;
        });
        })
    </script>
</div>
<!--{template common/footer}-->
<!--{/if}-->