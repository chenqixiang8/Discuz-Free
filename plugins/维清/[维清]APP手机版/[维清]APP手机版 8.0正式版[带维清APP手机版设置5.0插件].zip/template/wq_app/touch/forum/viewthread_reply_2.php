<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['viewthread_reply_2'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{loop $postlist $post}-->
<!--{if $post[first]}-->
<!--{eval continue;}-->
<!--{/if}-->
<!--{eval
    $mycenter=$_G['uid']==$post[uid]?"&mycenter=1":"";
    $wq_userurl=$wq_forumuser_url.$post[authorid].$mycenter;
    $post[dateline]= wq_app_dgmdate($post[dateline]);
}-->
<!--{hook/viewthread_posttop_mobile $postcount}-->
<div class="plc cl wqpost_view wqyes_reply pid$post[pid]" id="pid$post[pid]">
    <ul>
        <li>
            <div class="wqpost_view_info_div wqp_bottom2">
                <a href="{if $post['authorid'] && $post['username'] &&($_G['forum']['ismoderator']||!$post['anonymous'])}{$wq_userurl}{else}javascript:;{/if}"style="display: initial">
                    <img class="wqhead" src="<!--{if !$post['authorid'] || $post['anonymous']}--><!--{avatar(0, small, true)}--><!--{else}--><!--{avatar($post[authorid], small, true)}--><!--{/if}-->"/></a>
                <div class="wqpost_view_info" href="#replybtn_$post[pid]">
                    <h2 class="wqapp_f16">
                        <a href="{if $post['authorid'] && $post['username'] &&($_G['forum']['ismoderator']||!$post['anonymous'])}{$wq_userurl}{else}javascript:;{/if}" class="width100 wqapp_f16">
                            <!--{if $post['authorid'] && $post['username'] && !$post['anonymous']}-->
                            $post[author]
                            <!--{else}-->
                            <!--{if !$post['authorid']}-->
                            {lang guest} <em>$post[useip]{if $post[port]}:$post[port]{/if}</em>
                            <!--{elseif $post['authorid'] && $post['username'] && $post['anonymous']}-->
                            <!--{if $_G['forum']['ismoderator']}-->{lang anonymous}<!--{else}-->{lang anonymous}<!--{/if}-->
                            <!--{else}-->
                            $post[author] <em>{lang member_deleted}</em>
                            <!--{/if}-->
                            <!--{/if}-->
                        </a>
                            <!--{if !$post['first'] && $post['rewardfloor']}-->
                            <span class='wqm_left3'>
                                <label class="pdbts pdbts_1 wqpdbts wqpdbts2">{lang prosit}{lang rushreply_hit}</label>
                            </span>
			<!--{/if}-->
                         <!--{if $_G['forum']['ismoderator']}-->
                            <span class="y new_div" style="line-height: 24px;">
                                <a href="#moptions_$post[pid]" onclick="return false" class="wq_grey wqm_left10 new_button">
                                    <i class="wqiconfont2 wqicon2-gengduo1 wqapp_f20"></i>
                                </a>
                            </span>
                            <div id="moptions_{$post[pid]}" name="moptions_$post[pid]" popup="true" class="wqadmin_eject wqbolg_js2 new_menu" style="display:none;">
                                <span class="wqadmin_eject_arrow"></span>
                                <ul>
                                    <li id="reply_edit"><button type="button" class="redirect button" href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page"><i class="wqiconfont2 wqicon2-xindenew85 wqapp_f18"></i>{lang edit}</button></li>
                                    <li><!--{if $_G['group']['allowdelpost']}--><button type="button" class="dialog button" href="forum.php?mod=topicadmin&action=delpost&fid={$_G[fid]}&tid={$_G[tid]}&operation=&optgroup=&page=&topiclist[]={$post[pid]}"><i class="wqiconfont2 wqicon2-gbdelete wqapp_f20"></i>{$Tlang['0d9efacf5089d88c']}</button><!--{/if}--></li>
                                    <li><!--{if $_G['group']['allowbanpost']}--><button type="button" class="dialog button" href="forum.php?mod=topicadmin&action=banpost&fid={$_G[fid]}&tid={$_G[tid]}&operation=&optgroup=&page=&topiclist[]={$post[pid]}"><i class="wqiconfont2 wqicon2-comiispingbi1 wqapp_f20"></i>{$Tlang['5b1cbfcad581bfea']}</button><!--{/if}--></li>
                                    <li><!--{if $_G['group']['allowwarnpost']}--><button type="button" class="dialog button" href="forum.php?mod=topicadmin&action=warn&fid={$_G[fid]}&tid={$_G[tid]}&operation=&optgroup=&page=&topiclist[]={$post[pid]}"><i class="wqiconfont2 wqicon2-jinggao wqapp_f20"></i>{$Tlang['a8d4b15dd720dbfc']}</button><!--{/if}--></li>
                                    <!--<li>{if $_G['group']['allowstickreply']}<button type="button" class="dialog button" href="forum.php?mod=topicadmin&action=stickreply&fid={$_G[fid]}&tid={$_G[tid]}&operation=&optgroup=&page=&topiclist[]={$post[pid]}"><i class="wqiconfont2 wqicon2-zhiding wqapp_f20"></i>{$Tlang['01ff72df2ca84800']}</button>{/if}</li>-->
                                </ul>
                            </div>
                        <!--{else}-->
                            <!--{if (($_G['forum']['ismoderator'] && $_G['group']['alloweditpost'] && (!in_array($post['adminid'], array(1, 2, 3)) || $_G['adminid'] <= $post['adminid'])) || ($_G['forum']['alloweditpost'] && $_G['uid'] && ($post['authorid'] == $_G['uid'] && $_G['forum_thread']['closed'] == 0) && !(!$alloweditpost_status && $edittimelimit && TIMESTAMP - $post['dbdateline'] > $edittimelimit))) && !$_G['forum_thread']['special']}-->
                            <span class="y wqapp_f14 wq_grey wqm_left20"><a href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page"><i class="wqiconfont2 wqicon2-xindenew85  wqapp_f14"></i></a></span>
                            <!--{/if}-->
                         <!--{/if}-->

                         <span class="y wqapp_f14 wq_grey wqm_left20">

                             <!--{if !$_G['forum_thread']['special'] && !$rushreply && !$hiddenreplies && $_G['setting']['repliesrank'] && !($post['isWater'] && $_G['setting']['filterednovote'])}-->
                       <a href="forum.php?mod=misc&action=postreview&do=support&tid=$_G[tid]&pid=$post[pid]" class="wq_grey support_forum" data="$post[pid]"><i class="wqiconfont2 wqicon2-gzan wqm_right3 wqapp_f14 notlogged"></i><i id="review_support_$post[pid]">$post[postreview][support]</i></a>
                            <!--{/if}-->

                        </span>

                                 <!--{if ($_G['group']['raterange'] && $post['authorid'])||($_GET['from'] != 'preview' && !empty($post['ratelog']))}-->
                    <!--{if $_GET['from'] != 'preview' && !empty($post['ratelog'])}-->
                    <!--{eval $ajax_action="viewratings";$rate_class="rate_viewratings"}-->
                    <!--{else}-->
                    <!--{eval $ajax_action="rate";$rate_class="grades";}-->
                    <!--{/if}-->
                            <span class="y">
                                 <a url="forum.php?mod=misc&action=$ajax_action&tid=$_G[tid]&pid=$post[pid]" href="javascript:;"  class="wq_grey support {$rate_class}" {if $_G['group']['raterange'] && $post['authorid']}pid="$post[pid]"{/if}>
                                    <i class="wqiconfont2 wqicon2-dianping wqapp_f14 wqm_right3"></i>
                                    <!--{if count($postlist[$post[pid]][totalrate])>0}-->
                                    <!--{echo count($postlist[$post[pid]][totalrate]);}-->
                                    <!--{/if}-->
                                </a>
                            </span>
                     <!--{/if}-->
                      <!--{if $post['invisible'] == 0}-->
                            <span class="y wqp_right15">
                                    <!--{if $allowpostreply && $post['allowcomment'] && (!$thread['closed'] || $_G['forum']['ismoderator'])}-->
                                    <a class="dialog" href="forum.php?mod=misc&action=comment&tid=$post[tid]&pid=$post[pid]&extra=$_GET[extra]&page=$page{if $_G['forum_thread']['special'] == 127}&special=$specialextra{/if}" ><i class="wqiconfont2 wqicon2-icon-test1 wqapp_f14 wqm_right3"></i></a>
                                    <!--{/if}-->
                                </span>
                             <!--{/if}-->
                    </h2>
                     <!--{if $_G['forum_thread']['special'] == 3 && ($_G['forum']['ismoderator'] && (!$_G['setting']['rewardexpiration'] || $_G['setting']['rewardexpiration'] > 0 && ($_G[timestamp] - $_G['forum_thread']['dateline']) / 86400 > $_G['setting']['rewardexpiration']) || $_G['forum_thread']['authorid'] == $_G['uid']) && $post['authorid'] != $_G['forum_thread']['authorid'] && $_G['uid'] != $post['authorid'] && $_G['forum_thread']['price'] > 0}-->
                    <p class="wqapp_f14">
                        <a href="forum.php?mod=misc&action=bestanswer&tid={$post['tid']}&pid={$post['pid']}" class="bestanswer wqred">{$Tlang['0d1b1e2e37a34574']}</a>
                    </p>
                    <script>
                        $('.bestanswer').on('click', function() {
                            var obj = $(this);
                            $.ajax({
                                type: 'POST',
                                url: obj.attr('href') + '&inajax=1',
                                data: {
                                    'formhash': '{FORMHASH}',
                                    'listextra': '{$_GET[extra]}',
                                    'page': '{$_GET[page]}',
                                    'bestanswersubmit': 'yes',
                                    'from': '{$_GET[from]}'
                                },
                                dataType: 'html'
                            }).success(function(s) {
                                popup.open(wqXml(s));
                            }).error(function() {
                                window.location.href = obj.attr('href');
                                popup.close();
                            });
                            return false;
                        });
                    </script>
                    <!--{/if}-->
                    <!------- /if-->
                    <div class="message">
                        <!--{eval //$post[message] = str_replace('smilieid="','class="wq_smilieimg" smilieid="',$post[message]);}-->
                        <!--{if $post[first]}-->
                        <h2>
                            <!--{if $_G['forum_thread']['typeid'] && $_G['forum']['threadtypes']['types'][$_G['forum_thread']['typeid']]}-->
                            [{$_G['forum']['threadtypes']['types'][$_G['forum_thread']['typeid']]}]
                            <!--{/if}-->
                            <!--{if $threadsorts && $_G['forum_thread']['sortid']}-->
                            [{$_G['forum']['threadsorts']['types'][$_G['forum_thread']['sortid']]}]
                            <!--{/if}-->
                            $_G[forum_thread][subject]
                            <!--{if $_G['forum_thread'][displayorder] == -2}--> <span>({lang moderating})</span>
                            <!--{elseif $_G['forum_thread'][displayorder] == -3}--> <span>({lang have_ignored})</span>
                            <!--{elseif $_G['forum_thread'][displayorder] == -4}--> <span>({lang draft})</span>
                            <!--{/if}-->
                        </h2>
                        <!--{/if}-->
                        <!--{if $post['warned']}-->
                        <span class="grey wqatom_comment">{lang warn_get}</span>
                        <!--{/if}-->
                        <!--{if !$post['first'] && !empty($post[subject])}-->
                        <h2><strong>$post[subject]</strong></h2>
                        <!--{/if}-->


                        <!--{if $_G['adminid'] != 1 && $_G['setting']['bannedmessages'] & 1 && (($post['authorid'] && !$post['username']) || ($post['groupid'] == 4 || $post['groupid'] == 5) || $post['status'] == -1 || $post['memberstatus'])}-->
                        <div class="grey wqatom_comment">{lang message_banned}</div>
                        <!--{elseif $_G['adminid'] != 1 && $post['status'] & 1}-->
                        <div class="grey wqatom_comment">{lang message_single_banned}</div>
                        <!--{elseif $needhiddenreply}-->
                        <div class="grey wqatom_comment">{lang message_ishidden_hiddenreplies}</div>
                        <!--{elseif $post['first'] && $_G['forum_threadpay']}-->
                        <!--{template forum/viewthread_pay}-->
                        <!--{else}-->

                        <!--{if $_G['setting']['bannedmessages'] & 1 && (($post['authorid'] && !$post['username']) || ($post['groupid'] == 4 || $post['groupid'] == 5))}-->
                        <div class="grey wqatom_comment">{lang admin_message_banned}</div>
                        <!--{elseif $post['status'] & 1}-->
                        <div class="grey wqatom_comment">{lang admin_message_single_banned}</div>
                        <!--{/if}-->
                        <!--{if $_G['forum_thread']['price'] > 0 && $_G['forum_thread']['special'] == 0}-->
                        {lang pay_threads}: <strong>$_G[forum_thread][price] {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][title]} </strong> <a class="dialog" href="forum.php?mod=misc&action=viewpayments&tid=$_G[tid]" >{lang pay_view}</a>
                        <!--{/if}-->

                        <!--{if $post['first'] && $threadsort && $threadsortshow}-->
                        <!--{if $threadsortshow['optionlist'] && !($post['status'] & 1) && !$_G['forum_threadpay']}-->
                        <!--{if $threadsortshow['optionlist'] == 'expire'}-->
                        {lang has_expired}
                        <!--{else}-->
                        <div class="box_ex2 viewsort">
                            <h4>$_G[forum][threadsorts][types][$_G[forum_thread][sortid]]</h4>
                            <!--{loop $threadsortshow['optionlist'] $option}-->
                            <!--{if $option['type'] != 'info'}-->
                            $option[title]: <!--{if $option['value']}-->$option[value] $option[unit]<!--{else}--><span class="grey">--</span><!--{/if}--><br />
                            <!--{/if}-->
                            <!--{/loop}-->
                        </div>
                        <!--{/if}-->
                        <!--{/if}-->
                        <!--{/if}-->
							<p>

								<a class="reply_posts" href="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&repquote=$post[pid]&extra=$_GET[extra]&page=$page" data='$post[username]'>
									$post[message]
								</a>
                            </p>
							<!--{if $_G['setting']['mobile']['mobilesimpletype'] == 0}-->
								<!--{if $post['attachment']}-->
									<div class="grey wqatom_comment">
										{lang attachment}: <em><!--{if $_G['uid']}-->{lang attach_nopermission}<!--{else}-->{lang attach_nopermission_login}<!--{/if}--></em>
									</div>
								<!--{elseif $post['imagelist'] || $post['attachlist']}-->
									<!--{if $post['imagelist']}-->
										<!--{if count($post['imagelist']) == 1}-->
											<ul class="wqrelay_warp"><div class="list_atom list_atom1">{echo showattach($post, 1)}</div></ul>
										<!--{else}-->
											<ul class="wqrelay_warp"><div class="list_atom list_atom3">{echo showattach($post, 1)}</div></ul>
										<!--{/if}-->
									<!--{/if}-->
									<!--{if $post['attachlist']}-->
										<ul>{echo showattach($post)}</ul>
									<!--{/if}-->
								<!--{/if}-->
							<!--{/if}-->

                        <!--{/if}-->
                        <!--{if $_GET['from'] != 'preview' && !empty($comments[$post[pid]])}-->
                         <div id="comment_$post[pid]"class="wq_review_warp">
                                <!--{loop $comments[$post[pid]] $comment}-->
                                        <div class="wq_review_loop">
                                            <span class="wq_grey">
                                                        <!--{if $comment['authorid']}-->
                                                                <a href="home.php?mod=space&uid=$comment[authorid]" class="xi2 xw1">$comment[author]:</a>
                                                                <!--{else}-->
                                                                {lang guest}
                                                        <!--{/if}-->
                                                        $comment[comment]
                                                </span>
                                                <span class="y wqapp_f12 wq_grey">
                                                        <!--{date($comment[dateline], 'u')}-->
                                                        <!--{if $_G['forum']['ismoderator'] && $_G['group']['allowdelpost']}-->&nbsp;<a href="javascript:;" class="wqred" onclick="modaction('delcomment', $comment[id])">{lang delete}</a><!--{/if}-->
                                                </span>
                                                </div>
                                <!--{/loop}-->
                                </div>
                        <!--{/if}-->

                        <!--{hook/viewthread_postbottom_mobile $postcount}-->
                        <!--{eval $postcount++;}-->
                        <p class="list_info wqapp_f13">
                            <span class="wqwidth80_reply">$post[dateline]</span>
                        </p>
                    </div>
                      <!--{if $post['signature'] && ($_G['setting']['bannedmessages'] & 4 && ($post['memberstatus'] == '-1' || ($post['authorid'] && !$post['username']) || ($post['groupid'] == 4 || $post['groupid'] == 5) || ($post['status'] & 1)))}-->
			<div class="wqapp_sign wqreply_1_sign">{lang member_signature_banned}</div>
		<!--{elseif $post['signature'] && !$post['anonymous'] && $showsignatures}-->
			<div class="wqapp_sign wqreply_1_sign" style="max-height:{$_G['setting']['maxsigrows']}px;maxHeightIE:{$_G['setting']['maxsigrows']}px;">$post[signature]</div>
		<!--{elseif !$post['anonymous'] && $showsignatures && $_G['setting']['globalsightml']}-->
			<div class="wqapp_sign wqreply_1_sign">$_G['setting']['globalsightml']</div>
		<!--{/if}-->
                </div>
        </li>
    </ul>
</div>
<script>
    $(function () {
        if (typeof common_wxImagePreview == 'function') {
            common_wxImagePreview('pid{$post[pid]}');
        }
    })
</script>
<!--{/loop}-->


<div class="wqpublic_page">$multipage</div>
<!--{if ($_GET[page] && $_GET[page] > '1') || $_GET['checkrush']}-->
    <!--{if count($postlist) == '0'}-->
        <div class="wqempty_sofa" style="background: #f3f3f3;"><img src="{$_G['style'][styleimgdir]}images/sofa.png"/><br/>{$Tlang['d72d60ca7091a3bd']}</div>
    <!--{/if}-->
<!--{else}-->
    <!--{if count($postlist) == '1'}-->
        <div class="wqempty_sofa" style="background: #f3f3f3;"><img src="{$_G['style'][styleimgdir]}images/sofa.png"/><br/>{$Tlang['d72d60ca7091a3bd']}</div>
    <!--{/if}-->
<!--{/if}-->
<!--{/if}-->