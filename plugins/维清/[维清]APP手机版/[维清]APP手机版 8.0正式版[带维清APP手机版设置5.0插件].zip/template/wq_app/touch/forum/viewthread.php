<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['viewthread'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{if $_G['forum']['status'] == 3}-->
    <!--{template group/group_viewthread}-->
    <!--{eval exit;}-->
<!--{/if}-->
<!--{eval $threadsorts = null;}-->

<!--{template common/header}-->
<!--{if $_G[forum_thread][special] == 4 && $_GET['activity']=='yes'}-->
  <!--{template forum/viewthread_activity_1}-->
<!--{eval $nofooter=1;}-->
<!--{template common/footer}-->
<!--{/if}-->
<!--{eval include_once template('common/common_module');}-->
<!--{eval $threadicon = get_icon_for_list();}-->
<!--{hook/viewthread_top_mobile}-->
<!-- main postlist start -->
<!--{if $_G['group']['raterange'] && $post['authorid']}-->
    <div class="my_rate grades wqbg_color iphone_bind" style="display: none" ><a href="javascript:;">{$Tlang['f26bdb744e87d798']}</a></div>
<!--{/if}-->
<div id="view_big">
    <!--{eval $first = reset($postlist);}-->
    <!--{if $first['first']}-->

        <!--{block headconnect}-->
            <!--{if $_G['forum']['ismoderator']}-->
                <div name="moptions_$first[pid]" id="wqmanage_js" popup="true" class="wqadmin_view new_wqmanage new_menu slide-stop">
                    <h3>{$Tlang['34567c4ef7c56e5e']}<i class="wqiconfont2 wqicon2-iconuser wqapp_f20"></i></h3>
                    <ul>
                        <!--{if !$_G['forum_thread']['special']}-->
                        <li><button type="button" class="redirect " href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$first[pid]{if $_G[forum_thread][sortid]}{if $first[first]}&sortid={$_G[forum_thread][sortid]}{/if}{/if}{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page">{lang edit}</button></li>
                        <!--{/if}-->
                        <li><button type="button" class="dialog" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&operation=delete&optgroup=3&from={$_G[tid]}">{lang delete}</button></li>
                        <!--{if $_G['group']['allowbumpthread'] && !$_G['forum_thread']['is_archived']}--><!--{eval $modopt++;}--><li><button type="button" class="dialog" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&operation=bump&optgroup=3">{lang modmenu_updown}</button></li><!--{/if}-->
                        <!--{if $_G['group']['allowstickthread'] && ($_G['forum_thread']['displayorder'] <= 3 || $_G['adminid'] == 1) && !$_G['forum_thread']['is_archived']}--><!--{eval $modopt++;}--><li><button type="button" class="dialog" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&operation=stick&optgroup=1&from={$_G[tid]}">{lang modmenu_stickthread}</button></li><!--{/if}--><!--�ö�-->
                        <!--{if $_G['group']['allowhighlightthread'] && !$_G['forum_thread']['is_archived']}--><!--{eval $modopt++;}--><li><button type="button" class="dialog" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&operation=highlight&optgroup=1">{lang modmenu_highlight}</button></li><!--{/if}--><!--����-->
                        <!--{if $_G['group']['allowdigestthread'] && !$_G['forum_thread']['is_archived']}--><!--{eval $modopt++;}--><li><button type="button" class="dialog" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&operation=digest&optgroup=1">{lang modmenu_digestpost}</button></li><!--{/if}--><!--����-->
                        <!--{if $_G['group']['allowrecommendthread'] && !empty($_G['forum']['modrecommend']['open']) && $_G['forum']['modrecommend']['sort'] != 1 && !$_G['forum_thread']['is_archived']}--><!--{eval $modopt++;}--><li><button type="button" class="dialog" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&operation=recommend&optgroup=1">{lang modmenu_recommend}</button></li><!--{/if}--><!--�Ƽ�-->
                        <!--{if $_G['group']['allowstampthread'] && !$_G['forum_thread']['is_archived']}--><!--{eval $modopt++;}--> <li><button type="button" class="dialog" href="forum.php?mod=topicadmin&action=stamp&fid={$_G[fid]}&tid={$_G[tid]}">{lang modmenu_stamp}</button></li><!--{/if}--><!--ͼ��-->
                        <!--{if $_G['group']['allowstamplist'] && !$_G['forum_thread']['is_archived']}--><!--{eval $modopt++;}--><li><button type="button" class="dialog" href="forum.php?mod=topicadmin&action=stamplist&fid={$_G[fid]}&tid={$_G[tid]}">{lang modmenu_icon}</button></li><!--{/if}--><!--ͼ��-->
                        <li><button type="button" class="dialog" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&from={$_G[tid]}&optgroup=4">{lang close}</button></li>
                        <!--{if $_G['group']['allowmovethread'] && !$_G['forum_thread']['is_archived'] && $_G['forum']['status'] != 3}--><!--{eval $modopt++;}--><li><button type="button" class="dialog" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&operation=move&optgroup=2">{lang modmenu_move}</button></li><!--{/if}--><!--�ƶ�-->
                        <!--{if $_G['group']['allowedittypethread'] && !$_G['forum_thread']['is_archived']}--><!--{eval $modopt++;}--><li><button type="button" class="dialog" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&operation=type&optgroup=2">{lang modmenu_type}</button></li><!--{/if}--><!--����-->
                        <!--{if !$_G['forum_thread']['special'] && !$_G['forum_thread']['is_archived']}-->
                            <!--{if $_G['group']['allowcopythread'] && $_G['forum']['status'] != 3}--><!--{eval $modopt++;}--><li><button type="button" class="dialog" href="forum.php?mod=topicadmin&action=copy&fid={$_G[fid]}&tid={$_G[tid]}">{lang modmenu_copy}</button></li><!--{/if}--><!--����-->
                            <!--{if $_G['group']['allowmergethread'] && $_G['forum']['status'] != 3}--><!--{eval $modopt++;}--><li><button type="button" class="dialog" href="forum.php?mod=topicadmin&action=merge&fid={$_G[fid]}&tid={$_G[tid]}">{lang modmenu_merge}</button></li><!--{/if}--><!--�ϲ�-->
                            <!--{if $_G['group']['allowrefund'] && $_G['forum_thread']['price'] > 0}--><!--{eval $modopt++;}--><li><button type="button" class="dialog" href="forum.php?mod=topicadmin&action=refund&fid={$_G[fid]}&tid={$_G[tid]}">{lang modmenu_restore}</button></li><!--{/if}--><!--��������-->
                        <!--{/if}-->
                        <!--{if $_G['group']['allowsplitthread'] && !$_G['forum_thread']['is_archived'] && $_G['forum']['status'] != 3}--><!--{eval $modopt++;}--><li><button type="button" class="dialog" href="forum.php?mod=topicadmin&action=split&fid={$_G[fid]}&tid={$_G[tid]}">{lang modmenu_split}</button></li><!--{/if}--><!--�ָ�-->
                        <!--{if $_G['group']['allowrepairthread'] && !$_G['forum_thread']['is_archived']}--><!--{eval $modopt++;}--><li><button type="button" class="dialog" href="forum.php?mod=topicadmin&action=repair&fid={$_G[fid]}&tid{$_G[tid]}">{lang modmenu_repair}</button></li><!--{/if}--><!--�޸�-->
                        <li><button type="button" class="dialog" href="forum.php?mod=topicadmin&action=banpost&fid={$_G[fid]}&tid={$_G[tid]}&topiclist[]={$_G[forum_firstpid]}">{lang admin_banpost}</button></li>
                        <li><button type="button" class="dialog" href="forum.php?mod=topicadmin&action=warn&fid={$_G[fid]}&tid={$_G[tid]}&topiclist[]={$_G[forum_firstpid]}">{lang topicadmin_warn_add}</button></li>
                        <!--{if $_G['forum_thread']['is_archived'] && $_G['adminid'] == 1}--><!--{eval $modopt++;}--><li><button type="button" class="dialog" href="forum.php?mod=topicadmin&action=restore&fid={$_G[fid]}}&tid={$_G[tid]}">{lang modmenu_archive}</button></li><!--{/if}--><!--ȡ���浵-->
                        <!--{if $_G['group']['allowremovereward'] && $_G['forum_thread']['special'] == 3 && !$_G['forum_thread']['is_archived']}--><!--{eval $modopt++;}--><li><button type="button" class="dialog" href="forum.php?mod=topicadmin&action=removereward&fid={$_G[fid]}&tid={$_G[tid]}">{lang modmenu_removereward}</button></li><!--{/if}--><!--�Ƴ�����-->
                        <!--{if $_G['group']['allowmanagetag']}--><li><button type="button" class="dialog" href="forum.php?mod=tag&op=manage&tid={$_G[tid]}">{lang post_tag}</button></li><!--{/if}--><!--��ǩ-->
                        <!--{if $_G['group']['alloweditusertag']}--> <li><button type="button" class="dialog" href="forum.php?mod=misc&action=usertag&tid={$_G[tid]}&infloat=yes&handlekey=usertag&inajax=1&ajaxtarget=fwin_content_usertag">{lang usertag}</button></li><!--{/if}--><!--�û���ǩ-->
                        <!--{if $allowpusharticle && $allowpostarticle}--><!--{eval $modopt++;}--><li><button type="button" onclick="location.href = 'portal.php?mod=portalcp&ac=article&from_idtype=tid&from_id={$_G[tid]}'">{lang modmenu_pusharticle}</button></li><!--{/if}--><!--��������-->
                    </ul>
                </div>
                <div class="new_hide" style="display: none;"></div>
            <!--{/if}-->
        <!--{/block}-->

        <!--{if $_G['forum']['ismoderator']}-->
            <!--{eval
                $headparams['rclass'] = 'wqicon2-gengduo1 y wqapp_f30 wqheader_right new_button';
                $headparams['rtype'] = 'icon';
            }-->
        <!--{elseif (($_G['forum']['ismoderator'] && $_G['group']['alloweditpost'] && (!in_array($first['adminid'], array(1, 2, 3)) || $_G['adminid'] <= $first['adminid'])) || ($_G['forum']['alloweditpost'] && $_G['uid'] && ($first['authorid'] == $_G['uid'] && $_G['forum_thread']['closed'] == 0) && !(!$alloweditpost_status && $edittimelimit && TIMESTAMP - $first['dbdateline'] > $edittimelimit))) && !$_G['forum_thread']['special']}-->
            <!--{eval
                $rurl= $_G['forum_thread']['sortid'] && $first['first'] ? '&sortid='.$_G['forum_thread']['sortid'] : '';
                $rurl.= !empty($_GET['modthreadkey']) ? '&modthreadkey='.$_GET['modthreadkey'] : '';
                $headparams['rurl'] = 'forum.php?mod=post&action=edit&fid='.$_G['fid'].'&tid='.$_G['tid'].'&pid='.$first['pid'].$rurl.'&page=$page';
                $headparams['rclass'] = 'redirect';
                $headparams['rtype'] = 'but';
                $headparams['rname'] = '<i class="wqiconfont2 wqicon2-xindenew85 wqapp_f18"></i>';
            }-->
        <!--{/if}-->

        <!--{eval
            $headparams['wtype'] = '3';
            $headparams['lurl'] = $backurl;
            $headparams['ltype'] = 'a';
            $headparams['cname'] = $Tlang['72009302eb9a6b36'];
            echo wq_app_get_header($headparams, true, true, $headconnect);
        }-->
    <!--{else}-->
            <!--{eval
            $headparams['wtype'] = '1';
            $headparams['lurl'] = $backurl;
            $headparams['ltype'] = 'a';
            $headparams['cname'] = $Tlang['72009302eb9a6b36'];
            echo wq_app_get_header($headparams) ;
        }-->

     <div class="wqheight44" style="display: none;"></div>
        <div class="new_hide" style="display: none; z-index:12;"></div>
        <div class="wqview_seawarp4 <!--{if $wq_app_setting['view_style'] == 2}-->wqtilte_two_seawarp<!--{/if}-->">
            <div class="wqview_title">
                <h2 class="wqtitle">
                    <!--{eval echo discuzcode($_G[forum_thread][subject]);}-->
                    <!--{if $_G['forum_thread'][displayorder] == -2}-->
                        <span>({lang moderating})</span>
                    <!--{elseif $_G['forum_thread'][displayorder] == -3}-->
                        <span>({lang have_ignored})</span>
                    <!--{elseif $_G['forum_thread'][displayorder] == -4}-->
                        <span>({lang draft})</span>
                    <!--{/if}-->
                </h2>
            </div>
        </div>
        <!--{if $wq_app_setting['view_style'] == 1}-->
            <div class="wqseparate2" id="wqall_comment"></div>
            <div class="wqposts_atom">
                <h3 class="wqnew_bottom">
                    <a href="javascript:;" class="wqborder_bottom wqcolor wqnew_bottom_bule">{$Tlang['4bc7b967c326c87e']}</a>
                    <span>
                           <a href="forum.php?mod=viewthread&tid=$_G[tid]&extra=$_GET[extra]&ordertype=1">{lang post_descview}</a>
                           <a href="forum.php?mod=viewthread&tid=$_G[tid]&extra=$_GET[extra]&ordertype=2">{lang post_ascview}</a>
                    </span>
                </h3>
            </div>
        <!--{else}-->
            <div class="wqpublic_reply">
                <h3 class="wqh3"><span>{$Tlang['4bc7b967c326c87e']}</span>
                <span>
                           <a href="forum.php?mod=viewthread&tid=$_G[tid]&extra=$_GET[extra]&ordertype=1">{lang post_descview}</a>
                           <a href="forum.php?mod=viewthread&tid=$_G[tid]&extra=$_GET[extra]&ordertype=2">{lang post_ascview}</a>
                    </span>
                </h3>
            </div>
            <div class="wqpost_reply">
                <a href="javascript:;" id="fastpostmessage" class="notlogged">{$Tlang['8442ceb58921a995']}<i class="wqiconfont2 wqicon2-bianji"></i></a>
            </div>
        <!--{/if}-->
    <!--{/if}-->
    <div class='wqwechat_image_preview_warp'>
    <div class="postlist"><!--{if $_GET[page] && $_GET[page] > '1'}--></div><!--{/if}-->
    <!--{eval
        $wq_forumuser_url='home.php?mod=space&do=profile&uid=';
        $postcount = 0;loadcache('wq_usergroup');
        $wq_app_usergroup=$_G['cache']['wq_usergroup']?$_G['cache']['wq_usergroup']:wq_usergroup();
    }-->

    <!--{loop $postlist $post}-->
        <!--{eval
            $needhiddenreply = ($hiddenreplies && $_G['uid'] != $post['authorid'] && $_G['uid'] != $_G['forum_thread']['authorid'] && !$post['first'] && !$_G['forum']['ismoderator']);
            $mycenter=$_G['uid']==$post[uid]?"&mycenter=1":"";
            $wq_userurl=$wq_forumuser_url.$post[authorid].$mycenter;
            $post[message] = str_replace('smilieid="','class="wq_smilieimg" smilieid="',$post[message]);
            $post[dateline]= wq_app_dgmdate($post[dateline]);
        }-->

        <!--{if $first['first']}-->
            <!--{hook/viewthread_posttop_mobile $postcount}-->
        <!--{/if}-->

        <!--{if !$post[first]}-->
            <!--{eval continue;}-->
        <!--{/if}-->

        <!--{if $wq_app_setting['view_style'] == 1}-->
            <!--{template forum/viewthread_1}-->
        <!--{else}-->
            <!--{template forum/viewthread_2}-->
        <!--{/if}-->
        <!--{eval $postcount++;}-->
    <!--{/loop}-->

    <!--{if $wq_app_setting['view_style'] == 1}-->
        <!--{template forum/viewthread_reply_1}-->
    <!--{else}-->
        <!--{template forum/viewthread_reply_2}-->
    <!--{/if}-->

    <!--{template forum/forumdisplay_fastpost}-->
<!-- main postlist end -->
<!--{hook/viewthread_bottom_mobile}-->
</div>
</div>

<!--{template common/share}-->
<form method="post" autocomplete="off" id="fastpostform" action="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&extra=$_GET[extra]&replysubmit=yes">
    <input type="hidden" name="formhash" value="{FORMHASH}"/>

    <!--{eval
        $headparams['wclass'] = 'wqheader wqbg_color new_lump';
        $headparams['wextra'] = 'style="display:none; z-index: 99; position: fixed;"';

        $headparams['ltype'] = 'cancel';
        $headparams['lname'] = $Tlang['9c825be7149e5b97'];
        $headparams['lurl'] = 'javascript:void(0);';

	$headparams['ctype'] = 'span';
        $headparams['cname'] =$Tlang['dbedca5ca18ae5c8'];

        $headparams['rtype'] = 'but';
        $headparams['rname'] = $Tlang['c0e5b55d87a9643f'];
        $headparams['rclass'] = 'formdialog';
        $headparams['rid'] = 'postsubmit';
        $headparams['buttype'] = 'submit';
        $headparams['butname'] = 'ratesubmit';

        echo wq_app_get_header($headparams, false, true) ;
    }-->


    <div class="wqpost_list new_list" style="display:none;">
        <ul class="wqpost_list_ul">
            <!--{hook/viewthread_reply_wq_mobile}-->
            <li class="post_con wqnew_bottom">
                <textarea class="wqpost_textarea" id="needmessage" tabindex="3" autocomplete="off" name="message" rows="2" placeholder="{$Tlang['91efda220ced091e']}" fwin="reply" style="height: 120px; display: none;"></textarea>
                <div class="wqeditarea" contenteditable="true" placeholder="{$Tlang['91efda220ced091e']}"></div>
                <div class="wqpost_upload"><span class="wqiconfont2 wqicon2-biaoqing wqapp_f26 wqbiaoqing"></span>
                    <a href="javascript:;" class="wqiconfont2 wqicon2-tupian1 wqapp_f26">
                        <input type="button" id="file_button"  class="wqfiledata">
                        <input id='filedata' type="file" name="Filedata"  multiple="multiple"  class="wqfiledata" accept="image/*" style="display: none;" >
                        <i class="wqtoday" style="display: none;">0</i>
                    </a>
                </div>
            </li>
        </ul>
        <!--{template common/upload_image}-->
        <!--{template common/smilies}-->
    </div>
    <!--{template common/simple_editor}-->
</form>
<!--{if $wq_app_setting['view_open_promote']}-->
<div class="wq-promotion-mask" style="display:none;"></div>
<div class="nightmask"></div>
<div class="dialogbox" id="promotionCode" style="height: 390px; width: 240px; display: none; position: fixed; left: 0px; top: 89px; z-index: 120; opacity: 1;">
    <div class="qz_bg">
        <div class="qrcode_wrap width_max100">
            <div class="qrcode_container">
                <img class="qrcode_img" src="{$_G['siteurl']}plugin.php?id=wq_app_setting&mod=ajax&ac=promotionqrcodetid&tid={$_G['tid']}&fromuid={$_G[uid]}&rand={VERHASH}">
                <span>
                    <img src="<!--{eval echo avatar($_G['uid'], middle, true);}-->" />
                </span>
            </div>
            <div class="qrcode_code">
                <span><img src="<!--{eval echo avatar($_G['uid'], middle, true);}-->"></span>
                <div class="qrcode_head">
                    <h3>{$_G['username']}</h3>
                    <p>{$Tlang['9b47950a06398de6']}</p>
                </div>
            </div>
        </div>
    </div>
</div>
<!--{/if}-->
<script type="text/javascript" reload="1">
    JC.file('thirdparty/jqColorPicker.min.js');
    JC.run();
    var scroll_Top = 0;
    function upload_image(data) {
        if(data == '') {
            popup.open('{lang uploadpicfailed}', 'alert');
        }
        var dataarr = data.split('|');
        if(dataarr[0] == 'DISCUZUPLOAD' && dataarr[2] == 0) {
            popup.close();
            if ($('#imglist').is(':hidden')) {
                $('.cellphone_expression').hide();
                $('.wqbiaoqing').removeClass('wqicon2-jianpan').addClass('wqicon2-biaoqing');
                $('#imglist').show();
            }
           $('#imglist').prepend('<li><span aid="'+dataarr[3]+'" class="del wqdelete"><a href="javascript:;"> <i class="wqiconfont2 wqicon2-jianhao f22"></i></a></span><span class="wqimg"><a href="javascript:;"><img id="aimg_'+dataarr[3]+'" title="'+dataarr[6]+'" src="{$_G[setting][attachurl]}forum/'+dataarr[5]+'" /></a></span><input type="hidden" name="attachnew['+dataarr[3]+'][description]" /></li>');
           $('.wqtoday').show().text($('#imglist li').length-1);
           $('#filedata').val('');
        } else {
            var sizelimit = '';
            if(dataarr[7] == 'ban') {
                sizelimit = '{lang uploadpicatttypeban}';
            } else if(dataarr[7] == 'perday') {
                sizelimit = '{lang donotcross}'+Math.ceil(dataarr[8]/1024)+'K)';
            } else if(dataarr[7] > 0) {
                sizelimit = '{lang donotcross}'+Math.ceil(dataarr[7]/1024)+'K)';
            }
            popup.open(STATUSMSG[dataarr[2]] + sizelimit, 'alert');
        }
    };

    $(function(){
        $('.wqeditarea').wqEditor({
            selector: '#needmessage',
            editor: '.wqeditarea',
            bbcodeMode: true,
            placeholder: "{$Tlang['70ad0bcbf2229f1d']}",
            imglist: '#imglist',
            isInput: '',
            subButton: '#postsubmit'
        });
        var pcontent_height = $(window).height() - 44;
        $('.wqrate_pcontent').css('margin-top', '44px');
        $('body').on('click','.grades', function() {
            var obj = $(this);
            scroll_Top = $(window).scrollTop();
            $.ajax({
                type: 'GET',
                url: obj.attr('url') + '&inajax=1&page={$_GET[page]}',
                data: {},
                dataType: 'html'
            }).success(function(s) {
                var wq = wqXml(s);
                $('#popup_grade').html(wq);
                if ($('#popup_grade #rateform').length) {
                    $('#popup_content').height(pcontent_height).html(wq);

                    if ($('#popup_fullscreen').is(':hidden')) {
                        $('#popup_fullscreen').show();
                    }

                    $('.my_rate,#view_big').hide();
                } else {
                    popup.open(wq);
                }
            }).error(function() {
                window.location.href = obj.attr('href');
                popup.close();
            });
            return false;
        });
        $("body").on("blur",".wqrate_sz .graded",function(){
            var number = $(this).val();
            if(!isNaN(parseInt(number)) && parseInt(number) >= 0 && parseInt(number) <= 10){
                $(this).val(parseInt(number));
            }else{
                $(this).val("0");
            }
        });
        $('.rate_viewratings').on('click', function() {
            var obj = $(this);
            scroll_Top = $(window).scrollTop();
            $.ajax({
                type: 'GET',
                url: obj.attr('url') + '&inajax=1',
                data: {},
                dataType: 'html'
            }).success(function(s) {
                var wq = wqXml(s);
                $('#popup_content').height(pcontent_height - 49).html(wq);
                $('#popup_fullscreen').show();
                $('#view_big').hide();
                var pid = obj.attr('pid');
                if (pid) {
                    $('.my_rate,#rateview_submit').attr('url', 'forum.php?mod=misc&action=rate&tid=$_G[tid]&pid=' + pid).show();
                    $('#rate_h50').show();
                }
            }).error(function(s) {
                window.location.href = obj.attr('href');
                popup.close();
            });
            return false;
        });
        $("#fastpostmessage").on("click",function(e){
            scroll_Top = $(window).scrollTop();
            $("#view_big").hide();
            $('.new_lump').show();
            $(".new_list").show();
        });
        $('.wqbiaoqing').on('click', function () {
            $(this).toggleClass('wqicon2-jianpan');
            if ($('.cellphone_expression').is(':hidden')) {
                $('#imglist').hide();
                $('.cellphone_expression').show();
                $('#upload_icon').removeClass('blue');
                $('.wqbiaoqing').removeClass('wqicon2-biaoqing');
                expression_viwepager();
            } else {
                $('.cellphone_expression').hide();
                $('.wqbiaoqing').addClass('wqicon2-biaoqing');
            }
        });
        $('body').on('click', '.support_forum', function() {
            var obj = $(this);
            var data = obj.attr('data');
            $.ajax({
                type: 'GET',
                url: obj.attr('href') + '&inajax=1',
                data: {'hash': '{FORMHASH}'},
                dataType: 'html'
            }).success(function(s) {
                var wq = wqXml(s);
                $('#popup_grade').html(wq);
                if ($.trim($('#popup_grade p:eq(0)').text()) == '{$Tlang[289f61f54d327553]}') {
                    var support_num = oppose_num = parseInt($('#review_support_' + data).text());
                    var text = support_num > 0 ? support_num + 1 : 1;
                    $('#review_support_' + data).html(text);
                }
                popup.open(wq);
            }).error(function() {
                window.location.href = obj.attr('href');
                popup.close();
            });
            return false;
        });
        $('body').on('click', '.oppose', function() {
            var obj = $(this);
            var data = obj.attr('data');
            $.ajax({
                type: 'GET',
                url: obj.attr('href') + '&inajax=1',
                data: {'hash': '{FORMHASH}'},
                dataType: 'html'
            }).success(function(s) {
                var wq = wqXml(s);
                $('#popup_grade').html(wq);
                if ($.trim($('#popup_grade p:eq(0)').text()) == '{$Tlang[289f61f54d327553]}') {
                    var oppose_num = parseInt($('#review_supportss_' + data).text());
                    var text = oppose_num > 0 ? oppose_num + 1 : 1;
                    $('#review_supportss_' + data).html(text);
                }
                popup.open(wq);
            }).error(function() {
                window.location.href = obj.attr('href');
                popup.close();
            });
            return false;
        });
        if (typeof common_wxImagePreview == 'function') {
            common_wxImagePreview('wqpost_view_warp img, .wqpic_img');
        }

        $("#promotionCode").css({"top": ($(window).height() - $("#promotionCode").height()) / 2,"left": ($(window).width() - $("#promotionCode").width()) / 2});
        $(".promotionqrcode").on("touchend",function(){
            $("#promotionCode").fadeIn();
            $('.wq-promotion-mask').show();
        });
        $('.wq-promotion-mask').on('touchend', function (e) {
            $("#promotionCode").fadeOut();
            $('.wq-promotion-mask').hide();
        });
    });

    function errorhandle_recommendadd(msg, param) {
        console.log(param['recommendv']);
        if (param['recommendv'] == '+1') {
            var objv = $('#recommend_add');
            objv.css("display", "");
            objv.html(parseInt(objv.html()) + 1);
        }
    }
    function succeedhandle_newfav(url,msg, param) {
        if ($.trim(msg) == "{$Tlang['fffeda57b2002266']}") {
            clearInterval(setTimeout_location);
            wq_app_cache_user_favorite_or_recommend_info('favorite');
            $('.wqcomment_input_icon .wqcollection i').attr('class','wqiconfont2 wqicon2-shoucang1 wqapp_f26 wqcolor_yellow wqicon_position');
            $('.wqjojn_activity .wqjojn_collection i').attr('class','wqiconfont2 wqicon2-shoucang3 wqapp_f22 wqcolor_yellow');
            setTimeout(function () {
                popup.close();
            }, '1500');
        }
    }
    function errorhandle_recommendsubtract(msg, param) {
        if (param['recommendv'] == '-1') {
            var objv = $('#recommend_subtract');
            objv.css("display", "");
            objv.html(parseInt(objv.html()) + 1);
        }
    }

    function switchitemcp(id) {
        $('#' + id).addClass('copt').removeClass('notchecked');
        $('#' + id).siblings().addClass('notchecked').removeClass('copt');
    }
    function switchhl(obj, v) {
        if(parseInt($('#highlight_style_' + v).val())) {
            $('#highlight_style_' + v).val(0);
            obj.className = obj.className.replace(/ cnt/, '');
        } else {
            $('#highlight_style_' + v).val(1);
            obj.className += ' cnt';
        }
    }
    function showHighLightColor(hlid) {
        var showid = hlid + '_ctrl';
        if(!$('#' + showid + '_menu').length) {
            var str = '';
            var coloroptions = {'0' : '#000', '1' : '#EE1B2E', '2' : '#EE5023', '3' : '#996600', '4' : '#3C9D40', '5' : '#2897C5', '6' : '#2B65B7', '7' : '#8F2A90', '8' : '#EC1282'};
            var menu = document.createElement('div');
            menu.id = showid + '_menu';
            menu.className = 'cmen iphone_bind';
            menu.style.display = 'none';
            for(var i in coloroptions) {
                str += '<a href="javascript:;" onclick="$(\'#' + hlid + '\').val(\'' + i + '\');$(\'#' + showid + '\').css(\'background-color\', \'' + coloroptions[i] + '\'); $(\'#' + showid + '_menu\').hide()" style="background:' + coloroptions[i] + ';color:' + coloroptions[i] + ';">' + coloroptions[i] + '</a>';
            }
            menu.innerHTML = str;
            $('.color-setting').append(menu);
            $('body').on('touchstart', '.cmen a', function (e) {
                e.stopPropagation();
            });
            $('body').on('touchstart', function () {
                $('#' + showid + '_menu').fadeOut();
            });
        }
        var offset = $('#' + showid).offset();
        $('#' + showid + '_menu').css({position: 'fixed', top: (offset.top + $('#' + showid).height() - $(document).scrollTop()) + 'px', left: offset.left + 'px'})
        $('#' + showid + '_menu').fadeIn();
    }
</script>
<!--<a href="javascript:;" title="{lang scrolltop}" class="scrolltop bottom"></a>-->
<!--{eval $nofooter=1;}-->
<!--{template common/footer}-->

<!--{/if}-->