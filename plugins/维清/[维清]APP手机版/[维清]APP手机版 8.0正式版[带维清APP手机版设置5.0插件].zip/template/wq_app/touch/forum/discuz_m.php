<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['discuz_m'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{template common/header}-->

<!--{if $_G['setting']['mobile']['mobilehotthread'] && $_GET['forumlist'] != 1}-->
        <!--{eval wq_app_get_guide_options($wq_app_setting);}-->
<!--{/if}-->

<!--{if $_GET['visitclient']}-->
    <header class="header">
        <div class="nav">
            <span>{lang warmtip}</span>
        </div>
    </header>
    <div class="cl">
        <div class="clew_con">
            <h2 class="tit">{lang zsltmobileclient}</h2>
            <p>{lang visitbbsanytime}<input class="redirect button" id="visitclientid" type="button" value="{lang clicktodownload}" href="" /></p>
            <h2 class="tit">{lang iphoneandriodmobile}</h2>
            <p>{lang visitwapmobile}<input class="redirect button" type="button" value="{lang clicktovisitwapmobile}" href="$_GET[visitclient]" /></p>
        </div>
    </div>
<!--{else}-->

<!-- header start -->
    <!--{if $showvisitclient}-->
        <div class="visitclienttip vm" style="display:block;">
            <a href="javascript:;" id="visitclientid" class="btn_download">{lang downloadnow}</a>
            <p>
                    {lang downloadzslttoshareview}
            </p>
        </div>
    <!--{/if}-->
        <header class="wqheader wqbg_color wqheader-position wqheader-relative">
            <a href="javascript:;" class="wqiconfont2 wqicon2-daohang2 wqapp_f28 wqmenu"></a>
            <img class="wqlogo" src="{$_G['style']['styleimgdir']}images/{$logofilename}">
            <a href="javascript:;" class="wqiconfont2 wqicon2-albumfenxiang wqapp_f24 wqshare"></a>
        </header>
        <div class="wqheight44" style="display: none;"></div>
<!-- header end -->

<!--{hook/index_top_mobile}-->

<!-- main forumlist start -->
<!--{if $wq_app_setting['discuz_style'] == 1}-->
    <div class="wp wm wqplate_list1" id="wp">
        <ul>
            <!--{loop $catlist $key $cat}-->
            <div class="bm bmw fl wqplate_list1">
                <div class="subforumshow bm_h cl wqplate_list_warp" href="#sub_forum_$cat[fid]">
                <h2><a href="javascript:;" class="wqblock">$cat[name]
                        <span><i class="wqiconfont2 <!--{if !$_G[setting][mobile][mobileforumview]}-->wqicon2-jian <!--{else}-->wqicon2-jian<!--{/if}--> y wqapp_f24"></i></span>
                    </a>
                </h2>
                </div>
                <!--{eval $forumcolumns = get_forum_forumcolumns($cat);}-->
                <!--{eval include template('forum/discuz_'.$forumcolumns);}-->
            </div>
            <!--{/loop}-->
        </ul>
    </div>
<!--{else}-->
    <!--{eval include template('forum/forumlist');}-->
<!--{/if}-->
<!-- main forumlist end -->
<!--{hook/index_middle_mobile}-->
<script type="text/javascript">
    var mobileforumview = "$_G['setting']['mobile']['mobileforumview']", visitclient = "$_GET['visitclient']";
</script>
<script type="text/javascript" src="{$_G['style']['styleimgdir']}js/forum/discuz.js?{VERHASH}"></script>
<!--{/if}-->
<!--{template common/footer}-->

<!--{/if}-->