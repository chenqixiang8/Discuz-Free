<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['rate_view'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{template common/header}-->
<div id="ct" class="wqipagen">
	<div class="wqrate_total">
		<ul>
			<!--{eval $count = count($logcount); $add = $count % 2 != 0 ? 1 : 0}-->
			<!--{loop $logcount $id $count}-->
			<li>{$_G['setting']['extcredits'][$id][title]} {$count}</li>
			<!--{/loop}-->
			<!--{if $add}-->
			<li>&nbsp;</li>
			<!--{/if}-->
		</ul>
	</div>
	<div class="wqfloatwrap">
		<!--{loop $loglist $k $log}-->
		<!--{eval $log[score]=str_replace('+', '', $log[score]);}-->
		<div class="wqrate_tit <!--{if ($k)%2!=0}-->wqbg_tit<!--{/if}-->">
			<ul>
				<li><a href="home.php?mod=space&do=profile&uid=$log[uid]">$log[username]</a></li>
				<li>{$_G['setting']['extcredits'][$log[extcredits]][title]}{$log[score]}</li>
				<li>$log[dateline]</li>
			</ul>
			<!--{if $log[reason]}-->
			<p class="wqrate_reason">{$Tlang['608efb11807af263']}$log[reason]</p>
			<!--{/if}-->
		</div>
		<!--{/loop}-->
	</div>

</div>
<div class="wqheader wqbg_color">
    <a href="javascript:;" id="popup_hidden" class="wqcancel new_hidden2">{$Tlang['beb08d096719774b']}</a>
    <span class="wqpost_title">{$Tlang['0b895e776c79def4']}</span>
    <button name="ratesubmit" id="rateview_submit" type="button" value="true" class="wqpublish wqbg_color grades" style="display: none;">{$Tlang['0487fbf42b51d238']}</button>
</div>
<!--{template common/footer}-->


<!--{/if}-->