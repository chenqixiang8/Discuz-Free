<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['post_trade'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<li class="wqnew_bottom">
    <select name="item_quality" id="item_quality" class="wqpost_select" tabindex="1">
        <option value="1" {if $trade['quality'] == 1}selected="selected"{/if}>{lang trade_new}</option>
        <option value="2" {if $trade['quality'] == 2}selected="selected"{/if}>{lang trade_old}</option>
    </select>
</li>
<li class="wqnew_bottom"><span class="rq wqrequired">*</span><input type="text" name="item_name" id="item_name" class="wqpost_input" placeholder="{lang post_trade_name}" value="$trade[subject]" tabindex="1"></li>
<li class="wqnew_bottom"><span class="rq wqrequired">*</span><input type="text"  name="item_number" id="item_number"  class="wqpost_input" placeholder="{lang post_trade_number}" value="$trade[amount]" tabindex="1"></li>
<li class="wqnew_bottom">
    <select  name="transport" id="transport" class="wqpost_select">
        <option value="virtual" {if $trade['transport'] =='3'}selected="selected"{/if}>{lang post_trade_transport_virtual}</option>
        <option value="seller" {if $trade['transport'] =='1'}selected="selected"{/if}>{lang post_trade_transport_seller}</option>
        <option value="buyer" {if $trade['transport'] ==='2'}selected="selected"{/if}>{lang post_trade_transport_buyer}</option>
        <option value="logistics" {if $trade['transport'] ==='4'}selected="selected"{/if}>{lang trade_type_transport_physical}</option>
        <option value="offline" {if $trade['transport'] ==='0'}selected="selected"{/if}>{lang post_trade_transport_offline}</option>
    </select>
</li>

<li class="wqnew_bottom"><input type="tel" name="item_price" id="item_price" class="wqpost_input" placeholder="{lang post_current_price}"alue="$trade[price]" tabindex="1" ></li>
<li class="wqnew_bottom"><input type="tel" name="item_costprice" id="item_costprice" class="wqpost_input" placeholder="{lang post_original_price}"value="$trade[costprice]" tabindex="1" ></li>
<!--{if $_G['setting']['creditstransextra'][5] != -1}-->
    <li class="wqnew_bottom"><input type="tel" name="item_credit" id="item_credit" class="wqpost_input" placeholder="{lang post_current_credit}({$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][5]][title]})"alue="$trade[credit]" tabindex="1"></li>
    <li class="wqnew_bottom"><input type="tel" name="item_costcredit" id="item_costcredit" class="wqpost_input" placeholder="{lang post_original_credit}({$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][5]][title]})"value="$trade[costcredit]" tabindex="1" ></li>
<!--{/if}-->
<div id="logisticssetting" style="display:{if !$trade['transport'] || $trade['transport'] == 3}none{/if}">
    <li class="wqnew_bottom">
        <input type="text" name="postage_mail" id="postage_mail" class="wqpost_input" placeholder="{lang post_trade_transport_mail}" value="$trade[ordinaryfee]" tabindex="1" /></li>
    <li><input type="text" name="postage_express" id="postage_express" class="wqpost_input" placeholder="{lang post_trade_transport_express}" value="$trade[expressfee]" tabindex="1" /></li>
    <li><input type="text" name="postage_ems" id="postage_ems" class="wqpost_input" placeholder="EMS" value="$trade[emsfee]" tabindex="1" /></li>
</div>
<li class="wqnew_bottom">
    <select name="paymethod" id="paymethod" width="108" change="display('tenpayseller')" class="wqpost_select" tabindex="1">
        <!--{if $_G[setting][ec_tenpay_opentrans_chnid]}--><option value="0" {if $trade[tenpayaccount]}selected{/if}>{lang post_trade_paymethod_online}</option><!--{/if}-->
        <option value="1" {if !$trade[tenpayaccount]}selected{/if}>{lang post_trade_paymethod_offline}</option>
    </select>
</li>
<li class="wqnew_bottom"><input type="text" name="item_locus" id="item_locus"  class="wqpost_input" placeholder="{lang post_trade_locus}"value="$trade[locus]" tabindex="1"></li>
<li class="wqnew_bottom"><input type="text" id="trade_data" name="item_expiration" id="item_expiration" class="muidate wqpost_input" placeholder="{lang valid_before}"autocomplete="off" value="$trade[expiration]" tabindex="1" ></li>
<!--{if !$allowpostimg}-->
    <li class="wqnew_bottom">
        <div class="ac_pic">
            <p>
                <input type="button" class="pn" id="trade_button">
                <span>{$Tlang['53613c63e7a39eb8']}</span>
            </p>
        </div>
        <div id="tradeattach_image" class="wqupload_pic_img">
            <!--{if $tradeattach[attachment]}-->
                <div class="wqm_top10">
                    <a href="$tradeattach[url]/$tradeattach[attachment]"><img src="$tradeattach[url]/{if $tradeattach['thumb']}{eval echo getimgthumbname($tradeattach['attachment']);}{else}$tradeattach[attachment]{/if}" alt="" /></a>
                    <input type="hidden" name="tradeaid" id="tradeaid" value="$activityattach[aid]"/>
                    <input type="hidden" name="tradeaid_url" id="tradeaid_url" />
                </div>
            <!--{/if}-->
        </div>
    </li>
<!--{/if}-->
<script>
    $(function() {
        uploadsuccess_trade = function(data) {
            if (data == '') {
                popup.open('{lang uploadpicfailed}', 'alert');
            }
            var dataarr = data.split('|');
            if (dataarr[0] == 'DISCUZUPLOAD' && dataarr[2] == 0) {
                popup.close();
                if ($('#tradeaid').length) {
                    $.ajax({
                        type: 'GET',
                        url: 'forum.php?mod=ajax&action=deleteattach&inajax=yes&aids[]=' + $('#tradeaid').val(),
                    })
                }

                $('#tradeattach_image').html(' <div class="wqm_top10"><a href="javascript:;"><img id="aimg_' + dataarr[3] + '" title="' + dataarr[6] + '" src="'+prcpath+'forum/' + dataarr[5] + '" />\n\
<input type="hidden" name="tradeaid" id="tradeaid" value="' + dataarr[3] + '"><input type="hidden" name="tradeaid_url" id="tradeaid_url" value="' + dataarr[5] + '"></a></div>');
                $('#filedata').val('').attr('multiple','multiple');
            } else {
                var sizelimit = '';
                if (dataarr[7] == 'ban') {
                    sizelimit = '{lang uploadpicatttypeban}';
                } else if (dataarr[7] == 'perday') {
                    sizelimit = '{lang donotcross}' + Math.ceil(dataarr[8] / 1024) + 'K)';
                } else if (dataarr[7] > 0) {
                    sizelimit = '{lang donotcross}' + Math.ceil(dataarr[7] / 1024) + 'K)';
                }
                popup.open(STATUSMSG[dataarr[2]] + sizelimit, 'alert');
            }
        }
        $(document).on('click', '#trade_button', function() {
                uploadsuccess_forum= uploadsuccess_trade;
                $('#filedata').attr('multiple',null).click();
        });
        $("#transport").on("change",function(){
            if ($("#transport").val() == "seller" || $("#transport").val() == "buyer" || $("#transport").val() == "logistics") {
                $("#logisticssetting").show();
            } else {
                $("#logisticssetting").hide();
            }
        });
    });
</script>
<!--{/if}-->