<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['viewthread_1'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
 <!--{if $wq_app_setting['view_view_style'] == 1}-->
    <div class="wqview_seawarp">
    <!--{if $post[first]}-->
     <div class="wqview_title wqnew_bottom">
        <h2 class="wqtitle">
            <a href="<!--{if $wq_app_setting['view_click']}-->forum.php?mod=viewthread&tid=$post[tid]<!--{else}-->javascript:;<!--{/if}-->">
                <!--{eval echo discuzcode($_G[forum_thread][subject]);}-->
            </a>
                <!--{if $_G['forum_thread'][displayorder] == -2}-->
                    <span>({lang moderating})</span>
                <!--{elseif $_G['forum_thread'][displayorder] == -3}-->
                    <span>({lang have_ignored})</span>
                <!--{elseif $_G['forum_thread'][displayorder] == -4}-->
                    <span>({lang draft})</span>
                <!--{/if}-->
        </h2>
            <div class="wqsection_name">
                <span class="wqname">
                    <a href="forum.php?mod=forumdisplay&fid={$_G['fid']}">
                        <!--{eval echo strip_tags($_G['forum']['name']) ? strip_tags($_G['forum']['name']) : $_G['forum']['name'];}-->
                        <i class="wqiconfont2 wqicon2-202"></i></a></span>
                <span class="wqy wqinfo">{$thread[views]}{$Tlang['a6aa5366e09f370c']}<em>{$thread[replies]}{$Tlang['dbedca5ca18ae5c8']}</em><!--{if $wq_app_setting['view_open_promote']}--><em><a href="javascript:;" class="promotionqrcode">{$Tlang['04ce6c956620ce57']}</a></em><!--{/if}--></span>

            </div>
        </div>
    <!--{/if}-->
    <div class="wquser_info">
            <div class="wqhead_img">
                  <a href="{if $post['authorid'] && $post['username'] &&($_G['forum']['ismoderator']||!$post['anonymous'])}{$wq_userurl}{else}javascript:;{/if}" style="display: initial ">
                        <img class="wqhead" src="{if !$post['authorid'] || $post['anonymous']}{avatar(0, small, true)}{else}{avatar($post[authorid], small, true)}{/if}"/>
                    </a>
                 <!--{if $post['first'] &&  $_G['forum_threadstamp']}-->
                        <div id="threadstamp">
                            <img class="stamp" src="{STATICURL}image/stamp/$_G[forum_threadstamp][url]" title="$_G[forum_threadstamp][text]" />
                        </div>
                    <!--{/if}-->
            </div>
            <div class="wqhead_con">
                <div class="wqname">
                    <a href="{if $post['authorid'] && $post['username'] &&($_G['forum']['ismoderator']||!$post['anonymous'])}{$wq_userurl}{else}javascript:;{/if}" class="width100">
                                <!--{if $post['authorid'] && $post['username'] && !$post['anonymous']}-->
                                    $post[author]
                                <!--{else}-->
                                    <!--{if !$post['authorid']}-->
                                        {lang guest} <em>$post[useip]{if $post[port]}:$post[port]{/if}</em>
                                    <!--{elseif $post['authorid'] && $post['username'] && $post['anonymous']}-->
                                        <!--{if $_G['forum']['ismoderator']}-->{lang anonymous}<!--{else}-->{lang anonymous}<!--{/if}-->
                                    <!--{else}-->
                                        $post[author] <em>{lang member_deleted}</em>
                                    <!--{/if}-->
                                <!--{/if}-->
                            </a>
                              <!--{if $post[gender]}-->
                                <!--{eval $age = !empty($post['birthyear']) ? (intval(date("Y",time())) - $post['birthyear']) + 1 : "";}-->
                            <!--{if $post['gender']==1}-->
                                <span class="wqgender wqman"><i class="wqiconfont2 wqicon2-nan wqapp_f12"></i> {$age}</span>
                            <!--{else}-->
                                <span class="wqgender wqgirl"><i class="wqiconfont2 wqicon2-nv wqapp_f12"></i> {$age}</span>
                            <!--{/if}-->
                            <!--{/if}-->
                            <span class='wqm_left3'>
                                <a href="home.php?mod=spacecp&ac=usergroup{if $_G[uid]!=$post[authorid]}&gid=$post[groupid]{/if}" class="wqapp_f12 dislv_on">
                                       <!--{echo wq_usergroup_show($post[groupid]);}-->
                                </a>
                            </span>
                            <!--{eval $verify = wq_app_get_new_verify($post[authorid],false,2);}-->
                            <!--{if $verify}-->
                                <span class="wqview_uthentication">
                                    <!--{loop $verify['verifyicon'] $vid}-->
                                        <a  href="home.php?mod=spacecp&ac=profile&op=verify&vid=$vid">
                                            <!--{if $_G['setting']['verify'][$vid]['icon']}-->
                                                <img src="{$_G['setting']['verify'][$vid]['icon']}" alt="$_G['setting']['verify'][$vid][title]" title="$_G['setting']['verify'][$vid][title]">
                                            <!--{else}-->
                                                {$_G['setting']['verify'][$vid][title]}
                                            <!--{/if}-->
                                        </a>
                                     <!--{/loop}-->
                                </span>
                            <!--{/if}-->

                        <!--{eval $follow = 0;}-->
                        <!--{eval $follow = C::t('home_follow')->fetch_all_by_uid_followuid($_G['uid'], $post['authorid']);}-->
                        <!--{if !$follow}-->
                                <div class="wqpost_view_follow">
                                    <a href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid={$post['authorid']}&handlekey=add_attention" class="dialog notlogged">
                                     <i class="wqiconfont2 wqicon2-increase wqapp_f13 wqm_right3"></i>{$Tlang['2c8a07313e7706bc']}</a>
                                </div>
                             <!--{else}-->
                             <div class="wqpost_view_follow2">
                                <a href="home.php?mod=spacecp&ac=follow&op=del&hash={FORMHASH}&fuid={$post['authorid']}&handlekey=cancel_attention" class="dialog">
                                <i class="wqiconfont2 wqicon2-o3 wqapp_f13 wqm_right3"></i>{$Tlang['914d2c5341afe66f']}</a>
                             </div>
                          <!--{/if}-->
                  </div>
                <div class="wqdate">$post[dateline]</div>
            </div>
        </div>
     </div>
 <!--{elseif $wq_app_setting['view_view_style'] == 2}-->
 <div class="wqview_seawarp2">
    <div class="wquser_info wqnew_bottom">
            <div class="wqhead_img">
                  <a href="{if $post['authorid'] && $post['username'] &&($_G['forum']['ismoderator']||!$post['anonymous'])}{$wq_userurl}{else}javascript:;{/if}" style="display: initial ">
                        <img class="wqhead" src="{if !$post['authorid'] || $post['anonymous']}{avatar(0, small, true)}{else}{avatar($post[authorid], small, true)}{/if}"/>
                    </a>
                 <!--{if $post['first'] &&  $_G['forum_threadstamp']}-->
                        <div id="threadstamp">
                            <img class="stamp" src="{STATICURL}image/stamp/$_G[forum_threadstamp][url]" title="$_G[forum_threadstamp][text]" />
                        </div>
                    <!--{/if}-->
            </div>
            <div class="wqhead_con">
                <div class="wqname">
                    <a href="{if $post['authorid'] && $post['username'] &&($_G['forum']['ismoderator']||!$post['anonymous'])}{$wq_userurl}{else}javascript:;{/if}" class="width100">
                                <!--{if $post['authorid'] && $post['username'] && !$post['anonymous']}-->
                                    $post[author]
                                <!--{else}-->
                                    <!--{if !$post['authorid']}-->
                                        {lang guest} <em>$post[useip]{if $post[port]}:$post[port]{/if}</em>
                                    <!--{elseif $post['authorid'] && $post['username'] && $post['anonymous']}-->
                                        <!--{if $_G['forum']['ismoderator']}-->{lang anonymous}<!--{else}-->{lang anonymous}<!--{/if}-->
                                    <!--{else}-->
                                        $post[author] <em>{lang member_deleted}</em>
                                    <!--{/if}-->
                                <!--{/if}-->
                            </a>
                              <!--{if $post[gender]}-->
                                <!--{eval $age = !empty($post['birthyear']) ? (intval(date("Y",time())) - $post['birthyear']) + 1 : "";}-->
                            <!--{if $post['gender']==1}-->
                                <span class="wqgender wqman"><i class="wqiconfont2 wqicon2-nan wqapp_f12"></i> {$age}</span>
                            <!--{else}-->
                                <span class="wqgender wqgirl"><i class="wqiconfont2 wqicon2-nv wqapp_f12"></i> {$age}</span>
                            <!--{/if}-->
                            <!--{/if}-->
                            <span class='wqm_left3'>
                                <a href="home.php?mod=spacecp&ac=usergroup{if $_G[uid]!=$post[authorid]}&gid=$post[groupid]{/if}" class="wqapp_f12 dislv_on">
                                       <!--{echo wq_usergroup_show($post[groupid]);}-->
                                </a>
                            </span>
                            <!--{eval $verify = wq_app_get_new_verify($post[authorid],false,2);}-->
                            <!--{if $verify}-->
                                <span class='wqm_left3'>
                                    <!--{loop $verify['verifyicon'] $vid}-->
                                        <a  href="home.php?mod=spacecp&ac=profile&op=verify&vid=$vid">
                                            <!--{if $_G['setting']['verify'][$vid]['icon']}-->
                                                <img src="{$_G['setting']['verify'][$vid]['icon']}" alt="$_G['setting']['verify'][$vid][title]" title="$_G['setting']['verify'][$vid][title]">
                                            <!--{else}-->
                                                {$_G['setting']['verify'][$vid][title]}
                                            <!--{/if}-->
                                        </a>
                                     <!--{/loop}-->
                                </span>
                            <!--{/if}-->
                           <span class="wq_arrow"><a href="{if $post['authorid'] && $post['username'] &&($_G['forum']['ismoderator']||!$post['anonymous'])}{$wq_userurl}{else}javascript:;{/if}" class="wq_grey"> <i class="wqiconfont2 wqicon2-jiantou wqapp_f20"></i></a></span>
                  </div>
            </div>
        </div>
         <!--{if $post[first]}-->
     <div class="wqview_title">
            <h2 class="wqtitle">
                <!--{eval echo discuzcode($_G[forum_thread][subject]);}-->
                <!--{if $_G['forum_thread'][displayorder] == -2}-->
                    <span>({lang moderating})</span>
                <!--{elseif $_G['forum_thread'][displayorder] == -3}-->
                    <span>({lang have_ignored})</span>
                <!--{elseif $_G['forum_thread'][displayorder] == -4}-->
                    <span>({lang draft})</span>
                <!--{/if}--></h2>
        </div>
         <div class="wqdate">$post[dateline]
            <span class="wq_back">
                <a href="forum.php?mod=forumdisplay&fid={$_G['fid']}">
                    <!--{eval echo strip_tags($_G['forum']['name']) ? strip_tags($_G['forum']['name']) : $_G['forum']['name'];}-->
                </a></span>
             <!--{if $wq_app_setting['view_open_promote']}-->
                <span class="y promotionqrcode wqapp_promotionqrcode">{$Tlang['04ce6c956620ce57']}</span>
             <!--{/if}-->
        </div>
    <!--{/if}-->
     </div>
 <!--{elseif $wq_app_setting['view_view_style'] == 3}-->
    <div class="wqview_seawarp3 wqnew_bottom">
    <!--{if $post[first]}-->
     <div class="wqview_title">
            <h2 class="wqtitle">
                <!--{eval echo discuzcode($_G[forum_thread][subject]);}-->
                <!--{if $_G['forum_thread'][displayorder] == -2}-->
                    <span>({lang moderating})</span>
                <!--{elseif $_G['forum_thread'][displayorder] == -3}-->
                    <span>({lang have_ignored})</span>
                <!--{elseif $_G['forum_thread'][displayorder] == -4}-->
                    <span>({lang draft})</span>
                <!--{/if}-->
            </h2>
        </div>
    <!--{/if}-->
    <div class="wquser_info">
            <div class="wqhead_img">
                  <a href="{if $post['authorid'] && $post['username'] &&($_G['forum']['ismoderator']||!$post['anonymous'])}{$wq_userurl}{else}javascript:;{/if}" style="display: initial ">
                        <img class="wqhead" src="{if !$post['authorid'] || $post['anonymous']}{avatar(0, small, true)}{else}{avatar($post[authorid], small, true)}{/if}"/>
                    </a>
                 <!--{if $post['first'] &&  $_G['forum_threadstamp']}-->
                        <div id="threadstamp">
                            <img class="stamp" src="{STATICURL}image/stamp/$_G[forum_threadstamp][url]" title="$_G[forum_threadstamp][text]" />
                        </div>
                    <!--{/if}-->
            </div>
            <div class="wqhead_con">
                <div class="wqname">
                    <a href="{if $post['authorid'] && $post['username'] &&($_G['forum']['ismoderator']||!$post['anonymous'])}{$wq_userurl}{else}javascript:;{/if}" class="width100">
                                <!--{if $post['authorid'] && $post['username'] && !$post['anonymous']}-->
                                    $post[author]
                                <!--{else}-->
                                    <!--{if !$post['authorid']}-->
                                        {lang guest} <em>$post[useip]{if $post[port]}:$post[port]{/if}</em>
                                    <!--{elseif $post['authorid'] && $post['username'] && $post['anonymous']}-->
                                        <!--{if $_G['forum']['ismoderator']}-->{lang anonymous}<!--{else}-->{lang anonymous}<!--{/if}-->
                                    <!--{else}-->
                                        $post[author] <em>{lang member_deleted}</em>
                                    <!--{/if}-->
                                <!--{/if}-->
                            </a>
                              <!--{if $post[gender]}-->
                                <!--{eval $age = !empty($post['birthyear']) ? (intval(date("Y",time())) - $post['birthyear']) + 1 : "";}-->
                            <!--{if $post['gender']==1}-->
                                <span class="wqgender wqman"><i class="wqiconfont2 wqicon2-nan wqapp_f12"></i> {$age}</span>
                            <!--{else}-->
                                <span class="wqgender wqgirl"><i class="wqiconfont2 wqicon2-nv wqapp_f12"></i> {$age}</span>
                            <!--{/if}-->
                            <!--{/if}-->
                            <span>
                                <a href="home.php?mod=spacecp&ac=usergroup{if $_G[uid]!=$post[authorid]}&gid=$post[groupid]{/if}" class="wqapp_f12 dislv_on">
                                       <!--{echo wq_usergroup_show($post[groupid]);}-->
                                </a>
                            </span>
                            <span class="wqthe_landlord_t">
                            <!--{if !empty($postno[$post[number]])}-->$postno[$post[number]]<!--{else}-->{$post[number]}{$postno[0]}<!--{/if}-->
                            </span>

                            <!--{eval $verify = wq_app_get_new_verify($post[authorid],false,2);}-->
                            <!--{if $verify}-->
                                <span class='wqm_left3'>
                                    <!--{loop $verify['verifyicon'] $vid}-->
                                        <a  href="home.php?mod=spacecp&ac=profile&op=verify&vid=$vid">
                                            <!--{if $_G['setting']['verify'][$vid]['icon']}-->
                                                <img src="{$_G['setting']['verify'][$vid]['icon']}" alt="$_G['setting']['verify'][$vid][title]" title="$_G['setting']['verify'][$vid][title]">
                                            <!--{else}-->
                                                {$_G['setting']['verify'][$vid][title]}
                                            <!--{/if}-->
                                        </a>
                                     <!--{/loop}-->
                                </span>
                            <!--{/if}-->

                          <!--{if !IS_ROBOT && !$_GET['authorid'] && !$_G['forum_thread']['archiveid']}-->
                        <em class="y"><a href="forum.php?mod=viewthread&tid=$_G[tid]&page=$page&authorid=$_G[forum_thread][authorid]" rel="nofollow" class="wqsee_landlord">{lang viewonlyauthorid}</a></em>
                        <!--{elseif !$_G['forum_thread']['archiveid']}-->
                        <em class="y"><a href="forum.php?mod=viewthread&tid=$_G[tid]&page=$page" rel="nofollow" class="wqsee_landlord">{lang thread_show_all}</a></em>
                        <!--{/if}-->
                  </div>
                <div class="wqdate">$post[dateline]
                    <!--{if $wq_app_setting['view_open_promote']}-->
                        <span class="y wqm_left15 wqapp_f12 promotionqrcode wqapp_promotionqrcode">{$Tlang['04ce6c956620ce57']}</span>
                    <!--{/if}-->
                    <span class="y wqm_left15">
                        <i class="wqiconfont2 wqicon2-pinglun2 wqapp_f13"></i>{$thread[replies]}</span>
                        <span class="y">
                       <i class="wqiconfont2 wqicon2-p-see wqapp_f15"></i>{$thread[views]}</span>

                </div>
            </div>
        </div>
     </div>
  <!--{/if}-->

<!--{subtemplate forum/viewthread_public}-->
    <div class="wqseparate2" id="wqall_comment"></div>
    <div class="wqposts_atom">
       <h3 class="wqnew_bottom"><a href="javascript:;" class="wqborder_bottom wqcolor wqnew_bottom_bule">{$Tlang['4bc7b967c326c87e']}</a>
       <span>
           <!--{if $_GET['ordertype']== "1"}-->
           <a href="forum.php?mod=viewthread&tid={$_G['tid']}&extra={$_GET['extra']}#order"><i class="wqiconfont2 wqicon2-desc"></i>{$Tlang['e0b0f25d9c69d8e2']}</a>
            <!--{else}-->
            <a href="forum.php?mod=viewthread&tid={$_G['tid']}&extra={$_GET['extra']}&ordertype=1#order"><i class="wqiconfont2 wqicon2-just"></i>{$Tlang['fe87c0c04d9f5a58']}</a>
            <!--{/if}-->
       </span>
       </h3>
       <!--{if $post['first'] && $_G[forum_thread][special] == 5 && $_G[forum_thread][displayorder] >= 0}-->
        <div class="wqdebate_opposite">
            <ul class="ttp cl">
                <li style="display:inline;margin-left:12px">{lang debate_filter}:</li>
                <li{if !isset($_GET['stand'])} class="xw1 wqon"{/if}><a href="forum.php?mod=viewthread&tid=$_G[tid]&extra=$_GET[extra]" hidefocus="true">{lang all}</a></li>
                <li{if $_GET['stand'] == 1} class="xw1 wqon"{/if}><a href="forum.php?mod=viewthread&tid=$_G[tid]&extra=$_GET[extra]&stand=1" hidefocus="true">{lang debate_square}</a></li>
                <li{if $_GET['stand'] == 2} class="xw1 wqon"{/if}><a href="forum.php?mod=viewthread&tid=$_G[tid]&extra=$_GET[extra]&stand=2" hidefocus="true">{lang debate_opponent}</a></li>
                <li{if isset($_GET['stand']) && $_GET['stand'] == 0} class="xw1 wqon"{/if}><a href="forum.php?mod=viewthread&tid=$_G[tid]&extra=$_GET[extra]&stand=0" hidefocus="true">{lang debate_neutral}</a></li>
            </ul>
        </div>
       <!--{/if}-->
   </div>



<!--{/if}-->