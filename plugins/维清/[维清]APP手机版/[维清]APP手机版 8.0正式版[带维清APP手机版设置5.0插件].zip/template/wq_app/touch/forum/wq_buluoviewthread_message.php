<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['wq_buluoviewthread_message'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<div class="message {if !$post[first]}p_l0 wq_view_message{/if}">
    <!--{if !$post['first']}-->
    <!--{eval $post[message]=_buluo_wq_str_replace_message($post[message]);}-->
    <!--{else}-->
    <!--{eval $post[message]=_buluo_preg_replace_br($post[message]);}-->
    <!--{/if}-->
    $_G['forum_posthtml']['header'][$post[pid]]
    <!--{if $post['warned']}-->
    <span class="grey quote">{lang warn_get}</span>
    <!--{/if}-->
    <!--{if !$post['first'] && !empty($post[subject])}-->
    <h2><strong>$post[subject]</strong></h2>
    <!--{/if}-->
    <!--{if $_G['adminid'] != 1 && $_G['setting']['bannedmessages'] & 1 && (($post['authorid'] && !$post['username']) || ($post['groupid'] == 4 || $post['groupid'] == 5) || $post['status'] == -1 || $post['memberstatus'])}-->
    <div class="grey quote">{lang message_banned}</div>
    <!--{elseif $_G['adminid'] != 1 && $post['status'] & 1}-->
    <div class="grey quote">{lang message_single_banned}</div>
    <!--{elseif $needhiddenreply}-->
    <div class="grey quote">{lang message_ishidden_hiddenreplies}</div>
    <!--{elseif $post['first'] && $_G['forum_threadpay']}-->
    <!--{template forum/wq_buluoviewthread_pay}-->
    <!--{else}-->
    <!--{if $_G['setting']['bannedmessages'] & 1 && (($post['authorid'] && !$post['username']) || ($post['groupid'] == 4 || $post['groupid'] == 5))}-->
    <div class="grey quote">{lang admin_message_banned}</div>
    <!--{elseif $post['status'] & 1}-->
    <div class="grey quote">{lang admin_message_single_banned}</div>
    <!--{/if}-->
    <!--{if $post[first]&&$_G['forum_thread']['price'] > 0 && $_G['forum_thread']['special'] == 0 && empty($previewspecial)}-->
    <div class="m_t10 locked">{lang pay_threads}: <strong>$_G[forum_thread][price] {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][title]} </strong>
    <a id="pay_view" href="forum.php?mod=misc&action=viewpayments&tid=$_G[tid]" >{lang pay_view}</a></div>
    <script type="text/javascript" reload="1">
        $('#pay_view').click(function () {
            var obj = $(this);
            $.ajax({
                type: 'POST',
                url: obj.attr('href') + '&inajax=1',
                data: {},
                dataType: 'html'
            }).success(function (s) {
                popup.open(wqXml(s));
            }).error(function () {
                window.location.href = obj.attr('href');
                popup.close();
            });
            return false;
        });
    </script>
    <!--{/if}-->

    <!--{if $post['first'] && $threadsort && $threadsortshow}-->
    <!--{if $threadsortshow['optionlist'] && !($post['status'] & 1) && !$_G['forum_threadpay']}-->
    <!--{if $threadsortshow['optionlist'] == 'expire'}-->
    {lang has_expired}
    <!--{else}-->
    <div class="box_ex2 viewsort">
        <table>

            <!--{loop $threadsortshow['optionlist'] $option}-->
            <tr class="b_bottom">
                <!--{if $option['type'] != 'info'}-->
                <th> $option[title]:</th>
                <td>
                    <!--{if $option['value']}-->
                    <!--{if $option['type']== 'image'}-->
                    <!--{eval preg_match("/href=\"(.*)\"\s+target/ies", $option[value], $threadsortshow_img);}-->
                    <img src="{if $threadsortshow_img}$threadsortshow_img[1]{else}$option[value]{/if}"><!--{else}-->$option[value]<!--{/if}--> $option[unit]
                    <!--{else}--><span class="grey">--</span><!--{/if}--></td>
                <!--{/if}-->
            </tr>
            <!--{/loop}-->
        </table>
    </div>
    <!--{/if}-->
    <!--{/if}-->
    <!--{/if}-->
    <!--{if $post['first']}-->
    <!--{if !$_G[forum_thread][special]}-->
    <!--{eval $post[message] = str_replace('smilieid="','class="wq_smiley" smilieid="',$post[message]);}-->
    <div class="m_t10">$post[message]</div>
    <!--{elseif $_G[forum_thread][special] == 1}-->
    <!--{template forum/wq_buluoviewthread_poll}-->
    <!--{elseif $_G[forum_thread][special] == 2}-->
    <!--{template forum/wq_buluoviewthread_trade}-->
    <!--{elseif $_G[forum_thread][special] == 3}-->
    <!--{template forum/wq_buluoviewthread_reward}-->
    <!--{elseif $_G[forum_thread][special] == 4}-->
    <!--{template forum/wq_buluoviewthread_activity}-->
    <!--{elseif $_G[forum_thread][special] == 5}-->
    <!--{template forum/wq_buluoviewthread_debate}-->
    <!--{elseif $threadplughtml}-->
    $threadplughtml
    <!--{eval $post[message] = str_replace('smilieid="','class="wq_smiley" smilieid="',$post[message]);}-->
    $post[message]
    <!--{else}-->
    <!--{eval $post[message] = str_replace('smilieid="','class="wq_smiley" smilieid="',$post[message]);}-->
    $post[message]
    <!--{/if}-->
    <!--{else}-->
    <!--{eval $post[message] = str_replace('smilieid="','class="wq_smiley" smilieid="',$post[message]);}-->
    $post[message]
    <!--{/if}-->

    <!--{/if}-->
</div>
<!--{if $_G['setting']['mobile']['mobilesimpletype'] == 0}-->
<!--{if $post['attachment']}-->
<div class="grey quote annex_no">
    {lang attachment}: <em><!--{if $_G['uid']}-->{lang attach_nopermission}<!--{else}-->{lang attach_nopermission_login}<!--{/if}--></em>
</div>
<!--{elseif $post['imagelist'] || $post['attachlist']}-->
<!--{if $post['imagelist']}-->
<!--{if count($post['imagelist']) == 1}-->
<ul class="img_one">{echo showattach($post, 1)}</ul>
<!--{else}-->
<ul class="img_list cl vm">{echo showattach($post, 1)}</ul>
<!--{/if}-->
<!--{/if}-->
<!--{if $post['attachlist']}-->
<ul>{echo showattach($post)}</ul>
<!--{/if}-->
<!--{/if}-->
<!--{/if}-->
<!--{/if}-->