<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['post'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{if $_GET['type'] == 'wq_buluo'}-->
    <!--{template forum/wq_buluopost}-->
    <!--{eval exit;}-->
<!--{/if}-->

<!--{if !$wqfollow_post}-->
<!--{template common/header}-->
<!--{/if}-->
<!--{eval $adveditor = $isfirstpost && $special && ($_GET['action'] == 'newthread' || $_GET['action'] == 'reply' && !empty($_GET['addtrade']) || $_GET['action'] == 'edit' );}-->

<form method="post"
			{if $_GET[action] == 'newthread'} id="postform" action="forum.php?mod=post&action={if $special != 2}newthread{else}newtrade{/if}&fid=$_G[fid]&extra=$extra&topicsubmit=yes"
			{elseif $_GET[action] == 'reply'} id="{if $_GET[route] == 'w'}postform_w{else}postform{/if}" action="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&extra=$extra&replysubmit=yes"
			{elseif $_GET[action] == 'edit'} id="postform" action="forum.php?mod=post&action=edit&extra=$extra&editsubmit=yes" $enctype
                        {elseif $_GET[action] == 'publish'} id="follow" action="home.php?mod=spacecp&ac=follow&op=newthread&topicsubmit=yes&infloat=yes"
                        {/if}>
<input type="hidden" name="formhash" id="formhash" value="{FORMHASH}" />
<input type="hidden" name="posttime" id="posttime" value="{TIMESTAMP}" />
<input type="hidden" name="fid" id="fid" value="$_G[fid]" />
<!--{if !empty($_GET['modthreadkey'])}--><input type="hidden" name="modthreadkey" id="modthreadkey" value="$_GET['modthreadkey']" /><!--{/if}-->
<!--{if $_GET[action] == 'reply'}-->
    <input type="hidden" name="noticeauthor" value="$noticeauthor" />
    <input type="hidden" name="noticetrimstr" value="$noticetrimstr" />
    <input type="hidden" name="noticeauthormsg" value="$noticeauthormsg" />
    <!--{if $reppid}-->
        <input type="hidden" name="reppid" value="$reppid" />
    <!--{/if}-->
    <!--{if $_GET[reppost]}-->
        <input type="hidden" name="reppost" value="$_GET[reppost]" />
    <!--{elseif $_GET[repquote]}-->
        <input type="hidden" name="reppost" value="$_GET[repquote]" />
    <!--{/if}-->
<!--{/if}-->
<!--{if $_GET[action] == 'edit'}-->
    <input type="hidden" name="tid" value="$_G[tid]" />
    <input type="hidden" name="pid" value="$pid" />
    <input type="hidden" name="page" value="$_GET[page]" />
<!--{/if}-->

<!--{if $special}-->
    <input type="hidden" name="special" value="$special" />
<!--{/if}-->
<!--{if $specialextra}-->
    <input type="hidden" name="specialextra" value="$specialextra" />
<!--{/if}-->
<!--{if $_GET[action] == 'publish'}-->
<input type="hidden" name="usesig" value="$usesigcheck" />
<input type="hidden" name="adddynamic" value="1" />
<input type="hidden" name="addfeed" value="1" />
<input type="hidden" name="topicsubmit" value="true" />
<input type="hidden" name="referer" value="{echo dreferer()}" />
<!--{/if}-->
<!-- header start -->
<!--{if $_G['inajax']}-->
<div class="wq_weixin_warp">
<!--{/if}-->
    <!--{if $_GET['action'] == 'newthread'}-->
    <!--{eval $headparams['cname'] = strip_tags($_G['forum']['name']) ? strip_tags($_G['forum']['name']) : $_G['forum']['name'];}-->
    <!--{/if}-->
    <!--{if $_GET['action'] ==  'edit'}-->
     <!--{eval $headparams['cname'] = $Tlang['eca1c350f9aec30a'];}-->
    <!--{/if}-->
    <!--{if $_GET['action'] == 'reply'}-->
        <!--{eval $headparams['cname'] = $Tlang['dbedca5ca18ae5c8'];}-->
    <!--{/if}-->
    <!--{if $_GET[action] == 'publish'}-->
        <!--{eval $headparams['cname'] = $Tlang['b86266df3f6307ac'];}-->
   <!--{/if}-->
    <!--{if $_G['inajax']}-->
        <!--{eval
            $headparams['lurl']='javascript:;';
            $headparams['lclass'] = 'wqweixin_cancel';
            $headparams['lextra'] = 'onclick="popup.close()"';
        }-->
    <!--{else}-->
        <!--{eval
            $headparams['lurl']='forum.php?mod=post&action=newthread&fid='.$_G['fid'].'&dialog=dialog';
            $headparams['lclass']= 'wqcancel';
            $headparams['lextra']='';
        }-->
    <!--{/if}-->
    <!--{eval
        $headparams['wtype'] = '1';
        $headparams['ltype'] = 'a';

        echo wq_app_get_header($headparams);
    }-->



<!-- header end -->
<!-- main postbox start -->
<!--{eval $postspecialcheck = get_postspecialcheck($postspecialcheck);}-->
<!--{if $_GET[action] == 'newthread'}-->
    <!--{eval $post_nav_num=0;$postform_nav_li='';}-->

    <!--{if !$_G['forum']['threadsorts']['required'] && !$_G['forum']['allowspecialonly']}-->
    <!--{eval $postform_nav_li.='<li><a '.$postspecialcheck[0].' href="forum.php?mod=post&action=newthread&fid='.$_G['fid'].'">&#x5E16;&#x5B50;</a></li>';$post_nav_num++;}-->
    <!--{/if}-->

    <!--{if $_G['group']['allowpostpoll']}-->
    <!--{eval $postform_nav_li.=' <li><a '.$postspecialcheck[1].' href="forum.php?mod=post&action=newthread&special=1&fid='.$_G['fid'].'">&#x6295;&#x7968;</a></li>';$post_nav_num++;}-->
    <!--{/if}-->

    <!--{if $_G['group']['allowpostreward']}-->
    <!--{eval $postform_nav_li.=' <li><a '.$postspecialcheck[3].' href="forum.php?mod=post&action=newthread&special=3&fid='.$_G['fid'].'">&#x60AC;&#x8D4F;</a></li>';$post_nav_num++;}-->
    <!--{/if}-->

    <!--{if $_G['group']['allowpostdebate']}-->
    <!--{eval $postform_nav_li.=' <li><a '.$postspecialcheck[5].' href="forum.php?mod=post&action=newthread&special=5&fid='.$_G['fid'].'">&#x8FA9;&#x8BBA;</a></li>';$post_nav_num++;}-->
    <!--{/if}-->

    <!--{if $_G['group']['allowpostactivity']}-->
    <!--{eval $postform_nav_li.=' <li><a '.$postspecialcheck[4].' href="forum.php?mod=post&action=newthread&special=4&fid='.$_G['fid'].'">&#x6D3B;&#x52A8;</a></li>';$post_nav_num++;}-->
    <!--{/if}-->

    <!--{if $_G['group']['allowposttrade']}-->
    <!--{eval $postform_nav_li.=' <li><a '.$postspecialcheck[2].' href="forum.php?mod=post&action=newthread&special=2&fid='.$_G['fid'].'">&#x51FA;&#x552E;</a></li>';$post_nav_num++;}-->
    <!--{/if}-->

    <!--{loop $_G['forum']['threadsorts'][types] $tsortid $name}-->
    <!--{eval $postform_nav_li.=' <li><a '.($sortid == $tsortid?' class="wqcolor wqborder_bottom"':'').' href="forum.php?mod=post&action=newthread&sortid='.$tsortid.'&fid='.$_G['fid'].'">'. strip_tags($name).'</a></li>';$post_nav_num++;}-->
    <!--{/loop}-->
    <!--{if $postform_nav_li}-->
    <div class="my_post_roll wqnew_bottom slide-stop" id="my_post_roll">
        <div class="tag_list">
            <ul>$postform_nav_li</ul>
        </div>
    </div>
    <!--{/if}-->

    <!--{/if}-->
    <!--{eval $my_roll_tag='my_post_roll';}-->
    <!--{template common/slide}-->
    <div class="wqpost_list">
        <ul class="wqpost_list_ul">
            <!--{if !$isfirstpost && $thread[special] == 5 && empty($firststand)}-->
                <li class="wqnew_bottom">
                    <select id="stand" name="stand"class="wqpost_select">
                        <option value="">{lang debate_viewpoint}</option>
                        <option value="0">{lang debate_neutral}</option>
                        <option value="1"{if $stand == 1} selected{/if}>{lang debate_square}</option>
                        <option value="2"{if $stand == 2} selected{/if}>{lang debate_opponent}</option>
                    </select>
                    <script type="text/javascript" reload="1">simulateSelect('stand');</script>
		 </li>
            <!--{/if}-->

            <!--{if $isfirstpost && !empty($_G['forum'][threadtypes][types])}-->
                <li class="wqnew_bottom">
                    <select id="typeid" name="typeid" class="wqpost_select">
                        <option value="0" selected="selected">{lang select_thread_catgory}</option>
                        <!--{loop $_G['forum'][threadtypes][types] $typeid $name}-->
                        <!--{if empty($_G['forum']['threadtypes']['moderators'][$typeid]) || $_G['forum']['ismoderator']}-->
                        <option value="$typeid"{if $thread['typeid'] == $typeid || $_GET['typeid'] == $typeid} selected="selected"{/if}><!--{echo strip_tags($name);}--></option>
                        <!--{/if}-->
                        <!--{/loop}-->
                    </select>
                </li>
            <!--{/if}-->
            <!--{if $sortid}-->
            <input type="hidden" name="sortid" value="$sortid" />
            <!--{/if}-->
            <li class="wqnew_bottom" <!--{if $_GET[action] == 'publish'}-->style="display:none;"<!--{/if}-->>
            <!--{if $_GET['action'] != 'reply'}-->
                <input type="text" tabindex="1" class="wqpost_input" id="needsubject" size="30" autocomplete="off" value="$postinfo[subject]" name="subject" placeholder="{lang thread_subject}" fwin="login">
            </li>
           <!--{hook/post_bottom_mobile}-->
            <!--{if $_G[forum_thread][special] == 5 && empty($firststand)}-->
            <li class="point_view wqnew_bottom">
                <select id="stand" name="stand">
                    <option value="">{lang debate_viewpoint}</option>
                    <option value="0"<!--{if $_GET[stand] == '0'}--> selected="selected"<!--{/if}-->>{lang debate_neutral}</option>
                    <option value="1"<!--{if $_GET[stand] == '1'}--> selected="selected"<!--{/if}-->>{lang debate_square}</option>
                    <option value="2"<!--{if $_GET[stand] == '2'}--> selected="selected"<!--{/if}-->>{lang debate_opponent}</option>
                </select>
            </li>
            <!--{/if}-->
            <!--{eval get_specialtpl($Tlang)}-->
            <!--{else}-->
                RE: $thread['subject']
                <!--{if $quotemessage}-->$quotemessage<!--{/if}-->
        </li>
                <!--{hook/post_bottom_wq_mobile}-->
            <!--{/if}-->

            <li class="post_con wqnew_bottom">
                <textarea class="wqpost_textarea" id="needmessage" tabindex="3" autocomplete="off" id="{$editorid}_textarea" name="<!--{if $_GET[action] == 'publish'}-->message<!--{else}-->$editor[textarea]<!--{/if}-->" cols="80" rows="2"  placeholder="{lang thread_content}" fwin="reply" style="display: none;">$postinfo[message]</textarea>
                <!--{eval $postinfo[message]=wq_app_edit_message($postinfo[message],$postinfo[pid]); }-->
                <div class="wqeditarea" contenteditable="true" placeholder="{$Tlang['70ad0bcbf2229f1d']}">$postinfo[message]</div>
                <!--{if $_GET[action] == 'edit' && $isorigauthor && ($isfirstpost && $thread['replies'] < 1 || !$isfirstpost) && !$rushreply && $_G['setting']['editperdel']}-->
                <div class="wq_delete_post">
                    <input type="checkbox" name="delete" id="delete" class="weui_check y" value="1" title="{lang post_delpost}{if $thread[special] == 3}{lang reward_price_back}{/if}">
                    <label class="weui_check_label y" for="weiqing_delete"><i class="weui_icon_checked"></i>{$Tlang['1043019631627d72']}</label>
                </div>
                <!--{/if}-->
                <div class="wqpost_upload">
                    <div class="tag_list">
                        <ul>
                            <li data-type="biaoqing"><span class="wqiconfont2 wqicon2-biaoqing wqapp_f26 wqbiaoqing" onclick="_type_select(this,'biaoqing')"></span></li>
                             <!--{if !$_GET['route'] && $_GET['route']!='w'}-->
                                    <li data-type="tupian1">
                                        <a href="javascript:;" class="wqiconfont2 wqicon2-tupian1 wqapp_f26">
                                        <input type="button" id="file_button"  class="wqfiledata">
                                        <input type="file" name="Filedata"  id="filedata"  multiple="multiple" style="display:none" accept="image/*" />
                                        <i class="wqtoday" style="display: none">0</i>
                                    </a>
                                    </li>
                                    <li data-type="shezhi3"><span class="wqiconfont2 wqapp_f26 wqicon2-shezhi3 wqshezhi3" onclick="_type_select(this,'shezhi3')"></span></li>
                                <!--{if $_GET['action'] == 'newthread'}-->
                                    <li data-type="qianglou"><span class="wqiconfont2 wqapp_f26 wqicon2-qianglou wqqianglou" onclick="_type_select(this,'qianglou')"></span></li>
                                <!--{/if}-->
                                <li data-type="icon-test"><span class="wqiconfont2 wqapp_f26 wqicon2-icon-test wqicon-test" onclick="_type_select(this,'icon-test')"></span></li>
                                <!--{if $_G['forum']['allowmediacode'] && $_G['group']['allowmediacode']}-->
                                    <li data-type="shipin"><span class="wqiconfont2 wqapp_f26 wqicon2-shipin wqshipin" onclick="_type_select(this,'shipin')"></span></li>
                                <!--{/if}-->
                                <!--{if $_G['group']['allowpostattach']}-->
                                        <!--{if !empty($attachs['used'])}-->
                                            <!--{eval $wqattachlist = $attachs['used'];$wqattachcount=count($wqattachlist)}-->
                                        <!--{/if}-->
                                        <li data-type="fujian"><span class="wqiconfont2 wqapp_f26 wqicon2-fujian wqfujian" onclick="_type_select(this,'fujian')"></span>
                                        <i id="wqapp_fujian_chk" class="wqfujian2{if $wqattachlist <= 0} none{/if}">!</i>
                                    </li>
                                <!--{/if}-->
                                <!--{if ($_GET[action] == 'newthread' || $_GET[action] == 'reply' || $_GET[action] == 'edit') && $_G['group']['allowat']}-->
                                    <li data-type="at"><span class="wqiconfont2 wqapp_f26 wqicon2-at wqat" onclick="_type_select(this,'at')"></span></li>
                                <!--{/if}-->
                                <!--{if $_G['group']['allowposttag']}-->
                                <li data-type="tag2">
                                    <span class="wqiconfont2 wqapp_f26 wqicon2-tag2 wqtag2" onclick="_type_select(this,'tag2')">
                                        <i id="wqapp_tag_chk" class="wqtag{if !$postinfo[tag]} none{/if}"></i>
                                    </span>
                                </li>
                                <!--{/if}-->
                                <li data-type="fabu"><span class="wqiconfont2 wqapp_f26 wqicon2-fabu wqfabu" onclick="_type_select(this,'fabu')"></span></li>
                            <!--{/if}-->
                        </ul>
                    </div>
                    <!--{eval $my_roll_tag='wqpost_upload';}-->
                    <!--{template common/slide}-->
            </li>
        </ul>
        <!--{template common/upload_image}-->
        <!--{if $_GET[action] != 'edit' && ($secqaacheck || $seccodecheck)}-->
        <!--{subtemplate common/seccheck}-->
        <!--{/if}-->
        <!--{template common/smilies}-->
        <div class="wqpost_shezhi_warp showHide_shezhi3">
            <ul>
                <!--{if $_GET[action] != 'edit'}-->
                <!--{if $_G['group']['allowanonymous']}--><li class="wqnew_bottom"><input type="checkbox" name="isanonymous" id="isanonymous" class="weui_check" value="1" /><label for="isanonymous" class="weui_check_label"><i class="weui_icon_checked"></i>{lang post_anonymous}</label></li><!--{/if}-->
                <!--{else}-->
                        <!--{if $_G['group']['allowanonymous'] || (!$_G['group']['allowanonymous'] && $orig['anonymous'])}--><li><input type="checkbox" name="isanonymous" id="isanonymous" class="weui_check" value="1" {if $orig['anonymous']}checked="checked"{/if} /><label for="isanonymous" class="weui_check_label"><i class="weui_icon_checked"></i>{lang post_anonymous}</label></li><!--{/if}-->
                <!--{/if}-->
                <!--{if $_GET[action] == 'newthread' || $_GET[action] == 'edit' && $isfirstpost}-->
                        <li class="wqnew_bottom"><input type="checkbox" name="hiddenreplies" id="hiddenreplies" class="weui_check"{if $thread['hiddenreplies']} checked="checked"{/if} value="1"><label for="hiddenreplies" class="weui_check_label"><i class="weui_icon_checked"></i>{lang hiddenreplies}</label></li>
                <!--{/if}-->
                <!--{if $_G['uid'] && ($_GET[action] == 'newthread' || $_GET[action] == 'edit' && $isfirstpost) && $special != 3}-->
                        <li class="wqnew_bottom"><input type="checkbox" name="ordertype" id="ordertype" class="weui_check" value="1" $ordertypecheck /><label for="ordertype" class="weui_check_label"><i class="weui_icon_checked"></i>{lang post_descviewdefault}</label></li>
                <!--{/if}-->
                <!--{if ($_GET[action] == 'newthread' || $_GET[action] == 'edit' && $isfirstpost)}-->
                        <li class="wqnew_bottom"><input type="checkbox" name="allownoticeauthor" id="allownoticeauthor" class="weui_check" value="1"{if $allownoticeauthor} checked="checked"{/if} /><label for="allownoticeauthor" class="weui_check_label"><i class="weui_icon_checked"></i>{lang post_noticeauthor}</label></li>
                <!--{/if}-->
                <!--{if $_GET[action] != 'edit' && helper_access::check_module('feed') && $_G['forum']['allowfeed']}-->
                        <li class="wqnew_bottom"><input type="checkbox" name="addfeed" id="addfeed" class="weui_check" value="1" $addfeedcheck><label for="addfeed" class="weui_check_label"><i class="weui_icon_checked"></i>{lang addfeed}</label></li>
                <!--{/if}-->
                <li class="wqnew_bottom"><input type="checkbox" name="usesig" id="usesig" class="weui_check" value="1" {if !$_G['group']['maxsigsize']}disabled {else}$usesigcheck {/if}/><label for="usesig" class="weui_check_label"><i class="weui_icon_checked"></i>{lang post_show_sig}</label></li>
                <!--{if $_GET[action] == 'newthread' && $_G['forum']['ismoderator'] && ($_G['group']['allowdirectpost'] || !$_G['forum']['modnewposts'])}-->
                    <!--{if $_GET[action] == 'newthread' && $_G['forum']['ismoderator'] && ($_G['group']['allowdirectpost'] || !$_G['forum']['modnewposts']) && ($_G['group']['allowstickthread'] || $_G['group']['allowdigestthread'])}-->
                            <!--{if $_G['group']['allowstickthread']}-->
                                <li class="wqnew_bottom"><input type="checkbox" name="sticktopic" id="sticktopic" class="weui_check" value="1" $stickcheck /><label for="sticktopic" class="weui_check_label"><i class="weui_icon_checked"></i>{lang post_stick_thread}</label></li>
                            <!--{/if}-->
                            <!--{if $_G['group']['allowdigestthread']}-->
                                <li class="wqnew_bottom"><input type="checkbox" name="addtodigest" id="addtodigest" class="weui_check" value="1" $digestcheck /><label for="addtodigest" class="weui_check_label"><i class="weui_icon_checked"></i>{lang post_digest_thread}</label></li>
                            <!--{/if}-->
                    <!--{/if}-->
            <!--{elseif $_GET[action] == 'edit' && $_G['forum_auditstatuson']}-->
            <li class="wqnew_bottom"><input type="checkbox" name="audit" id="audit" class="weui_check" value="1"><label for="audit" class="weui_check_label"><i class="weui_icon_checked"></i>{lang auditstatuson}</label></li>
            <!--{/if}-->
            </ul>
        </div>
        <div class="wqpost_data showHide_qianglou" id="extra_rushreplyset_c">
            <ul>
               <li class="wqnew_bottom">
                    <span class="text_left" style="margin-left: 0">
                        <input type="checkbox" name="rushreply" id="rushreply" class="weui_check" value="1" {if $_GET[action] == 'edit' && getstatus($thread['status'], 3)}disabled="disabled" checked="checked"{/if} />
                        <label class="weui_check_label wqblock" for="rushreply"><i class="weui_icon_checked"></i>{lang rushreply_change}</label>
                    </span>
                </li>
                <li class="wqnew_bottom">
                    <em>{$Tlang['765c1cef187814dc']}</em>
                    <span class="text_left">
                        <input type="text" name="rushreplyfrom" id="rushreplyfrom" readonly onfocus="this.blur();" class="px wq_inputtime muidate" autocomplete="off" value="$postinfo[rush][starttimefrom]" onkeyup="$('#rushreply').checked = true;" />
                        <span> ~ </span>
                        <input type="text" name="rushreplyto" id="rushreplyto" readonly onfocus="this.blur();" class="px wq_inputtime muidate" autocomplete="off" value="$postinfo[rush][starttimeto]" onkeyup="$('#rushreply').checked = true;" />
                    </span>
                </li>
                <li class="wqnew_bottom">
                    <em>{$Tlang['01d93c34df528270']}</em>
                    <span class="text_left">
                        <input type="text" name="rewardfloor" id="rewardfloor" class="px oinf" value="$postinfo[rush][rewardfloor]" placeholder="{$Tlang['a1565e6581ecb06b']}" onkeyup="$('rushreply').checked = true;" />
                    </span>
                </li>
                <li class="wqnew_bottom">
                    <em>{lang stopfloor}</em>
                    <span class="text_left"><input type="text" name="replylimit" id="replylimit" class="px" autocomplete="off" value="$postinfo[rush][replylimit]" placeholder="{lang replylimit}" onkeyup="$('rushreply').checked = true;" /></span>
                </li>
                <li class="wqnew_bottom">
                    <em>{$Tlang['66a6e4b950b92dee']}</em>
                    <span class="text_left"><input type="text" name="stopfloor" id="stopfloor" class="px" autocomplete="off" value="$postinfo[rush][stopfloor]" placeholder="{$Tlang['6fca5502a0949f66']}"onkeyup="$('rushreply').checked = true;" /></span>
                </li>
                <li class="wqnew_bottom">
                    <em><!--{if $_G['setting']['creditstransextra'][11]}-->{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][11]][title]}<!--{else}-->{lang credits}<!--{/if}-->{lang min_limit}</em>
                    <span class="text_left">
                        <input type="text" name="creditlimit" id="creditlimit" class="px" autocomplete="off" value="$postinfo[rush][creditlimit]" placeholder="<!--{if $_G['setting']['creditstransextra'][11]}-->({$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][11]][title]})<!--{else}-->{lang total_credits}<!--{/if}-->{lang post_rushreply_credit}" onkeyup="$('rushreply').checked = true;" />
                    </span>
                </li>
            </ul>
        </div>
        <div class="wqapp_music_warp showHide_icon-test">
            <p class="wqnew_bottom"><input type="text" name="music" data-type='music' placeholder="{$Tlang['3a517db61c12d78d']}" class="wqadd_music"/><span class="wqapp_add wqbg_color wqapp_insert_data" data-class="wqadd_music">{$Tlang['b7d63548f8406158']}</span></p>
            <p class="wqbg_ys wqnew_bottom">{$Tlang['665cf93f9507f1d8']}</p>
        </div>
        <div class="wqapp_video_warp showHide_shipin">
            <p class="wqnew_bottom"><input type="text" name="video" data-type='video' placeholder="{$Tlang['6421fe2dfd302da0']}" class="wqadd_video"/><span class="wqapp_add wqbg_color wqapp_insert_data" data-class="wqadd_video">{$Tlang['b7d63548f8406158']}</span></p>
            <p class="wqbg_ys wqnew_bottom">{$Tlang['db94b969e775b5bb']}</p>
        </div>
         <div class="wqapp_tag_warp showHide_tag2">
            <p class="wqnew_bottom"><input type="text" id="tags" name="tags" value="$postinfo[tag]" placeholder="{$Tlang['a6d1586b56f1ccea']}" /><span class="wqapp_add wqbg_color wqapp_auto_get_tag">{$Tlang['202248784b6161e7']}</span></p>
            <p class="wqbg_ys wqnew_bottom">{$Tlang['6a673f6e97c16abb']}</p>
        </div>
         <div class="wqapp_at_warp showHide_at">
             <p class="wqnew_bottom"><input type="text" name="" placeholder="{$Tlang['2aef1a750edcec42']}" class="wqadd_at"/><span class="wqapp_add wqbg_color wqapp_insert_data" data-class="wqadd_at">{$Tlang['b7d63548f8406158']}</span></p>
             <p class="wqbg_ys wqnew_bottom">{$Tlang['de094091d497daf1']}</p>
        </div>

         <div class="wqapp_insert_warp showHide_fabu">
             <ul>
                 <li data-type="url"><a href="javascript:;" class="wqdel_url wq_on" onclick="_type_select(this,'url',true)">{$Tlang['351670232f6eb56f']}</a></li>
                 <li data-type="image"><a href="javascript:;" class="wqdel_image" onclick="_type_select(this,'image',true)">{$Tlang['b5092d651ab31c62']}</a></li>
                 <li data-type="flash"><a href="javascript:;" class="wqdel_flash" onclick="_type_select(this,'flash',true)">Flash</a></li>
                 <li data-type="quote"><a href="javascript:;" class="wqdel_quote" onclick="_type_select(this,'quote',true)">{$Tlang['5773bb3070e29d45']}</a></li>
                 <li data-type="code"><a href="javascript:;" class="wqdel_code" onclick="_type_select(this,'code',true)">{$Tlang['042c964768f8dd1d']}</a></li>
                 <li data-type="free"><a href="javascript:;" class="wqdel_free" onclick="_type_select(this,'free',true)">{$Tlang['8336198517717dab']}</a></li>
             </ul>
             <div class="wqseparate"></div>
             <div class="wq_insert_pop showHide_url">
                <p class="wqnew_bottom"><input type="text" name="" placeholder="{$Tlang['c8a59624a2a2492c']}" style="width: 100%;" class="wqadd_url"/></p>
                <p class="wqnew_bottom"><input type="text" name="" placeholder="{$Tlang['5d56944ec728b07e']}" style="width: 100%;" class="wqadd_url_1"/></p>
                <p class="wqnew_bottom"><span class="wqapp_add wqbg_color wqapp_insert_data" data-class="wqadd_url">{$Tlang['fd0ccca61f616bd9']}</span></p>
             </div>
             <div class="wq_insert_pop showHide_image none">
                <p class="wqnew_bottom"><input type="text" name="" placeholder="{$Tlang['bd66c8214d5ba26d']}" class="wqadd_image"/><span class="wqapp_add wqbg_color wqapp_insert_data" data-class="wqadd_image">{$Tlang['fd0ccca61f616bd9']}</span></p>
             </div>
              <!--Flash-->
             <div class="wq_insert_pop showHide_flash none">
                <p class="wqnew_bottom"><input type="text" name="" placeholder="{$Tlang['345d349b138687d6']}" class="wqadd_flash"/><span class="wqapp_add wqbg_color wqapp_insert_data" data-class="wqadd_flash">{$Tlang['fd0ccca61f616bd9']}</span></p>
                <p class="wqbg_ys wqnew_bottom">{$Tlang['945e461f6dd0c384']}</p>
             </div>
             <div class="wq_insert_pop showHide_quote none">
                 <textarea class="wqadd_quote"  placeholder="{$Tlang['8d4b32560532de3d']}"></textarea>
                 <p class="wqnew_bottom"><span class="wqapp_add wqbg_color wqapp_insert_data" data-class="wqadd_quote">{$Tlang['fd0ccca61f616bd9']}</span></p>
             </div>
             <div class="wq_insert_pop showHide_code none">
                 <textarea class="wqadd_code"  placeholder="{$Tlang['252aeea58d8e7b50']}"></textarea>
                 <p class="wqnew_bottom"><span class="wqapp_add wqbg_color wqapp_insert_data" data-class="wqadd_code">{$Tlang['fd0ccca61f616bd9']}</span></p>
             </div>
             <div class="wq_insert_pop showHide_free none">
                 <textarea class="wqadd_free"  placeholder="{$Tlang['26e4ae0c289d671e']}"></textarea>
                 <p class="wqnew_bottom"><span class="wqapp_add wqbg_color wqapp_insert_data" data-class="wqadd_free">{$Tlang['fd0ccca61f616bd9']}</span></p>
             </div>
        </div>
         <div class="wqapp_fujian_warp showHide_fujian">
             <p class="wqnew_bottom"><span class="wqbg_color wqapp_add" onclick="$('#filedatas').click();">{$Tlang['1679fa5c5ea7cc9e']}</span>
                 <input type="file" name="Filedata" id="filedatas" multiple="multiple" style="display:none">
                 <em class="y"><!--{if $_G['group']['maxattachsize']}-->{lang attachment_size}: {lang lower_than} $maxattachsize_mb<!--{else}-->{lang size_no_limit}<!--{/if}--></em>
             </p>
             <ul id="post_attach">
                <!--{loop $wqattachlist $attach}-->
                <!--{eval $wqimgurl=wq_app_setting_get_picurl($attach['attachment'],$attach['remote']) }-->
                    <li>
                        {$attach[filetype]}
                        <span class="wqtext">{$attach[filename]}</span>
                        <span class="y">
                            <a href="javascript:;" class="wq_insert wqbg_color" data-aid="{$attach[aid]}" data-isimage="{if $attach['isimage']}1{else}0{/if}" data-url="{$wqimgurl}">{$Tlang['fd0ccca61f616bd9']}</a>
                            <a href="javascript:;" class="wq_delete del" aid="{$attach[aid]}" wqtype="attach"><i class="wqiconfont2 wqicon2-gbdelete"></i></a>
                        </span>
                    </li>
                <!--{/loop}-->
             </ul>
        </div>
        <div class="wqpost_publish">
            <button id="postsubmit" class="wqpublish wqbg_color">
                <!--{if $_GET[action] == 'newthread' || $_GET[action] == 'publish'}-->
                {lang send_thread}
                <!--{elseif $_GET[action] == 'reply'}-->
                {lang join_thread}
                <!--{elseif $_GET[action] == 'edit'}-->
                {lang edit_save}
                <!--{/if}-->
            </button>
        </div>
    </div>
    <!--{hook/viewthread_fastpost_button_mobile}-->
    <!-- main postbox start -->
    <!--{if $_G['inajax']}-->
    </div>
    <!--{/if}-->
</form>
<!--{template common/simple_editor}-->

<script type="text/javascript">
    (function() {
        var needsubject = needmessage = false;

        <!--{if $_GET[action] == 'reply'}-->
                needsubject = true;
        <!--{elseif $_GET[action] == 'edit'}-->
                needsubject = needmessage = true;
        <!--{/if}-->
        $('#needmessage').on('scroll', function() {
                var obj = $(this);
                if(obj.scrollTop() > 0) {
                        obj.attr('rows', parseInt(obj.attr('rows')) + 2);
                }
        }).scrollTop($(document).height());
    })();
    function succeedhandle_follow() {
        clearTimeout(setTimeout_location);
        setTimeout_location = setTimeout(function() {
            window.location.href = 'home.php?mod=follow&uid={$_G[uid]}&do=view&from=space';
        }, '1000');
    }
    function succeedhandle_postform(url) {
        clearTimeout(setTimeout_location);
        setTimeout_location = setTimeout(function() {
            location.replace(url);
        }, '1000');
    }
</script>
<script type="text/javascript" reload="1">
    $('.wqeditarea').wqEditor({
        selector: '#needmessage',
        editor: '.wqeditarea',
        bbcodeMode: true,
        placeholder: "{$Tlang['70ad0bcbf2229f1d']}",
        imglist: '#imglist',
        isInput: '',
        subButton: '#postsubmit'
    });

    <!--{if 0 && $_G['setting']['mobile']['geoposition']}-->
    geo.getcurrentposition();
    <!--{/if}-->
    $(function () {
        $('#postsubmit').on('click', function() {
            var obj = $(this), form = $('#postform_w').length? $('#postform_w'):($('#postform').length ? $('#postform') : $('#follow'));
            popup.open(toast);
            var postlocation = '';
            if(geo.errmsg === '' && geo.loc) {
                postlocation = geo.longitude + '|' + geo.latitude + '|' + geo.loc;
            }
            $.ajax({
                type:'POST',
                url:form.attr('action') + '&geoloc=' + postlocation + '&handlekey='+form.attr('id')+'&inajax=1',
                data:form.serialize(),
                dataType: 'html'
            })
            .success(function(s) {
                popup.open(wqXml(s));
            })
            .error(function() {
                popup.open('{lang networkerror}', 'alert');
            });
            return false;
        });

        if(CURSCRIPT == 'forum' && CURMODULE=='post' && '{$_GET[action]}'=='newthread'){
            $('.wqeditarea').html($('#needmessage').val());
        }

        var needsubject = needmessage = false;
        if ('{$_GET[action]}' == 'reply') {
            needsubject = true;
        } else if ('{$_GET[action]}' == 'edit') {
            needsubject = needmessage = true;
        }

        $('.wqapp_auto_get_tag').on('click', function() {
                wqapp_relatekw();
        });
        $('#tags').blur(function(){
                wqapp_tagval();
        });
    });

</script>
<script src="{$_G['style']['styleimgdir']}js/forum/post.js?{VERHASH}" charset='gbk'></script>
<!--{eval $nofooter=1;}-->
<!--{if !$wqfollow_post}-->
<!--{template common/footer}-->
<!--{/if}-->
<!--{/if}-->