<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['viewthread_2'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->

    <div class="wqpublic_view">
        <h2>

            <!--{if $_G[forum][threadsorts][types][$_G[forum_thread][sortid]]}-->
            <span class="wq_typehtml wqts_txt">{$_G[forum][threadsorts][types][$_G[forum_thread][sortid]]}</span>
            <!--{/if}-->
            <!--{if $_G['forum_thread']['typeid'] && $_G['forum']['threadtypes']['types'][$_G['forum_thread']['typeid']]}-->
            <span class="wq_typehtml wqts_txt">{$_G['forum']['threadtypes']['types'][$_G['forum_thread']['typeid']]}</span>
            <!--{/if}-->
            <!--{if $threadsorts && $_G['forum_thread']['sortid']}-->
            <span class="wq_typehtml wqts_txt">{$_G['forum']['threadsorts']['types'][$_G['forum_thread']['sortid']]}</span>
            <!--{/if}-->
            <a href="<!--{if $wq_app_setting['view_click']}-->forum.php?mod=viewthread&tid=$post[tid]<!--{else}-->javascript:;<!--{/if}-->">
                <!--{eval echo discuzcode($_G[forum_thread][subject]);}-->
            </a>
            <!--{if $_G['forum_thread'][displayorder] == -2}--> <span>({lang moderating})</span>
            <!--{elseif $_G['forum_thread'][displayorder] == -3}--> <span>({lang have_ignored})</span>
            <!--{elseif $_G['forum_thread'][displayorder] == -4}--> <span>({lang draft})</span>
            <!--{/if}-->
        </h2>
        <!--{if $post['first'] &&  $_G['forum_threadstamp']}-->
            <div id="threadstamp"><img class="stamp" src="{STATICURL}image/stamp/$_G[forum_threadstamp][url]" title="$_G[forum_threadstamp][text]" /></div>
        <!--{/if}-->
        <p><span class="wqtime">$post[dateline]</span>
            <span class="wqname">
                <a href="{if $post['authorid'] && $post['username'] &&($_G['forum']['ismoderator']||!$post['anonymous'])}{$wq_userurl}{else}javascript:;{/if}" class="width100"> <!--{if $post['authorid'] && $post['username'] && !$post['anonymous']}-->
                            $post[author]
                            <!--{else}-->
                            <!--{if !$post['authorid']}-->
                            {lang guest} <em>$post[useip]{if $post[port]}:$post[port]{/if}</em>
                            <!--{elseif $post['authorid'] && $post['username'] && $post['anonymous']}-->
                            <!--{if $_G['forum']['ismoderator']}-->{lang anonymous}<!--{else}-->{lang anonymous}<!--{/if}-->
                            <!--{else}-->
                            $post[author] <em>{lang member_deleted}</em>
                            <!--{/if}-->
                            <!--{/if}-->
                            <!--{if $post[gender]}-->
                                <!--{eval $age = !empty($post['birthyear']) ? (intval(date("Y",time())) - $post['birthyear']) + 1 : "";}-->
                            <!--{/if}-->
                           </a>
            </span>
            <span class="wqplate_name"><a href="forum.php?mod=forumdisplay&fid=$_G['fid']"><!--{eval echo strip_tags($_G['forum']['name']) ? strip_tags($_G['forum']['name']) : $_G['forum']['name'];}--></a></span>
        </p>
    </div>


    <!--{subtemplate forum/viewthread_public}-->



<div class="wqpublic_reply">
    <h3 class="wqh3"><span>{$Tlang['4bc7b967c326c87e']}</span></h3>
</div>
    <div class="wqpost_reply"><a href="javascript:;" id="fastpostmessage" class="notlogged">{$Tlang['8442ceb58921a995']}<i class="wqiconfont2 wqicon2-bianji"></i></a></div>



<!--{/if}-->