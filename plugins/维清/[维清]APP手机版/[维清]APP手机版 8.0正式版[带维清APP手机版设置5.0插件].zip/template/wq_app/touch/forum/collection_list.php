<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['collection_list'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{if count($collectiondata) > 0}-->
<div class="wq_clct_list_warp">
    <div class="wq_collection_warp">
	<!--{loop $collectiondata $collectionvalues}-->
		<li class="wqnew_bottom">
                    <!--{if $op == 'my'}-->
                            <!--{if $collectionvalues['uid'] == $_G['uid']}-->
                                    <span class="ctag ctag0">{lang collection_mycreate}</span>
                            <!--{elseif in_array($collectionvalues['ctid'], $twctid)}-->
                                    <span class="ctag ctag1">{lang collection_myteam}</span>
                            <!--{else}-->
                                    <span class="ctag ctag2">{lang collection_mysubscribe}</span>
                            <!--{/if}-->
                    <!--{/if}-->
                    <h3>
                            <a href="forum.php?mod=collection&action=view&ctid={$collectionvalues['ctid']}{if $op}&fromop={$op}{/if}{if $tid}&fromtid={$tid}{/if}" class="xi2" {if $collectionvalues['updated'] && $op == 'my'}style='color:red;'{/if}>{$collectionvalues['name']}</a>
                    </h3>
                    <p class="wq_brief">{$collectionvalues['shortdesc']}</p>
                    <p>
                      <span class="xi2">{$Tlang['57f5cb4a5a928cae']}{$collectionvalues['displaynum']}, </span>
                    <!--{if $orderby=='commentnum'}-->
                            {lang collection_follow} {$collectionvalues['follownum']}, {lang collection_threadnum} {$collectionvalues['threadnum']}
                    <!--{elseif $orderby=='follownum'}-->
                            {lang collection_threadnum} {$collectionvalues['threadnum']}, {lang collection_commentnum} {$collectionvalues['commentnum']}
                    <!--{else}-->
                            {lang collection_follow} {$collectionvalues['follownum']}, {lang collection_commentnum} {$collectionvalues['commentnum']}
                    <!--{/if}-->
                    </p>
                    <p class="xg1">{$Tlang['c202c45c8f7548e3']}<a href="home.php?mod=space&uid=$collectionvalues['uid']">{$collectionvalues['username']}</a> , {lang collection_lastupdate} {$collectionvalues['lastupdate']}</p>
		</li>
	<!--{/loop}-->
        </div>
</div>
<!--{else}-->
<div class="wqemp"><span class="wqno_con"><img src="{$_G['style']['styleimgdir']}images/wqno_con.png"></span>{lang collection_nocollection}</div>
<!--{/if}-->

<!--{/if}-->