<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['wq_buluoviewthread_debate'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{if $debate[umpire]}-->
<!--{if $debate['umpirepoint']}-->
<div>
    <p>
        <!--{if $debate[winner]}-->
        <!--{if $debate[winner] == 1}-->
        <label><strong>{lang debate_square}</strong>{lang debate_winner}</label>
        <!--{elseif $debate[winner] == 2}-->
        <label><strong>{lang debate_opponent}</strong>{lang debate_winner}</label>
        <!--{else}-->
        <label><strong>{lang debate_draw}</strong></label>
        <!--{/if}-->
        <!--{/if}-->
        <em>{lang debate_comment_dateline}: $debate[endtime]</em>
    </p>
    <!--{if $debate[umpirepoint]}--><p><strong>{lang debate_umpirepoint}</strong>: $debate[umpirepoint]</p><!--{/if}-->
    <!--{if $debate[bestdebater]}--><p><strong>{lang debate_bestdebater}</strong>: $debate[bestdebater]</p><!--{/if}-->
</div>
<!--{/if}-->
<!--{/if}-->
<div id="postmessage_$post[pid]" class="postmessage">$post[message]</div>
<div class="mbn">
    <div class="debate_lump">
        <div class="debate_txt">
            <ul>
                <li>
                    <h3>{lang debate_square_point} <span>{lang debater}:$debate[affirmdebaters]<a href="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&stand=1{if $_GET[from]}&from=$_GET[from]{/if}" onclick="showWindow('reply', this.href)"> ( {lang debate_join} )</a></span></h3>
                    $debate[affirmpoint]</li>
                <li class="green_debate">
                    <h3>{lang debate_opponent_point}  <span>{lang debater}:$debate[negadebaters]<a href="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&stand=2{if $_GET[from]}&from=$_GET[from]{/if}" onclick="showWindow('reply', this.href)">( {lang debate_join} )</a></span></h3>
                    $debate[negapoint]</li>
            </ul>
        </div>
        <div class="debate_support">
            <div id="left" class="left progress">
                <div class="con">
                    <a href="forum.php?mod=misc&action=debatevote&tid=$_G[tid]&stand=1" class="wq_debatevote">{lang debate_support}{$Tlang['20efd88434a8d35a']}($debate[affirmvotes]) </a></div>
            </div>
            <div id="right" class="right progress">
                <div class="con">
                    <a href="forum.php?mod=misc&action=debatevote&tid=$_G[tid]&stand=2" class="wq_debatevote">{lang debate_support}{$Tlang['41036741ecdd9669']}($debate[negavotes])</a>
                </div>
            </div>
            <div class="middle">
                <div class="mask progress">
                    <span>VS</span>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="debate_time">
    <!--{if $debate[endtime]}-->
    <p class="end_time">{lang endtime}: $debate[endtime] <!--{if $debate[umpire]}-->{lang debate_umpire}: $debate[umpire]<!--{/if}--></p>
    <!--{/if}-->

    <!--{if $debate[umpire] && $_G['username'] && $debate[umpire] == $_G['member']['username']}-->
    <p class="mtn">
        <!--{if $debate[remaintime] && !$debate[umpirepoint]}-->
        <a href="forum.php?mod=misc&action=debateumpire&tid=$_G[tid]&pid=$post[pid]{if $_GET[from]}&from=$_GET[from]{/if}" >{lang debate_umpire_end}</a>
        <!--{elseif TIMESTAMP - $debate['dbendtime'] < 3600}-->
        <a href="forum.php?mod=misc&action=debateumpire&tid=$_G[tid]&pid=$post[pid]{if $_GET[from]}&from=$_GET[from]{/if}" >{lang debate_umpirepoint_edit}</a>
        <!--{/if}-->
    </p>
    <!--{/if}-->
</div>

<script type="text/javascript">
$(function() {

 $('.wq_debatevote').on('click', function() {
        var obj = $(this);
        $.ajax({
            type: 'GET',
            url: obj.attr('href') + '&inajax=1',
            data: {'hash': '{FORMHASH}'},
            dataType: 'html',
        }).success(function(s) {
            popup.open(wqXml(s));
        }).error(function() {
            window.location.href = obj.attr('href');
            popup.close();
        });
        return false;
    });
});

</script>
<!--{/if}-->