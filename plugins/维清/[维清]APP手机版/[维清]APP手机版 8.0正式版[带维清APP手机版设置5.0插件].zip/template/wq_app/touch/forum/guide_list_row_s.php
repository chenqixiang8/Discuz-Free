<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['guide_list_row_s'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{eval
    $tids = get_wq_app_tids($list['threadlist']);
    $threadlists= wq_app_get_thread_info_from_cache($tids);
}-->
<!--{eval include_once template('common/common_module');}-->

<!--{eval
    loadcache('wq_app_favorite_'  . $_G['uid']);
    $favorites=$_G['cache']['wq_app_favorite_'  . $_G['uid']];
}-->

<!--{loop $list['threadlist'] $key $thread}-->
    <!--{eval
        $threadicon = get_icon_for_list();
        $summarys = $threadlists[$thread['tid']]['summary'];
        $imagenum = $threadlists[$thread['tid']]['imagenum'];
        $images= $imagenum > 0 ? wq_app_setting_get_pic($threadlists[$thread['tid']]['maximgs'],$threadlists[$thread['tid']]['images'],$showmodel) : array();
        $thread['tid'] = get_tid_isclose_for_guide();
    }-->
<li class="wqno_border">
    <a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" class="wqblock guidelink">
        <div class="max_wqlisthidden">
            <h3 class="wqtitle_list wqtitle_jianju">{$threadicon}{$thread[typehtml]}{$thread[sorthtml]}<font $thread[highlight]>{$thread[subject]}</font></h3>
        </div>
        <!--{if $imagenum>0}-->
            <!--{loop $images $k $v}-->
            <div class="list_pane_pic wqm_bottom5 wq-lazyload-container">
                <img class="wq_js_delayload" src="{$_G['style'][styleimgdir]}images/wq_dian.jpg" data-src="{$v}">
            </div>
            <!--{/loop}-->
        <!--{/if}-->
    </a>
    <p class="guide_list_row4 wqapp_f14 wq_grey">
        <span class="wqm_right15">
             <a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" class="wq_grey">
            <i class="wqiconfont2 wqicon2-pinglun2 wqm_right5"></i>{if $thread['isgroup'] != 1}$thread[replies]{else}{$groupnames[$thread[tid]][replies]}{/if}
            </a>

        </span>
        <span class="y">
            <a href="forum.php?mod=misc&action=recommend&do=add&tid={$thread[tid]}&hash={FORMHASH}&handlekey=recommendadd" class="dialog wq_grey recommendadd_zan notlogged" data="$thread[tid]">
                <i class="wqiconfont2 wqicon2-gzan"></i>
                <span id="recommendadd_{$thread[tid]}">{$thread[recommend_add]}</span>
            </a>
        </span>
        <span class="y wqm_right15">
            <a href="home.php?mod=spacecp&ac=favorite&type=thread&id={$thread[tid]}&handlekey=newfav" class="wq_grey newfav dialog notlogged" data="$thread[tid]">
                    <!--{if $favorites[$thread[tid]]}-->
                        <i class="wqiconfont2 wqicon2-shoucang3 wqapp_f15 wqcolor_yellow" ></i>
                    <!--{else}-->
                        <i class="wqiconfont2 wqicon2-shoucang2 wqapp_f15 notlogged" id="i_crad_{$thread[tid]}"></i>
                    <!--{/if}-->
                </a>
        </span>
    </p>
</li>
<div class="wqseparate"></div>
<!--{/loop}-->

<!--{/if}-->