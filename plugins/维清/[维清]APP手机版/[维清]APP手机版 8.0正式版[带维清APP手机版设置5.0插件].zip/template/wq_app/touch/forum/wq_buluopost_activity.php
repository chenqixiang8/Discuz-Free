<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['wq_buluopost_activity'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<div class="exfm cl b_bottom">
    <div class="sinf z activity_ft">
        <p class="spmf cl a_select b_bottom">
            <select name="activitytime" id="activitytime">
                <option value="0" >&#x786E;&#x5207;&#x65F6;&#x95F4;</option>
                <option value="1" >&#x65F6;&#x95F4;&#x8303;&#x56F4;</option>
            </select>
        </p>
        <dl>
            <dt class="b_bottom">{lang post_event_time}<span class="rq">*</span></dt>
            <dd class="b_bottom">
                <div id="certainstarttime" {if $activity['starttimeto']}style="display: none"{/if}>
                     <input type="text" name="starttimefrom[0]" id="starttimefrom_0" class="act_px w_size" onclick="showcalendar(event, this, true)" autocomplete="off" value="$activity[starttimefrom]" tabindex="1" />
                </div>
                <div id="uncertainstarttime" {if !$activity['starttimeto']}style="display: none"{/if}>
                     <input type="text" name="starttimefrom[1]" id="starttimefrom_1" class="act_px" onclick="showcalendar(event, this, true)" autocomplete="off" value="$activity[starttimefrom]" tabindex="1" /><span> ~ </span><input onclick="showcalendar(event, this, true)" type="text" autocomplete="off" id="starttimeto" name="starttimeto" class="act_px" value="{if $activity['starttimeto']}$activity[starttimeto]{/if}" tabindex="1" />
                </div>
            </dd>

            <dt class="b_bottom"><label for="activityplace">{lang activity_space}</label><span class="rq">*</span></dt>
            <dd class="b_bottom">
                <input type="text" name="activityplace" id="activityplace" class="px oinf" value="$activity[place]" tabindex="1" />
            </dd>
            <!--{if $_GET[action] == 'newthread'}-->
            <dt class="b_bottom"><label for="activitycity">{lang activity_city}:</label></dt>
            <dd class="b_bottom"><input name="activitycity" id="activitycity" class="px" type="text" tabindex="1" /></dd>
            <!--{/if}-->
            <dt class="b_bottom"><label for="activitytypelist_dummy">{lang activiy_sort}:</label><span class="rq">*</span></dt>
            <dd class="b_bottom">
                <!--{if $activitytypelist}-->
                <ul id="activitytypelist" style="display: none">
                    <!--{loop $activitytypelist $type}-->
                    <li>$type</li>
                    <!--{/loop}-->
                </ul>
                <!--{/if}-->
                <input name="activityclass" id="activitytypelist_dummy" class="px"  type="text"/>
                <button type="button" id="activityclass" class="xl_kuang"><i class="wqiconfont wqicon-down_1"></i></button>
            </dd>
            <dt class="b_bottom"><label for="activitynumber">{lang activity_need_member}:</label></dt>
            <dd class="b_bottom">
                <input type="tel" name="activitynumber" id="activitynumber" class="px" onkeyup="checkvalue(this.value, 'activitynumbermessage')" value="$activity[number]" tabindex="1" />
                <span id="activitynumbermessage"></span>
            </dd>
            <div class="ftid a_select b_bottom">
                <select name="gender" id="gender" width="38" class="ps">
                    <option value="0" {if !$activity['gender']}selected="selected"{/if}>{lang unlimited}</option>
                    <option value="1" {if $activity['gender'] == 1}selected="selected"{/if}>{lang male}</option>
                    <option value="2" {if $activity['gender'] == 2}selected="selected"{/if}>{lang female}</option>
                </select>
            </div>
            <!--{if $_G['setting']['activityfield']}-->
            <div class="zi_bt">{lang optional_data}:</div>
            <div class="required_zl">
                <ul class="xl2 cl">
                    <!--{loop $_G['setting']['activityfield'] $key $val}-->
                    <li>
                        <input type="checkbox" name="userfield[]" id="userfield_$key" class="weui_check" value="$key"{if $activity['ufield']['userfield'] && in_array($key, $activity['ufield']['userfield'])} checked="checked"{/if} />
                        <label class="weui_check_label" for="userfield_$key"><i class="weui_icon_checked"></i>$val</label></li>
                    <!--{/loop}-->
                </ul>
            </div>
            <!--{/if}-->
            <!--{if $_G['setting']['activityextnum']}-->

            <div class="kzzl_lump b_top">
                <p class="kzzl b_bottom">
                    <span class="x_line"> <textarea name="extfield" id="extfield" class="pt" cols="50"placeholder="{lang other_data}" ><!--{if $activity['ufield']['extfield']}-->$activity[ufield][extfield]<!--{/if}--></textarea></span></p>
                <p class="t_xian">{lang post_activity_message} $_G['setting']['activityextnum'] {lang post_option}</p>
            </div>
            <!--{/if}-->
        </dl>
    </div>
    <div class="activity_ft z">
        <dl>
            <!--{if $_G['setting']['activitycredit']}-->
            <dt class="b_bottom"><label for="activitycredit">{lang consumption_credit}:</label></dt>
            <dd class="b_bottom">
                <input type="tel" name="activitycredit" id="activitycredit" class="px" value="$activity[credit]" />
                <i class="time_fw">{$_G['setting']['extcredits'][$_G['setting']['activitycredit']][title]}</i>

            </dd>
            <!--{/if}-->
            <dt class="b_bottom"><label for="cost">{lang activity_payment}:</label></dt>
            <dd class="b_bottom">
                <input type="tel" name="cost" id="cost" class="px" onkeyup="checkvalue(this.value, 'costmessage')" value="$activity[cost]" tabindex="1" />
                <i class="time_fw">{lang payment_unit}</i>
                <span id="costmessage"></span>
            </dd>
            <dt class="b_bottom"><label for="activityexpiration">{lang post_closing}:</label></dt>
            <dd class="hasd cl b_bottom">
                <span>
                    <input type="text" name="activityexpiration" id="activityexpiration" class="px" autocomplete="off" value="$activity[expiration]" tabindex="1" />
                </span>
                <!--<a href="javascript:;" class="dpbtn" onclick="showselect(this, 'activityexpiration')"></a>-->
            </dd>
            <!--{if $allowpostimg}-->
            <div class="ac_pic">
                <p>
                    <input type="button" class="pn" id="activity_image">
                    <span><!--{if $activityattach[attachment]}-->{lang update}<!--{else}-->{lang upload}<!--{/if}--></span>

                    <span class="xg1">
                        <!--{if $activityattach[attachment]}-->
                        {lang post_click_message_1}
                        <!--{else}-->
                        {lang post_click_message_2}
                        <!--{/if}-->
                    </span>
                </p>
                <div id="activityattach_image" class="sc_img">
                    <!--{if $activityattach[attachment]}-->
                    <img class="spimg" src="$activityattach[url]/{if $activityattach['thumb']}{eval echo getimgthumbname($activityattach['attachment']);}{else}$activityattach[attachment]{/if}"/>
                    <input type="hidden" name="activityaid" id="activityaid" value="$activityattach[aid]"/>
                    <!--{/if}-->
                </div>
            </div>
            <!--{/if}-->
            <!--{hook/post_activity_extra}-->
        </dl>
    </div>
</div>
<!--{eval $datetype="datetime";}-->
<!--{template common/wq_buluocalendar}-->
<script type="text/javascript">
$(function(){
     var   uploadsuccess_activity= function(data) {
                                       if(data == '') {
                                               popup.open('{lang uploadpicfailed}', 'alert');
                                       }
                                       var dataarr = data.split('|');
                                       if(dataarr[0] == 'DISCUZUPLOAD' && dataarr[2] == 0) {
                                               popup.close();
                                               if ($('#activityaid').length) {
                                                       $.ajax({
                                                                type:'GET',
                                                                url:'forum.php?mod=ajax&action=deleteattach&inajax=yes&aids[]=' + $('#activityaid').val(),
                                                       })
                                               }
                                               $('#activityattach_image').html('<a href="{$_G[setting][attachurl]}forum/'+dataarr[5]+'"><img id="aimg_'+dataarr[3]+'" title="'+dataarr[6]+'" src="{$_G[setting][attachurl]}forum/'+dataarr[5]+'" />\n\
<input type="hidden" name="activityaid" id="activityaid" value="'+dataarr[3]+'"><input type="hidden" name="activityaid_url" id="activityaid_url" value="'+dataarr[5]+'"></a>');
                                       $('#filedata').val('').attr('multiple','multiple');
                                        } else {
                                               var sizelimit = '';
                                               if(dataarr[7] == 'ban') {
                                                       sizelimit = '{lang uploadpicatttypeban}';
                                               } else if(dataarr[7] == 'perday') {
                                                       sizelimit = '{lang donotcross}'+Math.ceil(dataarr[8]/1024)+'K)';
                                               } else if(dataarr[7] > 0) {
                                                       sizelimit = '{lang donotcross}'+Math.ceil(dataarr[7]/1024)+'K)';
                                               }
                                               popup.open(STATUSMSG[dataarr[2]] + sizelimit, 'alert');
                                       }
             };
        $('#activity_image').click(function() {
              uploadsuccess_forum= uploadsuccess_activity;
	     $('#filedata').attr('multiple',null).click();
	});
        function checkvalue(value, message){
                if(!value.search(/^\d+$/)) {
                        document.getElementById(message).innerHTML = '';
                } else {
                        document.getElementById(message).innerHTML = '<b>{lang input_invalid}</b>';
                }
        }
        function  mobiscroll_Select(valueText,inst){
              $("#activitytypelist").mobiscroll('disable')
              $("#activitytypelist_dummy").attr('readonly',null)
              var text=$("#activitytypelist li").eq(valueText).text();
              $("#activitytypelist_dummy").val(text)
        }
        function  mobiscroll_Cancel(valueText,inst){
              $("#activitytypelist").mobiscroll('disable')
              $("#activitytypelist_dummy").attr('readonly',null)
        }
        function  activitytypelist (){
                $("#activitytypelist").mobiscroll().treelist({
                  theme: "android-ics light",
                  lang: "zh",
                  inputNlame:"activityclass",
                  inputClass:"px",
                  value:$("#activitytypelist_dummy").val(),
                  defaultValue:[Math.floor($('#activitytypelist li').length/2)],
                  cancelText: '&#x53D6;&#x6D88;',
                  setText: '&#x786E;&#x5B9A;',
                  headerText: function (valueText) { return "&#x6D3B;&#x52A8;&#x7C7B;&#x522B;"; },
                  onSelect:mobiscroll_Select,
                  onCancel:mobiscroll_Cancel,
                }).mobiscroll('show');
        }
        $('#activitytime').change(function(){
                 if($(this).val()=='1') {
                     $('#certainstarttime').hide();
                     $('#uncertainstarttime').show();
                 } else {
                     $('#certainstarttime').show();
                     $('#uncertainstarttime').hide();
                 }
        })
        $("#activityclass").click(function(){
            activitytypelist();
        })
	$("#activityexpiration,#starttimefrom_0,#starttimefrom_1,#starttimeto").mobiscroll(opt);
 });
 </script>



<!--{/if}-->