<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['viewthread_poll'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->

            <div class="wqview_voteoption">
                 <form id="poll" name="poll" method="post" autocomplete="off" action="forum.php?mod=misc&action=votepoll&fid=$_G[fid]&tid=$_G[tid]&pollsubmit=yes{if $_GET[from]}&from=$_GET[from]{/if}&quickforward=yes" >
        <input type="hidden" name="formhash" value="{FORMHASH}" />
                <p class="wqred" style="margin-bottom: 6px;">
                        <!--{if $multiple}-->
                        {lang poll_multiple}{lang thread_poll}
                        <!--{if $maxchoices}-->
                        :{lang poll_more_than}
                        <!--{/if}-->
                    <!--{else}-->
                    {lang poll_single}{lang thread_poll}
                    <!--{/if}-->
                    <!--{if $visiblepoll && $_G['group']['allowvote']}-->,{lang poll_after_result}<!--{/if}-->, {lang poll_voterscount}


                </p>
                <p class='wqsee_poll_per'>
                   <!--{if !$visiblepoll && ($overt || $_G['adminid'] == 1 || $thread['authorid'] == $_G['uid']) && $post['invisible'] == 0}-->
			<a href="forum.php?mod=misc&action=viewvote&tid=$_G[tid]" onclick="showWindow('viewvote', this.href)">{lang poll_view_voters}</a>
		<!--{/if}-->
                </p>
                <!--{if $_G[forum_thread][remaintime]}-->
        <p>
            {lang poll_count_down}:
            <span class="xg1">
                <!--{if $_G[forum_thread][remaintime][0]}-->$_G[forum_thread][remaintime][0] {lang days}<!--{/if}-->
                <!--{if $_G[forum_thread][remaintime][1]}-->$_G[forum_thread][remaintime][1] {lang poll_hour}<!--{/if}-->
                $_G[forum_thread][remaintime][2] {lang poll_minute}
            </span>
        </p>
         <!--{elseif $expiration && $expirations < TIMESTAMP}-->
        <p>{lang poll_end}</p>
        <!--{/if}-->

        <!--{eval $hasimage = get_poll_has_image($polloptions);}-->
        <!--{if !$hasimage}-->
                <div class="wqview_voteoption">
                <ul class="wqview_voteoption_ul">
                    <!--{loop $polloptions $key $option}-->
                <li>
                   <!--{if $_G['group']['allowvote']}-->
                    <input type="$optiontype" class="weui_check" id="option_$key" name="pollanswers[]" value="$option[polloptionid]" {if $_G['forum_thread']['is_archived']}disabled="disabled"{/if}/>
                           <label class="weui_check_label" for="option_$key"><i class="weui_icon_checked"></i>
                           <!--{/if}-->
                            <!--{if $imginfo}--><div class="wqlist1"><img id="aimg_$imginfo[aid]" aid="$imginfo[aid]" src="$imginfo[small]" onclick="zoom(this, this.getAttribute('zoomfile'), 0, 0, '{$_G[setting][showexif]}')" zoomfile="$imginfo[big]" alt="$imginfo[filename]" title="$imginfo[filename]" w="$imginfo[width]" /></div> <!--{/if}-->
                            <span class="wqtitle_list">
                              $key.$option[polloption]
                               </span>
                       <br/>
                       <span class="">
                           <!--{if !$visiblepoll}-->
                           <!--{eval $option[width] = $option[width] == 8 ? 0 : $option[width];}-->
                           <div class="pbg wqview_vote_bg"><div class="pbr" style="width: $option[width]; background-color:#$option[color]"></div></div>
                            $option[percent]%
                            <span class="wqred" style="color:#$option[color]">($option[votes])</span>
                           <!--{/if}-->
                       </span>
                      </label>

                </li>
                 <!--{/loop}-->
            </ul>
        </div>
        <!--{else}-->
         <div class="wqpoll_div">
        <ul class="poll_img">
            <!--{loop $polloptions $key $option}-->
                <li class="wqnew_all">
                    <!--{eval $imginfo=$option['imginfo'];}-->
                    <span><!--{if $imginfo}-->
                        <a href="javascript:;" title="$imginfo[filename]" >
                            <img id="aimg_$imginfo[aid]" aid="$imginfo[aid]" src="$imginfo[small]" onclick="zoom(this, this.getAttribute('zoomfile'), 0, 0, '{$_G[setting][showexif]}')" zoomfile="$imginfo[big]" alt="$imginfo[filename]" title="$imginfo[filename]" w="$imginfo[width]" />
                        </a>
                        <!--{else}-->
                        <a href="javascript:;" title=""><img src="template/wq_app/static/images/nophoto2.gif" /></a>
                        <!--{/if}-->
                    </span>
                    <!--{if $_G['group']['allowvote']}-->
                    <input type="$optiontype" class="weui_check" id="option_$key" name="pollanswers[]" value="$option[polloptionid]" {if $_G['forum_thread']['is_archived']}disabled="disabled"{/if}/>
                          <label class="weui_check_label" for="option_$key"><i class="weui_icon_checked"></i>$key.$option[polloption]</label><br/>
                    <!--{else}-->
                    $key.$option[polloption]<br/>
                     <!--{/if}-->

                    <!--{if !$visiblepoll}-->
                    $option[percent]% <em style="color:#$option[color]">($option[votes])</em>
                    <!--{/if}-->
                </li>
            <!--{/loop}-->
             </ul>
             </div>
         <!--{/if}-->
        <!--{if $_G['group']['allowvote'] && !$_G['forum_thread']['is_archived']}-->
        <div id="p_submit" class="wqwant_join wqbg_color wqm_top0">
            <input type="submit" name="pollsubmit" class="wqinput" id="pollsubmit" value="{lang submit}" />
        </div>
        <!--{if $overt}-->
        <p class="wqm_bottom10">{lang poll_msg_overt}</p>
        <!--{/if}-->
        <!--{elseif !$allwvoteusergroup}-->
        <!--{if !$_G['uid']}-->
        <p>{lang poll_msg_allwvote_user}</p>
        <!--{else}-->
        <p>{lang poll_msg_allwvoteusergroup}</p>
        <!--{/if}-->
        <!--{elseif !$allowvotepolled}-->
        <p>{lang poll_msg_allowvotepolled}</p>
        <!--{elseif !$allowvotethread}-->
        <p>{lang poll_msg_allowvotethread}</p>
        <!--{/if}-->
                </form>
            </div>

<!--{/if}-->