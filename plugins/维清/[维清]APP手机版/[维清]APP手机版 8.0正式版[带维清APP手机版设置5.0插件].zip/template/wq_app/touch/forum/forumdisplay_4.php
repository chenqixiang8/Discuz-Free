<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['forumdisplay_4'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{eval
    $tids = get_wq_app_tids($_G['forum_threadlist']);
    $threadlists= wq_app_get_thread_info_from_cache($tids);
}-->

<!--{loop $_G['forum_threadlist'] $key $thread}-->
    <!--{eval
        $threadicon = get_icon_for_list();
        $summarys = $threadlists[$thread['tid']]['summary'];
        $imagenum = $threadlists[$thread['tid']]['imagenum'];
        $images= $imagenum > 0 ? wq_app_setting_get_pic($threadlists[$thread['tid']]['maximgs'],$threadlists[$thread['tid']]['images'],$showmodel,3) : array();
    }-->
    <!--{if $thread['displayorder'] > 0}-->
        <!--{eval continue;}-->
    <!--{/if}-->

    <!--{hook/forumdisplay_thread_mobile $key}-->
    <!--{if $images && $imagenum >= 3 }-->
        <li class="wqinformation_3 wqnew_bottom">
            <a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" class="wqblock guidelink">
                <div class="max_wqlisthidden " style="max-height: 1.04rem;">
                    <h3 class="wqtitle_list">{$threadicon}{if $thread[typename]}<span class="wqicon_all_14 wqicon_vote">{$thread[typename]}</span>{/if}<font $thread[highlight]>{$thread[subject]}</font></h3>
                    <!--<p class="wqcon">{$summarys}</p>-->
                </div>
                <div class="list_pane3">
                    <!--{loop $images $k $v}-->
                        <div class="wq-lazyload-container" >
                            <img class="wq_js_delayload" src="{$_G['style'][styleimgdir]}images/wq_dian.jpg" data-src="{$v}">
                        </div>
                    <!--{/loop}-->
                    <!--{if $imagenum > 3 }-->
                        <span class="wqlisttu2"><i class="wqiconfont2 wqicon2-tupian-copy wqapp_f14 wqm_right2"></i>{$imagenum}</span>
                    <!--{/if}-->
                </div>
                <p class="list_info">
                    <span class="wqwidth80">$thread[author]</span>
                    <span class="y">
                        <i class="wqiconfont2 wqicon2-pinglun2 wqapp_f12"></i>
                        <!--{if $thread['isgroup'] != 1}-->$thread[replies]<!--{else}-->{$groupnames[$thread[tid]][replies]}<!--{/if}-->
                    </span>
                    <span class="y wqm_right10 width80"><i class="wqiconfont2 wqicon2-p-see wqyulan"></i>$thread[views]</span>
                </p>
            </a>
        </li>
    <!--{else}-->
        <li class="wqinformation_1 wqnew_bottom">
            <a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" class="wqblock guidelink">
                <!--{if $images && $imagenum > 0 }-->
                    <div class="wqlist1 wq-lazyload-container wqintelligent1">
                       <img class="wq_js_delayload" src="{$_G['style'][styleimgdir]}images/wq_dian.jpg"  data-src="{$images[0]}">
                    </div>
                <!--{/if}-->
                <div class="<!--{if $images && $imagenum > 0 }-->wqlisthidden <!--{else}--> max_wqlisthidden<!--{/if}-->" style="max-height: 1.04rem;">
                    <h3 class="wqtitle_list">
                        {$threadicon}{if $thread[typename]}<span class="wqicon_all_14 wqicon_vote">{$thread[typename]}</span>{/if}<font $thread[highlight]>{$thread[subject]}</font></h3>
                    <!--<p class="wqcon">{$summarys}</p>-->
                </div>
                <p class="list_info">
                    <!--{if $thread['authorid'] && $thread['author']}-->
                    <span class="wqwidth120">{$thread[author]}</span>
                    <!--{else}-->
                    {$_G[setting][anonymoustext]}
                    <!--{/if}-->
                    <span class="y"><i class="wqiconfont2 wqicon2-pinglun2 wqapp_f12"></i>{$thread[replies]}</span>
                    <span class="y wqm_right10"><i class="wqiconfont2 wqicon2-p-see wqyulan"></i>{$thread[views]}</span>
                </p>
            </a>
        </li>
    <!--{/if}-->
<!--{/loop}-->
<script>
    JC.file('thirdparty/jquery.masonry.min.js');
    JC.run();
</script>
<script type="text/javascript" src="{$_G['style']['styleimgdir']}js/forum/forumdisplay_p.js?{VERHASH}"></script>

<!--{/if}-->