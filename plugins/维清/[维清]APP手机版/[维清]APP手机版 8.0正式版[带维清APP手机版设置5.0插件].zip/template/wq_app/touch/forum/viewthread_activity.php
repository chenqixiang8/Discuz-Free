<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['viewthread_activity'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<div class="wqactivity_data">
    <!--{if $activity['thumb']}-->
    <div class="theme_img">
        <img src="$activity['thumb']"/>
    </div>
    <!--{/if}-->
    <ul>
        <li class="wqnew_bottom"><em>{lang activity_type}</em><span class="text_left">$activity[class]</span></li>
        <li class="wqnew_bottom"><em>{lang activity_starttime}</em><span class="text_left">  <!--{if $activity['starttimeto']}-->
        {lang activity_start_between}
        <!--{else}-->
        $activity[starttimefrom]
        <!--{/if}--></span></li>
        <li class="wqnew_bottom"><em>{lang activity_space}</em><span class="text_left">$activity[place]</span></li>
        <li class="wqnew_bottom"><em>{lang gender}</em><span class="text_left"><!--{if $activity['gender'] == 1}-->
        {lang male}
        <!--{elseif $activity['gender'] == 2}-->
        {lang female}
        <!--{else}-->
        {lang unlimited}
        <!--{/if}--></span></li>
        <!--{if $activity['cost']}-->
        <li class="wqnew_bottom"><em>{lang activity_payment}</em><span class="text_left">$activity[cost] {lang payment_unit}</span></li>
        <!--{/if}-->
        <li class="wqnew_bottom"><em>{$Tlang['1adc6e823a659005']}</em><span class="text_left">$allapplynum {lang activity_member_unit}
        <!--{if $post['invisible'] == 0 && ($_G['forum_thread']['authorid'] == $_G['uid'] || (in_array($_G['group']['radminid'], array(1, 2)) && $_G['group']['alloweditactivity']) || ( $_G['group']['radminid'] == 3 && $_G['forum']['ismoderator'] && $_G['group']['alloweditactivity']))}-->
        <!--{lang activity_mod}-->
        <!--{/if}--></span>
        </li>
        <!--{if $activity['number']}-->
        <li class="wqnew_bottom"><em>{lang activity_about_member}</em><span class="text_left">$aboutmembers {lang activity_member_unit}</span></li>
        <!--{/if}-->
        <!--{if $activity['expiration']}-->
        <li class="wqnew_bottom"><em>{lang post_closing}</em><span class="text_left">$activity[expiration]</span></li>
        <!--{/if}-->
    </ul>
</div>

<!--{if $post['invisible'] == 0}-->
    <!--{if ($applied && $isverified < 2)||(!$activityclose && $isverified == 2)}-->
        <div class="wqwant_join"style="margin-top: -10px;">
            <!--{if $applied && $isverified < 2}-->
            <!--{if !$isverified}-->
            {lang activity_wait}
            <!--{else}-->
            {lang activity_join_audit}
            <!--{/if}-->
            <!--{elseif !$activityclose &&$isverified == 2}-->
            <p class="pns mtn"><input value="{lang complete_data}" name="ijoin" id="ijoin" /></p>
            <!--{/if}-->
        </div>
    <!--{/if}-->
<!--{/if}-->
<!--{if $applylist}-->
 <div class='wqseparate' style='margin: 0 -12px;'></div>
<div class="wqscore_num wqbg_grey" style='margin: 0 -12px;'>

    <div class="wqscore_num_specific">{$Tlang['402f90e664c70286']}<span class="y">$applynumbers {lang activity_member_unit}</span></div>
    <div class="wqscore_num_head" id="my_view_activity">
        <div class="tag_list">
            <ul>
                <!--{loop $applylist $apply}-->
                <li>
                    <a  href="home.php?mod=space&do=profile&uid=$apply[uid]"><img src="<!--{avatar($apply[uid], small, true)}-->" /></a>
                </li>
                <!--{/loop}-->
            </ul>
        </div>
        <!--{eval $my_roll_tag='my_view_activity';}-->
        <!--{template common/slide}-->
    </div>
</div>
       <!--{/if}-->


<!--{/if}-->