<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['forumdisplay_j'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{eval
    $tids = get_wq_app_tids($_G['forum_threadlist']);
    $threadlists= wq_app_get_thread_info_from_cache($tids);
    $showmodel = 1;
}-->

<!--{loop $_G['forum_threadlist'] $key $thread}-->
    <!--{eval
        $threadicon = get_icon_for_list();
        $summarys = $threadlists[$thread['tid']]['summary'];
    }-->
    <!--{if $thread['displayorder'] > 0}-->
        <!--{eval continue;}-->
    <!--{/if}-->
    <!--{hook/forumdisplay_thread_mobile $key}-->
    <li>
        <a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" class="wqblock">
                    <!--{eval echo $threadimage = get_images_for_list();}-->
            <div class="wqessence_warp">
                 <p class="list_info">
                    <img class="wq_head wq_js_delayload" src="{$_G['style'][styleimgdir]}images/wq_dian.jpg" data-src="{avatar($thread[authorid], small, true)}"/>
                    <!--{if $thread['authorid'] && $thread['author']}-->
                    <span class="wq_name">{$thread[author]}</span>
                    <!--{else}-->
                    {$_G[setting][anonymoustext]}
                    <!--{/if}-->

                </p>
                <div class=" <!--{if $threadlists[$thread[tid]][imagenum]}-->wqessence_hidden<!--{else}-->wqessence_maxhidden<!--{/if}-->">
                    <h3 class="wqtitle_list">{if $thread[typename]}<span class="wqicon_all_14 wqicon_vote">{$thread[typename]}</span>{/if}<font $thread[highlight]>{$thread[subject]}</font></h3>
                </div>
                <p class="wq_grey wqapp_f12 wq_info">{$thread[dateline]}
                    <span class="y" style="line-height: 0.6rem;"><i class="wqiconfont2 wqicon2-pinglun2 wqapp_f12"></i>{$thread[replies]}</span>
                    <span class="y wqm_right10"style="line-height: 0.6rem;"><i class="wqiconfont2 wqicon2-p-see wqyulan"></i>{$thread[views]}</span>
                </p>
            </div>
        </a>
    </li>
<!--{/loop}-->

<script>
    JC.file('thirdparty/jquery.masonry.min.js');
    JC.run();
</script>
<script type="text/javascript" src="{$_G['style']['styleimgdir']}js/forum/forumdisplay_p.js?{VERHASH}"></script>


<!--{/if}-->