<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['discuz_2'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<div id="sub_forum_$cat[fid]" class="sub_forum bm_c wqplate_ul2">
    <ul>
        <!--{loop $cat[forums] $forumid}-->
        <!--{eval $forum=$forumlist[$forumid];}-->
            <li class="wqnew_bottom">
                    <div class="plan_t_img">
                        <!--{if $forum[icon]}-->
                            $forum[icon]
                        <!--{else}-->
                            <a href="forum.php?mod=forumdisplay&fid={$forum['fid']}">
                                <img src="{$_G['style'][styleimgdir]}images/forum{if $forum[folder]}_new{/if}.gif" alt="$forum[name]" />
                            </a>
                        <!--{/if}-->
                    </div>
                    <div>
                        <a href="forum.php?mod=forumdisplay&fid={$forum['fid']}">
                            <h3><font {if $forum[extra][namecolor]} style="color: {$forum[extra][namecolor]};"{/if}>{$forum[name]}</font></h3>
                            <p class="today_tz">
                                <!--{if $wq_app_setting[tpost]==1}-->
                                    {$Tlang[todaypost]}:$forum[todayposts]
                                <!--{else}-->
                                    {lang forum_threads}: <!--{echo dnumber($forum[threads])}-->
                                <!--{/if}-->
                            </p>
                        </a>
                                             <!--{if $wq_app_setting['view_line'] == '1'}-->
                        <span class="plan_line wqnew_right"></span>
                    <!--{/if}-->
                    </div>
            </li>
        <!--{/loop}-->
    </ul>
</div>
<!--{/if}-->