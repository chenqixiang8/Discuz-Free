<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['viewthread_sort'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{if $post['first'] && $threadsort && $threadsortshow}-->
<!--{if $threadsortshow['optionlist'] && !($post['status'] & 1) && !$_G['forum_threadpay']}-->
<!--{if $threadsortshow['optionlist'] == 'expire'}-->
{lang has_expired}
<!--{else}-->
<div class="wqactivity_data wqm_bottom10">
	<ul>

		<!--{loop $threadsortshow['optionlist'] $option}-->
		<li class="wqnew_bottom">
			<!--{if $option['type'] != 'info'}-->
			<em> $option[title]:</em>
			<span class="text_left">
				<!--{if $option['value']}-->
				<!--{if $option['type']== 'image'}-->
				<!--{eval preg_match("/href=\"(.*)\"\s+target/ies", $option[value], $threadsortshow_img);}-->
				<img src="{if $threadsortshow_img}$threadsortshow_img[1]{else}$option[value]{/if}"><!--{else}-->$option[value]<!--{/if}--> $option[unit]
				<!--{else}--><span class="grey">--</span><!--{/if}--></span>
			<!--{/if}-->
		</li>
		<!--{/loop}-->
	</ul>
</div>
<!--{/if}-->
<!--{/if}-->
<!--{/if}-->
<!--{/if}-->