<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['collection_all'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{template common/header}-->
<!--{eval $headright=false;}-->
    <!--{if helper_access::check_module('collection')}-->
        <!--{eval $headright=true;}-->
    <!--{/if}-->

    <!--{eval
        $headparams['wtype'] = '1';
        $headparams['ltype'] = 'a';
        $headparams['lurl'] = $backurl;
        $headparams['cname'] = $Tlang['5d6bc314174ee1c8'];
        $headparams['rtype'] = 'a';
        $headparams['rclass'] = 'wqapp_f16';

        $headparams['rtype'] = 'a';
        $headparams['rname'] = $Tlang['984c5e7090423fd1'];
        $headparams['rurl'] = 'forum.php?mod=collection&action=edit';
        $headparams['rclass'] = '';

        echo wq_app_get_header($headparams,true,$headright);
    }-->

<div id="ct" class="wp cl">
	<div class="bm">
		<div class="wq_amoy_paste">
                    <div class="tag_list">
			<!--{subtemplate forum/collection_nav}-->
                        </div>
		</div>
		<div class="wq_tbmu_sw wqnew_bottom">
			<!--{if $op != 'search'}-->
                        <a href="forum.php?mod=collection&amp;op=all"{if !in_array($orderby, array('threadnum', 'commentnum', 'follownum'))} class="a"{/if}>{$Tlang['486f9c6b76207a86']}</a>
				<span class="pipe">|</span>
                                <a href="forum.php?mod=collection&amp;op=all&amp;order=threadnum"{if $orderby == 'threadnum'} class="a"{/if}>{$Tlang['ad7d00e456b06cd2']}</a>
				<span class="pipe">|</span>
                                <a href="forum.php?mod=collection&amp;op=all&amp;order=commentnum"{if $orderby == 'commentnum'} class="a"{/if}>{$Tlang['be963ec7cfff9120']}</a>
				<span class="pipe">|</span>
                                <a href="forum.php?mod=collection&amp;op=all&amp;order=follownum"{if $orderby == 'follownum'} class="a"{/if}>{$Tlang['7ec8e70cd61579b3']}</a>
			<!--{else}-->
				{lang search}
			<!--{/if}-->
		</div>
				<!--{if $_G['setting']['search']['collection']['status'] && ($_G['group']['allowsearch'] & 64 || $_G['adminid'] == 1)}-->
                                 <div class="wq_search_collection">
					<form action="forum.php?mod=collection&amp;op=search" method="post">
                                            <span><input type="text" name="kw" class="px vm" /></span>
						<button type="submit" value="submit" class="pn vm">{lang search}</button>
					</form>
                                     </div>
				<!--{/if}-->
		<div class="bm_c">
			<!--{hook/collection_index_top}-->
			<!--{subtemplate forum/collection_list}-->
			<!--{hook/collection_index_bottom}-->
		</div>
	</div>
	$multipage
	<br /><br />
</div>
<!--{template common/footer}-->
<!--{/if}-->