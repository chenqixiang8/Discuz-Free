<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['wq_buluopost_trade'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<input type="hidden" name="trade" value="yes" />
<input type="hidden" name="item_type" value="1" />
<div class="exfm cl b_bottom">
    <div class="sinf sppoll z trade_ft">
        <ul>
            <li class="b_bottom">
                <div class="ftid">
                    <select id="item_quality" class="ps" name="item_quality" tabindex="1">
                        <option value="1" {if $trade['quality'] == 1}selected="selected"{/if}>{lang trade_new}</option>
                        <option value="2" {if $trade['quality'] == 2}selected="selected"{/if}>{lang trade_old}</option>
                    </select>
                </div></li>
            <li class="b_bottom">
                <i><label for="item_name">{lang post_trade_name}</label><span class="rq">*</span></i>
                <div class="spmf"><input type="text" name="item_name" id="item_name" class="poll_px oinf" value="$trade[subject]" tabindex="1" /></div>
            </li>
            <li class="b_bottom">
                <i><label for="item_number">{lang post_trade_number}</label><span class="rq">*</span></i>
                <div class="spmf">
                    <input type="tel" name="item_number" id="item_number" class="poll_px" value="$trade[amount]" tabindex="1" />

                </div>
            </li>
            <li class="b_bottom">
                <div class="spmf">
                    <div class="ftid">
                        <select name="transport" id="transport"  class="ps">
                            <option value="virtual" {if $trade['transport'] =='3'}selected="selected"{/if}>{lang post_trade_transport_virtual}</option>
                            <option value="seller" {if $trade['transport'] =='1'}selected="selected"{/if}>{lang post_trade_transport_seller}</option>
                            <option value="buyer" {if $trade['transport'] ==='2'}selected="selected"{/if}>{lang post_trade_transport_buyer}</option>
                            <option value="logistics" {if $trade['transport'] ==='4'}selected="selected"{/if}>{lang trade_type_transport_physical}</option>
                            <option value="offline" {if $trade['transport'] ==='0'}selected="selected"{/if}>{lang post_trade_transport_offline}</option>
                        </select>
                    </div></div>
            </li>
            <li class="b_bottom">
                <div class="rmb">
                    <p> <label for="item_price">{lang post_current_price}</label>
                        <input type="tel" name="item_price" id="item_price" class="px bt_none" value="$trade[price]" tabindex="1" /></p>
                    <p>  <label for="item_costprice">{lang post_original_price}</label>
                        <input type="tel" name="item_costprice" id="item_costprice" class="px b_top" value="$trade[costprice]" tabindex="1" /></p>

                </div>
                <!--{if $_G['setting']['creditstransextra'][5] != -1}-->
                <div class="rmb">
					<p>   <label for="item_credit">{lang post_current_credit}({$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][5]][title]})</label>
						<input type="tel" name="item_credit" id="item_credit" class="px b_top" value="$trade[credit]" tabindex="1" /></p>
                    <p>  <label for="item_costcredit">{lang post_original_credit}({$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][5]][title]})</label>
                        <input type="tel" name="item_costcredit" id="item_costcredit" class="px b_top" value="$trade[costcredit]" tabindex="1" /></p>

                </div>
                <!--{/if}-->
                <div class="spmf3 rmb" id="logisticssetting" style="display:{if !$trade['transport'] || $trade['transport'] == 3}none{/if}">
                    <p> <label for="postage_mail">{lang post_trade_transport_mail}</label>
                        <input type="text" name="postage_mail" id="postage_mail" class="px b_top" value="$trade[ordinaryfee]" tabindex="1" /></p>
                    <p>  <label for="postage_express">{lang post_trade_transport_express}</label>
                        <input type="text" name="postage_express" id="postage_express" class="px b_top" value="$trade[expressfee]" tabindex="1" /></p>
                    <p>  <label for="postage_ems">EMS</label>
                        <input type="text" name="postage_ems" id="postage_ems" class="px b_top" value="$trade[emsfee]" tabindex="1" /></p>
                </div>
            </li>
            <li class="b_bottom">
                <div class="ftid">
                    <select name="paymethod" id="paymethod" width="108" change="display('tenpayseller')" class="ps" tabindex="1">
                        <!--{if $_G[setting][ec_tenpay_opentrans_chnid]}--><option value="0" {if $trade[tenpayaccount]}selected{/if}>{lang post_trade_paymethod_online}</option><!--{/if}-->
                        <option value="1" {if !$trade[tenpayaccount]}selected{/if}>{lang post_trade_paymethod_offline}</option>
                    </select>
                </div>
            </li>
        </ul>
        <dl id="tenpayseller" style="{if !$trade[tenpayaccount]}display:none{/if}">
            <dt><label for="tenpay_account">{lang post_trade_tenpay_seller}:</label></dt>
            <dd><input type="text" name="tenpay_account" id="tenpay_account" class="px" value="$trade[tenpayaccount]" tabindex="2" /></dd>
        </dl>
    </div>
    <div class="sadd z trade_bt">
        <ul>
            <li class="b_bottom"><i><label for="item_locus">{lang post_trade_locus}:</label></i>
                <div class="jl_pl"><input type="text" name="item_locus" id="item_locus" class="px" value="$trade[locus]" tabindex="1" /></div></li>
            <li class="b_bottom"><i><label for="item_expiration">{lang valid_before}:</label></i>
                <div class="jl_pl hasd">
                    <input type="text" name="item_expiration" id="item_expiration" class="px"  autocomplete="off" value="$trade[expiration]" tabindex="1" />

                </div></li>
            <!--{if $allowpostimg}-->

            <div class="pns ac_pic">
                <p>
                    <input type="button" class="pn" id="trade_button">
                    &#x4E0A;&#x4F20;&#x5546;&#x54C1;&#x56FE;&#x7247;
                </p>

                <div id="tradeattach_image" class="ptn sc_img">
                    <!--{if $tradeattach[attachment]}-->
                    <a href="$tradeattach[url]/$tradeattach[attachment]" target="_blank"><img class="spimg" src="$tradeattach[url]/{if $tradeattach['thumb']}{eval echo getimgthumbname($tradeattach['attachment']);}{else}$tradeattach[attachment]{/if}" alt="" /></a>
                    <input type="hidden" name="tradeaid" id="tradeaid" value="$activityattach[aid]"/>
                    <input type="hidden" name="tradeaid_url" id="tradeaid_url" />
                    <!--{/if}-->
                </div>
            </div>
            <!--{/if}-->
            <!--{hook/post_trade_extra}-->
            </li>
        </ul>
    </div>
</div>
<!--{eval $datetype="date";}-->
<!--{template common/wq_buluocalendar}-->
<script>
	$(function() {
            uploadsuccess_trade = function(data) {
				if (data == '') {
					popup.open('{lang uploadpicfailed}', 'alert');
				}
				var dataarr = data.split('|');
				if (dataarr[0] == 'DISCUZUPLOAD' && dataarr[2] == 0) {
					popup.close();
					if ($('#tradeaid').length) {
						$.ajax({
							type: 'GET',
							url: 'forum.php?mod=ajax&action=deleteattach&inajax=yes&aids[]=' + $('#tradeaid').val(),
						})
					}

					$('#tradeattach_image').html('<a href="javascript:;"><img id="aimg_' + dataarr[3] + '" title="' + dataarr[6] + '" src="{$_G[setting][attachurl]}forum/' + dataarr[5] + '" />\n\
<input type="hidden" name="tradeaid" id="tradeaid" value="' + dataarr[3] + '"><input type="hidden" name="tradeaid_url" id="tradeaid_url" value="' + dataarr[5] + '"></a>');
                                      $('#filedata').val('').attr('multiple','multiple');
				} else {
					var sizelimit = '';
					if (dataarr[7] == 'ban') {
						sizelimit = '{lang uploadpicatttypeban}';
					} else if (dataarr[7] == 'perday') {
						sizelimit = '{lang donotcross}' + Math.ceil(dataarr[8] / 1024) + 'K)';
					} else if (dataarr[7] > 0) {
						sizelimit = '{lang donotcross}' + Math.ceil(dataarr[7] / 1024) + 'K)';
					}
					popup.open(STATUSMSG[dataarr[2]] + sizelimit, 'alert');
				}
			}

		$("#item_expiration").mobiscroll().date();
		var currYear = (new Date()).getFullYear();
		var year = 8;
		var opt = {
			preset: 'date',
			theme: 'android-ics light',
			display: 'modal',
			mode: 'mixed',
			lang: 'zh',
			dateFormat: 'yyyy-mm-dd',
			setText: '&#x786E;&#x5B9A;',
			cancelText: '&#x53D6;&#x6D88;',
			dateOrder: 'yyyymmdd',
			dayText: '&#x65E5;', monthText: '&#x6708;', yearText: '&#x5E74;', hourText: '&#x65F6;', minuteText: '&#x5206;',
			showNow: false,
			nowText: "&#x4ECA;",
			timeWheels: 'HHii', timeFormat: 'HH:ii',
			startYear: currYear,
			endYear: currYear + year
		};
		$("#item_expiration").mobiscroll(opt);
		$("#transport").change(function() {
			if ($(this).val() != 'virtual' && $(this).val() != 'offline') {
				$('#logisticssetting').show()
			} else {
				$('#logisticssetting').hide()
			}
		});
		$(document).on('click', '#trade_button', function() {
			uploadsuccess_forum= uploadsuccess_trade;
			$('#filedata').attr('multiple',null).click();
		});
	});
</script>
<!--{/if}-->