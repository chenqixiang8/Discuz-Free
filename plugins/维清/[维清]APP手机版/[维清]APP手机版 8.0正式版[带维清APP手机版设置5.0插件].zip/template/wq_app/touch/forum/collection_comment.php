<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['collection_comment'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{template common/header}-->
<!--{eval $headright=false;}-->
    <!--{if helper_access::check_module('collection')}-->
        <!--{eval $headright=true;}-->
    <!--{/if}-->

    <!--{eval
        $headparams['wtype'] = '1';
        $headparams['ltype'] = 'a';
        $headparams['lurl'] = $backurl;
        $headparams['cname'] = $Tlang['5d6bc314174ee1c8'];
        $headparams['rtype'] = 'a';
        $headparams['rclass'] = 'wqapp_f16';

        $headparams['rtype'] = 'a';
        $headparams['rname'] = $Tlang['984c5e7090423fd1'];
        $headparams['rurl'] = 'forum.php?mod=collection&action=edit';
        $headparams['rclass'] = '';

        echo wq_app_get_header($headparams,true,$headright);
    }-->
<script type="text/javascript" src="{$_G[setting][jspath]}home_friendselector.js?{VERHASH}"></script>
<script type="text/javascript">
	var fs;
	var clearlist = 0;
</script>

<div id="ct" class="wq_collection_comment">
		<div class="wq_comment_warp">

			<div class="wq_view_info">
                            <ul>
                                 <li class="wq_title wqnew_bottom">
                                        <a href="forum.php?mod=collection&action=view&ctid={$_G['collection']['ctid']}">{$_G['collection']['name']}</a>
                                </li>
                                <li class="wqnew_bottom" style="padding-bottom: 0;">
                                    <div title="$avgrate" class="wq_stars">
				<!--{if $_G['collection']['ratenum'] > 0}-->
					<span class="clct_ratestar z" style="position: relative;"><span class="star star$star">&nbsp;</span></span>
                                        <em class="wq_grey"style=" margin-left: 10px; line-height: 7px;vertical-align: text-top;">{lang collection_totalrates}</em>
				<!--{else}-->
					{lang collection_norate}
				<!--{/if}-->
				</div>
                                </li>
                                <li class="wqnew_bottom">
				<div class="wq_grey">{$_G['collection']['desc']}</div>
                                </li>
                            </ul>
			</div>
		</div>

		<!--{if $_G['collection']['commentnum'] > 0}-->
                <div class="wqseparate2"></div>
		<div class="bm">
			<!--{if $permission}-->
				<form action="forum.php?mod=collection&action=comment&op=del" method="POST">
			<!--{/if}-->
			<div class="wq_amoy_paste">
                             <div class="tag_list">
				<ul>
					<li class="a"><a href="forum.php?mod=collection&action=view&op=comment&ctid={$_G['collection']['ctid']}">{lang collection_commentlist}</a></li>
					<li><a href="forum.php?mod=collection&action=view&op=followers&ctid={$_G['collection']['ctid']}">{lang collection_followlist}</a></li>
					<!--{hook/collection_nav_extra}-->
				</ul>
                            </div>
			</div>
			<div class="wqcomment_list">
                            <ul>
			<!--{loop $commentlist $comment}-->
				<li class="wqnew_bottom">
					<div class="z wq_head"><a href="home.php?mod=space&uid=$comment['uid']"><!--{avatar($comment['uid'],small)}--></a></div>
                                        <div class="wq_info">
                                            <div>
                                                    <!--{if $permission}-->
                                                    <span class="y" style="padding-top:5px;">
                                                        <input type="checkbox" name="delcomment[]"class="weui_check" value="$comment[cid]">
                                                        <label class="weui_check_label" for="delcomment[]"><i class="weui_icon_checked"></i>
                                                             </label>
                                                    </span>
                                                    <!--{/if}-->
                                                    <a href="home.php?mod=space&uid={$comment['uid']}" c="1" class="width100">$comment[username]</a>
                                                    <span class="wq_grey wqapp_f12 wqm_left10">$comment[dateline]</span>
                                            </div>
                                            <div class="wq_grey wqapp_f12">$comment[message]</div>
                                            <!--{if $comment[rate]}-->
                                            <div class="cl"><span class="clct_ratestar z"><span class="star star$comment[rateimg]">&nbsp;</span></span></div><br/>
                                            <!--{/if}-->

                                        </div>
				</li>
			<!--{/loop}-->
                        </ul>
			</div>

			<div class="wq_delete_warp">
				<!--{if $permission}-->
				<input type="hidden" value="{$ctid}" name="ctid" />
			    <input type="hidden" name="formhash" id="formhash" value="{FORMHASH}" />
				<button type="submit" class="wq_delete"><span>{lang delete}</span></button>
				<!--{/if}-->
				<!--{if $multipage}-->$multipage<!--{/if}-->
			</div>
			<!--{if $permission}--></form><!--{/if}-->
		</div>
		<!--{/if}-->

		<!--{if $_G['group']['allowcommentcollection']}-->
                 <div class="wqseparate2"></div>
		<div class="bm">
			<form action="forum.php?mod=collection&action=comment&ctid={$_G['collection']['ctid']}" method="POST">
			 <div class="wqposts_atom">
                            <h3 class="wqnew_bottom"><a href="javascript:;" class="wqborder_bottom wqcolor wqnew_bottom_bule">{lang collection_ratecollection}</a>
                            </h3>
			<div class="wq_view_textarea {if $memberrate}bbda{/if}">
				<!--{if !$memberrate}-->
				<div style="padding-left:0.2rem; margin-top:.2rem;overflow: hidden;">
                                    <input type="hidden" name="ratescore" id="ratescore" />
                                    <span class="wq_clct_ratestar z">
                                            <span class="btn">
                                                <a href="javascript:;" onclick="rateStarSet('clct_ratestar_star',1,'ratescore')">1</a>
                                                <a href="javascript:;" onclick="rateStarSet('clct_ratestar_star',2,'ratescore')">2</a>
                                                <a href="javascript:;" onclick="rateStarSet('clct_ratestar_star',3,'ratescore')">3</a>
                                                <a href="javascript:;" onclick="rateStarSet('clct_ratestar_star',4,'ratescore')">4</a>
                                                <a href="javascript:;" onclick="rateStarSet('clct_ratestar_star',5,'ratescore')">5</a>
                                            </span>
                                            <span id="clct_ratestar_star" class="star star$memberrate"></span>
                                    </span>
				</div>
				<!--{/if}-->
				<div class="pbn wqtextarea_warp wqnew_bottom">
                                    <textarea name="message" rows="4" class="pt" style="width: 100%" placeholder="{$Tlang['530f626da3fb9b3e']}"></textarea>
				</div>
				<div class="wqbutton_warp"><button type="submit" class="button2 formdialog"><span>{lang collection_comment_submit}</span></button></div>
			</div>
			<!--{if $memberrate}-->
				<div class="wqview_stars">
					<span class="z">{lang collection_rated}&nbsp;</span>
					<span class="clct_ratestar"><span class="star star$memberrate"></span></span>
				</div>
			<!--{/if}-->
			</form>
		</div>
		<!--{/if}-->


	</div>
</div>
<!--{template common/footer}-->
<!--{/if}-->