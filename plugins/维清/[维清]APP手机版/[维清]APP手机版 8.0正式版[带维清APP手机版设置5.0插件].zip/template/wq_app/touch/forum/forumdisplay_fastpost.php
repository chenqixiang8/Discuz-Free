<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['forumdisplay_fastpost'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{if $_G[forum_thread][special] == 4}-->
<div class='wqjojn_activity'>
    <ul>
        <li><a href="javascript:;" class="notlogged" id="fastpostmessage"><i class="wqiconfont2 wqicon2-pinglun wqapp_f20"></i><br/>{$thread[replies]}{$Tlang['dbedca5ca18ae5c8']}</a></li>
        <li class='wqjojn_collection'>
             <a href="home.php?mod=spacecp&ac=favorite&type=thread&id=$_G[tid]&handlekey=newfav" class="dialog notlogged">
                    <!--{eval $flag = check_is_favorite($_G['tid'],'thread');}-->
                    <!--{if $flag && $_G['uid']}-->
                    <i class="wqiconfont2 wqicon2-shoucang3 wqapp_f22 wqcolor_yellow"></i><br/>{$Tlang['dbffe85907c5db92']}
                    <!--{else}-->
                    <i class="wqiconfont2 wqicon2-shoucang2 wqapp_f22"  id="i_crad_{$thread[tid]}"></i><br/>{$Tlang['23393395a9152c6f']}
                    <!--{/if}-->
              </a>
        </li>
        <li><a href="javascript:;"><i class="wqiconfont2 wqicon2-fenxiang01 wqapp_f22 wqshare" style="line-height: 0.38rem;"></i><br/><span style="line-height: 0.44rem;">{$Tlang['dae251a4f8687b1c']}</span></a></li>
    </ul>
    <!--{if $_G['uid'] && !$activityclose && (!$applied || $isverified == 2)}-->
        <div class="wqactivity_button"><a href="forum.php?mod=viewthread&tid={$_G['tid']}&activity=yes&extra=$extra">{$Tlang['e39b07482cb0532c']}</a></div>
    <!--{elseif $_G['uid'] && !$activityclose && $applied}-->
        <div class="wqactivity_button"style='background-color:#ffa264'><a href="forum.php?mod=viewthread&tid={$_G['tid']}&activity=yes&extra=$extra">{$Tlang['79868eec5cb44779']}</a></div>
    <!--{elseif !$_G['uid']}-->
        <div class="wqactivity_button"><a href="member.php?mod=logging&action=login" class="dialog notlogged">{$Tlang['4218475e1ba09401']}</a></div>
    <!--{/if}-->
</div>

<!--{else}-->
<!--{if $wq_app_setting['view_style'] == 1}-->
<div id="post_new"></div>
<div class="wqcomment_input wqnew_top">
    <div class="wqcomment_input_div z">
         <div class="wq_reply_eject notlogged" id="fastpostmessage">
             <i class="wqiconfont2 wqicon2-xiepinglun"></i>{$Tlang['9e598cfd08858c5a']}
           </div>
        <!--<input type="text" placeholder="{$Tlang['06e8cffa61d86ac8']}" name="message" id="fastpostmessage" class="notlogged" readonly />-->
    </div>
    <div class="wqcomment_input_icon">
        <ul>
            <li><a class="scrollIntoView" href="javascript:;"><i class="wqiconfont2 wqicon2-pinglun wqapp_f22 wqicon_position"><span class="wqcomment_num">{$_G[forum_thread][allreplies]}</span></i></a></li>
            <li class="wqcollection"><a href="home.php?mod=spacecp&ac=favorite&type=thread&id=$_G[tid]&handlekey=newfav" class="dialog notlogged">
                    <!--{eval $flag = check_is_favorite($_G['tid'],'thread');}-->
                    <!--{if $flag && $_G['uid']}-->
                    <i class="wqiconfont2 wqicon2-shoucang1 wqapp_f26 wqcolor_yellow wqicon_position"></i>
                    <!--{else}-->
                    <i class="wqiconfont2 wqicon2-shoucang1 wqapp_f26 wqicon_position"  id="i_crad_{$thread[tid]}"></i>
                    <!--{/if}-->
                </a></li>
            <li><a href="javascript:;"><i class="wqiconfont2 wqicon2-fenxiang01 wqapp_f24 wqshare wqview_share"></i></a></li>
        </ul>
    </div>
</div>
<!--{/if}-->
<script type="text/javascript">
    function succeedhandle_fastpostform(locationhref, message, param) {
            var pid = param['pid'];
            var tid = param['tid'];
            if(pid) {
                $.ajax({
                    type:'POST',
                    url:'forum.php?mod=viewthread&tid=' + tid + '&viewpid=' + pid,
                    dataType: 'html',
                    async: false,
                })
                .success(function(s) {
                    clearTimeout(setTimeout_location);
                    $('.wqempty_sofa').remove();
                        setTimeout(function () {
                            $('#view_big').show();
                            $('#mask, .new_list, .new_lump, .new_dialogbox2').hide();
                            $('.wqcomment_num').html(parseInt($('.wqcomment_num').html()) + 1);
                            $(window).scrollTop(scroll_Top);
                            $('#needmessage').val('');
                            $('.wqeditarea').html('');
                        }, 1500);
                        if ($('.wqposts_atom').length) {
                            $('.wqposts_atom').after(wqXml(s));
                        } else {
                            $('.postlist').after(wqXml(s));
                        }
                        $('.reply_posts').eq(0).find('img').addClass('wq_smilieimg');
                        var is_reply_reload="{$wq_app_setting['is_reply_reload']}";
                        if(is_reply_reload==1){
                           location.reload();
                        }
                    })
                .error(function(XMLHttpRequest, textStatus, errorThrown) {
                    location.reload();
                    popup.close();
                });
            } else {
                if(!message) {
                    message = '{lang postreplyneedmod}';
                }
                popup.open(message, 'alert');
            }
            $('#fastpostmessage').attr('value', '');
            if(param['sechash']) {
                $('.seccodeimg').click();
            }
    }
    $(function () {
        var intoView = scrollIntoView();
        $('.scrollIntoView').on('click', function () {
            intoView();
        });
    });

</script>
<!--{/if}-->
<!--{/if}-->