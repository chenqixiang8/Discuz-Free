<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['wq_buluotopicadmin'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{template common/wq_buluo_tpl_header}-->
<div class="ass_fl">
    <!--{if ($_GET['optgroup'] == 3 && $operation == 'delete') || ($_GET['optgroup'] == 4 && $operation == '')}-->
    <form id="moderateform" method="post" autocomplete="off" action="forum.php?mod=topicadmin&action=moderate&optgroup=$optgroup&modsubmit=yes&mobile=2&type=wq_buluo" >
        <input type="hidden" name="frommodcp" value="$frommodcp" />
        <input type="hidden" name="formhash" value="{FORMHASH}" />
        <input type="hidden" name="fid" value="$_G[fid]" />
        <input type="hidden" name="redirect" value="{echo dreferer()}" />
        <input type="hidden" name="reason" value="{lang topicadmin_mobile_mod}" />
        <!--{loop $threadlist $thread}-->
        <input type="hidden" name="moderate[]" value="$thread[tid]" />
        <!--{/loop}-->
        <!--{if $_GET['optgroup'] == 3}-->
        <!--{if $operation == 'delete'}-->
        <!--{if $_G['group']['allowdelpost']}-->
        <input name="operations[]" type="hidden" value="delete"/>
        <dt>{lang admin_delthread_confirm}</dt>
        <dd><input type="submit" class="formdialog button2" name="modsubmit" id="modsubmit" value="{lang confirms}" ><a href="javascript:;" onclick="popup.close();"  class="eject_cancel">{lang cancel}</a></dd>
        <!--{else}-->
        <dt>{lang admin_delthread_nopermission}</dt>
        <!--{/if}-->
        <!--{/if}-->
        <!--{elseif $_GET['optgroup'] == 4}-->
        <dt>
        <p>
            <input type="text" style="line-height:30px;" name="expirationclose" id="expirationclose"placeholder="{lang expire} "class="width_px" autocomplete="off" value="$expirationclose"  />
        </p>
        <p><span class="xg1">{$Tlang['130a94c5836b3edd']}2016-12-01 10:50</span></p>
        <p>
            <input type="radio" name="operations[]" id="admin_operations_1" class="weui_check" value="open" $closecheck[0]/>
            <label class="weui_check_label" for="admin_operations_1"><i class="weui_icon_checked"></i>{lang admin_open}</label>
        </p>
        <p>
            <input type="radio" name="operations[]" id="admin_operations_0" class="weui_check" value="close" $closecheck[1]/>
            <label class="weui_check_label" for="admin_operations_0"><i class="weui_icon_checked"></i>{lang admin_close}</label>
        </p>
        </dt>
        <dd><input type="submit" name="modsubmit" id="modsubmit"  value="{lang confirms}" class="formdialog button2"><a href="javascript:;" onclick="popup.close();" class="eject_cancel">{lang cancel}</a></dd>
        <!--{/if}-->
    </form>
    <!--{else}-->
    <dt>{lang admin_threadtopicadmin_error}</dt>
    <dd><input type="button" onclick="popup.close();" value="{lang confirms}" class="button2"></dd>
    <!--{/if}-->
</div>
<!--{template common/wq_buluo_tpl_footer}-->

<!--{/if}-->