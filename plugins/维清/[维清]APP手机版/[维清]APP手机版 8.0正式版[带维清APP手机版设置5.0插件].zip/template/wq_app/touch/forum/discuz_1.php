<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['discuz_1'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{eval $subforums_info = wq_app_get_subforum();}-->
<div id="sub_forum_$cat[fid]" class="sub_forum bm_c wqplate_ul1">
    <ul>
        <!--{loop $cat[forums] $forumid}-->
        <!--{eval $forum=$forumlist[$forumid];}-->
            <li class="wqnew_bottom">
                    {if $forum['subforums']}
                        <div class="bg_arrow bg_arrow_{$forum['fid']}">
                            <div class="mb_arrow wqnew_left">
                                <div class="bmw_arrow wqiconfont2 wqicon2-down_1 wqapp_f26 wq_grey2 bmw_arrow_{$forum['fid']}" onclick="show_subforum($forum['fid'])"></div>
                            </div>
                        </div>
                    <!--{/if}-->
                    <div class="bmw_fis">
                        <!--{if $forum[icon]}-->
                            $forum[icon]
                        <!--{else}-->
                            <a href="forum.php?mod=forumdisplay&fid={$forum['fid']}">
                                <img src="{$_G['style'][styleimgdir]}images/forum{if $forum[folder]}_new{/if}.gif" alt="$forum[name]" />
                            </a>
                        <!--{/if}-->
                        <a href="forum.php?mod=forumdisplay&fid={$forum['fid']}">
                            <!--{if $forum[todayposts] > 0 &&$wq_app_setting[tpost]==1}--><span class="y num"{if $forum['subforums']} style="margin-right: 0px;"<!--{/if}-->>$forum[todayposts]</span><!--{/if}-->
                            <font {if $forum[extra][namecolor]} style="color: {$forum[extra][namecolor]};"{/if}>{$forum[name]}</font>
                                <p><em>{lang forum_threads}: {echo dnumber($forum[threads])}</em><cite class="y">$forum[lastpost][dateline]</cite></p>
                        </a>
                    </div>
                </li>
                <!--{if $forum['subforums']}-->
                <div class="bmw_nav dis-com-box bmw_nav_{$forum['fid']}" style="display:none;">
                    <ul>
                        <!--{loop $subforums_info[$forum['fid']] $subforum}-->
                            <li class="wqnew_bottom">
                                <a href="forum.php?mod=forumdisplay&fid={$subforum['fid']}">
                                    <!--{if $subforum[icon]}-->
                                        <img src="{$subforum[icon]}" alt="$subforum[name]" />
                                    <!--{else}-->
                                        <img src="{$_G['style'][styleimgdir]}images/forum{if $forum[folder]}_new{/if}.gif" alt="$subforum[name]" />
                                    <!--{/if}-->

                                    <!--{if $subforum[todayposts] > 0}-->
                                        <span class="y num">$subforum[todayposts]</span>
                                    <!--{/if}-->

                                    <font {if $subforum[extra][namecolor]} style="color: {$subforum[extra][namecolor]};"{/if}>{$subforum[name]}</font>
                                    <p><em>{lang forum_threads}: {echo dnumber($subforum[threads])}</em><cite class="y">$subforum[lastpost][2]</cite></p>
                                </a>
                            </li>
                        <!--{/loop}-->
                    </ul>
                </div>
                <!--{/if}-->
        <!--{/loop}-->
    </ul>
</div>
<!--{/if}-->