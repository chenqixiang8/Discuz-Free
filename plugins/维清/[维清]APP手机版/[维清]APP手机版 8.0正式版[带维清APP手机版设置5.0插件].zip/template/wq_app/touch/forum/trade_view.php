<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['trade_view'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{eval $header_nav='null';}-->
<!--{template common/header}-->
<!--{eval
    $headparams['wtype'] = '1';
    $headparams['lurl'] = $backurl;
    $headparams['ltype'] = 'a';
    $headparams['cname'] = $Tlang['b4ba2fe0f6a28098'];
    echo wq_app_get_header($headparams);
}-->

<div id="ct" class="ct2 wp">
    <div class="mn buy_info">
        <form method="post" autocomplete="off" id="tradepost" name="tradepost" action="forum.php?mod=trade&orderid=$orderid" accept-charset="UTF-8">
            <!--{if !empty($_G['gp_modthreadkey'])}-->
            <input type="hidden" name="modthreadkey" value="$_G[gp_modthreadkey]" />
            <!--{/if}-->
            <!--{if !empty($_G['gp_tid'])}-->
            <input type="hidden" name="tid" value="$_G[gp_tid]" >
            <!--{/if}-->
            <input type="hidden" name="formhash" value="{FORMHASH}"/>
            <div class="bm">
                <h3 class="bm_h"><!--{if !$tradelog[offline]}-->{lang trade_pay_alipay}<!--{else}-->{lang trade_pay_offline}<!--{/if}--></h3>
                <div class="bm_c torder">
                    <table cellspacing="0" cellpadding="0" class="tfm">
                        <tr>
                            <th>{lang status}</th>
                            <td style="line-height:30px; font-size: 14px;">$tradelog[statusview] ($tradelog[lastupdate])</td>
                        </tr>
                        <!--{if $tradelog[offline] && $offlinenext}-->
                        <tr>
                            <td colspan="2"><input id="password" name="password" type="password" class="pt wqnew_all"  placeholder="{lang trade_password}" /></td>
                        </tr>
                        <tr>
                            <td  colspan="2">
                                <p class="border1 m_t5 m_b10 wqnew_all"><textarea id="buyermsg" name="message" rows="3" class="pt"   placeholder="{lang trade_message},{lang trade_seller_remark_comment}"></textarea></p>
                            </td>
                        </tr>
                        <tr>
                            <!--{block wq_trade_a}-->
                            <!--{eval $p=0;}-->
                            <!--{loop $offlinenext $nextid $nextbutton}-->
                            <!--{eval $p++;}-->
                                <button class="pn" type="button" onclick="$('#offlinestatus').val('$nextid');
                                    $('#offlinesubmit').click();"><em>$Tlang['trade_offline_'.$nextid]</em></button>
                        <!--{/loop}-->
                        <!--{/block}-->
                        <!--{if $p>0}-->
                        <td class="pns trade_btn" colspan="2">
                            <div class="trade_btn_$p">$wq_trade_a</div>
                            <input type="hidden" id='offlinestatus' name="offlinestatus" value=""/>
                            <input type="hidden" name="offlinesubmit" value="ture"/>
                            <input type="submit" id="offlinesubmit"  class="formdialog" style="display: none" />
                        </td>
                        <!--{/if}-->

                        </tr>
                        <!--{/if}-->
                        <!--{if trade_typestatus('successtrades', $tradelog[status]) || trade_typestatus('refundsuccess', $tradelog[status])}-->
                        <tr>
                            <!--{if $tradelog[ratestatus] == 3}-->
                            <th>{lang eccredit_post_between}</th><td>&nbsp;</td>
                            <!--{elseif ($_G['uid'] == $tradelog[buyerid] && $tradelog[ratestatus] == 1) || ($_G['uid'] == $tradelog[sellerid] && $tradelog[ratestatus] == 2)}-->
                            <th>{lang eccredit_post_waiting}</th><td>&nbsp;</td>
                            <!--{else}-->
                            <!--{if ($_G['uid'] == $tradelog[buyerid] && $tradelog[ratestatus] == 2) || ($_G['uid'] == $tradelog[sellerid] && $tradelog[ratestatus] == 1)}-->
                            <th>{lang eccredit_post_already}</th>
                            <!--{else}-->
                            <th>&nbsp;</th>
                            <!--{/if}-->
                            <td class="pns">
                                <!--{if $_G['uid'] == $tradelog[buyerid]}-->
                                <!--<button class="pn" type="button" onclick="window.open('home.php?mod=spacecp&ac=eccredit&op=rate&orderid=$tradelog[orderid]&type=0', '', '')"><span>{lang eccredit1}</span></button>-->
                                <!--{elseif $_G['uid'] == $tradelog[sellerid]}-->
                                <!--<button class="pn" type="button" onclick="window.open('home.php?mod=spacecp&ac=eccredit&op=rate&orderid=$tradelog[orderid]&type=1', '', '')"><span>{lang eccredit1}</span></button>-->
                                <!--{/if}-->
                            </td>
                            <!--{/if}-->
                        </tr>
                        <!--{elseif !$tradelog[offline]}-->
                        <tr>

                            <td class="pns" colspan="2">
                                <!--{if $tradelog[status] == 0 && $tradelog[buyerid] == $_G['uid']}-->
                                <!--{if $tradelog[tenpayaccount]}-->
                                <button class="pn" type="button" name="" onclick="location.href = 'forum.php?mod=trade&orderid=$orderid&pay=yes&apitype=tenpay';"><span>{lang trade_online_tenpay}</span></button>
                                <!--{/if}-->
                                <!--{else}-->
                                <!--{if $tradelog[paytype] == 1}-->
                                <button class="pn" type="button" onclick="location.href = '$loginurl'"><span>{$Tlang['6847c86b00975bea']}</span></button>
                                <!--{/if}-->
                                <!--{if $tradelog[paytype] == 2}-->
                                <button class="pn" type="button" onclick="location.href = '$loginurl'"><span>{$Tlang['a91d2a1ce160fc9c']}</span></button>
                                <!--{/if}-->
                                <!--{/if}-->
                            </td>
                        </tr>
                        <!--{/if}-->
                    </table>
                </div>
            </div>
            <div class="buy_info torder_securied m_t10">
                <h3 class="bm_h wqnew_bottom">{lang trade_order} <!--{if $tradelog[tradeno]}-->$tradelog[tradeno]<!--{/if}--></h3>
                <div class="bm_c  wqapp_p_top10 torder">
                    <div class="spvimg">
                        <a href="forum.php?mod=viewthread&tid=$trade[tid]"><!--{if $trade['aid']}--><img src="{echo getforumimg($trade[aid])}" width="90"/><!--{else}--><img src="{IMGDIR}/nophotosmall.gif" /><!--{/if}--></a>
                    </div>
                    <div class="spi">
                        <h4 class="wx bbda"><a href="forum.php?mod=viewthread&tid=$trade[tid]">$tradelog[subject]</a></h4>
                        <dl>
                            <dt class="lh">
                            <span>{$Tlang['3d661f9dcff22585']}</span><!--{if $tradelog[price] > 0}--><strong>&yen;$tradelog[price]</strong>&nbsp;<!--{/if}-->
                            <!--{if $_G['setting']['creditstransextra'][5] != -1 && $tradelog[credit]}-->{$_G[setting][extcredits][$_G['setting']['creditstransextra'][5]][title]}<strong>$tradelog[credit]</strong><!--{/if}-->
                            </dt>
                            <dt class="lh">
                            <span>{lang trade_seller}:</span><a href="home.php?mod=space&do=profile&uid=$tradelog[sellerid]" class="xg2">$tradelog[seller]</a>
                            <!--{if $_G['uid'] != $tradelog['sellerid']}-->
                            <a href="home.php?mod=space&do=pm&subop=view&touid=$tradelog[sellerid]" class="xg2"><img src="{IMGDIR}/pmto.gif"/></a>
                            <!--{/if}-->
                            </dt>
                            <dt class="lh">
                            <span>{lang trade_buyer}:</span><a href="home.php?mod=space&do=profile&uid=$tradelog[buyerid]">$tradelog[buyer]</a>
                            <!--{if $_G['uid'] != $tradelog['buyerid']}-->
                            <a href="home.php?mod=space&do=pm&subop=view&touid=$tradelog[buyerid]" class="xg2"><img src="{IMGDIR}/pmto.gif"/></a>
                            <!--{/if}-->
                            </dt>
                            <div id='wq_trade_show' class="wq_trade_dt" style='display: none'>
                                <!--{if $tradelog[status] == 0 && $tradelog[sellerid] == $_G['uid']}-->
                                <dt style="clear:left" class="seller_input">
                                <label for="newprice">{$Tlang['e555d356e453d712']}</label>
                                <span>&yen;<input type="text" id="newprice" name="newprice" value="$tradelog[baseprice]" class="px graded" style="width:100px"/></span>&nbsp;
                                <!--{if $_G['setting']['creditstransextra'][5] != -1 && $tradelog[credit]}-->
                                {$_G[setting][extcredits][$_G['setting']['creditstransextra'][5]][title]} <input type="text" id="newcredit" name="newcredit" value="$tradelog[basecredit]" class="px" style="width:100px"/>
                                <!--{/if}-->
                                </dt>
                                <!--{/if}-->
                                <dt style="clear:left"><label for="newnumber">{$Tlang['e4ed182bebceaba9']}</label>
                                <!--{if $tradelog[status] == 0 && $tradelog[buyerid] == $_G['uid']}-->
                                <!--{eval $inventory=$trade[amount]-$trade[totalitems];}-->
                                <em class="rate_table rate_buy">
                                    <a href="javascript:;" class="wqiconfont2 wqicon2-jian jianhao subtract_rate nolight f20" id="minus_number"></a>
                                    <em class="rate_sz buy_sz"><input type="tel" id='wq_number' name="newnumber" class="graded" value="$tradelog[number]"></em>
                                    <input type="hidden" id="wq_number_hidden" value="$tradelog[number]">
                                    <a href="javascript:;" class="wqiconfont2 wqicon2-jia jiahao add_rate light f20" id="add_number"></a>
                                    <em>({$Tlang['eb3cb9138a794033']} {$inventory})</em>
                                </em>
                                <script type="text/javascript">
                                    $('#minus_number').click(function () {
                                        var wq_number = parseInt($('#wq_number').val()) - 1;
                                        if (wq_number >= 1) {
                                            $('#wq_number').val(wq_number);
                                            wq_numbers(wq_number);
                                        }
                                    });
                                    $('#add_number').click(function () {
                                        var wq_number = parseInt($('#wq_number').val()) + 1;
                                        if (wq_number <= '$inventory') {
                                            $('#wq_number').val(wq_number);
                                            wq_numbers(wq_number);
                                        }
                                    });
                                    $('#wq_number').blur(function () {
                                        var wq_number = parseInt($(this).val());
                                        if (wq_number <= '$inventory' && wq_number >= 1) {
                                            $('#wq_number').val(wq_number);
                                            wq_numbers(wq_number);
                                        } else {
                                            $('#wq_number').val($('#wq_number_hidden').val());
                                        }
                                    });
                                    function wq_numbers(wq_number) {
                                        $('#wq_number_hidden').val(wq_number);
                                        $('#add_number').attr('class', 'wqiconfont2 wqicon2-jia jianhao add_rate wqapp_f24 ' + (wq_number + 1 > '$inventory' ? 'no' : '') + 'light');
                                        $('#minus_number').attr('class', 'wqiconfont2 wqicon2-jian jianhao subtract_rate wqapp_f24 ' + (wq_number - 1 < 1 ? 'no' : '') + 'light');
                                    }
                                    wq_numbers(parseInt('$tradelog[number]'));
                                </script>
                                <!--{else}-->
                                $tradelog[number]
                                <!--{/if}-->
                                </dt>

                                <dt>
                                <!--{if $tradelog['transport'] == 0}-->{lang post_trade_transport_offline}<!--{/if}-->
                                <!--{if $tradelog['transport'] == 1}-->{lang post_trade_transport_seller}<!--{/if}-->
                                <!--{if $tradelog['transport'] == 2}-->{lang post_trade_transport_buyer}<!--{/if}-->
                                <!--{if $tradelog['transport'] == 3}-->{lang post_trade_transport_virtual}<!--{/if}-->
                                <!--{if $tradelog['transport'] == 4}-->{$Tlang['fbbcd73624c1c2a2']}<!--{/if}-->
                                <!--{if $tradelog['transport']}-->
                                {lang trade_transportfee}
                                &yen;
                                <!--{if $tradelog[status] == 0 && $tradelog[sellerid] == $_G['uid']}-->
                                <span class="seller_input"><input type="text" name="newfee" value="$tradelog['transportfee']" class="px" style="width:100px"/></span>
                                <!--{else}-->
                                $tradelog[transportfee]
                                <!--{/if}-->
                                <!--{/if}-->
                                </dt>

                                <!--{if $tradelog['transport'] != 3}-->

                                <!--{if $tradelog[status] == 0 && $tradelog[buyerid] == $_G['uid']}-->
                                <dt>
                                <em class="w_list">{$Tlang['fa16d5a8e5864f85']}</em>
                                <span><input type="text" id="newbuyername" name="newbuyername"  value="$tradelog[buyername]" maxlength="50" class="px wqnew_all"/></span>
                                </dt>
                                <!--{elseif $tradelog[buyername]}-->
                                <dt><em class="w_list">{$Tlang['fa16d5a8e5864f85']}</em>
                                $tradelog[buyername]
                                </dt>
                                <!--{/if}-->



                                <!--{if $tradelog[status] == 0 && $tradelog[buyerid] == $_G['uid']}-->
                                <dt> <em class="w_list">{$Tlang['2d79d3a27c3045b7']}</em>
                                <span><input type="text" id="newbuyercontact" name="newbuyercontact" value="$tradelog[buyercontact]" maxlength="100" size="40" class="px wqnew_all" /></span>
                                </dt> <!--{elseif $tradelog[buyercontact]}-->
                                <dt><em class="w_list"> {$Tlang['2d79d3a27c3045b7']}</em>
                                $tradelog[buyercontact]</dt>
                                <!--{/if}-->



                                <!--{if $tradelog[status] == 0 && $tradelog[buyerid] == $_G['uid']}-->
                                <dt> <em class="w_list">{$Tlang['e514023a6801f917']}</em>
                                <span><input type="text" id="newbuyerzip" name="newbuyerzip" value="$tradelog[buyerzip]" maxlength="10" class="px wqnew_all" /></span>
                                </dt> <!--{elseif $tradelog[buyerzip]}-->
                                <dt> <em class="w_list">{$Tlang['e514023a6801f917']}</em>
                                $tradelog[buyerzip] </dt>
                                <!--{/if}-->



                                <!--{if $tradelog[status] == 0 && $tradelog[buyerid] == $_G['uid']}-->
                                <dt> <em class="w_list">{$Tlang['a4a7de757d32148c']}</em>
                                <span><input type="text" id="newbuyerphone" name="newbuyerphone" value="$tradelog[buyerphone]" maxlength="20" class="px wqnew_all" /></span>
                                </dt><!--{elseif $tradelog[buyerphone]}-->
                                <dt> <em class="w_list">{$Tlang['a4a7de757d32148c']}</em>
                                $tradelog[buyerphone] </dt>
                                <!--{/if}-->



                                <!--{if $tradelog[status] == 0 && $tradelog[buyerid] == $_G['uid']}-->
                                <dt> <em class="w_list">{$Tlang['734e5ea9b979860a']}</em>
                                <span><input type="text" id="newbuyermobile" name="newbuyermobile" value="$tradelog[buyermobile]"  maxlength="20" class="px wqnew_all" /></span>
                                </dt> <!--{elseif $tradelog[buyermobile]}-->
                                <dt><em class="w_list">{$Tlang['734e5ea9b979860a']}</em>
                                $tradelog[buyermobile]</dt>
                                <!--{/if}-->


                                <!--{else}-->
                                <input type="hidden" name="newbuyername" value="" />
                                <input type="hidden" name="newbuyercontact" value="" />
                                <input type="hidden" name="newbuyerzip" value="" />
                                <input type="hidden" name="newbuyerphone" value="" />
                                <input type="hidden" name="newbuyermobile" value="" />
                                <!--{/if}-->

                                <!--{if $tradelog[status] == 0 && $tradelog[buyerid] == $_G['uid']}-->
                                <dt valign="top"> <em class="w_list v_a_top m_t10" valign="top">{$Tlang['81bba0c2d20024f3']}</em>
                                <span class="border1 m_t5 wqnew_all" style="    display: inline-table; width: 75%;"><textarea id="newbuyermsg" name="newbuyermsg" rows="3"  class="pt px">$tradelog[buyermsg]</textarea></span>
                                </dt><!--{elseif $tradelog[buyermsg]}-->
                                <dt valign="top"> <em class="w_list">{$Tlang['81bba0c2d20024f3']}</em>
                                $tradelog[buyermsg] </dt>
                                <!--{/if}-->

                                <!--{if $tradelog[status] == 0 && ($_G['uid'] == $tradelog['sellerid'] || $_G['uid'] == $tradelog['buyerid'])}-->
                                <dt class="pns padd_0">
                                <button class="pn m_0_10 wqbg_color wqtrade_confirm" type="submit" name="tradesubmit" value="true">{lang trade_submit_order}</button>
                                </dt>
                                <!--{/if}-->
                            </div>
                        </dl>
                    </div>
                    <div class="p_load_more bl_none m_t10"><a href="javascript:;">{$Tlang['542342c528357511']}<i class="wqiconfont2 wqicon2-down_1"></i></a></div>
                    <script>
                        $('.p_load_more').click(function () {
                            var scrollTop = $(document).scrollTop();
                            $('#wq_trade_show').toggle();
                            if ($('#wq_trade_show').is(':hidden')) {
                                $('.p_load_more a').html('{$Tlang[542342c528357511]}<i class="wqiconfont2 wqicon2-down_1">');
                            } else {
                                $('.p_load_more a').html('{$Tlang[c699f8e04db8c066]}<i class="wqiconfont2 wqicon2-down_1 wqicon2-up_1">');
                            }
                            var top = $('.p_load_more').offset().top - scrollTop;
                            $('html,body').animate({scrollTop: top < 0 ? -top : top}, 1000);
                        });
                    </script>
                </div>
            </div>
            <!--{if $tradelog['offline'] && !empty($messagelist)}-->
            <h3 class="bbda mtw">{lang trade_message}</h3>
            <div class="xld xlda buy_message">
                <!--{loop $messagelist $message}-->
                <dl class="bbda">
                    <dd class="m avt"><!--{avatar($message[0],small)}--></dd>
                    <dt><a href="home.php?mod=space&do=profile&uid=$message[0]" >$message[1]</a>&nbsp;<span class="xg1 xw0"> $message[2]</span></dt>
                        <dt>$message[3]</dt>
                </dl>
                <!--{/loop}-->
            </div>
            <!--{/if}-->
        </form>
    </div>
</div>

<!--{template common/footer}-->

<!--{/if}-->