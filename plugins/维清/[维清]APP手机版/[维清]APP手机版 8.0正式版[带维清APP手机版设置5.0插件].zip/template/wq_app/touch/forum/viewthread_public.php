<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['viewthread_public'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->


<div class="message wqshare_wx wqpost_view_warp <!--{if $wq_app_setting['view_style'] == 2}--> wqpost_view_warp_public<!--{/if}-->">

    <!--{if $rushreply}-->
        <div class="wqrob_floors">
            <ul>
          <!--{if $rushresult[creditlimit] == ''}-->
            <p class="wq_title">{lang thread_rushreply}</p>
                <!--{else}-->
              <p class="wq_title">{lang thread_rushreply_limit}</p>
                <!--{/if}-->
                <!--{if $rushresult['timer']}-->
                 <li class="wqnew_bottom">
                     <span>
                        {$Tlang['6ccb801b9732ef4f']}
                        <span id="rushtimer_body_$thread[tid]"></span>
                        <script language="javascript">settimer($rushresult['timer'], 'rushtimer_body_$thread[tid]');</script>
                        {if $rushresult['timertype'] == 'start'}{lang header_start} {else}{$Tlang['4dfdb2da7f5ab00d']}{/if}
                     </span>
                 </li>

                <!--{/if}-->
                <!--{if $rushresult[stopfloor]}-->
                <li class="wqnew_bottom"><em>{$Tlang['66a6e4b950b92dee']}</em> <span class="text_left">$rushresult[stopfloor]</span></li>
                <!--{/if}-->
                <!--{if $rushresult[rewardfloor]}-->
                    <li class="wqnew_bottom"><em>{lang thread_rushreply_floor}</em> <span class="text_left">$rushresult[rewardfloor]</span></li>
                <!--{/if}-->
                <!--{if $rushresult[rewardfloor] && $_GET['checkrush']}-->
                    <li class="ptn wqnew_bottom">
                        <!--{if $countrushpost}--><span class="c_green">{$countrushpost}{lang thread_rushreply_rewardnum}</span><!--{else}--> <span class="wq_grey">{lang thread_rushreply_noreward} </span><!--{/if}-->&nbsp;&nbsp;
                        <a href="forum.php?mod=viewthread&tid=$_G[tid]" class="wqcolor">{lang thread_rushreply_check_back}</a>
                    </li>
                <!--{/if}-->
                <!--{if $rushresult[rewardfloor]}-->
                <li class="wq_see_btn wqnew_bottom">
                    <!--{if $_G['uid'] == $_G['thread']['authorid'] || $_G['forum']['ismoderator']}-->
                        <a href="forum.php?mod=ajax&action=get_rushreply_membernum&tid=$_G[tid]&handlekey=membernum" class="pn xi2 dialog wqcolor wqm_right15">
                            {lang thread_rushreply_statnum}
                        </a>
                    <!--{/if}-->
                    <!--{if !$_GET['checkrush']}-->
                    <a href="forum.php?mod=viewthread&tid=$post[tid]&checkrush=1" rel="nofollow" class="pn xi2 wqcolor">{lang rushreply_view}</a>
                    <!--{/if}-->
                </li>
            <!--{/if}-->
             </ul>
        </div>
    <!--{/if}-->

    <!--{if $post['warned']}-->
        <span class="quote">{lang warn_get}</span>
    <!--{/if}-->

    <!--{if !$post['first'] && !empty($post[subject])}-->
        <h2><strong>$post[subject]</strong></h2>
    <!--{/if}-->

    <!--{if $_G['adminid'] != 1 && $_G['setting']['bannedmessages'] & 1 && (($post['authorid'] && !$post['username']) || ($post['groupid'] == 4 || $post['groupid'] == 5) || $post['status'] == -1 || $post['memberstatus'])}-->
        <div class="quote">{lang message_banned}</div>
    <!--{elseif $_G['adminid'] != 1 && $post['status'] & 1}-->
        <div class="quote">{lang message_single_banned}</div>
    <!--{elseif $needhiddenreply}-->
        <div class="quote">{lang message_ishidden_hiddenreplies}</div>
    <!--{elseif $post['first'] && $_G['forum_threadpay']}-->
        <!--{template forum/viewthread_pay}-->
    <!--{else}-->
        <!--{if $_G['setting']['bannedmessages'] & 1 && (($post['authorid'] && !$post['username']) || ($post['groupid'] == 4 || $post['groupid'] == 5))}-->
            <div class="quote">{lang admin_message_banned}</div>
        <!--{elseif $post['status'] & 1}-->
            <div class="quote">{lang admin_message_single_banned}</div>
        <!--{/if}-->

        <!--{if $_G['forum_thread']['price'] > 0 && $_G['forum_thread']['special'] == 0}-->
            <div class="locked">
                {lang pay_threads}: <strong>$_G[forum_thread][price] {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][title]} </strong>
            <a class="dialog notlogged" href="forum.php?mod=misc&action=viewpayments&tid=$_G[tid]" >{lang pay_view}</a>
            </div>
        <!--{/if}-->

	<!--{template forum/viewthread_sort}-->

        <!--{if $post['first']}-->
            <!--{if $_G[forum_thread][special] == 1}-->
                <!--{template forum/viewthread_poll}-->
            <!--{elseif $_G[forum_thread][special] == 2}-->
                <!--{template forum/viewthread_trade}-->
            <!--{elseif $_G[forum_thread][special] == 3}-->
                <!--{template forum/viewthread_reward}-->
            <!--{elseif $_G[forum_thread][special] == 4}-->
                <!--{template forum/viewthread_activity}-->
            <!--{elseif $_G[forum_thread][special] == 5}-->
                <!--{template forum/viewthread_debate}-->
            <!--{elseif $threadplughtml}-->
                $threadplughtml
            <!--{/if}-->
		<!--{/if}-->
		$post[message]
		<!--{if $_G['setting']['mobile']['mobilesimpletype'] == 0}-->
			<!--{if $post['attachment']  && $_GET['from'] != 'preview'}-->
				<div class="grey" style="padding:0px 12px 12px 12px;font-size: 15px; line-height: 22px;">
					{lang attachment}: <em><!--{if $_G['uid']}-->{lang attach_nopermission}<!--{else}-->{lang attach_nopermission_login}<!--{/if}--></em>
				</div>
			<!--{elseif $post['imagelist'] || $post['attachlist']}-->
				<!--{if $post['imagelist']}-->
					<div class="message wqshare_wx">
						<ul>
							<!--{echo showattach($post, 1)}-->
						</ul>
					</div>
				<!--{/if}-->
				<!--{if $post['attachlist']}-->
						<!--{echo showattach($post)}-->
				<!--{/if}-->
			<!--{/if}-->
		<!--{/if}-->
    <!--{/if}-->
</div>


<!--{hook/viewthread_postbottom_mobile $postcount}-->
<!--{if ($post[tags] || $relatedkeywords) && $_GET['from'] != 'preview'}-->
    <div class="my_post_view" id="my_post_view">
        <div class="tag_list">
            <ul>
                <!--{if $post[tags]}-->
                    <!--{eval $tagi = 0;}-->
                    <!--{loop $post[tags] $var}-->
                        <!--{if $tagi}--><!--{/if}--> <li><a title="$var[1]" href="misc.php?mod=tag&id=$var[0]">$var[1]</a></li>
                        <!--{eval $tagi++;}-->
                    <!--{/loop}-->
                <!--{/if}-->
                <!--{if $relatedkeywords}--><span>$relatedkeywords</span><!--{/if}-->
            </ul>
        </div>
    </div>

    <!--{eval $my_roll_tag='my_post_view';}-->
        <!--{template common/slide}-->
    <!--{/if}-->
    <!--{if $post['signature'] && ($_G['setting']['bannedmessages'] & 4 && ($post['memberstatus'] == '-1' || ($post['authorid'] && !$post['username']) || ($post['groupid'] == 4 || $post['groupid'] == 5) || ($post['status'] & 1)))}-->
			<div class="wqapp_sign" style="padding-bottom: 10px;">{lang member_signature_banned}</div>
		<!--{elseif $post['signature'] && !$post['anonymous'] && $showsignatures}-->
			<div class="sign wqapp_sign" style="padding-bottom: 10px; max-height:{$_G['setting']['maxsigrows']}px;maxHeightIE:{$_G['setting']['maxsigrows']}px;">$post[signature]</div>
		<!--{elseif !$post['anonymous'] && $showsignatures && $_G['setting']['globalsightml']}-->
			<div class="wqapp_sign" style="padding-bottom: 10px;">$_G['setting']['globalsightml']</div>
		<!--{/if}-->
    <!--{if $_GET['from'] != 'preview' && !empty($post['ratelog'])}-->
        <div class="wqseparate2"></div>
        <div class="wqscore_num" id="ratelog_$post[pid]">
            <div class="wqscore_num_specific">{$Tlang['b0ac651a9d17d521']}<span class="wq_grey y"><!--{echo count($postlist[$post[pid]][totalrate]);}-->{$Tlang['9460d1893ae7ba19']}</span></div>
            <div class="wqscore_num_head">
                <div class="tag_list">
                    <ul>
                        <!--{loop $post['ratelog'] $uid $ratelog}-->
                            <li><a href="home.php?mod=space&do=profile&uid=$uid"><!--{echo avatar($uid, 'small');}--></a></li>
                        <!--{/loop}-->
                    </ul>
                </div>
            </div>
        </div>
    <!--{else}-->
        <div id="post_rate_div_$post[pid]"></div>
    <!--{/if}-->

    <div class="wqscore_zambia">
        <!--{if ($_G['group']['raterange'] && $post['authorid'])||($_GET['from'] != 'preview' && !empty($post['ratelog']))}-->
            <!--{if $_GET['from'] != 'preview' && !empty($post['ratelog'])}-->
                <!--{eval $ajax_action="viewratings";$rate_class="rate_viewratings"}-->
            <!--{else}-->
                <!--{eval $ajax_action="rate";$rate_class="grades";}-->
            <!--{/if}-->
            <a href="javascript:;" url="forum.php?mod=misc&action=$ajax_action&tid=$_G[tid]&pid=$post[pid]" class="$rate_class" {if $_G['group']['raterange'] && $post['authorid']}pid="$post[pid]"{/if}>
               <i class="wqiconfont2 wqicon2-dianping wqapp_f18 wqm_right3"></i>{$Tlang['0487fbf42b51d238']}
            </a>
        <!--{/if}-->
        <!--{if !$_G['forum']['disablecollect'] && helper_access::check_module('collection')}-->
        <a href="forum.php?mod=collection&action=edit&op=addthread&tid=$_G[tid]&handlekey=k_collect" class="dialog wqm_left10" id="k_collect">
                <i class="wqiconfont2 wqicon2-menhu wqapp_f18 wqm_right3"></i>{lang collection}
                <span id="collectionnumber"{if !$post['releatcollectionnum']} style="display:none"{/if}>{$post['releatcollectionnum']}</span>

        </a>
        <!--{/if}-->
        <!--{if $wq_app_setting['view_open_promote']}-->
            <a href="javascript:;" class="wqm_left10 promotionqrcode wqapp_promotionqrcode"><i class="wqiconfont2 wqicon2-guangbo wqapp_f18 wqm_right3"></i>{$Tlang['04ce6c956620ce57']}</a>
        <!--{/if}-->
        <!--{if $wq_app_setting['view_style'] == 1}-->
        <!--{if $post['authorid'] != $_G['uid']}-->
                 <span class="y wqapp_f12 wqm_left10"><a href="misc.php?mod=report&rtype=post&rid=$post[pid]&tid=$_G[tid]&fid=$_G[fid]" class="dialog">{lang report}</a></span>
             <!--{/if}-->
            <!--{if !empty($_G['setting']['recommendthread']['addtext'])}-->
                <span class="y">
                    <a href="forum.php?mod=misc&action=recommend&do=add&tid=$_G[tid]&hash={FORMHASH}&handlekey=recommendadd" class="wq_grey dialog recommendadd_zan notlogged" dataid="recommendadd">
                        <i class="wqiconfont2 wqicon2-gzan wqm_right3 wqapp_f14"></i>
                        <i id="recommend_add">{$_G['thread']['recommend_add']}</i>
                    </a>
                </span>
            <!--{/if}-->
        <!--{/if}-->
    </div>


    <!--{if $wq_app_setting['view_style'] == 1}-->
    <!--{eval
    $nextoldset=wq_app_get_last_thread_and_next_thread();
    $nextnewset=wq_app_get_last_thread_and_next_thread('nextnewset');
    }-->
    <div class="view_up_down">
        <!--{if $nextoldset}-->
            <p><a href="forum.php?mod=redirect&goto=nextoldset&tid=$_G[tid]" title="{lang last_thread}">{$Tlang['8dccd8233557b4aa']} {$nextoldset}</a></p>
        <!--{/if}-->
        <!--{if $nextnewset}-->
            <p><a href="forum.php?mod=redirect&goto=nextnewset&tid=$_G[tid]" title="{lang next_thread}" >{$Tlang['7e2890e74680b8e9']} {$nextnewset}</a></p>
        <!--{/if}-->
    </div>
    <!--{/if}-->
    <!--{if $wq_app_setting['view_style'] == 2}-->
    <div class="wqyuedu">{$Tlang['a6aa5366e09f370c']} {$_G[forum_thread][views]}
        <a href="forum.php?mod=misc&action=recommend&do=add&tid=$_G[tid]&hash={FORMHASH}&handlekey=recommendadd" class="wq_grey dialog recommendadd_zan notlogged" dataid="recommendadd">
            <i class="wqiconfont2 wqicon2-gzan wqm_right3 wqapp_f14"></i>
            <em id="recommend_add">{$_G['thread']['recommend_add']}</em>
        </a>
        <!--{eval $report=$_G['setting']['footernavs']['report'];}-->
        <!--{if $report['available'] && ($report['type'] && (!$report['level'] || ($report['level'] == 1 && $_G['uid']) || ($report['level'] == 2 && $_G['adminid'] > 0) || ($report['level'] == 3 && $_G['adminid'] == 1)) ||
                                            !$report['type'] && ($report['id'] == 'report' && $_G['uid']))}-->
            <span class="y"><a href="misc.php?mod=report&url={$_G[currenturl_encode]}&handlekey=miscreport&ajaxtarget=fwin_content_miscreport" class="dialog wq_grey">$report[navname]</a></span>
        <!--{/if}-->
    </div>
    <!--{/if}-->
</div>

<!--{if $post['relateitem']}-->
    <div class="wqseparate2"></div>
    <div class="wqrelated_posts">
        <h3><a href="javascript:;" class="wqborder_bottom wqcolor">{lang related_thread}</a></h3>
        <ul>
            <!--{loop $post['relateitem'] $key $var}-->
                <li {if $key>3}style="display:none;" data-display="none"{/if}><a href="forum.php?mod=viewthread&tid=$var[tid]" title="$var[subject]" class="wqellipsis">$var[subject]</a></li>
            <!--{/loop}-->
            <!--{if $key>4}-->
            <li class="p_load_more bl_none m_t-1" style="line-height: 35px;" onclick="$('.wqrelated_posts ul li[data-display=\'none\']').toggle();$(this).children().toggleClass('wqicon2-appup_1');">
                {$Tlang['668100c73123b792']}
                 <i class="wqiconfont2 wqicon2-down_1 wqapp_f18"></i>
            </li>
            <!--{/if}-->
        </ul>
    </div>
<!--{/if}-->
<!--{/if}-->