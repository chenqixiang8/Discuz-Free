<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['collection_recommend'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{template common/header}-->
<div class="wqshield_notice">
<form action="forum.php?mod=collection&action=comment&op=recommend&ctid={$ctid}" id="form_collectionrecommend" name="form_collectionrecommend" method="POST">
	<div class="wqshield_con">
            <p class="wqinput"><input type="text" value="" name="threadurl"  placeholder="{lang collection_recommend_thread_url}" /></p>
		<!--<button type="submit" class="pn pnc"><span>{lang collection_recommend_submit}</span></button>-->
        </div>
	<input type="hidden" value="{FORMHASH}" name="formhash" />
	<input type="hidden" name="inajax" value="1">
	<input type="hidden" name="handlekey" value="$_GET['handlekey']">
         <p class="wqbtn_can wqnew_top">
            <a href="javascript:;" onclick="popup.close();" class="wqeject_cancel wqnew_right">{$Tlang['9c825be7149e5b97']}</a>
            <button type="submit" value="submit" class="wqdetermine formdialog">{$Tlang['387e9a577ee04ca3']}</button>
        </p>
</form>
</div>
<!--{template common/footer}-->
<!--{/if}-->