<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['usertag'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{template common/header}-->
	<form id="usertagform" method="post" autocomplete="off" action="forum.php?mod=misc&action=usertag&addusertag=yes&infloat=yes" onsubmit="ajaxpost('usertagform', 'return_$_GET[handlekey]', '', '');return false;">
	<input type="hidden" name="formhash" value="{FORMHASH}" />
	<input type="hidden" name="tid" value="$_G[tid]" />
	<input type="hidden" name="handlekey" value="$_GET[handlekey]" />
	<div class="c bart wqshield_notice">
            <div class="wqshield_con">
		<p class="wqinput wqnew_all">
			<input type="text" name="tags" id="tags" class="px" value="" size="60" />
		</p>
		<!--{if $polloptions}-->
		<div class="mtn wqapp_f14 wqtext_left">{lang poll_select_option}</div>
		<p>
			<select multiple="multiple" name="polloptions" style="width:331px" size="5">
				<!--{loop $polloptions $var}-->
				<option value="$var[polloptionid]">$var[polloption]</option>
				<!--{/loop}-->
			</select>
		</p>
                <br>
		<!--{/if}-->
		<!--{if $recent_use_tag}-->
		<div class="mtn wqapp_f14 wqtext_left">{lang recent_use_tag}
			<!--{eval $tagi = 0;}-->
			<!--{loop $recent_use_tag $var}-->
				<!--{if $tagi}-->, <!--{/if}--><a href="javascript:;" class="xi2" onclick="$('tags').value == '' ? $('tags').value = '$var' : $('tags').value += ',$var';">$var</a>
				<!--{eval $tagi++;}-->
			<!--{/loop}-->
		</div>
		<!--{/if}-->

		<!--{if $lastlog}-->
		<div class="mtn wqapp_f14 wqtext_left">{lang set_tag_log}:</div>
			<!--{loop $lastlog $log}-->
				<div class="wqapp_f14 wqtext_left">$log[dateline] $log[username] : $log[reason]</div>
			<!--{/loop}-->
		<!--{/if}-->
                </div>

          <p class="wqbtn_can wqnew_top">
            <a href="javascript:;" onclick="popup.close();" class="wqeject_cancel wqnew_right">{lang cancel}</a>
            <button type="submit" name="addusertag" class="pn" value="true">{lang submit}</button>
        </p>
<!--	<p class="o pns" id="return_$_GET[handlekey]">
		<button type="submit" name="addusertag" class="pn" value="true"><strong>{lang submit}</strong></button>
		<button type="button" id="closebtn" class="pn" onclick="hideWindow('$_GET[handlekey]');"><strong>{lang close}</strong></button>
	</p>-->
</div>
	</form>

<script type="text/javascript">
	function errorhandle_$_GET[handlekey](msg, values) {
		var  msgmode = !values['haserror'] ? 'right' : 'alert';
		if(values['limit']) {
			var action = $('usertagform').getAttribute('action');
			action = hostconvert(action);
			$('usertagform').action = action.replace(/\&limit\=\d+/g, '')+'&limit='+values['next'];
			$('return_$_GET[handlekey]').innerHTML = msg;
			setTimeout("ajaxpost('usertagform', 'return_$_GET[handlekey]', '', '')", '1000');
			return false;
		}
		showDialog(msg, msgmode, '', null, true, null, '', '', '', 3);
		hideWindow('$_GET[handlekey]');
	}
</script>
<!--{template common/footer}-->
<!--{/if}-->