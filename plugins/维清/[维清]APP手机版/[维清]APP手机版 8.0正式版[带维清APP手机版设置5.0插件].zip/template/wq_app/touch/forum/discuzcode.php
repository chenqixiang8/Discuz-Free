<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['discuzcode'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
{eval
function tpl_hide_credits_hidden($creditsrequire) {
global $_G;
}
<!--{block return}--><div class="locked">&#x9690;&#x85CF;&#x5185;&#x5BB9;&#x9700;&#x8981;&#x79EF;&#x5206;&#x9AD8;&#x4E8E; $creditsrequire &#x624D;&#x53EF;&#x6D4F;&#x89C8;&#xFF0C;&#x60A8;&#x7684;&#x79EF;&#x5206;&#x4E3A; {$_G[member][credits]}</div><!--{/block}-->
<!--{eval return $return;}-->
{eval
}

function tpl_hide_credits($creditsrequire, $message) {
}
<!--{block return}--><div class="locked">{lang post_hide_credits}</div>
$message<br /><br />
<!--{/block}-->
<!--{eval return $return;}-->
{eval
}

function tpl_codedisp($code) {
}
<!--{block return}--><div class="blockcode"><div><ol><li>$code</ol></div></div><!--{/block}-->
<!--{eval return $return;}-->
{eval
}

function tpl_quote() {
}
<!--{block return}--><div class="quote"><blockquote>{lang e_quote}: \\1</blockquote></div><!--{/block}-->
<!--{eval return $return;}-->
{eval
}

function tpl_free() {
}
<!--{block return}--><div class="quote"><blockquote>\\1</blockquote></div><!--{/block}-->
<!--{eval return $return;}-->
{eval
}

function tpl_hide_reply() {
global $_G;
}
<!--{block return}--><div class="showhide"><h4>{lang post_hide}</h4>\\1</div>
<!--{/block}-->
<!--{eval return $return;}-->
{eval
}

function tpl_hide_reply_hidden() {
global $_G;
}
<!--{block return}-->
<div class="locked" style="text-align: center">&#x60A8;&#x9700;&#x8981;&#x56DE;&#x590D;&#x624D;&#x80FD;&#x67E5;&#x770B;&#x9690;&#x85CF;&#x5185;&#x5BB9;<!--{if $_G[uid]}--><a style="text-align: center;display: block;" href="javascript:$('#fastpostmessage').click();">&#x56DE;&#x590D;</a><!--{else}--><a style="text-align: center;display: block;" href="member.php?mod=logging&action=login&infloat=1" class="dialog notlogged">&#x56DE;&#x590D;</a><!--{/if}--></div>
<!--{/block}-->
<!--{eval return $return;}-->
{eval
}

function attachlist($attach) {
global $_G;
$attach['refcheck'] = (!$attach['remote'] && $_G['setting']['attachrefcheck']) || ($attach['remote'] && ($_G['setting']['ftp']['hideurl'] || ($attach['isimage'] && $_G['setting']['attachimgpost'] && strtolower(substr($_G['setting']['ftp']['attachurl'], 0, 3)) == 'ftp')));
$aidencode = packaids($attach);
$is_archive = $_G['forum_thread']['is_archived'] ? "&fid=".$_G['fid']."&archiveid=".$_G[forum_thread][archiveid] : '';
}
<!--{block return}-->
<div class="box box_ex2 attach f14">
    <dd>
        <p class="attnm">
            <!--{if $_G['setting']['mobile']['mobilesimpletype'] == 0}-->
        <div class="z attnm_img">  $attach[attachicon]</div>
            <!--{/if}-->
            <!--{if !$attach['price'] || $attach['payed']}-->
            <a href="forum.php?mod=attachment{$is_archive}&aid=$aidencode" id="aid$attach[aid]">$attach[filename]</a>
            <!--{else}-->
            <a href="forum.php?mod=misc&action=attachpay&aid=$attach[aid]&tid=$attach[tid]" id="aid$attach[aid]"  data='forum.php?mod=attachment{$is_archive}&aid=$aidencode'  class="dialog wq_attachments">$attach[filename]</a>
            <!--{/if}-->
            <span class="xg1 f12 grey">($attach[dateline])</span>
            <!--{if !$attach['attachimg'] && $_G['getattachcredits']}-->{lang attachcredits}: $_G[getattachcredits]<br /><!--{/if}-->
        </p>
        <p class="xg1">$attach[attachsize]<!--{if $attach['readperm']}-->, {lang readperm}: <strong>$attach[readperm]</strong><!--{/if}-->, <i class="wqiconfont2 wqicon2-xiazai"></i>: $attach[downloads]<!--{if !$attach['attachimg'] && $_G['getattachcredits']}-->, {lang attachcredits}: $_G[getattachcredits]<!--{/if}--></p>
        <p>
            <!--{if $attach['price']}-->
            {lang price}: <strong class="rq">$attach[price] {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][title]}</strong> &nbsp;<a href="forum.php?mod=misc&action=viewattachpayments&aid=$attach[aid]" class="dialog">[{lang pay_view}]</a>
            <!--{if !$attach['payed']}-->
            &nbsp;<a href="forum.php?mod=misc&action=attachpay&aid=$attach[aid]&tid=$attach[tid]" id="aid$attach[aid]_buy" class="dialog attachment_buy">[{lang attachment_buy}]</a>
            <script>
                function succeedhandle_attach_{$attach[aid]}(url, msg, param) {
                    var text=  $('#hidden_utf8').text();
                    if ($.trim(msg).indexOf(text) != '-1') {
                     clearInterval(setTimeout_location);
                     $('#aid{$attach[aid]}_buy').remove();
                     $('#aid{$attach[aid]}').attr('class',null).attr('href',$('#aid{$attach[aid]}').attr('data'));
                        setTimeout(function () {
                        popup.close();
                        }, '1000');
                    }
                }
            </script>
            <!--{/if}-->
            <!--{/if}-->
        </p>
        <!--{if $attach['description']}--><p class="xg2">{$attach[description]}</p><!--{/if}-->
    </dd>
</div>
<!--{/block}-->
<!--{eval return $return;}-->
{eval
}

function imagelist($attach) {
global $_G, $post;
$view_use_original_image = intval($_G['cache']['plugin']['wq_app_setting']['view_use_original_image']);
$fix = count($post[imagelist]) == 1 ? 140 : 83;
$fixtype = count($post[imagelist]) == 1 ? 'fixnone' : 'fixwr';
$fixtype = $post[first] ? 'fixnone' : $fixtype;
$height = $post[first] ? 9999 : 320;
$width = $post[first] ? 640 : 320;
$attach['refcheck'] = (!$attach['remote'] && $_G['setting']['attachrefcheck']) || ($attach['remote'] && ($_G['setting']['ftp']['hideurl'] || ($attach['isimage'] && $_G['setting']['attachimgpost'] && strtolower(substr($_G['setting']['ftp']['attachurl'], 0, 3)) == 'ftp')));
$mobileimg_url = $attach[url] . ($_G['setting']['thumbstatus'] && $attach['thumb'] ? getimgthumbname($attach['attachment']) : $attach['attachment']);
$mobilethumburl = $attach['attachimg'] && $_G['setting']['showimages'] && (!$attach['price'] || $attach['payed']) && ($_G['group']['allowgetimage'] || $_G['uid'] == $attach['uid']) ? ($view_use_original_image==2 ? getforumimg($attach['aid'], 0, $width, $height, $fixtype) : $mobileimg_url) : '' ;
$aidencode = packaids($attach);
$is_archive = $_G['forum_thread']['is_archived'] ? "&fid=".$_G['fid']."&archiveid=".$_G[forum_thread][archiveid] : '';
$guestviewthumb = !empty($_G['setting']['guestviewthumb']['flag']) && !$_G['uid'];
}
<!--{block return}-->
<!--{if $attach['attachimg'] && $_G['setting']['showimages'] && (($_G['group']['allowgetimage'] || $_G['uid'] == $attach['uid']) && (!$attach['price'] || $attach['payed']) || (($guestviewthumb)))}-->
    <!--{if $guestviewthumb}-->
        <!--{eval
            $thumbpath = helper_attach::attachpreurl().'image/'.helper_attach::makethumbpath($attach['aid'], $_G['setting']['guestviewthumb']['width'], $_G['setting']['guestviewthumb']['height']);
            $makefile = 'forum.php?mod=image&aid='.$attach['aid'].'&size='.$_G['setting']['guestviewthumb']['width'].'x'.$_G['setting']['guestviewthumb']['height'].'&key='.dsign($attach['aid'].'|'.$_G['setting']['guestviewthumb']['width'].'|'.$_G['setting']['guestviewthumb']['height']).'&type=1';
            $guestviewthumbcss = guestviewthumbstyle();
        }-->
        {$guestviewthumbcss}
        <div class="guestviewthumb">
                <img id="aimg_$attach[aid]" class="guestviewthumb_cur" aid="$attach[aid]" src="$thumbpath" onclick="location.href='member.php?mod=logging&action=login'" onerror="javascript:if(this.getAttribute('makefile')){this.src=this.getAttribute('makefile'); this.removeAttribute('makefile');}" file="$thumbpath" makefile="$makefile" alt="$attach[imgalt]" title="$attach[imgalt]"/>
                <br>
                <a href="member.php?mod=logging&action=login">{lang guestviewthumb}</a>
        </div>
    <!--{else}-->
        <!--{if !$attach['price'] || $attach['payed']}-->
            <!--{if $_G['setting']['mobile']['mobilesimpletype'] == 0}-->
                <li>
                    <!--{if $_G['cache']['plugin']['wq_login']['appid']['appid'] &&  strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false}-->
                        <img id="aimg_$attach[aid]" src="$mobilethumburl" alt="$attach[imgalt]" title="$attach[imgalt]" />
                    <!--{else}-->
                        <a href="forum.php?mod=viewthread&tid=$attach[tid]&aid=$attach[aid]&from=album&page=$_G[page]" class="orange">
                            <img id="aimg_$attach[aid]" src="$mobilethumburl" alt="$attach[imgalt]" title="$attach[imgalt]" />
                        </a>
                    <!--{/if}-->
                </li>
            <!--{/if}-->
        <!--{/if}-->
    <!--{/if}-->
<!--{/if}-->
<!--{/block}-->
<!--{eval return $return;}-->
{eval
}

function attachinpost($attach) {
global $_G;
$view_use_original_image = intval($_G['cache']['plugin']['wq_app_setting']['view_use_original_image']);
$attach['refcheck'] = (!$attach['remote'] && $_G['setting']['attachrefcheck']) || ($attach['remote'] && ($_G['setting']['ftp']['hideurl'] || ($attach['isimage'] && $_G['setting']['attachimgpost'] && strtolower(substr($_G['setting']['ftp']['attachurl'], 0, 3)) == 'ftp')));
$mobileimg_url = $attach[url] . ($_G['setting']['thumbstatus'] && $attach['thumb'] ? getimgthumbname($attach['attachment']) : $attach['attachment']);
$mobilethumburl = $attach['attachimg'] && $_G['setting']['showimages'] && (!$attach['price'] || $attach['payed']) && ($_G['group']['allowgetimage'] || $_G['uid'] == $attach['uid']) ? ($view_use_original_image==2 ? getforumimg($attach['aid'], 0, 640, 9999, 'fixnone') : $mobileimg_url) : '' ;
$aidencode = packaids($attach);
$is_archive = $_G['forum_thread']['is_archived'] ? '&fid='.$_G['fid'].'&archiveid='.$_G[forum_thread][archiveid] : '';
$guestviewthumb = !empty($_G['setting']['guestviewthumb']['flag']) && !$_G['uid'];
}
<!--{block return}-->


<!--{if $attach['attachimg'] && $_G['setting']['showimages'] && (!$attach['price'] || $attach['payed']) && ($_G['group']['allowgetimage'] || $_G['uid'] == $attach['uid'])}-->
    <!--{if $_G['setting']['mobile']['mobilesimpletype'] == 0}-->
        <!--{if $_G['cache']['plugin']['wq_login']['appid']['appid'] &&  strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false}-->
            <img id="aimg_$attach[aid]" src="$mobilethumburl" alt="$attach[imgalt]" title="$attach[imgalt]" />
        <!--{else}-->
            <a href="forum.php?mod=viewthread&tid=$attach[tid]&aid=$attach[aid]&from=album&page=$_G[page]" class="orange"><img id="aimg_$attach[aid]" src="$mobilethumburl" alt="$attach[imgalt]" title="$attach[imgalt]" /></a>
        <!--{/if}-->
    <!--{/if}-->
<!--{else}-->
    <!--{if $guestviewthumb}-->
        <!--{eval
            $thumbpath = helper_attach::attachpreurl().'image/'.helper_attach::makethumbpath($attach['aid'], $_G['setting']['guestviewthumb']['width'], $_G['setting']['guestviewthumb']['height']);
            $makefile = 'forum.php?mod=image&aid='.$attach['aid'].'&size='.$_G['setting']['guestviewthumb']['width'].'x'.$_G['setting']['guestviewthumb']['height'].'&key='.dsign($attach['aid'].'|'.$_G['setting']['guestviewthumb']['width'].'|'.$_G['setting']['guestviewthumb']['height']).'&type=1';
            $guestviewthumbcss = guestviewthumbstyle();
        }-->
        {$guestviewthumbcss}
        <div class="guestviewthumb">
                <img id="aimg_$attach[aid]" class="guestviewthumb_cur" aid="$attach[aid]" src="$thumbpath" onclick="location.href='member.php?mod=logging&action=login'" onerror="javascript:if(this.getAttribute('makefile')){this.src=this.getAttribute('makefile'); this.removeAttribute('makefile');}" file="$thumbpath" makefile="$makefile" alt="$attach[imgalt]" title="$attach[imgalt]"/>
                <br>
                <a href="member.php?mod=logging&action=login">{lang guestviewthumb}</a>
        </div>
    <!--{else}-->
        <div class="box box_ex2 attach f14">
            <dd>
                <p class="attnm">
                    <!--{if $_G['setting']['mobile']['mobilesimpletype'] == 0}-->
                <div class="z attnm_img">  $attach[attachicon]</div>
                    <!--{/if}-->
                    <!--{if !$attach['price'] || $attach['payed']}-->
                    <a href="forum.php?mod=attachment{$is_archive}&aid=$aidencode" id="aid$attach[aid]">$attach[filename]</a>
                    <!--{else}-->
                    <a href="forum.php?mod=misc&action=attachpay&aid=$attach[aid]&tid=$attach[tid]" id="aid$attach[aid]"  data='forum.php?mod=attachment{$is_archive}&aid=$aidencode'  class="dialog wq_attachments">$attach[filename]</a>
                    <!--{/if}-->
                    <span class="xg1 f12 grey">($attach[dateline])</span>
                    <!--{if !$attach['attachimg'] && $_G['getattachcredits']}-->{lang attachcredits}: $_G[getattachcredits]<br /><!--{/if}-->
                </p>
                <p class="xg1">$attach[attachsize]<!--{if $attach['readperm']}-->, {lang readperm}: <strong>$attach[readperm]</strong><!--{/if}-->, <i class="wqiconfont2 wqicon2-xiazai"></i>: $attach[downloads]<!--{if !$attach['attachimg'] && $_G['getattachcredits']}-->, {lang attachcredits}: $_G[getattachcredits]<!--{/if}--></p>
                <p>
                    <!--{if $attach['price']}-->
                    {lang price}: <strong class="rq">$attach[price] {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][title]}</strong> &nbsp;<a href="forum.php?mod=misc&action=viewattachpayments&aid=$attach[aid]" class="dialog">[{lang pay_view}]</a>
                    <!--{if !$attach['payed']}-->
                    &nbsp;<a href="forum.php?mod=misc&action=attachpay&aid=$attach[aid]&tid=$attach[tid]" id="aid$attach[aid]_buy" class="dialog attachment_buy">[{lang attachment_buy}]</a>
                    <script>
                        function succeedhandle_attach_{$attach[aid]}(url, msg, param) {
                            var text=  $('#hidden_utf8').text();
                            if ($.trim(msg).indexOf(text) != '-1') {
                             clearInterval(setTimeout_location);
                             $('#aid{$attach[aid]}_buy').remove();
                             $('#aid{$attach[aid]}').attr('class',null).attr('href',$('#aid{$attach[aid]}').attr('data'));
                                setTimeout(function () {
                                popup.close();
                                }, '1000');
                            }
                        }
                    </script>
                    <!--{/if}-->
                    <!--{/if}-->
                </p>
                <!--{if $attach['description']}--><p class="xg2">{$attach[description]}</p><!--{/if}-->
            </dd>
        </div>
    <!--{/if}-->
<!--{/if}-->

<!--{/block}-->
<!--{eval return $return;}-->
<!--{eval
}

}-->

<!--{/if}-->