<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['wq_buluoviewthread_poll'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->

<div id="postmessage_$post[pid]" class="postmessage">$post[message]</div>

<div class="bt pd2 x_poll">
    <form id="poll" name="poll" method="post" autocomplete="off" action="forum.php?mod=misc&action=votepoll&fid=$_G[fid]&tid=$_G[tid]&pollsubmit=yes{if $_GET[from]}&from=$_GET[from]{/if}&quickforward=yes&mobile=2" >
        <input type="hidden" name="formhash" value="{FORMHASH}" />
        <div>
            <!--{if $multiple}--><strong>{lang poll_multiple}{lang thread_poll}</strong><!--{if $maxchoices}-->: <br/> {lang poll_more_than} <!--{/if}--><!--{else}--><strong>{lang poll_single}{lang thread_poll}</strong><!--{/if}--><!--{if $visiblepoll && $_G['group']['allowvote']}--> , {lang poll_after_result}<!--{/if}-->, {lang poll_voterscount}
        </div>
        <!--{if $_G[forum_thread][remaintime]}-->
        <p>
            {lang poll_count_down}:
            <span class="xg1">
                <!--{if $_G[forum_thread][remaintime][0]}-->$_G[forum_thread][remaintime][0] {lang days}<!--{/if}-->
                <!--{if $_G[forum_thread][remaintime][1]}-->$_G[forum_thread][remaintime][1] {lang poll_hour}<!--{/if}-->
                $_G[forum_thread][remaintime][2] {lang poll_minute}
            </span>
        </p>
        <!--{elseif $expiration && $expirations < TIMESTAMP}-->
        <p><strong>{lang poll_end}</strong></p>
        <!--{/if}-->
        <div class="tp_poll">
            <!--{eval //print_r($polloptions);}-->
            <!--{eval $hasimage = _buluo_get_poll_has_image($polloptions);}-->
            <!--{if !$hasimage}-->
            <!--{loop $polloptions $key $option}-->
            <p>
                <!--{if $_G['group']['allowvote']}-->
                <input type="$optiontype" id="option_$key" class="weui_check" name="pollanswers[]" value="$option[polloptionid]" {if $_G['forum_thread']['is_archived']}disabled="disabled"{/if}  />
                       <label class="weui_check_label" for="option_$key"><i class="weui_icon_checked"></i>$key.$option[polloption]</label>
                <!--{else}-->
                 $key.$option[polloption]
                <!--{/if}-->
                <!--{if !$visiblepoll}-->
                $option[percent]% <em style="color:#$option[color]">($option[votes])</em>
                <!--{/if}-->
            </p>
            <!--{/loop}-->
            <!--{else}-->
            <!--//hasimages-->
             <ul class="poll_img">
            <!--{loop $polloptions $key $option}-->
                <li class="b_all">
                    <!--{eval $imginfo=$option['imginfo'];}-->
                    <span><!--{if $imginfo}-->
                        <a href="javascript:;" title="$imginfo[filename]" >
                            <img id="aimg_$imginfo[aid]" aid="$imginfo[aid]" src="$imginfo[small]" onclick="zoom(this, this.getAttribute('zoomfile'), 0, 0, '{$_G[setting][showexif]}')" zoomfile="$imginfo[big]" alt="$imginfo[filename]" title="$imginfo[filename]" w="$imginfo[width]" />
                        </a>
                        <!--{else}-->
                        <a href="javascript:;" title=""><img src="{$_G[style][styleimgdir]}mobile/images/nophoto.gif" /></a>
                        <!--{/if}-->
                    </span>
                    <!--{if $_G['group']['allowvote']}-->
                    <input type="$optiontype" class="weui_check" id="option_$key" name="pollanswers[]" value="$option[polloptionid]" {if $_G['forum_thread']['is_archived']}disabled="disabled"{/if}/>
                           <label class="weui_check_label" for="option_$key"><i class="weui_icon_checked"></i>$key.$option[polloption]</label><br/>
                           <!--{/if}-->
                    <!--{if !$visiblepoll}-->
                    $option[percent]% <em style="color:#$option[color]">($option[votes])</em>
                    <!--{/if}-->
                </li>

            <!--{/loop}-->
             </ul>
            <!--{/if}-->

        </div>
        <!--{if $_G['group']['allowvote'] && !$_G['forum_thread']['is_archived']}-->
        <div id="p_submit">
            <input type="submit" name="pollsubmit" id="pollsubmit" value="{lang submit}" /></div>
        <!--{if $overt}-->
        <span class="xg2 wq_font_12">{lang poll_msg_overt}</span>
        <!--{/if}-->
        <!--{elseif !$allwvoteusergroup}-->
        <!--{if !$_G['uid']}-->
        <span class="xi1 poll_vote">{lang poll_msg_allwvote_user}</span>
        <!--{else}-->
        <span class="xi1 poll_vote">{lang poll_msg_allwvoteusergroup}</span>
        <!--{/if}-->
        <!--{elseif !$allowvotepolled}-->
        <span class="xi1 poll_vote">{lang poll_msg_allowvotepolled}</span>
        <!--{elseif !$allowvotethread}-->
        <span class="xi1 poll_vote">{lang poll_msg_allowvotethread}</span>
        <!--{/if}-->
    </form>
</div>

<!--{/if}-->