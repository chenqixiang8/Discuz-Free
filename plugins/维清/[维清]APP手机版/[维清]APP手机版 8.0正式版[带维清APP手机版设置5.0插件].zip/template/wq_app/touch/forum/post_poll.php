<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['post_poll'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<li class="wqnew_bottom">
    <input type="hidden" name="polls" value="yes" />
    <input type="hidden" name="fid" value="$_G[fid]" />
    <input type="hidden" name="tpolloption" value="1" />
    <h4 class="wqpost_option">{lang post_poll_comment} &nbsp;
        <span class="y">
            <input id="pollchecked" type="checkbox" class="weui_check" onclick="switchpollm(1)" />
            <label class="weui_check_label" for="pollchecked"><i class="weui_icon_checked"></i>{lang post_single_frame_mode}</label>
        </span>
    </h4>
    <div class="wqpost_poll" id="pollm_c_1">
        <span id="polloption_new"></span>
        <p style="display: none" id='polloption_hidden'>
            <a href="javascript:;" class="wqpost_poll_pic">
                <input type="file" class="wqpost_poll_file" id="pollUploadProgress" name="Filedata"  index="file_index">
                <i class="wqiconfont2 wqicon2-tupian wqapp_f18" id="newpoll"></i>
            </a>
            <a href="javascript:;" class="wqiconfont2 wqicon2-poll wqapp_f22 wqpost_poll_del wqred"></a>
            <input type="text" name="polloption[]"  class="wqpost_input wqpoll_inputwidth">
        </p>
        <p class="wqpost_additem wqnew_top"><a href="javascript:;" class="wqblock">+{lang post_poll_add}</a></p>
    </div>
    <div class="wqpost_poll2" id="pollm_c_2" style="display: none;">
        <textarea onchange="switchpollm(0)" name="polloptions"></textarea>
    </div>
</li>
<li class="wqnew_bottom">
        <label for="maxchoices">{lang post_poll_allowmultiple}
          <input type="tel" name="maxchoices" id="maxchoices" class="wqpost_input wqpoll_inputwidth" value="{if $_GET[action] == 'edit' && $poll[maxchoices]}$poll[maxchoices]{else}1{/if}" tabindex="1" /><i class="wqpost_li_small wqapp_f14">{$Tlang['ae1323dd208fe1aa']}</i>
        </label>
</li>
<li class="wqnew_bottom">

    <label for="polldatas">{lang post_poll_expiration}
         <input type="tel" name="expiration" id="polldatas" class="wqpost_input wqpoll_inputwidth" value="{if $_GET[action] == 'edit'}{if !$poll[expiration]}0{elseif $poll[expiration] < 0}{lang poll_close}{elseif $poll[expiration] < TIMESTAMP}{lang poll_finish}{else}{echo (round(($poll[expiration] - TIMESTAMP) / 86400))}{/if}{/if}" tabindex="1" /><i class="wqpost_li_small wqapp_f14">{$Tlang['007bd5bdbc31a995']}</i></em>
</label>
    </li>
<li class="wqpost_see wqnew_bottom">
  <input type="checkbox" name="visibilitypoll" id="visibilitypoll" class="weui_check" value="1"{if $_GET[action] == 'edit' && !$poll[visible]} checked{/if} tabindex="1" />
           <label class="weui_check_label wqblock" for="visibilitypoll"><i class="weui_icon_checked"></i>{lang poll_after_result}
        </label>

</li>
 <li class="wqpost_see wqnew_bottom">
       <input type="checkbox" name="overt" id="overt" class="weui_check" value="1"{if $_GET[action] == 'edit' && $poll[overt]} checked{/if} tabindex="1" />
           <label class="weui_check_label wqblock" for="overt"><i class="weui_icon_checked"></i>{lang post_poll_overt} </label>
</li>
<script>
    var curoptions = 0;
    var curnumber = 1;
    var maxoptions = parseInt('$_G[setting][maxpolloptions]');
    for(var i=0;i<2;i++){
        addpolloption();
    }

    function addpolloption() {
        if(curoptions < maxoptions) {
            var imgid = 'newpoll_'+curnumber;
            var proid = 'pollUploadProgress_'+curnumber;
            var pollstr = $('#polloption_hidden').html().replace('newpoll', imgid).replace('file_index', curnumber);
            pollstr = pollstr.replace('pollUploadProgress', proid);
            document.getElementById('polloption_new').outerHTML = '<p class=wqnew_top>' + pollstr + '</p>' + document.getElementById('polloption_new').outerHTML;
            curoptions++;
            curnumber++;
        } else {
            var str = "{$Tlang['852c6752d7c919c1']}";
            popup.open(str + maxoptions, 'alert');
        }
    }
    $(".wqpost_additem").on("click",function(){
        addpolloption();
    });
    $(".wqpost_poll").on("click",".wqpost_poll_del",function(){
        $(this).parent().remove();
        curoptions--;
    });

    var index_data
    var uploadsuccess_poll = function(data) {
        if(data == '') {
            popup.open('{lang uploadpicfailed}', 'alert');
        }
        var result = jQuery.parseJSON(data);
        if(result.aid=='0'){
           popup.open(STATUSMSG[result.errorcode], 'alert');
        }
        if(result.smallimg) {
            popup.close();
            $('#newpoll_'+index_data).html('<img src="'+result.smallimg+'" /><input type="hidden" name="pollimage[]" value="'+result.aid+'">').attr('class',null);
        }
    };
    $(document).on('change', '.wqpost_poll_file', function() {
        index_data=$(this).attr('index');
        picture(uploadsuccess_poll,$(this).attr('id'),'Filedata','misc.php?mod=swfupload&action=swfupload&operation=poll&fid=$_G[fid]');
    });

    function switchpollm(swt) {
        t = document.getElementById('pollchecked').checked && swt ? 2 : 1;
        var v = '';
        for(var i = 0; i < document.getElementById('postform').elements.length; i++) {
            var e = document.getElementById('postform').elements[i];
            if(!isUndefined(e.name)) {
                if(e.name.match('^polloption')) {
                    if(t == 2 && e.tagName == 'INPUT') {
                        v += e.value + '\n';
                    } else if(t == 1 && e.tagName == 'TEXTAREA') {
                        v += e.value;
                    }
                }
            }
        }
        if(t == 1) {
                var a = v.split('\n');
                var pcount = 0;
                for(var i = 0; i < document.getElementById('postform').elements.length; i++) {
                    var e = document.getElementById('postform').elements[i];
                    if(!isUndefined(e.name)) {
                        if(e.name.match('^polloption')) {
                            pcount++;
                            if(e.tagName == 'INPUT') e.value = ''
                        }
                    }
                }
                for(var i = 0; i < a.length - pcount + 2; i++) {
                    addpolloption();
                }
                var ii = 0;
                for(var i = 0; i < document.getElementById('postform').elements.length; i++) {
                    var e = document.getElementById('postform').elements[i];
                    if(!isUndefined(e.name)) {
                        if(e.name.match('^polloption') && e.tagName == 'INPUT' && a[ii]) {
                            e.value = a[ii++];
                        }
                    }
                }
        } else if (t == 2) {
            v = v.slice(0, v.length - 2)
            document.getElementById('postform').polloptions.value = trim(v)

        }
        document.getElementById('postform').tpolloption.value = t
        if(swt) {
            display('pollm_c_1');
            display('pollm_c_2');
        }
    }
    function trim(str) {
        return str.replace(/^\s*(.*?)[\s\n]*$/g, '$1');
    }
    function display(id) {
        var obj = document.getElementById(id);
        if(obj.style.visibility) {
            obj.style.visibility = obj.style.visibility == 'visible' ? 'hidden' : 'visible';
        } else {
            obj.style.display = obj.style.display == '' ? 'none' : '';
        }
    }
</script>

<!--{/if}-->