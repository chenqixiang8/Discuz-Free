<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['post_forumselect'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{if $_GET['ac'] == 'selfav'}-->
<!--{eval include_once DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_wq_app.php';}-->
<!--{eval echo wq_app_select_fav_by_fid($_GET['fid']);exit();}-->
<!--{/if}-->
<!--{template common/header}-->
<!--{if $_GET['ac'] == 'delfav'}-->
<!--{eval wq_app_delete_fav_by_fid($_GET['fid']);return $_G['forum']['favtimes'];exit();}-->
<!--{elseif $_GET['ac'] == 'forumlist'}-->
<!--{eval include template('forum/forumlist_1');}-->
<!--{template common/footer}-->
<!--{elseif $_GET['ac'] == 'myfav'}-->
    <!--{eval
        $headparams['wtype'] = '1';
        $headparams['lurl'] = $backurl;
        $headparams['ltype'] = 'a';
        $headparams['cname'] = $Tlang['522d4f8f3d5d6d97'];
        echo wq_app_get_header($headparams);
    }-->

<!--{eval include template('forum/forumlist');}-->
<!--{else}-->
    <!--{eval
        $headparams['wtype'] = '1';
        $headparams['cname'] = $Tlang['789afa93d19c7c4c'];
        echo wq_app_get_header($headparams,true,false,'',false);
    }-->

    <!--{if $wq_app_setting['post_style'] == 1}-->
        <div class="wqchoice_post">
            <ul>
                <!--{eval $catlist=wq_app_get_forum_in_group();}-->

                <!--{eval loadcache('forums');}-->
                <!--{eval $forumlist = $_G['cache']['forums'];}-->
                <!--{loop $forumlist $forum}-->
                    <!--{if $forum['type'] == 'forum' && $forum['status'] == '1' && $forumlist[$forum['fup']][status] == '1'}-->
                        <!--{eval $forumfids = $catlist[$forum['fup']]['forums'] ? $catlist[$forum['fup']]['forums'] : array();}-->
                        <!--{if in_array($forum['fid'],$forumfids)}-->
                            <li><a href="forum.php?mod=post&action=newthread&fid={$forum['fid']}">{$forum['name']}</a></li>
                        <!--{/if}-->
                    <!--{/if}-->
                <!--{/loop}-->
            </ul>
        </div>
    <!--{else}-->
        <!--{eval include template('forum/forumlist');}-->
    <!--{/if}-->
<!--{/if}-->
<!--{template common/share}-->
<!--{template common/footer}-->

<!--{/if}-->