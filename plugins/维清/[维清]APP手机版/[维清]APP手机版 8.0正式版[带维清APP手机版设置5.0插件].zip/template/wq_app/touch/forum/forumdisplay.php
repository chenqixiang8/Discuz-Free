<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['forumdisplay'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{eval //echo"<pre>"; print_r($_GET);exit;}-->
<!--{template common/header}-->
<!--{eval $guide_nav = get_post_all_check($_GET['filter']);}-->
<!--{eval $nav_array[$guide_nav] = 'class="wqcolor wqborder_bottom"';}-->
<!--{block wq_navtitle}-->
<!--{if !empty($navtitle)}-->$navtitle - <!--{/if}--><!--{if empty($nobbname)}--> $_G['setting']['bbname'] - <!--{/if}--> {lang waptitle} - Powered by Discuz!
<!--{/block}-->

<!--{eval
    $headparams['wtype'] = '1';
    $headparams['lurl'] = $backurl;
    $headparams['ltype'] = 'a';
    $headparams['rtype'] = 'share';
    $headparams['cname'] = strip_tags($_G['forum']['name']) ? strip_tags($_G['forum']['name']) : $_G['forum']['name'];

    echo wq_app_get_header($headparams,true,true);
}-->



<!--{template common/share}-->
<!--{hook/forumdisplay_top_mobile}-->
<div class="wqforum_list_warp">
    <div class="wqforum_list_pic">
        <!--{if $_G['forum']['icon']}-->
        <!--{eval $valueparse = parse_url($_G['forum']['icon']);$_G['forum']['icon']=!isset($valueparse['host'])?$_G['setting']['attachurl']."common/".$_G['forum']['icon']:$_G['forum']['icon'];}-->
        <img src="$_G['forum']['icon']" />
        <!--{else}-->
        <img src="{$_G['style'][styleimgdir]}images/forum{if $forum[folder]}_new{/if}.gif" />
        <!--{/if}-->
    </div>
    <div class="wqforum_list_info">
        <p class="wqapp_f15"><span class="wqm_right20">{$Tlang['57f5cb4a5a928cae']}<em class="wqm_right3">{$_G[forum]['threads']}</em></span><span>{$Tlang['2c8a07313e7706bc']}<em class="wqm_right3" id="fav_num">{$_G[forum][favtimes]}</em></span></p>
        <p>
            <!--{eval $fav = fetch_by_id_idtype_uid($_G[forum][fid], "fid", $_G['uid']);}-->
            <!--{if empty($fav)}-->
            <span class="wqforum_list_follow y"><a href="home.php?mod=spacecp&ac=favorite&type=forum&id={$_G[forum][fid]}" class="wqwhite notlogged" id="a_favorite"><i class="wqiconfont2 wqicon2-increase wqapp_f13 wqm_right3"></i>{$Tlang['2c8a07313e7706bc']}</a></span>
            <!--{else}-->
            <span class="wqforum_list_follow y"><a href="javascript:;" class="wqwhite" id="cancel_favorite" ><i class="wqiconfont2 wqicon2-o3 wqapp_f14 wqm_right3"></i>{$Tlang['2c8a07313e7706bc']}</a></span>
            <!--{/if}-->
        </p>
        <p class='wqforum_sum'><!--{if $_G['forum'][description]}-->$_G['forum'][description]<!--{else}-->{$Tlang['38d5fceb8820c542']}<!--{/if}--></p>
    </div>
</div>
<!--{if $sublist}-->

<div class="wqson_plate">
    <ul>
        <!--{loop $sublist $key $value}-->
        <li {if $key > 2}class="dsn"{/if}>
            <!--{if $value[icon]}-->
            <span class="wqname_img">{echo trim($value[icon])}</span>
            <!--{else}-->
            <span class="wqname_img">
                <a href="forum.php?mod=forumdisplay&fid={$value['fid']}">
                    <img src="{$_G['style'][styleimgdir]}images/forum{if $value[folder]}_new{/if}.gif" alt="$value[name]" />
                </a>
            </span>
            <!--{/if}-->
            <span class="wqname"><a href="forum.php?mod=forumdisplay&fid={$value['fid']}">{echo trim($value[name])}</a></span>
        </li>
        <!--{if $key == 2 && count($sublist) > 3}-->
        <li class="wqchild-show">
            <a href="javascript:;" class="wqblock wqellipsis" style="text-align: center;"><span>{$Tlang['db9c470ab0853172']}</span><i class="wqiconfont2 wqicon2-jiantou"></i></a>
        </li>
        <!--{/if}-->
        <!--{/loop}-->
        <!--{if count($sublist) > 3}-->
        <li class="wqchild-hide dsn">
            <a href="javascript:;" class="wqblock wqellipsis" style="text-align: center;"><span>{$Tlang['c699f8e04db8c066']}</span></a>
        </li>
        <!--{/if}-->
    </ul>
</div>
<div class="wqseparate"></div>
<!--{/if}-->
<!--{eval $screen_url='forum.php?mod=forumdisplay&fid='.$_G['forum']['fid'];}-->
<div class="my_post2_roll wqnew_bottom" style="padding-left:4px;">
    <div class="tag_list">
        <ul>
            <li><a href="$screen_url&sortall=1" {$nav_array[0]}>{$Tlang['8dfe4b30674494c1']}</a></li>
            <li><a addclass="wqindex_list" href="{$screen_url}&filter=heat&orderby=heats&sortall=1"  {$nav_array[1]}>{$Tlang['8f0491c8e569b3df']}</a></li>
            <li><a addclass="wqindex_list" href="{$screen_url}&filter=digest&digest=1&sortall=1"  {$nav_array[4]}>{$Tlang['46d1ecf7cc55b12f']}</a></li>
            <li><a addclass="wqindex_list" href="{$screen_url}&filter=hot&sortall=1" {$nav_array[2]} >{$Tlang['53fda8b6e44196b1']}</a></li>
            <!--{eval $view_select = empty($_G['forum']['threadsorts']) &&  empty($_G['forum']['allowpostspecial']) && empty($_G['forum']['threadtypes']) && empty($sublist) ? 0 : 1}-->
            <!--{if $view_select}-->
            <li style="width: 20%;"><a inajax="1" addclass="wqindex_list" href="forum.php?$_SERVER['QUERY_STRING']" id="wq_screen_js"{$nav_array[5]} >{$Tlang['fbabec3054214512']}<i class="wqiconfont2 wqicon2-downfoldfill"></i></a></li>
            <!--{/if}-->
        </ul>
   </div>
</div>
<script type="text/javascript">
    var forum_optionlist = <!--{if $forum_optionlist}-->'$forum_optionlist'<!--{else}-->''<!--{/if}-->;
</script>
<script type="text/javascript" src="{$_G['style'][styleimgdir]}js/forum/threadsort.js?{VERHASH}"></script>
<!--{loop $quicksearchlist $optionid $option}-->
            <!--{eval $formsearch = '';}-->
            <!--{if getstatus($option['search'], 1)}-->
                    <!--{block formsearch}-->
                        <div class="wq_search_list wqnew_bottom">
                            <span class="wq_search_title">$option[title]:</span>
                            <!--{if in_array($option['type'], array('radio', 'checkbox', 'select', 'range'))}-->
                                <span class="wq_div_margin" id="select_$option[identifier]">
                                <!--{if $option[type] == 'select'}-->
                                    <!--{if $_GET[searchoption][$optionid][value]}-->
                                        <script type="text/javascript">
                                            changeselectthreadsort('$_GET[searchoption][$optionid][value]', $optionid, 'search');
                                        </script>
                                    <!--{else}-->
                                        <select name="searchoption[$optionid][value]" id="$option[identifier]" onchange="changeselectthreadsort(this.value, '$optionid', 'search');" class="ps vm">
                                            <option value="0">{lang please_select}</option>
                                        <!--{loop $option['choices'] $id $value}-->
                                            <!--{if !$value[foptionid]}-->
                                            <option value="$id">$value[content] <!--{if $value['level'] != 1}-->&raquo;<!--{/if}--></option>
                                            <!--{/if}-->
                                        <!--{/loop}-->
                                        </select>
                                                                    <input type="hidden" name="searchoption[$optionid][type]" value="$option[type]">
                                    <!--{/if}-->
                                <!--{elseif $option[type] != 'checkbox'}-->
                                    <select name="searchoption[$optionid][value]" id="$option[identifier]" class="ps vm">
                                        <option value="0">{lang please_select}</option>
                                    <!--{loop $option['choices'] $id $value}-->
                                        <option value="$id" {if $_GET[searchoption][$optionid][value] == $id}selected="selected"{/if}>$value</option>
                                    <!--{/loop}-->
                                    </select>
                                    <input type="hidden" name="searchoption[$optionid][type]" value="$option[type]">
                                <!--{else}-->
                                    <!--{loop $option['choices'] $id $value}-->

                                        <em><input type="checkbox" class="weui_check" name="searchoption[$optionid][value][$id]"id="searchoption[$optionid][value][$id]" value="$id" {if is_array($_GET[searchoption][$optionid]) && $_GET[searchoption][$optionid][value][$id]}checked="checked"{/if}>
                                       <label  for="searchoption[$optionid][value][$id]" class="weui_check_label"><i class="weui_icon_checked"></i>$value</label></em>
                                    <!--{/loop}-->
                                    <input type="hidden" name="searchoption[$optionid][type]" value="checkbox">
                                <!--{/if}-->
                                </span>
                            <!--{else}-->
                                <!--{if $option['type'] == 'calendar'}-->
                                    <script type="text/javascript" src="{$_G[setting][jspath]}calendar.js?{VERHASH}"></script>
                                    <span class="wq_div_margin"><input type="text" name="searchoption[$optionid][value]" size="15" class="px vm" value="{if is_array($_GET[searchoption][$optionid])}$_GET[searchoption][$optionid][value]{/if}" onclick="showcalendar(event, this, false)" /></span>
                                <!--{else}-->
                                    <span class="wq_div_margin"><input type="text" name="searchoption[$optionid][value]" size="15" class="px vm" value="{if is_array($_GET[searchoption][$optionid])}$_GET[searchoption][$optionid][value]{/if}" /></span>
                                <!--{/if}-->
                            <!--{/if}-->
                        </div>
                        <!--{/block}-->
                    <!--{/if}-->
        <!--{eval $formsearch_html .= $formsearch;}-->
	<!--{eval $fontsearch = '';$showoption = array();$tmpcount = 0;}-->
	<!--{if getstatus($option['search'], 2)}-->
            <!--{block fontsearch}-->
                <div class="wq_screen_list <!--{if $wq_app_setting['view_screen_mode'] == '2'}-->wq_new_bottom wq-scrollmenu slide-stop<!--{/if}-->">
                    <span class="wq_tilte wqsort_{$option['identifier']}">$option[title]:</span>
                    <!--{if $wq_app_setting['view_screen_mode'] == '2'}-->
                    <div class="wq_roll {$option['identifier']}" data-class="$option['identifier']" style="overflow: hidden;">
                        <div class="tag_list">
                    <!--{/if}-->
                    <ul>
                        <li{if $_GET[''.$option[identifier]] == 'all'} class="a"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=sortid&sortid=$_GET['sortid']&searchsort=1$filterurladd&$option[identifier]=all$sorturladdarray[$option[identifier]]">{lang unlimited}</a></li>
                        <!--{if $option[type] == 'select'}-->
                            <!--{loop $option['choices'] $id $value}-->
                                    <!--{if $value[foptionid] == 0}-->
                                    <li{if preg_match('/^'.$value[optionid].'\./i', $_GET[''.$option[identifier]]) || preg_match('/^'.$value[optionid].'$/i', $_GET[''.$option[identifier]])} class="a"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=sortid&sortid=$_GET[sortid]&searchsort=1&$option[identifier]=$id$sorturladdarray[$option[identifier]]">$value[content]</a></li>
                                    <!--{/if}-->
                            <!--{/loop}-->
                            <!--{if !($_GET[''.$option[identifier]] == 'all' || !isset($_GET[''.$option[identifier]]))}-->
                                <!--{loop $option['choices'] $id $value}-->
                                    <!--{if (preg_match('/^'.$value[foptionid].'\./i', $_GET[''.$option[identifier]]) || preg_match('/^'.$value[foptionid].'$/i', $_GET[''.$option[identifier]])) && ($showoption[$value[count]][$id] = $value)}-->
                                    <!--{/if}-->
                                <!--{/loop}-->
                                <!--{if ksort($showoption)}--><!--{/if}-->
                                <!--{loop $showoption $optioncount $values}-->
                                    <!--{if $tmpcount != $optioncount && ($tmpcount = $optioncount)}-->
                                        </ul>
                    <br/>
                                        <ul class="subtsm cl">
                                            <!--{loop $values $id $value}-->
                                                <li{if preg_match('/^'.$value[optionid].'\./i', $_GET[''.$option[identifier]]) || preg_match('/^'.$value[optionid].'$/i', $_GET[''.$option[identifier]])} class="a"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=sortid&sortid=$_GET[sortid]&searchsort=1&$option[identifier]=$id$sorturladdarray[$option[identifier]]" class="xi2">$value[content]</a></li>
                                            <!--{/loop}-->
                                        </ul>

                                    <!--{/if}-->
                                <!--{/loop}-->
                            <!--{/if}-->
                            <br/>
                        <!--{else}-->
                            <!--{loop $option['choices'] $id $value}-->
                                <li{if $_GET[''.$option[identifier]] && !strcmp($id, $_GET[''.$option[identifier]])} class="a"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=sortid&sortid=$_GET[sortid]&searchsort=1&$option[identifier]=$id$sorturladdarray[$option[identifier]]">$value</a></li>
                            <!--{/loop}-->
                        <!--{/if}-->
                    <!--{if $wq_app_setting['view_screen_mode'] == '2'}-->
                        </div>
                    </div>
                     <!--{/if}-->
                </div>
            <!--{/block}-->
        <!--{/if}-->
    <!--{eval $fontsearch_html .= $fontsearch;}-->
<!--{/loop}-->




<!--{if $fontsearch_html || $formsearch_html}-->

<div class="<!--{if $wq_app_setting['view_screen_mode'] == '1'}-->wq_information_screen<!--{else}-->wq_information_screen_roll<!--{/if}-->">
    <!--{eval $sortname='';}-->
    <!--{loop $_G['forum']['threadsorts']['types'] $id $name}-->
        <!--<{if $_GET['sortid'] == $id}-->
            <!--{eval $sortname=$name;break;}-->
        <!--{/if}>-->
    <!--{/loop}-->
    <div class="wq_screen_stop wqnew_bottom">{$sortname}
        <!--{if $wq_app_setting['view_screen_openstop'] == '1'}-->
            <span>{$Tlang['542342c528357511']} <i class="wqiconfont2 wqicon2-down_1"></i></span>
        <!--{else}-->
            <span>{$Tlang['c699f8e04db8c066']} <i class="wqiconfont2 wqicon2-appup_1"></i></span>
        <!--{/if}-->
    </div>
        <div class="fontsearch <!--{if $wq_app_setting['view_screen_openstop'] == '2'}-->wq_open<!--{/if}-->"<!--{if $wq_app_setting['view_screen_openstop'] == '1'}--> style="display: none;"<!--{/if}-->>
             <!--{if $fontsearch_html}-->
                <div id="fontsearch" class="tsm cl">
                    $fontsearch_html
               </div>
             <!--{/if}-->
             <!--{if $formsearch_html}-->
              <!--{if $wq_app_setting['view_screen_openstop'] == '2'}--><div class="wqseparate2"></div><!--{/if}-->
            <div <!--{if $wq_app_setting['view_screen_openstop'] == '2'}--> class="wqapp_bg_white"<!--{/if}-->>
                <form method="post" autocomplete="off" name="searhsort" id="searhsort" class="bbs bm_c pns mfm cl" action="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=sortid&sortid=$_GET[sortid]">
                    <input type="hidden" name="formhash" value="{FORMHASH}" />
                    $formsearch_html
                    <div class="wq_formsearch_btn wqnew_bottom"><button type="submit" class="button2" name="searchsortsubmit"><em>{lang search}</em></button></div>
                </form>
                </div>
            <!--{/if}-->
        </div>
</div>




<script>
    $(function () {
        var hasInit = 0,
            fontSearch = $('.fontsearch'),
            screenStop = $('.wq_screen_stop span'),
            hideFont = function() {
                fontSearch.removeClass('wq_open');
                setTimeout(function () {
                    fontSearch.hide();
                }, 200);

                screenStop.html('{$Tlang['542342c528357511']} <i class="wqiconfont2 wqicon2-down_1"></i>');
            },
            showFont = function() {
                fontSearch.show();
                setTimeout(function () {
                    fontSearch.addClass('wq_open');
                    if (!hasInit) {
                        wq_utils.initMoreScrollMenu();
                        hasInit = 1;
                    }
                });

                screenStop.html('{$Tlang['c699f8e04db8c066']} <i class="wqiconfont2 wqicon2-appup_1"></i>');
            };

        screenStop.on('click', function () {
            if (fontSearch.hasClass('wq_open')) {
                hideFont();

                setcookie('fontSearch', '0', 500);
            } else {
                showFont();

                setcookie('fontSearch', '1', 500);
            }
        });

        if ($('.fontsearch').hasClass('wq_open')) {
            wq_utils.initMoreScrollMenu();
            hasInit = 1;
        }

        if (getcookie('fontSearch') === '1') {
            showFont();
        } else if (getcookie('fontSearch') === '0') {
            hideFont();
        }
    });
</script>

<!--{/if}-->

<div id="advanced_filter" class="wqipagen" style="display: none;position:fixed;top:0px;left:0px;">
    <div class="wqtitle">
       {$Tlang['758f910a66add3a0']}<i id="list_hide" class="wqiconfont2 wqicon2-iconuser wqtj_close"></i>
    </div>

    <div class="wqpcontent">
        <!--{if $sublist}-->
        <h3>{$Tlang['23a560993ef05dfb']}</h3>
        <ul>
            <!--{loop $sublist $value}-->
            <li><a href="forum.php?mod=forumdisplay&fid={$value['fid']}">{$value['name']}</a> </li>
            <!--{/loop}-->
        </ul>
        <!--{/if}-->
        <!--{eval $screen_url='forum.php?mod=forumdisplay&fid='.$_G['forum']['fid'];}-->
        <!--{if $_G['forum']['threadtypes']}-->
        <h3>{$Tlang['e2c10536ad973ce3']}</h3>
        <ul>
            <li<!--{if empty($_GET[typeid]) &&empty($_GET[specialtype]) && empty($_GET[sortid])}--> class="active"<!--{/if}-->>
                <a href="$screen_url">{$Tlang['8dfe4b30674494c1']}</a>
            </li>
            <!--{loop $_G['forum']['threadtypes']['types'] $key $value}-->
            <li<!--{if $_GET[typeid] == $key}--> class="active"<!--{/if}-->>
                <a href="$screen_url&filter=typeid&typeid={$key}{if $_GET[sortall]}&sortall=1{/if}">{$value}</a>
            </li>
            <!--{/loop}-->
        </ul>
        <!--{/if}-->
        <!--{if $_G['forum']['threadsorts']}-->
        <h3>{$Tlang['5c628d6fb054066c']}</h3>
        <ul>
            <li<!--{if empty($_GET[typeid]) && empty($_GET[specialtype]) && empty($_GET[sortid])}--> class="active"{/if}>
                <a href="$screen_url">{$Tlang['8dfe4b30674494c1']}</a>
            </li>
            <!--{loop $_G['forum']['threadsorts']['types'] $id $name}-->
            <li{if $_GET['sortid'] == $id} class="active"{/if}><a href="$screen_url&filter=sortid&sortid=$id{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">$name</a></li>
            <!--{/loop}-->
        </ul>
        <!--{/if}-->
        <!--{if $_G['forum']['allowpostspecial']}-->
        <h3>{$Tlang['cc1025f7bbbc225d']}</h3>
        <ul>
            <li<!--{if empty($_GET[typeid]) && empty($_GET[specialtype]) && empty($_GET[sortid])}--> class="active"<!--{/if}-->>
                <a href="$screen_url">{$Tlang['8dfe4b30674494c1']}</a>
            </li>

            <!--{if $showpoll}-->
            <li<!--{if $_GET[specialtype] == "poll"}--> class="active"<!--{/if}-->>
                <a href="$screen_url&filter=specialtype&specialtype=poll{if $_GET[sortall]}&sortall=1{/if}">{$Tlang['a1e86aeac9394d67']}</a>
            </li>
            <!--{/if}-->
            <!--{if $showtrade}-->
            <li<!--{if $_GET[specialtype] == "trade"}--> class="active"<!--{/if}-->>
                <a href="$screen_url&filter=specialtype&specialtype=trade{if $_GET[sortall]}&sortall=1{/if}">{$Tlang['884b6b88fa1e0b8e']}</a>
            </li>
            <!--{/if}-->
            <!--{if $showreward}-->
            <li<!--{if $_GET[specialtype] == "reward"}--> class="active"<!--{/if}-->>
                <a href="$screen_url&filter=specialtype&specialtype=reward{if $_GET[sortall]}&sortall=1{/if}">{$Tlang['655aa530ba4d16cf']}</a>
            </li>
            <!--{/if}-->
            <!--{if $showactivity}-->
            <li<!--{if $_GET[specialtype] == "activity"}--> class="active"<!--{/if}-->>
                <a href="$screen_url&filter=specialtype&specialtype=activity">{$Tlang['2e5409eeacda8839']}</a>
            </li>
            <!--{/if}-->
            <!--{if $showdebate}-->
            <li<!--{if $_GET[specialtype] == "debate"}--> class="active"<!--{/if}-->>
                <a href="$screen_url&filter=specialtype&specialtype=debate">{$Tlang['5cbc8ce0fb1e25e0']}</a>
            </li>
            <!--{/if}-->
        </ul>
        <!--{/if}-->
            <h3>{lang orderby} </h3>
            <ul>
                <li {if $_GET['orderby'] == 'dateline'}class="active"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=author&orderby=dateline$forumdisplayadd[author]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang list_post_time}</a></li>
                <li {if $_GET['orderby'] == 'replies'}class="active"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=reply&orderby=replies$forumdisplayadd[reply]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang replies}</a></li>
                <li {if $_GET['orderby'] == 'views'}class="active"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=reply&orderby=views$forumdisplayadd[view]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang views}</a></li>
            </ul>
            <h3>{lang time}</h3>
            <ul>
                <li {if !$_GET['dateline']}class="active"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang all}{lang search_any_date}</a></li>
                <li {if $_GET['dateline'] == '86400'}class="active"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=86400$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang last_1_days}</a></li>
                <li {if $_GET['dateline'] == '172800'}class="active"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=172800$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang last_2_days}</a></li>
                <li {if $_GET['dateline'] == '604800'}class="active"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=604800$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang list_one_week}</a></li>
                <li {if $_GET['dateline'] == '2592000'}class="active"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=2592000$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang list_one_month}</a></li>
                <li {if $_GET['dateline'] == '7948800'}class="active"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=7948800$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang list_three_month}</a></li>
            </ul>
    </div>
</div>
<!--{if !empty($_G['forum']['recommendlist']) && $wq_app_setting['isopen_modrecommend']}-->
        <div class="wqtop_post">
            <!--{subtemplate forum/recommend}-->
        </div>
<!--{/if}-->
    <!--{if $_G['forum_threadcount']}-->
        <!--{eval $toplist = get_wq_app_toplist($_G['forum_threadlist']);}-->
        <!--{if $toplist}-->
            <div class="wqtop_post">
                <ul>
                    <!--{loop $toplist $key $topthread}-->
                    <!--{hook/forumdisplay_thread_mobile $key}-->
                    <li><a href="forum.php?mod=viewthread&tid=$topthread[tid]&extra=$extra" class="wqellipsis"><span class="wqtop_post_span">{$topthread['topicon']}</span>
                        <!--{eval $wq_top_typehtml = str_replace(array('[', ']','<a','</a>'), array('<span class="wq_typehtml" ', '</span>'), array($topthread[typehtml],$topthread[sorthtml]));;}-->
                        {$wq_top_typehtml[0]}{$wq_top_typehtml[1]}
                        <font $topthread[highlight]>{$topthread[subject]}</font></a>
                    </li>
                    <!--{/loop}-->
                </ul>
            </div>
        <!--{/if}-->
    <!--{/if}-->

<!--{if empty($_G['forum']['picstyle']) || $_G['cookie']['forumdefstyle']}-->
<!--{eval $showmodel = get_forum_showmodel();$showmodelclass=wq_app_get_forum_class($showmodel);}-->
<div class="$showmodelclass"  id="hotlist_{$guide_nav}" data="$guide_nav" title="$wq_navtitle" pattern="ordinary">
    <!--{if $_G['forum_threadlist'] && $_G[forum]['threads'] > 0}-->
    <ul class="wqindex_list_ul<!--{if $showmodel == 'b'|| $showmodel == 's'}-->  wqguide_list_ul<!--{/if}--> {if $wq_app_setting[is_drop_down_loading]}pulldown_load_js{/if}" botton='130' contentid='thread_lists{$guide_nav}'  count="{$_G['forum_threadcount']}" query_string="{$_SERVER['QUERY_STRING']}" page="$page" perpage="$_G['setting']['mobile']['mobiletopicperpage']" id='thread_lists{$guide_nav}'>
        <!--{eval include_once template('common/common_module');}-->
        <!--{eval include template('forum/forumdisplay_'.$showmodel);}-->
    </ul>
    <!--{else}-->
    <!--{eval include_once template('common/common_module');}-->
    <!--{eval echo wq_app_no_content('forum/template','guide_nothreads');}-->
    <!--{/if}-->
    <!--{if $wq_app_setting[is_drop_down_loading]}-->
    <!--{eval echo wq_app_load_icon();}-->
    <!--{else}-->
    <!--{if $multipage}--><div class="pgs cl mtm"><!--{eval echo wq_app_multipage($multipage);}--></div><!--{/if}-->
    <!--{/if}-->
</div>
<!--{if $showmodel == 'w'}-->
<script type="text/javascript" src="{$_G['style']['styleimgdir']}js/forum/moments.js?{VERHASH}" charset="gbk"></script>
<!--{/if}-->
<!--{else}-->
<style>body{ background-color: #f9f9f9;}</style>
<div class="wqwaterfall_warp" id="wq_forumdisplay_list">
    <div class="wqwaterfall_con" id="hotlist_{$guide_nav}" delid="delid" data="$guide_nav" title="$wq_navtitle">
        <ul class="waterfall wqwaterfall {if $wq_app_setting[is_drop_down_loading]}pulldown_load_js{/if}" id='thread_lists{$guide_nav}' wq_flag="waterfall" botton='330' contentid='thread_lists{$guide_nav}' count="$_G['forum_threadcount']" query_string="{$_SERVER['QUERY_STRING']}" page="$page" perpage="$_G['setting']['mobile']['mobiletopicperpage']">
            <!--{if $_G['forum_threadlist'] && $_G[forum]['threads'] > 0}-->
            <!--{subtemplate forum/forumdisplay_p}-->
            <!--{else}-->
            <!--{eval include_once template('common/common_module');}-->
            <!--{eval echo wq_app_no_content('forum/template','forum_nothreads');}-->
            <!--{/if}-->
        </ul>
    </div>
</div>

<!--{if $wq_app_setting[is_drop_down_loading]}-->
<!--{eval echo wq_app_load_icon();}-->
<!--{else}-->
<!--{if $multipage}-->
<div class="pgs cl mtm"><!--{eval echo wq_app_multipage($multipage);}--></div>
<!--{/if}-->
<!--{/if}-->
<!--{/if}-->
<!--{if $wq_app_setting[is_drop_down_loading] && $_G['forum_threadlist'] && $_G[forum]['threads'] > 0}-->
<p class="wqloaded_all"<!--{if $_G['forum_threadcount'] / $_G['setting']['mobile']['mobiletopicperpage'] > $page}--> style="display:none;"<!--{/if}-->>{$Tlang['b3f7b411f8a25701']}</p>
<!--{/if}-->
<!--{hook/forumdisplay_bottom_mobile}-->
<div class="wqheight44"></div>
<div class="wqedition_post wqnew_top ">
    <a href="forum.php?mod=post&action=newthread&fid={$_G['fid']}" id="newspecial">
		<div <!--{if $wq_app_setting['post_but_singleshow']}--> class="postbut"<!--{/if}-->>
        <i class="wqiconfont2 wqicon2-fatie"></i>
        {$Tlang['d67ced8c5e663236']}<!--{eval echo strip_tags($_G['forum']['name']) ? strip_tags($_G['forum']['name']) : $_G['forum']['name'];}-->{$Tlang['a9e07e284660333a']}
		</div>
    </a>
</div>
<!--{if $_G['group']['allowpost'] && ($_G['group']['allowposttrade'] || $_G['group']['allowpostpoll'] || $_G['group']['allowpostreward'] || $_G['group']['allowpostactivity'] || $_G['group']['allowpostdebate'] || $_G['setting']['threadplugins'] || $_G['forum']['threadsorts'])}-->
    <!--{eval $l=0;}-->
    <!--{block newspecial_html}-->
    <!--{if !$_G['forum']['allowspecialonly']}-->
        <!--{eval $l++;}-->
        <li><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]"><i class="wqiconfont2 wqicon2-post_1 wqapp_f22"></i>{lang post_newthread}<em class="wqiconfont2 wqicon2-jiantou"></em></a></li>
    <!--{/if}-->
    <!--{if $_G['group']['allowpostpoll']}-->
        <!--{eval $l++;}-->
        <li class="poll"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=1"><i class="wqiconfont2 wqicon2-toupiao wqapp_f22"></i>{lang post_newthreadpoll}<em class="wqiconfont2 wqicon2-jiantou"></em></a></li>
    <!--{/if}-->
    <!--{if $_G['group']['allowpostreward']}-->
        <!--{eval $l++;}-->
        <li class="reward"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=3"><i class="wqiconfont2 wqicon2-jinqian wqapp_f22"></i>{lang post_newthreadreward}<em class="wqiconfont2 wqicon2-jiantou"></em></a></li>
    <!--{/if}-->
    <!--{if $_G['group']['allowpostdebate']}-->
        <!--{eval $l++;}-->
        <li class="debate"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=5"><i class="wqiconfont2 wqicon2-vsbianlun wqapp_f22"></i>{lang post_newthreaddebate}<em class="wqiconfont2 wqicon2-jiantou"></em></a></li>
    <!--{/if}-->
    <!--{if $_G['group']['allowpostactivity']}-->
        <!--{eval $l++;}-->
        <li class="activity"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=4"><i class="wqiconfont2 wqicon2-qunliao wqapp_f22"></i>{lang post_newthreadactivity}<em class="wqiconfont2 wqicon2-jiantou"></em></a></li>
    <!--{/if}-->
    <!--{if $_G['group']['allowposttrade']}-->
        <!--{eval $l++;}-->
        <li class="g_trade"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=2"><i class="wqiconfont2 wqicon2-wodeshangpin wqapp_f22"></i>{lang post_newthreadtrade}<em class="wqiconfont2 wqicon2-jiantou"></em></a></li>
    <!--{/if}-->
    <!--{if $_G['forum']['threadsorts'] && !$_G['forum']['allowspecialonly']}-->
        <!--{loop $_G['forum']['threadsorts']['types'] $id $threadsorts}-->
        <!--{if $_G['forum']['threadsorts']['show'][$id]}-->
            <!--{eval $l++;}-->
            <li class="popupmenu_option"><a  href="forum.php?mod=post&action=newthread&fid=$_G[fid]&extra=$extra&sortid=$id"><i class="wqiconfont2 wqicon2-post_1 wqapp_f22"></i>$threadsorts<em class="wqiconfont2 wqicon2-jiantou"></em></a></li>
        <!--{/if}-->
        <!--{/loop}-->
    <!--{/if}-->
    <!--{/block}-->
<!--{if $l>1}-->
<div id="newspecial_menu" class="wqpost_ass" style="display: none;">
    <ul class="p_pop" id="wq_post_newthread_ul" style="overflow-y:auto;">
        $newspecial_html
    </ul>
    <ul class="p_pop"><li class="g_cancel"><a href="javascript:;" id="wq_g_cancel">{$Tlang['9c825be7149e5b97']}</a></li></ul>
</div>
<script type="text/javascript">
    $(function() {
        $('#wq_post_newthread_ul').css('max-height', wq_window_height - 56);
        $('#newspecial, #wq_g_cancel').click(function() {
            $('#mask').fadeToggle();
            $('#newspecial_menu').slideToggle();
            return false;
        });
        $('body').on('click', '#mask',function(e) {
            if (!$('#newspecial_menu').is(':hidden')){
                $('#mask').fadeOut();
                $('#newspecial_menu').slideUp();
            }
            e.preventDefault();
        });
    });

</script>
    <!--{/if}-->
<!--{/if}-->
<script type="text/javascript">
     var wqforum_list_follow = ".wqforum_list_follow", a_favorite = "#a_favorite", cancel_favorite = "#cancel_favorite", formhash = "{FORMHASH}", forum_fid = "$_G['forum']['fid']", Cancel_success = "{$Tlang['bef022f6310db3b9']}", _favtimes = "{$Tlang['36f840103635eeb2']}", favtimes = "{$Tlang['2c8a07313e7706bc']}", info_success = "{$Tlang['fffeda57b2002266']}", fav_num = "#fav_num", contain = '$showmodelclass';
</script>
<script type="text/javascript" src="{$_G['style']['styleimgdir']}js/forum/forumdisplay.js?{VERHASH}" charset="gbk"></script>
<div class="pullrefresh" style="display:none;"></div>
<style>#wq_ad_show2{display:none};</style>
<!--{eval $nofooter=1;}-->
<!--{template common/footer}-->

<!--{/if}-->