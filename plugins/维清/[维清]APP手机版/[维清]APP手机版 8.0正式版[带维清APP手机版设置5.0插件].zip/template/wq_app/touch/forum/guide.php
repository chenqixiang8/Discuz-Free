<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['guide'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{template common/header}-->

<!--{if empty($_GET['view']) && CURMODULE == 'guide'}-->
    <!--{eval wq_app_get_guide_options($wq_app_setting);}-->
<!--{/if}-->

<!--{if $_GET['update'] && $_GET['update'] == 'update'}-->
<!--{eval $push = get_my_favfids_by_fid(true);}-->
<!--{eval include template('forum/guide_1');}-->
<!--{template common/footer}-->
<!--{eval exit();}-->
<!--{/if}-->
<!-- header start -->
    <!--{if !$_GET['op']}-->

        <!--{eval
            $headparams['wtype'] = '2';
            $headparams['wclass'] = 'group_menu';
            $headparams['ltype'] = 'dh';
            $headparams['ctype'] = 'img';
            $headparams['cimg'] = $logofilename;
            $headparams['rtype'] = 'icon';
            $headparams['rurl'] = 'forum.php?mod=guide&view=newthread&ac=myfav&op=list';
            $headparams['rclass'] = ' wqicon2-chakantieziguanzhu wqapp_f24 wqmyfollow';
            echo wq_app_get_header($headparams,false,true);
        }-->

        <div class="wqguide_list_warp wqnew_bottom">
            <ul>
                <li><a href="forum.php?mod=guide&view=newthread" class="<!--{if $_GET['view'] == 'newthread' && !$_GET['ac']}--> wqcolor wqborder_bottom<!--{/if}-->">{$Tlang['13097feed87cf6ee']}</a></li>
                <li><a href="forum.php?mod=guide&view=hot"<!--{if $_GET['view'] == 'hot'}--> class="wqcolor wqborder_bottom"<!--{/if}-->>{$Tlang['6959da5d2e80c069']}</a></li>
                <li><a href="forum.php?mod=guide&view=digest"<!--{if $_GET['view'] == 'digest'}--> class="wqcolor wqborder_bottom"<!--{/if}-->>{$Tlang['46d1ecf7cc55b12f']}</a></li>
                <li><a href="forum.php?mod=guide&view=newthread&ac=myfav"<!--{if $_GET['ac'] == 'myfav'}--> class="wqcolor wqborder_bottom"<!--{/if}-->>{$Tlang['2c8a07313e7706bc']}</a></li>
            </ul>
        </div>
    <!--{else}-->
        <!--{eval
            $headparams['wtype'] = '1';
            $headparams['lurl'] = $backurl;
            $headparams['ltype'] = 'a';
            $headparams['cname'] = $Tlang['d4ad604e64744048'];
            echo wq_app_get_header($headparams);
        }-->
    <!--{/if}-->
    <div class="mui-off-canvas-backdrop"></div>
    <!-- header end -->
    <!--{hook/index_top_mobile}-->

    <!-- main forumlist start -->
    <!--{if $_GET['ac'] == 'myfav' && $_GET['op'] == 'list'}-->

<div class="wqfollow_list">
    <h3><span class="wqline wqbg_color"></span>{$Tlang['bb8dbdc596494abc']}</h3>
    <!--{eval $myfav = get_my_favfids_by_fid();}-->
    <!--{if $myfav}-->
        <ul class="wqfollow_list_ul">
            <!--{loop $myfav $key $val}-->
                <li class="wqnew_bottom">
                    <a href="forum.php?mod=forumdisplay&fid={$val['fid']}">
                        <div class="wqfollow_list_img">
                            <!--{if $val[icon]}-->
                               <img src="$_G['setting']['attachurl']common/$val[icon]" alt="$val[name]" />
                            <!--{else}-->
                                <img src="{$_G['style'][styleimgdir]}images/forum{if $val[folder]}_new{/if}.gif" alt="$val[name]" />
                             <!--{/if}-->
                        </div>
                        <div class="wqtitle"><span class="wqname wqellipsis">$val['name']</span></div>
                        <div class="wqdesc wqellipsis"><span class="wqm_right10">$val['threads']{$Tlang['7d938b8372235f6b']}</span><span>$val['favtimes']{$Tlang['afa0307eee1d3577']}</span></div>
                    </a>
                    <div  class="wqcancel_follow wqborder ">
                        <a href="javascript:;" class="wqcolor wqfav-button" id="fav_wqcolor_{$val[fid]}" data="$val[fid]">{$Tlang['914d2c5341afe66f']}</a>
                    </div>
                </li>
            <!--{/loop}-->
        </ul>
    <!--{else}-->
        <div class="wqno_follow">
            <a href="forum.php?mod=misc&action=nav&ac=myfav">
                <div class="wqfollow_list_img wqborder_grey">
                    <i class="wqiconfont2 wqicon2-increase"></i>
                </div>
                <div class="wqno_foffow wqapp_f14">{$Tlang['444c93fdbc1f42f3']}</div>
            </a>
        </div>
    <!--{/if}-->
</div>
<!--{eval $push = get_my_favfids_by_fid(true);//echo"<pre>";print_r($push);exit;}-->
 <!--{if $push}-->
<div class="wqseparate"></div>
<div class="wqfollow_list">
    <h3><span class="wqline wqbg_color"></span>{$Tlang['38df038c95fd9274']}<span class="y wqapp_f14"><a href="forum.php?mod=guide&view=newthread&ac=myfav&op=list" class=" wqbule" id ="guide_update">{$Tlang['6ace45ddb6ca5867']}</a> </span></h3>
    <ul class="wqfollow_list_ul" id='update'>
        <!--{eval include template('forum/guide_1');}-->
    </ul>
</div>
<!--{/if}-->
<p class="wqmore"><a href="forum.php?mod=misc&action=nav&ac=myfav" class="wqblock">{$Tlang['4a46d6c501761eee']}<i class="wqiconfont2 wqicon2-jiantou"></i></a></p>
<script>
    var Cancel_success="{$Tlang['bef022f6310db3b9']}",formhash = "{FORMHASH}", info_success = "{$Tlang['fffeda57b2002266']}", _favtimes = "{$Tlang['2c8a07313e7706bc']}", favtimes = "{$Tlang['914d2c5341afe66f']}";
    function succeedhandle_favbtn(url, msg, param) {
        if ($.trim(msg) == info_success) {
            clearTimeout(setTimeout_location);
            setTimeout(function () {
                location.reload();
            }, 1000);
        }
    }
    function cancel_callback(fid) {
        popup.open('<div class=\"wqtip\"><p>' + Cancel_success + '</p></div>');
        $("#fav_wqcolor_" + fid).html(_favtimes);
        $("#fav_wqcolor_" + fid).parent().toggleClass('wqbg_color wqborder');
        $("#fav_wqcolor_" + fid).attr('data-href', 'home.php?mod=spacecp&ac=favorite&type=forum&id=' + fid).prop('id', 'fav_wqwhite_' + fid).addClass('wqwhite').removeClass('wqcolor');
        typeof get_favtimes != 'undefined' && get_favtimes(fid);
        setTimeout(function () {
            location.reload();
        }, 1000);
    }
</script>
<script type="text/javascript" src="{$_G['style']['styleimgdir']}js/public/favtimes.js?{VERHASH}"></script>
<!--{eval $nofooter=1;}-->
<!--{else}-->

<!--{if $wq_app_setting[thread_carousel]==1}-->
    <div class="wq_limp_g slide-stop">
        <div id="wqscroll" class="scroll_lb" style="visibility: visible;">
            <div class="scroll_lump">
                <!--{eval $wqscroll= get_block_data_by_bid($wq_app_setting['weiqing_thread_block_id']);}-->
                {$wqscroll}
            </div>
            <ul id="scroll_con">
                <!--{eval echo get_block_data_by_ul($wqscroll);}-->
            </ul>
        </div>
    </div>
<!--    <script src="{$_G['style'][styleimgdir]}js/thirdparty/swipe.js"></script>-->
    <script>
        var elem = document.getElementById('wqscroll');
        window.wqscroll = Swipe(elem, {
            auto: 3000,
            continuous: true,
            callback: function (pos) {
                var i = bullets.length;
                if (i == 2 && pos > 1) {
                    pos = pos - 2
                }
                while (i--) {
                    bullets[i].className = ' ';
                }
                bullets[pos].className = 'on';
            }
        });
        var bullets = document.getElementById('scroll_con').getElementsByTagName('li');
    </script>
<!--{/if}-->
<!--{eval $showmodel = get_guide_showmodel();}-->
<!--{eval $showmodelclass=wq_app_get_forum_class($showmodel);}-->
<!--{if $showmodel == 'j'}-->
<style>.wqmore{ background-color: #f0f0f0;margin-top: -10px;}</style>
<!--{/if}-->
<div class="$showmodelclass">
    <!--{eval unset($data);}-->
    <!--{eval $list = get_guide_data_by_type();}-->
    <!--{eval $page = max(1,intval($_GET['page']));}-->
    <!--{eval $threadcount =  $list['threadcount'];}-->
    <!--{eval $guide_view = get_guide_view();}-->
    <!--{if $list['threadcount']}-->
    <ul class="hotlist wqindex_list_ul pulldown_load_js <!--{if $showmodel == 'b'|| $showmodel == 's'}--> wqguide_list_ul<!--{/if}-->" id="thread_lists_{$guide_view}" contentid='thread_lists_{$guide_view}'  query_string="{$_SERVER['QUERY_STRING']}" count="$threadcount" page="$page" perpage="$wq_app_setting[guide_perpage]">
        <!--{eval include template('forum/guide_list_row_'.$showmodel);}-->
    </ul>
    <p class="wqloaded_all"<!--{if $threadcount / $wq_app_setting[guide_perpage] > $page}--> style="display:none;"<!--{/if}-->>{$Tlang['b3f7b411f8a25701']}</p>
    <!--{else}-->
    <p class="wqemp"><span class="wqno_con"><img src="{$_G['style'][styleimgdir]}images/wqno_con.png"></span>{lang guide_nothreads}</p>
    <!--{/if}-->
    <!--{eval echo wq_app_load_icon();}-->
</div>
<!--{if $showmodel == 'w'}-->
<script type="text/javascript" src="{$_G['style']['styleimgdir']}js/forum/moments.js?{VERHASH}" charset="gbk"></script>
<!--{/if}-->
<script>
    $(function () {
        var contain = '$showmodelclass';
        listStorage('guide', contain);
        $('html,body').css('min-height', '101%');
    });
</script>
<div class="pullrefresh" style="display:none;"></div>
<!--{/if}-->
<!-- main forumlist end -->
<!--{hook/index_middle_mobile}-->

<script type="text/javascript">
    var mobileforumview = "$_G['setting']['mobile']['mobileforumview']", visitclient = "$_GET['visitclient']";
</script>
<script type="text/javascript" src="{$_G['style']['styleimgdir']}js/forum/discuz.js?{VERHASH}" charset="gbk"></script>
<!--{if $_GET['ac'] == 'myfav'}-->

<!--{/if}-->
<style>#wq_ad_show2{display:none};</style>
<!--{eval $footerSlide = 1;}-->
<!--{template common/footer}-->
<!--{/if}-->