<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['post_reward'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->

<li class="wqnew_bottom">
    <input type="tel" name="rewardprice" id="rewardprice" class="wqpost_input" size="6" onkeyup="getrealprice(this.value)" placeholder="{$Tlang['086217487d7722ae']}" value="{$_G['group']['minrewardprice']}" tabindex="1" />
    <i class="wqpost_li_small wqapp_f14">{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][title]}</i>
</li>
<li>
    <p>{lang reward_tax_after} <strong id="realprice" class="wqred"> 2 </strong> {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][title]}</p>
    <p class="wqapp_f14 wqlh24">  {lang reward_price_min}{$_G['group']['minrewardprice']} {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}
    <!--{if $_G['group']['maxrewardprice'] > 0}-->, {lang reward_price_max} {$_G['group']['maxrewardprice']} {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}<!--{/if}-->
    , {lang you_have} <!--{echo getuserprofile('extcredits'.$_G['setting']['creditstransextra'][2]);}--> {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][title]}<br/>
    <!--{if $_G['setting']['rewardexpiration'] > 0}-->
    $_G['setting']['rewardexpiration'] {lang post_reward_message}
    <!--{/if}-->
    </p>
</li>
<script>
    function getrealprice(price){
        if (!price.search(/^\d+$/)) {
            n = Math.ceil(parseInt(price) + price * $_G['setting']['creditstax']);
            if (price > 32767) {
                document.getElementById('realprice').innerHTML = '<b>{lang reward_price_overflow}</b>';
            }
            <!--{if $_GET[action] == 'edit'}-->
            else if (price < $rewardprice) {
                document.getElementById('realprice').innerHTML = '<b>{lang reward_cant_fall}</b>';
            }
            <!--{/if}-->
            else if (price < $_G['group']['minrewardprice'] || ($_G['group']['maxrewardprice'] > 0 && price > $_G['group']['maxrewardprice'])) {
                document.getElementById('realprice').innerHTML = '<b>{lang reward_price_bound}</b>';
            } else {
                document.getElementById('realprice').innerHTML = n;
            }
        } else{
            document.getElementById('realprice').innerHTML = '<b>{lang input_invalid}</b>';
        }
    }
    if(document.getElementById('rewardprice')) {
        getrealprice(document.getElementById('rewardprice').value)
    }
</script>
<!--{/if}-->