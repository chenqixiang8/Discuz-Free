<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['view'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{template common/header}-->
<!--{if !empty($_G['cache']['plugin']['wq_reward'])}-->
<!--{eval include_once DISCUZ_ROOT . './source/plugin/wq_reward/function/function_reward.php';}-->
<!--{eval $button_html = forum_portal_group('aid',$_GET['aid']);}-->
<!--{/if}-->

<!--{eval
$wq_app_usergroup=$_G['cache']['wq_usergroup']?$_G['cache']['wq_usergroup']:wq_usergroup();
$articleuserinfo = get_wq_app_userinfo_and_age($article,true);
}-->
<style>.quote{ margin-bottom: 0px;}</style>
    <!--{block headconnect}-->
        <div id="wqgateway_js" name="moptions_$post[pid]" popup="true" class="wqadmin_eject new_menu" style="display:none;">
            <span class="wqadmin_eject_arrow"></span>
            <ul>
                <li><button type="button" class="wqpadding_leftright5" onclick="location.href='portal.php?mod=portalcp&ac=article&op=edit&aid=$article[aid]'"><i class="wqiconfont2 wqicon2-xindenew85 wqapp_f18"></i>{lang edit}</button></li>
                <li><button type="button" class="newDialog wqpadding_leftright5" href="portal.php?mod=portalcp&ac=article&op=delete&aid={$_GET[aid]}&handlekey=wqdelete&inajax=1" data-message="{$Tlang['fb2ba3e9f3f1a628']}" data-value="0" data-handle="wqdelete"><i class="wqiconfont2 wqicon2-gbdelete wqapp_f20"></i>{lang delete}</button></li>
                <li><button type="button" class="newDialog wqpadding_leftright5" href="portal.php?mod=portalcp&ac=article&op=delete&aid={$_GET[aid]}&handlekey=wqdelete&inajax=1" data-message="{$Tlang['d420a3331bdca28f']}" data-value="1" data-handle="wqdelete"><i class="wqiconfont2 wqicon2-huishou wqapp_f20"></i>{$Tlang['350b60ee1854cc19']}</button></li>
            </ul>
        </div>
        <div class="new_hide" style="display: none;"></div>
    <!--{/block}-->

     <!--{eval $headright=false;}-->
    <!--{if $_G['group']['allowmanagearticle'] || ($_G['group']['allowpostarticle'] && $article['uid'] == $_G['uid'] && (empty($_G['group']['allowpostarticlemod']) || $_G['group']['allowpostarticlemod'] && $article['status'] == 1)) || $categoryperm[$value['catid']]['allowmanage']}-->
        <!--{eval
            $headright=true;
            $headparams['rtype'] = 'icon';
            $headparams['rclass'] = ' wqicon2-gengduo1 y wqapp_f30 wqheader_right new_button';
        }-->
    <!--{/if}-->
    <!--{eval
        $headparams['wtype'] = '3';
        $headparams['ltype'] = 'a';
        $headparams['lurl'] = $backurl;
        $headparams['cname'] = $Tlang['ed40e4b80f96457b'];

        echo wq_app_get_header($headparams, true, $headright, $headconnect) ;
    }-->

<div class='wqwechat_image_preview_warp'>
<div class="wqview_warp">
    <!--{if $wq_app_setting['portal_view_showmodel'] == 1}-->
    <div class="wqview_title wqnew_bottom">
        <h2 class="wqtitle">$article[title] <!--{if $article['status'] == 1}-->({lang moderate_need})<!--{elseif $article['status'] == 2}-->({lang ignored})<!--{/if}--></h2>
        <div class="wqsection_name">
            <span class="wqname">
                <a href="{echo getportalcategoryurl($cat[catid])}">$cat[catname]<i class="wqiconfont2 wqicon2-202"></i></a></span>
            <span class="wqy wqinfo"><!--{if $article[viewnum] > 0}-->$article[viewnum]<!--{else}-->0<!--{/if}-->{$Tlang['a6aa5366e09f370c']}<em><!--{if $article[commentnum] > 0}-->$article[commentnum]<!--{else}-->0<!--{/if}-->{$Tlang['dbedca5ca18ae5c8']}</em></span>
        </div>
    </div>
    <div class="wquser_info">
        <div class="wqhead_img">
            <a href="home.php?mod=space&uid=$article[uid]{if $_G['uid']==$article[uid]}&mycenter=1{/if}" style="display: initial">
             <img class="wqhead" src="{avatar($article['uid'], small, true)}" style="display: inline; visibility: visible;">
            </a>
        </div>
        <div class="wqhead_con">
            <div class="wqname"><a href="home.php?mod=space&uid=$article[uid]{if $_G['uid']==$article[uid]}&mycenter=1{/if}"><span class="wqwidth80">$article[username]</span></a>
                <!--{if $articleuserinfo[$article[uid]][gender]}-->
                    <!--{eval $age = !empty($articleuserinfo[$article[uid]]['birthyear']) ? (intval(date("Y",time())) - $articleuserinfo[$article[uid]]['birthyear']) + 1 : "";}-->
                    <!--{if $articleuserinfo[$article[uid]]['gender']==1}-->
                        <span class="wqgender wqman"><i class="wqiconfont2 wqicon2-nan wqapp_f12"></i> {$age}</span>
                    <!--{else}-->
                        <span class="wqgender wqgirl"><i class="wqiconfont2 wqicon2-nv wqapp_f12"></i> {$age}</span>
                    <!--{/if}-->
                <!--{/if}-->
                <span class='wqm_left3'>
                    <a href="home.php?mod=spacecp&ac=usergroup{if $_G[uid]!=$post[authorid]}&gid=$post[groupid]{/if}" class="wqapp_f12 dislv_on">
                        <!--{echo wq_usergroup_show($articleuserinfo[$article[uid]][groupid]);}-->
                    </a>
                </span>
              </div>
            <div class="wqdate"> $article[dateline]</div>
            <p class="wqoriginal_author"> <!--{if $article[author]}--><em class="wqheader_right">{lang view_author_original}: $article[author]</em><!--{/if}--></p>
        </div>
    </div>
     <!--{elseif $wq_app_setting['portal_view_showmodel'] == 2}-->
     <div class="wqportal_view_showmodel_2">
         <h2 class="wq_title">$article[title] <!--{if $article['status'] == 1}-->({lang moderate_need})<!--{elseif $article['status'] == 2}-->({lang ignored})<!--{/if}--></h2>
         <p class="wq_info">
             <a href="{echo getportalcategoryurl($cat[catid])}">$cat[catname]</a>$article[dateline]
             <span><i class="wqiconfont2 wqicon2-yulan wqapp_f16 wqm_right3"></i><!--{if $article[viewnum] > 0}-->$article[viewnum]<!--{else}-->0<!--{/if}--></span></p>
     </div>
      <!--{elseif $wq_app_setting['portal_view_showmodel'] == 3}-->
       <div class="wqportal_view_showmodel_3">
         <h2 class="wq_title">$article[title] <!--{if $article['status'] == 1}-->({lang moderate_need})<!--{elseif $article['status'] == 2}-->({lang ignored})<!--{/if}--></h2>
         <p class="wq_info">
             <a href="{echo getportalcategoryurl($cat[catid])}">$cat[catname]</a><!--{if $article[viewnum] > 0}-->$article[viewnum]<!--{else}-->0<!--{/if}-->{$Tlang['a6aa5366e09f370c']}
             <span>$article[dateline]</span></p>
     </div>
      <!--{/if}-->
 <!--{if $article[summary] && empty($cat[notshowarticlesummay])}-->
        <div class="wqview_abstract"><div><strong>{lang article_description}</strong>: $article[summary]</div><!--{hook/view_article_summary}--></div>
    <!--{/if}-->
    <div class="message wqshare_wx wqpost_view_warp">
        <div class="text_con_txt message_img">
            <div class="vwtb">
                <div id="article_content message_img">
                    {if $content[title]}
                    <div class="vm_pagetitle xw1">$content[title]</div>
                    {/if}
                    <!--{hook/view_portalcontent}-->
                    $content[content]
                </div>
            </div>
            <!--{if $multi}--><div class="ptw pbw cl">$multi</div><!--{/if}-->
        </div>
        {$button_html}
        <script type="text/javascript" src="{$_G[setting][jspath]}home.js?{VERHASH}"></script>
    </div>
</div>
<div id="click_div">
    <!--{template home/space_click}-->
</div>
<!--{eval $listuserinfo=get_wq_app_userinfo_and_age($commentlist,true,'follower');}-->
 <!--{if $article['allowcomment']}-->

<div class="wqseparate2" id="wqall_comment"></div>
<div class="wqposts_atom">
     <!--{if $wq_app_setting['portal_view_reply'] == 1}-->
        <h3><a id="order" name="order" class="wqborder_bottom wqcolor">{$Tlang['4bc7b967c326c87e']}</a></h3>
    <!--{elseif $wq_app_setting['portal_view_reply'] == 2}-->
        <h3 class="wqportal_view_reply2"><a id="order" name="order">{$Tlang['4bc7b967c326c87e']}</a></h3>
    <!--{elseif $wq_app_setting['portal_view_reply'] == 3}-->
        <h3 class="wqportal_view_reply3 wqapp_f14"><a id="order" name="order">{$Tlang['b12fbc28c49a5b96']}</a></h3>
     <!--{/if}-->
    <div class="wqpost_view" id="comment_{$comment[cid]}_li">
        <ul>
            <!--{loop $commentlist $comment}-->
            <li class="<!--{if $wq_app_setting['portal_view_reply'] == 3}-->wqreply_full_screen <!--{else}-->wqpost_view_info_div<!--{/if}-->">
                <a href="home.php?mod=space&do=profile&uid=$comment[uid]" style="display: initial">
                    <img src="{avatar($comment[uid], middle, true)}" class="wqhead" />
                </a>
                <div class="wqpost_view_info" href="#replybtn_$post[pid]">
                    <h2 class="wqapp_f16">
                        <!--{if !empty($comment['uid'])}-->
                        <a href="home.php?mod=space&do=profile&uid=$comment[uid]" class="wqwidth80 wqapp_f16 wq_grey">  $comment[username]</a>
                        <!--{else}-->
                        <a href="javascript:;" class="wqwidth80 wqapp_f16 wq_grey"> {lang guest}</a>
                        <!--{/if}-->

                        <!--{if $listuserinfo[$comment['uid']]['gender']==1}-->
                            <span class="wqgender wqman"><i class="wqiconfont2 wqicon2-nan wqapp_f12"></i>{$listuserinfo[$comment['uid']][age]}</span>
                        <!--{elseif $listuserinfo[$comment['uid']]['gender']==2}-->
                            <span class="wqgender wqgirl"><i class="wqiconfont2 wqicon2-nv wqapp_f12"></i>{$listuserinfo[$comment['uid']][age]}</span>
                        <!--{/if}-->
                        <span class='wqm_left3'>
                            <a href="javascript:;" class="f12">
                                <!--{eval echo wq_usergroup_show($listuserinfo[$comment['uid']][groupid]);}-->
                            </a>
                        </span>
                        <!--{if ($_G['group']['allowmanagearticle'] || $_G['uid'] == $comment['uid']) && $_G['groupid'] != 7 && !$article['idtype']}-->
                        <span class="y wqm_left10 new_div" style="line-height: 24px;"><a href="javascript:;" class="wq_grey new_button"><i class="wqiconfont2 wqicon2-gengduo1 wqapp_f20"></i></a></span>
                        <!--{/if}-->
                        <div id="wqgateway_comment_js" name="moptions_$post[pid]" popup="true" class="wqadmin_eject new_menu" style="display:none;">
                            <span class="wqadmin_eject_arrow"></span>
                            <ul>
                                <!--{if $comment['uid'] == $_G['uid']}-->
                                <li><a href="portal.php?mod=portalcp&ac=comment&op=edit&cid=$comment[cid]&aid={$_GET[aid]}" id="c_$comment[cid]_edit" class="wqpadding_leftright5"><i class="wqiconfont2 wqicon2-xindenew85 wqapp_f20"></i>{lang edit}</a></li>
                                <!--{/if}-->
                                <li><a href="portal.php?mod=portalcp&ac=comment&op=delete&cid=$comment[cid]" id="c_$comment[cid]_delete" class="newDialog wqpadding_leftright5"  data-message="{$Tlang['df2c63ea0791153a']}"> <i class="wqiconfont2 wqicon2-gbdelete wqapp_f20" style='vertical-align: middle'></i>{lang delete}</a></li>
                            </ul>
                        </div>
                        <!--{if !isset($_G[makehtml])}--><span class="y wqapp_f14 wq_grey"><a href="javascript:;" class="reference notlogged">{lang quote}</a></span> <!--{/if}-->
                    </h2>
                     <!--{if $wq_app_setting['portal_view_reply'] == 3}--><div class='wq_time2'><!--{date($comment[dateline])}--></div><!--{/if}-->
                    <div class="wq_img">
                        <!--{if $_G[adminid] == 1 || $comment[uid] == $_G[uid] || $comment[status] != 1}-->
                        <!--{eval $comment[message] = str_replace('smilieid="','class="wq_smilieimg" smilieid="',$comment[message]);}-->
                        $comment[message]
                        <!--{else}-->
                        {lang moderate_not_validate}
                        <!--{/if}-->
                    </div>
                    <!--{if $wq_app_setting['portal_view_reply'] != 3}--><div class='wq_time' style='margin-left: 0px; '><!--{date($comment[dateline])}--></div><!--{/if}-->
                </div>
            </li>
            <!--{/loop}-->
        </ul>
    </div>
</div>

<!--{if !empty($aimgs[$comment[cid]])}-->
<script type="text/javascript" reload="1">aimgcount[{$comment[cid]}] = [<!--{echo implode(',', $aimgs[$comment[cid]]);}-->];attachimgshow($comment[cid]);</script>
<!--{/if}-->
<!--{if empty($commentlist)}-->
<div class="wqempty_sofa"><img src="{$_G['style'][styleimgdir]}images/sofa.png"/><br/>{$Tlang['d72d60ca7091a3bd']}</div>
<!--{/if}-->
<!--{/if}-->
<!--{template common/share}-->
</div>
<!--{subtemplate portal/view_fastpost}-->
<!--<a href="javascript:;" title="{lang scrolltop}" class="scrolltop bottom"></a>-->
<script type="text/javascript">
    function succeedhandle_wqdelete(url) {
        clearTimeout(setTimeout_location);
        setTimeout_location = setTimeout(function() {
            location.replace(url);
        }, 1000);
    }
    function succeedhandle_cform() {
        var str = '{$Tlang['27aced185a192f9a']}'
        clearTimeout(setTimeout_location);
        if ($.trim(arguments[1]) == str) {
            setTimeout_location = setTimeout(function() {
                popup.close();
            }, 1000);
        } else {
            setTimeout_location = setTimeout(function() {
                history.go(0);
            }, 1000);
        }
    }
    var scroll_Top;
    function uploadsuccess_forum(data) {
        if(data == '') {
            popup.open('{lang uploadpicfailed}', 'alert');
        }
        var dataarr = data.split('|');
        if(dataarr[0] == 'DISCUZUPLOAD' && dataarr[2] == 0) {
            popup.close();
            if ($('#imglist').is(':hidden')) {
                $('.cellphone_expression').hide();
                $('.wqbiaoqing').removeClass('wqicon2-jianpan').addClass('wqicon2-biaoqing');
                $('#imglist').show();
            }
           $('#imglist').prepend('<li><span aid="'+dataarr[3]+'" class="del wqdelete"><a href="javascript:;"> <i class="wqiconfont2 wqicon2-jianhao f22"></i></a></span><span class="wqimg"><a href="javascript:;"><img id="aimg_'+dataarr[3]+'" title="'+dataarr[6]+'" src="{$_G[setting][attachurl]}forum/'+dataarr[5]+'" /></a></span><input type="hidden" name="attachnew['+dataarr[3]+'][description]" /></li>');
           $('.wqtoday').show().text($('#imglist li').length-1);
           $('#filedata').val('');
        } else {
            var sizelimit = '';
            if(dataarr[7] == 'ban') {
                sizelimit = '{lang uploadpicatttypeban}';
            } else if(dataarr[7] == 'perday') {
                sizelimit = '{lang donotcross}'+Math.ceil(dataarr[8]/1024)+'K)';
            } else if(dataarr[7] > 0) {
                sizelimit = '{lang donotcross}'+Math.ceil(dataarr[7]/1024)+'K)';
            }
            popup.open(STATUSMSG[dataarr[2]] + sizelimit, 'alert');
        }
    };
    $('.wqbiaoqing').on('click', function () {
        $(this).toggleClass('wqicon2-jianpan');
        if ($('.cellphone_expression').is(':hidden')) {
            $('#imglist').hide();
            $('.cellphone_expression').show();
            $('#upload_icon').removeClass('blue');
            $('.wqbiaoqing').removeClass('wqicon2-biaoqing');
            expression_viwepager();
        } else {
            $('.cellphone_expression').hide();
            $('.wqbiaoqing').addClass('wqicon2-biaoqing');
        }
    });
    function expression_insertunit(obj) {
        var id_val = $('.wqpost_textarea').val();
        $('.wqpost_textarea').val(id_val + obj.attr('code'));
    }
    if (!typeof deleteSmiles == 'undefined') {
        deleteSmilies('{:', ':}');
    }
    $('.wqcomment_input_div.z, .reference').click(function () {
        scroll_Top = $(window).scrollTop();
        $('.new_lump, .new_list').show();
        $('.postlist, .wqposts_atom').hide();
    });
    $('.reference').click(function () {
        var message = $.trim($(this).parents('h2').next().html().slice($(this).parents('h2').next().html().lastIndexOf('>') + 1));
        var author = $.trim($(this).parents('h2').find('.wqwidth80.wqapp_f16.wq_grey').html());
        $('.wqpost_textarea').val('[quote]' + author + ': ' + message + '[/quote]\n');
    });
    if (typeof common_wxImagePreview == 'function') {
        common_wxImagePreview('wqpost_view_warp');
    }
</script>
</div>
<!--{eval $nofooter=1;}-->
<!--{template common/footer}-->

<!--{/if}-->