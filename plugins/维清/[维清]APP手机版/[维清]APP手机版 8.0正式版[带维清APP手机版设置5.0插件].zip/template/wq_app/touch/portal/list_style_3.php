<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['list_style_3'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{eval
    $highlight = article_title_style($value);
    $article_url = fetch_article_url($value);
    $imglist[$value[aid]][image] = array_slice($imglist[$value[aid]][image],0,3);
    $classname = $imglist[$value[aid]][num] == 1 ? "list_pane1" : ($imglist[$value[aid]][num] == 2 ? "list_pane2" : "list_pane3");
}-->

<li class="wqnew_bottom">
    <a href="$article_url" class="wqblock">
        <div class="max_wqlisthidden">
            <h3 class="wqtitle_list">$value[title]<!--{if $value[status] == 1}-->({lang moderate_need})<!--{/if}--></h3>
            <p class="wqcon">$value[summary]</p>
        </div>
        <!--{if $imglist[$value[aid]][num] && $imglist[$value[aid]][num] > 0}-->
            <div class="{$classname}">
                <!--{loop $imglist[$value[aid]][image] $k $v}-->
                    <div class="wq-lazyload-container">
                        <img class="wq_js_delayload" src="{$_G['style'][styleimgdir]}images/wq_dian.jpg" data-src="{$v}">
                    </div>
                <!--{/loop}-->
                <!--{if $imglist[$value[aid]][num] > 1}-->
                <span class="wqlisttu2"><i class="wqiconfont2 wqicon2-tupian-copy wqapp_f14 wqm_right2"></i>{$imglist[$value[aid]][num]}</span>
                <!--{/if}-->
            </div>
        <!--{/if}-->
        <p class="list_info wqm_top10">
            <span> $value[dateline]</span>
            <span class="y"><i class="wqiconfont2 wqicon2-pinglun2 wqapp_f12 wqapp_f13"></i><!--{if $value[commentnum] > 0}-->$value[commentnum]<!--{else}-->0<!--{/if}--></span>
        </p>

    </a>
</li>
<!--{/if}-->