<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['list_style_6'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{eval $highlight = article_title_style($value);}-->
<!--{eval $article_url = fetch_article_url($value);}-->
<li class="wqnew_bottom">
    <a href="$article_url" class="wqblock">
        <!--{if $imglist[$value[aid]][num] && $imglist[$value[aid]][num] > 0}-->
        <div class="wqlist1 wq-lazyload-container">
           <img class="wq_js_delayload delayload tn" src="$_G['style'][styleimgdir]images/wq_dian.jpg" data-src="{$imglist[$value[aid]][image][0]}" alt="$value[title]"/>
        </div>
        <!--{/if}-->
        <div>
            <h3 class="<!--{if $imglist[$value[aid]][num] && $imglist[$value[aid]][num] > 0}-->wqlisthiddenp<!--{else}-->wqmax_listhiddenp<!--{/if}-->">
                $value[title]<!--{if $value[status] == 1}-->({lang moderate_need})<!--{/if}-->
            </h3>
        </div>
        <p class="list_info">
            <span class="wqwidth120">$value[username]</span>
            <span class="y">{$value['dateline']}</span>
        </p>
    </a>
</li>
<!--{/if}-->