<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['list_style_4'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{eval
    $highlight = article_title_style($value);
    $article_url = fetch_article_url($value);
    $imglist[$value[aid]][image] = array_slice($imglist[$value[aid]][image],0,3);
}-->
<!--{if $imglist[$value[aid]] && $imglist[$value[aid]][num] >= 3 }-->
    <li class="wqinformation_3 wqnew_bottom">
        <a href="$article_url" class="wqblock guidelink">
            <div class="max_wqlisthidden ">
                <h3 class="wqtitle_list">
                   $value[title]<!--{if $value[status] == 1}-->({lang moderate_need})<!--{/if}-->
                </h3>
                <p class="wqcon">$value[summary]</p>
            </div>
            <div class="list_pane3">
                <!--{loop $imglist[$value[aid]][image] $k $v}-->
                    <div class="wq-lazyload-container" >
                        <img class="wq_js_delayload" src="{$_G['style'][styleimgdir]}images/wq_dian.jpg" data-src="{$v}">
                    </div>
                <!--{/loop}-->
                <!--{if $imglist[$value[aid]][num] > 3 }-->
                    <span class="wqlisttu2"><i class="wqiconfont2 wqicon2-tupian-copy wqapp_f14 wqm_right2"></i>{$imglist[$value[aid]][num]}</span>
                <!--{/if}-->
            </div>
            <p class="list_info">
                    <span>$value[dateline]</span>
                    <span class="y"><i class="wqiconfont2 wqicon2-pinglun2 wqapp_f12"></i>
                       <!--{if $value[commentnum] > 0}-->$value[commentnum]<!--{else}-->0<!--{/if}-->
                    </span>
            </p>
        </a>
    </li>
<!--{else}-->
    <li class="wqinformation_1 wqnew_bottom">
        <a href="$article_url" class="wqblock">
            <!--{if $imglist[$value[aid]] && $imglist[$value[aid]][num] > 0}-->
                <div class="wqlist2 wq-lazyload-container">
                   <img class="wq_js_delayload" src="{$_G['style'][styleimgdir]}images/wq_dian.jpg"  data-src="{$imglist[$value[aid]][image][0]}">
                </div>
            <!--{/if}-->
            <div class="<!--{if $imglist[$value[aid]] && $imglist[$value[aid]][num] == 0}-->max_wqlisthidden<!--{else}-->wqlisthidden<!--{/if}-->">
                <h3 class="wqtitle_list">
                   $value[title]<!--{if $value[status] == 1}-->({lang moderate_need})<!--{/if}-->
                </h3>
                <p class="wqcon">$value[summary]</p>
            </div>
            <p class="list_info">
                <span>{$value[dateline]}</span>
                <span class="y"><i class="wqiconfont2 wqicon2-pinglun2 wqapp_f12"></i><!--{if $value[commentnum] > 0}-->$value[commentnum]<!--{else}-->0<!--{/if}--></span>
            </p>
        </a>
    </li>
<!--{/if}-->
<!--{/if}-->