<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['list'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{block wq_navtitle}-->
<!--{if !empty($navtitle)}-->$navtitle - <!--{/if}--><!--{if empty($nobbname)}--> $_G['setting']['bbname'] - <!--{/if}--> {lang waptitle} - Powered by Discuz!
<!--{/block}-->
<!--{if $_GET['api'] != '1'}-->
<!--{template common/header}-->
<!--{eval $perpage = $cat['perpage'];}-->
<!--{/if}-->
<!--{eval $list = array();}-->
<!--{eval $wheresql = category_get_wheresql($cat);}-->
<!--{eval $list = category_get_list($cat, $wheresql, $page);}-->
<!--{if $_GET['api'] == '1'}-->
    <!--{eval include DISCUZ_ROOT.'./template/wq_app/php/config.php';}-->
<!--{if $page==1}-->
    <ul class="wqindex_list_ul" id="hotlist_{$cat[catid]}" count="$list[count]" page="$page" perpage="$cat['perpage']" data="$cat[catid]" title="$wq_navtitle">
<!--{/if}-->
<!--{if $list['list']}-->
    <!--{eval
        $imglist=wq_app_setting_get_imgurl_and_num($list['list']);
    }-->
    <!--{loop $list['list'] $value}-->
        <!--{if $wq_app_setting['portal_list_showmodel'] == 6}-->
            <!--{template portal/list_style_6}-->
        <!--{elseif $wq_app_setting['portal_list_showmodel'] == 3}-->
            <!--{template portal/list_style_3}-->
        <!--{elseif $wq_app_setting['portal_list_showmodel'] == 4}-->
            <!--{template portal/list_style_4}-->
        <!--{/if}-->
    <!--{/loop}-->
<!--{elseif $page==1}-->
    <p class="wqemp"><span class="wqno_con"><img src="{$_G['style'][styleimgdir]}images/wqno_con.png"></span>{$Tlang['108da925079f6c07']}</p>
<!--{/if}-->
<!--{if $page==1}-->
    </ul>
<!--{/if}-->
<!--{eval exit();}-->
<!--{/if}-->

<!--{template common/share}-->
<!--{if $_GET['formindex']}-->
<!--{if $wq_app_setting[portal_carousel]==1}-->

<!--{eval
    $headparams['wtype'] = '2';
    $headparams['wclass'] = 'group_menu';
    $headparams['ltype'] = 'dh';
    $headparams['ctype'] = 'img';
    $headparams['cimg'] = $logofilename;
    $headparams['rtype'] = 'share';
    echo wq_app_get_header($headparams,false,true);
}-->

    <div class="wq_limp_g slide-stop">
        <div id="wqscroll" class="scroll_lb" style="visibility: visible;">
            <div class="scroll_lump">
                <!--{eval $wqscroll= get_block_data_by_bid($wq_app_setting['weiqing_article_block_id']);}-->
                {$wqscroll}
            </div>
            <ul id="scroll_con">
                <!--{eval echo get_block_data_by_ul($wqscroll);}-->
            </ul>
        </div>
    </div>
<script>
    var elem = document.getElementById('wqscroll');
    window.wqscroll = Swipe(elem, {
        auto: 3000,
        continuous: true,
        callback: function (pos) {
            var i = bullets.length;
            if (i == 2 && pos > 1) {
                pos = pos - 2
            }
            while (i--) {
                bullets[i].className = ' ';
            }
            bullets[pos].className = 'on';
        }
    });

    var bullets = document.getElementById('scroll_con').getElementsByTagName('li');
</script>
<!--{/if}-->
<div class="my_portal_tag group_tag_ul wqnew_bottom" id="my_group_tag">
    <div class="tag_list">
        <ul class="slide-stop">
            <!--{loop $catids $cats}-->
            <li <!--{if $cat[catid] == $cats}--> class="a b_bule_bottom"<!--{/if}-->>
                <a href="portal.php?catid={$cats}"  data="$cats">{$_G['cache']['portalcategory'][$cats][catname]}</a>
            </li>
            <!--{/loop}-->
        </ul>
    </div>
</div>
<!--{eval $my_roll_tag='my_group_tag';}-->
    <!--{template common/slide}-->
<!--{else}-->
        <!--{eval $headright=false;}-->
    <!--{if ($_G['group']['allowpostarticle'] || $_G['group']['allowmanagearticle'] || $categoryperm[$catid]['allowmanage'] || $categoryperm[$catid]['allowpublish']) && empty($cat['disallowpublish'])}-->
        <!--{eval
            $headright=true;
            $headparams['rtype'] = 'a';
            $headparams['rclass'] = 'wqapp_f22 wqiconfont2 wqicon2-fabiao';
            $headparams['rurl'] ='portal.php?mod=portalcp&ac=article&catid='.$cat[catid];
        }-->
    <!--{/if}-->
    <!--{eval
        $headparams['wtype'] = '1';
        $headparams['lurl'] = $backurl;
        $headparams['ltype'] = 'a';
        $headparams['cname'] = $cat[catname];
        echo wq_app_get_header($headparams,true,true);
    }-->
    
<!--{/if}-->
<!--{eval
    $imglist=wq_app_setting_get_imgurl_and_num($list['list']);
}-->
<!--{eval //echo"<pre>"; print_r($imglist);exit;}-->
<div id="ct" class="wqindex_list wqindex_listp">
    <ul class="wqindex_list_ul" id="hotlist_{$cat[catid]}" count="$list[count]" page="$page" perpage="$perpage" data="$cat[catid]" title="$wq_navtitle">
        <!--{if $list['list']}-->
        <!--{loop $list['list'] $value}-->
            <!--{if $wq_app_setting['portal_list_showmodel'] == 6}-->
            <!--{template portal/list_style_6}-->
        <!--{elseif $wq_app_setting['portal_list_showmodel'] == 3}-->
            <!--{template portal/list_style_3}-->
        <!--{elseif $wq_app_setting['portal_list_showmodel'] == 4}-->
            <!--{template portal/list_style_4}-->
        <!--{/if}-->
        <!--{/loop}-->
        <!--{else}-->
        <p class="wqemp"><span class="wqno_con"><img src="{$_G['style'][styleimgdir]}images/wqno_con.png"></span>{$Tlang['108da925079f6c07']}</p>
        <!--{/if}-->
    </ul>
    <div class="wqmore" style="display: none">
        <!--{if $_G[uid] && isset($mysetting[myextstyle]) && $mysetting[myextstyle] != '0'}-->
        <img src="{$_G['style'][styleimgdir]}images/icon_load.gif"/>
        <!--{else}-->
        <img src="{$_G['style'][styleimgdir]}images/icon_load.gif"/>
        <!--{/if}-->
        {$Tlang['d0a97567aed382e8']}
    </div>
    <p class="wqloaded_all" style="display:none;" >{$Tlang['b3f7b411f8a25701']}</p>
</div>
<script type="text/javascript">
    var navcontrol = null;
    $(function () {
        if (history.pushState) {
            history.replaceState({title: '$cat[catid]'}, document.title, location.href);
            var currentState = false;

            $('#my_group_tag a').click(function (event) {
                var obj = $(this);
                wq_switch_nav(obj);
                return false;
            });

            window.addEventListener("popstate", function () {
                currentState = history.state;
                if (currentState.title) {
                    var obj = $('#my_group_tag a[data="' + currentState.title + '"]');
                    if (obj.length) {
                        wq_switch_nav(obj);
                    }
                }
            });

            function wq_switch_nav(obj) {
                var data = obj.attr('data');
                if ($('#hotlist_' + data).length) {
                    switchover(obj, data);
                } else {
                    $.ajax({
                        type: 'POST',
                        url: obj.attr('href'),
                        data: {api: 1},
                        dataType: 'html'
                    }).success(function (s) {
                        $('.wqmore').before(s);
                        switchover(obj, data);
                        delayload();
                    });
                }
            }

            function switchover(obj, data) {
                $('#ct ul').hide();
                $('#my_group_tag li').attr('class', null);
                obj.parent().attr('class', 'a b_bule_bottom');
                var wq_title = $('#hotlist_' + data).attr('title');
                $('title').text(wq_title);
                if (!currentState) {
                    var param = obj.attr('href').split("?");
                    history.pushState({title: data}, wq_title, location.href.split("?")[0] + "?" + param[1]);
                }
                $('#hotlist_' + data).show();
                var obj = $('#ct ul:visible');
                var count = obj.attr('count'), perpage = obj.attr('perpage'), page = obj.attr('page'), data = obj.attr('data');
                if ($('#hotlist_' + data).find('.wqno_con').length) {
                    $(".wqloaded_all").hide();
                    $(".wqmore").hide();
                } else if (count / perpage <= page) {
                    $(".wqloaded_all").show();
                    $(".wqmore").hide();
                } else {
                    $(".wqloaded_all").hide();
                    $(".wqmore").show();
                }
            }
        }
        listStorage('portal', 'wqindex_list');
        delayload();
        var scroll_locked = true;
        $('html,body').css('min-height', '101%');

        $(window).on('scroll', throttle(function () {
            delayload();
            var obj = $('#ct ul:visible');
            var count = obj.attr('count');
            var perpage = obj.attr('perpage');
            var page = obj.attr('page');
            var data = obj.attr('data');
            if (scroll_locked && count / perpage > page && $(document).scrollTop() + wq_window_height > $(document).height() - 50) {
                $(".wqmore").show();
                scroll_locked = false;
                loadthread(page, data);
            } else if ($('#hotlist_' + data).find('.wqno_con').length) {
                $(".wqloaded_all").hide();
                $(".wqmore").hide();
            } else if (count / perpage <= page){
                $(".wqloaded_all").show();
                $(".wqmore").hide();
            }
        }, 300));

        function loadthread(page, data) {
            var portal_url = !'$_GET[formindex]' ? window.location.href : 'portal.php?';
            page++;
            $.ajax({
                url: portal_url,
                data: {api: 1, catid: data, page: page},
                dataType: 'html',
                success: function (s) {
                    $('#hotlist_' + data).append(s).attr('page', page);
                    scroll_locked = true;
                }
            });
        }
    });
</script>
<div class="pullrefresh" style="display:none;"></div>
<style>#wq_ad_show2{display:none};</style>
<!--{eval $footerSlide = 1;}-->
<!--{template common/footer}-->
<!--{/if}-->