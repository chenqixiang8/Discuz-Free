<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['view_fastpost'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<div id="post_new"></div>
<div class="wqcomment_input">
    <!--{if $article['allowcomment']}-->
         <div class="wqcomment_input_div z">
             <div class="wq_reply_eject notlogged" id="message_comment">
                  <i class="wqiconfont2 wqicon2-xiepinglun"></i>{lang send_reply_fast_tip}
             </div>
             <!--<input type="text" value="" autocomplete="off" id="message_comment" placeholder="{lang send_reply_fast_tip}" readonly='readonly'>-->
         </div>
    <!--{else}-->
        <div class="wqcomment_input_divno z">
            <div class="wq_reply_eject">
                {$Tlang['32cea4e8ec10eec5']}
            </div>
            <!--<input type="text" value="" autocomplete="off" placeholder="{$Tlang['32cea4e8ec10eec5']}"  readonly='readonly' >-->
       </div>
    <!--{/if}-->
    <div class="wqcomment_input_icon">
        <ul>
            <li><a class="scrollIntoView" href="javascript:;"><i class="wqiconfont2 wqicon2-pinglun2 wqapp_f22 wqicon_position"><span class="wqcomment_num"><!--{if $article[commentnum] > 0}-->$article[commentnum]<!--{else}-->0<!--{/if}--></span></i></a></li>
            <li class="wqcollection"><a href="home.php?mod=spacecp&ac=favorite&type=article&id=$article[aid]&handlekey=favoritearticlehk_{$article[aid]}" id="a_favorite" class="dialog notlogged">
                <!--{eval $flag = check_is_favorite($article[aid],'article');}-->
                <!--{if $flag && $_G['uid']}-->
                <i class="wqiconfont2 wqicon2-shoucang1 wqapp_f26 wqcolor_yellow wqicon_position"></i>
                <!--{else}-->
                <i class="wqiconfont2 wqicon2-shoucang1 wqapp_f26 wqicon_position"></i>
                <!--{/if}-->
                </a>
            </li>
            <li><a href="javascript:;" id="a_share"><i class="wqiconfont2 wqicon2-fenxiang01 wqapp_f24 wqshare wqview_share"></i></a></li>
        </ul>
    </div>
</div>
<script>
    $(function () {
        var intoView = scrollIntoView();
        $('.scrollIntoView').on('click', function () {
            intoView();
        }) ;
    });
</script>
<!--{if $article['allowcomment']}-->
<form  id="cform" name="cform" action="$form_url" method="post" autocomplete="off">
    <input type="hidden" name="formhash" value="{FORMHASH}">
    <input type="hidden" name="replysubmit" value="true">
    <input type="hidden" name="commentsubmit" value="true" />
    <!--{if !empty($topicid) }-->
    <input type="hidden" name="referer" value="$topicurl#comment" />
    <input type="hidden" name="topicid" value="$topicid">
    <!--{else}-->
    <input type="hidden" name="portal_referer" value="$viewurl#comment">
    <input type="hidden" name="referer" value="$viewurl#comment" />
    <input type="hidden" name="id" value="$data[id]" />
    <input type="hidden" name="idtype" value="$data[idtype]" />
    <input type="hidden" name="aid" value="$aid">
    <!--{/if}-->
    <!--{eval
        $headparams['wclass'] = 'wqheader wqbg_color new_lump';
        $headparams['wtype'] = '';
        $headparams['wextra'] = 'style="display:none; z-index: 12;"';

        $headparams['ltype'] = 'cancel';
        $headparams['lname'] = $Tlang['9c825be7149e5b97'];
        $headparams['lurl'] = 'javascript:void(0);';

	$headparams['ctype'] = 'span';
        $headparams['cname'] =$Tlang['dbedca5ca18ae5c8'];

        $headparams['rtype'] = 'but';
        $headparams['rname'] = $Tlang['c0e5b55d87a9643f'];
        $headparams['rclass'] = 'formdialog';
        $headparams['rid'] = 'postsubmit';
        $headparams['butname'] = 'ratesubmit';

        echo wq_app_get_header($headparams, false, true) ;
    }-->


    <div class="wqpost_list new_list" style="display:none;">
        <ul class="wqpost_list_ul">
            <li class="post_con wqnew_bottom">
                <textarea class="wqpost_textarea" id="needmessage" tabindex="3" autocomplete="off" name="message" rows="2" placeholder="{$Tlang['91efda220ced091e']}" fwin="reply" style="height: 120px;"></textarea>
            </li>
        </ul>
    </div>
</form>

<!--{if empty($_G[uid])}-->
<!--{eval $getlogin['mod']='logging';$getlogin['action']='login';$login_url = 'member.php?'.url_implode($getlogin);}-->
<script type="text/javascript">
    $(function () {
        $('#cform').click(function () {
            location.href = "$login_url";
        })
    });
</script>

<!--{/if}-->
<!--{/if}-->
<!--{/if}-->