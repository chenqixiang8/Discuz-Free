<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['portalcp_comment'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{template common/header}-->
<!--{if $_GET['op'] == 'edit'}-->
<form id="editcommentform_{$cid}" name="editcommentform_{$cid}" method="post" autocomplete="off" action="portal.php?mod=portalcp&ac=comment&op=edit&cid={$_GET[cid]}{if $_GET[modarticlecommentkey]}&modarticlecommentkey=$_GET[modarticlecommentkey]{/if}">
    <input type="hidden" name="referer" value="{echo dreferer()}"/>
    <input type="hidden" name="editsubmit" value="true" />
    <input type="hidden" name="editsubmit_btn" value="true" />
    <!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
    <input type="hidden" name="formhash" value="{FORMHASH}" />
    <input id="wq_postsubmit" type="button" class="formdialog" style="display: none">

    <!--{eval
        $headparams['wtype'] = '2';

        $headparams['ltype'] = 'cancel';
        $headparams['lname'] = $Tlang['9c825be7149e5b97'];
        $headparams['lurl'] = 'javascript:void(0);';

	$headparams['ctype'] = 'span';
        $headparams['cname'] =$Tlang['9a150d4af72d7358'];

        $headparams['rtype'] = 'but';
        $headparams['rname'] = "{lang submit}";
        $headparams['rid'] = 'postsubmit';
        $headparams['buttype'] = 'button';

        echo wq_app_get_header($headparams, false, true) ;
    }-->

    <div class="wqpost_list">
        <ul class="wqpost_list_ul">
            <li class="post_con wqnew_bottom">
                <textarea id="needmessage"  cols="70"   rows="8" class="wqpost_textarea" style=" height: 120px;">$comment[message]</textarea>
                <input type="hidden" id="wq_needmessage"  name="message">
            </li>
        </ul>
    </div>
</form>
<script>
    var message = $('#needmessage').val();

    message = message.replace(/\n?\[img\]\s*([^\[\<\r\n]+?)\s*\[\/img\]\n?/gi, function (match, capture) {
        wq_capture = $.trim(capture.replace('$_G[siteurl]', ''));
        var img = $('img[data="' + wq_capture + '"]').attr('dataid');
        if (img) {
            return  '[em:' + img + ':]';
        } else {
            return match.replace('amp;', '');
        }
    });

    $('#needmessage').val(message);

    function postsubmit_button() {
        $('#postsubmit').attr('disabled', ($.trim($('#needmessage').val()) ? null : 'disabled'));
    }

    $('#needmessage').on('keyup input', function () {
        postsubmit_button();
    });

    $('#postsubmit').on('click', function () {
        var needmessage = $('#needmessage').val();
        needmessage = needmessage.replace(/\[em:([0-9]+):\]/gi, function (match, capture) {
            var img = $('img[dataid="' + capture + '"]').attr('data');
            if (img) {
                return wq_capture = '[img]' + img + '[/img]';
            } else {
                return match;
            }
        });
        $('#wq_needmessage').val(needmessage);
        $('#wq_postsubmit').click();
    });

    function succeedhandle_editcommentform_{$cid}(url,) {
        clearTimeout(setTimeout_location);
        setTimeout(function () {
            location.replace(url);
        }, 1000)
    }
</script>
<!--{elseif $_GET['op'] == 'delete'}-->
<form id="deletecommentform_{$cid}" name="deletecommentform_{$cid}" method="post" autocomplete="off" action="portal.php?mod=portalcp&ac=comment&op=delete&cid=$cid">
    <input type="hidden" name="referer" value="{echo dreferer()}" />
    <input type="hidden" name="deletesubmit" value="true" />
    <input type="hidden" name="formhash" value="{FORMHASH}" />
    <!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
    <div class="c">{lang comment_delete_confirm}</div>
    <p class="o pns">
        <button type="submit" name="deletesubmitbtn" value="true" class="pn pnc"><strong>{lang confirms}</strong></button>
    </p>
</form>
<script>
    function succeedhandle_deletecommentform_{$cid}() {
        setTimeout_location = setTimeout(function() {
            history.go(0);
        }, 1500)
    }
</script>
<!--{/if}-->
<!--{template common/footer}-->
<!--{/if}-->