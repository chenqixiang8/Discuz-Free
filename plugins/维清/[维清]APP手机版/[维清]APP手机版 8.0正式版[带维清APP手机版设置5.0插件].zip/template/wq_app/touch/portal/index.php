<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['index'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{eval @include_once './source/plugin/wq_channel/index/wqchannel.php';}-->
<!--{if $_G['cache']['plugin']['wq_channel']}-->
    <!--{eval
        $pageid= DB::fetch_first("SELECT pageid FROM %t WHERE 1 ORDER BY `pageid` ASC",array("wq_channel_pages"));
        $url="plugin.php?id=wq_channel&mod=index&pageid=".$pageid['pageid'];
        $url=str_replace("&amp;","&",$url);
        header("location:".$url);
    }-->
<!--{/if}-->

<!--{eval //exit('channel is not find');}-->

<!--{eval include_once DISCUZ_ROOT.'./template/wq_app/php/config.php';}-->
<!--{eval loadcache(array('portalcategory','wq_app_setting_set'));$catids=$_G['cache']['wq_app_setting_set'];;}-->
<!--{if !$catids}-->
<!--{loop  $_G['cache']['portalcategory'] $key $val}-->
<!--{if $val[closed]}-->
<!--{eval continue;}-->
<!--{else}-->
<!--{eval $catids[]=$val['catid'];break;}-->
<!--{/if}-->
<!--{/loop}-->
<!--{/if}-->
<!--{eval $_GET['mod'] = 'list'; $_GET['catid'] = $_GET['catid'] ? $_GET['catid'] : $catids[0]; $_GET['formindex'] = '1'}-->
<!--{eval require_once libfile('portal/' . $_GET['mod'], 'module');}-->
<!--{/if}-->