<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['portalcp_article'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{template common/header}-->

<!--{if $op == 'delete'}-->

<h3 class="flb">
	<em>{lang article_delete}</em>
	<!--{if $_G[inajax]}--><span><a href="javascript:;" onclick="hideWindow('$_GET[handlekey]');" class="flbc" title="{lang close}">{lang close}</a></span><!--{/if}-->
</h3>

<form method="post" autocomplete="off" action="portal.php?mod=portalcp&ac=article&op=delete&aid=$_GET[aid]">
	<div class="c">
		<!--{if $_G['group']['allowpostarticlemod'] && $article['status'] == 1}-->
		{lang article_delete_sure}
		<input type="hidden" name="optype" value="0" class="pc" />
		<!--{else}-->
		<label class="lb"><input type="radio" name="optype" value="0" class="pc" />{lang article_delete_direct}</label>
		<label class="lb"><input type="radio" name="optype" value="1" class="pc" checked="checked" />{lang article_delete_recyclebin}</label>
		<!--{/if}-->
	</div>
	<p class="o pns">
		<button type="submit" name="btnsubmit" value="true" class="pn pnc"><strong>{lang confirms}</strong></button>
	</p>
	<input type="hidden" name="aid" value="$_GET[aid]" />
	<input type="hidden" name="referer" value="{echo dreferer()}" />
	<input type="hidden" name="deletesubmit" value="true" />
	<input type="hidden" name="formhash" value="{FORMHASH}" />
</form>
<!--{elseif $op == 'verify'}-->
<h3 class="flb">
	<em id="return_$_GET[handlekey]">{lang moderate_article}</em>
	<!--{if $_G[inajax]}--><span><a href="javascript:;" onclick="hideWindow('$_GET[handlekey]');" class="flbc" title="{lang close}">{lang close}</a></span><!--{/if}-->
</h3>

<form method="post" autocomplete="off" id="aritcle_verify_$aid" action="portal.php?mod=portalcp&ac=article&op=verify&aid=$aid">
	<div class="c">
		<label for="status_0" class="lb"><input type="radio" class="pr" name="status" value="0" id="status_0"{if $article[status]=='1'} checked="checked"{/if} />{lang passed}</label>
		<label for="status_x" class="lb"><input type="radio" class="pr" name="status" value="-1" id="status_x" />{lang delete}</label>
		<label for="status_2" class="lb"><input type="radio" class="pr" name="status" value="2" id="status_2"{if $article[status]=='2'} checked="checked"{/if} />{lang ignore}</label>
	</div>
	<p class="o pns">
		<button type="submit" name="btnsubmit" value="true" class="pn pnc"><strong>{lang confirms}</strong></button>
	</p>
	<input type="hidden" name="aid" value="$aid" />
	<input type="hidden" name="referer" value="{echo dreferer()}" />
	<input type="hidden" name="handlekey" value="$_GET['handlekey']" />
	<input type="hidden" name="verifysubmit" value="true" />
	<input type="hidden" name="formhash" value="{FORMHASH}" />
</form>
<!--{elseif $op == 'related'}-->
    <!--{if $ra}-->
    <li id="raid_li_$ra[aid]"><input type="hidden" name="raids[]" value="$ra[aid]" size="5">[ $ra[aid] ] <a href="{echo fetch_article_url($ra);}" target="_blank">$ra[title]</a> <a href="javascript:;" onclick="raid_delete($ra[aid]);">{lang delete}</a></li>
    <!--{/if}-->
<!--{elseif $op == 'pushplus'}-->
<h3 class="flb">
	<em>{lang article_pushplus}</em>
	<!--{if $_G[inajax]}--><span><a href="javascript:;" onclick="hideWindow('$_GET[handlekey]');" class="flbc" title="{lang close}">{lang close}</a></span><!--{/if}-->
</h3>
<form method="post" target="_blank" action="portal.php?mod=portalcp&ac=article&tid=$tid&aid=$aid">
	<div class="c">
		<b>$pushcount</b> {lang portalcp_article_message1}<a href="$article_url" target="_blank" class="xi2">({lang view_article})</a>
		<!--{if $pushedcount}--><br />{lang portalcp_article_message2}<!--{/if}-->
		<div id="pushplus_list">
		<!--{loop $pids $pid}-->
		<input type="hidden" name="pushpluspids[]" value="$pid" />
		<!--{/loop}-->
		</div>
	</div>
	<p class="o pns">
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<input type="hidden" name="pushplussubmit" value="1" />

		<input type="hidden" name="toedit" value="1" />
		<button type="submit" class="pn pnc vm"><span>{lang submit}</span></button>
	</p>
</form>
<!--{elseif $op == 'add_success' && $_GET['inajax'] == '1'}-->
    <div class="wqtip">
        <dt id="messagetext">
            <script type="text/javascript"  reload="1">
                setTimeout_location = setTimeout(function () {
                    location.href = 'portal.php?mod=view&aid=$aid';
                }, '1000');
            </script>
            {lang article_send_succeed}
        </dt>
    </div>
<!--{elseif $op == 'add_success'}-->
<div class="nfl">
	<div class="f_c altw">
		<div class="alert_right">
			<p>{lang article_send_succeed}</p>
			<p class="alert_btnleft">
				<a href="{$article_add_url}&op=edit&aid=$aid">{lang article_edit}</a>
				<span class="pipe">|</span>
				<a href="$article_add_url">{lang article_send_continue}</a>
				<span class="pipe">|</span>
				<a href="portal.php?mod=view&aid=$aid" target="_blank">{lang view_article}</a>
				<!--{if $htmlstatus}-->
					<span class="pipe">|</span>
					<span id='makehtml_' mktitle="{lang article}"></span>
				<!--{/if}-->
			</p>
		</div>
	</div>
</div>
<script src="{STATICURL}js/makehtml.js" type="text/javascript"></script>
<script type="text/javascript">
<!--{if !empty($_G['cookie']['clearUserdata']) && $_G['cookie']['clearUserdata'] == 'home'}-->
	saveUserdata('home', '');
<!--{/if}-->
make_html('portal.php?mod=view&aid={$aid}', $('makehtml_'));
</script>
<!--{else}-->
<form method="post" autocomplete="off" id="articleform" action="portal.php?mod=portalcp&ac=article" enctype="multipart/form-data">
    <input type="hidden" id="color_style" class="pn colorwd" title="{lang select_color}" fwin="eleStyle" onclick="change_title_color(this.id);" style="background-color:$stylecheck[0]" />
    <input type="hidden" id="highlight_style_0" name="highlight_style[0]" value="$stylecheck[0]" />
    <input type="hidden" id="highlight_style_1" name="highlight_style[1]" value="$stylecheck[1]" />
    <input type="hidden" id="highlight_style_2" name="highlight_style[2]" value="$stylecheck[2]" />
    <input type="hidden" id="highlight_style_3" name="highlight_style[3]" value="$stylecheck[3]" />
    <input type="hidden" id="conver" name="conver" value="" />
    <input type="hidden" id="aid" name="aid" value="$article[aid]" />
    <input type="hidden" name="cid" value="$article_content[cid]" />
    <input type="hidden" id="attach_ids" name="attach_ids" value="0" />
    <input type="hidden" name="articlesubmit" value="true" />
    <input type="hidden" name="formhash" value="{FORMHASH}" />
    <input type="hidden" name="id" value="$_GET[from_id]" />
    <input type="hidden" name="idtype" value="$_GET[from_idtype]" />


     <!--{if !empty($aid)}-->
     <!--{eval  $headparams['cname'] = "{lang article_edit}";}-->
    <!--{else}-->
        <!--{if $_GET['ac'] == 'article'&&  $_GET['from_id']>0}-->
            <!--{eval  $headparams['cname'] = $Tlang['cf65fa8ea7af58d9'];}-->
        <!--{else}-->
            <!--{eval  $headparams['cname'] = "{lang article_publish}";}-->
        <!--{/if}-->
    <!--{/if}-->

    <!--{eval
        $headparams['wtype'] = '2';

        $headparams['ltype'] = 'cancel';
        $headparams['lname'] = '<i class="wqiconfont2 wqicon2-fanhui-copy-copy wqapp_f22"></i>';
        $headparams['lurl'] = 'javascript:void(0);';

	$headparams['ctype'] = 'span';

        echo wq_app_get_header($headparams, false) ;
    }-->

    <div class="wqpost_list">
        <ul class="wqpost_list_ul">
            <li class="wqnew_bottom">
                <input type="text" class="wqpost_input" id="title" value="$article[title]" name="title" placeholder="{$Tlang['0b3d6ba0ad26e11e']}" />
            </li>
            <li class="wqnew_bottom" id="htmlname_"{if !$htmlstatus} style="display: none"{/if}>
                <input type="text" name="htmlname" id="htmlname" class="wqpost_input" value="$article[htmlname]"  placeholder="{$Tlang['d0effcc422101ca9']}" size="80" onblur="check_htmlname_exists(this)" />.{$_G['setting']['makehtml']['extendname']}
                <input type="hidden" name="oldhtmlname" id="oldhtmlname" value="$article[htmlname]" placeholder="{$Tlang['272e4a5433775dc4']}" />
            </li>
            <li class="wqnew_bottom" id="pagetitle" {if $article[contents] < 2} style="display: none"{/if}>
                <input type="text" name="pagetitle" id="pagetitle" class="wqpost_input" value="$article_content[title]" size="80" />
            </li>
            <!--{if $_G['cache']['portalcategory'] && $categoryselect}-->
            <li class="a_select wqnew_bottom">$categoryselect</li>
            <!--{/if}-->
            <li class="wqnew_bottom">
                <input type="text" class="wqpost_input" id="from" name="from" value="$article[from]" placeholder="{$Tlang['2d485e68c1b6af50']}" />
            </li>
            <!--{if $from_cookie}-->
            <li class="wqnew_bottom">
                <select name="from_cookie" id="from_cookie" onchange="$('#from').val(this.value);" class="wqpost_select">
                    <option value="" selected>{$Tlang['5f2b5a269d057dfb']}</option>
                    <!--{loop $from_cookie $var}-->
                    <option value="$var">$var</option>
                    <!--{/loop}-->
                </select>
            </li>
            <!--{/if}-->
            <li class="wqnew_bottom">
                <input type="text" class="wqpost_input" id="fromurl" value="$article[fromurl]" name="fromurl" placeholder="{$Tlang['bf2630a689dcc0cc']}" />
            </li>
            <li class="wqnew_bottom">
                <input type="text" class="wqpost_input muidate" id="dateline" value="$article[dateline]" name="dateline" placeholder="{$Tlang['e5d945ff5448fd01']}" />
            </li>
            <li class="wqnew_bottom">
                <input type="text" class="wqpost_input" id="url" value="$article[url]" name="url" placeholder="{$Tlang['0d86440afd0216cc']}" />
            </li>
            <li class="wqnew_bottom">
                <input type="text" class="wqpost_input" id="author" value="$article[author]" name="author" placeholder="{$Tlang['82f2c2a3f9821c1d']}" />
            </li>
            <li class="wqnew_bottom">
                <p class="wq_grey2">{lang article_tag}</p>
                <p class="wq_grey2">
                    <!--{loop $article_tags $key $tag}-->
                    <span class="wqm_right10">
                        <input type="checkbox" name="tag[$key]" id="article_tag_$key" class="weui_check"{if $article_tags[$key]} checked="checked"{/if} />
                        <label for="article_tag_$key" class="lb"><i class="weui_icon_checked"></i>$tag_names[$key]</label>
                    </span>
                    <!--{/loop}-->
                </p>
            </li>
            <!--{if $category[$catid][allowcomment]}-->
            <li class="wqnew_bottom">
                <p class="wq_grey2">
                    <input type="checkbox" class="weui_check" name="forbidcomment" id="ck_allowcomment" value="1"{if isset($article['allowcomment']) && empty($article['allowcomment'])}checked="checked"{/if} />
                    <label for="ck_allowcomment"><i class="weui_icon_checked"></i>{lang article_forbidcomment_description}</label>
                </p>
            </li>
            <!--{/if}-->
            <li class="post_con wqnew_bottom">
                <textarea id="needmessage" name="summary" placeholder="{$Tlang['a37b42046171061d']}" class="wqpost_textarea">$article[summary]</textarea>
            </li>
            <li class="post_con wqnew_bottom">
                <textarea id="uchome-ttHtmlEditor" name="content" value="" style="display: none;">{$article_content[content]}</textarea>
                <div class="wqeditarea" contenteditable="true" placeholder="{$Tlang['70ad0bcbf2229f1d']}">
                <!--{eval echo htmlspecialchars_decode($article_content[content], ENT_QUOTES);}-->
                </div>
                <div class="wqpost_upload">
                    <span class="wqiconfont2 wqicon2-biaoqing wqapp_f26 wqbiaoqing"></span>
                    <a href="javascript:;" class="wqiconfont2 wqicon2-tupian3 wqapp_f26">
                        <input type="button" id="file_button"  class="wqfiledata">
                        <input type="file" name="Filedata" id="filedata" multiple="multiple" style="display: none;" accept="image/*" />
                        <i class="wqtoday" style="display: none">0</i>
                    </a>
                </div>
            </li>
        </ul>
        <!--{template common/upload_image}-->
        <!--{template common/smilies}-->
        <!--{template common/simple_editor}-->
        <div class="wqpost_publish"><button class="formdialog wqpublish wqbg_color">{lang save}</button></div>
    </div>
    <!--{if $secqaacheck || $seccodecheck}-->
        <!--{block sectpl}--><sec> <span id="sec<hash>" onclick="showMenu(this.id)"><sec></span><div id="sec<hash>_menu" class="p_pop p_opt" style="display:none"><sec></div><!--{/block}-->
        <div class="exfm pns"><!--{subtemplate common/seccheck}--></div>
    <!--{/if}-->
</form>
<script type="text/javascript">
    $(function () {
        $('.wqeditarea').wqEditor({
            selector: '#uchome-ttHtmlEditor',
            editor: '.wqeditarea',
            bbcodeMode: false,
            placeholder: "{$Tlang['70ad0bcbf2229f1d']}",
            imglist: '#imglist',
            isInput: '',
            subButton: '#issuance'
        });
        $('.wqeditarea').on('touchmove', function (event) {
            event.stopImmediatePropagation();
        });
        upload_image = function (data) {
            if (data == '') {
                popup.open('{lang uploadpicfailed}', 'alert');
            }
            var dataarr = data.split('|');
            if (dataarr[0] == 'DISCUZUPLOAD' && dataarr[2] == 0) {
                popup.close();
                if ($('#imglist').is(':hidden')) {
                    $('.cellphone_expression').hide();
                    $('.wqexpression').removeClass('c_jianpan').removeClass('wqicon-jianpan');
                    $('#imglist').show();
                    $('#upload_icon').addClass('blue');
                }
                $('#imglist').prepend('<li><span aid="' + dataarr[3] + '" class="del"><a href="javascript:;">\n\
                    <i class="wqiconfont2 wqicon2-delete f22 wq_del"></i></a></span><span class="p_img"><a href="javascript:;"><img id="aimg_' + dataarr[3] + '" title="' + dataarr[6] + '" src="{$_G[setting][attachurl]}forum/' + dataarr[5] + '" /></a></span><input type="hidden" name="attachnew[' + dataarr[3] + '][description]" /></li>');
                $('.today_p').show().text($('#imglist li').length - 1);
                $('#filedata').val('');
            } else {
                var sizelimit = '';
                if (dataarr[7] == 'ban') {
                    sizelimit = '{lang uploadpicatttypeban}';
                } else if (dataarr[7] == 'perday') {
                    sizelimit = '{lang donotcross}' + Math.ceil(dataarr[8] / 1024) + 'K)';
                } else if (dataarr[7] > 0) {
                    sizelimit = '{lang donotcross}' + Math.ceil(dataarr[7] / 1024) + 'K)';
                }
                popup.open(STATUSMSG[dataarr[2]] + sizelimit, 'alert');
            }
        };
        $('.wqbiaoqing').on('click', function () {
            $(this).toggleClass('wqicon2-jianpan');
            if ($('.cellphone_expression').is(':hidden')) {
                $('#imglist').hide();
                $('.cellphone_expression').show();
                $('#upload_icon').removeClass('blue');
                $('.wqbiaoqing').removeClass('wqicon2-biaoqing');
                expression_viwepager();
            } else {
                $('.cellphone_expression').hide();
                $('.wqbiaoqing').addClass('wqicon2-biaoqing');
            }
        });
    });
</script>
<!--{/if}-->
<!--{eval $nofooter=1;}-->
<!--{template common/footer}-->

<!--{/if}-->