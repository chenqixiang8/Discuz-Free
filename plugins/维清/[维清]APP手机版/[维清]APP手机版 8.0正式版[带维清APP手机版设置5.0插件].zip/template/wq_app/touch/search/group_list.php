<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['group_list'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{eval
    $touch_tplid = $_G['setting']['styleid2'];
    loadcache('style_' . $touch_tplid);
    $touch_tpl = $_G['cache']['style_' . $touch_tplid];
    include DISCUZ_ROOT.$touch_tpl['tpldir'].'/php/config.php';
}-->
<!--{if $page==1}-->
<div id="wq_search_list_children" page='$page' searchid='$searchid' perpage='$_G[tpp]' {if empty($viewgroup)}action='thread' count='$index[num]'{else}action='group' count='$groupnum'{/if}   >
     <!--{/if}-->
     <!--{if empty($grouplist)&&$page==1}-->
     <div class="groupsearch_list" >
		 <h3 class="grouptitle">{$Tlang['buluo']}</h3>
		 <div class="support_idea search_support_idea">
        <a href="#">
            <!--class="dialog"-->
            <div class="apply_group_icon"><i class="wqiconfont wqicon-yuanjiahao apply_group search_group_jh"></i></div>
            <a href="forum.php?mod=group&action=create&name=$keyword"> <div class="apply_group_txt search_group_txt">{$Tlang['apply_buluo']}"{$keyword}"{$Tlang['buluo']}</div></a>
        </a>
		</div>
    </div>
    <!--{else}-->
    <!--{if $page==1}-->
    <div class="groupsearch_list" >
        <h3 class="grouptitle">{$Tlang['buluo']}</h3>
        <ul id="wq_group">
            <!--{/if}-->
            <!--{if (!$viewgroup &&  $page==1)||$viewgroup  }-->
            <!--{loop $grouplist $group}-->
            <li class="b_bottom">
                <a href="forum.php?mod=group&fid=$group[fid]">
                    <div>
                        <div class="left_pic">
                            <div class="delayload_div">
                                <img src="$group[icon]" style="display: inline; visibility: visible;">
                            </div>
                        </div>
                        <div class="h_over">
                            <h3 class="title">$group[name]</h3>
                            <div class="title_con">$group[description]</div>
                        </div>
                        <p class="by disuser_nick"><span class="m_r10">{$Tlang['member']}{$group[membernum]}</span>{$Tlang['huati']}{$group[threads]} </p>
                    </div>
                </a>
            </li>
            <!--{/loop}-->
            <!--{/if}-->
            <!--{if $page==1}-->
        </ul>
        <!--{if empty($viewgroup)&&$groupnum>8}-->
        <a id="wq_all_viewgroup" href="search.php?mod=group&searchid=$searchid&orderby=$orderby&ascdesc=$ascdesc&searchsubmit=yes&viewgroup=1" ><p class="more_relevant">{$Tlang['more_buluo']}<i class="wqiconfont wqicon-youyou y"></i></p></a>
        <!--{/if}-->
    </div>
    <!--{/if}-->
    <!--{/if}-->

    <!--{if !empty($threadlist)}-->
    <!--{if $page==1}-->
    <div class="groupsearch_ht" >
        <h3 class="grouptitle">{$Tlang['huati']}</h3>
        <ul id="wq_thread">
            <!--{/if}-->
            <!--{eval
                $touch_tplid = $_G['setting']['styleid2'];
                loadcache('style_' . $touch_tplid);
                $touch_tpl = $_G['cache']['style_' . $touch_tplid];
                include DISCUZ_ROOT.$touch_tpl['tpldir'].'/php/config.php';
                $data=_buluo_get_data($threadlist);
            }-->
            <!--{loop $threadlist $thread}-->
            <li class="b_bottom">
                <a href="forum.php?mod=viewthread&tid=$thread[tid]&highlight=$index[keywords]">
                    <div>
                        <!--{if $data[images][$thread[tid]][image]}-->
                        <div class="right_pic">
                            <div class="delayload_div"><img class="wq_js_delayload" data="$data[images][$thread[tid]][image]" style="display: inline; visibility: visible;"></div>
                        </div>
                        <!--{/if}-->

                        <div class="h_over">
                            <h3 class="title" $thread[highlight]>$thread[subject]</h3>
                            <div class="title_con">$thread[message]</div>
                        </div>
                        <p class="by disuser_nick"><b>$thread[forumname]</b>
                            <span class="y browse_record"><i class="wqiconfont wqicon-massage c_grey m_r2"></i>$thread[replies]</span>
                            <span class="num y"><i class="wqiconfont wqicon-liulan f14 c_grey m_r2 m_tf2"></i>$thread[views]</span>
                        </p>
                    </div>
                </a>
            </li>
            <!--{/loop}-->
            <!--{if $page==1}-->
        </ul>
    </div>
    <!--{/if}-->
    <!--{/if}-->
    <!--{if $page==1}-->
</div>
<!--{/if}-->
<!--{/if}-->