<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['pubsearch'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{if !empty($srchtype)}--><input type="hidden" name="srchtype" value="$srchtype" /><!--{/if}-->
<!--{eval
    $headparams['wtype'] = '1';
    $headparams['lurl'] = $backurl;
    $headparams['ltype'] = 'a';
    $headparams['cname'] = $Tlang['38224a4a6fc78c7c'];
    echo wq_app_get_header($headparams);
}-->

<!--<div class="wqsearch_warp wqnew_bottom">
    <div class="wqsearch_warp_div">
        <div class="wqsearch_warp_input z">
            <span class="wqsearch_return"><a href="{$backurl}"><i class="wqiconfont2 wqicon2-fanhui-copy-copy wqapp_f22"></i></a></span>
            <span class="wqsearch_switch">
                <a href = "javascript:void(0)" onclick = "document.getElementById('wqsearch_eject').style.display='block';"><span>{if $_GET['mod'] == 'forum'}{$Tlang['3dc487520005b6c7']}{/if}{if $_GET['mod'] == 'portal'}{$Tlang['ad4a637929cd4720']}{/if}</span><i class="wqiconfont2 wqicon2-control-arr"></i></a>
            </span>
            <div class="wqsearch_eject" id="wqsearch_eject"  style="display: none;">
                <span class="wqsearch_eject_arrow"></span>
                <ul>
                    <li><a href="search.php?mod=forum"><i class="wqiconfont2 wqicon2-tiezisousuo wqapp_f20"></i>{$Tlang['3dc487520005b6c7']}</a></li>
                    <li><a href="search.php?mod=portal"><i class="wqiconfont2 wqicon2-shuji wqapp_f20"></i>{$Tlang['ad4a637929cd4720']}</a></li>
                </ul>
            </div>
            <span class="wqsearch_input2">
                <input value="$keyword" autocomplete="off" name="srchtxt" id="scform_srchtxt" value="" placeholder="{$Tlang['84b323e823c2664d']}">
            </span>
        </div>
        <div class="wqsearch_list_btn y">
            <input type="hidden" name="searchsubmit" value="yes">
            <button  type="submit" class="wqbg_color wqborder"id="scform_submit">{lang search}</button></div></div>
</div>-->
<style>body{ background: #f9f9f9;}</style>
<!--<div class="wqheight44"></div>-->
<div class="wqapp_search_warp">
    <div class="wqapp_search">
        <div class="wqapp_switch">
            <span>
                <a class="wqsearch-switch" href="javascript:;">
                    <!--{if CURMODULE == 'forum'}-->
                        {$Tlang['3dc487520005b6c7']}
                    <!--{elseif CURMODULE=='group'}-->
                        {$_G['setting']['navs'][3]['navname']}
                    <!--{elseif CURMODULE=='album'}-->
                        {lang album}
                    <!--{elseif CURMODULE=='blog'}-->
                        {lang blog}
                    <!--{elseif CURMODULE=='portal'}-->
                        {$Tlang['ad4a637929cd4720']}
                    <!--{/if}-->
                    <span class="wq_arrow"><i class="wqiconfont2 wqicon2-down_1 wqapp_f14"></i></span>
                </a>
            </span>
            <div class="wqsearch_choice" id="wqsearch-choice" style="display: none;">
                <ul>
                    <!--{eval $keywordenc = $keyword ? rawurlencode($keyword) : '';}-->
                    <!--{if $_G['setting']['search']['forum']['status'] && ($_G['group']['allowsearch'] & 2 || $_G['adminid'] == 1)}-->
                        <li><a href="search.php?mod=forum{if $keyword}&srchtxt=$keywordenc&searchsubmit=yes{/if}">{$Tlang['3dc487520005b6c7']}</a></li>
                    <!--{/if}-->
                    <!--{if $_G['setting']['portalstatus'] && $_G['setting']['search']['portal']['status'] && ($_G['group']['allowsearch'] & 1 || $_G['adminid'] == 1)}-->
                        <li><a href="search.php?mod=portal{if $keyword}&srchtxt=$keywordenc&searchsubmit=yes{/if}">{$Tlang['ad4a637929cd4720']}</a></li>
                    <!--{/if}-->
                    <!--{if $_G['setting']['groupstatus'] && $_G['setting']['search']['group']['status'] && ($_G['group']['allowsearch'] & 16 || $_G['adminid'] == 1)}-->
                        <li><a href="search.php?mod=group">{$_G['setting']['navs'][3]['navname']}</a></li>
                    <!--{/if}-->
                    <!--{if helper_access::check_module('album') && $_G['setting']['search']['album']['status'] && ($_G['group']['allowsearch'] & 8 || $_G['adminid'] == 1) && helper_access::check_module('album')}-->
                        <li><a href="search.php?mod=album{if $keyword}&srchtxt=$keywordenc&searchsubmit=yes{/if}">{lang album}</a></li>
                    <!--{/if}-->
                    <!--{if helper_access::check_module('blog') && $_G['setting']['search']['blog']['status'] && ($_G['group']['allowsearch'] & 4 || $_G['adminid'] == 1) && helper_access::check_module('blog')}-->
                        <li><a href="search.php?mod=blog{if $keyword}&srchtxt=$keywordenc&searchsubmit=yes{/if}">{lang blog}</a></li>
                    <!--{/if}-->
                </ul>
            </div>
        </div>
        <div class="wqsearch_input"><input value="$keyword" autocomplete="off" name="srchtxt" id="scform_srchtxt" placeholder="{$Tlang['84b323e823c2664d']}"><i class="wqiconfont2 wqicon2-guanbi1 wqsearch_close" style="display: none;"></i></div>
        <div class="wqsearch_list_btn y">
            <input type="hidden" name="searchsubmit" value="yes">
            <button  type="submit" id="scform_submit">{lang search}</button>
        </div>
    </div>
</div>
<!--{if empty($_GET['searchid'])}-->
<!--{eval $searchs=unserialize(getcookie("search_" . $_G['uid']));}-->

<!--{if !empty($searchs)}-->
    <div class="wqsearch_keyword wqsearch-history">
        <h3>{$Tlang['6ea227332d193cbd']}<span class="y"><a href="javascript:;" class="wqhistory_delete">{$Tlang['3930101d085b7f09']}</a></span></h3>
        <ul>
            <!--{loop $searchs $key $val}-->
                <!--{eval $srchtxt=rawurlencode($val);$bgcolor=wq_app_setting_set_search_and_label_bgcolor();}-->
                <li style="background-color: {$bgcolor}"><a href="search.php?mod={$_GET['mod']}&srchtxt={$srchtxt}&formhash={FORMHASH}&searchsubmit=true&source=hotsearch">$val</a></li>
            <!--{/loop}-->
        </ul>
    </div>
<!--{/if}-->
<div class="wqsearch_keyword">
    <!--{if $_G['setting']['srchhotkeywords']}-->
    <h3>{lang hot_search}</h3>
    <ul>
        <!--{loop $_G['setting']['srchhotkeywords'] $val}-->
        <!--{eval $bgcolor=wq_app_setting_set_search_and_label_bgcolor();}-->
            <!--{if $val=trim($val)}-->
                <!--{eval $valenc=rawurlencode($val);}-->
                <!--{block srchhotkeywords[]}-->
                    <!--{if !empty($searchparams[url])}-->
                        <li style="background-color: {$bgcolor}"><a href="$searchparams[url]?q=$valenc&source=hotsearch{$srchotquery}" class="xi2 b_all" sc="1">$val</a></li>
                    <!--{else}-->
                        <li style="background-color: {$bgcolor}"><a href="search.php?mod={$_GET['mod']}&srchtxt=$valenc&formhash={FORMHASH}&searchsubmit=true&source=hotsearch" class="xi2 b_all" sc="1">$val</a></li>
                    <!--{/if}-->
                <!--{/block}-->
            <!--{/if}-->
        <!--{/loop}-->
        <!--{echo implode('', $srchhotkeywords);}-->
    </ul>
    <!--{/if}-->
</div>
<!--{/if}-->
<script>
    $('#scform_srchtxt').val().length ? $('.wqsearch_close').css('display', 'inline') : $('.wqsearch_close').hide();
    $(function () {
        $(document).on('click', function () {
            $('#wqsearch-choice').hide();
        });

        $('.wqsearch-switch').on('click', function (e) {
            var menu = $('#wqsearch-choice');
            if (menu.is(':hidden')) {
                menu.show();
                $(document).one('scroll', function () {
                    menu.hide();
                });
            } else {
                menu.hide();
            }
            e.stopPropagation();
        });

        $('.wqsearch_close').on('touchend', function () {
            $('#scform_srchtxt').val('');
            $(this).hide();
        });

        $('#scform_srchtxt').on('input', function () {
            $('#scform_srchtxt').val().length ? $('.wqsearch_close').css('display', 'inline') : $('.wqsearch_close').hide();
        });

        $('.wqhistory_delete').on('touchend', function () {
            $.ajax({
                url: 'plugin.php?id=wq_app_setting&mod=ajax',
                data: {ac:'wqhistory_delete',formhash:"{FORMHASH}",inajax:1},
                type: 'GET',
                dataType: 'html',
                success: function (s) {
                    popup.open(wqXml(s));
                    $('.wqsearch-history').remove();
                }
            });
        });
    });
</script>


<!--{/if}-->