<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['album_list'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<div class="tl">
	<div class="wqsearch_result wqnew_bottom">
		<h2><!--{if $keyword}-->{lang search_result_keyword}<!--{else}-->{lang search_result}<!--{/if}--></h2>
	</div>
	<!--{ad/search/y mtw}-->
	<!--{if empty($albumlist)}-->
		<p class="wqemp"><span class="wqno_con"><img src="{$_G['style']['styleimgdir']}images/wqno_con.png"></span>{lang search_nomatch}</p>
	<!--{else}-->
		<div class="ptw album_list clearfixed">
			<ul class="ml mla cl">
				<!--{loop $albumlist $key $value}-->
                                            <li class="wqnew_all">
                                                <a href="home.php?mod=space&uid=$value[uid]&do=album&id=$value[albumid]">
                                                    <div class="c">
                                                        <!--{if $value[pic]}--><img src="$value[pic]" /><!--{/if}-->
                                                    </div>
                                                    <div class="ptn">
                                                        <em class="width100">$value[albumname]</em>
                                                        <span> <!--{if $value[picnum]}-->
                                                            $value[picnum]
                                                            <!--{/if}--></span>
                                                    </div>
                                                </a>
                                            </li>
				<!--{/loop}-->
			</ul>
		</div>
		<!--{if !empty($multipage)}--><div class="pgs cl mbm">$multipage</div><!--{/if}-->
	<!--{/if}-->
</div>

<!--{/if}-->