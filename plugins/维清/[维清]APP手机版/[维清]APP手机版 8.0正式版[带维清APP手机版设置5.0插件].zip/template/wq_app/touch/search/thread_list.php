<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['thread_list'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
 <div class="wqsearch_result wqnew_bottom">
        <!--{if $keyword}-->{lang search_result_keyword} <!--{if $modfid}-->
        <a href="forum.php?mod=modcp&action=thread&fid=$modfid&keywords=$modkeyword&submit=true&do=search&page=$page">{lang goto_memcp}</a>
        <!--{/if}--><!--{else}-->{lang search_result}<!--{/if}-->
 </div>
<div class="wqsearch_list">
    <!--{if empty($threadlist)}-->
    <p class="wqemp"><span class="wqno_con"><img src="{$_G['style'][styleimgdir]}images/wqno_con.png"></span>{lang search_nomatch}</p>
    <!--{else}-->
    <ul class="wqsearch_list_ul">
        <!--{eval
            $tids = get_wq_app_tids($threadlist);
            $threadlists= wq_app_get_thread_info_from_cache($tids);
        }-->

        <!--{loop $threadlist $thread}-->
            <!--{eval
                $imagenum = $threadlists[$thread['tid']]['imagenum'];
                $imagenum = $threadlists[$thread['tid']]['imagenum'];
                $images= $imagenum > 0 ? wq_app_setting_get_pic($threadlists[$thread['tid']]['maximgs'],$threadlists[$thread['tid']]['images'],1,1) : array();
            }-->
        <li class="wqnew_bottom">
            <a href="forum.php?mod=viewthread&tid=$thread[realtid]&highlight=$index[keywords]"class="wqblock">
                <!--{if $imagenum > 0}-->
                    <div class="wqlist1 wq-lazyload-container">
                        <!--{loop $images $k $v}-->
                         <img class="wq_js_delayload tn" src="{$_G['style'][styleimgdir]}images/wq_dian.jpg" data-src="{$v}">
                        <!--{/loop}-->
                        <!--{if $imagenum > 1}-->
                        <span class="wqlisttu1"><i class="wqiconfont2 wqicon2-tupian-copy wqapp_f14 wqm_right2"></i>{$imagenum}</span>
                        <!--{/if}-->
                    </div>
                <!--{/if}-->
                <div class="<!--{if $imagenum > 0}--> wqsearch_hidden<!--{else}--> wqsearch_maxhidden<!--{/if}-->">
                    <h3 class="wqtitle_list">$thread['subject']</h3>
                </div>
                <p class="list_info">
                    <span class="wqwidth80"><!--{if $thread['authorid'] && $thread['author']}-->$thread[author]<!--{else}-->{lang anonymous}<!--{/if}--></span>
                    <span class="y"><i class="wqiconfont2 wqicon2-pinglun2 wqapp_f12"></i>$thread[replies]</span>
                    <span class="y wqm_right10"><!--{eval echo wq_app_dgmdate($thread[dateline]);}--></span>
                </p>
            </a>
        </li>
        <!--{/loop}-->
    </ul>
    <!--{/if}-->
</div>
$multipage

<!--{/if}-->