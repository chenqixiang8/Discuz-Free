<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['portal_list'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<div class="wqsearch_result wqnew_bottom"><!--{if $keyword}-->{lang search_result_keyword}<!--{else}-->{lang search_result}<!--{/if}--></div>
<div class="wqsearch_list">

	<!--{ad/search/y mtw}-->
	<!--{if empty($articlelist)}-->
        <p class="wqemp"><span class="wqno_con"><img src="{$_G['style'][styleimgdir]}images/wqno_con.png"></span>{lang search_nomatch}</p>
	<!--{else}-->
        <ul class="wqsearch_list_ul">
			<!--{loop $articlelist $article}-->
                         <li class="wqnew_bottom">
                             <a href="{echo fetch_article_url($article);}">
                                  <!--{if $article[pic]}-->
                <div class="wqlist1 wq-lazyload-container">
                    <img  src="$_G['style'][styleimgdir]images/wq_dian.jpg" data-src="$article[pic]" alt="$article[subject]" class="tn wq_js_delayload" />
                </div>
                <!--{/if}-->
                        <div class="<!--{if $article[pic]}--> wqsearch_hidden<!--{else}--> wqsearch_maxhidden<!--{/if}-->">
                         <h3 class="wqtitle_list">$article[title]</h3>
                        </div>
                        <p class="list_info"><span class="wqwidth80">$article[username]</span>
                        <span class="y"><i class="wqiconfont2 wqicon2-pinglun2 wqapp_f12"></i>$article[commentnum]</span>
                        <span class="y wqm_right10"><!--{eval echo wq_app_dgmdate($thread[dateline]);}--></span>
                        </p>
                        </a>

			</li>
			<!--{/loop}-->
		</ul>
	<!--{/if}-->
	<!--{if !empty($multipage)}--><div class="pgs cl mbm">$multipage</div><!--{/if}-->
</div>
<!--{/if}-->