<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['group'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<!--{if !empty($searchid)}-->

<!--{subtemplate search/group_list}-->
<!--{eval exit;}-->
<!--{/if}-->

<!--{eval $plugin_wq_buluo = !empty($_G['cache']['plugin']['wq_buluo']) ? 1 : 0;}-->
<!--{if $plugin_wq_buluo}-->
    <!--{eval
        $wq_buluo=$_G['cache']['plugin']['wq_buluo'];
        $wq_buluo[mobile_header]=intval($wq_buluo[mobile_header]);
    }-->
    <!--{if $wq_buluo[mobile_header]!=1}--> <!--{eval $header_nav='null';}--> <!--{/if}-->
<!--{/if}-->

<!--{template common/wq_buluo_tpl_header}-->

<div  class="qz_bg">
    <div class="groupsearch_page">
        <div class="groupsearch_box">
            <form id="wq_searchform" class="searchform" method="post" autocomplete="off"  action="search.php?mod=group">
                <input type="hidden" name="formhash" value="{FORMHASH}" />
                <input type="hidden" id="wq_searchid" name="searchid" value="$searchid"/>
                <input type="hidden" name="inajax" value="1"/>
                <input type="hidden" name="searchsubmit" value="yes"/>
                <input type="hidden" id="orderby" name="orderby" value="lastpost"/>
                <input type="hidden" id="ascdesc" name="ascdesc" value="yes"/>
                <input type="hidden" id="viewgroup" name="viewgroup" value="1"/>
                <!--{if !empty($srchtype)}--><input type="hidden" name="srchtype" value="$srchtype"/><!--{/if}-->
                <i class="wqiconfont wqicon-sousuo f22 magnifier"></i>
                <div>
                    <input id='wq_search' class='wq_text_show' type="search" placeholder="&#x8BF7;&#x8F93;&#x5165;&#x60A8;&#x60F3;&#x641C;&#x7D22;&#x7684;&#x5173;&#x952E;&#x8BCD;" name="srchtxt">
                    <div class="group_del wq_all_del" style="display: none" onclick="$('#wq_search_key').show();
                            $('#wq_search_list').html('').hide();">
                        <span class="wqiconfont wqicon-icon32 log_close"></span>
                    </div>
                </div>
            </form>
            <!--{if empty($searchid) || !submitcheck('searchsubmit', 1)}-->

            <div class="groupsearch_key" id="wq_search_key" >

                <!--{eval $search_keyword = $wq_buluo['search_keyword']?explode("\n", str_replace("\r\n", "\n", $wq_buluo['search_keyword'])):'';}-->
                <!--{if $search_keyword}-->
                <ul id="search_keyword">
                    <!--{loop $search_keyword  $key $val}-->
                    <!--{eval $val= trim($val);}-->
                    <!--{if $val}-->
                    <li>$val</li>
                    <!--{/if}-->
                    <!--{/loop}-->
                </ul>
                <script>
                    $('#search_keyword li').click(function () {
                        var keyword = $(this).text();
                        $('#wq_search').val(keyword);
                        $('.wq_all_del').show();
                        wq_search(keyword);
                    });
                </script>
                <!--{/if}-->
            </div>
            <!--{/if}-->

        </div>
        <div id="wq_icon_load"class="group_icon_load" style="display: none">
            <img  src="{$_G['style'][styleimgdir]}mobile/images/icon_load.gif"/>
        </div>
        <div id='wq_search_list' style="display: none">

        </div>
        <div class="p_load_more" style="display: none">
            <!--{if $_G[uid] && isset($mysetting[myextstyle]) && $mysetting[myextstyle] != '0'}-->
            <img src="{$mysetting[myextstyle]}/icon_load.gif"/>
            <!--{else}-->
            <img src="{$_G['style'][styleimgdir]}mobile/images/icon_load.gif"/>
            <!--{/if}-->
            {$Tlang['d0a97567aed382e8']}
        </div>
        <!--{if !empty($searchid) && submitcheck('searchsubmit', 1)}-->
        <!--{subtemplate search/group_list}-->
        <!--{/if}-->
    </div>
    <script>
        function wq_search(keyword) {
            if (keyword) {
                $('#wq_search_key,#wq_search_list').hide();
                $('#wq_icon_load').show()
                $('#wq_searchid').val('');
                $('#orderby').val('');
                $('#ascdesc').val('');
                $('#viewgroup').val('');
                var form = $('#wq_searchform');
                $.ajax({
                    type: 'POST',
                    url: form.attr('action'),
                    data: form.serialize(),
                    dataType: 'html',
                }).success(function (s) {
                    if (s) {
                        $('#wq_icon_load').hide()
                        $('#wq_search_list').html(s).show();
                        delayload();
                    }
                }).error(function () {
                    popup.open('{lang networkerror}', 'alert');
                });
            } else {
                $('#wq_search_key').show();
                $('#wq_search_list,#wq_icon_load').hide();
            }
        }
        $(function () {
            $('#wq_searchform').on('submit', function () {
                var keyword = $.trim($('#wq_search').val());
                wq_search(keyword);
                return false;
            });
            $('#wq_search').on('input', function () {
                var keyword = $.trim($('#wq_search').val());
                if (keyword=='') {
                    wq_search(keyword);
               }
            });
            $(document).on('click', '#wq_all_viewgroup', function () {
                var obj = $(this);
                $.ajax({
                    type: 'GET',
                    url: obj.attr('href'),
                    dataType: 'html'
                }).success(function (s) {
                    $('#orderby').val('lastpost');
                    $('#ascdesc').val('yes');
                    $('#viewgroup').val('1');
                    $('#wq_search_list').html(s).show();
                }).error(function () {
                    window.location.href = obj.attr('href');
                });
                return false;
            });
            var scroll_locked = true;
            $(window).bind('scroll', function () {
                var form = $('#wq_searchform');
                var list = $('#wq_search_list_children');
                if (list.length) {
                    var count = list.attr('count');
                    var perpage = list.attr('perpage');
                    var page = list.attr('page');
                    if (scroll_locked && count / perpage > page && $(document).scrollTop() + wq_window_height >= $(document).height()) {
                        $(".p_load_more").show();
                        scroll_locked = false;
                        var id = list.attr('action');
                        page++;
                        $('#wq_searchid').val(list.attr('searchid'));
                        list.attr('page', page);
                        $.ajax({
                            type: 'GET',
                            url: form.attr('action') + "&page=" + page,
                            data: form.serialize(),
                            dataType: 'html',
                            success: function (data) {
                                $('#wq_' + id).append(data);
                                $(".p_load_more").hide();
                                scroll_locked = true;
                            }
                        });
                    }
                }
            });
            var searchkey = localStorage.getItem('search_val');
            if(searchkey){
                    $('#wq_search').val(searchkey);
                    $('.wq_all_del').show();
                    wq_search(searchkey);
                    group_storage('search_val','','remove');

            }
            $("body").on('click','a',function(){
                    var searchval = $("#wq_search").val();
                    group_storage('search_val',searchval);
            });
        });
    </script>
</div>
<!--{template group/index_nav}-->
<!--{eval $wq_footer_hide='1';}-->
<!--{template common/wq_buluofooter}-->
<!--{/if}-->