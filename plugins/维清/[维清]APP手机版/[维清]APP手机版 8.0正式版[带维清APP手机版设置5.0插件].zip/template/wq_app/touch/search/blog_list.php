<?php exit("From: DisM.taobao.com"); ?>
<!--{eval include DISCUZ_ROOT . './source/plugin/wq_app_setting/function/function_common.php';$pconfig = array();}-->
<!--{eval wq_get_pluginextend_loadconfig(DISCUZ_ROOT . './template/wq_app/touch/templateextend/',$pconfig);}-->
<!--{eval $filename = $pconfig['filename']['blog_list'];}-->
<!--{eval $is_file = is_file("./template/wq_app/touch/".$filename.".htm") || is_file("./template/wq_app/touch/".$filename.".php");}-->
<!--{if $is_file}-->
	<!--{eval include template($filename);}-->
<!--{else}-->
<div class="wqsearch_result wqnew_bottom">
		<h2><!--{if $keyword}-->{lang search_result_keyword}<!--{else}-->{lang search_result}<!--{/if}--></h2>
	</div>
<div class="wqsearch_list">
	<!--{ad/search/y mtw}-->
	<!--{if empty($bloglist)}-->
		<p class="wqemp"><span class="wqno_con"><img src="{$_G['style']['styleimgdir']}images/wqno_con.png"></span>{lang search_nomatch}</p>
	<!--{else}-->
<ul class="wqsearch_list_ul">
				<!--{loop $bloglist $blog}-->
                                <li class="wqnew_bottom">
                                    <a href="home.php?mod=space&uid=$blog[uid]&do=blog&id=$blog[blogid]">
                                                   <div class="wqsearch_maxhidden">
                                                    <h3 class="wqtitle_list">$blog[subject]</h3>
                                                   </div>
                                                   <p class="list_info"><span class="wqwidth80">$blog[username]</span>
                                                   <span class="y"><i class="wqiconfont2 wqicon2-pinglun2 wqapp_f12"></i>$blog[replynum]</span>
                                                   </p>
                                        </a>
                                    </li>
				<!--{/loop}-->
			</ul>
	<!--{/if}-->
	<!--{if !empty($multipage)}--><div class="pgs cl mbm">$multipage</div><!--{/if}-->
</div>
<!--{/if}-->