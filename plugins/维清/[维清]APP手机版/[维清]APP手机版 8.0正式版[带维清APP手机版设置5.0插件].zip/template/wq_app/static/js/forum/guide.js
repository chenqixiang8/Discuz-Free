$(function () {
    $(".wqcolor").click(function () {
        var obj = $(this);
        obj.parent().addClass("wqbg_color");
        obj.addClass("wqwhite").removeClass("wqcolor").text(Cancel_fav);
        var fid = obj.attr("data");
        $.get('forum.php?', {mod: 'misc', action: 'nav', ac: 'delfav', fid: fid, formhash: formhash}, function (data) {
            if (data) {
                popup.open('<div class=\"wqtip\"><p class=class=\"wqp\">' + Cancel_success + '</p></div>');

                close_location();
            }
        }, "text");

    });

    $(".wqwhite").click(function () {
        var obj = $(this);
        $.ajax({
            type: 'POST',
            url: obj.attr('href'),
            data: {favoritesubmit: 'true', handlekey: 'favbtn', inajax: 1, formhash: formhash},
            dataType: 'html'
        }).success(function (s) {
            popup.open(wqXml(s));
        }).error(function () {
            window.location.href = obj.attr('href');
            popup.close();
        });
        return false;
    });

    $("#guide_update").click(function () {
        var obj = $(this);
        $.ajax({
            type: 'POST',
            url: obj.attr('href'),
            data: {update: 'update', inajax: 1, formhash: formhash},
            dataType: 'html'
        }).success(function (s) {
            var data = wqXml(s);
            $("#update").replaceWith(data);
        });
        return false;
    });
});

function succeedhandle_favbtn(url, msg, param) {
    if ($.trim(msg) == info_success) {
        close_location();
    }
}

function close_location() {
    wq_setTimeout();
    window.location.href = 'forum.php?mod=guide&view=newthread&ac=myfav&op=list';
}