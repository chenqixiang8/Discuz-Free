function expression_insertunit(obj) {
	var id_val = $('#needmessage').val();
	$('#needmessage').val(id_val + obj.attr('code'));
}
deleteSmilies('{:', ':}');
$(function() {
	$('.wqexpression').on('click', function() {
		if($(this).is('.c_jianpan')) {
			$('#needmessage').focus();
		}
		$(this).toggleClass('wqicon-jianpan c_jianpan');
		if($('.cellphone_expression').is(':hidden')) {
			$('#imglist').hide();
			$('.cellphone_expression').show();
			$('#upload_icon').removeClass('blue');
			expression_viwepager();
		} else {
			$('.cellphone_expression').hide();
		}
	});

	var needsubject = needmessage = false;
	if('{$_GET[action]}' == 'reply') {
		needsubject = true;
	} else if('{$_GET[action]}' == 'edit') {
		needsubject = needmessage = true;
	}
	if('{$_GET[action]}' == 'newthread' || ('$_GET[action]' == 'edit' && '$isfirstpost')) {
		$('#needsubject').on('keyup input', function() {
			var obj = $(this);
			if(obj.val()) {
				needsubject = true;
				if(needmessage == true) {
					$('.btn_pn').removeClass('btn_pn_grey').addClass('btn_pn_blue');
					$('.btn_pn').attr('disable', 'false');
				}
			} else {
				needsubject = false;
				$('.btn_pn').removeClass('btn_pn_blue').addClass('btn_pn_grey');
				$('.btn_pn').attr('disable', 'true');
			}
		});
	}
	$('#needmessage').on('keyup input', function() {
		var obj = $(this);
		if(obj.val()) {
			needmessage = true;
			if(needsubject == true) {
				$('.btn_pn').removeClass('btn_pn_grey').addClass('btn_pn_blue');
				$('.btn_pn').attr('disable', 'false');
			}
		} else {
			needmessage = false;
			$('.btn_pn').removeClass('btn_pn_blue').addClass('btn_pn_grey');
			$('.btn_pn').attr('disable', 'true');
		}
	});
})
$(document).on('click', '#postsubmit', function() {
	var form = $('#postform');
	var obj = $('#postsubmit');
	if(obj.attr('disable') == 'true') {
		return false;
	}
	popup.open('<img src="' + IMGDIR + '/imageloading.gif">');
	var postlocation = '';
	if(geo.errmsg === '' && geo.loc) {
		postlocation = geo.longitude + '|' + geo.latitude + '|' + geo.loc;
	}
	$.ajax({
		type: 'POST',
		url: form.attr('action') + '&geoloc=' + postlocation + '&handlekey=' + form.attr('id') + '&inajax=1',
		data: form.serialize(),
		dataType: 'html'
	}).success(function(s) {
		popup.open(wqXml(s));
		if('$_GET[do]' == 'broadcast') {
			location.href = 'home.php?mod=follow';
		}
	}).error(function() {
		popup.open('����������⣬���Ժ�����', 'alert');
	});
	return false;

});
function upload_image(data) {
	if(data == '') {
		popup.open('�ϴ�ʧ�ܣ����Ժ�����', 'alert');
	}

	var dataarr = data.split('|');
	if(dataarr[0] == 'DISCUZUPLOAD' && dataarr[2] == 0) {
		if($('#imglist').is(':hidden')) {
			$('.wqicon2-tupian1').addClass('wqcolor');
			$('.wqicon2-tupian1').parent().siblings().each(function() {
				var icon = $(this).data('type');
				$('.showHide_' + icon).hide();
				if(icon != 'biaoqing') {
					$('.wqicon2-' + icon).removeClass('wqcolor');
				}
			})
			$('.wqbiaoqing').addClass('wqicon2-biaoqing').removeClass('wqicon2-jianpan');
			$('#imglist').show();
			$('#upload_icon').addClass('blue');
		}
		wqapp_getimage(dataarr[3], 'image');
	} else {
		var sizelimit = '';
		if(dataarr[7] == 'ban') {
			sizelimit = "(�������ͱ���ֹ)";
		} else if(dataarr[7] == 'perday') {
			sizelimit = "(���ܳ���" + Math.ceil(dataarr[8] / 1024) + 'K)';
		} else if(dataarr[7] > 0) {
			sizelimit = "(���ܳ���" + Math.ceil(dataarr[7] / 1024) + 'K)';
		}
		popup.open(STATUSMSG[dataarr[2]] + sizelimit, 'alert');
	}
}
;

function wqupload_attach(data) {

	if(data == '') {
		popup.open('�ϴ�ʧ�ܣ����Ժ�����', 'alert');
	}
	var aid = parseInt(data);
	if(aid > 0) {
		wqapp_getimage(aid, 'attach');
	} else {
		aid = aid < 0 ? Math.abs(aid) : aid;
		if(typeof STATUSMSG[aid] == "undefined") {
			popup.open(STATUSMSG[-1], 'alert');
		} else {
			popup.open(STATUSMSG[aid], 'alert');
		}
		return false;
	}
}
function wqapp_getimage(aid, wqtype) {

	$.ajax({
		url: 'plugin.php?id=wq_app_setting&mod=api&aid=' + aid,
		data: {fun: 'attachlist', ac: wqtype},
		dataType: 'JSON',
		type: 'POST',
		async: false,
		success: function(res) {
			if(res && res.errcode == '1') {
				if(wqtype == 'image') {
					$('#imglist').prepend(res.msg);
					if(parseInt($('#imglist li').length - 1) != 0) {
						$('.wqtoday').show().text($('#imglist li').length - 1);
					}
					$('#filedata').val('');
				} else if(wqtype == 'attach') {
					$('#post_attach').append(res.msg);
					$('.wqfujian2').show();
					$('#filedatas').val('');
				}
			}
			popup.close();
		}
	});
}
function _type_select(obj, type, b) {
	if(typeof b != 'undefined') {
		if($(obj).hasClass('wq_on')) {
			$('.showHide_' + type).hide();
			$(obj).removeClass('wq_on');
		} else {
			$(obj).addClass('wq_on');
			$('.showHide_' + type).show();
			$(obj).parent().siblings().each(function() {
				var icon = $(this).data('type');
				$('.showHide_' + icon).hide();
				$('.wqdel_' + icon).removeClass('wq_on');
			})
			$('.wqbiaoqing').addClass('wqicon2-biaoqing').removeClass('wqicon2-jianpan');
		}
	} else {
		if(type == 'biaoqing') {
			if($(obj).is('.c_jianpan')) {
				$('.wqeditarea').focus();
			}
			$(obj).toggleClass('wqicon2-jianpan');
			if($('.showHide_' + type).is(':hidden')) {
				$('.showHide_' + type).show();
				$('#upload_icon').removeClass('blue');
				$('#imglist').hide();
				$(obj).removeClass('wqicon2-biaoqing');
				expression_viwepager();
				$(obj).parent().siblings().each(function() {
					var icon = $(this).data('type');
					$('.showHide_' + icon).hide();
					$('.wqicon2-' + icon).removeClass('wqcolor');
				})
			} else {
				$('.showHide_' + type).hide();
				$(obj).addClass('wqicon2-biaoqing');
			}
		} else {
			if($(obj).hasClass('wqcolor')) {
				$('.showHide_' + type).hide();
				$(obj).removeClass('wqcolor');
			} else {
				$(obj).addClass('wqcolor');
				$('#imglist').hide();
				$('#upload_icon').removeClass('blue');
				$('.showHide_' + type).show();
				$(obj).parent().siblings().each(function() {
					var icon = $(this).data('type');
					$('.showHide_' + icon).hide();
					if(icon != 'biaoqing') {
						$('.wqicon2-' + icon).removeClass('wqcolor');
					}
				})
				$('.wqbiaoqing').addClass('wqicon2-biaoqing').removeClass('wqicon2-jianpan');
			}
		}
	}
}

function isNull(str) {
	if(str == "" || !str || typeof (str) == "undefined" || str.length == 0) {
		return true;
	}
	;

	var regu = "^[ ]+$";
	var re = new RegExp(regu);
	return re.test(str);
}

function wqapp_relatekw() {
	var subject = $('#needsubject').val();
	subject = wqapp_replace(subject);
	var message = $('#needmessage').val();
	message = wqapp_replace(message);
	message = message.replace(/&/ig, '', message).substr(0, 500);
	var url = 'plugin.php?id=wq_app_setting&mod=ajax&ac=tags&subjectenc=' + subject + '&messageenc=' + message;
	popup.open(toast);
	$.ajax({
		type: 'GET',
		url: url,
		dataType: 'html',
	}).success(function(s) {
		if(s != '') {
			tagsplit = $('#tags').val().split(','),
				returnsplit = s.split(','),
				result = '';
			for(i in tagsplit) {
				for(j in returnsplit) {
					if(tagsplit[i] == returnsplit[j]) {
						tagsplit[i] = '';
						break;
					}
				}
			}
			for(i in tagsplit) {
				if(tagsplit[i] != '') {
					result += tagsplit[i] + ',';
				}
			}
			$('#tags').val(result + s);
			wqapp_tagval();
		}
		popup.close();
	});
}

function wqapp_replace(str) {
	str = str.replace(/<\/?[^>]+>|\[\/?.+?\]|"/ig, "");
	str = str.replace(/\s{2,}/ig, ' ');
	return str;
}

function wqapp_tagval() {
	if($('#tags').val().length) {
		$('#wqapp_tag_chk').removeClass('none');
	} else {
		$('#wqapp_tag_chk').addClass('none');
	}
}