function succeedhandle_postform_w(url,msg,params) {
    clearTimeout(setTimeout_location);
    get_reply(params);
    if($('#wqcommet_warp_'+params.tid).is(':hidden')){
        $('#wqcommet_warp_'+params.tid).show();
    }
    if($('#wqcommet_'+params.tid).is(':hidden')){
        $('#wqcommet_'+params.tid).show();
    }
    setTimeout_location = setTimeout(function() {
        popup.close();
    }, '1000');
}

function get_reply(params){
     $.ajax({
        type: 'GET',
        url: 'plugin.php?id=wq_app_setting&mod=ajax&ac=get_reply',
        data: {tid: params.tid, fid: params.fid, pid: params.pid, formhash: formhash},
        dataType: 'html',
        async: false,
        success: function (s) {
            $('#wqcommet_'+params.tid).prepend(s);
        }
    });
}

$(function () {
    if ($('.new_button2').length) {
        $('body').on('click', '.new_button2', function (e) {
            var menu = $(this).parents('.new_div').siblings('.new_menu');
            if (menu.is(':hidden')) {
                $('.new_menu').hide();
                menu.show();
                $(document).one('scroll', function () {
                    menu.hide();
                });
            } else {
                menu.hide();
            }
            e.stopPropagation();
        });
        $('body').on('click', function () {
            $('.new_menu:visible').hide();
        });
    }
});