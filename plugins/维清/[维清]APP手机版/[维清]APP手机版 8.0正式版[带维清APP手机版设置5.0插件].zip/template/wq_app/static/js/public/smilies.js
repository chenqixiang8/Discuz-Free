function delayload_smile(j, index) {
    $("#wqscroll_" + j + " .image_b[data-index=\"" + index + "\"] .delayload").each(function () {
        var img = $(this).attr("data");
        $(this).attr("src", img).attr("class", null);
    });
}
function expression_viwepager() {
    if (typeof ($('.wqscrolls:visible').attr('data')) != "undefined") {
        var j = $('.wqscrolls:visible').attr('data');
        var bullets = $('.small_dots_t:visible span');
        window.Swipe(document.getElementById('wqscroll_' + j), {
            continuous: true,
            callback: function (pos, y, direction, ids) {
                var s = i = bullets.length;
                delayload_smile(ids, pos);
                if (i == 2 && pos > 1) {
                    pos = pos - 2;
                }
                while (i--) {
                    bullets[i].className = 'small_dots';
                }
                bullets[pos].className = 'small_dots on';
            }
        }, j);
        delayload_smile(j, 0);
    }
}
$('.expression li').click(function () {
    var date = $(this).attr('data');
    $('.wqscrolls').hide();
    $('#wqscrolls_' + date).show();
    if (!$(this).is('.on')) {
        expression_viwepager();
    }
    $('.expression li').removeClass('on');
    $(this).addClass('on');
});

function deleteSmilies(left, right) {
    $('.image_b a:not(.delete_emoji)').click(function () {
        expression_insertunit($(this));
    });
    $('.delete_emoji').on('click', function () {
        var content = $('#needmessage').val();
        var start = content.length - 2;
        var last = content.substr(start, 2);
        if (last == right) {
            var position = content.lastIndexOf(left);
            content = content.substr(0, position);
        } else {
            content = content.substring(0, content.length - 1);
        }
        $('#needmessage').val(content);
    });
    $('#needmessage').on('keydown', function (event) {
        if (event.keyCode == "8") {
            var content = $('#needmessage').val();
            var start = content.length - 2;
            var last = content.substr(start, 2);
            var content = $('#needmessage').val();
            var content_leng = content.leng;
            var Position = getTxt1CursorPosition('needmessage');
            var end = content.substr(Position, content_leng);
            content = content.substr(0, Position);
            var start = content.length - 2;
            var last = content.substr(start, 2);
            if (last == right) {
                var position = content.lastIndexOf(left);
                content = content.substr(0, position);
                $('#needmessage').val(content + end);
                setCursorPosition('needmessage', content.length);
                return false;
            }
        }
    });
}