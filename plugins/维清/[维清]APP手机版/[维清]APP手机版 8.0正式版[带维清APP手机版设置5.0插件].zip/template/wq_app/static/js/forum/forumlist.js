$(function () {
    if (showstyle == 2 && fontlength == 6) {
        $('#wqlist_left').css('width', '26%');
        $('#wqlist_right').css({'left': '26%', 'width': '73.5%'});
    }
    function switchover(obj, myscroll) {
        $('.forum_list_fight').hide();
        $('#department-list li').removeClass('active');
        obj.parent().addClass('active');
        if ($('#department-list').height() >= $('#main-window').height()) {
            myscroll.scrollToElement('#wqlist_left .active', 1000);
        }
    }

    var clientHeight = function (type) {
        var clientHeight = $('.scrollBorder').offset().top;
        var height = fit_height(window, ['.wqfooter']) - clientHeight, top = clientHeight;
        if (type == 'height') {
            return height;
        } else if (type == 'top') {
            return top;
        }
    };

    var wrapHeight = clientHeight('height'), topHeight = clientHeight('top');
    $('#wqlist_left, .wqlist_warp, #wqlist_right').css('height', wrapHeight);
    $('#wqlist_left, .wqlist_warp').css('top', topHeight);

    var myscroll = new IScroll("#wqlist_left", {click: true, bounce: true});

    var myscroll2 = {};

    if ($("#wqlist_left a:first").attr('data-gid')) {
        var fid = $("#wqlist_left a:first").attr('data');
    } else {
        var fid = sessionStorage.getItem('key2') || $("#wqlist_left a:first").attr('data');
    }

    var scroll_right = parseFloat(sessionStorage.getItem('key3')) || 0;

    sessionStorage.removeItem('key2');
    sessionStorage.removeItem('key3');

    switchover($('#wqlist_left a[data="' + fid + '"]'), myscroll);
    $(".forum_" + fid).height(wrapHeight).show();

    myscroll2[fid] = new IScroll(".forum_" + fid, {click: true, bounce: true});
    myscroll2[fid].scrollTo(0, scroll_right);

    $("#wqlist_left a").on('click', function (e) {
        var obj = $(this);
        fid = obj.attr("data");
        switchover(obj, myscroll);
        $('.forum_' + fid).show();

        var initScroll = function () {
            var resultContentH = $("#new_right").height();
            if (resultContentH > 0) {
                $(".forum_" + fid).height(wrapHeight);
                myscroll2[fid] = new IScroll(".forum_" + fid, {click: true, bounce: true});
            }
        };

        if (!myscroll2[fid]) initScroll();

        return false;
    });

    $('#new_right').on('click', 'a', function (e) {
        var href = $(this).attr("href");

        sessionStorage.setItem('key2', fid);
        sessionStorage.setItem('key3', myscroll2[fid].y);
        e.preventDefault();
        location.href = href;
    });
});