;(function ($) {
    var defaults = {
        type: 'slide',
        selector: '',
        stop: ''
    };

    $.extend({
        wqslideout: function (obj) {
            var opt = $.extend({}, defaults, obj);
            var disX,
                disY,
                disX2,
                disY2,
                left = 0,
                x_index = null,
                y_index = null,
                weight = $('.wq-slide-warp').width();

            var slideout = {
                slideInit: function () {
                   document.addEventListener('touchstart', function (event) {
                        var touch = event.targetTouches[0];
                        disX = touch.clientX;
                        disY = touch.clientY;
                        x_index = null;
                        y_index = null;
                        $('.wq-slide-warp').css('transition', '');
                    }, false);

                    document.addEventListener('touchmove', slideout.touchmove, false);

                    document.addEventListener('touchend', function (event) {
                        var touch = event.targetTouches[0];
                        $('.wq-slide-warp').css('transition', '150ms cubic-bezier(.165,.84,.44,1)');

                        if (x_index > 1.7 * y_index) {
                            if ( (left == 0 && disX2 > 50) || (left == weight && disX2 > -50)) {
                                $('.wq-slide-warp').css('transform', 'translateX('+ weight + 'px)');
                                $('.wq-slide-mask').fadeIn(100);
                                left = weight;
                                $('html').addClass('slide-open');
                            } else {
                                $('.wq-slide-warp').css('transform', 'translateX(0)');
                                $('.wq-slide-mask').fadeOut(100);
                                left = 0;
                                $('html').removeClass('slide-open');
                            }
                        }

                        window.norefresh = false;
                    }, false);

                    if (document.querySelector('.wq-slide-list')) {
                        var maxHeight = fit_height(window, ['.wq-slide-head', '.wq-slide-bottom', '.wq-slide-space']);

                        $('.wq-slide-list').height(maxHeight);


                        var myscroll = new IScroll(".wq-slide-list", {
                            bounce: true
                        });

                        $('.wq-slide-list a').on('tap', function() {
                            if (this.href && this.href.indexOf('javascript') == -1) {
                                location.href = this.href;
                            }
                            return false;
                        });

                    }

                    if (opt.stop) {
                        this.stopSlide(opt.stop);
                    }

                    if (opt.click) {
                        this.clickInit(opt.click);
                    }
                 },
                touchmove: function () {
                    if(typeof(noTouchmove) == 'boolean' && noTouchmove === true){
                        return false;
                    }
                    var touch = event.targetTouches[0];
                        disX2 = touch.clientX - disX;
                        disY2 = touch.clientY - disY;



                    if (!x_index && !y_index) {
                        x_index = Math.abs(disX2);
                        y_index = Math.abs(disY2);
                    }

                    if (x_index > 1.7 * y_index) {
                        window.norefresh = true;
                        if (left + disX2 <= 0) {
                            $('.wq-slide-warp').css('transform', 'translateX(0)');

                        } else if (left + disX2 >= weight) {
                            $('.wq-slide-warp').css('transform', 'translateX('+ weight + 'px)');

                        } else {
                            $('.wq-slide-warp').css('transform', 'translateX(' + (left + disX2) + 'px)');
                        }
                        event.preventDefault();
                    } else {
                        window.norefresh = false;
                    }
                },
                stopSlide: function (selector) {

                    $('body').on('touchstart', selector, function () {
                        document.removeEventListener('touchmove', slideout.touchmove, false);
                    });

                    $('body').on('touchend', selector, function () {
                        document.addEventListener('touchmove', slideout.touchmove, false);
                    });
                },
                clickInit: function (selector) {
                    if (!$(selector).length) return;
                    $(selector).on('click', function () {
                            $('.wq-slide-warp').css('transform', 'translateX('+ weight + 'px)');
                            $('.wq-slide-mask').fadeIn(100);
                            left = weight;
                            $(this).addClass('wq-clickout-on');
                            $('html').addClass('slide-open');
                    });
                },
                closeSlide: function () {
                    $('.wq-slide-mask').on('click', function () {
                        $('.wq-slide-warp').css('transform', 'translateX(0)');
                        $('.wq-slide-mask, #slideoutCode').fadeOut(100);
                        left = 0;
                        $('html').removeClass('slide-open');
                    });
                }
            };

            if (opt.type == 'slide') {
                slideout.slideInit();

            } else if (opt.type == 'click') {
                slideout.clickInit(opt.selector);

            } else if (opt.type == 'both') {
                slideout.slideInit();
                slideout.clickInit(opt.selector);
            }

            slideout.closeSlide();

            $(".wq-slide-warp .wqbtn_follow i").on("touchend",function(){
                $("#slideoutCode").fadeIn();
                $('.wq-slide-warp').css('transform', 'translateX(0)');
                left = 0;
            });
        }
    });
})($);