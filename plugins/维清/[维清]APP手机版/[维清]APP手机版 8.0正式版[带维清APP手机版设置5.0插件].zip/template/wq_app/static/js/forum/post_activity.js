$(function(){
    var uploadsuccess_activity = function(data) {
        if(data == '') {
            popup.open('{lang uploadpicfailed}', 'alert');
        }
        var dataarr = data.split('|');
        if(dataarr[0] == 'DISCUZUPLOAD' && dataarr[2] == 0) {
            popup.close();
            if ($('#activityaid').length) {
                $.ajax({
                    type:'GET',
                    url:'forum.php?mod=ajax&action=deleteattach&inajax=yes&aids[]=' + $('#activityaid').val(),
                })
            }
            $('#activityattach_image').html('<div class="wqm_top10"><a href="'+prcpath+'forum/'+dataarr[5]+'"><img id="aimg_'+dataarr[3]+'" title="'+dataarr[6]+'" src="'+prcpath+'forum/'+dataarr[5]+'" />\n\
            <input type="hidden" name="activityaid" id="activityaid" value="'+dataarr[3]+'"><input type="hidden" name="activityaid_url" id="activityaid_url" value="'+dataarr[5]+'"></a></div>');
            $('#filedata').val('').attr('multiple','multiple');
        } else {
            var sizelimit = '';
            if(dataarr[7] == 'ban') {
                    sizelimit = '{lang uploadpicatttypeban}';
            } else if(dataarr[7] == 'perday') {
                    sizelimit = '{lang donotcross}'+Math.ceil(dataarr[8]/1024)+'K)';
            } else if(dataarr[7] > 0) {
                    sizelimit = '{lang donotcross}'+Math.ceil(dataarr[7]/1024)+'K)';
            }
            popup.open(STATUSMSG[dataarr[2]] + sizelimit, 'alert');
        }
    };

    $('#activity_image').click(function(){
       uploadsuccess_forum= uploadsuccess_activity;
       $('#filedata').attr('multiple',null).click();
    });

    if (!!navigator.userAgent.match(/iphone|ipad/gi)) {
        $('.muidate').on('touchend', function () {
            $('input, select').blur();
        });
    }

    $(".muidate.wqpost_input").width("45%");
    $("#activitytime").on("change",function(){
        if ($("#activitytime").val() == "0") {
            $("#activity_data1").show();
            $("#activity_data2").hide();
            $("#activity_data3").hide();
            $("#activity_data3").prev("span").hide();
        } else {
            $("#activity_data1").hide();
            $("#activity_data2").show();
            $("#activity_data3").show();
            $("#activity_data3").prev("span").show();
        }
    });
    var isSelected = '0';
    $("#classid").on("change", function(){
        if($(this).val() == "1") {
            $(".class-create, #mask").show();
        }
        else {
            isSelected = $(this).val();
        }
    });

    $(".wqeject_cancel").on("click", function(){
        $(".class-create, #mask").hide();
        $('#classid option[value="' + isSelected + '"]').prop('selected', 'selected');
    });

    $(".wqdetermine").on("click", function(){
        var newClass = $(".new_className").val();
        if(newClass){
            $("#classid").prepend('<option selected="selected" value="' + newClass + '">' + newClass + '</option>');
            $(".class-create, #mask").hide();
            isSelected = $('#classid option').eq(0).val();
        }
    });
    var width = ($(document).width() - $(".class-create").width()) / 2;
    var height = ($(window).height() - $(".class-create").height()) / 2;
    $(".class-create").css({"left": width, "top": height});
});