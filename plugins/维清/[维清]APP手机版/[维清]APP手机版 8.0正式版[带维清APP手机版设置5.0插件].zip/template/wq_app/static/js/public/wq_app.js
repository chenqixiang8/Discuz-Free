var setTimeout_location, wq_window_width = $(window).width(), wq_window_height = $(window).height(), wq_fixed_top = 0, wq_scrollbar;
var toast = '<div id="loadingToast" class="weui_loading_toast"><div class="weui_mask_transparent"></div><div class="weui_toast"><div class="weui_loading"><div class="weui_loading_leaf weui_loading_leaf_0"></div><div class="weui_loading_leaf weui_loading_leaf_1"></div><div class="weui_loading_leaf weui_loading_leaf_2"></div><div class="weui_loading_leaf weui_loading_leaf_3"></div><div class="weui_loading_leaf weui_loading_leaf_4"></div><div class="weui_loading_leaf weui_loading_leaf_5"></div><div class="weui_loading_leaf weui_loading_leaf_6"></div><div class="weui_loading_leaf weui_loading_leaf_7"></div><div class="weui_loading_leaf weui_loading_leaf_8"></div><div class="weui_loading_leaf weui_loading_leaf_9"></div><div class="weui_loading_leaf weui_loading_leaf_10"></div><div class="weui_loading_leaf weui_loading_leaf_11"></div></div></div></div>';

function wq_app_showwindow(id, url, type) {
    popup.open(toast);
    type = type ? type : 'GET';
    $.ajax({
        type: type,
        url: url,
        data: {inajax: 1, handlekey: id},
        dataType: 'html'
    }).success(function(s) {
        var wq = wqXml(s);
        popup.open(wq_replace_js(wq));
        evalscript(wq);
    }).error(function() {
        window.location.href = url;
        popup.close();
    });
    return false;
}
function wq_app_ajaxpost(form) {
    popup.open(toast);
    $.ajax({
        type: 'POST',
        url: $(form).attr('action') + '&inajax=1',
        data: $(form).serialize(),
        dataType: 'html'
    }).success(function(s) {
        popup.open(wqXml(s));
    }).error(function() {
        popup.open('{lang networkerror}', 'alert');
    });
    return false;
}
function wq_app_ajax_scroll(page, count, perpage, url, id, botton, successfun) {
    var wq_scroll_locked = true;
    botton = botton ? botton : 0;
    count = parseInt(count);
    perpage = parseInt(perpage);
    page = parseInt(page);
    $(window).on('scroll', throttle(function() {
        if (wq_scroll_locked && count / perpage > page && $(this).scrollTop() + wq_window_height >= $(document).height() - botton) {
            wq_scroll_locked = false;
            $(".p_load_more").show();
            page++;
            $.ajax({
                type: 'GET',
                url: url,
                data: {api: 1, page: page},
                dataType: 'html',
                success: function(data) {
                    $('#' + id).append(data);
                    $(".p_load_more").hide();
                    wq_scroll_locked = true;
                    if (typeof successfun == 'function') {
                        eval(successfun(page));
                    }
                    if (perpage * page >= count) {
                        $('.loading').show();
                    }
                }
            })
        }
    }), 300);
}
function wq_setTimeout() {
    clearInterval(setTimeout_location);
    setTimeout(function() {
        popup.close();
    }, '1000');
}

function delayload() {
    var document_top = $(document).scrollTop();
    $(".wq_js_delayload").each(function() {
        var img_top = $(this).offset().top;
        if (img_top >= document_top && img_top <= document_top + wq_window_height) {
            var img = $(this).attr("data-src");
            $(this).attr("src", img).removeClass("wq_js_delayload");
            this.onload = function () {
                if ($(this).parents('.wq-lazyload-container').length) {
                    feed_img($(this).parents('.wq-lazyload-container'));
                }
            }
        }
    });
}
$(function() {
    $(document).on('.wq_text_show', 'keydown input change', function() {
        if ($(this).val() != '') {
            $(this).siblings('.wq_all_del').show();
        } else {
            $(this).siblings('.wq_all_del').hide();
        }
    });
    $(document).on('.wq_all_del', 'click', function() {
        $(this).hide().siblings('.wq_text_show').val('');
    });
    delayload();
    var pulldown_load = true;
    $(document).on('scroll', throttle(function() {
        delayload();

        var obj = $('.pulldown_load_js:visible');

        if (obj.length && pulldown_load) {
            var botton = obj.attr('botton') ? obj.attr('botton') : 0;
            var query_string = obj.attr('query_string');
            var count = parseInt(obj.attr('count'));
            var perpage = parseInt(obj.attr('perpage'));
            var page = parseInt(obj.attr('page'));
            var windowHeight = $(window).height();
            $(".wqmore").show();

            if (count / perpage > page && $(this).scrollTop() + windowHeight >= $(document).height() - botton - 160) {
                pulldown_load = false;
                page++;
                var url=SITEURL+"source/plugin/wq_app_setting/api/index.php?script=" + CURSCRIPT + "&"+query_string;
                $.ajax({
                    type: 'GET',
                    url: url,
                    data: {page: page},
                    dataType: 'html',
                    success: function(data) {
                        var append_dom = $('#' + obj.attr('contentid')).append(data);
                        obj.attr('page', page);
                        $(".wqmore").hide();
                        pulldown_load = true;

                        $('img').each(function() {
                            if ($(this).attr('smilieid')) {
                                $(this).addClass('wq_smilieimg');
                            }
                        });

                        if (perpage * page >= count) {
                            $('.loading').show();
                        }

                        if (window.set_li_height) {
                            set_li_height(append_dom);
                        }
                    }
                })

            } else if (count / perpage <= page) {
                $(".wqloaded_all").show();
                $(".wqmore").hide();
            }
        }
    }, 300));

     $(document).on('click', '.recommendadd_zan', function () {
        var obj = $(this);
        var data = obj.attr('data')
        setcookie('wq_app_recommend_tid', data);
        return false;
    });

    $(document).on('click', '.newfav', function () {
        var obj = $(this);
        var data = obj.attr('data');
        setcookie('wq_app_newfav_tid', data);
        return false;
    });

});
function getTxt1CursorPosition(txt1) {
    var oTxt1 = document.getElementById(txt1);
    var cursurPosition = -1;

    if (oTxt1.selectionStart) {
        cursurPosition = oTxt1.selectionStart;
    } else {//IE
        var range = document.selection.createRange();
        range.moveStart("character", -oTxt1.value.length);
        cursurPosition = range.text.length;
    }

    return cursurPosition;
}
function setCursorPosition(elem, index) {
    elem = document.getElementById(elem);
    var val = elem.value
    var len = val.length
    if (len < index)
        return
    setTimeout(function() {
        elem.focus()
        if (elem.setSelectionRange) {
            elem.setSelectionRange(index, index)
        } else { // IE9-
            var range = elem.createTextRange()
            range.moveStart("character", -len)
            range.moveEnd("character", -len)
            range.moveStart("character", index)
            range.moveEnd("character", 0)
            range.select()
        }
    }, 10)
}
function wq_show_password(elem, thiss) {
    if ($('#' + elem).is(':visible')) {
        var wq_password = $('#' + elem);
        var wq_text = $('#' + elem + '_text');
    } else {
        var wq_text = $('#' + elem);
        var wq_password = $('#' + elem + '_text');
    }
    var name = wq_password.attr('name');
    var value = wq_password.val();
    wq_password.hide().attr('name', '');
    wq_text.attr('name', name).val(value).show();
    thiss.children().toggleClass('top12 wqicon-yanjinghei wqicon-liulan');
}
function wq_is_scroll() {
    var maxHeight = parseInt($('body').css('max-height'));
    if (maxHeight == wq_window_height) {
        $('body').css('max-height', '')
        $(window).scrollTop(wq_scrollbar)
    } else {
        wq_scrollbar = $(window).scrollTop();
        $('body').css("max-height", wq_window_height);
    }
    $('body,html').toggleClass("wq_ovhidden");
}
$.fn.extend({
    autoHeight: function(padding) {
        padding = padding ? padding : 0;
        $(this).on('input focus', function() {
            $(this).height(this.scrollHeight - padding);
        });
    }
});

function _adjustHs(elem) {
    var obj = $('#' + elem);
    var wq_scrollHeight = document.getElementById(elem).scrollHeight
    return obj.height(wq_scrollHeight - 6).scrollTop(wq_scrollHeight);
}

var historyLength = history.length;
var ajaxUrl = {
    hidden: function(html) {
        $('#wq_hidden_html').remove();
        $('body').append('<div id="wq_hidden_html" style="display:none;">' + html + '</div>');
        return  $('#wq_hidden_html').children();
    },
    inajax: function(obj, type) {
        popup.open(toast, '', '', 1);
        var url = obj.url;
        var before = obj.before
        if (before) {
            eval(before);
        }
        $.ajax({
            type: 'GET',
            url: obj.url,
            data: {inajax: 1, api: 1},
            dataType: 'html'
        }).success(function(s) {
            var successFun = obj.successfun
            if (successFun) {
                eval(successFun);
            }
            var xmlValue = wqXml(s);
            var htmlText = wq_replace_js(xmlValue);
            var htmlObj = ajaxUrl.hidden(htmlText);
            var title = htmlObj.attr('title');
            var htmlId = htmlObj.attr('id');
            $('#wq_hidden_html').remove();
            if (!type) {
                historyLength++;
                obj.title = title;
                history.pushState(obj, title, SITEURL + url);
            }
            $('title').remove();
            $('head').append('<title>' + htmlObj.attr('title') + '</title>');
            $('#' + htmlId).remove();
            $("div[pattern='ordinary']").remove();
            $("div[delid='delid']").remove();
            var append_html = $('#' + obj.addid).append(htmlText);
            set_li_height(append_html, true);
            evalscript(xmlValue);
            popup.close();
        }).error(function() {
                window.location.href = obj.url;
        });
    },
    int: function() {
        $(document).on('click', 'a[inajax="1"]', function() {

            var state = {
                url: $(this).attr('href'),
                addid: $(this).attr('addid'),
            }
            if ($(this).attr('before')) {
                state.before = $(this).attr('before');
            }
            if ($(this).attr('successFun')) {
                state.successFun = $(this).attr('successFun');
            }
            ajaxUrl.inajax(state);
            return false;
        });
        $(window).on("popstate", function(event) {
            var state = event.originalEvent.state;
            if (state) {
                if (state.url) {
                    historyLength--;
                    ajaxUrl.inajax(event.originalEvent.state, 1);
                }
            }
        });
    }
}

$(function() {
	ajaxUrl.int();
})

function feed_imgList(obj) {
    var length = obj.length, width = 100 / length - 2;
    obj.width(width + '%');
    if (length > 1) {
        obj.height(obj.width() * 0.75);
    } else if (length == 1) {
        var img_width = obj.eq(0).find('img').width();
        var img_height = obj.eq(0).find('img').height();
        if (img_width < obj.width() / 3) {
            obj.width('31.3%');
            obj.height(obj.width());
        } else if (img_width < obj.width() / 2) {
            obj.width('48%');
            obj.height(obj.width());
        } else {
            obj.height(obj.width() * 0.56);
        }
    }
    for (var i = 0; i < length; i++) {
        feed_img(obj.eq(i));
    }
}

function feed_img(obj) {
    var img = new Image()
    obj.css('overflow', 'hidden');
    img.src = obj.find('img').attr('data-src')
    img.onload = function() {
        var img_width = img.width, img_height = img.height;
        if (img_width / obj.width() > img_height / obj.height()) {
            obj.find('img').height(obj.height());
            obj.find('img').width(obj.height() * img_width / img_height);
            var marginLeft = (obj.width() - obj.find('img').width()) / 2;
            obj.find('img').css('margin-left', marginLeft);
        } else {
            obj.find('img').width(obj.width());
            obj.find('img').height(obj.width() * img_height / img_width);
            var marginTop = (obj.height() - obj.find('img').height()) / 2;
            obj.find('img').css('margin-top', marginTop);
        }
    }
}

function fit_height(parent, arr) {
    var height = $(parent).height();

    arr.forEach(function (item) {
        height -= $(item)[0].clientHeight
    });

    return height;
}

function wq_app_cache_user_favorite_or_recommend_info(wqtype){
    $.ajax({
        type: 'POST',
        url: 'plugin.php?id=wq_app_setting&mod=ajax&ac='+wqtype,
        dataType: 'xml',
    });
}
$.fn.closemenu = function (c) {
    c = typeof c == 'undefined' || c === null ? 'new_menu' : c ;
    return this.each(function () {
        $(this).on('click', function () {
            $('.new_hide').hide();
            $('.' + c).hide();
            $(this).off();
        })
    })
};

$.fn.openmenu = function (c) {
    c = typeof c == 'undefined' || c === null ? 'new_menu' : c ;
    return this.each(function () {
        $('.new_hide').css({"height": $(window).height() + 'px'}).fadeIn().closemenu(c);
        $(this).siblings('.'+ c).fadeIn().closemenu(c);
    });
};

function expand_the_menu(obj,f_class,menu){
    $(obj).parents('.'+ f_class).openmenu(menu);
}

function succeedhandle_newfav(url,msg, param) {
    if ($.trim(msg) == "��Ϣ�ղسɹ�") {
        wq_app_cache_user_favorite_or_recommend_info('favorite');
        var tid = getcookie('wq_app_newfav_tid');
        setcookie('wq_app_newfav_tid','',-1)
        $('#i_crad_'+tid).attr('class','wqiconfont2 wqicon2-shoucang wqcolor_yellow');
        $('#crad_'+tid).text(parseInt($('#crad_'+tid).text()) + 1);
        wq_setTimeout();
    }
}

function errorhandle_recommendadd(msg, param){
   if (param['recommendv'] == '+1') {
        var tid = getcookie('wq_app_recommend_tid');
        setcookie('wq_app_recommend_tid','',-1)
        var num = parseInt($('#recommendadd_'+tid).text());
        $('#recommendadd_'+tid).text(num + 1);
        wq_setTimeout();
    }
}

function errorhandle_wrecommendadd(msg, param){
   if (param['recommendv'] == '+1') {

        var tid = getcookie('wq_app_recommend_tid');
        var username = $('#wqcommet_warp_'+tid).attr("data-username");
        var uid = $('#wqcommet_warp_'+tid).attr("data-uid");

        setcookie('wq_app_recommend_tid','',-1)
        if($('#wqcommet_warp_'+tid).is(':hidden')){
            $('#wqcommet_warp_'+tid).show();
        }
        if($('#wqzan_'+tid).is(':hidden')){
            $('#wqzan_'+tid).show();
            $('#wqzan_'+tid).append('<a href="home.php?mod=space&do=profile&uid='+uid+'" class="wq_name">'+username+'</a>')
        }else{
            $('#wqzan_'+tid).append('<a href="home.php?mod=space&do=profile&uid='+uid+'" class="wq_name">,'+username+'</a>')
        }
        wq_setTimeout();
    }
}

function errorhandle_recommendsub(msg, param){
   if (param['recommendv'] == '-1') {
        var tid = getcookie('wq_app_recommend_tid');
        setcookie('wq_app_recommend_tid','',-1)
        var num = parseInt($('#recommendsub_'+tid).text());
        $('#recommendsub_'+tid).text(num + 1);
        wq_setTimeout();
    }
}

function scrollIntoView() {
    var h = 0;
    return function () {
        var hf = parseInt($('.wqposts_atom').offset().top) - 44,
            hs = parseInt($('body').scrollTop());
        if (hs >= hf) {
            $('body').animate({'scrollTop': h + 'px'}, 300);
        } else {
            h = $(document).scrollTop();
            $('body').animate({'scrollTop': hf + 'px'}, 300);
        }
    }
}

var DTimers = [];
var DItemIDs = [];
var DTimers_exists = false;
function settimer(timer, itemid) {
    if(timer && itemid) {
        DTimers.push(timer);
        DItemIDs.push(itemid);
    }
    if(!DTimers_exists) {
        setTimeout("showtime()", 1000);
        DTimers_exists = true;
    }
}
function showtime() {
    for(i=0; i<=DTimers.length; i++) {
        if(DItemIDs[i]) {
            if(DTimers[i] == 0) {
                $(DItemIDs[i]).innerHTML = '�ѽ���';
                DItemIDs[i] = '';
                continue;
            }
            var timestr = '';
            var timer_day = Math.floor(DTimers[i] / 86400);
            var timer_hour = Math.floor((DTimers[i] % 86400) / 3600);
            var timer_minute = Math.floor(((DTimers[i] % 86400) % 3600) / 60);
            var timer_second = (((DTimers[i] % 86400) % 3600) % 60);
            if(timer_day > 0) {
                timestr += timer_day + '��';
            }
            if(timer_hour > 0) {
                timestr += timer_hour + 'Сʱ'
            }
            if(timer_minute > 0) {
                timestr += timer_minute + '��'
            }
            if(timer_second > 0) {
                timestr += timer_second + '��'
            }
            DTimers[i] = DTimers[i] - 1;
            $('#' + DItemIDs[i]).html(timestr);
        }
    }
    setTimeout("showtime()", 1000);
}

function listStorage(key, contain) {
    var m_ua = navigator.appVersion;
    var mbrowser = {
        isUC: /UCBrowser/.test(m_ua),
        isBaiduBox: /baiduboxapp\//.test(m_ua),
        isBaiduBrowser: /baidubrowser\//.test(m_ua),
        isQQBrowser: ! /QQ\//.test(m_ua) && /MQQBrowser/.test(m_ua) && !/MicroMessenger/.test(m_ua),
        isWXIos: /MicroMessenger/.test(m_ua) && /iPhone/.test(m_ua),
        isSafari: /applewebkit\/\d+(\.\d+)*\d*\s*\(KHTML,\s*like\s*Gecko\)\s*version\/\d+(\.\d+)*\.\d+\s*mobile\/\d+\w\d+\s*safari\/\d+(\.\d+)*\.\d+$/i.test(m_ua)
    };
    if (!mbrowser.isUC && !mbrowser.isBaiduBox && !mbrowser.isBaiduBrowser && !mbrowser.isQQBrowser && !mbrowser.isWXIos && !mbrowser.isSafari) {
        $(window).on('load', function () {
            var guide = sessionStorage.getItem(key) ? JSON.parse(sessionStorage.getItem(key)) : '';
            if (guide && guide.hash == (location.href.split('?')[1] ? location.href.split('?')[1].replace('&mobile=2', '') : '') && guide.contain == '.' + contain && $(guide.html).find('.guidelink:eq(0)').attr('href') == $(guide.contain).find('.guidelink:eq(0)').attr('href')) {
                $(guide.contain).html(guide.html);
                $(window).scrollTop(guide.top);
            }
            sessionStorage.removeItem(key);

        });

        $(window).on('unload', function (e) {
            if ($('.wqindex_list_ul').attr('page') > 1) {
                sessionStorage.setItem(key, JSON.stringify({
                    contain: '.' + contain,
                    html: $('.' + contain).html(),
                    top: $(window).scrollTop(),
                    hash:  location.href.split('?')[1] ? location.href.split('?')[1].replace('&mobile=2', '') : ''
                }));

            }
        });
    }
}

function wq_app_ajaxget(ajaxurl,id){
    $.ajax({
        type: 'GET',
        url: ajaxurl,
        dataType: 'html'
    }).success(function (s) {
        var wq = wqXml(s);
        var start = wq.indexOf('<option');
        var end = wq.lastIndexOf('</select>');
        var option = wq.slice(start, end);
        $("#"+id).html(option);
    }).error(function() {
        console.log('Request failed');
    });
}