$(function() {
    var con = $("p[is_content='null']");
    if(con.length == 1){
        return;
    }
    var wqwaterfall_content = $('#wq_forumdisplay_list');
    wqwaterfall_content.imagesLoaded(function(){
        var flag = $("ul[wq_flag='waterfall']");
        if(flag && flag.length == 1){
            var con = $("p[is_content='null']");
            if(con.length == 1){
                $('.pgs').hide();
                return;
            }
            $("ul[wq_flag='waterfall'] li").each(function(){
                var li_height = $(this).children().height();
                $(this).css('height',li_height);
            });
        }
        $('.wqwaterfall').masonry({
            itemSelector: '.waterfall > li'
        });
    });

});

function set_li_height(data,handover){
    data.imagesLoaded(function(){
        var flag = $("ul[wq_flag='waterfall']");
        if(flag && flag.length == 1){
            var con = $("p[is_content='null']");
            if(con.length == 1){
                $('.pgs').hide();
                return;
            }

            $("ul[wq_flag='waterfall'] li").each(function(){
            var li_height = $(this).children().height();
            $(this).css('height',li_height);
            });

            if(data){
                $("ul[wq_flag='waterfall'] li:lt(2)").each(function(){
                    $(this).css('margin-top','0px');
                });
                $('.pgs').show();
                if(!handover){
                    data.masonry('reload');
                }else{
                    $('.wqwaterfall').masonry('reload');
                }
            }
        }
    });
}