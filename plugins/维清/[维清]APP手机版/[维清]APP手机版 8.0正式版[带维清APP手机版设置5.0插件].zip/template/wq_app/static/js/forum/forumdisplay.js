$(function () {
    var scroll_locked = true;
    $('.wqforum_list_follow').on('click', '#a_favorite', function () {
        var obj = $(this);
        $.ajax({
            type: 'POST',
            url: obj.attr('href'),
            data: {favoritesubmit: 'true', handlekey: 'favbtn', inajax: 1, formhash: formhash},
            dataType: 'html'
        }).success(function (s) {
            wq_is_scroll();
            popup.open(wqXml(s));
        }).error(function () {
            window.location.href = obj.attr('href');
            popup.close();
        });
        return false;
    });
    listStorage('forum', contain);

    $(wqforum_list_follow).on('click', cancel_favorite, function () {
        $.get('forum.php?', {mod: 'misc', action: 'nav', ac: 'delfav', fid: forum_fid, formhash: formhash}, function (data) {
            if (data) {
                popup.open('<div class=\"wqtip\"><p class=class=\"wqp\">' + Cancel_success + '</p></div>')
                $(cancel_favorite).html('<i class="wqiconfont2 wqicon2-increase wq_f13 wqm_right3"></i>' + favtimes);
                $(cancel_favorite).parent().attr('class', 'wqforum_list_follow y wqbg_color');
                $(cancel_favorite).unbind("click").attr('href', 'home.php?mod=spacecp&ac=favorite&type=forum&id=' + forum_fid).attr('id', 'a_favorite').attr('class', 'wqwhite');
                get_favtimes();
                wq_setTimeout();
            }
        }, "text");
    });

    var pcontent_height = wq_window_height - 50;
    $('.wqpcontent').attr("style", 'height:' + pcontent_height + 'px');
    $('#list_hide, #wq_screen_js').click(function () {
        $('#advanced_filter').slideToggle();
        wq_is_scroll();

        return false;
    });
    $(' .wqpcontent a').on('click', function () {
        $('#advanced_filter').hide();
    });
    delayload();
});
function succeedhandle_favbtn(url, msg, param) {
    if ($.trim(msg) == info_success) {
        $(a_favorite).html('<i class="wqiconfont2 wqicon2-o3 wq_f14 wqm_right3"></i>' + favtimes);
        $(a_favorite).parent().attr('class', 'wqforum_list_follow y wqbg_color');
        $(a_favorite).unbind("click").attr('href', 'javascript:;').attr('id', 'cancel_favorite').attr('class', 'wqwhite');
        get_favtimes();
        wq_is_scroll();
        wq_setTimeout();
    }
}


function get_favtimes() {
    $.ajax({
        type: 'GET',
        url: 'forum.php?mod=misc',
        data: {action: 'nav', ac: 'selfav', fid: forum_fid, formhash: formhash},
        dataType: 'json',
        success: function (s) {
            $('#fav_num').html(s.favtimes);
        }
    });
}

$(function () {
    $('.wqchild-show').on('click', function () {
        $('.wqchild-show').hide();
        $('.wqson_plate .dsn').show();
    });
    $('.wqchild-hide').on('click', function () {
        $('.wqchild-show').show();
        $('.wqson_plate .dsn').hide();
    })
});