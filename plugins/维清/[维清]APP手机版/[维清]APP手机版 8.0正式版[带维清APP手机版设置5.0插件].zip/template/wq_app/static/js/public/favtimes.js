$(function () {
    $('body').on('click', '.wqfav-button', function (e) {
        var obj = $(this);
        if ($(this).hasClass('wqcolor')) {
            var fid = obj.attr('data');
            $.get('forum.php?', {mod: 'misc', action: 'nav', ac: 'delfav', fid: fid, formhash: formhash}, function (data) {
                if (data) {
                    cancel_callback && cancel_callback(fid);
                }
            }, "text");
        } else {
            $.ajax({
                type: 'POST',
                url: obj.attr('data-href'),
                data: {favoritesubmit: 'true', handlekey: 'favbtn', inajax: 1, formhash: formhash},
                dataType: 'html'
            }).success(function (s) {
                popup.open(wqXml(s));
            }).error(function () {
                window.location.href = obj.attr('data-href');
                popup.close();
            });
        }
        return false;
    });
});