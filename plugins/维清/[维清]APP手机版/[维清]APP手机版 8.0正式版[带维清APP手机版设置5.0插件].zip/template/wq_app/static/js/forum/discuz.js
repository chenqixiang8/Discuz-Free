var visitclienthref = getvisitclienthref();

if(visitclienthref) {
    $('#visitclientid').attr('href', visitclienthref);
    if(!visitclient){
         $('.visitclienttip').css('display', 'block');
    }
} else {
    if(visitclient){
        window.location.href = visitclient;
    }
}

(function() {
    if(mobileforumview){
        $('.sub_forum').css('display', 'block');
    }else{
        $('.sub_forum').css('display', 'none');
    }
    $('.subforumshow').on('click', function() {
        var obj = $(this);
        var subobj = $(obj.attr('href'));
        if(subobj.css('display') == 'none') {
            subobj.css('display', 'block');
            obj.find('span').html('<i class="wqiconfont2 wqicon2-jian y wqapp_f24"></i>');
        } else {
            subobj.css('display', 'none');
            obj.find('span').html('<i class="wqiconfont2 wqicon2-jia y wqapp_f24"></i>');
        }
    });
 })();



function getvisitclienthref() {
    var visitclienthref = '';
    if(ios) {
        visitclienthref = 'https://itunes.apple.com/cn/app/zhang-shang-lun-tan/id489399408?mt=8';
    } else if(andriod) {
        visitclienthref = 'http://www.discuz.net/mobile.php?platform=android';
    }
    return visitclienthref;
}

function show_subforum(fid) {
    if ($('.bmw_nav_' + fid).is(':hidden')) {
        $('.bmw_arrow_' + fid).addClass('wqicon2-up_1');
        $('.bg_arrow_' + fid).addClass('bmw_arrow_top');
        $('.bmw_nav_' + fid).slideDown(300, 'swing');
    } else {
        $('.bmw_arrow_' + fid).removeClass('wqicon2-up_1');
        $('.bg_arrow_' + fid).removeClass('bmw_arrow_top');
        $('.bmw_nav_' + fid).slideUp(300, 'swing');
    }
}