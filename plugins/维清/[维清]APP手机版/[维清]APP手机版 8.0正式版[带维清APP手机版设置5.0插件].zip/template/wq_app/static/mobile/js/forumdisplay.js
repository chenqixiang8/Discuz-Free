$(function() {
        $('.favbtn2').on('click', function() {
            var obj = $(this);
             window.tid = obj.attr('data');
            $.ajax({
                type: 'POST',
                url: obj.attr('href') + '&handlekey=favbtn2&inajax=1',
                data: {
                    'favoritesubmit': 'true',
                    'formhash':formhash
                },
                dataType: 'html',
            }).success(function(s) {
                popup.open(wqXml(s));
            }).error(function() {
                window.location.href = obj.attr('href');
                popup.close();
            });
            return false;
        });

        $('.recommend').on('click', function() {
            var obj = $(this);
            var handlekey = obj.attr('dataid');
            window.tid = obj.attr('data');
            $.ajax({
                type: 'GET',
                url: obj.attr('href') + '&handlekey=' + handlekey + '&inajax=1',
                data: {'hash': formhash},
                dataType: 'html',
            }).success(function(s) {
                popup.open(wqXml(s));
            }).error(function() {
                window.location.href = obj.attr('href');
                popup.close();
            });
            return false;
        });

    });

        function errorhandle_recommendadd(msg, param) {
        if (param['recommendv'] == '+1') {
            var obja = $('.recommend_add_'+tid);
            obja.css("display", "");
            obja.html(parseInt(obja.html()) + 1);
        }
    }
    function succeedhandle_favbtn2(url, msg, param) {
        if ($.trim(msg) == forum_fav) {
            clearInterval(setTimeout_location);
            $('.forum_fav_'+tid).text(parseInt($('.forum_fav_'+tid).text()) + 1);
            setTimeout(function() {
                popup.close();
            }, '1000');
        }
    }

    function errorhandle_recommendsubtract(msg, param) {
        if (param['recommendv'] == '-1') {
            var objr = $('.recommend_subtract_'+tid);
            objr.css("display", "");
            objr.html(parseInt(objr.html()) + 1);
        }
    }