var setTimeout_location, wq_window_width = $(window).width(), wq_window_height = $(window).height(), wq_fixed_top = 0, wq_scrollbar;
var toast = '<div id="loadingToast" class="weui_loading_toast"><div class="weui_mask_transparent"></div><div class="weui_toast"><div class="weui_loading"><div class="weui_loading_leaf weui_loading_leaf_0"></div><div class="weui_loading_leaf weui_loading_leaf_1"></div><div class="weui_loading_leaf weui_loading_leaf_2"></div><div class="weui_loading_leaf weui_loading_leaf_3"></div><div class="weui_loading_leaf weui_loading_leaf_4"></div><div class="weui_loading_leaf weui_loading_leaf_5"></div><div class="weui_loading_leaf weui_loading_leaf_6"></div><div class="weui_loading_leaf weui_loading_leaf_7"></div><div class="weui_loading_leaf weui_loading_leaf_8"></div><div class="weui_loading_leaf weui_loading_leaf_9"></div><div class="weui_loading_leaf weui_loading_leaf_10"></div><div class="weui_loading_leaf weui_loading_leaf_11"></div></div></div></div>';

function group_storage(key, value, type) {
	if (type == 'remove') {
		localStorage.removeItem(key, value);
	} else {
		localStorage.setItem(key, value);
	}
}
function wq_touch_showwindow(id, url, type) {
	popup.open(toast);
	type = type ? type : 'GET';
	$.ajax({
		type: type,
		url: url,
		data: {inajax: 1, handlekey: id},
		dataType: 'html',
	}).success(function(s) {
		var wq = wqXml(s);
		wq = wq_replace_js(wq);
		popup.open(wq);
		evalscript(wq);
	}).error(function() {
		window.location.href = url;
		popup.close();
	});
	return false;
}
function wq_touch_ajaxpost(form) {
	popup.open(toast);
	$.ajax({
		type: 'POST',
		url: $(form).attr('action') + '&inajax=1',
		data: $(form).serialize(),
		dataType: 'html',
	}).success(function(s) {
		popup.open(wqXml(s));
	}).error(function() {
		popup.open('{lang networkerror}', 'alert');
	});
	return false;
}
function wq_touch_ajax_scroll(page, count, perpage, url, id, botton, successfun) {
	var wq_scroll_locked = true;
	botton = botton ? botton : 0;
	count = parseInt(count);
	perpage = parseInt(perpage);
	page = parseInt(page);
	$(window).bind('scroll', function() {
		if (wq_scroll_locked && count / perpage > page && $(this).scrollTop() + wq_window_height >= $(document).height() - botton) {
			wq_scroll_locked = false;
			$(".p_load_more").show();
			page++;
			$.ajax({
				type: 'GET',
				url: url,
				data: {api: 1, page: page},
				dataType: 'html',
				success: function(data) {
					$('#' + id).append(data);
					$(".p_load_more").hide();
					wq_scroll_locked = true;
					if (typeof successfun == 'function') {
						eval(successfun(page));
					}
					if (perpage * page >= count) {
						$('.loading').show();
					}
				}
			})
		}
	});
}
function wq_setTimeout() {
	clearInterval(setTimeout_location);
	setTimeout(function() {
		popup.close();
	}, '1000');
}

function delayload() {
	var document_top = $(document).scrollTop();
	$(".wq_js_delayload").each(function() {
		var img_top = $(this).offset().top;
		if (img_top >= document_top && img_top <= document_top + wq_window_height) {
			var img = $(this).attr("data");
			$(this).attr("src", img).removeClass("wq_js_delayload");
		}
	});
}
function delayload_buluo() {
	var document_top = $(document).scrollTop();
	$(".wq_js_delayload").each(function() {
		var img_top = $(this).offset().top;
		if (img_top >= document_top && img_top <= document_top + wq_window_height) {
			$(this).attr('src', $(this).attr('data')).removeClass("wq_js_delayload");
			if ($(this).parent().hasClass('img-box')) {
				feed_img($(this).parent())
			}
		}
	});
}
function feed_img(obj) {
	var img = new Image()
	img.src = obj.find('img').attr('data')
	img.onload = function() {
		var img_width = img.width, img_height = img.height;
		if (img_width / obj.width() > img_height / obj.height()) {
			obj.find('img').height(obj.height());

			obj.find('img').width(obj.height() / img_height * img_width);

			var marginLeft = (obj.width() - obj.find('img').width()) / 2;
			obj.find('img').css('margin-left', marginLeft);
		} else {
			obj.find('img').width(obj.width());
			obj.find('img').height(obj.width() / img_width * img_height);

			var marginTop = (obj.height() - obj.find('img').height()) / 2;
			obj.find('img').css('margin-top', marginTop);
		}
	}
}

function wqc_img_box() {
	var document_top = $(document).scrollTop();
	$(".wqc_img_box").each(function() {
		var img_top = $(this).offset().top;
		if (img_top >= document_top && img_top <= document_top + wq_window_height) {
			var divwidth = parseInt($(this).width());
			var imgwidth = parseInt($(this).attr('dataw'));
			var imgheight = parseInt($(this).attr('datah'));
			var num = parseInt($(this).attr('num'));
			var datatid = $(this).attr('datatid');
			var data = $(this).attr('data');
			switch (num) {
				case 1:
					var divh = 200;
					var divw = divwidth;
					break;
				case 2:
					var divh = 150;
					var divw = divwidth;
					break;
				case 3:
					var divh = 100;
					var divw = divwidth;
			}
			if (imgwidth > imgheight) {
				var dataheight = divh;
				var datawidth = (divh * imgwidth) / imgheight;
				if (datawidth < divw) {
					var poor = divwidth - datawidth;
					var datawidth = datawidth + poor;
					var dataheight = dataheight + poor;
					var datatop = -(dataheight - divh) / 2;
					var dataleft = 0;
				} else {
					var dataleft = -(datawidth - divw) / 2;
					var datatop = 0;
				}
			} else if (imgheight > imgwidth) {
				var dataheight = divw;
				var dataheight = (divw * imgheight) / imgwidth;
				var datatop = -(dataheight - divh) / 2;
				var dataleft = 0;
			} else {
				if (divw > divh) {
					var datawidth = divw;
					var dataheight = divw;
				} else {
					var datawidth = divh;
					var dataheight = divh;
				}
				var dataleft = 0;
				var datatop = -(dataheight - divh) / 2;
			}
			var cwidth = $(window).width();
			$("#wqc_css_" + datatid + "_" + data).css("height", dataheight);
			if (datawidth < cwidth) {
				$("#wqc_css_" + datatid + "_" + data).css("width", "'" + datawidth + "'");
				$("#wqc_css_" + datatid + "_" + data).css("margin-left", dataleft);
			} else {
				dataheight = 200 * cwidth / datawidth;
				$("#wqc_css_" + datatid + "_" + data).parent().css("height", dataheight);
			}
			$("#wqc_css_" + datatid + "_" + data).css("height", dataheight);
			$("#wqc_css_" + datatid + "_" + data).css("margin-top", datatop);
			$(this).removeClass("wqc_img_box");
		}
	});
}

$(function() {
	$(document).delegate('.wq_text_show', 'keydown input change', function() {
		if ($(this).val() != '') {
			$(this).siblings('.wq_all_del').show();
		} else {
			$(this).siblings('.wq_all_del').hide();
		}
	});
	$(document).delegate('.wq_all_del', 'click', function() {
		$(this).hide().siblings('.wq_text_show').val('');
	});
	var h = location.href
	if (h.indexOf('buluo') == -1) {
		delayload()
		wqc_img_box()
	} else {
		delayload_buluo()
	}
	var pulldown_load = true;
	$(document).bind('scroll', function() {
		if (h.indexOf('buluo') == -1) {
			delayload()
			wqc_img_box()
		} else {
			delayload_buluo()
		}
		var obj = $('.pulldown_load_js:visible');
		if (obj.length && pulldown_load) {
			botton = obj.attr('botton') ? obj.attr('botton') : 0;
			count = parseInt(obj.attr('count'));
			perpage = parseInt(obj.attr('perpage'));
			page = parseInt(obj.attr('page'));

			if (count / perpage > page && $(this).scrollTop() + wq_window_height >= $(document).height() - botton) {
				pulldown_load = false;
				$(".p_load_more").show();
				page++;
				$.ajax({
					type: 'GET',
					url: location.href,
					data: {api: 1, inajax: '1', page: page},
					dataType: 'html',
					success: function(s) {

						data = wqXml(s);
						var append_dom = $('#' + obj.attr('contentid')).append(data);
						obj.attr('page', page);
						$(".p_load_more").hide();
						pulldown_load = true;
						if (perpage * page >= count) {
							$('.loading').show();
						}
						set_li_height(append_dom);
					}
				})
			}
		}
	});

});
function getTxt1CursorPosition(txt1) {
	var oTxt1 = document.getElementById(txt1);
	var cursurPosition = -1;
	if (oTxt1.selectionStart) {
		cursurPosition = oTxt1.selectionStart;
	} else {//IE
		var range = document.selection.createRange();
		range.moveStart("character", -oTxt1.value.length);
		cursurPosition = range.text.length;
	}
	return cursurPosition;
}

function setCursorPosition(elem, index) {
	elem = document.getElementById(elem);
	var val = elem.value
	var len = val.length
	if (len < index)
		return
	setTimeout(function() {
		elem.focus()
		if (elem.setSelectionRange) {
			elem.setSelectionRange(index, index)
		} else { // IE9-
			var range = elem.createTextRange()
			range.moveStart("character", -len)
			range.moveEnd("character", -len)
			range.moveStart("character", index)
			range.moveEnd("character", 0)
			range.select()
		}
	}, 10)
}

function wq_show_password(elem, thiss) {
	if ($('#' + elem).is(':visible')) {
		var wq_password = $('#' + elem);
		var wq_text = $('#' + elem + '_text');
	} else {
		var wq_text = $('#' + elem);
		var wq_password = $('#' + elem + '_text');
	}
	var name = wq_password.attr('name');
	var value = wq_password.val();
	wq_password.hide().attr('name', '');
	wq_text.attr('name', name).val(value).show();
	thiss.children().toggleClass('top12 wqicon-yanjinghei wqicon-liulan');
}
function wq_is_scroll() {
	var maxHeight = parseInt($('body').css('max-height'));
	if (maxHeight == wq_window_height) {
		$('body').css('max-height', '')
		$(window).scrollTop(wq_scrollbar)
	} else {
		wq_scrollbar = $(window).scrollTop();
		$('body').css("max-height", wq_window_height);
	}
	$('body,html').toggleClass("wq_ovhidden");
}
$.fn.extend({
	autoHeight: function(padding) {
		padding = padding ? padding : 0;
		$(this).on('input focus', function() {
			$(this).height(this.scrollHeight - padding);
		});
	}
});
function _adjustHs(elem) {
	var obj = $('#' + elem);
	var wq_scrollHeight = document.getElementById(elem).scrollHeight
	return obj.height(wq_scrollHeight - 6).scrollTop(wq_scrollHeight);
}
var historyLength = history.length;
var ajaxUrl = {
	hidden: function(html) {
		$('#wq_hidden_html').remove();
		$('body').append('<div id="wq_hidden_html" style="display:none;">' + html + '</div>');
		return  $('#wq_hidden_html').children();
	},
	inajax: function(obj, type) {
		popup.open(toast, '', '', 1);
		var url = obj.url;
		var before = obj.before
		if (before) {
			eval(before);
		}
		$.ajax({
			type: 'GET',
			url: obj.url,
			data: {inajax: 1, api: 1},
			dataType: 'html'
		}).success(function(s) {
			var successFun = obj.successfun
			if (successFun) {
                            eval(successFun);
			}
			var xmlValue = wqXml(s);
			var htmlText = wq_replace_js(xmlValue);
			var htmlObj = ajaxUrl.hidden(htmlText);
			var title = htmlObj.attr('title');
			var htmlId = htmlObj.attr('id');
			$('#wq_hidden_html').remove();
			if (!type) {
				historyLength++;
				obj.title = title;
				history.pushState(obj, title, SITEURL + url);
			}
			$('title').remove();
			$('head').append('<title>' + htmlObj.attr('title') + '</title>');
			$('#' + htmlId).remove();
			$("div[pattern='ordinary']").remove();
			$("div[delid='delid']").remove();
			var append_html = $('#' + obj.addid).append(htmlText);
			set_li_height(append_html, true);
			evalscript(xmlValue);
			popup.close();
		}).error(function() {
			window.location.href = obj.url;
		});
	},
	int: function() {
		$(document).on('click', 'a[inajax="1"]', function() {
			var state = {
				url: $(this).attr('href'),
				addid: $(this).attr('addid'),
			}
			if ($(this).attr('before')) {
				state.before = $(this).attr('before');
			}
			if ($(this).attr('successFun')) {
				state.successFun = $(this).attr('successFun');
			}
			ajaxUrl.inajax(state);
			return false;
		});
		$(window).on("popstate", function(event) {
			var state = event.originalEvent.state
			if (state.url && !state.isloadtouchjs) {
				historyLength--;
				ajaxUrl.inajax(event.originalEvent.state, 1);
			}
		});
	}
}

$(function() {
	ajaxUrl.int();
})