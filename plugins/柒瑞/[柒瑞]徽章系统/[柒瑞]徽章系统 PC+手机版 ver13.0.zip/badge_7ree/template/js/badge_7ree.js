/*
	(C)2006-2013 dism.taobao.com
	This is NOT a freeware, use is subject to license terms
	Update: 13:14 2014/1/20
	Agreement: http://dism.taobao.com/?@7.developer.doc/agreement_7ree_html
	More Plugins: http://dism.taobao.com/?@7ree
 */
 
 function getlogo_7ree(value_7ree,source_7ree,target1_7ree,target2_7ree){
 	 	if(value_7ree){
 	 		value_7ree = value_7ree.replace(/\'/g,"");
			value_7ree = value_7ree.replace(/\"/g,"");
			
 	 		$(source_7ree).value = value_7ree;
 			$(target1_7ree).src = 'source/plugin/badge_7ree/badge_img/small/'+value_7ree;
 			$(target2_7ree).src = 'source/plugin/badge_7ree/badge_img/big/'+value_7ree;

 		}
 }
 
 
 function gettemplate_7ree(type_7ree,obj_7ree){
  		if(type_7ree){
  			
 			//$(obj_7ree).innerText = type_7ree;
			ajaxget('plugin.php?id=badge_7ree:badge_7ree&code=11&type_7ree='+type_7ree, 'type_template_area_7ree', 'type_template_area_7ree');

 		}
 }

 function openclose_7ree(id_7ree,linehieght_7ree){
 		if($(id_7ree).className=='close_btn_7ree'){
		 		$('side_div_'+id_7ree).style.height=linehieght_7ree+'px';
		 		$(id_7ree).className='open_btn_7ree';
 		}else if($(id_7ree).className=='open_btn_7ree'){
		 		$('side_div_'+id_7ree).style.height='auto';
		 		$(id_7ree).className='close_btn_7ree';
 		}
 }



