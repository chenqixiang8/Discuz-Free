<?php

/*
 * [dism.taobao.com] (C)2006-2021 dism.taobao.com.
 * This is NOT a freeware, use is subject to license terms
 * Agreement: https://dism.taobao.com/?@7.developer.doc/agreement_7ree_html
 * More Plugins: https://dism.taobao.com/developer-7.html
 * EMail: service@dism.taobao.com
 * QQ: 467783778
 * WeiXin: dism_taobao_com
 * Update: 2021-08-01 22:41:00
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
loadcache('plugin');

class plugin_badge_7ree {


		function forumdisplay_top(){
				$this->checkfid_7ree();
		}
		
		function viewthread_top(){
				$this->checkfid_7ree();
		}
		
		function checkfid_7ree(){
				global $_G;
				$return = '';
				if($_G['fid']){
						//$did_7ree = DB::result_first("SELECT id_7ree FROM ".DB::table('badge_main_7ree')." WHERE fid_7ree LIKE '%#{$_G[fid]}#%'");
						@require_once(DISCUZ_ROOT.'./source/discuz_version.php');
						$cahcedir_7ree = DISCUZ_VERSION == "X2" ? './data/cache/cache_' : './data/sysdata/cache_';
						$cachename_7ree = "badge_fid_7ree";
						@include DISCUZ_ROOT.$cahcedir_7ree.$cachename_7ree.'.php';
						$did_7ree=array();
						foreach($fidcache_7ree as $fidcache_value){
							if(strstr($fidcache_value['fid_7ree'],'#'.$_G['fid'].'#')){
								$did_7ree[]=$fidcache_value['id_7ree'];
								//break;
							}
						}
						//print_r($did_7ree);
					if($did_7ree){
						if($_G['uid']){
							//$logid_7ree = DB::result_first("SELECT id_7ree FROM ".DB::table('badge_log_7ree')." WHERE did_7ree='$did_7ree' AND uid_7ree='$_G[uid]' AND status_7ree=2");
							//echo("SELECT id_7ree FROM ".DB::table('badge_log_7ree')." WHERE did_7ree IN(".dimplode($did_7ree).") AND uid_7ree='$_G[uid]' AND status_7ree=2");
							$logid_7ree = DB::result_first("SELECT id_7ree FROM ".DB::table('badge_log_7ree')." WHERE did_7ree IN(".dimplode($did_7ree).") AND uid_7ree='$_G[uid]' AND status_7ree=2");
							
							if(!$logid_7ree){
								showmessage("badge_7ree:php_lang_errortip_nobid_7ree");
							}
						}else{
							showmessage('not_loggedin', NULL, array(), array('login' => 1));
						}
					}
				}
				return $return;
		
		}

		function global_cpnav_extra1(){
				global $_G;
				$return = "<link rel='stylesheet' id='css_badge_7ree' type='text/css' href='source/plugin/badge_7ree/template/css/badge_7ree.css?{VERHASH}'/><script src='source/plugin/badge_7ree/template/js/badge_7ree.js?{VERHASH}'></script>";
				return $return;
		}

		function global_footerlink(){
				global $_G;
				$return = "";
				if($_G['uid']){
					@include_once("source/plugin/badge_7ree/function_7ree/badge_function_7ree.php");
						//�Զ����Ż�������
						//�����л������ҳ�����Ҫ�Զ����ŵĻ��£�ͬʱ�ų��Ѿ���ȡ�Ļ��£�
						//���������Ѽ��Ľ�����飬����ǰuid��Ա���Ż��£����ú���ʵ�֣�
					$query = DB::query("SELECT id_7ree,type_7ree,how_7ree,group_7ree,var1_7ree,var2_7ree,num1_7ree,num2_7ree,ext_7ree
										FROM ".DB::table('badge_main_7ree')." WHERE onoff_7ree = 1 AND how_7ree IN(1,4)");
	
					while($badge_table_7ree = DB::fetch($query)){
    	   			//����Ҫ����Ƿ����������û��飬��ִ�ж���
    	   					$badge_group_7ree = explode(',', $badge_table_7ree['group_7ree']);
							if(in_array($_G['groupid'],$badge_group_7ree)){
								if($badge_table_7ree['how_7ree']=='1'){
									push_badge_7ree($badge_table_7ree['id_7ree'],$_G['uid'],'auto');
									$mylog_7ree=DB::fetch_first("SELECT * FROM ".DB::table('badge_log_7ree')." WHERE uid_7ree='$_G[uid]' AND did_7ree='$badge_table_7ree[id_7ree]'");
									if($mylog_7ree['id_7ree'] && $mylog_7ree['view_7ree']<>1){
										$mytipid_7ree[]=$badge_table_7ree['id_7ree'];
									}
									break;
								}elseif($badge_table_7ree['how_7ree']=='4'){
									//�ж��Ƿ��Ѿ��������ö����
									$badge_table_7ree['myget_7ree'] = badge_test_7ree($badge_table_7ree['type_7ree'],$badge_table_7ree['id_7ree'],$_G[uid],$badge_table_7ree['var1_7ree'],$badge_table_7ree['num1_7ree'],$badge_table_7ree['var2_7ree'],$badge_table_7ree['num2_7ree'],$badge_table_7ree['upgrade_7ree'],$badge_table_7ree['ext_7ree']);
									$mytipid_7ree[] = $badge_table_7ree['myget_7ree']['status_7ree'] =="status1_7ree" ? $badge_table_7ree['id_7ree'] : 0;
									//$mytipid_7ree = $badge_table_7ree['myget_7ree'];
								}
								
							}
           			} 



           			foreach($mytipid_7ree as $mytipid_value){
           				if($mytipid_value){
           						$return = "<script language='JavaScript' type='text/JavaScript'>showWindow('badgewin_7ree', 'plugin.php?id=badge_7ree:badge_7ree&code=13&id_7ree={$mytipid_value}','get',0,{cover:1});</script>";
           						break;
           				}else{
           						$mybadgeid_7ree = DB::result_first("SELECT id_7ree FROM ".DB::table('badge_log_7ree')." WHERE uid_7ree = '{$_G[uid]}' AND status_7ree = 2 AND view_7ree = 0");
								$return = $mybadgeid_7ree ? "<script language='JavaScript' type='text/JavaScript'>showWindow('badgewin_7ree', 'plugin.php?id=badge_7ree:badge_7ree&code=12&id_7ree={$mybadgeid_7ree}','get',0,{cover:1});</script>" : "";
								if($return) break;
						}
					}

				}
				return $return;
		}				
				
		function viewthread_sidetop_output(){
				global $_G,$postlist;
				$vars_7ree = $_G['cache']['plugin']['badge_7ree'];
				$exttitle_7ree = $_G['setting']['extcredits'][$vars_7ree['ext_7ree']][title];
				$return = array();
				if($vars_7ree['lefttop_7ree']<>'top') return $return;
				$authorids_7ree=array();
				foreach($postlist as $pid=>$postinfo_7ree){
					$authorids_7ree[] = $postinfo_7ree['authorid'];
				}
				$authorids_7ree = dimplode(array_filter(array_unique($authorids_7ree)));
				
				 $query = DB::query("SELECT l.*, m.*  FROM ".DB::table('badge_log_7ree')." l
											LEFT JOIN ".DB::table('badge_main_7ree')." m ON. m.id_7ree = l.did_7ree
											WHERE l.uid_7ree IN($authorids_7ree) AND l.status_7ree = 2 AND m.onoff_7ree = 1
											ORDER BY l.time_7ree DESC");
					while($table_7ree = DB::fetch($query)){
							$table_7ree['time_7ree'] = gmdate( lang('plugin/badge_7ree', 'php_lang_timeformat4_7ree'), $table_7ree['time_7ree'] + $_G['setting']['timeoffset'] * 3600 ); 
							$table_7ree['detail2_7ree'] = str_replace(array('#var1_7ree#','#var2_7ree#','#num1_7ree#','#num2_7ree#'), array($table_7ree['var1_7ree'],$table_7ree['var2_7ree'],$table_7ree['num1_7ree'],$table_7ree['num2_7ree']), $table_7ree['detail_7ree']); 
							$badgelist0_7ree[$table_7ree['uid_7ree']][] = $table_7ree;
           			} 
			
				if(is_array($postlist) && $vars_7ree[agreement_7ree]) {
            		foreach($postlist as $key => $postlist_7ree) {
            			$badgelist_7ree[$postlist_7ree['authorid']]['badge_7ree']= $badgelist0_7ree[$postlist_7ree['authorid']];
            			$badgelist_7ree[$postlist_7ree['authorid']]['badge_num'] = count($badgelist0_7ree[$postlist_7ree['authorid']]);
            			$badgelist_7ree[$postlist_7ree['authorid']]['height_7ree'] = ceil($badgelist_7ree[$postlist_7ree['authorid']]['badge_num']/4)*40;
            			$badgelist_7ree[$postlist_7ree['authorid']]['btn_on_7ree'] = $badgelist_7ree[$postlist_7ree['authorid']]['height_7ree']>$vars_7ree['lineheight_7ree'] ? 1 : 0; 
            			$badgelist_7ree[$postlist_7ree['authorid']]['height_7ree'] = min($badgelist_7ree[$postlist_7ree['authorid']]['height_7ree'],$vars_7ree['lineheight_7ree']);
            			include template('badge_7ree:badge_sideinfo_7ree');
						$return[] = trim($return_7ree);

            		}   
	  			}

				return $return;

		}


		function viewthread_sidebottom_output(){
				global $_G,$postlist,$post;

				$vars_7ree = $_G['cache']['plugin']['badge_7ree'];
				$exttitle_7ree = $_G['setting']['extcredits'][$vars_7ree['ext_7ree']][title];
				$return = array();
				if($vars_7ree['lefttop_7ree']<>'bottom') return $return;
				$authorids_7ree=array();
				foreach($postlist as $pid=>$postinfo_7ree){
					$authorids_7ree[] = $postinfo_7ree['authorid'];
				}
				$authorids_7ree = dimplode(array_filter(array_unique($authorids_7ree)));
				
				 $query = DB::query("SELECT l.*, m.*  FROM ".DB::table('badge_log_7ree')." l
											LEFT JOIN ".DB::table('badge_main_7ree')." m ON. m.id_7ree = l.did_7ree
											WHERE l.uid_7ree IN($authorids_7ree) AND l.status_7ree = 2 AND m.onoff_7ree = 1
											ORDER BY l.time_7ree DESC");
					while($table_7ree = DB::fetch($query)){
							$table_7ree['time_7ree'] = gmdate( lang('plugin/badge_7ree', 'php_lang_timeformat4_7ree'), $table_7ree['time_7ree'] + $_G['setting']['timeoffset'] * 3600 ); 
							$table_7ree['detail2_7ree'] = str_replace(array('#var1_7ree#','#var2_7ree#','#num1_7ree#','#num2_7ree#'), array($table_7ree['var1_7ree'],$table_7ree['var2_7ree'],$table_7ree['num1_7ree'],$table_7ree['num2_7ree']), $table_7ree['detail_7ree']);
							$badgelist0_7ree[$table_7ree['uid_7ree']][] = $table_7ree;
           			} 
           			
			
				if(is_array($postlist) && $vars_7ree[agreement_7ree]) {	
            		foreach($postlist as $key => $postlist_7ree) {
            			$badgelist_7ree[$postlist_7ree['authorid']]['badge_7ree']= $badgelist0_7ree[$postlist_7ree['authorid']];
            			$badgelist_7ree[$postlist_7ree['authorid']]['badge_num'] = count($badgelist0_7ree[$postlist_7ree['authorid']]);
            			$badgelist_7ree[$postlist_7ree['authorid']]['height_7ree'] = ceil($badgelist_7ree[$postlist_7ree['authorid']]['badge_num']/4)*40;
            			$badgelist_7ree[$postlist_7ree['authorid']]['btn_on_7ree'] = $badgelist_7ree[$postlist_7ree['authorid']]['height_7ree']>$vars_7ree['lineheight_7ree'] ? 1 : 0; 
            			$badgelist_7ree[$postlist_7ree['authorid']]['height_7ree'] = min($badgelist_7ree[$postlist_7ree['authorid']]['height_7ree'],$vars_7ree['lineheight_7ree']);
            			include template('badge_7ree:badge_sideinfo_7ree');
						$return[] = trim($return_7ree);
            		}   
	  			}

				return $return;

		}

		function space_card_bottom_output(){
				global $_G;	
				$vars_7ree = $_G['cache']['plugin']['badge_7ree'];
				$exttitle_7ree = $_G['setting']['extcredits'][$vars_7ree['ext_7ree']][title];
				$return = "";
				
				$_GET['username'] = daddslashes(dhtmlspecialchars($_GET['username']));
					
				if($vars_7ree['agreement_7ree'] && ($_GET['uid'] || $_GET['username'])) {
					
				
					
					if($_GET['uid']){
						$uid_7ree = intval($_GET['uid']);
					}else{
						$uid_7ree = DB::result_first("SELECT uid FROM ".DB::table('common_member')." WHERE username = '{$_GET[username]}' LIMIT 1");
					}
					
					$query = DB::query("SELECT l.*, m.name_7ree, m.logo_7ree  FROM ".DB::table('badge_log_7ree')." l
											LEFT JOIN ".DB::table('badge_main_7ree')." m ON. m.id_7ree = l.did_7ree
											WHERE l.uid_7ree = '{$uid_7ree}' AND l.status_7ree = 2 AND m.onoff_7ree = 1
											ORDER BY l.time_7ree DESC LIMIT 7");
					while($table_7ree = DB::fetch($query)){
							$table_7ree['time_7ree'] = gmdate( lang('plugin/badge_7ree', 'php_lang_timeformat4_7ree'), $table_7ree['time_7ree'] + $_G['setting']['timeoffset'] * 3600 ); 
							$badgelist_7ree[] = $table_7ree;
           			} 
					
					if(count($badgelist_7ree)) include template('badge_7ree:badge_cardinfo_7ree');
				}

				
				return $return;
		
		
		}


		function space_profile_baseinfo_top_output(){
				global $_G;
				$vars_7ree = $_G['cache']['plugin']['badge_7ree'];
				$exttitle_7ree = $_G['setting']['extcredits'][$vars_7ree['ext_7ree']]['title'];
				$return = "";
				
				$_GET['username'] = daddslashes(dhtmlspecialchars($_GET['username']));
				
				if($vars_7ree['agreement_7ree'] && ($_GET['uid'] || $_GET['username'])) {
					
					if($_GET['uid']){
						$uid_7ree = intval($_GET['uid']);
					}else{
						$uid_7ree = DB::result_first("SELECT uid FROM ".DB::table('common_member')." WHERE username = '{$_GET[username]}' LIMIT 1");
					}

					$query = DB::query("SELECT l.*, m.*  FROM ".DB::table('badge_log_7ree')." l
											LEFT JOIN ".DB::table('badge_main_7ree')." m ON. m.id_7ree = l.did_7ree
											WHERE l.uid_7ree = '{$uid_7ree}' AND l.status_7ree = 2 AND m.onoff_7ree = 1
											ORDER BY l.time_7ree DESC");
					while($table_7ree = DB::fetch($query)){
							$table_7ree['time_7ree'] = gmdate( lang('plugin/badge_7ree', 'php_lang_timeformat4_7ree'), $table_7ree['time_7ree'] + $_G['setting']['timeoffset'] * 3600 ); 
							$table_7ree['detail2_7ree'] = str_replace(array('#var1_7ree#','#var2_7ree#','#num1_7ree#','#num2_7ree#'), array($table_7ree['var1_7ree'],$table_7ree['var2_7ree'],$table_7ree['num1_7ree'],$table_7ree['num2_7ree']), $table_7ree['detail_7ree']); 
							$badgelist_7ree[] = $table_7ree;
           			} 
					
					include template('badge_7ree:badge_profileinfo_7ree');
					
				}

				
				return $return;
		
		
		}
		
}


class plugin_badge_7ree_forum extends plugin_badge_7ree{
}		

class plugin_badge_7ree_home extends plugin_badge_7ree{
}

class plugin_badge_7ree_group extends plugin_badge_7ree{
}



?>