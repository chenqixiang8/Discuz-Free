<?php

/*
	(C)2006-2021 dism.taobao.com
	This is NOT a freeware, use is subject to license terms
	Update: 2021/5/1 13:46
	Agreement: http://dism.taobao.com/?@7.developer.doc/agreement_7ree_html
	More Plugins: http://dism.taobao.com/?@7ree
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$template_return_7ree = "";
$extcredit_7ree = "";
$thisextcredit_7ree = "";
$remain_7ree = "";
$isfinish_7ree = "";
$tip_7ree = "";


//�ض����ͻ���ģ���������////////////

if($template_7ree==1){
		foreach ($_G['setting']['extcredits'] as $key_7ree => $extcredits_7ree){
			$isselect_7ree = $var1_7ree == $key_7ree ? "SELECTED" : "";
			$option_string_7ree = $option_string_7ree . "<option value='$key_7ree' {$isselect_7ree}>$extcredits_7ree[title]</option>";
		}
		foreach ($_G['setting']['extcredits'] as $key_7ree => $extcredits_7ree){
			$isselect2_7ree = $var2_7ree == $key_7ree ? "SELECTED" : "";
			$option_string2_7ree = $option_string2_7ree . "<option value='$key_7ree' {$isselect2_7ree}>$extcredits_7ree[title]</option>";
		}

		$template_return_7ree = "
	
<table cellspacing='10' cellpadding='10' width='100%'>
	<tr style='height:40px;' class='tbmu'>
		<td width='150px'><b >".lang('plugin/badge_7ree','php_lang_kuozhanjifien_7ree')."</b> <font color='red'>*</font><br>#var1_7ree#</td>
		<td>
			<select id='var1_7ree' name='var1_7ree' class='px vm input_select_7ree'>
			$option_string_7ree
			</select>
		</td>
	</tr>
		<tr style='height:40px;' class='tbmu'>
		<td width='150px'><b >".lang('plugin/badge_7ree','php_lang_jifienyaoqiu_7ree')."</b> <font color='red'>*</font><br>#num1_7ree#</td>
		<td><input type='text' value='$num1_7ree' id='num1_7ree' name='num1_7ree' class='px vm input_text_7ree'>
		</td>
	</tr>
	<tr style='height:40px;' class='tbmu'>
		<td width='150px'><b >".lang('plugin/badge_7ree','php_lang_kuozhanjifien2_7ree')."</b> <font color='red'>*</font><br>#var2_7ree#</td>
		<td>
			<select id='var2_7ree' name='var2_7ree' class='px vm input_select_7ree'>
			$option_string2_7ree
			</select>
		</td>
	</tr>
		<tr style='height:40px;' class='tbmu'>
		<td width='150px'><b >".lang('plugin/badge_7ree','php_lang_jifienyaoqiu2_7ree')."</b> <font color='red'>*</font><br>#num2_7ree#</td>
		<td><input type='text' value='$num2_7ree' id='num2_7ree' name='num2_7ree' class='px vm input_text_7ree'>
		<br>".lang('plugin/badge_7ree','php_lang_jifen2tip9_7ree')."
		</td>
	</tr>
</table>
";
}

if($uid_7ree){//�����ж�����
	$extcredit_7ree =  'extcredits'.$var1_7ree;
	$extcredit2_7ree =  'extcredits'.$var2_7ree;
	$thisextcredit_7ree = DB::fetch_first("SELECT {$extcredit_7ree},{$extcredit2_7ree} FROM ".DB::table('common_member_count')." WHERE uid='{$uid_7ree}'");
	$remain_7ree = $num1_7ree - $thisextcredit_7ree[$extcredit_7ree];
	$remain2_7ree = $num2_7ree - $thisextcredit_7ree[$extcredit2_7ree];
	
	//////////�������//////////////////////
	//�Ƿ񸴺˻�������
	$isfinish_7ree = $remain_7ree <=0 && $remain2_7ree <=0  ? 1 : 0;
	if($remain_7ree>0){
		$remain_tip=$remain_7ree.$_G['setting']['extcredits'][$var1_7ree]['title'];
	}else{
		$remain_tip="";
	}
	if($remain2_7ree>0){
		$remain2_tip=$remain2_7ree.$_G['setting']['extcredits'][$var2_7ree]['title'];
	}else{
		$remain2_tip="";
	}
	if($remain_tip && $remain2_tip){
		$hetip_7ree=lang('plugin/badge_7ree','php_lang_he_7ree');
	}else{
		$hetip_7ree='';
	}
	//��ɽ�����ʾ
	$tip_7ree = $isfinish_7ree ? lang('plugin/badge_7ree','php_lang_jifen2tip1_7ree').$_G['username'].lang('plugin/badge_7ree','php_lang_jifen2tip2_7ree'):lang('plugin/badge_7ree','php_lang_jifen2tip3_7ree').$_G['username'].lang('plugin/badge_7ree','php_lang_jifen2tip4_7ree').$remain_tip.$hetip_7ree.$remain2_tip.lang('plugin/badge_7ree','php_lang_jifen2tip5_7ree');
	
	//���л���������⴦��
	//˫���ֻ��²�֧��
    
}
//From: Dism��taobao��com
?>