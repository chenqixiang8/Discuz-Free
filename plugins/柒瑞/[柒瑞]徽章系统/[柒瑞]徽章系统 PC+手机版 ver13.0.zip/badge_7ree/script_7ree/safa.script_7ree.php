<?php

/*
	(C)2006-2021 dism.taobao.com
	This is NOT a freeware, use is subject to license terms
	Update: 2021/5/1 13:50
	Agreement: http://dism.taobao.com/?@7.developer.doc/agreement_7ree_html
	More Plugins: http://dism.taobao.com/?@7ree
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


$template_return_7ree = "";
$extcredit_7ree = "";
$thisextcredit_7ree = "";
$remain_7ree = "";
$isfinish_7ree = "";
$tip_7ree = "";


//�ض����ͻ���ģ���������////////////

if($template_7ree==1){
	
		$select1_7ree = $num1_7ree == 604800 ? "SELECTED" : "";
		$select2_7ree = $num1_7ree == 2592000 ? "SELECTED" : "";
		$select3_7ree = $num1_7ree == 7776000 ? "SELECTED" : "";
							
		$template_return_7ree = "
	
	
<table cellspacing='10' cellpadding='10' width='100%'>
	<tr style='height:40px;' class='tbmu'>
		<td width='150px'><b >".lang('plugin/badge_7ree','php_lang_shafashuliang_7ree')."</b> <font color='red'>*</font><br>#var1_7ree#</td>
		<td><font color='red'>".lang('plugin/badge_7ree','php_lang_shafawarning_7ree')."</font>	
			<br><input id='var1_7ree' name='var1_7ree' class='px vm px vm input_text_7ree' value='{$var1_7ree}'>
			<br>".lang('plugin/badge_7ree','php_lang_shafatiaojian_7ree')."
		</td>
	</tr>
	<tr style='height:40px;' class='tbmu'>
		<td width='150px'><b >".lang('plugin/badge_7ree','php_lang_shijianxianzhi_7ree')."</b> <font color='red'>*</font><br>#var1_7ree#</td>
		<td>
			<select id='num1_7ree' name='num1_7ree' class='px vm input_select_7ree'>
			<option value='604800' {$select1_7ree}>".lang('plugin/badge_7ree','php_lang_yizhoushijian_7ree')."</option>
			<option value='2592000' {$select2_7ree}>".lang('plugin/badge_7ree','php_lang_yiyueshijian_7ree')."</option>
			<option value='7776000' {$select3_7ree}>".lang('plugin/badge_7ree','php_lang_sanyueshijian_7ree')."</option>
			</select>
		</td>
	</tr>			
</table>	
";
}



if($uid_7ree){//�����ж�����
	$shafa_num_7ree = 0;
	$postlimit_7ree = DB::result_first("SELECT posts FROM ".DB::table('common_member_count')." WHERE uid='{$uid_7ree}'");
	$query = DB::query("SELECT tid FROM ".DB::table('forum_post')." WHERE first = 0 AND authorid = '{$uid_7ree}' AND dateline > $_G['timestamp'] - $num1_7ree LIMIT {$postlimit_7ree}");
		while($table_7ree = DB::fetch($query)){	
			$allshafa_7ree[] = $table_7ree[tid];
		}
        $numtest = count($allshafa_7ree);
		$allshafa_7ree = array_filter(array_unique($allshafa_7ree));
		foreach ($allshafa_7ree as $allshafa_value){
			$authoruid_7ree = DB::result_first("SELECT authorid FROM ".DB::table('forum_post')." WHERE first = '0' AND tid = '{$allshafa_value}' AND dateline > $_G['timestamp'] - $num1_7ree ORDER BY pid LIMIT 1");
			if($authoruid_7ree == $uid_7ree) $shafa_num_7ree = $shafa_num_7ree + 1;
		}
		

	$remain_7ree = $var1_7ree - $shafa_num_7ree;
	
	//////////�������//////////////////////
	//�Ƿ񸴺˻�������
	$isfinish_7ree = $remain_7ree <=0 ? 1 : 0;
	//��ɽ�����ʾ
	$tip_7ree = $isfinish_7ree ? lang('plugin/badge_7ree','php_lang_shafatip1_7ree').$_G['username'].lang('plugin/badge_7ree','php_lang_shafatip2_7ree').$shafa_num_7ree.lang('plugin/badge_7ree','php_lang_shafatip3_7ree') :lang('plugin/badge_7ree','php_lang_shafatip4_7ree').$_G['username'].lang('plugin/badge_7ree','php_lang_shafatip5_7ree').$shafa_num_7ree.lang('plugin/badge_7ree','php_lang_shafatip6_7ree').$remain_7ree.lang('plugin/badge_7ree','php_lang_shafatip7_7ree');
	
	//���л���������⴦��
    if($isfinish_7ree && COUNT($upgrade_array)){
    	  $thislevel_7ree = 0;
          foreach($upgrade_array AS $key => $upgrade_value){
          	if($shafa_num_7ree <= $upgrade_value){
          		$thislevel_7ree = $key + 1; 
          		break;
          	}
          }
          if($thislevel_7ree) DB::query("UPDATE ".DB::table('badge_log_7ree')." SET level_7ree = '{$thislevel_7ree}' WHERE uid_7ree={$uid_7ree} AND did_7ree={$did_7ree}");
    }

}
//From: dis'.'m.tao'.'bao.com
?>