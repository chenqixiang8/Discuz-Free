<?php

/*
	(C)2006-2021 dism.taobao.com
	This is NOT a freeware, use is subject to license terms
	Update: 2021/5/1 13:44
	Agreement: http://dism.taobao.com/?@7.developer.doc/agreement_7ree_html
	More Plugins: http://dism.taobao.com/?@7ree
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$template_return_7ree = "";
$extcredit_7ree = "";
$thisextcredit_7ree = "";
$remain_7ree = "";
$isfinish_7ree = "";
$tip_7ree = "";

$pluginonoff_7ree = DB::result_first("SELECT available FROM ".DB::table('common_plugin')." WHERE identifier = 'jingcai_7ree'");
//�ض����ͻ���ģ���������////////////

if($template_7ree==1){

	if($pluginonoff_7ree==1){
					
		$check1_7ree = (!$var1_7ree || $var1_7ree == 1) ? " checked='true' ":"";
		$check2_7ree = $var1_7ree == 2 ? " checked='true' ":"";
					
		$template_return_7ree = "
	
<table cellspacing='10' cellpadding='10' width='100%'>
	<tr style='height:40px;' class='tbmu'>
		<td width='150px'><b>".lang('plugin/badge_7ree','php_lang_jingcaifanwei_7ree')."</b> <font color='red'>*</font><br>#var1_7ree#</td>
		<td>
			<input type='radio' value='1' name='var1_7ree' id='var1_7ree' {$check1_7ree}> ".lang('plugin/badge_7ree','php_lang_jingcaifanwei1_7ree')."
			<input type='radio' value='2' name='var1_7ree' id='var1_7ree' style='margin-left:50px;' {$check2_7ree}> ".lang('plugin/badge_7ree','php_lang_jingcaifanwei2_7ree')."
		</td>
	</tr>
	<tr style='height:40px;' class='tbmu'>
		<td width='150px'><b>".lang('plugin/badge_7ree','php_lang_jingcaishuliang_7ree')."</b> <font color='red'>*</font><br>#num1_7ree#</td>
		<td>
			<input id='num1_7ree' name='num1_7ree' class='px vm px vm input_text_7ree' value='{$num1_7ree}'>
			<br>".lang('plugin/badge_7ree','php_lang_jingcaidanwei_7ree').lang('plugin/badge_7ree','php_lang_jingcaiyaoqiu_7ree')."
		</td>
	</tr>
</table>	
";
	}else{
		$template_return_7ree = "<table cellspacing='10' cellpadding='10' width='100%'>
	<tr style='height:40px;' class='tbmu'>
		<td width='150px'></td>
		<td><div class='notice'>".lang('plugin/badge_7ree','php_lang_errortip_plugins_7ree')."</div>
		</td>
	</tr>
</table>";
	}		
			
			
}



if($uid_7ree){//�����ж�����
	$jingcai_7ree = 0;
	if($var1_7ree==1){
		$jcwhere_7ree = "";
	}elseif($var1_7ree==2){
		$jcwhere_7ree = "AND log_reward_7ree > 0 AND mywin_7ree<>'d' ";
	}
    $jingcai_7ree = DB::result_first("SELECT COUNT(*) FROM ".DB::table('jingcai_log_7ree')." WHERE uid_7ree='{$uid_7ree}' ".$jcwhere_7ree);
	$remain_7ree = $num1_7ree - $jingcai_7ree;
	
	//////////�������//////////////////////
	//�Ƿ񸴺˻�������
	$isfinish_7ree = $remain_7ree <=0 ? 1 : 0;
	//��ɽ�����ʾ
	$tip_7ree = $isfinish_7ree ? lang('plugin/badge_7ree','php_lang_jingcaitip1_7ree').$_G['username'].lang('plugin/badge_7ree','php_lang_jingcaitip2_7ree').$jingcai_7ree.lang('plugin/badge_7ree','php_lang_jingcaitip3_7ree'):lang('plugin/badge_7ree','php_lang_jingcaitip4_7ree').$_G['username'].lang('plugin/badge_7ree','php_lang_jingcaitip5_7ree').$jingcai_7ree.lang('plugin/badge_7ree','php_lang_jingcaitip6_7ree').$remain_7ree.lang('plugin/badge_7ree','php_lang_jingcaitip7_7ree');
	
	//���л���������⴦��
    if($isfinish_7ree && COUNT($upgrade_array)){
    	  $thislevel_7ree = 0;
          foreach($upgrade_array AS $key => $upgrade_value){
          	if($jingcai_7ree <= $upgrade_value){
          		$thislevel_7ree = $key + 1; 
          		break;         	
          	}
          }
          if($thislevel_7ree) DB::query("UPDATE ".DB::table('badge_log_7ree')." SET level_7ree = '{$thislevel_7ree}' WHERE uid_7ree={$uid_7ree} AND did_7ree={$did_7ree}");
    }	

}


?>