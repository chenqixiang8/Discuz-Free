<?php

/*
	(C)2006-2021 dism.taobao.com
	This is NOT a freeware, use is subject to license terms
	Update: 2021/5/1 13:48
	Agreement: http://dism.taobao.com/?@7.developer.doc/agreement_7ree_html
	More Plugins: http://dism.taobao.com/?@7ree
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$template_return_7ree = "";
$extcredit_7ree = "";
$thisextcredit_7ree = "";
$remain_7ree = "";
$isfinish_7ree = "";
$tip_7ree = "";


//�ض����ͻ���ģ���������////////////

if($template_7ree==1){
	
	$ck1_7ree = $ck2_7ree = '';
	if($var1_7ree==1){
		$ck1_7ree = "checked";
	}elseif($var1_7ree==2){
		$ck2_7ree = "checked";
	}else{
		$ck1_7ree = $ck2_7ree = '';
	}
		$template_return_7ree = "
	
<table cellspacing='10' cellpadding='10' width='100%'>
	<tr style='height:40px;' class='tbmu'>
		<td width='150px'><b >".lang('plugin/badge_7ree','php_lang_touxiangyaoqiu_7ree')."</b> <font color='red'>*</font><br>#var1_7ree#</td>
		<td>
			<input type='radio' id='var1_7ree' name='var1_7ree' value='1' ".$ck1_7ree.">".lang('plugin/badge_7ree','php_lang_youtouxiang_7ree')."<span class='pipe'>|</span>
			<input type='radio' id='var1_7ree' name='var1_7ree' value='2' ".$ck2_7ree.">".lang('plugin/badge_7ree','php_lang_wutouxiang_7ree')."
			<br>".lang('plugin/badge_7ree','php_lang_lingquyaoqiu_7ree')."
		</td>
	</tr>
</table>	
";
}



if($uid_7ree){//�����ж�����
	$avatar_7ree = '';
	$avatar_7ree = avatar($uid_7ree,'small',TRUE,FALSE,TRUE);
	
	//////////�������//////////////////////
	//�Ƿ񸴺˻�������
	
	$ch = curl_init(); 
	$timeout = 10; 
	curl_setopt($ch, CURLOPT_URL, $avatar_7ree); 
	curl_setopt($ch, CURLOPT_HEADER, 1); 
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout); 

	$contents = curl_exec($ch);
	if (preg_match("/404/", $contents)){
		$isfinish_7ree = 0 ;
	}else{
		$isfinish_7ree = 1 ;
	}

	//��ɽ�����ʾ
	$tip_7ree = $isfinish_7ree ? lang('plugin/badge_7ree','php_lang_touxiangtip1_7ree').$_G['username'].lang('plugin/badge_7ree','php_lang_touxiangtip2_7ree'):lang('plugin/badge_7ree','php_lang_touxiangtip3_7ree').$_G['username'].lang('plugin/badge_7ree','php_lang_touxiangtip4_7ree');
	//���л���������⴦��
    
    


}


?>