<?php

/*
	(C)2006-2021 dism.taobao.com
	This is NOT a freeware, use is subject to license terms
	Update: 2021/5/1 13:51
	Agreement: http://dism.taobao.com/?@7.developer.doc/agreement_7ree_html
	More Plugins: http://dism.taobao.com/?@7ree
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


$template_return_7ree = "";
$extcredit_7ree = "";
$thisextcredit_7ree = "";
$remain_7ree = "";
$isfinish_7ree = "";
$tip_7ree = "";


//�ض����ͻ���ģ���������////////////

if($template_7ree==1){


	require_once libfile('function/forumlist');
	
	//$var1_7ree = array($var1_7ree);


		$template_return_7ree = "
	
<table cellspacing='10' cellpadding='10' width='100%'>
	
		<tr style='height:40px;' class='tbmu'>
		<td width='150px'><b >".lang('plugin/badge_7ree','php_lang_zhidingtid_7ree')."</b> <font color='red'>*</font><br>#var1_7ree#</td>
		<td>
			<input type='text' id='var1_7ree' name='var1_7ree' value='{$var1_7ree}' class='px vm px vm input_text_7ree' >
		</td>
	</tr>
	
	<tr style='height:40px;' class='tbmu'>
		<td width='150px'><b >".lang('plugin/badge_7ree','php_lang_replyshu_7ree')."</b> <font color='red'>*</font><br>#num1_7ree#</td>
		<td>
			<input id='num1_7ree' name='num1_7ree' class='px vm px vm input_text_7ree' value='{$num1_7ree}'>
			<br>".lang('plugin/badge_7ree','php_lang_replytiaojian_7ree')."
		</td>
	</tr>
</table>	
";
}



if($uid_7ree){//�����ж�����
	
	if($var1_7ree){
		//$posts_7ree = DB::result_first("SELECT replies FROM ".DB::table('forum_thread')." WHERE tid = '{$var1_7ree}' ORDER BY replies DESC limit 1");
		$posts_7ree = DB::result_first("SELECT COUNT(*) FROM ".DB::table('forum_post')." WHERE authorid = '{$uid_7ree}' AND tid='{$var1_7ree}'");
	}else{
		$posts_7ree = DB::result_first("SELECT posts FROM ".DB::table('common_member_count')." WHERE uid = '{$uid_7ree}'");
	}
	

	$posts_7ree = $posts_7ree ? intval($posts_7ree) : 0;
	$remain_7ree = $num1_7ree - $posts_7ree;
	
	//////////�������//////////////////////
	//�Ƿ񸴺˻�������
	$isfinish_7ree = $remain_7ree <=0 ? 1 : 0;
	//��ɽ�����ʾ
	$tip_7ree = $isfinish_7ree ? lang('plugin/badge_7ree','php_lang_replytip1_7ree').$_G['username'].lang('plugin/badge_7ree','php_lang_replytip2_7ree').$posts_7ree.lang('plugin/badge_7ree','php_lang_replytip3_7ree'):lang('plugin/badge_7ree','php_lang_replytip4_7ree').$_G['username'].lang('plugin/badge_7ree','php_lang_replytip5_7ree').$posts_7ree.lang('plugin/badge_7ree','php_lang_replytip6_7ree').$remain_7ree.lang('plugin/badge_7ree','php_lang_replytip7_7ree');
	
	//���л���������⴦��
    if($isfinish_7ree && COUNT($upgrade_array)){
    	  $thislevel_7ree = 0;
          foreach($upgrade_array AS $key => $upgrade_value){
          	if($posts_7ree <= $upgrade_value){
          		$thislevel_7ree = $key + 1; 
          		break;
          	}
          }
          if($thislevel_7ree) DB::query("UPDATE ".DB::table('badge_log_7ree')." SET level_7ree = '{$thislevel_7ree}' WHERE uid_7ree={$uid_7ree} AND did_7ree={$did_7ree}");
    }		

}
//From: dis'.'m.tao'.'bao.com
?>