<?php

/*
	(C)2006-2021 dism.taobao.com
	This is NOT a freeware, use is subject to license terms
	Update: 2021/5/1 13:51
	Agreement: http://dism.taobao.com/?@7.developer.doc/agreement_7ree_html
	More Plugins: http://dism.taobao.com/?@7ree
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$template_return_7ree = "";
$extcredit_7ree = "";
$thisextcredit_7ree = "";
$remain_7ree = "";
$isfinish_7ree = "";
$tip_7ree = "";

$pluginonoff_7ree = DB::result_first("SELECT available FROM ".DB::table('common_plugin')." WHERE identifier = 'dsu_paulsign'");
//�ض����ͻ���ģ���������////////////

if($template_7ree==1){

	if($pluginonoff_7ree==1){
		$check1_7ree = (!$var1_7ree || $var1_7ree == 1) ? " checked='true' ":"";
		$check2_7ree = $var1_7ree == 2 ? " checked='true' ":"";
		$template_return_7ree = "
	
<table cellspacing='10' cellpadding='10' width='100%'>
	<tr style='height:40px;' class='tbmu'>
		<td width='150px'><b>".lang('plugin/badge_7ree','php_lang_qiandaofanwei_7ree')."</b> <font color='red'>*</font><br>#var1_7ree#</td>
		<td>
			<input type='radio' value='1' name='var1_7ree' id='var1_7ree' {$check1_7ree}> ".lang('plugin/badge_7ree','php_lang_qiandaofanwei1_7ree')."
			<input type='radio' value='2' name='var1_7ree' id='var1_7ree' style='margin-left:50px;' {$check2_7ree}> ".lang('plugin/badge_7ree','php_lang_qiandaofanwei2_7ree')."
		</td>
	</tr>
	<tr style='height:40px;' class='tbmu'>
		<td width='150px'><b>".lang('plugin/badge_7ree','php_lang_qiandaoshuliang_7ree')."</b> <font color='red'>*</font><br>#num1_7ree#</td>
		<td>
			<input id='num1_7ree' name='num1_7ree' class='px vm px vm input_text_7ree' value='{$num1_7ree}'>
			<br>".lang('plugin/badge_7ree','php_lang_qiandaodanwei_7ree').lang('plugin/badge_7ree','php_lang_qiandaoyaoqiu_7ree')."
		</td>
	</tr>
</table>	
";
	}else{
		$template_return_7ree = "<table cellspacing='10' cellpadding='10' width='100%'>
	<tr style='height:40px;' class='tbmu'>
		<td width='150px'></td>
		<td><div class='notice'>".lang('plugin/badge_7ree','php_lang_errortip_plugins_7ree')."</div>
		</td>
	</tr>
</table>";
	}		
			
			
}



if($uid_7ree){//�����ж�����
	$qiandao_7ree = 0;
	if($var1_7ree==1){
		$qiandao_7ree = DB::result_first("SELECT days FROM ".DB::table('dsu_paulsign')." WHERE uid='{$uid_7ree}' ");	
	}elseif($var1_7ree==2){
		$qiandao_7ree = DB::result_first("SELECT mdays FROM ".DB::table('dsu_paulsign')." WHERE uid='{$uid_7ree}' ");
	}

	$remain_7ree = $num1_7ree - $qiandao_7ree;
	
	//////////�������//////////////////////
	//�Ƿ񸴺˻�������
	$isfinish_7ree = $remain_7ree <=0 ? 1 : 0;
	//��ɽ�����ʾ
	$tip_7ree = $isfinish_7ree ? lang('plugin/badge_7ree','php_lang_qiandaotip1_7ree').$_G['username'].lang('plugin/badge_7ree','php_lang_qiandaotip2_7ree').$qiandao_7ree.lang('plugin/badge_7ree','php_lang_qiandaotip3_7ree'):lang('plugin/badge_7ree','php_lang_qiandaotip4_7ree').$_G['username'].lang('plugin/badge_7ree','php_lang_qiandaotip5_7ree').$qiandao_7ree.lang('plugin/badge_7ree','php_lang_qiandaotip6_7ree').$remain_7ree.lang('plugin/badge_7ree','php_lang_qiandaotip7_7ree');
	
	//���л���������⴦��
    if($isfinish_7ree && COUNT($upgrade_array)){
    	  $thislevel_7ree = 0;
          foreach($upgrade_array AS $key => $upgrade_value){
          	if($qiandao_7ree <= $upgrade_value){
          		$thislevel_7ree = $key + 1; 
          		break;         	
          	}
          }
          if($thislevel_7ree) DB::query("UPDATE ".DB::table('badge_log_7ree')." SET level_7ree = '{$thislevel_7ree}' WHERE uid_7ree={$uid_7ree} AND did_7ree={$did_7ree}");
    }
    
}


?>