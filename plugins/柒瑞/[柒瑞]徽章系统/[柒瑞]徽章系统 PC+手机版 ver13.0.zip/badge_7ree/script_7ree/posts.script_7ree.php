<?php

/*
	(C)2006-2021 dism.taobao.com
	This is NOT a freeware, use is subject to license terms
	Update: 2021/5/1 13:52
	Agreement: http://dism.taobao.com/?@7.developer.doc/agreement_7ree_html
	More Plugins: http://dism.taobao.com/?@7ree
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}



$template_return_7ree = "";
$extcredit_7ree = "";
$thisextcredit_7ree = "";
$remain_7ree = "";
$isfinish_7ree = "";
$tip_7ree = "";


//�ض����ͻ���ģ���������////////////

if($template_7ree==1){
					
			$check1_7ree = (!$var1_7ree || $var1_7ree == 1) ? " checked='true' ":"";
			$check2_7ree = $var1_7ree == 2 ? " checked='true' ":"";
			$check3_7ree = $var1_7ree == 3 ? " checked='true' ":"";
			$template_return_7ree = "
	
<table cellspacing='10' cellpadding='10' width='100%'>
	
	<tr style='height:40px;' class='tbmu'>
		<td width='130px'><b>".lang('plugin/badge_7ree','php_lang_tiezileixing_7ree')."</b></td>
		<td>
			<input type='radio' value='1' name='var1_7ree' id='var1_7ree' {$check1_7ree}> ".lang('plugin/badge_7ree','php_lang_zhutitiezi_7ree')."
			<input type='radio' value='2' name='var1_7ree' id='var1_7ree' style='margin-left:50px;' {$check2_7ree}> ".lang('plugin/badge_7ree','php_lang_huifutiezi_7ree')."
			<input type='radio' value='3' name='var1_7ree' id='var1_7ree' style='margin-left:50px;' {$check3_7ree}> ".lang('plugin/badge_7ree','php_lang_jinghuatiezi_7ree')."
		</td>
	</tr>
	
	<tr style='height:40px;' class='tbmu'>
		<td width='150px'><b >".lang('plugin/badge_7ree','php_lang_tiezishuliang_7ree')."</b> <font color='red'>*</font><br>#num1_7ree#</td>
		<td>
			<input id='num1_7ree' name='num1_7ree' class='px vm px vm input_text_7ree' value='{$num1_7ree}'>
			<br>".lang('plugin/badge_7ree','php_lang_tiezitiaojian_7ree')."
		</td>
	</tr>
</table>
";
}



if($uid_7ree){//�����ж�����

	$selectnum_7ree = "";
	$selectname_7ree = "";
		
	if($var1_7ree == 1){
		$selectnum_7ree = 'threads';
		$selectname_7ree = lang('plugin/badge_7ree','php_lang_zhutitiezi_7ree');
	}elseif($var1_7ree == 2){
		$selectnum_7ree = 'posts';
		$selectname_7ree = lang('plugin/badge_7ree','php_lang_huifutiezi_7ree');
	}elseif($var1_7ree == 3){
		$selectnum_7ree = 'digestposts';
		$selectname_7ree = lang('plugin/badge_7ree','php_lang_jinghuatiezi_7ree');
	}
	
	$thisnum1_7ree = DB::result_first("SELECT {$selectnum_7ree} FROM ".DB::table('common_member_count')." WHERE uid=$uid_7ree");
	$remain_7ree = $num1_7ree - $thisnum1_7ree;
	
	//////////�������//////////////////////
	//�Ƿ񸴺˻�������
	$isfinish_7ree = $remain_7ree <=0 ? 1 : 0;
	//��ɽ�����ʾ
	$tip_7ree = $isfinish_7ree ? lang('plugin/badge_7ree','php_lang_tiezitip1_7ree').$_G['username'].lang('plugin/badge_7ree','php_lang_tiezitip2_7ree').$selectname_7ree.$thisnum1_7ree.lang('plugin/badge_7ree','php_lang_tiezitip3_7ree'):lang('plugin/badge_7ree','php_lang_tiezitip4_7ree').$_G['username'].lang('plugin/badge_7ree','php_lang_tiezitip5_7ree').$thisnum1_7ree.$selectname_7ree.lang('plugin/badge_7ree','php_lang_tiezitip6_7ree').$remain_7ree.lang('plugin/badge_7ree','php_lang_tiezitip7_7ree');
	
	//���л���������⴦��
    if($isfinish_7ree && COUNT($upgrade_array)){
    	  $thislevel_7ree = 0;
          foreach($upgrade_array AS $key => $upgrade_value){
          	if($thisnum1_7ree <= $upgrade_value){
          		$thislevel_7ree = $key + 1; 
          		break;         	
          	}
          }
          if($thislevel_7ree) DB::query("UPDATE ".DB::table('badge_log_7ree')." SET level_7ree = '{$thislevel_7ree}' WHERE uid_7ree={$uid_7ree} AND did_7ree={$did_7ree}");
    }			

}
//From: Dism��taobao��com
?>