<?php

/*
	(C)2006-2021 dism.taobao.com
	This is NOT a freeware, use is subject to license terms
	Update: 2021/5/1 13:53
	Agreement: http://dism.taobao.com/?@7.developer.doc/agreement_7ree_html
	More Plugins: http://dism.taobao.com/?@7ree
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$template_return_7ree = "";
$extcredit_7ree = "";
$thisextcredit_7ree = "";
$remain_7ree = "";
$isfinish_7ree = "";
$tip_7ree = "";

$pluginonoff_7ree = DB::result_first("SELECT available FROM ".DB::table('common_plugin')." WHERE identifier = 'olgift_7ree'");
//�ض����ͻ���ģ���������////////////

if($template_7ree==1){

	if($pluginonoff_7ree==1){
					
		$check1_7ree = (!$var1_7ree || $var1_7ree == 1) ? " checked='true' ":"";
		$check2_7ree = $var1_7ree == 2 ? " checked='true' ":"";
		$template_return_7ree = "
	
<table cellspacing='10' cellpadding='10' width='100%'>
	<tr style='height:40px;' class='tbmu'>
		<td width='150px'><b>".lang('plugin/badge_7ree','php_lang_libaoshuliang_7ree')."</b> <font color='red'>*</font><br>#num1_7ree#</td>
		<td>
			<input id='num1_7ree' name='num1_7ree' class='px vm px vm input_text_7ree' value='{$num1_7ree}'>
			<br>".lang('plugin/badge_7ree','php_lang_libaodanwei_7ree').lang('plugin/badge_7ree','php_lang_libaoyaoqiu_7ree')."
		</td>
	</tr>
</table>	
";
	}else{
		$template_return_7ree = "<table cellspacing='10' cellpadding='10' width='100%'>
	<tr style='height:40px;' class='tbmu'>
		<td width='150px'></td>
		<td><div class='notice'>".lang('plugin/badge_7ree','php_lang_errortip_plugins_7ree')."</div>
		</td>
	</tr>
</table>";
	}		
			
			
}



if($uid_7ree){//�����ж�����
	$libao_7ree = 0;
		$libao_7ree = DB::result_first("SELECT num_7ree FROM ".DB::table('olgift_rank_7ree')." WHERE uid_7ree='{$uid_7ree}' ");


	$remain_7ree = $num1_7ree - $libao_7ree;
	
	//////////�������//////////////////////
	//�Ƿ񸴺˻�������
	$isfinish_7ree = $remain_7ree <=0 ? 1 : 0;
	//��ɽ�����ʾ
	$tip_7ree = $isfinish_7ree ? lang('plugin/badge_7ree','php_lang_libaotip1_7ree').$_G['username'].lang('plugin/badge_7ree','php_lang_libaotip2_7ree').$libao_7ree.lang('plugin/badge_7ree','php_lang_libaotip3_7ree'):lang('plugin/badge_7ree','php_lang_libaotip4_7ree').$_G['username'].lang('plugin/badge_7ree','php_lang_libaotip5_7ree').$libao_7ree.lang('plugin/badge_7ree','php_lang_libaotip6_7ree').$remain_7ree.lang('plugin/badge_7ree','php_lang_libaotip7_7ree');
	
	//���л���������⴦��
    if($isfinish_7ree && COUNT($upgrade_array)){
    	  $thislevel_7ree = 0;
          foreach($upgrade_array AS $key => $upgrade_value){
          	if($libao_7ree <= $upgrade_value){
          		$thislevel_7ree = $key + 1; 
          		break;
          	}
          }
          if($thislevel_7ree) DB::query("UPDATE ".DB::table('badge_log_7ree')." SET level_7ree = '{$thislevel_7ree}' WHERE uid_7ree={$uid_7ree} AND did_7ree={$did_7ree}");
    }	
    
}


?>