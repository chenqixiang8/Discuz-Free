<?php
/*
	(C)2006-2016 dism.taobao.com
	This is NOT a freeware, use is subject to license terms
	Update: 2016/11/13 1:00
	Agreement: http://dism.taobao.com/?@7.developer.doc/agreement_7ree_html
	More Plugins: http://dism.taobao.com/?@7ree
*/


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

	@require_once(DISCUZ_ROOT.'./source/discuz_version.php');
	$cahcedir_7ree = DISCUZ_VERSION == "X2" ? './data/cache/cache_' : './data/sysdata/cache_';
	$cachename_7ree = "badge_fid_7ree";
	$cachfile_path = DISCUZ_ROOT.$cahcedir_7ree.$cachename_7ree.'.php';
	if(file_exists($cachfile_path)){
			unlink($cachfile_path);
	}



$sql = <<<EOF
	
DROP TABLE IF EXISTS `pre_badge_log_7ree`;

DROP TABLE IF EXISTS `pre_badge_main_7ree`;


EOF;

runquery($sql);

$finish = TRUE;

?>