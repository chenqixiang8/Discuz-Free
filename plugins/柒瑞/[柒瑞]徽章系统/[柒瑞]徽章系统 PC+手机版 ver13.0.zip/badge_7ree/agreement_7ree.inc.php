<?php

/*
	(C)2007-2020 [dism.taobao.com]
	This is NOT a freeware, use is subject to license terms
	Agreement: http://dism.taobao.com/?@7.developer.doc/agreement_7ree_html
	More Plugins: http://dism.taobao.com/?@7ree
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
echo "<script>window.location.href='https://dism.taobao.com/?@7.developer.doc/agreement_7ree_html';</script>";


?>