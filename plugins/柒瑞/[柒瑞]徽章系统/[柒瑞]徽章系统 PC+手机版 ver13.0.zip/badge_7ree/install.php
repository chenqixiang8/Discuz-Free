<?php
/*
	(C)2006-2017 dism.taobao.com
	This is NOT a freeware, use is subject to license terms
	Update: 2021/5/1 12:55
	Agreement: http://dism.taobao.com/?@7.developer.doc/agreement_7ree_html
	More Plugins: http://dism.taobao.com/?@7ree
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}


$sql = <<<EOF
	
CREATE TABLE IF NOT EXISTS `pre_badge_log_7ree` (
  `id_7ree` mediumint(8) NOT NULL auto_increment,
  `uid_7ree` mediumint(8) NOT NULL,
  `did_7ree` mediumint(8) NOT NULL,
  `time_7ree` int(10) NOT NULL,
  `status_7ree` tinyint(1) NOT NULL,
  `level_7ree` int(2) NOT NULL,    
  `view_7ree` tinyint(1) NOT NULL,
  PRIMARY KEY  (`id_7ree`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_badge_main_7ree` (
  `id_7ree` mediumint(8) NOT NULL auto_increment,
  `name_7ree` varchar(100) NOT NULL,
  `logo_7ree` varchar(250) NOT NULL,
  `detail_7ree` text NOT NULL,
  `group_7ree` varchar(250) NOT NULL,
  `fenlei_7ree` varchar(100) NOT NULL,
  `type_7ree` varchar(100) NOT NULL,
  `how_7ree` tinyint(1) NOT NULL,
  `var1_7ree` int(10) NOT NULL,
  `var2_7ree` int(10) NOT NULL,
  `num1_7ree` int(10) NOT NULL,
  `num2_7ree` int(10) NOT NULL,
  `upgrade_7ree` varchar(250) NOT NULL,
  `fid_7ree` text NOT NULL,
  `ext_7ree` mediumint(8) NOT NULL,
  `dateline_7ree` int(10) NOT NULL,
  `onoff_7ree` tinyint(1) NOT NULL,
  PRIMARY KEY  (`id_7ree`)
) ENGINE=MyISAM;


EOF;

runquery($sql);


$pluginid = 'badge_7ree';


$finish = TRUE;

?>