<?php

/*
	(C)2006-2014 dism.taobao.com
	This is NOT a freeware, use is subject to license terms
	Update: 15:49 2014/8/14
	Agreement: http://dism.taobao.com/?@7.developer.doc/agreement_7ree_html
	More Plugins: http://dism.taobao.com/?@7ree
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class badge_7ree_api {

	function forumdisplay_authorInfo() {
		global $_G;
		$vars_7ree = $_G['cache']['plugin']['badge_7ree'];
		$return = array();
		foreach($GLOBALS['threadlist'] as $thread) {
			$authorids_7ree[] = $thread['authorid'];
		}
		$authorids_7ree = dimplode(array_filter(array_unique($authorids_7ree)));
		$query = DB::query("SELECT l.*, m.*  FROM ".DB::table('badge_log_7ree')." l
											LEFT JOIN ".DB::table('badge_main_7ree')." m ON. m.id_7ree = l.did_7ree							
											WHERE l.uid_7ree IN($authorids_7ree) AND l.status_7ree = 2 AND m.onoff_7ree = 1
											ORDER BY l.time_7ree DESC");
		while($table_7ree = DB::fetch($query)){	
			if($i_7ree[$table_7ree['uid_7ree']]<6){
				$badgelist0_7ree[$table_7ree['uid_7ree']] .= "<img src='".$_G['siteurl']."/source/plugin/badge_7ree/badge_img/small/".$table_7ree['logo_7ree']."' style='width:17px;height:17px;margin:0px 0px 4px 3px;' border='0'>";
				$i_7ree[$table_7ree['uid_7ree']]=$i_7ree[$table_7ree['uid_7ree']]+1;
			}
        } 
        if(is_array($GLOBALS['threadlist']) && $vars_7ree['agreement_7ree']) {	
	        foreach($GLOBALS['threadlist'] as $key => $postlist_7ree) {
				$return[$postlist_7ree['authorid']] = $badgelist0_7ree[$postlist_7ree['authorid']];
				
			}   
	  	}
		return $return;
	}



	function viewthread_authorInfo() {
		global $_G;
		$vars_7ree = $_G['cache']['plugin']['badge_7ree'];
		$return = array();
		foreach($GLOBALS['postlist'] as $thread) {
			$authorids_7ree[] = $thread['authorid'];
		}
		$authorids_7ree = dimplode(array_filter(array_unique($authorids_7ree)));
		$query = DB::query("SELECT l.*, m.*  FROM ".DB::table('badge_log_7ree')." l
											LEFT JOIN ".DB::table('badge_main_7ree')." m ON. m.id_7ree = l.did_7ree
											WHERE l.uid_7ree IN($authorids_7ree) AND l.status_7ree = 2 AND m.onoff_7ree = 1
											ORDER BY l.time_7ree DESC");
		while($table_7ree = DB::fetch($query)){	
			if($i_7ree[$table_7ree['uid_7ree']]<3){
				$badgelist0_7ree[$table_7ree['uid_7ree']] .= "<img src='".$_G['siteurl']."/source/plugin/badge_7ree/badge_img/small/".$table_7ree['logo_7ree']."' style='width:17px;height:17px;margin:0px 0px 10px 3px;' border='0'>";
				$i_7ree[$table_7ree['uid_7ree']]=$i_7ree[$table_7ree['uid_7ree']]+1;
			}
        } 
        if(is_array($GLOBALS['postlist']) && $vars_7ree['agreement_7ree']) {
	        foreach($GLOBALS['postlist'] as $key => $postlist_7ree) {
				$return[$postlist_7ree['authorid']] = $badgelist0_7ree[$postlist_7ree['authorid']];
				
			}   
	  	}
		return $return;
	}



	function profile_authorInfo() {
		global $_G;
		$vars_7ree = $_G['cache']['plugin']['badge_7ree'];
		$return='';
		$_GET['uid'] = intval($_GET['uid']);
		if($_GET['uid'] && $vars_7ree['agreement_7ree']){
				$query = DB::query("SELECT l.*, m.name_7ree, m.logo_7ree  FROM ".DB::table('badge_log_7ree')." l
									LEFT JOIN ".DB::table('badge_main_7ree')." m ON. m.id_7ree = l.did_7ree							
									WHERE l.uid_7ree = '{$_GET[uid]}' AND l.status_7ree = 2 AND m.onoff_7ree = 1
									ORDER BY l.time_7ree DESC LIMIT 7");
				while($table_7ree = DB::fetch($query)){
						$return .= "<img src='".$_G['siteurl']."/source/plugin/badge_7ree/badge_img/small/".$table_7ree['logo_7ree']."' style='width:17px;height:17px;margin:0px 0px 12px 3px;' border='0'>";
           		} 
		}
		return $return;
	}



}
//From: dis'.'m.tao'.'bao.com
?>