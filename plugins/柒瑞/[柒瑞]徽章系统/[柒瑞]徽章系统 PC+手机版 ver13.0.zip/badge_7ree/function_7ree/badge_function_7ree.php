<?php

/*
	(C)2006-2021 dism.taobao.com
	This is NOT a freeware, use is subject to license terms
	Update: 2021/5/1 13:16
	Agreement: http://dism.taobao.com/?@7.developer.doc/agreement_7ree_html
	More Plugins: http://dism.taobao.com/?@7ree
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


//���·���fid��Ȩ����
	function badge_fidcache_7ree(){
		@require_once(DISCUZ_ROOT.'./source/discuz_version.php');
		$cahcedir_7ree = DISCUZ_VERSION == "X2" ? './data/cache/cache_' : './data/sysdata/cache_';
		$cachename_7ree = "badge_fid_7ree";
		@include DISCUZ_ROOT.$cahcedir_7ree.$cachename_7ree.'.php';
		require_once libfile('function/cache');
		
		$query = DB::query("SELECT id_7ree,fid_7ree FROM ".DB::table('badge_main_7ree')." WHERE fid_7ree!='' LIMIT 200");
				while($table_7ree = DB::fetch($query)) {
					$list_7ree['id_7ree']=$table_7ree['id_7ree'];
					$list_7ree['fid_7ree']=$table_7ree['fid_7ree'];
					$fidtable_7ree[]=$table_7ree;
				}
		$curdata_7ree= "\$fidcache_7ree = ".arrayeval($fidtable_7ree).";\n\n";
		writetocache("$cachename_7ree", $curdata_7ree);
	}


//���Ļ��º���
//����1�������Ӧ����ģ��


function badge_template_7ree($type_7ree,$var1_7ree,$var2_7ree,$num1_7ree,$num2_7ree){
	global $_G;
	$type_7ree = strcheck_7ree($type_7ree);
	if($type_7ree){
		$template_7ree=1;
		$var1_7ree = intval($var1_7ree);
		$var2_7ree = intval($var2_7ree);
		$num1_7ree = intval($num1_7ree);
		$num2_7ree = intval($num2_7ree);
		@include("source/plugin/badge_7ree/script_7ree/".$type_7ree.".script_7ree.php");
		
		$return_7ree = $template_return_7ree ? $template_return_7ree : "<div class='notice'>".lang('plugin/badge_7ree', 'php_lang_errortip_template_7ree')."</div>";
		
		return $return_7ree;
	}else{
		return;
	}
}
//����2���ж��Ƿ���ϻ�������,�����������ɵ�������ࣻ

function badge_test_7ree($type_7ree,$did_7ree,$uid_7ree,$var1_7ree,$num1_7ree,$var2_7ree,$num2_7ree,$upgrade_7ree,$ext_7ree){
	global $_G;
		$vars_7ree = $_G['cache']['plugin']['badge_7ree'];
	    $type_7ree = strcheck_7ree($type_7ree);
	    $upgrade_7ree = strcheck_7ree($upgrade_7ree);
	    $upgrade_array = $upgrade_7ree ? explode(",",$upgrade_7ree):array();
		$did_7ree = intval($did_7ree);
		$uid_7ree = intval($uid_7ree);
	if(!$type_7ree || !$uid_7ree || !$did_7ree) return;
		$return_7ree = array();
		
		$var1_7ree = intval($var1_7ree);
		$var2_7ree = intval($var2_7ree);
		$num1_7ree = intval($num1_7ree);
		$num2_7ree = intval($num2_7ree);
		$ext_7ree = intval($ext_7ree);
		

		@include("source/plugin/badge_7ree/script_7ree/".$type_7ree.".script_7ree.php");
			
		$isget_7ree = DB::fetch_first("SELECT time_7ree,status_7ree,level_7ree FROM ".DB::table('badge_log_7ree')." WHERE uid_7ree={$uid_7ree} AND did_7ree={$did_7ree}");


		if($ext_7ree && !$isget_7ree){//�ж��Ƿ���Ҫ���Ļ����Լ����������Ƿ��㹻��
		//�Զ��������͵Ļ����ظ��۷ּ�⣬���ѻ���򲻿۷�
			if($ext_7ree && $vars_7ree['ext_7ree'] ){
					$dbext_7ree = 'extcredits'.$vars_7ree['ext_7ree'];
					$membercount_7ree = DB::result_first("SELECT {$dbext_7ree} FROM ".DB::table('common_member_count')." WHERE uid='{$uid_7ree}'");
					if($membercount_7ree < $ext_7ree){
							$return_7ree['tip_7ree'] = lang('plugin/badge_7ree', 'php_lang_errMsgext_7ree'); 
							$return_7ree['isfinish_7ree'] = 0;
							return $return_7ree;
					}
			}
		}
		

		if(!$isget_7ree['status_7ree']){
			$return_7ree['status_7ree'] = $isfinish_7ree ? "status1_7ree" : ""; // ������ �� ��������
				
		}elseif($isget_7ree['status_7ree']=="1"){
			$return_7ree['status_7ree'] = "status2_7ree"; //������
			$isget_7ree['time_7ree'] = gmdate( lang('plugin/badge_7ree', 'php_lang_timeformat4_7ree'), $isget_7ree['time_7ree'] + $_G['setting']['timeoffset'] * 3600 );
			$tip_7ree = lang('plugin/badge_7ree', 'php_lang_applytip1_7ree').$isget_7ree['time_7ree'].lang('plugin/badge_7ree', 'php_lang_applytip2_7ree');
		}elseif($isget_7ree[status_7ree] =="2"){
			$return_7ree[status_7ree] = "status3_7ree"; //����ȡ
			$isget_7ree['time_7ree'] = gmdate( lang('plugin/badge_7ree', 'php_lang_timeformat4_7ree'), $isget_7ree['time_7ree'] + $_G['setting']['timeoffset'] * 3600 );
			$tip_7ree = lang('plugin/badge_7ree', 'php_lang_gettip1_7ree').$isget_7ree['time_7ree'].lang('plugin/badge_7ree', 'php_lang_gettip2_7ree');
			if($isget_7ree['level_7ree']){
				$tip_7ree .= lang('plugin/badge_7ree', 'php_lang_lvtips1_7ree').$isget_7ree['level_7ree'].lang('plugin/badge_7ree', 'php_lang_lvtips2_7ree');
			}
		}

		$return_7ree['tip_7ree'] = $tip_7ree; 
		$return_7ree['isfinish_7ree'] = $isfinish_7ree; //�Ƿ��������
		
		return $return_7ree;

	
}

function push_badge_7ree($did_7ree,$uid_7ree,$action_7ree){ //���Ż��º���
		global $_G;
		$vars_7ree = $_G['cache']['plugin']['badge_7ree'];
		$badge_test = array();
		$did_7ree = intval($did_7ree);
		$uid_7ree = intval($uid_7ree);
		$action_7ree = strcheck_7ree($action_7ree);
		$notification_7ree = "";
		if(!$did_7ree || !$uid_7ree) return;

	//	$action_7ree =  auto �Զ��� apply ���룻 push ���ţ�
	//�����ж�
	
	//1��ȡ������Ϣ��2����Ƿ������������
	$thisbadge_7ree = DB::fetch_first("SELECT * FROM ".DB::table('badge_main_7ree')." WHERE id_7ree={$did_7ree} LIMIT 1");
	
	if($thisbadge_7ree['id_7ree']) $badge_test = badge_test_7ree($thisbadge_7ree['type_7ree'],$did_7ree,$uid_7ree,$thisbadge_7ree['var1_7ree'],$thisbadge_7ree['num1_7ree'],$thisbadge_7ree['var2_7ree'],$thisbadge_7ree['num2_7ree'],$thisbadge_7ree['upgrade_7ree'],$thisbadge_7ree['ext_7ree']);

	//�ж��Ƿ���Ҫ���Ļ����Լ����������Ƿ��㹻��
	if($thisbadge_7ree['ext_7ree'] && $vars_7ree['ext_7ree'] ){
			if($action_7ree!="push"){//��������˻���ʱ�����ظ��۷��ж�
				$dbext_7ree = 'extcredits'.$vars_7ree['ext_7ree'];
				$membercount_7ree = DB::result_first("SELECT {$dbext_7ree} FROM ".DB::table('common_member_count')." WHERE uid='{$uid_7ree}'");
				if($membercount_7ree < $thisbadge_7ree['ext_7ree']){
						showmessage('badge_7ree:php_lang_errMsgext_7ree');
				}else{
						updatemembercount($uid_7ree, array($vars_7ree['ext_7ree'] => "-".$thisbadge_7ree['ext_7ree']));
				}
			}
	}
	
	//���Ż���
	if($action_7ree == "auto" && in_array($thisbadge_7ree['how_7ree'],array('1','3','4')) && $badge_test['status_7ree']=="status1_7ree"){
		
		
		DB::query("INSERT INTO ".DB::table('badge_log_7ree')." SET uid_7ree = '{$uid_7ree}', did_7ree = '{$did_7ree}', time_7ree= '{$_G[timestamp]}', status_7ree = 2");
		$notification_7ree = lang('plugin/badge_7ree', 'php_lang_getmsg1_7ree').$thisbadge_7ree['name_7ree'].lang('plugin/badge_7ree', 'php_lang_getmsg2_7ree').$_G['siteurl'].lang('plugin/badge_7ree', 'php_lang_getmsg3_7ree');
		
	}elseif($action_7ree == "apply" && $thisbadge_7ree['how_7ree']==2  && $badge_test['status_7ree']=="status1_7ree"){
		DB::query("INSERT INTO ".DB::table('badge_log_7ree')." SET uid_7ree = '{$uid_7ree}', did_7ree = '{$did_7ree}', time_7ree= '{$_G[timestamp]}', status_7ree = 1");
		$notification_7ree = lang('plugin/badge_7ree', 'php_lang_applymsg1_7ree').$thisbadge_7ree['name_7ree'].lang('plugin/badge_7ree', 'php_lang_applymsg2_7ree').$_G['siteurl'].lang('plugin/badge_7ree', 'php_lang_applymsg3_7ree');
	}elseif($action_7ree == "push" && $thisbadge_7ree['how_7ree']==2  && $badge_test['status_7ree']=="status2_7ree"){
		DB::query("UPDATE ".DB::table('badge_log_7ree')." SET time_7ree= '{$_G[timestamp]}', status_7ree = 2 WHERE uid_7ree = '{$uid_7ree}' AND did_7ree = '{$did_7ree}' LIMIT 1");
		$notification_7ree = lang('plugin/badge_7ree', 'php_lang_passmsg1_7ree').$thisbadge_7ree['name_7ree'].lang('plugin/badge_7ree', 'php_lang_passmsg2_7ree').$_G['siteurl'].lang('plugin/badge_7ree', 'php_lang_passmsg3_7ree');
	}


//�������� addnotice
	if($notification_7ree) notification_add($uid_7ree, 'system', $notification_7ree, $notevar, 1);
	
	return ;

}



function get_typename_7ree($type_7ree){ //��ȡ������ƺ���
	global $extype_array_7ree;
	$type_7ree = strcheck_7ree($type_7ree);
	if($type_7ree){
	
		foreach ($extype_array_7ree as $extype_array_value){
			if($extype_array_value[1]==$type_7ree){
				$return_7ree = $extype_array_value[0];
				break;
			}
		}
	
	
	
		return $return_7ree;
	}else{
		return;
	}
}

function strcheck_7ree($string, $isurl = false) //��ȫ���˺���
{ 
	$string = preg_replace('/[\\x00-\\x08\\x0B\\x0C\\x0E-\\x1F]/','',$string); 
	$string = str_replace(array("\0","%00","\r"),'',$string); 
	empty($isurl) && $string = preg_replace("/&(?!(#[0-9]+|[a-z]+);)/si",'&',$string); 
	$string = str_replace(array("%3C",'<'),'<',$string); 
	$string = str_replace(array("%3E",'>'),'>',$string); 
	$string = str_replace(array('"',"'","\t",' '),array('"','\'',' ',' '),$string); 
	return trim($string); 
} 


?>