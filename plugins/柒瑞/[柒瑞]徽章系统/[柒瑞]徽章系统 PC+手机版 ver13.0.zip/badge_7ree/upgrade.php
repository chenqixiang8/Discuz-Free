<?php

/*
	(C)2006-2021 dism.taobao.com
	This is NOT a freeware, use is subject to license terms
	Update: 2021/5/1 12:56
	Agreement: http://dism.taobao.com/?@7.developer.doc/agreement_7ree_html
	More Plugins: http://dism.taobao.com/?@7ree
*/



if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

function testfield_7ree($dbfield_7ree, $dbtable_7ree) {
	$field_7ree=array();
	$query=DB::query('SHOW COLUMNS FROM '.DB::table($dbtable_7ree));
	while ($row = DB::fetch($query)) {
		$field_7ree[]=$row['Field'];
	}
	return in_array($dbfield_7ree,$field_7ree) ? TRUE:FALSE;
}

if (!testfield_7ree('fenlei_7ree','badge_main_7ree')) {
	$sql="ALTER TABLE `pre_badge_main_7ree` ADD `fenlei_7ree` VARCHAR( 100 ) NOT NULL AFTER  `group_7ree`;";
	runquery($sql);	
}

if (!testfield_7ree('upgrade_7ree','badge_main_7ree')) {
	$sql="ALTER TABLE `pre_badge_main_7ree` ADD `upgrade_7ree` VARCHAR( 255 ) NOT NULL AFTER  `num2_7ree`;";
	runquery($sql);	
}

if (!testfield_7ree('level_7ree','badge_log_7ree')) {
	$sql="ALTER TABLE `pre_badge_log_7ree` ADD `level_7ree` INT( 2 ) NOT NULL AFTER  `status_7ree`;";
	runquery($sql);
}

if (!testfield_7ree('fid_7ree','badge_main_7ree')) {
	$sql="ALTER TABLE  `pre_badge_main_7ree` ADD  `fid_7ree` TEXT NOT NULL AFTER  `upgrade_7ree`";
	runquery($sql);
}

if (!testfield_7ree('ext_7ree','badge_main_7ree')) {
	$sql="ALTER TABLE  `pre_badge_main_7ree` ADD  `ext_7ree` MEDIUMINT( 8 ) NOT NULL AFTER  `fid_7ree`";
	runquery($sql);
}

if (!testfield_7ree('dateline_7ree','badge_main_7ree')) {
	$sql="ALTER TABLE  `pre_badge_main_7ree` ADD  `dateline_7ree` INT( 10 ) NOT NULL COMMENT  '��Ч��' AFTER  `ext_7ree`";
	runquery($sql);
}



$finish = TRUE;




?>