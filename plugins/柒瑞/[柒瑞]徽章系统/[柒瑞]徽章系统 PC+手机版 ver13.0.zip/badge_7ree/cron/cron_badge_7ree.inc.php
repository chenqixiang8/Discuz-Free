<?php
/*
	[dism.taobao.com] (C)2007-2021 dism.taobao.com.
	This is NOT a freeware, use is subject to license terms
	2021/5/1 13:19
	Agreement: http://dism.taobao.com/?@7.developer.doc/agreement_7ree_html
	More Plugins: http://dism.taobao.com/?@7ree
*/

//cronname:�������ϵͳ�ƻ�����

//hour:3              ������һСʱִ�б���������Ϊ������





if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
loadcache('plugin');
$vars_7ree = $_G['cache']['plugin']['badge_7ree'];

if(!$vars_7ree['agreement_7ree']) showmessage('badge_7ree:php_lang_agree_7ree');
$dateline_7ree = 0;

$query=DB::query("SELECT id_7ree,dateline_7ree FROM ".DB::table('badge_main_7ree')." WHERE dateline_7ree>0");

while($result=DB::fetch($query)){
	$dateline_7ree = $_G['timestamp'] - $result['dateline_7ree']*86400;
	
	$query2=DB::query("SELECT uid_7ree FROM ".DB::table('badge_log_7ree')." WHERE status_7ree=2 AND did_7ree = '{$result[id_7ree]}' AND time_7ree<{$dateline_7ree}");
	while($result2=DB::fetch($query2)){//pm
		$badgename_7ree = DB::result_first("SELECT name_7ree FROM ".DB::table('badge_main_7ree')." WHERE id_7ree = '{$result[id_7ree]}'");
		$notification_7ree = lang('plugin/badge_7ree', 'php_lang_delmsg1_7ree').$badgename_7ree.lang('plugin/badge_7ree', 'php_lang_delmsg2_7ree').$_G['siteurl'].lang('plugin/badge_7ree', 'php_lang_getmsg3_7ree');;
		if($notification_7ree) notification_add($result2['uid_7ree'], 'system', $notification_7ree, $notevar, 1);
	}
	
	DB::query("DELETE FROM ".DB::table('badge_log_7ree')." WHERE status_7ree=2 AND did_7ree = '{$result[id_7ree]}' AND time_7ree<{$dateline_7ree}");
}


?>