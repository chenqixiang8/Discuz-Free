<?php

/*
 * [dism.taobao.com] (C)2006-2021 dism.taobao.com.
 * This is NOT a freeware, use is subject to license terms
 * Agreement: https://dism.taobao.com/?@7.developer.doc/agreement_7ree_html
 * More Plugins: https://dism.taobao.com/developer-7.html
 * EMail: service@dism.taobao.com
 * QQ: 467783778
 * WeiXin: dism_taobao_com
 * Update: 2021-08-01 22:40:42
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class mobileplugin_badge_7ree{

		function forumdisplay_top_mobile(){
				$this->checkfid_7ree();
		}
	
		function viewthread_top_mobile(){
			$this->checkfid_7ree();
		}

		function checkfid_7ree(){
			global $_G;
			$return = '';
			if($_G['fid']){
					//$did_7ree = DB::result_first("SELECT id_7ree FROM ".DB::table('badge_main_7ree')." WHERE fid_7ree LIKE '%#{$_G[fid]}#%'");
					@require_once(DISCUZ_ROOT.'./source/discuz_version.php');
					$cahcedir_7ree = DISCUZ_VERSION == "X2" ? './data/cache/cache_' : './data/sysdata/cache_';
					$cachename_7ree = "badge_fid_7ree";
					@include DISCUZ_ROOT.$cahcedir_7ree.$cachename_7ree.'.php';
					$did_7ree=array();
					foreach($fidcache_7ree as $fidcache_value){
						if(strstr($fidcache_value['fid_7ree'],'#'.$_G['fid'].'#')){
							$did_7ree[]=$fidcache_value['id_7ree'];
							//break;
						}
					}
					//print_r($did_7ree);
				if($did_7ree){
					if($_G['uid']){
						//$logid_7ree = DB::result_first("SELECT id_7ree FROM ".DB::table('badge_log_7ree')." WHERE did_7ree='$did_7ree' AND uid_7ree='$_G[uid]' AND status_7ree=2");
						//echo("SELECT id_7ree FROM ".DB::table('badge_log_7ree')." WHERE did_7ree IN(".dimplode($did_7ree).") AND uid_7ree='$_G[uid]' AND status_7ree=2");
						$logid_7ree = DB::result_first("SELECT id_7ree FROM ".DB::table('badge_log_7ree')." WHERE did_7ree IN(".dimplode($did_7ree).") AND uid_7ree='$_G[uid]' AND status_7ree=2");
						
						if(!$logid_7ree){
							showmessage("badge_7ree:php_lang_errortip_nobid_7ree");
						}
					}else{
						showmessage('not_loggedin', NULL, array(), array('login' => 1));
					}
				}
			}
			return $return;
	
		}

		function global_header_mobile(){
			global $_G;
			$return = "<link rel='stylesheet' id='css_badge_7ree' type='text/css' href='source/plugin/badge_7ree/template/css/badge_7ree.css?{VERHASH}'/><script src='source/plugin/badge_7ree/template/js/badge_7ree.js?{VERHASH}'></script>";
			return $return;
		}


		function global_footer_mobile(){
			global $_G;
			$return = "";
			if($_G['uid']){
				@include_once("source/plugin/badge_7ree/function_7ree/badge_function_7ree.php");
					//�Զ����Ż�������
					//�����л������ҳ�����Ҫ�Զ����ŵĻ��£�ͬʱ�ų��Ѿ���ȡ�Ļ��£�
					//���������Ѽ��Ľ�����飬����ǰuid��Ա���Ż��£����ú���ʵ�֣�
				$query = DB::query("SELECT id_7ree,type_7ree,how_7ree,group_7ree,var1_7ree,var2_7ree,num1_7ree,num2_7ree,ext_7ree
									FROM ".DB::table('badge_main_7ree')." WHERE onoff_7ree = 1 AND how_7ree IN(1,4)");

				while($badge_table_7ree = DB::fetch($query)){
				   //����Ҫ����Ƿ����������û��飬��ִ�ж���
						   $badge_group_7ree = explode(',', $badge_table_7ree['group_7ree']);
						if(in_array($_G['groupid'],$badge_group_7ree)){
							if($badge_table_7ree['how_7ree']=='1'){
								push_badge_7ree($badge_table_7ree['id_7ree'],$_G['uid'],'auto');
								$mylog_7ree=DB::fetch_first("SELECT * FROM ".DB::table('badge_log_7ree')." WHERE uid_7ree='$_G[uid]' AND did_7ree='$badge_table_7ree[id_7ree]'");
								if($mylog_7ree['id_7ree'] && $mylog_7ree['view_7ree']<>1){
									$mytipid_7ree[]=$badge_table_7ree['id_7ree'];
								}

								break;
							}elseif($badge_table_7ree['how_7ree']=='4'){
								//�ж��Ƿ��Ѿ��������ö����
								$badge_table_7ree['myget_7ree'] = badge_test_7ree($badge_table_7ree['type_7ree'],$badge_table_7ree['id_7ree'],$_G[uid],$badge_table_7ree['var1_7ree'],$badge_table_7ree['num1_7ree'],$badge_table_7ree['var2_7ree'],$badge_table_7ree['num2_7ree'],$badge_table_7ree['upgrade_7ree'],$badge_table_7ree['ext_7ree']);
								$mytipid_7ree[] = $badge_table_7ree['myget_7ree']['status_7ree'] =="status1_7ree" ? $badge_table_7ree['id_7ree'] : 0;
								//$mytipid_7ree = $badge_table_7ree['myget_7ree'];
							}
							
						}
				   } 

				   foreach($mytipid_7ree as $mytipid_value){
					   if($mytipid_value){
							   $return = "<script language='JavaScript' type='text/JavaScript'>window.location.href='plugin.php?id=badge_7ree:badge_7ree&code=13&id_7ree={$mytipid_value}';</script>";
							   break;
					   }else{
							   $mybadgeid_7ree = DB::result_first("SELECT id_7ree FROM ".DB::table('badge_log_7ree')." WHERE uid_7ree = '{$_G[uid]}' AND status_7ree = 2 AND view_7ree = 0");
							$return = $mybadgeid_7ree ? "<script language='JavaScript' type='text/JavaScript'><script language='JavaScript' type='text/JavaScript'>window.location.href='plugin.php?id=badge_7ree:badge_7ree&code=12&id_7ree={$mybadgeid_7ree}';</script>" : "";
							if($return) break;
					}
				}

			}

			return $return;
		}
	
		function forumdisplay_thread_mobile_output(){
			global $_G,$postlist,$post;
			$return=array();
			$vars_7ree = $_G['cache']['plugin']['badge_7ree'];
			if(!$vars_7ree['mob_forum_badge_7ree']){
				return $return;
			}
			
			$authorids_7ree=array();
			foreach ($_G['forum_threadlist'] as $key=>$thread){
					$authorids_7ree[] = $thread['authorid'];
			}
				$authorids_7ree = dimplode(array_filter(array_unique($authorids_7ree)));

				$query = DB::query("SELECT l.*, m.*  FROM ".DB::table('badge_log_7ree')." l
											LEFT JOIN ".DB::table('badge_main_7ree')." m ON. m.id_7ree = l.did_7ree
											WHERE l.uid_7ree IN($authorids_7ree) AND l.status_7ree = 2 AND m.onoff_7ree = 1
											ORDER BY l.time_7ree DESC");
				while($table_7ree = DB::fetch($query)){
						if($i_7ree[$table_7ree['uid_7ree']]<6){
								//$badgelist0_7ree[$table_7ree['uid_7ree']] .= "<a href='plugin.php?id=badge_7ree:badge_7ree&code=1' style='float:right;padding:0 10px 0 0; '><img src='./source/plugin/badge_7ree/badge_img/small/".$table_7ree['logo_7ree']."'border='0'></a>";
								$badgelist0_7ree[$table_7ree['uid_7ree']] .= "<img src='./source/plugin/badge_7ree/badge_img/small/".$table_7ree['logo_7ree']."' style='width:17px;height:17px;display: inline; visibility: visible;vertical-align:middle;margin-left:5px;' border='0'>";
								$i_7ree[$table_7ree['uid_7ree']]=$i_7ree[$table_7ree['uid_7ree']]+1;
						}
        		} 
				//print_r($badgelist0_7ree);
				//echo("<pre>");
				//print_r($_G['forum_threadlist']);
		        if(is_array($_G['forum_threadlist']) && $vars_7ree['agreement_7ree']) {
				        foreach ($_G['forum_threadlist'] as $key=>$thread){
				        	$_G['forum_threadlist'][$key]['author']="<a href='plugin.php?id=badge_7ree:badge_7ree&code=1'><span style='color:#C0C0C0;'>".$_G['forum_threadlist'][$key]['author']."</span>".$badgelist0_7ree[$thread['authorid']['authorid']]."</a>";
						}
			  	}
		}

		function viewthread_posttop_mobile_output(){
				global $_G,$postlist,$post;
				$return = array();
				$vars_7ree = $_G['cache']['plugin']['badge_7ree'];
				
				if(!$vars_7ree['mob_post_badge_7ree']){
					return $return;
				}

				$authorids_7ree=array();
				foreach($postlist as $pid=>$postinfo_7ree){
					$authorids_7ree[] = $postinfo_7ree['authorid'];
				}
				$authorids_7ree = dimplode(array_filter(array_unique($authorids_7ree)));

				$query = DB::query("SELECT l.*, m.*  FROM ".DB::table('badge_log_7ree')." l
											LEFT JOIN ".DB::table('badge_main_7ree')." m ON. m.id_7ree = l.did_7ree
											WHERE l.uid_7ree IN($authorids_7ree) AND l.status_7ree = 2 AND m.onoff_7ree = 1
											ORDER BY l.time_7ree DESC");
				while($table_7ree = DB::fetch($query)){
						if($i_7ree[$table_7ree['uid_7ree']]<6){
								$badgelist0_7ree[$table_7ree['uid_7ree']] .= "<a href='plugin.php?id=badge_7ree:badge_7ree&code=1'><img src='./source/plugin/badge_7ree/badge_img/small/".$table_7ree['logo_7ree']."' style='width:17px;height:17px;margin:0px 0px 4px 3px; display: inline; visibility: visible;vertical-align:middle;' border='0'></a>";
								$i_7ree[$table_7ree['uid_7ree']]=$i_7ree[$table_7ree['uid_7ree']]+1;
						}
        		} 
		        if(is_array($postlist) && $vars_7ree['agreement_7ree']) {
				        foreach($postlist as $pid => $postlist_7ree) {
				        	$postlist[$pid]['author']=$postlist[$pid]['author'].$badgelist0_7ree[$postlist[$pid]['authorid']];
						}
			  	}

				return $return;

		}


}

class mobileplugin_badge_7ree_forum extends mobileplugin_badge_7ree{
}

class mobileplugin_badge_7ree_home extends mobileplugin_badge_7ree{
}

class mobileplugin_badge_7ree_group extends mobileplugin_badge_7ree{
}
//From: dis'.'m.tao'.'bao.com
?>