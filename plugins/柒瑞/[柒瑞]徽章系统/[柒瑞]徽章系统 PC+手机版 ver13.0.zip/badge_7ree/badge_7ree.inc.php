<?php

/*
 * [dism.taobao.com] (C)2006-2021 dism.taobao.com.
 * This is NOT a freeware, use is subject to license terms
 * Agreement: https://dism.taobao.com/?@7.developer.doc/agreement_7ree_html
 * More Plugins: https://dism.taobao.com/developer-7.html
 * EMail: service@dism.taobao.com
 * QQ: 467783778
 * WeiXin: dism_taobao_com
 * Update: 2021-08-01 22:40:54
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


$vars_7ree = $_G['cache']['plugin']['badge_7ree'];

if(!$vars_7ree['agreement_7ree']) showmessage('badge_7ree:php_lang_agree_7ree');

$pluginname = "badge_7ree";


$navtitle = lang('plugin/badge_7ree', 'php_lang_navtitle_7ree');
$metakeywords  = lang('plugin/badge_7ree', 'php_lang_navtitle_7ree');
$metadescription  = lang('plugin/badge_7ree', 'php_lang_navtitle_7ree');
$exttitle_7ree = $_G['setting']['extcredits'][$vars_7ree['ext_7ree']]['title'];

$vars_7ree['mutinum_7ree'] = intval($vars_7ree['mutinum_7ree']) ? intval($vars_7ree['mutinum_7ree']) : 20;

$isadmins_7ree = $_G['uid'] && $vars_7ree['admins_7ree'] && (in_array($_G['uid'],explode(',',$vars_7ree['admins_7ree']))) ? 1 : 0;
$isadmins_7ree = $isadmins_7ree || $_G['adminid'] == 1 ? 1: 0;


@include_once("source/plugin/badge_7ree/function_7ree/badge_function_7ree.php");

//����Ȩ�޼��

$id_7ree = intval($_GET['id_7ree']);
$code = intval($_GET['code']);
$uid_7ree = intval($_GET['uid_7ree']);
$gid_7ree = intval($_GET['gid_7ree']);
$_GET['mang'] = daddslashes(dhtmlspecialchars($_GET['mang']));


if ( !in_array($code, array( "","1","2","12","13","14") ) && !$_G['uid']) showmessage('not_loggedin', NULL, array(), array('login' => 1));

if (!$id_7ree && in_array($code , array("6","7","8","9","12","13","14"))) showmessage( "ERROR,Missing required parameter.@7ree" );

if (($_GET[formhash] <> FORMHASH) && (in_array($code, array("6","7","8","9")))) showmessage('Access Deined @7ree');

if(!submitcheck(submit_7ree) && (in_array($code, array("4","5","15")))) showmessage("Access Deined @7ree");

if ( in_array($code, array("3","4","5","6","8","9","10","11") ) && $isadmins_7ree!=1 ) showmessage( "Access Deined @7ree" );



$extype_array=explode("\n",str_replace("\r","",$vars_7ree['extype_7ree']));
	foreach ($extype_array as $extype_array_vars){
		$extype_array_7ree[]=explode("=",$extype_array_vars);
	}
	
	$query = DB::query("SELECT l.uid_7ree, m.username,count(l.id_7ree) AS count_7ree  FROM ".DB::table('badge_log_7ree')." l
						LEFT JOIN ".DB::table('common_member')." m ON m.uid = l.uid_7ree
						WHERE l.status_7ree = 2 GROUP BY l.uid_7ree	ORDER BY count_7ree DESC LIMIT 15");

	while($table_7ree = DB::fetch($query)){	
			$badge_rank_7ree[] = $table_7ree;
	}
	$fenlei_array=explode("\n",str_replace("\r","",$vars_7ree['fenlei_7ree']));
	
	
	
if (!$code){//������ҳ

	//$_GET['fenlei_7ree'] = daddslashes(dhtmlspecialchars($_GET['fenlei_7ree']));
	$_GET['fenlei_7ree'] = intval($_GET['fenlei_7ree']) ;
	$fenleinum_7ree = $_GET['fenlei_7ree'] > 0 ? $_GET['fenlei_7ree'] - 1 : 0;
	$fenlei_where_7ree = $_GET['fenlei_7ree'] ? " AND fenlei_7ree = binary('".$fenlei_array[$fenleinum_7ree]."')":"";
	
    $allnum_7ree = DB::result_first("SELECT COUNT(*) FROM ".DB::table('badge_log_7ree'));

	$query = DB::query("SELECT l.*, m.username, b.name_7ree, b.logo_7ree FROM ".DB::table('badge_log_7ree')." l
						LEFT JOIN ".DB::table('common_member')." m ON m.uid = l.uid_7ree
						LEFT JOIN ".DB::table('badge_main_7ree')." b ON b.id_7ree = l.did_7ree
						WHERE l.status_7ree = 2 AND b.onoff_7ree = 1 ORDER BY id_7ree DESC LIMIT 10");

	while($table_7ree = DB::fetch($query)){	
			$table_7ree['time_7ree'] = gmdate( lang('plugin/badge_7ree', 'php_lang_timeformat2_7ree'), $table_7ree['time_7ree'] + $_G['setting']['timeoffset'] * 3600);
			$log_recent_7ree[] = $table_7ree;
	}

			$mycount_7ree = 0;
			$querynum_7ree = DB::result_first("SELECT COUNT(*) FROM ".DB::table('badge_main_7ree')." WHERE onoff_7ree = 1 {$fenlei_where_7ree}");
			
  	    	$page = max(1, intval($_GET['page']));
        	$startpage = ($page - 1) * $vars_7ree['mutinum_7ree'];
			$query = DB::query("SELECT *  FROM ".DB::table('badge_main_7ree')." 
								WHERE onoff_7ree = 1 {$fenlei_where_7ree}
								ORDER BY id_7ree DESC LIMIT {$startpage}, {$vars_7ree['mutinum_7ree']}");

			while($table_7ree = DB::fetch($query)){
					$table_7ree['time_7ree'] = gmdate( "Y-m-d", $table_7ree['time_7ree'] + $_G['setting']['timeoffset'] * 3600 );
    	   				$table_7ree['typename_7ree'] = get_typename_7ree($table_7ree['type_7ree']);
    	   			
    	   				$table_7ree['detail2_7ree'] = str_replace(array('#var1_7ree#','#var2_7ree#','#num1_7ree#','#num2_7ree#'), array($table_7ree['var1_7ree'],$table_7ree['var2_7ree'],$table_7ree['num1_7ree'],$table_7ree['num2_7ree']), $table_7ree['detail_7ree']);
    	   				$logoarray_7ree=explode('.',$table_7ree['logo_7ree']);
    	   				$table_7ree['gif_7ree']=$logoarray_7ree[0].'.gif';
    	   			 //����Ҫ����Ƿ����������û��飬��ִ�ж���
    	   			 $group_7ree = explode(',', $table_7ree['group_7ree']);
					if(in_array($_G['groupid'],$group_7ree)){	
    	   			$table_7ree['myget_7ree'] = badge_test_7ree($table_7ree['type_7ree'],$table_7ree['id_7ree'],$_G['uid'],$table_7ree['var1_7ree'],$table_7ree['num1_7ree'],$table_7ree['var2_7ree'],$table_7ree['num2_7ree'],$table_7ree['upgrade_7ree'],$table_7ree['ext_7ree']);
    	   			if($table_7ree['myget_7ree']['status_7ree']=='status3_7ree') $mycount_7ree = $mycount_7ree + 1;
    	   			if($table_7ree['how_7ree']==3 && $table_7ree['myget_7ree']['status_7ree']<>'status3_7ree') {

    	   				$table_7ree['myget_7ree']['tip_7ree']= lang('plugin/badge_7ree','php_lang_shoudongtips_7ree');
    	   				$table_7ree['myget_7ree']['status_7ree']= "";

    	   			}
    	   			}else{
    	   			$table_7ree['myget_7ree']['tip_7ree']= $_G['uid'] ? lang('plugin/badge_7ree','php_lang_yonghuzutips_7ree') : lang('plugin/badge_7ree','php_lang_xiandenglu_7ree');
    	   			}
    	   			
    	   			
					$badge_list_7ree[] = $table_7ree;
           	} 
        	$multipage = multi($querynum_7ree, $vars_7ree['mutinum_7ree'], $page, "plugin.php?id=badge_7ree:badge_7ree&fenlei_7ree={$_GET['fenlei_7ree']}");
        	
        	
        	

}elseif($code=="1"){//�ҵĻ���

		if($_G['uid']){
		
			//$_GET['fenlei_7ree'] = daddslashes(dhtmlspecialchars($_GET['fenlei_7ree']));
			$_GET['fenlei_7ree'] = intval($_GET['fenlei_7ree']) ;
			$fenleinum_7ree = $_GET['fenlei_7ree'] > 0 ? $_GET['fenlei_7ree'] - 1 : 0;
			$fenlei_where_7ree = $_GET['fenlei_7ree'] ? " AND m.fenlei_7ree = binary('".$fenlei_array[$fenleinum_7ree]."')":"";
			//$fenlei_where_7ree = $_GET['fenlei_7ree'] ? " AND m.fenlei_7ree = '{$_GET[fenlei_7ree]}'":"";
		
			$querynum_7ree = DB::result_first("SELECT COUNT(*) FROM ".DB::table('badge_log_7ree')." l
												LEFT JOIN ".DB::table('badge_main_7ree')." m ON. m.id_7ree = l.did_7ree
												WHERE l.uid_7ree = '$_G[uid]' AND l.status_7ree = 2 {$fenlei_where_7ree}");
  	    	$page = max(1, intval($_GET['page']));
        	$startpage = ($page - 1) * $vars_7ree[mutinum_7ree];
			$query = DB::query("SELECT l.*, m.*  FROM ".DB::table('badge_log_7ree')." l
								LEFT JOIN ".DB::table('badge_main_7ree')." m ON. m.id_7ree = l.did_7ree
								WHERE l.uid_7ree = '$_G[uid]' AND l.status_7ree = 2 AND m.onoff_7ree = 1  {$fenlei_where_7ree}
								ORDER BY l.time_7ree DESC LIMIT {$startpage}, {$vars_7ree[mutinum_7ree]}");

			while($table_7ree = DB::fetch($query)){
					$table_7ree['time_7ree'] = gmdate( "Y-m-d", $table_7ree['time_7ree'] + $_G[setting][timeoffset] * 3600 );
    	   			$table_7ree['typename_7ree'] = get_typename_7ree($table_7ree['type_7ree']);
    	   			
    	   			$table_7ree['detail2_7ree'] = str_replace(array('#var1_7ree#','#var2_7ree#','#num1_7ree#','#num2_7ree#'), array($table_7ree['var1_7ree'],$table_7ree['var2_7ree'],$table_7ree['num1_7ree'],$table_7ree['num2_7ree']), $table_7ree['detail_7ree']);
    	   			
    	   			 //����Ҫ����Ƿ����������û��飬��ִ�ж���
    	   			 $group_7ree = explode(',', $table_7ree[group_7ree]);
					if(in_array($_G[groupid],$group_7ree)){	
    	   			$table_7ree['myget_7ree'] = badge_test_7ree($table_7ree['type_7ree'],$table_7ree['id_7ree'],$_G[uid],$table_7ree['var1_7ree'],$table_7ree['num1_7ree'],$table_7ree['var2_7ree'],$table_7ree['num2_7ree'],$table_7ree['upgrade_7ree'],$table_7ree['ext_7ree']);
    	   			}else{
    	   			$table_7ree['myget_7ree']['tip_7ree']= $_G[uid] ? lang('plugin/badge_7ree','php_lang_yonghuzutips_7ree') : lang('plugin/badge_7ree','php_lang_xiandenglu_7ree');
    	   			}
    	   			
    	   			
					$badge_list_7ree[] = $table_7ree;
           	} 
        	$multipage = multi($querynum_7ree, $vars_7ree[mutinum_7ree], $page, "plugin.php?id=badge_7ree:badge_7ree&code=1&fenlei_7ree={$_GET[fenlei_7ree]}");

		}




}elseif($code=="2"){//���°���

}elseif($code=="3"){//����Ա����̨
	
	if(!$_GET['mang']){
		
			$querynum_7ree = DB::result_first("SELECT COUNT(*) FROM ".DB::table('badge_main_7ree'));
  	    	$page = max(1, intval($_GET['page']));
        	$startpage = ($page - 1) * 20; 
			$query = DB::query("SELECT *  FROM ".DB::table('badge_main_7ree')."
								ORDER BY id_7ree DESC LIMIT {$startpage}, 20");

			while($table_7ree = DB::fetch($query)){
					$table_7ree['time_7ree'] = gmdate( "Y-m-d", $table_7ree['time_7ree'] + $_G['setting']['timeoffset'] * 3600 );
    	   			$table_7ree['typename_7ree'] = get_typename_7ree($table_7ree['type_7ree']);


    	   			$table_7ree['detail2_7ree'] = str_replace(array('#var1_7ree#','#var2_7ree#','#num1_7ree#','#num2_7ree#'), array($table_7ree['var1_7ree'],$table_7ree['var2_7ree'],$table_7ree['num1_7ree'],$table_7ree['num2_7ree']), $table_7ree['detail_7ree']);
				
		   			$badge_list_7ree[] = $table_7ree;
           	} 
        	$multipage = multi($querynum_7ree, 20, $page, "plugin.php?id=badge_7ree:badge_7ree&code=3");


	
	}elseif($_GET[mang]=="new"){//����
	
			$query = DB::query("SELECT groupid, grouptitle FROM ".DB::table('common_usergroup'));
	        	while($table_7ree = DB::fetch($query)){
		   		$grouplist_7ree[] = $table_7ree;
        	} 
        	
        	
        	require_once libfile('function/forumlist');
			$forumlist = forumselect(FALSE, 0, array());
        
        	if($_GET['id_7ree']) {
        		$action_7ree = "plugin.php?id=badge_7ree:badge_7ree&code=5";
        		$this_badge_7ree = DB::fetch_first("SELECT * FROM ".DB::table('badge_main_7ree')." WHERE id_7ree = {$id_7ree}");
        		$this_badge_7ree['typename_7ree'] = $this_badge_7ree['type_7ree'] ? get_typename_7ree($this_badge_7ree['type_7ree']) : "";
        		$group_7ree = explode(',', $this_badge_7ree[group_7ree]);
        		$template_return_7ree = badge_template_7ree($this_badge_7ree['type_7ree'],$this_badge_7ree['var1_7ree'],$this_badge_7ree['var2_7ree'],$this_badge_7ree['num1_7ree'],$this_badge_7ree['num2_7ree']);
        		$fid_7ree =  explode('#', trim($this_badge_7ree['fid_7ree'],'#'));
        	}else{
        		$action_7ree = "plugin.php?id=badge_7ree:badge_7ree&code=4";
        		$fid_7ree = array();
        	}
        	
        	
        	require_once libfile('function/forumlist');
			$forumlist = forumselect(FALSE, 0, $fid_7ree); 
        	
        	
        	
	
	}elseif($_GET['mang']=="log"){
	
	        $_GET['type_7ree']=intval($_GET['type_7ree']);
			
			if(!$_GET['type_7ree']){
			     $where_7ree = "";
			}elseif($_GET['type_7ree']==1){
			     $where_7ree = "where status_7ree = '2'";
			}elseif($_GET['type_7ree']==2){
			     $where_7ree = "where status_7ree = '1'";
			}
	
	
			$querynum_7ree = DB::result_first("SELECT COUNT(*) FROM ".DB::table('badge_log_7ree')." {$where_7ree}");
  	    	$page = max(1, intval($_GET['page']));
        	$startpage = ($page - 1) * 20; 
			$query = DB::query("SELECT l.*,l.id_7ree AS lid_7ree ,m.id_7ree AS mid_7ree, m.*, u.username,u.groupid  FROM ".DB::table('badge_log_7ree')." l
								LEFT JOIN ".DB::table('badge_main_7ree')." m ON m.id_7ree = l.did_7ree
								LEFT JOIN ".DB::table('common_member')." u ON u.uid = l.uid_7ree
								{$where_7ree} 
								ORDER BY l.id_7ree DESC LIMIT {$startpage}, 20");

			while($table_7ree = DB::fetch($query)){
					$table_7ree['time_7ree'] = gmdate( "Y-m-d H:i:s", $table_7ree['time_7ree'] + $_G['setting']['timeoffset'] * 3600 );
    	   			$table_7ree['typename_7ree'] = get_typename_7ree($table_7ree['type_7ree']);
    	   			
    	   			$table_7ree['detail2_7ree'] = str_replace(array('#var1_7ree#','#var2_7ree#','#num1_7ree#','#num2_7ree#'), array($table_7ree['var1_7ree'],$table_7ree['var2_7ree'],$table_7ree['num1_7ree'],$table_7ree['num2_7ree']), $table_7ree['detail_7ree']);



					$loglist_7ree[] = $table_7ree;
           	} 
        	$multipage = multi($querynum_7ree, 20, $page, "plugin.php?id=badge_7ree:badge_7ree&code=3&mang=log&type_7ree=".$_GET['type_7ree']);
	
	}elseif($_GET['mang']=="push"){
	
			$query = DB::query("SELECT id_7ree,name_7ree FROM ".DB::table('badge_main_7ree')." 
								WHERE how_7ree = 3 AND onoff_7ree = 1 ORDER BY id_7ree DESC ");
			while($table_7ree = DB::fetch($query)){
		   			$badgelist3_7ree[] = $table_7ree;
           	} 
	
	
	
	}else{	
		showmessage("Undefined Operation @ dism.taobao.com");
	}
	
	

}elseif($code=="4"){//�ύ�������¶���
	$name_7ree = dhtmlspecialchars(trim($_GET['name_7ree']));
	if(!$name_7ree) showmessage('badge_7ree:php_lang_errortip_name_7ree',"");
	$detail_7ree = dhtmlspecialchars(trim($_GET['detail_7ree']));
	if(!$detail_7ree) showmessage('badge_7ree:php_lang_errortip_detail_7ree',"");
	$logo_7ree = dhtmlspecialchars(trim($_GET['logo_7ree']));
	if(!$logo_7ree) showmessage('badge_7ree:php_lang_errortip_logo_7ree',"");
	
	if(!count($_GET['group_7ree'])) showmessage('badge_7ree:php_lang_errortip_group_7ree',"");
	$group_7ree = dhtmlspecialchars(implode(',', $_GET['group_7ree']));
		
	$type_7ree = dhtmlspecialchars(trim($_GET['type_7ree']));
	if(!$type_7ree) showmessage('badge_7ree:php_lang_errortip_type_7ree',"");
	$var1_7ree = intval($_GET['var1_7ree']);
	$var2_7ree = intval($_GET['var2_7ree']);
	$num1_7ree = intval($_GET['num1_7ree']);
	$num2_7ree = intval($_GET['num2_7ree']);
	$how_7ree = intval($_GET['how_7ree']);
	$ext_7ree = intval($_GET['ext_7ree']);
	$dateline_7ree = intval($_GET['dateline_7ree']);
	$onoff_7ree = intval($_GET['onoff_7ree']);
	
	$fenlei_7ree = dhtmlspecialchars(trim($_GET['fenlei_7ree']));
	$upgrade_7ree = dhtmlspecialchars(trim($_GET['upgrade_7ree']));
	
	if(!$var1_7ree & !$var2_7ree & !$num1_7ree & !$num2_7ree ) showmessage('badge_7ree:php_lang_errortip_vars_7ree',"");
	
	if($_GET['fid_7ree'][0]<>''){
		$fid_7ree = '#'.daddslashes(dhtmlspecialchars(implode('#', $_GET['fid_7ree']))).'#';
	}else{
		$fid_7ree = '';
	}
	
	DB::query("INSERT INTO ".DB::table('badge_main_7ree')." SET 
				name_7ree = '{$name_7ree}',
				detail_7ree = '{$detail_7ree}',
				logo_7ree = '{$logo_7ree}',
				group_7ree = '{$group_7ree}',
				fenlei_7ree = '{$fenlei_7ree}',
				type_7ree = '{$type_7ree}',
				how_7ree = '{$how_7ree}',
				var1_7ree = '{$var1_7ree}',
				var2_7ree = '{$var2_7ree}',
				num1_7ree = '{$num1_7ree}',
				num2_7ree = '{$num2_7ree}',
				upgrade_7ree = '{$upgrade_7ree}',
				fid_7ree = '{$fid_7ree}',
				ext_7ree = '{$ext_7ree}',
				dateline_7ree = '{$dateline_7ree}',
				onoff_7ree = '{$onoff_7ree}'
				");


	//����fid
	badge_fidcache_7ree();
	showmessage(lang('plugin/badge_7ree','php_lang_addok_7ree').$_GET['name_7ree'],"plugin.php?id=badge_7ree:badge_7ree&code=3");

}elseif($code=="5"){//�ύ�༭���¶���
	
	$name_7ree = dhtmlspecialchars(trim($_GET['name_7ree']));
	if(!$name_7ree) showmessage('badge_7ree:php_lang_errortip_name_7ree',"");
	$detail_7ree = dhtmlspecialchars(trim($_GET['detail_7ree']));
	if(!$detail_7ree) showmessage('badge_7ree:php_lang_errortip_detail_7ree',"");
	$logo_7ree = dhtmlspecialchars(trim($_GET['logo_7ree']));
	if(!$logo_7ree) showmessage('badge_7ree:php_lang_errortip_logo_7ree',"");
	
	if(!count($_GET['group_7ree'])) showmessage('badge_7ree:php_lang_errortip_group_7ree',"");
	$group_7ree = dhtmlspecialchars(implode(',', $_GET['group_7ree']));
		
	$type_7ree = dhtmlspecialchars(trim($_GET['type_7ree']));
	if(!$type_7ree) showmessage('badge_7ree:php_lang_errortip_type_7ree',"");
	$var1_7ree = intval($_GET['var1_7ree']);
	$var2_7ree = intval($_GET['var2_7ree']);
	$num1_7ree = intval($_GET['num1_7ree']);
	$num2_7ree = intval($_GET['num2_7ree']);
	$how_7ree = intval($_GET['how_7ree']);
	$ext_7ree = intval($_GET['ext_7ree']);
	$dateline_7ree = intval($_GET['dateline_7ree']);
	$onoff_7ree = intval($_GET['onoff_7ree']);

	
	$fenlei_7ree = dhtmlspecialchars(trim($_GET['fenlei_7ree']));
	$upgrade_7ree = dhtmlspecialchars(trim($_GET['upgrade_7ree']));
	
	if(!$var1_7ree & !$var2_7ree & !$num1_7ree & !$num2_7ree ) showmessage('badge_7ree:php_lang_errortip_vars_7ree',"");

	if($_GET['fid_7ree'][0]<>''){
		$fid_7ree = '#'.daddslashes(dhtmlspecialchars(implode('#', $_GET['fid_7ree']))).'#';
	}else{
		$fid_7ree = '';
	}
	
	
	DB::query("UPDATE ".DB::table('badge_main_7ree')." SET 
				name_7ree = '{$name_7ree}',
				detail_7ree = '{$detail_7ree}',
				logo_7ree = '{$logo_7ree}',
				group_7ree = '{$group_7ree}',
				fenlei_7ree = '{$fenlei_7ree}',
				type_7ree = '{$type_7ree}',
				how_7ree = '{$how_7ree}',
				var1_7ree = '{$var1_7ree}',
				var2_7ree = '{$var2_7ree}',
				num1_7ree = '{$num1_7ree}',
				num2_7ree = '{$num2_7ree}',
				upgrade_7ree = '{$upgrade_7ree}',
				fid_7ree = '{$fid_7ree}',
				ext_7ree = '{$ext_7ree}',
				dateline_7ree = '{$dateline_7ree}',
				onoff_7ree = '{$onoff_7ree}'
				WHERE id_7ree = {$id_7ree} LIMIT 1");
	

	//����fid
	badge_fidcache_7ree();
	showmessage(lang('plugin/badge_7ree','php_lang_editok_7ree').$_GET['name_7ree'],"plugin.php?id=badge_7ree:badge_7ree&code=3");



}elseif($code=="6"){//ɾ�����¶���
	//ɾ������ǰ��⣬�Ƿ��Ѿ��л�Ա�����˴˻��¡�
	
	$id_7ree = intval($id_7ree);
	$badge_log_7ree = DB::result_first("SELECT count(id_7ree) FROM ".DB::table('badge_log_7ree')." WHERE did_7ree = {$id_7ree}");
	
	if($badge_log_7ree){
		showmessage('badge_7ree:php_lang_delerror_7ree',"plugin.php?id=badge_7ree:badge_7ree&code=3");
	}else{
		DB::query("DELETE FROM ".DB::table('badge_main_7ree')." WHERE id_7ree = {$id_7ree} LIMIT 1");
		showmessage('badge_7ree:php_lang_delok_7ree',"plugin.php?id=badge_7ree:badge_7ree&code=3");
	}

}elseif($code=="7"){//��Ա������¶���
	
	$badge_group_7ree = DB::result_first("SELECT group_7ree FROM ".DB::table('badge_main_7ree')." WHERE id_7ree = {$id_7ree} LIMIT 1");
	$badge_group_7ree = explode(',', $badge_group_7ree);
	if(in_array($_G['groupid'],$badge_group_7ree)) push_badge_7ree($id_7ree,$_G['uid'],'apply');
	
	
	showmessage('badge_7ree:php_lang_applyok_7ree',"plugin.php?id=badge_7ree:badge_7ree");
	

}elseif($code=="8"){//��˻�������

	$badge_group_7ree = DB::result_first("SELECT group_7ree FROM ".DB::table('badge_main_7ree')." WHERE id_7ree = {$id_7ree} LIMIT 1");
	$badge_group_7ree = explode(',', $badge_group_7ree);
	//showmessage($badge_group_7ree);
	if(in_array($gid_7ree,$badge_group_7ree)) push_badge_7ree($id_7ree,$uid_7ree,'push');

	
	showmessage('badge_7ree:php_lang_applypass_7ree',"plugin.php?id=badge_7ree:badge_7ree&code=3&mang=log");


}elseif($code=="9"){//ɾ����Ա����
	
	DB::query("DELETE FROM ".DB::table('badge_log_7ree')." WHERE id_7ree = {$id_7ree} LIMIT 1");
	showmessage('badge_7ree:php_lang_delbadgeok_7ree',"plugin.php?id=badge_7ree:badge_7ree&code=3&mang=log");

}elseif($code=="10"){//�ֶ����Ż��¶���
	$badge_7ree = intval($_GET['badge_7ree']);
	$user_7ree = dhtmlspecialchars(trim($_GET['user_7ree']));
	
	if(!$badge_7ree) showmessage('badge_7ree:php_lang_errortip_selectname_7ree',"");
	if(!$user_7ree) showmessage('badge_7ree:php_lang_errortip_member_7ree',"");
	
	$badge_group_7ree = DB::result_first("SELECT group_7ree FROM ".DB::table('badge_main_7ree')." WHERE id_7ree = {$badge_7ree} LIMIT 1");
	$badge_group_7ree = explode(',', $badge_group_7ree);
	
	$user2_7ree = str_replace(",","','",$user_7ree);
	
	$query = DB::query("SELECT uid,groupid FROM ".DB::table('common_member')." WHERE username IN ('{$user2_7ree}')");
	while($table_7ree = DB::fetch($query)){
		if(in_array($table_7ree[groupid],$badge_group_7ree)) push_badge_7ree($badge_7ree,$table_7ree[uid],'auto');
    } 

	showmessage(lang('plugin/badge_7ree','php_lang_pushok_7ree').$_GET['user_7ree'],"plugin.php?id=badge_7ree:badge_7ree&code=3&mang=push");


}elseif($code=="11"){//ajax�õ�����ģ��

	$template_return_7ree = badge_template_7ree($_GET['type_7ree'],'0','0','0','0');
	

}elseif($code=="12"){//ajax�����õ�������Ϣ
	

	
		//��ȡ��ǰ��ȡ������Ϣ
		$thisbadge_7ree = DB::fetch_first("SELECT l.*, m.* FROM ".DB::table('badge_log_7ree')." l
										   LEFT JOIN ".DB::table('badge_main_7ree')." m ON l.did_7ree = m.id_7ree
										   WHERE l.id_7ree ='{$id_7ree}' LIMIT 1");
		$thisbadge_7ree['time_7ree'] = gmdate(lang('plugin/badge_7ree', 'php_lang_timeformat1_7ree'), $thisbadge_7ree['time_7ree'] + $_G['setting']['timeoffset'] * 3600 );
		$thisbadge_7ree['detail2_7ree'] = str_replace(array('#var1_7ree#','#var2_7ree#','#num1_7ree#','#num2_7ree#'), array($thisbadge_7ree['var1_7ree'],$thisbadge_7ree['var2_7ree'],$thisbadge_7ree['num1_7ree'],$thisbadge_7ree['num2_7ree']), $thisbadge_7ree['detail_7ree']);
		
		//�޸�ֵΪ�Ѷ�ȡ��ʾ��Ϣ
		DB::query("UPDATE ".DB::table('badge_log_7ree')." SET view_7ree = 1 WHERE id_7ree ='{$id_7ree}' LIMIT 1");


}elseif($code=="13"){//ajax������ʾ��ȡ����
	
		
		$thisbadge_7ree = DB::fetch_first("SELECT * FROM ".DB::table('badge_main_7ree')." WHERE id_7ree ='{$id_7ree}' LIMIT 1");
		$thisbadge_7ree['detail2_7ree'] = str_replace(array('#var1_7ree#','#var2_7ree#','#num1_7ree#','#num2_7ree#'), array($thisbadge_7ree['var1_7ree'],$thisbadge_7ree['var2_7ree'],$thisbadge_7ree['num1_7ree'],$thisbadge_7ree['num2_7ree']), $thisbadge_7ree['detail_7ree']);

		$myget_7ree = badge_test_7ree($thisbadge_7ree['type_7ree'],$thisbadge_7ree['id_7ree'],$_G['uid'],$thisbadge_7ree['var1_7ree'],$thisbadge_7ree['num1_7ree'],$thisbadge_7ree['var2_7ree'],$thisbadge_7ree['num2_7ree'],$thisbadge_7ree['upgrade_7ree'],$thisbadge_7ree['ext_7ree']);

		DB::update('badge_log_7ree',array('view_7ree'=>1),array('uid_7ree'=>$_G['uid'],'did_7ree'=>$id_7ree));


}elseif($code=="14"){//��Ա�������,���Զ����Ŷ���
	
	$badge_group_7ree = DB::result_first("SELECT group_7ree FROM ".DB::table('badge_main_7ree')." WHERE id_7ree = {$id_7ree} LIMIT 1");
	$badge_group_7ree = explode(',', $badge_group_7ree);
	if(in_array($_G['groupid'],$badge_group_7ree)) push_badge_7ree($id_7ree,$_G['uid'],'auto');
	
		showmessage('badge_7ree:php_lang_chenggonglingqu_7ree',"plugin.php?id=badge_7ree:badge_7ree");
	//dheader("location:plugin.php?id=badge_7ree:badge_7ree&code=1");
	
	
	
}elseif($code=="15"){//������˻�ɾ������

	if(!count($_GET['mod_7ree'])){
		showmessage('badge_7ree:php_lang_ERRORshanchulog_7ree',"plugin.php?id=badge_7ree:badge_7ree&code=3&mang=log");
	}

	$type_7ree=intval($_GET['type_7ree']);
	if(!$type_7ree){
		showmessage('badge_7ree:php_lang_errortip_type2_7ree',"plugin.php?id=badge_7ree:badge_7ree&code=3&mang=log");
	}

	$mod_7ree = dintval((array)$_GET['mod_7ree'], true);
	if($type_7ree==1){//�������
		DB::query("UPDATE ".DB::table('badge_log_7ree')." SET `status_7ree` = '2' WHERE id_7ree IN(".dimplode($mod_7ree).")");
	}elseif($type_7ree==2){//����ɾ��
		DB::query("DELETE FROM ".DB::table('badge_log_7ree')." WHERE id_7ree IN(".dimplode($mod_7ree).")");
	}

	showmessage('badge_7ree:php_lang_chenggongshanchulog_7ree',"plugin.php?id=badge_7ree:badge_7ree&code=3&mang=log");

}else{
	showmessage("Undefined Operation @ dism.taobao.com");
}


if($code=="11"){
	$template_7ree = "badge_7ree:ajax_7ree";
}elseif($code=="12"){
	$template_7ree = "badge_7ree:noticetip_7ree";
}elseif($code=="13"){
	$template_7ree = "badge_7ree:pushtip_7ree";
}else{
	$template_7ree = "badge_7ree:badge_7ree";
}


include template($template_7ree);





?>