<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); if($new_hangyes || $shlist) { ?>
<div class="quanzhi inner home-inner shixi" >
    <div class="left">
        <div class="quanzhi-title">
            <div class="ele-pointer">热门商家</div>
        </div>
        <div class="quanzhi-logo ele-pointer quanzhi-logo-shixi"></div>
        <div class="quanzhi-logo-txt ele-pointer">商家好店</div>
        <div  class="quanzhi-recomand">
            <?php if(is_array($new_hangyes)) foreach($new_hangyes as $_k => $_v) { ?>            <p>
                <a href="javascript:;" class="first"><?php echo $_v['0']['name'];?></a>
                <em class="vline v-line-spc"></em>
                <a href="javascript:;" class="second"><?php echo $_v['1']['name'];?></a>
            </p>
            <?php } ?>
        </div>
        <a href="javascript:;"  class="quanzhi-more">查看更多</a>
    </div>
    <div class="right recomand-content clearfix">
        <div>
            <?php if(is_array($shlist)) foreach($shlist as $_k => $_v) { ?>            <?php if(!$config[qraut]):
$yuanurl = $_G['siteurl']."$SCRITPTNAME?id=xigua_hs&ac=view&shid=".$_v['shid']."&x=1&st=".$_v['stid'];
$_qrfile = './source/plugin/xigua_hs/cache/' . md5($yuanurl) . '.jpg';
if (!is_file(DISCUZ_ROOT . $_qrfile)) :
@include_once DISCUZ_ROOT.'source/plugin/mobile/qrcode.class.php';
if(class_exists('QRcode')):
QRcode::png($yuanurl, DISCUZ_ROOT . $_qrfile, QR_ECLEVEL_L, 5);
else:
file_put_contents(DISCUZ_ROOT . $_qrfile, dfsockopen('http://qr.liantu.com/api.php?&w=280&h=280&bg=ffffff&fg=000000&text=' . urlencode($yuanurl)));
endif;
endif;
endif;?>            <a href="javascript:;" class="shixi-item"><img src="<?php echo $_v['logo'];?>" class="img">
                <div class="job-compnay ellipsis"><?php echo $_v['name'];?></div>
                <img class="innner_shqr" src="<?php if($config['qraut']) { ?><?php echo $SCRITPTNAME;?>?id=xigua_hb:qrauto&ode=sh_<?php echo $_v['shid'];?><?php echo $urlext;?><?php } else { ?><?php echo $_qrfile;?><?php } ?>">
            </a>
            <?php } ?>
        </div>
    </div>
</div>
<?php } ?>
