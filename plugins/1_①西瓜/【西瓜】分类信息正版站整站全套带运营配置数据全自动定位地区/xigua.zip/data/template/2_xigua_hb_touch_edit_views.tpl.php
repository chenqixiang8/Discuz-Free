<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<div id="lll_ctrl" style="z-index:999" class="weui-popup__container popup-bottom">
<form  action="<?php echo $SCRITPTNAME;?>?id=xigua_hb&ac=refresh&do=editviews&st=<?php echo $_GET['st'];?>" method="post" id="form2">
<input name="formhash" value="<?php echo FORMHASH;?>" type="hidden">
<input name="inajax" value="1" type="hidden">
<input name="vpubid" class="vpubid" value="0" type="hidden">
<div class="weui-popup__overlay"></div>
<div class="weui-popup__modal">
<div class="toolbar">
<div class="toolbar-inner">
<a href="javascript:;" class="picker-button close-popup">取消</a>
<h1 class="title">改浏览量 ID: <em class="vpubid"></em></h1>
</div>
</div>
<div class="modal-content">
<div class="weui-cells before_none after_none">
<div class="weui-cell">
<div class="weui-cell__hd"><label class="weui-label">浏览量</label></div>
<div class="weui-cell__bd">
<input name="form[views]" class="weui-input" type="tel" placeholder="请填写浏览量" value="0">
</div>
</div>
<div class="weui-cell">
<div class="weui-cell__hd"><label class="weui-label">分享量</label></div>
<div class="weui-cell__bd">
<input name="form[shares]" class="weui-input" type="tel" placeholder="请填写分享量" value="0">
</div>
</div>
<div class="weui-cell">
<div class="weui-cell__hd"><label class="weui-label">点赞量</label></div>
<div class="weui-cell__bd">
<input name="form[votes]" class="weui-input" type="tel" placeholder="请填写点赞量" value="0">
</div>
</div>
</div>
<div class="fix-bottom" style="position:relative">
<input type="submit" id="dosubmit2" href="javascript:;" class="weui-btn weui-btn_primary" value="确定">
</div>
</div>
</div>
</form>
</div>
<script>var formlock2 =0;$(document).on('submit', '#form2', function () {var dosubbtn = $('#dosubmit2');var that = $(this);if (formlock2 === 1) {return false;}$.showLoading();formlock2 = 1;$.ajax({type: 'post',url: that.attr('action') + '&inajax=1' + _URLEXT,data: that.serialize(),dataType: 'xml',success: function (data) {$.hideLoading();formlock2 = 0;if (null == data) {tip_common('error|' + ERROR_TIP);return false;}var s = data.lastChild.firstChild.nodeValue;tip_common(s);},error: function () {$.hideLoading();formlock2 = 0;}});return false;});</script>