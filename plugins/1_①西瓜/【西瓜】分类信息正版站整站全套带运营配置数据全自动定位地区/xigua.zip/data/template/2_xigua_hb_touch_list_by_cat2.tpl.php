<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); $_index_index_key=0;?><?php if(is_array($indexmod)) foreach($indexmod as $_index_index => $_indexmod) { if(!$_GET['nav'] && $_index_index_key==0) { $_GET[nav] = $_index_index;?><?php } if($_index_index =='zx') { ?>
<a href="javascript:;" data-save="nav=zx" class="weui-navbar__item <?php if(!$_GET['nav']||$_GET['nav']=='zx') { ?>weui_bar__item_on<?php } ?> ajaxcat" data-id="0">
    <span><?php echo $_indexmod;?></span>
</a>
<?php } if($_index_index =='fj' && $allowfj) { ?>
<a href="javascript:;" data-save="nav=fj" class="weui-navbar__item <?php if($_GET['nav']=='fj') { ?>weui_bar__item_on<?php } ?>" data-id="0" id="near_xinxi" style="min-width:60px">
    <span><?php echo $_indexmod;?></span>
</a>
<?php } if($_index_index =='needs' && $allow_ho_needs) { ?>
    <a href="javascript:;" data-save="nav=needs" class="<?php if($_GET['nav']=='needs') { ?>weui_bar__item_on <?php } ?>weui-navbar__item ajaxcat"  data-loadingurl="<?php echo $SCRITPTNAME;?>?id=xigua_ho&ac=need_li&orderby=newest<?php echo $urlext;?>&inajax=1&page=">
        <span><?php echo $_indexmod;?></span>
    </a>
    <?php if($_GET['nav']=='needs') { ?><script>var indexloadingurl = '<?php echo $SCRITPTNAME;?>?id=xigua_ho&ac=need_li&orderby=newest<?php echo $urlext;?>&inajax=1&page=';</script><?php } } if($_index_index =='shifu' && $allow_ho_shifu) { ?>
    <a href="javascript:;" data-save="nav=shifu" class="<?php if($_GET['nav']=='shifu') { ?>weui_bar__item_on <?php } ?>weui-navbar__item ajaxcat"  data-loadingurl="<?php echo $SCRITPTNAME;?>?id=xigua_ho&ac=shifu_li&orderby=jiedannum<?php echo $urlext;?>&inajax=1&page=">
        <span><?php echo $_indexmod;?></span>
    </a>
    <?php if($_GET['nav']=='shifu') { ?><script>var indexloadingurl = '<?php echo $SCRITPTNAME;?>?id=xigua_ho&ac=shifu_li&orderby=jiedannum<?php echo $urlext;?>&inajax=1&page=';</script><?php } } if($_index_index =='full' && $allowjobfull) { ?>
    <a href="javascript:;" data-save="nav=full" class="<?php if($_GET['nav']=='full') { ?>weui_bar__item_on <?php } ?>weui-navbar__item ajaxcat"  data-loadingurl="<?php echo $SCRITPTNAME;?>?id=xigua_job&ac=job_li&type=full&nouser=1<?php echo $urlext;?>&inajax=1&page=">
        <span><?php echo $_indexmod;?></span>
    </a>
    <?php if($_GET['nav']=='full') { ?><script>var indexloadingurl = '<?php echo $SCRITPTNAME;?>?id=xigua_job&ac=job_li&type=full&nouser=1<?php echo $urlext;?>&inajax=1&page=';</script><?php } } if($_index_index =='part' && $allowjobpart) { ?>
    <a href="javascript:;" data-save="nav=part" class="<?php if($_GET['nav']=='part') { ?>weui_bar__item_on <?php } ?>weui-navbar__item ajaxcat"  data-loadingurl="<?php echo $SCRITPTNAME;?>?id=xigua_job&ac=job_li&type=part&nouser=1<?php echo $urlext;?>&inajax=1&page=">
        <span><?php echo $_indexmod;?></span>
    </a>
    <?php if($_GET['nav']=='part') { ?><script>var indexloadingurl = '<?php echo $SCRITPTNAME;?>?id=xigua_job&ac=job_li&type=part&nouser=1<?php echo $urlext;?>&inajax=1&page=';</script><?php } } if($_index_index =='jl' && $allowresume) { ?>
    <a href="javascript:;" data-save="nav=jl" class="<?php if($_GET['nav']=='jl') { ?>weui_bar__item_on <?php } ?>weui-navbar__item ajaxcat"  data-loadingurl="<?php echo $SCRITPTNAME;?>?id=xigua_job&ac=resume_li&nouser=1<?php echo $urlext;?>&inajax=1&page=">
        <span><?php echo $_indexmod;?></span>
    </a>
    <?php if($_GET['nav']=='jl') { ?><script>var indexloadingurl = '<?php echo $SCRITPTNAME;?>?id=xigua_job&ac=resume_li&nouser=1<?php echo $urlext;?>&inajax=1&page=';</script><?php } } if($_index_index =='114' && $allowdh) { ?>
    <a href="javascript:;" data-save="nav=114" class="<?php if($_GET['nav']=='114') { ?>weui_bar__item_on <?php } ?>weui-navbar__item ajaxcat"  data-loadingurl="<?php echo $SCRITPTNAME;?>?id=xigua_dh&ac=myshop_li&viewtype=new&<?php echo $urlext;?>&inajax=1&page=">
        <span><?php echo $_indexmod;?></span>
    </a>
    <?php if($_GET['nav']=='114') { ?><script>var indexloadingurl = '<?php echo $SCRITPTNAME;?>?id=xigua_dh&ac=myshop_li&viewtype=new<?php echo $urlext;?>&inajax=1&page=';</script><?php } } if($_index_index =='he' && $allowhe) { ?>
    <a href="javascript:;" data-save="nav=he" class="<?php if($_GET['nav']=='he') { ?>weui_bar__item_on <?php } ?>weui-navbar__item ajaxcat"  data-loadingurl="<?php echo $SCRITPTNAME;?>?id=xigua_he&ac=he_li&<?php echo $urlext;?>&inajax=1&page=">
        <span><?php echo $_indexmod;?></span>
    </a>
    <?php if($_GET['nav']=='he') { ?><script>var indexloadingurl = '<?php echo $SCRITPTNAME;?>?id=xigua_he&ac=he_li<?php echo $urlext;?>&inajax=1&page=';</script><?php } } if($_index_index =='dp' && $allowdp) { ?>
    <a href="javascript:;" data-save="nav=dp" class="<?php if($_GET['nav']=='dp') { ?>weui_bar__item_on <?php } ?>weui-navbar__item ajaxcat"  data-loadingurl="<?php echo $SCRITPTNAME;?>?id=xigua_dp&ac=dp_li&<?php echo $urlext;?>&inajax=1&page=">
        <span><?php echo $_indexmod;?></span>
    </a>
    <?php if($_GET['nav']=='dp') { ?><script>var indexloadingurl = '<?php echo $SCRITPTNAME;?>?id=xigua_dp&ac=dp_li<?php echo $urlext;?>&inajax=1&page=';</script><?php } } if($_index_index =='tid' && $allowtid) { ?>
    <a href="javascript:;" data-save="nav=tid" class="<?php if($_GET['nav']=='tid') { ?>weui_bar__item_on <?php } ?>weui-navbar__item ajaxcat" data-loadingurl="<?php echo $SCRITPTNAME;?>?id=xigua_hb&ac=tid_li&from=index&inajax=1<?php echo $urlext;?>&page=">
        <span><?php echo $_indexmod;?></span>
    </a>
    <?php if($_GET['nav']=='tid') { ?><script>var indexloadingurl = '<?php echo $SCRITPTNAME;?>?id=xigua_hb&ac=tid_li&from=index&inajax=1<?php echo $urlext;?>&page=';</script><?php } } if($_index_index =='article' && $allow_article) { ?>
<a href="javascript:;" data-save="nav=article" class="<?php if($_GET['nav']=='article') { ?>weui_bar__item_on <?php } ?>weui-navbar__item ajaxcat" data-loadingurl="<?php echo $SCRITPTNAME;?>?id=xigua_hb&ac=article_li&from=index&inajax=1<?php echo $urlext;?>&page=">
    <span><?php echo $_indexmod;?></span>
</a>
<?php if($_GET['nav']=='article') { ?><script>var indexloadingurl = '<?php echo $SCRITPTNAME;?>?id=xigua_hb&ac=article_li&from=index&inajax=1<?php echo $urlext;?>&page=';</script><?php } } if($_index_index =='hp' && $allowhp) { ?>
<a href="javascript:;" data-save="nav=hp" class="<?php if($_GET['nav']=='hp') { ?>weui_bar__item_on <?php } ?>weui-navbar__item ajaxcat" data-loadingurl="<?php echo $SCRITPTNAME;?>?id=xigua_hp&ac=good_li&orderby=views&inajax=1<?php echo $urlext;?>&page=">
    <span><?php echo $_indexmod;?></span>
</a>
<?php if($_GET['nav']=='hp') { ?><script>var indexloadingurl = '<?php echo $SCRITPTNAME;?>?id=xigua_hp&ac=good_li&orderby=views&inajax=1<?php echo $urlext;?>&page=';</script><?php } } if($_index_index =='hf' && $allowhf) { ?>
<a href="javascript:;" data-save="nav=hf" class="<?php if($_GET['nav']=='hf') { ?>weui_bar__item_on <?php } ?>weui-navbar__item ajaxcat" data-loadingurl="<?php echo $SCRITPTNAME;?>?id=xigua_hf&ac=qun_li&viewtype=new&inajax=1<?php echo $urlext;?>&page=">
    <span><?php echo $_indexmod;?></span>
</a>
<?php if($_GET['nav']=='hf') { ?><script>var indexloadingurl = '<?php echo $SCRITPTNAME;?>?id=xigua_hf&ac=qun_li&viewtype=new&inajax=1<?php echo $urlext;?>&page=';</script><?php } } if($_index_index =='hs' && $allowhs) { ?>
    <a href="javascript:;" data-save="nav=hs" class="<?php if($_GET['nav']=='hs') { ?>weui_bar__item_on <?php } ?>weui-navbar__item ajaxcat" data-loadingurl="<?php echo $SCRITPTNAME;?>?id=xigua_hs&ac=myshop_li<?php echo $urlext;?>&inajax=1&page=">
        <span><?php echo $_indexmod;?></span>
    </a>
    <?php if($_GET['nav']=='hs') { ?><script>var indexloadingurl = '<?php echo $SCRITPTNAME;?>?id=xigua_hs&ac=myshop_li<?php echo $urlext;?>&inajax=1&page=';</script><?php } } if($_index_index =='pt' && $allowpt) { ?>
    <a href="javascript:;" data-save="nav=pt" class="<?php if($_GET['nav']=='pt') { ?>weui_bar__item_on <?php } ?>weui-navbar__item ajaxcat" data-loadingurl="<?php echo $SCRITPTNAME;?>?id=xigua_pt&ac=cat_li&from=index&inajax=1<?php echo $urlext;?>&page=">
        <span><?php echo $_indexmod;?></span>
    </a>
    <?php if($_GET['nav']=='pt') { ?><script>var indexloadingurl = '<?php echo $SCRITPTNAME;?>?id=xigua_pt&ac=cat_li&from=index&inajax=1<?php echo $urlext;?>&page=';</script><?php } } if($_index_index =='sp' && $allowsp) { ?>
    <a href="javascript:;" data-save="nav=sp" class="<?php if($_GET['nav']=='sp') { ?>weui_bar__item_on <?php } ?>weui-navbar__item ajaxcat" data-loadingurl="<?php echo $SCRITPTNAME;?>?id=xigua_sp&ac=cat_li&from=index&inajax=1<?php echo $urlext;?>&page=">
        <span><?php echo $_indexmod;?></span>
    </a>
    <?php if($_GET['nav']=='sp') { ?><script>var indexloadingurl = '<?php echo $SCRITPTNAME;?>?id=xigua_sp&ac=cat_li&from=index&inajax=1<?php echo $urlext;?>&page=';</script><?php } } if($_index_index =='kj' && $allowhd) { ?>
    <a href="javascript:;" data-save="nav=kj" class="<?php if($_GET['nav']=='kj') { ?>weui_bar__item_on <?php } ?>weui-navbar__item ajaxcat" data-loadingurl="<?php echo $SCRITPTNAME;?>?id=xigua_hd&ac=evt_li<?php echo $urlext;?>&inajax=1&page=">
        <span><?php echo $_indexmod;?></span>
    </a>
    <?php if($_GET['nav']=='kj') { ?><script>var indexloadingurl = '<?php echo $SCRITPTNAME;?>?id=xigua_hd&ac=evt_li<?php echo $urlext;?>&inajax=1&page=';</script><?php } } if($_index_index =='hm' && $allowhm) { ?>
    <a href="javascript:;" data-save="nav=hm" class="<?php if($_GET['nav']=='hm') { ?>weui_bar__item_on <?php } ?>weui-navbar__item ajaxcat"  data-loadingurl="<?php echo $SCRITPTNAME;?>?id=xigua_hm&ac=seckill_li<?php echo $urlext;?>&inajax=1&page=">
        <span><?php echo $_indexmod;?></span>
    </a>
    <?php if($_GET['nav']=='hm') { ?><script>var indexloadingurl = '<?php echo $SCRITPTNAME;?>?id=xigua_hm&ac=seckill_li<?php echo $urlext;?>&inajax=1&page=';</script><?php } } if($_index_index =='yh' && $allowyh) { ?>
    <a href="javascript:;" data-save="nav=yh" class="<?php if($_GET['nav']=='yh') { ?>weui_bar__item_on <?php } ?>weui-navbar__item ajaxcat"  data-loadingurl="<?php echo $SCRITPTNAME;?>?id=xigua_hm&ac=seckill_li<?php echo $urlext;?>&stype=youhui&inajax=1&page=">
        <span><?php echo $_indexmod;?></span>
    </a>
    <?php if($_GET['nav']=='yh') { ?><script>var indexloadingurl = '<?php echo $SCRITPTNAME;?>?id=xigua_hm&ac=seckill_li<?php echo $urlext;?>&stype=youhui&inajax=1&page=';</script><?php } } if($_index_index =='hk' && $allowhk) { ?>
    <a href="javascript:;" data-save="nav=hk" class="<?php if($_GET['nav']=='hk') { ?>weui_bar__item_on <?php } ?>weui-navbar__item ajaxcat"  data-loadingurl="<?php echo $SCRITPTNAME;?>?id=xigua_hk&ac=good_li<?php echo $urlext;?>&inajax=1&page=">
        <span><?php echo $_indexmod;?></span>
    </a>
    <?php if($_GET['nav']=='hk') { ?><script>var indexloadingurl = '<?php echo $SCRITPTNAME;?>?id=xigua_hk&ac=good_li<?php echo $urlext;?>&inajax=1&page=';</script><?php } } if($_index_index =='xxhb' && $allowxxhb) { ?>
    <a href="javascript:;" data-save="nav=xxhb" class="<?php if($_GET['nav']=='xxhb') { ?>weui_bar__item_on <?php } ?>weui-navbar__item ajaxcat"  data-loadingurl="<?php echo $SCRITPTNAME;?>?id=xigua_hb&ac=list_item<?php echo $urlext;?>&hb=1&inajax=1&page=">
        <span><?php echo $_indexmod;?></span>
    </a>
    <?php if($_GET['nav']=='xxhb') { ?><script>var indexloadingurl = '<?php echo $SCRITPTNAME;?>?id=xigua_hb&ac=list_item<?php echo $urlext;?>&hb=1&inajax=1&page=';</script><?php } } if($_index_index =='sjhb' && $allowsjhb) { ?>
    <a href="javascript:;" data-save="nav=sjhb" class="<?php if($_GET['nav']=='sjhb') { ?>weui_bar__item_on <?php } ?>weui-navbar__item ajaxcat"  data-loadingurl="<?php echo $SCRITPTNAME;?>?id=xigua_hs&ac=myshop_li<?php echo $urlext;?>&hb=1&inajax=1&page=">
        <span><?php echo $_indexmod;?></span>
    </a>
    <?php if($_GET['nav']=='sjhb') { ?><script>var indexloadingurl = '<?php echo $SCRITPTNAME;?>?id=xigua_hs&ac=myshop_li<?php echo $urlext;?>&hb=1&inajax=1&page=';</script><?php } } $_index_index_key++;?><?php } ?>