<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); hookscriptoutput('mytx');?><?php include template('xigua_hb:common_header'); ?><style>.weui-switch-cp__input:checked~.weui-switch-cp__box, .weui-switch:checked{background-color:<?php echo $config['maincolor'];?>!important;border-color:<?php echo $config['maincolor'];?>!important}</style>
<link rel="stylesheet" href="source/plugin/xigua_hb/static/dist/cropper.css?<?php echo VERHASH;?>">
<div class="page__bd">
    <?php include template('xigua_hb:common_nav'); ?>    <form action="<?php echo $SCRITPTNAME;?>?id=xigua_hb&ac=mytx" method="post" id="form">
        <input type="hidden" name="formhash" value="<?php echo FORMHASH;?>" />
        <input type="hidden" name="referer" value="<?php echo $referer;?>">

        <div class="weui-cells__title">请添加常用提现方式</div>
        <div class="weui-cells weui-cells_form">
            <div class="weui-cell">
                <div class="weui-cell__bd">
                    <div class="weui-uploader">
                        <div class="weui-uploader__hd">
                            <p class="weui-uploader__title">请上传支付宝收款码<span class="color-red">*</span></p>
                            <div class="weui-uploader__info"></div>
                        </div>
                        <div class="weui-uploader__bd">
                            <ul class="weui-uploader__files" data-only="1">
                                <?php if($user['alipay_qr']) { ?>
                                <li class="weui-uploader__file weui-uploader__file_status" style="background-image:url(<?php echo $user['alipay_qr'];?>)">
                                    <input type="hidden" name="form[alipay_qr][]" value="<?php echo $user['alipay_qr'];?>"/>
                                    <div class="weui-uploader__file-content"><i class="weui-icon-warn iconfont icon-shanchu"></i></div>
                                </li>
                                <?php } ?>
                            </ul>
                            <div class="weui-uploader__input-box">
                                <?php if((HB_INWECHAT&&$config['multiupload']) || IN_MAGAPP) { ?>
                                <a class="weui-uploader__input" data-name="form[alipay_qr]" type="file"></a>
                                <?php } else { ?>
                                <input class="weui-uploader__input" data-name="form[alipay_qr]" type="file">
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="weui-cell">
                <div class="weui-cell__bd">
                    <div class="weui-uploader">
                        <div class="weui-uploader__hd">
                            <p class="weui-uploader__title">请上传微信收款码<span class="color-red">*</span></p>
                            <div class="weui-uploader__info"></div>
                        </div>
                        <div class="weui-uploader__bd">
                            <ul class="weui-uploader__files" data-only="1">
                                <?php if($user['wxpay_qr']) { ?>
                                <li class="weui-uploader__file weui-uploader__file_status" style="background-image:url(<?php echo $user['wxpay_qr'];?>)">
                                    <input type="hidden" name="form[wxpay_qr][]" value="<?php echo $user['wxpay_qr'];?>"/>
                                    <div class="weui-uploader__file-content"><i class="weui-icon-warn iconfont icon-shanchu"></i></div>
                                </li>
                                <?php } ?>
                            </ul>
                            <div class="weui-uploader__input-box">
                                <?php if((HB_INWECHAT&&$config['multiupload']) || IN_MAGAPP) { ?>
                                <a  class="weui-uploader__input" data-name="form[wxpay_qr]" type="file"></a>
                                <?php } else { ?>
                                <input  class="weui-uploader__input" data-name="form[wxpay_qr]" type="file">
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="weui-cells__title">其他提现方式</div>
        <div class="weui-cells">

            <div class="weui-cell">
                <div class="weui-cell__hd"><label class="weui-label">真实姓名</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" type="text" name="form[realname]" placeholder="请填写您的真实姓名" value="<?php echo $user['realname'];?>">
                </div>
            </div>

            <div class="weui-cell">
                <div class="weui-cell__hd"><label class="weui-label">银行卡号</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" type="text" name="form[cardno]" placeholder="请填写您的银行卡号" value="<?php echo $user['cardno'];?>">
                </div>
            </div>
        </div>


        <div class="fix-bottom mt10" style="position: relative">
            <input type="submit" class="weui-btn weui-btn_primary" name="dosubmit" id="dosubmit" value="确定">
        </div>
    </form>
</div>

<div id="popctrl" class="weui-popup__container" style="z-index:1001">
    <div class="weui-popup__modal">
        <div style="height: 100vh"><img id="photo"></div>
        <div class="pub_funcbar">
            <a class="weui-btn close-popup weui-btn_primary" data-method="confirm">确定</a>
            <a class="weui-btn close-popup weui-btn_default" data-method="destroy">取消</a>
        </div>
    </div>
</div><?php $tabbar=0;?><?php include template('xigua_hb:common_footer'); include template('xigua_hb:enter_up'); ?>