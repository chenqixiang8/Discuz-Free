<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?><?php
$__FORMHASH = FORMHASH;$html = <<<EOF

<script>
function f_getOption(){
    var minwidth     = '{$config['minwidth']}';
    var minheight    = '{$config['minheight']}';
    var ignoreext    = {$config['ignoreext']};
    var ignorelink    = {$config['ignorelink']};

    var defaulttitle = '{$config['defaulttitle']}';
    var defaultlogo  = '{$config['defaultlogo']}';
    var defaultdesc  = '{$config['defaultdesc']}';

    var f_title = document.title ? document.title : defaulttitle;
    if(typeof custom_title !== 'undefined'){
        f_title = custom_title;
    }
    var f_img = defaultlogo;
    var f_desc = defaultdesc;

    var metadom = jQuery('meta[name="description"]');
    f_desc = metadom.length> 0 ? metadom.attr('content') : defaultdesc;
    
EOF;
 if($_GET['isuse']) { 
$html .= <<<EOF

    f_desc = jQuery.trim(jQuery(jQuery('.detailCon')[0]).find('h2').next().text()).substr(0, 50);
    
EOF;
 } 
$html .= <<<EOF


    var f_imglist = jQuery('img');
    for(var i=0; i<f_imglist.length; i++){
        if(!f_imglist[i].src || (ignoreext && ignoreext.test(f_imglist[i].src)) || (ignorelink && ignorelink.test(f_imglist[i].src))){
            continue;
        }
        if(minwidth && f_imglist[i].naturalWidth < minwidth){
            continue;
        }
        if(minheight && f_imglist[i].naturalHeight < minheight){
            continue;
        }
        f_img = f_imglist[i].src;
        break;
    }
    var ret = {
        title: f_title,
        desc: f_desc,
        link: get_currenturl(),
        imgUrl: f_parseimg(f_img)
    };
    console.log(ret);
    return ret;
}
function get_currenturl() {
    var loc = location.href.split('#')[0];
    return loc;
}
function Anmi(obj, x, fast, callback) {
    var ani = ' animated';
    if(fast == 'fast'){
        ani = ' animated-fast';
    }
    obj.removeClass().addClass(x + ani).one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function(){
        jQuery(this).removeClass();
        if(callback && typeof callback == 'function') {
            callback();
        }
    });
}
function f_parseimg(img) {
    if(img.indexOf('http://')===-1 && img.indexOf('https://')===-1){
        img = "{$_G['siteurl']}"+img;
    }
    if(typeof customImg!=='undefined'){
        img = customImg;
    }
    return img;
}

jQuery(function () {
    var f_iosActionsheet = jQuery('#f_iosActionsheet');
    var f_iosMask = jQuery('#f_iosMask');
    function f_hideActionSheet() {
        f_iosActionsheet.removeClass('weui-actionsheet_toggle');
        f_iosMask.fadeOut(200);
    }
    f_iosMask.on('click', f_hideActionSheet);
    jQuery('#f_iosActionsheetCancel').on('click', f_hideActionSheet);
    jQuery("
EOF;
 if($config['trigger']) { 
$html .= <<<EOF
#{$config['trigger']}, .{$config['trigger']} ,
EOF;
 } 
$html .= <<<EOF
 .f_sharebtn").removeAttr('onclick').unbind( "click").unbind("touchstart").unbind("touchend").on("click", function(){
        f_iosActionsheet.addClass('weui-actionsheet_toggle');
        f_iosMask.fadeIn(200);
    });
});

</script>


EOF;
 if($inwechat) { 
$html .= <<<EOF

<script>!function(e,n){"function"==typeof define&&(define.amd||define.cmd)?define(function(){return n(e)}):n(e,!0)}(this,function(e,n){function i(n,i,t){e.WeixinJSBridge?WeixinJSBridge.invoke(n,o(i),function(e){c(n,e,t)}):u(n,t)}function t(n,i,t){e.WeixinJSBridge?WeixinJSBridge.on(n,function(e){t&&t.trigger&&t.trigger(e),c(n,e,i)}):t?u(n,t):u(n,i)}function o(e){return e=e||{},e.appId=C.appId,e.verifyAppId=C.appId,e.verifySignType="sha1",e.verifyTimestamp=C.timestamp+"",e.verifyNonceStr=C.nonceStr,e.verifySignature=C.signature,e}function r(e){return{timeStamp:e.timestamp+"",nonceStr:e.nonceStr,package:e.package,paySign:e.paySign,signType:e.signType||"SHA1"}}function a(e){return e.postalCode=e.addressPostalCode,delete e.addressPostalCode,e.provinceName=e.proviceFirstStageName,delete e.proviceFirstStageName,e.cityName=e.addressCitySecondStageName,delete e.addressCitySecondStageName,e.countryName=e.addressCountiesThirdStageName,delete e.addressCountiesThirdStageName,e.detailInfo=e.addressDetailInfo,delete e.addressDetailInfo,e}function c(e,n,i){"openEnterpriseChat"==e&&(n.errCode=n.err_code),delete n.err_code,delete n.err_desc,delete n.err_detail;var t=n.errMsg;t||(t=n.err_msg,delete n.err_msg,t=s(e,t),n.errMsg=t),(i=i||{})._complete&&(i._complete(n),delete i._complete),t=n.errMsg||"",C.debug&&!i.isInnerInvoke&&alert(JSON.stringify(n));var o=t.indexOf(":");switch(t.substring(o+1)){case"ok":i.success&&i.success(n);break;case"cancel":i.cancel&&i.cancel(n);break;default:i.fail&&i.fail(n)}i.complete&&i.complete(n)}function s(e,n){var i=e,t=v[i];t&&(i=t);var o="ok";if(n){var r=n.indexOf(":");"confirm"==(o=n.substring(r+1))&&(o="ok"),"failed"==o&&(o="fail"),-1!=o.indexOf("failed_")&&(o=o.substring(7)),-1!=o.indexOf("fail_")&&(o=o.substring(5)),"access denied"!=(o=(o=o.replace(/_/g," ")).toLowerCase())&&"no permission to execute"!=o||(o="permission denied"),"config"==i&&"function not exist"==o&&(o="ok"),""==o&&(o="fail")}return n=i+":"+o}function d(e){if(e){for(var n=0,i=e.length;n<i;++n){var t=e[n],o=h[t];o&&(e[n]=o)}return e}}function u(e,n){if(!(!C.debug||n&&n.isInnerInvoke)){var i=v[e];i&&(e=i),n&&n._complete&&delete n._complete,console.log('"'+e+'",',n||"")}}function l(e){if(!(w||T||C.debug||x<"6.0.2"||V.systemType<0)){var n=new Image;V.appId=C.appId,V.initTime=A.initEndTime-A.initStartTime,V.preVerifyTime=A.preVerifyEndTime-A.preVerifyStartTime,N.getNetworkType({isInnerInvoke:!0,success:function(e){V.networkType=e.networkType;var i="https://open.weixin.qq.com/sdk/report?v="+V.version+"&o="+V.isPreVerifyOk+"&s="+V.systemType+"&c="+V.clientVersion+"&a="+V.appId+"&n="+V.networkType+"&i="+V.initTime+"&p="+V.preVerifyTime+"&u="+V.url;n.src=i}})}}function p(){return(new Date).getTime()}function f(n){k&&(e.WeixinJSBridge?"preInject"===I.__wxjsjs__isPreInject?I.addEventListener&&I.addEventListener("WeixinJSBridgeReady",n,!1):n():I.addEventListener&&I.addEventListener("WeixinJSBridgeReady",n,!1))}function m(){N.invoke||(N.invoke=function(n,i,t){e.WeixinJSBridge&&WeixinJSBridge.invoke(n,o(i),t)},N.on=function(n,i){e.WeixinJSBridge&&WeixinJSBridge.on(n,i)})}function g(e){if("string"==typeof e&&e.length>0){var n=e.split("?")[0],i=e.split("?")[1];return n+=".html",void 0!==i?n+"?"+i:n}}if(!e.jWeixin){var h={config:"preVerifyJSAPI",onMenuShareTimeline:"menu:share:timeline",onMenuShareAppMessage:"menu:share:appmessage",onMenuShareQQ:"menu:share:qq",onMenuShareWeibo:"menu:share:weiboApp",onMenuShareQZone:"menu:share:QZone",previewImage:"imagePreview",getLocation:"geoLocation",openProductSpecificView:"openProductViewWithPid",addCard:"batchAddCard",openCard:"batchViewCard",chooseWXPay:"getBrandWCPayRequest",openEnterpriseRedPacket:"getRecevieBizHongBaoRequest",startSearchBeacons:"startMonitoringBeacons",stopSearchBeacons:"stopMonitoringBeacons",onSearchBeacons:"onBeaconsInRange",consumeAndShareCard:"consumedShareCard",openAddress:"editAddress"},v=function(){var e={};for(var n in h)e[h[n]]=n;return e}(),I=e.document,S=I.title,y=navigator.userAgent.toLowerCase(),_=navigator.platform.toLowerCase(),w=!(!_.match("mac")&&!_.match("win")),T=-1!=y.indexOf("wxdebugger"),k=-1!=y.indexOf("micromessenger"),M=-1!=y.indexOf("android"),P=-1!=y.indexOf("iphone")||-1!=y.indexOf("ipad"),x=function(){var e=y.match(/micromessenger\/(\d+\.\d+\.\d+)/)||y.match(/micromessenger\/(\d+\.\d+)/);return e?e[1]:""}(),A={initStartTime:p(),initEndTime:0,preVerifyStartTime:0,preVerifyEndTime:0},V={version:1,appId:"",initTime:0,preVerifyTime:0,networkType:"",isPreVerifyOk:1,systemType:P?1:M?2:-1,clientVersion:x,url:encodeURIComponent(location.href)},C={},L={_completes:[]},B={state:0,data:{}};f(function(){A.initEndTime=p()});var E=!1,O=[],N={config:function(e){C=e,u("config",e);var n=!1!==C.check;f(function(){if(n)i(h.config,{verifyJsApiList:d(C.jsApiList)},function(){L._complete=function(e){A.preVerifyEndTime=p(),B.state=1,B.data=e},L.success=function(e){V.isPreVerifyOk=0},L.fail=function(e){L._fail?L._fail(e):B.state=-1};var e=L._completes;return e.push(function(){l()}),L.complete=function(n){for(var i=0,t=e.length;i<t;++i)e[i]();L._completes=[]},L}()),A.preVerifyStartTime=p();else{B.state=1;for(var e=L._completes,t=0,o=e.length;t<o;++t)e[t]();L._completes=[]}}),m()},ready:function(e){0!=B.state?e():(L._completes.push(e),!k&&C.debug&&e())},error:function(e){x<"6.0.2"||(-1==B.state?e(B.data):L._fail=e)},checkJsApi:function(e){var n=function(e){var n=e.checkResult;for(var i in n){var t=v[i];t&&(n[t]=n[i],delete n[i])}return e};i("checkJsApi",{jsApiList:d(e.jsApiList)},(e._complete=function(e){if(M){var i=e.checkResult;i&&(e.checkResult=JSON.parse(i))}e=n(e)},e))},onMenuShareTimeline:function(e){t(h.onMenuShareTimeline,{complete:function(){i("shareTimeline",{title:e.title||S,desc:e.title||S,img_url:e.imgUrl||"",link:e.link||location.href,type:e.type||"link",data_url:e.dataUrl||""},e)}},e)},onMenuShareAppMessage:function(e){t(h.onMenuShareAppMessage,{complete:function(n){"favorite"===n.scene?i("sendAppMessage",{title:e.title||S,desc:e.desc||"",link:e.link||location.href,img_url:e.imgUrl||"",type:e.type||"link",data_url:e.dataUrl||""}):i("sendAppMessage",{title:e.title||S,desc:e.desc||"",link:e.link||location.href,img_url:e.imgUrl||"",type:e.type||"link",data_url:e.dataUrl||""},e)}},e)},onMenuShareQQ:function(e){t(h.onMenuShareQQ,{complete:function(){i("shareQQ",{title:e.title||S,desc:e.desc||"",img_url:e.imgUrl||"",link:e.link||location.href},e)}},e)},onMenuShareWeibo:function(e){t(h.onMenuShareWeibo,{complete:function(){i("shareWeiboApp",{title:e.title||S,desc:e.desc||"",img_url:e.imgUrl||"",link:e.link||location.href},e)}},e)},onMenuShareQZone:function(e){t(h.onMenuShareQZone,{complete:function(){i("shareQZone",{title:e.title||S,desc:e.desc||"",img_url:e.imgUrl||"",link:e.link||location.href},e)}},e)},startRecord:function(e){i("startRecord",{},e)},stopRecord:function(e){i("stopRecord",{},e)},onVoiceRecordEnd:function(e){t("onVoiceRecordEnd",e)},playVoice:function(e){i("playVoice",{localId:e.localId},e)},pauseVoice:function(e){i("pauseVoice",{localId:e.localId},e)},stopVoice:function(e){i("stopVoice",{localId:e.localId},e)},onVoicePlayEnd:function(e){t("onVoicePlayEnd",e)},uploadVoice:function(e){i("uploadVoice",{localId:e.localId,isShowProgressTips:0==e.isShowProgressTips?0:1},e)},downloadVoice:function(e){i("downloadVoice",{serverId:e.serverId,isShowProgressTips:0==e.isShowProgressTips?0:1},e)},translateVoice:function(e){i("translateVoice",{localId:e.localId,isShowProgressTips:0==e.isShowProgressTips?0:1},e)},chooseImage:function(e){i("chooseImage",{scene:"1|2",count:e.count||9,sizeType:e.sizeType||["original","compressed"],sourceType:e.sourceType||["album","camera"]},(e._complete=function(e){if(M){var n=e.localIds;n&&(e.localIds=JSON.parse(n))}},e))},getLocation:function(e){},previewImage:function(e){i(h.previewImage,{current:e.current,urls:e.urls},e)},uploadImage:function(e){i("uploadImage",{localId:e.localId,isShowProgressTips:0==e.isShowProgressTips?0:1},e)},downloadImage:function(e){i("downloadImage",{serverId:e.serverId,isShowProgressTips:0==e.isShowProgressTips?0:1},e)},getLocalImgData:function(e){!1===E?(E=!0,i("getLocalImgData",{localId:e.localId},(e._complete=function(e){if(E=!1,O.length>0){var n=O.shift();wx.getLocalImgData(n)}},e))):O.push(e)},getNetworkType:function(e){var n=function(e){var n=e.errMsg;e.errMsg="getNetworkType:ok";var i=e.subtype;if(delete e.subtype,i)e.networkType=i;else{var t=n.indexOf(":"),o=n.substring(t+1);switch(o){case"wifi":case"edge":case"wwan":e.networkType=o;break;default:e.errMsg="getNetworkType:fail"}}return e};i("getNetworkType",{},(e._complete=function(e){e=n(e)},e))},openLocation:function(e){i("openLocation",{latitude:e.latitude,longitude:e.longitude,name:e.name||"",address:e.address||"",scale:e.scale||28,infoUrl:e.infoUrl||""},e)},getLocation:function(e){e=e||{},i(h.getLocation,{type:e.type||"wgs84"},(e._complete=function(e){delete e.type},e))},hideOptionMenu:function(e){i("hideOptionMenu",{},e)},showOptionMenu:function(e){i("showOptionMenu",{},e)},closeWindow:function(e){i("closeWindow",{},e=e||{})},hideMenuItems:function(e){i("hideMenuItems",{menuList:e.menuList},e)},showMenuItems:function(e){i("showMenuItems",{menuList:e.menuList},e)},hideAllNonBaseMenuItem:function(e){i("hideAllNonBaseMenuItem",{},e)},showAllNonBaseMenuItem:function(e){i("showAllNonBaseMenuItem",{},e)},scanQRCode:function(e){i("scanQRCode",{needResult:(e=e||{}).needResult||0,scanType:e.scanType||["qrCode","barCode"]},(e._complete=function(e){if(P){var n=e.resultStr;if(n){var i=JSON.parse(n);e.resultStr=i&&i.scan_code&&i.scan_code.scan_result}}},e))},openAddress:function(e){i(h.openAddress,{},(e._complete=function(e){e=a(e)},e))},openProductSpecificView:function(e){i(h.openProductSpecificView,{pid:e.productId,view_type:e.viewType||0,ext_info:e.extInfo},e)},addCard:function(e){for(var n=e.cardList,t=[],o=0,r=n.length;o<r;++o){var a=n[o],c={card_id:a.cardId,card_ext:a.cardExt};t.push(c)}i(h.addCard,{card_list:t},(e._complete=function(e){var n=e.card_list;if(n){for(var i=0,t=(n=JSON.parse(n)).length;i<t;++i){var o=n[i];o.cardId=o.card_id,o.cardExt=o.card_ext,o.isSuccess=!!o.is_succ,delete o.card_id,delete o.card_ext,delete o.is_succ}e.cardList=n,delete e.card_list}},e))},chooseCard:function(e){i("chooseCard",{app_id:C.appId,location_id:e.shopId||"",sign_type:e.signType||"SHA1",card_id:e.cardId||"",card_type:e.cardType||"",card_sign:e.cardSign,time_stamp:e.timestamp+"",nonce_str:e.nonceStr},(e._complete=function(e){e.cardList=e.choose_card_info,delete e.choose_card_info},e))},openCard:function(e){for(var n=e.cardList,t=[],o=0,r=n.length;o<r;++o){var a=n[o],c={card_id:a.cardId,code:a.code};t.push(c)}i(h.openCard,{card_list:t},e)},consumeAndShareCard:function(e){i(h.consumeAndShareCard,{consumedCardId:e.cardId,consumedCode:e.code},e)},chooseWXPay:function(e){i(h.chooseWXPay,r(e),e)},openEnterpriseRedPacket:function(e){i(h.openEnterpriseRedPacket,r(e),e)},startSearchBeacons:function(e){i(h.startSearchBeacons,{ticket:e.ticket},e)},stopSearchBeacons:function(e){i(h.stopSearchBeacons,{},e)},onSearchBeacons:function(e){t(h.onSearchBeacons,e)},openEnterpriseChat:function(e){i("openEnterpriseChat",{useridlist:e.userIds,chatname:e.groupName},e)},launchMiniProgram:function(e){i("launchMiniProgram",{targetAppId:e.targetAppId,path:g(e.path),envVersion:e.envVersion},e)},miniProgram:{navigateBack:function(e){e=e||{},f(function(){i("invokeMiniProgramAPI",{name:"navigateBack",arg:{delta:e.delta||1}},e)})},navigateTo:function(e){f(function(){i("invokeMiniProgramAPI",{name:"navigateTo",arg:{url:e.url}},e)})},redirectTo:function(e){f(function(){i("invokeMiniProgramAPI",{name:"redirectTo",arg:{url:e.url}},e)})},switchTab:function(e){f(function(){i("invokeMiniProgramAPI",{name:"switchTab",arg:{url:e.url}},e)})},reLaunch:function(e){f(function(){i("invokeMiniProgramAPI",{name:"reLaunch",arg:{url:e.url}},e)})},postMessage:function(e){f(function(){i("invokeMiniProgramAPI",{name:"postMessage",arg:e.data||{}},e)})},getEnv:function(n){f(function(){n({miniprogram:"miniprogram"===e.__wxjs_environment})})}}},b=1,R={};return I.addEventListener("error",function(e){if(!M){var n=e.target,i=n.tagName,t=n.src;if(("IMG"==i||"VIDEO"==i||"AUDIO"==i||"SOURCE"==i)&&-1!=t.indexOf("wxlocalresource://")){e.preventDefault(),e.stopPropagation();var o=n["wx-id"];if(o||(o=b++,n["wx-id"]=o),R[o])return;R[o]=!0,wx.ready(function(){wx.getLocalImgData({localId:t,success:function(e){n.src=e.localData}})})}}},!0),I.addEventListener("load",function(e){if(!M){var n=e.target,i=n.tagName;n.src;if("IMG"==i||"VIDEO"==i||"AUDIO"==i||"SOURCE"==i){var t=n["wx-id"];t&&(R[t]=!1)}}},!0),n&&(e.wx=e.jWeixin=N),N}});</script>
<script>
    var X_STRP = 1;
    var X_IOS = !!navigator.userAgent.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/);
    initJSAPI();
    function initJSAPI(){
        jQuery.ajax({
            url: 'plugin.php?id=xigua_f:sign',
            cache: false,
            dataType: "json",
            data: {formhash:'{$__FORMHASH}', url: get_currenturl()},
            type: "GET",
            success:function(res){
                if(typeof res.appid == 'undefined'){
                    
EOF;
 if($config['debug']=='true') { 
$html .= <<<EOF

                    alert(JSON.stringify(res));
                    
EOF;
 } else { 
$html .= <<<EOF

                    console.log(res);
                    
EOF;
 } 
$html .= <<<EOF

                    return false;
                }
                wx.config({
                    debug: {$config['debug']},
                    appId: res.appid,
                    timestamp: res.timestamp,
                    nonceStr: res.nonceStr,
                    signature: res.signature,
                    jsApiList: [
                        'onMenuShareTimeline',
                        'onMenuShareAppMessage',
                        'onMenuShareQQ',
                        'onMenuShareWeibo',
                        'onMenuShareQZone',
                        'setNavigationBarColor',
                        'setBounceBackground',
                        'hideMenuItems','scanQRCode',
                        'checkJsApi','chooseImage','previewImage','uploadImage','downloadImage',
                        'openLocation', 'getLocation',
                        'translateVoice','startRecord',
                        'stopRecord', 'onVoiceRecordEnd', 'playVoice', 'onVoicePlayEnd', 'pauseVoice', 'stopVoice', 'uploadVoice', 'downloadVoice'
                    ]
                });
                wx.ready(function () {
                    var option = f_getOption();
                    var option_config ={
                        title: option.title,
                        desc: option.desc,
                        link: option.link,
                        imgUrl: option.imgUrl,
                        success:function(){ if(typeof menuShareCommon == 'function'){menuShareCommon();} if(typeof shareIncr === 'function'){shareIncr();} },
                        cancel:function(){ if(typeof menuShareCommonErr == 'function'){menuShareCommonErr();} }
                    };
                    var autotitle = ((typeof TIMELINE_TITLE=='undefined') ? option.title : TIMELINE_TITLE);
                    console.log(autotitle);
                    wx.onMenuShareTimeline({
                        title:autotitle,
                        desc: option.desc,
                        link: option.link,
                        imgUrl: option.imgUrl,
                        success:function(){ if(typeof menuShareTimeline == 'function'){menuShareTimeline();} if(typeof shareIncr === 'function'){shareIncr();} },
                        cancel:function(){X_STRP = 0; if(typeof menuShareTimelineErr == 'function'){menuShareTimelineErr();} },
                        fail:function(){  X_STRP = 0; if(typeof menuShareTimelineErr == 'function'){menuShareTimelineErr();} }
EOF;
 if($config['iospyq']) { 
$html .= <<<EOF
,
                        trigger: function (res) {
                            if(X_IOS){
                            X_STRP = 1;setTimeout(function () {
                                if(X_STRP===1){
                                    if(typeof menuShareTimeline == 'function'){menuShareTimeline();} if(typeof shareIncr === 'function'){shareIncr();}
                                }
                            }, 4500);
                            }
                        }
                        
EOF;
 } 
$html .= <<<EOF

                    });
                    wx.onMenuShareQQ(option_config);
                    wx.onMenuShareAppMessage(option_config);
                    wx.onMenuShareWeibo(option_config);
                    
EOF;
 if($config['hidelink']) { 
$html .= <<<EOF

                    wx.hideMenuItems({
                        menuList: [
                            "menuItem:copyUrl",
                            "menuItem:originPage",
                            "menuItem:readMode",
                            "menuItem:openWithQQBrowser",
                            "menuItem:openWithSafari",
                            "menuItem:share:email"
                        ]
                    });
                    
EOF;
 } 
$html .= <<<EOF

                    if($("#auto_play").length>0) {
                        $('#auto_play')[0].play();
                    }
                    if (window.__wxjs_environment === 'miniprogram'){
                        wx.miniProgram.postMessage({ data: {
EOF;
 if($config['xcxjr']) { 
$html .= <<<EOF
imgUrl:option.imgUrl, 
EOF;
 } 
$html .= <<<EOF
title:option.title, desc:option.desc, link:option.link} })
                    }
                });
            }
        });
    }
</script>

EOF;
 } elseif($inmqqbrowser||$inmucbrowser) { 
$html .= <<<EOF

<script>
    var bShare = function (elementNode, config) {

        var qApiSrc = {
            lower: "//3gimg.qq.com/html5/js/qb.js",
            higher: "//jsapi.qq.com/get?api=app.share"
        };
        var bLevel = {
            qq: {forbid: 0, lower: 1, higher: 2},
            uc: {forbid: 0, allow: 1}
        };
        var UA = navigator.appVersion;
        var isqqBrowser = (UA.split("MQQBrowser/").length > 1) ? bLevel.qq.higher : bLevel.qq.forbid;
        var isucBrowser = (UA.split("UCBrowser/").length > 1) ? bLevel.uc.allow : bLevel.uc.forbid;
        var version = {
            uc: "",
            qq: ""
        };
        var isWeixin = false;

        config = config || {};
        this.url = config.url || document.location.href || '';
        this.title = config.title || document.title || '';
        this.desc = config.desc || document.title || '';
        this.img = config.img || document.getElementsByTagName('img').length > 0 && document.getElementsByTagName('img')[0].src || '';
        this.img_title = config.img_title || document.title || '';
        this.from = config.from || window.location.host || '';
        this.ucAppList = {
            sinaWeibo: ['kSinaWeibo', 'SinaWeibo', 11, '新浪微博'],
            weixin: ['kWeixin', 'WechatFriends', 1, '微信好友'],
            weixinFriend: ['kWeixinFriend', 'WechatTimeline', '8', '微信朋友圈'],
            QQ: ['kQQ', 'QQ', '4', 'QQ好友'],
            QZone: ['kQZone', 'QZone', '3', 'QQ空间']
        };

        this.share = function (to_app) {
            var title = this.title, url = this.url, desc = this.desc, img = this.img, img_title = this.img_title, from = this.from;
            if (isucBrowser) {
                to_app = to_app == '' ? '' : (platform_os == 'iPhone' ? this.ucAppList[to_app][0] : this.ucAppList[to_app][1]);
                if (to_app == 'QZone') {
                    B = "mqqapi://share/to_qzone?src_type=web&amp;version=1&amp;file_type=news&amp;req_type=1&amp;image_url="+img+"&title="+title+"&description="+desc+"&url="+url+"&app_name="+from;
                    k = document.createElement("div"), k.style.visibility = "hidden", k.innerHTML = '<iframe src="' + B + '" scrolling="no" width="1" height="1"></iframe>', document.body.appendChild(k), setTimeout(function () {
                        k && k.parentNode && k.parentNode.removeChild(k)
                    }, 5E3);
                }
                if (typeof(ucweb) != "undefined") {
                    ucweb.startRequest("shell.page_share", [title, title, url, to_app, "", "@" + from, ""])
                } else {
                    if (typeof(ucbrowser) != "undefined") {
                        ucbrowser.web_share(title, title, url, to_app, "", "@" + from, '')
                    } else {
                    }
                }
            } else {
                if (isqqBrowser && !isWeixin) {
                    to_app = to_app == '' ? '' : this.ucAppList[to_app][2];
                    var ah = {
                        url: url,
                        title: title,
                        description: desc,
                        img_url: img,
                        img_title: img_title,
                        to_app: to_app,//΢�ź���1,��Ѷ΢��2,QQ�ռ�3,QQ����4,���ɶ�ά��7,΢������Ȧ8,�౷���9,������ַ10,������΢��11,�������13
                        cus_txt: "请输入此时此刻想要分享的内容"
                    };
                    ah = to_app == '' ? '' : ah;
                    if (typeof(browser) != "undefined") {
                        if (typeof(browser.app) != "undefined" && isqqBrowser == bLevel.qq.higher) {
                            browser.app.share(ah)
                        }
                    } else {
                        if (typeof(window.qb) != "undefined" && isqqBrowser == bLevel.qq.lower) {
                            window.qb.share(ah)
                        } else {
                        }
                    }
                } else {
                }
            }
        };
        this.isloadqqApi = function () {
            if (isqqBrowser) {
                var b = (version.qq < 5.4) ? qApiSrc.lower : qApiSrc.higher;
                var d = document.createElement("script");
                var a = document.getElementsByTagName("body")[0];
                d.setAttribute("src", b);
                a.appendChild(d)
            }
        };

        this.getPlantform = function () {
            ua = navigator.userAgent;
            if ((ua.indexOf("iPhone") > -1 || ua.indexOf("iPod") > -1)) {
                return "iPhone"
            }
            return "Android"
        };

        this.is_weixin = function () {
            var a = UA.toLowerCase();
            if (a.match(/MicroMessenger/i) == "micromessenger") {
                return true
            } else {
                return false
            }
        };

        this.getVersion = function (c) {
            var a = c.split("."), b = parseFloat(a[0] + "." + a[1]);
            return b
        };

        this.init = function () {
            platform_os = this.getPlantform();
            version.qq = isqqBrowser ? this.getVersion(UA.split("MQQBrowser/")[1]) : 0;
            version.uc = isucBrowser ? this.getVersion(UA.split("UCBrowser/")[1]) : 0;
            isWeixin = this.is_weixin();
            if ((isqqBrowser && version.qq < 5.4 && platform_os == "iPhone") || (isqqBrowser && version.qq < 5.3 && platform_os == "Android")) {
                isqqBrowser = bLevel.qq.forbid
            } else {
                if (isqqBrowser && version.qq < 5.4 && platform_os == "Android") {
                    isqqBrowser = bLevel.qq.lower
                } else {
                    if (isucBrowser && ((version.uc < 10.2 && platform_os == "iPhone") || (version.uc < 9.7 && platform_os == "Android"))) {
                        isucBrowser = bLevel.uc.forbid
                    }
                }
            }
            this.isloadqqApi();
            if (isqqBrowser || isucBrowser) {
                jQuery(elementNode).fadeIn();
            }
        };

        this.init();

        var share = this;
        var items = document.getElementsByClassName('bShare');
        for (var i=0;i<items.length;i++) {
            items[i].onclick = function(){
                share.share(this.getAttribute('data-app'));
            }
        }

        return this;
    };
    setTimeout(function () {
        var option = f_getOption();
        var config = {
            url:option.link,
            title:option.title,
            desc:option.desc,
            img:option.imgUrl,
            img_title:option.title,
            from:'{$_G['setting']['bbname']}'
        };
        new bShare('#f_Share',config);
    }, {$config['dely']});
</script>

EOF;
 } if(!($inmqqbrowser||$inmucbrowser) || $inwechat) { 
$html .= <<<EOF

<script>
    setTimeout(function(){
        var option = f_getOption();
        jQuery.ajax({
            url: 'plugin.php?id=xigua_f:sign',
            cache: false,
            dataType: "json",
            data: {formhash:'{$__FORMHASH}',sharelink:1, option:option},
            contentType: "application/x-www-form-urlencoded; charset=utf-8",
            type: "POST",
            success: function(data){
                console.log(data);
                jQuery('.qq').on('click',function () {
                    window.location.href = data.qq;
                });
                jQuery('.weibo').on('click',function () {
                    window.location.href = data.weibo;
                });
                jQuery('.qzone').on('click',function () {
                    window.location.href = data.qzone;
                });
            }
        });
    }, {$config['dely']});
    var wechatbtn = jQuery('.weixin,.weixin_timeline');
    var wechatmask = jQuery('#wechat-masker');
    wechatmask.find('div').hide();
    
EOF;
 if($inwechat) { 
$html .= <<<EOF

    var wechatguider = jQuery('#wechat-guider');
    var showmethd = 'fadeInUp';
    
EOF;
 } else { 
$html .= <<<EOF

    var wechatguider = jQuery('#other-guider');
    var showmethd = 'fadeInDown';
    
EOF;
 } 
$html .= <<<EOF

    wechatguider.show();

    wechatbtn.on('click',function(){
        wechatmask.show();
        Anmi(wechatguider, showmethd, 'fast');
        Anmi(wechatmask, 'fadeIn', 'fast');
    });
    wechatmask.on('click',function(){
        Anmi(wechatguider, 'fadeOutUp', 'normal');
        Anmi(wechatmask, 'fadeOut', 'normal', function(){
            wechatmask.hide();
        });
    });
</script>

EOF;
 } if($config['addmocuz']) { 
$html .= <<<EOF

<script type="text/javascript">
var opter = f_getOption();
var mocuz_share_config = {
    link: opter.link,
    subject: opter.title,
    description: opter.desc,
    icon: opter.imgUrl
};
!function(a){var b={Android:function(){return/Android/i.test(navigator.userAgent)},BlackBerry:function(){return/BlackBerry/i.test(navigator.userAgent)},iOS:function(){return/iPhone|iPad|iPod/i.test(navigator.userAgent)},Windows:function(){return/IEMobile/i.test(navigator.userAgent)},any:function(){return isMobile.Android()||isMobile.BlackBerry()||isMobile.iOS()||isMobile.Windows()}},c='{"shareSNS":{"sharelink":"'+a.link+'","shareIcon":"'+a.icon+'","sharetext":"'+a.description+'","shareshow":"","sharesubject":"'+a.subject+'"}}';window.addEventListener("load",function(){b.Android()?(window.myjs.shareshow(),window.myjs.jiaohu(c)):b.iOS()&&(location.href="objc://jiaohu:/"+c,setTimeout(function(){location.href="objc://shareshow"},500))})}(mocuz_share_config);
</script>

EOF;
 } 
$html .= <<<EOF


EOF;
?>