<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); 
0
|| checktplrefresh('./source/plugin/xigua_hb/template/tuijian.htm', './source/plugin/xigua_hb/template/three_list.htm', 1605508349, 'xigua_hb', './data/template/1_xigua_hb_tuijian.tpl.php', './source/plugin/xigua_hb/template', 'tuijian')
;?>
<?php if($tuijianlist) { ?>
<div class="recomand">
    <div class="inner home-inner"><h4 class="recomand-title">为你推荐</h4>
        <div class="recomand-content clearfix">
            <?php if(is_array($tuijianlist)) foreach($tuijianlist as $_k => $_v) { ?>            <?php $_v[vars] = array_values($_v[vars]); $top3 = array_slice($_v[vars], 0, 3); $top3cnt = count($top3);?><a href="<?php echo hb_pc_rewriteoutput('view_page', $_v['id']); ?>" target="_blank"  class="item" >
    <div class="item-title ellipsis <?php if(!$top3) { ?>towrow<?php } ?>"><?php echo strip_tags($_v['description']); ?></div>
    <p class="job-requirement ellipsis">
        <?php if(is_array($top3)) foreach($top3 as $__k => $__v) { ?>        <?php if(!$__v['html']) { ?>
        <?php continue;?>        <?php } ?>
        <span><?php echo $__v['html'];?></span>
        <?php if($__k<$top3cnt-1) { ?>
        <em class="vline"></em>
        <?php } ?>
        <?php } ?>
    </p>
    <p class="job-compnay ellipsis"><?php echo $newlist_cat_all[$_v['catid']]['name'];?></p>
    <div class="job-salary-box">
        <?php if($_v['vars']['0']['html']) { ?>
        <div class="salary-container" >
            <span class="salary"><?php echo cutstr(str_replace(' ', '', $_v['vars']['0']['html']), 14); ?></span>
        </div>
        <?php } else { ?><?php echo $_v['realname'];?><?php echo $_v['time_u'];?>发布
        <?php } ?>
        <?php if($_v['tags']['0']) { ?>
        <span class="bao-tag"><em><?php echo $_v['tags']['0'];?></em></span>
        <?php } ?>
    </div>
</a>
            <?php } ?>
        </div>
    </div>
</div>
<?php } ?>