<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); if($ac=='index' && $config['showheader']) { $hide_nav = 0;?><?php } if((getcookie('miniprogram')||IN_PROG) && $ac=='index') { $hide_nav = 0;?><?php } if(!$hide_nav) { if($ac=='index') { ?>
<header class="x_header bgcolor_11 cl  weui-flex f15" <?php if($config['intopindex']) { ?>style="background:transparent!important;position:absolute"<?php } ?>>
<?php if($_G['cache']['plugin']['xigua_st']['showfz']) { ?>
<span onclick="window.location.href='<?php echo $SCRITPTNAME;?>?id=xigua_st&ac=city<?php echo $urlext;?>'" class="fzopen"><?php echo $stinfo['name2']?$stinfo['name2']:$_G['cache']['plugin']['xigua_st']['zongname']; ?> <i class="iconfont icon-xiangxia f13"></i></span>
<?php } else { ?>
    <a class="z x_logo" href="<?php echo $SCRITPTNAME;?>?id=xigua_hb"><?php if(strpos($config['logo'],'/')!==false) { ?><img src="<?php echo $config['logo'];?>" /> <?php } else { ?><span style="margin:0 .75rem"><?php echo $config['logo'];?></span><?php } ?></a><?php } ?>
    <form class="z x_form" style="position: relative;" id="search" method="get" action="<?php echo $SCRITPTNAME;?>">
        <input type="hidden" name="id" value="xigua_hb">
        <input type="hidden" name="ac" value="cat">
        <input type="hidden" name="st" value="<?php echo $_GET['st'];?>">
        <input type="hidden" name="idu" value="<?php echo $_GET['idu'];?>">
        <input name="keyword" class="x_logo_input" type="text" value="" placeholder="<?php echo $config['sousuoinput'];?>" x-webkit-speech="" <?php if($config['intopindex']) { ?>style="background: rgba(255,255,255,.8)"<?php } ?>>
        <button class="x_logo_search main_color" <?php if(1) { ?>type="submit"<?php } else { ?>type="button" onclick="mag.newWin('<?php echo $_G['siteurl'];?>/<?php echo $SCRITPTNAME;?>?'+$('#search').serialize());"<?php } ?>>搜索</button>
    </form>
</header>
<?php } else { $back_to = "$SCRITPTNAME?id=xigua_hb";?><?php if($_SERVER['HTTP_REFERER']) { $back_to = "javascript:window.history.go(-1);";?><?php } if($ac=='pub'&&$_GET['step']==3) { $back_to = "$SCRITPTNAME?id=xigua_hb&ac=pub";?><?php } if(in_array($ac, array('mypub', 'myorder'))) { $back_to = "$SCRITPTNAME?id=xigua_hb&ac=my";?><?php } if($back_to_overwrite) { $back_to = $back_to_overwrite;?><?php } if($_GET['hide_side']) { $custom_side = array();?><?php } ?>
<header class="x_header bgcolor_11 cl f15">
    <a class="z f14" href="<?php echo $back_to;?>"><i class="iconfont icon-fanhuijiantou w15"></i><?php if(!$hidebackfont) { ?>返回<?php } ?></a>
    <?php if($need_side) { ?><a class="y sidectrl view_ctrl"><i class="iconfont icon-gengduo1 f22"></i></a><?php } ?>
    <?php if($custom_side) { ?><a class="y sidectrl <?php echo $custom_side['2'];?>" href="<?php echo $custom_side['0'];?>"><?php echo $custom_side['1'];?></a><?php } ?>
    <?php if(!$hidenav) { ?><div class="navtitle"><?php echo $anavtitle ? $anavtitle: $navtitle; ?></div><?php } ?>
</header>
<?php } if(!$no_header_fix) { ?>
<div class="x_header_fix" <?php if($config['intopindex']&&$ac=='index') { ?>style="display:none"<?php } ?>></div>
<?php } } ?>