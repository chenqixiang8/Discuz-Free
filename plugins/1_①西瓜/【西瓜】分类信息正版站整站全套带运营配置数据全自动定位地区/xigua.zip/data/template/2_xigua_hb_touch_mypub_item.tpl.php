<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); if(is_array($list)) foreach($list as $v) { $calltel = $v[mobile] ? "tel:$v[mobile]" : '';
if($v[weixin]):
$calltel = "javascript:lxfs_tip(this, '$v[mobile]', '$v[weixin]');";
endif;
$callfull = "showfull('$v[id]', '$v[mobile]', '','', '$v[weixin]');return false;";
if($v[wancheng]):
    $calltel = "javascript:$.toast('信息已结束','error');";
    $callfull = "showfull('$v[id]', '', '','', '');return false;";
else:
    $vcatid = $v[catid];
    $vtelp  = $cats[$vcatid]['telpri'];
    if($vtelp>0 && !($_G['uid']==$v[uid] || IS_ADMINID)):
        include DISCUZ_ROOT. 'source/plugin/xigua_hb/include/c_addon.php';
        if(!$viewtels[$v[id]] && !$ishk):
            $calltel = "javascript:hb_paytel('$v[id]','$vtelp','$vcatid');";
            $callfull = "showfull('$v[id]', '', '$vtelp','$vcatid', '$v[weixin]');return false;";
        endif;
    endif;
endif;
$hidegl = $_GET[stat]!='endts'&&!$v[wancheng];?><div class="li<?php if($v['wancheng']) { ?> op6<?php } ?>" id="li_<?php echo $v['id'];?>">
    <div class="po-avt-wrap">
        <a href="<?php echo $SCRITPTNAME;?>?id=xigua_hb&ac=member&uid=<?php echo $v['uid'];?>"><img class="po-avt" src="<?php echo avatar($v[uid], 'middle', true);?>"></a>
    </div>
    <div class="po-cmt">
        <div class="po-hd cl <?php if($cats[$v['catid']]['hidereal']) { ?>h30hide <?php } if($v['wancheng']) { ?>wxexpired1<?php } ?>" <?php if($v['wancheng'] && $cats[$v['catid']]['closeicon']) { ?>style="background-image:url(<?php echo $cats[$v['catid']]['closeicon'];?>)"<?php } ?>>
            <?php if(!$_GET['hb']) { ?>
            <?php if(!$v['pay_status']&& $_GET['is_my']) { ?>
            <a class="abs b-color8 mod-feed-tag main_color" style="top:1px" href="<?php echo $SCRITPTNAME;?>?id=xigua_hb&ac=pay&catid=<?php echo $v['catid'];?>&pubid=<?php echo $v['id'];?>"><?php if(IS_ADMINID) { ?>未支付<?php } else { ?>立即支付<?php } ?></a>
            <?php } else { ?>
                <?php if($v['display']) { ?>
            <?php if($v['endts']<TIMESTAMP) { ?>
                <a class="abs" style="color:#999" href="javascript:;"><?php echo $cats[$v['catid']]['name'];?></a>
            <?php } else { ?>
            <?php if($config['listcattype']!=2) { ?>
            <a class="abs <?php if($_GET['pinstyle']) { ?>pstyle1<?php } ?>" href="<?php echo $SCRITPTNAME;?>?id=xigua_hb&ac=cat&cat_id=<?php echo $v['catid'];?>"><?php echo $cats[$v['catid']]['name'];?></a>
            <?php } ?>
            <?php } ?>
                <?php } else { ?>
                <a class="abs b-color8 mod-feed-tag main_color">待审核 <?php echo $cats[$v['catid']]['name'];?></a>
                <?php } ?>
            <?php } ?>
            <?php } else { ?>
            <a class="abs color-red" href="javascript:;"><i class="iconfont icon-hot-02"></i> <?php echo $v['views'];?></a>
            <?php } ?>

            <div class="usr-name mod-usr-name lv">
                <span class="name"><?php echo $users[$v['uid']]['username'];?></span>
                <?php if($veris1[$v['uid']]) { if($_G['cache']['plugin']['xigua_hr']['grtb']) { ?><img class="rzimg vm" src="<?php echo $_G['cache']['plugin']['xigua_hr']['grtb'];?>" /> <?php } else { ?><i class="iconfont icon-erified color-forest vm"></i><?php } } ?>
                <?php if($veris2[$v['uid']]) { if($_G['cache']['plugin']['xigua_hr']['qytb']) { ?><img class="rzimg vm" src="<?php echo $_G['cache']['plugin']['xigua_hr']['qytb'];?>" /> <?php } else { ?><i class="iconfont icon-qiyerenzheng color-dropbox vm"></i><?php } } ?>
                <?php if($bao[$v['uid']]) { if(!$bao[$v['uid']]['icon']) { $bao[$v[uid]][icon] = $_G[cache][plugin][xigua_hr][bzjtb];?><?php } if($bao[$v['uid']]['icon']) { ?><img class="rzimg vm" src="<?php echo $bao[$v['uid']]['icon'];?>" /> <?php } else { ?><i class="iconfont icon-baozhengjinmoshi color-good vm" style="font-size:19px"></i><?php } if($_G['cache']['plugin']['xigua_hr']['bzjed']) { ?><span class="f13 main_color"><?php echo $_G['cache']['plugin']['xigua_hr']['lbbzjqz'];?><?php echo $bao[$v['uid']]['price'];?>元</span><?php } } ?>
                <?php if($v['dig_on']) { ?><div class="mod-lv is-star">置顶<?php if($_GET['is_my'] && ($_G['uid']==$v['uid']||IS_ADMINID)) { ?>剩<?php echo intval(($v['dig_endts']-TIMESTAMP)/86400);?>天<?php } ?></div><?php } ?>
                <?php if($v['hb_num']>$v['hb_sendnum']) { ?><div class="mod-lv is-hot view_jump" data-id="<?php echo $v['id'];?>" data-stid="<?php echo $v['stid'];?>">红包</div><?php } ?>
            </div>

            <div class="post cl">

                <?php if(array_filter($v['tags'])) { ?>
                <div class="cl mt8 item_tags view_jump" data-id="<?php echo $v['id'];?>" data-stid="<?php echo $v['stid'];?>">
                    <?php if(is_array($v['tags'])) foreach($v['tags'] as $k => $tag) { ?>                    <?php if($tag) { ?><span class="mod-feed-tag b-color<?php echo $k;?>"><?php echo $tag;?></span><?php } ?>
                    <?php } ?>
                </div>
                <?php } ?>
                <div id="view_jump_<?php echo $v['id'];?>" class="view_jump mod-feed-text is-three cl" data-id="<?php echo $v['id'];?>" data-stid="<?php echo $v['stid'];?>"><?php if($config['listcattype']==2) { ?><a class="bftag b-color0 main_color" href="<?php echo $SCRITPTNAME;?>?id=xigua_hb&ac=cat&cat_id=<?php echo $v['catid'];?>"><?php echo $cats[$v['catid']]['name'];?></a><?php } ?>
                    <?php if($config['customfisrt']!=2) { echo nl2br(str_replace(array("\n\n","\r\r", "\n\r\n\r"), '', trim(strip_tags($v['description']))));; } ?>
                    <?php $distvar = '';?>                    <?php if(is_array($v['vars'])) foreach($v['vars'] as $vr) { ?>                    <?php if($vr['type']=='location' && is_array($vr['value']) && count($vr['value'])==3 && is_numeric($vr['value']['2'])) { ?>
                    <?php $distvar = $vr;?>                    <?php } elseif($vr['html'] && $vr['type']=='linkurl' && $vr['html']!=' ') { ?>
                    <span class="block"><span class="main_color"><?php echo $vr['title'];?>：</span><a href="<?php echo $vr['value'];?>">更多详情请点击</a></span>
                    <?php } elseif($vr['html'] && $vr['type']!='pics' && $vr['html']!=' ') { ?>
                    <span class="block"><span class="main_color"><?php echo $vr['title'];?>：</span><?php echo $vr['html'];?></span>
                    <?php } ?>
                    <?php } if($config['customfisrt']==2) { echo nl2br(str_replace(array("\n\n","\r\r", "\n\r\n\r"), '', trim(strip_tags($v['description']))));; } if(0&& $v['video'] && is_file(DISCUZ_ROOT.'source/plugin/xigua_hb/api_qr.inc.php')) { ?>
<div class="video_set"><video poster="<?php echo $v['video_cover'];?>" src="<?php echo $v['video'];?>" controls="controls"  <?php if(!IN_PROG) { ?>x5-playsinline webkit-playsinline playsinline x-webkit-airplay="allow"<?php } ?>></video></div><?php $v[img_preview] = array();$hidev=1;?><?php } if($v['realname'] && $v['realname']!='-') { ?><span class="block"><span class="main_color">联系人: </span><?php echo $v['realname'];?></span><?php } ?>
                </div>
    <?php if($config['zjbd']) { ?>
        <?php if($vtelp>0 && $vcatid&&!$viewtels[$v['id']] && !$ishk) { ?>
        <a class="mb8 h30 weui-btn weui-btn_mini" href="javascript:hb_paytel('<?php echo $v['id'];?>','<?php echo $vtelp;?>',<?php echo $vcatid;?>);"><i class="iconfont icon-dianhua2 f14"></i>拨打电话</a>
        <?php } elseif($v['weixin']) { ?>
        <a class="mb8 h30 weui-btn weui-btn_mini" href="javascript:;" onclick="lxfs_tip(this, '<?php echo $v['mobile'];?>', '<?php echo $v['weixin'];?>');">查看联系方式</a>
        <?php } elseif($v['mobile']) { ?>
        <a class="mb8 h30 weui-btn weui-btn_mini" href="tel:<?php echo $v['mobile'];?>"><i class="iconfont icon-dianhua2"></i>拨打电话</a>
        <?php } ?>
    <?php } else { ?>
        <a class="showfull main_color" id="showfull_<?php echo $v['id'];?>" onclick="<?php echo $callfull;?>">全文</a>
    <?php } ?>
                <div class="cl feed-preview-pic">
<?php if($v['video']&&!$hidev && is_file(DISCUZ_ROOT.'source/plugin/xigua_hb/api_qr.inc.php')) { ?>
<span class="imgloading view_jump" data-id="<?php echo $v['id'];?>">
    <em class="emvbg" style="background-image:url(<?php echo $v['video_cover'];?>)"></em><em class="emvdo"></em>
</span><?php } $img_preview_cnt = count($v[img_preview])-1;?><?php if(is_array($v['img_preview'])) foreach($v['img_preview'] as $k => $img) { $showzhang = ($k==$img_preview_cnt && $v[img_count]>3);
if($v[video]&&$img_preview_cnt==2):
    $showzhang = $k==1;
    if($k==$img_preview_cnt):
        continue;
    endif;
endif;?><span <?php if($config['picin']) { ?>class="imgloading view_jump" data-id="<?php echo $v['id'];?>" data-stid="<?php echo $v['stid'];?>"<?php } else { ?>class="imgloading"<?php } ?>><img src="<?php echo $img;?>" onerror="this.error=null;$(this).parent().remove();">
                    <?php if($showzhang&&$v['img_count']>1) { ?><em class="num"><?php echo $v['img_count'];?>张</em><?php } ?>
                    </span>
                    <?php } ?>
                </div>
                <?php if($v['sh']) { ?>
                <a class="weui-flex hs_inner sh_jump" href="javascript:;" data-id="<?php echo $v['sh']['shid'];?>">
                    <img src="<?php echo $v['sh']['logo'];?>">
                    <div class="hs_titloc">
                        <h3 class="da"><?php echo $v['sh']['name'];?></h3>
                        <span><i class="iconfont icon-coordinates_fill f14 vm"></i><?php echo $v['sh']['addr'];?></span>
                    </div>
                </a>
                <?php } elseif(0&&$v['sh']&&$v['img_preview']) { ?>
                <a class="hs_inner_loc da" href="<?php echo $SCRITPTNAME;?>?id=xigua_hs&ac=view&shid=<?php echo $v['sh']['shid'];?>"><i class="iconfont icon-coordinates_fill f14 "></i><?php echo $v['sh']['addr'];?></a>
                <?php } elseif($distvar) { ?>
                <a class="hs_inner_loc da" style="display:block" href="<?php echo $SCRITPTNAME;?>?id=xigua_hb&ac=view&pubid=<?php echo $v['id'];?>"><i class="iconfont icon-coordinates_fill f14 "></i><?php echo $distvar['value']['0'];?> <?php if($v['distance']) { ?><span class="diskm">距我<?php echo $v['distance'];?></span><?php } ?></a>
                <?php } ?>
            </div>
            <?php if(!$_GET['hb']) { ?>
            <div class="cl pr">
                <p class="time">
                    <span><em><?php echo $v['views'];?></em>浏览, </span>
                    <span><em><?php echo $v['shares'];?></em>分享, </span>
                    <span><?php echo $v['time_u'];?><?php if($v['refresh_times']) { ?>刷新<?php } else { ?>发布<?php } ?></span>
<?php if($_G['uid'] == $v['uid']||IS_ADMINID ) { ?><span><?php echo date('m-d H:i', $v['endts']); ?>过期</span><?php } ?>
                </p>
                <?php if(($_G['uid'] == $v['uid']||IS_ADMINID)  ) { ?>
                <a <?php if($hidegl) { ?>style="display:none"<?php } ?> class="a c_opt" href="javascript:;" id="pubitem_<?php echo $v['id'];?>" data-id="<?php echo $v['id'];?>" data-uid="<?php echo $v['uid'];?>" data-wc="<?php echo $v['wancheng'];?>" <?php if($v['display']&&!$v['wancheng']) { ?>data-canzd="1"<?php } else { ?>data-hidefx="1"<?php } ?> <?php if((!$v['hb_num']||$v['hb_num']==$v['hb_sendnum'])&&$v['display']&&$config['red']&&!$v['wancheng']) { ?>data-canhb="1"<?php } ?> <?php if(!$v['pay_status']) { ?>data-catid="<?php echo $v['catid'];?>"<?php } ?> onclick="return showansi(this);"><?php if(IS_ADMINID) { ?>管理<?php } else { ?>管理<?php } ?></a>
                <?php } ?>
                <?php if($hidegl) { ?><i class="c-icon iconfont icon-qunawanhuifu" id="c_icon_<?php echo $v['id'];?>"></i><?php } ?>
                <div class="touch-panel animated opannel">
                    <div class="touch-panel-c weui-flex">
                        <a href="javascript:void(0)" class="weui-flex__item praise" data-id="<?php echo $v['id'];?>" data-href="<?php echo $SCRITPTNAME;?>?id=xigua_hb&ac=misc&do=vote&pubid=<?php echo $v['id'];?>&formhash=<?php echo FORMHASH;?>"><i id="praise_<?php echo $v['id'];?>" class="iconfont <?php if($vots[$v['id']]) { ?>icon-jinlingyingcaiwangtubiao24<?php } else { ?>icon-jinlingyingcaiwangtubiao44<?php } ?>"></i>赞</a>
<?php if($calltel) { ?><a href="<?php echo $calltel;?>" class="weui-flex__item"><i class="icon-dianhua2 iconfont"></i>电话</a><?php } ?>
                        <?php if($config['showcomment']) { ?><a href="javascript:void(0)" class="weui-flex__item comment" id="comment_<?php echo $v['id'];?>" data-id="<?php echo $v['id'];?>"><i class="icon-xiaoxi iconfont"></i>评论</a><?php } ?>
                        <?php if($config['showsixin']) { ?><a href="javascript:void(0)" data-id="<?php echo $v['id'];?>" data-uid="<?php echo $v['uid'];?>" class="weui-flex__item comment_to"><i class="icon-sixin2 iconfont"></i>私信</a><?php } ?>
                    </div>
                </div>
            </div>
            <?php } else { ?>
            <?php if(($_G['uid'] == $v['uid']||IS_ADMINID)  ) { ?>
            <a <?php if($hidegl) { ?>style="display:none"<?php } ?> class="a c_opt" href="javascript:;" id="pubitem_<?php echo $v['id'];?>" data-id="<?php echo $v['id'];?>" data-uid="<?php echo $v['uid'];?>" data-wc="<?php echo $v['wancheng'];?>" <?php if($v['display']&&!$v['wancheng']) { ?>data-canzd="1"<?php } else { ?>data-hidefx="1"<?php } ?> <?php if((!$v['hb_num']||$v['hb_num']==$v['hb_sendnum'])&&$v['display']&&$config['red']&&!$v['wancheng']) { ?>data-canhb="1"<?php } ?> <?php if(!$v['pay_status']) { ?>data-catid="<?php echo $v['catid'];?>"<?php } ?> onclick="return showansi(this);"><?php if(IS_ADMINID) { ?>管理<?php } else { ?>管理<?php } ?></a>
            <?php } ?>
            <div class="weui-flex pr">
                <div class="weui-flex__item"><span class=" color-red" ><i class="iconfont icon-hongbao2 f18"></i> <span class="f12">&yen;</span><span class="f20"><?php echo $v['hb_money'];?></span><span class="f12">元</span></span></div>
                <?php if($v['hb_num']>$v['hb_sendnum']) { ?><div class="color-red f12 hlisttip">抢红包进行中</div><?php } else { ?><div class="color-gray f12 hlisttip">来晚一步，抢光了</div><?php } ?>
            </div>
            <?php } ?>
        </div>

<?php if(!$_GET['hb'] && !$_GET['is_my']) { ?>
<div class="r" id="r_<?php echo $v['id'];?>" <?php if(!$v['zanlist']&&!$v['commentlist']) { ?>style="display:none"<?php } ?>></div>
<div class="cmt-wrap" id="cmt_wrap_<?php echo $v['id'];?>" <?php if(!$v['zanlist']&&!$v['commentlist']) { ?>style="display:none"<?php } ?>>
    <div class="like cl">
        <span class="likenum c9"><em id="praises_<?php echo $v['id'];?>"><?php echo $v['votes'];?></em>赞</span>
<span class="likeuser z" id="praise_list_<?php echo $v['id'];?>"><?php if(is_array($v['zanlist'])) foreach($v['zanlist'] as $_v) { ?><a href="<?php echo $SCRITPTNAME;?>?id=xigua_hb&ac=member&uid=<?php echo $_v['uid'];?>"><img class="uavatar" src="<?php echo avatar($_v['uid'], 'middle', true);; ?>" onerror="$(this).parent().remove();this.error=null" /></a>
<?php } ?>
</span>
    </div>
    <?php if($config['showcomment']) { ?>
    <div class="cmt-list border_top" id="cmt_list_<?php echo $v['id'];?>" data-id="<?php echo $v['id'];?>" <?php if(!$v['commentlist']) { ?>style="display:none"<?php } ?>>
        <?php $comment_simple = 1;?>        <?php $comments = $v[commentlist];?>        <?php include template('xigua_hb:comment_li'); ?>        <?php if($v['comments']>5) { ?>
        <p class="view_jump" data-id="<?php echo $v['id'];?>" data-stid="<?php echo $v['stid'];?>">查看全部<?php echo $v['comments'];?>条评论</p>
        <?php } ?>
    </div>
    <?php } ?>
</div>
<?php } if(($_G['uid'] == $v['uid']||IS_ADMINID) && ($v['display']||$_GET['is_admin']) && $hidegl ) { ?>
<div class="po-act">
<?php if($config['digprices']&&$dig_prices) { ?>
    <a class="weui-btn weui-btn_mini p0 mt0" href="javascript:;" onclick="hb_dig('<?php echo $v['id'];?>');">置顶</a>
<?php } if((!$v['hb_num']||$v['hb_num']==$v['hb_sendnum'])&&$config['red']) { ?>
    <a class="weui-btn weui-btn_mini p0 mt0" href="javascript:;" onclick="hb_hbchoice('<?php echo $v['id'];?>');">红包</a>
<?php } ?>
    <?php if($config['refresh']>0 && !$needsafe) { ?>
    <a class="weui-btn weui-btn_mini p0 mt0" href="javascript:;" onclick="hb_shuaxin('<?php echo $v['id'];?>');">刷新</a>
    <?php } ?>
    <a class="weui-btn weui-btn_mini p0 mt0" href="javascript:;" onclick="$('#pubitem_<?php echo $v['id'];?>').trigger('click');">更多</a>
</div>
<?php } elseif(($_G['uid'] == $v['uid']||IS_ADMINID) && !$v['pay_status'] && !$v['display']) { ?>
<div class="po-act">
    <a class="weui-btn weui-btn_mini p0 mt0" href="<?php echo $SCRITPTNAME;?>?id=xigua_hb&ac=pay&catid=<?php echo $v['catid'];?>&pubid=<?php echo $v['id'];?>">支付</a>
    <a class="weui-btn weui-btn_mini p0 mt0" href="javascript:;" onclick="$('#pubitem_<?php echo $v['id'];?>').trigger('click');">更多</a>
</div>
<?php } ?>
    </div>
</div>
<?php } ?>