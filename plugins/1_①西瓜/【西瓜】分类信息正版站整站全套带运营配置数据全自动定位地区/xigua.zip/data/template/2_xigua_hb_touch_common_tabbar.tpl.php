<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); if($tabbar) { if($config['custom_nav']) { $custom_nav = C::t('#xigua_hb#xigua_hb_nav')->fetch_index();?>    <div class="weui-tabbar<?php if($showfloatapp||!$custom_nav) { ?> none<?php } ?>"><?php if(is_array($custom_nav)) foreach($custom_nav as $loop_k => $loopin) { $highlight = '&high='.$loop_k;
$inlink = $loopin['adlink'].$highlight;
$is_on = !$is_on && (strpos(hb_currenturl(),$inlink)!==false||(strpos(hb_currenturl(),$highlight)!==false)||$_GET['high']==$loop_k);
if($is_on):
    $loopin[icon] = $loopin[icon2]?$loopin[icon2]:$loopin[icon];
    $loopin[iconname] = $loopin[iconname2]?$loopin[iconname2]:$loopin[iconname];
endif;?><a href="<?php echo $inlink;?>" class="weui-tabbar__item <?php if($is_on) { ?>weui-bar__item_on<?php } ?> <?php if($loopin['up']) { ?> weui-bar__item_on <?php if($config['showpubfont']) { ?> showpubfont <?php } } ?>">
<?php if($loopin['up']) { ?>
    <div class="pub_circle"></div>
    <?php if($loopin['icon']) { ?>
    <img src="<?php echo $loopin['icon'];?>" class="tabcon" />
    <?php } elseif($loopin['iconname']) { ?>
    <i class="iconfont icon-<?php echo $loopin['iconname'];?> weui-tabbar__icon"></i>
    <?php } if($config['showpubfont']) { ?><p class="weui-tabbar__label pub_circle_p" style="color:#777!important"><?php echo $loopin['name'];?></p><?php } } else { ?>
    <?php if($loopin['icon']) { ?>
    <img src="<?php echo $loopin['icon'];?>" class="tabcon3" />
    <?php } elseif($loopin['iconname']) { ?>
    <i class="iconfont icon-<?php echo $loopin['iconname'];?> weui-tabbar__icon"></i>
    <?php } if(strpos($inlink, 'type=sx')!==false) { if($newpm || $newpm = C::t('#xigua_hb#xigua_hb_comment')->fetch_type1_num()) { ?>
<span class="weui-badge weui-badge_dot" style="position:absolute"></span><?php } } ?>
    <p class="weui-tabbar__label"><?php echo $loopin['name'];?></p>
<?php } ?>
</a>
<?php } ?>
    </div>
<?php } else { ?>
<div class="weui-tabbar<?php if($showfloatapp) { ?> none<?php } ?>">
    <a href="<?php echo $siteurl;?><?php echo $SCRITPTNAME;?>?id=xigua_hb<?php echo $urlext;?>" class="weui-tabbar__item <?php if($ac=='index'&&$_GET['id']=='xigua_hb') { ?>weui-bar__item_on<?php } ?>">
                        <i class="iconfont icon-index weui-tabbar__icon"></i>
        <p class="weui-tabbar__label">首页</p>
    </a>

    <?php if($_G['cache']['plugin']['xigua_hs']) { ?>
    <a href="<?php echo $siteurl;?><?php echo $SCRITPTNAME;?>?id=xigua_hs&mobile=2<?php echo $urlext;?>" class="weui-tabbar__item">
        <i class="iconfont icon-shoplight weui-tabbar__icon f26"></i>
        <p class="weui-tabbar__label">商圈</p>
    </a>
    <?php } else { ?>
    <a href="<?php echo $siteurl;?><?php echo $SCRITPTNAME;?>?id=xigua_hb&ac=hongbao<?php echo $urlext;?>" class="weui-tabbar__item <?php if($ac=='hongbao') { ?>weui-bar__item_on<?php } ?>">
        <i class="iconfont icon-hongbao2 weui-tabbar__icon"></i>
        <p class="weui-tabbar__label">红包</p>
    </a>
    <?php } ?>

    <a href="<?php if($pub0) { ?><?php echo $pub0;?><?php if(strpos($pub0, 'java')===false) { ?><?php echo $urlext;?><?php } } else { ?><?php echo $siteurl;?><?php echo $SCRITPTNAME;?>?id=xigua_hb&ac=pub&needlogin=1<?php echo $urlext;?><?php } ?>" class="weui-tabbar__item weui-bar__item_on <?php if($config['showpubfont']) { ?>showpubfont<?php } ?>">
        <div class="pub_circle"></div>
        <i class="iconfont icon-fabuhei weui-tabbar__icon"></i>
        <?php if($config['showpubfont']) { ?><p class="weui-tabbar__label pub_circle_p" style="color:#777!important"><?php echo $config['showpubfont'];?></p><?php } ?>
    </a>
    <?php if($config['setbuttom']) { ?>
    <?php $helplink = explode('|', $config[setbuttom]);?>    <a href="<?php echo $helplink['2'];?>" class="weui-tabbar__item <?php if(strpos(hb_currenturl(),$helplink['2'])!==false) { $hason=1;?>weui-bar__item_on<?php } ?>">
        <?php if($helplink['1'] && strpos($helplink['1'], '.')!==false) { ?><img src="<?php echo $helplink['1'];?>" style="width:1rem;height:1rem;display:block;margin:.35rem auto 0;" /><?php } elseif($helplink['1']) { ?><i class="iconfont icon-<?php echo $helplink['1'];?> weui-tabbar__icon"></i><?php } else { ?><i class="iconfont icon-jieban weui-tabbar__icon"></i><?php } ?>
        <p class="weui-tabbar__label"><?php echo $helplink['0'];?></p>
    </a>
    <?php } elseif($_G['cache']['plugin']['xigua_hs']) { ?>
    <a href="<?php echo $siteurl;?><?php echo $SCRITPTNAME;?>?id=xigua_hb&ac=hongbao<?php echo $urlext;?>" class="weui-tabbar__item <?php if($ac=='hongbao') { ?>weui-bar__item_on<?php } ?>">
        <i class="iconfont icon-hongbao2 weui-tabbar__icon"></i>
        <p class="weui-tabbar__label">红包</p>
    </a>
    <?php } else { ?>
    <a href="<?php echo $siteurl;?><?php echo $SCRITPTNAME;?>?id=xigua_hb&ac=about<?php echo $urlext;?>" class="weui-tabbar__item <?php if($ac=='about') { ?>weui-bar__item_on<?php } ?>">
        <i class="iconfont icon-jieban weui-tabbar__icon"></i>
        <p class="weui-tabbar__label">帮助</p>
    </a>
    <?php } ?>

    <a href="<?php echo $siteurl;?><?php echo $SCRITPTNAME;?>?id=xigua_hb&ac=my&needlogin=1<?php echo $urlext;?>" class="weui-tabbar__item <?php if(!$hason && strpos($ac,'my')!==false) { ?>weui-bar__item_on<?php } ?>">
        <span style="display:inline-block;position:relative;">
            <i class="iconfont icon-xiaolian2 weui-tabbar__icon"></i>
            <?php if($newpm || $newpm = C::t('#xigua_hb#xigua_hb_comment')->fetch_type1_num()) { ?>
            <span class="weui-badge weui-badge_dot" style="position:absolute;top:0;right:-.3rem"></span>
            <?php } ?>
        </span>
        <p class="weui-tabbar__label">我的</p>
    </a>
</div>
<?php } } ?>