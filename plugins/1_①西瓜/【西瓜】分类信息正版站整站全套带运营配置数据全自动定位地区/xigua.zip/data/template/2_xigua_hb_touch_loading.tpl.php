<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<div id="loading-show" class="weui-loadmore">
    <i class="weui-loading"></i>
    <span class="weui-loadmore__tips">正在加载</span>
</div>
<div id="loading-none" class="weui-loadmore weui-loadmore_line hidden">
<!--    <span class="weui-loadmore__tips">没有更多了</span>-->
    <div class="hs_empty"><i class="icon iconfont icon-zanwuwenda"></i><p>没有更多了</p></div>
</div>
