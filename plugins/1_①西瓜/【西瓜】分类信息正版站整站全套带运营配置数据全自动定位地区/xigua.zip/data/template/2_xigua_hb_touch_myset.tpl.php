<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); hookscriptoutput('myset');?><?php include template('xigua_hb:common_header'); ?><div class="page__bd">
    <?php include template('xigua_hb:common_nav'); ?>    <div class="weui-cells">

        <a class="weui-cell weui-cell_access" href="<?php echo $SCRITPTNAME;?>?id=xigua_hb&ac=mysetxx">
            <div class="weui-cell__hd"><i class="iconfont icon-weixinzhifu1 color-forest"></i></div>
            <div class="weui-cell__bd">
                <p>消息设置</p>
            </div>
            <div class="weui-cell__ft"> </div>
        </a>
<?php if($dxp) { ?>
        <a class="weui-cell weui-cell_access" href="<?php echo $SCRITPTNAME;?>?id=xigua_hb&ac=myzl">
            <div class="weui-cell__hd"><i class="iconfont icon-shouji color-red"></i></div>
            <div class="weui-cell__bd">
                <p>绑定手机</p>
            </div>
            <div class="weui-cell__ft"><?php echo $muhumobile;?></div>
        </a>
<?php } ?>
        <a class="weui-cell weui-cell_access" href="<?php echo $SCRITPTNAME;?>?id=xigua_hb&ac=myaddr&mobile=2<?php echo $urlext;?>">
            <div class="weui-cell__hd"><i class="iconfont icon-coordinates_fill color-soundcloud"></i></div>
            <div class="weui-cell__bd">
                <p>收货地址</p>
            </div>
            <div class="weui-cell__ft"></div>
        </a>

        <a class="weui-cell weui-cell_access" href="<?php echo $SCRITPTNAME;?>?id=xigua_hb&ac=mytx">
            <div class="weui-cell__hd"><i class="iconfont icon-zhifubao color-paypal"></i></div>
            <div class="weui-cell__bd">
                <p>提现设置</p>
            </div>
            <div class="weui-cell__ft"></div>
        </a>

<?php if($_G['cache']['plugin']['xigua_member']) { ?>
        <a class="weui-cell weui-cell_access" href="<?php echo $SCRITPTNAME;?>?id=xigua_member:profile">
            <div class="weui-cell__hd"><i class="iconfont icon-fabuxuqiu color-amazon"></i></div>
            <div class="weui-cell__bd">
                <p>个人资料</p>
            </div>
            <div class="weui-cell__ft"></div>
        </a>
<?php } ?>

    <a class="weui-cell weui-cell_access" href="<?php echo $SCRITPTNAME;?>?id=xigua_hb&ac=mycover">
        <div class="weui-cell__hd"><i class="iconfont icon-xiangji color-good"></i></div>
        <div class="weui-cell__bd">
            <p>个人主页背景</p>
        </div>
        <div class="weui-cell__ft"></div>
    </a>

<?php if($_G['cache']['plugin']['xigua_st']) { $hotcity = DB::fetch_all("select * from %t WHERE status=1 ORDER BY displayorder DESC", array('xigua_st'), 'stid');?>    <a class="weui-cell weui-cell_access" href="javascript:;">
        <div class="weui-cell__hd"><i class="iconfont icon-iconfenxiao color-dribbble"></i></div>
        <div class="weui-cell__bd">
            <input class="weui-input" id="site" placeholder="请选择默认站点" type="text" value="<?php echo $hotcity[$user['dftst']]['name']; ?>">
        </div>
        <div class="weui-cell__ft"></div>
    </a>
<?php } if($_G['cache']['plugin']['xigua_hr']['inputpos']==2) { ?>
        <a class="weui-cell weui-cell_access" href="<?php echo $SCRITPTNAME;?>?id=xigua_hr&ac=my&mobile=2">
            <div class="weui-cell__hd"><i class="iconfont icon-yanzheng color-green"></i></div>
            <div class="weui-cell__bd">
                <p>认证中心</p>
            </div>
            <div class="weui-cell__ft"></div>
        </a>
<?php } if($_G['cache']['plugin']['myrepeats'] && is_file(DISCUZ_ROOT.'source/plugin/xigua_hb/include/c_myrepeats.php')) { include_once DISCUZ_ROOT.'source/plugin/xigua_hb/include/c_myrepeats.php'?><a class="weui-cell weui-cell_access" href="javascript:;">
    <div class="weui-cell__hd"><i class="iconfont icon-yanzheng color-green"></i></div>
    <div class="weui-cell__bd">
        <input class="weui-input" id="qiehuan" placeholder="<?php echo lang('plugin/myrepeats', 'memcp');; ?> <?php echo $_G['username'];?>" type="text" value="">
    </div>
    <div class="weui-cell__ft"></div>
</a>
<script>
$("#qiehuan").select({
    title: "<?php echo lang('plugin/myrepeats', 'memcp');; ?>",
    items: [<?php if(is_array($rlist)) foreach($rlist as $v) { ?>{title: "<?php echo $v['user'];?>",value: "<?php echo $v['link'];?>",},<?php } ?>],
    onOpen:function () {$('.masker').fadeIn();},
    beforeClose:function () {$('.masker').fadeOut(150);return true;},
    onChange: function(d) {
        if(typeof d.values !='undefined'){
            $.showLoading();
            if(d.values.indexOf('switch')===-1){
                hb_jump(d.values);
            }else{$.ajax({
                type: 'post',
                url: d.values+'&inajax=1',
                data:{formhash : FORMHASH},
                dataType: 'xml',
                success: function (data) {
                    $.hideLoading();
                    if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                    var s = data.lastChild.firstChild.nodeValue;
                    tip_common(s);
                },
                error: function () {
                    $.hideLoading();
                }
            });
            }
        }
    }
});
</script>
<?php } ?>
    </div>
    <div class="weui-cells">
        <a class="weui-cell weui-cell_access" href="member.php?mod=logging&amp;action=logout&amp;formhash=<?php echo FORMHASH;?>" >
            <div class="weui-cell__hd"><i class="iconfont icon-tuichu color-gray"></i></div>
            <div class="weui-cell__bd">
                <p>退出登录</p>
            </div>
            <div class="weui-cell__ft"> </div>
        </a>
    </div>
</div>
<div class="masker" style="position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,.5);display:none;z-index:1000" onclick='$("#site").select("close")'></div><?php $tabbar=1;?><?php include template('xigua_hb:common_footer'); if($_G['cache']['plugin']['xigua_st'] && $hotcity) { ?>
<script>
var oldshid = '<?php echo intval($user['dftst']);; ?>';
$("#site").select({
    title: "请选择默认站点",
    items: [{title:"<?php echo $_G['cache']['plugin']['xigua_st']['zongname'];?>", value:0},<?php if(is_array($hotcity)) foreach($hotcity as $v) { ?>{title: "<?php echo $v['name'];?>",value: "<?php echo $v['stid'];?>",},<?php } ?>],
    onOpen:function () {$('.masker').fadeIn();},
    beforeClose:function () {$('.masker').fadeOut(150);return true;},
    onChange: function(d) {
        if(typeof d.values !='undefined'){
            if(oldshid==d.values){
                return false;
            }
            oldshid =d.values;
            $.showLoading();
            $.ajax({
                type: 'post',
                url: _APPNAME +'?id=xigua_hb&ac=myset&newstid='+d.values+'&inajax=1',
                data:{formhash : FORMHASH},
                dataType: 'xml',
                success: function (data) {
                    $.hideLoading();
                    if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                    var s = data.lastChild.firstChild.nodeValue;
                    tip_common(s);
                },
                error: function () {
                    $.hideLoading();
                }
            });
        }
    }
});
</script>
<?php } ?>