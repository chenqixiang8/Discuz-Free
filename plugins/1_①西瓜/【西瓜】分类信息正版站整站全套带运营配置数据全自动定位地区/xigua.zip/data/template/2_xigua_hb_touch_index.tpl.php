<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); hookscriptoutput('index');?><?php include template('xigua_hb:common_header'); ?><div class="page__bd">
<?php if($_G['cache']['plugin']['xigua_f']['defaultlogo']) { ?><div class="visb" style="display:none"><img src="<?php echo $_G['cache']['plugin']['xigua_f']['defaultlogo'];?>"/></div><?php } include template('xigua_hb:common_nav'); if($topnavslider) { ?>
<div class="swipe cl" data-speed="5000">
<div class="swipe-wrap"><?php if(is_array($topnavslider)) foreach($topnavslider as $slider) { ?><div><?php echo $slider;?></div>
<?php } ?>
</div>
<nav class="cl bullets bullets1">
<ul class="position"><?php if(is_array($topnavslider)) foreach($topnavslider as $k => $slider) { ?><li <?php if($k==0) { ?>class="current"<?php } ?>></li>
<?php } ?>
</ul>
</nav>
</div>
<?php } ?>
<div class="weui-cells mt0 after_none before_none">
<div class="weui-cell tl" style="white-space:nowrap;padding:.5rem .6rem">
<div class="weui-cell__bd">
<i class="iconfont icon-hot1 color-red f14"></i><?php if($_G['cache']['plugin']['xigua_hs']) { $totalviews += C::t('#xigua_hs#xigua_hs_shanghu')->total_views();?><?php } ?>
<span class="f14">浏览:<em class="ml3 main_color"><?php echo hb_trans($totalviews);; ?></em></span>
<span class="ml3 f14">发布:<em class="ml3 main_color"><?php echo hb_trans($totalpub);; ?></em></span>
<span class="ml3 f14">分享:<em class="ml3 main_color"><?php echo hb_trans($totalshares);; ?></em></span>
</div>
<div class="weui-cell__hd">
<a class="f14 c9" href="<?php echo $SCRITPTNAME;?>?id=xigua_hb&ac=about">帮助</a>
</div>
</div>
</div>
<?php if($jing_list) { if($_GET[province]):
$cityauto = '&province='.$_GET[province];
$cityauto = $config['indexshowdist']?$cityauto:'';
endif;
if($_GET[city] || $_GET[dist]):
$cityauto = '&city='.$_GET[city].'&dist='.$_GET[dist];
$cityauto = $config['indexshowdist']?$cityauto:'';
endif;?><nav class=" nav-list cl swipe" <?php if($config['swiperbg']) { ?>style="background:url(<?php echo $config['swiperbg'];?>); background-size:cover;background-color:#fff"<?php } ?>>
<div class="swipe-wrap">
<div>
<ul class="cl"><?php if(is_array($jing_list)) foreach($jing_list as $k => $n) { if($k && $k%$numi1==0) { ?>
</ul>
</div>
<div>
<ul class="cl">
<?php } ?>
<li<?php if($config['numi1']!=5&&$config['numi1']>0) { ?> <?php echo "style='width:".(100/$config['numi1'])."%'";?><?php } ?>>
<a href="javascript:;" onclick="hb_jump('<?php echo $n['cat_link'] ? $n['cat_link'] : "$SCRITPTNAME?id=xigua_hb&ac=cat&cat_id=".$n['id'].$cityauto; ?>')">
<span>
<img src="<?php echo $n['icon'];?>"/>
<?php if($n['jiaobiao']) { ?><div class="ping_groups_cover_stamp stamp_dynamic"><?php echo $n['jiaobiao'];?></div><?php } ?>
</span>
<em class="m-piclist-title"><?php echo $n['name'];?></em>
</a>
</li>
<?php } ?>
</ul>
</div>
</div>
<nav class="cl bullets bullets1">
<ul class="position position1"><?php if(is_array($jing_count)) foreach($jing_count as $k => $v) { ?><li <?php if($k==0) { ?> class="current" <?php } ?>></li>
<?php } ?>
</ul>
</nav>
</nav>
<?php } if($index_list) { $tmpp = array_chunk($index_list, 4);?><?php if(is_array($tmpp)) foreach($tmpp as $__k => $tmpp2) { $counttmpp2 = count($tmpp2);?><ul class="inedxicon cl">
    <?php if(is_array($tmpp2)) foreach($tmpp2 as $_k => $_v) { ?>    <li style="width:<?php echo 100/$counttmpp2;; ?>%"><a href="<?php echo $_v['adlink'];?>"><img src="<?php echo $_v['icon'];?>"></a></li>
    <?php } ?>
</ul>
<?php } } ?>

<div class="weui-cells mt0 after_none">
<div class="chip-row">
<div class="toutiao"><?php echo $config['toutitle'];?></div>
<div class="toutiao-slider swiper-container" id="newsSlider">
<ul class="swiper-wrapper"><?php $toutiaoitems = array_filter(explode("\n", trim($_G['cache']['plugin']['xigua_hb']['toutext'])));?><?php if(is_array($toutiaoitems)) foreach($toutiaoitems as $toutiaoitem) { list($font, $link)= explode(",", trim($toutiaoitem));?><li class="swiper-slide"> <a href="<?php echo $link;?>"><?php echo $font;?></a> </li>
<?php } if(is_array($toutiao)) foreach($toutiao as $v) { $v[cat_name] = $v[cat_name] ? $v[cat_name] : $tmpcats[$v[catid]][name];?><li class="swiper-slide"> <a href="<?php echo $SCRITPTNAME;?>?id=xigua_hb&ac=view&pubid=<?php echo $v['id'];?>">[<?php echo $v['cr_time'];?>]<?php echo $v['user']['username'];?>发布了<?php echo $v['cat_name'];?>信息</a> </li>
<?php } ?>
</ul>
</div>
</div>
</div>

<?php if($_G['cache']['plugin']['xigua_hm']['bighui'] || $_G['cache']['plugin']['xigua_hm']['smallhui']) { ?>
<div class="weui-cells after_none before_none"><?php list($link1, $icon1) = explode(",", trim($_G['cache']['plugin']['xigua_hm']['bighui']));?><?php if($icon1) { ?><div class="chip-l" style="padding:0"><a href="<?php echo $link1;?>" class="bigh" style="background-image:url(<?php echo $icon1;?>)"></a></div><?php } $smallhuis = array_filter(explode("\n", trim($_G['cache']['plugin']['xigua_hm']['smallhui'])));?><?php if(is_array($smallhuis)) foreach($smallhuis as $sk => $smallhui) { list($font1, $font2, $icon, $link)= explode(",", trim($smallhui));?><div class="chip">
<div>
<p><a style="display:block" href="<?php echo $link;?>"><?php echo $font1;?></a></p>
<p><a style="display:block" href="<?php echo $link;?>"><?php echo $font2;?></a></p>
</div>
<a href="<?php echo $link;?>"><img src="<?php echo $icon;?>"></a>
</div>
<?php } ?>
</div>
<?php } if($config['colorblock'] ) { ?>
<div class="weui-cells after_none before_none chipCW"><?php $colorblocks = array_filter(explode("\n", trim($config[colorblock])));?><?php if(is_array($colorblocks)) foreach($colorblocks as $colorblock) { list($_font1, $_font2, $_icon, $_link, $_color, $__stid)= explode("|", trim($colorblock));
$__stid = intval($__stid);
if($_GET['st']>0):
if(!($__stid==0||$__stid==$_GET['st'])):
continue;
endif;
else:
if(!($__stid==0||$__stid==-1)):
continue;
endif;
endif;?><div class="chip chipC" onclick="hb_jump('<?php echo $_link;?>');" <?php if($_color) { ?>style="background-color:<?php echo $_color;?>"<?php } ?>>
<div>
<p><a class="chipCH" href="javascript:;"><?php echo $_font1;?></a></p>
<div class="chipCS"><a href="javascript:;"><?php echo $_font2;?></a></div>
</div>
<a href="javascript:;"><img src="<?php echo $_icon;?>"></a>
</div>
<?php } ?>
</div>
<?php } if($config['fid_s']) { $tidlist = C::t('#xigua_hb#xigua_hb_pub')->fetch_thread_for_index_light();
$_fid = explode(',', $config['fid_s']);
$_fid = intval($_fid[0]);?><?php if($tidlist) { ?><div>
<div class="weui-cells__title weui_title border_none f15">
<span><?php echo $config['toutitle'];?></span>
<a class="y c9" href="forum.php?mod=forumdisplay&amp;fid=<?php echo $_fid ? $_fid : $config['fid_s']; ?>">更多<i class="f13 iconfont icon-jinrujiantou"></i></a>
</div><div class="weui-cells"><?php if(is_array($tidlist)) foreach($tidlist as $_k => $_v) { $_k=$_k+1;?><div class="weui-cell">
<div class="weui-cell__hd"><div class="tt_<?php echo $_k;?> tt_n"><?php echo $_k;?></div></div>
<div class="weui-cell__bd elp f14">
<a href="forum.php?mod=viewthread&amp;tid=<?php echo $_v['tid'];?>"><?php echo $_v['subject'];?></a>
</div>
<div class="weui-cell__ft f14"><?php echo $_v['time_u'];?></div>
</div>
<?php } ?>
</div>
</div>
<?php } } if($_G['cache']['plugin']['xigua_sp'] && $_G['cache']['plugin']['xigua_sp']['indexsp_num']> 0) { $splist = C::t('#xigua_sp#xigua_sp_good')->fetch_all_by_where(array("stat=1"), 0, $_G['cache']['plugin']['xigua_hs'][indexsp_num], 'displayorder desc, sellnum desc');?><?php if($splist) { ?><style>.coupon_swiper .swiper-slide{width:7.25rem}.seclight_box{width:5.25rem!important;margin:0 0 .75rem .75rem;overflow:hidden}.seclight_img{width:100%;height:4rem;display:block}.seclight_box .p1{font-size:.6rem;color:#000;height:1rem;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;line-height:1.1rem}.seclight_box .p2{height:1.4rem!important;overflow:hidden}</style><div class="weui-cells f15 before_none after_none">
<div class="weui-cells__title weui_title mt0 f15">热卖商品        <a class="y c9 pr_1" href="<?php echo $SCRITPTNAME;?>?id=xigua_sp<?php echo $urlext;?>" >更多<i class="f13 iconfont icon-jinrujiantou"></i></a></div>
<div class="swiper-container coupon_swiper">
<div class="swiper-wrapper"><?php if(is_array($splist)) foreach($splist as $k => $qv) { $spthumb = $qv['fengmian'] ? $qv['fengmian'] : ($qv['album'][0] ?$qv['album'][0] :$qv['append_img_ary'][0]);?><div class="swiper-slide seclight_box">
<a href="<?php echo $SCRITPTNAME;?>?id=xigua_sp&ac=view&gid=<?php echo $qv['id'];?><?php echo $urlext;?>">
<div class="pr">
<img class="seclight_img" style="height:5rem;width:5rem" src="<?php echo $spthumb;?>">
</div>
<div class="p1"><?php echo $qv['title'];?></div>
<div class="p2" style="overflow: hidden;white-space: nowrap;text-overflow: ellipsis">
<span class="main_color"><em class="f12">&yen;</em><em class="f18"><?php echo $qv['tprice'];?></em></span>
<span><s class="f12 c9 ">原价 &yen;<?php echo $qv['disprice'];?></s></span>
</div>
</a>
</div>
<?php } ?>
</div>
</div>
</div>
<?php } } if($sh_list) { ?>
<div class="weui-cells__title weui_title border_none"><span class="f15">热门商家</span>  <a class="y c9" href="<?php echo $SCRITPTNAME;?>?id=xigua_hs">更多<i class="f13 iconfont icon-jinrujiantou"></i></a></div>
<div class="weui-cells after_none before_none p15 pt0">
<div class="sh_slider">
<ul class="shangjia" style="width:<?php echo $shwidth;?>px"><?php if(is_array($sh_list)) foreach($sh_list as $shi) { ?><li class="s_shangjia">
<a href="<?php echo $SCRITPTNAME;?>?id=xigua_hs&ac=view&shid=<?php echo $shi['shid'];?>">
<div class="picture"><img src="<?php echo $shi['logo'];?>"></div>
<span class="sh_name"><?php echo $shi['name'];?></span>
</a>
</li>
<?php } ?>
<li class="sh_more"> <a href="<?php echo $SCRITPTNAME;?>?id=xigua_hs&ac=enter&from=hb"> <span class="color-red">我要入驻<i class="f13 iconfont icon-jinrujiantou color-red"></i></span>  </a> </li>
</ul>
</div>
</div>
<?php } if($_G['cache']['plugin']['xigua_ho']) { $ho_tuindex = unserialize($_G['cache']['plugin']['xigua_ho'][tuindex]);?><?php if(in_array(2, $ho_tuindex)) { include template('xigua_ho:tuindex'); } } if($midnavslider) { ?>
<div class="weui-cells after_none before_none">
<div class="swipe cl" data-speed="6000">
<div class="swipe-wrap"><?php if(is_array($midnavslider)) foreach($midnavslider as $slider) { ?><div><?php echo $slider;?></div>
<?php } ?>
</div>
<nav class="cl bullets bullets1">
<ul class="position"><?php if(is_array($midnavslider)) foreach($midnavslider as $k => $slider) { ?><li <?php if($k==0) { ?>class="current"<?php } ?>></li>
<?php } ?>
</ul>
</nav>
</div>
</div>
<?php } include template('xigua_hb:list_by_cat1'); ?></div><?php $c2 = $city;
if($c2==lang_hb('quanbu', 0)):
$c2 = '';
endif;
if(!$config['indexshowdist']):
$c2 =  $_GET[dist] = $_GET[province] = '';
endif;
$pgsize = 5;
if($_GET[tpl]):
$pgsize =20;
endif;?><script>var loadingurl =(typeof indexloadingurl!='undefined') ? indexloadingurl : _APPNAME+'?id=xigua_hb&ac=list_item&inajax=1&pagesize=<?php echo $pgsize;?>&tpl=<?php echo $_GET['tpl'];?>&province=<?php echo $_GET['province'];?>&city=<?php echo $c2;?>&dist=<?php echo $_GET[dist]?$dist:'';?>&page=';
<?php if($allowdp) { ?>scrollto=0;<?php } else { ?>scrollto=1;<?php } ?>
var TIMELINE_TITLE = '<?php echo $desc;?>';
var TOUTIAOS = [];
<?php if($toutiao) { if(is_array($toutiao)) foreach($toutiao as $v) { $v[cat_name] = $v[cat_name] ? $v[cat_name] : $tmpcats[$v[catid]][name];?>TOUTIAOS.push("<a href=\"<?php echo $SCRITPTNAME;?>?id=xigua_hb&ac=view&pubid=<?php echo $v['id'];?>\"><img src=\"<?php echo avatar($v[user][uid], 'middle', true);?>\" class=\"avt\"><?php echo $v['user']['username'];?><?php echo $v['cr_time'];?>发布了<?php echo $v['cat_name'];?>信息</a>");
<?php } } if($shwidthauto&& $shtime&&$_G['cache']['plugin']['xigua_hs']['sh_list']&& $_G['cache']['plugin']['xigua_hs']['autosh']) { ?>
var SH_SLIDER = $('.sh_slider');
SH_SLIDER.animate({"scrollLeft":<?php echo $shwidthauto;?>}, <?php echo $shtime;?>, 'linear');
SH_SLIDER.on('scroll', function(){
if($(this).scrollLeft()>=<?php echo $shwidthauto;?>){
$(this).animate({"scrollLeft":0}, 1, 'linear');
$(this).animate({"scrollLeft":<?php echo $shwidthauto;?>}, <?php echo $shtime;?>, 'linear');
}
});
SH_SLIDER.on('touchstart', function () {
SH_SLIDER.stop().unbind();
});
<?php } ?>
</script><?php $tabbar=1;?><?php if($config['indexshowdist']) { ?>
<script>$('.x_logo').removeAttr('href').addClass('dist_nav').attr('data-id',1).html('<span style="padding:0 .5rem;display:block;margin:0 .5rem"><?php echo $fontop;?> <i class="iconfont icon-xiangxia f13"></i></span>')</script>
<div class="dist_show"><div id="dist_show_1" class="nav_expand_panel " <?php if($config['intopindex']) { ?>style="top:0"<?php } else { ?>style="top:2.1rem"<?php } ?>>
<div class="weui-flex">
<div class="weui-flex__item">
<ul>
<li class="first_check border_bfull <?php if(!$_GET['province']) { ?>checked main_color<?php } ?>"><a href="<?php echo $SCRITPTNAME;?>?id=xigua_hb&cat_id=<?php echo $cat_id;?>&province=&city=&orderby=<?php echo $orderby;?>&keyword=<?php echo $keyword;?>&lat=<?php echo $lat;?>&lng=<?php echo $lng;?><?php echo $urlext;?>">全部</a></li><?php if(is_array($dist0)) foreach($dist0 as $v) { ?><li class="first_check border_bfull <?php if($_GET['province']==$v['name']) { ?>checked main_color<?php $city_id=$v['id'];?><?php } ?>" data-id="<?php echo $v['id'];?>" data-link="<?php echo $v['link'];?>"><a><?php echo $v['name'];?></a></li>
<?php } ?>
</ul>
</div>
<div class="weui-flex__item checked"><?php if(is_array($dist0)) foreach($dist0 as $k => $v) { ?><ul class="sub_cheker <?php if($_GET['province']!=$v['name']) { ?>none<?php } else { ?>checked<?php } ?>" id="sub_cheker_<?php echo $v['id'];?>">
<li class="sub_check border_bfull"><a data-href="<?php echo $SCRITPTNAME;?>?id=xigua_hb&cat_id=<?php echo $cat_id;?>&province=<?php echo $v['name'];?>&city=&orderby=<?php echo $orderby;?>&keyword=<?php echo $keyword;?>&lat=<?php echo $lat;?>&lng=<?php echo $lng;?><?php echo $urlext;?>" class="choose color-red">全<?php echo $v['name'];?> <i class="iconfont icon-coordinates_fill f14 "></i></a></li><?php if(is_array($v['child'])) foreach($v['child'] as $vv) { ?><li class="sub_check border_bfull <?php if($city==$vv['name']&&$_GET['city']) { ?>checked main_color autotrigger<?php } ?>"><a data-href="<?php echo $SCRITPTNAME;?>?id=xigua_hb&cat_id=<?php echo $cat_id;?>&province=<?php echo $v['name'];?>&city=<?php echo $vv['name'];?>&orderby=<?php echo $orderby;?>&keyword=<?php echo $keyword;?>&lat=<?php echo $lat;?>&lng=<?php echo $lng;?><?php echo $urlext;?>" id="sub_check<?php echo $vv['id'];?>" data-id="<?php echo $vv['id'];?>" onclick="hs_getnext(<?php echo $vv['id'];?>, '<?php echo $vv['name'];?>','<?php echo $SCRITPTNAME;?>?id=xigua_hb&cat_id=<?php echo $cat_id;?>&orderby=<?php echo $orderby;?>&keyword=<?php echo $keyword;?>&lat=<?php echo $lat;?>&lng=<?php echo $lng;?><?php echo $urlext;?>', '<?php echo $vv['link'];?>')"><?php echo $vv['name'];?></a></li>
<?php } ?>
</ul>
<?php } ?>
</div>
<div class="weui-flex__item checked" id="ajaxbox"> <ul class="ajaxbox_cheker"></ul> </div>
</div>
</div></div>
<script>
function hs_getnext(id, name, datahref, datalink){
if(datalink){
hb_jump(datalink);
return false
}
$('.sub_check a').removeClass('checked').removeClass('main_color');
$('.sub_check a').parent().removeClass('checked').removeClass('main_color');
$('#sub_check'+id).addClass('checked').addClass('main_color');
$.ajax({
type: 'get',
url: _APPNAME + '?id=xigua_hb&province='+$('.first_check+.checked').find('a').text()+'&name='+name+'&ctid='+id+'&datahref='+encodeURIComponent(datahref)+'&inajax=1',
dataType: 'xml',
success: function (data) {
if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
var s = data.lastChild.firstChild.nodeValue;
$('.ajaxbox_cheker').html(s);
}
});
}
$(document).on('click','.choose', function () {
if($(this).data('link')){
hb_jump($(this).data('link'));
return false
}
var that = $(this), c_jmpurl = '';
if(that.data('href')){ c_jmpurl = that.data('href'); }
if(that.data('ctid')){ c_jmpurl = $('#sub_check'+that.data('ctid')).data('href'); }
window.location.href= c_jmpurl;
});
$(document).on('click','.dist_check', function () {$('.dist_check').removeClass('checked').removeClass('main_color'); $(this).addClass('checked').addClass('main_color');});
$(document).on('click','.dist_nav', function () {if($('.autotrigger').length>0){$('.autotrigger').find('a').trigger('click');}});
$(document).on('click','.first_check', function () {
if($(this).data('link')){
hb_jump($(this).data('link'));
return false
}
$('.ajaxbox_cheker').html('');
});
</script>
<?php } include template('xigua_hb:common_footer'); if($_G['cache']['plugin']['xigua_hs']) { if($_G['cache']['plugin']['xigua_st']['dingwei'] && getcookie('nowst') && $_REQUEST['st']==0) { dheader("Location: $SCRITPTNAME?id=xigua_hb&mobile=2&st=".getcookie('nowst'));?><?php } if($_G['cache']['plugin']['xigua_st']['dingwei'] && !getcookie('setcitygeo')) { ?>
<script>var HB_INWECHAT = '<?php echo HB_INWECHAT;?>',mkey = "<?php echo $_G['cache']['plugin']['xigua_hs']['mkey'];?>",HS_MULTIUPLOAD = "<?php echo $_G['cache']['plugin']['xigua_hb']['multiupload'];?>";</script>
<script src="source/plugin/xigua_hb/static/js/geolocation.js?<?php echo VERHASH;?>" type="text/javascript"></script>
<script src="source/plugin/xigua_hs/static/hs.js?<?php echo VERHASH;?>" type="text/javascript"></script>
<script>
function fzdw(){
hs_getlocation(function (position) {
var citylat = (position.latitude||position.lat);
var citylng = (position.longitude||position.lng);
$.ajax({
type: 'GET',
url: _APPNAME + '?id=xigua_hs&ac=getloc&checkst=1&lat='+citylat+'&lng='+citylng+'&inajax=1',
dataType: 'xml',
success: function (data) {
if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
var s = data.lastChild.firstChild.nodeValue;
console.log(s);
var m = s.split('|');
if('success' == m[0]){
var _t = m[1].split(',');
console.log(_t);
if(_t[0]>0 && _t[0]!='<?php echo $_GET['st'];?>'){
$.confirm("当前定位是"+_t[1]+'，是否切换？', function() {
hb_setcookie('setcitygeo', 1, <?php echo $_G['cache']['plugin']['xigua_st']['dingagain'];?>);
hb_setcookie('nowst', _t[0], 864000);
window.location.href = _APPNAME+"?id=xigua_hb&st="+_t[0];
}, function() {
hb_setcookie('setcitygeo', 1, <?php echo $_G['cache']['plugin']['xigua_st']['dingagain'];?>);
});
}else{
hb_setcookie('setcitygeo', 1, <?php echo $_G['cache']['plugin']['xigua_st']['dingagain'];?>);
}
}else{
}
}
});
});
}
if(typeof wx!='undefined'){wx.ready(function () {  fzdw(); });}else{setTimeout(function(){ fzdw(); }, 350);}
</script>
<?php } elseif(trim($config['getbygeo']) && !getcookie('setcitygeo')) { ?>
<script>var HB_INWECHAT = '<?php echo HB_INWECHAT;?>',mkey = "<?php echo $_G['cache']['plugin']['xigua_hs']['mkey'];?>",HS_MULTIUPLOAD = "<?php echo $_G['cache']['plugin']['xigua_hb']['multiupload'];?>";</script>
<script src="source/plugin/xigua_hb/static/js/geolocation.js?<?php echo VERHASH;?>" type="text/javascript"></script>
<script src="source/plugin/xigua_hs/static/hs.js?<?php echo VERHASH;?>" type="text/javascript"></script>
<script>
function autocitydw(){
hs_getlocation(function (position) {
var citylat = (position.latitude||position.lat);
var citylng = (position.longitude||position.lng);
$.ajax({
type: 'GET',
url: _APPNAME + '?id=xigua_hs&ac=getloc&geoauto=1&lat='+citylat+'&lng='+citylng+'&inajax=1',
dataType: 'xml',
success: function (data) {
if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
var s = data.lastChild.firstChild.nodeValue;
console.log(s);
var m = s.split('|');
if('success' == m[0]){
$.confirm("检测到您在"+m[1].split(':')[0]+'，是否切换？', function() {
hb_setcookie('setcitygeo', 1, 3600);
window.location.href = _APPNAME+"?id=xigua_hb&"+m[1].split(':')[1]+_URLEXT;
}, function() {
hb_setcookie('setcitygeo', 1, 3600);
});
}else{
hb_setcookie('setcitygeo', 1, 3600);
}
}
});
});
}
if(typeof wx!='undefined'){wx.ready(function () { autocitydw(); });}else{setTimeout(function(){ autocitydw(); }, 350);}
</script>
<?php } } ?>