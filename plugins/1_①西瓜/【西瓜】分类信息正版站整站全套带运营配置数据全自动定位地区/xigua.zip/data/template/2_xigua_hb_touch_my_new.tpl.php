<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); hookscriptoutput('my_new');?><?php include template('xigua_hb:common_header'); if($_G['cache']['plugin']['xigua_hh']) { $hhme = C::t('#xigua_hh#xigua_hh_member')->fetch_prepare($_G[uid]);?><?php } include_once DISCUZ_ROOT . "source/plugin/xigua_hb/include/c_my.php";?><link href="source/plugin/xigua_hb/static/css/mynew.css?<?php echo VERHASH;?>" rel="stylesheet" /><style>.weui-cells{overflow: hidden;background: #fff;margin:.75rem;border-radius:.5rem;position: relative;padding: 0;}.weui-cells:before, .weui-cells:after, .weui-grids:before,.weui-grids:after,.weui-grid:before,.weui-grid:after{display:none}.my_new_bd .my__head_new{margin-bottom:35px}.weui-grid{padding:1rem 0}.weui-grid__icon{text-align:center}<?php if($ispcma) { ?>
.weui-cells{margin:.75rem 0}.my_new_bd .float_nav{width:100%;margin-left:0}
<?php } ?></style>
<div class="page__bd my_new_bd">
    <div class="my__head_new main_bg" <?php if($cover) { ?>style="background-image:url(<?php echo $cover;?>);"<?php } ?>>
    <i class="header-annimate-element1"></i><i class="header-annimate-element4"></i>
    <i class="header-annimate-element5"></i><i class="header-annimate-element6"></i>
    <i class="header-annimate-element7"></i><i class="header-annimate-element8"></i>
    <i class="header-annimate-element9"></i>
        <div class="my__head_wap block">
            <a class="setting" href="<?php echo $SCRITPTNAME;?>?id=xigua_hb&ac=myset">设置</a>
            <div class="my__head_user z">
                <?php if($_G['cache']['plugin']['xigua_member']) { ?>
                <a href="<?php echo $SCRITPTNAME;?>?id=xigua_member:profile" class="my__head_avatar z"><img src="<?php echo avatar($_G['uid'], 'middle', 1)?>" onerror="this.error=null;this.src='source/plugin/xigua_hb/static/img/icon.png'" ></a>
                <?php } else { ?>
                <span class="my__head_avatar z"><img src="<?php echo avatar($_G['uid'], 'middle', 1)?>" onerror="this.error=null;this.src='source/plugin/xigua_hb/static/img/icon.png'"></span>
                <?php } ?>
                <div>
                    <div class="my__head_nickname f16"><?php echo $_G['username'];?> <?php if($_G['cache']['plugin']['xigua_hh']) { ?><em class="f12">UID : <?php echo $_G['uid'];?></em><?php } ?></div>

                    <?php if($_G['cache']['plugin']['xigua_hh']) { ?>
                        <?php if($hhme) { ?>
                        <a href="<?php if($hhme['display']) { if($hhme['end']) { ?><?php echo $SCRITPTNAME;?>?id=xigua_hh&ac=join&do=renew<?php } else { ?><?php echo $SCRITPTNAME;?>?id=xigua_hh&ac=my<?php } } elseif($hhme['unpay']) { ?>javascript:myhh_pay('<?php echo $hhme['order']['subject'];?>','<?php echo $hhme['order']['baseprice'];?>', '<?php echo $hhme['order']['order_id'];?>');<?php } else { ?>javascript:$.toast('待审核');<?php } ?>" class="qblink"><i class="iconfont icon-hehuoren f12"></i><?php echo $hhme['joininfo']['name'];?> <em class="f12"><?php if($hhme['display']) { if($hhme['end']) { ?>已过期，点击续费<?php } else { ?><?php echo $hhme['endts_u'];?><?php if(lang('plugin/xigua_hh', 'yongjiu')!=$hhme['endts_u']) { ?>过期<?php } } } else { ?><?php echo $hhme['status_u'];?><?php } ?></em>
                            <i class="iconfont icon-jinrujiantou f10"></i>
                        </a>
                        <?php } else { ?>
                        <a href="<?php echo $SCRITPTNAME;?>?id=xigua_hh&ac=join&mobile=2" class="qblink">
                            <i class="iconfont icon-hehuoren f12"></i>加盟合伙人<i class="iconfont icon-jinrujiantou f10"></i>
                        </a>
                        <?php } ?>
                    <?php } else { ?>
                    <a class="qblink">UID : <?php echo $_G['uid'];?></a>
                    <?php } ?>
                </div>
            </div>
            <?php $viewsstyle = 'style="width:33.333333%"';?>            <?php if($_G['cache']['plugin']['xigua_hk']) { ?>
                <?php $card = C::t('#xigua_hk#xigua_hk_card')->fetch_online_card($_G[uid]);?>                <?php $viewsstyle = '';?>                <?php if($card) { ?>
                <a class="hh_head_side slideInRight" style="background-image:url(source/plugin/xigua_hk/static/img/vipicon.png);" href="<?php echo $SCRITPTNAME;?>?id=xigua_hk<?php echo $urlext;?>"></a>
                <?php } else { ?>
                <a class="hh_head_side slideInRight" style="background-image:url(source/plugin/xigua_hk/static/img/vipicon.png);" href="<?php echo $SCRITPTNAME;?>?id=xigua_hk&ac=join<?php echo $urlext;?>"></a>
                <?php } ?>
            <?php } elseif($_G['cache']['plugin']['xigua_hh']) { ?>
                <?php $viewsstyle = '';?>                <?php if($hhme) { ?>
                <a class="hh_head_side slideInRight hh_imhhr" href="<?php if($hhme['display']) { if($hhme['end']) { ?><?php echo $SCRITPTNAME;?>?id=xigua_hh&ac=join&do=renew<?php } else { ?><?php echo $SCRITPTNAME;?>?id=xigua_hh&ac=my<?php } } elseif($hhme['unpay']) { ?>javascript:myhh_pay('<?php echo $hhme['order']['subject'];?>','<?php echo $hhme['order']['baseprice'];?>', '<?php echo $hhme['order']['order_id'];?>');<?php } else { ?>javascript:$.toast('待审核');<?php } ?>"></a>
                <?php } else { ?>
                <a class="hh_head_side slideInRight" href="<?php echo $SCRITPTNAME;?>?id=xigua_hh&ac=join<?php echo $urlext;?>"></a>
                <?php } ?>
            <?php } ?>
            <?php if($config['newcenter']==2) { ?>
            <div class="weui-grids weui-grids-mini pd_sub_0">
                <a href="javascript:;" class="weui-grid" <?php echo $viewsstyle;?>>
                    <div class="tc">
                        <span id="njum3" class="countup f14"><?php echo $totalpub;?></span>
                    </div>
                    <p class="weui-grid__label f13 ">总发布</p>
                </a>
                <a href="javascript:;" class="weui-grid" <?php echo $viewsstyle;?>>
                    <div class="tc">
                        <span id="njum1" class="countup f14 "><?php echo $totalviews;?></span>
                    </div>
                    <p class="weui-grid__label f13 ">总浏览量</p>
                </a>
                <a href="javascript:;" class="weui-grid" <?php echo $viewsstyle;?>>
                    <div class="tc">
                        <span id="njum2" class="countup f14"><?php echo $totalviewme;?></span>
                    </div>
                    <p class="weui-grid__label f13 ">我的浏览量</p>
                </a>
            </div>
            <?php } ?>
        </div>
    </div>

<div class="float_nav weui-flex cl">
    <div class="swiper-container" id="newsSlider" data-autoplay="5000" data-speed="3000">
        <ul class="swiper-wrapper">
            <?php $toutiaoitems = array_filter(explode("\n", trim($_G['cache']['plugin']['xigua_hb']['toutext'])));?>            <?php if(is_array($toutiaoitems)) foreach($toutiaoitems as $toutiaoitem) { ?>            <?php list($font, $link)= explode(",", trim($toutiaoitem));?>            <li class="swiper-slide"> <b class="main_color mr8 f14"><i class="iconfont icon-tongzhi f14 "></i>平台公告</b> <a href="<?php echo $link;?>" class="c9 f14"><?php echo $font;?></a> </li>
            <?php } ?>
        </ul>
    </div>
</div>

<div class="weui-cells f15 before_none after_none">
    <div class="weui-grids">
        <a href="<?php echo $SCRITPTNAME;?>?id=xigua_hb&ac=mypub&mobile=2<?php echo $urlext;?>" class="weui-grid" style="width:25%">
            <div class="weui-grid__icon">
                <i class="iconfont icon-fabuhei main_color f22 " style="top: 2px;position: relative"></i>
            </div>
            <p class="weui-grid__label">我的发布</p>
            <em class="sub_label f10 c9"><?php echo $totalmypub;?>条</em>
        </a>
        <a style="width:25%" <?php if(!(IN_MAGAPP || IN_QIANFAN)&&$config['qbguide']&&$config['qbguidelink']) { ?>onclick="return jump_download();"<?php } else { if(IN_QIANFAN && $config['autoinapp']) { ?>onclick="QFH5.jumpMyPackage();"<?php } elseif(IN_MAGAPP&&$config['autoinapp']) { ?>onclick="mag.newWin('/mag/user/v1/user/wallet');"<?php } else { ?>href="<?php echo $SCRITPTNAME;?>?id=xigua_hb&ac=qianbao&mobile=2"<?php } } ?> class="weui-grid">
            <div class="weui-grid__icon">
                <i class="iconfont icon-qianbao2 main_color f24"></i>
                <?php if($qianbao['money']>0) { ?><span class="weui-badge">&yen;<?php echo $qianbao['money']*100/100; ?></span><?php } ?>
            </div>
            <p class="weui-grid__label">我的钱包</p>
        </a>


        <a class="weui-grid" style="width:25%" href="<?php echo $SCRITPTNAME;?>?id=xigua_hb&ac=member&uid=<?php echo $_G['uid'];?>&type=viewlog&mobile=2">
            <div class="weui-grid__icon">
                <i class="iconfont icon-wode1 main_color f24"></i>
            </div>
            <p class="weui-grid__label">个人主页</p>
        </a>

        <a style="width:25%" class="weui-grid" href="<?php echo $SCRITPTNAME;?>?id=xigua_hb&ac=mycomment&type=sx&mobile=2">
            <div class="weui-grid__icon">
                <i class="iconfont icon-createtask_fill main_color f26 pr-1"></i>
                <?php if($newpm = C::t('#xigua_hb#xigua_hb_comment')->fetch_type1_num()) { ?><span class="weui-badge"><?php echo $newpm;?></span><?php } ?>
            </div>
            <p class="weui-grid__label">我的私信</p>
        </a>

    </div>
</div><?php $gwidth='style="max-width:8rem;width:25%;"';?><div class="weui-cells f15 before_none after_none">
    <div class="weui-cells__title weui_title mt0 f15 bold">我的订单</div>
    <div class="weui-grids">
    <?php if($_G['cache']['plugin']['xigua_hm']) { ?>
        <a href="<?php echo $SCRITPTNAME;?>?id=xigua_hm&ac=my_order&do=seckill<?php echo $urlext;?>" class="weui-grid" <?php echo $gwidth;?>>
            <div class="weui-grid__icon">
                <i class="iconfont icon-qianggou color-red2 f22"></i>
            </div>
            <p class="weui-grid__label <?php echo $gfont;?>">抢购订单</p>
        </a>
    <?php } ?>
        <?php if($_G['cache']['plugin']['xigua_hd']) { ?>
        <a href="<?php echo $SCRITPTNAME;?>?id=xigua_hd&ac=my_order&do=evt<?php echo $urlext;?>" class="weui-grid" <?php echo $gwidth;?>>
            <div class="weui-grid__icon">
                <i class="iconfont icon-huojian color-orange f24"></i>
            </div>
            <p class="weui-grid__label <?php echo $gfont;?>">减价订单</p>
        </a>
        <?php } ?>
        <?php if($_G['cache']['plugin']['xigua_hk']) { ?>
        <a href="<?php echo $SCRITPTNAME;?>?id=xigua_hk&ac=my_order&type=unuse&mobile=2<?php echo $urlext;?>" class="weui-grid" <?php echo $gwidth;?>>
            <div class="weui-grid__icon">
                <i class="iconfont icon-icons- color-paypal f24"></i>
            </div>
            <p class="weui-grid__label <?php echo $gfont;?>"><?php echo str_replace(lang('plugin/xigua_hk', 'heika'), $_G['cache']['plugin']['xigua_hk']['cardname'], lang('plugin/xigua_hb', 'heikadd')); ?></p>
        </a>
        <?php } ?>
        <?php if($_G['cache']['plugin']['xigua_pt']) { ?>
        <a href="<?php echo $SCRITPTNAME;?>?id=xigua_pt&ac=order<?php echo $urlext;?>" class="weui-grid" <?php echo $gwidth;?>>
            <div class="weui-grid__icon">
                <i class="iconfont icon-fenlei color-good f22"></i>
            </div>
            <p class="weui-grid__label <?php echo $gfont;?>">拼团订单</p>
        </a>
        <?php } ?>
        <?php if($_G['cache']['plugin']['xigua_sp']) { ?>
        <a href="<?php echo $SCRITPTNAME;?>?id=xigua_sp&ac=wode<?php echo $urlext;?>" class="weui-grid" <?php echo $gwidth;?>>
            <div class="weui-grid__icon">
                <i class="iconfont icon-gouwuche main_color f24"></i>
            </div>
            <p class="weui-grid__label <?php echo $gfont;?>">商品订单</p>
        </a>
        <?php } ?>
        <?php if($_G['cache']['plugin']['xigua_hp']) { ?>
        <a href="<?php echo $SCRITPTNAME;?>?id=xigua_hp&ac=my&mobile=2<?php echo $urlext;?>" class="weui-grid">
            <div class="weui-grid__icon">
                <i class="iconfont icon-mingpian color-dribbble f24"></i>
            </div>
            <p class="weui-grid__label">我的名片</p>
        </a>
        <?php } ?>
        <?php if($_G['cache']['plugin']['xigua_hs']) { ?>
        <a href="<?php echo $SCRITPTNAME;?>?id=xigua_hs&ac=help&do=fukuan&mobile=2<?php echo $urlext;?>" class="weui-grid">
            <div class="weui-grid__icon">
                <i class="iconfont icon-yongjin1 color-dribbble f22"></i>
            </div>
            <p class="weui-grid__label">线下订单</p>
        </a>
        <?php } ?>
        <a href="<?php echo $SCRITPTNAME;?>?id=xigua_hb&ac=myorder&mobile=2<?php echo $urlext;?>" class="weui-grid" <?php echo $gwidth;?>>
            <div class="weui-grid__icon">
                <i class="iconfont icon-dingdan color-paypal f20" style="position: relative;top: 2px;"></i>
            </div>
            <p class="weui-grid__label <?php echo $gfont;?>">订单记录</p>
        </a>
    </div>
</div>

<div class="weui-cells f15 before_none after_none" style="display:none">
    <div class="weui-cells__title weui_title mt0 f15 bold">商家中心
        <a class="y c9 pr_1" href="<?php echo $SCRITPTNAME;?>?id=xigua_hs&ac=shcenter&mobile=2<?php echo $urlext;?>">更多商家管理<i class="f13 iconfont icon-jinrujiantou"></i></a>
    </div>
    <div class="weui-grids">
        <?php if($_G['cache']['plugin']['xigua_hs']) { ?>
        <a href="<?php echo $SCRITPTNAME;?>?id=xigua_hs&ac=shcenter&mobile=2<?php echo $urlext;?>" class="weui-grid">
            <div class="weui-grid__icon">
                <i class="iconfont icon-shop color-paypal f24"></i>
            </div>
            <p class="weui-grid__label">商家中心</p>
            <p class="sub_label f10 c9" style="display:none">已入驻<em style="display:none" id="myshnum">0</em>家</p>
        </a>
        <a id="saoyisao" href="javascript:;" class="weui-grid">
            <div class="weui-grid__icon">
                <i class="iconfont icon-saoyisao color-good f20" style="position:relative;top:3px"></i>
            </div>
            <p class="weui-grid__label">扫码核销</p>
        </a>
        <a href="<?php echo $SCRITPTNAME;?>?id=xigua_hs&ac=myshop<?php echo $urlext;?>" class="weui-grid">
            <div class="weui-grid__icon">
                <i class="iconfont icon-gonggao color-green f22"></i>
            </div>
            <p class="weui-grid__label">快速管理</p>
        </a>

        <a href="<?php echo $SCRITPTNAME;?>?id=xigua_hs&ac=add_area<?php echo $urlext;?>" class="weui-grid">
            <div class="weui-grid__icon">
                <i class="iconfont icon-mudedi  color-red f24"></i>
            </div>
            <p class="weui-grid__label">配送方式</p>
        </a>
        <?php } ?>
    </div>
</div>


<div class="weui-cells f15 before_none after_none">
    <div class="weui-cells__title weui_title mt0 f15 bold">我的工具</div>
    <div class="weui-grids">
        <?php if($config['tcpub']) { ?>
        <a href="<?php echo $SCRITPTNAME;?>?id=xigua_hb&ac=buypub&mobile=2<?php echo $urlext;?>" class="weui-grid">
            <div class="weui-grid__icon">
                <i class="iconfont icon-bianji color-good f24"></i>
            </div>
            <p class="weui-grid__label">发布套餐</p>
            <?php if($qianbao['mfxxnum']) { ?>
            <em class="sub_label f10 c9">剩余<?php echo $qianbao['mfxxnum'];?>次</em>
            <?php } ?>
        </a>
        <?php } ?>
        <?php if($config['sxtc']) { ?>
        <a href="<?php echo $SCRITPTNAME;?>?id=xigua_hb&ac=refresh&do=sxtc&mobile=2<?php echo $urlext;?>" class="weui-grid">
            <div class="weui-grid__icon">
                <i class="iconfont icon-fenlei color-rss f24"></i>
            </div>
            <p class="weui-grid__label">刷新套餐</p>
            <?php if($qianbao['mfsxnum']) { ?>
            <em class="sub_label f10 c9">剩刷新<?php echo $qianbao['mfsxnum'];?>次</em>
            <?php } ?>
        </a>
        <?php } ?>

        <?php if($_G['cache']['plugin']['xigua_dp']) { ?>
        <a href="<?php echo $SCRITPTNAME;?>?id=xigua_dp&ac=my<?php echo $urlext;?>" class="weui-grid">
            <div class="weui-grid__icon">
                <i class="iconfont icon-ganxie1 color-danger f24"></i>
            </div>
            <p class="weui-grid__label">!wddp!</p>
        </a>
        <?php } ?>
        <?php if(IS_ADMINID && !$stadmin) { ?>
        <a href="<?php echo $SCRITPTNAME;?>?id=xigua_hb&ac=manage&stat=display&display=0&mobile=2<?php echo $urlext;?>" class="weui-grid">
            <div class="weui-grid__icon">
                <i class="iconfont icon-fabuzhiwei color-red f24"></i>
            </div>
            <p class="weui-grid__label">信息管理</p>
        </a>

        <?php if($_G['cache']['plugin']['xigua_hs']) { ?>
        <a href="<?php echo $SCRITPTNAME;?>?id=xigua_hs&ac=myshop&manage=1&stat=display&display=0&mobile=2<?php echo $urlext;?>" class="weui-grid">
            <div class="weui-grid__icon">
                <i class="iconfont icon-whatsapp color-paypal f24"></i>
            </div>
            <p class="weui-grid__label">商家管理</p>
        </a>
        <?php } ?>
        <?php } if(IS_ADMINID) { ?>
    <?php if($_G['cache']['plugin']['xigua_dh']) { ?>
        <a href="<?php echo $SCRITPTNAME;?>?id=xigua_dh&ac=my114&manage=1&mobile=2<?php echo $urlext;?>" class="weui-grid">
            <div class="weui-grid__icon">
                <i class="iconfont icon-unie607 color-green f24"></i>
            </div>
            <p class="weui-grid__label">电话本管理</p>
        </a>
    <?php } } ?>

        <?php if($_G['cache']['plugin']['xigua_st']&&$_G['uid']) { ?>
        <?php $_stinfo = C::t('#xigua_st#xigua_st')->fetch_by_status_uid($_G['uid']);?>        <?php } ?>
        <?php if($_stinfo) { ?>
        <a href="<?php echo $SCRITPTNAME;?>?id=xigua_st&ac=my&mobile=2<?php echo $urlext;?>&st=<?php echo $_stinfo['stid'];?>" class="weui-grid">
            <div class="weui-grid__icon">
                <i class="iconfont icon-shouru color-red f24"></i>
            </div>
            <p class="weui-grid__label">站点管理</p>
        </a>
        <?php } elseif($_G['uid'] && $_G['cache']['plugin']['xigua_st']['zzjmf']>0) { ?>
        <a href="<?php echo $SCRITPTNAME;?>?id=xigua_st&ac=shenqing&mobile=2<?php echo $urlext;?>" class="weui-grid">
            <div class="weui-grid__icon">
                <i class="iconfont icon-tianjia color-bluish f24"></i>
            </div>
            <p class="weui-grid__label">申请加盟</p>
        </a>
        <?php } ?>

        <a href="<?php echo $SCRITPTNAME;?>?id=xigua_hb&ac=myaddr&mobile=2<?php echo $urlext;?>" class="weui-grid">
            <div class="weui-grid__icon">
                <i class="iconfont icon-coordinates_fill color-soundcloud f24"></i>
            </div>
            <p class="weui-grid__label">收货地址</p>
        </a>

        <?php if($_G['cache']['plugin']['xigua_hr']['inputpos']==1) { ?>
        <a href="<?php echo $SCRITPTNAME;?>?id=xigua_hr&ac=my&mobile=2<?php echo $urlext;?>" class="weui-grid">
            <div class="weui-grid__icon">
                <i class="iconfont icon-yanzheng color-green f22"></i>
            </div>
            <p class="weui-grid__label">认证中心</p>
        </a>
        <?php } else { ?>
        <a href="<?php echo $SCRITPTNAME;?>?id=xigua_hb&ac=mysetxx&mobile=2<?php echo $urlext;?>" class="weui-grid">
            <div class="weui-grid__icon">
                <i class="iconfont icon-weixinzhifu1 color-amazon f24"></i>
            </div>
            <p class="weui-grid__label">消息设置</p>
        </a>
        <?php } ?>

        <a href="<?php echo $SCRITPTNAME;?>?id=xigua_hb&ac=mycomment&type=tome&mobile=2<?php echo $urlext;?>" class="weui-grid">
            <div class="weui-grid__icon">
                <i class="iconfont icon-xiaoxi color-purple f24"></i>
            </div>
            <p class="weui-grid__label">我的评论</p>
        </a>

        <a href="<?php echo $SCRITPTNAME;?>?id=xigua_hb&ac=fav&mobile=2<?php echo $urlext;?>" class="weui-grid">
            <div class="weui-grid__icon">
                <i class="iconfont icon-collection_fill color-vimeo f24"></i>
            </div>
            <p class="weui-grid__label">收藏/关注</p>
        </a>

        <?php if($_G['cache']['plugin']['xigua_dh']) { ?>
        <a href="<?php echo $SCRITPTNAME;?>?id=xigua_dh&ac=my114&mobile=2<?php echo $urlext;?>" class="weui-grid">
            <div class="weui-grid__icon">
                <i class="iconfont icon-dianhuaben color-success f24"></i>
            </div>
            <p class="weui-grid__label">我的电话本</p>
        </a>
        <?php } ?>

        <?php if($_G['cache']['plugin']['xigua_he']) { ?>
        <a href="<?php echo $SCRITPTNAME;?>?id=xigua_he&ac=wode&mobile=2<?php echo $urlext;?>" class="weui-grid">
            <div class="weui-grid__icon">
                <i class="iconfont icon-huodong color-paypal f24"></i>
            </div>
            <p class="weui-grid__label">我的活动</p>
        </a>
        <?php } ?>


        <?php if($_G['cache']['plugin']['xigua_ho']) { ?>
        <a href="<?php echo $SCRITPTNAME;?>?id=xigua_ho&ac=my<?php echo $urlext;?>" class="weui-grid">
            <div class="weui-grid__icon">
                <i class="iconfont icon-huodongxiangqu color-good f24"></i>
            </div>
            <p class="weui-grid__label">!wddj!</p>
        </a>
        <?php } ?>

        <?php if($_G['cache']['plugin']['xigua_hf']) { ?>
        <a href="<?php echo $SCRITPTNAME;?>?id=xigua_hf&ac=my<?php echo $urlext;?>" class="weui-grid">
            <div class="weui-grid__icon">
                <i class="iconfont icon-jieban color-green f24"></i>
            </div>
            <p class="weui-grid__label">!shangjia!</p>
        </a>
        <?php } ?>

        <?php if($config['sethome']) { ?>
        <?php $sethome = explode("\n", $config[sethome])?>        <?php if(is_array($sethome)) foreach($sethome as $v) { ?>        <?php $link = explode('|', trim($v));?>        <a href="<?php echo strpos($link['2'], '?')===false ? $link['2'].'?'.$urlext: $link['2'].$urlext; ?>" class="weui-grid">
            <div class="weui-grid__icon">
                <?php if($link['1']) { ?><img src="<?php echo $link['1'];?>" style="width:24px;height:24px" /> <?php } else { ?><i class="iconfont icon-toutiao main_color f24"></i><?php } ?>
            </div>
            <p class="weui-grid__label"><?php echo $link['0'];?></p>
        </a>
        <?php } ?>
        <?php } ?>
    </div>
</div>


    <div class="weui-cells">

        <a class="weui-cell weui-cell_access" href="<?php echo $SCRITPTNAME;?>?id=xigua_hb&ac=about&mobile=2">
            <div class="weui-cell__hd"><i class="iconfont icon-guize color-forest"></i></div>
            <div class="weui-cell__bd">
                <p>帮助中心</p>
            </div>
            <div class="weui-cell__ft"> </div>
        </a>
        <?php if(IN_MAGAPP&& $config['magkefu']) { ?>
        <!--songtao://assistant?id=729661326364ccea8521d4f745c40342&name=xxx-->
        <a class="weui-cell weui-cell_access" href="<?php echo $config['magkefu'];?>">
        <?php } else { ?>
        <a class="weui-cell weui-cell_access" href="javascript:;" onclick='$.alert("<img src=<?php echo $config['kfqrcode'];?> /><br>长按二维码添加微信", "长按二维码添加微信");'>
        <?php } ?>
            <div class="weui-cell__hd"><i class="iconfont icon-kefu color-pink"></i></div>
            <div class="weui-cell__bd">
                <p>联系客服</p>
            </div>
            <div class="weui-cell__ft">有问题请找我</div>
        </a>
    </div>

    <div class="footer_fix"></div>
</div>
<a style="display:none;height:2.5rem;position:fixed;left:0;bottom:4rem;z-index:501;color:#fff;width:1rem;font-size:.6rem;line-height:.75rem;text-align:center;padding-top:.25rem;border-radius:0 .15rem .15rem 0;box-shadow:0 .1rem .25rem rgba(0,0,0,.25);background:<?php echo $config['maincolor'];?>;" id="shguide">商家版</a><?php $tabbar=1;?><?php include template('xigua_hb:common_footer'); ?><script src="source/plugin/xigua_hb/static/countUp.js" type="text/javascript"></script>
<script>
<?php if($config['newcenter']==2) { ?>
var options = {useEasing : true,useGrouping : true,separator : '',decimal : '.',prefix : '',suffix : ''};
new countUp("njum1", 0, $('#njum1').text(), 0, 2.5, options).start();
new countUp("njum2", 0, $('#njum2').text(), 0, 2.5, options).start();
new countUp("njum3", 0, $('#njum3').text(), 0, 2.5, options).start();
<?php } ?>
if($('#myshnum').length>0){
    $.ajax({
        type: 'get',
        url: _APPNAME +'?id=xigua_hs&ac=myshnum&inajax=1',
        dataType: 'xml',
        success: function (data) {
            if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
            var s = data.lastChild.firstChild.nodeValue;
            if(!s || s==0){
                $('#hm_link').remove();
                $('#shguide').attr('href', '<?php echo $SCRITPTNAME;?>?id=xigua_hs&ac=enter&mobile=2<?php echo $urlext;?>').show();
            }else{
                 $('#myshnum').parent().parent().parent().parent().show();
                $('#myshnum').html(s).show();
                $('#shguide').attr('href', '<?php echo $SCRITPTNAME;?>?id=xigua_hs&ac=shcenter&mobile=2<?php echo $urlext;?>').show();
            }
        },
        error: function () {}
    });
    $(document).on('click','#saoyisao', function () {
        <?php if(IN_MAGAPP) { ?>mag.scanQR(function(text){window.location.href=text});
        <?php } elseif(IN_QIANFAN) { ?>qianfanScan();
        <?php } elseif(IN_APPBYME) { ?>appbymeScan();
        <?php } else { ?>if(typeof wx!='undefined'){
            wx.scanQRCode();
        }else if(navigator.userAgent.indexOf('bsl') >=0 && typeof BSL!='undefined'){
            BSL.Qcode('0', 'bslsetqr')
        }<?php } ?>
    });
    function bslsetqr (result) {
        window.location.href = result;
    }
    function appbymeScan() {
        sq.scan(function(result){
            window.location.href=result.url;
        });
    }
    function qianfanScan(){
        QFH5.jumpScan(function(state,data){
            if(state==1){
                window.location.href=data.content;
            }else{
            }
        })
    }
}
<?php if($_G['cache']['plugin']['xigua_hh']) { ?>
function myhh_pay(tit, pri, oid){
    $.modal({
        title: "立即支付",
        text: "<span>"+tit+" <b class='color-red'> &yen;"+pri+"</b></span>",
        buttons: [
            { text: "关闭", className: "default"},
            { text: "取消订单", className: "default", onClick: function(){myhh_dopay(0);}},
            { text: "支付", onClick: function(){myhh_dopay(oid);}}
        ]
    });
}
function myhh_dopay(order_id){
    $.showLoading();
    $.ajax({
        type: 'post',
        url: _APPNAME+'?id=xigua_hh&ac=unjoin&inajax=1&order_id='+order_id+(order_id?'':'&do=del'),
        data:{formhash:FORMHASH},
        dataType: 'xml',
        success: function (data) {
            $.hideLoading();
            if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
            var s = data.lastChild.firstChild.nodeValue;
            tip_common(s);
        },
        error: function () { $.hideLoading(); }
    });
}
<?php } ?>
function jump_download() {
    $.confirm("<?php echo $config['qbguide'];?>", function() {
        window.location.href = '<?php echo $config['qbguidelink'];?>';
    }, function() {
    });
    return false;
}
<?php if($config['subscribe'] && !getcookie('miniprogram')&& HB_INWECHAT) { if($config['secert']||$config['magapp_secret']):
    if($config['appid'] && $config['appsecert']):
    $openid = $_G['cookie'][$ckey] ? authcode($_G['cookie'][$ckey], 'DECODE', $authkey) : '';
        if(!$openid):
          $tools = new JsApiPaySF();
          $opendata = $tools->GetFollowOpenid(hb_currenturl().'&oauth=yes');
          if($openid = $opendata['openid']):
            dsetcookie($ckey, authcode($openid, 'ENCODE', $authkey), 864000);
          endif;
        endif;
    endif;
endif;?>$.ajax({
    type: 'get',
    url: _APPNAME + '?id=xigua_hb&ac=checksub&inajax=1&openid=<?php echo $openid;?>',
    data: {formhash: FORMHASH},
    dataType: 'xml',
    success: function (data) {
        if (null == data) {
            return false;
        }
        var s = $.trim(data.lastChild.firstChild.nodeValue);
        if (s.split('|')[1] != 'subscribe') {
            /*if(typeof wx !=='undefined') {
                if (window.__wxjs_environment === 'miniprogram') {
                    wx.miniProgram.navigateTo({url: '/pages/guanzhu/index'});
                    return false;
                }
            }*/
            $.alert("<img src=<?php echo $config['qrcode'];?> /><br>长按识别二维码关注获得", "恭喜您获得实时回复特权");
        }
        $.hideLoading();
    }
});
<?php } ?>
</script>