<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); $footerlink = explode("\n", $hb_setting[footerlink]);
$footerlinks = array();
foreach($footerlink as $_k => $_v):
    list($_link, $_name, $_color, $_gpname) = explode('|', trim($_v));
    $footerlinks[$_gpname][] = array($_link, $_name, $_color);
endforeach;?><div class="zp-footer" <?php if($hb_setting['leftcolor']) { ?>style="background:<?php echo $hb_setting['leftcolor']=='#000000'? $config['maincolor'] : $hb_setting['leftcolor']; ?>"<?php } ?>>
    <div class="inner home-inner">
        <div class="footer-about clearfix">
            <?php if(is_array($footerlinks)) foreach($footerlinks as $_k => $_v) { ?>            <dl class="dlr" style="padding-left:24px;">
                <dt><?php echo $_k;?></dt>
                <dd>
                    <?php if(is_array($_v)) foreach($_v as $__k => $__v) { ?>                    <a <?php if($__v['0']=='#') { ?>href="javascript:;"<?php } else { ?>href="<?php echo $__v['0'];?>" target="_blank"<?php } ?> <?php if($__v['2']) { ?>style="color:<?php echo $__v['2'];?>"<?php } ?>><?php echo $__v['1'];?></a>
                    <?php } ?>
                </dd>
            </dl>
            <?php } ?>
            <dl style="margin-top:-10px;float:right;">
                <dd>
                    <div class="wise-app-box"><img src="<?php echo $_G['cache']['plugin']['xigua_hb']['qrcode'];?>"></div>
                    <p class="wise-app-tip">手机扫一扫，轻松找信息</p>
                </dd>
            </dl>
        </div>
    </div>
    <?php if($_G['setting']['icp']) { ?>
    <div class="inner home-inner copyright">
        <p style="line-height:1.8">Copyright &copy; <?php echo $_G['setting']['sitename'];?>  ( <a class="cfff" href="http://beian.miit.gov.cn/" target="_blank"><?php echo $_G['setting']['icp'];?></a> )</p>
   </div>
    <?php } ?>
</div>
</div>
<div id="sidebar-buttons">
    <a id="weixin-qrcode-login" href="javascript:;"><i class="iconfont icon-shouji f26"></i><div class="frton">手机访问</div></a>
    <a id="online-button" href="javascript:;"><i class="iconfont icon-sixin2 f26"></i><div class="frton">联系客服</div></a>
    <a id="back-to-top" href="javascript:;"><i class="iconfont icon-iconfontarrowup f26"></i><div class="frton">返回顶部</div></a>
    <div id="qrcode_app" class="qrcode-login-dialog cl" style="display:none;<?php if(!$hb_setting['appqrcode']) { ?>width:150px<?php } ?>">
        <?php if($hb_setting['appname'] && $hb_setting['appqrcode']) { ?>
        <div class="z"><img src="<?php echo $hb_setting['appqrcode'];?>"><p><?php echo $hb_setting['appname'];?></p></div>
        <?php } ?>
        <?php if($_G['cache']['plugin']['xigua_hb']['qrcode']) { ?>
        <div class="z"><img src="<?php echo $_G['cache']['plugin']['xigua_hb']['qrcode'];?>"><p>关注微信公众号</p></div>
        <?php } ?>
    </div>
    <div id="qrcode_kefu" class="qrcode-login-dialog cl" style="display:none;width:150px">
        <?php if($_G['cache']['plugin']['xigua_hb']['kfqrcode']) { ?>
        <div class="z"><img src="<?php echo $_G['cache']['plugin']['xigua_hb']['kfqrcode'];?>"><p>联系客服</p></div>
        <?php } ?>
    </div>
</div>
<script>
function hb_jump(jpurl) {
    window.location.href = jpurl;
}
function show_loadmore(){
    $('.load-more').show();
    $('.weui-loadmore').hide();
}
function hide_loadmore(){
    $('.load-more').hide();
    $('.weui-loadmore').show();
}
$(document).on('click','#back-to-top', function () {$('body,html').animate({scrollTop: 0}, 300);return false;});
$('.link-share').hover(function () {
    $('.share-panel').show();
}, function () {
    $('.share-panel').hide();
});
$('.apply-btn2').hover(function () {
    $(this).parent().find('.share-panel2').show();
}, function () {
    $(this).parent().find('.share-panel2').hide();
});
$('.publish').hover(function () {
    $(this).parent().find('.share-panel3').show();
}, function () {
    $(this).parent().find('.share-panel3').hide();
});
$('.header_user_vatar').hover(function () {
    $(this).find('.share-panel3').show();
}, function () {
    $(this).find('.share-panel3').hide();
});
$('.shixi-item').hover(function () {
    $(this).find('.innner_shqr').show();
}, function () {
    $(this).find('.innner_shqr').hide();
});
$('#sidebar-buttons a').hover(function(){
    var that = $(this);
    that.addClass('hover_sidebar');
    console.log(that.attr('id'));
    if(that.attr('id')=='weixin-qrcode-login'){
        $('#qrcode_app').show();
    }else if(that.attr('id')=='online-button'){
        $('#qrcode_kefu').show();
    }
},function(){
    var that = $(this);
    that.removeClass('hover_sidebar');
    if(that.attr('id')=='weixin-qrcode-login'){
        $('#qrcode_app').hide();
    }else if(that.attr('id')=='online-button'){
        $('#qrcode_kefu').hide();
    }
});
$(document).on('click','.jav_right li', function () {
    var that = $(this);
    that.parent().find('li').removeClass('cur');
    that.addClass('cur');
    $('.jav_right_bottom').hide().eq(that.index()).show();
});
$(document).on('click','.checkit', function () {
    if($(this).is(':checked')){
        hb_jump($(this).data('href'));
    }else{
        hb_jump($(this).data('href')+'&orderby=');
    }
});
var swiper = new Swiper('.pc_swiper', {
    slidesPerView: 1,
    loop: true,
    autoplay: {
        delay: 5000,
        disableOnInteraction: true,
    },
    pagination: {
        el: '.swiper-pagination',
        clickable: true,
    },
    navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
    },
});
if ($("#list").length> 0) {
    list_load_more();
    <?php if($hb_setting['autoscroll']) { ?>
    $(window).scroll(function() {
        var totalheight = parseFloat($(window).height()) + parseFloat($(window).scrollTop());
        if ($(document).height() <= totalheight + 50) {
            list_load_more();
        }
    });
    <?php } ?>
}
$(document).on('click','.load-more', function () {
    list_load_more();
});
function list_load_more() {
    if (page <= 0 || typeof loadingurl == 'undefined') {
        return;
    }
    if (!loadingurl) {
        return;
    }
    if (lm) {
        return;
    }
    lm = true;
    $.ajax({
        type: 'get', url: loadingurl + '' + page + _URLEXT, dataType: 'xml', success: function (data) {
            if (null == data) {
                alert(ERROR_TIP);
                return false;
            }
            var s = $.trim(data.lastChild.firstChild.nodeValue);
            if (!s) {
                page = -1;
                hide_loadmore();
                return;
            }
            show_loadmore();
            $("#list").append(s);
            lm = false;
            console.log('page:' + page);
            if (typeof loadingCallback !== 'undefined') {
                loadingCallback();
            }
            page++;
        }, error: function () {
            hide_loadmore();
            lm = false;
        }
    });
}
$(document).on('click','.apply-btn', function () {
    var that = $(this);
    console.log(that.data('mobile'));
    if(that.data('mobile')){
        that.html(that.data('mobile'));
    }else{
    }
});
function IEVersion() {
    var userAgent = navigator.userAgent;
    var isIE = userAgent.indexOf("compatible")> -1 && userAgent.indexOf("MSIE")> -1;
    var isEdge = userAgent.indexOf("Edge")> -1 && !isIE;
    var isIE11 = userAgent.indexOf('Trident')> -1 && userAgent.indexOf("rv:11.0")> -1;
    if (isIE) {
        var reIE = new RegExp("MSIE (\\d+\\.\\d+);");
        reIE.test(userAgent);
        var fIEVersion = parseFloat(RegExp["$1"]);
        if (fIEVersion == 7) {
            return 7;
        } else if (fIEVersion == 8) {
            return 8;
        } else if (fIEVersion == 9) {
            return 9;
        } else if (fIEVersion == 10) {
            return 10;
        } else {
            return 6;
        }
    } else if (isEdge) {
        return 'edge';
    } else if (isIE11) {
        return 11;
    } else {
        return 100;
    }
}
if (IEVersion()<10) {
    function closeCurrentPage() {
        location.href = "about:blank";
    }
    var d = document.createElement("div");
    d.className = "update-browse";
    var dialog = '\
        <section class="dialog-wrap active" style="position: fixed;left: 0;right: 0;top: 0;bottom: 0;-webkit-box-pack: center;-ms-flex-pack: center;justify-content: center;-webkit-box-align: center;-ms-flex-align: center;align-items: center;z-index: 4000;display: -webkit-box;display: -ms-flexbox;display: flex;-webkit-box-orient: vertical;-webkit-box-direction: normal;-ms-flex-direction: column;flex-direction: column;">\
            <div class="overlay" style="display: block;background: rgba(0, 0, 0, 0.7);position: fixed;left: 0;right: 0;top: 0;bottom: 0;z-index: 4000;"></div>\
            <div class="dialog" style="display: block;position: relative;width: 480px;background: #fff;border-radius: 5px;overflow: hidden;z-index: 4005;margin: 0 auto;">\
                <div class="close-btn" onclick="closeDialog()" style="position: absolute;right: 0;top: 0;width: 55px;height: 50px;text-align: center;padding-top: 20px;cursor: pointer;">\
                    <i class="icon close-icon" style="width: 12px;height: 12px;display: inline-block;"></i>\
                </div>\
                <div class="dialog-bd" style="padding: 48px 20px;text-align: center;width: 230px;margin: 0 auto;">\
                    <h3 class="bd-tt" style="font-size: 18px;font-weight: normal;line-height: 18px; margin-bottom: 36px;color: #000;">升级您的浏览器</h3>\
                        <div class="bd-txt" style="text-align: left;line-height: 28px;font-size: 16px;letter-spacing: 0;">您的IE浏览器版本过低，为了更好的体验，请尽快升级您的浏览器。</div>\
                </div>\
            </div>\
        </section>';

    d.innerHTML = dialog;
    var s = document.getElementsByTagName("body")[0];
    s.insertBefore(d, s.firstChild);

    function closeDialog() {
        var parent = document.getElementsByTagName("body")[0]
        var child = document.getElementsByClassName("update-browse")[0];
        parent.removeChild(child);
    }
}
$(document).on('click','.search-btn', function () {
    $('#searchForm').submit();
});
$('.position-sel').hover(function () {
    $('.industry-box').show();
},function () {
    $('.industry-box').hide();
});
$(document).on('click','.industry-box a', function () {
    var that = $(this);
    $('#searchv').html(that.data('txt'));
    $('input[name="id"]').val(that.data('id'));
    $('input[name="ac"]').val(that.data('ac'));
    $('.industry-box').hide();
});
if (typeof _URLEXT !== 'undefined' && _URLEXT !== '&' && _URLEXT!=='' && _URLEXT) {
    $('a').each(function () {
        var that = $(this);
        var thhf = that.attr('href');
        if (thhf && thhf.indexOf('javascript') === -1 && thhf.indexOf('tel') === -1 && thhf.indexOf('sms') === -1 && thhf.indexOf('st=') === -1) {
            var nehref = '';
            if (thhf.indexOf('?') === -1) {
                nehref = thhf.replace(_URLEXT, '') + '?' + _URLEXT;
            } else {
                nehref = thhf.replace(_URLEXT, '') + _URLEXT;
            }
            that.attr('href', nehref);
        }
    });
}
</script>
<?php if($_G['cache']['plugin']['xigua_hb']['tjcode']) { ?><div style="display:none"><?php echo $_G['cache']['plugin']['xigua_hb']['tjcode'];?></div><?php } ?>
</body>
</html>