<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); include_once DISCUZ_ROOT.'source/plugin/xigua_hb/include/c_pc_common.php';
if($config['mustlogin'] && !$_G[uid]):
    hb_check_login();
endif;
$desc = strip_tags($desc);
$description = strip_tags($description);
$navtitle = strip_tags($navtitle);
$navtitle = $navtitle?$navtitle:$config[tname];
if($config[tnameshow]):
    if($navtitle!=$config[tname]):
        $navtitle = "$navtitle - $config[tname]";
    endif;
endif;
if(is_file("$stpath/hook2.php")):
    include_once "$stpath/hook2.php";
endif;
if($_G['cache']['plugin']['xigua_hh']['fanslock']=='lock4'&&strlen($_G[cookie][URLEXT])>=5 && !$_GET[idu]):
    dheader("Location: ". hb_currenturl().$_G[cookie][URLEXT]);
endif;
if(0 && $_G[uid]):
    $hhuser = C::t('#xigua_hh#xigua_hh_member')->fetch_prepare($_G['uid']);
    if($user['display'] && !$user['end'] && (!$_GET[idu]||$_G[uid]!=$_GET[idu])):
        dheader("Location: ". hb_currenturl().'&idu='.$_G[uid]);
    endif;
endif;
$CMAPP = strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'bsl')!==false || strpos(strtolower($_SERVER['HTTP_USER_AGENT']),'ck 2.0')!==false;
$INAPP = (IN_APPBYME||IN_MAGAPP||IN_QIANFAN);
if(IN_MOCUZ||$CMAPP):
    $hide_nav = 1;
endif;
if(IN_PROG && $ac!='index'):
    $hide_nav=1;
endif;
$showfloatapp = ($INAPP && $config[hidebtm]) || $_GET[app];
if($_G['cache']['plugin']['xigua_st']):
    if($_GET['st']<1):
        $stinfo['name'] = $_G['cache']['plugin']['xigua_st']['zongname'];
    endif;
    $navtitle = str_replace('tname', $stinfo['name'], $navtitle);
    $desc     = str_replace('tname', $stinfo['name'], $desc ? $desc : $description);
endif;
$c06 = hb_hex2rgb($config['maincolor'], .06);
if(!$hb_setting):
$cache_key = 'hb_ext_setting';
loadcache($cache_key);
$hb_setting = $_G['cache'][$cache_key];
endif;?><!doctype html>
<html lang="zh-cmn-Hans">
<head>
<meta charset="<?php echo CHARSET;?>">
<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, viewport-fit=cover">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<?php if($hb_setting['base']) { ?><base href="<?php echo $hb_setting['base'];?>/" /><?php } ?>
<title><?php echo $navtitle;?></title>
<meta name="keywords" content="<?php echo $navtitle;?>">
<meta name="description" content="<?php echo $desc ? $desc : $description; ?>">
<link rel="stylesheet" href="source/plugin/xigua_hb/static/pc/style.css?7<?php echo VERHASH;?>">
<link rel="stylesheet" href="source/plugin/xigua_hb/static/css/swiper.min.css?7<?php echo VERHASH;?>">
<link rel="stylesheet" href="source/plugin/xigua_hb/static/iconfont.css?7<?php echo VERHASH;?>">
<style>.swiper-pagination-bullet-active{background:#fff}.card_car_tag.blue {background:<?php echo $c06;?>;border:1px solid <?php echo $c06;?>}
.card_car_tag.blue i {color:<?php echo $config['maincolor'];?>;}.ifoset{font-family:DINAlternate-Bold;src:local("DINAlternate-Bold"),url(source/plugin/xigua_hb/static/css/DINAlternate-Bold.ttf) format("truetype")}
.card_activity_tag.orange{background:<?php echo $config['maincolor'];?>;color:#fff}.main_color{color:<?php echo $config['maincolor'];?>!important}
.hover_sidebar{background:<?php echo $c06;?>;color:<?php echo $config['maincolor'];?>!important}.mod_lv.is-red{background:<?php echo $c06;?>!important;color:<?php echo $config['maincolor'];?>!important;border:1px solid <?php echo $c06;?>}
.dialog-wrap .btn-err:active,.dialog-wrap .btn-err.active,.dialog-wrap .btn-err:hover,.dialog-wrap .btn.active,.dialog-wrap .btn:hover,.search-form.active,.search-form:hover,.show-industry .search-form,.quanzhi-more:hover,.quanzhi-more:active,.dialog-wrap .btn:active{border-color:<?php echo $config['maincolor'];?>}.hover-layer .popover-right-triangle{border-left-color:<?php echo $config['maincolor'];?>}
.industry-box,.suggest-result,.asider-item-click .app-layer,.asider-item-click .layer,.city-choose .city-txt.active,.city-choose:hover .city-txt:after,.city-choose-layer{border:1px solid <?php echo $config['maincolor'];?>;}
.active,.zixun-item-bd:hover,.new-staff-box:hover,.txt:hover,.job-menu-sub .text a:hover,.quanzhi-more:hover,.quanzhi-recomand a:hover,.quanzhi-logo-txt,.hotsearch .list .items a:hover,.condition-box a:hover,.copyright .link-hover:hover,.footer-about dl dd a:hover,.dialog-wrap .btn-err.active,.dialog-wrap .btn-err:hover,.dialog-wrap .btn.active,.dialog-wrap .btn:hover,.dialog-wrap .dialog .dialog-ft .ft-btn:first-child,.dialog-wrap .dialog .dialog-ft .ft-btn:only-child,.suber-add-subsetup,.txt-link-more:hover,.third-key a:hover,.nav li a.publish,.tab .tab-li.active,.tab .tab-li:hover,.c-btn-primary .c-icon,.c-location-header-tips-success,.c-location-header-btn-in-active,.c-location-header-btn-in-active .c-icon,.item-bd .bd-txt a{color:<?php echo $config['maincolor'];?>}
.apply-btn,.job-video .nav li.cur a:after,.quanzhi-logo-txt:after,.quanzhi-logo-txt:before,.hover-layer .tip-txt,.nav li.cur a:after,.nav li a.publish:active,.tabs li.active:after{background-image:linear-gradient(45deg,<?php echo $config['maincolor'];?>,<?php echo $config['maincolor'];?>)}
.votebtn,.head-tab .ht-tab-item.active:after,.main_bg,.fareitemactive,.areaitemactive,.moneyitemactive{background-color:<?php echo $config['maincolor'];?>}
</style><script>var IN_WECHAT = '<?php echo HB_INWECHAT;?>',IN_PROG='<?php echo IN_PROG;?>', AVATAR = "<?php echo avatar($_G['uid'], 'middle', true); ?>", UID = '<?php echo $_G['uid'];?>', FORMHASH = '<?php echo FORMHASH;?>', PLZINPUT = "请输入文字", BODA = '拨打电话', DELCONFIRM = '确定删除?', SUIBIANSHUO = '随便说点什么', HUIFU1 = '回复：', ERROR_TIP = '数据异常，请刷新页面再试。';var loading = false, page = 1, _APPNAME = '<?php echo $SCRITPTNAME;?>', scrollto =0, plzinput_mobile = '请输入手机号码';
var cookiepre = '<?php echo $_G['config']['cookie']['cookiepre'];?>', cookiedomain = '<?php echo $_G['config']['cookie']['cookiedomain'];?>', cookiepath = '<?php echo $_G['config']['cookie']['cookiepath'];?>', IN_APP='<?php if(IN_MAGAPP) { ?>magapp<?php } elseif(IN_APPBYME) { ?>appbyme<?php } elseif(IN_QIANFAN) { ?>qianfan<?php } ?>', LISTINCR = '<?php echo $config['listincr'];?>', _URLEXT = '<?php echo $_G['cookie']['URLEXT'];?><?php echo $urlext;?>', GSITE='<?php echo $_G['siteurl'];?>', MAXTAG = '<?php echo intval($config['maxtag']); ?>', MAXTAGTIP = "<?php echo str_replace('n', $config['maxtag'], lang_hb('zdng',0));?>", FASIXIN = '发私信'<?php if($config['xiala']) { ?>,XL=1<?php } ?>, LXFS ='查看联系方式',CKXFF = '查看联系方式需支付<strong class="amount">', QRZF ='</strong>元<br>确认支付？', CKLXFS = '查看联系方式', ISADMINID = '<?php echo IS_ADMINID; ?>', QUXIAO = '取消', SHANCHU = '删除', QUEDING = '确定', lm=false;</script>
<script src="source/plugin/xigua_hb/static/lib/jquery-2.1.4.js?23<?php echo VERHASH;?>" type="text/javascript"></script>
<script src="source/plugin/xigua_hb/static/js/swiper.min.js?<?php echo VERHASH;?>" type="text/javascript"></script>
</head>
<body>
<div class="home-body" <?php if($_GET['ac']=='cat' && $hb_setting['cattoppic']) { ?>style="background:url(<?php echo $hb_setting['cattoppic'];?>) no-repeat 0px 68px;background-size:contain"<?php } ?> <?php if($_GET['ac']=='hangye' && $hs_setting['shhy_toppic']) { ?>style="background:url(<?php echo $hs_setting['shhy_toppic'];?>) no-repeat 0px 68px;background-size:contain"<?php } ?>>
<div id="header">
    <div class="inner home-inner clearfix" style="display:flex">
        <?php if($hb_setting['logo']) { ?>
        <div class="logo">
            <a href="<?php echo $indexhome ? $indexhome : hb_pc_rewriteoutput('index_page')?>"><?php if(strpos($hb_setting['logo'],'//')!==false) { ?><img style="width:100%;height:100%" src="<?php echo $hb_setting['logo'];?>" /> <?php } else { ?><strong class="f28" style="position:relative;top:5px;"><?php echo strip_tags($hb_setting['logo']); ?></strong><?php } ?></a>
        </div>
        <?php } include template('xigua_hb:st'); ?><div class="nav cl header_nav">
    <ul class="cl"><?php $toplink = explode("\n", $hb_setting[toplink]);?><?php if(is_array($toplink)) foreach($toplink as $_k => $_v) { list($_link, $_name, $_color, $_target) = explode('|', trim($_v));
$cat_id =isset($_GET['cat_id'])? intval($_GET['cat_id']):'';
if(!$_name):
    contiune;
endif;?><li <?php if(($_GET['id']=='xigua_hs:xigua_hs'||$_GET['id']=='xigua_hs')&& (strpos($_link,'xigua_hs')!==false||strpos($_link,'shangjia')!==false||strpos($_link,'hangye')!==false||strpos($_link,'shop')!==false) &&!$hascur) { ?>class="cur"<?php $hascur =1;?><?php } ?> <?php if($ac=='index'&&($_GET['id']=='xigua_hb:xigua_hb'||$_GET['id']=='xigua_hb')&&$_k==0&&!$hascur) { ?>class="cur"<?php $hascur =1;?><?php } if(($_GET['id']=='xigua_hb:xigua_hb'||$_GET['id']=='xigua_hb') && $ac!='index'&&$ac!='view' && (strpos($_link, 'cat_id='.$cat_id)!==false || strpos($_link, 'cat_'.$cat_id)!==false)&&!$hascur) { ?>class="cur"<?php $hascur =1;?><?php } ?>><a href="<?php echo $_link;?>" <?php if($_target) { ?>target="_blank"<?php } ?> <?php if($_color) { ?>style="color:<?php echo $_color;?>"<?php } ?>><?php echo $_name;?></a></li>
<?php } ?>
                <?php if($_G['uid']) { ?>
                <li class="y header_user_vatar">
                    <div href="javascript:;" class="header_user_vatar_a"><img src="<?php echo avatar($_G[uid], 'middle', 1);?>" class="img"></div>
                    <div class="share-panel3">
                        <div class="share-layer share-layer-comp">
                            <div class="popover" style="height:1px">
                                <i class="popover-tag popover-bottom-triangle" style="top:-2px"></i>
                            </div>
                            <div>
                                <a class="logbtn" target="_blank" href="home.php?mod=space&amp;do=notice">提醒 <?php if($_G['member']['newprompt']) { ?><span class="f12 color-red2"><?php echo $_G['member']['newprompt'];?></span><?php } ?></a>
                                <a class="logbtn" href="member.php?mod=logging&amp;action=logout&amp;formhash=<?php echo FORMHASH;?>">退出登录</a>
                            </div>
                        </div>
                    </div>
                </li>
                <?php } else { ?>
                <li class="y header_user_vatar">
                    <div href="javascript:;" class="header_user_vatar_a"><img alt="" src="<?php echo avatar(0, 'middle', 1);?>" onerror="this.error=null;this.src='source/plugin/xigua_hb/static/img/zhanwei.png'" class="img"></div>
                    <div class="share-panel3">
                        <div class="share-layer share-layer-comp">
                            <div class="popover" style="height:1px">
                                <i class="popover-tag popover-bottom-triangle" style="top:-2px"></i>
                            </div>
                            <div>
                                <a class="logbtn" href="member.php?mod=logging&amp;action=login">立即登录</a>
                            </div>
                        </div>
                    </div>
                </li>
                <?php } ?>
                <?php if(strpos($_GET['id'], 'xigua_hs')!==false) { ?>
        <li class="y" style="position:relative"><a href="javascript:;" class="publish">商家入驻</a>
                <div class="share-panel3" >
                    <div class="share-layer share-layer-comp" <?php if($hb_setting['appnamepub'] && $hb_setting['appqrcode']) { ?>style="width:440px"<?php } ?>>
                        <div class="popover">
                            <i class="popover-tag popover-bottom-triangle"></i>
                        </div>
                        <div>
                            <?php if($hb_setting['appnamepub'] && $hb_setting['appqrcode']) { ?>
                            <div style="float: left;width: 220px;"><img src="<?php echo $hb_setting['appqrcode'];?>">
                                <p style="text-align:center;margin-bottom:10px;line-height:1.5"><?php echo $hb_setting['appnamepub'];?></p></div>
                            <div style="float: left;width: 220px;"><img src="<?php echo $SCRITPTNAME;?>?id=xigua_hb:qrcode&isenter=1">
                                <p style="text-align:center;margin-bottom:10px;line-height:1.5">微信扫码入驻商家</p></div>
                            <?php } else { ?>
                            <img src="<?php echo $SCRITPTNAME;?>?id=xigua_hb:qrcode&isenter=1">
                            <p style="text-align:center;margin-bottom:10px;line-height:1.5">微信扫码入驻商家</p>
                            <?php } ?>
                        </div>
                    </div>
            </div>
        </li>
                <?php } else { ?>
                <li class="y" style="position:relative"><a href="javascript:;" class="publish">发布信息</a>
                    <div class="share-panel3" >
                        <div class="share-layer share-layer-comp" <?php if($hb_setting['appnamepub'] && $hb_setting['appqrcode']) { ?>style="width:440px"<?php } ?>>
                            <div class="popover">
                                <i class="popover-tag popover-bottom-triangle"></i>
                            </div>
                            <div>
                                <?php if($hb_setting['appnamepub'] && $hb_setting['appqrcode']) { ?>
                                <div style="float: left;width: 220px;"><img src="<?php echo $hb_setting['appqrcode'];?>">
                                    <p style="text-align:center;margin-bottom:10px;line-height:1.5"><?php echo $hb_setting['appnamepub'];?></p></div>
                                <div style="float: left;width: 220px;"><img src="<?php echo $SCRITPTNAME;?>?id=xigua_hb:qrcode&ispub=1">
                                    <p style="text-align:center;margin-bottom:10px;line-height:1.5">微信扫码发布信息</p></div>
                                <?php } else { ?>
                                <img src="<?php echo $SCRITPTNAME;?>?id=xigua_hb:qrcode&ispub=1">
                                <p style="text-align:center;margin-bottom:10px;line-height:1.5">微信扫码发布信息</p>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                </li>
        <?php } ?>
            </ul>
        </div>
    </div>
</div>