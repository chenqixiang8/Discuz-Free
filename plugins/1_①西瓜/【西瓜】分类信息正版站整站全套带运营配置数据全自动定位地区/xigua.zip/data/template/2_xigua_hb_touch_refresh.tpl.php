<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<div id="refresh_ctrl" style="z-index:999" class="weui-popup__container popup-bottom">
<form  action="<?php echo $SCRITPTNAME;?>?id=xigua_hb&ac=refresh&do=auto&st=<?php echo $_GET['st'];?>" method="post" id="form1">
    <input name="formhash" value="<?php echo FORMHASH;?>" type="hidden">
    <input name="inajax" value="1" type="hidden">
    <input name="reshid" class="reshid" value="0" type="hidden">
    <div class="weui-popup__overlay"></div>
    <div class="weui-popup__modal">
        <div class="toolbar">
            <div class="toolbar-inner">
                <a href="javascript:;" class="picker-button close-popup">取消</a>
                <h1 class="title">刷新信息 ID: <em class="reshid"></em></h1>
            </div>
        </div>
        <div class="modal-content">
            <div class="weui-cells before_none after_none">
                <div class="weui-cell">
                    <div class="weui-cell__hd"><label class="weui-label">自动刷新</label></div>
                    <div class="weui-cell__bd">
                        <input name="form[jiange]" class="weui-input" type="tel" placeholder="请填写时间" value="0">
                    </div>
                    <div class="weui-cell__ft">
                        <span class="color-red">分钟<em class="color-gray">后自动刷新</em></span>
                    </div>
                </div>
                <div class="weui-cell">
                    <div class="weui-cell__hd"><label class="weui-label">刷新上限</label></div>
                    <div class="weui-cell__bd">
                        <input name="form[jiangemax]" class="weui-input" type="tel" placeholder="自动刷新信息上限次数" value="<?php echo $old_data['jiangemax'];?>">
                    </div>
                    <div class="weui-cell__ft">
                        <span class="color-red">次<em class="color-gray">后停止刷新</em></span>
                    </div>
                </div>

<div style="padding:10px 15px" class="color-gray">已刷新
    <em class="main_color" id="refresh_time_num"> <?php echo $old_data['refresh_times'];?> </em>次,
    <b class="main_color">每次自动刷新扣除余额<?php echo $config['refresh'];?>元</b>
    <p>余额不足或刷新总数达上限即停止自动刷新</p>
    <a href="<?php echo $SCRITPTNAME;?>?id=xigua_hb&ac=qianbao<?php echo $urlext;?>" class="main_color bold">点此充值余额</a>

    <div>
        <a class="color-red bold" href="<?php echo $SCRITPTNAME;?>?id=xigua_hb&ac=refresh&do=sxtc">点此购买低价超值刷新套餐</a>
        <p>刷新套餐剩余次数<em class="main_color" id="refresh_tc">0</em>次</p>
    </div>
</div>
            </div>
            <div class="fix-bottom" style="position: relative">
                <input type="submit" id="dosubmit1" href="javascript:;" class="weui-btn weui-btn_primary" value="确定">
            </div>
        </div>
    </div>
</form>
</div>