<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); hookscriptoutput('index3');
0
|| checktplrefresh('./source/plugin/xigua_hb/template/index3.htm', './source/plugin/xigua_hb/template/three_list.htm', 1605508349, 'xigua_hb', './data/template/1_xigua_hb_index3.tpl.php', './source/plugin/xigua_hb/template', 'index3')
;?><?php include template('xigua_hb:common_header'); ?>    <div class="main home-content" <?php if($hb_setting['pictoppic']) { ?>style="background-image:url(<?php echo $hb_setting['pictoppic'];?>)"<?php } ?>>
        <div class="inner home-inner">
            <div class="search-box ">
                <div class="search-form clearfix ">
                    <div  class="clearfix">
                        <div class="search-form-con">
                            <div class="position-sel search-form-ele">
                                <i class="line"></i><span class="label-text search-form-ele"><em class="search-form-ele" id="searchv">信息</em><i class="icon more-down-icon"></i></span>
                                <div class="industry-box">
                                    <ul>
                                        <li><a href="javascript:;" data-id="xigua_hb" data-ac="cat" data-txt="信息">信息</a></li>
                                        <li><a href="javascript:;" data-id="xigua_hs" data-ac="hangye" data-txt="商家">商家</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="ipt-wrap">
                            <form class="z x_form" id="searchForm" method="get" action="<?php echo $SCRITPTNAME;?>">
                                <input type="hidden" name="id" value="xigua_hb">
                                <input type="hidden" name="ac" value="cat">
                                <input type="hidden" name="st" value="<?php echo $_GET['st'];?>">
                                <input type="hidden" name="idu" value="<?php echo $_GET['idu'];?>">
                                <input type="text" name="keyword" autocomplete="off" maxlength="50" placeholder="<?php echo $config['sousuoinput'];?>" value="" class="ipt-search search-form-ele">
                            </form>
                            </div>
                            <div class="search-btn">
                                <i class="icon search-icon"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="inner home-inner page-core clearfix"  style="overflow:hidden">
            <div class="left job-classify" <?php if($hb_setting['leftcolor']) { ?>style="background:<?php echo $hb_setting['leftcolor']=='#000000'? $config['maincolor'] : $hb_setting['leftcolor']; ?>"<?php } ?>>
                <?php if(is_array($cat_tree_all)) foreach($cat_tree_all as $_k => $_v) { $ii++;
$ij = 0;
if($ii>10):
    break;
endif;?>                <div class="box">
                    <div class="first-item">
                        <a href="<?php echo $_v['cat_link'] ? $_v['cat_link'] : hb_pc_rewriteoutput('cat_page', $_v['id'], $cityauto); ?>" class="query-item"><?php echo $_v['name'];?></a>
                        <?php if(!$hb_setting['hidecat']) { ?>
                        <?php if(is_array($_v['child'])) foreach($_v['child'] as $__k => $__v) { ?>                        <a href="<?php echo $__v['cat_link'] ? $__v['cat_link'] : hb_pc_rewriteoutput('cat_page', $__v['id'], $cityauto); ?>" class="query-item"><?php echo $__v['name'];?></a>
                        <?php } ?>
                        <?php } ?>
                    </div>
                    <div class="job-menu-sub">
                        <div class="popover">
                            <i class="popover-left-triangle" style="top:<?php echo ($i*40)+5; ?>px;left:-35px;"></i>
                            <?php $i++;?>                        </div>
                        <ul>
                            <li class="clearfix">
                                <div class="head-txt"><?php echo $_v['name'];?></div>
                                <div class="text">
                                    <?php if(!$_v['child']) { ?>
                                    <a href="<?php echo $_v['cat_link'] ? $_v['cat_link'] : hb_pc_rewriteoutput('cat_page', $_v['id'], $cityauto); ?>" class="job-classify-btn"><?php echo $_v['name'];?></a>
                                    <?php } else { ?>
                                    <?php if(is_array($_v['child'])) foreach($_v['child'] as $__k => $__v) { ?>                                    <a href="<?php echo $__v['cat_link'] ? $__v['cat_link'] : hb_pc_rewriteoutput('cat_page', $__v['id'], $cityauto); ?>" class="job-classify-btn"><?php echo $__v['name'];?></a>
                                    <?php } ?>
                                    <?php } ?>
                                </div>
                            </li>
                            <?php if(is_array($cat_tree_all)) foreach($cat_tree_all as $tmp_k => $tmp_v) { ?>                            <?php if($tmp_k==$_v['id']) { ?>
                            <?php continue;?>                            <?php } $ij++;
if($ij>10):
    break;
endif;?>                            <li class="clearfix">
                                <div class="head-txt"><?php echo $tmp_v['name'];?></div>
                                <div class="text">
                                    <?php if(!$tmp_v['child']) { ?>
                                    <a href="<?php echo $tmp_v['cat_link'] ? $tmp_v['cat_link'] : hb_pc_rewriteoutput('cat_page', $tmp_v['id'], $cityauto); ?>" class="job-classify-btn"><?php echo $tmp_v['name'];?></a>
                                    <?php } else { ?>
                                    <?php if(is_array($tmp_v['child'])) foreach($tmp_v['child'] as $__k => $__v) { ?>                                    <a href="<?php echo $__v['cat_link'] ? $__v['cat_link'] : hb_pc_rewriteoutput('cat_page', $__v['id'], $cityauto); ?>" class="job-classify-btn"><?php echo $__v['name'];?></a>
                                    <?php } ?>
                                    <?php } ?>
                                </div>
                            </li>
                            <?php } ?>
                        </ul>
                    </div>
                </div>
                <?php } ?>
            </div>
            <div class="middle banner">
                <div class="ivu-carousel"  style="width:690px">
                    <?php if($hb_setting['pcslider1']) { ?>
                    <div class="swiper-container pc_swiper">
                        <div class="swiper-wrapper"><?php for($i=1; $i<=4; $i++):
$key1 = 'pcslider'.$i;
$key2 = 'pcslider_link'.$i;?>                            <?php if($hb_setting[$key1]) { ?>
                            <div class="swiper-slide">
                                <a target="_blank" href="<?php echo $hb_setting[$key2];?>"><img src="<?php echo $hb_setting[$key1];?>"></a>
                            </div>
                            <?php } endfor;?>                        </div>
                        <div class="swiper-pagination"></div>
                        <div class="swiper-button-next"></div>
                        <div class="swiper-button-prev"></div>
                    </div>
                    <?php } elseif($topnavslider) { ?>
                    <div class="swiper-container pc_swiper">
                        <div class="swiper-wrapper">
                            <?php if(is_array($topnavslider)) foreach($topnavslider as $slider) { ?>                            <div class="swiper-slide"><?php echo $slider;?></div>
                            <?php } ?>
                        </div>
                        <div class="swiper-pagination"></div>
                        <div class="swiper-button-next"></div>
                        <div class="swiper-button-prev"></div>
                    </div>
                    <?php } ?>
                </div>
            </div>
            <div class="right job-video">
                <div class="nav clearfix">
                    <ul class="jav_right">
                        <?php if($tidlist && $config['toutitle']) { ?>
                        <li class="cur"><a class="title"><?php echo $config['toutitle'];?></a></li>
                        <li><a class="title">最新发布</a></li>
                        <?php } else { ?>
                        <li class="cur"><a class="title">最新发布</a></li>
                        <?php } ?>
                    </ul>
                </div>
                <?php if($tidlist) { ?>
                <div class="content jav_right_bottom">
                    <?php if(is_array($tidlist)) foreach($tidlist as $_k => $_v) { ?>                    <?php $_k=$_k+1;?>                    <a target="_blank" href="forum.php?mod=viewthread&amp;tid=<?php echo $_v['tid'];?>" class="paihang-item source">
                        <div class="paihang-item-rank"><?php echo $_k;?></div>
                        <div class="paihang-item-left ellipsis" style="max-width:175px"><?php echo $_v['subject'];?></div>
                        <!--<div class="paihang-item-right"><?php echo $_v['time_u'];?></div>-->
                    </a>
                    <?php } ?>
                    <a target="_blank" href="forum.php?mod=forumdisplay&amp;fid=<?php echo $_fid ? $_fid : $config['fid_s']; ?>" class="txt txt-link-more">查看更多</a>
                </div>
                <?php } ?>
                <div class="content jav_right_bottom" <?php if($tidlist) { ?>style="display:none"<?php } ?>>
                    <?php if(is_array($toutiao)) foreach($toutiao as $v) { ?>                    <?php $v[cat_name] = $v[cat_name] ? $v[cat_name] : $tmpcats[$v[catid]][name];
                    $vimg_src = $v[imglist] ? unserialize($v[imglist]): array();
                    $vimg_src = $vimg_src ? $vimg_src[0] : avatar($v['uid'], 'middle', true);?>                    <a target="_blank" href="<?php echo hb_pc_rewriteoutput('view_page', $v['id']); ?>"  class="zixun-item source">
                        <img src="<?php echo $vimg_src;?>" onerror="this.error=null;this.src='source/plugin/xigua_hb/static/img/zhanwei.png'" class="zixun-item-img">
                        <div class="zixun-item-bd">
                            <h4 class="zixun-bd-tt c-line-clamp2" style="-webkit-box-orient: vertical;"><?php echo $v['user']['username'];?><?php echo $v['cr_time'];?>发布了<?php echo $v['cat_name'];?>信息</h4>
                        </div>
                    </a>
                    <?php } ?>
                    <a target="_blank"  href="<?php echo hb_pc_rewriteoutput('cat_page', 0); ?>" class="txt txt-link-more">查看更多</a>
                </div>
            </div>
        </div>
        <div class="quanzhi inner home-inner">
            <div class="left">
                <div class="quanzhi-title">
                    <div class="ele-pointer">最新信息</div>
                </div>
                <div class="quanzhi-logo ele-pointer"></div>
                <div class="quanzhi-logo-txt ele-pointer">优质信息抢先看</div>
                <div  class="quanzhi-recomand">
                    <?php if(is_array($newjing_list)) foreach($newjing_list as $_k => $_v) { ?>                    <p>
                        <a href="<?php echo $_v['0']['cat_link'] ? $_v['0']['cat_link'] : hb_pc_rewriteoutput('cat_page', $_v['0']['id'], $cityauto); ?>" target="_blank" class="first"><?php echo $_v['0']['name'];?></a>
                        <em class="vline v-line-spc"></em>
                        <a href="<?php echo $_v['1']['cat_link'] ? $_v['1']['cat_link'] : hb_pc_rewriteoutput('cat_page', $_v['1']['id'], $cityauto); ?>" target="_blank" class="second"><?php echo $_v['1']['name'];?></a>
                    </p>
                    <?php } ?>
                </div><a href="<?php echo hb_pc_rewriteoutput('cat_page', 0); ?>" target="_blank"  class="quanzhi-more">查看更多</a>
            </div>
            <div class="right recomand-content clearfix">
                <div>
                    <?php if(is_array($diglist)) foreach($diglist as $_k => $_v) { ?>                    <?php $_v[vars] = array_values($_v[vars]); $top3 = array_slice($_v[vars], 0, 3); $top3cnt = count($top3);?><a href="<?php echo hb_pc_rewriteoutput('view_page', $_v['id']); ?>" target="_blank"  class="item" >
    <div class="item-title ellipsis <?php if(!$top3) { ?>towrow<?php } ?>"><?php echo strip_tags($_v['description']); ?></div>
    <p class="job-requirement ellipsis">
        <?php if(is_array($top3)) foreach($top3 as $__k => $__v) { ?>        <?php if(!$__v['html']) { ?>
        <?php continue;?>        <?php } ?>
        <span><?php echo $__v['html'];?></span>
        <?php if($__k<$top3cnt-1) { ?>
        <em class="vline"></em>
        <?php } ?>
        <?php } ?>
    </p>
    <p class="job-compnay ellipsis"><?php echo $newlist_cat_all[$_v['catid']]['name'];?></p>
    <div class="job-salary-box">
        <?php if($_v['vars']['0']['html']) { ?>
        <div class="salary-container" >
            <span class="salary"><?php echo cutstr(str_replace(' ', '', $_v['vars']['0']['html']), 14); ?></span>
        </div>
        <?php } else { ?><?php echo $_v['realname'];?><?php echo $_v['time_u'];?>发布
        <?php } ?>
        <?php if($_v['tags']['0']) { ?>
        <span class="bao-tag"><em><?php echo $_v['tags']['0'];?></em></span>
        <?php } ?>
    </div>
</a>
                    <?php } ?>
                </div>
            </div>
        </div>
<?php if(is_file(DISCUZ_ROOT.'source/plugin/xigua_hs/template/shlist.php')) { include template('xigua_hs:shlist'); } else { include template('xigua_hb:shlist'); } include template('xigua_hb:tuijian'); ?>        <div class="brand-box" >
            <div class="inner home-inner brand-box-content clearfix">
                <p class="brand-box-title"><?php echo $config['tname'];?></p>
                <div class="brand-box-container" style="display:flex">
                    <dl>
                        <dt><?php echo $totalviews;?>+</dt>
                        <dd>信息浏览量</dd>
                    </dl>
                    <?php if($totalsh) { ?>
                    <dl>
                        <dt><?php echo $totalsh;?>+</dt>
                        <dd>已入驻商家</dd>
                    </dl>
                    <?php } ?>
                    <dl>
                        <dt><?php echo $totalpub;?>+</dt>
                        <dd>发布数</dd>
                    </dl>
                    <dl>
                        <dt><?php echo $totalshares;?>+</dt>
                        <dd>分享量<s style="visibility:hidden">量</s></dd>
                    </dl>
                </div>
            </div>
        </div>
    </div><?php include template('xigua_hb:common_footer'); ?>