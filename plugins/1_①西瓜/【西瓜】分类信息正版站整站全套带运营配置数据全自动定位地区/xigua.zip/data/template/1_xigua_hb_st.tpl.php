<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); if($_G['cache']['plugin']['xigua_st'] && is_file(DISCUZ_ROOT.'source/plugin/xigua_st/xigua_st.inc.php')) { include_once DISCUZ_ROOT.'source/plugin/xigua_hb/include/c_pc_st.php';?><div class="city-choose">
    <span  class="city-txt"><?php echo $stinfo['name2']?$stinfo['name2']:($hb_setting['zongname'] ? $hb_setting['zongname'] : $_G['cache']['plugin']['xigua_st']['zongname']); ?><i class="icon more-down-icon"></i></span>
    <div class="city-choose-layer">
        <div class="tabs">
            <div class="citys-box">
                <div  class="tabs-ctn-item clearfix">
                    <div  class="city-content clearfix">
                        <div  class="second-key ellipsis">热门城市</div>
                        <div  class="third-key">
                            <a class="city" href="<?php echo $hb_currenturl;?>&st=-1"><?php echo $hb_setting['zongname'] ? $hb_setting['zongname'] : $st_config['zongname'];; ?></a>
                            <?php if(is_array($hotcity)) foreach($hotcity as $_v) { ?>                            <a class="city" href="<?php echo $hb_currenturl;?>&st=<?php echo $_v['stid'];?>"><?php echo $_v['name2']?$_v['name2']:$_v['name']; ?></a>
                            <?php } ?>
                        </div>
                    </div>
                    <?php if(is_array($abccitys)) foreach($abccitys as $_k => $_v) { ?>                    <div  class="city-content clearfix">
                        <div  class="second-key ellipsis"><?php echo $_k;?></div>
                        <div  class="third-key">
                            <?php if(is_array($_v)) foreach($_v as $__v) { ?>                            <a  href="<?php echo $hb_currenturl;?>&st=<?php echo $__v['stid'];?>" class="city"><?php echo $__v['name2']?$__v['name2']:$__v['name']; ?></a>
                            <?php } ?>
                        </div>
                    </div>
                    <?php } ?>
                </div>
                <div  class="tabs-ctn-item clearfix"></div>
                <div  class="tabs-ctn-item clearfix"></div>
                <div  class="tabs-ctn-item clearfix"></div>
                <div  class="tabs-ctn-item clearfix"></div>
            </div>
        </div>
    </div>
</div>
<?php } ?>
