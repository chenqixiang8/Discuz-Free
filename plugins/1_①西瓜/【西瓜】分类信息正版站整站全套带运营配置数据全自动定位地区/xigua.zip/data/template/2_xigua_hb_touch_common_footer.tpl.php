<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<div class="cl footer_fix"></div><?php include template('xigua_hb:common_tabbar'); include template('xigua_hb:refresh'); ?><div id="backtotop" class="backtotop" <?php if($showfloatapp) { ?>style="bottom:-7rem"<?php } ?>> <span class="icon-vertical-align-top"><i class="iconfont icon-iconfontarrowup"></i></span></div>
<?php if($showfloatapp) { ?>
<div class="psleft" <?php if($config['hidebtm']==2) { ?>style="display:none"<?php } ?>><div id="psleft"></div></div>
<?php } if($config['floatleft']==2 && !in_array($ac, array('my','shcenter','view'))) { $showkf = 1;?><?php } elseif($config['floatleft']==3) { $showkf = 0;?><?php } if(($config['qrcode'] || $config['kfqrcode']) && $showkf && !$INAPP) { ?>
<div class="left_float">
<?php if($config['qrcode']) { ?><span id="lftqr" onclick='$.alert("<img src=<?php echo $config['qrcode'];?> /><br>长按二维码添加微信", "长按二维码添加微信");'>订阅</span><?php } if(strpos($config['kfqrcode'], 'jpg')===false&&strpos($config['kfqrcode'], 'png')===false) { ?>
<a id="leftkf" href="<?php echo $config['kfqrcode'];?>">客服</a><?php } else { ?>
<span id="leftkf" onclick='$.alert("<img src=<?php echo $config['kfqrcode'];?> /><br>长按二维码添加微信", "长按二维码添加微信");'>客服</span>
<?php } ?>
</div>
<?php } if(HB_INWECHAT && $config['showfav']) { if(!getcookie('disfav_uid') && !getcookie('miniprogram')) { ?>
<div id="fav_guide_mask" <?php if(getcookie('miniprogram') || $_GET['x']) { ?>style="display:none"<?php } ?>>
<div class="fav_icon">点击这里收藏</div>
<div class="fav_text">下次就可以在“我”的收藏快速找到这里啦！</div>
<a class="fav_close"><i class="iconfont icon-guanbijiantou"></i></a>
<i class="fav_triangle"></i>
</div>
<?php } } if(IS_ADMINID) { include template('xigua_hb:edit_views'); } if(is_file(DISCUZ_ROOT.'source/plugin/xigua_f/m.class.php')) { include_once DISCUZ_ROOT.'source/plugin/xigua_f/m.class.php';
echo mobileplugin_xigua_f::global_footer_mobile();?><?php } if($config['showguide']||!HB_INWECHAT) { ?><div id="wechat-mask"><div id="wechat-guider" <?php if(!HB_INWECHAT &&!IN_APPBYME&&!IN_QIANFAN&&!IN_MAGAPP) { ?>class="other-guider"<?php } ?>></div></div><?php } ?>
<div class="mask none"></div>
<?php if(HB_INWECHAT) { ?><script src="//res.wx.qq.com/open/js/jweixin-1.0.0.js?<?php echo VERHASH;?>" type="text/javascript"></script><?php } ?>
<script src="source/plugin/xigua_hb/static/app.js?3<?php echo VERHASH;?>2" type="text/javascript"></script>
<script>
function hb_dig(id){var act =[];$.showLoading();$.ajax({type: 'GET',url: _APPNAME+'?id=xigua_hb&ac=succeed&showajax=inx&inajax=1&pubid='+id,dataType: 'xml',success: function (data) {
$.hideLoading();var s = data.lastChild.firstChild.nodeValue;if(s){var spli = s.split('|');console.log(spli);if(spli[0]=='error'){tip_common(s);return false;}
var ej = $.parseJSON(spli[1]);for(var o in ej) {act.push({text:ej[o].title+'<div style="display:none" data-type="'+ej[o].type+'"></div>', onClick: function () {
hb_jump('<?php echo $SCRITPTNAME;?>?id=xigua_hb&ac=pay&digtype='+$(this)[0].text.match(/data\-type\="(\d+)"/i)[1]+'&pubid=' + id+_URLEXT);}});}$.actions({title: '请选择置顶类型',actions: act});
}else{$.actions({title: '请选择置顶类型',actions: [<?php if(is_array($dig_prices)) foreach($dig_prices as $_d_i) { ?>{text: "<?php echo $_d_i['title'];?>", onClick: function () {hb_jump('<?php echo $SCRITPTNAME;?>?id=xigua_hb&ac=pay&digtype=<?php echo $_d_i['type'];?>&pubid=' + id+_URLEXT);}},<?php } ?>]});}},error: function () {}});}
function hb_hbchoice(id){<?php if(is_file(DISCUZ_ROOT.'source/plugin/xigua_hb/hbrw_send.php')) { ?>hb_selecthbtype(id);return false;<?php } ?>$.actions({title: '请选择红包金额',actions: [<?php if(is_array($red)) foreach($red as $item) { ?>{text: "<?php echo $item['title'];?>",onClick: function() { hb_jump('<?php echo $SCRITPTNAME;?>?id=xigua_hb&ac=pay&redtype=<?php echo $item['price'];?>&pubid='+id+_URLEXT);}},<?php } ?>]});}
function hb_shuaxin(id) {$.modal({title: "刷新信息",
text: "刷新信息需要支付<strong class=\"amount\"><?php echo $config['refresh'];?></strong>元<br>您确认要刷新选定的信息吗?<br><a style=display:block;margin:.5rem;color:red; href=plugin.php?id=xigua_hb&ac=refresh&do=sxtc>点此购买低价超值刷新套餐</a>",
buttons: [
{ text: "取消", className: "default", onClick: function(){ } },
{ text: "刷新一次", onClick: function(){
<?php if($config['refresh']>0) { ?>
hb_jump('<?php echo $SCRITPTNAME;?>?id=xigua_hb&ac=pay&refresh=1&pubid=' + id + _URLEXT);
<?php } else { ?>
$.showLoading();
$.ajax({type: 'post', url: '<?php echo $SCRITPTNAME;?>?id=xigua_hb&ac=refresh&pubid=' + id + '&inajax=1',
data: {formhash: FORMHASH}, dataType: 'xml',
success: function (data) {$.hideLoading();if (null == data) {tip_common('error|' + ERROR_TIP);return false;}
var s = data.lastChild.firstChild.nodeValue;
tip_common(s);}, error: function () {$.hideLoading();}
});<?php } ?>} },<?php if($config['sxtc']) { ?>{ text: "自动刷新", onClick: function(){
$('.reshid').val(id).html(id+'');
$('#refresh_ctrl').popup().show();
$.ajax({type: 'get', url: '<?php echo $SCRITPTNAME;?>?id=xigua_hb&ac=refresh&do=get_refe&check_rpid=' + id + '&inajax=1',
dataType: 'xml', success:function(data){
var s = data.lastChild.firstChild.nodeValue;
$('input[name="form[jiange]"]').val(s.split(',')[1]);
$('input[name="form[jiangemax]"]').val(s.split(',')[2]);$('#refresh_tc').html(s.split(',')[3]);
$('#refresh_time_num').html(s.split(',')[0]);},error:function(){$.hideLoading();}});}}<?php } ?>]});}
<?php if($_G['uid'] && trim($config['vtel_taocan'])) { $my_tcan = DB::fetch_first('select * from %t where uid=%d', array('xigua_hb_vtel_taocan', $_G['uid']));?><?php } ?>
function hb_paytel(id, pri, pricat) {
$.modal({
title: '查看联系方式',
text: CKXFF+'<strong class="amount">'+pri+'</strong>'+QRZF+"<?php if($my_tcan) { ?><p>您当前已使用 <em class=\"main_color\"><?php echo $my_tcan['used'];?></em> 次 查看电话机会, 剩余 <em class=\"main_color\"><?php echo $my_tcan['total'];?></em> 次</p><p>有效期 <em class=\"main_color\"><?php echo date('Y-m-d H:i:s', $my_tcan['endts']); ?></em></p><?php } ?>",
buttons: [
{text: "关闭", className: "default", onClick: function () {}},
{text: "支付", className: "", onClick: function () {hb_setcookie('telpayer', 1, 3600);hb_jump('<?php echo $SCRITPTNAME;?>?id=xigua_hb&ac=pay&telpay=1&pricat=' + pricat + '&pubid=' + id + _URLEXT);}}
<?php if(trim($config['vtel_taocan']) && $my_tcan['endts']>=TIMESTAMP && $my_tcan['total']>=1) { ?>,{text: "使用套餐", className: "", onClick: function () { $.showLoading();
    $.ajax({
        type: 'post',data: {formhash:FORMHASH},
        url: _APPNAME+'?id=xigua_hb&ac=refresh&do=telpay&usetc=1&pricat='+pricat+'&pubid2=' + id,
        dataType: 'xml',
        success: function (data) {
            $.hideLoading();
            if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
            var s = data.lastChild.firstChild.nodeValue;
            tip_common(s);
        },
        error: function() {$.hideLoading();}
    });
  }}
<?php } elseif(trim($config['vtel_taocan'])) { ?>,{text: "购买套餐", className: "", onClick: function () {
hb_jump('<?php echo $SCRITPTNAME;?>?id=xigua_hb&ac=refresh&do=dhtc' + _URLEXT);
}}
<?php } ?>
]
});
}
function showansi(obj) {var act = [], that = $(obj);var catid = that.data('catid'), id= that.data('id');<?php if($_GET['stat']!='endts') { ?>
if(catid){act.push({text: '立即支付', onClick: function () {hb_jump('<?php echo $SCRITPTNAME;?>?id=xigua_hb&ac=pay&pubid='+id+'&catid='+catid+_URLEXT);}});}else {<?php if($red && trim($config['red'])) { ?>
if(that.data('canhb')){act.push({text: '红包扩散', onClick: function () {<?php if(is_file(DISCUZ_ROOT.'source/plugin/xigua_hb/hbrw_send.php')) { ?>hb_selecthbtype(id);return false;<?php } ?>$.actions({title: '请选择红包金额',actions: [<?php if(is_array($red)) foreach($red as $item) { ?>{text: "<?php echo $item['title'];?>",onClick: function() {hb_jump('<?php echo $SCRITPTNAME;?>?id=xigua_hb&ac=pay&redtype=<?php echo $item['price'];?>&pubid='+id+_URLEXT);}},<?php } ?>]});}});}<?php } ?>
if(!that.data('hidefx')){act.push( {text: '分享扩散', onClick: function () {localStorage.setItem('wetip_'+id, 1);hb_jump('<?php echo $SCRITPTNAME;?>?id=xigua_hb&ac=view&fx=1&pubid='+id+_URLEXT);}});}
<?php if($config['digprices']&&$dig_prices) { ?>if(that.data('canzd')) {act.push({text: '置顶扩散', onClick: function () {hb_dig(id);}});}<?php } ?>}
<?php if($config['refresh']) { ?>
if (that.data('canzd')) {act.push({text: '刷新信息', onClick: function () {hb_shuaxin(id);}});}<?php } if($config['canfinsh']) { ?>if(!that.data('wc')){act.push( {text: '标记成交', onClick: function () {confirm_del('确定标记成交后，会<span class="main_color">隐藏电话号码</span>，并显示<span class="main_color">已结束</span>！请谨慎操作。','<?php echo $SCRITPTNAME;?>?id=xigua_hb&ac=wc&pubid='+id+'&formhash=<?php echo FORMHASH;?>', 0);}});}<?php } if(IS_ADMINID) { ?>
act.push({text: '改浏览量', onClick: function () {$('.vpubid').val(id).html(id + '');$('#lll_ctrl').popup().show();$.ajax({type: 'get', url: '<?php echo $SCRITPTNAME;?>?id=xigua_hb&ac=refresh&do=get_refe&check_rpid=' + id + '&inajax=1',dataType: 'xml', success: function (data) {var s = data.lastChild.firstChild.nodeValue;$('input[name="form[views]"]').val(s.split(',')[4]);$('input[name="form[shares]"]').val(s.split(',')[5]);$('input[name="form[votes]"]').val(s.split(',')[6]);},error:function(){$.hideLoading();}});}});
act.push({text: '审核', onClick: function () {$.modal({title: "审核",text: "请设置审核的状态",buttons: [{ text: "取消", className: "default"},{ text: "拒绝", onClick: function(){dotong(id, 0);} },{ text: "通过", onClick: function(){dotong(id, 1);}}]});}});
act.push({text: '屏蔽', onClick: function () {$.modal({title: "屏蔽用户",text: "屏蔽后此用户无法发布信息！",buttons: [{ text: "取消", className: "default"},{ text: "屏蔽", onClick: function(){pingbi(that.data('uid'), 1);} },{ text: "解除", onClick: function(){pingbi(that.data('uid'), 0);}}]});}});
<?php } ?>
act.push( {text: '编辑', onClick: function () {hb_jump('<?php echo $SCRITPTNAME;?>?id=xigua_hb&ac=pub&step=3&edit='+id+_URLEXT);}});<?php } else { ?>
act.push( {text: '上架', onClick: function () {hb_shuaxin(id);}});<?php } ?>
act.push( {text: '下架', onClick: function () {confirm_del('下架无法恢复，确认下架?', '<?php echo $SCRITPTNAME;?>?id=xigua_hb&ac=pub&del='+id+'&formhash=<?php echo FORMHASH;?>', id);}});
$.actions({title: '信息ID: '+id,actions: act});hb_setcookie('disable_'+id, 1, 86400);return false;}
<?php if(IS_ADMINID) { ?>
function dotong(pubid, guo){$.showLoading();$.ajax({type: 'post',url: window.location.href + '&ac=manage&inajax=1&pubid='+pubid+'&tongguo='+guo,data:{formhash:FORMHASH,'domanage':1},
dataType: 'xml',success: function (data) {$.hideLoading();if(null==data){ tip_common('error|'+ERROR_TIP); return false;}var s = data.lastChild.firstChild.nodeValue;tip_common(s);},error: function () { $.hideLoading(); }});}
function pingbi(uid, guo){$.showLoading();$.ajax({type: 'post',url: window.location.href + '&ac=manage&inajax=1&uid='+uid+'&pingbi='+guo,data:{formhash:FORMHASH,'domanage':1},dataType: 'xml',
success: function (data) {$.hideLoading();if(null==data){ tip_common('error|'+ERROR_TIP); return false;}var s = data.lastChild.firstChild.nodeValue;tip_common(s);},error: function () { $.hideLoading(); }});}
<?php } ?>
</script>
<div class="swiper-container global-lightbox animated" id="globalLightbox"><div class="swiper-wrapper" id="globalWrapper"></div><div class="swiper-pagination lightbox-pagination"></div><a class="iconfont icon-guanbijiantou closeLightbox"> </a></div>
<?php if($_G['cache']['plugin']['xigua_guide']&& !getcookie('miniprogram') && HB_INWECHAT && is_file(DISCUZ_ROOT.'source/plugin/xigua_guide/mobile.class.php')) { include_once DISCUZ_ROOT.'source/plugin/xigua_guide/mobile.class.php';
$gguid = mobileplugin_xigua_guide::global_footer_mobile();
echo $gguid;?><style>body{padding-top:0!important}.g_guide{z-index:502<?php if(!$config['showgz']) { ?>;display:none<?php } ?>}</style><?php if($gguid&&!$config['showgz']) { ?><script>
$.ajax({type:'get',url:_APPNAME +'?id=xigua_hb&ac=checksub&inajax=1',data:{formhash:FORMHASH},dataType: 'xml',success: function (data) {
if(null==data){  return false;}    var s = $.trim(data.lastChild.firstChild.nodeValue);    if(s.split('|')[1]!='subscribe'){$('.g_guide').show();}}});</script><?php } } if(IN_MAGAPP) { ?>
<script>if(typeof f_getOption == 'function'){var app_option = f_getOption();
if(typeof SHAREIMG !=='undefined'){mag.setData({shareData: {type: 1, imageurl:SHAREIMG, picurl:  SHAREIMG}});}else{mag.setData({shareData: {title: app_option.title,des: app_option.desc,picurl: app_option.imgUrl,linkurl: app_option.link}});}}mag.bounceEnable('false');</script>
<?php } elseif(IN_QIANFAN) { ?>
<script>
if(typeof f_getOption == 'function'){
var app_option = f_getOption();function QFH5ready(){QFH5.setShareInfo(app_option.title,app_option.imgUrl,app_option.desc, app_option.link, function(state,data){
if(state==1){if(typeof openShareDialog == 'function'){openShareDialog();}if(typeof openShare == 'function'){openShare();}}else{alert(data.error);}});}
QFH5.setShareInfo(app_option.title,app_option.imgUrl,app_option.desc, app_option.link, function(state,data){if(state==1){if(typeof openShareDialog == 'function'){openShareDialog();}
if(typeof openShare == 'function'){if(data.type == 1 || data.type === 'SharePlatformWechatMoment'){openShare();}else{$.toast('分享朋友圈才能抢红包哦'+data.type);}}
}else{alert(data.error);}});QFH5ready();}
</script>
<?php } elseif(IN_APPBYME) { ?>
<script>if(typeof f_getOption == 'function'){var app_option = f_getOption();var TOPBAR_MORE_SHARE = 'share';function share(){AppbymeJavascriptBridge.share(app_option.desc, app_option.desc, app_option.link, function(data){alert(data.errInfo);});}
var navbar = {button:[{value:'分享',type:TOPBAR_SHARE}],callBack:function(action){}};sq.customNavBar(navbar);}</script>
<?php } if($_G['cache']['plugin']['xigua_x']) { include_once DISCUZ_ROOT."source/plugin/xigua_x/hook.class.php";
echo plugin_xigua_x::global_footer();?><?php } if($config['tjcode']) { ?><div style="display:none"><?php echo $config['tjcode'];?></div><?php } if(HB_INWECHAT) { ?>
<script><?php if(IN_PROG) { ?>
$('#leftkf').unbind('click').on('touchstart', function () {wx.miniProgram.navigateTo({ url: '/pages/kefu/index'});return false;});
hb_setcookie('miniprogram', 1, 120);$('#fav_guide_mask').hide();$('.g_guide').remove();
<?php if(($_GET['id']=='xigua_hh' && $ac=='my')||$_GET['id']=='xigua_sp') { } else { if($ac!='index'&&$ac!='member') { ?>
$('.x_header').hide();$('.x_header_fix').hide();$('.fix_float').css('top',0);<?php } } } else { ?>hb_setcookie('miniprogram', '', 0);
<?php } ?></script>
<?php } if($config['indexpopexpire']>0 && !getcookie('popexpire')) { dsetcookie('popexpire', 1, $config[indexpopexpire]);
$pophelp = C::t('#xigua_hb#xigua_hb_help')->fetch_by_pop();?><?php if($pophelp) { ?><style>.weui-dialog__bd{max-height:50vh;overflow-y: auto;}</style><div style="display:none"><div id="popsubject"><?php echo $pophelp['subject'];?></div><div id="popcontent"><?php echo $pophelp['content'];?></div></div>
<script>if(window.localStorage.getItem('fetch_by_pop') <Date.parse(new Date()) ){window.localStorage.setItem('fetch_by_pop', Date.parse(new Date())+<?php echo $config['indexpopexpire']*1000; ?>);
$.modal({title: $('#popsubject').text(),text: $('#popcontent').html(),buttons: [{ text: "查看详情", onClick: function(){ hb_jump("<?php echo $pophelp['link'] ?$pophelp['link'] : $SCRITPTNAME.'?id=xigua_hb&ac=about&helpid='.$pophelp['id']; ?>"); } },{ text: "我知道了", className: "default", onClick: function(){ console.log(3)} }]});}</script>
<?php } } ?>
<div id="lxfs" style="display:none">
<div class="weui-cell c6" id="lxfs_mobile0" style="padding:.5rem 0 .5rem">
<div class="weui-flex lxfsw">
<div><i class="iconfont icon-dianhua2 main_color "></i> 电话</div>
<div class="weui-flex__item">
<p id="lxfs_mobile"></p> </div><div>
<a class="tsbtn_m" id="lxfs_mobile1" href="javascript:;">拨打电话</a>
</div></div></div>
<div class="weui-cell c6" style="padding:.5rem 0 0">
<div class="weui-flex lxfsw">
<div><i class="iconfont icon-weixin3 main_color f12"></i> 微信</div>
<div class="weui-flex__item">
<p  id="lxfs_weixin"></p></div><div>
<a class="tsbtn_m fzbtn" id="lxfs_weixin1" data-clipboard-text="" href="javascript:;">点击复制</a>
</div></div></div></div><script>var clipboard = new ClipboardJS('.fzbtn');clipboard.on('success', function(e) {$.alert('微信号<br> '+e.text+' <br> 复制成功'+' <br> 快到微信中搜索添加吧！');});function lxfs_tip(obj, mobile, weixin){var that=$(obj);var lxfsbox = $('#lxfs');if(!mobile){lxfsbox.find('#lxfs_mobile0').hide();}else{lxfsbox.find('#lxfs_mobile0').show();lxfsbox.find('#lxfs_mobile').html(mobile);lxfsbox.find('#lxfs_mobile1').attr('href', 'tel:'+mobile);}lxfsbox.find('#lxfs_weixin').html(weixin);lxfsbox.find('#lxfs_weixin1').attr('data-clipboard-text', weixin);var htm = lxfsbox.html() ;$.alert(htm);}<?php if(1) { ?>if(/iphone/gi.test(navigator.userAgent) && ((screen.height==812&&screen.width==375)||(screen.width==414&&screen.height==896))){$('.weui-tabbar, .in_bottom, .view_bottom, .fix_next').css('padding-bottom','1rem');$('.footer_fix').css('height','3.5rem');}<?php } ?>function jumpDownload(){$.confirm("<?php echo $config['qbguide'];?>", function() {window.location.href = '<?php echo $config['qbguidelink'];?>';}, function() {});return false;}
<?php if(!($_GET['ac']=='cat'&&$_GET['id']=='xigua_sp')) { ?>var top1 = 0, fix_banner = $('.fixbanner'), x_header_fix = $('.x_header_fix');
if (fix_banner.length > 0) {$('<div id="buchang" style="display:none;width:100%;height:2.4rem" class="cl"></div>').insertBefore(fix_banner);setTimeout(function () {top1 = fix_banner.offset().top;}, 200);if (x_header_fix.length > 0 && x_header_fix.css('display') !== 'none') {$(window).scroll(function () {var win_top = $(this).scrollTop();var top = fix_banner.offset().top - 42;if (win_top >= top) {fix_banner.addClass("sfixed");$('#buchang').show();}if(top1===0){top1 = fix_banner.offset().top;}if (win_top < top1 - 42) {fix_banner.removeClass("sfixed");$('#buchang').hide();}})} else {$(window).scroll(function () {var win_top = $(this).scrollTop();var top = fix_banner.offset().top;if (win_top>= top) {fix_banner.addClass("sfixed2");$('#buchang').show();}if(top1===0){top1 = fix_banner.offset().top;}if (win_top< top1) {fix_banner.removeClass("sfixed2");$('#buchang').hide();}})}$(document).on('click', '.fixbanner .weui-navbar__item', function () {$("html,body").animate({scrollTop: typeof top1 !== 'undefined' ? top1 : 200}, 500);});}<?php } ?></script>
<?php if(is_file(DISCUZ_ROOT.'source/plugin/xigua_hb/hbrw_send.php')) { include template('xigua_hb:hbrw'); } ?>
</body></html>