<?php
//Discuz! cache file, DO NOT modify me!
//Identify: 61362f49877d8af432e403f00bde7f4d

$adminextend = array (
  0 => 'xigua.php',
);
?>