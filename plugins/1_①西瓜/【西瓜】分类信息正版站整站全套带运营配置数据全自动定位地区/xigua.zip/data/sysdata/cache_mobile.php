<?php
//Discuz! cache file, DO NOT modify me!
//Identify: 5c39cbbfefac327acb53537c23f0a0ac

$mobilecheck = '{"discuzversion":"X3.4","charset":"utf-8","version":"4","pluginversion":"1.4.8","oemversion":"0","regname":"register","qqconnect":"0","sitename":"Discuz! Board","mysiteid":"","ucenterurl":"http:\\/\\/127.0.0.1\\/xigua\\/uc_server","setting":{"closeforumorderby":null},"extends":{"used":null,"lastupdate":null}}';
?>