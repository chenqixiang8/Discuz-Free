<?php
//Discuz! cache file, DO NOT modify me!
//Identify: e33db03737b15cc42a23ba9f06b82cee

$pluginsetting = array (
);
?>