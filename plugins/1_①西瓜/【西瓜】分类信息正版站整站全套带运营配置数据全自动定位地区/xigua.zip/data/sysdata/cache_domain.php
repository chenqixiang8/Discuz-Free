<?php
//Discuz! cache file, DO NOT modify me!
//Identify: fbe1d89a0a9059a5196fdfc08302b49a

$domain = array (
  'defaultindex' => 'plugin.php?id=xigua_hb',
  'holddomain' => 'www|*blog*|*space*|*bbs*',
  'list' => 
  array (
  ),
  'app' => 
  array (
    'portal' => '',
    'forum' => '',
    'group' => '',
    'home' => '',
    'default' => '',
  ),
  'root' => 
  array (
    'home' => '',
    'group' => '',
    'forum' => '',
    'topic' => '',
    'channel' => '',
  ),
);
?>