<?php


define('UC_CONNECT', 'mysql');

define('UC_DBHOST', 'localhost');
define('UC_DBUSER', 'xigua');
define('UC_DBPW', 'xigua123');
define('UC_DBNAME', 'xigua');
define('UC_DBCHARSET', 'utf8');
define('UC_DBTABLEPRE', '`xigua`.pre_ucenter_');
define('UC_DBCONNECT', 0);

define('UC_CHARSET', 'utf-8');
define('UC_KEY', 'H3lfFfzd86L3N2Z0ka4284N8k0q7q8ldv468U3pbb6b1Iee8b9Nbla0ej9DdYfJ8');
define('UC_API', 'http://127.0.0.1/xigua/uc_server');
define('UC_APPID', '1');
define('UC_IP', '');
define('UC_PPP', 20);
?>