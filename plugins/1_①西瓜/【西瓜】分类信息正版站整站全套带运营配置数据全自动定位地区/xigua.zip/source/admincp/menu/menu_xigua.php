<?php
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$lang1 = diconv('西瓜', 'UTF-8', CHARSET);
$lang2 = diconv('【西瓜】', 'UTF-8', CHARSET);

$topmenu[$lang1] = '';

loadcache('adminmenu');
foreach ($_G['cache']['adminmenu'] as $k => $v) {
    if(strpos($v['name'], $lang2) !== false ){
        unset($_G['cache']['adminmenu'][$k]);
        $menu[$lang1][] = array($v['name'], $v['action']);
    }
}

if(empty(  $menu[$lang1])){
    unset($topmenu[$lang1] );
}