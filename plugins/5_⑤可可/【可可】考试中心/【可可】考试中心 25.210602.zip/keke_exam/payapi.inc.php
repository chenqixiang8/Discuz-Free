<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

global $_G;
$keke_exam = $_G['cache']['plugin']['keke_exam'];
header("Content-type:text/html;charset=utf-8");
include_once DISCUZ_ROOT."source/plugin/keke_exam/function.php";
$title= CHARSET=='gbk' ? diconv(lang('plugin/keke_exam', '216'), CHARSET, 'UTF-8') : lang('plugin/keke_exam', '216');
$priceid=dhtmlspecialchars($_GET['priceid']);
$post_orderid=dhtmlspecialchars($_GET['orderid']);

if(!$_G['uid']){
	$msg=lang('plugin/keke_exam', '217');
	$msgs=kekeexam_gbk2utf($msg);
	if($zftype==1){
		exit( '<script>alert("'.$msgs.'");</script>');
	}else{
		exit( json_encode(array('err' =>$msgs)));
	}
}



$total_price=0;
if($post_orderid){
/*	$orderdata=C::t('#keke_video_base#keke_video_order')->fetchfirst_byid($post_orderid);
	if($orderdata['state']==1){
		showmessage(lang('plugin/keke_video_base', '030'), '', array(), array('alert' => 'error'));
	}
	$ordercids=explode(',',$orderdata['cid']);
	$courses=C::t('#keke_video_base#keke_video_course')->fetch_all_by_cids($ordercids);
	$orderid=$post_orderid;
	$total_price=$orderdata['price'];
	if($orderdata['revision']){
		if($_GET['zftype']==2){
			$orderid=$orderid.'_re'.random(2);
		}
	}
	
	if($_GET['deduction'] && $keke_video_base['deduction'] && $_GET['deductionnum']){
		$_GET['deductionnum']=intval(abs($_GET['deductionnum']));
		if(!discuz_process::islocked('getuidcount_checklocked', 60)) {
			$member = C::t('common_member_count')->fetch($_G['uid']);
			if($member['extcredits'.$keke_video_base['integraltype']]<$_GET['deductionnum']){
				$msg=kekevideo_gbk2utf($_G['setting']['extcredits'][$keke_video_base['integraltype']]['title'].lang('plugin/keke_video_base', '031'));
				discuz_process::unlock('getuidcount_checklocked');
				exit(json_encode(array('err' =>$msg)));
			}elseif($_GET['zftype']==1 && $_GET['cherckapi']){
				discuz_process::unlock('getuidcount_checklocked');
				exit( json_encode(array('err' =>0)));
			}
			$uptitle=lang('plugin/keke_video_base', '255').lang('plugin/keke_video_base', '258').$buytitlenames.lang('plugin/keke_video_base', '259').lang('plugin/keke_video_base', '257');
			updatemembercount($_G['uid'], array('extcredits'.$keke_video_base['integraltype']=>-$_GET['deductionnum']), true, '', 0, '',lang('plugin/keke_video_base', '032'),$uptitle);
			discuz_process::unlock('getuidcount_checklocked');
		}else{
			exit( json_encode(array('err' =>kekevideo_gbk2utf(lang('plugin/keke_video_base', '033')))));
		}
		$total_price-=intval(abs($_GET['deductionnum']))*$keke_video_base['proportion'];
		$deduction['money']=sprintf("%.2f",(intval(abs($_GET['deductionnum']))*$keke_video_base['proportion']));
		$deduction['info']=intval(abs($_GET['deductionnum'])).$dcreditname.lang('plugin/keke_video_base', '254').$deduction['money'].lang('plugin/keke_video_base', '047');
		
		$updateorderarr=array(
			'price'=>$total_price,
			'deduction'=>($deduction?serialize($deduction):''),
		);
		C::t('#keke_video_base#keke_video_order')->update($post_orderid,$updateorderarr);
		
	}elseif($_GET['zftype']==1 && $_GET['cherckapi']){
		exit( json_encode(array('err' =>0)));
	}
	
	if($total_price<=0){
		uporderstate($orderid,3);
		$_GET['zftype']=3;
	}
	if(K_INCMAG){
		$_GET['zftype']=5;
	}elseif(K_INQIANFAN){
		$_GET['zftype']=6;
	}*/
}elseif($priceid){
	$odids=array();
	$total_price=$k=0;
	$priceids=explode(',',$_GET['priceid']);
	$pricedata=C::t('#keke_exam#keke_exam_price')->fetch_all_byids($priceids);
	foreach($pricedata as $pk=>$pv){
		$arr_unit[$pv['uid']][]=$pv;
		if($pv['credit']){
			$member_credit[$pv['credit_type']]+=$pv['credit'];
		}
		$tt_price+=$pv['price'];
		if($pv['limit']){
			$buylimit[]=$pv['id'];
		}
	}
	
	if($buylimit){
		$buylog=C::t('#keke_exam#keke_exam_buylog')->count_all_byuidpid($_G['uid'],$buylimit);
		foreach($buylog as $buypid=>$buylogval){
			if($buylogval['count']>=$pricedata[$buypid]['limit']){
				$examdata=C::t('#keke_exam#keke_exam_paper')->fetchfirst_byid($pricedata[$buypid]['pid']);
				exit( json_encode(array('types'=>1,'pid'=>'','err' =>kekeexam_gbk2utf($examdata['title'].' <br> ['.$pricedata[$buypid]['title'].'] '.lang('plugin/keke_exam', '218').$pricedata[$buypid]['limit'].lang('plugin/keke_exam', '219')))));
			}
		}
	}
	
	if($_GET['deduction'] && $keke_exam['deduction'] && $_GET['deductionnum']){
		$member_credit[$keke_exam['integraltype']]+=intval(abs($_GET['deductionnum']));
	}
	
	$err=0;
	
	
	if(!discuz_process::islocked('getuidcount_checklocked', 60)) {
		$member = C::t('common_member_count')->fetch($_G['uid']);
		foreach($member_credit as $check_c_k =>$check_c_v){
			if($member['extcredits'.$check_c_k]<$check_c_v){
				$err=$check_c_k;
			}
		}
		
		if($err){
			$msg=kekeexam_gbk2utf($_G['setting']['extcredits'][$err]['title'].lang('plugin/keke_exam', '220'));
			discuz_process::unlock('getuidcount_checklocked');
			exit(json_encode(array('err' =>$msg,'state'=>4)));
		}
		
		if($_GET['zftype']==1 && $_GET['cherckapi']){
			discuz_process::unlock('getuidcount_checklocked');
			exit( json_encode(array('err' =>0)));
		}
		
		
		$examdatas=C::t('#keke_exam#keke_exam_paper')->fetchfirst_byid($pricedata[$priceids[0]]['pid']);
		$uptitle=lang('plugin/keke_exam', '221').lang('plugin/keke_exam', '222').$examdatas['title'].lang('plugin/keke_exam', '223').(count($priceids)>1?lang('plugin/keke_exam', '225'):'').lang('plugin/keke_video_base', '053');
		foreach($member_credit as $pay_c_k =>$pay_c_v){
			updatemembercount($_G['uid'], array('extcredits'.$pay_c_k=>-$pay_c_v), true, '', 0, '',lang('plugin/keke_exam', '224'),$uptitle);
		}
		
		discuz_process::unlock('getuidcount_checklocked');
	}else{
		exit( json_encode(array('err' =>kekeexam_gbk2utf(lang('plugin/keke_exam', '226')))));
	}
	
	
	
	$dcreditname=$_G['setting']['extcredits'][$keke_exam['integraltype']]['title'];
	C::t('#keke_exam#keke_exam_cart')->delete_by_uidandpid($_G['uid'],$pids);
	
	$appoint=unserialize($keke_video_base['appoint']);
	foreach($arr_unit as $uk=>$uv){
		$pidsa=array();
		$unit_price=0;
		$unitcredit=array();
		foreach($uv as $vv){
			$pidsa[]=$vv['id'];
			if($vv['credit']){
				$unitcredit[$vv['credit_type']]+=$vv['credit'];
			}
			if($vv['vip'] && $vv['vipprice']>0 && in_array($_G['groupid'],$appoint)){
				$isvipprice[$vv['id']]=$vv['price']=$vv['vipprice'];
			}
			$unit_price+=$vv['price'];
		}
		$unit_orderid=_orderid();
		$odids[]=$unit_orderid;
		
		if($_GET['deduction'] && $keke_video_base['deduction'] && $_GET['deductionnum']){
			$deduction['money']=sprintf("%.2f",(intval(abs($_GET['deductionnum']))*$keke_video_base['proportion'])/$tt_price*$unit_price);
			$deduction['info']=intval(abs($_GET['deductionnum'])).$dcreditname.lang('plugin/keke_video_base', '254').$deduction['money'].lang('plugin/keke_video_base', '047');
		}
		
		if($isvipprice){
			$deduction['vipprice']=$isvipprice;
		}
		
		_instorder($unit_orderid,$unit_price,$uk,implode(",",$pidsa),$unitcredit,$deduction);
		$total_price+=$unit_price;
	}
	if(count($arr_unit)>1){
		$orderid='ALL'._orderid();
		_instorder($orderid,$total_price,0,implode(",",$odids),$member_credit);
	}else{
		$orderid=$unit_orderid;
	}
	
	
	
	if($_GET['deduction'] && $keke_video_base['deduction'] && $_GET['deductionnum']){
		$total_price-=intval(abs($_GET['deductionnum']))*$keke_video_base['proportion'];
	}
	if($total_price<=0){
		uporderstate($orderid,3);
		$_GET['zftype']=3;
	}
	$total_price=round($total_price,2);
	if(K_INCMAG){
		$_GET['zftype']=5;
	}elseif(K_INQIANFAN){
		$_GET['zftype']=6;
	}
}




if($_GET['zftype']==1){
	include_once("source/plugin/keke_exam/paylib/alipay/alipay.config.php");
	include_once("source/plugin/keke_exam/paylib/alipay/alipay_submit.class.php");
	$show_url = $_G['siteurl']."plugin.php?id=keke_exam";
	$parameter = array(
		"service"       => $alipay_config['service'],
		"partner"       => $alipay_config['partner'],
		"seller_id"  => $alipay_config['seller_id'],
		"payment_type"	=> $alipay_config['payment_type'],
		"notify_url"	=> $alipay_config['notify_url'],
		"return_url"	=> $alipay_config['return_url'],
		"_input_charset"	=> trim(strtolower($alipay_config['input_charset'])),
		"out_trade_no"	=> $orderid,
		"subject"	=> $title,
		"total_fee"	=> $total_price,
		"show_url"	=> $show_url,
		"app_pay"   => "Y",
	);
	$alipaySubmit = new AlipaySubmit($alipay_config);
	$html_text = $alipaySubmit->buildRequestForm($parameter,"get", 'go-pay');
	echo $html_text;
}elseif($_GET['zftype']==2){
	if($_GET['inwxmini']){
		exit(json_encode(array('orderid' => $orderid)));
	}
	include_once DISCUZ_ROOT."source/plugin/keke_exam/inc.php";	
	$tools = new JsApiPay();
	$openIds = $_G['cookie'][$uskey];
	$openId=authcode($openIds, 'DECODE', $_G['config']['security']['authkey']);
	$notify = new NativePay();
	$input = new WxPayUnifiedOrder();
	$input->SetBody($title);
	$input->SetAttach($title);
	$input->SetOut_trade_no($orderid);
	$input->SetTotal_fee($total_price*100);
	$input->SetTime_start(date("YmdHis"));
	$input->SetGoods_tag($title);
	$input->SetNotify_url($_G['siteurl'].'source/plugin/keke_exam/paylib/notify_wx.inc.php');
	$input->SetTrade_type($s_type);

	if($iswx){
		$input->SetOpenid($openId);
		$order = WxPayApi::unifiedOrder($input);



		$jsApiParameters = $tools->GetJsApiParameters($order);
		try
        {
            $jsApiParameters = $tools->GetJsApiParameters($order);
        }catch (Exception $e){
            $jsApiParameters = json_encode(array('err' => $e->getMessage()));
            $jsApiParameters = diconv($jsApiParameters, 'utf-8');
        }
        echo $jsApiParameters;
        exit;
	}else{
		if(checkmobile() && 1){
			$h5pay=_h5pay($total_price*100,$orderid,$title);
			echo json_encode(array('h5payurl' => $h5pay['mweb_url'],'ewmurl' => '','orderid'=>$orderid));
		}else{
			$input->SetProduct_id($orderid);
			$result = $notify->GetPayUrl($input);
			$url2 = $result["code_url"];
			if($url2){
				$src = _getqrcodeurl($url2);
				if(strpos($orderid, '_re') !== false){
					$exporderid=explode('_re',$orderid);
					$orderid=$exporderid[0];
				}
				echo json_encode(array('ewmurl' => $src,'orderid'=>$orderid));
			}else{
				$err = $result['return_msg'];
				echo json_encode(array('err' => $err));
			}
		}
	}
}elseif($_GET['zftype']==3){
	exit(json_encode(array('err' => 0,'ewmurl'=>1,'orderid'=>$orderid)));
}elseif($_GET['zftype']==5){
	$magreturn=_magpaytrade($orderid,$total_price,$title);
	exit(json_encode($magreturn));
}elseif($_GET['zftype']==6){
	$return=array(
		'title'=>$title,
		'orderid'=>$orderid,
		'total_price'=>$total_price
	);
	exit(json_encode($return)); //d'.'is'.'m.tao'.'ba'.'o.com
}