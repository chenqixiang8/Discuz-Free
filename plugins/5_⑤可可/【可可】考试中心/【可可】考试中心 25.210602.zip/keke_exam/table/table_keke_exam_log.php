<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_keke_exam_log extends discuz_table {

	public function __construct() {
		$this->_table = 'keke_exam_log';
		$this->_pk    = 'id';

		parent::__construct(); //d'.'i'.'sm.ta'.'o'.'bao.com
	}
	
	
	public function fetchfirst_byid($cid) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d", array($this->_table,$cid));
	}
	
	
	public function fetch_alls($startlimit,$ppp,$where='',$order='') {
		$where=$where?$where:1;
		$orders=$order?$order:'order by id desc';
		$return= DB::fetch_all("SELECT * FROM %t WHERE %i %i LIMIT %d,%d", array($this->_table,$where,$orders,$startlimit,$ppp), $this->_pk);
		foreach($return as $key=>$val){
			$return[$key]['times']=dgmdate($val['start'], 'Y-m-d H:i:s');
			$return[$key]['endtimes']=dgmdate($val['end'], 'Y-m-d H:i:s');
		}
		return $return;
	}
	
	
	public function count_all($where='') {
		$where=$where?$where:1;
		return DB::result_first("SELECT count(*) FROM %t WHERE %i", array($this->_table,$where));
	}
	
	public function fetch_first_bywhere($where='') {
		$where=$where?$where:1;
		return DB::fetch_first("SELECT * FROM %t WHERE %i", array($this->_table,$where));
	}

	public function fetch_all_by_pids($pids) {
		return $query=DB::fetch_all("SELECT * FROM %t WHERE id in (%n)", array($this->_table,$pids), $this->_pk);
		
	}
	
	public function handinpapers() {
		return DB::query("UPDATE ".DB::table($this->_table)." SET `state` = 1 WHERE `end`>0 AND `end`<='".TIMESTAMP."'");
	}
	
	
}

?>