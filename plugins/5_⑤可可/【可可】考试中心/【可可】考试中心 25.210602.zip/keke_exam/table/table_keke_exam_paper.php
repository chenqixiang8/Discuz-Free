<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_keke_exam_paper extends discuz_table {

	public function __construct() {
		$this->_table = 'keke_exam_paper';
		$this->_pk    = 'id';

		parent::__construct(); //d'.'i'.'sm.ta'.'o'.'bao.com
	}
	
	
	public function fetchfirst_byid($pid) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d", array($this->_table,$pid));
	}
	

	
	public function fetch_alls($startlimit,$ppp,$where='',$order='') {
		$where=$where?$where:1;
		$orders=$order?$order:'order by time desc';
		$return= DB::fetch_all("SELECT * FROM %t WHERE %i %i LIMIT %d,%d", array($this->_table,$where,$orders,$startlimit,$ppp), $this->_pk);
		foreach($return as $key=>$val){
			$return[$key]['times']=dgmdate($val['time'], 'Y-m-d H:i:s');
		}
		return $return;
	}
	
	
	public function count_all($where='') {
		$where=$where?$where:1;
		return DB::result_first("SELECT count(*) FROM %t WHERE %i", array($this->_table,$where));
	}
	


	public function fetch_all_by_pids($pids) {
		return $query=DB::fetch_all("SELECT * FROM %t WHERE id in (%n)", array($this->_table,$pids), $this->_pk);
		
	}
	
	public function fetch_by_new($par,$num) {
		$where=$par?'':1;
		return DB::fetch_all("SELECT * FROM %t WHERE subcate in (%n) AND state=1 ORDER BY displayorder DESC,id DESC LIMIT 0,%d", array($this->_table,$par,$num));
	}
	
	public function del_by_qids($ids,$uid) {
		return DB::delete($this->_table, "id in (".$ids.") AND uid=".$uid);
	}
	public function sum_by_cate($cates) {
		return DB::fetch_all("SELECT sum(total) as sum,cate FROM %t WHERE cate in (%n) group by cate", array($this->_table,$cates),'cate');
	}
	
	
	
	
}

?>