<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_keke_exam_teachergroup extends discuz_table {

	public function __construct() {
		$this->_table = 'keke_exam_teachergroup';
		$this->_pk    = 'id';

		parent::__construct(); //d'.'i'.'sm.ta'.'o'.'bao.com
	}
	
	
	public function fetchfirst_byid($oid) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d", array($this->_table,$oid));
	}
	
	public function fetchfirst_bydefault() {
		return DB::fetch_first("SELECT * FROM %t WHERE defaults=%d", array($this->_table,1));
	}
	
	
	public function fetch_all_by_ids($ids) {
		return DB::fetch_all("SELECT * FROM %t WHERE id in (%n)", array($this->_table,$ids), $this->_pk);
		
	}
	
	public function fetch_alls() {
		return DB::fetch_all("SELECT * FROM %t", array($this->_table), $this->_pk);
		
	}
	
	public function update_all($set='') {
		return DB::query("UPDATE %t SET %i", array($this->_table,$set));
	}
	
	
	public function fetch_all_teacher($startlimit=0,$ppp=200,$where='',$order='') {
		$where=$where?$where:1;
		$orders=$order?$order:'order by time desc';
		return DB::fetch_all("SELECT * FROM %t WHERE %i %i LIMIT %d,%d", array($this->_table,$where,$orders,$startlimit,$ppp),$this->_pk);
	}
	
	
	public function count_all($where='') {
		$where=$where?$where:1;
		return DB::result_first("SELECT count(*) FROM %t WHERE %i", array($this->_table,$where));
	}
	
	
}

?>