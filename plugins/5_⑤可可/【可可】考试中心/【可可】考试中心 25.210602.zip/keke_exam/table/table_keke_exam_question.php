<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_keke_exam_question extends discuz_table {
	public function __construct() {
		$this->_table = 'keke_exam_question';
		$this->_pk    = 'id';

		parent::__construct(); //d'.'i'.'sm.ta'.'o'.'bao.com
	}
	public function fetchfirst_byid($qid) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d", array($this->_table,$qid));
	}
	public function fetch_alls($startlimit,$ppp,$where='',$order='') {
		$where=$where?$where:1;
		$orders=$order?$order:'order by time desc';
		$return= DB::fetch_all("SELECT * FROM %t WHERE %i %i LIMIT %d,%d", array($this->_table,$where,$orders,$startlimit,$ppp), $this->_pk);
		foreach($return as $key=>$val){
			$return[$key]['times']=dgmdate($val['time'], 'Y-m-d H:i:s');
		}
		return $return;
	}
	public function count_all($where='') {
		$where=$where?$where:1;
		return DB::result_first("SELECT count(*) FROM %t WHERE %i", array($this->_table,$where));
	}

    public function countsub_by_qids($qids) {
        return DB::fetch_all("SELECT `from`,count(*) as count FROM %t WHERE `from` in (%n) group by `from`", array($this->_table,$qids),'from');
    }
	public function fetch_all_by_qids($qids) {
		return $query=DB::fetch_all("SELECT * FROM %t WHERE id in (%n)", array($this->_table,$qids), $this->_pk);
	}


    public function fetch_all_by_fromqids($qids) {
        $query=DB::fetch_all("SELECT * FROM %t WHERE `from` in (%n)", array($this->_table,$qids), $this->_pk);
        foreach ($query as $val){
            $return[$val['from']][$val['id']]=$val;
            $allQids[]=$val['id'];
        }
        return [$return,$allQids];
    }

	public function fetch_all_by_titles($titles) {
		global $_G;
		return $query=DB::fetch_all("SELECT id,title FROM %t WHERE title in (%n) AND uid=%d", array($this->_table,$titles,$_G['uid']), $this->_pk);
	}
	public function del_by_qids($qids,$uid) {
		return DB::delete($this->_table, "id in (".$qids.") AND uid=".$uid);
	}
}

?>