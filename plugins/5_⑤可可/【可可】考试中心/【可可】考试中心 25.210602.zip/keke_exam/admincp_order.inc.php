<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
	loadcache('plugin'); //d'.'is'.'m.ta'.'obao.com
	include_once DISCUZ_ROOT."source/plugin/keke_exam/function.php";
	
	if($_GET['ac']=='replenish'){
		$orderid=dhtmlspecialchars($_GET['orderid']);
		$orderdata=C::t('#keke_exam#keke_exam_order')->fetchfirst_byid($orderid);
		if (submitcheck("submit_replenish")) {
			if($orderdata['state']){
				cpmsg(lang('plugin/keke_exam', '019'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_exam&pmod=admincp_order&page='.intval($_GET['page']), 'error');
			}
			uporderstate($orderid,6,$_GET['sn'].' '.lang('plugin/keke_exam', '170'));
			cpmsg(lang('plugin/keke_exam', '020'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_exam&pmod=admincp_order&page='.intval($_GET['page']), 'succeed');
		}
		showtableheader(lang('plugin/keke_exam', '021'));
		showformheader('plugins&operation=config&do='.$pluginid.'&pmod=keke_exam&pmod=admincp_order&ac=replenish', 'testhd');
		showtablerow('', array('width="70"'),
			array(
				'<b>'.lang('plugin/keke_exam', '022').'</b>',
				'<a href="home.php?mod=space&uid='.$orderdata['uid'].'" target="_blank">'.$orderdata['username'].'</a>'
			)
		);
		showtablerow('', array('width="70"'),
			array(
				'<b>'.lang('plugin/keke_exam', '023').'</b>',
				$orderdata['id']
			)
		);
		if($orderdata['credit']){
			$credit=unserialize($orderdata['credit']);
			$n=0;
			foreach($credit as $credit_type=>$credit_num){
				$creditnum.=($n==0 && $val['price']<=0?'':'<b>/</b>').$credit_num.' '.$_G['setting']['extcredits'][$credit_type]['title'];
				$n++;
			}
			$creditnum=' + '.$creditnum;
		}
		showtablerow('', array('width="70"'),
			array(
				'<b>'.lang('plugin/keke_exam', '024').'</b>',
				($orderdata['price']>0?'&yen; '.$orderdata['price'].($orderdata['revision']?'<span class="revision"> '.lang('plugin/keke_exam', '017').' </span>':''):'').$creditnum
			)
		);
		showtablerow('', array('width="70"'),
			array(
				'<b>'.lang('plugin/keke_exam', '025').'</b>',
				date('Y-m-d H:i:s',$orderdata['time'])
			)
		);
		showsubtitle(array(''));
		showsetting(lang('plugin/keke_exam', '026'),'sn','','text','','',lang('plugin/keke_exam', '027'));
		echo '<input name="orderid" type="hidden" value="'.$orderid.'" />';
		showsubmit('submit_replenish', 'submit', '');
		showtablefooter(); //From: Dism��taobao��com
		showformfooter(); //From: Dism_taobao_com
		exit();
	}
	if (submitcheck("forumset")) {
		if(is_array($_GET['delete'])) {
			if($_GET['optype'] == 'delete') {
				C::t('#keke_exam#keke_exam_order')->delete($_GET['delete']);
			}
		}else{
			cpmsg(lang('plugin/keke_exam', '028'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_exam&pmod=admincp_order', 'error');
		}
		
		if(!$_GET['optype']){
			cpmsg(lang('plugin/keke_exam', '029'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_exam&pmod=admincp_order', 'error');
		}
		cpmsg(lang('plugin/keke_exam', '030'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_exam&pmod=admincp_order&page='.$_GET['page'], 'succeed');
	}
	
	
	$where="id NOT LIKE '%ALL%'";$param='';
	if($_GET['orderid']){
		$where="id='".daddslashes(dhtmlspecialchars($_GET['orderid'])).'\'';
		$param.='&orderid='.dhtmlspecialchars($_GET['orderid']);
	}
	if($_GET['state']){
		if($_GET['state']==9)$_GET['state']=0;
		$where.=" AND state=".intval($_GET['state']);
		$param.='&state='.intval($_GET['state']);
	}
	if($_GET['teacherid']){
		$where.=" AND teacher_uid=".intval($_GET['teacherid']);
		$param.='&teacherid='.intval($_GET['teacherid']);
	}
	if($_GET['byuid']){
		$where.=" AND uid=".intval($_GET['byuid']);
		$param.='&byuid='.intval($_GET['byuid']);
	}
	if($_GET['time']){
		$where.=" AND time>".strtotime($_GET['time']);
		$param.='&time='.dhtmlspecialchars($_GET['time']);
	}
	if($_GET['endtime']){
		$where.=" AND time<".strtotime($_GET['endtime']);
		$param.='&endtime='.dhtmlspecialchars($_GET['endtime']);
	}
	if($_GET['types']){
		$where.=" AND price>0";
		$param.='&types='.intval($_GET['types']);
	}
	if($_GET['pagenum']){
		$param.='&pagenum='.intval($_GET['pagenum']);
	}
	
	$ppp=$_GET['pagenum']?intval($_GET['pagenum']):20;
	$tmpurl=ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_exam&pmod=admincp_order'.$param;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	showtableheader(lang('plugin/keke_exam', '018'));
	showformheader('plugins&operation=config&do='.$pluginid.'&pmod=keke_exam&pmod=admincp_order', 'testhd');
	showtablerow('', array(),
		array(
			'<select name="state"><option value="0">'.lang('plugin/keke_exam', '031').'</option><option value="1" '.($_GET['state']==1?'selected':'').'>'.lang('plugin/keke_exam', '032').'</option><option value="9" '.($_GET['state']==9?'selected':'').'>'.lang('plugin/keke_exam', '033').'</option><option value="3" '.($_GET['state']==3?'selected':'').'>'.lang('plugin/keke_exam', '034').'</option></select>
			<input name="orderid" value="'.dhtmlspecialchars($_GET['orderid']).'" type="text" placeholder="'.lang('plugin/keke_exam', '035').'" />
			<input name="byuid" type="text" value="'.($_GET['byuid']?intval($_GET['byuid']):'').'" size="10" placeholder="'.lang('plugin/keke_exam', '036').'UID" />
			<input name="teacherid" type="text" size="10" value="'.($_GET['teacherid']?intval($_GET['teacherid']):'').'" placeholder="'.lang('plugin/keke_exam', '037').'UID"/>
			<input name="time" type="text" value="'.dhtmlspecialchars($_GET['time']).'" onclick="showcalendar(event, this)" size="15" placeholder="'.lang('plugin/keke_exam', '038').'"/> - <input name="endtime" type="text" onclick="showcalendar(event, this)" size="15" value="'.dhtmlspecialchars($_GET['endtime']).'" placeholder="'.lang('plugin/keke_exam', '039').'"/>
			<select name="types"><option value="0">'.lang('plugin/keke_exam', '040').'</option><option value="1" '.($_GET['types']==1?'selected':'').'>'.lang('plugin/keke_exam', '041').'</option></select>
			<select name="pagenum"><option value="20" '.($_GET['pagenum']==20?'selected':'').'>20</option><option value="50" '.($_GET['pagenum']==50?'selected':'').'>50</option><option value="100" '.($_GET['pagenum']==100?'selected':'').'>100</option><option value="500" '.($_GET['pagenum']==500?'selected':'').'>500</option><option value="1000" '.($_GET['pagenum']==1000?'selected':'').'>1000</option></select>
			<input type="submit" class="btn" id="submit_searchsubmit" name="searchsubmit" value="'.lang('plugin/keke_exam', '042').'"><input name="inajax" type="hidden" value="1" /><script src="static/js/calendar.js"></script>'
		)
    );
	showformfooter(); //From: Dism_taobao_com
	showtablefooter(); //From: Dism��taobao��com
	showformheader("plugins&operation=config&do=".$plugin["pluginid"]."&identifier=" . $plugin["identifier"] . "&pmod=admincp_order");	
	showtableheader(lang('plugin/keke_exam', '043'));
    showsubtitle(array('del',lang('plugin/keke_exam', '044'), lang('plugin/keke_exam', '045'),lang('plugin/keke_exam', '046'),lang('plugin/keke_exam', '047'),lang('plugin/keke_exam', '048'),lang('plugin/keke_exam', '049'),lang('plugin/keke_exam', '050'),lang('plugin/keke_exam', '051')));
	
	$count_all=C::t('#keke_exam#keke_exam_order')->count_all($where);
	if($count_all){
		$order_data=C::t('#keke_exam#keke_exam_order')->fetch_all_order($startlimit,$ppp,$where,$order);
		foreach($order_data as $key=>$val){
			$state=$val['state']==1?'<img src="source/plugin/keke_exam/template/images/ico016.png" width="11" height="11" />'.lang('plugin/keke_exam', '052'):($val['state']==0?'<img src="source/plugin/keke_exam/template/images/ico017.png" width="11" height="11" />'.lang('plugin/keke_exam', '033'):'<img src="source/plugin/keke_exam/template/images/ico011.png" width="11" height="11" />'.lang('plugin/keke_exam', '034'));
			$exam=$creditnum=$creditnums=$deductiontxt='';
			$pids=array();
			$pids=explode(',',$val['pid']);
			
			$pricedata=C::t('#keke_exam#keke_exam_price')->fetch_all_byids($pids);
			foreach($pricedata as $priceval){
				$paperids[$priceval['pid']]=$priceval['pid'];
			}
			$examdata=C::t('#keke_exam#keke_exam_paper')->fetch_all_by_pids($paperids);
			
			$num=1;$exam='';
			foreach($pricedata as $ck=>$cv){
				$exam.='<a href="plugin.php?id=keke_exam&ac=exam&pid='.$cv['pid'].'" target="_blank">[ '.$examdata[$cv['pid']]['title'].' ]</a><div class="decs">'.($cv['title']?$cv['title']:($cv['total']?lang('plugin/keke_exam', '053').$cv['total'].lang('plugin/keke_exam', '054'):lang('plugin/keke_exam', '055'))).'</div><br/>';
				$num++;
			}
			
			if($val['credit']){
				$credit=unserialize($val['credit']);
				$n=0;
				foreach($credit as $credit_type=>$credit_num){
					$creditnum.=($n==0 && $val['price']<=0?'':'<b>/</b>').$credit_num.' '.$_G['setting']['extcredits'][$credit_type]['title'];
					$creditnums.=($n==0 && $val['price']<=0?'':(intval($credit_num*$val['take']/100)?'<b>/</b>':'')).(intval($credit_num*$val['take']/100)?intval($credit_num*$val['take']/100).' '.$_G['setting']['extcredits'][$credit_type]['title']:'');
					$n++;
				}
			}
			$table = array(); //From: Dism_taobao-com
			$table[0] = '<input type="checkbox" class="checkbox" name="delete[]" value="'.$val['id'].'" />';
			$table[1] = '<div class="payusername"><a href="home.php?mod=space&uid='.$val['uid'].'" target="_blank">'.$val['username'].'</a></div>'.$val['id'];
			$table[2] = '<div class="pricebox">'.($val['price']>0?'&yen; '.$val['price'].($val['revision']?'<span class="revision">'.lang('plugin/keke_exam', '017').'</span>':''):'').$creditnum.'</div>';
			$table[3] = '<div class="exam">'.$exam.'</div>';
			$table[4] = '<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_exam&pmod=admincp_order&teacherid='.$val['teacher_uid'].'">'._getusname($val['teacher_uid']).'</a>';
			$table[5] = ($val['state']==1)?'<div class="pricebox">'.(number_format($val['price']*$val['take']/100,2)>0?'&yen; '.number_format($val['price']*$val['take']/100,2):'').$creditnums.'</div>':'-';
			$table[6] = '<div class="states">'.$state.'</div>'.($val['sn']?'<span class="snbox">'.$val['sn'].'</span>':'');
			$table[7] = dgmdate($val['time'], 'Y/m/d H:i');
			
			$table[8] = ($val['state']==0)?'<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_exam&pmod=admincp_order&ac=replenish&orderid='.$val['id'].'&page='.intval($_GET['page']).'">'.lang('plugin/keke_exam', '021').'</a>':'-';
			showtablerow('',array(''), $table);
		}
		$multipage = multi($count_all, $ppp, $page, $_G['siteurl'].$tmpurl);
	}
	if($multipage)echo '<tr class="hover"><td colspan="9">'.$multipage.'</td></tr>';
	echo '<input type="hidden" name="page" value="'.intval($_GET['page']).'"><style>.states img{vertical-align:middle; margin-right:7px;}.decs{ color:#999; margin:0px; line-height:20px;}.exam a{ color:#666; margin:7px 10px 10px 0; line-height:28px;}.pricebox{ color:#c30; margin:7px 10px 0px 0; line-height:20px;}.pricebox b{ color:#CCC; margin:0 5px; font-weight:400}.revision{ margin:0 5px; background:#ff5959;display:inline-block; color:#FFF;padding:0px 2px;font-size:12px; line-height: 16px;}.deduction{line-height: 23px; margin-top: 2px;color: #666;margin-bottom: 10px;display: inline-block;}.snbox{ margin-top: 8px;color: #999;margin-bottom: 10px;display: inline-block;}.payusername{ margin-bottom: 5px;}.numbox{border: 1px solid #ababab;background: #fff;color: #585858;padding: 0 2px;}.modtip{    background: #fff;font-size: 12px !important;margin: 0px;border: 1px solid #ff7272;display: inline-block;color: #ff7272;height: 15px;line-height: 15px;padding: 0 5px;}</style>';
	showsubmit('forumset', 'submit', '<input type="checkbox" name="chkall" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')"><label for="chkallIuPN">'.lang('plugin/keke_exam', '058').'</label>&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="optype" id="delete" value="delete" class="radio" /><label for="delete" class="vmiddle">'.lang('plugin/keke_exam', '056').'</label>&nbsp;&nbsp;','');
    showtablefooter(); //From: Dism��taobao��com
	showformfooter(); //From: Dism_taobao_com