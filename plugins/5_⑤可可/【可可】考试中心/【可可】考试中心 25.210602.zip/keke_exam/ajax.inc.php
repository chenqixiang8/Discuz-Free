<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $_G;
$keke_exam = $_G['cache']['plugin']['keke_exam'];
require_once DISCUZ_ROOT.'./source/plugin/keke_exam/function.php';
if($_GET['formhash'] != $_G['formhash']) {
    exit('Formhash_Error');
}
if($_GET['ac']=='updatapic') {
    $width = $_GET['width'] ? intval($_GET['width']) : '';
    $hight = $_GET['hight'] ? intval($_GET['hight']) : '';
    $pic['url'] = _exam_upload_img($_FILES['imgFile'], $width, $hight);
    $pic['error'] = 0;
    header('Content-type: text/html');
    exit(json_encode($pic));
}elseif($_GET['ac']=='excelimport'){
    $file['url']=_exam_upload_file($_FILES['file'],50240,array('xls','xlsx'));
    $num=excelImports($file['url']);
    exit(json_encode(array('err'=>0,'msg'=>$num)));
}elseif($_GET['ac']=='teacher'){
	$teacherarr=array(
		'uid'=>$_G['uid'],
		'username'=>kekexam_utf2gbk($_GET['nickname']),
		'name'=>kekexam_utf2gbk($_GET['name']),
		'img'=>$_GET['coveimg'],
		'profile'=>kekexam_utf2gbk($_GET['profile']),
		'rank'=>kekexam_utf2gbk($_GET['rank']),
		'wechatqrcode'=>$_GET['wechatqrcode'],
		'wechat'=>kekexam_utf2gbk($_GET['wechat']),
	);
	foreach($teacherarr as $k=>$v){
		$teacherarr[$k]=dhtmlspecialchars($v);
	}
	$teacherarr['info']=kekexam_utf2gbk($_GET['info']);
	$id=C::t('#keke_exam#keke_exam_teacher')->update($_G['uid'],$teacherarr);
	exit(json_encode(array('state'=>0)));
}elseif($_GET['ac']=='checkgopay'){
	$_GET['pid']=dhtmlspecialchars($_GET['pid']);
	$pricedata=C::t('#keke_exam#keke_exam_price')->fetch_all_byids($_GET['pid']);
	foreach($pricedata as $pk=>$pv){
		if($pv['limit']){
			$buylimit[]=$pv['id'];
		}
	}
	if($buylimit){
		$buylog=C::t('#keke_exam#keke_exam_buylog')->count_all_byuidpid($_G['uid'],$buylimit);
		foreach($buylog as $buypid=>$buylogval){
			if($buylogval['count']>=$pricedata[$buypid]['limit']){
				$inconformity[]=$buypid;
			}
		}
		if($inconformity){
			foreach($_GET['pid'] as $pids){
				$pidarr[$pids]=$pids;
			}
			foreach($inconformity as $iv){
				unset($pidarr[$iv]);
			}
			if(count($pidarr)>1){
				exit(json_encode(array('state'=>1,'pids'=>implode(',',$pidarr))));
			}else{
				exit(json_encode(array('state'=>2)));
			}
		}else{
			exit(json_encode(array('state'=>0,'pids'=>implode(',',$_GET['pid']))));
		}
	}else{
		exit(json_encode(array('state'=>0,'pids'=>implode(',',$_GET['pid']))));
	}
		
}elseif($_GET['ac']=='addquestion'){
	$_GET['type']=intval($_GET['type']);
	if($_GET['op']){
		$info=kekexam_utf2gbk($_GET['info']);
		if(!$info){
			if($_GET['view']==1){
				exit('noinfo');
			}else{
				exit(json_encode(array('state'=>1,'msg'=>kekeexam_gbk2utf(lang('plugin/keke_exam', '178')))));
			}
		}
		$info=strip_tags($info, "<img><u>");
		$con=array_filter(explode("/hhf/",str_replace(array("\r\n", "\n", "\r"), '/hhf/',$info)));
        $con=array_values($con);
		$n=0;
		foreach($con as $key=>$val){
			$val=preg_replace('/^(&nbsp;|\s)*|(&nbsp;|\s)*$/', '', $val);
			if(preg_match("/^(\d+)\./",$val)){
				$question[$n]['title']=preg_replace('/^(\d+)\./','',$val);
				$titlearr[]=$question[$n]['title'];
			}
			if(strpos($val, lang('plugin/keke_exam', '179')) !== false || strpos($val, lang('plugin/keke_exam', '258')) !== false){
                $separator=(strpos($val, lang('plugin/keke_exam', '179')) !== false)?lang('plugin/keke_exam', '179'):lang('plugin/keke_exam', '258');
				$answer=explode($separator,$val);
				$question[$n]['answer']=preg_replace("/(\s|\&nbsp\;|".lang('plugin/keke_exam', '235')."|\xc2\xa0)/","",$answer[1]);
			}
			if(preg_match("/^[A-Z]\./i",$val)){
				$question[$n]['option'][]=preg_replace("/^[A-Z]\./i",'',$val);
			}
			if(strpos($val, lang('plugin/keke_exam', '180')) !== false || strpos($val, lang('plugin/keke_exam', '259')) !== false){
                $separators=(strpos($val, lang('plugin/keke_exam', '180')) !== false)?lang('plugin/keke_exam', '180'):lang('plugin/keke_exam', '259');
				$explain=explode($separators,$val);
				$question[$n]['explain']=preg_replace("/(\s|\&nbsp\;|".lang('plugin/keke_exam', '235')."|\xc2\xa0)/","",$explain[1]);
				$k[$n]=$key;
			}
			if(strpos($val, lang('plugin/keke_exam', '181')) !== false || strpos($val, lang('plugin/keke_exam', '260')) !== false){
                if($key-$k[$n]>1){
                    for ($i=($k[$n]+1);$i<$key;$i++){
                        $question[$n]['explain'].="<br/>".$con[$i];
                    }
                }
                $separatora=(strpos($val, lang('plugin/keke_exam', '181')) !== false)?lang('plugin/keke_exam', '181'):lang('plugin/keke_exam', '260');
				$difficulty=explode($separatora,$val);
				$question[$n]['difficulty']=($difficulty[1]==lang('plugin/keke_exam','182'))?1:($difficulty[1]==lang('plugin/keke_exam','183')?2:3);
				$n++;
			}
		}
		$checktitle=C::t('#keke_exam#keke_exam_question')->fetch_all_by_titles($titlearr);
		foreach($checktitle as $checkval){
			if(!(in_array($checkval['title'],$checktitles))){
				$checktitles[]=$checkval['title'];
			}
		}
		$optarr=range('A','Z');
		$splitoptarr=array_flip($optarr);
		$i=0;
		foreach($question as $k=>$v){
			if($v['option']){
				$q=array();
				foreach($v['option'] as  $ok=>$ov){
					$q[$ok+1]=$ov;
				}
				$option=$q;
			}
			$type=3;
			$answerstr=preg_replace("/(\s|\&nbsp\;|".lang('plugin/keke_exam', '235')."|\xc2\xa0)/","",$v['answer']);
			$answerarr=array();
			if($answerstr==lang('plugin/keke_exam', '184') || $answerstr==lang('plugin/keke_exam', '185')){
				$type=4;
				$answerarr[]=($answerstr==lang('plugin/keke_exam', '184'))?1:2;
			}elseif(preg_match("/^[A-Z\s]+$/",$v['answer'])){
				if(strlen($answerstr)==1){
					$type=1;
					$answerarr[]=$splitoptarr[$answerstr]+1;
				}else{
					$type=2;
					$ansarrs=str_split($answerstr);
					foreach($ansarrs as $ak=>$av){
						$answerarr[]=$splitoptarr[$av]+1;
					}
				}
			}elseif(strpos($v['title'], "<u>&nbsp;") !== false || strpos($v['title'], "()") !== false || strpos($v['title'], lang('plugin/keke_exam', '234')) !== false){
				$type=5;
				$ansarrs=explode('|',$answerstr);
				$d=1;
				foreach($ansarrs as $ak=>$av){
					$answerarr[$d]=$av;
					$d++;
				}
			}else{
				$answerarr[]=$answerstr;
			}
			$questions[$k]['title']=$v['title'];
			$questions[$k]['type']=$type;
			$questions[$k]['cate']=intval($_GET['cateid']);
			$questions[$k]['uid']=intval($_G['uid']);
			$questions[$k]['difficulty']=$v['difficulty'];
			$questions[$k]['explain']=$v['explain'];
			$dataval=array(
				'option'=>$option,
				'answer'=>$answerarr,
			);
			$questions[$k]['data']=serialize($dataval);
			$questions[$k]['time']=TIMESTAMP;
			if(!$_GET['view'] && !(in_array($v['title'],$checktitles))){
				C::t('#keke_exam#keke_exam_question')->insert($questions[$k], false,true);
				$i++;
			}
		}
		if($_GET['view']==1){
            $preview='';
			foreach($questions as $qsk=>$qss){
				$questions[$qsk]['data']=unserialize($qss['data']);
				if(in_array($qss['title'],$checktitles)){
					$questions[$qsk]['repeat']=1;
				}
			}
			$xx=array('','A','B','C','D','E','F','G');
			include template('keke_exam:block');
			exit($preview);
		}else{
			exit(json_encode(array('state'=>1,'msg'=>kekeexam_gbk2utf(lang('plugin/keke_exam', '186').$i.lang('plugin/keke_exam', '187')))));
		}
	}else{
		if(!$_GET['title']){
			exit(json_encode(array('state'=>1,'msg'=>kekeexam_gbk2utf(lang('plugin/keke_exam', '001')))));
		}
		if($_GET['type']==5){
			$_GET['answer']=$_GET['choices'];
			$_GET['choices']=array();
		}
		$val=array(
			'option'=>datatoarr($_GET['choices']),
			'answer'=>datatoarr($_GET['answer'])
		);
		if(($_GET['type']==1 || $_GET['type']==2) && empty($val['option'])){
			exit(json_encode(array('state'=>1,'msg'=>kekeexam_gbk2utf(lang('plugin/keke_exam', '188')))));
		}
		if(empty($val['answer']) && $_GET['type']!=6){
			exit(json_encode(array('state'=>1,'msg'=>kekeexam_gbk2utf(lang('plugin/keke_exam', '189')))));
		}
		$addarr=array(
			'type'=>$_GET['type'],
			'cate'=>$_GET['cateid'],
			'title'=>kekexam_utf2gbk($_GET['title']),
			'uid'=>$_G['uid'],
			'difficulty'=>$_GET['difficulty'],
			'explain'=>kekexam_utf2gbk($_GET['explain']),
			'data'=>serialize($val),
			'time'=>TIMESTAMP,
            'from'=>$_GET['from']
		);
		if($_GET['qid']){
            $returnid=intval($_GET['qid']);
            C::t('#keke_exam#keke_exam_question')->update($returnid,$addarr);
		}else{
            $returnid=C::t('#keke_exam#keke_exam_question')->insert($addarr, true);
        }
	}
	exit(json_encode(array('state'=>0,'qid'=>$returnid)));
}elseif($_GET['ac']=='delquestion'){
	$questionid=intval($_GET['questionid']);
	$questiondata=C::t('#keke_exam#keke_exam_question')->fetchfirst_byid($questionid);
	if($questiondata['uid']!=$_G['uid']){
		exit(json_encode(array('state'=>1,'msg'=>kekeexam_gbk2utf(lang('plugin/keke_exam', '002')))));
	}
	C::t('#keke_exam#keke_exam_question')->delete($questionid);
	exit(json_encode(array('state'=>0)));
}elseif($_GET['ac']=='addcart'){
	if(!$_G['uid']){
		exit(json_encode(array('state'=>2,'msg'=>'Please login')));
	}
	$preditid=intval($_GET['preditid']);
	$cart_arr=C::t('#keke_exam#keke_exam_cart')->fetchfirst_bypid($preditid,$_G['uid']);
	if(!$cart_arr){
		$arr=array(
			'pid'=>$preditid,
			'uid'=>$_G['uid'],
		);
		C::t('#keke_exam_base#keke_exam_cart')->insert($arr);
	}else{
		exit(json_encode(array('state'=>1,'msg'=>kekeexam_gbk2utf(lang('plugin/keke_exam', '190')))));
	}
	exit(json_encode(array('state'=>0)));
}elseif($_GET['ac']=='delcart'){
	$cartarr=C::t('#keke_exam#keke_exam_cart')->fetchfirst_byid($_GET['cartid']);
	if($cartarr['uid']!=$_G['uid']){
		exit(json_encode(array('state'=>1,'msg'=>kekeexam_gbk2utf(lang('plugin/keke_exam', '015')))));
	}
	C::t('#keke_exam#keke_exam_cart')->delete($_GET['cartid']);
	exit(json_encode(array('state'=>0)));
}elseif($_GET['ac']=='delfollow'){
	$followarr=C::t('#keke_exam#keke_exam_follow')->fetchfirst_byid($_GET['followid']);
	if($followarr['uid']!=$_G['uid']){
		exit(json_encode(array('state'=>1,'msg'=>kekeexam_gbk2utf(lang('plugin/keke_exam', '015')))));
	}
	C::t('#keke_exam#keke_exam_follow')->delete($_GET['followid']);
	exit(json_encode(array('state'=>0)));
}elseif($_GET['ac']=='delwrong'){
    if($_GET['qid']){
        $wrongarr=C::t('#keke_exam#keke_exam_wrong')->fetch_first_by_qidanduid($_GET['qid'],$_G['uid']);
        if($wrongarr['uid']!=$_G['uid']){
            exit(json_encode(array('state'=>1,'msg'=>kekeexam_gbk2utf(lang('plugin/keke_exam', '015')))));
        }
        $delWrongId=$wrongarr['id'];
    }else{
        $wrongarr=C::t('#keke_exam#keke_exam_wrong')->fetchall_byuids($_G['uid']);
        foreach ($wrongarr as $val){
            $delWrongId[]=$val['id'];
        }
    }
	C::t('#keke_exam#keke_exam_wrong')->delete($delWrongId);
	exit(json_encode(array('state'=>0)));
}elseif($_GET['ac']=='addfavorites'){
	if(!$_G['uid']){
		exit(json_encode(array('state'=>1,'msg'=>kekeexam_gbk2utf(lang('plugin/keke_exam', '002')))));
	}
	$favoritesarr=C::t('#keke_exam#keke_exam_favorites')->fetchfirst_bycid($_GET['pid'],$_G['uid']);
	if($favoritesarr){
		C::t('#keke_exam#keke_exam_favorites')->delete($favoritesarr['id']);
		exit(json_encode(array('state'=>2,'msg'=>kekeexam_gbk2utf(lang('plugin/keke_exam', '191')))));
	}
	C::t('#keke_exam#keke_exam_favorites')->insert(array('pid'=>$_GET['pid'],'uid'=>$_G['uid'],'time'=>TIMESTAMP));
	//$bindurl=_checkwechatbind();
	exit(json_encode(array('state'=>0,'bindurl'=>$bindurl)));
}elseif($_GET['ac']=='delfavorites'){
	$delfavoritesarr=C::t('#keke_exam#keke_exam_favorites')->fetchfirst_byid($_GET['favoritesid']);
	if($delfavoritesarr['uid']!=$_G['uid']){
		exit(json_encode(array('state'=>1,'msg'=>kekeexam_gbk2utf(lang('plugin/keke_exam', '015')))));
	}
	C::t('#keke_exam#keke_exam_favorites')->delete($_GET['favoritesid']);
	exit(json_encode(array('state'=>0)));
}elseif($_GET['ac']=='addview'){
	$pid=intval($_GET['pid']);
	$paper=C::t('#keke_exam#keke_exam_paper')->fetchfirst_byid($pid);
	C::t('#keke_exam#keke_exam_paper')->update($pid,array('view'=>$paper['view']+1));
	exit(json_encode(array('state'=>0)));
}elseif($_GET['ac']=='addfollow'){
	$follow_data=C::t('#keke_exam#keke_exam_follow')->fetchfirst_byteacherid($_GET['teacherid'],$_G['uid']);
	if($follow_data){
		C::t('#keke_exam#keke_exam_follow')->delete($follow_data['id']);
	}else{
		C::t('#keke_exam#keke_exam_follow')->insert(array('uid'=>$_G['uid'],'tid'=>$_GET['teacherid'],'time'=>TIMESTAMP));
	}
	exit(json_encode(array('state'=>0,'bindurl'=>$bindurl)));	
}elseif($_GET['ac']=='add_card'){
	$card=$_GET['card'];
	$arr=array(
		'alipay_name'=>kekexam_utf2gbk($card['alipayname']),
		'alipay'=>$card['alipay'],
		'wechatpay_name'=>kekexam_utf2gbk($card['wechatpayname']),
		'wechatpay'=>$card['wechatpay'],
		'bank_name'=>kekexam_utf2gbk($card['bankname']),
		'bank'=>$card['bank'],
		'bank_type'=>kekexam_utf2gbk($card['banktype']),
	);
	C::t('#keke_exam#keke_exam_teacher')->update($_G['uid'],$arr);
	exit(json_encode(array('state'=>0)));
	
}elseif($_GET['ac']=='cashout'){
	$acc_type=intval($_GET['acc_type']);
	$acc_type=in_array($acc_type,array(1,2,3))?$acc_type:1;
	$money=floatval($_GET['money']);
	
	if($money<=0){
		exit(json_encode(array('state'=>1,'msg'=>kekeexam_gbk2utf(lang('plugin/keke_exam', '192')))));
	}
	
	if(!discuz_process::islocked('cashout_checklocked_exam', 60)) {
		$teacherdata = C::t('#keke_exam#keke_exam_teacher')->fetchfirst_byid($_G['uid']);
		
		if($acc_type==1){
			if(!$teacherdata['alipay']){
				discuz_process::unlock('cashout_checklocked_exam');
				exit(json_encode(array('state'=>1,'msg'=>kekeexam_gbk2utf(lang('plugin/keke_exam', '193')))));
			}
			$card=lang('plugin/keke_exam', '208').' / '.$teacherdata['alipay'].' / '.$teacherdata['alipay_name'];
		}elseif($acc_type==2){
			if(!$teacherdata['wechatpay']){
				discuz_process::unlock('cashout_checklocked_exam');
				exit(json_encode(array('state'=>1,'msg'=>kekeexam_gbk2utf(lang('plugin/keke_exam', '194')))));
			}
			$card=lang('plugin/keke_exam', '209').' / '.$teacherdata['wechatpay'].' / '.$teacherdata['wechatpay_name'];
		}else{
			if(!$teacherdata['bank']){
				discuz_process::unlock('cashout_checklocked_exam');
				exit(json_encode(array('state'=>1,'msg'=>kekeexam_gbk2utf(lang('plugin/keke_exam', '195')))));
			}
			$card=lang('plugin/keke_exam', '210').' / '.$teacherdata['bank_type'].' - '.$teacherdata['bank'].' / '.$teacherdata['bank_name'];
		}
		
		if($keke_exam['tixian_min']>$money){
			discuz_process::unlock('cashout_checklocked_exam');
			exit(json_encode(array('state'=>1,'msg'=>kekeexam_gbk2utf(lang('plugin/keke_exam', '196').$keke_exam['tixian_min'].lang('plugin/keke_exam', '197')))));
		}
		if($money>$teacherdata['money']){
			discuz_process::unlock('cashout_checklocked_exam');
			exit(json_encode(array('state'=>1,'msg'=>kekeexam_gbk2utf(lang('plugin/keke_exam', '198')))));
		}
		$cachout_arr=array(
			'uid'=>$_G['uid'],
			'money'=>$money,
			'card_type'=>$acc_type,
			'card'=>$card,
			'time'=>TIMESTAMP
		);
		C::t('#keke_exam#keke_exam_cashout')->insert($cachout_arr);
		cach_log(-$money,lang('plugin/keke_exam', '199'),$_G['uid']);
		discuz_process::unlock('cashout_checklocked_exam');
	}else{
		exit(json_encode(array('state'=>1,'msg'=>kekeexam_gbk2utf(lang('plugin/keke_exam', '200')))));
	}
	$all_set=_exam_get_set();
	exit(json_encode(array('state'=>0)));
}elseif($_GET['ac']=='addcate'){
	$_GET['name']=$_GET['name']?$_GET['name']:lang('plugin/keke_exam', '201');
	$addarr=array(
		'uid'=>$_G['uid'],
		'type'=>$_GET['type'],
		'name'=>kekexam_utf2gbk($_GET['name']),
		'upid'=>$_GET['upid'],
	);
	$id=C::t('#keke_exam#keke_exam_cate')->insert($addarr, true);
	exit(json_encode(array('state'=>0,'cateid'=>$id)));	
}elseif($_GET['ac']=='delcate'){
	$cateid=intval($_GET['ids']);
	$catetype=$_GET['catetype']?intval($_GET['catetype']):1;
	$catedata=C::t('#keke_exam#keke_exam_cate')->fetch_all_by_displayorders('uid='.$_G['uid'].' AND type='.$catetype);
	$cateids=_getallChildidscateid($catedata,$cateid);
	$cateidarr=explode(',',$cateids);
	C::t('#keke_exam#keke_exam_cate')->delete($cateidarr);
	exit(json_encode(array('state'=>0)));
}elseif($_GET['ac']=='editcatename'){
	$cateid=intval($_GET['ids']);
	C::t('#keke_exam#keke_exam_cate')->update($cateid,array('name'=>kekexam_utf2gbk($_GET['name'])));
	exit(json_encode(array('state'=>0)));	
}elseif($_GET['ac']=='getcate'){
	$_GET['index']=intval($_GET['index']);
	$where=' type='.intval($_GET['type']).' AND uid='.$_G['uid'];
	$catedata=C::t('#keke_exam#keke_exam_cate')->fetch_all_by_displayorders($where);
    function getChild($data, $id = 0){
        $tree =$res = array();
        foreach( $data as $key=>$vo ){
            $vos=array('id'=>$vo['cate_id'],'title'=>kekeexam_gbk2utf($vo['name']),'upid'=>$vo['upid'],'spread'=>'true');
            $res[$vo['cate_id']] = $vos;
            $res[$vo['cate_id']]['children'] = array();
        }
        unset( $data );
        foreach( $res as $key=>$vo ){
            if( $vo['upid'] != 0 ){
                $res[$vo['upid']]['children'][] = &$res[$key];
            }
        }
        foreach( $res as $key=>$vo ){
            if( $vo['upid'] == $id ){
                $tree[] = $vo;
            }
        }
        unset( $res );
        return $tree;
    }
    $return=getChild($catedata);
	$returns=array(array('id'=>0,'title'=>kekeexam_gbk2utf(lang('plugin/keke_exam', '202')),'children'=>$return,'spread'=>'true'));
	$returnss = json_encode( $returns );
	exit($returnss);
}elseif($_GET['ac']=='getsubcate'){
	$cateid=intval($_GET['cateid']);
	$catedata=_get_exam_allcatedata();
	$data=array();
	if($catedata[$cateid]['subcate']){
		foreach($catedata[$cateid]['subcate'] as $key=>$val){
			$data[]=array($val,kekeexam_gbk2utf($catedata[$val]['name']));
		}
		$type=0;
	}else{
		$data[]=array($cateid,kekeexam_gbk2utf($catedata[$cateid]['name']));
		$type=1;
	}
	exit(json_encode(array('type'=>$type,'datas'=>$data)));
}elseif($_GET['ac']=='addpaper'){
	if(!$_GET['title']){
		exit(json_encode(array('state'=>1,'msg'=>kekeexam_gbk2utf(lang('plugin/keke_exam', '003')))));
	}
	if(!$_GET['question']){
		exit(json_encode(array('state'=>1,'msg'=>kekeexam_gbk2utf(lang('plugin/keke_exam', '004')))));
	}
	$total_score=$total=0;
	foreach($_GET['question'] as $key=>$questionsval){
		$questionsval['title']=kekexam_utf2gbk($questionsval['title']);
		if(!$questionsval['data']){
			exit(json_encode(array('state'=>1,'msg'=>kekeexam_gbk2utf(lang('plugin/keke_exam', '005')))));
		}
		$qsval[]=$questionsval;
		if($questionsval['modes']==1){
			foreach($questionsval['score'] as $score){
				if($score<=0){
					exit(json_encode(array('state'=>1,'msg'=>kekeexam_gbk2utf(lang('plugin/keke_exam', '006')))));
				}
				$total_score+=$score;
			}
			$total+=count($questionsval['score']);
		}else{
			$total_score+=($questionsval['qsnum']*$questionsval['qsfen']);
			$total+=$questionsval['qsnum'];
		}
	}
	$addarr=array(
		'title'=>kekexam_utf2gbk($_GET['title']),
		'data'=>serialize($qsval),
		'pass'=>intval($_GET['pass']),
		'total_score'=>$total_score,
		'total'=>$total
	);
	C::t('#keke_exam#keke_exam_paper')->update($_GET['pid'],$addarr);
	exit(json_encode(array('state'=>0)));
	
}elseif($_GET['ac']=='delpaper'){
	$paperid=intval($_GET['paperid']);
	$paperdata=C::t('#keke_exam#keke_exam_paper')->fetchfirst_byid($paperid);
	if($paperdata['uid']!=$_G['uid']){
		exit(json_encode(array('state'=>1,'msg'=>kekeexam_gbk2utf(lang('plugin/keke_exam', '002')))));
	}
	C::t('#keke_exam#keke_exam_paper')->delete($paperid);
	exit(json_encode(array('state'=>0)));
	
}elseif($_GET['ac']=='addprice'){
	$pid=intval($_GET['pid']);
	$paperdata=C::t('#keke_exam#keke_exam_paper')->fetchfirst_byid($pid);
	if($_GET['price']){
		foreach($_GET['price'] as $pkey=>$pval){
			$updatearr=array(
				'title'=>kekexam_utf2gbk($pval['title']),
				'price'=>$pval['price'],
				'yprice'=>$pval['yprice'],
				'credit'=>$pval['credit'],
				'credit_type'=>$pval['credit_type'],
				'total'=>$pval['total'],
				'limit'=>$pval['limit'],
				'displayorder'=>$pval['displayorder'],
			);
			C::t('#keke_exam#keke_exam_price')->update($pkey,$updatearr);
		}
	}
	if($_GET['new']){
		foreach($_GET['new']['title'] as $key=>$val){
			if($_GET['new']['price'] || $_GET['new']['credit']){
				$addarr=array(
					'title'=>kekexam_utf2gbk($val),
					'price'=>$_GET['new']['price'][$key],
					'yprice'=>$_GET['new']['yprice'][$key],
					'credit'=>$_GET['new']['credit'][$key],
					'credit_type'=>$_GET['new']['credit_type'][$key],
					'total'=>$_GET['new']['total'][$key],
					'limit'=>$_GET['new']['limit'][$key],
					'displayorder'=>$_GET['new']['displayorder'][$key],
					'pid'=>$pid,
					'uid'=>$_G['uid'],
				);
				C::t('#keke_exam#keke_exam_price')->insert($addarr, true);
			}
		}
	}
	exit(json_encode(array('state'=>0)));
}elseif($_GET['ac']=='delprice'){
	$priceid=intval($_GET['priceid']);
	$pricedata=C::t('#keke_exam#keke_exam_price')->fetch_first_byid($priceid);
	$paperdata=C::t('#keke_exam#keke_exam_paper')->fetchfirst_byid($pricedata['pid']);
	if($_G['uid']!=$paperdata['uid']){
		exit(json_encode(array('state'=>1,'msg'=>kekeexam_gbk2utf(lang('plugin/keke_exam', '015')))));
	}
	C::t('#keke_exam#keke_exam_price')->delete($priceid);
	exit(json_encode(array('state'=>0)));
}elseif($_GET['ac']=='addexam'){
	if(!$_GET['title'])$errTip=lang('plugin/keke_exam', '007');
	if(!$_GET['exam_subcate'])$errTip=lang('plugin/keke_exam', '203');
    if(!$_GET['exam_type'])$errTip=lang('plugin/keke_exam', '232');
    if($errTip){
        exit(json_encode(array('state'=>1,'msg'=>kekeexam_gbk2utf($errTip))));
    }
    $exam_type=count($_GET['exam_type'])==1?intval($_GET['exam_type'][0]):3;
	$pid=intval($_GET['pid']);
	$addarr=array(
		'title'     =>  kekexam_utf2gbk($_GET['title']),
		'uid'       =>  $_G['uid'],
		'img'       =>  $_GET['coveimg'],
		'cate'      =>  intval($_GET['exam_cate']),
		'subcate'   =>  intval($_GET['exam_subcate']),
        'type'      =>  $exam_type,
		'start'     =>  ($_GET['date']?strtotime($_GET['date']):''),
		'end'       =>  ($_GET['date1']?strtotime($_GET['date1']):''),
		'exam_exp'  =>  kekexam_utf2gbk($_GET['exam_exp']),
		'answertime'=>  intval($_GET['answertime']),
		'ansmod'    =>  intval($_GET['ansmod']),
		'time'      =>  TIMESTAMP
	);
	if($pid){
		C::t('#keke_exam#keke_exam_paper')->update($pid,$addarr);
	}else{
		$pid=C::t('#keke_exam#keke_exam_paper')->insert($addarr, true);
	}
	exit(json_encode(array('state'=>0,'pid'=>$pid)));
}elseif($_GET['ac']=='getquestion'){
	$gid=intval($_GET['gid']);
	$xx=array('','A','B','C','D','E','F','G');
	$ppp=10;
	$page = max(1, $_GET['page']);
	$startlimit = ($page - 1) * $ppp;
	$where='uid='.$_G['uid'];
	$param='';
	if($_GET['type'] && $_GET['type']!=99){
		$where.=" AND type='".intval($_GET['type'])."'";
		$param.='&type='.dhtmlspecialchars($_GET['type']);
	}
	if($_GET['qsids']){
		$_GET['qsids']=$_GET['page']>=1?explode(',',$_GET['qsids']):$_GET['qsids'];
		$qsidsa=dimplode($_GET['qsids']);
		if($_GET['jointype']){
			$where.=" AND id in (".$qsidsa.")";
			$param.='&jointype=1';
		}else{
			$where.=" AND id not in (".$qsidsa.")";
		}
		foreach($_GET['qsids'] as $key=>$val){
			$qsidstr.=$val.',';
		}
		
		$qsidstr=substr($qsidstr,0,strlen($qsidstr)-1); 
		$param.='&qsids='.dhtmlspecialchars($qsidstr);
	}elseif($_GET['jointype']){
        $questionalist='';
		include template('keke_exam:block');
		exit($questionalist);
	}
	if($_GET['difficulty']){
		$where.=" AND difficulty='".intval($_GET['difficulty'])."'";
        $parameter.='&difficulty='.intval($_GET['difficulty']);
		$param.='&difficulty='.dhtmlspecialchars($_GET['difficulty']);
	}
	if($_GET['kewords']){
		$_GET['keywords']=dhtmlspecialchars($_GET['kewords']);
		$where.=" AND title LIKE '%".addcslashes(kekexam_utf2gbk($_GET['kewords']),'%_')."%'";
		$parameter.='&title='.$_GET['keywords'];
		$param.='&kewords='.dhtmlspecialchars($_GET['kewords']);
	}
	if($_GET['cateid']){
		$_GET['cateid']=intval($_GET['cateid']);
		$catedata=C::t('#keke_exam#keke_exam_cate')->fetch_all_by_displayorders('uid='.$_G['uid'].' AND type=1');
		$cateids=_getallChildidscateid($catedata,$_GET['cateid']);
		$where.=" AND cate IN (".$cateids.")";
		$parameter.='&cateid='.$_GET['cateid'];
	}
	$order='ORDER BY ID DESC';
	if($_GET['op']=='post'){
        $allQuestionId=$_GET['qs'];

        $qArr= C::t('#keke_exam#keke_exam_question')->fetch_all_by_fromqids($_GET['qs']);
	    if($qArr[1])$allQuestionId=array_merge($allQuestionId,$qArr[1]);

		$where.= ' AND id in ('.dimplode($allQuestionId).')';
		$ppp=1000;
	}else{
        $where.=' AND `from`=0';
    }

	$tmpurl='plugin.php?id=keke_exam:ajax&ac=getquestion'.$param.'&formhash='.FORMHASH;
	$count_all=C::t('#keke_exam#keke_exam_question')->count_all($where);
	$questionarrs=C::t('#keke_exam#keke_exam_question')->fetch_alls($startlimit,$ppp,$where,$order);
	$multipage = multi($count_all, $ppp, $page, $_G['siteurl'].$tmpurl);
	$multipage=preg_replace("/\<label\>([\s\S]*)\<\/label\>/i", '', $multipage);
	$multipage=str_replace('href','data-href',$multipage);
	if($_GET['op']=='post'){
		foreach($_GET['qs'] as $qss){
			$questions[$qss]=$questionarrs[$qss];
			$questions[$qss]['data']=unserialize($questionarrs[$qss]['data']);

            if($qArr[0][$qss]){
                foreach ($qArr[0][$qss] as $questionId=>$qData){
                    $questions[$questionId]=$questionarrs[$questionId];
                    $questions[$questionId]['data']=unserialize($questionarrs[$questionId]['data']);
                }
            }

        }
		$pid=intval($_GET['pid']);
		$paperdata=C::t('#keke_exam#keke_exam_paper')->fetchfirst_byid($pid);
		$paperquestionarr=unserialize($paperdata['data']);
		$scorearr=array();
		foreach($paperquestionarr as $ppqskey=>$ppqsval){
			foreach($ppqsval['score'] as $ppqsid=>$score){
				$scorearr[$ppqsid]=$score;
			}
		}
	}
	if($_GET['selectIds']){
        $selectIds=explode('-',$_GET['selectIds']);
    }
	$core=floatval($_GET['core']);
	include template('keke_exam:block');
	if($_GET['op']=='post'){
		echo $questionalists;
	}else{
		echo $questionalist;
	}
	exit();
}elseif($_GET['ac']=='getpaper'){
	$ppp=10;
	$_GET['page']=intval($_GET['page']);
	$param=($_GET['op'])?'op='.dhtmlspecialchars($_GET['op']):($_GET['catid']?'catid='.dhtmlspecialchars($_GET['catid']):'');
	$param=$param?'&'.$param:'';
	$tmpurl='plugin.php?id=keke_exam:ajax&ac=getpaper'.$param;
	$page = max(1, $_GET['page']);
	$startlimit = ($page - 1) * $ppp;
	$where='uid='.$_G['uid'];
	$order='ORDER BY ID DESC';
	if($_GET['op']=='post'){
		$where.= ' AND id in ('.dimplode($_GET['qs']).')';
	}
	$count_all=C::t('#keke_exam#keke_exam_paper')->count_all($where);
	$paperarrs=C::t('#keke_exam#keke_exam_paper')->fetch_alls($startlimit,$ppp,$where,$order);
	$multipage = multi($count_all, $ppp, $page, $_G['siteurl'].$tmpurl);
	$multipage=preg_replace("/\<label\>([\s\S]*)\<\/label\>/i", '', $multipage);
	$multipage=str_replace('href','data-href',$multipage);
	include template('keke_exam:block');
	echo $paperlist;
	exit();
}elseif($_GET['ac']=='oppaper'){
	if($_GET['select'] && is_array($_GET['select'])){
		foreach($_GET['select'] as $qid){
			$oparrs[]=intval($qid);
		}
		if($_GET['optype']){
			if($_GET['optype']=='del'){
				C::t('#keke_exam#keke_exam_paper')->del_by_qids(dimplode($oparrs),$_G['uid']);
			} elseif($_GET['optype'] == 'up') {
				C::t('#keke_exam#keke_exam_paper')->update($_GET['select'], array('state' => 1));
			} elseif($_GET['optype'] == 'down') {
				C::t('#keke_exam#keke_exam_paper')->update($_GET['select'], array('state' => 2));
			}
		}		
	}
	exit(json_encode(array('state'=>0)));
}elseif($_GET['ac']=='opuestion') {
    if ($_GET['select'] && is_array($_GET['select'])) {
        foreach ($_GET['select'] as $qid) {
            $oparrs[] = intval($qid);
        }
        if ($_GET['optype'] == 'del') {
            C::t('#keke_exam#keke_exam_question')->del_by_qids(dimplode($oparrs), $_G['uid']);
        }
    }
    exit(json_encode(array('state' => 0)));
}elseif ($_GET['ac']=='checkExamOngoing'){
    $totals=C::t('#keke_exam#keke_exam_total')->fetch_first_by_pidanduid(intval($_GET['pid']),$_G['uid']);
    $pricedata=C::t('#keke_exam#keke_exam_price')->count_all('pid='.intval($_GET['pid']).' AND price>0');
    if($totals['total']==0 && $pricedata){
        exit(json_encode(array('state'=>1,'msg'=>kekeexam_gbk2utf(lang('plugin/keke_exam', '204')))));
    }
    $testdata=C::t('#keke_exam#keke_exam_log')->fetch_first_bywhere('uid='.$_G['uid'].' AND start<'.TIMESTAMP.' AND end>'.TIMESTAMP.' AND pid='.intval($_GET['pid']).' AND state=0');
    if($testdata['id']){
        exit(json_encode(array('state'=>0,'examid'=>$testdata['id'])));
    }
    exit(json_encode(array('state'=>0,'examid'=>0)));
}elseif($_GET['ac']=='gotest'){
    $all_set=_exam_get_set();
    $qArr = array();
    $materia = array();
	$pid=intval($_GET['pid']);
	$priceid=intval($_GET['priceid']);
	if(!$_G['uid']){
		exit(json_encode(array('state'=>1,'msg'=>kekeexam_gbk2utf(lang('plugin/keke_exam', '217')))));
	}
	$testdata=C::t('#keke_exam#keke_exam_log')->fetch_first_bywhere('uid='.$_G['uid'].' AND start<'.TIMESTAMP.' AND end>'.TIMESTAMP.' AND pid='.$pid.' AND state=0');
	if($testdata['id']){
        $testUrl=getTestUrl($testdata['id']);
		exit(json_encode(array('state'=>0,'examid'=>$testdata['id'],'testurl'=>$testUrl)));
	}
    $total=C::t('#keke_exam#keke_exam_total')->fetch_first_by_pidanduid($pid,$_G['uid']);
	$pricedata=C::t('#keke_exam#keke_exam_price')->fetch_first_byid($priceid);
	if(!$pricedata || ($pricedata['price']<=0 && !$pricedata['credit'])){
		if($total['total']==0){
			$buylog=C::t('#keke_exam#keke_exam_buylog')->count_all('uid='.$_G['uid'].' AND pid='.$priceid);
			if($pricedata['limit'] && $buylog>=$pricedata['limit']){
				exit(json_encode(array('state'=>1,'msg'=>kekeexam_gbk2utf(lang('plugin/keke_exam', '228')))));
			}
			if(!$total['id']){
                $total['total']=$pricedata['total']?$pricedata['total']:-1;
				$insterarr=array(
					'uid'=>$_G['uid'],
					'teacher_uid'=>$pricedata['uid'],
					'pid'=>$pid,
					'total'=>$total['total'],
				);
				C::t('#keke_exam#keke_exam_total')->insert($insterarr);
			}else{
                $total['total']=$updatatotal=$pricedata['total']?$total['total']+$pricedata['total']:-1;
				C::t('#keke_exam#keke_exam_total')->update($total['id'],array('total'=>$updatatotal));
			}
			$buylog=array(
				'uid'=>$_G['uid'],
				'pid'=>$priceid,
				'time'=>TIMESTAMP,
			);
			C::t('#keke_exam#keke_exam_buylog')->insert($buylog);
		}
	}
	if($total['total']==0){
		exit(json_encode(array('state'=>1,'msg'=>kekeexam_gbk2utf(lang('plugin/keke_exam', '204')))));
	}
	if($total['total']>0){
		C::t('#keke_exam#keke_exam_total')->update($total['id'],array('total'=>$total['total']-1));
	}
	$paperdata=C::t('#keke_exam#keke_exam_paper')->fetchfirst_byid($pid);
    if(($paperdata['type']==1 || $paperdata['type']==2) && $paperdata['type']!=$_GET['type']){
        exit(json_encode(array('state'=>1,'msg'=>kekeexam_gbk2utf(lang('plugin/keke_exam', '233')))));
    }
	$paperquestionarr=unserialize($paperdata['data']);
    foreach($paperquestionarr as $qTtem){
        if($qTtem['modes']==2 && $qTtem['type']==6){
            foreach ($qTtem['data'] as $dItem){
                $materia[$dItem]=$dItem;
            }
        }
    }
    if($materia){
        $qArr= C::t('#keke_exam#keke_exam_question')->fetch_all_by_fromqids($materia);
    }
	foreach($paperquestionarr as $key=>$val){
		$data=array();
		if($val['modes']==1){
			foreach($val['data'] as $ks=>$vs){
				if($val['score'][$vs])$data[$vs]=$val['score'][$vs];
			}
		}else{
			$datas=array_rand($val['data'],$val['qsnum']);
			if(!is_array($datas)){
				$datas=array($datas);
			}
			foreach($datas as $k=>$v){
                $newdata=array();
                if ($val['type'] == 6) {
                    if ($qArr[0][$val['data'][$v]]) {
                        $newdata = array_keys($qArr[0][$val['data'][$v]]);
                        foreach($newdata as $nv){
                            $data[$nv]=$val['qsfen'];
                        }
                    }
                }else{
                    $data[$val['data'][$v]]=$val['qsfen'];
                }
			}
		}
		$testarr[$key]=array(
			'title'=>$val['title'],
			'data'=>$data
		);
	}
	$test_data=serialize($testarr);
	$addarr=array(
		'uid'=>$_G['uid'],
		'pid'=>$pid,
		'data'=>$test_data,
		'start'=>TIMESTAMP,
		'end'=>$paperdata['answertime']?$paperdata['answertime']*60+TIMESTAMP:'',
        'exam_type'=>intval($_GET['type']),
	);
	$id=C::t('#keke_exam#keke_exam_log')->insert($addarr, true);
	C::t('#keke_exam#keke_exam_paper')->update($pid,array('examtotal'=>$paperdata['examtotal']+1));
    $testUrl=getTestUrl($id);
	exit(json_encode(array('state'=>0,'examid'=>$id,'testurl'=>$testUrl)));
}elseif($_GET['ac']=='dosave'){
	$result=0;
	$pid=intval($_GET['pid']);
	$examid=intval($_GET['examid']);
	$examdata=$paperdata=C::t('#keke_exam#keke_exam_log')->fetchfirst_byid($examid);
	if(!$examdata || $examdata['uid']!=$_G['uid']){
		exit(json_encode(array('state'=>1,'msg'=>kekeexam_gbk2utf(lang('plugin/keke_exam', '015')))));
	}
	$questionarr=unserialize($examdata['data']);
	$questiondata=_getquestion_by_id($questionarr,1);
	foreach($questionarr as $questions){
		foreach($questions['data'] as $questionid=>$score){
			$scores[$questionid]=$score;
		}
	}
	foreach($questiondata as $quekey=>$queval){
        if($queval['type']==6)continue;
		$isright[$queval['id']]=0;
		$tmpcheck=empty($_GET['as'][$queval['id']])?0:1;
		if($queval['type']==1 || $queval['type']==4){
			$tmpcheck=0;
			if($_GET['as'][$queval['id']][0]==$queval['data']['answer'][0]){
				$tmpcheck=1;
			}
		}elseif($queval['type']==3){
			$_GET['as'][$queval['id']][0]=kekexam_utf2gbk($_GET['as'][$queval['id']][0]);
		}else{
			foreach($_GET['as'][$queval['id']] as $askey=>$asval){
				if($queval['type']==5){
					$_GET['as'][$queval['id']][$askey]=kekexam_utf2gbk($asval);
					if($_GET['as'][$queval['id']][$askey]!=$queval['data']['answer'][$askey]){
						$tmpcheck=0;
					}
				}elseif($queval['type']==2){
					if(!(in_array($asval,$queval['data']['answer'])) || count($_GET['as'][$queval['id']])!=count($queval['data']['answer'])){
						$tmpcheck=0;
						break;
					}
				}
			}
		}
		if($tmpcheck){
			$result+=$scores[$queval['id']];
			$isright[$queval['id']]=$scores[$queval['id']];
		}else{
			$isright[$queval['id']]=0;
			$wrong[]=$queval['id'];
		}
	}
    $state=$_GET['postexam']?1:0;
    $postTime='';
	if($state){
        $getwrong=C::t('#keke_exam#keke_exam_wrong')->fetch_all_by_qidanduid($wrong,$_G['uid']);
        foreach($wrong as $quevalid){
            if(!$getwrong[$quevalid]){
                $wrong_arr=array(
                    'uid'=>$_G['uid'],
                    'qid'=>$quevalid,
                    'pid'=>$paperdata['pid'],
                    'examid'=>$examid,
                    'time'=>TIMESTAMP
                );
                C::t('#keke_exam#keke_exam_wrong')->insert($wrong_arr);
            }
        }
        $postTime=TIMESTAMP;
    }
	$answerdata=array(
		'answer'=>$_GET['as'],
		'isright'=>$isright,
	);

	$answer_data=serialize($answerdata);
	$updatearr=array(
		'answer_data'=>$answer_data,
		'time'=>$postTime,
		'totalscore'=>$result,
		'state'=>$state
	);
	$id=C::t('#keke_exam#keke_exam_log')->update($examid,$updatearr);
	exit(json_encode(array('state'=>0)));
}elseif($_GET['ac']=='checkorder'){
	$orderdata= C::t('#keke_exam#keke_exam_order')->fetch($_GET['orderid']);
	exit(json_encode(array('state' =>$orderdata['state'])));
}elseif($_GET['ac']=='checklogstate'){	
	$examid=intval($_GET['examid']);
	$examdata=C::t('#keke_exam#keke_exam_log')->fetchfirst_byid($examid);
	if(!$examdata || $examdata['uid']!=$_G['uid']){
		exit(json_encode(array('state'=>4,'msg'=>kekeexam_gbk2utf(lang('plugin/keke_exam', '015')))));
	}
	exit(json_encode(array('state' =>$examdata['state'])));
}elseif($_GET['ac']=='waitprice'){
	$orderdata=C::t('#keke_exam#keke_exam_order')->fetchfirst_byid($_GET['orderid']);
	if($orderdata['teacher_uid']!=$_G['uid']){
		exit(json_encode(array('state'=>1)));
	}
	if($orderdata['state']!=0){
		exit(json_encode(array('state'=>2)));
	}
	C::t('#keke_exam#keke_exam_order')->update($_GET['orderid'],array('price'=>floatval($_GET['orderprice']),'revision'=>TIMESTAMP));
	exit(json_encode(array('state'=>0)));
}elseif($_GET['ac']=='checkmagorder'){
	$orderdata=C::t('#keke_exam#keke_exam_order')->fetchfirst_byid($_GET['orderid']);
	$url = 'http://'.$keke_exam['magurl'].'/core/pay/pay/orderStatusQuery?unionOrderNum='.$_GET['unionordernum'].'&secret='.$keke_exam['magsecret'];
	$data = dfsockopen($url);
	if(!$data){
		$data = file_get_contents($url);
	}
	$return= json_decode($data,true);
	if($orderdata && $orderdata['state']!=1 && $return['paycode'] == 1){
		uporderstate($_GET['orderid'],5);
		exit(json_encode(array('state'=>0)));
	}
	exit(json_encode(array('state'=>1)));	
}elseif($_GET['ac']=='updateqianfansn'){
	C::t('#keke_exam#keke_exam_order')->update($_GET['orderid'],array('sn'=>$_GET['sn']));
	exit(json_encode(array('state'=>1)));
}elseif($_GET['ac']=='closorder'){	
	$orderdata=C::t('#keke_exam#keke_exam_order')->fetchfirst_byid($_GET['orderid']);
	if($orderdata['uid']!=$_G['uid']){
		exit(json_encode(array('state'=>1,'msg'=>kekeexam_gbk2utf(lang('plugin/keke_exam', '015')))));
	}
	C::t('#keke_exam#keke_exam_order')->update($_GET['orderid'],array('state'=>4));
	exit(json_encode(array('state'=>0)));
}elseif($_GET['ac']=='kekeaddevaluate'){
	$pid=intval($_GET['pid']);
	$notedata=C::t('#keke_exam#keke_exam_evaluate')->fetchfirst_byuid($pid,$_G['uid']);
	$pricedata=C::t('#keke_exam#keke_exam_price')->fetch_all('pid='.$pid);
	foreach($pricedata as $price){
		$priceids[]=$price['id'];
	}
	$checkbuylog=C::t('#keke_exam#keke_exam_buylog')->count_all('pid in ('. dimplode($priceids).') AND uid='.$_G['uid']);
	if(!$checkbuylog){
		exit(json_encode(array('state'=>1,'msg'=>kekeexam_gbk2utf(lang('plugin/keke_exam', '206')))));
	}
	if($notedata){
		exit(json_encode(array('state'=>1,'msg'=>kekeexam_gbk2utf(lang('plugin/keke_exam', '207')))));
	}
	C::t('#keke_exam#keke_exam_evaluate')->insert(array('uid'=>$_G['uid'],'username'=>$_G['username'],'star'=>intval($_GET['star']),'pid'=>$pid,'text'=>kekexam_utf2gbk($_GET['text']),'time'=>TIMESTAMP),true);
	exit(json_encode(array('state'=>0,'star'=>intval($_GET['star']),'time'=>dgmdate(TIMESTAMP, 'Y-m-d H:i:s'),'text'=>kekeexam_gbk2utf(dhtmlspecialchars($_GET['text'])))));
}elseif($_GET['ac']=='getexplain'){
    $explain='';
    $paperdata=C::t('#keke_exam#keke_exam_paper')->fetchfirst_byid(intval($_GET['pid']));
    include template('keke_exam:block');
    exit($explain);
}