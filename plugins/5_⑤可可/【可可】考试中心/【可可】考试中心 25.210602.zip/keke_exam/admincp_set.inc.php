<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
	loadcache('plugin'); //d'.'is'.'m.ta'.'obao.com
	include_once DISCUZ_ROOT."source/plugin/keke_exam/function.php";
	
	$allcatedata=_get_exam_allcatedata();
	$_GET['op']=$_GET['op']?$_GET['op']:'set';
	_exam_showadminsubmenu(array(
		array(lang('plugin/keke_exam', '230'), "set"),
		array(lang('plugin/keke_exam', '087'), "seo"),
		array(lang('plugin/keke_exam', '088'), "index_slider"),
		array(lang('plugin/keke_exam', '089'), "mobile_slider"),
		array(lang('plugin/keke_exam', '090'), "mobile_nav"),
		array(lang('plugin/keke_exam', '092'), "mobile_discover"),
	),'admincp_set');

if ($_GET['op'] == 'index_slider') {
	$slider=_exam_get_cache('slider');
	if (submitcheck("forumset")) {
		if(is_array($_GET['delete'])) {
			C::t('#keke_exam#keke_exam_slider')->delete($_GET['delete']);
			_exam_save_cache('slider');
		}
		cpmsg(lang('plugin/keke_exam', '020'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_exam&pmod=admincp_set&op=index_slider', 'succeed');
	}
	if($_GET['ac']=='editpic'){
		if (!submitcheck("editsubmit")) {
			if($_GET['keyid']){
				$keyid=intval($_GET['keyid']);
				$dataarr=$slider[$keyid];
			}
			showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admincp_set&op=index_slider&ac=editpic", 'enctype');
			showtableheader(lang('plugin/keke_exam', '093'));
			showsetting(lang('plugin/keke_exam', '094'),'spic',$dataarr['img'],'filetext');
			showsetting(lang('plugin/keke_exam', '095'),'url',$dataarr['url'],'text');
			showsetting(lang('plugin/keke_exam', '084'),'displayorder',$dataarr['displayorder'],'text');
			echo '<input name="keyid" type="hidden" value="'.$keyid.'" />';
			showsubmit('editsubmit', 'submit', '');
			showtablefooter(); //From: Dism��taobao��com
			showformfooter(); //From: Dism_taobao_com
			exit;
		}else{
			$picurl=_exam_upload_img($_FILES['spic'],1920,800);
			$pic=$picurl ? $picurl : $_GET['spic'];
			if(!$pic){
				cpmsg(lang('plugin/keke_exam', '096'), '', 'error');
			}
			$arr=array(
				'id'=>intval($_GET['keyid']),
				'img'=> $pic,
				'url'=> $_GET['url'],
				'type'=>1,
				'displayorder'=> $_GET['displayorder'],
			);
			C::t('#keke_exam#keke_exam_slider')->insert($arr,false,true);
			_exam_save_cache('slider');
			cpmsg(lang('plugin/keke_exam', '020'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier='.$plugin["identifier"].'&pmod=admincp_set&op=index_slider', 'succeed');
		
		}
	}
	showtips('<li>'.lang('plugin/keke_exam', '097').'</li><li>'.lang('plugin/keke_exam', '098').'</li>');
	showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admincp_set&ac=editpic&op=index_slider", 'enctype');
	showtableheader('header');
	showsubtitle(array('del',lang('plugin/keke_exam', '094'),lang('plugin/keke_exam', '095'),lang('plugin/keke_exam', '084'),lang('plugin/keke_exam', '051')));
	
	foreach($slider as $slider_data){
		if($slider_data['type']==1){
			$table = array(); //From: Dism_taobao-com
			$table[0] = '<input type="checkbox" class="checkbox" name="delete[]" value="'.$slider_data['id'].'" />';
			$table[1] = '<img src="'.$slider_data['img'].'" width="180" />';
			$table[2] = '<a href="'.$slider_data['url'].'"/>'.$slider_data['url'].'</a>';
			$table[3] = $slider_data['displayorder'];
			$table[4] = '<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier='.$plugin["identifier"].'&pmod=admincp_set&ac=editpic&op=index_slider&keyid='.$slider_data['id'].'&formhash='.FORMHASH.'">'.lang('plugin/keke_exam', '014').'</a>';
			showtablerow('',array(), $table);
		}
	}
	showsubmit('forumset', 'submit', 'del',' <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier='.$plugin["identifier"].'&pmod=admincp_set&ac=editpic&op=index_slider&formhash='.FORMHASH.'" class="addtr">'.lang('plugin/keke_exam', '099').'</a>');
	showtablefooter(); //From: Dism��taobao��com
	showformfooter(); //From: Dism_taobao_com
} else if ($_GET['op'] == 'mobile_slider') {
		$slider=_exam_get_cache('slider');
		if (submitcheck("forumset")) {
			if(is_array($_GET['delete'])) {
					C::t('#keke_exam#keke_exam_slider')->delete($_GET['delete']);
					_exam_save_cache('slider');
			}
			cpmsg(lang('plugin/keke_exam', '020'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_exam&pmod=admincp_set&op=mobile_slider', 'succeed');
		}
		if($_GET['ac']=='editpic'){
			if (!submitcheck("editsubmit")) {
				if($_GET['keyid']){
					$keyid=intval($_GET['keyid']);
					$dataarr=$slider[$keyid];
				}
				showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admincp_set&op=mobile_slider&ac=editpic", 'enctype');
				showtableheader(lang('plugin/keke_exam', '093'));
				showsetting(lang('plugin/keke_exam', '094'),'spic',$dataarr['img'],'filetext');
				showsetting(lang('plugin/keke_exam', '095'),'url',$dataarr['url'],'text');
				showsetting(lang('plugin/keke_exam', '084'),'displayorder',$dataarr['displayorder'],'text');
				echo '<input name="keyid" type="hidden" value="'.$keyid.'" />';
				showsubmit('editsubmit', 'submit', '');
				showtablefooter(); //From: Dism��taobao��com
				showformfooter(); //From: Dism_taobao_com
				exit;
			}else{
				$picurl=_exam_upload_img($_FILES['spic'],1200,432);
				$pic=$picurl ? $picurl : $_GET['spic'];
				if(!$pic){
					cpmsg(lang('plugin/keke_exam', '096'), '', 'error');
				}
				$arr=array(
					'id'=>intval($_GET['keyid']),
					'img'=> $pic,
					'url'=> $_GET['url'],
					'type'=>2,
					'displayorder'=> $_GET['displayorder'],
				);
				C::t('#keke_exam#keke_exam_slider')->insert($arr,false,true);
				_exam_save_cache('slider');
				cpmsg(lang('plugin/keke_exam', '020'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier='.$plugin["identifier"].'&pmod=admincp_set&op=mobile_slider', 'succeed');
			}
		}
		showtips('<li>'.lang('plugin/keke_exam', '100').'</li><li>'.lang('plugin/keke_exam', '101').'</li>');
		showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admincp_set&ac=editpic&op=mobile_slider", 'enctype');
		showtableheader('header');
		showsubtitle(array('del',lang('plugin/keke_exam', '094'),lang('plugin/keke_exam', '095'),lang('plugin/keke_exam', '084'),lang('plugin/keke_exam', '051')));
		foreach($slider as $slider_data){
			if($slider_data['type']==2){
				$table = array(); //From: Dism_taobao-com
				$table[0] = '<input type="checkbox" class="checkbox" name="delete[]" value="'.$slider_data['id'].'" />';
				$table[1] = '<img src="'.$slider_data['img'].'" width="180" />';
				$table[2] = '<a href="'.$slider_data['url'].'"/>'.$slider_data['url'].'</a>';
				$table[3] = $slider_data['displayorder'];
				$table[4] = '<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier='.$plugin["identifier"].'&pmod=admincp_set&ac=editpic&op=mobile_slider&keyid='.$slider_data['id'].'&formhash='.FORMHASH.'">'.lang('plugin/keke_exam', '014').'</a>';
				showtablerow('',array(), $table);
			}
		}
		showsubmit('forumset', 'submit', 'del',' <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier='.$plugin["identifier"].'&pmod=admincp_set&ac=editpic&op=mobile_slider&formhash='.FORMHASH.'" class="addtr">'.lang('plugin/keke_exam', '102').'</a>');
		showtablefooter(); //From: Dism��taobao��com
		showformfooter(); //From: Dism_taobao_com
}elseif ($_GET['op'] == 'mobile_nav') {
		$slider=_exam_get_cache('slider');
		$all_set=_exam_get_set();
		if (submitcheck("forumset")) {
			if(is_array($_GET['delete'])) {
					C::t('#keke_exam#keke_exam_slider')->delete($_GET['delete']);
					_exam_save_cache('slider');
			}
			cpmsg(lang('plugin/keke_exam', '020'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_exam&pmod=admincp_set&op=mobile_nav', 'succeed');
		}
		if (submitcheck("forumsets")) {
			$arr=array(
				'rownum'=>intval($_GET['rownum']),
				'mobilenavrows'=>intval($_GET['mobilenavrows']),
			);
			_exam_insert_set($arr);
			cpmsg(lang('plugin/keke_exam', '020'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_exam&pmod=admincp_set&op=mobile_nav', 'succeed');
		}
		if($_GET['ac']=='editpic'){
			if (!submitcheck("editsubmit")) {
				if($_GET['keyid']){
					$keyid=intval($_GET['keyid']);
					$dataarr=$slider[$keyid];
				}
				showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admincp_set&op=mobile_nav&ac=editpic", 'enctype');
				showtableheader(lang('plugin/keke_exam', '093'));
				showsetting(lang('plugin/keke_exam', '103'),'title',$dataarr['title'],'text');
				showsetting(lang('plugin/keke_exam', '094'),'spic',$dataarr['img'],'filetext');
				showsetting(lang('plugin/keke_exam', '095'),'url',$dataarr['url'],'text');
				showsetting(lang('plugin/keke_exam', '084'),'displayorder',$dataarr['displayorder'],'text');
				echo '<input name="keyid" type="hidden" value="'.$keyid.'" />';
				showsubmit('editsubmit', 'submit', '');
				showtablefooter(); //From: Dism��taobao��com
				showformfooter(); //From: Dism_taobao_com
				exit;
			}else{
				$picurl=_exam_upload_img($_FILES['spic'],220,220);
				$pic=$picurl ? $picurl : $_GET['spic'];
				if(!$pic){
					cpmsg(lang('plugin/keke_exam', '096'), '', 'error');
				}
				$arr=array(
					'id'=>intval($_GET['keyid']),
					'title'=> $_GET['title'],
					'img'=> $pic,
					'url'=> $_GET['url'],
					'type'=>3,
					'displayorder'=> $_GET['displayorder'],
				);
				C::t('#keke_exam#keke_exam_slider')->insert($arr,false,true);
				_exam_save_cache('slider');
				cpmsg(lang('plugin/keke_exam', '020'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier='.$plugin["identifier"].'&pmod=admincp_set&op=mobile_nav', 'succeed');
			}
		}
		showtips('<li>'.lang('plugin/keke_exam', '104').'</li>');
		showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admincp_set&ac=editpic&op=mobile_nav", 'enctype');
		showtableheader(lang('plugin/keke_exam', '105'));
		showsetting(lang('plugin/keke_exam', '106'),array('rownum',array(array('4','4'.lang('plugin/keke_exam', '107')),array('5','5'.lang('plugin/keke_exam', '107')))),($all_set['rownum']?$all_set['rownum']:4),'select');
		showsetting(lang('plugin/keke_exam', '108'),'mobilenavrows',($all_set['mobilenavrows']?$all_set['mobilenavrows']:2),'text');
		showsubmit('forumsets', 'submit');
		showtableheader(lang('plugin/keke_exam', '109'));
		showsubtitle(array('del',lang('plugin/keke_exam', '110'),lang('plugin/keke_exam', '094'),lang('plugin/keke_exam', '095'),lang('plugin/keke_exam', '084'),lang('plugin/keke_exam', '051')));
		foreach($slider as $slider_data){
			if($slider_data['type']==3){
				$table = array(); //From: Dism_taobao-com
				$table[0] = '<input type="checkbox" class="checkbox" name="delete[]" value="'.$slider_data['id'].'" />';
				$table[1] = $slider_data['title'];
				$table[2] = '<img src="'.$slider_data['img'].'" width="50" />';
				$table[3] = '<a href="'.$slider_data['url'].'"/>'.$slider_data['url'].'</a>';
				$table[4] = $slider_data['displayorder'];
				$table[5] = '<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier='.$plugin["identifier"].'&pmod=admincp_set&ac=editpic&op=mobile_nav&keyid='.$slider_data['id'].'&formhash='.FORMHASH.'">'.lang('plugin/keke_exam', '014').'</a>';
				showtablerow('',array(), $table);
			}
		}
		showsubmit('forumset', 'submit', 'del',' <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier='.$plugin["identifier"].'&pmod=admincp_set&ac=editpic&op=mobile_nav&formhash='.FORMHASH.'" class="addtr">'.lang('plugin/keke_exam', '102').'</a>');
		showtablefooter(); //From: Dism��taobao��com
		showformfooter(); //From: Dism_taobao_com
}elseif ($_GET['op'] == 'pc_nav') {
		$slider=_exam_get_cache('slider');
		$all_set=_get_set();
		if (submitcheck("forumset")) {
			if(is_array($_GET['delete'])) {
					C::t('#keke_exam#keke_exam_slider')->delete($_GET['delete']);
					_exam_save_cache('slider');
			}
			cpmsg(lang('plugin/keke_exam', '020'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_exam&pmod=admincp_set&op=mobile_nav', 'succeed');
		}
		if (submitcheck("forumsets")) {
			$arr=array(
				'rownum'=>intval($_GET['rownum']),
				'mobilenavrows'=>intval($_GET['mobilenavrows']),
			);
			_insert_set($arr);
			cpmsg(lang('plugin/keke_exam', '020'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_exam&pmod=admincp_set&op=mobile_nav', 'succeed');
		}
		if($_GET['ac']=='editpic'){
			if (!submitcheck("editsubmit")) {
				if($_GET['keyid']){
					$keyid=intval($_GET['keyid']);
					$dataarr=$slider[$keyid];
				}
				$dataarr['title']=explode('||',$dataarr['title']);
				showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admincp_set&op=pc_nav&ac=editpic", 'enctype');
				showtableheader(lang('plugin/keke_exam', '093'));
				showsetting(lang('plugin/keke_exam', '103'),'title',$dataarr['title'][0],'text');
				showsetting(lang('plugin/keke_exam', '111'),'dec',$dataarr['title'][1],'text');
				showsetting(lang('plugin/keke_exam', '094'),'spic',$dataarr['img'],'filetext');
				showsetting(lang('plugin/keke_exam', '095'),'url',$dataarr['url'],'text');
				showsetting(lang('plugin/keke_exam', '084'),'displayorder',$dataarr['displayorder'],'text');
				echo '<input name="keyid" type="hidden" value="'.$keyid.'" />';
				showsubmit('editsubmit', 'submit', '');
				showtablefooter(); //From: Dism��taobao��com
				showformfooter(); //From: Dism_taobao_com
				exit;
			}else{
				$picurl=_exam_upload_img($_FILES['spic'],220,220);
				$pic=$picurl ? $picurl : $_GET['spic'];
				if(!$pic){
					cpmsg(lang('plugin/keke_exam', '096'), '', 'error');
				}
				$title=$_GET['title'].'||'.$_GET['dec'];
				$arr=array(
					'id'=>intval($_GET['keyid']),
					'title'=> $title,
					'img'=> $pic,
					'url'=> $_GET['url'],
					'type'=>5,
					'displayorder'=> $_GET['displayorder'],
				);
				C::t('#keke_exam#keke_exam_slider')->insert($arr,false,true);
				_exam_save_cache('slider');
				cpmsg(lang('plugin/keke_exam', '020'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier='.$plugin["identifier"].'&pmod=admincp_set&op=pc_nav', 'succeed');
			
			}
		}
		showtips('<li>'.lang('plugin/keke_exam', '104').'</li>');
	
		showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admincp_set&ac=editpic&op=mobile_nav", 'enctype');
	
		showtableheader(lang('plugin/keke_exam', '109'));
		showsubtitle(array('del',lang('plugin/keke_exam', '094'),lang('plugin/keke_exam', '110'),lang('plugin/keke_exam', '095'),lang('plugin/keke_exam', '084'),lang('plugin/keke_exam', '051')));
		
		foreach($slider as $slider_data){
			if($slider_data['type']==5){
				$table = array(); //From: Dism_taobao-com
				$slider_data['title']=explode('||',$slider_data['title']);
				$table[0] = '<input type="checkbox" class="checkbox" name="delete[]" value="'.$slider_data['id'].'" />';
				$table[1] = '<img src="'.$slider_data['img'].'" width="50" />';
				$table[2] = '<b>'.$slider_data['title'][0].'</b><div class="dectxt">'.$slider_data['title'][1].'</div>';
				$table[3] = '<a href="'.$slider_data['url'].'"/>'.$slider_data['url'].'</a>';
				$table[4] = $slider_data['displayorder'];
				$table[5] = '<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier='.$plugin["identifier"].'&pmod=admincp_set&ac=editpic&op=pc_nav&keyid='.$slider_data['id'].'&formhash='.FORMHASH.'">'.lang('plugin/keke_exam', '014').'</a>';
				showtablerow('',array(), $table);
			}
		}
		showsubmit('forumset', 'submit', 'del',' <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier='.$plugin["identifier"].'&pmod=admincp_set&ac=editpic&op=pc_nav&formhash='.FORMHASH.'" class="addtr">'.lang('plugin/keke_exam', '102').'</a><style>.dectxt{color:#999; margin-top:5px}</style>');
		showtablefooter(); //From: Dism��taobao��com
		showformfooter(); //From: Dism_taobao_com
}elseif ($_GET['op'] == 'mobile_discover') {
		$slider=_exam_get_cache('slider');
		if (submitcheck("forumset")) {
			if(is_array($_GET['delete'])) {
					C::t('#keke_exam#keke_exam_slider')->delete($_GET['delete']);
					_exam_save_cache('slider');
			}
			cpmsg(lang('plugin/keke_exam', '020'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_exam&pmod=admincp_set&op=mobile_discover', 'succeed');
		}
		if($_GET['ac']=='editpic'){
			if (!submitcheck("editsubmit")) {
				if($_GET['keyid']){
					$keyid=intval($_GET['keyid']);
					$dataarr=$slider[$keyid];
				}
				showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admincp_set&op=mobile_discover&ac=editpic", 'enctype');
				showtableheader(lang('plugin/keke_exam', '093'));
				showsetting(lang('plugin/keke_exam', '112'),'title',$dataarr['title'],'text');
				showsetting(lang('plugin/keke_exam', '094'),'spic',$dataarr['img'],'filetext');
				showsetting(lang('plugin/keke_exam', '095'),'url',$dataarr['url'],'text');
				showsetting(lang('plugin/keke_exam', '084'),'displayorder',$dataarr['displayorder'],'text');
				echo '<input name="keyid" type="hidden" value="'.$keyid.'" />';
				showsubmit('editsubmit', 'submit', '');
				showtablefooter(); //From: Dism��taobao��com
				showformfooter(); //From: Dism_taobao_com
				exit;
			}else{
				$picurl=_exam_upload_img($_FILES['spic'],120,120);
				$pic=$picurl ? $picurl : $_GET['spic'];
				if(!$pic){
					cpmsg(lang('plugin/keke_exam', '096'), '', 'error');
				}
				$arr=array(
					'id'=>intval($_GET['keyid']),
					'title'=> $_GET['title'],
					'img'=> $pic,
					'url'=> $_GET['url'],
					'type'=>4,
					'displayorder'=> $_GET['displayorder'],
				);
				C::t('#keke_exam#keke_exam_slider')->insert($arr);
				_exam_save_cache('slider');
				cpmsg(lang('plugin/keke_exam', '020'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier='.$plugin["identifier"].'&pmod=admincp_set&op=mobile_discover', 'succeed');
			
			}
		}
		showtips('<li>'.lang('plugin/keke_exam', '104').'</li>');
	
		showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admincp_set&ac=editpic&op=mobile_discover", 'enctype');
		showtableheader('header');
		showsubtitle(array('del',lang('plugin/keke_exam', '110'),lang('plugin/keke_exam', '094'),lang('plugin/keke_exam', '095'),lang('plugin/keke_exam', '084'),lang('plugin/keke_exam', '051')));
		foreach($slider as $slider_data){
			if($slider_data['type']==4){
				$table = array(); //From: Dism_taobao-com
				$table[0] = '<input type="checkbox" class="checkbox" name="delete[]" value="'.$slider_data['id'].'" />';
				$table[1] = $slider_data['title'];
				$table[2] = '<img src="'.$slider_data['img'].'" width="50" />';
				$table[3] = '<a href="'.$slider_data['url'].'"/>'.$slider_data['url'].'</a>';
				$table[4] = $slider_data['displayorder'];
				$table[5] = '<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier='.$plugin["identifier"].'&pmod=admincp_set&ac=editpic&op=mobile_discover&keyid='.$slider_data['id'].'&formhash='.FORMHASH.'">'.lang('plugin/keke_exam', '014').'</a>';
				showtablerow('',array(), $table);
			}
		}
		showsubmit('forumset', 'submit', 'del',' <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier='.$plugin["identifier"].'&pmod=admincp_set&ac=editpic&op=mobile_discover&formhash='.FORMHASH.'" class="addtr">'.lang('plugin/keke_exam', '102').'</a>');
		showtablefooter(); //From: Dism��taobao��com
		showformfooter(); //From: Dism_taobao_com
		
} else if ($_GET['op'] == 'seo') {
	$all_set=_exam_get_set();
	if (!submitcheck("editsubmit")) {
		showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admincp_set&op=seo", '');
		showtableheader(lang('plugin/keke_exam', '113'));
		showsetting('title','index_title',$all_set['index_title'],'text');
		showsetting('keywords','index_keywords',$all_set['index_keywords'],'text');
		showsetting('description','index_description',$all_set['index_description'],'textarea');
		showtableheader(lang('plugin/keke_exam', '114'));
		showsetting(lang('plugin/keke_exam', '115'),'list_index_title',$all_set['list_index_title'],'text');
		showsetting(lang('plugin/keke_exam', '238').'title','list_title',$all_set['list_title'],'text','','',lang('plugin/keke_exam', '240'));
        showsetting(lang('plugin/keke_exam', '239').'title','sublist_title',$all_set['sublist_title'],'text','','',lang('plugin/keke_exam', '116'));
		showsetting('keywords','list_keywords',$all_set['list_keywords'],'text','','',lang('plugin/keke_exam', '116'));
		showsetting('description','list_description',$all_set['list_description'],'textarea');
		showtableheader(lang('plugin/keke_exam', '117'));
		showsetting('title','course_title',$all_set['course_title'],'text','','',lang('plugin/keke_exam', '118'));
		showsetting('keywords','course_keywords',$all_set['course_keywords'],'text','','',lang('plugin/keke_exam', '118'));
		showsetting('description','course_description',$all_set['course_description'],'textarea','','',lang('plugin/keke_exam', '119'));
		showtableheader(lang('plugin/keke_exam', '120'));
		showsetting('title','teacher_title',$all_set['teacher_title'],'text','','',lang('plugin/keke_exam', '121'));
		showsetting('keywords','teacher_keywords',$all_set['teacher_keywords'],'text','','',lang('plugin/keke_exam', '121'));
		showsetting('description','teacher_description',$all_set['teacher_description'],'textarea','','',lang('plugin/keke_exam', '121'));
		showsubmit('editsubmit', 'submit', '');
		showtablefooter(); //From: Dism��taobao��com
		showformfooter(); //From: Dism_taobao_com
		exit;
	}else{
		$arr=array(
			'index_title'=>$_GET['index_title'],
			'index_keywords'=>$_GET['index_keywords'],
			'index_description'=>$_GET['index_description'],
			'list_title'=>$_GET['list_title'],
			'list_index_title'=>$_GET['list_index_title'],
            'sublist_title'=>$_GET['sublist_title'],
			'list_keywords'=>$_GET['list_keywords'],
			'list_description'=>$_GET['list_description'],
			'course_title'=>$_GET['course_title'],
			'course_keywords'=>$_GET['course_keywords'],
			'course_description'=>$_GET['course_description'],
			'teacher_title'=>$_GET['teacher_title'],
			'teacher_keywords'=>$_GET['teacher_keywords'],
			'teacher_description'=>$_GET['teacher_description'],
		);
		_exam_insert_set($arr);
		cpmsg(lang('plugin/keke_exam', '020'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier='.$plugin["identifier"].'&pmod=admincp_set&op=seo', 'succeed');
	}
	
} else if ($_GET['op'] == 'set') {
	$all_set=_exam_get_set();
	if (!submitcheck("editsubmit")) {
		showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admincp_set&op=set", 'enctype');
		showtableheader(lang('plugin/keke_exam', '230'));
		showsetting(lang('plugin/keke_exam', '231'),'logo',$all_set['logo'],'filetext');
		showsubmit('editsubmit', 'submit', '');
		showtablefooter(); //From: Dism��taobao��com
		showformfooter(); //From: Dism_taobao_com
		exit;
	}else{
		$picurl=_exam_upload_img($_FILES['logo']);
		$pic=$picurl ? $picurl : $_GET['logo'];
		if(!$pic){
			cpmsg(lang('plugin/keke_exam', '096'), '', 'error');
		}
		$arr=array(
			'logo'=>$pic
		);
		_exam_insert_set($arr);
		cpmsg(lang('plugin/keke_exam', '020'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier='.$plugin["identifier"].'&pmod=admincp_set&op=set', 'succeed');
	}
	
	
}