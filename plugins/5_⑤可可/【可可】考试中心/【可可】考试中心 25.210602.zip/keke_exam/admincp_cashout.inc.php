<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
	loadcache('plugin'); //d'.'is'.'m.ta'.'obao.com
	include_once DISCUZ_ROOT."source/plugin/keke_exam/function.php";
	$allowget=$_GET['allowget']?true:false;
	if (submitcheck("forumset",$allowget)) {
		if($_GET['cashids']) {
			$cashoutdata=C::t('#keke_exam#keke_exam_cashout')->fetch_all($_GET['cashids']);
			if(is_array($_GET['cashids'])){
				foreach($cashoutdata as $val){
					if(!$val['state']){
						$newcashids[]=$val['id'];
						if($_GET['optype'] == 'ref'){
							cach_log($val['money'],lang('plugin/keke_exam', '059'),$val['uid']);
						}
					}
				}
				$cashids=$newcashids;
			}else{
				$cashids=(!$val['state'])?$_GET['cashids']:'';
			}
			$start=$_GET['optype'] == 'pass'?1:2;
			if($cashids){
				C::t('#keke_exam#keke_exam_cashout')->update($cashids, array('state' => $start,'htime'=>TIMESTAMP));
				foreach($cashoutdata as $cashval){
					$tuids[$cashval['uid']]=$cashval['uid'];
				}
			}
		}else{
			cpmsg(lang('plugin/keke_exam', '060'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_exam&pmod=admincp_cashout', 'error');
		}
		
		if(!$_GET['optype']){
			cpmsg(lang('plugin/keke_exam', '029'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_exam&pmod=admincp_cashout', 'error');
		}
		cpmsg(lang('plugin/keke_exam', '030').count($cashids).lang('plugin/keke_exam', '061'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_exam&pmod=admincp_cashout', 'succeed');
	}
	showtableheader(lang('plugin/keke_exam', '062'));
	showformheader('plugins&operation=config&do='.$pluginid.'&pmod=keke_exam&pmod=admincp_cashout', 'testhd');
	showtablerow('', array('width="50"', 'width="90"'),
		array(
			'<b>'.lang('plugin/keke_exam', '063').'</b>',
			'<select name="state"><option value="0">'.lang('plugin/keke_exam', '031').'</option><option value="9" '.($_GET['state']==9?'selected':'').'>'.lang('plugin/keke_exam', '064').'</option><option value="1" '.($_GET['state']==1?'selected':'').'>'.lang('plugin/keke_exam', '065').'</option><option value="2" '.($_GET['state']==2?'selected':'').'>'.lang('plugin/keke_exam', '066').'</option></select>',
			'<input type="submit" class="btn" id="submit_searchsubmit" name="searchsubmit" value="'.lang('plugin/keke_exam', '042').'">'
		)
    );
	showformfooter(); //From: Dism_taobao_com
	showtablefooter(); //From: Dism��taobao��com
	
	$where='1';$param='';
	if($_GET['state']){
		$_GET['state']=$_GET['state']==9?0:$_GET['state'];
		$where.=" AND state=".intval($_GET['state']);
		$_GET['state']=!$_GET['state']?9:$_GET['state'];
		$param.='&state='.intval($_GET['state']);
	}
	
	showformheader("plugins&operation=config&do=".$plugin["pluginid"]."&identifier=" . $plugin["identifier"] . "&pmod=admincp_cashout");	
	showtableheader(lang('plugin/keke_exam', '067'));
    showsubtitle(array(lang('plugin/keke_exam', '068'), lang('plugin/keke_exam', '069'),lang('plugin/keke_exam', '070'),lang('plugin/keke_exam', '071'),lang('plugin/keke_exam', '072'),lang('plugin/keke_exam', '073'),lang('plugin/keke_exam', '074')));
	$ppp=30;
	$tmpurl=ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_exam&pmod=admincp_cashout'.$param;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	if($allcount = C::t('#keke_exam#keke_exam_cashout')->count_all($where)){
		$cashout_data=C::t('#keke_exam#keke_exam_cashout')->fetch_alls($startlimit,$ppp,$where,$order);
				
		foreach($cashout_data as $key=>$val){
			$op=!$val['state']?'<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_exam&pmod=admincp_cashout&optype=pass&cashids='.$val['id'].'&forumset=TRUE&allowget=1&formhash='.FORMHASH.'" onClick="return confirm( \''.lang('plugin/keke_exam', '075').'\');">'.lang('plugin/keke_exam', '076').'</a> / <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_exam&pmod=admincp_cashout&optype=ref&cashids='.$val['id'].'&forumset=TRUE&allowget=1&formhash='.FORMHASH.'"  onClick="return confirm( \''.lang('plugin/keke_exam', '077').'\');">'.lang('plugin/keke_exam', '078').'</a>':dgmdate($val['htime'], 'Y/m/d H:i');
			
			$table = array(); //From: Dism_taobao-com
			$table[0] = '<input type="checkbox" class="checkbox" name="cashids[]" value="'.$val['id'].'" />';
			$table[1] = '<a href="#">'._getusname($val['uid']).'</a>';
			$table[2] = ''.$val['card'];
			$table[3] = '<b class="money">&yen; '.$val['money'].'</b>';
			$table[4] = dgmdate($val['time'], 'Y/m/d H:i');
			$table[5] = $val['state']==0?'<span class="ds">'.lang('plugin/keke_exam', '079').'</span>':($val['state']==1?'<span class="zc">'.lang('plugin/keke_exam', '080').'</span>':'<span class="jj">'.lang('plugin/keke_exam', '081').'</span>');
			$table[6] = $op;
			showtablerow('',array('','width=""','width=""'), $table);
		}
	}
	$multipage='';
	$multipage = multi($allcount, $ppp, $page, $_G['siteurl'].$tmpurl);
	if($multipage)echo '<tr class="hover"><td colspan="9">'.$multipage.'</td></tr>';
	echo '<style>.ds{color: #F90;}.jj{color: #c30;}.zc{color: #3fd411;}.money{color: #c30;}</style>';
	showsubmit('', '', '<input type="checkbox" name="chkall" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'cashids\')"><label for="chkallIuPN">'.lang('plugin/keke_exam', '068').'</label>&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="optype" id="pass" value="pass" class="radio" /><label for="pass" class="vmiddle">'.lang('plugin/keke_exam', '082').'</label>&nbsp;&nbsp;<input type="radio" name="optype" id="ref" value="ref" class="radio" /><label for="refuse" class="vmiddle">'.lang('plugin/keke_exam', '081').'</label>','<input type="submit" class="btn" id="submit_forumset" name="forumset" onClick="return confirm( \''.lang('plugin/keke_exam', '083').'\');" value="'.lang('plugin/keke_exam', '057').'">');
    showtablefooter(); //From: Dism��taobao��com
	showformfooter(); //From: Dism_taobao_com