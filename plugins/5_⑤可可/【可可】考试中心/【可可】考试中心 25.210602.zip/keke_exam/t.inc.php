<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $_G;
$keke_exam = $_G['cache']['plugin']['keke_exam'];
if(!$_G['uid']) {
	showmessage('not_loggedin', NULL, array(), array('login' => 1));
}
$teacherdata = C::t('#keke_exam#keke_exam_teacher')->fetchfirst_byid($_G['uid']);
if($teacherdata['state']!=1){
	showmessage(lang('plugin/keke_exam', '013'),'plugin.php?id=keke_exam&ac=setin');
}
$ac=$_GET['ac']=$_GET['ac']?dhtmlspecialchars($_GET['ac']):'paper';

$optarr=range('A','Z');
$ppp=20;
$_GET['page']=intval($_GET['page']);
$page = max(1, $_GET['page']);
$startlimit = ($page - 1) * $ppp;

require_once DISCUZ_ROOT.'./source/plugin/keke_exam/function.php';
if($ac=='addquestion'){
	$catedata=C::t('#keke_exam#keke_exam_cate')->fetch_all_by_displayorders('uid='.$_G['uid'].' AND type=1');
	$_GET['type']=$_GET['type']?intval($_GET['type']):1;
    $_GET['from']=intval($_GET['from']);
	$qid=intval($_GET['qid']);
	$_GET['op']=dhtmlspecialchars($_GET['op']);
	$questions=C::t('#keke_exam#keke_exam_question')->fetchfirst_byid($qid);
	$questiondata=unserialize($questions['data']);
    $questions['title']=str_replace(array('<textarea>','</textarea>'),'',$questions['title']);
    foreach ($questiondata as $qk=>$qv){
        $questiondata[$qk]=str_replace(array('<textarea>','</textarea>'),'',$qv);
    }
	$answerarrs=($_GET['type']==1 || $_GET['type']==2)?$questiondata['option']:$questiondata['answer'];
	if($questions['type']==6){
        $subQuestions=C::t('#keke_exam#keke_exam_question')->fetch_all_by_fromqids($qid);
    }
	if($_GET['from']){
        $fromQuestions=C::t('#keke_exam#keke_exam_question')->fetchfirst_byid($_GET['from']);
    }
}elseif($ac=='question'){
	$catedata=C::t('#keke_exam#keke_exam_cate')->fetch_all_by_displayorders('uid='.$_G['uid'].' AND type=1');
	$tmpurl='plugin.php?id=keke_exam:t&ac=question';
	$where='uid='.$_G['uid'].' AND `from` = 0';
	if($_GET['type']){
		$where.=" AND type='".intval($_GET['type'])."'";
		$parameter.='&type='.intval($_GET['type']);
	}
	if($_GET['difficulty']){
		$where.=" AND difficulty='".intval($_GET['difficulty'])."'";
		$parameter.='&difficulty='.intval($_GET['difficulty']);
	}
	if($_GET['kewords']){
		$_GET['keywords']=dhtmlspecialchars($_GET['kewords']);
		$where.=" AND title LIKE '%".addcslashes($_GET['kewords'],'%_')."%'";
		$parameter.='&title='.$_GET['keywords'];
	}
	if($_GET['cateid']){
		$_GET['cateid']=intval($_GET['cateid']);
		$cateids=_getallChildidscateid($catedata,$_GET['cateid']);
		$where.=" AND cate IN (".$cateids.")";
		$parameter.='&cateid='.$_GET['cateid'];
	}

	$order='ORDER BY ID DESC';
	$count_all=C::t('#keke_exam#keke_exam_question')->count_all($where);
	$questionarrs=C::t('#keke_exam#keke_exam_question')->fetch_alls($startlimit,$ppp,$where,$order);
    foreach ($questionarrs as $qsItem) {
        if ($qsItem['type']==6){
            $material[]=$qsItem['id'];
        }
    }
    if($material){
        $countMaterialQs=C::t('#keke_exam#keke_exam_question')->countsub_by_qids($material);
    }
	$tmpurl='plugin.php?id=keke_exam:t&ac=question'.$parameter;
}elseif($ac=='addprice'){	
	$pid=intval($_GET['pid']);
	$pricedata=C::t('#keke_exam#keke_exam_price')->fetch_all('pid='.$pid);
}elseif($ac=='addpaper'){
	$_GET['type']=$_GET['type']?intval($_GET['type']):1;
	$pid=intval($_GET['pid']);
	$paperdata=C::t('#keke_exam#keke_exam_paper')->fetchfirst_byid($pid);
	$paperquestionarr=unserialize($paperdata['data']);
	$questiondata=_getquestion_by_id($paperquestionarr);
}elseif($ac=='paper'){
	$tmpurl='plugin.php?id=keke_exam:t&ac=paper';
	$where='uid='.$_G['uid'];
	$order='ORDER BY ID DESC';
	$count_all=C::t('#keke_exam#keke_exam_paper')->count_all($where);
	$paperarrs=C::t('#keke_exam#keke_exam_paper')->fetch_alls($startlimit,$ppp,$where,$order);
	foreach($paperarrs as $k=>$v){
		$paperarrs[$k]['time']=dgmdate($v['time'], 'Y-m-d H:i:s');
		$paperarrs[$k]['start']=($v['start']?dgmdate($v['start'], 'Y-m-d H:i:s'):$v['start']);
		$paperarrs[$k]['end']=($v['end']?dgmdate($v['end'], 'Y-m-d H:i:s'):$v['end']);
	}
}elseif($ac=='addexam'){
	$pid=intval($_GET['pid']);
	if($pid){
		$paperdata=C::t('#keke_exam#keke_exam_paper')->fetchfirst_byid($pid);
		$startime=$paperdata['start']?dgmdate($paperdata['start'], 'Y-m-d H:i:s'):'';
		$endtime=$paperdata['end']?dgmdate($paperdata['end'], 'Y-m-d H:i:s'):'';
	}
	$catedata=_get_exam_allcatedata();
}elseif($ac=='exam'){
	$tmpurl='plugin.php?id=keke_exam:t&ac=exam';
	$where='uid='.$_G['uid'];
	$order='ORDER BY ID DESC';
	$count_all=C::t('#keke_exam#keke_exam')->count_all($where);
	$examarrs=C::t('#keke_exam#keke_exam')->fetch_alls($startlimit,$ppp,$where,$order);
	foreach($examarrs as $k=>$v){
		$examarrs[$k]['time']=dgmdate($v['time'], 'Y-m-d H:i:s');
		$examarrs[$k]['start']=dgmdate($v['start'], 'Y-m-d H:i:s');
		$examarrs[$k]['end']=dgmdate($v['end'], 'Y-m-d H:i:s');
		$exam[$v['paperid']]=$v['paperid'];
	}
	$paperarr=C::t('#keke_exam#keke_exam_paper')->fetch_all_by_pids($exam);
}elseif($ac=='order'){
	$where=" teacher_uid=".intval($_G['uid'])." AND id NOT LIKE '%ALL%'";
	$tmpurl='plugin.php?id=keke_exam:t&ac=order';
	$count_all=C::t('#keke_exam#keke_exam_order')->count_all($where);
	$orderarr[0]=C::t('#keke_exam#keke_exam_order')->fetch_all_order($startlimit,$ppp,$where,$order);
	
	foreach($orderarr[0] as $k=>$v){
		$pids=explode(',',$v['pid']);
		$orderarr[0][$k]['pid']=$pids;
		$orderarr[0][$k]['time']=dgmdate($v['time'], 'Y-m-d H:i:s');
		$orderarr[0][$k]['pid_total']=count($pids);
		foreach($pids as $vs){
			$pricearr[$vs]=$vs;
		}
	}
	$prices=C::t('#keke_exam#keke_exam_price')->fetch_all_byids($pricearr);
	foreach($prices as $pk=>$pv){
		$pids[$pv['pid']]=$pv['pid'];
	}
	$papers=C::t('#keke_exam#keke_exam_paper')->fetch_all_by_pids($pids);
	
	$multipage = multi($count_all, $ppp, $page, $_G['siteurl'].$tmpurl);
	$orderarr[1]=preg_replace("/\<label\>([\s\S]*)\<\/label\>/i", '', $multipage);
}elseif($ac=='result'){
	$tmpurl='plugin.php?id=keke_exam:t&ac=result';
	$where='pid='.intval($_GET['pid']);
	$order='ORDER BY ID DESC';
	$count_all=C::t('#keke_exam#keke_exam_log')->count_all($where);
	$resultrrs=C::t('#keke_exam#keke_exam_log')->fetch_alls($startlimit,$ppp,$where,$order);
	foreach($resultrrs as $k=>$v){
		$resultrrs[$k]['time']=dgmdate($v['time'], 'Y-m-d H:i:s');
		$resultrrs[$k]['start']=dgmdate($v['start'], 'Y-m-d H:i:s');
		
		$uids[$v['uid']]=$v['uid'];
		$eids[$v['eid']]=$v['eid'];
	}
	$members = C::t('common_member')->fetch_all_username_by_uid($uids);
}elseif($ac=='user'){
	$where=' teacher_uid='.intval($_G['uid']);
	$ppp=15;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	if($_GET['op']=='fans'){
		$where=' tid='.intval($_G['uid']);
		$tmpurl='plugin.php?id=keke_exam:t&ac=user&op=fans';
		$count_all=C::t('#keke_exam#keke_exam_follow')->count_all($where);
		$dataarr=C::t('#keke_exam#keke_exam_follow')->fetch_all_favorites($startlimit,$ppp,$where,$order);
		foreach($dataarr as $key=>$val){
			$userarr[2][$val['uid']]=$val['uid'];
			$dataarr[$key]['times']=dgmdate($val['time'], 'Y-m-d H:i');
		}
		$members = C::t('common_member')->fetch_all_username_by_uid($userarr[2]);
	}

}elseif($ac=='finance'){
	$keke_exam['tixian_type']=unserialize($keke_exam['tixian_type']);
	if($_GET['o']=='set'){
		
	}else{
		$ppp=15;
		$page = max(1, intval($_GET['page']));
		$startlimit = ($page - 1) * $ppp;
		$where='uid='.$_G['uid'];
		$tmpurl='plugin.php?id=keke_exam:t&ac=finance';
		if($_GET['type']==2){
			$tmpurl=$tmpurl.'&type=2';
			$count_all=C::t('#keke_exam#keke_exam_cashout')->count_all($where);
			$dataarr=C::t('#keke_exam#keke_exam_cashout')->fetch_alls($startlimit,$ppp,$where,$order);
		}else{
			$count_all=C::t('#keke_exam#keke_exam_cash')->count_all($where);
			$dataarr=C::t('#keke_exam#keke_exam_cash')->fetch_alls($startlimit,$ppp,$where,$order);
		}
		foreach($dataarr as $key=>$val){
			$dataarr[$key]['times']=dgmdate($val['time'], 'Y-m-d H:i');
		}
		$multipage = multi($count_all, $ppp, $page, $_G['siteurl'].$tmpurl);
		$multipage=preg_replace("/\<label\>([\s\S]*)\<\/label\>/i", '', $multipage);
	}
	
}elseif($ac=='win'){
	if($_GET['o']=='addquestion'){
		$_GET['types']=intval($_GET['types']);
		$_GET['gid']=intval($_GET['gid']);
		$_GET['qsids']=dhtmlspecialchars($_GET['qsids']);
		$_GET['core']=floatval($_GET['core']);
		$_GET['step']=intval($_GET['step']);
	}elseif($_GET['o']=='addqsgro'){
		$_GET['modes']=intval($_GET['modes']);
	}elseif($_GET['o']=='waitprice'){
		$orderdata=C::t('#keke_exam#keke_exam_order')->fetchfirst_byid($_GET['orderid']);
		if($orderdata['teacher_uid']!=$_G['uid']){
			exit(lang('plugin/keke_exam', '015'));
		}
		if($orderdata['state']!=0){
			exit(lang('plugin/keke_exam', '016'));
		}
	}
	$_GET['modes']=intval($_GET['modes']);
	include template('keke_exam:t_win');
	exit;
}
$multipage = multi($count_all, $ppp, $page, $_G['siteurl'].$tmpurl);
$multipage=preg_replace("/\<label\>([\s\S]*)\<\/label\>/i", '', $multipage);
include template('keke_exam:t');