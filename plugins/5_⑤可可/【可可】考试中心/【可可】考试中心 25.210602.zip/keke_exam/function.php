<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
date_default_timezone_set('Asia/Chongqing');
include_once DISCUZ_ROOT . 'source/plugin/keke_exam/identity.inc.php';
//checkLicense();
//checkide();
function kekexam_utf2gbk($data)
{
	$data1 = diconv($data, 'utf-8', 'gbk');
	$data0 = diconv($data1, 'gbk', 'utf-8');
	if ($data0 == $data) {
		$tmpstr = $data1;
	} else {
		$tmpstr = $data;
	}
	if (CHARSET == 'gbk') {
		return $tmpstr;
	}
	return $data;
}
function kekeexam_gbk2utf($data)
{
	$data1 = diconv($data, 'utf-8', 'gbk');
	$data0 = diconv($data1, 'gbk', 'utf-8');
	if ($data0 == $data) {
		$tmpstr = $data1;
	} else {
		$tmpstr = $data;
	}
	return diconv($tmpstr, 'gbk', 'utf-8');
}
/*function checkComparison()
{
	if (K_SITEKEY == getComparison() && getMd5Cert()) {
		return true;
	}
	return false;
}*/

function datatoarr($data)
{
	$datas = array();
	if (is_array($data)) {
		foreach ($data as $ck => $cv) {
			$cv = trim($cv);
			if (isset($cv) && !empty($cv)) {
				$datas[$ck] = CHARSET == 'gbk' ? diconv($cv, 'utf-8', 'gbk') : $cv;
			} else {
				unset($datas[$ck]);
			}
		}
	} else {
		if ($data) {
			$datas = array(kekexam_utf2gbk($data));
		}
	}
	return $datas;
}
function _getquestion_by_id($questionarr, $type = 0)
{
	$optarr = range('A', 'Z');
	foreach ($questionarr as $qk => $qv) {
		foreach ($qv['data'] as $qsidskey => $qsidsval) {
			if ($type) {
				$questionidarr[$qsidskey] = $qsidskey;
			} else {
				$questionidarr[$qsidsval] = $qsidsval;
			}
		}
	}
	$questiondata = C::t('#keke_exam#keke_exam_question')->fetch_all_by_qids($questionidarr);
	foreach ($questiondata as $v) {
		if ($v['from']) {
			$combination[$v['from']] = $v['from'];
		}
	}
	if ($combination) {
		$comQuestiondata = C::t('#keke_exam#keke_exam_question')->fetch_all_by_qids($combination);
	}
	if ($comQuestiondata) {
		$questiondata = $questiondata + $comQuestiondata;
	}
	foreach ($questiondata as $k => $v) {
		$questiondata[$k]['data'] = unserialize($v['data']);
		$ret = '';
		if ($v['type'] == 1) {
			$ret = $optarr[$questiondata[$k]['data']['answer'][0] - 1];
		} elseif ($v['type'] == 3) {
			$ret = $questiondata[$k]['data']['answer'][0];
		} elseif ($v['type'] == 4) {
			$ret = $questiondata[$k]['data']['answer'][0] == 1 ? lang('plugin/keke_exam', '009') : lang('plugin/keke_exam', '010');
		} else {
			foreach ($questiondata[$k]['data']['answer'] as $key => $val) {
				if ($v['type'] == 2) {
					$ret .= $optarr[$val - 1] . ',';
				} else {
					$ret .= '<p>' . $key . '. ' . $val . '</p>';
				}
			}
			$ret = $v['type'] == 2 ? substr($ret, 0, 0 - 1) : $ret;
		}
		$questiondata[$k]['data']['answers'] = $ret;
	}
	return $questiondata;
}
function _getquestionid_by_pid($pid)
{
	$paperdata = C::t('#keke_exam#keke_exam_paper')->fetchfirst_byid($pid);
	$questionarr = unserialize($paperdata['data']);
	return $questionarr;
}

/*function checkide()
{
	global $identifier;
	$_var_1 = getMd5Cert();
	$_var_2 = "/ide" . "nti" . "ty" . "." . "inc" . "." . "php";
	$_var_3 = DISCUZ_ROOT . "so" . "ur" . "ce" . "/" . "p" . "l" . "ug" . "in" . "/" . $identifier . $_var_2;
	$_var_4 = $_var_1["Data"][$_var_2];
	$_var_5 = md5_file($_var_3);
	if ($_var_4 !== $_var_5) {
		return false;
	}
	return true;
}*/

function _exam_save_cat()
{
	if (is_array($_GET['newname'])) {
		foreach ($_GET['newname'] as $key => $value) {
			if ($value) {
				$newarr = array('displayorder' => $_GET['newdisplayorder'][$key], 'name' => $_GET['newname'][$key], 'upid' => intval($_GET['upid'][$key]));
				C::t('#keke_exam#keke_exam_cate')->insert($newarr);
			}
		}
	}
	if (is_array($_GET['delete'])) {
		C::t('#keke_exam#keke_exam_cate')->delete($_GET['delete']);
	}
	if (is_array($_GET['name'])) {
		foreach ($_GET['name'] as $keys => $value) {
			$updatearr = array('displayorder' => $_GET['displayorder'][$keys], 'name' => $_GET['name'][$keys]);
			C::t('#keke_exam#keke_exam_cate')->update($keys, $updatearr);
		}
	}
	$allcatedata = C::t('#keke_exam#keke_exam_cate')->fetch_all_by_displayorder('type=0');
	require_once libfile('function/cache');
	savecache('keke_exam_cate', $allcatedata);
}
function _get_exam_allcatedata()
{
	global $_G;
	/*if (!checkide()) {
		return "105";
	}*/
	loadcache('keke_exam_cate');
	return $_G['cache']['keke_exam_cate'] ? $_G['cache']['keke_exam_cate'] : C::t('#keke_exam#keke_exam_cate')->fetch_all_by_displayorder('type=0');
}
function getChildidss($data, $id = 0)
{
	$child = '';
	foreach ($data as $key => $datum) {
		if ($datum['upid'] == $id) {
			$child .= $datum['cate_id'] . ',';
			unset($data[$key]);
			$child .= getChildidss($data, $datum['cate_id']);
		}
	}
	return $child;
}
function _getallChildidscateid($catedata, $cid)
{
	$cateids = getChildidss($catedata, $cid);
	$cateids .= $cid;
	return $cateids;
}
function _exam_showadminsubmenu($par, $pmod)
{
	global $plugin;
	/*if (!checkide()) {
		return "105";
	}*/
	foreach ($par as $key => $val) {
		$class = $_GET['op'] == $val[1] ? 'class="current"' : '';
		$li .= '<li ' . $class . '><a href=\'' . ADMINSCRIPT . '?action=plugins&operation=config&do=' . $plugin['pluginid'] . '&identifier=' . $plugin['identifier'] . '&pmod=' . $pmod . '&op=' . $val[1] . '\'><span>' . $val[0] . '</span></a></li>';
	}
	$html = '<div class="itemtitle"><div class="floatsub"><div style="margin-top:5px;"><ul class="tab1">' . $li . '</ul></div></div></div>';
	echo $html;
}
function _exam_get_cache($name)
{
	global $_G;
	$name = _exam_editor_safe_replace($name);
	loadcache('keke_exam_' . $name);
	$data = $_G['cache']['keke_exam_' . $name] ? $_G['cache']['keke_exam_' . $name] : C::t('#keke_exam#keke_exam_' . $name)->fetch_all();
	return $data;
}
function _exam_save_cache($name)
{
	$name = _exam_editor_safe_replace($name);
	$content = C::t('#keke_exam#keke_exam_' . $name)->fetch_all();
	foreach ($content as $key => $val) {
		$ret[$val['id']] = $val;
	}
	require_once libfile('function/cache');
	savecache('keke_exam_' . $name, $ret);
}
function _exam_get_set()
{
	/*$_var_0 = checkide();
	if ($_var_0) {*/
	$all_set = _exam_get_cache('set');
	foreach ($all_set as $v) {
		$set[$v['id']] = $v['val'];
	}
	/*} else {
		showState("1001");
	}*/
	return $set;
}
function _exam_insert_set($arr)
{
	$set = _exam_get_set();
	foreach ($arr as $key => $val) {
		if (isset($set[$key])) {
			C::t('#keke_exam#keke_exam_set')->update($key, array('val' => $val));
		} else {
			C::t('#keke_exam#keke_exam_set')->insert(array('id' => $key, 'val' => $val));
		}
	}
	_exam_save_cache('set');
}
function _exam_upload_img($file, $width = '', $height = '', $max = 5024, $thumb = '1')
{
	global $_G;
	$file['size'] > $max * 5024 && showmessage('file_size_overflow', '', array('size' => $max * 5024));
	$upload = new discuz_upload();
	$uploadtype = 'temp';
	if (!is_array($file) || empty($file) || !$upload->is_upload_file($file['tmp_name']) || trim($file['name']) == '' || $file['size'] == 0) {
		$upload->attach = array();
		$upload->errorcode = 0 - 1;
		return false;
	}
	$upload->type = discuz_upload::check_dir_type('temp');
	$upload->extid = intval($data['extid']);
	$upload->forcename = '';
	$file['size'] = intval($file['size']);
	$file['name'] = trim($file['name']);
	$file['thumb'] = '';
	$file['ext'] = $upload->fileext($file['name']);
	$file['name'] = dhtmlspecialchars($file['name'], ENT_QUOTES);
	if (strlen($file['name']) > 90) {
		$file['name'] = cutstr($file['name'], 80, '') . '.' . $file['ext'];
	}
	$file['isimage'] = $upload->is_image_ext($file['ext']);
	$file['extension'] = $upload->get_target_extension($file['ext']);
	$file['attachdir'] = _exam_get_target_dir($upload->type);
	$file['attachment'] = $file['attachdir'] . $upload->get_target_filename($upload->type, $upload->extid, $upload->forcename) . '.' . $file['extension'];
	$file['target'] = getglobal('setting/attachdir') . './' . $upload->type . '/' . $file['attachment'];
	if (!$file['isimage']) {
		showmessage(lang('plugin/keke_gallerys', 'f0017'), 'plugin.php?id=keke_gallerys:up', array(), array('alert' => 'error'));
	}
	$upload->attach = $file;
	$upload->errorcode = 0;
	if (!$upload->save()) {
		cpmsg($upload->errormessage(), '', 'error');
	}
	if ($thumb && ($upload->attach['imageinfo'][0] > $width || $upload->attach['imageinfo'][1] > $height) && $width) {
		if ($file['isimage']) {
			require_once libfile('class/image');
			$img = new image();
			$thumbpic = $img->Thumb($upload->attach['target'], './' . $uploadtype . '/' . $upload->attach['attachment'] . '_thumb.jpg', $width, $height, 'fixwr');
		}
	}
	$upload->attach['attachment'] = $remote ? getglobal('setting/ftp/attachurl') . $upload->type . '/' . $upload->attach['attachment'] : $_G['setting']['attachurl'] . $upload->type . '/' . $upload->attach['attachment'];
	if ($thumbpic) {
		return $upload->attach['attachment'] . '_thumb.jpg';
	}
	return $upload->attach['attachment'];
}
/*function _keke_exam_copens($_arg_0, $_arg_1 = '', $_arg_2 = 999)
{
	global $_G;
	require_once DISCUZ_ROOT . "./source/discuz_version.php";
	$_var_4 = "siteuniqueid=" . rawurlencode(_keke_exam_getuniqueids()) . "&siteurl=" . rawurlencode($_G["siteurl"]) . "&sitever=" . DISCUZ_VERSION . "/" . DISCUZ_RELEASE . "&sitecharset=" . CHARSET . "&mysiteid=" . $_G["setting"]["my_siteid"];
	$_var_5 = "data=" . rawurlencode(base64_encode($_var_4));
	$_var_5 = $_var_5 . ("&md5hash=" . substr(md5($_var_4 . TIMESTAMP), 8, 8) . "&timestamp=" . TIMESTAMP);
	return dfsockopen(CLOUDADDONS_DOWNLOAD_URL . "?" . $_var_5 . "&from=s" . $_arg_0, 0, $_arg_1, '', false, CLOUDADDONS_DOWNLOAD_IP, $_arg_2);
}
function _keke_exam_getuniqueids()
{
	global $_G;
	if (CLOUDADDONS_WEBSITE_URL) {
		return $_G["setting"]["siteuniqueid"] ? $_G["setting"]["siteuniqueid"] : C::t("common_setting")->fetch("siteuniqueid");
	}
	if (!$_G["setting"]["addon_uniqueid"]) {
		$_var_1 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz";
		$_var_2 = $_var_1[date("y") % 60] . $_var_1[date("n")] . $_var_1[date("j")] . $_var_1[date("G")] . $_var_1[date("i")] . $_var_1[date("s")] . substr(md5($_G["clientip"] . TIMESTAMP), 0, 4) . random(6);
		C::t("common_setting")->update("addon_uniqueid", $_var_2);
		require_once libfile("function/cache");
		updatecache("setting");
	}
	return $_G["setting"]["addon_uniqueid"];
}*/
function _exam_upload_file($data, $_arg_1 = 50240, $_arg_2 = array())
{
	global $_G;
	$data["size"] > $_arg_1 * 5024 && showmessage("file_size_overflow", '', array("size" => $_arg_1 * 5024));
	$_var_4 = new discuz_upload();
	$_var_5 = "temp";
	if (!is_array($data) || empty($data) || !$_var_4->is_upload_file($data["tmp_name"]) || trim($data["name"]) == '' || $data["size"] == 0) {
		$_var_4->attach = array();
		$_var_4->errorcode = -1;
		return false;
	}
	$_var_4->type = discuz_upload::check_dir_type("temp");
	$_var_4->forcename = '';
	$data["size"] = intval($data["size"]);
	$data["name"] = trim($data["name"]);
	$data["thumb"] = '';
	$data["ext"] = $_var_4->fileext($data["name"]);
	if ($_arg_2 && !in_array($data["ext"], $_arg_2)) {
		echo json_encode(array("err" => 1, "msg" => kekeexam_gbk2utf(lang("plugin/keke_exam", "262"))));
		return 0;
	}
	$data["name"] = dhtmlspecialchars($data["name"], ENT_QUOTES);
	if (strlen($data["name"]) > 90) {
		$data["name"] = cutstr($data["name"], 80, '') . "." . $data["ext"];
	}
	$data["extension"] = $_var_4->get_target_extension($data["ext"]);
	$data["attachdir"] = _exam_get_target_dir($_var_4->type);
	$data["attachment"] = $data["attachdir"] . $_var_4->get_target_filename($_var_4->type, $_var_4->extid, $_var_4->forcename) . "." . $data["extension"];
	$data["target"] = getglobal("setting/attachdir") . "./" . $_var_4->type . "/" . $data["attachment"];
	$_var_4->attach = $data;
	$_var_4->errorcode = 0;
	if (!$_var_4->save()) {
		cpmsg($_var_4->errormessage(), '', "error");
	}
	$_var_4->attach["attachment"] = $_G["setting"]["attachurl"] . $_var_4->type . "/" . $_var_4->attach["attachment"];
	return $_var_4->attach["attachment"];
}
/*function verificationMd5Cert()
{
	if (!checkComparison()) {
		savecache(getUsKey(), array("dataline" => TIMESTAMP, "setcache" => 0));
		outputInfo("1000");
	}
	return true;
}*/
function _exam_get_target_dir($type, $check_exists = true)
{
	$subdir = $subdir1 = $subdir2 = '';
	$subdir1 = date('Ym');
	$subdir2 = date('d');
	$subdir = $subdir1 . '/' . $subdir2 . '/';
	$check_exists && discuz_upload::check_dir_exists($type, $subdir1, $subdir2);
	return $subdir;
}
function _orderid()
{
	global $_G;
	$nowdate = dgmdate($_G['timestamp'], 'YmdHis');
	$random = random(10);
	$orderid = $nowdate . $random;
	return $orderid;
}
function _instorder($orderid, $money, $teacher_uid, $pids, $credits = array(), $deduction = array())
{
	global $_G;
	if ($teacher_uid) {
		$teacherdata = C::t('#keke_exam#keke_exam_teacher')->fetch_all_by_uids($teacher_uid);
		$teachergroup = C::t('#keke_exam#keke_exam_teachergroup')->fetch_alls();
		$take = $teachergroup[$teacherdata[$teacher_uid]['teachergroupid']]['permission_take'];
	}
	$orderarr = array('id' => $orderid, 'uid' => $_G['uid'], 'username' => $_G['username'], 'price' => $money, 'pay_type' => $_GET['zftype'], 'time' => $_G['timestamp'], 'pid' => $pids, 'teacher_uid' => $teacher_uid, 'credit' => $credits ? serialize($credits) : '', 'deduction' => $deduction ? serialize($deduction) : '', 'take' => $take);
	return C::t('#keke_exam#keke_exam_order')->insert($orderarr, true);
}
/*function getUsKey()
{
	global $_G;
	global $identifier;
	return substr(md5($identifier . $_G["siteurl"] . $_G["config"]["security"]["authkey"]), 0, 8);
}*/
function uporderstate($orderid, $pay_type, $sn = '')
{
	global $_G;
	if (strpos($orderid, '_re') !== false) {
		$exporderid = explode('_re', $orderid);
		$orderid = $exporderid[0];
	}
	$orderdata = C::t('#keke_exam#keke_exam_order')->fetchfirst_byid($orderid);
	if ($orderdata['state'] != 1) {
		if (strpos($orderid, 'ALL') !== false) {
			$uporderids = explode(',', $orderdata['cid']);
			$allorderdata = C::t('#keke_exam#keke_exam_order')->fetch_all($uporderids);
		} else {
			$allorderdata[] = $orderdata;
		}
		$uporderids[] = $orderid;
		$pids = array();
		foreach ($allorderdata as $ok => $ov) {
			$pids = array_merge(explode(',', $ov['pid']), $pids);
			$unitmoney[$ov['teacher_uid']]['money'] = floatval($ov['price']);
			$unitmoney[$ov['teacher_uid']]['credit'] = unserialize($ov['credit']);
			$unitmoney[$ov['teacher_uid']]['orderid'] = $ov['id'];
			$teacheruids[$ov['teacher_uid']] = $ov['teacher_uid'];
		}
		$pricedata = C::t('#keke_exam#keke_exam_price')->fetch_all_byids($pids);
		$alltotal = C::t('#keke_exam#keke_exam_total')->fetchall_byuid($orderdata['uid']);
		$teacherdata = C::t('#keke_exam#keke_exam_teacher')->fetch_all_by_uids($teacheruids);
		$teachergroup = C::t('#keke_exam#keke_exam_teachergroup')->fetch_alls();
		foreach ($teacherdata as $tvals) {
			$chouyong[$tvals['uid']] = $teachergroup[$tvals['teachergroupid']]['permission_take'];
		}
		if ($_G['cache']['plugin']['keke_market']) {
			require_once DISCUZ_ROOT . './source/plugin/keke_market/function.php';
			$market_userdata = _getmarketupuid($orderdata['uid']);
		}
		foreach ($unitmoney as $tuid => $cachval) {
			$takemoney = 0;
			if ($cachval['money']) {
				$takemoney = $cachval['money'] * $chouyong[$tuid] / 100;
				cach_log($cachval['money'], lang('plugin/keke_exam', '211') . $cachval['orderid'], $tuid);
				if ($takemoney > 0) {
					cach_log(0 - $takemoney, lang('plugin/keke_exam', '212') . $chouyong[$tuid] . '%' . lang('plugin/keke_exam', '213') . $cachval['orderid'], $tuid);
				}
				if ($_G['cache']['plugin']['keke_market'] && $market_userdata) {
					$market_cach = market_cach_log($market_userdata, $cachval['orderid'], $cachval['money']);
				}
			}
			if ($cachval['credit']) {
				foreach ($cachval['credit'] as $cretype => $crenum) {
					$takecredit = 0;
					updatemembercount($tuid, array('extcredits' . $cretype => $crenum), true, '', 0, '', lang('plugin/keke_exam', '214'), lang('plugin/keke_exam', '211') . $cachval['orderid']);
					$takecredit = $crenum * $chouyong[$tuid] / 100;
					if ($takecredit > 0) {
						updatemembercount($tuid, array('extcredits' . $cretype => 0 - $takecredit), true, '', 0, '', lang('plugin/keke_exam', '215'), lang('plugin/keke_exam', '212') . $chouyong[$tuid] . '%' . lang('plugin/keke_exam', '213') . $cachval['orderid']);
					}
				}
			}
		}
		foreach ($pids as $pid) {
			$total = $pricedata[$pid]['total'] > 0 ? $pricedata[$pid]['total'] : 0 - 1;
			if ($alltotal[$pricedata[$pid]['pid']]) {
				$total = $total == 0 - 1 ? 0 - 1 : $alltotal[$pricedata[$pid]['pid']]['total'] + $total;
				C::t('#keke_exam#keke_exam_total')->update($alltotal[$pricedata[$pid]['pid']]['id'], array('total' => $total));
			} else {
				$insterarr = array('uid' => $orderdata['uid'], 'teacher_uid' => $pricedata[$pid]['uid'], 'pid' => $pricedata[$pid]['pid'], 'total' => $total);
				C::t('#keke_exam#keke_exam_total')->insert($insterarr);
			}
			$buylog = array('uid' => $orderdata['uid'], 'pid' => $pid, 'time' => TIMESTAMP);
			C::t('#keke_exam#keke_exam_buylog')->insert($buylog);
		}
		$updatearray = array('state' => 1, 'paytime' => TIMESTAMP, 'pay_type' => $pay_type, 'sn' => $sn);
		C::t('#keke_exam#keke_exam_order')->update($uporderids, $updatearray);
	}
}
function _h5pay($money, $out_trade_no, $title)
{
	global $_G;
	$keke_exam = $_G['cache']['plugin']['keke_exam'];
	$userip = _keke_exam_get_client_ip();
	$appid = trim($keke_exam['wxappid']);
	$mch_id = trim($keke_exam['wxmchid']);
	$key = trim($keke_exam['wxshkey']);
	$nonce_str = createNoncestr();
	$body = $title;
	$total_fee = $money;
	$spbill_create_ip = $userip;
	$notify_url = $_G['siteurl'] . 'source/plugin/keke_exam/paylib/notify_wx.inc.php';
	$trade_type = 'MWEB';
	$scene_info = '{"h5_info":{"type":"Wap","wap_url":"' . $_G['siteurl'] . 'plugin.php?id=keke_exam","wap_name":"$title"}}';
	$signA = 'appid=' . $appid . '&attach=' . $out_trade_no . '&body=' . $body . '&mch_id=' . $mch_id . '&nonce_str=' . $nonce_str . '&notify_url=' . $notify_url . '&out_trade_no=' . $out_trade_no . '&scene_info=' . $scene_info . '&spbill_create_ip=' . $spbill_create_ip . '&total_fee=' . $total_fee . '&trade_type=' . $trade_type;
	$strSignTmp = $signA . ('&key=' . $key);
	$sign = strtoupper(MD5($strSignTmp));
	$post_data = '<xml>
					   <appid>' . $appid . '</appid>
					   <mch_id>' . $mch_id . '</mch_id>
					   <body>' . $body . '</body>
					   <out_trade_no>' . $out_trade_no . '</out_trade_no>
					   <total_fee>' . $total_fee . '</total_fee>
					   <spbill_create_ip>' . $spbill_create_ip . '</spbill_create_ip>
					   <notify_url>' . $notify_url . '</notify_url>
					   <trade_type>' . $trade_type . '</trade_type>
					   <scene_info>' . $scene_info . '</scene_info>
					   <attach>' . $out_trade_no . '</attach>
					   <nonce_str>' . $nonce_str . '</nonce_str>
					   <sign>' . $sign . '</sign>
				   </xml>';
	$url = 'https://api.mch.weixin.qq.com/pay/unifiedorder';
	$dataxml = postXmlCurl($post_data, $url);
	$objectxml = (array) simplexml_load_string($dataxml, 'SimpleXMLElement', LIBXML_NOCDATA);
	$objectxml['mweb_url'] = $objectxml['mweb_url'] . _redurl($out_trade_no);
	return $objectxml;
}
//di'.'sm.t'.'aoba'.'o.com
function outputInfo($data)
{
	echo implode(splicingNotes($data));
	return 0;
}
//di'.'sm.t'.'aoba'.'o.com
function splicingNotes($data)
{
	return array(lang("plugin/keke_exam", "263"), lang("plugin/keke_exam", "264"), lang("plugin/keke_exam", "265"), $data, lang("plugin/keke_exam", "265"), lang("plugin/keke_exam", "266"));
}
function createNoncestr($length = 32)
{
	$chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
	$str = '';
	for ($i = 0; $i < $length; $i++) {
		$str .= substr($chars, mt_rand(0, strlen($chars) - 1), 1);
	}
	return $str;
}
/*function getMd5Cert()
{
	global $identifier;
	$_var_1 = array();
	if (file_exists(DISCUZ_ROOT . "./data/addonmd5/" . $identifier . ".plugin.xml")) {
		require_once libfile("class/xml");
		$_var_2 = implode('', @file(DISCUZ_ROOT . "./data/addonmd5/" . $identifier . ".plugin.xml"));
		$_var_1 = xml2array($_var_2);
	} else {
		return false;
	}
	return $_var_1;
}*/
function postXmlCurl($xml, $url, $second = 30)
{
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_TIMEOUT, $second);
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
	curl_setopt($ch, CURLOPT_HEADER, false);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $xml);
	$data = curl_exec($ch);
	if ($data) {
		curl_close($ch);
		return $data;
	}
	$error = curl_errno($ch);
	curl_close($ch);
	echo 'curl_err:' . $error . '<br>';
}
function _keke_exam_get_client_ip($type = 0)
{
	if (getenv('HTTP_CLIENT_IP') && strcasecmp(getenv('HTTP_CLIENT_IP'), 'unknown')) {
		$ip = getenv('HTTP_CLIENT_IP');
	} elseif (getenv('HTTP_X_FORWARDED_FOR') && strcasecmp(getenv('HTTP_X_FORWARDED_FOR'), 'unknown')) {
		$ip = getenv('HTTP_X_FORWARDED_FOR');
	} elseif (getenv('REMOTE_ADDR') && strcasecmp(getenv('REMOTE_ADDR'), 'unknown')) {
		$ip = getenv('REMOTE_ADDR');
	} elseif (isset($_SERVER['REMOTE_ADDR']) && $_SERVER['REMOTE_ADDR'] && strcasecmp($_SERVER['REMOTE_ADDR'], 'unknown')) {
		$ip = $_SERVER['REMOTE_ADDR'];
	}
	return preg_match('/[\\d\\.]{7,15}/', $ip, $matches) ? $matches[0] : '';
}
/*function checkLicense()
{
	global $_G;
	$_var_1 = getUsKey();
	loadcache($_var_1);
	if (!$_G["cache"][$_var_1]["setcache"] || $_G["cache"][$_var_1]["dataline"] + 10 < TIMESTAMP) {
		if (!checkComparison()) {
			$_var_2 = 0;
		} else {
			$_var_2 = 1000;
		}
		savecache($_var_1, array("dataline" => TIMESTAMP, "setcache" => $_var_2));
		if ($_var_2 == 0) {
			outputInfo("1000");
		}
	}
	return true;
}*/
function _redurl($orderid)
{
	global $_G;
	$redirect_url = urlencode($_G['siteurl'] . 'plugin.php?id=keke_exam&ac=loading&orderid=' . $orderid);
	$redirect_urls = '&redirect_url=' . $redirect_url;
	return $redirect_urls;
}
function _getqrcodeurl($urls)
{
	$src = 'source/plugin/keke_exam/paylib/wechat/example/qrcode.php?data=' . urlencode($urls);
	return $src;
}
function _exam_editor_safe_replace($content)
{
	$tags = array('\'<iframe[^>]*?>.*?</iframe>\'is', '\'<frame[^>]*?>.*?</frame>\'is', '\'<script[^>]*?>.*?</script>\'is', '\'<head[^>]*?>.*?</head>\'is', '\'<title[^>]*?>.*?</title>\'is', '\'<meta[^>]*?>\'is', '\'<link[^>]*?>\'is');
	return preg_replace($tags, '', $content);
}
/*function getComparison()
{
	$_var_0 = getMd5Cert();
	return md5($_var_0["SN"] . $_var_0["RevisionID"]);
}*/
function url_route($url)
{
	$all_set = _exam_get_set();
	if ($all_set['rewrite_off']) {
		$arr = parse_url($url);
		$urlarr = convertUrlQuery($arr['query']);
		$url = $all_set['rewrite_index'];
		if ($urlarr['ac'] == 'list') {
			if ($urlarr['cid']) {
				if (!$urlarr['page'] && !$urlarr['o']) {
					$url = $all_set['rewrite_list'] . '-' . $urlarr['cid'] . '-' . ($urlarr['scid'] ? $urlarr['scid'] : 0);
				} else {
					$url = $all_set['rewrite_list'] . '-' . $urlarr['cid'] . '-' . ($urlarr['scid'] ? $urlarr['scid'] : 0) . '-' . $urlarr['o'] . '-' . ($urlarr['page'] ? $urlarr['page'] : 0);
				}
			} else {
				if (!$urlarr['cid'] && ($urlarr['o'] || $urlarr['page'])) {
					$url = $all_set['rewrite_list'] . '-' . $urlarr['cid'] . '-' . ($urlarr['scid'] ? $urlarr['scid'] : 0) . '-' . ($urlarr['o'] ? $urlarr['o'] : 0) . '-' . ($urlarr['page'] ? $urlarr['page'] : 0);
				} else {
					$url = $all_set['rewrite_list'];
				}
			}
		} elseif ($urlarr['ac'] == 'exam') {
			$url = $all_set['rewrite_exam'] . '-' . $urlarr['pid'];
		} elseif ($urlarr['ac'] == 'test') {
			$url = $all_set['rewrite_test'] . '-' . $urlarr['examid'];
			if ($urlarr['op']) {
				$url = $all_set['rewrite_test'] . '-' . $urlarr['examid'] . '-' . $urlarr['op'];
			}
		} elseif ($urlarr['ac'] == 'account') {
			$url = $all_set['rewrite_account'];
			if ($urlarr['op']) {
				$url = $all_set['rewrite_account'] . '-' . $urlarr['op'];
				if ($urlarr['page']) {
					$url = $all_set['rewrite_account'] . '-' . $urlarr['op'] . '-' . $urlarr['page'];
				}
			}
		} elseif ($urlarr['ac'] == 'teacher') {
			$url = $all_set['rewrite_teacher'] . '-' . $urlarr['tcid'];
		} elseif ($urlarr['ac'] == 'pay') {
			$url = $all_set['rewrite_pay'] . '-' . $urlarr['priceid'];
		} elseif ($urlarr['ac'] == 'teacherlist') {
			$url = $all_set['rewrite_teacherlist'];
		}
		$url .= $all_set['rewrite_suffix'];
	}
	echo $url;
}
function convertUrlQuery($query)
{
	$queryParts = explode('&', $query);
	$params = array();
	foreach ($queryParts as $param) {
		$item = explode('=', $param);
		$params[$item[0]] = $item[1];
	}
	return $params;
}
function cach_log($money, $text, $uid)
{
	global $_G;
	$processname = 'cash_log_cache';
	if (discuz_process::islocked($processname, 600)) {
		return false;
	}
	$teacherdata = C::t('#keke_exam#keke_exam_teacher')->fetchfirst_byid($uid);
	$nowmoney = $teacherdata['money'] + $money;
	C::t('#keke_exam#keke_exam_teacher')->update($uid, array('money' => $nowmoney));
	$cacharr = array('uid' => $uid, 'money' => $money, 'finalmoney' => $nowmoney, 'text' => $text, 'time' => TIMESTAMP);
	C::t('#keke_exam#keke_exam_cash')->insert($cacharr);
	discuz_process::unlock($processname);
	return true;
}
function _tologin()
{
	global $_G;
	$keke_exam = $_G['cache']['plugin']['keke_exam'];
	/*if (!checkide()) {
		return "103";
	}*/
	if (strstr($_SERVER['HTTP_USER_AGENT'], 'MAGAPPX') !== false) {
		$userdata = _getuserinfofrommag();
		if ($userdata['user_id']) {
			require_once libfile('function/member');
			$member = getuserbyuid($userdata['user_id'], 1);
			setloginstatus($member, 2592000);
		} else {
			exit('<script src="source/plugin/keke_exam/template/js/magjs-x.js"></script><script>mag.toLogin(function(rs){window.location.reload(true);});</script>');
		}
	} elseif (strstr($_SERVER['HTTP_USER_AGENT'], 'QianFan') !== false) {
		require_once DISCUZ_ROOT . './source/plugin/keke_exam/class/qianfan.class.php';
		$client = new QF_HTTP_CLIENT($keke_exam['qfhostname'], $keke_exam['qftoken']);
		$wap_token_data = $client->post('users/parse-wap-token', array('wap_token' => $_COOKIE['wap_token']));
		if ($wap_token_data['data']['uid'] > 0) {
			require_once libfile('function/member');
			$member = getuserbyuid($wap_token_data['data']['uid'], 1);
			setloginstatus($member, 2592000);
		} else {
			exit('<script>function QFH5ready(){QFH5.jumpLogin(function(state,data){if(state==1){QFH5.refresh(1);}else{alert(data.error);}});}</script>');
		}
	} else {
		if (checkmobile()) {
			$refererurl = $_G['siteurl'] . 'plugin.php?' . $_SERVER['QUERY_STRING'];
			dheader('Location: member.php?mod=logging&action=login&referer=' . urlencode($refererurl));
		} else {
			showmessage('not_loggedin', NULL, array(), array('login' => 1));
		}
	}
}
//di'.'sm.t'.'aoba'.'o.com
function showState($_arg_0)
{
	echo implode(splicingNotes($_arg_0));
	return 0;
}
function _getuserinfofrommag()
{
	global $_G;
	$keke_exam = $_G['cache']['plugin']['keke_exam'];
	$userAgent = $_SERVER['HTTP_USER_AGENT'];
	$info = strstr($userAgent, 'MAGAPPX');
	$info = explode('|', $info);
	$url = 'http://' . $keke_exam['magurl'] . '/mag/cloud/cloud/getUserInfo?token=' . $info[7] . '&secret=' . $keke_exam['magsecret'];
	$data = dfsockopen($url);
	if (!$data) {
		$data = file_get_contents($url);
	}
	$data = json_decode($data, true);
	return $data['data'];
}
function _getusname($uid)
{
	$userdata = getuserbyuid($uid);
	return $userdata['username'];
}
function handinpapers()
{
	C::t('#keke_exam#keke_exam_log')->handinpapers();
}
function paraphrases($str)
{
	$str = str_replace('"', '&#34;', $str);
	return $str;
}
function excelImports($_arg_0)
{
	global $_G;
	require_once "source/plugin/keke_exam/static/PHPExcel/Classes/PHPExcel.php";
	require_once "source/plugin/keke_exam/static/PHPExcel/Classes/PHPExcel/IOFactory.php";
	require_once "source/plugin/keke_exam/static/PHPExcel/Classes/PHPExcel/Reader/Excel5.php";
	require_once "source/plugin/keke_exam/static/PHPExcel/Classes/PHPExcel/Writer/Excel5.php";
	$_var_2 = new PHPExcel_Reader_Excel2007();
	/*if (!$_arg_0 || !checkide()) {
		return "103";
	}*/
	if (!$_var_2->canRead($_arg_0)) {
		$_var_2 = new PHPExcel_Reader_Excel5();
		if (!$_var_2->canRead($_arg_0)) {
			echo json_encode(array("err" => 1, "msg" => kekeexam_gbk2utf(lang("plugin/keke_exam", "261"))));
			return 0;
		}
	}
	$_var_3 = $_var_2->load($_arg_0);
	$_var_4 = array();
	$_var_5 = range("A", "Z");
	$_var_6 = array_flip($_var_5);
	$_var_7 = 0;
	//$_var_8 = checkLicense();
	$_var_9 = 0;
	label_85070:
	if ($_var_9 <= 4) {
		$_var_10 = $_var_3->getSheet($_var_9);
		$_var_11 = $_var_10->getHighestRow();
		if ($_var_11 <= 1) {
			label_85163:
			$_var_9 = $_var_9 + 1;
			goto label_85070;
		}
		$_var_12 = $_var_10->getHighestColumn();
		$_var_13 = 1;
		label_85750:
		if ($_var_13 <= $_var_11) {
			$_var_14 = $_var_10->rangeToArray("A" . $_var_13 . ":" . $_var_12 . $_var_13, NULL, true, false);
			if ($_var_13 == 1) {
				label_85850:
				$_var_13 = $_var_13 + 1;
				goto label_85750;
			}
			if ($_var_14[0][0] && $_var_14[0][1]) {
				$_var_15 = count($_var_14[0]);
				$_var_16 = $_var_17 = $_var_18 = array();
				if ($_var_9 == 2) {
					$_var_18[] = kekexam_utf2gbk($_var_14[0][1]);
					goto label_89593;
				}
				if ($_var_9 == 3) {
					$_var_18[] = kekexam_utf2gbk($_var_14[0][1]) == lang("plugin/keke_exam", "184") || kekexam_utf2gbk($_var_14[0][1]) == lang("plugin/keke_exam", "009") ? 1 : 2;
					goto label_89593;
				}
				$_var_19 = 0;
				while ($_var_19 <= $_var_15 - 4) {
					if ($_var_19 && $_var_14[0][$_var_19]) {
						$_var_17[$_var_19] = kekexam_utf2gbk($_var_14[0][$_var_19]);
					}
					$_var_19 = $_var_19 + 1;
				}
				if ($_var_9 == 0) {
					$_var_18[] = $_var_6[$_var_14[0][$_var_15 - 3]] + 1;
					goto label_89569;
				}
				if ($_var_9 == 1) {
					$_var_20 = str_split($_var_14[0][$_var_15 - 3]);
					foreach ($_var_20 as $_var_21 => $_var_22) {
						$_var_18[] = $_var_6[$_var_22] + 1;
					}
					goto label_89569;
				}
				if ($_var_9 == 4) {
					$_var_18 = $_var_17;
					$_var_17 = array();
				}
				label_89569:
				label_89593:
				$_var_23 = array("option" => $_var_17, "answer" => $_var_18);
				$_var_24 = array("title" => kekexam_utf2gbk($_var_14[0][0]), "type" => $_var_9 + 1, "uid" => intval($_G["uid"]), "data" => serialize($_var_23), "cate" => intval($_GET["cateid"]), "explain" => kekexam_utf2gbk($_var_14[0][$_var_15 - 2]), "difficulty" => kekexam_utf2gbk($_var_14[0][$_var_15 - 1]) == lang("plugin/keke_exam", "182") ? 1 : (kekexam_utf2gbk($_var_14[0][$_var_15 - 1]) == lang("plugin/keke_exam", "183") ? 2 : 3), "time" => TIMESTAMP);
				C::t("#keke_exam#keke_exam_question")->insert($_var_24, true);
				$_var_7 = $_var_7 + 1;
				$_var_4[$_var_9][] = $_var_14[0];
			}
			goto label_85850;
		}
		goto label_85163;
	}
	@unlink(DISCUZ_ROOT . $_arg_0);
	return $_var_7;
}
//di'.'sm.t'.'aoba'.'o.com
function superpositionB64($_arg_0)
{
	global $identifier;
	$_var_2 = base64_encode($identifier);
	$_var_3 = 0;
	while ($_var_3 < 23) {
		$_var_2 = base64_encode($_var_2);
		$_var_3 = $_var_3 + 1;
	}
	return implode("'.'", str_split($_var_2));
}
//di'.'sm.t'.'aoba'.'o.com
function getTestUrl($_arg_0)
{
	$_var_1 = _exam_get_set();
	$_var_2 = "plugin.php?id=keke_exam&ac=test&examid=" . $_arg_0;
	if ($_var_1["rewrite_off"]) {
		$_var_2 = $_var_1[rewrite_test] . "-" . $_arg_0 . $_var_1["rewrite_suffix"];
	}
	return $_var_2;
}