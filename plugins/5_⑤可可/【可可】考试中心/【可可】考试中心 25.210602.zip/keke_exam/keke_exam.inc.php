<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $_G;
$keke_exam = $_G['cache']['plugin']['keke_exam'];
require_once DISCUZ_ROOT.'./source/plugin/keke_exam/function.php';
$optarr=range('A','Z');
$questionidarr=array();
$eid=intval($_GET['eid']);
$allcatedata=_get_exam_allcatedata();
$slider=_exam_get_cache('slider');
$all_set=_exam_get_set();
handinpapers();
$_GET['ac']=$_GET['ac']?$_GET['ac']:'index';
if($_GET['ac']=='exam'){
	$pid=intval($_GET['pid']);
	$examdata=C::t('#keke_exam#keke_exam_paper')->fetchfirst_byid($pid);
	$pricedata=C::t('#keke_exam#keke_exam_price')->fetch_all('pid='.$pid);
	$favoritesarr=C::t('#keke_exam#keke_exam_favorites')->fetchfirst_bycid($pid,$_G['uid']);
	$paperquestionarr=unserialize($examdata['data']);
	$n=1;
    $preview=[];
	$previewNum=$keke_exam['preview']?intval($keke_exam['preview']):5;
    $qsData=_getquestion_by_id($paperquestionarr);
	foreach($qsData as $question){
		if($question['type']!=6){
            $preview[]=$question;
            if(!$keke_exam['randompv'] && count($preview)>=$previewNum)break;
        }
	}
    if($keke_exam['randompv']){
        foreach (array_rand($preview,$previewNum) as $qid){
            $questionpreview[]=$preview[$qid];
        }
    }else{
        $questionpreview=array_slice($preview, 0,$previewNum);
    }
	$evaluatearr=C::t('#keke_exam#keke_exam_evaluate')->fetchfirst_byuid($pid,$_G['uid']);
	$teacher_data=C::t('#keke_exam#keke_exam_teacher')->fetchfirst_byid($examdata['uid']);
	$follow_data=C::t('#keke_exam#keke_exam_follow')->fetchfirst_byteacherid($examdata['uid'],$_G['uid']);
	$evaluate_data=C::t('#keke_exam#keke_exam_evaluate')->fetchall_by_pid($pid);
	foreach($evaluate_data as $ek=>$ev){
		for($i=0; $i<$ev['star'];$i++){
			$evaluate_data[$ek]['stars'][]=1;
		}
		$evaluate_data[$ek]['time']=dgmdate($ev['time'], 'Y-m-d H:i:s');
	}
	foreach($pricedata as $price){
		$priceids[]=$price['id'];
	}
	$checkbuylog=C::t('#keke_exam#keke_exam_buylog')->count_all('pid in ('. dimplode($priceids).') AND uid='.$_G['uid']);
	if(checkmobile()){
        $examLogData=C::t('#keke_exam#keke_exam_log')->fetch_alls(0,10,'pid='.$pid.' GROUP BY uid');
        if(count($examLogData)<6){
            $examLogData=array_pad($examLogData,6,array('uid'=>0));
        }
    }
	$examdata['starttime']=dgmdate($examdata['start'], 'Y-m-d H:i');
	$examdata['endtime']=dgmdate($examdata['end'], 'Y-m-d H:i');
	$examdata['bigtotal']=count($paperquestionarr);
    $examurl=urlencode($_G['siteurl'].'plugin.php?id=keke_exam&ac=exam&pid='.$pid);
    $navtitle=str_replace(array('[exam]','[subcate]','[cate]'),array($examdata['title'],'-'.$allcatedata[$examdata['subcate']]['name'],$allcatedata[$examdata['cate']]['name']),$all_set['course_title']);
    $metakeywords=str_replace(array('[exam]','[subcate]','[cate]'),array($examdata['title'],'-'.$allcatedata[$examdata['subcate']]['name'],$allcatedata[$examdata['cate']]['name']),$all_set['course_keywords']);
    $metadescription=str_replace(array('[description]','[exam]','[subcate]','[cate]'),array(cutstr($examdata['exam_exp'],60),$examdata['title'],$allcatedata[$examdata['subcate']]['name'],$allcatedata[$examdata['cate']]['name']),  $all_set['course_description']);
}elseif($_GET['ac']=='pay'){
    if(!K_INMINIPROGRAM && (strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false) && $keke_exam['wxappid'] && $keke_exam['wxsecert']){
        include_once libfile('function/cache');
        include_once DISCUZ_ROOT."source/plugin/keke_exam/inc.php";
        $tools = new JsApiPay();
        $openId = $tools->GetOpenid();
        if(!$openId && $_GET['code']){
            $url = $_G['siteurl'].'plugin.php?id=keke_exam&ac=pay&priceid='.$_GET['priceid'];
            Header("Location: $url");
        }
        dsetcookie($uskey, authcode($openId, 'ENCODE', $_G['config']['security']['authkey']), 8640000);
    }
	$_GET['priceid']=dhtmlspecialchars($_GET['priceid']);
	$priceids=explode(',',$_GET['priceid']);
	$pricedata=C::t('#keke_exam#keke_exam_price')->fetch_all_byids($priceids);
	foreach($pricedata as $pk=>$pv){
		$pids[]=$pv['pid'];
		$arr_unit[$pv['uid']][]=$pv;
		$teacher_uids[]=$pv['uid'];
	}
	$teachers_data=C::t('#keke_exam#keke_exam_teacher')->fetch_all_by_uids($teacher_uids);
	$count_teacher=count($arr_unit);
	$examdata=C::t('#keke_exam#keke_exam_paper')->fetch_all_by_pids($pids);
	$i=0;
	foreach($pricedata as $key=>$val){
		if($val['vip'] && $val['vipprice']>0 && in_array($_G['groupid'],$appoint)){
			$val['price']=$val['vipprice'];
		}
		$total_price+=$val['price'];
		if($val['credit']){
			$total_credit[$val['credit_type']]+=$val['credit'];
		}
	}
	if($orderid && $orderdata){
		$total_price=$orderdata['price'];
	}
	$keke_exam['buyclause']=_exam_editor_safe_replace($keke_exam['buyclause']);
	$pay=array('total'=>count($pricedata),'total_price'=>number_format($total_price,2),'total_prices'=>$total_price,'total_credit'=>$total_credit);
}elseif($_GET['ac']=='test'){
    $qsCount=0;
	$_GET['qid']=intval($_GET['qid']);
	$examid=intval($_GET['examid']);
	$examdata=C::t('#keke_exam#keke_exam_log')->fetchfirst_byid($examid);
	$paperdata=C::t('#keke_exam#keke_exam_paper')->fetchfirst_byid($examdata['pid']);
    if($examdata['uid']!=$_G['uid'] && $paperdata['uid']!=$_G['uid']){
        exit(lang('plugin/keke_exam', '171'));
    }
	if($_GET['qid'])$paperdata['ansmod']=1;
    $examdata['starttime']=dgmdate($examdata['start'], 'Y-m-d H:i:s');
	$examdata['endtime']=dgmdate($examdata['end'], 'Y-m-d H:i:s');
	$questionarr=unserialize($examdata['data']);
	$questiondata=_getquestion_by_id($questionarr,1);
    foreach ($questionarr as $value) {
        $qsCount+=count($value['data']);
    }
	$questioncount=array(count($questionarr),$qsCount);
	if($examdata['start']>TIMESTAMP){
		showmessage(lang('plugin/keke_exam', '011'));
	}
	if($examdata['end'] && $examdata['end']<TIMESTAMP && !$_GET['qid']){
		//showmessage(lang('plugin/keke_exam', '012'));
	}
    $isisright=0;
	$answerdata=unserialize($examdata['answer_data']);
	foreach($answerdata['answer'] as $ak=>$av){
		$ret='';
		if($questiondata[$ak]['type']==1){
			$ret=$optarr[$av[0]-1];
		}elseif($questiondata[$ak]['type']==3){
			$ret=$av[0];
		}elseif($questiondata[$ak]['type']==4){
			$ret=($av[0]==1)?lang('plugin/keke_exam', '009'):lang('plugin/keke_exam', '010');
		}else{
			foreach($av as $key=>$val){
				if($questiondata[$ak]['type']==2){
					$ret.=$optarr[$val-1].',';
				}else{
					$ret.='<p>'.$key.'. '.$val.'</p>';
				}
			}
			$ret=($questiondata[$ak]['type']==2)?substr($ret, 0, -1):$ret;
		}
		$ansarr[$ak]=$ret;
		if($answerdata['isright'][$ak])$isisright++;
	}
    if($examdata['state']==1){
        if($_GET['op']=='achievement'){
            $pAnswerTime=$paperdata['answertime']*60;
            $AnswerTime=($examdata['time']?$examdata['time']:$examdata['end'])-$examdata['start'];
            if(!$paperdata['answertime']){
                $AnswerPercents=100;
            }else{
                $AnswerPercents=$AnswerTime/$pAnswerTime*100;
            }
            $percent=array(
                $examdata['totalscore']/$paperdata['total_score']*100,
                number_format($isisright/$questioncount[1]*100,1),
                array(
                    ($AnswerTime<60?$AnswerTime.lang('plugin/keke_exam', '236'):intval($AnswerTime/60).lang('plugin/keke_exam', '237')),
                    number_format($AnswerPercents,1)
                )
            );

            $newquestionArr=$questionarr;
            foreach ($newquestionArr as $Key=>$Item) {
                $isrights=0;
                $newquestionArr[$Key]['count']=count($Item['data']);
                foreach($Item['data'] as $k=>$v){
                    if($answerdata['isright'][$k])$isrights++;
                }
                $newquestionArr[$Key]['isright']=$isrights;
                $newquestionArr[$Key]['percent']=$isrights/count($Item['data'])*100;
            }
        }
        if($_GET['op']=='wrong'){
            if($examdata['totalscore']==$paperdata['total_score']) {
                $isAllRight=1;
            }else{
                $qsCount=0;
                foreach ($questionarr as $Keys=>$Items) {
                    foreach($Items['data'] as $k=>$v){
                        if($answerdata['isright'][$k]){
                            unset($questionarr[$Keys]['data'][$k]);
                        }else{
                            $qsCount++;
                        }
                    }
                }
                $questioncount[1]=$qsCount;
            }
        }
    }

}elseif($_GET['ac']=='list'){
	$_GET['cid']=intval($_GET['cid']);
	$_GET['scid']=intval($_GET['scid']);
	$_GET['o']=intval($_GET['o']);
	$ppp=20;
	$tmpurl='plugin.php?id=keke_exam&ac=list&cid='.$_GET['cid'].'&scid='.$_GET['scid'].'&o='.$_GET['o'].'&keyword='.dhtmlspecialchars($_GET['keyword']);
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$where='state=1 ';
	$order=" ORDER BY displayorder DESC,id DESC";
	if($_GET['cid']){
		$where.=" AND cate=".$_GET['cid'];
	}
	if($_GET['scid']){
		$where.=" AND subcate=".$_GET['scid'];
	}
	if($_GET['keyword']){
		$where.=" AND title LIKE '%".$_GET['keyword']."%'";
	}
	if($_GET['o']){
		switch ($_GET['o']){
			case 1:
				$order=" ORDER BY id DESC";
				break;  
			case 2:
				$order=" ORDER BY view DESC";
				break;
			case 3:
				$order=" ORDER BY price DESC";
				break;
		  	case 4:
				$order=" ORDER BY price ASC";
				break;
		}
	}
	$count_all=C::t('#keke_exam#keke_exam_paper')->count_all($where);
	$exam_arr=C::t('#keke_exam#keke_exam_paper')->fetch_alls($startlimit,$ppp,$where,$order);
	foreach($exam_arr as $examkey=>$examlist){
		$examdata=(unserialize($examlist['data']));
		$exam_arr[$examkey]['big_questions']=count($examdata);
	}
	$multipage = multi($count_all, $ppp, $page, $_G['siteurl'].$tmpurl);
	$multipage=preg_replace("/\<label\>([\s\S]*)\<\/label\>/i", '', $multipage);
    $navtitle=$all_set['list_index_title'];
	if($_GET['cid']){
        $navtitle=str_replace('[cate]',$allcatedata[$_GET['cid']]['name'],$all_set['list_title']);
	    if($_GET['scid'])$navtitle=str_replace(array('[subcate]','[cate]'),array($allcatedata[$_GET['scid']]['name'],$allcatedata[$_GET['cid']]['name']),$all_set['sublist_title']);
    }
	$metakeywords=str_replace(array('[subcate]','[cate]'),array($allcatedata[$_GET['scid']]['name'],$allcatedata[$_GET['cid']]['name']),$all_set['list_keywords']);
	$metadescription=str_replace(array('[subcate]','[cate]'),array($allcatedata[$_GET['scid']]['name'],$allcatedata[$_GET['cid']]['name']),$all_set['list_description']);
}elseif($_GET['ac']=='setin'){
	if(!$_G['uid']) {
		_tologin();
	}
	$keke_exam['setin']=_exam_editor_safe_replace($keke_exam['setin']);
	$teacher_data=C::t('#keke_exam#keke_exam_teacher')->fetchfirst_byid($_G['uid']);
	$defaultgroid=C::t('#keke_exam#keke_exam_teachergroup')->fetchfirst_bydefault();
	if($teacher_data['state']==1){
		dheader('location: plugin.php?id=keke_exam:t');
	}
	if(!submitcheck('Submit_btn')) {
		$time=dgmdate($teacher_data['time'], 'Y-m-d H:i:s');
		$keke_exam['entryclause']=_exam_editor_safe_replace($keke_exam['entryclause']);
	}else{
		if($teacher_data['state']==4){
			showmessage(lang('plugin/keke_exam', '172'), NULL);
		}
		$profile=$_GET['profile'];
		if(!$profile['name']){
			showmessage(lang('plugin/keke_exam', '173'), NULL);
		}
		
		if(!$profile['tel']){
			showmessage(lang('plugin/keke_exam', '174'), NULL);
		}
		
		if(!$profile['wechat']){
			showmessage(lang('plugin/keke_exam', '175'), NULL);
		}
		
		if(!$profile['profile']){
			showmessage(lang('plugin/keke_exam', '176'), NULL);
		}
		$all_set=_exam_get_set();
		$arr=array(
			'uid'=>$_G['uid'],
			'username'=>$_G['username'],
			'name'=>$profile['name'],
			'tel'=>$profile['tel'],
			'wechat'=>$profile['wechat'],
			'profile'=>$profile['profile'],
			'teachergroupid'=>$defaultgroid['id'],
			'state'=>0,
			'time'=>TIMESTAMP,
		);
		C::t('#keke_exam#keke_exam_teacher')->insert($arr,true,true);
		showmessage(lang('plugin/keke_exam', '177'), 'plugin.php?id=keke_exam&ac=setin');
	}
}elseif($_GET['ac']=='teacher'){
    $ppp=20;
    $_GET['o']=intval($_GET['o']);
    $_GET['tcid']=intval($_GET['tcid']);
    $tmpurl='plugin.php?id=keke_exam&ac=teacher&tcid='.$_GET['tcid'].($_GET['o']?'&o='.$_GET['o']:'');
    $page = max(1, intval($_GET['page']));
    $startlimit = ($page - 1) * $ppp;
    $follow_data=C::t('#keke_exam#keke_exam_follow')->fetchfirst_byteacherid($_GET['tcid'],$_G['uid']);
    $count['fl']=C::t('#keke_exam#keke_exam_follow')->count_all('tid='.$_GET['tcid']);
    if($_GET['o']==2 && $_G['cache']['plugin']['keke_video_base']){
        $where='uid= '.$_GET['tcid'];
        $order=" ORDER BY displayorder DESC,id DESC";
        $count_all=C::t('#keke_video_base#keke_video_course')->count_all($where);
        $coursearr=C::t('#keke_video_base#keke_video_course')->fetch_all_course($startlimit,$ppp,$where,$order);
    }else{
        $where='state=1 AND uid='.$_GET['tcid'];
        $count_all=C::t('#keke_exam#keke_exam_paper')->count_all($where);
        $exam_arr=C::t('#keke_exam#keke_exam_paper')->fetch_alls($startlimit,$ppp,$where);
        foreach($exam_arr as $examkey=>$examlist){
            $examdata=(unserialize($examlist['data']));
            $exam_arr[$examkey]['big_questions']=count($examdata);
        }
    }
    $shareurl=urlencode($_G['siteurl'].'plugin.php?id=keke_exam&ac=teacher&tcid='.$_GET['tcid']);
    $multipage = multi($count_all, $ppp, $page, $_G['siteurl'].$tmpurl);
    $multipage=preg_replace("/\<label\>([\s\S]*)\<\/label\>/i", '', $multipage);
    $teacher_data=C::t('#keke_exam#keke_exam_teacher')->fetchfirst_byid($_GET['tcid']);
    if(!$teacher_data['username'])$teacher_data['username']=_getusname($_GET['tcid']);
    $navtitle=str_replace('[teacher]',$teacher_data['username'],$all_set['teacher_title']);
    $metakeywords=str_replace('[teacher]',$teacher_data['username'],$all_set['teacher_keywords']);
    $metadescription=str_replace('[teacher]',$teacher_data['username'],$all_set['teacher_keywords']);
}elseif($_GET['ac']=='account'){
	if(!$_G['uid']) {
		_tologin();
	}
	$oparr=array('myexam','order','favorites','records','cart','follow','msg','examlog','wrong');
	$_GET['op']=in_array($_GET['op'],$oparr)?$_GET['op']:(checkmobile()?'index':'mycourse');
	if($_GET['op']=='myexam'){
		$ppp=15;
		$page = max(1, intval($_GET['page']));
		$startlimit = ($page - 1) * $ppp;
		$tmpurl='plugin.php?id=keke_exam&ac=account&op=myexam';
		$where=' uid='.intval($_G['uid']);
		$count_all=C::t('#keke_exam#keke_exam_total')->count_all($where);
		$dataarr=C::t('#keke_exam#keke_exam_total')->fetch_alls($startlimit,$ppp,$where,$order);
		foreach($dataarr as $key=>$val){
			$pids[$val['pid']]=$val['pid'];
		}
		$paperdata=C::t('#keke_exam#keke_exam_paper')->fetch_all_by_pids($pids);
		$multipage = multi($count_all, $ppp, $page, $_G['siteurl'].$tmpurl);
		$multipage=preg_replace("/\<label\>([\s\S]*)\<\/label\>/i", '', $multipage);
	}elseif($_GET['op']=='examlog'){
		$pageurl='plugin.php?id=keke_exam&ac=account&op=examlog';
		$ppp=15;
		$page = max(1, intval($_GET['page']));
		$startlimit = ($page - 1) * $ppp;
		$where=' uid='.intval($_G['uid']);
		$count_all=C::t('#keke_exam#keke_exam_log')->count_all($where);
		$dataarr=C::t('#keke_exam#keke_exam_log')->fetch_alls($startlimit,$ppp,$where,$order);
		foreach($dataarr as $key=>$val){
			$pids[$val['pid']]=$val['pid'];
		}
		$paperdata=C::t('#keke_exam#keke_exam_paper')->fetch_all_by_pids($pids);
		$multipage = multi($count_all, $ppp, $page, $_G['siteurl'].$tmpurl);
		$multipage=preg_replace("/\<label\>([\s\S]*)\<\/label\>/i", '', $multipage);
	}elseif($_GET['op']=='wrong'){
		$tmpurl='plugin.php?id=keke_exam&ac=account&op=wrong';
		$ppp=15;
		$page = max(1, intval($_GET['page']));
		$startlimit = ($page - 1) * $ppp;
		$where=' uid='.intval($_G['uid']);
		$count_all=C::t('#keke_exam#keke_exam_wrong')->count_all($where);
		$dataarr=C::t('#keke_exam#keke_exam_wrong')->fetch_alls($startlimit,$ppp,$where,$order);
		foreach($dataarr as $key=>$val){
			$qsarr[]=$val['qid'];
		}
		$questionarr[]['data']=$qsarr;
		$questiondata=_getquestion_by_id($questionarr);
        foreach($questiondata as $quekey=>$queval){
            if($queval['type']==6)unset($questiondata[$quekey]);
        }
		$paperdata=C::t('#keke_exam#keke_exam_paper')->fetch_all_by_pids($pids);
		$multipage = multi($count_all, $ppp, $page, $_G['siteurl'].$tmpurl);
		$multipage=preg_replace("/\<label\>([\s\S]*)\<\/label\>/i", '', $multipage);
	}elseif($_GET['op']=='order'){
		$pageurl='plugin.php?id=keke_exam&ac=account&op=order';
		$ppp=15;
		$page = max(1, intval($_GET['page']));
		$startlimit = ($page - 1) * $ppp;
		$tmpurl='plugin.php?id=keke_exam&ac=account&op=order';
		$where=" uid=".intval($_G['uid'])." AND id NOT LIKE '%ALL%'";
		$count_all=C::t('#keke_exam#keke_exam_order')->count_all($where);
		$dataarr=C::t('#keke_exam#keke_exam_order')->fetch_all_order($startlimit,$ppp,$where,$order);
		foreach($dataarr as $key=>$val){
			$dataarr[$key]['pid']=explode(',',$val['pid']);
			$dataarr[$key]['time']=dgmdate($val['time'], 'Y-m-d H:i');
			foreach($dataarr[$key]['pid'] as $pk=>$pv){
				if($pv)$pids[$pv]=$pv;
			}
		}
		$pricedata=C::t('#keke_exam#keke_exam_price')->fetch_all_byids($pids);
		foreach($pricedata as $pricekey=>$priceval){
			$paperids[$priceval['pid']]=$priceval['pid'];
			$paperid[$priceval['id']]=$priceval['pid'];
		}
		$paperdata=C::t('#keke_exam#keke_exam_paper')->fetch_all_by_pids($paperids);
		$multipage = multi($count_all, $ppp, $page, $_G['siteurl'].$tmpurl);
		$multipage=preg_replace("/\<label\>([\s\S]*)\<\/label\>/i", '', $multipage);
	}elseif($_GET['op']=='favorites'){
		$where=' uid='.intval($_G['uid']);
		$ppp=15;
		$page = max(1, intval($_GET['page']));
		$startlimit = ($page - 1) * $ppp;
		$tmpurl='plugin.php?id=keke_exam&ac=account&op=favorites';
		$where=' uid='.intval($_G['uid']);
		$count_all=C::t('#keke_exam#keke_exam_favorites')->count_all($where);
		$dataarr=C::t('#keke_exam#keke_exam_favorites')->fetch_all_favorites($startlimit,$ppp,$where,$order);
		foreach($dataarr as $key=>$val){
			$pids[$val['pid']]=$val['pid'];
			$dataarr[$key]['time']=dgmdate($val['time'], 'Y-m-d H:i');
		}
		$paperdata=C::t('#keke_exam#keke_exam_paper')->fetch_all_by_pids($pids);
		$multipage = multi($count_all, $ppp, $page, $_G['siteurl'].$tmpurl);
		$multipage=preg_replace("/\<label\>([\s\S]*)\<\/label\>/i", '', $multipage);
	}elseif($_GET['op']=='follow'){
		$follow_data=C::t('#keke_exam#keke_exam_follow')->fetch_byuid($_G['uid']);
	}elseif($_GET['op']=='cart'){
		$cartarr=C::t('#keke_exam#keke_exam_cart')->fetch_all_by_uid($_G['uid']);
		foreach($cartarr as $key=>$val){
			$pids[]=$val['pid'];
		}
		$pricedata=C::t('#keke_exam#keke_exam_price')->fetch_all_byids($pids);
		foreach($pricedata as $keys=>$vals){
			$total_price+=$vals['price'];
			$paperarrsids[$vals['pid']]=$vals['pid'];
		}
		$paperarrs=C::t('#keke_exam#keke_exam_paper')->fetch_all_by_pids($paperarrsids);
		$i=1;
		foreach($total_credit as $ctypes=>$cvals){
			$total_credits.=($cvals>0)?((($i==1)?'':' + ').$cvals.$_G['setting']['extcredits'][$ctypes]['title']):'';
			$i++;
		}
		$total_price=number_format($total_price,2);
	}elseif($_GET['op']=='msg'){
		$check=C::t('#keke_video_base#keke_video_openid')->fetch_first_byid($_G['uid']);
		if($check['openid']){
			$subscribe = _video_getwechatuserinfo($check['openid']);
		}
	}elseif($_GET['op']=='index'){
		$count[1]=C::t('#keke_exam#keke_exam_wrong')->count_all("uid=".$_G['uid']);
		$count[2]=C::t('#keke_exam#keke_exam_favorites')->count_all("uid=".$_G['uid']);
		$count[3]=C::t('#keke_exam#keke_exam_follow')->count_all("uid=".$_G['uid']);
	}
	if($_G['cache']['plugin']['keke_market']){
		$gomarket=1;
		if($keke_video_base['distribution']){
			$marketmember=C::t('#keke_market#keke_market_member')->fetchfirst_byuid($_G['uid']);
			$gomarket=$marketmember?1:0;
		}
	}
	$teacher_data=C::t('#keke_exam#keke_exam_teacher')->fetchfirst_byid($_G['uid']);
}else{
	foreach($allcatedata as $cate){
		if($cate['upid']==0){
			$subcat=$cate['subcate']? $cate['subcate']:$cate['cate_id'];
			$exam_list[$cate['cate_id']]=C::t('#keke_exam#keke_exam_paper')->fetch_by_new($subcat,8);
			$catecount[$cate['cate_id']]['subcatenum']=count($cate['subcate'])?count($cate['subcate']):1;
			$bigcate[$cate['cate_id']]=$cate['cate_id'];
		}
	}
	if(checkmobile())$sum_question=C::t('#keke_exam#keke_exam_paper')->sum_by_cate($bigcate);
	$recommend['cate']=explode(',',$keke_exam['hotcate']);
	$hotexam_arr=explode(',',$keke_exam['hotexam']);
	$hotexam_data=C::t('#keke_exam#keke_exam_paper')->fetch_all_by_pids($hotexam_arr);	
	foreach($hotexam_arr as $hk=>$hv){
		$examdata=(unserialize($hotexam_data[$hk]['data']));
		$hotexam_data[$hv]['big_questions']=count($examdata);
		$recommend['exam'][]=$hotexam_data[$hv];
	}
    $teacher_data=C::t('#keke_exam#keke_exam_teacher')->fetchfirst_byid($_G['uid']);
    $navtitle=$all_set['index_title'];
    $metakeywords=$all_set['index_keywords'];
    $metadescription=$all_set['index_description'];
}

if(checkmobile()){
    if($keke_exam['hideheader'] && (K_INCMAG || K_INCWECHAT || K_INQIANFAN))$_GET['app']=1;
	include template('keke_exam:exam_'.$_GET['ac']);
}else{
	include template('diy:exam_'.$_GET['ac'], NULL, './source/plugin/keke_exam/template');
}