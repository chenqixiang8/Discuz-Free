<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

		loadcache('plugin'); //d'.'is'.'m.ta'.'obao.com
		require_once DISCUZ_ROOT.'./source/plugin/keke_exam/function.php';
		if(submitcheck('catesubmit')) {
			_exam_save_cat();
			cpmsg(lang('plugin/keke_exam', '020'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_exam&pmod=admincp_cate', 'succeed');
		}
		showformheader('plugins&operation=config&do=' . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . '&pmod=admincp_cate','enctype');
		showtableheader();
		showsubtitle(array('del', '', lang('plugin/keke_exam', '084')));
		$allcatedata=_get_exam_allcatedata();
		foreach($allcatedata as $key => $value) {
			$style = $value['upid'] ? '' : 'parent';
			if(!$value['upid'] && $reckey) {
				$upid = $allcatedata[$reckey]['upid'] ? $allcatedata[$reckey]['upid'] : $reckey;
				echo '<tr><td></td><td colspan="20"><div class="lastboard"><a href="###" onclick="addrow(this, 1, '.$upid.')" class="addtr">'.lang('plugin/keke_exam', '085').'</a></div></td></tr>';
			}
			$ico=!$value['upid'] ? '<input type="text" class="txt" name="icon_id['.$value['cate_id'].']" value="'.$value['icon_id'].'" />':'';
			showtablerow('', array('class="td25"', '','class="td25"'), array(
				'<input type="checkbox" class="checkbox" name="delete[]" value="'.$value['cate_id'].'" />',
				'<div class="'.$style.'board"><input type="text" class="txt" name="name['.$value['cate_id'].']" value="'.$value['name'].'" /><span class="lightfont"> id: '.$value['cate_id'].'</span></div>',
				'<input type="text" class="txt" name="displayorder['.$value['cate_id'].']" value="'.$value['displayorder'].'" />',
				'',
			));
			$reckey = $key;
		}
		
		if($reckey) {
			$upid = $allcatedata[$reckey]['upid'] ? $allcatedata[$reckey]['upid'] : $reckey;
		}
		if($upid) {
			echo '<tr><td></td><td colspan="20"><div class="lastboard"><a href="#" onclick="addrow(this, 1, '.$upid.')" class="addtr">'.lang('plugin/keke_exam', '085').'</a></div></td></tr>';
		}
		echo '<tr><td></td><td><div><a href="###" onclick="addrow(this, 0)" class="addtr">'.lang('plugin/keke_exam', '086').'</a></div></td><td colspan="20"></td></tr>';
		showsubmit('catesubmit', 'submit', 'del');
		showtablefooter(); //From: Dism��taobao��com
		showformfooter(); //From: Dism_taobao_com
		echo '<script type="text/javascript">
		var rowtypedata = [
			[[1, \'<input type="checkbox" class="checkbox" name="newhot[]" />\', \'td25\'], [1, \'<input type="text" class="txt" name="newname[]" />\', \'\'], [1, \'\', \'\'],[1, \'<input type="text" class="txt" name="newdisplayorder[]" />\', \'td25\'], [1, \'<input type="hidden" name="upid[]" value="0" />\']],
			[[1, \'<input type="checkbox" class="checkbox" name="newhot[]" />\', \'td25\'], [1, \'<div class="board"><input type="text" class="txt" name="newname[]" /></div>\', \'\'], [1, \'\', \'\'],[1, \'<input type="text" class="txt" name="newdisplayorder[]" />\', \'td25\'],  [1, \'<input type="hidden" name="upid[]" value="{1}" />\']],
		];
		</script><style>.imgsize{height:25px;vertical-align:middle;cursor:pointer; margin-left:10px;}
.imgprevew{position:absolute;z-index:999;border:1px solid #eee;left:0; top:40px; display:none}
.imgbox{ position:relative; }</style>';