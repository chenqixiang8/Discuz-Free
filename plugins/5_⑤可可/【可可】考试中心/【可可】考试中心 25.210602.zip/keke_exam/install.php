<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$keke_exam_buylog= DB::table("keke_exam_buylog");
$keke_exam_cart= DB::table("keke_exam_cart");
$keke_exam_cash= DB::table("keke_exam_cash");
$keke_exam_cashout= DB::table("keke_exam_cashout");
$keke_exam_cate= DB::table("keke_exam_cate");
$keke_exam_evaluate= DB::table("keke_exam_evaluate");
$keke_exam_favorites= DB::table("keke_exam_favorites");
$keke_exam_follow= DB::table("keke_exam_follow");
$keke_exam_log= DB::table("keke_exam_log");
$keke_exam_order= DB::table("keke_exam_order");
$keke_exam_paper= DB::table("keke_exam_paper");
$keke_exam_price= DB::table("keke_exam_price");
$keke_exam_question= DB::table("keke_exam_question");
$keke_exam_set= DB::table("keke_exam_set");
$keke_exam_slider= DB::table("keke_exam_slider");
$keke_exam_teacher= DB::table("keke_exam_teacher");
$keke_exam_teachergroup= DB::table("keke_exam_teachergroup");
$keke_exam_total= DB::table("keke_exam_total");
$keke_exam_wrong= DB::table("keke_exam_wrong");

$sql = <<<EOF
CREATE TABLE `$keke_exam_buylog` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `uid` int(1) NOT NULL,
  `pid` int(20) NOT NULL,
  `time` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE `$keke_exam_cart` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `uid` int(50) NOT NULL,
  `pid` varchar(255) NOT NULL,
  `total` int(10) NOT NULL,
  `time` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `atid` (`id`) USING BTREE
)ENGINE=MyISAM;

CREATE TABLE `$keke_exam_cash` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `uid` int(20) NOT NULL,
  `money` float(20,2) NOT NULL,
  `finalmoney` float(20,2) NOT NULL,
  `text` varchar(255) NOT NULL,
  `time` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `atid` (`id`) USING BTREE
)ENGINE=MyISAM;
CREATE TABLE `$keke_exam_cashout` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `uid` int(20) NOT NULL,
  `money` float(20,2) NOT NULL,
  `state` int(1) NOT NULL,
  `card_type` int(1) NOT NULL,
  `card` varchar(255) NOT NULL,
  `time` int(10) NOT NULL,
  `htime` int(10) NOT NULL,
  `msg` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `atid` (`id`) USING BTREE
)ENGINE=MyISAM;
CREATE TABLE `$keke_exam_cate` (
  `cate_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `upid` int(10) unsigned NOT NULL DEFAULT '0',
  `displayorder` int(6) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `uid` int(10) NOT NULL,
  `type` int(1) NOT NULL,
  PRIMARY KEY (`cate_id`)
)ENGINE=MyISAM;

CREATE TABLE `$keke_exam_evaluate` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `uid` int(20) NOT NULL,
  `username` varchar(50) NOT NULL,
  `pid` int(20) NOT NULL,
  `star` int(1) NOT NULL,
  `text` mediumtext NOT NULL,
  `time` int(10) NOT NULL,
  `state` int(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `atid` (`id`) USING BTREE
)ENGINE=MyISAM;

CREATE TABLE `$keke_exam_favorites` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `uid` int(50) NOT NULL,
  `pid` varchar(255) NOT NULL,
  `time` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `atid` (`id`) USING BTREE
)ENGINE=MyISAM;

CREATE TABLE `$keke_exam_follow` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `uid` int(20) NOT NULL,
  `tid` int(20) NOT NULL,
  `time` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `atid` (`id`) USING BTREE
)ENGINE=MyISAM;

CREATE TABLE `$keke_exam_log` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL,
  `data` mediumtext NOT NULL,
  `answer_data` mediumtext NOT NULL,
  `pid` int(20) NOT NULL,
  `achievement` int(10) NOT NULL,
  `state` int(11) NOT NULL,
  `time` varchar(20) NOT NULL,
  `totalscore` float(10,0) NOT NULL,
  `end` int(10) NOT NULL,
  `start` int(10) NOT NULL,
  `exam_type` int(1) NOT NULL,
  PRIMARY KEY (`id`)
)ENGINE=MyISAM;

CREATE TABLE `$keke_exam_order` (
  `id` char(50) NOT NULL,
  `uid` int(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `pay_type` varchar(20) NOT NULL,
  `price` float(20,2) NOT NULL,
  `credit` varchar(255) NOT NULL,
  `pid` varchar(500) NOT NULL,
  `teacher_uid` int(50) NOT NULL,
  `state` int(1) NOT NULL,
  `time` int(13) NOT NULL,
  `paytime` int(13) NOT NULL,
  `sn` varchar(50) NOT NULL,
  `revision` int(1) NOT NULL,
  `deduction` varchar(255) NOT NULL,
  `take` varchar(10) NOT NULL,
  `buymod` int(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `atid` (`id`) USING BTREE
)ENGINE=MyISAM;

CREATE TABLE `$keke_exam_paper` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL,
  `title` varchar(255) NOT NULL,
  `data` mediumtext NOT NULL,
  `type` int(1) NOT NULL,
  `total` int(10) NOT NULL,
  `cate` int(10) NOT NULL,
  `subcate` int(10) NOT NULL,
  `exam_exp` varchar(1000) NOT NULL,
  `img` varchar(255) NOT NULL,
  `total_score` float(10,0) NOT NULL,
  `pass` int(10) NOT NULL,
  `ansmod` int(1) NOT NULL,
  `answertime` int(10) NOT NULL,
  `time` varchar(10) NOT NULL,
  `start` int(10) NOT NULL,
  `end` int(10) NOT NULL,
  `state` int(1) NOT NULL,
  `displayorder` int(20) NOT NULL,
  `view` int(20) NOT NULL,
  `examtotal` int(20) NOT NULL,
  `price` float(2,0) NOT NULL,
  PRIMARY KEY (`id`)
)ENGINE=MyISAM;

CREATE TABLE `$keke_exam_price` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `uid` int(1) NOT NULL,
  `pid` int(20) NOT NULL,
  `title` varchar(150) NOT NULL,
  `price` float(20,2) NOT NULL,
  `yprice` float(20,2) NOT NULL,
  `total` int(20) NOT NULL,
  `limit` int(10) NOT NULL,
  `state` int(2) NOT NULL,
  `displayorder` int(10) NOT NULL,
  `credit` int(50) NOT NULL,
  `credit_type` int(1) NOT NULL,
  PRIMARY KEY (`id`)
)ENGINE=MyISAM;

CREATE TABLE `$keke_exam_question` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `type` int(10) NOT NULL,
  `title` text NOT NULL,
  `cate` int(10) NOT NULL,
  `data` mediumtext NOT NULL,
  `explain` text NOT NULL,
  `uid` int(10) NOT NULL,
  `difficulty` int(1) NOT NULL,
  `time` varchar(20) NOT NULL,
  `from` int(20) NOT NULL,
  PRIMARY KEY (`id`)
)ENGINE=MyISAM;

CREATE TABLE `$keke_exam_set` (
  `id` varchar(50) NOT NULL,
  `val` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
)ENGINE=MyISAM;

CREATE TABLE `$keke_exam_slider` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `img` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `title` varchar(200) NOT NULL,
  `displayorder` int(20) NOT NULL,
  `type` int(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `atid` (`id`) USING BTREE
)ENGINE=MyISAM;
CREATE TABLE `$keke_exam_teacher` (
  `uid` int(100) NOT NULL,
  `username` varchar(255) NOT NULL,
  `name` varchar(100) NOT NULL,
  `rank` varchar(20) NOT NULL,
  `tel` varchar(18) NOT NULL,
  `wechat` varchar(20) NOT NULL,
  `profile` varchar(500) NOT NULL,
  `exp_time` int(10) NOT NULL,
  `time` int(10) NOT NULL,
  `state` int(1) NOT NULL,
  `op_time` int(10) NOT NULL,
  `img` varchar(255) NOT NULL,
  `info` mediumtext NOT NULL,
  `bank_name` varchar(100) NOT NULL,
  `bank_type` varchar(100) NOT NULL,
  `bank` varchar(50) NOT NULL,
  `alipay_name` varchar(100) NOT NULL,
  `alipay` varchar(50) NOT NULL,
  `wechatpay_name` varchar(100) NOT NULL,
  `wechatpay` varchar(50) NOT NULL,
  `money` float(20,2) NOT NULL,
  `teachergroupid` int(10) NOT NULL,
  `wechatqrcode` varchar(255) NOT NULL,
  PRIMARY KEY (`uid`),
  KEY `atid` (`uid`) USING BTREE
)ENGINE=MyISAM;

CREATE TABLE `$keke_exam_teachergroup` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `permission_take` int(2) NOT NULL,
  `defaults` int(1) NOT NULL,
  `time` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `atid` (`id`) USING BTREE
)ENGINE=MyISAM;

CREATE TABLE `$keke_exam_total` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL,
  `pid` int(20) NOT NULL,
  `total` int(20) NOT NULL,
  `teacher_uid` int(20) NOT NULL,
  PRIMARY KEY (`id`)
)ENGINE=MyISAM;

CREATE TABLE `$keke_exam_wrong` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `uid` int(1) NOT NULL,
  `qid` int(20) NOT NULL,
  `pid` int(20) NOT NULL,
  `time` int(10) NOT NULL,
  `examid` int(20) NOT NULL,
  PRIMARY KEY (`id`)
)ENGINE=MyISAM;

EOF;
runquery($sql);
$finish = true;
@unlink(DISCUZ_ROOT . './source/plugin/keke_exam/discuz_plugin_keke_exam.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_exam/discuz_plugin_keke_exam_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_exam/discuz_plugin_keke_exam_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_exam/discuz_plugin_keke_exam_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_exam/discuz_plugin_keke_exam_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . 'source/plugin/keke_exam/install.php');
@unlink(DISCUZ_ROOT . 'source/plugin/keke_exam/upgrade.php');