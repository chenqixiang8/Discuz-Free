<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
loadcache('plugin'); //d'.'is'.'m.ta'.'obao.com
include_once DISCUZ_ROOT."source/plugin/keke_exam/function.php";
$all_set=_exam_get_set();
$_GET['op']=$_GET['op']?$_GET['op']:'rewriteset';
_exam_showadminsubmenu(array(
	array(lang('plugin/keke_exam', '241'), "rewriteset"),
	array(lang('plugin/keke_exam', '249'), "rewrite"),
),'admincp_rewrite');
if ($_GET['op'] == 'rewriteset') {
	if (!submitcheck("editsubmit")) {
		showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admincp_rewrite&op=rewriteset", 'enctype');
		showtableheader(lang('plugin/keke_exam', '241'));
		showsetting(lang('plugin/keke_exam', '242'),'rewrite[off]',$all_set['rewrite_off']);
		showsetting(lang('plugin/keke_exam', '243'),'rewrite[suffix]',$all_set['rewrite_suffix'],'text','','',lang('plugin/keke_exam', '244'));
		showsetting(lang('plugin/keke_exam', '245'),'rewrite[index]',($all_set['rewrite_index']?$all_set['rewrite_index']:'exam'),'text','','','');
		showsetting(lang('plugin/keke_exam', '246'),'rewrite[list]',($all_set['rewrite_list']?$all_set['rewrite_list']:'exam-class'),'text','','','');
		showsetting(lang('plugin/keke_exam', '247'),'rewrite[exam]',($all_set['rewrite_exam']?$all_set['rewrite_exam']:'exam'),'text','','','');
		showsetting(lang('plugin/keke_exam', '248'),'rewrite[test]',($all_set['rewrite_test']?$all_set['rewrite_test']:'test'),'text','','','');
		showsetting(lang('plugin/keke_exam', '250'),'rewrite[account]',($all_set['rewrite_account']?$all_set['rewrite_account']:'exam-account'),'text','','','');
		showsetting(lang('plugin/keke_exam', '252'),'rewrite[teacher]',($all_set['rewrite_teacher']?$all_set['rewrite_teacher']:'exam-teacher'),'text','','','');
		showsetting(lang('plugin/keke_exam', '253'),'rewrite[pay]',($all_set['rewrite_pay']?$all_set['rewrite_pay']:'exam-pay'),'text','','','');
		showsubmit('editsubmit', 'submit', '');
		showtablefooter(); //From: Dism��taobao��com
		showformfooter(); //From: Dism_taobao_com
		exit;
	}else{
		foreach($_GET['rewrite'] as $key=>$val){
			$arr['rewrite_'.$key]=_exam_editor_safe_replace($val);
		}
        _exam_insert_set($arr);
		cpmsg(lang('plugin/keke_exam', '030'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier='.$plugin["identifier"].'&pmod=admincp_rewrite', 'succeed');
	}
}else{
	showtips(lang('plugin/keke_exam', '251'));
	$rewrite=array(
		'index','list','account','exam','test','teacher','pay'
	);
	$suffix=str_replace(".","\.",$all_set['rewrite_suffix']);
	foreach($rewrite as $rewritekey=>$rewriteval){
		if($all_set['rewrite_'.$rewriteval]){
			$rewritearr[$rewriteval]=str_replace(".","\.",$all_set['rewrite_'.$rewriteval]);
		}
	}
	$strtmp= '<br><h1>'.lang('plugin/keke_exam', '254').'</h1>
	<pre class="colorbox">
	
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$rewritearr['index'].$suffix.'$ $1/plugin.php?id=keke_exam%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$rewritearr['list'].$suffix.'$ $1/plugin.php?id=keke_exam&ac=list%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$rewritearr['list'].'-([0-9]+)-([0-9]+)'.$suffix.'$ $1/plugin.php?id=keke_exam&ac=list&cid=$2&scid=$3%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$rewritearr['list'].'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$suffix.'$ $1/plugin.php?id=keke_exam&ac=list&cid=$2&scid=$3&o=$4&page=$5%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$rewritearr['account'].$suffix.'$ $1/plugin.php?id=keke_exam&ac=account%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$rewritearr['account'].'-(\w+)'.$suffix.'$ $1/plugin.php?id=keke_exam&ac=account&op=$2%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$rewritearr['account'].'-(\w+)-([0-9]+)'.$suffix.'$ $1/plugin.php?id=keke_exam&ac=account&op=$2&page=$3%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$rewritearr['exam'].'-([0-9]+)'.$suffix.'$ $1/plugin.php?id=keke_exam&ac=exam&pid=$2%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$rewritearr['test'].'-([0-9]+)'.$suffix.'$ $1/plugin.php?id=keke_exam&ac=test&examid=$2%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$rewritearr['test'].'-([0-9]+)-(\w+)'.$suffix.'$ $1/plugin.php?id=keke_exam&ac=test&examid=$2&op=$3%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$rewritearr['teacher'].'-([0-9]+)'.$suffix.'$ $1/plugin.php?id=keke_exam&ac=teacher&tcid=$2%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$rewritearr['pay'].'-(.*?)'.$suffix.'$ $1/plugin.php?id=keke_exam&ac=pay&pid=$2%1
	
	</pre>
	<h1>'.lang('plugin/keke_exam', '255').'</h1>
	<pre class="colorbox">
	
	
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^'.$rewritearr['index'].$suffix.'$ plugin.php?id=keke_exam%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^'.$rewritearr['list'].$suffix.'$ plugin.php?id=keke_exam&ac=list%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^'.$rewritearr['list'].'-([0-9]+)-([0-9]+)'.$suffix.'$ plugin.php?id=keke_exam&ac=list&cid=$1&scid=$2%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^'.$rewritearr['list'].'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$suffix.'$ plugin.php?id=keke_exam&ac=list&cid=$1&scid=$2&o=$3&page=$4%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^'.$rewritearr['account'].$suffix.'$ plugin.php?id=keke_exam&ac=account%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^'.$rewritearr['account'].'-(\w+)'.$suffix.'$ plugin.php?id=keke_exam&ac=account&op=$1%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^'.$rewritearr['account'].'-(\w+)-([0-9]+)'.$suffix.'$ plugin.php?id=keke_exam&ac=account&op=$1&page=$2%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^'.$rewritearr['exam'].'-([0-9]+)'.$suffix.'$ plugin.php?id=keke_exam&ac=exam&pid=$1%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^'.$rewritearr['test'].'-([0-9]+)'.$suffix.'$ plugin.php?id=keke_exam&ac=test&examid=$1%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^'.$rewritearr['test'].'-([0-9]+)-(\w+)'.$suffix.'$ plugin.php?id=keke_exam&ac=test&examid=$1&op=$2%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^'.$rewritearr['teacher'].'-([0-9]+)'.$suffix.'$ plugin.php?id=keke_exam&ac=teacher&tcid=$1%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^'.$rewritearr['pay'].'-([0-9]+)'.$suffix.'$ plugin.php?id=keke_exam&ac=pay&priceid=$1%1
	
	</pre>
	<h1>Nginx Web Server</h1>
	<pre class="colorbox">

	
	rewrite ^([^\.]*)/'.$rewritearr['index'].$suffix.'$ $1/plugin.php?id=keke_exam last;
	rewrite ^([^\.]*)/'.$rewritearr['list'].$suffix.'$ $1/plugin.php?id=keke_exam&ac=list last;
	rewrite ^([^\.]*)/'.$rewritearr['list'].'-([0-9]+)-([0-9]+)'.$suffix.'$ $1/plugin.php?id=keke_exam&ac=list&cid=$2&scid=$3 last;
	rewrite ^([^\.]*)/'.$rewritearr['list'].'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$suffix.'$ $1/plugin.php?id=keke_exam&ac=list&cid=$2&scid=$3&o=$4&page=$5 last;
	rewrite ^([^\.]*)/'.$rewritearr['account'].$suffix.'$ $1/plugin.php?id=keke_exam&ac=account last;
	rewrite ^([^\.]*)/'.$rewritearr['account'].'-(\w+)'.$suffix.'$ $1/plugin.php?id=keke_exam&ac=account&op=$2 last;
	rewrite ^([^\.]*)/'.$rewritearr['account'].'-(\w+)-([0-9]+)'.$suffix.'$ $1/plugin.php?id=keke_exam&ac=account&op=$2&page=$3 last;
	rewrite ^([^\.]*)/'.$rewritearr['exam'].'-([0-9]+)'.$suffix.'$ $1/plugin.php?id=keke_exam&ac=exam&pid=$2 last;
	rewrite ^([^\.]*)/'.$rewritearr['test'].'-([0-9]+)'.$suffix.'$ $1/plugin.php?id=keke_exam&ac=test&examid=$2 last;
	rewrite ^([^\.]*)/'.$rewritearr['test'].'-([0-9]+)-(\w+)'.$suffix.'$ $1/plugin.php?id=keke_exam&ac=test&examid=$2&op=$3 last;
	rewrite ^([^\.]*)/'.$rewritearr['teacher'].'-([0-9]+)'.$suffix.'$ $1/plugin.php?id=keke_exam&ac=teacher&tcid=$2 last;
	rewrite ^([^\.]*)/'.$rewritearr['pay'].'-(.*?)'.$suffix.'$ $1/plugin.php?id=keke_exam&ac=pay&cid=$2 last;
	
	</pre>
	<h1>'.lang('plugin/keke_exam', '256').'</h1>
	<pre class="colorbox">
	
	
	RewriteRule ^(.*)/'.$rewritearr['index'].$suffix.'*$ $1/plugin.php?id=keke_exam
	RewriteRule ^(.*)/'.$rewritearr['list'].$suffix.'*$ $1/plugin.php?id=keke_exam&ac=list
	RewriteRule ^(.*)/'.$rewritearr['list'].'-([0-9]+)-([0-9]+)'.$suffix.'*$ $1/plugin.php?id=keke_exam&ac=list&cid=$2&scid=$3
	RewriteRule ^(.*)/'.$rewritearr['list'].'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$suffix.'*$ $1/plugin.php?id=keke_exam&ac=list&cid=$2&scid=$3&o=$4&page=$5
	RewriteRule ^(.*)/'.$rewritearr['account'].$suffix.'*$ $1/plugin.php?id=keke_exam&ac=account
	RewriteRule ^(.*)/'.$rewritearr['account'].'-(\w+)'.$suffix.'*$ $1/plugin.php?id=keke_exam&ac=account&op=$2
	RewriteRule ^(.*)/'.$rewritearr['account'].'-(\w+)-([0-9]+)'.$suffix.'*$ $1/plugin.php?id=keke_exam&ac=account&op=$2&page=$3
	RewriteRule ^(.*)/'.$rewritearr['exam'].'-([0-9]+)'.$suffix.'*$ $1/plugin.php?id=keke_exam&ac=exam&pid=$2
	RewriteRule ^(.*)/'.$rewritearr['test'].'-([0-9]+)'.$suffix.'*$ $1/plugin.php?id=keke_exam&ac=test&examid=$2
	RewriteRule ^(.*)/'.$rewritearr['test'].'-([0-9]+)-(\w+)'.$suffix.'*$ $1/plugin.php?id=keke_exam&ac=test&examid=$2&op=$3
	RewriteRule ^(.*)/'.$rewritearr['teacher'].'-([0-9]+)'.$suffix.'*$ $1/plugin.php?id=keke_exam&ac=teacher&tcid=$2
	RewriteRule ^(.*)/'.$rewritearr['pay'].'-(.*?)'.$suffix.'*$ $1/plugin.php?id=keke_exam&ac=pay&cid=$2
	
	</pre>
	<h1>'.lang('plugin/keke_exam', '257').'</h1>
	<pre class="colorbox">
	
	
	&lt;rule name="exam_index"&gt;
		&lt;match url="^(.*/)*'.$rewritearr['index'].$all_set['rewrite_suffix'].'\?*(.*)$" /&gt;
		&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=keke_exam" /&gt;
	&lt;/rule&gt;
	&lt;rule name="exam_list"&gt;
		&lt;match url="^(.*/)*'.$rewritearr['list'].$all_set['rewrite_suffix'].'\?*(.*)$" /&gt;
		&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=keke_exam&amp;amp;ac=list" /&gt;
	&lt;/rule&gt;
	&lt;rule name="exam_list_a"&gt;
		&lt;match url="^(.*/)*'.$rewritearr['list'].'-([0-9]+)-([0-9]+)'.$all_set['rewrite_suffix'].'\?*(.*)$" /&gt;
		&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=keke_exam&amp;amp;ac=list&amp;amp;cid={R:2}&amp;amp;scid={R:3}" /&gt;
	&lt;/rule&gt;
	&lt;rule name="exam_list_b"&gt;
		&lt;match url="^(.*/)*'.$rewritearr['list'].'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$all_set['rewrite_suffix'].'\?*(.*)$" /&gt;
		&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=keke_exam&amp;amp;ac=list&amp;amp;cid={R:2}&amp;amp;scid={R:3}&amp;amp;o={R:4}&amp;amp;page={R:5}" /&gt;
	&lt;/rule&gt;
	&lt;rule name="account"&gt;
		&lt;match url="^(.*/)*'.$rewritearr['account'].$all_set['rewrite_suffix'].'\?*(.*)$" /&gt;
		&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=keke_exam&amp;amp;ac=account" /&gt;
	&lt;/rule&gt;
	&lt;rule name="account_a"&gt;
		&lt;match url="^(.*/)*'.$rewritearr['account'].'-(\w+)'.$all_set['rewrite_suffix'].'\?*(.*)$" /&gt;
		&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=keke_exam&amp;amp;ac=account&amp;amp;op={R:2}" /&gt;
	&lt;/rule&gt;
	&lt;rule name="account_b"&gt;
		&lt;match url="^(.*/)*'.$rewritearr['account'].'-(\w+)-([0-9]+)'.$all_set['rewrite_suffix'].'\?*(.*)$" /&gt;
		&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=keke_exam&amp;amp;ac=account&amp;amp;op={R:2}&amp;amp;page={R:3}" /&gt;
	&lt;/rule&gt;
	&lt;rule name="exam"&gt;
		&lt;match url="^(.*/)*'.$rewritearr['exam'].'-([0-9]+)'.$all_set['rewrite_suffix'].'\?*(.*)$" /&gt;
		&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=keke_exam&amp;amp;ac=exam&amp;amp;pid={R:2}" /&gt;
	&lt;/rule&gt;
	&lt;rule name="test"&gt;
		&lt;match url="^(.*/)*'.$rewritearr['test'].'-([0-9]+)'.$all_set['rewrite_suffix'].'\?*(.*)$" /&gt;
		&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=keke_exam&amp;amp;ac=test&amp;amp;examid={R:2}" /&gt;
	&lt;/rule&gt;
	&lt;rule name="test_a"&gt;
		&lt;match url="^(.*/)*'.$rewritearr['test'].'-([0-9]+)-(\w+)'.$all_set['rewrite_suffix'].'\?*(.*)$" /&gt;
		&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=keke_exam&amp;amp;ac=test&amp;amp;examid={R:2}&amp;amp;op={R:3}" /&gt;
	&lt;/rule&gt;
	&lt;rule name="teacher"&gt;
		&lt;match url="^(.*/)*'.$rewritearr['teacher'].'-([0-9]+)'.$all_set['rewrite_suffix'].'\?*(.*)$" /&gt;
		&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=keke_exam&amp;amp;ac=teacher&amp;amp;tcid={R:2}" /&gt;
	&lt;/rule&gt;
	&lt;rule name="pay"&gt;
		&lt;match url="^(.*/)*'.$rewritearr['pay'].'-([0-9]+)'.$all_set['rewrite_suffix'].'\?*(.*)$" /&gt;
		&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=keke_exam&amp;amp;ac=pay&amp;amp;cid={R:2}" /&gt;
	&lt;/rule&gt;
	
	
	</pre>';
	echo $strtmp;
	showtablefooter(); //From: Dism��taobao��com
}