<?php
define('IN_API', true);
define('CURSCRIPT', 'api');
define('DISABLEXSSCHECK', true);
require_once '../../../../../../source/class/class_core.php';
$discuz = C::app();
$discuz->init();

global $_G;
if($_GET['formhash']!=FORMHASH){
	exit('FORMHASH_ERROR');
}
date_default_timezone_set("Asia/chongqing");
error_reporting(E_ERROR);
header("Content-Type: text/html; charset=utf-8");

$CONFIG = json_decode(preg_replace("/\/\*[\s\S]+?\*\//", "", file_get_contents("config.json")), true);
$action = $_GET['action'];

require_once DISCUZ_ROOT.'./source/plugin/keke_exam/function.php';

switch ($action) {
    case 'config':
        $result =  json_encode($CONFIG);
        break;
    /* 上传图片 */
    case 'uploadimage':
    /* 上传涂鸦 */
    case 'uploadscrawl':
	$file = $_FILES['upfile'];
		$picurl=_upload_img($_FILES['upfile'],$width,$hight);
		if ($file["error"] == 0) {
			//上传文件到CDN
			$res = array(
				"state"    => "SUCCESS",
				"url"      => $picurl, 
				"title"    => "",          //新文件名
				"original" => "",       //原始文件名
				"type"     => "",           //文件类型
				"size"     => "",           //文件大小
			);
			echo json_encode($res);
		}
		exit;
    /* 上传视频 */
    case 'uploadvideo':
    /* 上传文件 */
    case 'uploadfile':
		$file = $_FILES['upfile'];
		$fileurl=_upload_file($_FILES['upfile']);
		if ($file["error"] == 0) {
			//上传文件到CDN
			$res = array(
				"state"    => "SUCCESS",          //上传状态，上传成功时必须返回"SUCCESS"
				"url"      => $fileurl[0],            //CDN地址
				"title"    => "",          //新文件名
				"original" => "",       //原始文件名
				"type"     => "",           //文件类型
				"size"     => "",           //文件大小
			);
			echo json_encode($res);
		}
		exit;
    default:
        $result = json_encode(array(
            'state'=> 'url_error'
        ));
        break;
}
/* 输出结果 */
if (isset($_GET["callback"])) {
    if (preg_match("/^[\w_]+$/", $_GET["callback"])) {
        echo htmlspecialchars($_GET["callback"]) . '(' . $result . ')';
    } else {
        echo json_encode(array(
            'state'=> 'callback_error'
        ));
    }
} else {
    echo $result;
}