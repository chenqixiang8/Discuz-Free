<?php
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$config = array();
foreach($pluginvars as $key => $val) {
	$config[$key] = $val['value'];	
}
$pluginid='aljsc';
$modelist = array(1 => lang('plugin/aljsc','sc3'), 2 => lang('plugin/aljsc','sc4'));
$config['type'] = str_replace('\r', '\n', $config['type']);
$typelist = explode("\n", $config['type']);
$config['status'] = str_replace('\r', '\n', $config['status']);
$config['status'] = explode("\n", $config['status']);
foreach ($config['status'] as $status) {
    $status = explode('|', $status);
    $statuslist[$status[0]] = $status[1];
}

$config['eso'] = str_replace('\r', '\n', $config['eso']);
$config['eso'] = explode("\n", $config['eso']);
foreach ($config['eso'] as $eso) {
    $eso = explode('-', $eso);
    $esolist[$eso[0]] = $eso[1];
}
if($_GET['act']=='edit'){
	if(submitcheck('formhash')){
		if ($_FILES['logo']['tmp_name']) {
            $picname = $_FILES['logo']['name'];
            $picsize = $_FILES['logo']['size'];

            if ($picname != "") {
                $type = strstr($picname, '.');

                $rand = rand(100, 999);
                $pics = date("YmdHis") . $rand . $type;
                $img_dir = 'source/plugin/aljsc/images/logo/';
                if (!is_dir($img_dir)) {
                    mkdir($img_dir);
                }
                $logo = $img_dir . $pics;
                if (@copy($_FILES['logo']['tmp_name'], $logo) || @move_uploaded_file($_FILES['logo']['tmp_name'], $logo)) {
                    @unlink($_FILES['logo']['tmp_name']);
                }
            }
        }
        $updatearray = array(
            'per' => $_GET['per'],
            'displayorder' => $_GET['displayorder'],
            'type' => $_GET['type'],
            'mode' => $_GET['mode'],
            'status' => $_GET['status'],
            'title' => $_GET['title'],
            'sponsor' => $_GET['sponsor'],
            'starttime' => strtotime($_GET['starttime']),
            'endtime' => strtotime($_GET['endtime']),
            'price' => $_GET['price'],
            'extcredit' => $_GET['extcredit'],
            'num' => $_GET['num'],
            'e' => $_GET['e'],
            'desc' => $_GET['desc'],
            'uid' => $_G['uid'],
            'username' => $_G['username'],
        );
        if ($logo) {
            $updatearray['logo'] = $logo;
        }
        C::t('#aljsc#aljsc')->update($_GET['sid'], $updatearray);
       
		cpmsg(lang('plugin/aljsc','admin_1'), 'action=plugins&operation=config&identifier='.$pluginid.'&pmod=admin', 'succeed');
	}else{
		$shop = C::t('#aljsc#aljsc')->fetch($_GET['sid']);
		include template('aljsc:edit');
	}
}else{
	if(!submitcheck('submit')) {
		showformheader('plugins&operation=config&identifier='.$pluginid.'&pmod=admin');
		showtableheader('&#21830;&#21697;&#21517;&#31216;&#65306;<input type="text" name="title" style="width:100px;" value="'.$_GET[title].'"> <input type="submit" class=" pn pnc">');
		showsubtitle(array('',lang('plugin/aljsc','admin_10'),lang('plugin/aljsc','admin_2'),lang('plugin/aljsc','admin_3'), lang('plugin/aljsc','admin_4'),lang('plugin/aljsc','admin_5'),lang('plugin/aljsc','admin_6'),lang('plugin/aljsc','admin_7'),lang('plugin/aljsc','admin_8')));
		$currpage=$_GET['page']?$_GET['page']:1;
		$perpage=10;
		$start=($currpage-1)*$perpage;
		if($_GET['title']){
			$title='%' . addcslashes($_GET['title'], '%_') . '%';
			$where=" where title like '$title'";
		}
		$num=DB::result_first("SELECT count(*) FROM ".DB::table('aljsc').$where);
		$paging = helper_page :: multi($num, $perpage, $currpage, ADMINSCRIPT."?action=plugins&operation=config&identifier=".$pluginid."&pmod=admin", 0, 10, false, false);
		$query = DB::query("SELECT * FROM ".DB::table('aljsc')." $where ORDER BY id desc limit $start,$perpage");
		while($row = DB::fetch($query)) {
			if($row[recomened]){
				$che[$row[id]]='checked="checked"';
			}
			$start=date('Y-m-d H:i',$row['starttime']);
			$end=date('Y-m-d H:i',$row['endtime']);
			showtablerow('', array('', '','class="td_m"', 'class="td_k"', 'class="td_l"','class="td_l"','class="td_l"'), array(					
							"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$row[id]\">{$row[id]}<input type=\"hidden\" value=\"$row[id]\" name=\"myid[]\" >",		
							"<input  type=\"text\" name=\"displayorder[".$row[id]."]\" value=\"$row[displayorder]\" style=\"width:30px;\">",	
							$row['title'],	
							$modelist[$row['mode']],	
							$row['num'],		
							$row['num2'],
							$start,
							$end,
							'<input class="checkbox" type="checkbox" name="tuijian['.$row[id].']" '.$che[$row[id]].' value="1">&nbsp;&nbsp;&nbsp;<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier='.$pluginid.'&pmod=admin&act=edit&sid='.$row[id].'&uid='.$row[uid].'">'.lang('plugin/aljsc','admin_9').'</a>',		
							));
			
		}
		
		showsubmit('submit', 'submit', 'del','',$paging);
		showtablefooter();
		showformfooter();
		
		
	}else{
		//debug($_POST);
		if(is_array($_POST['delete'])) {
			foreach($_POST['delete'] as $id) {
				C::t('#aljsc#aljsc')->delete($id);
			}
		}
		foreach($_POST['myid'] as $id) {
			DB::update('aljsc',array('recomened'=>$_POST['tuijian'][$id]),'id='.$id);
		}
		
		if(is_array($_POST['displayorder'])) {
			foreach($_POST['displayorder'] as $k=>$id) {
				DB::update('aljsc',array('displayorder'=>$id),'id='.$k);
			}
		}
		cpmsg(lang('plugin/aljsc','admin_1'), 'action=plugins&operation=config&identifier='.$pluginid.'&pmod=admin', 'succeed');
	}
}
function showmsg($msg,$close){
	if($close){
		$str="parent.hideWindow('$close');";
	}else{
		$str="parent.location=parent.location;";
	}
	include template('aljsc:showmsg');
	exit;
}
function showerror($msg){
	include template('aljsc:showerror');
	exit;
}
function img2thumb($src_img, $dst_img, $width = 75, $height = 75, $cut = 0, $proportion = 0)
{
    if(!is_file($src_img))
    {
        return false;
    }
    $ot = fileext($dst_img);
    $otfunc = 'image' . ($ot == 'jpg' ? 'jpeg' : $ot);
    $srcinfo = getimagesize($src_img);
    $src_w = $srcinfo[0];
    $src_h = $srcinfo[1];
    $type  = strtolower(substr(image_type_to_extension($srcinfo[2]), 1));
    $createfun = 'imagecreatefrom' . ($type == 'jpg' ? 'jpeg' : $type);

    $dst_h = $height;
    $dst_w = $width;
    $x = $y = 0;

    if(($width> $src_w && $height> $src_h) || ($height> $src_h && $width == 0) || ($width> $src_w && $height == 0))
    {
        $proportion = 1;
    }
    if($width> $src_w)
    {
        $dst_w = $width = $src_w;
    }
    if($height> $src_h)
    {
        $dst_h = $height = $src_h;
    }

    if(!$width && !$height && !$proportion)
    {
        return false;
    }
    if(!$proportion)
    {
        if($cut == 0)
        {
            if($dst_w && $dst_h)
            {
                if($dst_w/$src_w> $dst_h/$src_h)
                {
                    $dst_w = $src_w * ($dst_h / $src_h);
                    $x = 0 - ($dst_w - $width) / 2;
                }
                else
                {
                    $dst_h = $src_h * ($dst_w / $src_w);
                    $y = 0 - ($dst_h - $height) / 2;
                }
            }
            else if($dst_w xor $dst_h)
            {
                if($dst_w && !$dst_h)  
                {
                    $propor = $dst_w / $src_w;
                    $height = $dst_h  = $src_h * $propor;
                }
                else if(!$dst_w && $dst_h)  
                {
                    $propor = $dst_h / $src_h;
                    $width  = $dst_w = $src_w * $propor;
                }
            }
        }
        else
        {
            if(!$dst_h)  
            {
                $height = $dst_h = $dst_w;
            }
            if(!$dst_w)  
            {
                $width = $dst_w = $dst_h;
            }
            $propor = min(max($dst_w / $src_w, $dst_h / $src_h), 1);
            $dst_w = (int)round($src_w * $propor);
            $dst_h = (int)round($src_h * $propor);
            $x = ($width - $dst_w) / 2;
            $y = ($height - $dst_h) / 2;
        }
    }
    else
    {
        $proportion = min($proportion, 1);
        $height = $dst_h = $src_h * $proportion;
        $width  = $dst_w = $src_w * $proportion;
    }

    $src = $createfun($src_img);
    $dst = imagecreatetruecolor($width ? $width : $dst_w, $height ? $height : $dst_h);
    $white = imagecolorallocate($dst, 255, 255, 255);
    imagefill($dst, 0, 0, $white);

    if(function_exists('imagecopyresampled'))
    {
        imagecopyresampled($dst, $src, $x, $y, 0, 0, $dst_w, $dst_h, $src_w, $src_h);
    }
    else
    {
        imagecopyresized($dst, $src, $x, $y, 0, 0, $dst_w, $dst_h, $src_w, $src_h);
    }
    $otfunc($dst, $dst_img);
    imagedestroy($dst);
    imagedestroy($src);
    return true;
}
//From: Dism��taobao��com
?>