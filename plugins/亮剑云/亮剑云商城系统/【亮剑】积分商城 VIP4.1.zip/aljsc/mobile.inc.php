<?php

 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */

if (!defined('IN_DISCUZ')) {
    exit('Access denied.');
}

$config = $_G['cache']['plugin']['aljsc'];
if($_GET['act'] == 'typelist'){
	$config['type'] = str_replace('\r', '\n', $config['type']);
	$typelist = explode("\n", $config['type']);

	include template('aljsc:typelist');
}
//From: Dism·taobao·com
?>