<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$pluginid = 'aljsc';
$_GET=dhtmlspecialchars($_GET);
if(!C::t('#aljsc#aljsc_setting')->fetch('mobile_img_array')){
	$mobile_img_array = 'plugin.php?id=aljsc&act=list&type=1|source/plugin/aljsc/images/aljbd.png|&#34394;&#25311;&#29289;&#21697;
plugin.php?id=aljsc&act=list&type=2|source/plugin/aljsc/images/aljzc.png|&#25968;&#30721;&#20135;&#21697;
plugin.php?id=aljsc&act=list&type=3|source/plugin/aljsc/images/mapp_template.png|&#22270;&#20070;&#26434;&#24535;
plugin.php?id=aljsc&act=list&type=4|source/plugin/aljsc/images/aljdc.png|&#29664;&#23453;&#39318;&#39280;
plugin.php?id=aljsc&act=list&type=5|source/plugin/aljsc/images/aljhd.png|&#26102;&#23578;&#26381;&#35013;';
	C::t('#aljsc#aljsc_setting')->insert(array('key'=>'mobile_img_array','value'=>$mobile_img_array));
}
if(!C::t('#aljsc#aljsc_setting')->fetch('member_about')){
	$mobile_member_about = '<div class="c_yg_logo">
        <img src="source/plugin/aljsc/images/about.png"/>
      </div>
      <ul class="c_about_details">
        <li>&#24494;&#20449;&#26381;&#21153;&#21495;&#65306;&#49;&#48;&#48;&#48;&#48;</li>
        <li>&#81;&#81;&#65306;&#49;&#48;&#48;&#48;&#48;</li>
        <li>&#26032;&#28010;&#24494;&#21338;&#65306;&#49;&#48;&#48;&#48;&#48;</li>
        <li>&#23448;&#26041;&#32593;&#22336;&#65306;&#104;&#116;&#116;&#112;&#58;&#47;&#47;&#119;&#119;&#119;&#46;&#120;&#120;&#120;&#46;&#99;&#111;&#109;&#47;</li>
         <li>&#25216;&#26415;&#25903;&#25345;&#65306;&#120;&#120;&#120;</li>
      </ul>';
	C::t('#aljsc#aljsc_setting')->insert(array('key'=>'member_about','value'=>$mobile_member_about));
}
if(submitcheck('formhash')){
	if($_FILES['logo']['tmp_name']) {
		$picname = $_FILES['logo']['name'];
		$picsize = $_FILES['logo']['size'];
	
		if ($picname != "") {
			$type = strtolower(strrchr($picname, '.'));
			if ($type != ".gif" && $type != ".jpg"&& $type != ".png") {
				showerror('&#35831;&#19978;&#20256;&#46;&#106;&#112;&#103;&#32;&#46;&#112;&#110;&#103;&#32;&#46;&#103;&#105;&#102;&#22270;&#29255;');
			}
			$rand = rand(100, 999);
			$pics = date("YmdHis") . $rand . $type;
			$logo = "source/plugin/".$pluginid."/images/logo/". $pics;
			if(@copy($_FILES['logo']['tmp_name'], $logo)||@move_uploaded_file($_FILES['logo']['tmp_name'], $logo)){
				@unlink($_FILES['logo']['tmp_name']);
			}
		}
	}

	if(empty($logo)){
		$logo = $_GET['logo'];
	}

	
	$record = C::t('#'.$pluginid.'#'.$pluginid.'_setting')->fetch('logo');

	if($_GET['deletelogo']){
		C::t('#'.$pluginid.'#'.$pluginid.'_setting') -> delete('logo');
		if($record['value']){
			unlink($record['value']);
		}
	}

	if(!$record){
		C::t('#'.$pluginid.'#'.$pluginid.'_setting')->insert(array('key'=>'logo','value'=>$logo));
	}else{
		C::t('#'.$pluginid.'#'.$pluginid.'_setting')->update_value_by_key($logo,'logo');
	}
	unset($logo);
	foreach($_GET['settingsnew'] as $k=>$v){
		if(!C::t('#aljsc#aljsc_setting')->fetch($k)){
			C::t('#aljsc#aljsc_setting')->insert(array('key'=>$k,'value'=>$v));
		}else{
			C::t('#aljsc#aljsc_setting')->update_value_by_key($v,$k);
		}
	}

	cpmsg('&#35774;&#32622;&#25104;&#21151;&#65281;', 'action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=aljsc&pmod=setting', 'succeed');
}else{
	$record = C::t('#'.$pluginid.'#'.$pluginid.'_setting')->fetch('logo');
	$logo = $record['value'];
	$setting = C::t('#aljsc#aljsc_setting')->range();
	$settings= $setting;
	include template('aljsc:setting');
}
//From: Dism��taobao��com
?>