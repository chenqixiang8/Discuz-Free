<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(empty($_G['uid'])){
	showmessage(lang('plugin/aljsc','sc2'), '', array(), array('login' => true));
}

$_GET=dhtmlspecialchars($_GET);
$num = intval($_GET['num']);
$settings=C::t('#aljsc#aljsc_setting')->range();
$shop=C::t('#aljsc#aljsc')->fetch($_GET['sid']);
$orderid = '';
$requesturl = credit_payurl(1, $orderid,$shop,$settings,$num);

if(C::t('#aljsc#aljsc_order')->fetch($orderid)) {
	showmessage('credits_addfunds_order_invalid', '', array(), array('showdialog' => 1, 'showmsg' => true, 'closetime' => true));
}

if(empty($_G['uid'])){
	showmessage(lang('plugin/aljsc','sc2'), '', array(), array('login' => true));
}
if ($_GET['formhash'] != formhash() || !submitcheck('formhash', 1) || preg_replace("/https?:\/\/([^\:\/]+).*/i", "\\1", $_SERVER['HTTP_REFERER']) != preg_replace("/([^\:]+).*/", "\\1", $_SERVER['HTTP_HOST'])) {
	debug('Access Denied!');
}

if (in_array($_G['groupid'], $notallowgroups)) {
   showmessage(lang('plugin/aljsc','sc23'));
}

$shop = C::t('#aljsc#aljsc')->fetch($_GET['sid']);
if (empty($num)) {
	showmessage(lang('plugin/aljsc','sc16'));
}
if ($shop['num'] < $num) {
	showmessage(lang('plugin/aljsc','sc17'));
}

if ($shop['e']) {
	$limitnum=DB::result_first('select sum(amount) from %t where sid=%d and uid=%d',array('aljsc_order',$_GET['sid'],$_G['uid']));
	
	if(($limitnum + $num) > $shop['e'] || $num >$shop['e']){
		$lnum=($shop['e']-$limitnum)>=0 ? ($shop['e']-$limitnum):0;
		showmessage('&#27599;&#20154;&#38480;&#25442;'.$shop['e'].'&#20010;&#65292;&#24744;&#24050;&#20817;&#25442;'.$limitnum.'&#20010;&#65292;&#36824;&#21487;&#20197;&#20817;&#25442;'.$lnum.'&#20010;');
	}
}
if (TIMESTAMP < $shop['starttime']) {
	echo "<script>parent.showError('".lang('plugin/aljsc','sc19')."');</script>";
	exit;
}
if (TIMESTAMP > $shop['endtime']) {
	echo "<script>parent.showError('".lang('plugin/aljsc','sc19')."');</script>";
	exit;
}

C::t('#aljsc#aljsc')->update_num_by_id($_GET['sid'],$num);
C::t('#aljsc#aljsc')->update_num2_by_id($_GET['sid'],$num);

$allattrs = C::t('#aljsc#aljsc_attr') -> range();
foreach($_GET['typename'] as $v){
	$attrs[]=$allattrs[$v]['content'];
}
$attrs = implode(',',$attrs);
C::t('#aljsc#aljsc_order')->insert(array(
	'orderid' => $orderid,
	'status' => '1',
	'uid' => $_G['uid'],
	'username' => $_G['username'],
	'sid' => $_GET['sid'],
	'stitle' => $shop['title'],
	'amount' => $num,
	'price' => $shop['price'],
	'submitdate' => $_G['timestamp'],
	'a' => $_GET['a'].$attrs,
));

include template('common/header');
echo '<form id="payform" action="'.$requesturl.'" method="post"></form><script type="text/javascript" reload="1">$(\'payform\').submit();</script>';
include template('common/footer');
dexit();

function credit_payurl($price, &$orderid,$shop,$settings,$num) {
	global $_G;
	$orderid = dgmdate(TIMESTAMP, 'YmdHis').random(18);
	$args = array(
		'subject' 		=> lang('plugin/aljsc','s6').$shop['title'].'-'.$_G['setting']['bbname'],
		'body' 			=> lang('plugin/aljsc','s6').$shop['title'].'-'.$_G['setting']['bbname'],
		'service' 		=> 'create_partner_trade_by_buyer',//trade_create_by_buyer
		'partner' 		=> $settings['ec_partner']['value'],
		'notify_url' 		=> $_G['siteurl'].'source/plugin/aljsc/notify.php',
		'return_url' 		=> $_G['siteurl'].'source/plugin/aljsc/notify.php',
		'show_url'		=> $_G['siteurl'],
		'_input_charset' 	=> CHARSET,
		'out_trade_no' 		=> $orderid,
		'price' 		=> $shop['price']*$num,
		'quantity' 		=> 1,
		'seller_email' 		=> $settings['ec_account']['value'],
		'extend_param'	=> 'isv^dz11'
	);
	if($settings['ec_creditdirectpay']['value']) {
		$args['service'] = 'create_direct_pay_by_user';
		$args['payment_type'] = '1';
	} else {
		$args['logistics_type'] = 'EXPRESS';
		$args['logistics_fee'] = 0;
		$args['logistics_payment'] = 'SELLER_PAY';
		$args['payment_type'] = 1;
	}
	//debug($args);
	return trade_returnurl($args,$settings);
}

function trade_returnurl($args,$settings) {
	global $_G;
	ksort($args);
	$urlstr = $sign = '';
	foreach($args as $key => $val) {
		$sign .= '&'.$key.'='.$val;
		$urlstr .= $key.'='.rawurlencode($val).'&';
	}
	$sign = substr($sign, 1);
	$sign = md5($sign.$settings['ec_securitycode']['value']);
	return 'https://www.alipay.com/cooperate/gateway.do?'.$urlstr.'sign='.$sign.'&sign_type=MD5';
}
//From: Dism��taobao��com
?>