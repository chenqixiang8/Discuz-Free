<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$_GET=dhtmlspecialchars($_GET);
if(submitcheck('formhash')){
	foreach($_GET['settingsnew'] as $k=>$v){
		if(!C::t('#aljsc#aljsc_setting')->fetch($k)){
			C::t('#aljsc#aljsc_setting')->insert(array('key'=>$k,'value'=>$v));
		}else{
			C::t('#aljsc#aljsc_setting')->update_value_by_key($v,$k);
		}
	}
	cpmsg(lang('plugin/aljsc','s1'), 'action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=aljsc&pmod=alipaysetting', 'succeed');
}else{
	$settings=C::t('#aljsc#aljsc_setting')->range();
	include template('aljsc:alipaysetting');
}
//From: Dism��taobao��com
?>