<?php

/*
 * ���ߣ�����
 * ��ϵQQ:281097180
 *
 */


if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
function getstr($string, $length, $in_slashes=0, $out_slashes=0, $bbcode=0, $html=0) {
	global $_G;

	$string = trim($string);
	$sppos = strpos($string, chr(0).chr(0).chr(0));
	if($sppos !== false) {
		$string = substr($string, 0, $sppos);
	}
	if($in_slashes) {
		$string = dstripslashes($string);
	}
	$string = preg_replace("/\[hide=?\d*\](.*?)\[\/hide\]/is", '', $string);
	if($html < 0) {
		$string = preg_replace("/(\<[^\<]*\>|\r|\n|\s|\[.+?\])/is", ' ', $string);
	} elseif ($html == 0) {
		$string = dhtmlspecialchars($string);
	}

	if($length) {
		$string = cutstr($string, $length);
	}

	if($bbcode) {
		require_once DISCUZ_ROOT.'./source/class/class_bbcode.php';
		$bb = & bbcode::instance();
		$string = $bb->bbcode2html($string, $bbcode);
	}
	if($out_slashes) {
		$string = daddslashes($string);
	}
	return trim($string);
}
require_once libfile('function/mail');
header('Content-Type: text/javascript');
$config = $_G ['cache'] ['plugin'] ['aljsc'];
$pernum = $config['num'];
$sendtime = $config['sendtime'];

dsetcookie('emailaljsc', '1', $sendtime);


@set_time_limit(0);

$list = $sublist = $cids = $touids = array();
foreach(C::t('common_mailcron')->fetch_all_by_sendtime($_G['timestamp'], 0, $pernum) as $value) {
	if($value['touid']) $touids[$value['touid']] = $value['touid'];
	$cids[] = $value['cid'];
	$list[$value['cid']] = $value;
}

if(empty($cids)) exit();

foreach(C::t('common_mailqueue')->fetch_all_by_cid($cids) as $value) {
	$sublist[$value['cid']][] = $value;
}

if($touids) {
	C::t('common_member_status')->update($touids, array('lastsendmail' => TIMESTAMP), 'UNBUFFERED');
}

C::t('common_mailcron')->delete($cids);
C::t('common_mailqueue')->delete_by_cid($cids);



foreach ($list as $cid => $value) {
	$mlist = $sublist[$cid];
	
	if($value['email'] && $mlist) {
		$subject = getstr($mlist[0]['subject'], 80, 0, 0, 0, -1);
		
		$message = '';
		if(count($mlist) == 1) {
			$message = '<br>'.$mlist[0]['message'];
		} else {
			foreach ($mlist as $subvalue) {
				if($subvalue['message']) {
					$message .= "<br><strong>$subvalue[subject]</strong><br>$subvalue[message]<br>";
				} else {
					$message .= $subvalue['subject'].'<br>';
				}
			}
		}
		if(!sendmail($value['email'], $subject, $message)) {
			$log=array('sendemail'=>$value[email],'sendtype'=>1,'sendtime'=>$_G['timestamp'],'success'=>0);
			C::t("#aljsc#aljsc_emaillog")->insert($log);
			runlog('sendmail', "$value[email] sendmail failed.");
		}else{
			$log=array('sendemail'=>$value[email],'sendtype'=>1,'sendtime'=>$_G['timestamp'],'success'=>1);
			C::t("#aljsc#aljsc_emaillog")->insert($log);
		}
	}
}
//From: Dism_taobao_com
?>