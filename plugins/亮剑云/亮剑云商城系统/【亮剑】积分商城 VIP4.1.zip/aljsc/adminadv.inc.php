<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */

if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access denied.');
}
$piclist = array(1 => 'adv', 2 => 'tadv', 3 => 'gadv', 4 => 'leftadv');
$urllist = array(1 => 'advurl', 2 => 'tadvurl', 3 => 'gadvurl', 4 => 'leftadvurl');

if (submitcheck('formhash')) {

    foreach ($piclist as $indexadv) {

        for ($i = 1; $i <= count($_FILES[$indexadv]['tmp_name']); $i++) {
            if ($_FILES[$indexadv]['tmp_name'][$i]) {
                $picname = $_FILES[$indexadv]['name'][$i];
                $picsize = $_FILES[$indexadv]['size'][$i];

                if ($picname != "") {
                    $type = strstr($picname, '.');
                    if ($type != ".gif" && $type != ".jpg" && $type != ".png") {
                        showerror(lang('plugin/aljsc', 's12'));
                    }
                    $rand = rand(100, 999);
                    $pics = date("YmdHis") . $rand . $type;
                    $dir = 'source/plugin/aljsc/images/adv/';
                    if (!is_dir($dir)) {
                        @mkdir($dir, 0777);
                    }
                    $adv[$indexadv][$i] = $dir . $pics;
                    if (@copy($_FILES[$indexadv]['tmp_name'][$i], $adv[$i]) || @move_uploaded_file($_FILES[$indexadv]['tmp_name'][$i], $adv[$indexadv][$i])) {
                        @unlink($_FILES[$indexadv]['tmp_name'][$i]);
                    }
                }
            }
        }

        $badv = C::t('#aljsc#aljsc_setting')->fetch($indexadv);
        $badv = unserialize($badv['value']);

        if ($_GET[$indexadv . 'delete']) {
            foreach ($_GET[$indexadv . 'delete'] as $k => $d) {
                unset($badv[$k]);
            }
        }
        
        if ($adv[$indexadv]) {
            foreach ($adv[$indexadv] as $kk => $vv) {
                $badv[$kk] = $vv;
            }
        }
       C::t('#aljsc#aljsc_setting')->delete($indexadv);
       C::t('#aljsc#aljsc_setting')->insert(array('key' => $indexadv, 'value' => serialize($badv)));
         
        
        
    }
    if ($urllist) {
        foreach ($urllist as $url) {
            if ($_GET[$url]) {
                if (C::t('#aljsc#aljsc_setting')->fetch($url)) {
                    C::t('#aljsc#aljsc_setting')->delete($url);
                    C::t('#aljsc#aljsc_setting')->insert(array('key' => $url, 'value' => serialize($_GET[$url])));
                } else {
                    C::t('#aljsc#aljsc_setting')->insert(array('key' => $url, 'value' => serialize($_GET[$url])));
                }
            }
        }
    }

    cpmsg(lang('plugin/aljsc','sc1'), 'action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=aljsc&pmod=adminadv', 'succeed');
} else {
    $sets = C::t('#aljsc#aljsc_setting')->range();
    foreach ($piclist as $pic) {
        $sets[$pic]['value'] = unserialize($sets[$pic]['value']);
    }

    foreach ($urllist as $url) {
        $sets[$url]['value'] = unserialize($sets[$url]['value']);
    }
    include template('aljsc:adminadv');
}
//From: Dism��taobao��com
?>