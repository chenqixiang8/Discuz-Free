<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_aljsc extends discuz_table {

    public function __construct() {

        $this->_table = 'aljsc';
        $this->_pk = 'id';

        parent::__construct();
    }

    public function fetch_extcredits($uid, $id) {
        $uid = intval($uid);
        $id = intval($id);
        return DB::result_first("select extcredits" . $id . " from " . DB::table('common_member_count') . " where uid=" . $uid);
    }

    public function update_pv_by_id($id) {
        return DB::query('update %t set pv=pv+1 where id=%d', array($this->_table, $id));
    }

    public function update_num_by_id($id,$num) {
        return DB::query('update %t set num=num-%d where id=%d', array($this->_table,$num,$id));
    }
    
    public function update_num2_by_id($id,$num) {
        return DB::query('update %t set num2=num2+%d where id=%d', array($this->_table,$num,$id));
    }

    public function count_by_endtime() {
        return DB::result_first('select count(*) from %t where endtime>%d', array($this->_table, TIMESTAMP));
    }

    public function count_by_endtime2() {
        return DB::result_first('select count(*) from %t where endtime<%d', array($this->_table, TIMESTAMP));
    }

    public function count_by_type($type,$s, $e,$yes) {

        $con[] = $this->_table;
        $where = 'where 1 ';
        if ($type) {
            $con[] = $type;
            $where.=' and type=%d';
        }
        if ($s) {
            $con[] = $s;
            $where.=' and extcredit>%d';
        }
        if ($e) {
            $con[] = $e;
            $where.=' and extcredit<%d';
        }
        if ($yes) {
            $where.=' and num>0';
        }
        return DB::result_first('select count(*) from %t ' . $where, $con);
    }

    public function fetch_all_by_type($type, $order = 'id', $desc, $start, $perpage, $s, $e,$yes,$kw) {
        $con[] = $this->_table;
        $where = 'where 1 ';
        if ($type) {
            $con[] = $type;
            $where.=' and type=%d';
        }
        if ($s) {
            $con[] = $s;
            $where.=' and extcredit>%d';
        }
        if ($e) {
            $con[] = $e;
            $where.=' and extcredit<%d';
        }
        if ($yes) {
            $where.=' and num>0';
        }
		if ($kw) {
			$con[] = $kw;
            $where.=' and title like %s';
        }
        if ($order) {
            $desc = $desc ? $desc : 'desc';
            $con[] = $order;
            $con[] = $desc;
            $where.=' order by %i %i';
        }else{
			$where.=' order by displayorder asc, id desc';
		}
		
        if (isset($start) && isset($perpage)) {
            $con[] = $start;
            $con[] = $perpage;
            $where.=' limit %d,%d';
        }
		
        return DB::fetch_all('select * from %t ' . $where, $con);
    }


    public function fetch_all_by_pv($start, $perpage, $sid) {
        return DB::fetch_all('select * from %t where id!=%d order by pv limit %d,%d', array($this->_table,$sid,$start, $perpage));
    }

    public function count_by_pv($sid) {
        return DB::result_first('select count(*) from %t where id!=%d order by pv', array($this->_table, $sid));
    }

    public function update_recomened_by_id($recomened,$id){
        return DB::query('update %t set recomened=%d where id=%d',array($this->_table,$recomened,$id));
    }
    public function fetch_all_by_recomened($start=0, $perpage=0){
		if($start && $perpage){
			$con = "LIMIT $start, $perpage";
		}
        return DB::fetch_all('select * from %t where recomened=1 order by displayorder desc '.$con,array($this->_table));
    }

}
//From: Dism_taobao_com
?>