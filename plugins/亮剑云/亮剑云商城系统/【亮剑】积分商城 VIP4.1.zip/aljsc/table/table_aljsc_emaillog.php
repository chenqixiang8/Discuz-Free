<?php

/*
 * ���ߣ�����
 * ��ϵQQ:281097180
 *
 */


if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class table_aljsc_emaillog extends discuz_table
{
	public function __construct() {

		$this->_table = 'aljsc_emaillog';
		$this->_pk    = 'id';

		parent::__construct();
	}
}




?>