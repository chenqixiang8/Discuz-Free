<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_aljsc_log extends discuz_table
{
	public function __construct() {

		$this->_table = 'aljsc_log';
		$this->_pk    = 'id';

		parent::__construct();
	}
	public function count_by_sid($sid){
		return DB::fetch_all('select * from %t where sid=%d group by uid',array($this->_table,$sid));
	}
	public function count_by_sid_reward($sid){
		return DB::result_first('select count(*) from %t where sid=%d and status =1 group by uid',array($this->_table,$sid));
	}
	public function fetch_all_by_sid($sid,$start,$perpage){
		return DB::fetch_all('select * from %t where sid=%d group by uid  order by id desc limit %d,%d',array($this->_table,$sid,$start,$perpage));
	}
	public function fetch_all_by_sid_new($sid,$start,$perpage){
		return DB::fetch_all('select count(uid) uidall,username,uid,dateline from %t where sid=%d group by uid  order by id desc limit %d,%d',array($this->_table,$sid,$start,$perpage));
	}
	public function fetch_all_by_mod($admin,$uid,$mod,$start,$perpage){
            if($admin){
                return DB::fetch_all('select * from %t where  mode = %d  order by id desc limit %d,%d',array($this->_table,$mod,$start,$perpage));
            }else{
                return DB::fetch_all('select * from %t where  uid=%d and mode = %d  order by id desc limit %d,%d',array($this->_table,$uid,$mod,$start,$perpage));
            }
		
	}
        public function fetch_all_by_mod_isnot($admin,$uid,$mod,$start,$perpage){
            if($admin){
                return DB::fetch_all('select * from %t where  mode = %d and isnot=1  order by id desc limit %d,%d',array($this->_table,$mod,$start,$perpage));
            }else{
                return DB::fetch_all('select * from %t where  uid=%d and mode = %d and isnot=1  order by id desc limit %d,%d',array($this->_table,$uid,$mod,$start,$perpage));
            }
        }
		public function fetch_all_by_mode_isnot_indexlog($start,$perpage){
			return DB::fetch_all('select * from %t where  mode = 1 or isnot=1  order by id desc limit %d,%d',array($this->_table,$start,$perpage));
		}
	public function update_status_by_id($id){
		return DB::query('update %t set status=1 where id=%d',array($this->_table,$id));
	}
}
//From: Dism_taobao_com
?>