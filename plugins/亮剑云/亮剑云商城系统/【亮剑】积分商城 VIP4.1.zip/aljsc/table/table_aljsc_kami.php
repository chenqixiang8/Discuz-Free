<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_aljsc_kami extends discuz_table {

    public function __construct() {

        $this->_table = 'aljsc_kami';
        $this->_pk = 'mid';

        parent::__construct();
    }
}
//From: Dism_taobao_com
?>