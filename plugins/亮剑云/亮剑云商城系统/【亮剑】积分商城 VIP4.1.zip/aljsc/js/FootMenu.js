﻿// JavaScript Document
$(document).ready(function() {
    var d = $(".Bottom1Width > ul > li"), b = $(".BottomLi"), c = !1, a = !0;
    d.click(function() {
        if (a) {
			var hh=parseInt($(this).attr("title"));
			var hh_e=(hh-1)*41+66;
            a = !1;
            var e = d.index(this);
            b.eq(e).siblings().hide().css({
                "height": 0
            }), b.eq(e).height() > 1 ? (c = !1, b.eq(e).animate({
                "height": 0
            }, function() {
                a = !0;
            })) : (c = !0, b.eq(e).animate({
                "height": hh_e
            }, function() {
                a = !0;
            }));
        }
    }), $("html").click(function() {
        c && setTimeout(function() {
            b.hide().css({
                "height": 0
            });
        }, 200);
    }), $(".KingLiCont a").click(function() {
        c = !1;
    }), $(".KingLiBg").click(function() {
        return !1;
    });
});