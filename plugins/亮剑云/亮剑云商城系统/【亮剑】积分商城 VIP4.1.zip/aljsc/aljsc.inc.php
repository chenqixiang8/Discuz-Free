<?php

/*
 * ���ߣ�����
 * ��ϵQQ:281097180
 *
 */

if (!defined('IN_DISCUZ')) {
    exit('Access denied.');
}

if(!function_exists('sendmail')) {
	include libfile('function/mail');
}
$pluginid = 'aljsc';
require_once 'source/plugin/'.$pluginid.'/lang/lang.php';
$loading = 'source/plugin/'.$pluginid.'/template/touch/new/sc.gif';
$piclist = array(1 => 'adv', 2 => 'tadv', 3 => 'gadv', 4 => 'leftadv');
$config = $_G['cache']['plugin']['aljsc'];
$notallowgroups = unserialize($config['notallowgroups']);
$groups = unserialize($config['groups']);

$settings = C::t('#aljsc#aljsc_setting')->range();
$new_index_dh = explode ("\n", str_replace ("\r", "", $settings['new_index_dh']['value']));
foreach($new_index_dh as $key=>$value){
	$arr=explode('|',$value);
	$new_index_dh_types[]=$arr;
}

$money = getuserprofile('extcredits'.$config['extcredit']);
$config['type'] = str_replace('\r', '\n', $config['type']);
$typelist = explode("\n", $config['type']);
foreach ($typelist as $status) {
    $arr = explode('|', $status);
    $typearr[$arr[0]] = $arr[1];
}

$config['status'] = str_replace('\r', '\n', $config['status']);
$config['status'] = explode("\n", $config['status']);
foreach ($config['status'] as $status) {
    $status = explode('|', $status);
    $statuslist[$status[0]] = $status[1];
}

$config['eso'] = str_replace('\r', '\n', $config['eso']);
$config['eso'] = explode("\n", $config['eso']);
foreach ($config['eso'] as $eso) {
    $eso = explode('-', $eso);
    $esolist[$eso[0]] = $eso[1];
}
$modelist = array(1 => lang('plugin/aljsc','sc3'), 2 => lang('plugin/aljsc','sc4'));
$allattrs = C::t('#aljsc#aljsc_attr') -> range();
$config['atypes'] = str_replace('\r', '\n', $config['atypes']);
$atypes = explode("\n", $config['atypes']);
foreach ($atypes as $k => $type) {
	$type = explode('|', $type);
	$typename[$type[0]] = trim($type[1]);
}
if($_G['cache']['plugin']['aljgwc']['aljsc']){
	$def_address = C::t('#aljgwc#aljbd_address')->fetch_by_uid($_G['uid']);
}
if ($_GET['act'] == 'add') {
	if(empty($_G['uid'])){
		showmessage(lang('plugin/aljsc','sc2'), '', array(), array('login' => true));
	}
    if (!in_array($_G['groupid'], $groups)) {
        debug('Access Denied!');
    }
    if (submitcheck('submit')) {
        if ($_FILES['logo']['tmp_name']) {
            $picname = $_FILES['logo']['name'];
            $picsize = $_FILES['logo']['size'];

            if ($picname != "") {
                $type = strstr($picname, '.');

                $rand = rand(100, 999);
                $pics = date("YmdHis") . $rand . $type;
                $img_dir = 'source/plugin/aljsc/images/logo/';
                if (!is_dir($img_dir)) {
                    mkdir($img_dir);
                }
                $logo = $img_dir . $pics;
                if (@copy($_FILES['logo']['tmp_name'], $logo) || @move_uploaded_file($_FILES['logo']['tmp_name'], $logo)) {
                    @unlink($_FILES['logo']['tmp_name']);
                }
            }
        }

		$allattrs = C::t('#aljsc#aljsc_attr') -> range();
		foreach($_GET['typename'] as $v){
			$attrs[]=$allattrs[$v]['content'];
		}
		$attrs = implode(',',$attrs);
        $insertarray = array(
            'per' => $_GET['per'],
            'displayorder' => $_GET['displayorder'],
            'type' => $_GET['type'],
            'mode' => $_GET['mode'],
            'status' => $_GET['status'],
            'title' => $_GET['title'],
            'sponsor' => $_GET['sponsor'],
            'starttime' => strtotime($_GET['starttime']),
            'endtime' => strtotime($_GET['endtime']),
            'price' => $_GET['price'],
            'extcredit' => $_GET['extcredit'],
            'num' => $_GET['num'],
            'e' => $_GET['e'],
            'logo' => $logo,
            'desc' => $_GET['desc'],
            'uid' => $_G['uid'],
            'username' => $_G['username'],
            'dateline' => $_G['timestamp'],
            'a' => $_GET['a'].$attrs,
            'b' => $_GET['b'],
        );
        C::t('#aljsc#aljsc')->insert($insertarray);
        echo "<script>parent.showDialog('".lang('plugin/aljsc','sc5')."','right','',function(){parent.location.href='plugin.php?id=aljsc&act=admin';});</script>";
    } else {
        if (!in_array($_G['groupid'], $groups)) {
            debug('Access Denied!');
        }
        if ($_GET['formhash'] != formhash() || !submitcheck('act', 1) || preg_replace("/https?:\/\/([^\:\/]+).*/i", "\\1", $_SERVER['HTTP_REFERER']) != preg_replace("/([^\:]+).*/", "\\1", $_SERVER['HTTP_HOST'])) {
            debug('Access Denied!');
        }
        include template('aljsc:add');
    }
} else if ($_GET['act'] == 'edit') {
	if(empty($_G['uid'])){
		showmessage(lang('plugin/aljsc','sc2'), '', array(), array('login' => true));
	}
    if (!in_array($_G['groupid'], $groups)) {
        debug('Access Denied!');
    }
    if (submitcheck('submit')) {
        if ($_GET['formhash'] != formhash() || !submitcheck('act', 1) || preg_replace("/https?:\/\/([^\:\/]+).*/i", "\\1", $_SERVER['HTTP_REFERER']) != preg_replace("/([^\:]+).*/", "\\1", $_SERVER['HTTP_HOST'])) {
            debug('Access Denied!');
        }
        if ($_FILES['logo']['tmp_name']) {
            $picname = $_FILES['logo']['name'];
            $picsize = $_FILES['logo']['size'];

            if ($picname != "") {
                $type = strstr($picname, '.');

                $rand = rand(100, 999);
                $pics = date("YmdHis") . $rand . $type;
                $img_dir = 'source/plugin/aljsc/images/logo/';
                if (!is_dir($img_dir)) {
                    mkdir($img_dir);
                }
                $logo = $img_dir . $pics;
                if (@copy($_FILES['logo']['tmp_name'], $logo) || @move_uploaded_file($_FILES['logo']['tmp_name'], $logo)) {
                    @unlink($_FILES['logo']['tmp_name']);
                }
            }
        }

		$allattrs = C::t('#aljsc#aljsc_attr') -> range();
		foreach($_GET['typename'] as $v){
			$attrs[]=$allattrs[$v]['content'];
		}
		$attrs = implode(',',$attrs);
        $updatearray = array(
            'per' => $_GET['per'],
            'displayorder' => $_GET['displayorder'],
            'type' => $_GET['type'],
            'mode' => $_GET['mode'],
            'status' => $_GET['status'],
            'title' => $_GET['title'],
            'sponsor' => $_GET['sponsor'],
            'starttime' => strtotime($_GET['starttime']),
            'endtime' => strtotime($_GET['endtime']),
            'price' => $_GET['price'],
            'extcredit' => $_GET['extcredit'],
            'num' => $_GET['num'],
            'e' => $_GET['e'],
            'desc' => $_GET['desc'],
            'uid' => $_G['uid'],
            'username' => $_G['username'],
			'a' => $_GET['a'].$attrs,
			'b' => $_GET['b'],
        );
        if ($logo) {
            $updatearray['logo'] = $logo;
        }
        C::t('#aljsc#aljsc')->update($_GET['sid'], $updatearray);
        echo "<script>parent.showDialog('".lang('plugin/aljsc','sc6')."','right','',function(){parent.location.href='plugin.php?id=aljsc&act=admin';});</script>";
        exit;
    } else {
        if (!in_array($_G['groupid'], $groups)) {
            debug('Access Denied!');
        }
        $shop = C::t('#aljsc#aljsc')->fetch($_GET['sid']);
        include template('aljsc:add');
    }
}else if($_GET['act'] == 'mobile_goodsview_pay'){
	$shop = C::t('#aljsc#aljsc')->fetch($_GET['sid']);
	$attrs = DB::fetch_all('select * from %t where tid = %d',array('aljsc_attr',$_GET['sid']));
	foreach($attrs as $attr){
        if(!$moren[$attr['name']]){
            $moren[$attr['name']] = $attr['mid'];
        }
		$goodattrs[$attr['name']][$attr['mid']]['mid'] = $attr['mid'];
		$goodattrs[$attr['name']][$attr['mid']]['content'] = $attr['content'];
	}
	if($_GET['cart'] == 'yes'){
		$formurl = 'plugin.php?id=aljgwc&act=addcart&gid='.$shop['id'].'&pluginid=aljsc';
	}else{
		$formurl = 'plugin.php?id=aljgwc&act=buy&pluginid=aljsc&goods_id='.$shop['id'];
	}
	include template('aljsc:new/confirm');
} else if ($_GET['act'] == 'view') {
	$_GET = dhtmlspecialchars($_GET);
    $loglist = C::t('#aljsc#aljsc_log')->range(0, 10, 'desc');
    C::t('#aljsc#aljsc')->update_pv_by_id($_GET['sid']);
    $shop = C::t('#aljsc#aljsc')->fetch($_GET['sid']);
	
    $cnum = C::t('#aljsc#aljsc')->count_by_pv($_GET['sid']);
    if ($cnum - 5 > 0) {
        $cnum = $cnum - 5;
        $start=mt_rand(0, $cnum);
    }else{
        $start=0;
    }
    
    $cshoplist = C::t('#aljsc#aljsc')->fetch_all_by_pv($start, 4, $_GET['sid']);
	foreach($cshoplist as $k=>$v){
		$cshoplist[$k]['rewrite']=str_replace ("{id}", $v['id'], $config ['re_view']);
	}
	if($shop['price'] && $shop['mode']!=2){
	    if($_G['cache']['plugin']['aljgwc']['aljsc']){
            $logusers = DB::fetch_all('select a.* from %t as a left join %t b on a.orderid = b.orderid where a.pid = 2 and b.goods_id=%d and a.status>1 group by a.uid limit 0,5',array('aljbd_goods_order','aljbd_goods_order_list',$_GET['sid']));
	        //debug($logusers);
	    }else{
            $logusers = C::t('#aljsc#aljsc_order')->fetch_all_by_sid($_GET['sid'], 0, 5);
        }
	}else{
		$logusers = C::t('#aljsc#aljsc_log')->fetch_all_by_sid($_GET['sid'], 0, 5);
	}
	
	if($shop['price'] && $shop['mode']!=2){

        if($_G['cache']['plugin']['aljgwc']['aljsc']){
            $count = DB::fetch_all('select a.* from %t as a left join %t b on a.orderid = b.orderid where a.pid = 2 and b.goods_id=%d and a.status>1 group by a.uid ',array('aljbd_goods_order','aljbd_goods_order_list',$_GET['sid']));
        }else{
            $count = C::t('#aljsc#aljsc_order')->count_by_sid($_GET['sid']);
        }
	}else{
		if($shop['mod'] == 2){
			$count = C::t('#aljsc#aljsc_log')->count_by_sid_reward($_GET['sid']);
		}else{
			$count = C::t('#aljsc#aljsc_log')->count_by_sid($_GET['sid']);
		}
	}
	
	require_once DISCUZ_ROOT.'source/plugin/aljsc/class/qrcode.class.php';
	$file = 'source/plugin/aljsc/images/qrcode/qrcode_'.intval($_GET['sid']).'.jpg';
	if(!file_exists($file)){
		QRcode::png($_G['siteurl'].'plugin.php?id=aljsc&act=view&sid='.intval($_GET['sid']),$file, QR_MODE_STRUCTURE, 8);
	}
    $attrs = DB::fetch_all('select * from %t where tid = %d',array('aljsc_attr',$shop['id']));
	foreach($attrs as $attr){
	    if(!$moren[$attr['name']]){
            $moren[$attr['name']] = $attr['mid'];
        }
		$goodattrs[$attr['name']][$attr['mid']]['mid'] = $attr['mid'];
		$goodattrs[$attr['name']][$attr['mid']]['content'] = $attr['content'];
	}
	//debug($moren);
	$count = count($count);
	
    $num2 = $shop['num'] - intval($count);
    $addr = C::t('#aljsc#aljsc_user')->fetch($_G['uid']);
    $navtitle = $shop['title'].'-'.$config['title'];
    $metakeywords = $shop['title'];
    $metadescription = $shop['title'];
	if(file_exists('source/plugin/mapp_share/api/api.php')){
		$shareid = intval($_GET['sid']);
		$sharetype = 5;	
		require_once 'source/plugin/mapp_share/api/api.php';
	}
	if($_G['mobile'] && $settings['is_mobile_template']['value'] && $_G['cache']['plugin']['aljgwc']['aljsc']){
		include template('aljsc:new/view');
	}else{
		include template('aljsc:view');
	}
}else if($_GET['act'] == 'viewcontent'){
	$_GET = dhtmlspecialchars($_GET);
	$shop = C::t('#aljsc#aljsc')->fetch($_GET['sid']);
	$navtitle = $shop['title'].'-'.$config['title'];
    $metakeywords = $shop['title'];
    $metadescription = $shop['title'];
	include template('aljsc:new/view_content');
}else if($_GET['act'] == 'mobile_goodsview_record'){//�һ���¼
	$_GET = dhtmlspecialchars($_GET);
	$shop = C::t('#aljsc#aljsc')->fetch($_GET['sid']);
	$currpage=$_GET['page']?$_GET['page']:1;
	$perpage=10;
	$start=($currpage-1)*$perpage;
	//$codes = DB::fetch_all('SELECT * FROM %t WHERE sid=%d and success=0 and uid>0 and pid=%d order by dateline desc limit %d,%d',array($pluginid.'_order',$yid,$pid,$start,$perpage));
	if($shop['price'] && $shop['mode']!=2){
		if($_G['cache']['plugin']['aljgwc']['aljsc']){
			$conn[] ='aljbd_goods_order';
			$conn[] ='aljbd_goods_order_list';
			$where = 'where a.pid=2 and a.status >1 and b.goods_id=%d ';
			$conn[] = $_GET['sid'];
			$where .= ' group by a.uid order by a.submitdate desc';
			$where .= ' limit %d,%d';
			$conn[] = $start;
			$conn[] = $perpage;
			$codes = DB::fetch_all('select a.*,count(a.uid) uidall from %t as a left join %t as b on a.orderid=b.orderid '.$where,$conn);
		}else{
			$codes = C::t('#aljsc#aljsc_order')->fetch_all_by_sid($_GET['sid'],$start,$perpage);
		}
	}else{
		$codes = C::t('#aljsc#aljsc_log')->fetch_all_by_sid_new($_GET['sid'],$start,$perpage);
	}
	
	include template($pluginid.':new/view_record');
} else if ($_GET['act'] == 'del') {
	if(empty($_G['uid'])){
		showmessage(lang('plugin/aljsc','sc2'), '', array(), array('login' => true));
	}
    if (!in_array($_G['groupid'], $groups)) {
        debug('Access Denied!');
    }
    if ($_GET['formhash'] != formhash() || !submitcheck('act', 1) || preg_replace("/https?:\/\/([^\:\/]+).*/i", "\\1", $_SERVER['HTTP_REFERER']) != preg_replace("/([^\:]+).*/", "\\1", $_SERVER['HTTP_HOST'])) {
        debug('Access Denied!');
    }
    C::t('#aljsc#aljsc')->delete($_GET['sid']);
    showmessage(lang('plugin/aljsc','sc7'), 'plugin.php?id=aljsc&act=admin');
} else if ($_GET['act'] == 'admin') {
	if(empty($_G['uid'])){
		showmessage(lang('plugin/aljsc','sc2'), '', array(), array('login' => true));
	}
    if (!in_array($_G['groupid'], $groups) || !submitcheck('act', 1)) {
        debug('Access Denied!');
    }
	//$_G['setting']['switchwidthauto'] = 1;
	//$_G['setting']['allowwidthauto'] = 0;
	$page = intval($_GET['page']);
    $currpage = $page ? $page : 1;
    $perpage = 20;
    $start = ($currpage - 1) * $perpage;
	$con[]='aljsc';
	$where.='where 1';
	if($_GET['title']){
		$con[] = '%' . addcslashes($_GET['title'], '%_') . '%';
		$where.=" and title like %s";
	}
	if($_GET['type']){
		$con[] = $_GET['type'];
		$where.=" and type = %d";
	}
	if($_GET['mode']){
		$con[] = $_GET['mode'];
		$where.=" and mode = %d";
	}
    $num = DB::result_first("select count(*) from %t ".$where,$con);
	
    $start = ($currpage - 1) * $perpage;
	$where.=' order by id desc';
	if(!empty($perpage)){
		$con[]=$start;
		$con[]=$perpage;
		$where.=' limit %d,%d';
	}
    
	$shoplist = DB::fetch_all('select * from %t '.$where,$con);;
	//$num = C::t('#aljsc#aljsc')->count();
    //$shoplist = C::t('#aljsc#aljsc')->range($start, $perpage, 'desc');
    $paging = helper_page :: multi($num, $perpage, $currpage, 'plugin.php?id=aljsc&act=admin&title='.$_GET['title'].'&type='.$_GET['type'].'&mode='.$_GET['mode'], 0, 11, false, false);
    $navtitle = lang('plugin/aljsc','sc8');
    include template('aljsc:admin');
} else if ($_GET['act'] == 'cancelrecomened') {
	if(empty($_G['uid'])){
		showmessage(lang('plugin/aljsc','sc2'), '', array(), array('login' => true));
	}
    if (!in_array($_G['groupid'], $groups)) {
        debug('Access Denied!');
    }
    C::t('#aljsc#aljsc')->update_recomened_by_id(0, $_GET['sid']);
    showmessage(lang('plugin/aljsc','sc9'), 'plugin.php?id=aljsc&act=admin');
} else if ($_GET['act'] == 'recomened') {
	if(empty($_G['uid'])){
		showmessage(lang('plugin/aljsc','sc2'), '', array(), array('login' => true));
	}
    if (!in_array($_G['groupid'], $groups)) {
        debug('Access Denied!');
    }
    C::t('#aljsc#aljsc')->update_recomened_by_id(1, $_GET['sid']);
    showmessage(lang('plugin/aljsc','sc9'), 'plugin.php?id=aljsc&act=admin');
} else if ($_GET['act'] == 'addr') {
	if(empty($_G['uid'])){
		showmessage(lang('plugin/aljsc','sc2'), '', array(), array('login' => true));
	}
    if ($_GET['uid']) {
        if (!in_array($_G['groupid'], $groups)) {
            debug('Access Denied!');
        }
    }
    $uid = $_GET['uid'] ? $_GET['uid'] : $_G['uid'];

    if (submitcheck('submit')) {
        if (C::t('#aljsc#aljsc_user')->fetch($uid)) {
            $updatearray = array(
                'name' => $_GET['name'],
                'qq' => $_GET['qq'],
                'tel' => $_GET['tel'],
                'addr' => $_GET['addr'],
            );
            C::t('#aljsc#aljsc_user')->update($uid, $updatearray);
			if(defined('IN_MOBILE')){
				if($_GET["sid"]){
					echo "<script>parent.tips('".lang('plugin/aljsc','sc11')."',function(){parent.location.href='plugin.php?id=aljsc&act=view&sid=".$_GET["sid"]."';});</script>";
				}else{
					echo "<script>parent.tips('".lang('plugin/aljsc','sc11')."',function(){parent.location.href=parent.location.href;});</script>";
				}
				
			}else{
				echo "<script>parent.showDialog('".lang('plugin/aljsc','sc11')."','right','',function(){parent.location.href=parent.location.href;});</script>";
			}
        } else {
            $insertarray = array(
                'uid' => $uid,
                'username' => $_G['username'],
                'name' => $_GET['name'],
                'qq' => $_GET['qq'],
                'tel' => $_GET['tel'],
                'addr' => $_GET['addr'],
            );
            C::t('#aljsc#aljsc_user')->insert($insertarray);
			if(defined('IN_MOBILE')){
				echo "<script>parent.tips('".lang('plugin/aljsc','sc12')."',function(){parent.location.href='plugin.php?id=aljsc&act=view&addr=1&sid=" . $_GET['sid'] . "';});</script>";
			}else{
				echo "<script>parent.showDialog('".lang('plugin/aljsc','sc12')."','right','',function(){parent.location.href='plugin.php?id=aljsc&act=view&addr=1&sid=" . $_GET['sid'] . "';});</script>";
			}
        }
    } else {
        $user = C::t('#aljsc#aljsc_user')->fetch($uid);
        include template('aljsc:addr');
    }
}else if($_GET['act'] == 'mobile_address'){
	
	if(empty($_GET['uid']) || empty($_GET['orderid'])){
		echo $aljsclang['php']['Request_error'];
		exit;
	}
	$shop = C::t('#aljsc#aljsc_log')->fetch($_GET['orderid']);
	if($shop['c']){
		$regionlist=C::t('#aljgwc#aljgwc_region')->range();
		$add = unserialize($shop['c']);
		echo '<p style="text-align:left;">'.$aljsclang['php']['full_name'].$add['fullName'].'</p><p style="text-align:left;">'.$aljsclang['php']['Telephone'].$add['mobile'].'</p><p style="text-align:left;">'.$aljsclang['php']['address'].$regionlist[$add['region']][name].$regionlist[$add['region1']][name].$regionlist[$add['region2']][name].$add['addressDetail'].'</p><p style="text-align:right;margin-top:10px"><a class="btn btn-default" href="javascript:;" onclick="closedialog();">'.$aljsclang['php']['close'].'</a></p>';
	}else{
		$add = C::t('#aljsc#aljsc_user')->fetch($_GET['uid']);
		echo '<p style="text-align:left;">'.$aljsclang['php']['full_name'].$add['name'].'</p><p style="text-align:left;">'.$aljsclang['php']['Telephone'].$add['tel'].'</p><p style="text-align:left;">'.$aljsclang['php']['address'].$add['addr'].'</p><p style="text-align:right;margin-top:10px"><a class="btn btn-default" href="javascript:;" onclick="closedialog();">'.$aljsclang['php']['close'].'</a></p>';
	}
	exit;
}else if($_GET['act'] == 'mobile_wuliu'){
	if(empty($_GET['orderid'])){
		echo $aljsclang['php']['Request_error'];
		exit;
	}
	$wuliu = C::t('#aljsc#aljsc_wuliu')->fetch($_GET['orderid']);
	if($wuliu){
		echo '<p style="text-align:left;">'.$aljsclang['php']['logistics_company'].$wuliu['companyname'].'</p><p style="text-align:left;">'.$aljsclang['php']['Number_of_logistics'].$wuliu['worderid'].'</p><p style="text-align:right;margin-top:10px"><a class="btn btn-default" href="javascript:;" onclick="closedialog();">'.$aljsclang['php']['close'].'</a></p>';
	}
	exit;
}else if($_GET['act']=='mobile_Cami'){
	if(empty($_GET['orderid'])){
		echo $aljsclang['php']['Request_error'];
		exit;
	}
	$orderid= intval($_GET['orderid']);
	$kamilist=DB::fetch_all('select * from %t where orderid = %d order by mid desc',array('aljsc_kami',$orderid));
	$html = '<table cellspacing="0" cellpadding="0" border="0" style="text-align:left;width:100%">
                
  				<tbody style="text-align: left;"><tr>
<th style="width:50%" height="30"><span style="color:red;"></span>&#21457;&#25918;&#26102;&#38388;</td>
<th style="width:50%" colspan="4">&#21345;&#23494;</td>
</tr>';
	foreach($kamilist as $c){
		$html.= '<tr>
<td style="width:50%" height="30"><span style="color:red;"></span>'.dgmdate($c['dateline']).'</td>
<td style="width:50%" colspan="4">'.$c['message'].'</td>
</tr>';
	}
	$html .='</tbody></table>';
	echo $html;
	exit;
} else if ($_GET['act'] == 'reward') {
	if(defined('IN_MOBILE')){
		if(empty($_G['uid'])){
			if($settings['is_mobile_template']['value'] && $_G['cache']['plugin']['aljgwc']['aljsc']){
				echo "<script>parent.closedialog();parent.tips('".lang('plugin/aljsc','sc2')."','');</script>";
		   }else{
				echo lang('plugin/aljsc','sc2');
		   }
			exit;
		}
	}else{
		if(empty($_G['uid'])){
			showmessage(lang('plugin/aljsc','sc2'), '', array(), array('login' => true));
		}
	}
	if (empty($_GET['sid'])) {
		if(defined('IN_MOBILE')){
			if($settings['is_mobile_template']['value'] && $_G['cache']['plugin']['aljgwc']['aljsc']){
				echo "<script>parent.closedialog();parent.tips('&#21830;&#21697;&#19981;&#23384;&#22312;&#65281;','');</script>";
		   }else{
				echo '&#21830;&#21697;&#19981;&#23384;&#22312;&#65281;';
		   }
		}else{
			showerror('&#21830;&#21697;&#19981;&#23384;&#22312;&#65281;');
		}
        exit;
    }
    $shop = C::t('#aljsc#aljsc')->fetch($_GET['sid']);
    if ($shop['num'] < 1) {
		if(defined('IN_MOBILE')){
			if($settings['is_mobile_template']['value'] && $_G['cache']['plugin']['aljgwc']['aljsc']){
				echo "<script>parent.closedialog();parent.tips('".lang('plugin/aljsc','sc13')."','');</script>";
		   }else{
				echo lang('plugin/aljsc','sc13');
		   }
		}else{
			showerror(lang('plugin/aljsc','sc13'));
		}
        exit;
    }
	if (TIMESTAMP < $shop['starttime']) {
		if(defined('IN_MOBILE')){
			if($settings['is_mobile_template']['value'] && $_G['cache']['plugin']['aljgwc']['aljsc']){
				echo "<script>parent.closedialog();parent.tips('".lang('plugin/aljsc','sc15')."','');</script>";
		   }else{
				echo lang('plugin/aljsc','sc15');
		   }
			exit;
		}else{
			showerror(lang('plugin/aljsc','sc15'));
			exit;
		}
        
    }
	if ($shop['e']) {
		$limitnum=DB::result_first('select count(*) from %t where sid=%d and uid=%d and isnot=%d',array('aljsc_log',$_GET['sid'],$_G['uid'],1));
		if($limitnum >= $shop['e']){
			if(defined('IN_MOBILE')){
				if($settings['is_mobile_template']['value'] && $_G['cache']['plugin']['aljgwc']['aljsc']){
					echo "<script>parent.closedialog();parent.tips('&#27599;&#20154;&#38480;&#20013;".$shop['e']."&#27425;','');</script>";
			   }else{
					echo '&#27599;&#20154;&#38480;&#20013;'.$shop['e'].'&#27425;';
			   }
				exit;
			}else{
				showerror('&#27599;&#20154;&#38480;&#20013;'.$shop['e'].'&#27425;');
			}
		}
    }

    if ($money < $shop['extcredit'] * 1) {
		if(defined('IN_MOBILE')){
			if($settings['is_mobile_template']['value'] && $_G['cache']['plugin']['aljgwc']['aljsc']){
				echo "<script>parent.closedialog();parent.tips('".$_G['setting']['extcredits'][$config['extcredit']]['title'].lang('plugin/aljsc','sc14')."','');</script>";
		   }else{
				echo $_G['setting']['extcredits'][$config['extcredit']]['title'].lang('plugin/aljsc','sc14');
		   }
			exit;
		}else{
			showerror($_G['setting']['extcredits'][$config['extcredit']]['title'].lang('plugin/aljsc','sc14'));
		}
        
    }

	if (in_array($_G['groupid'], $notallowgroups)) {
       if(defined('IN_MOBILE')){
		   if($settings['is_mobile_template']['value'] && $_G['cache']['plugin']['aljgwc']['aljsc']){
				echo "<script>parent.closedialog();parent.tips('".lang('plugin/aljsc','sc23')."','');</script>";
		   }else{
				echo lang('plugin/aljsc','sc23');
		   }
		   exit;
		}else{
			showerror(lang('plugin/aljsc','sc23'));
			exit;
		}
    }

	
    if (TIMESTAMP > $shop['endtime']) {
		if(defined('IN_MOBILE')){
			if($settings['is_mobile_template']['value'] && $_G['cache']['plugin']['aljgwc']['aljsc']){
				echo "<script>parent.closedialog();parent.tips('".lang('plugin/aljsc','sc15')."','');</script>";
			}else{
				echo lang('plugin/aljsc','sc15');
			}
			exit;
		}else{
			showerror(lang('plugin/aljsc','sc15'));
			exit;
		}
        
    }
    if($_G['cache']['plugin']['aljgwc']['aljsc']){
        if (!$def_address) {
            if(defined('IN_MOBILE')){
                if($settings['is_mobile_template']['value'] && $_G['cache']['plugin']['aljgwc']['aljsc']){
                    echo "<script>parent.closedialog();parent.tips('&#35831;&#20808;&#21040;&#25105;&#30340;&#45;&#45;&#25910;&#36135;&#22320;&#22336;&#20013;&#22635;&#20889;&#25910;&#36135;&#22320;&#22336;','');</script>";
                }else{
                    echo '&#35831;&#20808;&#21040;&#25105;&#30340;&#45;&#45;&#25910;&#36135;&#22320;&#22336;&#20013;&#22635;&#20889;&#25910;&#36135;&#22320;&#22336;';
                }
                exit;
            }else{
                showerror('&#35831;&#20808;&#21040;&#25105;&#30340;&#45;&#45;&#25910;&#36135;&#22320;&#22336;&#20013;&#22635;&#20889;&#25910;&#36135;&#22320;&#22336;');
                exit;
            }

        }
    }
    if (mt_rand(1, $config['standard']) <= $shop['per']) {
        $isnot = 1;
		$num=1;
    }
    $insertarray = array(
        'uid' => $_G['uid'],
        'username' => $_G['username'],
        'sid' => $shop['id'],
        'mode' => $shop['mode'],
        'title' => $shop['title'],
        'extcredit' => $shop['extcredit'],
        'num' => $num,
        'dateline' => TIMESTAMP,
        'isnot' => $isnot,
    );
	if($_G['cache']['plugin']['aljgwc']['aljsc']){
		$insertarray['c'] = serialize($def_address);
	}
	
    updatemembercount($_G['uid'], array($config['extcredit'] => '-' . 1* $shop['extcredit']));
    C::t('#aljsc#aljsc_log')->insert($insertarray);
	if ($isnot) {
		$tipstates='&#20182;&#24050;&#25277;&#20013; <a href="plugin.php?id=aljsc&act=rewardrecord">&#26597;&#30475;</a>';
	}else{
		$tipstates='&#20182;&#26410;&#25277;&#20013; <a href="plugin.php?id=aljsc&act=rewardinfo">&#26597;&#30475;</a>';
	}
	foreach(DB::fetch_all('select uid from '.DB::table('common_member').' where groupid in ('.dimplode($groups).')') as $u){
		notification_add($u['uid'], 'system',str_replace('{username}',$_G['username'],str_replace('{shopname}','<a href="plugin.php?id=aljsc&act=view&sid='.$shop['id'].'">'.$shop['title'].'</a>','&#24744;&#21457;&#24067;&#30340;&#25277;&#22870;{shopname},{username}&#36827;&#34892;&#20102;&#25277;&#22870;&#65281;'.$tipstates)));
	}
    if ($isnot) {
        C::t('#aljsc#aljsc')->update_num_by_id($_GET['sid'],$num);
        C::t('#aljsc#aljsc')->update_num2_by_id($_GET['sid'],$num);
		if(defined('IN_MOBILE')){
			if($settings['is_mobile_template']['value'] && $_G['cache']['plugin']['aljgwc']['aljsc']){
				echo "<script>parent.closedialog();</script>";
			}
			echo "<script>parent.tips('".$config['rewardtips']."',function(){parent.location.href='plugin.php?id=aljsc&act=view&sid=" . $_GET['sid'] . "';});</script>";
			exit;
		}else{
			showmsg($config['rewardtips']);
		}
    } else {
		if(defined('IN_MOBILE')){
			if($settings['is_mobile_template']['value'] && $_G['cache']['plugin']['aljgwc']['aljsc']){
				echo "<script>parent.closedialog();</script>";
			}
			echo "<script>parent.tips('".$config['notips']."',function(){parent.location.href='plugin.php?id=aljsc&act=view&sid=" . $_GET['sid'] . "';});</script>";
			//echo $config['notips'];
			exit;
		}else{
			showmsg($config['notips']);
		}
    }
} else if ($_GET['act'] == 'log') {
	if(empty($_G['uid'])){
		showmessage(lang('plugin/aljsc','sc2'), '', array(), array('login' => true));
	}
    $shop = C::t('#aljsc#aljsc')->fetch($_GET['sid']);
    if (submitcheck('formhash')) {
		if (in_array($_G['groupid'], $notallowgroups)) {
		   if(defined('IN_MOBILE')){
				echo "<script>parent.tips('".lang('plugin/aljsc','sc23')."');</script>";
				exit;
			}else{
				echo "<script>parent.layer.closeAll();parent.showError('".lang('plugin/aljsc','sc23')."');</script>";
				exit;
			}
		}
        $num = intval($_GET['num']);
        if (empty($num)) {
			if(defined('IN_MOBILE')){
				echo "<script>parent.tips('".lang('plugin/aljsc','sc16')."');</script>";
			}else{
				echo "<script>parent.layer.closeAll();parent.showError('".lang('plugin/aljsc','sc16')."');</script>";
			}
            exit;
        }
        if ($shop['num'] < $num) {
			if(defined('IN_MOBILE')){
				echo "<script>parent.tips('".lang('plugin/aljsc','sc17')."');</script>";
			}else{
				echo "<script>parent.layer.closeAll();parent.showError('".lang('plugin/aljsc','sc17')."');</script>";
			}
            exit;
        }
		if ($shop['e']) {
			$limitnum=DB::result_first('select sum(num) from %t where sid=%d and uid=%d',array('aljsc_log',$_GET['sid'],$_G['uid']));
			if(($limitnum + $num) > $shop['e'] || $num >$shop['e']){
				$lnum=($shop['e']-$limitnum)>=0 ? ($shop['e']-$limitnum):0;
				if(defined('IN_MOBILE')){
					echo "<script>parent.tips('&#27599;&#20154;&#38480;&#25442;".$shop['e']."&#20010;&#65292;&#24744;&#24050;&#20817;&#25442;".$limitnum."&#20010;&#65292;&#36824;&#21487;&#20197;&#20817;&#25442;".$lnum."&#20010;');</script>";
					exit;
				}else{
                    echo "<script>parent.layer.closeAll();parent.showError('&#27599;&#20154;&#38480;&#25442;".$shop['e']."&#20010;&#65292;&#24744;&#24050;&#20817;&#25442;".$limitnum."&#20010;&#65292;&#36824;&#21487;&#20197;&#20817;&#25442;".$lnum."&#20010;');</script>";
				}
			}
		}
        if ($money < $shop['extcredit'] * $num) {
			if(defined('IN_MOBILE')){
				echo "<script>parent.tips('".$_G['setting']['extcredits'][$config['extcredit']]['title'].lang('plugin/aljsc','sc18')."');</script>";
			}else{
				echo "<script>parent.layer.closeAll();parent.showError('".$_G['setting']['extcredits'][$config['extcredit']]['title'].lang('plugin/aljsc','sc18')."');</script>";
			}
            exit;
        }
		if (TIMESTAMP < $shop['starttime']) {
			if(defined('IN_MOBILE')){
				echo "<script>parent.tips('".lang('plugin/aljsc','sc19')."');</script>";
			}else{
				echo "<script>parent.layer.closeAll();parent.showError('".lang('plugin/aljsc','sc19')."');</script>";
			}
            exit;
        }
        if (TIMESTAMP > $shop['endtime']) {
			if(defined('IN_MOBILE')){
				echo "<script>parent.tips('".lang('plugin/aljsc','sc19')."');</script>";
			}else{
				echo "<script>parent.layer.closeAll();parent.showError('".lang('plugin/aljsc','sc19')."');</script>";
			}
            exit;
        }

		$allattrs = C::t('#aljsc#aljsc_attr') -> range();
		foreach($_GET['typename'] as $v){
			$attrs[]=$allattrs[$v]['content'];
		}
		$attrs = implode(',',$attrs);
        $insertarray = array(
            'uid' => $_G['uid'],
            'username' => $_G['username'],
            'sid' => $shop['id'],
            'mode' => $shop['mode'],
            'title' => $shop['title'],
            'extcredit' => $shop['extcredit']*$num,
            'num' => $num,
            'dateline' => TIMESTAMP,
            'a' => $_GET['a'].$attrs,
        );
        updatemembercount($_G['uid'], array($config['extcredit'] => '-' . $num * $shop['extcredit']));
        $insertid = C::t('#aljsc#aljsc_log')->insert($insertarray,true);
        C::t('#aljsc#aljsc')->update_num_by_id($_GET['sid'],$num);
        C::t('#aljsc#aljsc')->update_num2_by_id($_GET['sid'],$num);
		
		$sid = intval($_GET['sid']);
		$kamilist = DB::fetch_all('select * from %t where sid = %d and uid =0 limit %d',array('aljsc_kami',$sid,$num));
		if($kamilist && count($kamilist) == $num){
			DB::query('update %t set status = 1,d = 1 where id=%d',array('aljsc_log',$insertid));
			foreach($kamilist as $kami){
				DB::query('update %t set orderid = %d,dateline = %d,uid =%d,username = %s where mid=%d',array('aljsc_kami',$insertid,TIMESTAMP,$_G['uid'],$_G['username'],$kami['mid']));
			}
			$order = C::t('#aljsc#aljsc_log')->fetch($insertid);
			notification_add($order['uid'], 'system',str_replace('{username}',$order['username'],str_replace('{shopname}','<a href="plugin.php?id=aljsc&act=view&sid='.$order['sid'].'">'.$order['title'].'</a>',$config['fahuotips'])));
			if($config['ismail']){
				$email_first=C::t("common_member")->fetch($order['uid']);
				$email=$email_first['email'];
				sendmail_cron($email,$config['mailtitle'],str_replace('{username}',$order['username'],str_replace('{shopname}','<a href="plugin.php?id=aljsc&act=orderlist&sid='.$order['sid'].'">'.$order['title'].'</a>',$config['fahuotips'])));
			}
			
		}

	
		notification_add($_G['uid'], 'system',str_replace('{username}',$_G['username'],str_replace('{shopname}','<a href="plugin.php?id=aljsc&act=view&sid='.$shop['id'].'">'.$shop['title'].'</a>',$config['suctips'])));
		if($config['ismail']){
			$email_first = C::t("common_member")->fetch($_G['uid']);
			$email = $email_first['email'];
			sendmail_cron($email,$config['mailtitle'],str_replace('{username}',$_G['username'],str_replace('{shopname}','<a href="plugin.php?id=aljsc&act=view&sid='.$shop['id'].'">'.$shop['title'].'</a>',$config['suctips'])));
		}

		foreach(DB::fetch_all('select uid from '.DB::table('common_member').' where groupid in ('.dimplode($groups).')') as $u){
			notification_add($u['uid'], 'system',str_replace('{username}',$_G['username'],str_replace('{shopname}','<a href="plugin.php?id=aljsc&act=view&sid='.$shop['id'].'">'.$shop['title'].'</a>',$config['tsy'])));
			if($config['ismail']){
				$email_first=C::t("common_member")->fetch($u['uid']);
				$email=$email_first['email'];
				sendmail_cron($email,$config['mailtitle'],str_replace('{username}',$_G['username'],str_replace('{shopname}','<a href="plugin.php?id=aljsc&act=view&sid='.$shop['id'].'">'.$shop['title'].'</a>',$config['tsy'])));
			}
			
		}
		if(defined('IN_MOBILE')){
			 echo "<script>parent.tips('".lang('plugin/aljsc','sc20')."',function(){parent.location.href='plugin.php?id=aljsc&act=view&sid=" . $_GET['sid'] . "';});</script>";
		}else{
			 echo "<script>parent.layer.closeAll();parent.showDialog('".lang('plugin/aljsc','sc20')."','right','',function(){parent.location.href='plugin.php?id=aljsc&act=view&sid=" . $_GET['sid'] . "';});</script>";
		}
    } else {
        $user = C::t('#aljsc#aljsc_user')->fetch($_G['uid']);

		$attrs = DB::fetch_all('select * from %t where tid = %d',array('aljsc_attr',$shop['id']));
		foreach($attrs as $attr){
			$goodattrs[$attr['name']][$attr['mid']]['mid'] = $attr['mid'];
			$goodattrs[$attr['name']][$attr['mid']]['content'] = $attr['content'];
		}
		$config['atypes'] = str_replace('\r', '\n', $config['atypes']);
		$atypes = explode("\n", $config['atypes']);
		foreach ($atypes as $k => $type) {
			$type = explode('|', $type);
			$typename[$type[0]] = trim($type[1]);
		}
        include template('aljsc:log');
    }
} else if ($_GET['act'] == 'alipay') {
	if(empty($_G['uid'])){
		showmessage(lang('plugin/aljsc','sc2'), '', array(), array('login' => true));
	}
    $shop = C::t('#aljsc#aljsc')->fetch($_GET['sid']);
	$user = C::t('#aljsc#aljsc_user')->fetch($_G['uid']);

	$attrs = DB::fetch_all('select * from %t where tid = %d',array('aljsc_attr',$shop['id']));
	foreach($attrs as $attr){
		$goodattrs[$attr['name']][$attr['mid']]['mid'] = $attr['mid'];
		$goodattrs[$attr['name']][$attr['mid']]['content'] = $attr['content'];
	}
	$config['atypes'] = str_replace('\r', '\n', $config['atypes']);
	$atypes = explode("\n", $config['atypes']);
	foreach ($atypes as $k => $type) {
		$type = explode('|', $type);
		$typename[$type[0]] = trim($type[1]);
	}
    include template('aljsc:alipay');
}elseif($_GET['act'] == 'wxpay'){
    if(empty($_G['uid'])){
        showmessage(lang('plugin/aljsc','sc2'), '', array(), array('login' => true));
    }

    $_GET=dhtmlspecialchars($_GET);
    $num = intval($_GET['num']);
    $settings=C::t('#aljsc#aljsc_setting')->range();
    $shop=C::t('#aljsc#aljsc')->fetch($_GET['sid']);
    $good=$shop;
    $orderid = dgmdate(TIMESTAMP, 'YmdHis').random(18);

    if(C::t('#aljsc#aljsc_order')->fetch($orderid)) {
        showmessage('credits_addfunds_order_invalid', '', array(), array('showdialog' => 1, 'showmsg' => true, 'closetime' => true));
    }

    if (in_array($_G['groupid'], $notallowgroups)) {
        showmessage(lang('plugin/aljsc','sc23'));
    }
    if ($shop['e']) {
        $limitnum=DB::result_first('select sum(amount) from %t where sid=%d and uid=%d',array('aljsc_order',$_GET['sid'],$_G['uid']));

        if(($limitnum + $num) > $shop['e'] || $num >$shop['e']){
            $lnum=($shop['e']-$limitnum)>=0 ? ($shop['e']-$limitnum):0;
            showmessage('&#27599;&#20154;&#38480;&#25442;'.$shop['e'].'&#20010;&#65292;&#24744;&#24050;&#20817;&#25442;'.$limitnum.'&#20010;&#65292;&#36824;&#21487;&#20197;&#20817;&#25442;'.$lnum.'&#20010;');
        }
    }

    if (empty($num)) {
        showmessage(lang('plugin/aljsc','sc16'));
    }
    if ($shop['num'] < $num) {
        showmessage(lang('plugin/aljsc','sc17'));
    }
    if (TIMESTAMP < $shop['starttime']) {
        showmessage(lang('plugin/aljsc','sc19'));
    }
    if (TIMESTAMP > $shop['endtime']) {
        showmessage(lang('plugin/aljsc','sc19'));
    }

    C::t('#aljsc#aljsc')->update_num_by_id($_GET['sid'],$num);
    C::t('#aljsc#aljsc')->update_num2_by_id($_GET['sid'],$num);

    $allattrs = C::t('#aljsc#aljsc_attr') -> range();
    foreach($_GET['typename'] as $v){
        $attrs[]=$allattrs[$v]['content'];
    }
    C::t('#aljsc#aljsc_order')->insert(array(
        'orderid' => $orderid,
        'status' => '1',
        'uid' => $_G['uid'],
        'username' => $_G['username'],
        'sid' => $_GET['sid'],
        'stitle' => $shop['title'],
        'amount' => $num,
        'price' => $shop['price'],
        'submitdate' => $_G['timestamp'],
        'a' => $_GET['a'].$attrs,
    ));
    showmessage('&#19979;&#21333;&#25104;&#21151;', 'plugin.php?id=aljsc:wxpay&orderid='.$orderid, array(), array('header' => true));
} else if ($_GET['act'] == 'order') {
	if(empty($_G['uid'])){
		showmessage(lang('plugin/aljsc','sc2'), '', array(), array('login' => true));
	}
	//$_G['setting']['switchwidthauto'] = 1;
	//$_G['setting']['allowwidthauto'] = 0;
    $status = $_GET['status'] ? $_GET['status'] : 0;
    $navtitle = lang('plugin/aljsc','sc8');
	if($settings['is_mobile_template']['value'] && $_G['cache']['plugin']['aljgwc']['aljsc'] && $_G['mobile']){
		include template('aljsc:new/order');
	}else{
		$page = intval($_GET['page']);
		$currpage = $page ? $page : 1;
		$perpage = 10;
		if($_G['charset']=='gbk'&&defined('IN_MOBILE')&&!$_GET['sj']){
			$_GET['title']=diconv($_GET['title'],'utf-8','gbk');
			$_GET['username']=diconv($_GET['username'],'utf-8','gbk');
		}
		$con[]='aljsc_log';
		$where.='where mode=%d';
		$con[]=1;
		if($_GET['title']){
			$con[] = '%' . addcslashes($_GET['title'], '%_') . '%';
			$where.=" and title like %s";
		}
		if($_GET['username']){
			$con[] = '%' . addcslashes($_GET['username'], '%_') . '%';
			$where.=" and username like %s";
		}
		
		if($_GET['s_time']){
			$where.=' and dateline >= %d';
			$con[]=strtotime($_GET['s_time']);
		}

		if($_GET['e_time']){
			$where.=' and dateline <= %d';
			$con[]=strtotime($_GET['e_time']);
		}
		if (in_array($_G['groupid'], $groups)) {
			$num = DB::result_first("select count(*) from %t ".$where,$con);
		} else {
			$where.=' and uid=%d';
			$con[]=$_G['uid'];
			$num = DB::result_first("select count(*) from %t ".$where,$con);
		}
		
		$start = ($currpage - 1) * $perpage;
		$where.=' order by id desc';
		if(!empty($perpage)){
			$con[]=$start;
			$con[]=$perpage;
			$where.=' limit %d,%d';
		}
		if (in_array($_G['groupid'], $groups)) {
			$loglist = DB::fetch_all('select * from %t '.$where,$con);;
		} else {
			$loglist = DB::fetch_all('select * from %t '.$where,$con);
		}
		//debug($loglist);
		$paging = helper_page :: multi($num, $perpage, $currpage, 'plugin.php?id=aljsc&act=order&groupid='.$_G['groupid'].'&title='.$_GET['title'].'&username='.$_GET['username'].'&s_time='.$_GET['s_time'].'&e_time='.$_GET['e_time'], 0, 11, false, false);
		include template('aljsc:order');
	}
}else if($_GET[act] == 'mobile_member_goods'){//�ҵĶһ�/�н���¼
	$currpage=$_GET['page']?$_GET['page']:1;
	$perpage=10;
	$start=($currpage-1)*$perpage;
	
	$con[]='aljsc_log';
	$where.='where mode=%d ';
	if($_GET['mode']){
		$form ='rewardinfo';
		$con[]=2;
		$where.=' and isnot=%d ';
		$con[]=1;
	}else{
		$form ='order';
		$con[]=1;
	}
	
	if($_GET['status'] == 1){
		$where .= 'and status=0';
	}else if($_GET['status'] == 2){
		$where .= 'and status=1';
	}else if($_GET['status'] == 3){
		$where .= 'and status>=2';
	}
	if($_GET['title']){
		$con[] = '%' . addcslashes($_GET['title'], '%_') . '%';
		$where.=" and title like %s";
	}
	if($_GET['username']){
		$con[] = '%' . addcslashes($_GET['username'], '%_') . '%';
		$where.=" and username like %s";
	}
	
	if($_GET['s_time']){
		$where.=' and dateline >= %d';
		$con[]=strtotime($_GET['s_time']);
	}

	if($_GET['e_time']){
		$where.=' and dateline <= %d';
		$con[]=strtotime($_GET['e_time']);
	}
	if (in_array($_G['groupid'], $groups)) {
        $num = DB::result_first("select count(*) from %t ".$where,$con);
    } else {
		$where.=' and uid=%d';
		$con[]=$_G['uid'];
        $num = DB::result_first("select count(*) from %t ".$where,$con);
    }
	
    $start = ($currpage - 1) * $perpage;
	$where.=' order by id desc';
	if(!empty($perpage)){
		$con[]=$start;
		$con[]=$perpage;
		$where.=' limit %d,%d';
	}
	
    if (in_array($_G['groupid'], $groups)) {
		$member_goods = DB::fetch_all('select * from %t '.$where,$con);;
    } else {
        $member_goods = DB::fetch_all('select * from %t '.$where,$con);
    }
	
	$max = ceil($num/$perpage);
	if($currpage == 1){
		$max_page ='<input type="hidden" id="max-page" value="'.$max.'">';
	}
	include template($pluginid.':new/member_goods');
}else if ($_GET['act'] == 'orderlist'){
	//$_G['setting']['switchwidthauto'] = 1;
	//$_G['setting']['allowwidthauto'] = 0;

	$currpage=intval($_GET['page'])?intval($_GET['page']):1;
	$perpage=10;
	$start=($currpage-1)*$perpage;
	$con[]='aljsc_order';
	if (!in_array($_G['groupid'], $groups)) {
		$where.='where uid=%d';
		$con[]=$_G['uid'];
	}
	if($_GET['title']){
		$con[] = '%' . addcslashes($_GET['title'], '%_') . '%';
		$where.=" and stitle like %s";
	}
	if($_GET['orderid']){
		$con[] = '%' . addcslashes($_GET['orderid'], '%_') . '%';
		$where.=" and orderid like %s";
	}
	
	if($_GET['s_time']){
		$where.=' and submitdate >= %d';
		$con[]=strtotime($_GET['s_time']);
	}

	if($_GET['e_time']){
		$where.=' and submitdate <= %d';
		$con[]=strtotime($_GET['e_time']);
	}

	$num=DB::result_first('select count(*) from %t '.$where,$con);
	$where.=' order by submitdate desc';
	if(!empty($perpage)){
		$con[]=$start;
		$con[]=$perpage;
		$where.=' limit %d,%d';
	}
	$orderlist=DB::fetch_all('select * from %t '.$where,$con);
	$paging = helper_page :: multi($num, $perpage, $currpage, 'plugin.php?id=aljsc&act=orderlist'.'&orderid='.$_GET['orderid'].'&title='.$_GET['title'].'&s_time='.$_GET['s_time'].'&e_time='.$_GET['e_time'], 0, 11, false, false);
	include template('aljsc:orderlist');
} else if ($_GET['act'] == 'rewardrecord') {
	if(empty($_G['uid'])){
		showmessage(lang('plugin/aljsc','sc2'), '', array(), array('login' => true));
	}
	if($settings['is_mobile_template']['value'] && $_G['cache']['plugin']['aljgwc']['aljsc'] && $_G['mobile']){
		$navtitle = lang('plugin/aljsc','sc8');
		include template('aljsc:new/rewardrecord');
	}else{

		//$_G['setting']['switchwidthauto'] = 1;
		//$_G['setting']['allowwidthauto'] = 0;
		$page = intval($_GET['page']);
		$currpage = $page ? $page : 1;
		$perpage = 10;
		//$num = C::t('#aljsc#aljsc_log')->count();
		$start = ($currpage - 1) * $perpage;
		if($_G['charset']=='gbk'&&defined('IN_MOBILE')&&!$_GET['sj']){
			$_GET['title']=diconv($_GET['title'],'utf-8','gbk');
			$_GET['username']=diconv($_GET['username'],'utf-8','gbk');
		}
		//debug($loglist);
		$con[]='aljsc_log';
		$where.='where mode=%d';
		$con[]=2;
		//$where.=' and isnot=%d';
		//$con[]=1;
		if($_GET['title']){
			$con[] = '%' . addcslashes($_GET['title'], '%_') . '%';
			$where.=" and title like %s";
		}
		if($_GET['username']){
			$con[] = '%' . addcslashes($_GET['username'], '%_') . '%';
			$where.=" and username like %s";
		}
		
		if($_GET['s_time']){
			$where.=' and dateline >= %d';
			$con[]=strtotime($_GET['s_time']);
		}

		if($_GET['e_time']){
			$where.=' and dateline <= %d';
			$con[]=strtotime($_GET['e_time']);
		}
		if (in_array($_G['groupid'], $groups)) {
			$num = DB::result_first("select count(*) from %t ".$where,$con);
		} else {
			$where.=' and uid=%d';
			$con[]=$_G['uid'];
			$num = DB::result_first("select count(*) from %t ".$where,$con);
		}
		
		$start = ($currpage - 1) * $perpage;
		$where.=' order by id desc';
		if(!empty($perpage)){
			$con[]=$start;
			$con[]=$perpage;
			$where.=' limit %d,%d';
		}
		if (in_array($_G['groupid'], $groups)) {
			$loglist = DB::fetch_all('select * from %t '.$where,$con);;
		} else {
			$loglist = DB::fetch_all('select * from %t '.$where,$con);
		}
		$paging = helper_page :: multi($num, $perpage, $currpage, 'plugin.php?id=aljsc&act=rewardrecord&groupid='.$_G['groupid'].'&title='.$_GET['title'].'&username='.$_GET['username'].'&s_time='.$_GET['s_time'].'&e_time='.$_GET['e_time'], 0, 11, false, false);
		$navtitle = lang('plugin/aljsc','sc8');
		include template('aljsc:rewardrecord');
	}
}else if($_GET[act] == 'mobile_rewardrecord'){//�ҵĳ齱��¼
	$currpage=$_GET['page']?$_GET['page']:1;
	$perpage=10;
	$start=($currpage-1)*$perpage;
	
	$con[]='aljsc_log';
	$where.='where mode=%d ';
	$con[]=2;
	if($_GET['title']){
		$con[] = '%' . addcslashes($_GET['title'], '%_') . '%';
		$where.=" and title like %s";
	}
	if($_GET['username']){
		$con[] = '%' . addcslashes($_GET['username'], '%_') . '%';
		$where.=" and username like %s";
	}
	
	if($_GET['s_time']){
		$where.=' and dateline >= %d';
		$con[]=strtotime($_GET['s_time']);
	}

	if($_GET['e_time']){
		$where.=' and dateline <= %d';
		$con[]=strtotime($_GET['e_time']);
	}
	if (in_array($_G['groupid'], $groups)) {
        $num = DB::result_first("select count(*) from %t ".$where,$con);
    } else {
		$where.=' and uid=%d';
		$con[]=$_G['uid'];
        $num = DB::result_first("select count(*) from %t ".$where,$con);
    }
	
    $start = ($currpage - 1) * $perpage;
	$where.=' order by id desc';
	if(!empty($perpage)){
		$con[]=$start;
		$con[]=$perpage;
		$where.=' limit %d,%d';
	}
    if (in_array($_G['groupid'], $groups)) {
		$member_goods = DB::fetch_all('select * from %t '.$where,$con);;
    } else {
        $member_goods = DB::fetch_all('select * from %t '.$where,$con);
    }
	
	$max = ceil($num/$perpage);
	if($currpage == 1){
		$max_page ='<input type="hidden" id="max-page" value="'.$max.'">';
	}
	include template($pluginid.':new/mobile_rewardrecord');
}  else if ($_GET['act'] == 'rewardinfo') {
	if(empty($_G['uid'])){
		showmessage(lang('plugin/aljsc','sc2'), '', array(), array('login' => true));
	}
	$status = $_GET['status'] ? $_GET['status'] : 0;
	if($settings['is_mobile_template']['value'] && $_G['cache']['plugin']['aljgwc']['aljsc'] && $_G['mobile']){
		$navtitle = lang('plugin/aljsc','sc8');
		include template('aljsc:new/rewardinfo');
	}else{
		//$_G['setting']['switchwidthauto'] = 1;
		//$_G['setting']['allowwidthauto'] = 0;
		$page = intval($_GET['page']);
		$currpage = $page ? $page : 1;
		$perpage = 10;
	   // $num = C::t('#aljsc#aljsc_log')->count();
		$start = ($currpage - 1) * $perpage;
		if($_G['charset']=='gbk'&&defined('IN_MOBILE')&&!$_GET['sj']){
			$_GET['title']=diconv($_GET['title'],'utf-8','gbk');
			$_GET['username']=diconv($_GET['username'],'utf-8','gbk');
		}
		$con[]='aljsc_log';
		$where.='where mode=%d';
		$con[]=2;
		$where.=' and isnot=%d';
		$con[]=1;
		if($_GET['title']){
			$con[] = '%' . addcslashes($_GET['title'], '%_') . '%';
			$where.=" and title like %s";
		}
		if($_GET['username']){
			$con[] = '%' . addcslashes($_GET['username'], '%_') . '%';
			$where.=" and username like %s";
		}
		
		if($_GET['s_time']){
			$where.=' and dateline >= %d';
			$con[]=strtotime($_GET['s_time']);
		}

		if($_GET['e_time']){
			$where.=' and dateline <= %d';
			$con[]=strtotime($_GET['e_time']);
		}
		if (in_array($_G['groupid'], $groups)) {
			$num = DB::result_first("select count(*) from %t ".$where,$con);
		} else {
			$where.=' and uid=%d';
			$con[]=$_G['uid'];
			$num = DB::result_first("select count(*) from %t ".$where,$con);
		}
		
		$start = ($currpage - 1) * $perpage;
		$where.=' order by id desc';
		if(!empty($perpage)){
			$con[]=$start;
			$con[]=$perpage;
			$where.=' limit %d,%d';
		}
		if (in_array($_G['groupid'], $groups)) {
			$loglist = DB::fetch_all('select * from %t '.$where,$con);;
		} else {
			$loglist = DB::fetch_all('select * from %t '.$where,$con);
		}
		$paging = helper_page :: multi($num, $perpage, $currpage, 'plugin.php?id=aljsc&act=rewardinfo&groupid='.$_G['groupid'].'&title='.$_GET['title'].'&username='.$_GET['username'].'&s_time='.$_GET['s_time'].'&e_time='.$_GET['e_time'], 0, 11, false, false);
		$navtitle = lang('plugin/aljsc','sc8');
		include template('aljsc:rewardinfo');
	}
}else if ($_GET['act'] == 'dellog') {
	if(empty($_G['uid'])){
		showmessage(lang('plugin/aljsc','sc2'), '', array(), array('login' => true));
	}
    if (!in_array($_G['groupid'], $groups)) {
        debug('Access Denied!');
    }
    if ($_GET['formhash'] != formhash() || !submitcheck('act', 1) || preg_replace("/https?:\/\/([^\:\/]+).*/i", "\\1", $_SERVER['HTTP_REFERER']) != preg_replace("/([^\:]+).*/", "\\1", $_SERVER['HTTP_HOST'])) {
        debug('Access Denied!');
    }
    C::t('#aljsc#aljsc_log')->delete($_GET['lid']);
    showmessage(lang('plugin/aljsc','sc7'), 'plugin.php?id=aljsc&act=' . $_GET['from']);
}else if($_GET['act'] == 'receipt'){
	$order = C::t('#aljsc#aljsc_log') -> fetch($_GET['orderid']);
	if($order['uid'] == $_G['uid']){
		DB::query("update %t set status=2 where id = %s",array('aljsc_log',$_GET['orderid']));
	}
	showmessage('&#30830;&#35748;&#25910;&#36135;&#25104;&#21151;','plugin.php?id=aljsc&act=order&status=2');
} else if ($_GET['act'] == 'fahuo') {
	if(empty($_G['uid'])){
		showmessage(lang('plugin/aljsc','sc2'), '', array(), array('login' => true));
	}
    if (!in_array($_G['groupid'], $groups)) {
        debug('Access Denied!');
    }
    if(submitcheck('formhash')){
		if(C::t('#aljsc#aljsc_wuliu')->fetch($_GET['orderid'])){
			C::t('#aljsc#aljsc_wuliu')->update($_GET['orderid'],array(
				'companyname' => $_GET['companyname'],
				'worderid' => $_GET['worderid'],
				'updatetime' => TIMESTAMP,
			));

			C::t('#aljsc#aljsc_log')->update_status_by_id($_GET['orderid']);

			$order = C::t('#aljsc#aljsc_log')->fetch($_GET['orderid']);
			notification_add($order['uid'], 'system',str_replace('{username}',$order['username'],str_replace('{shopname}','<a href="plugin.php?id=aljsc&act=view&sid='.$order['sid'].'">'.$order['title'].'</a>',$config['fahuotips'])));
			if($config['ismail']){
				$email_first=C::t("common_member")->fetch($order['uid']);
				$email=$email_first['email'];
				sendmail_cron($email,$config['mailtitle'],str_replace('{username}',$order['username'],str_replace('{shopname}','<a href="plugin.php?id=aljsc&act=view&sid='.$order['sid'].'">'.$order['title'].'</a>',$config['fahuotips'])));
			}

			showmessage(lang('plugin/aljsc','sc1'), 'plugin.php?id=aljsc&act=' . $_GET['from']);
		}else{
			C::t('#aljsc#aljsc_wuliu')->insert(array(
				'orderid' => $_GET['orderid'],
				'type' => 2,
				'companyname' => $_GET['companyname'],
				'worderid' => $_GET['worderid'],
				'dateline' => TIMESTAMP,
			));
			C::t('#aljsc#aljsc_log')->update_status_by_id($_GET['orderid']);

			$order = C::t('#aljsc#aljsc_log')->fetch($_GET['orderid']);
			notification_add($order['uid'], 'system',str_replace('{username}',$order['username'],str_replace('{shopname}','<a href="plugin.php?id=aljsc&act=view&sid='.$order['sid'].'">'.$order['title'].'</a>',$config['fahuotips'])));
			if($config['ismail']){
				$email_first=C::t("common_member")->fetch($order['uid']);
				$email=$email_first['email'];
				sendmail_cron($email,$config['mailtitle'],str_replace('{username}',$order['username'],str_replace('{shopname}','<a href="plugin.php?id=aljsc&act=view&sid='.$order['sid'].'">'.$order['title'].'</a>',$config['fahuotips'])));
			}

			showmessage(lang('plugin/aljsc','sc1'), 'plugin.php?id=aljsc&act=' . $_GET['from']);
		}
	}else{
		$wuliu = C::t('#aljsc#aljsc_wuliu')->fetch($_GET['orderid']);
		include template('aljsc:wuliu');
	}
} else if ($_GET['act'] == 'viewwuliu') {
	$wuliu = C::t('#aljsc#aljsc_wuliu')->fetch($_GET['orderid']);
	include template('aljsc:viewwuliu');
}else if ($_GET['act'] == 'so') {
	if(empty($_G['uid'])){
		showmessage(lang('plugin/aljsc','sc2'), '', array(), array('login' => true));
	}
    $loglist = C::t('#aljsc#aljsc_log')->range(0, 10, 'desc');
    $shoplist = C::t('#aljsc#aljsc')->fetch_all_by_so($_GET['srchtxt']);
    include template('aljsc:index');
} else if ($_GET['act'] == 'list') {
	$_GET = dhtmlspecialchars($_GET);
	$typename = $typearr[$_GET['type']];
	$navtitle = $typename.$config['title'];
	$metakeywords =  $typename.$config['title'];
	$metadescription = $typename;
	$op = $_GET['op'];
	if($_G['mobile'] && $settings['is_mobile_template']['value'] && $_G['cache']['plugin']['aljgwc']['aljsc']){
		if($op == 'search'){
			$title = $aljlang['Search_goods'];
			$search_url = 'plugin.php?id=aljsc&act=list&op=list_search&keywords=';
			include template($pluginid.':new/search');
		}else if($op == 'list_search'){
			$keywords = $_GET['keywords'];
			include template($pluginid.':new/list_search');
		}else{
			//$typelist=C::t('#'.$pluginid.'#'.$pluginid.'_type')->fetch_all_by_upid(0);
			
			$title = $aljlang['All_goods'];
			if($_GET['type']){
				$type = $_GET['type'];
			}else{
				$type = 0;
			}
			include template('aljsc:new/goodslist');
		}
	}else{
		
		foreach ($piclist as $p => $pic) {
			$$pic = C::t('#aljsc#aljsc_setting')->fetch($pic);
			$p = $$pic;
			$p['value'] = unserialize($p['value']);
			$url = $pic . 'url';
			$$url = C::t('#aljsc#aljsc_setting')->fetch($url);
			$url = $$url;
			$url['value'] = unserialize($url['value']);
			foreach ($p['value'] as $k => $v) {
				$b = $pic . 's';
				$b = $$b;
				$a[] = array('imgUrl' => $v, 'url' => $url['value'][$k]);
			}
			$$pic = $a;
			unset($a);
		}
		$conn = array(
			'type' => $_GET['type'],
			's' => $_GET['s'],
			'e' => $_GET['e'],
			'yes' => $_GET['yes'],
			'order' => $_GET['order'],
			'desc' => $_GET['desc']
		);
		$conn = http_build_query($conn);
		$page = intval($_GET['page']);
		$currpage = $page ? $page : 1;
		$perpage = 16;
		$kw = '%'.stripsearchkey($_GET['kw']).'%';
		$num = C::t('#aljsc#aljsc')->count_by_type($_GET['type'], $_GET['s'], $_GET['e'], $_GET['yes'],$kw);
		$start = ($currpage - 1) * $perpage;
		$goodslist = C::t('#aljsc#aljsc')->fetch_all_by_type($_GET['type'], $_GET['order'], $_GET['desc'], $start, $perpage, $_GET['s'], $_GET['e'], $_GET['yes'],$kw);
		foreach($goodslist as $k=>$v){
			$goodslist[$k]['rewrite']=str_replace ("{id}", $v['id'], $config ['re_view']);
		}
		$paging = helper_page :: multi($num, $perpage, $currpage, 'plugin.php?id=aljsc&act=list&' . $conn, 0, 11, false, false);
		
		include template('aljsc:list');
	}
}else if($_GET['act'] == 'mobile_list_goods'){//��Ʒ�б�
	$con = 'where 1';
	if($_GET['type']){
		if($_GET['type'] == 1000){
			$con.= ' and recomened=1';
		}else{
			$con.= ' and type='.intval($_GET['type']);
		}
	}
	if($_GET['order'] == 'addtime'){
		$con.= ' order by dateline desc';
	}else if($_GET['order'] == 'publictime'){
		$con.= ' order by num asc';
	}else if($_GET['order'] == 'favorate'){
		$con.= ' order by pv desc';
	}else if($_GET['order'] == 'totalpriceup'){
		$con.= ' order by price asc,extcredit asc';
	}else if($_GET['order'] == 'totalpricedown'){
		$con.= ' order by price desc,extcredit desc';
	}
	
	$currpage=$_GET['page']?$_GET['page']:1;
	$perpage=10;
	$start=($currpage-1)*$perpage;
	$num = DB::result_first('select count(*) from %t '.$con,array($pluginid));
	$max = ceil($num/$perpage);
	if($currpage == 1){
		$max_page ='<input type="hidden" id="max-page" value="'.$max.'">';
	}
	
	if($currpage == $max || empty($max)){
		$mes = '<div class="c_click_see" id="more" style="background: none;float: left;">'.$aljsclang['php']['No_more_data'].'</div>';
	}
	
	$goodslist = DB::fetch_all('select * from %t '.$con.' limit %d,%d',array($pluginid,$start,$perpage));
	include template($pluginid.':new/list_goods');
} else if($_GET['act'] == 'viewqrcode'){
	require_once DISCUZ_ROOT.'source/plugin/aljsc/class/qrcode.class.php';
	$file = 'source/plugin/aljsc/images/qrcode.jpg'; 
	unlink($file);
	if(!file_exists($file)){
		QRcode::png($_G['siteurl'].'plugin.php?id=aljsc',$file, QR_MODE_STRUCTURE, 8);
	}
	include template('aljsc:viewqrcode');
} else if($_GET['act'] == 'addkami'){
	if(!in_array($_G['groupid'], $groups)){
		showmessage('&#27809;&#26377;&#26435;&#38480;&#65281;');
	}
	$sid = intval($_GET['sid']);
	include template('aljsc:addkami');
	
} else if($_GET['act'] == 'addkamisubmit'){
	if(submitcheck('formhash')){
		if($_GET['message']){
			$messages = explode ("\n", str_replace ("\r", "", $_GET['message']));
			foreach($messages as $message){
				C::t('#aljsc#aljsc_kami') -> insert(array(
					'sid' => $_GET['sid'],
					'message' => $message,
					'addtime' => TIMESTAMP,
				));
			}
		}
		showmessage('&#28155;&#21152;&#25104;&#21151;&#65281;','plugin.php?id=aljsc&act=admin');
	}
} else if($_GET['act']=='kamilist'){
	$sid= intval($_GET['sid']);
	if($sid){
		$currpage=intval($_GET['page'])?intval($_GET['page']):1;
		$perpage=10;
		$start=($currpage-1)*$perpage;
		$num=DB::result_first('select count(*) from %t where sid = %d',array('aljsc_kami',$sid));
		$kamilist=DB::fetch_all('select * from %t where sid = %d order by mid desc limit %d,%d',array('aljsc_kami',$sid,$start,$perpage));
		$paging = helper_page :: multi($num, $perpage, $currpage, 'plugin.php?id=aljsc&act=kamilist&sid='.$sid, 0, 11, false, false);
		include template('aljsc:kamilist');
	}
} else if($_GET['act']=='deletekami'){
	$mid= intval($_GET['mid']);
	$sid= intval($_GET['sid']);
	if($mid && $sid && $_GET['formhash'] == formhash()){
		C::t('#aljsc#aljsc_kami') -> delete($mid);
		$currpage=intval($_GET['page'])?intval($_GET['page']):1;
		$perpage=10;
		$start=($currpage-1)*$perpage;
		$num=DB::result_first('select count(*) from %t where sid = %d',array('aljsc_kami',$sid));
		$kamilist=DB::fetch_all('select * from %t where sid = %d order by mid desc',array('aljsc_kami',$sid));
		$paging = helper_page :: multi($num, $perpage, $currpage, 'plugin.php?id=aljsc&act=kamilist&sid='.$sid, 0, 11, false, false);
		include template('aljsc:kamilist');
	}
} else if($_GET['act']=='viewkami'){
	$orderid= intval($_GET['orderid']);
	if($orderid){
		$currpage=intval($_GET['page'])?intval($_GET['page']):1;
		$perpage=10;
		$start=($currpage-1)*$perpage;
		$num=DB::result_first('select count(*) from %t where orderid = %d',array('aljsc_kami',$orderid));
		$kamilist=DB::fetch_all('select * from %t where orderid = %d order by mid desc',array('aljsc_kami',$orderid));
		$paging = helper_page :: multi($num, $perpage, $currpage, 'plugin.php?id=aljsc&act=viewkami&orderid='.$orderid, 0, 11, false, false);
		include template('aljsc:viewkami');
	}
} else if($_GET['act'] == 'addattr'){
	if(!in_array($_G['groupid'], $groups)){
		showmessage('&#27809;&#26377;&#26435;&#38480;&#65281;');
	}
	$tid = intval($_GET['tid']);

	$config['atypes'] = str_replace('\r', '\n', $config['atypes']);
	$atypes = explode("\n", $config['atypes']);
	foreach ($atypes as $k => $type) {
		$type = explode('|', $type);
		$typename[$type[0]] = trim($type[1]);
	}

	include template('aljsc:addattr');
	
} else if($_GET['act'] == 'addattrsubmit'){
	if(submitcheck('formhash')){
		if($_GET['content']){
			$contents = explode ("\n", str_replace ("\r", "", $_GET['content']));
			foreach($contents as $content){
				C::t('#aljsc#aljsc_attr') -> insert(array(
					'tid' => $_GET['tid'],
					'name' => $_GET['name'],
					'content' => $content,
					'addtime' => TIMESTAMP,
				));
			}
		}
		echo '<script>alert("'.lang('plugin/aljsc','s1').'");</script>';
		exit;
	}
} else if($_GET['act']=='attrlist'){
	$tid= intval($_GET['tid']);
	if($tid){
		$thisgood = C::t('#aljsc#aljsc')->fetch($tid);
		$currpage=intval($_GET['page'])?intval($_GET['page']):1;
		$perpage=10;
		$start=($currpage-1)*$perpage;
		$num=DB::result_first('select count(*) from %t where tid = %d',array('aljsc_attr',$tid));
		$attrlist=DB::fetch_all('select * from %t where tid = %d order by mid desc limit %d,%d',array('aljsc_attr',$tid,$start,$perpage));
		$paging = helper_page :: multi($num, $perpage, $currpage, 'plugin.php?id=aljsc&act=attrlist&tid='.$tid, 0, 11, false, false);
		$config['atypes'] = str_replace('\r', '\n', $config['atypes']);
		$atypes = explode("\n", $config['atypes']);
		foreach ($atypes as $k => $type) {
			$type = explode('|', $type);
			$goodtypename[$type[0]] = trim($type[1]);
		}
		include template('aljsc:attrlist');
	}
} else if($_GET['act']=='deleteattr'){
	$tid= intval($_GET['tid']);
	$mid= intval($_GET['mid']);
	if($mid && $tid && $_GET['formhash'] == formhash()){
		$thisgood = C::t('#aljsc#aljsc')->fetch($tid);
		C::t('#aljsc#aljsc_attr') -> delete($mid);
		$currpage=intval($_GET['page'])?intval($_GET['page']):1;
		$perpage=10;
		$start=($currpage-1)*$perpage;
		$num=DB::result_first('select count(*) from %t where tid = %d',array('aljsc_attr',$tid));
		$attrlist=DB::fetch_all('select * from %t where tid = %d order by mid desc limit %d,%d',array('aljsc_attr',$tid,$start,$perpage));
		$paging = helper_page :: multi($num, $perpage, $currpage, 'plugin.php?id=aljsc&act=attrlist&tid='.$tid, 0, 11, false, false);
		$config['atypes'] = str_replace('\r', '\n', $config['atypes']);
		$atypes = explode("\n", $config['atypes']);
		foreach ($atypes as $k => $type) {
			$type = explode('|', $type);
			$goodtypename[$type[0]] = trim($type[1]);
		}
		include template('aljsc:attrlist');
	}
} else if($_GET['act'] == 'user'){
	if(empty($_G['uid'])){
		showmessage(lang('plugin/aljsc','sc2'), 'member.php?mod=logging&action=login&referer=plugin.php?id='.$pluginid.'%26act='.$_GET['act']);
	}
	if($_G['mobile'] && $settings['is_mobile_template']['value'] && $_G['cache']['plugin']['aljgwc']['aljsc']){
		$_GET = dhtmlspecialchars($_GET);
		$op = $_GET['op'];
		loaducenter();
		if($op == 'pm'){
			$page = empty($_GET['page']) ? 0 : intval($_GET['page']);
			$touid = empty($_GET['touid'])?0:intval($_GET['touid']);
			if($_GET['subop'] == 'view'){
				
				if($touid) {
					$ols = array();
					if(defined('IN_MOBILE')) {
						$perpage = 5;
					} else {
						$perpage = 10;
					}
					
					//$perpage = mob_perpage($perpage);
					
					$member = getuserbyuid($touid);
					$tousername = $member['username'];
					unset($member);
					$count = uc_pm_view_num($_G['uid'], $touid, 0);
					if(!$page) {
						$page = ceil($count/$perpage);
					}
					$list = uc_pm_view($_G['uid'], 0, $touid, 5, ceil($count/$perpage)-$page+1, $perpage, 0, 0);
					$multi = pmmulti($count, $perpage, $page, "plugin.php?id=aljyg&act=member&op=pm&subop=view&touid=$touid");
				}
				
				$founderuid = empty($list)?0:$list[0]['founderuid'];
				$pmid = empty($list)?0:$list[0]['pmid'];
			}else{
				$filter = in_array($_GET['filter'], array('newpm', 'privatepm', 'announcepm')) ? $_GET['filter'] : 'privatepm';
				$perpage = 15;
				$page = empty($_GET['page'])?0:intval($_GET['page']);
				if($page<1) $page = 1;
				$newpm = $newpmcount = 0;
				if($filter == 'privatepm' || $filter == 'newpm') {
					$result = uc_pm_list($_G['uid'], $page, $perpage, 'inbox', $filter, 200);
					$count = $result['count'];
					$list = $result['data'];
				}
				if($filter == 'privatepm' && $page == 1 || $filter == 'newpm') {
					$newpmarr = uc_pm_checknew($_G['uid'], 1);
					$newpm = $newpmarr['newpm'];
				}
				$newpmcount = $newpm + $announcepm;
				if($_G['member']['newpm']) {
					if($newpm && $_G['setting']['cloud_status']) {
						$msgService = Cloud::loadClass('Cloud_Service_Client_Message');
						$msgService->setMsgFlag($_G['uid'], $_G['timestamp']);
					}
					C::t('common_member')->update($_G['uid'], array('newpm' => 0));
					uc_pm_ignore($_G['uid']);
				}
				$multi = multi($count, $perpage, $page, "plugin.php?id=aljyg&act=member&op=pm&subop=view&touid=".$_G['uid'], 0, 5);
			}
			if(!empty($list)) {
				$today = $_G['timestamp'] - ($_G['timestamp'] + $_G['setting']['timeoffset'] * 3600) % 86400;
				foreach ($list as $key => $value) {
					$value['lastsummary'] = str_replace('&amp;', '&', $value['lastsummary']);
					$value['lastsummary'] = preg_replace("/&[a-z]+\;/i", '', $value['lastsummary']);
					$value['daterange'] = 5;
					if($value['lastdateline'] >= $today) {
						$value['daterange'] = 1;
					} elseif($value['lastdateline'] >= $today - 86400) {
						$value['daterange'] = 2;
					} elseif($value['lastdateline'] >= $today - 172800) {
						$value['daterange'] = 3;
					} elseif($value['lastdateline'] >= $today - 604800) {
						$value['daterange'] = 4;
					}
					$list[$key] = $value;
				}
			}
			$navtitle = '&#26597;&#30475;&#28040;&#24687;';
			include template($pluginid.':new/pm');
		}else if($op == 'notice'){
			$gglist = str_replace($config['gg'], '\r', '\n');
			$gglist = explode("\n", $config['gg']);
			$navtitle = '&#26368;&#26032;&#20844;&#21578;';
			include template($pluginid.':new/notice');
		}else if($op == 'set'){
			$navtitle = '&#35774;&#32622;&#24110;&#21161;';
			include template($pluginid.':new/set');
		}else if($op == 'problem'){
			$member_problem = explode ("\n", str_replace ("\r", "", $settings['member_problem']['value']));
			foreach($member_problem as $key=>$value){
				$arr=explode('|',$value);
				$member_problem_types[]=$arr;
			}
			$navtitle = '&#24120;&#35265;&#38382;&#39064;';
			include template($pluginid.':new/problem');
		}else if($op == 'about'){
			$navtitle = '&#20851;&#20110;&#25105;&#20204;';
			include template($pluginid.':new/about');
		}else{
			include template('aljsc:new/member');
		}
	}else{
		include template('aljsc:user');
	}
}else if($_GET['act'] == 'mobile_index_count'){//�� ��ҳ�һ���
	$count = DB::result_first('SELECT sum(num) FROM %t where status>0',array($pluginid.'_log'));
	echo $settings['exchange_times']['value']+$count;
	exit;
}else if($_GET['act'] == 'mobile_index_announced'){//�� �Ƽ�
	$announced = C::t('#aljsc#aljsc')->fetch_all_by_recomened(0,4);
	include template('aljsc:new/mobile_index_announced');
}else if($_GET['act'] == 'mobile_index_goods'){//�� ��ҳ��������Ʒ
	$con = 'where 1 ';
	$where[] = $pluginid;
	if($_GET['keywords']){
		$search = '%'.addcslashes($_GET['keywords'], '%_').'%';
		$con.= " and title like %s";
		$where[] = $search;
	}
	if($_GET['order'] == 'addtime'){
		$con.= ' order by dateline desc';
	}else if($_GET['order'] == 'publictime'){
		$con.= ' order by num asc';
	}else if($_GET['order'] == 'favorate'){
		$con.= ' order by pv desc';
	}else if($_GET['order'] == 'totalpriceup'){
		$con.= ' order by price asc,extcredit asc';
	}else if($_GET['order'] == 'totalpricedown'){
		$con.= ' order by price desc,extcredit desc';
	}
	
	$currpage=$_GET['page']?$_GET['page']:1;
	$perpage=10;
	$start=($currpage-1)*$perpage;
	$num = DB::result_first('select count(*) from %t '.$con,$where);
	$max = ceil($num/$perpage);
	
	if($currpage == 1){
		$max_page ='<input type="hidden" id="max-page" value="'.$max.'">';
	}
	
	if($currpage == $max){
		$mes = '<div class="c_click_see" id="more" style="background: none;float: left;">'.$aljsclang['php']['No_more_data'].'</div>';
	}
	$where[] = $start;
	$where[] = $perpage;
	$goodslist = DB::fetch_all('select * from %t '.$con.' limit %d,%d',$where);
	
	include template(($pluginid.':new/mobile_index_goods'));
} else {
	foreach ($piclist as $p => $pic) {
		$$pic = C::t('#aljsc#aljsc_setting')->fetch($pic);
		$p = $$pic;
		$p['value'] = unserialize($p['value']);
		$url = $pic . 'url';
		$$url = C::t('#aljsc#aljsc_setting')->fetch($url);
		$url = $$url;
		$url['value'] = unserialize($url['value']);
		foreach ($p['value'] as $k => $v) {
			$b = $pic . 's';
			$b = $$b;
			$a[$k] = array('imgUrl' => $v, 'url' => $url['value'][$k]);
		}
		$$pic = $a;
		unset($a);
	}
	$mobileadvs = $adv;
	$adv = json_encode($adv);
	$loglist = C::t('#aljsc#aljsc_log')->fetch_all_by_mode_isnot_indexlog(0, 20);  
	$navtitle = $config['title'];
	$metakeywords = $config['keywords'];
	$metadescription = $config['description'];
	if($_G['mobile'] && $settings['is_mobile_template']['value'] && $_G['cache']['plugin']['aljgwc']['aljsc']){
		
		$mobile_img = explode ("\n", str_replace ("\r", "", $settings['mobile_img_array']['value']));
		
		foreach($mobile_img as $key=>$value){
			$arr=explode('|',$value);
			$img_types[]=$arr;
		}
		include template('aljsc:new/aljsc_index_new');
	}else{
		
		
		$gglist = str_replace($config['gg'], '\r', '\n');
		$gglist = explode("\n", $config['gg']);
		
		$rlist = C::t('#aljsc#aljsc')->fetch_all_by_recomened();
		foreach($rlist as $k=>$v){
			$rlist[$k]['rewrite']=str_replace ("{id}", $v['id'], $config ['re_view']);
		}
		include template('aljsc:index');
	}
}

function showmsg($msg, $close) {
    if ($close) {
        $str = "parent.hideWindow('$close');";
    } else {
        $str = "parent.location=parent.location;";
    }
    include template('aljsc:showmsg');
    exit;
}

function showerror($msg) {
    include template('aljsc:showerror');
    exit;
}
//From: Dism_taobao_com
?>