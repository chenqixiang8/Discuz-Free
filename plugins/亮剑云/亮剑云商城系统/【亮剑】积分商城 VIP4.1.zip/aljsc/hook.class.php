<?php

/*
 * ���ߣ�����
 * ��ϵQQ:281097180
 *
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Deined');
} 

class plugin_aljsc {
	function __construct() {
	
	}
	function global_footer(){
		global $_G;
		$config = $_G ['cache'] ['plugin'] ['aljsc'];
		$ismail = $config['ismail'];
		if(!isset($_G['cookie']['emailaljsc'])&&$ismail){
			return '<script src="plugin.php?id=aljsc:misc_sendmail"></script>';
		}
	}
}
//From: Dism��taobao��com
?>