<?php
/**
* 	�����˺���Ϣ
*/


class WxPayConf_pub
{
	static $APPID;
	static $MCHID;
	static $KEY;
	static $APPSECRET;
	static $NOTIFY_URL;
	static $CURL_TIMEOUT = 30;
		
}
$setting=C::t('#aljsc#aljsc_setting')->range();
$NOTIFY_URL  = $_G['siteurl'].'source/plugin/aljsc/wxpay/notify_url.php';
//$WxPayConf_pub = new WxPayConf_pub($setting['appid']['value'],$setting['mchid']['value'],$setting['key']['value'],$setting['APPSECRET']['value'],$NOTIFY_URL);
WxPayConf_pub::$APPID = $setting['appid']['value'];
WxPayConf_pub::$MCHID= $setting['mchid']['value'];
WxPayConf_pub::$KEY= $setting['key']['value'];
WxPayConf_pub::$APPSECRET= $setting['APPSECRET']['value'];
WxPayConf_pub::$NOTIFY_URL= $NOTIFY_URL;
?>