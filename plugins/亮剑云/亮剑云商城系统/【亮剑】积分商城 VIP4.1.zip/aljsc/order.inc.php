<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$config = array();
foreach($pluginvars as $key => $val) {
	$config[$key] = $val['value'];
}
if($_GET['act'] == 'wuliu'){
	if(submitcheck('formhash')){
		if(C::t('#aljsc#aljsc_wuliu')->fetch($_GET['orderid'])){
			C::t('#aljsc#aljsc_wuliu')->update($_GET['orderid'],array(
				'companyname' => $_GET['companyname'],
				'worderid' => $_GET['worderid'],
				'updatetime' => TIMESTAMP,
			));
			C::t('#aljsc#aljsc_order')->update_status_by_orderid($_GET['orderid']);
			
			$order = C::t('#aljsc#aljsc_order')->fetch($_GET['orderid']);
			notification_add($order['uid'], 'system',str_replace('{username}',$order['username'],str_replace('{shopname}','<a href="plugin.php?id=aljsc&act=view&sid='.$order['sid'].'">'.$order['stitle'].'</a>',$config['fahuotips'])));
			if($config['ismail']){
				$email_first=C::t("common_member")->fetch($order['uid']);
				$email=$email_first['email'];
				sendmail($email,$config['mailtitle'],str_replace('{username}',$order['username'],str_replace('{shopname}','<a href="plugin.php?id=aljsc&act=view&sid='.$order['sid'].'">'.$order['stitle'].'</a>',$config['fahuotips'])));
			}
			
			cpmsg(lang('plugin/aljsc','sc1'), 'action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=aljsc&pmod=order', 'succeed');
		}else{
			C::t('#aljsc#aljsc_wuliu')->insert(array(
				'orderid' => $_GET['orderid'],
				'type' => 1,
				'companyname' => $_GET['companyname'],
				'worderid' => $_GET['worderid'],
				'dateline' => TIMESTAMP,
			));
			C::t('#aljsc#aljsc_order')->update_status_by_orderid($_GET['orderid']);

			$order = C::t('#aljsc#aljsc_order')->fetch($_GET['orderid']);
			notification_add($order['uid'], 'system',str_replace('{username}',$order['username'],str_replace('{shopname}','<a href="plugin.php?id=aljsc&act=view&sid='.$order['sid'].'">'.$order['stitle'].'</a>',$config['fahuotips'])));
			if($config['ismail']){
				$email_first=C::t("common_member")->fetch($order['uid']);
				$email=$email_first['email'];
				sendmail($email,$config['mailtitle'],str_replace('{username}',$order['username'],str_replace('{shopname}','<a href="plugin.php?id=aljsc&act=view&sid='.$order['sid'].'">'.$order['stitle'].'</a>',$config['fahuotips'])));
			}

			cpmsg(lang('plugin/aljsc','sc1'), 'action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=aljsc&pmod=order', 'succeed');
		}
	}else{
		$wuliu = C::t('#aljsc#aljsc_wuliu')->fetch($_GET['orderid']);
		include template('aljsc:wuliu');
	}
}else if($_GET['act'] == 'delete'){
	C::t('#aljsc#aljsc_order')->delete($_GET['orderid']);
	cpmsg(lang('plugin/aljsc','sc7'), 'action=plugins&operation=config&do=' . $_GET['do'] . '&identifier=aljsc&pmod=order', 'succeed');
}else{
	$currpage=$_GET['page']?$_GET['page']:1;
	$perpage=$config['page'];
	$num=C::t('#aljsc#aljsc_order')->count();
	$start=($currpage-1)*$perpage;
	$orderlist=C::t('#aljsc#aljsc_order')->range($start,$perpage,'desc');
	$con[]='aljsc_order';
	$where.='where 1';
	if($_GET['title']){
		$con[] = '%' . addcslashes($_GET['title'], '%_') . '%';
		$where.=" and stitle like %s";
	}
	if($_GET['orderid']){
		$con[] = '%' . addcslashes($_GET['orderid'], '%_') . '%';
		$where.=" and orderid like %s";
	}
	
	if($_GET['s_time']){
		$where.=' and submitdate >= %d';
		$con[]=strtotime($_GET['s_time']);
	}

	if($_GET['e_time']){
		$where.=' and submitdate <= %d';
		$con[]=strtotime($_GET['e_time']);
	}

	$num=DB::result_first('select count(*) from %t '.$where,$con);
	$where.=' order by submitdate desc';
	if(!empty($perpage)){
		$con[]=$start;
		$con[]=$perpage;
		$where.=' limit %d,%d';
	}
	$orderlist=DB::fetch_all('select * from %t '.$where,$con);
	$paging = helper_page :: multi($num, $perpage, $currpage, ADMINSCRIPT.'?action=plugins&operation=config&do='.$_GET['do'].'&identifier=aljsc&pmod=order'.'&orderid='.$_GET['orderid'].'&title='.$_GET['title'].'&s_time='.$_GET['s_time'].'&e_time='.$_GET['e_time'], 0, 11, false, false);
	include template('aljsc:adminorder');
}
//From: Dism_taobao_com
?>