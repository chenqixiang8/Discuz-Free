<?php


if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(empty($_G['uid'])){
	showmessage(lang('plugin/aljsc','sc2'), '', array(), array('login' => true));
}


$_GET=dhtmlspecialchars($_GET);
$num = intval($_GET['num']);
$settings=C::t('#aljsc#aljsc_setting')->range();
$shop=C::t('#aljsc#aljsc')->fetch($_GET['sid']);
$orderid = dgmdate(TIMESTAMP, 'YmdHis').random(18);


if(C::t('#aljsc#aljsc_order')->fetch($orderid)) {
	showmessage('credits_addfunds_order_invalid', '', array(), array('showdialog' => 1, 'showmsg' => true, 'closetime' => true));
}

if(empty($_G['uid'])){
	showmessage(lang('plugin/aljsc','sc2'), '', array(), array('login' => true));
}
if ($_GET['formhash'] != formhash() || !submitcheck('formhash', 1) || preg_replace("/https?:\/\/([^\:\/]+).*/i", "\\1", $_SERVER['HTTP_REFERER']) != preg_replace("/([^\:]+).*/", "\\1", $_SERVER['HTTP_HOST'])) {
	debug('Access Denied!');
}

if (in_array($_G['groupid'], $notallowgroups)) {
   showmessage(lang('plugin/aljsc','sc23'));
}

$shop = C::t('#aljsc#aljsc')->fetch($_GET['sid']);
if (empty($num)) {
	showmessage(lang('plugin/aljsc','sc16'));
}
if ($shop['num'] < $num) {
	showmessage(lang('plugin/aljsc','sc17'));
}
if ($shop['e']) {
	$limitnum=DB::result_first('select sum(amount) from %t where sid=%d and uid=%d',array('aljsc_order',$_GET['sid'],$_G['uid']));
	
	if(($limitnum + $num) > $shop['e'] || $num >$shop['e']){
		$lnum=($shop['e']-$limitnum)>=0 ? ($shop['e']-$limitnum):0;
		showmessage('&#27599;&#20154;&#38480;&#25442;'.$shop['e'].'&#20010;&#65292;&#24744;&#24050;&#20817;&#25442;'.$limitnum.'&#20010;&#65292;&#36824;&#21487;&#20197;&#20817;&#25442;'.$lnum.'&#20010;');
	}
}
if (TIMESTAMP < $shop['starttime']) {
	echo "<script>parent.showError('".lang('plugin/aljsc','sc19')."');</script>";
	exit;
}
if (TIMESTAMP > $shop['endtime']) {
	echo "<script>parent.showError('".lang('plugin/aljsc','sc19')."');</script>";
	exit;
}

C::t('#aljsc#aljsc')->update_num_by_id($_GET['sid'],$num);
C::t('#aljsc#aljsc')->update_num2_by_id($_GET['sid'],$num);

$allattrs = C::t('#aljsc#aljsc_attr') -> range();
foreach($_GET['typename'] as $v){
	$attrs[]=$allattrs[$v]['content'];
}
C::t('#aljsc#aljsc_order')->insert(array(
	'orderid' => $orderid,
	'status' => '1',
	'uid' => $_G['uid'],
	'username' => $_G['username'],
	'sid' => $_GET['sid'],
	'stitle' => $shop['title'],
	'amount' => $num,
	'price' => $shop['price'],
	'submitdate' => $_G['timestamp'],
	'a' => $_GET['a'].$attrs,
));






$alipay_config['partner'] = trim($settings['ec_partner']['value']);


$alipay_config['key'] = $settings['ec_securitycode']['value'];


$alipay_config['private_key_path']	= 'source/plugin/aljsc/key/rsa_private_key.pem';


$alipay_config['ali_public_key_path']= 'source/plugin/aljsc/key/alipay_public_key.pem';






$alipay_config['sign_type']    = 'MD5';


$alipay_config['input_charset']= 'utf8';


$alipay_config['cacert']    = getcwd().'/source/plugin/aljsc'.'\\cacert.pem';


$alipay_config['transport']    = 'http';

require_once("source/plugin/aljsc/lib/alipay_submit.class.php");


$format = "xml";
$v = "2.0";
$req_id = date('Ymdhis');

$notify_url = $_G['siteurl'].'source/plugin/aljsc/notify_url.php';



$call_back_url = $_G['siteurl'].'source/plugin/aljsc/call_back_url.php';

$merchant_url = $_G['siteurl'].'source/plugin/aljsc/notify.php';


$seller_email = $settings['ec_account']['value'];

$out_trade_no = $orderid;



$subject = $shop['title'];
$subject = g2u($subject);

$total_fee = $shop['price']*$num;

$req_data = '<direct_trade_create_req><notify_url>' . $notify_url . '</notify_url><call_back_url>' . $call_back_url . '</call_back_url><seller_account_name>' . $seller_email . '</seller_account_name><out_trade_no>' . $out_trade_no . '</out_trade_no><subject>' . $subject . '</subject><total_fee>' . $total_fee . '</total_fee><merchant_url>' . $merchant_url . '</merchant_url></direct_trade_create_req>';

$para_token = array(
		"service" => "alipay.wap.trade.create.direct",
		"partner" => trim($alipay_config['partner']),
		"sec_id" => trim($alipay_config['sign_type']),
		"format"	=> $format,
		"v"	=> $v,
		"req_id"	=> $req_id,
		"req_data"	=> $req_data,
		"_input_charset"	=> trim(strtolower($alipay_config['input_charset']))
);


$alipaySubmit = new AlipaySubmit($alipay_config);
$html_text = $alipaySubmit->buildRequestHttp($para_token);

$html_text = urldecode($html_text);


$para_html_text = $alipaySubmit->parseResponse($html_text);


$request_token = $para_html_text['request_token'];



$req_data = '<auth_and_execute_req><request_token>' . $request_token . '</request_token></auth_and_execute_req>';

$parameter = array(
		"service" => "alipay.wap.auth.authAndExecute",
		"partner" => trim($alipay_config['partner']),
		"sec_id" => trim($alipay_config['sign_type']),
		"format"	=> $format,
		"v"	=> $v,
		"req_id"	=> $req_id,
		"req_data"	=> $req_data,
		"_input_charset"	=> trim(strtolower($alipay_config['input_charset']))
);


$alipaySubmit = new AlipaySubmit($alipay_config);
$html_text = $alipaySubmit->buildRequestForm($parameter, 'get', '');
echo $html_text;

function g2u($a) {
   return is_array($a) ? array_map('g2u', $a) : diconv($a, CHARSET, 'UTF-8');
}

function u2g($a) {
	return is_array($a) ? array_map('u2g', $a) : diconv($a, 'UTF-8', CHARSET);
}
//From: Dism_taobao_com
?>