<?php
/*
	Install Uninstall Upgrade AutoStat System Code
*/
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
//start to put your own code 
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_aljsc_kami` (
  `mid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `sid` int(10) unsigned NOT NULL,
  `message` text,
  `uid` mediumint(8) unsigned NOT NULL,
  `username` varchar(100) NOT NULL,
  `addtime` int(10) unsigned NOT NULL,
  `dateline` int(10) unsigned NOT NULL,
  `orderid` varchar(255) NOT NULL,
  PRIMARY KEY (`mid`)
);
CREATE TABLE IF NOT EXISTS `pre_aljsc_attr` (
  `mid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `tid` int(10) unsigned NOT NULL,
  `name` int(10) NOT NULL,
  `content` text,
  `addtime` int(10) unsigned NOT NULL,
  `typeid` int(10) NOT NULL,
  PRIMARY KEY (`mid`)
);
CREATE TABLE IF NOT EXISTS `pre_aljsc` (
  `id` int(10) NOT NULL auto_increment,
  `type` tinyint(3) NOT NULL,
  `mode` tinyint(3) NOT NULL,
  `status` tinyint(3) NOT NULL,
  `title` varchar(255) NOT NULL,
  `sponsor` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `starttime` int(10) NOT NULL,
  `endtime` int(10) NOT NULL,
  `extcredit` int(10) NOT NULL,
  `num` int(10) NOT NULL,
  `num2` int(11) NOT NULL default '0',
  `logo` varchar(255) NOT NULL,
  `desc` mediumtext NOT NULL,
  `uid` int(10) NOT NULL,
  `username` varchar(255) NOT NULL,
  `dateline` int(10) NOT NULL,
  `pv` int(10) NOT NULL default '0',
  `recomened` tinyint(3) NOT NULL,
  `displayorder` int(10) NOT NULL,
  `per` int(11) NOT NULL,
  `a` varchar(255) NOT NULL,
  `b` varchar(255) NOT NULL,
  `c` text NOT NULL,
  `d` int(11) NOT NULL,
  `e` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
);
CREATE TABLE IF NOT EXISTS `pre_aljsc_log` (
  `id` int(10) NOT NULL auto_increment,
  `uid` int(10) NOT NULL,
  `username` varchar(255) NOT NULL,
  `sid` int(10) NOT NULL,
  `mode` int(10) NOT NULL,
  `title` varchar(255) NOT NULL,
  `extcredit` int(10) NOT NULL,
  `num` int(10) NOT NULL,
  `dateline` int(10) NOT NULL,
  `status` tinyint(3) NOT NULL default '0',
  `isnot` tinyint(3) NOT NULL,
   `a` varchar(255) NOT NULL,
  `b` varchar(255) NOT NULL,
  `c` text NOT NULL,
  `d` int(11) NOT NULL,
  `e` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
);
CREATE TABLE IF NOT EXISTS `pre_aljsc_order` (
  `orderid` char(32) NOT NULL default '',
  `status` char(3) NOT NULL default '',
  `buyer` char(50) NOT NULL default '',
  `admin` char(15) NOT NULL default '',
  `uid` mediumint(8) unsigned NOT NULL default '0',
  `username` varchar(255) NOT NULL,
  `sid` int(11) NOT NULL,
  `stitle` varchar(255) NOT NULL,
  `amount` int(10) unsigned NOT NULL default '0',
  `price` float(7,2) unsigned NOT NULL default '0.00',
  `submitdate` int(10) unsigned NOT NULL default '0',
  `confirmdate` int(10) unsigned NOT NULL default '0',
  `email` char(40) NOT NULL default '',
  `ip` char(15) NOT NULL default '',
  `a` varchar(255) NOT NULL,
  `b` varchar(255) NOT NULL,
  `c` text NOT NULL,
  `d` int(11) NOT NULL,
  `e` int(11) NOT NULL,
  PRIMARY KEY (`orderid`)
);
CREATE TABLE IF NOT EXISTS `pre_aljsc_wuliu` (
  `orderid` varchar(255) NOT NULL,
  `type` int(10) NOT NULL,
  `companyname` varchar(255) NOT NULL,
  `worderid` varchar(255) NOT NULL,
  `dateline` int(10) NOT NULL,
  `updatetime` int(10) NOT NULL,
  `a` int(10) NOT NULL,
  `b` int(10) NOT NULL,
  `c` varchar(255) NOT NULL,
  `d` varchar(255) NOT NULL,
  `e` varchar(255) NOT NULL,
  PRIMARY KEY (`orderid`)
);
CREATE TABLE IF NOT EXISTS `pre_aljsc_setting` (
  `key` varchar(255) NOT NULL,
  `value` text NOT NULL,
   `a` varchar(255) NOT NULL,
  `b` varchar(255) NOT NULL,
  `c` text NOT NULL,
  `d` int(11) NOT NULL,
  `e` int(11) NOT NULL,
  PRIMARY KEY  (`key`)
);
INSERT INTO `pre_aljsc_setting` (`key`, `value`) VALUES
('tadv', 'a:2:{i:1;s:52:"source/plugin/aljsc/images/adv/20140610224923961.jpg";i:2;s:52:"source/plugin/aljsc/images/adv/20140610224805555.jpg";}'),
('adv', 'a:3:{i:3;s:52:"source/plugin/aljsc/images/adv/20140610224805608.jpg";i:2;s:52:"source/plugin/aljsc/images/adv/20140610224805280.jpg";i:1;s:52:"source/plugin/aljsc/images/adv/20140610224805901.jpg";}'),
('advurl', 'a:3:{i:1;s:1:"#";i:2;s:1:"#";i:3;s:1:"#";}'),
('tadvurl', 'a:2:{i:1;s:1:"#";i:2;s:1:"#";}'),
('gadvurl', 'a:1:{i:1;s:1:"#";}'),
('leftadvurl', 'a:3:{i:1;s:1:"#";i:2;s:1:"#";i:3;s:1:"#";}'),
('gadv', 'a:1:{i:1;s:52:"source/plugin/aljsc/images/adv/20140610224923401.jpg";}'),
('leftadv', 'a:3:{i:1;s:52:"source/plugin/aljsc/images/adv/20140610224805318.jpg";i:2;s:52:"source/plugin/aljsc/images/adv/20140610224805329.jpg";i:3;s:52:"source/plugin/aljsc/images/adv/20140610224805230.jpg";}');
CREATE TABLE IF NOT EXISTS `pre_aljsc_user` (
  `uid` int(10) NOT NULL,
  `username` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `qq` bigint(20) NOT NULL,
  `tel` bigint(20) NOT NULL,
  `addr` varchar(255) NOT NULL,
   `a` varchar(255) NOT NULL,
  `b` varchar(255) NOT NULL,
  `c` text NOT NULL,
  `d` int(11) NOT NULL,
  `e` int(11) NOT NULL,
  PRIMARY KEY  (`uid`)
);
CREATE TABLE IF NOT EXISTS `pre_aljsc_emaillog` (
  `id` int(10) NOT NULL auto_increment,
  `sendemail` varchar(255) NOT NULL,
  `sendtype` tinyint(3) NOT NULL,
  `sendtime` int(10) NOT NULL,
  `success` tinyint(3) NOT NULL,
  PRIMARY KEY  (`id`)
);
EOF;
runquery($sql);
//finish to put your own code
if(file_exists( DISCUZ_ROOT . './source/plugin/wechat/wechat.lib.class.php')){
	$pluginid = 'aljsc';
	$Hooks = array(
		'forumdisplay_topBar',
	);
	$data = array();
	foreach ($Hooks as $Hook) {
		$data[] = array($Hook => array('plugin' => $pluginid, 'include' => 'api.class.php', 'class' => $pluginid . '_api', 'method' => $Hook));
	}
	require_once DISCUZ_ROOT . './source/plugin/wechat/wechat.lib.class.php';
	WeChatHook::updateAPIHook($data);
}
$finish = TRUE;
?>