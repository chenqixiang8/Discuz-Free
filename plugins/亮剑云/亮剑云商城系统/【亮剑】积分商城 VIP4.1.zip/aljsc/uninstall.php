<?php
/*
	Install Uninstall Upgrade AutoStat System Code
*/
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
//start to put your own code 
$sql = <<<EOF
DROP TABLE IF  EXISTS `pre_aljsc`;
DROP TABLE IF  EXISTS `pre_aljsc_log`;
DROP TABLE IF  EXISTS `pre_aljsc_setting`;
DROP TABLE IF  EXISTS `pre_aljsc_user`;
DROP TABLE IF  EXISTS `pre_aljsc_order`;
DROP TABLE IF  EXISTS `pre_aljsc_wuliu`;
DROP TABLE IF  EXISTS `pre_aljsc_kami`;
DROP TABLE IF  EXISTS `pre_aljsc_attr`;
DROP TABLE IF  EXISTS `pre_aljsc_emaillog`;
EOF;
runquery($sql);
//finish to put your own code
$finish = TRUE;
?>