<?php
/* * 
 * 功能：支付宝页面跳转同步通知页面
 */
require '../../../source/class/class_core.php';
$discuz = C::app();
$discuz->init();

$settings=C::t('#aljsc#aljsc_setting')->range();


$alipay_config['partner'] = trim($settings['ec_partner']['value']);

//安全检验码，以数字和字母组成的32位字符
//如果签名方式设置为“MD5”时，请设置该参数
$alipay_config['key']			= $settings['ec_securitycode']['value'];

//商户的私钥（后缀是.pen）文件相对路径
//如果签名方式设置为“0001”时，请设置该参数
$alipay_config['private_key_path']	= 'source/plugin/aljsc/key/rsa_private_key.pem';

//支付宝公钥（后缀是.pen）文件相对路径
//如果签名方式设置为“0001”时，请设置该参数
$alipay_config['ali_public_key_path']= 'source/plugin/aljsc/key/alipay_public_key.pem';


//↑↑↑↑↑↑↑↑↑↑请在这里配置您的基本信息↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑


//签名方式 不需修改
$alipay_config['sign_type']    = 'MD5';

//字符编码格式 目前支持 gbk 或 utf-8
$alipay_config['input_charset']= 'utf8';

//ca证书路径地址，用于curl中ssl校验
//请保证cacert.pem文件在当前文件夹目录中
$alipay_config['cacert']    = getcwd().'/source/plugin/aljsc'.'\\cacert.pem';

//访问模式,根据自己的服务器是否支持ssl访问，若支持请选择https；若不支持请选择http
$alipay_config['transport']    = 'http';

require "lib/alipay_notify.class.php";

//计算得出通知验证结果
$alipayNotify = new AlipayNotify($alipay_config);
$verify_result = $alipayNotify->verifyReturn();

if($verify_result) {//验证成功
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//请在这里加上商户的业务逻辑程序代码
	
	//——请根据您的业务逻辑来编写程序（以下代码仅作参考）——
    //获取支付宝的通知返回参数，可参考技术文档中页面跳转同步通知参数列表

	//商户订单号
	$out_trade_no = $_GET['out_trade_no'];

	//支付宝交易号
	$trade_no = $_GET['trade_no'];

	//交易状态
	$result = $_GET['result'];


	C::t('#aljsc#aljsc_order')->update($out_trade_no, array('status' => '2', 'buyer' => $trade_no, 'confirmdate' => $_G['timestamp']));
	$_G['siteurl'] = 'http://'.$_SERVER['HTTP_HOST'].'/plugin.php?id=aljsc&act=orderlist';
	dheader('location: '.$_G['siteurl']);
	
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
}
else {
    //验证失败
    //如要调试，请看alipay_notify.php页面的verifyReturn函数
   
}
//From: Dism·taobao·com
?>
