<?php

/*
 * 支付宝接口通知文件
 * 不需要加IN_DISCUZ判断
 *
 */

require '../../../source/class/class_core.php';
$discuz = C::app();
$discuz->init();

if(!empty($_POST)) {
	$notify = $_POST;
	$location = FALSE;
} else if(!empty($_GET)) {
	$notify = $_GET;
	$location = TRUE;
} else {
	exit('Access Denied');
}
$ec_partner=C::t('#aljsc#aljsc_setting')->fetch('ec_partner');
if(dfsockopen("http://notify.alipay.com/trade/notify_query.do?partner=".$ec_partner['value']."&notify_id=".$notify['notify_id'], 60) !== 'true') {
	exit('Access Denied');
}
if ($_GET['trade_status'] == 'WAIT_SELLER_SEND_GOODS' || $_GET['trade_status'] == 'TRADE_FINISHED' || $_GET['trade_status'] == 'TRADE_SUCCESS'){
	C::t('#aljsc#aljsc_order')->update($notify['out_trade_no'], array('status' => '2', 'buyer' => "$notify[trade_no]", 'confirmdate' => $_G['timestamp']));
}

if($location){
	$_G['siteurl'] = 'http://'.$_SERVER['HTTP_HOST'];
	dheader('location: '.$_G['siteurl'].'/plugin.php?id=aljsc&act=orderlist');
}
//From: Dism·taobao·com
?>