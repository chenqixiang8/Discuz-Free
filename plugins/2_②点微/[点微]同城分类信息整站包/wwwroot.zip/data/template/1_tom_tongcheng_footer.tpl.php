<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<footer class="new-footer" <?php if($_GET['mod'] == 'index' && $_GET['app'] == 1) { ?>style="display:none;"<?php } ?>>
    <section class="new-footer__box dislay-flex">
        <a class="flex footer-box__item <?php if($_GET['mod'] == 'index' ) { ?>tc-template__color on<?php } ?>" href="plugin.php?id=tom_tongcheng&amp;site=<?php echo $site_id;?>&amp;mod=index&amp;prand=<?php echo $prand;?>">
            <i class="tciconfont tcicon-nav__index"></i>
            <section class="text1">首页</section>
        </a>
        <?php if($tongchengConfig['footer_nav1_mod'] == 2 ) { ?>
        <a class="flex footer-box__item " href="<?php echo $footer_nav1_content_link;?>">
            <?php if($footer_nav1_content_ico ) { ?>
             <i><img style="margin-top: 2px;width: 25px;height: 25px;" src="<?php echo $footer_nav1_content_ico;?>"></i>
            <?php } else { ?>
            <i class="tciconfont tcicon-nav_fenlei"></i>
            <?php } ?>
            <section class="text1"><?php echo $footer_nav1_content_name;?></section>
        </a>
        <?php } elseif($tongchengConfig['footer_nav1_mod'] == 3 ) { ?>
        <a class="flex footer-box__item " href="plugin.php?id=tom_tcshop&amp;site=<?php echo $site_id;?>&amp;mod=index&amp;prand=<?php echo $prand;?>">
            <i class="tciconfont tcicon-shop"></i>
            <section class="text1"><?php echo $tcshopConfig['tcshop_name'];?></section>
        </a>
        <?php } elseif($tongchengConfig['footer_nav1_mod'] == 4 ) { ?>
        <a class="flex footer-box__item " href="plugin.php?id=tom_tchongbao&amp;site=<?php echo $site_id;?>&amp;mod=index&amp;prand=<?php echo $prand;?>">
            <i class="tciconfont tcicon-hongbao"></i>
            <section class="text1">红包</section>
        </a>
        <?php } elseif($tongchengConfig['footer_nav1_mod'] == 5 ) { ?>
        <a class="flex footer-box__item " href="plugin.php?id=tom_tcqianggou&amp;site=<?php echo $site_id;?>&amp;mod=index&amp;prand=<?php echo $prand;?>">
            <i class="tciconfont tcicon-qianggou"></i>
            <section class="text1">抢购</section>
        </a>
        <?php } elseif($tongchengConfig['footer_nav1_mod'] == 6 ) { ?>
        <a class="flex footer-box__item " href="plugin.php?id=tom_tcptuan&amp;site=<?php echo $site_id;?>&amp;mod=index&amp;prand=<?php echo $prand;?>">
            <i class="tciconfont tcicon-ptuan"></i>
            <section class="text1">拼单</section>
        </a>
        <?php } elseif($tongchengConfig['footer_nav1_mod'] == 7 ) { ?>
        <a class="flex footer-box__item " href="plugin.php?id=tom_tcmall&amp;site=<?php echo $site_id;?>&amp;mod=index&amp;prand=<?php echo $prand;?>">
            <i class="tciconfont tcicon-mall"></i>
            <section class="text1">商城</section>
        </a>
        <?php } elseif($tongchengConfig['footer_nav1_mod'] == 8 ) { ?>
        <a class="flex footer-box__item " href="plugin.php?id=tom_tctoutiao&amp;site=<?php echo $site_id;?>&amp;mod=index&amp;prand=<?php echo $prand;?>">
            <i class="tciconfont tcicon-toutiao"></i>
            <section class="text1">头条</section>
        </a>
        <?php } elseif($tongchengConfig['footer_nav1_mod'] == 9 ) { ?>
        <a class="flex footer-box__item " href="plugin.php?id=tom_tczhaopin&amp;site=<?php echo $site_id;?>&amp;mod=index&amp;prand=<?php echo $prand;?>">
            <i class="tciconfont tcicon-zhaopin"></i>
            <section class="text1">招聘</section>
        </a>
        <?php } elseif($tongchengConfig['footer_nav1_mod'] == 10 ) { ?>
        <a class="flex footer-box__item <?php if($_GET['mod'] == 'fenlei' ) { ?>tc-template__color on<?php } ?>" href="plugin.php?id=tom_tongcheng&amp;site=<?php echo $site_id;?>&amp;mod=fenlei&amp;prand=<?php echo $prand;?>">
            <i class="tciconfont tcicon-fenlei"></i>
            <section class="text1">便民信息</section>
        </a>
        <?php } else { ?>
            <?php if($__ShowTcshop == 1 ) { ?>
            <a class="flex footer-box__item " href="plugin.php?id=tom_tcshop&amp;site=<?php echo $site_id;?>&amp;mod=index&amp;prand=<?php echo $prand;?>">
                <i class="tciconfont tcicon-shop"></i>
                <section class="text1"><?php echo $tcshopConfig['tcshop_name'];?></section>
            </a>
            <?php } else { ?>
            <a class="flex footer-box__item <?php if($_GET['mod'] == 'fenleisearch' ) { ?>tc-template__color on<?php } ?>" href="plugin.php?id=tom_tongcheng&amp;site=<?php echo $site_id;?>&amp;mod=fenleisearch&amp;prand=<?php echo $prand;?>">
                <i class="tciconfont tcicon-nav__shoucang"></i>
                <section class="text1">分类</section>
            </a>
            <?php } ?>
        <?php } ?>
        <?php if($_GET['mod'] == 'list' ) { ?>
        <a class="flex footer-box__item footer-box__fabu tc-template__color" href="<?php echo $fabuUrl;?>">
        <?php } else { ?>
        <a class="flex footer-box__item footer-box__fabu tc-template__color" href="plugin.php?id=tom_tongcheng&amp;site=<?php echo $site_id;?>&amp;mod=fabu&amp;prand=<?php echo $prand;?>">
        <?php } ?>
            <?php if($tongchengConfig['footer_fabu_ico'] ) { ?>
            <i><img style="width: 37px;height: 37px;" src="<?php echo $tongchengConfig['footer_fabu_ico'];?>"></i>
            <?php } else { ?>
            <i class="tciconfont tcicon-fabu"></i>
            <?php } ?>
            <section class="text1">发布</section>
        </a>
        <?php if($tongchengConfig['footer_nav_mod'] == 1 ) { ?>
        <a class="flex footer-box__item " href="<?php echo $footer_nav_content_link;?>">
            <?php if($footer_nav_content_ico ) { ?>
             <i><img style="margin-top: 2px;width: 25px;height: 25px;" src="<?php echo $footer_nav_content_ico;?>"></i>
            <?php } else { ?>
            <i class="tciconfont tcicon-nav_fenlei"></i>
            <?php } ?>
            <section class="text1"><?php echo $footer_nav_content_name;?></section>
        </a>
        <?php } elseif($tongchengConfig['footer_nav_mod'] == 3 ) { ?>
        <a class="flex footer-box__item " href="plugin.php?id=tom_tchongbao&amp;site=<?php echo $site_id;?>&amp;mod=index&amp;prand=<?php echo $prand;?>">
            <i class="tciconfont tcicon-hongbao"></i>
            <section class="text1">红包</section>
        </a>
        <?php } elseif($tongchengConfig['footer_nav_mod'] == 4 ) { ?>
        <a class="flex footer-box__item " href="plugin.php?id=tom_tcqianggou&amp;site=<?php echo $site_id;?>&amp;mod=index&amp;prand=<?php echo $prand;?>">
            <i class="tciconfont tcicon-qianggou"></i>
            <section class="text1">抢购</section>
        </a>
        <?php } elseif($tongchengConfig['footer_nav_mod'] == 5 ) { ?>
        <a class="flex footer-box__item " href="plugin.php?id=tom_tcptuan&amp;site=<?php echo $site_id;?>&amp;mod=index&amp;prand=<?php echo $prand;?>">
            <i class="tciconfont tcicon-ptuan"></i>
            <section class="text1">拼单</section>
        </a>
        <?php } elseif($tongchengConfig['footer_nav_mod'] == 6 ) { ?>
        <a class="flex footer-box__item " href="plugin.php?id=tom_tcmall&amp;site=<?php echo $site_id;?>&amp;mod=index&amp;prand=<?php echo $prand;?>">
            <i class="tciconfont tcicon-mall"></i>
            <section class="text1">商城</section>
        </a>
        <?php } elseif($tongchengConfig['footer_nav_mod'] == 7 ) { ?>
        <a class="flex footer-box__item " href="plugin.php?id=tom_tctoutiao&amp;site=<?php echo $site_id;?>&amp;mod=index&amp;prand=<?php echo $prand;?>">
            <i class="tciconfont tcicon-toutiao"></i>
            <section class="text1">头条</section>
        </a>
        <?php } elseif($tongchengConfig['footer_nav_mod'] == 8 ) { ?>
        <a class="flex footer-box__item " href="plugin.php?id=tom_tczhaopin&amp;site=<?php echo $site_id;?>&amp;mod=index&amp;prand=<?php echo $prand;?>">
            <i class="tciconfont tcicon-zhaopin"></i>
            <section class="text1">招聘</section>
        </a>
        <?php } else { ?>
        <a class="flex footer-box__item  <?php if($_GET['mod'] == 'message' ) { ?>tc-template__color on<?php } ?>" href="plugin.php?id=tom_tongcheng&amp;site=<?php echo $site_id;?>&amp;mod=message&amp;prand=<?php echo $prand;?>">
            <font class="iconfont">
            <?php if($pmNewNum > 0 ) { ?><i><?php echo $pmNewNum;?></i><?php } ?>
                <em class="tciconfont tcicon-nav__message"></em>
            </font>
            <section class="text1">消息</section>
        </a>
        <?php } ?>
        <a class="flex footer-box__item  <?php if($_GET['mod'] == 'personal' ) { ?>tc-template__color on<?php } ?>" href="plugin.php?id=tom_tongcheng&amp;site=<?php echo $site_id;?>&amp;mod=personal&amp;prand=<?php echo $prand;?>">
            <font class="iconfont">
            <?php if($tongchengConfig['footer_nav_mod'] != 2 && $_GET['mod'] != 'index' ) { ?>
              <?php if($pmNewNum > 0 ) { ?><i><?php echo $pmNewNum;?></i><?php } ?>
            <?php } ?>
            <em class="tciconfont tcicon-nav__my"></em>
            </font>
            <section class="text1">我的</section>
        </a>
    </section>
</footer>
<?php if($_GET['mod'] == 'index' && $_GET['app'] == 1) { ?>
<section class="app-nav">
    <div class="app-nav__task"></div>
    <div class="app-nav__main">
        <div class="nav-main__lt dislay-flex">
            <div class="main-lt__icon"><img src="source/plugin/tom_tongcheng/images/app-nav__icon.png" /></div>
            <div class="main-lt__text">快速导航</div>
        </div>
        <div class="nav-main__rt">
            <a class="main-rt__item" href="plugin.php?id=tom_tongcheng&amp;site=<?php echo $site_id;?>&amp;mod=index&amp;prand=<?php echo $prand;?>">
                <div class="item-hd"><i class="tciconfont tcicon-nav__index"></i></div>
                <div class="item-bd">首页</div>
            </a>
            <?php if($tongchengConfig['footer_nav1_mod'] == 2 ) { ?>
            <a class="main-rt__item" href="<?php echo $footer_nav1_content_link;?>">
                <div class="item-hd"><i class="tciconfont tcicon-nav_fenlei"></i></div>
                <div class="item-bd"><?php echo $footer_nav1_content_name;?></div>
            </a>
            <?php } elseif($tongchengConfig['footer_nav1_mod'] == 3 ) { ?>
            <a class="main-rt__item" href="plugin.php?id=tom_tcshop&amp;site=<?php echo $site_id;?>&amp;mod=index&amp;prand=<?php echo $prand;?>">
                <div class="item-hd"><i class="tciconfont tcicon-shop"></i></div>
                <div class="item-bd"><?php echo $tcshopConfig['tcshop_name'];?></div>
            </a>
            <?php } elseif($tongchengConfig['footer_nav1_mod'] == 4 ) { ?>
            <a class="main-rt__item" href="plugin.php?id=tom_tchongbao&amp;site=<?php echo $site_id;?>&amp;mod=index&amp;prand=<?php echo $prand;?>">
                <div class="item-hd"><i class="tciconfont tcicon-hongbao"></i></div>
                <div class="item-bd">红包</div>
            </a>
            <?php } elseif($tongchengConfig['footer_nav1_mod'] == 5 ) { ?>
            <a class="main-rt__item" href="plugin.php?id=tom_tcqianggou&amp;site=<?php echo $site_id;?>&amp;mod=index&amp;prand=<?php echo $prand;?>">
                <div class="item-hd"><i class="tciconfont tcicon-qianggou"></i></div>
                <div class="item-bd">抢购</div>
            </a>
            <?php } elseif($tongchengConfig['footer_nav1_mod'] == 6 ) { ?>
            <a class="main-rt__item" href="plugin.php?id=tom_tcptuan&amp;site=<?php echo $site_id;?>&amp;mod=index&amp;prand=<?php echo $prand;?>">
                <div class="item-hd"><i class="tciconfont tcicon-ptuan"></i></div>
                <div class="item-bd">拼单</div>
            </a>
            <?php } elseif($tongchengConfig['footer_nav1_mod'] == 7 ) { ?>
            <a class="main-rt__item" href="plugin.php?id=tom_tcmall&amp;site=<?php echo $site_id;?>&amp;mod=index&amp;prand=<?php echo $prand;?>">
                <div class="item-hd"><i class="tciconfont tcicon-mall"></i></div>
                <div class="item-bd">商城</div>
            </a>
            <?php } elseif($tongchengConfig['footer_nav1_mod'] == 8 ) { ?>
            <a class="main-rt__item" href="plugin.php?id=tom_tctoutiao&amp;site=<?php echo $site_id;?>&amp;mod=index&amp;prand=<?php echo $prand;?>">
                <div class="item-hd"><i class="tciconfont tcicon-toutiao"></i></div>
                <div class="item-bd">头条</div>
            </a>
            <?php } elseif($tongchengConfig['footer_nav1_mod'] == 9 ) { ?>
            <a class="main-rt__item" href="plugin.php?id=tom_tczhaopin&amp;site=<?php echo $site_id;?>&amp;mod=index&amp;prand=<?php echo $prand;?>">
                <div class="item-hd"><i class="tciconfont tcicon-zhaopin"></i></div>
                <div class="item-bd">招聘</div>
            </a>
            <?php } elseif($tongchengConfig['footer_nav1_mod'] == 10 ) { ?>
            <a class="main-rt__item" href="plugin.php?id=tom_tongcheng&amp;site=<?php echo $site_id;?>&amp;mod=fenlei&amp;prand=<?php echo $prand;?>">
                <div class="item-hd"><i class="tciconfont tcicon-fenlei"></i></div>
                <div class="item-bd">便民信息</div>
            </a>
            <?php } else { ?>
                <?php if($__ShowTcshop == 1 ) { ?>
                <a class="main-rt__item" href="plugin.php?id=tom_tcshop&amp;site=<?php echo $site_id;?>&amp;mod=index&amp;prand=<?php echo $prand;?>">
                    <div class="item-hd"><i class="tciconfont tcicon-shop"></i></div>
                    <div class="item-bd"><?php echo $tcshopConfig['tcshop_name'];?></div>
                </a>
                <?php } else { ?>
                <a class="main-rt__item" href="plugin.php?id=tom_tongcheng&amp;site=<?php echo $site_id;?>&amp;mod=fenleisearch&amp;prand=<?php echo $prand;?>">
                    <div class="item-hd"><i class="tciconfont tcicon-nav__shoucang"></i></div>
                    <div class="item-bd">分类</div>
                </a>
                <?php } ?>
            <?php } ?>
            <a class="main-rt__item" href="plugin.php?id=tom_tongcheng&amp;site=<?php echo $site_id;?>&amp;mod=fabu&amp;prand=<?php echo $prand;?>">
                <div class="item-hd"><i class="tciconfont tcicon-fabu tc-template__color"></i></div>
                <div class="item-bd">发布</div>
            </a>
            <?php if($tongchengConfig['footer_nav_mod'] == 1 ) { ?>
            <a class="main-rt__item" href="<?php echo $footer_nav_content_link;?>">
                <div class="item-hd"><i class="tciconfont tcicon-nav_fenlei"></i></div>
                <div class="item-bd"><?php echo $footer_nav_content_name;?></div>
            </a>
            <?php } elseif($tongchengConfig['footer_nav_mod'] == 3 ) { ?>
            <a class="main-rt__item" href="plugin.php?id=tom_tchongbao&amp;site=<?php echo $site_id;?>&amp;mod=index&amp;prand=<?php echo $prand;?>">
                <div class="item-hd"><i class="tciconfont tcicon-hongbao"></i></div>
                <div class="item-bd">红包</div>
            </a>
            <?php } elseif($tongchengConfig['footer_nav_mod'] == 4 ) { ?>
            <a class="main-rt__item" href="plugin.php?id=tom_tcqianggou&amp;site=<?php echo $site_id;?>&amp;mod=index&amp;prand=<?php echo $prand;?>">
                <div class="item-hd"><i class="tciconfont tcicon-qianggou"></i></div>
                <div class="item-bd">抢购</div>
            </a>
            <?php } elseif($tongchengConfig['footer_nav_mod'] == 5 ) { ?>
            <a class="main-rt__item" href="plugin.php?id=tom_tcptuan&amp;site=<?php echo $site_id;?>&amp;mod=index&amp;prand=<?php echo $prand;?>">
                <div class="item-hd"><i class="tciconfont tcicon-ptuan"></i></div>
                <div class="item-bd">拼单</div>
            </a>
            <?php } elseif($tongchengConfig['footer_nav_mod'] == 6 ) { ?>
            <a class="main-rt__item" href="plugin.php?id=tom_tcmall&amp;site=<?php echo $site_id;?>&amp;mod=index&amp;prand=<?php echo $prand;?>">
                <div class="item-hd"><i class="tciconfont tcicon-mall"></i></div>
                <div class="item-bd">商城</div>
            </a>
            <?php } elseif($tongchengConfig['footer_nav_mod'] == 7 ) { ?>
            <a class="main-rt__item" href="plugin.php?id=tom_tctoutiao&amp;site=<?php echo $site_id;?>&amp;mod=index&amp;prand=<?php echo $prand;?>">
                <div class="item-hd"><i class="tciconfont tcicon-toutiao"></i></div>
                <div class="item-bd">头条</div>
            </a>
            <?php } elseif($tongchengConfig['footer_nav_mod'] == 8 ) { ?>
            <a class="main-rt__item" href="plugin.php?id=tom_tczhaopin&amp;site=<?php echo $site_id;?>&amp;mod=index&amp;prand=<?php echo $prand;?>">
                <div class="item-hd"><i class="tciconfont tcicon-zhaopin"></i></div>
                <div class="item-bd">招聘</div>
            </a>
            <?php } else { ?>
            <a class="main-rt__item" href="plugin.php?id=tom_tongcheng&amp;site=<?php echo $site_id;?>&amp;mod=message&amp;prand=<?php echo $prand;?>">
                <div class="item-hd"><i class="tciconfont tcicon-nav__message"></i></div>
                <div class="item-bd">消息</div>
            </a>
            <?php } ?>
            <a class="main-rt__item" href="plugin.php?id=tom_tongcheng&amp;site=<?php echo $site_id;?>&amp;mod=personal&amp;prand=<?php echo $prand;?>">
                <div class="item-hd"><i class="tciconfont tcicon-nav__my"></i></div>
                <div class="item-bd">我的</div>
            </a>
        </div>
    </div>
</section>
<script>
$(document).on('click', '.app-nav__main .nav-main__lt', function(){
    if($(this).parent().hasClass('app-nav__main2')){
        $(this).parent().removeClass('app-nav__main2');
        $('.app-nav__task').hide();
        $(this).find('.main-lt__icon').removeClass('main-lt__icon2');
        $(this).find('.main-lt__text').html('快速导航');
    }else{
        $(this).parent().addClass('app-nav__main2');
        $('.app-nav__task').show();
        $(this).find('.main-lt__icon').addClass('main-lt__icon2');
        $(this).find('.main-lt__text').html('收起');
    }
})
</script>
<?php } ?>