<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<section id="global-topnav__box" class="global-topnav__box">
    <div class="global-topnav__mask global-topnav__close"></div>
    <div class="global-topnav__content">
        <div class="global-topnav__title">
            <span class="title">全局导航</span>
            <span class="close global-topnav__close"></span>
        </div>
        <div class="global-topnav__menu clearfix">
            <a class="global-menu__item dislay-flex" href="plugin.php?id=tom_tongcheng&amp;site=<?php echo $site_id;?>&amp;mod=index&amp;prand=<?php echo $prand;?>">
                <div class="item-box">
                    <div class="hd"><i class="icon tciconfont tcicon-nav__index"></i></div>
                    <div class="bd">首页</div>
                </div>
            </a>
            <a class="global-menu__item dislay-flex" href="plugin.php?id=tom_tcshop&amp;site=<?php echo $site_id;?>&amp;mod=index&amp;prand=<?php echo $prand;?>">
                <div class="item-box">
                    <div class="hd"><i class="icon tciconfont tcicon-shop"></i></div>
                    <div class="bd"><?php echo $tcshopConfig['tcshop_name'];?></div>
                </div>
            </a>
            <a class="global-menu__item dislay-flex" href="plugin.php?id=tom_tcshop&amp;site=<?php echo $site_id;?>&amp;mod=ruzhu&amp;prand=<?php echo $prand;?>">
                <div class="item-box">
                    <div class="hd">
                        <i class="icon tciconfont tcicon-fabu"></i>
                    </div>
                    <div class="bd">入驻</div>
                </div>
            </a>
            <a class="global-menu__item dislay-flex" href="plugin.php?id=tom_tongcheng&amp;site=<?php echo $site_id;?>&amp;mod=personal&amp;prand=<?php echo $prand;?>">
                <div class="item-box">
                    <div class="hd"><i class="icon tciconfont tcicon-nav__my"></i></div>
                    <div class="bd">我的</div>
                </div>
            </a>
        </div>
        <div class="global-topnav__nav dislay-flex global-topnav__list box_hide">
        </div>
        <div class="global-topnav__bottom"><span class="line"></span></div>
    </div>
</section>
<script>
$(document).on('click', '.nav-popup__btn', function(){
    $("#global-topnav__box").show();
    loadGlobalTopnavList();
    sTop = $(window).scrollTop();
    $('body').css("top",-sTop+"px");
    $('body').css("left","0px");
    $('body').css("right","0px");
    $("body").css("position","fixed");
    
    if($("#music_audio_btn").length > 0){
        $('#music_audio_btn').hide();
    }
    
})
$(document).on('click', '.global-topnav__close', function(){
    $("#global-topnav__box").hide();
    $("body").css("position","static");
    $(window).scrollTop(sTop);
    
    if($("#music_audio_btn").length > 0){
        $('#music_audio_btn').show();
    }
    
})

var loadGlobalTopnavStatus = 0;
function loadGlobalTopnavList() {
    if(loadGlobalTopnavStatus == 1){
        return false;
    }
    loadGlobalTopnavStatus = 1;
    $.ajax({
        type: "GET",
        url: "<?php echo $ajaxGlobalTopnavLoadListUrl;?>",
        data: {},
        success: function(msg){
            loadGlobalTopnavStatus = 0;
            var data = eval('('+msg+')');
            if(data == 205){
                return false;
            }else{
                $(".global-topnav__list").html(data);
                $(".global-topnav__list").removeClass("box_hide");
            }
        }
    });
}
</script>