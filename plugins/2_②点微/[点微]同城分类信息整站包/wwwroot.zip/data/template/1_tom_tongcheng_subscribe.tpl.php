<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<section id="subscribe_box" class="new_subscribe_box new_subscribe_hidden">
    <div class="subscribe_box_left">
        <div class="guanzu_pic"><img src="<?php echo $tongchengConfig['fwh_logo'];?>"></div>
        <div class="guanzu_text">
            <h5><?php echo $tongchengConfig['fwh_name'];?></h5>
            <p><?php echo $tongchengConfig['fwh_desc'];?></p>
        </div>
    </div>
    <div class="subscribe_box_right">
        <div class="guanzu_button tc-template__bg" onclick="show_subscribe();">关注</div>
        <div class="guanzu_close" onclick="close_subscribe();"></div>
    </div>
</section>
<?php if($show_app_download == 1 && $__IsMagapp == 0 && $__IsQianfan == 0 && $__IsApp == 0 ) { ?>
<section id="app_download_box" class="new_subscribe_box new_subscribe_hidden">
    <div class="subscribe_box_left">
        <div class="guanzu_pic"><img src="<?php echo $app_download_content['2'];?>"></div>
        <div class="guanzu_text">
            <h5><?php echo $app_download_content['0'];?></h5>
            <p><?php echo $app_download_content['1'];?></p>
        </div>
    </div>
    <div class="subscribe_box_right">
        <a href="<?php echo $app_download_content['3'];?>"><div class="guanzu_button tc-template__bg">下载</div></a>
        <div class="guanzu_close" onclick="close_subscribe();"></div>
    </div>
</section>
<?php } ?>
<script>
function close_subscribe(){
    $("#subscribe_box").hide();
    <?php if($show_app_download == 1 ) { ?>
    $("#app_download_box").hide();
    <?php } ?>
    $.ajax({
        type: "GET",
        url: "<?php echo $ajaxCloseSubscribeUrl;?>",
        data: "u=1",
        success: function(msg){
        }
    });
}
function check_subscribe(){
    $.ajax({
        type: "GET",
        url: "<?php echo $ajaxCheckSubscribeUrl;?>",
        data: "u=1",
        success: function(msg){
            var msg = $.trim(msg);
            if(msg == '100'){
                $("#subscribe_box").removeClass("new_subscribe_hidden");
            }else if(msg != '2'){
                <?php if($show_app_download == 1 && $__IsMagapp == 0 && $__IsQianfan == 0 && $__IsApp == 0 ) { ?>
                $("#app_download_box").removeClass("new_subscribe_hidden");
                <?php } ?>
            }
        }
    });
}
function show_subscribe(){
    layer.open({
        content: '<img src="<?php echo $tongchengConfig['fwh_qrcode'];?>"><p>长按二维码识别关注<p/>'
        ,btn: '确认'
      });
}
$(document).ready(function(){
    setTimeout(function(){check_subscribe();},500);
});
</script>