<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<style>
.tc-template__color{color:<?php echo $tongchengConfig['template_color'];?> !important;}
.tc-template__bg{background:<?php echo $tongchengConfig['template_color'];?> !important;}
.tc-template__border{ border-color:<?php echo $tongchengConfig['template_color'];?> !important;}
</style>