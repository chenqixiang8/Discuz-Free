<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<section class="index-toutiao__box">
    <div class="toutiao-box__title tc-template__color"><em class="index_toutiao_title_icon"></em>同城头条<a href="plugin.php?id=tom_tctoutiao&amp;site=<?php echo $site_id;?>&amp;mod=index">全部<i class="tciconfont tcicon-jiantou__you"></i></a></div>
    <?php if($tctoutiaoConfig['tongcheng_index_type'] == 1) { ?>
    <div class="toutiao-box__list">
        <?php if(is_array($tctoutiaoList)) foreach($tctoutiaoList as $key => $value) { ?>        <?php if($value['template_type'] == 1) { ?>
        <a class="toutiao-list__item tuotiao-list__type2 clearfix" href="plugin.php?id=tom_tctoutiao&amp;site=<?php echo $site_id;?>&amp;mod=info&amp;aid=<?php echo $value['id'];?>">
            <div class="toutiao-item__content">
                <div class="title"><?php echo $value['title'];?></div>
                <div class="xinxi">
                    <span><?php echo $value['zuozheInfo']['name'];?></span>
                    <span><i class="tciconfont tcicon-toutiao_yanjing"></i><?php echo $value['clicks'];?>人看过</span>
                </div>
            </div>
            <div class="toutiao-item__pic toutiao-item__picnum">
                <div class="item-picnum">
                    <?php if(is_array($value['coverList'])) foreach($value['coverList'] as $k => $v) { ?>                    <img src="<?php echo $v;?>">
                    <?php } ?>
                    <?php if($value['type'] == 3) { ?>
                    <div class="bofang"><img src="source/plugin/tom_tctoutiao/images/icon_play.png"></div>
                    <?php } elseif($value['type'] == 2 && $value['photoCount'] > 0) { ?>
                    <div class="picnum"><i class="tciconfont tcicon-tupian"><span><?php echo $value['photoCount'];?>图</span></i></div>
                    <?php } ?>
                </div>
            </div>
        </a>
        <?php } elseif($value['template_type'] == 2) { ?>
        <a class="toutiao-list__item tuotiao-list__type1" href="plugin.php?id=tom_tctoutiao&amp;site=<?php echo $site_id;?>&amp;mod=info&amp;aid=<?php echo $value['id'];?>">
            <div class="toutiao-item__title"><?php echo $value['title'];?></div>
            <div class="toutiao-item__pic2 dislay-flex toutiao-item__picnum">
                <?php if(is_array($value['coverList'])) foreach($value['coverList'] as $k => $v) { ?>                <div class="pic-item flex"><img src="<?php echo $v;?>"></div>
                <?php } ?>
                <?php if($value['type'] == 2 && $value['photoCount'] > 0) { ?>
                <div class="picnum"><i class="tciconfont tcicon-tupian"><span><?php echo $value['photoCount'];?>图</span></i></div>
                <?php } ?>
            </div>
            <div class="toutiao-item__xx">
                <span><?php echo $value['zuozheInfo']['name'];?></span>
                <span><i class="tciconfont tcicon-toutiao_yanjing"></i><?php echo $value['clicks'];?>人看过</span>
            </div>
        </a>
        <?php } elseif($value['template_type'] == 3) { ?>
        <a class="toutiao-list__item tuotiao-list__type4 clearfix" href="plugin.php?id=tom_tctoutiao&amp;site=<?php echo $site_id;?>&amp;mod=info&amp;aid=<?php echo $value['id'];?>">
            <div class="toutiao-item__content">
                <div class="title"><?php echo $value['title'];?></div>
                <div class="xinxi">
                    <span><?php echo $value['zuozheInfo']['name'];?></span>
                    <span><i class="tciconfont tcicon-toutiao_yanjing"></i><?php echo $value['clicks'];?>人看过</span>
                </div>
            </div>
        </a>
        <?php } ?>
        <?php } ?>
    </div>
    <?php } ?>
    <?php if($tctoutiaoConfig['tongcheng_index_type'] == 2) { ?>
    <div class="swiper-container swiper-container-toutiao">
        <div class="toutiao-box__list swiper-wrapper">
            <?php if(is_array($tctoutiaoList)) foreach($tctoutiaoList as $key => $value) { ?>            <?php if($value['coverPic']) { ?>
            <a class="swiper-slide toutiao-list__item tuotiao-list__type2 clearfix" href="plugin.php?id=tom_tctoutiao&amp;site=<?php echo $site_id;?>&amp;mod=info&amp;aid=<?php echo $value['id'];?>">
                <div class="toutiao-item__content">
                    <div class="title"><?php echo $value['title'];?></div>
                    <div class="xinxi">
                        <span><?php echo $value['zuozheInfo']['name'];?></span>
                        <span><i class="tciconfont tcicon-toutiao_yanjing"></i><?php echo $value['clicks'];?>人看过</span>
                    </div>
                </div>
                <div class="toutiao-item__pic toutiao-item__picnum">
                    <div class="item-picnum">
                        <img src="<?php echo $value['coverPic'];?>">
                        <?php if($value['type'] == 3) { ?>
                        <div class="bofang"><img src="source/plugin/tom_tctoutiao/images/icon_play.png"></div>
                        <?php } elseif($value['type'] == 2 && $value['photoCount'] > 0) { ?>
                        <div class="picnum"><i class="tciconfont tcicon-tupian"><span><?php echo $value['photoCount'];?>图</span></i></div>
                        <?php } ?>
                    </div>
                </div>
            </a>
            <?php } ?>
            <?php } ?>
        </div>
    </div>
    <?php } ?>
</section>