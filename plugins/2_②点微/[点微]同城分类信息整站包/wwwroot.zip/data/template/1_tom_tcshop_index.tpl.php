<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<!DOCTYPE html><html>
<head>
<?php if($isGbk) { ?>
<meta http-equiv="Content-Type" content="text/html; charset=GBK">
<?php } else { ?>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<?php } ?>
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="format-detection" content="telephone=no" />
<title><?php echo $tcshopConfig['plugin_name'];?> - <?php echo $__SitesInfo['name'];?></title>
<meta name="keywords" content="<?php echo $shareTitle;?>" />
<meta name="description" content="<?php echo $shareDesc;?>" />
<link rel="stylesheet" href="source/plugin/tom_tongcheng/images/style.css?v=<?php echo $cssJsVersion;?>" />
<link rel="stylesheet" href="source/plugin/tom_tcshop/images/iconfont/iconfont.css?v=<?php echo $cssJsVersion;?>" />
<link rel="stylesheet" href="source/plugin/tom_tongcheng/images/jquery-popups.css?v=<?php echo $cssJsVersion;?>" />
<link rel="stylesheet" href="source/plugin/tom_tcshop/images/shop_style.css?v=<?php echo $cssJsVersion;?>" />
<link href="source/plugin/tom_tongcheng/images/swiper.min.css" rel="stylesheet" />
<script src="source/plugin/tom_tcshop/images/jquery.min-2.1.3.js" type="text/javascript"></script>
<script src="source/plugin/tom_tongcheng/images/swiper.min.js" type="text/javascript"></script>
<script src="source/plugin/tom_tongcheng/images/global.js?v=<?php echo $cssJsVersion;?>" type="text/javascript"></script>
<script src="source/plugin/tom_tongcheng/images/jquery-popups.js?v=<?php echo $cssJsVersion;?>" type="text/javascript"></script>
<script type="text/javascript">
    var commonjspath = 'source/plugin/tom_tongcheng/images';
</script>
<script src="source/plugin/tom_tongcheng/images/common.js?v=<?php echo $cssJsVersion;?>" type="text/javascript" type="text/javascript"></script><?php include template('tom_tongcheng:template_css'); ?><style>
.swiper-pagination-bullet-active{ background:<?php echo $tongchengConfig['template_color'];?>}
.index-focuspic__zhong .swiper-pagination-bullet-active{ width:6px; }
</style>
</head>
<body id="shop_index" class="shop_index">
<div id="sites-lbs" class='pop-ups__container'>
  <div class="pop-ups__overlay"></div>
  <div class="pop-ups__modal">
      <div class="pop-ups__box">
          <div class="index_lbs_top">当前站点：<?php echo $__SitesInfo['lbs_name'];?></div>
          <section class="index_lbs_sites">
            <h5>热门站点</h5>
            <div class="index_lbs_sites-list clearfix">
                <span><a href="plugin.php?id=tom_tcshop&amp;site=1&amp;mod=index&amp;lbs_no=1"><?php echo $tongchengConfig['lbs_name'];?></a></span>
                <?php if(is_array($hotSitesList)) foreach($hotSitesList as $key => $val) { ?>                <span><a href="plugin.php?id=tom_tcshop&amp;site=<?php echo $val['id'];?>&amp;mod=index&amp;lbs_no=1"><?php echo $val['lbs_name'];?></a></span>
                <?php } ?>
            </div>
            <?php if(is_array($cateSitesList)) foreach($cateSitesList as $key => $val) { ?>            <h5><?php echo $val['name'];?></h5>
            <div class="index_lbs_sites-list clearfix">
                <?php if(is_array($val['sites'])) foreach($val['sites'] as $kk => $vv) { ?>                <span><a href="plugin.php?id=tom_tcshop&amp;site=<?php echo $vv['id'];?>&amp;mod=index&amp;lbs_no=1"><?php echo $vv['lbs_name'];?></a></span>
                <?php } ?>
            </div>
            <?php } ?>
            </section>
          <div class="pop-ups__block"></div>
      </div>
      <div class="pop-ups__close">
          <a href="javascript:void(0);" class="tcui-btn tcui-btn_default close-popups">关闭</a>
      </div>
  </div>
</div>
<?php if($focuspicTopList) { ?>
<section class="index-box index-focuspic">
    <section class="new-index__focuspic swiper-container-focuspic swiper-container">
        <div class="swiper-wrapper">
            <?php if(is_array($focuspicTopList)) foreach($focuspicTopList as $key => $val) { ?>            <div class="swiper-slide">
                <a href="<?php echo $val['link'];?>"><img src="<?php echo $val['picurl'];?>" width="100%"></a>
            </div>
            <?php } ?>
        </div>
        <div class="swiper-pagination swiper-pagination-focuspic" style="bottom: 30px;"></div>
    </section>
    <?php if($tcadminConfig['open_sites'] == 1) { ?>
    <a class="site-lbs open-popups" data-target="#sites-lbs" href="javascript:void(0);"><?php echo $__SitesInfo['lbs_name'];?><i class="tciconfont tcicon-jiantou__xia"></i></a>
    <?php } ?>
    <div class="index-box search-box">
        <form id="search_form" class="search-main dislay-flex" onsubmit="return false;">
            <div class="search-lt">
                <div class="search-lt__select">店铺</div>
                <div class="select-box__list">
                    <div class="select-list__item" data-mode="shop">店铺</div>
                    <?php if($__ShowTcmall == 1) { ?>
                    <div class="select-list__item" data-mode="mall">商城</div>
                    <?php } ?>
                    <?php if($__ShowTcqianggou == 1) { ?>
                    <div class="select-list__item" data-mode="qianggou">抢购</div>
                    <?php } ?>
                    <?php if($__ShowTcptuan == 1) { ?>
                    <div class="select-list__item" data-mode="ptuan">拼团</div>
                    <?php } ?>
                    <?php if($__ShowTcqianggou == 1) { ?>
                    <div class="select-list__item" data-mode="coupon">卡券</div>
                    <?php } ?>
                </div>
            </div>
            <div class="search-rt flex dislay-flex">
                <input type="text" name="keyword" id="keyword" class="flex" placeholder="搜店铺">
                <input type="hidden" name="formhash" value="<?php echo $formhash;?>">
                <i class="tciconfont tcicon-sousuo id-search__btn"></i>
            </div>
        </form>
    </div>
</section>
<section class="h30 white"></section>
<?php } ?>
<section class="shop_nav" style="margin-top: -2px;">
<section class="nav-li swiper-container swiper-container-nav">
        <div class="swiper-wrapper">
            <ul class="swiper-slide">
            <?php if(is_array($navList)) foreach($navList as $key => $val) { ?>                <li>
                    <a href="<?php echo $val['link'];?>">
                      <section class="nav-li-pic">
                            <img src="<?php echo $val['picurl'];?>?v=1"/>
                      </section>
                      <p><?php echo $val['title'];?></p>
                    </a>
                </li>
                <?php if(($navCount> 10 && $val['i'] == 10) || ($navCount> 20 && $val['i'] == 20) || ($navCount> 30 && $val['i'] == 30) || ($navCount> 40 && $val['i'] == 40) ) { ?>
                </ul>
                <ul class="swiper-slide">
                <?php } ?>
            <?php } ?> 
            </ul>
        </div>
        <?php if($navCount> 10  ) { ?>
        <div class="swiper-pagination swiper-pagination-nav" style="bottom: 5px;"></div>
        <?php } ?>
        <section class="clear"></section>
    </section>
</section>
<?php if($line4NavCount > 0) { ?>
<section class="shop-qukuai__box dislay-flex">
    <?php if(is_array($line4NavList)) foreach($line4NavList as $key => $value) { ?>    <a class="shop-qukuai__item flex" href="<?php echo $value['1'];?>"><img src="source/plugin/tom_tcshop/images/index_ads/<?php echo $value['0'];?>"></a>
    <?php } ?>
</section>
<?php } ?>
<section class="index-headlines">
    <section class="shop_headlines">
        <div class="shop_headlines-title">商圈<span>头条</span></div>
        <div class="shop_headlines-list id-index-scroll-ad">
            <ul>
                <?php if(is_array($newTcshopList)) foreach($newTcshopList as $key => $val) { ?>                <li><img src="<?php echo $val['picurl'];?>"><font color="<?php echo $tongchengConfig['template_color'];?>"><?php echo $val['name'];?></font> 入驻成功</li>
                <?php } ?>
            </ul>
        </div>
        <div class="shop_headlines-ruzhu"><a class="tc-template__bg" href="plugin.php?id=tom_tcshop&amp;site=<?php echo $site_id;?>&amp;mod=ruzhu&amp;prand=<?php echo $prand;?>">立即入驻</a></div> 
    </section>
</section>
<?php if($focuspicZhongList) { ?>
<section class="index-zhongfocuspic">
    <section class="index-focuspic__zhong swiper-zhong-focuspic swiper-container">
        <div class="swiper-wrapper">
            <?php if(is_array($focuspicZhongList)) foreach($focuspicZhongList as $key => $val) { ?>            <div class="swiper-slide">
                <a href="<?php echo $val['link'];?>"><img src="<?php echo $val['picurl'];?>" width="100%"></a>
            </div>
            <?php } ?>
        </div>
        <div class="swiper-pagination swiper-pagination-zhongfocuspic"></div>
    </section>
</section>
<?php } ?>
<section class="shop_list" style="margin-top:0px;">
<div class="shop_list-menu">
    	<a class="list-menu <?php if($tab == 1) { ?>on<?php } ?>" href="plugin.php?id=tom_tcshop&amp;site=<?php echo $site_id;?>&amp;mod=index&amp;tab=1">
            <div class="title <?php if($tab == 1) { ?>tc-template__color<?php } ?>">推荐</div>
            <div class="msg <?php if($tab == 1) { ?>tc-template__bg<?php } ?>">为你推荐</div>
        </a>
    	<a class="list-menu <?php if($tab == 2) { ?>on<?php } ?>" href="plugin.php?id=tom_tcshop&amp;site=<?php echo $site_id;?>&amp;mod=index&amp;tab=2">
            <div class="title <?php if($tab == 2) { ?>tc-template__color<?php } ?>">新入</div>
            <div class="msg <?php if($tab == 2) { ?>tc-template__bg<?php } ?>">最新加入</div>
        </a>
    	<a class="list-menu <?php if($tab == 3) { ?>on<?php } ?>" href="plugin.php?id=tom_tcshop&amp;site=<?php echo $site_id;?>&amp;mod=index&amp;tab=3">
            <div class="title <?php if($tab == 3) { ?>tc-template__color<?php } ?>">附近</div>
            <div class="msg <?php if($tab == 3) { ?>tc-template__bg<?php } ?>">附近店铺</div>
        </a>
    </div>
    <div class="list-item" id="index-list"></div>
    <div class="list-msg" style="display: none;" id="load-html">加载中...</div>
    <div class="list-msg" style="display: none;" id="no-load-html">没有更多商家</div>
    <div class="list-msg" style="display: none;" id="no-list-html">没有相关商家</div>
</section>
<div id="dialogs">
    <!--BEGIN dialog1-->
    <div class="js_dialog" id="lbsDialog" style="display: none;">
        <div class="tcui-mask"></div>
        <div class="tcui-dialog" id="lbsDialogBox" style="top: 40%;">
        </div>
    </div>
    <!--END dialog1-->
</div><?php include template('tom_tcshop:footer'); ?><section class="back_top">
    <a href="javascript:void(0);"><img src="source/plugin/tom_tongcheng/images/back_top.png"></a>
</section>
<div style="display: none;"><?php echo $tongchengConfig['tongji_code'];?></div>
<script src="//res.wx.qq.com/open/js/jweixin-1.0.0.js" type="text/javascript" type="text/javascript"></script>
<script src="//api.map.baidu.com/api?v=2.0&ak=<?php echo $tcshopConfig['baidu_js_ak'];?>" type="text/javascript"></script>
<script>
var list_jm_link = '<?php echo $md5HostUrl;?>';
var list_top = 'list_scrollTop'+list_jm_link;
var list_page = 'list_page'+list_jm_link;
var list_data = 'list_data'+list_jm_link;

$(document).ready(function(){
   $.get("<?php echo $ajaxCommonClicksUrl;?>");
   setTimeout(function(){$.get("<?php echo $ajaxUpdateVipStatusUrl;?>");},800);
   setTimeout(function(){$.get("<?php echo $ajaxUpdateTopstatusUrl;?>");},900);
   setTimeout(function(){$.get("<?php echo $ajaxTongbu114Url;?>");},1000);
});

var scrollRunStatus = 0;
$(window).scroll(function () {
    var runScrollTop       = $(this).scrollTop();
    if(runScrollTop > 100 && scrollRunStatus == 0){
       scrollRunStatus = 1;
       console.log('runScrollTop:'+runScrollTop);
       $.get("<?php echo $ajaxAutoClickUrl;?>");
    }
});
    
$(document).ready(function(){
    var swiper1 = new Swiper('.swiper-container-nav', {
        pagination: '.swiper-pagination-nav',
        paginationClickable: true,
        spaceBetween: 30,
        centeredSlides: true,
        autoplay: 10000,
        autoplayDisableOnInteraction: false
    });
    <?php if($focuspicTopList) { ?>
    var swiper2 = new Swiper('.swiper-container-focuspic', {
        pagination: '.swiper-pagination-focuspic',
        paginationClickable: true,
        spaceBetween: 30,
        centeredSlides: true,
        autoplay: 2500,
        autoplayDisableOnInteraction: false
    });
    <?php } ?>
    <?php if($focuspicZhongList) { ?>
    var swiper3 = new Swiper('.swiper-zhong-focuspic', {
        pagination: '.swiper-pagination-zhongfocuspic',
        paginationClickable: true,
        spaceBetween:15,
        centeredSlides: true,
        autoplay: 2500,
        autoplayDisableOnInteraction: false
    });
    <?php } ?>
});

var loadPage = 1;
function indexLoadList(){
    loadPage = 1;
    loadList(1);
}

$(document).ready(function(){
    if($("#index-list").length>0){
        if(sessionStorage.getItem(list_page)){
            $('#index-list').html(sessionStorage.getItem(list_data));
            loadPage = sessionStorage.getItem(list_page);
            loadPage = loadPage*1;
            $(document).scrollTop(sessionStorage.getItem(list_top));
            
        }else{
            indexLoadList();
        }
    }
});

var loadListStatus = 0;
function loadList(Page) {
    if(loadListStatus == 1){
        return false;
    }
    loadListStatus = 1;
    $("#index-list").html('');
    $("#load-html").show();
    $.ajax({
        type: "GET",
        url: "<?php echo $ajaxIndexLoadListUrl;?>",
        data: {page:Page},
        success: function(msg){
            loadListStatus = 0;
            var data = eval('('+msg+')');
            if(data == 205){
                $("#no-list-html").show();
                return false;
            }else{
                loadPage += 1;
                $("#index-list").html(data);
            }
        }
    });
}

$(window).scroll(function () {
    var scrollTop       = $(this).scrollTop();
    var scrollHeight    = $(document).height();
    var windowHeight    = $(this).height();
    if ((scrollTop + windowHeight) >= (scrollHeight * 0.9)) {
        scrollLoadList();
    }
    
    if ((scrollTop + windowHeight) >= 1000) {
        $('.back_top').show();
    }else{
        $('.back_top').hide();
    }
    
    if ($(window).scrollTop()> 350) {
        sessionStorage.setItem(list_top, $(window).scrollTop());
        sessionStorage.setItem(list_data, $('#index-list').html());
        if(loadPage >= 1){ sessionStorage.setItem(list_page, loadPage); }
    } else {
        sessionStorage.removeItem(list_page);
        sessionStorage.removeItem(list_data);
        sessionStorage.removeItem(list_top);
    }
});

function scrollLoadList() {
    if(loadListStatus == 1){
        return false;
    }
    if(loadPage > 50){
        return false;
    }
    $('#load-html').show();
$('#no-load-html').hide();
    loadListStatus = 1;
    $.ajax({
        type: "GET",
        url: "<?php echo $ajaxIndexLoadListUrl;?>",
        data: {page:loadPage},
        success: function(msg){
            loadListStatus = 0;
            var data = eval('('+msg+')');
            if(data == 205){
                loadListStatus = 1;
                $('#load-html').hide();
                $('#no-load-html').show();
                return false;
            }else{
                loadPage += 1;
                $('#load-html').hide();
                $("#index-list").append(data);
            }
        }
    });
}

$(function() {
    setInterval(function() {
        var e = $(".id-index-scroll-ad ul");
        e.scrollTo({
            to: e.find("li").eq(0).height(),
            durTime: 800,
            delay: 80,
            callback: function() {
                var a = e.find("li").eq(0),
                i = a.clone(!0);
                e.scrollTop(0),
                a.remove(),
                e.append(i)
            }
        })
    },
    2e3)
});

$(function(){
    $('#dialogs').on('click', '.tcui-dialog__btn', function(){
        $(this).parents('.js_dialog').fadeOut(200);
    });
});

$(document).on('click','.back_top', function () {
    $('body,html').animate({scrollTop: 0}, 500);
    return false;
});
</script>
<script>
$(".search-main").on('click','.search-lt__select', function () {
    $(".select-box__list").toggle();
});

$(document).on("click",function(t) {
    var a = $(t.target);
    a.hasClass("search-lt__select") || $(".select-box__list").hide();
});

var _mode = 'shop';
var _searchUrl = "<?php echo $searchUrl;?>";
$(".select-box__list").on('click','.select-list__item', function () {
    _mode = $(this).data("mode");

    $(".search-lt__select").html($(this).html());
    
    var searchText = '';
    if(_mode == 'shop'){
        _searchUrl = "<?php echo $searchUrl;?>";
        searchText = '搜店铺';
    }else if(_mode == 'mall'){
        _searchUrl = "<?php echo $searchMallUrl;?>";
        searchText = '搜好货';
    }else if(_mode == 'qianggou'){
        _searchUrl = "<?php echo $searchQianggouUrl;?>";
        searchText = '搜抢购商品';
    }else if(_mode == 'coupon'){
        _searchUrl = "<?php echo $searchCouponUrl;?>";
        searchText = '搜优惠券';
    }else if(_mode == 'ptuan'){
        _searchUrl = "<?php echo $searchPtuanUrl;?>";
        searchText = '搜拼团商品';
    }
    
    $("#keyword").attr('placeholder', searchText);
});

$(".id-search__btn").click( function (){ 
    $.ajax({
        type: "GET",
        url: _searchUrl,
        data: $('#search_form').serialize(),
        success: function(msg){
            window.location = msg;
        }
    });
});
</script>
<script>
wx.config({
    debug: false,
    appId: '<?php echo $wxJssdkConfig["appId"];?>',
    timestamp: <?php echo $wxJssdkConfig["timestamp"];?>,
    nonceStr: '<?php echo $wxJssdkConfig["nonceStr"];?>',
    signature: '<?php echo $wxJssdkConfig["signature"];?>',
    jsApiList: [
      'onMenuShareTimeline',
      'onMenuShareAppMessage',
      'onMenuShareQQ',
      'previewImage',
      'openLocation', 
      'getLocation'
    ]
});
wx.ready(function () {
    wx.getLocation({
        type: 'wgs84', // Ĭ��Ϊwgs84��gps���꣬���Ҫ����ֱ�Ӹ�openLocation�õĻ������꣬�ɴ���'gcj02'
        success: function(res) {
            var point = new BMap.Point(res.longitude, res.latitude);
            var convertor = new BMap.Convertor();
            var pointArr = [];
            pointArr.push(point);
            convertor.translate(pointArr, 1, 5, function(data) {
                if (data.status === 0) {
                    $.get("<?php echo $ajaxUpdateLbsUrl;?>&latitude="+data.points[0].lat+"&longitude="+data.points[0].lng);
                } else {
                    $.get("<?php echo $ajaxUpdateLbsUrl;?>&latitude="+res.latitude+"&longitude="+res.longitude);
                }
            });
        }
    });
    wx.onMenuShareTimeline({
        title: '<?php echo $shareTitle;?>',
        link: '<?php echo $shareUrl;?>', 
        imgUrl: '<?php echo $shareLogo;?>', 
        success: function () { 
        },
        cancel: function () {
        }
    });
    wx.onMenuShareAppMessage({
        title: '<?php echo $shareTitle;?>',
        desc: '<?php echo $shareDesc;?>',
        link: '<?php echo $shareUrl;?>',
        imgUrl: '<?php echo $shareLogo;?>',
        type: 'link',
        dataUrl: '',
        success: function () { 
        },
        cancel: function () { 
        }
    });
    wx.onMenuShareQQ({
        title: '<?php echo $shareTitle;?>',
        desc: '<?php echo $shareDesc;?>',
        link: '<?php echo $shareUrl;?>',
        imgUrl: '<?php echo $shareLogo;?>',
        success: function () { 
        },
        cancel: function () { 
        }
    });
});
</script>
<!-- lbs start -->
<?php if($tcadminConfig['open_sites_lbs'] > 1 && $tcadminConfig['open_sites'] == 1 ) { ?>
<form name="lbsForm" id="lbsForm">
    <input type="hidden" id="id_city" name="city" value="" />
    <input type="hidden" id="id_district" name="district" value="" />
    <input type="hidden" name="formhash" value="<?php echo $formhash;?>" />
</form>
<script>
var gc = new BMap.Geocoder();
function getaddress(lat, lng) {
    <?php if($tcadminConfig['open_sites_lbs'] > 1) { ?>
    var point = new BMap.Point(lng, lat);
    gc.getLocation(point, function (rs) {
        var addComp = rs.addressComponents;
        <?php if($lbs_show == 1) { ?>
        alert(addComp.city +','+ addComp.district);
        <?php } ?>
        $('#id_city').val(addComp.city);
        $('#id_district').val(addComp.district);
        $.ajax({
            type: "GET",
            url: "<?php echo $ajaxLbsCheckUrl;?>",
            data: $('#lbsForm').serialize(),
            success: function(msg){
                var data = eval('('+msg+')');
                if(data == 100){
                    return false;
                }else{
                    $("#lbsDialogBox").html(data);
                    $("#lbsDialog").show();
                }
            }
        });
    });
    <?php } else { ?>
    return false;
    <?php } ?>
}
function closeLbs(){
    $.ajax({
        type: "GET",
        url: "<?php echo $ajaxLbsCloseUrl;?>",
        data: "u=1",
        success: function(msg){
        }
    });
}
</script>
<?php if($__IsWeixin == 1) { ?>
<script>
function getaddresswx(lat, lng) {
    var point = new BMap.Point(lng, lat);
    var convertor = new BMap.Convertor();
    var pointArr = [];
    pointArr.push(point);
    convertor.translate(pointArr, 1, 5, function(data) {
        if (data.status === 0) {
            $.get("<?php echo $ajaxUpdateLbsUrl;?>&latitude="+data.points[0].lat+"&longitude="+data.points[0].lng);
            getaddress(data.points[0].lat, data.points[0].lng);
        } else {
            getaddress(lat, lng);
        }
    });
}
wx.ready(function () {
    <?php if($tcadminConfig['open_sites_lbs'] > 1 ) { ?>
    wx.getLocation({
        type: 'wgs84',
        success: function(res) {
            getaddresswx(res.latitude, res.longitude);
        }
    });
    <?php } ?>
});
</script>
<?php } else { if($tongchengConfig['open_moblie_https_location'] == 1) { ?>
<script>
$(document).ready(function(){
   h5Geolocation();
});
function h5Geolocation(){
if (navigator.geolocation){
navigator.geolocation.getCurrentPosition(
function(position) {  
var lat = position.coords.latitude;
var lng = position.coords.longitude;
var point = new BMap.Point(lng, lat);
var convertor = new BMap.Convertor();
var pointArr = [];
pointArr.push(point);
convertor.translate(pointArr, 1, 5, function(data) {
                    if (data.status === 0) {
                        latitude = data.points[0].lat;
                        longitude = data.points[0].lng;
} else {
                        latitude = lat;
                        longitude = lng;
}
                    $.get("<?php echo $ajaxUpdateLbsUrl;?>&latitude="+latitude+"&longitude="+longitude);
                    getaddress(latitude, longitude);
});
 },
function(error) {
}
)
}else{
tusi('浏览器不支持Geolocation服务');
}
}
</script>
<?php } } } ?>
<!-- lbs end -->
</body>
</html>