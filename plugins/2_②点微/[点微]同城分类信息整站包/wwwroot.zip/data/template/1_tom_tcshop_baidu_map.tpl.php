<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<script>
// ��ͼAPI START
var latitude = longitude = null;
var type = 0;
var isSaveClick = true;
var gc = new BMap.Geocoder();
function getaddress(lat, lng) {
    $('#hidlat').val(lat);
    $('#hidlng').val(lng);
    if (isSaveClick) {
        $('#locationtext').text("定位中...");
        var point = new BMap.Point(lng, lat);
        gc.getLocation(point, function (rs) {
            var addComp = rs.addressComponents;
            $('#locationtext').text('定位');
            $('#address').val(addComp.city + addComp.district + addComp.street + addComp.streetNumber);
        });
    }
    isSaveClick = true;
}
function getLocation() {
    getaddress(res.latitude, res.longitude);
}
function LocationOK(x, y) {
    getaddress(x, y);
    $("#baidumap").hide();
}
function LocationCancel(x, y) {
    $("#baidumap").hide();
}

$("#mylocation").click(function() {
    $("#actionsheet_cancel").click();
    type = 2;
    <?php if($tongchengConfig['open_moblie_https_location'] == 1) { ?>
    h5Geolocation();
    <?php } else { ?>
    wapGeolocation()
    <?php } ?>
});

$("#maplocation").click(function() {
    $("#baidumap").show();
    $("#actionsheet_cancel").click();
});

$(function () {
    var actionSheet = $('#actionSheet_wrap');
    function hideActionSheet() {
        if (actionSheet.hasClass('tcui-actionsheet_toggle')) {
            actionSheet.removeClass('tcui-actionsheet_toggle');
        }
        return false;
    }
    $('#actionsheet_cancel').on('click', hideActionSheet);
    $("#showActionSheet").on("click", function () {
        if (tomBrowser.versions.WindowsWechat) {
            return tusi("只能在手机端定位哦");
        }
        
        type = 1;
        <?php if($tongchengConfig['open_moblie_https_location'] == 1) { ?>
        h5Geolocation();
        <?php } else { ?>
        wapGeolocation()
        <?php } ?>
        actionSheet.addClass('tcui-actionsheet_toggle');
        return false;
    });
});

function h5Geolocation(){
if (navigator.geolocation){
navigator.geolocation.getCurrentPosition(
function(position) {  
var lat = position.coords.latitude;
var lng = position.coords.longitude;
var point = new BMap.Point(lng, lat);
var convertor = new BMap.Convertor();
var pointArr = [];
pointArr.push(point);
convertor.translate(pointArr, 1, 5, function(data) {
                    if (data.status === 0) {
                        latitude = data.points[0].lat;
                        longitude = data.points[0].lng;
} else {
                        latitude = lat;
                        longitude = lng;
}
                    if(type == 1){
                        $('#hidlat').val(latitude); // γ�ȣ�����������ΧΪ90 ~ -90
                        $('#hidlng').val(longitude); // ���ȣ�����������ΧΪ180 ~ -180��
                        $("#baidumap iframe").attr("src", 'plugin.php?id=tom_tcshop&site=<?php echo $site_id;?>&mod=baidumap&lat=' + latitude + "&lng=" + longitude);
                    }else if(type == 2){
                        getaddress(latitude, longitude);
                    }
});
 },
function(error) {
tusi("定位失败:"+error.code)
}
)
}else{
tusi('浏览器不支持Geolocation服务');
}
}

function wapGeolocation(){
var geolocation = new BMap.Geolocation();
geolocation.getCurrentPosition(function(r){
if(this.getStatus() == BMAP_STATUS_SUCCESS){
            if(type == 1){
                $('#hidlat').val(r.point.lat); // γ�ȣ�����������ΧΪ90 ~ -90
                $('#hidlng').val(r.point.lng); // ���ȣ�����������ΧΪ180 ~ -180��
                $("#baidumap iframe").attr("src", 'plugin.php?id=tom_tcshop&site=<?php echo $site_id;?>&mod=baidumap&lat=' + r.point.lat + "&lng=" + r.point.lng);
            }else if(type == 2){
                getaddress(r.point.lat, r.point.lng);
            }
}else{
tusi('定位失败:'+this.getStatus());
}        
},{enableHighAccuracy: true})
}
// ��ͼAPI END
</script>