<?php
//Discuz! cache file, DO NOT modify me!
//Identify: 589ab69c52aeebcf7d0d80a0d577e0dd

$pluginsetting = array (
);
?>