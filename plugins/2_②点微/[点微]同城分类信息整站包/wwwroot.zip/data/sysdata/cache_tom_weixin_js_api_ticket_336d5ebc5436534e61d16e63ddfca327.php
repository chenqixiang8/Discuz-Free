<?php
//Discuz! cache file, DO NOT modify me!
//Identify: 4362f447d767ce392ba9c1a0e8acd85c

$js_api_ticket='';
$cache_time='1584877949';
?>