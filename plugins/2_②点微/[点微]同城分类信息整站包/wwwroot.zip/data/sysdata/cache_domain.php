<?php
//Discuz! cache file, DO NOT modify me!
//Identify: 259e9d60370cf2131a8609d216c5c990

$domain = array (
  'defaultindex' => 'forum.php',
  'holddomain' => 'www|*blog*|*space*|*bbs*',
  'list' => 
  array (
  ),
  'app' => 
  array (
    'portal' => '',
    'forum' => '',
    'group' => '',
    'home' => '',
    'default' => '',
  ),
  'root' => 
  array (
    'home' => '',
    'group' => '',
    'forum' => '',
    'topic' => '',
    'channel' => '',
  ),
);
?>