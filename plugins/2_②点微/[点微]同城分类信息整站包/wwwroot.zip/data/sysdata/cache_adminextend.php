<?php
//Discuz! cache file, DO NOT modify me!
//Identify: 8e83829499b95916231bf71ad57b9bad

$adminextend = array (
  0 => 'tom.php',
);
?>