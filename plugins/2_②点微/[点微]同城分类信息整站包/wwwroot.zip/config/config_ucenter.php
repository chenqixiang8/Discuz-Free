<?php


define('UC_CONNECT', 'mysql');

define('UC_DBHOST', 'localhost');
define('UC_DBUSER', 'tom');
define('UC_DBPW', 'tom123');
define('UC_DBNAME', 'tom');
define('UC_DBCHARSET', 'utf8');
define('UC_DBTABLEPRE', '`tom`.pre_ucenter_');
define('UC_DBCONNECT', 0);

define('UC_CHARSET', 'utf-8');
define('UC_KEY', 'U979y8Zc21EbH7Ucu9C76f9bt0A3hfR682p7N7Kcgd1aB5Rfw0LbXaH9D24a5cW0');
define('UC_API', 'http://127.0.0.1/tom/uc_server');
define('UC_APPID', '1');
define('UC_IP', '');
define('UC_PPP', 20);
?>